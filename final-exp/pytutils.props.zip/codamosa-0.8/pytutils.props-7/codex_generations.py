

# Generated at 2022-06-12 08:09:36.134394
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        name = lazyclassproperty(lambda cls: 'foo')

    # check that Test.name is cached
    assert Test.name == 'foo'
    Test._lazy_name = 'bar'
    assert Test.name == 'bar'



# Generated at 2022-06-12 08:09:45.338438
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def x(cls):
            print("%s.x was evaluated" % cls.__name__)
            return cls.__name__

        @lazyclassproperty
        def y(cls):
            print("%s.y was evaluated" % cls.__name__)
            return cls.__name__

    class B(A):
        pass

    assert A.x == "A"
    assert A.x == "A"
    assert A.x == "A"
    assert B.x == "B"
    assert B.x == "B"
    assert A.y == "A"
    assert B.y == "B"
    assert A.y == "A"
    assert B.y == "B"



# Generated at 2022-06-12 08:09:55.132415
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Demo class as mixin
    class DemoMixin(object):
        @lazyperclassproperty
        def demo_lazy_perclass_property(cls):
            return cls.__name__
    # Test class using the mixin
    class DemoTestClass(DemoMixin):
        pass
    # Test class inheriting the test class
    class DemoTestClassInheritor(DemoTestClass):
        pass
    # Test class not using the mixin
    class DemoTestClassWithoutMixin(object):
        pass

    # Test if all classes use their own instances
    assert DemoMixin.demo_lazy_perclass_property == "DemoMixin"
    assert DemoTestClass.demo_lazy_perclass_property == "DemoTestClass"
    assert DemoTestClassInheritor.demo_l

# Generated at 2022-06-12 08:09:59.977965
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:07.603668
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 'x'

        @lazyclassproperty
        def y(cls):
            print('y')
            return 'y'

    class B(A):
        @lazyclassproperty
        def y(cls):
            print('y')
            return 'y'

        @lazyclassproperty
        def z(cls):
            print('z')
            return 'z'

    assert A.x == 'x'
    assert A.x == 'x'
    assert B.y == 'y'
    assert B.y == 'y'
    assert B.z == 'z'
    assert B.z == 'z'
    assert A.x == 'x'



# Generated at 2022-06-12 08:10:11.402574
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:22.095171
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return dict()
        @lazyclassproperty
        def y(cls):
            return list()

    class B(A):
        pass

    assert A.x is A.x, 'A.x should be the same'
    assert A.y is A.y, 'A.y should be the same'
    assert B.x is B.x, 'B.x should be the same'
    assert B.y is B.y, 'B.y should be the same'
    assert A.x is B.x, 'A.x and B.x should be the same'
    assert A.y is B.y, 'A.y and B.y should be the same'


# Generated at 2022-06-12 08:10:27.217021
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_function(cls):
        return 'function'

    class TestClass(object):
        _property = lazyclassproperty(test_function)

        def __init__(self, value):
            self.value = value

    assert TestClass._property == 'function'
    assert TestClass(1)._property == 'function'


# Generated at 2022-06-12 08:10:33.557692
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print("Computing for", cls)
            return "hello"

    class B(A):
        pass

    class C(A):
        pass

    print("A.prop:", A.prop)
    print("B.prop:", B.prop)
    print("C.prop:", C.prop)



# Generated at 2022-06-12 08:10:41.945093
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazyprop(cls):
            return cls.__name__

    assert A.lazyprop == 'A'

    class B(A):
        pass

    assert A.lazyprop == 'A'
    assert B.lazyprop == 'B'

    class C(A):
        @lazyclassproperty
        def lazyprop(cls):
            return 'C'

    assert A.lazyprop == 'A'
    assert B.lazyprop == 'B'
    assert C.lazyprop == 'C'



# Generated at 2022-06-12 08:10:49.873186
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:

        @lazyperclassproperty
        def foo(self):
            print('eval foo')
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'



# Generated at 2022-06-12 08:10:54.264740
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:59.058135
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(self):
            return 'x'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(self):
            return 'y'

    class D(C):
        pass

    assert A().x == 'x'
    assert B().x == 'x'
    assert C().x == 'y'
    assert D().x == 'y'



# Generated at 2022-06-12 08:11:02.170867
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def get_attribute():
        return 123

    class A:
        get_attribute = lazyclassproperty(get_attribute)

    assert A.get_attribute == 123



# Generated at 2022-06-12 08:11:07.005070
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):
        k = 0

        @lazyclassproperty
        def x(cls):
            cls.k = 1
            return 1


    Test.k = 0
    Test().k = 0
    assert Test.x == 1
    assert Test.k == 1
    assert Test().k == 0
    assert Test().x == 1



# Generated at 2022-06-12 08:11:10.723444
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        @classmethod
        def bar(cls):
            return cls()


    class Bar(Foo):
        pass


    assert Foo().bar is Foo().bar
    assert Foo().bar is not Bar().bar


# Generated at 2022-06-12 08:11:17.350232
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        @lazyclassproperty
        def calc(cls):
            return 'results of expensive calculation'

    class Y(X):
        pass

    assert X.calc == 'results of expensive calculation'
    assert Y.calc == 'results of expensive calculation'
    X.calc = 'foo'
    assert X.calc == 'foo'
    assert Y.calc == 'results of expensive calculation'



# Generated at 2022-06-12 08:11:23.848635
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def n(self):
            print('computing n')
            return 1.23

    assert Foo.n == Foo.n == 1.23
    assert Foo().n == Foo().n == 1.23
    assert Foo.n == 1.23
    assert Foo().n == 1.23

    class Bar(Foo):
        pass

    assert Bar.n == Bar.n == 1.23
    assert Bar().n == Bar().n == 1.23



# Generated at 2022-06-12 08:11:30.402162
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return "Got %s" % cls.__name__

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def x(cls):
            return "C.x: %s" % cls.__name__

    class D(C):
        pass

    assert C.x == 'C.x: C'
    assert D.x == 'C.x: D'
    assert A.x == 'Got A'
    assert B.x == 'Got B'



# Generated at 2022-06-12 08:11:33.300362
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def attr(cls):
            print('value calculated')
            return 42
    print(A.attr)
    print(A.attr)



# Generated at 2022-06-12 08:11:41.779225
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:51.670412
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:56.516470
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:01.192721
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:05.248269
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def some_function(cls):
        return 'class'

    class TestClass(object):
        @lazyclassproperty
        def some_property(cls):
            return some_function(cls)

    assert TestClass.some_property == 'class'



# Generated at 2022-06-12 08:12:11.989860
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:15.083921
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            return cls.__name__

    assert C.prop == 'C'
    assert C.prop == 'C'

    class D(C):
        pass

    assert D.prop == 'D'


# Generated at 2022-06-12 08:12:18.328133
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:23.995141
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from unittest import TestCase, main

    class Test(TestCase):
        n = 0

        @lazyclassproperty
        def increment(cls):
            cls.n += 1

        def test_increment(self):
            Test.increment
            Test.increment
            self.assertEqual(Test.n, 1)

    main()



# Generated at 2022-06-12 08:12:33.459808
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def cache(cls):
            return 0
    c1, c2 = C(), C()
    assert c1.cache == 0
    assert c2.cache == 0
    c1.cache = 1
    assert c1.cache == 1
    assert c2.cache == 1
    c2.cache = 2
    assert c1.cache == 2
    assert c2.cache == 2
    del c1.cache
    assert hasattr(C, '_lazy_cache')
    assert c1.cache == 2
    assert c2.cache == 2
    del c2.cache
    assert not hasattr(C, '_lazy_cache')
    assert c1.cache == 0
    assert c2.cache == 0



# Generated at 2022-06-12 08:12:50.512046
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            print("Running 'A' test")
            return 123

    class B(A):
        @lazyperclassproperty
        def test(cls):
            print("Running 'B' test")
            return 321

    print("A.test: {}".format(A.test))
    print("B.test: {}".format(B.test))

    print("A.test: {}".format(A.test))
    print("B.test: {}".format(B.test))



# Generated at 2022-06-12 08:12:55.994774
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:04.936738
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 2
    assert A.x == 2
    assert A.x == 2  # second call will not repeat the computation

    class B(A):
        pass
    assert B.x == 2  # inherits A.x

    class C(object):
        @lazyclassproperty
        def x(cls):
            return cls.y
        y = 4
    assert C.x == 4

    class D(object):
        @lazyclassproperty
        def x(cls):
            return cls.y
    assert D.x == D.y == 5



# Generated at 2022-06-12 08:13:12.749425
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        """
        Test class for lazyclassproperty
        """
        @classproperty
        def class_attr(cls):
            return "class_attr"


# Generated at 2022-06-12 08:13:15.720843
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('x')
            return 'x'

    class B(A):
        pass

    assert A.x == B.x == 'x'



# Generated at 2022-06-12 08:13:25.354067
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A():
        @classmethod
        def foo(cls):
            return "foo"

        @lazyclassproperty
        def bar(cls):
            return cls.foo()

        @lazyclassproperty
        def bar2(cls):
            return cls.foo()

    assert A.bar == "foo"
    # the second time, we get cached value
    assert A.bar == "foo"
    # the property is per class
    class B(A):
        pass

    assert A.bar2 == "foo"
    assert B.bar2 == "foo"
    # foo function is not called
    assert A.foo.call_count == 0
    assert B.foo.call_count == 0



# Generated at 2022-06-12 08:13:30.629224
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def prop(cls):
            print("Initializing prop!")
            return 1

    assert hasattr(A, '_lazy_prop') == False
    assert A.prop == 1
    assert A.prop == 1

    class B(A):
        pass

    assert hasattr(B, '_lazy_prop') == False
    assert B.prop == 1
    assert B.prop == 1



# Generated at 2022-06-12 08:13:36.920344
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        @lazyclassproperty
        def fn(cls):
            return 1
    class Y(X):
        @lazyclassproperty
        def fn(cls):
            return 2
    assert X.fn == 1
    assert X.fn == 1
    assert Y.fn == 2
    assert Y.fn == 2
    assert X.fn == 1



# Generated at 2022-06-12 08:13:40.873429
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def TEST(cls):
            print('TEST')
            return cls.__name__

    assert TestClass.TEST == 'TestClass'
    assert TestClass.TEST == 'TestClass'
    assert TestClass.TEST == 'TestClass'



# Generated at 2022-06-12 08:13:51.968126
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import json

    class A(object):
        @lazyperclassproperty
        def data(cls):
            return json.loads(
                '[{"id": 1, "description": "Foo"}, {"id": 2, "description": "Bar"}]'
            )

        def __init__(self, id):
            self.id = id

        def __eq__(self, other):
            return self.id == other.id and self.description == other.description


    class B(A):
        @lazyperclassproperty
        def data(cls):
            return json.loads(
                '[{"id": 3, "description": "Foo"}, {"id": 4, "description": "Bar"}]'
            )


    class C(object):
        pass

    assert B.data != A.data


# Generated at 2022-06-12 08:14:17.265407
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self._test = True

        @lazyperclassproperty
        def test(self):
            return self._test

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self._test = False

    b = B()
    a = A()
    # print(a.test)
    # assert(a.test == True)
    # assert(b.test == False)
    b._test = True
    # assert(b.test == True)



# Generated at 2022-06-12 08:14:19.871336
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__
    class B(A):
        pass

    assert A.x == B.x == 'A'



# Generated at 2022-06-12 08:14:23.588041
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def name(cls):
            return 1

    class B(A):
        @lazyclassproperty
        def name(cls):
            return 2

    assert A.name == 1
    assert B.name == 2
    assert A.name == 1
    assert B.name == 2



# Generated at 2022-06-12 08:14:28.435427
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Bar(object):
        @lazyclassproperty
        def spam(cls):
            return 42

        @lazyclassproperty
        def spam_stale(cls):
            return 1337

    class Foo(Bar):
        pass

    assert Bar.spam == 42
    assert Bar.spam_stale == 1337

    assert Foo.spam == 42
    assert Foo.spam_stale == 1337

    assert Bar.spam is Foo.spam
    assert Bar.spam_stale is not Foo.spam_stale


# Generated at 2022-06-12 08:14:32.067450
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:14:37.535949
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Main(metaclass=DeclarativeMeta):
        @lazyperclassproperty
        def test_fct(cls):
            return cls.__name__

    class Sub(Main):
        pass

    class SubSub(Sub):
        pass

    assert Sub.test_fct == 'Sub'
    assert SubSub.test_fct == 'SubSub'
    assert Main.test_fct == 'Main'



# Generated at 2022-06-12 08:14:42.652359
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:

        @lazyclassproperty
        def foo(cls):
            print("foo")
            return 'foo'

    assert A.foo == 'foo'
    assert A.__dict__['_lazy_foo'] == 'foo'
    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == 'foo'
    assert '_lazy_foo' not in B.__dict__
    assert B.foo == 'foo'
    assert B.__dict__['_lazy_foo'] == 'foo'

    # Now let's change foo in A
    A.foo = 'bar'
    assert A.foo == 'bar'
    assert A.__dict__['_lazy_foo'] == 'bar'
    assert B.foo == 'foo'

# Generated at 2022-06-12 08:14:49.924753
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def _get_value_1(self):
            return 1
        value_1 = lazyperclassproperty(_get_value_1)

    class B(A):
        def _get_value_2(self):
            return 2
        value_2 = lazyperclassproperty(_get_value_2)

    class C(B):
        def _get_value_3(self):
            return 3
        value_3 = lazyperclassproperty(_get_value_3)

    a = A()
    b = B()
    c = C()

    assert a.value_1 == 1
    assert b.value_1 == 1
    assert c.value_1 == 1

    assert a.value_2 == 2
    assert b.value_2 == 2
    assert c.value_2 == 2

   

# Generated at 2022-06-12 08:14:51.522463
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_prop(self):
            return 'test'
    assert TestClass.test_prop == 'test'



# Generated at 2022-06-12 08:14:54.289213
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    fn_counter = {'counter': 0}

    class A(object):
        @lazyclassproperty
        def prop(cls):
            fn_counter['counter'] += 1
            return fn_counter['counter']

    assert A.prop == 1
    assert A.prop == 1
    assert fn_counter['counter'] == 1
    assert A.prop == 1



# Generated at 2022-06-12 08:15:34.933275
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def a(cls):
            return "foo"

    assert C.a == "foo"



# Generated at 2022-06-12 08:15:37.749572
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyclassproperty
        def p(cls):
            print('Running p()')
            return 'p()'

    class B(A):
        pass

    print(A.p)
    print(A.p)
    print(B.p)



# Generated at 2022-06-12 08:15:43.954136
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class BaseClass(object):
        @lazyperclassproperty
        def class_attr(cls):
            print("lazyperclassproperty: evaluating {0} __init__".format(cls.__class__.__name__))
            return "BaseClass"

    class SubClass(BaseClass):
        @lazyperclassproperty
        def class_attr(cls):
            print("lazyperclassproperty: evaluating {0} __init__".format(cls.__class__.__name__))
            return "SubClass"

    print("## lazyperclassproperty ##")
    print(BaseClass.class_attr)
    print(SubClass.class_attr)
    print(BaseClass.class_attr)
    print(SubClass.class_attr)


# Generated at 2022-06-12 08:15:49.799498
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print("test_lazyperclassproperty")

    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class Derived1(Base):
        pass

    class Derived2(Base):
        pass

    print("Base.prop: " + Base.prop)
    print("Derived1.prop: " + Derived1.prop)
    print("Derived2.prop: " + Derived2.prop)

    # Output:
    # Base.prop: Base
    # Derived1.prop: Derived1
    # Derived2.prop: Derived2



# Generated at 2022-06-12 08:15:56.365989
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("A.a %s" % cls.__name__)
            return "a"
    class B(A):
        @lazyclassproperty
        def b(cls):
            print("B.b %s" % cls.__name__)
            return "b"

    #print(A.a)
    #print(A.a)
    #print(B.a)
    #print(B.a)
    #print(A.b)
    #print(A.b)
    #print(B.b)
    #print(B.b)
    assert A.a == "a"
    assert A.a == "a"
    assert B.a == "a"
    assert B.a

# Generated at 2022-06-12 08:16:01.315889
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, n):
            self.n = n

        @lazyperclassproperty
        def a(cls):
            return [cls.n]

    class B(A):
        def __init__(self, n):
            super(B, self).__init__(n)

    assert A.a == B.a == []
    assert A('a').a == ['a']
    assert B('b').a == ['b']
    assert A('a').a == ['a']
    assert B('b').a == ['b']

# Generated at 2022-06-12 08:16:07.305905
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1 + 1

    assert A.prop == 2
    # Test that prop is still defined on A.
    assert hasattr(A, 'prop')

    class B(A):
        pass

    assert B.prop == 2
    # Test that prop is not defined on B.
    assert not hasattr(B, 'prop')

    class C(B):
        @classproperty
        def prop(cls):
            return 3

    assert C.prop == 3
    assert B.prop == 2



# Generated at 2022-06-12 08:16:10.619304
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestLazyClassProperty(object):

        @lazyclassproperty
        def testprop(cls):
            return cls.__name__

    assert TestLazyClassProperty.testprop == TestLazyClassProperty.testprop
    assert TestLazyClassProperty.testprop == 'TestLazyClassProperty'


# Generated at 2022-06-12 08:16:15.615204
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    cnt = 0
    class C(object):
        @lazyclassproperty
        def prop1(cls):
            nonlocal cnt
            cnt += 1
            return cnt

        @lazyclassproperty
        def prop2(cls):
            return C.prop1 + 1

    assert C.prop1 == 1
    assert C.prop1 == 1
    assert C.prop2 == 2



# Generated at 2022-06-12 08:16:25.956666
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def A_attr(cls):
            print("A_attr is evaluated")
            return 1

    print("Before accessing A.A_attr")
    assert A.A_attr == 1
    print("After first access")
    assert A.A_attr == 1
    print("After second access")

    class B(A):
        @lazyclassproperty
        def B_attr(cls):
            print("B_attr is evaluated")
            return 2

    print("Before accessing B.B_attr")
    assert B.B_attr == 2
    print("After first access")
    assert B.B_attr == 2
    print("After second access")
    print("Before accessing B.A_attr")
    assert B.A_attr == 1
    print("After first access")

# Generated at 2022-06-12 08:18:03.625328
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:10.327412
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test 1
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            print("run Base.prop")
            return 1

    class A(Base):
        pass

    class B(Base):
        pass

    assert Base.prop == 1
    assert A.prop == 1
    assert B.prop == 1

    # Test 2
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            print("run Base.prop")
            return 1

    class A(Base):
        @lazyperclassproperty
        def prop(cls):
            print("run A.prop")
            return 2

    class B(Base):
        pass

    assert Base.prop == 1
    assert A.prop == 2
    assert B.prop == 1

    # Test

# Generated at 2022-06-12 08:18:12.386796
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("pow!")
            return 42

    assert Foo.bar is Foo.bar



# Generated at 2022-06-12 08:18:15.849670
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):

        @lazyclassproperty
        def prop(cls):
            print("Called")
            return 42

    assert C.prop == 42
    assert C.__dict__['_lazy_prop'] == 42
    # second time calls shouldnt happen
    assert C.prop == 42
    assert C.__dict__['_lazy_prop'] == 42



# Generated at 2022-06-12 08:18:19.692511
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("A.a lazy property called")
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1
    assert A.a == 1



# Generated at 2022-06-12 08:18:23.824638
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:28.269809
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test_property(self):
            print('test_property!')
            return 1

    a = A()
    assert hasattr(a, 'test_property')
    assert a.test_property == 1
    assert hasattr(A, '_lazy_test_property')
    assert A._lazy_test_property == 1



# Generated at 2022-06-12 08:18:29.993831
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def test(cls):
            print('Hello')
            return 123

    # The 'Hello' will only be printed once
    a = Test()
    a.test
    a = Test()
    a.test
    a = Test()
    a.test



# Generated at 2022-06-12 08:18:34.853388
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a_property(cls):
            return [1,2,3]

    a1 = A()
    a2 = A()
    assert a1.a_property == [1,2,3]
    a2.a_property.append(4)
    assert a1.a_property == [1,2,3,4]
    assert a2.a_property == [1,2,3,4]


# Generated at 2022-06-12 08:18:40.310224
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("classmethod called")
            return 42

    # Normally, classmethods are called when the class is defined, but lazy
    # classmethods are not executed until they're actually accessed.
    print(Foo.bar)
    # -> classmethod called
    # -> 42

    # Once called, the value is stored and the classmethod is not called
    # anymore.
    print(Foo.bar)
    # -> 42
    print(Foo.bar)
    # -> 42

