

# Generated at 2022-06-12 08:09:35.333003
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:09:37.541571
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'
    assert C.prop == 'value'



# Generated at 2022-06-12 08:09:40.236548
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def ff(cls):
            return 'ff_value'
    a = A()
    assert a.ff == 'ff_value'



# Generated at 2022-06-12 08:09:43.184395
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            return "FOO"
    assert Test.foo == "FOO"
    assert Test.foo == "FOO"



# Generated at 2022-06-12 08:09:46.292320
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def a(cls):
            return 1 + 1

# Generated at 2022-06-12 08:09:53.089603
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop for class %s" % cls.__name__)
            return 'The result'

    print("A.prop = %s" % A.prop)
    print("A.prop = %s" % A.prop)
    print("")

    class B(A):
        pass

    print("B.prop = %s" % B.prop)
    print("B.prop = %s" % B.prop)


# Generated at 2022-06-12 08:09:58.920817
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def test_property(cls):
            print('init')
            return []

        @classmethod
        def add_test_property(cls):
            cls.test_property.append(1)


    assert Foo.test_property == []
    assert Foo.test_property == []
    assert Foo.test_property == []

    Foo.add_test_property()
    assert Foo.test_property == [1]

    class Bar(Foo):
        @classmethod
        def add_test_property(cls):
            cls.test_property.append(2)

    assert Bar.test_property == [2]
    assert Foo.test_property == [1]



# Generated at 2022-06-12 08:10:07.015816
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A): pass

    class C(B): pass

    class D(C): pass

    assert A.a == 1
    assert B.a == 1
    assert C.a == 1
    assert D.a == 1
    A.a = 8
    assert A.a == 8
    assert B.a == 1
    assert C.a == 1
    assert D.a == 1
    assert A._A__a_lazy_a == 8
    assert B._B__a_lazy_a == 1
    assert C._C__a_lazy_a == 1
    assert D._D__a_lazy_a == 1
    B.a = 9
    assert A._A__a_lazy

# Generated at 2022-06-12 08:10:15.210188
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazyclassprop1(cls):
            return 1

        @lazyclassproperty
        def lazyclassprop2(cls):
            return 2

    assert A.lazyclassprop1 == 1
    assert A.lazyclassprop2 == 2

    # Test class inheritance
    class B(A):
        pass

    assert A.lazyclassprop1 == 1
    assert A.lazyclassprop2 == 2
    assert B.lazyclassprop1 == 1
    assert B.lazyclassprop2 == 2


# Generated at 2022-06-12 08:10:23.570321
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def list(cls):
            return []

    class MyClass1(MyClass):
        pass

    class MyClass2(MyClass):
        pass

    MyClass.list.append(1)
    assert MyClass.list == [1]
    assert MyClass1.list == [1]
    assert MyClass2.list == [1]
    MyClass1.list.append(2)
    assert MyClass.list == [1, 2]
    assert MyClass1.list == [1, 2]
    assert MyClass2.list == [1, 2]


# Generated at 2022-06-12 08:10:33.818667
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 1

    assert A.test == 1
    A.test = 2
    assert A.test == 1

    class B(A):
        pass

    assert B.test == 1
    B.test = 3
    assert B.test == 1

    class C(A):
        @classproperty
        def test(cls):
            return cls.__name__

    assert C.test == 'C'
    C.test = 4
    assert C.test == 'C'
    assert A.test == 1

# Generated at 2022-06-12 08:10:37.039483
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def get_attr(cls):
            return 'Hello World'

    assert MyClass.get_attr == MyClass.get_attr



# Generated at 2022-06-12 08:10:46.826484
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest

    def myfn(cls):
        print("evaluate myfn for %s" % cls.__name__)
        return cls.__name__

    class MyBase(object):
        def __init__(self):
            pass

        @lazyperclassproperty
        def myclassprop(cls):
            return myfn(cls)

    class MyClass(MyBase):
        pass

    class MyTest(unittest.TestCase):
        def test_lazyperclassproperty(self):
            obj_a = MyClass()
            obj_b = MyClass()
            obj_c = MyBase()
            self.assertEqual(obj_a.myclassprop, "MyClass")
            self.assertEqual(obj_b.myclassprop, "MyClass")

# Generated at 2022-06-12 08:10:53.200229
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def spam(cls):
            return 'ham'

    print(Foo.spam)
    print(Foo.spam)
    Foo.spam = 'eggs'
    print(Foo.__dict__)
    print(Foo.spam)
    del Foo.spam
    print(Foo.spam)



# Generated at 2022-06-12 08:10:58.856659
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> class A(object):
    ...    @lazyclassproperty
    ...    def f(cls):
    ...        print 'hello, I am a lazy class property'
    ...        return lambda x:x+1
    >>> A.f
    hello, I am a lazy class property
    <function <lambda> at ...>
    >>> A.f(3)
    4
    >>> A.f
    <function <lambda> at ...>
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:11:02.581007
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class b:
        @lazyclassproperty
        def a(cls):
            return 1

    class c(b):
        pass

    assert b.a == 1
    assert c.a == 1


# Generated at 2022-06-12 08:11:10.295791
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self):
            self.calls = 0

        def _value(self):
            self.calls += 1
            return self.calls

        @lazyperclassproperty
        def value(self):
            return self._value()

    class B(A):
        pass

    class C(A):
        def _value(self):
            return super()._value()+1

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()
    c1 = C()

    assert a1.value == 1
    assert a1.value == 1
    assert a1.value == 1
    assert a2.value == 1
    assert a2.value == 1

    assert b1.value == 1
    assert b1.value == 1

# Generated at 2022-06-12 08:11:18.567903
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print(cls.__name__)
            return 5
    class B(A):
        pass
    class C(A):
        @classmethod
        def a(cls):
            return 6

    def test_a():
        assert A.a == 5
        assert B.a == 5
        assert C.a == 6
    test_a()
    A.a = 7
    assert A.a == 7
    assert B.a == 7
    assert C.a == 6



# Generated at 2022-06-12 08:11:22.712226
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> class A(object):
    ...     @lazyclassproperty
    ...     def x(cls):
    ...         print 'x'
    ...         return 1
    ...
    >>> A.x
    x
    1
    >>> A.x
    1

    """



# Generated at 2022-06-12 08:11:27.962433
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test for function lazyclassproperty.
    """
    class DummyClass(object):
        def __init__(self):
            super(DummyClass, self).__init__()

        @lazyclassproperty
        def lazyprop_class(cls):
            return 'lazyprop_class'

    assert DummyClass.lazyprop_class == 'lazyprop_class'


# Generated at 2022-06-12 08:11:42.699070
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return 1
    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 2
    class C(A):
        @lazyperclassproperty
        def a(cls):
            return 3
    # Check that lazyperclassproperty is truely lazy
    assert A.__dict__.get('_A_lazy_a') is None
    assert B.__dict__.get('_B_lazy_a') is None
    assert C.__dict__.get('_C_lazy_a') is None
    # Check that lazyperclassproperty values are stored in the dict of the class
    assert A.a == 1
    assert A.__dict__.get('_A_lazy_a')

# Generated at 2022-06-12 08:11:45.820384
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_attr(cls):
            return 1

    assert TestClass.test_attr == 1

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:11:51.897101
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Initializing A.prop")
            return 42

    class B(A):
        pass

    print("A.prop:", A.prop)
    print("B.prop:", B.prop)

    a = A()
    print("a.prop:", a.prop)
    a.prop = 3
    print("a.prop:", a.prop)



# Generated at 2022-06-12 08:11:54.900390
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_lazy(cls):
        return "valid"

    class TestClass(object):
        test_lazy = lazyclassproperty(test_lazy)

    assert TestClass.test_lazy == "valid"



# Generated at 2022-06-12 08:12:05.904628
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def x(cls):
            """I am the 'x' property."""

# Generated at 2022-06-12 08:12:15.939660
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    class Test(unittest.TestCase):
        def test_lazyclassproperty(self):
            class TestClass2(object):
                @lazyclassproperty
                def foo(cls):
                    return 'foo'

            class TestClass1(TestClass2):
                pass

            self.assertEqual(TestClass1.foo, 'foo')
            self.assertEqual(TestClass2.foo, 'foo')
            TestClass2.foo = 'bar'
            self.assertEqual(TestClass1.foo, 'bar')
            self.assertEqual(TestClass2.foo, 'bar')
    unittest.main()



# Generated at 2022-06-12 08:12:21.863155
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    called = []
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            called.append(True)
            return 42
    assert len(called) == 0
    assert Foo.bar == 42
    assert len(called) == 1
    assert Foo.bar == 42
    assert len(called) == 1
    class Foo2(Foo):
        pass
    assert len(called) == 1
    assert Foo.bar == 42
    assert len(called) == 1
    assert Foo2.bar == 42
    assert len(called) == 2
    Foo2.bar = 37
    assert len(called) == 2
    assert Foo2.bar == 37
    assert len(called) == 2
    assert Foo.bar == 42
    assert len(called) == 2

# Generated at 2022-06-12 08:12:26.687462
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    @lazyperclassproperty
    def x(cls):
        print ('x was evaluated for class %s' % cls.__name__)
        return 'x'

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'x'



# Generated at 2022-06-12 08:12:32.154717
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):

        def __init__(self):
            self.my_var = 1

        @lazyclassproperty
        def my_prop(self):
            return self.my_var

    test_inst = TestClass()
    test_inst.my_prop = 2
    print('lazyclassproperty:', test_inst.my_prop)


# Generated at 2022-06-12 08:12:35.563438
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

    class Bar(Foo):
        pass

    assert Foo.bar == "Foo"
    assert Bar.bar == "Bar"



# Generated at 2022-06-12 08:12:53.590820
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:00.005929
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def foo(cls):
            # can access cls here
            return [1, 2, 3]

    class B(A):
        pass

    class C(B):
        pass

    assert A.foo == [1, 2, 3]
    assert id(A.foo) == id(B.foo)
    assert id(B.foo) != id(C.foo)
    assert id(A.foo) != id(C.foo)



# Generated at 2022-06-12 08:13:08.020770
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassProperty(object):
        @lazyclassproperty
        def foo(cls):
            print("Initializing the TestLazyClassProperty foo class property with the value 123")
            return 123

    assert hasattr(TestLazyClassProperty, '_lazy_foo') == False
    assert TestLazyClassProperty.foo == 123
    assert hasattr(TestLazyClassProperty, '_lazy_foo') == True

    # Make sure that _lazy_foo is cached across instances of the class
    assert TestLazyClassProperty().foo == 123
    assert TestLazyClassProperty().foo == 123



# Generated at 2022-06-12 08:13:12.053215
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:16.300553
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Singleton:
        @lazyperclassproperty
        def singleton(cls):
            return object()

    class A(Singleton):
        pass

    class B(Singleton):
        pass

    a = A()
    b = B()
    assert a.singleton == b.singleton
    assert A.singleton == B.singleton



# Generated at 2022-06-12 08:13:22.092024
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:31.238863
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.name = 'Foo'

        @lazyperclassproperty
        def bar(cls):
            print("[%s]: bar called" % (cls.__name__,))
            foo = cls()
            return foo.name

    class B(A):
        def __init__(self):
            self.name = 'Bar'

    def _test_one(x):
        b1 = x()
        assert b1.bar == b1.name
        b1.name = 'Changed'
        assert b1.bar == b1.name

    def _test_two(x, y):
        b1 = x()
        assert b1.bar == b1.name
        b1.name = 'Changed'
        assert b1.bar

# Generated at 2022-06-12 08:13:36.531540
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            return []

    class B(A):
        pass

    a = A()
    b = B()

    a.x.append(1)

    assert a.x == [1]
    assert b.x == []



# Generated at 2022-06-12 08:13:45.142875
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def __new__(cls):
            print("Returning A")
            return super(A, cls).__new__(cls)

    class B(object):
        @lazyperclassproperty
        def __new__(cls):
            print("Returning B")
            return super(B, cls).__new__(cls)

    class C(A, B):
        pass

    class D(B, A):
        pass

    c = C()
    d = D()

    assert len(c) == len(d)



# Generated at 2022-06-12 08:13:55.517595
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass1(object):

        def __init__(self):
            self._last_val = 0

        @lazyclassproperty
        def random_class_property(cls):
            cls._last_val += 1
            return random.random()

    class MyClass2(MyClass1):
        pass

    assert MyClass1() != MyClass1()
    assert MyClass2() != MyClass2()

    val1 = MyClass1.random_class_property
    assert MyClass1.random_class_property == val1
    assert MyClass1._last_val == 1
    assert MyClass2.random_class_property == val1
    assert MyClass2._last_val == 1

    val2 = MyClass2.random_class_property
    assert MyClass2.random_class_property == val2
   

# Generated at 2022-06-12 08:14:20.949166
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def b(cls):
            print("Constructing b for " + cls.__name__)
            return [1,2,3]

    assert A.b == A.b
    assert A.b == [1,2,3]

    class B(A):
        pass

    assert B.b == B.b
    assert A.b == B.b
    assert B.b == [1,2,3]

    class C(A):
        @lazyclassproperty
        def b(cls):
            print("Constructing b for " + cls.__name__)
            return [4,5,6]

    assert C.b == C.b
    assert C.b == [4,5,6]
    assert C.b != A.b

# Generated at 2022-06-12 08:14:25.818335
# Unit test for function lazyclassproperty
def test_lazyclassproperty():  # TODO: Unit tests doesn't work
    import random


# Generated at 2022-06-12 08:14:32.095520
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            print("%s: Calc" % cls.__name__)
            return "Base"

    class A(Base): pass

    class B(Base): pass

    class D(A, B): pass

    class E(Base):
        @lazyperclassproperty
        def test(cls):
            print("%s: Calc" % cls.__name__)
            return "E"

    assert A.test == "Base"
    assert B.test == "Base"
    assert D.test == "Base"
    assert E.test == "E"

    assert Base.test == "Base"


# Generated at 2022-06-12 08:14:34.068733
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def _lazyprop(cls):
            return 42

   

# Generated at 2022-06-12 08:14:42.191628
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            print("Calculating A.x")
            return 1

    class B(A):
        @lazyperclassproperty
        def x(cls):
            print("Calculating B.x")
            return 2

    print('B.x = {0}'.format(B.x))
    print('A.x = {0}'.format(A.x))
    print('B.x = {0}'.format(B.x))
    print('A.x = {0}'.format(A.x))
    print('B.x = {0}'.format(B.x))


# Generated at 2022-06-12 08:14:45.225437
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        count = 0
        @lazyclassproperty
        def get_count(cls):
            cls.count += 1
            return cls.count
    assert Test.get_count == 1
    assert Test.get_count == 1



# Generated at 2022-06-12 08:14:51.293009
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):

        def __init__(self):
            self.x = 5

        @lazyperclassproperty
        def foo(cls):
            return 4

        @lazyperclassproperty
        def bar(cls):
            return 3

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    base = Base()
    sub1 = Sub1()
    sub2 = Sub2()

    print(base.foo, base.bar)
    print(sub1.foo, sub1.bar)
    print(sub2.foo, sub2.bar)



# Generated at 2022-06-12 08:14:53.518371
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__
    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'


# Generated at 2022-06-12 08:14:56.589545
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 42
    a = A()

    assert(a.x == 42)
    assert(a.__class__.x == 42)



# Generated at 2022-06-12 08:14:59.563509
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import pytest
    class Person(object):
        @lazyclassproperty
        def auto_attribute(self):
            return 1

    person = Person()
    assert person.auto_attribute==1

# Generated at 2022-06-12 08:15:37.518218
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    assert A.x == 1



# Generated at 2022-06-12 08:15:44.038911
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class FooClass(object):
        def __init__(self):
            self._bar = 0

        @lazyperclassproperty
        def bar(cls):
            return cls._bar

        @bar.setter
        def bar(self, x):
            self._bar = x + 1

    class FooClassSubclass(FooClass):
        pass

    # Before accessing properties, the attributes don't exist on the classes
    assert not hasattr(FooClass, '_FooClass_lazy_bar')
    assert not hasattr(FooClassSubclass, '_FooClassSubclass_lazy_bar')

    # Accessing the properties creates the attributes
    assert FooClass().bar == 0
    assert FooClassSubclass().bar == 0


# Generated at 2022-06-12 08:15:47.433099
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'
    assert Foo().bar == 'baz'

    class Baz(Foo):
        pass

    assert Baz.bar == 'baz'
    assert Baz().bar == 'baz'



# Generated at 2022-06-12 08:15:52.066338
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 42

    assert A.prop == 42
    assert A.prop == 42

    class B(A):
        pass

    assert B.prop == 42
    assert B.prop == 42

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return 13

    assert C.prop == 13
    assert C.prop == 13

    assert A.prop == 42
    assert A.prop == 42

# Generated at 2022-06-12 08:15:54.335787
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "bar"

    assert A.foo == "bar"
    assert A.__dict__["_lazy_foo"] == "bar"



# Generated at 2022-06-12 08:15:58.638315
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from unittest.mock import MagicMock

    class A(object):
        pass

    class B(A):
        pass

    class C(B):
        pass

    A.foo = lazyperclassproperty(A)
    B.foo = lazyperclassproperty(B)
    C.foo = MagicMock()

    expected = [A, B, C]

    assert A.foo is expected[0]
    assert B.foo is expected[1]
    assert C.foo is expected[2]

# Generated at 2022-06-12 08:16:04.298663
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    try:
        class foo(object):
            _lazy_prop = 3
            @lazyclassproperty
            def prop(cls):
                return cls._lazy_prop

        assert foo.prop == 3
        foo._lazy_prop = 5
        assert foo.prop == 5
        foo._lazy_prop = 1
        assert foo.prop == 1
    except Exception as e:
        assert False, 'lazyclassproperty failed %s' % repr(e)

    try:
        class foo2(foo):
            _lazy_prop = 99
    except Exception as e:
        assert False, 'lazyclassproperty failed %s' % repr(e)


# Generated at 2022-06-12 08:16:09.161250
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def max_a(cls):
            return max(int(a) for a in cls.a.values())


    class B(A):
        a = {}

    assert not hasattr(A, '_lazy_max_a')
    assert B.max_a == 0
    assert hasattr(B, '_lazy_max_a')
    assert A.max_a == B.max_a == 0



# Generated at 2022-06-12 08:16:12.070216
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def value(cls):
            print('computed value')
            return 'value'

    print(Test.value)
    print(Test.value)


# Generated at 2022-06-12 08:16:18.654864
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('Getting property a')
            return 1
    print(A.a)
    print(A.a)
    print(A.a)

    class B(A):
        pass

    print(B.a)
    print(B.a)
    print(B.a)

    class C(A):
        @lazyclassproperty
        def a(cls):
            print('Getting property a')
            return 2
    print(C.a)
    print(C.a)
    print(C.a)

# test_lazyclassproperty()


# Generated at 2022-06-12 08:17:35.057323
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass:
        def _value(cls):
            print('evaluating value')
            return 42

        value = lazyclassproperty(_value)

    m = MyClass()
    assert m.value == 42



# Generated at 2022-06-12 08:17:38.757768
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:43.685817
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print(cls)
            return 1

    class B(A):
        pass

    a = A.a
    b = B.a
    c = A.a
    assert a == 1
    assert b == 1
    assert c == 1



# Generated at 2022-06-12 08:17:46.894162
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(self):
            return object()

    assert A.foo is not A.foo
    class B(A):
        pass
    assert A.foo is not B.foo


# Generated at 2022-06-12 08:17:54.687894
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            print("Evaluating %s"%cls.__name__)
            return list(range(10))
    class A(Base):
        pass
    class B(Base):
        pass
    assert Base.test != A.test != B.test != Base.test
    assert Base.test == A.test
    assert Base.test != B.test
    assert len(Base.test) == 10
    assert len(A.test) == 10
    assert len(B.test) == 10


# Generated at 2022-06-12 08:18:00.515355
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class UnitTest(object):
        @lazyperclassproperty
        def class_name(cls):
            return cls.__name__

    class UnitTestA(UnitTest):
        pass

    class UnitTestB(UnitTest):
        pass

    assert UnitTest.class_name == 'UnitTest'
    assert UnitTestA.class_name == 'UnitTestA'
    assert UnitTestB.class_name == 'UnitTestB'



# Generated at 2022-06-12 08:18:03.794415
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'
    assert A.foo == 'bar'


# Generated at 2022-06-12 08:18:07.278236
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def one(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def one(cls):
            return 2

    assert A.one == 1
    assert B.one == 1
    assert C.one == 2



# Generated at 2022-06-12 08:18:10.433650
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class M:
        @lazyperclassproperty
        def lazy(cls):
            return cls.__name__

    assert 'm' == M().lazy

    class N(M):
        pass

    assert 'm' == M().lazy
    assert 'n' == N().lazy
    assert 'M' == M.lazy
    assert 'N' == N.lazy

# Generated at 2022-06-12 08:18:14.137845
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'foo' + type(cls).__name__.lower()

    class Bar(Foo):
        pass

    assert Foo.bar == 'foofoo'
    assert Bar.bar == 'foobar'
