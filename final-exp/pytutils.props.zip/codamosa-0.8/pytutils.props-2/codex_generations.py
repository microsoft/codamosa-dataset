

# Generated at 2022-06-12 08:09:36.225257
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test(object):
        @lazyperclassproperty
        def foo(cls):
            return cls
        @classmethod
        def bar(cls):
            return cls

    class test2(test):
        pass

    # test if instance of class test2 has own copy of foo
    assert test().foo is test
    assert test2().foo is test2

    # test if bar is shared between classes
    assert test().bar is test
    assert test2().bar is test



# Generated at 2022-06-12 08:09:40.649707
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'


FOO_CONST = 42



# Generated at 2022-06-12 08:09:44.728518
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def x(cls):
            return cls

    class D(C):
        pass

    class E(C):
        pass

    assert C.x is C
    assert D.x is D
    assert E.x is E



# Generated at 2022-06-12 08:09:49.879893
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Lazy(object):
        @lazyperclassproperty
        def value(cls):
            return id(cls)

    class Child(Lazy):
        pass

    class GrandChild(Child):
        pass

    assert Lazy.value != Child.value != GrandChild.value
    assert GrandChild.value != Child.value != Lazy.value



# Generated at 2022-06-12 08:09:55.202052
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def a(clazz):
            return "foo"
    c1 = C()
    c2 = C()
    assert c1.a == c2.a
    assert C.a == "foo"

    c1.a = "bar"
    assert c2.a == "foo"
    assert C.a == "foo"
    assert c1.a == "bar"

# Generated at 2022-06-12 08:10:00.751531
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self, name):
            self.name = name
        @lazyperclassproperty
        def test(self):
            return self.name
    class B(A):
        pass
    a = A("a")
    b = B("b")
    assert a.test == "a"
    assert b.test == "b"


# Generated at 2022-06-12 08:10:07.999534
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, value):
            self.value = value

    def test_function(cls):
        return "test class: " + cls.__name__

    A.lazy_class_property = lazyperclassproperty(test_function)

    class B(A):
        pass

    class C(B):
        pass

    print("A's lazy_class_property: ")
    print(A.lazy_class_property)
    print("B's lazy_class_property: ")
    print(B.lazy_class_property)
    print("C's lazy_class_property: ")
    print(C.lazy_class_property)


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:10:13.819348
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1

        @lazyclassproperty
        def b(cls):
            return 1

    class B(A):
        @lazyclassproperty
        def a(cls):
            return 2

    assert A.a == 1
    assert A.b == 1
    assert B.a == 2



# Generated at 2022-06-12 08:10:23.938731
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def call_count_class(cls):
            cls.call_count_class = getattr(cls, 'call_count_class', 0) + 1
            return cls.call_count_class

    a1 = A()
    a2 = A()
    a3 = A()
    assert a1.call_count_class == 1
    assert a2.call_count_class == 1
    assert a3.call_count_class == 1

    class B(A):
        @lazyperclassproperty
        def call_count_class_b(cls):
            cls.call_count_class_b = getattr(cls, 'call_count_class_b', 0) + 1
            return cls.call_count_class_b

   

# Generated at 2022-06-12 08:10:27.797481
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def state(cls):
            return 5
    assert(TestClass.state == 5)
    TestClass.state = 6
    assert(TestClass.state == 6)



# Generated at 2022-06-12 08:10:34.535708
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return 1

    class B(A):
        pass

    assert not B.__dict__.has_key('b')
    assert A.b == 1
    assert B.b == 1
    assert A.b == B.b
    assert B.__dict__.has_key('b')
    assert A.__dict__.has_key('b')

# Generated at 2022-06-12 08:10:38.465752
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print(cls)
            return 'bar'
    print(Foo.bar)
    print(Foo.bar)



# Generated at 2022-06-12 08:10:46.376537
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        counter = 0

        @lazyperclassproperty
        def get_value(cls):
            # We want to make sure we only run this once for each class.
            cls.counter = cls.counter + 1
            return 'test'

    class MySubClass(MyClass):
        pass

    assert MyClass.get_value is MyClass.get_value
    assert MyClass.counter is 1
    assert MyClass.get_value is MySubClass.get_value
    assert MyClass.get_value is not MySubClass.get_value
    assert MySubClass.counter is 2



# Generated at 2022-06-12 08:10:54.166972
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:57.702019
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            print('a')
            return 1

    class B(A):
        pass

    class C(B):
        pass

    assert(A.a == 1)
    assert(B.a == 1)
    assert(C.a == 1)

# Generated at 2022-06-12 08:11:05.044884
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:11:09.090624
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        i = lazyperclassproperty(lambda cls: 1)

    class B(A):
        pass

    class C(B):
        pass

    assert A.i == 1
    assert B.i == 1
    assert C.i == 1

    A.i = 2
    assert A.i == 2
    assert B.i == 1
    assert C.i == 1


# Generated at 2022-06-12 08:11:19.897278
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @lazyperclassproperty
        def x_y(cls):
            return cls.x, cls.y

    class B(A):
        def __init__(self, x, y, z):
            super().__init__(x, y)
            self.z = z

        @lazyperclassproperty
        def x_y_z(cls):
            return cls.x, cls.y, cls.z

    class X(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def x_2(cls):
            return cls.x * 2


# Generated at 2022-06-12 08:11:28.910771
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def __doc__(cls):
            return cls.__name__
            # return cls.__name__ + ' (the new doc string)'

    class B(A):
        pass

    assert A.__doc__ == 'A'
    assert B.__doc__ == 'B'

    # overwriting the value of __doc__ at the class level
    A.__doc__ = 'A (overridden)'
    assert A.__doc__ == 'A (overridden)'

    # removing the value of __doc__ at the class level
    del A.__doc__
    # the value gets reinstantiated by the lazyclassproperty when accessed again
    assert A.__doc__ == 'A'

# Generated at 2022-06-12 08:11:39.571625
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('In x')
            return 42
    class B(A):
        pass

    a = A()
    b = B()
    assert a.x == 42
    assert b.x == 42

    # check that the call to x only happened once
    # if we work in the same class, the property is already stored
    assert a.x == 42
    assert b.x == 42

    class C(A):
        @lazyclassproperty
        def x(cls):
            print('In x')
            return 24
    assert A.x == 42
    assert C.x == 24
    assert a.x == 42

    # check that the call to x only happened once
    # if we work in the same class, the property is already stored

# Generated at 2022-06-12 08:11:53.025171
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert C.foo == 'foo'
    assert C.__dict__['_lazy_foo'] == 'foo'
    C.foo = 'bar'
    assert C.foo == 'bar'
    assert C.__dict__['_lazy_foo'] == 'bar'

    class D(C):
        pass

    assert D.foo == 'bar'
    assert D.__dict__['_lazy_foo'] == 'bar'
    D.foo = 'baz'
    assert D.foo == 'baz'
    assert D.__dict__['_lazy_foo'] == 'baz'
    # Make sure C.foo didn't change
    assert C.foo == 'bar'
    assert C

# Generated at 2022-06-12 08:11:55.200022
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def my_prop(cls):
            return cls

    assert A.my_prop == A
    assert A.my_prop == A

# Generated at 2022-06-12 08:12:02.044480
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:09.766106
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def f(cls):
            return 'f'

    assert getattr(A, '_lazy_f') is None
    assert A.f is 'f'
    assert getattr(A, '_lazy_f') is 'f'
    assert A.f is 'f'

    class B(A):
        pass

    assert getattr(A, '_lazy_f') is 'f'
    assert getattr(B, '_lazy_f') is None

    assert B.f is 'f'
    assert getattr(B, '_lazy_f') is 'f'
    assert getattr(A, '_lazy_f') is 'f'

    # Checking that the class of A and B have the same attribute

# Generated at 2022-06-12 08:12:12.190312
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'



# Generated at 2022-06-12 08:12:17.047447
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        def __init__(self):
            self.val = 1

    class B(A):
        val = lazyperclassproperty(lambda cls: cls())

    class C(A):
        val = lazyperclassproperty(lambda cls: cls())


# Generated at 2022-06-12 08:12:24.275335
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print('called A')
            return 1

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            print('called B')
            return 2

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print('called C')
            return 3

    assert A.foo == 1
    assert B.foo == 2
    assert C.foo == 3

# Generated at 2022-06-12 08:12:34.227568
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def inc(cls):
            return cls.__name__ + 'A'

        def get_inc(self):
            return self.inc

    class B(A):
        @lazyperclassproperty
        def inc(cls):
            return cls.__name__ + 'B'

        def get_inc(self):
            return self.inc

    class C(B):
        @lazyperclassproperty
        def inc(cls):
            return cls.__name__ + 'C'

        def get_inc(self):
            return self.inc

    assert A.inc == 'AA'
    assert A().inc == 'AA'
    assert B.inc == 'BB'
    assert B().inc == 'BB'

# Generated at 2022-06-12 08:12:39.922219
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def x(cls):
            return 'Parent'

    class Child(Parent):
        pass

    child = Child()
    parent = Parent()

    class GrandChild(Child):
        pass

    assert Child.x == 'Parent'
    assert Parent.x == 'Parent'
    assert GrandChild.x == 'Parent'

    assert child.x == 'Parent'
    assert parent.x == 'Parent'
    assert GrandChild().x == 'Parent'


# Generated at 2022-06-12 08:12:47.255961
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 1
    class B(A):
        pass
    class C(A):
        @lazyclassproperty
        def a(cls):
            return 2
    assert A.a == 1
    assert B.a == 1
    assert C.a == 2
    del A.a
    assert A.a == 1
    del C.a
    assert C.a == 2


# Generated at 2022-06-12 08:13:04.816548
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty
    """
    # using following dict to simulate sqlalchemy models
    data = {
        'Video': {},
        'Audio': {},
        'Image': {},
        'Srt': {},
        'Avi': {},
        'Mp4': {},
        'Wav': {},
        'Jpg': {},
        'Srt': {},
    }

    class Meta(object):
        """
        Fake model
        """
        def __init__(self, name):
            self.name = name

        @lazyperclassproperty
        def item(cls):
            # print("Init name: {0}".format(cls.__name__))
            return data[cls.__name__]


# Generated at 2022-06-12 08:13:09.816128
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__
    class X(Base):
        pass
    class Y(Base):
        pass
    assert Base.foo == 'Base'
    assert X.foo == 'X'
    assert Y.foo == 'Y'


################################################################################
# Singleton
################################################################################


# Generated at 2022-06-12 08:13:16.217594
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        call_count = 0

        @lazyclassproperty
        def a_property(cls):
            cls.call_count += 1
            return 'hello world'

        @classproperty
        def called(cls):
            return cls.call_count

    assert A.called == 0    # hasn't been called yet
    assert A.a_property == 'hello world'  # calls it once
    assert A.called == 1    # called once
    assert A.a_property == 'hello world'  # doesn't call again
    assert A.called == 1    # still called only once


# Generated at 2022-06-12 08:13:22.627532
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class Child(Base):
        pass

    class Child2(Base):
        pass

    assert Base.x == 'x'
    assert Child.x == 'x'
    assert Child2.x == 'x'
    Base.x = 'y'
    assert Base.x == 'y'
    assert Child.x == 'x'
    assert Child2.x == 'x'

# Generated at 2022-06-12 08:13:27.565597
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls): return 'A'

    class B(A):
        @lazyperclassproperty
        def foo(cls): return 'B'

    assert 'A' == A.foo
    assert 'B' == B.foo


# Generated at 2022-06-12 08:13:30.946539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def foo(cls):
        return "foo"

    class A(object):
        d = lazyclassproperty(foo)

    class B(A):
        pass

    assert A.d == B.d == "foo"



# Generated at 2022-06-12 08:13:39.142315
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):

        @lazyperclassproperty
        def bar(self):
            return 'bar_value'

    class Foo2(Foo):
        pass

    foo = Foo()
    foo2 = Foo2()

    # Test lazy attribute with same class -> assert that the same memoized value is returned
    assert foo.bar == foo.bar, 'Lazy attribute same class test'

    # Test lazy attribute with different classes -> assert that the value returned is different
    assert foo.bar != foo2.bar, 'Lazy attribute different classes test'



# Generated at 2022-06-12 08:13:47.233141
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:52.561593
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:55.916797
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("x")
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert A.x == 1
    assert B.x == 1
    assert B.x == 1

# Generated at 2022-06-12 08:14:20.838730
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        attr1 = 1

        @lazyperclassproperty
        def attr2(cls):
            return cls.attr1 + 1

        @classmethod
        def attr3(cls):
            print('A.attr3')

    assert A.attr2 == 2
    A.attr1 = 10
    assert A.attr2 == 11
    assert A.attr3() == None
    assert A().attr3() == None
    assert A.attr3() == None

    class B(A):
        attr1 = 2

        @classmethod
        def attr3(cls):
            print('B.attr3')

    assert B.attr2 == 3
    assert B().attr3() == None
    assert B.attr3() == None



# Generated at 2022-06-12 08:14:24.339502
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:30.439516
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('init a 1')
            return 1

        @lazyclassproperty
        def b(cls):
            print('init a 2')
            return 2

    class B(A):
        @lazyclassproperty
        def a(cls):
            print('init b 1')
            return 1

        @lazyclassproperty
        def b(cls):
            print('init b 2')
            return 2

    print(A.a)
    print(A.a)
    print(A.b)
    print(A.b)

    print(B.a)
    print(B.a)
    print(B.b)
    print(B.b)



# Generated at 2022-06-12 08:14:34.615302
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Example1(object):
        @lazyperclassproperty
        def func(cls):
            return 'hello'

    class Example2(Example1):
        pass

    assert Example1.func == 'hello'
    assert Example2.func == 'hello'



# Generated at 2022-06-12 08:14:43.750503
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x=None):
            self.x = x

        @lazyperclassproperty
        def c(cls):
            return cls.__name__

    class B(A):
        pass

    class C(object):
        def __init__(self, x=None):
            self.x = x

        @lazyperclassproperty
        def c(cls):
            return cls.__name__

    a = A()
    b = B()
    c = C()
    assert a.c == 'A'
    assert b.c == 'B'
    assert c.c == 'C'
    assert A.c == 'A'
    assert B.c == 'B'
    assert C.c == 'C'



# Generated at 2022-06-12 08:14:51.110879
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def some_prop(self):
            return 1

    class B(A):
        pass

    class C:
        @lazyperclassproperty
        def some_prop(self):
            return 1

    test_a = A()
    test_b = B()
    test_c = C()
    A.some_prop = None
    B.some_prop = None
    C.some_prop = None

    assert test_a.some_prop == 1
    assert test_b.some_prop == 1
    assert test_c.some_prop == 1
    assert A.some_prop == 1
    assert B.some_prop == 1
    assert C.some_prop == 1
    assert test_a.some_prop != test_b.some_prop


# Generated at 2022-06-12 08:14:55.193629
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:15:04.873322
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo(object):
        _num_calls = 0

        @lazyclassproperty
        def bar(cls):
            cls._num_calls += 1
            return cls

        @classmethod
        def reset_num_calls(cls):
            cls._num_calls = 0

    assert foo._num_calls == 0
    assert foo.bar is foo
    assert foo._num_calls == 1
    assert foo.bar is foo
    assert foo._num_calls == 1

    foo.reset_num_calls()

    class foo2(foo):
        pass

    assert foo2._num_calls == 0
    assert foo2.bar is foo2
    assert foo2._num_calls == 1
    assert foo2.bar is foo2
    assert foo2._num_c

# Generated at 2022-06-12 08:15:13.687783
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:15:19.668752
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X(object):
        @lazyperclassproperty
        def hello(cls):
            print('hello')
            return cls.__name__

        @lazyperclassproperty
        def world(cls):
            print('world')
            return cls.__name__

    class Y(X):
        pass

    class Z(X):
        pass

    assert X.hello == 'X'
    print(X.world)
    assert X.world == 'X'
    assert Y.hello == 'Y'
    assert Y.world == 'Y'
    assert Z.hello == 'Z'
    assert Z.world == 'Z'

# Generated at 2022-06-12 08:16:04.253079
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def label(cls):
            return cls.__name__

    class B(A):
        pass

    class C(B):
        pass

    assert A.label == 'A'
    assert B.label == 'B'
    assert C.label == 'C'



# Generated at 2022-06-12 08:16:11.209798
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Lazy init of class " + cls.__name__ + " property prop")
            return []

    class B(A):
        pass

    class C(B):
        pass

    assert(A.prop is B.prop)
    assert(B.prop is C.prop)
    assert(A.prop is not C.prop)
    assert(len(A.prop) == 0)
    assert(len(B.prop) == 0)
    assert(len(C.prop) == 0)
    A.prop.append('A')
    assert(len(A.prop) == 1)
    assert(len(B.prop) == 1)
    assert(len(C.prop) == 1)
    B.prop.append

# Generated at 2022-06-12 08:16:14.363602
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def test(cls):
            return 3

    class Bar(Foo):
        pass

    assert Foo.test == Bar.test == 3



# Generated at 2022-06-12 08:16:16.843589
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_func():
        return 1
    class TestClass(object):
        test = lazyclassproperty(test_func)
    assert TestClass.test == 1
    TestClass.test = 2
    assert TestClass.test == 2


# Generated at 2022-06-12 08:16:19.745789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def my_property(_cls):
            return 7

    assert TestClass.my_property == 7


# Generated at 2022-06-12 08:16:28.425081
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self, value):
            self.value = value

        @lazyperclassproperty
        def name(cls):
            return cls.__name__

        @lazyperclassproperty
        def value_property(cls):
            return cls.value


    class B(A):
        value = "b"

    class D(B):
        value = "d"

    a = A(value="a")
    b = B()
    d = D()

    assert a.name == "A"
    assert b.name == "B"
    assert d.name == "D"

    assert a.value_property == "a"
    assert b.value_property == "b"
    assert d.value_property == "d"

# Generated at 2022-06-12 08:16:36.593173
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    This is a unit test for the @lazyclassproperty decorator for use with unittest.
    The class "A" creates a class property which only has a value assigned upon the first property access.
    The class "B" inherits from class "A" and does not access the decorated class property, thus the value is
    calculated for class "A" only.
    """

    class A(object):
        @lazyclassproperty
        def my_class_property(cls):
            return "Hi there!"

    assert A.my_class_property == "Hi there!"
    class B(A):
        pass
    assert A.my_class_property == "Hi there!"
    assert not hasattr(B, "_lazy_my_class_property")

if __name__ == "__main__":
    test_lazyclass

# Generated at 2022-06-12 08:16:43.367069
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class ChildA(Base):
        @lazyperclassproperty
        def a(cls):
            return 'A'

    class ChildB(Base):
        @lazyperclassproperty
        def a(cls):
            return 'B'

    a = Base()
    a2 = Base()
    b = ChildA()
    b2 = ChildA()
    c = ChildB()

    assert a.a == 'a'
    assert a2.a == 'a'
    assert b.a == 'A'
    assert b2.a == 'A'
    assert c.a == 'B'

# Generated at 2022-06-12 08:16:48.017609
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        x = [1, 2, 3]

        @lazyclassproperty
        def y(self):
            return sum(self.x)

    class B(A):
        x = [2, 3, 4]

    print(A().y)
    print(B().y)



# Generated at 2022-06-12 08:16:51.368262
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:25.787546
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:28.671285
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        @lazyclassproperty
        def my_property(cls):
            print('Calculating')
            return 42

    # This prints "Calculating"
    assert MyClass.my_property == 42



# Generated at 2022-06-12 08:18:31.772505
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    @lazyclassproperty
    def foo(cls):
        return cls.__name__

    def test_lazy_foo(cls):
        foo1 = cls.foo
        # should be same obj
        assert foo1 is cls.foo

    test_lazy_foo(Foo)
    test_lazy_foo(Bar)
    test_lazy_foo(Baz)
    # should be different objects
    assert Foo.foo is not Bar.foo
    # should be different objects
    assert Bar.foo is not Baz.foo



# Generated at 2022-06-12 08:18:34.769776
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo! '*10

    class Bar(Foo):
        pass

    assert Bar.foo == Bar.foo
    assert Bar.foo != Foo.foo


# Generated at 2022-06-12 08:18:40.482385
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print("eval x")
            return 42

    assert A.x == 42
    assert A.x == 42

    class B(A):
        pass

    assert B.x == 42
    assert B.x == 42

    class C(A):
        @classmethod
        def _setup_class(cls):
            cls.x = 12

    assert C.x == 12
    assert C.x == 12

    class D(C):
        pass

    assert D.x == 12
    assert D.x == 12


# Generated at 2022-06-12 08:18:50.799447
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C:
        @lazyperclassproperty
        def x(cls):
            return [set()]
    print('C.x:', C.x)
    print('C.x:', C.x)
    c = C()
    print('c.x:', c.x)
    c.x.append(1)
    print('c.x:', c.x)
    print('C.x:', C.x)
    print()

    class D(C):
        pass

    print('D.x:', D.x)
    print('D.x:', D.x)
    d = D()
    print('d.x:', d.x)
    d.x.append(1)
    print('d.x:', d.x)

# Generated at 2022-06-12 08:18:56.283066
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:19:04.443301
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class BaseClass(object):
        @classmethod
        def awesome_factory(cls):
            return 'in BaseClass'

    class ChildClass(BaseClass):
        @lazyperclassproperty
        def awesome_lazy_property_of_child_class(cls):
            return cls.awesome_factory()

    class ChildClass2(BaseClass):
        @lazyperclassproperty
        def awesome_lazy_property_of_child2_class(cls):
            return cls.awesome_factory()

    assert ChildClass.awesome_lazy_property_of_child_class == 'in BaseClass'
    assert ChildClass2.awesome_lazy_property_of_child2_class == 'in BaseClass'

# Generated at 2022-06-12 08:19:12.395488
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    cls = lambda f: lambda: f
    cls0 = cls(0)
    cls1 = cls(1)
    cls2 = cls(2)
    n = 1
    c = lazyclassproperty(lambda: n)
    c(cls0)()
    assert c(cls1)() == 1
    assert c(cls2)() == 1
    n = 2
    assert c(cls1)() == 1
    assert c(cls2)() == 1   # the property is only evaluated when accessed
    assert c(cls0)() == 2
    assert c(cls1)() == 2
    assert c(cls2)() == 2


# Generated at 2022-06-12 08:19:21.161925
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def hello(cls):
            return 'world'

    # The hello attribute is not set yet.
    assert not hasattr(A, '_lazy_hello')

    # The hello attribute is created when first requested.
    assert A.hello == 'world'

    # The hello attribute is set now.
    assert A._lazy_hello == 'world'

    class B(A):
        pass

    # The hello attribute is not set yet in B.
    assert not hasattr(B, '_lazy_hello')

    # The hello attribute is created when first requested in B.
    assert B.hello == 'world'

    # The hello attribute is set now in B.
    assert B._lazy_hello == 'world'