

# Generated at 2022-06-12 08:09:39.590181
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from functools import reduce
    from inspect import isclass
    from operator import or_

    class SomeClass(object):
        @lazyperclassproperty
        def x(cls):
            print('executing lazyperclassproperty')
            return cls

        @lazyclassproperty
        def y(cls):
            print('executing lazyclassproperty')
            return cls

    class SomeSubClass(SomeClass):
        pass

    assert SomeClass.x is SomeClass
    assert isclass(SomeClass.y)
    assert isclass(SomeSubClass.y)
    assert SomeClass.x is not SomeSubClass.x
    assert SomeClass.y is SomeSubClass.y

# Generated at 2022-06-12 08:09:44.534973
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazy(cls):
            return cls

    class B(A):
        pass

    class C(B):
        pass

    assert A.lazy is A
    assert B.lazy is B
    assert C.lazy is C
    assert A.lazy is A


# Generated at 2022-06-12 08:09:50.554649
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            pass


# Generated at 2022-06-12 08:09:56.583986
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print("A: I'm lazy")
            return 'A'
    class B(A):
        @lazyperclassproperty
        def x(cls):
            print("B: I'm lazy")
            return 'B'
    class C(A):
        pass

    A.x
    B.x
    C.x
    assert A.x == 'A'
    assert B.x == 'B'
    assert C.x == 'A'

test_lazyperclassproperty()

# Generated at 2022-06-12 08:10:00.797357
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def property(cls):
            print("evaluating")
            return "foo"

    class B(A):
        pass

    assert A.property is B.property



# Generated at 2022-06-12 08:10:05.243471
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return "B"

    assert A.x == "A"
    assert B.x == "B"
    assert A().x == "A"
    assert B().x == "B"

# Generated at 2022-06-12 08:10:16.100419
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import pytest

    def fn(cls):
        return cls.__name__

    class A:
        @lazyclassproperty
        def foo(cls):
            return cls.__name__

    # After the property is accessed for the first time
    assert A.foo == 'A'
    # The attribute foo is not set directly on the class
    with pytest.raises(AttributeError) as e:
        A.__dict__['foo']
    assert '_lazy_foo' in str(e.value)
    # The attribute foo is set on the class
    assert A.__dict__['_lazy_foo'] == 'A'

    # The property can be accessed directly on the class
    assert A.foo == 'A'
    # The attribute foo is not set directly on the class

# Generated at 2022-06-12 08:10:22.462571
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestClass(object):
        @lazyclassproperty
        def somevalue(cls):
            return 1

    assert TestClass.somevalue == 1

    class TestClass2(TestClass):
        pass

    assert TestClass.somevalue == 1
    assert TestClass2.somevalue == 1
    TestClass2.somevalue = 2
    assert TestClass.somevalue == 1
    assert TestClass2.somevalue == 2


# Generated at 2022-06-12 08:10:30.379795
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:10:38.286524
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def func(klass):
        print('lazyclassproperty (in func):', klass)
        return {'klass': klass}

    class TestLazyClassProperty(object):
        @lazyclassproperty
        def test(klass):
            print('lazyclassproperty:', klass)
            return {'klass': klass}

        @lazyclassproperty
        def _test(klass):
            print('_lazyclassproperty:', klass)
            return {'klass': klass}

        @lazyclassproperty
        def __test(klass):
            print('__lazyclassproperty:', klass)
            return {'klass': klass}

        class TestBase(object):
            pass

    test = TestLazyClassProperty()

# Generated at 2022-06-12 08:10:45.184336
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def get_value(cls):
        return cls.__name__

    class A(object):
        value = lazyperclassproperty(get_value)

    class B(A):
        pass

    class C(A):
        pass

    assert A.value == 'A'
    assert B.value == 'B'
    assert C.value == 'C'


# Generated at 2022-06-12 08:10:55.064799
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def prop(cls):
            return "parent"

    class Child(Parent):
        pass

    class Child1(Parent):
        @lazyperclassproperty
        def prop(cls):
            return "child1"

    class Child2(Parent):
        pass

    class Grandchild(Child):
        @lazyperclassproperty
        def prop(cls):
            return "grandchild"

    assert Parent.prop == "parent"
    assert Child.prop == "parent"
    assert Child1.prop == "child1"
    assert Child2.prop == "parent"
    assert Grandchild.prop == "grandchild"
    assert Parent.prop is not Child1.prop
    assert Child1.prop is Child1.prop



# Generated at 2022-06-12 08:11:01.105966
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # base class
    class Foo(object):
        @lazyclassproperty
        def verbose_name(cls):
            return "some verbose name"

    # inheritor class
    class Bar(Foo):
        pass

    # inheritor class
    class Bax(Foo):
        pass

    assert Foo.verbose_name == "some verbose name"
    assert Bar.verbose_name == "some verbose name"

    assert Foo.verbose_name is Bar.verbose_name is Bax.verbose_name

    Foo.verbose_name = "another name"
    assert Foo.verbose_name == "another name"
    assert Bar.verbose_name == "some verbose name"
    assert Bax.verbose_name == "some verbose name"

# Generated at 2022-06-12 08:11:06.855730
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def myprop(cls):
            print('first time')
            return 1

    class B(A):
        pass

    assert A.myprop == 1
    assert B.myprop == 1
    assert A.myprop == 1
    assert B.myprop == 1
    assert A.myprop == 1
    assert B.myprop == 1



# Generated at 2022-06-12 08:11:09.446218
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 42

    print(A.foo)
    print(A.foo)



# Generated at 2022-06-12 08:11:14.038871
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    @lazyperclassproperty
    def foo(cls):
        return cls

    assert A.foo is A
    assert B.foo is B
    assert C.foo is C
    assert A().foo is A



# Generated at 2022-06-12 08:11:22.260145
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        x = 1

        @lazyperclassproperty
        def instance_count(cls):
            if not hasattr(cls, '_instance_count'):
                cls._instance_count = 0
            else:
                cls._instance_count += 1
            return cls._instance_count

    class B(A):
        pass

    print(A.instance_count)
    print(B.instance_count)
    print(A.instance_count)
    print(B.instance_count)



# Generated at 2022-06-12 08:11:28.547433
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            return 'Base: %s' % cls.__name__

    class SubBase(Base):
        pass

    class SubClass(SubBase):
        @lazyperclassproperty
        def test(cls):
            return 'SubClass: %s' % cls.__name__


# Generated at 2022-06-12 08:11:35.346029
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        @lazyclassproperty
        def method(cls):
            "This is the docstring"
            return cls
    assert hasattr(X, '_lazy_method') == False # No temporary variable
    assert X.method is X
    assert X.method.__doc__ == 'This is the docstring'
    # Test that only one instance of the property exists
    assert X._lazy_method is X._lazy_method



# Generated at 2022-06-12 08:11:41.261167
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1
    class B(A):
        pass
    assert A.prop == 1
    assert B.prop == 1
    A.prop = 2
    assert B.prop == 1
    class C(A):
        pass
    assert C.prop == 1
    A.prop = 3
    assert B.prop == 1
    assert C.prop == 1



# Generated at 2022-06-12 08:11:55.023850
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestA(object):
        def __init__(self, val):
            self.val = val

    class TestB(TestA):
        pass

    class TestC(TestA):
        pass

    class TestD(TestB):
        pass

    class Test(object):
        def __init__(self, val):
            self.val = val

        @lazyperclassproperty
        def prop(cls):
            return cls.val

    a = TestA(1)
    b = TestB(2)
    c = TestC(3)
    d = TestD(4)
    e = Test(5)
    f = Test(6)

    assert a.prop == 1
    assert b.prop == 2
    assert c.prop == 3
    assert d.prop == 4
    assert e.prop

# Generated at 2022-06-12 08:11:59.612847
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:05.564496
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def coolness(cls):
            return 'awesome'

    assert Foo.coolness == 'awesome'
    assert Foo.coolness is Foo.coolness

    class Bar(Foo):
        pass

    assert Bar.coolness == 'awesome'
    assert Bar.coolness is Bar.coolness
    assert Foo.coolness is Bar.coolness



# Generated at 2022-06-12 08:12:10.605281
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Dummy(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert Dummy.foo == 'foo'
    class SubDummy(Dummy):
        pass

    assert SubDummy.foo == 'foo'



# Generated at 2022-06-12 08:12:17.047501
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def do_something_slow(a):
        time.sleep(1)
        return a + 1
    class A:
        b = lazyperclassproperty(do_something_slow)
    class B(A):
        pass
    t = time.time()

# Generated at 2022-06-12 08:12:21.984853
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            # WOW, you can even call directly!
            def inner():
                return "WOW"
            return inner

    assert Foo.bar == "WOW"
    assert Foo.bar == "WOW"



# Generated at 2022-06-12 08:12:28.877290
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    _class_list = []
    _list = []

    class TestClass(object):
        def __init__(self):
            self.__class__.name = "TestClass"
            pass

        @lazyperclassproperty
        def perclass(cls):
            _class_list.append(cls)
            return cls.name

        @lazyclassproperty
        def static(cls):
            _list.append(cls)
            return cls.name

    # Tests
    class TestClassDublicate(TestClass):
        pass

    assert TestClass.perclass == "TestClass"
    assert TestClassDublicate.perclass == "TestClass"

    class TestClassDublicate(TestClass):
        name = "TestClassDublicate"

    assert TestClass.perclass == "TestClass"

# Generated at 2022-06-12 08:12:37.815953
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class FooParent(object):
        FIRST = 1

        @lazyperclassproperty
        def prop(cls):
            return cls.FIRST

    class Foo(FooParent):
        FIRST = 2

        @property
        def prop_const(self):
            return self.FIRST

    foo = Foo()

    # Check the lazy per-class property
    assert foo.prop != 1
    assert foo.prop != foo.prop_const
    assert foo.prop == 2

    class BarParent(object):
        FIRST = 1

        @lazyperclassproperty
        def prop(cls):
            return cls.FIRST

    class Bar(BarParent):
        FIRST = 3

        @property
        def prop_const(self):
            return self.FIRST

    bar = Bar()

    # Check that the property for the

# Generated at 2022-06-12 08:12:49.256096
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("Initializing foo for class: %s" % cls.__name__)
            return ["foo for %s" % cls.__name__]

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("Initializing foo for class: %s" % cls.__name__)
            return ["foo for %s" % cls.__name__]

    b = B()
    c = C()
    a = A()
    # Prints "Initializing foo for class: A"
    print(a.foo)
    # Prints "Initializing foo for class: B"
    print(b.foo)
    # Prints "

# Generated at 2022-06-12 08:12:56.952007
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:10.661035
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return "Hello A"

    class B(A):
        @lazyclassproperty
        def b(cls):
            return "Hello B"

    # make sure every class has its own value of b
    assert B.b == A.b
    b = B()
    assert b.b == "Hello B"
    a = A()
    assert a.b == "Hello A"

# Generated at 2022-06-12 08:13:14.130193
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test if lazyclassproperty yields the same result each time
    """
    import random
    generator = random.Random()

    class A:

        @lazyclassproperty
        def x(cls):
            return generator.randrange(100)

    assert A.x == A.x



# Generated at 2022-06-12 08:13:20.905294
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C1(object):
        @lazyperclassproperty
        def f(self):
            return 'C1'

    class C2(C1):
        @lazyperclassproperty
        def f(self):
            return 'C2'

    c1 = C1()
    c2 = C2()

    assert getattr(c1, '_C1_lazy_f') == 'C1'
    assert getattr(c2, '_C2_lazy_f') == 'C2'


# Generated at 2022-06-12 08:13:28.255551
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(self):
            print("A:x getter")
            return "A:x"

    class B(A):
        @lazyperclassproperty
        def x(self):
            print("B:x getter")
            return "B:x"

    class C(B):
        pass

    assert A.x == 'A:x'
    assert B.x == 'B:x'
    assert C.x == 'B:x'



# Generated at 2022-06-12 08:13:31.289541
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return "Hello, world"

    assert A.x == "Hello, world"



# Generated at 2022-06-12 08:13:39.378699
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        value = 0

        @lazyclassproperty
        def odd_value(cls):
            cls.value += 1
            return cls.value % 2

    assert A.odd_value == 1
    assert A.odd_value == 1
    assert A.odd_value == 1

    class B(A):
        pass

    assert B.odd_value == 0
    assert B.odd_value == 0
    assert B.odd_value == 0

    assert A.value == 1
    assert B.value == 1



# Generated at 2022-06-12 08:13:50.649317
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        def __init__(self):
            self.x = 1

        @lazyclassproperty
        def a(cls):
            return cls
        @lazyclassproperty
        def b(cls):
            return 1

    class B(A):
        def __init__(self):
            self.x = 2
            super(B, self).__init__()

    # Verify that class property is the same for class and its instances
    a = A()
    assert(a.a is A)
    assert(A.a is A)
    assert(a.b == 1)
    assert(A.b == 1)
    assert(isinstance(a.b, int))
    assert(isinstance(A.b, int))

    # Verify that class property is the same for class and its base class

# Generated at 2022-06-12 08:13:57.318197
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            cls.bar.num_executions += 1
            return cls.bar.num_executions

    class Bar(Foo):
        pass

    assert Foo.bar.num_executions == 0
    assert Bar.bar.num_executions == 0

    assert Foo.bar == 1
    assert Bar.bar == 1

    assert Foo.bar.num_executions == 1
    assert Bar.bar.num_executions == 1

    assert Foo.bar == 1
    assert Bar.bar == 1

    assert Foo.bar.num_executions == 1
    assert Bar.bar.num_executions == 1

# Generated at 2022-06-12 08:13:59.998072
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'foo'

    class B(A):
        pass

    assert A.a == 'foo'
    assert B.a == 'foo'



# Generated at 2022-06-12 08:14:07.854453
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        def _function_to_cache(self):
            return random.random()

        @lazyclassproperty
        def cached(self):
            return self._function_to_cache()

    class TestInheritor(TestClass):
        pass

    original_random = random.random()
    test_instance = TestClass()
    test_inheritor = TestInheritor()
    assert test_instance.cached == test_instance._function_to_cache()
    assert test_inheritor.cached == test_inheritor._function_to_cache()
    assert test_instance.cached != test_inheritor.cached
    assert test_instance.cached == TestClass.cached
    assert test_inheritor.cached == TestInheritor.cached


# Generated at 2022-06-12 08:14:30.054919
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def property(cls):
            print("A.property called")
            return 1

    class B(A): pass

    assert B.property == A.property == 1
    assert B.property == A.property == 1
    assert A.__dict__['_lazy_property'] == 1
    assert '_lazy_property' not in B.__dict__



# Generated at 2022-06-12 08:14:39.356136
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        def __init__(self):
            self.count = 0

        # Unit test for function lazyclassproperty
        @lazyclassproperty
        def test_lazyclassproperty(cls):
            self.count += 1
            return cls.count

    a = Test()
    a.count = 5
    b = Test()
    b.count = 9
    c = Test()
    print("Lazy class property: test_lazyclassproperty")
    print("count a = %d" % a.count)
    print("count b = %d" % b.count)
    print("count c = %d" % c.count)
    print("lr c   = %d" % Test.test_lazyclassproperty)

# Generated at 2022-06-12 08:14:47.886436
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def f(cls):
            print('f accessed')
            return 1

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    # Value f for A is not calculated yet
    assert b.f == 1
    # Value f for A is already calculated and cached
    assert a.f == 1
    # Value f for C is not calculated yet
    assert c.f == 1

    # As you can see that B.f and C.f is actually stored in A,
    # but every class has its own copy of 1

    delattr(A, '_lazy_f')
    delattr(C, '_lazy_f')

    # The property f is deleted from A

# Generated at 2022-06-12 08:14:55.958065
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:01.122794
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, val):
            self.val = val

# Generated at 2022-06-12 08:15:10.996730
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def val(cls):
            cls._val = 'A'
            return cls._val

    class B(A):
        @lazyperclassproperty
        def val(cls):
            cls._val = 'B'
            return cls._val

    class C(A):
        _val = 'C'

    assert A.val == 'A'
    assert B.val == 'B'
    assert C.val == 'C'
    assert A().val == 'A'
    assert B().val == 'B'
    assert C().val == 'C'
    assert C._val == 'C'

    assert hasattr(A, '_A_lazy_val')
    assert hasattr(B, '_B_lazy_val')


# Generated at 2022-06-12 08:15:13.849195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def add(x, y):
        return x + y

    class A(object):
        @lazyclassproperty
        def sum(self):
            return add(1, 2)

    assert A.sum == 3


lazyclassmethod = lazyclassproperty



# Generated at 2022-06-12 08:15:18.881567
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:26.469077
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        # @lazyclassproperty
        # @lazyperclassproperty
        def foobar(self):
            return 'something'

    class Bar(Foo):
        @staticmethod
        def foobar():
            return 'something else'

    foo = Foo()
    assert foo.foobar is not None
    assert foo.foobar == 'something'
    assert Foo.foobar == 'something'
    assert Bar.foobar == 'something else'
    bar = Bar()
    assert bar.foobar == 'something else'

    bar.foobar = 'something'
    assert bar.foobar == 'something'
    assert Bar.foobar == 'something else'



# Generated at 2022-06-12 08:15:32.881168
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:20.988041
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            print('Foo!')
            return 'x'

    a1 = A()
    a2 = A()

    assert a1.x == 'x'
    assert a2.x == 'x'

# Generated at 2022-06-12 08:16:24.990318
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Some(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    assert Some.foo == 'bar'
    assert Some.foo == 'bar'  # cached
    Some.foo = 'baz'
    assert Some.foo == 'baz'



# Generated at 2022-06-12 08:16:30.301722
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return cls.__class__.__name__

    assert(A.foo == 'A')
    assert(hasattr(A, '_lazy_foo'))
    assert(A._lazy_foo == 'A')

    class B(A):
        pass

    assert(B.foo == 'B')
    assert(hasattr(B, '_lazy_foo'))
    assert(B._lazy_foo == 'B')
    assert(not hasattr(A, '_lazy_foo'))



# Generated at 2022-06-12 08:16:35.934464
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:42.117996
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C:
        @lazyperclassproperty
        def lazy(cls):
            print('C.lazy get')
            return 'C.lazy'

        @lazyperclassproperty
        def lazy2(cls):
            print('C.lazy2 get')
            return 'C.lazy2'

    class D(C):
        pass

    assert C.lazy == D.lazy == 'C.lazy'
    assert C.lazy2 == D.lazy2 == 'C.lazy2'



# Generated at 2022-06-12 08:16:48.867624
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ClassA(object):
        @lazyperclassproperty
        def anumber(cls):
            return 5

    class ClassB(ClassA):
        pass

    assert ClassA.anumber == 5
    assert ClassB.anumber == 5

    ClassA.anumber = 6
    assert ClassA.anumber == 6
    assert ClassB.anumber == 5

    ClassB.anumber = 7
    assert ClassA.anumber == 6
    assert ClassB.anumber == 7


# Generated at 2022-06-12 08:16:56.940353
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def __init__(self, val):
            self.val = val

    class A(Foo):
        @lazyclassproperty
        def lazy(cls):
            return cls(10)

    class B(A):
        @lazyclassproperty
        def lazy(cls):
            return cls(20)

    class C(B):
        @lazyclassproperty
        def lazy(cls):
            return cls(30)

    assert A.lazy.val == 10
    assert B.lazy.val == 20
    assert C.lazy.val == 30
    assert isinstance(A.lazy, A)
    assert isinstance(B.lazy, B)
    assert isinstance(C.lazy, C)



# Generated at 2022-06-12 08:17:05.192189
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Define a class with a name and a lazy property
    class A(object):
        name = 'A'

        @lazyclassproperty
        def lazyprop(cls):
            return 'lazyprop'

    # Test lazy property
    assert hasattr(A, '_lazy_lazyprop') is False
    assert A.lazyprop == 'lazyprop'
    assert hasattr(A, '_lazy_lazyprop') is True

    # Add a name to class B, but don't add a lazyprop
    class B(A):
        name = 'B'

    # Test lazy property, inherited from class A
    assert hasattr(B, '_lazy_lazyprop') is False
    assert B.lazyprop == 'lazyprop'

# Generated at 2022-06-12 08:17:06.661879
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def myprop(self):
        return 1

    assert myprop == 1

# Generated at 2022-06-12 08:17:10.070068
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 'b'

    assert B.a == 'b'
    assert A.a == 'a'


lazyproperty = classproperty

# Generated at 2022-06-12 08:18:55.768346
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def test_func(cls, value):
        cls.x = value
        return cls.x

    class test_class(object):
        y = lazyclassproperty(test_func)

    t = test_class()
    t.y = 'value'
    print('t.y:', t.y)



# Generated at 2022-06-12 08:18:59.839112
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    class C(B):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'

# Generated at 2022-06-12 08:19:08.599415
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        def __init__(self, name):
            self.name = name

        @lazyperclassproperty
        def base(cls):
            print("base called for %s" % (cls.__name__))
            return cls.__name__ + "_base"

    class A(Base):
        def __init__(self, name, value):
            super(A, self).__init__(name)
            self.value = value

        @lazyperclassproperty
        def a(cls):
            print("a called for %s" % (cls.__name__))
            return cls.__name__ + "_a"

    class B(Base):
        def __init__(self, name, value):
            super(B, self).__init__(name)

# Generated at 2022-06-12 08:19:15.264432
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("Foo")
            return 'foo of A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            print("Foo")
            return 'foo of C'

    assert "foo of A" == A.foo
    assert "foo of A" == B.foo
    assert "foo of C" == C.foo



# Generated at 2022-06-12 08:19:24.277977
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:19:34.153598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        count = 0
        @lazyperclassproperty
        def static_func(cls):
            cls.count += 1
            return {'class': cls.__name__}

    a = A()
    assert A.static_func['class'] == 'A'
    assert A.count == 1
    b = A()
    assert A.static_func['class'] == 'A'
    assert A.count == 1
    class B(A):
        count = 0
        @lazyperclassproperty
        def static_func(cls):
            cls.count += 1
            return {'class': cls.__name__}

    assert B.static_func['class'] == 'B'
    assert B.count == 1
    assert A.static_func['class'] == 'A'