

# Generated at 2022-06-12 08:09:40.482055
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def testprop(cls):
            return True

        @lazyclassproperty
        def testprop2(cls):
            return True

    class TestClass2(TestClass):
        pass

    assert TestClass.testprop is True
    assert TestClass2.testprop is True
    assert TestClass.testprop2 is True
    assert TestClass2.testprop2 is True
    assert TestClass.__dict__['_lazy_testprop'] is True
    assert TestClass2.__dict__['_lazy_testprop'] is True
    assert TestClass.__dict__['_lazy_testprop2'] is True
    assert TestClass2.__dict__['_lazy_testprop2'] is True
    assert 'testprop' not in TestClass.__dict

# Generated at 2022-06-12 08:09:47.379706
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(metaclass=type):
        a = lazyperclassproperty(lambda cls: cls.__name__)

    class B(A):
        pass

    class C(A):
        pass

    assert A.a == 'A', f'A.a expected A, but got {A.a} instead.'
    assert B.a == 'B', f'B.a expected B, but got {B.a} instead.'
    assert C.a == 'C', f'C.a expected C, but got {C.a} instead.'


from weakref import WeakKeyDictionary
from inspect import signature, isclass



# Generated at 2022-06-12 08:09:50.730367
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def a(cls):
            return int(time.time())

    assert Test.a == Test.a
    time.sleep(1)
    assert Test.a != Test.a



# Generated at 2022-06-12 08:09:58.138962
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    # Check if the value is assigned to the class itself *not* the
    # class's instances
    assert A.foo == 'bar'
    assert A().foo == 'bar'
    assert B.foo == 'bar'
    assert B().foo == 'bar'

    # Check if the value is cached
    A.foo = 'spam'
    assert A.foo == 'spam'
    assert A().foo == 'spam'
    assert B.foo == 'spam'
    assert B().foo == 'spam'

    # Check if the value is unique for subclasses
    B.foo = 'ham'
    assert A.foo == 'spam'
    assert A

# Generated at 2022-06-12 08:10:03.570168
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:09.361188
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        counter = 0

        @lazyclassproperty
        def my_property(cls):
            Foo.counter += 1
            return Foo.counter
        pass

    assert Foo.my_property == 1
    assert Foo.my_property == 1
    assert Foo.my_property == 1

    class Bar(Foo):
        pass

    assert Bar.my_property == 2
    assert Bar.my_property == 2
    assert Bar.my_property == 2



# Generated at 2022-06-12 08:10:14.619624
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def x(cls):
            return cls.__name__


# Generated at 2022-06-12 08:10:19.225163
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def name(cls):
            print('eval')
            return 'Test'

    assert A.name == 'Test'
    assert A.name == 'Test'

    class B(A):
        pass

    assert B.name == 'Test'
    assert B.name == 'Test'



# Generated at 2022-06-12 08:10:25.023843
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty
    """
    class Foo(object):
        # Create a lazy class property.
        @lazyclassproperty
        def hello(cls):
            return "hello"

    # Assert class property hello is initialised.
    assert Foo.hello == 'hello'

    # Create a sub class FooSub.
    class FooSub(Foo):
        pass

    # Assert subclass FooSub has property hello.
    assert FooSub.hello == 'hello'



# Generated at 2022-06-12 08:10:31.102730
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def val(cls):
            return 5

    class B(A):
        @lazyperclassproperty
        def val(cls):
            return 6

    assert A.val == 5
    assert B.val == 6
    assert A().val == 5
    assert B().val == 6



# Generated at 2022-06-12 08:10:42.503492
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> import sys
    >>> class A(object):
    ...     @lazyclassproperty
    ...     def prop(x):
    ...         print('create A instance')
    ...         return sys.maxsize
    >>> class B(A):
    ...     @lazyclassproperty
    ...     def prop(x):
    ...         print('create B instance')
    ...         return 0
    >>> A.prop
    create A instance
    9223372036854775807
    >>> A.prop
    9223372036854775807
    >>> B.prop
    create B instance
    0
    >>> B.prop
    0
    """


# Generated at 2022-06-12 08:10:45.999319
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:52.308196
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:56.742189
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassProperty(object):
        def __init__(self, value):
            self.value = value

        @lazyclassproperty
        def test(cls):
            return cls(6)
    assert isinstance(TestLazyClassProperty.test, TestLazyClassProperty)
    assert TestLazyClassProperty.test.value == 6



# Generated at 2022-06-12 08:11:00.602599
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        counter = 0

        @lazyclassproperty
        def inc(cls):
            cls.counter += 1
            return cls.counter

    assert Test.inc == 1
    assert Test.inc == 1



# Generated at 2022-06-12 08:11:06.741047
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def value(cls):
            """
            This value should be different for each class
            """
            return cls.__name__

    class Derived(Base):
        pass

    assert Base.value == "Base"
    assert Derived.value == "Derived"
    assert isinstance(Base.value, str)
    assert isinstance(Derived.value, str)



# Generated at 2022-06-12 08:11:09.669080
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'hello'


# Generated at 2022-06-12 08:11:20.445102
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def x(cls):
            return 1

        x = lazyclassproperty(x)

    class B(A):
        def x(cls):
            return 2

        x = lazyclassproperty(x)

    class C(A):
        def x(cls):
            return 3

        x = lazyclassproperty(x)

    class D(B, C):
        def x(cls):
            return 4

        x = lazyclassproperty(x)

    class E(C, B):
        def x(cls):
            return 5

        x = lazyclassproperty(x)

    # Should be 1 for all
    assert A.x == 1
    assert B.x == 1
    assert C.x == 1
    assert D.x == 1
    assert E.x == 1

    # Should be

# Generated at 2022-06-12 08:11:29.871903
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A: pass
    class B(A): pass

    def new_class():
        return "new"

    @lazyperclassproperty
    def get_class(cls):
        return cls

    A.get_class
    B.get_class
    assert(A.get_class is A)
    assert(B.get_class is B)
    assert(A.get_class is not B)
    assert(B.get_class is not A)

    assert(A.get_class == A)
    assert(B.get_class == B)
    assert(A.get_class != B)
    assert(B.get_class != A)

    assert(A.get_class is not new_class)
    assert(A.get_class != new_class)



# Generated at 2022-06-12 08:11:35.484968
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def p(cls):
            return cls.__name__

    class B(A):
        pass

    a = A()
    b = B()
    c = A()
    assert a.p == 'A'
    assert b.p == 'B'
    assert c.p == 'A'


# Generated at 2022-06-12 08:11:44.272406
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls): return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.a == 'A'
    assert B.a == 'B'
    assert C.a == 'C'



# Generated at 2022-06-12 08:11:52.165952
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:11:59.272022
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Service(object):
        def __init__(self, name):
            self.name = name

        @lazyclassproperty
        def service(cls):
            return Service(cls.__name__)

    class FooService(Service):
        def __init__(self):
            super(FooService, self).__init__(FooService.__name__)

    class BarService(Service):
        def __init__(self):
            super(BarService, self).__init__(BarService.__name__)

    assert Service.service is not FooService.service
    assert isinstance(Service.service, Service)
    assert isinstance(FooService.service, FooService)
    assert isinstance(BarService.service, BarService)
    assert Service.service.name == 'Service'
    assert FooService.service

# Generated at 2022-06-12 08:12:03.409030
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class lazyclasspropertyTest(object):
        @lazyclassproperty
        def foo(cls):
            return "foo"

    assert lazyclasspropertyTest.foo == "foo"
    assert lazyclasspropertyTest.__dict__['_lazy_foo'] == "foo"



# Generated at 2022-06-12 08:12:10.160697
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test to check that lazyclassproperty works in the intended way.
    """

    # Set unit test flag
    _TEST_LAZYCLASS_PROPERTY = True

    class Parent(object):
        @lazyclassproperty
        def lazy_prop(cls):
            return ("LAZY" if not _TEST_LAZYCLASS_PROPERTY else "EAGER") + " PARENT"

    class Child(Parent):
        @lazyclassproperty
        def lazy_prop(cls):
            return ("LAZY" if not _TEST_LAZYCLASS_PROPERTY else "EAGER") + " CHILD"

    # Check that parent's property is lazy
    assert Parent.lazy_prop == "LAZY PARENT"
    # Check that child's property is lazy
    assert Child

# Generated at 2022-06-12 08:12:17.145229
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):

        @lazyclassproperty
        def foo(cls):
            print('Calculating foo')
            return 'foo'

        @classproperty
        def bar(cls):
            print('Calculating bar')
            return 'bar'

    assert hasattr(Test, '_lazy_foo')
    assert not hasattr(Test, '_lazy_bar')
    assert Test.foo == 'foo'
    assert not hasattr(Test, '_lazy_foo')
    assert Test.bar == 'bar'

# Generated at 2022-06-12 08:12:23.954703
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A:
        @lazyperclassproperty
        def p(cls):
            print("Calculating A.p")
            return 123

    class B(A):
        @lazyperclassproperty
        def p(cls):
            print("Calculating B.p")
            return 456

    assert A.p == 123
    assert B.p == 456
    assert A().p == 123
    assert B().p == 456



# Generated at 2022-06-12 08:12:33.813426
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:37.714132
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("call a")
            return 1

    class B(A):
        pass
    class C(A):
        pass
    # call a
    # 1
    print(A.a)

    # 1
    print(B.a)

    # 1
    print(C.a)



# Generated at 2022-06-12 08:12:49.117142
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def a(cls):
            return {'a': 'a'}

    class Derived(Base):
        @lazyperclassproperty
        def b(cls):
            return {'b': 'b'}

    assert Base.a == Derived.a == {'a': 'a'}
    assert Derived.b == {'b': 'b'}
    assert Base.a != Derived.b
    Base.a['new'] = 'new'
    Derived.b['new'] = 'new'
    print(Base.a)
    print(Derived.a)
    print(Derived.b)
    assert Base.a == Derived.a
    assert Derived.a != Derived.b
    assert Derived.b['new']

# Generated at 2022-06-12 08:13:04.656331
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        test = lazyperclassproperty(lambda cls: cls.__name__ + 'foo')

    class SubTest(Test):
        pass

    class SubSubTest(SubTest):
        pass

    assert Test.test == 'Testfoo'
    assert SubTest.test == 'SubTestfoo'
    assert SubSubTest.test == 'SubSubTestfoo'
    assert Test.test == 'Testfoo'
    assert SubTest.test == 'SubTestfoo'
    assert SubSubTest.test == 'SubSubTestfoo'



# Generated at 2022-06-12 08:13:10.247365
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    calls = []

    class A(object):
        @lazyclassproperty
        def fn(cls):
            calls.append(cls)
            return 1

    class B(A):
        pass

    assert B.fn == 1
    assert calls == [A,]

    del calls[:]
    assert A.fn == 1
    assert calls == []

    # Check that caching worked
    del calls[:]
    assert A.fn == 1
    assert calls == []


# Generated at 2022-06-12 08:13:18.749854
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return [1,2,3]

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass


    foo = Foo()
    bar = Bar()
    baz = Baz()

    assert foo.bar is not bar.bar
    assert foo.bar is not baz.bar
    assert foo.bar is [1,2,3]
    assert bar.bar is [1,2,3]
    assert baz.bar is [1,2,3]

    assert foo.bar is foo.bar
    assert bar.bar is bar.bar
    assert baz.bar is baz.bar


# Generated at 2022-06-12 08:13:28.447236
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Vehicle(object):
        def __init__(self):
            pass


# Generated at 2022-06-12 08:13:34.216261
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def method(cls):
            print ("Calling method()")
            return 42

    a, b = A(), A()
    assert a.method == b.method == 42
    a.method = 100
    assert a.method == 100
    assert b.method == 42



# Generated at 2022-06-12 08:13:38.529785
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent:
        @lazyperclassproperty
        def value(cls):
            return cls.__name__

    class Child(Parent):
        pass

    assert 'Parent' == Parent.value
    assert 'Child' == Child.value



# Generated at 2022-06-12 08:13:45.017807
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Person(object):
        def __init__(self):
            self.name = ''

        @lazyperclassproperty
        def height(cls):
            print('fetching height')
            print('class=%s' % cls.__name__)
            return cls.get_height()

        @classmethod
        def get_height(cls):
            return '200cm'

    class Mother(Person):
        @classmethod
        def get_height(cls):
            return '300cm'

    x = Person()
    y = Mother()

    print('x height=%s' % x.height)
    print('y height=%s' % y.height)
    print('x height=%s' % x.height)
    print('y height=%s' % y.height)




# Generated at 2022-06-12 08:13:55.517185
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def myprop(cls):
            print("Initializing myprop")
            return "myprop"

    print("A.myprop", A.myprop)
    print("A.myprop", A.myprop)

    class B(A):
        pass

    print("B.myprop", B.myprop)
    print("B.myprop", B.myprop)

    class C(A):
        @lazyclassproperty
        def myprop(cls):
            print("Initializing myprop in C")
            return "myprop_c"

    print("C.myprop", C.myprop)
    print("C.myprop", C.myprop)

    class D(C):
        pass

    print("D.myprop", D.myprop)

# Generated at 2022-06-12 08:14:02.891184
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            return "xyz"
    assert C.x == "xyz"
    assert C().x == "xyz"
    assert C.x is C().x
    C.x = "abc"
    assert C.x == "abc"
    assert C().x == "abc"
    assert C.x is C().x
    class D(C):
        pass
    assert D.x == "abc"
    assert D().x == "abc"
    assert D.x is D().x


# Generated at 2022-06-12 08:14:11.102739
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test for class method
    class TestClass(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'
    assert TestClass.foo == 'foo'
    assert TestClass._lazy_foo == 'foo'

    # Test for static method
    class TestClass(object):
        @staticmethod
        @lazyclassproperty
        def foo():
            return 'foo'
    assert TestClass.foo == 'foo'
    assert TestClass._lazy_foo == 'foo'

    # Test for inheritors
    class TestClass1(object):
        @lazyclassproperty
        def foo(cls):
            return []

    class TestClass2(TestClass1):
        @lazyclassproperty
        def foo(cls):
            return ['bar']

# Generated at 2022-06-12 08:14:30.869419
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def test(cls):
            return 'result'

    assert Test.__dict__['_lazy_test'] is None
    assert Test.test == 'result'
    assert Test.__dict__['_lazy_test'] == 'result'



# Generated at 2022-06-12 08:14:35.781844
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def mem(cls):
            return object()

    class B(A):
        pass

    class C(A):
        pass

    assert A.mem is not B.mem
    assert A.mem is not C.mem
    assert B.mem is not C.mem



# Generated at 2022-06-12 08:14:41.176510
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def g(cls):
            return 42


    class B(A):
        pass

    a = A()
    assert a.g == 42
    assert B.g == 42

    class C(A):
        @lazyclassproperty
        def g(cls):
            return 10

    c = C()
    assert c.g == 10
    assert B.g == 42
    assert A.g == 42



# Generated at 2022-06-12 08:14:49.263712
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A():

        class Inner():
            @lazyperclassproperty
            def result(cls):
                '''Some result'''
                print('lazyperclassproperty called')
                return 'Some result'

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    assert A.Inner.result == 'Some result'
    assert A.Inner.result == 'Some result'
    assert hasattr(A.Inner, '_Inner_lazy_result')
    assert not hasattr(B.Inner, '_Inner_lazy_result')
    assert not hasattr(C.Inner, '_Inner_lazy_result')

    b = B()
    assert B.Inner.result == 'Some result'
    assert B.Inner.result

# Generated at 2022-06-12 08:14:53.698519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            cls.bar_counter = getattr(cls, 'bar_counter', 0) + 1
            return cls.bar_counter


    class Bar(Foo):
        pass

    assert Foo.bar == 1
    assert Foo.bar == 1
    assert Bar.bar == 1
    assert Bar.bar == 1



# Generated at 2022-06-12 08:15:03.282906
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self, a1):
            self.a1 = a1

        @lazyclassproperty
        def total_a1(cls):
            return sum(obj.a1 for obj in cls.get_all_instances())

        @classmethod
        def get_all_instances(cls):
            return [cls(1), cls(2), cls(3)]

    assert A.total_a1 == 6

    class B(A):
        def __init__(self, b1):
            super().__init__(b1)
            self.b1 = b1

        @lazyclassproperty
        def total_b1(cls):
            return sum(obj.b1 for obj in cls.get_all_instances())


# Generated at 2022-06-12 08:15:10.059553
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(self):
            return 'foo'
    class B(A):
        pass
    class C(A):
        @lazyperclassproperty
        def foo(self):
            return 'bar'
    assert A().foo == 'foo'
    assert B().foo == 'foo'
    assert C().foo == 'bar'
    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'bar'



# Generated at 2022-06-12 08:15:12.683048
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        _a = 0
        @lazyclassproperty
        def a(cls):
            cls._a += 1
            return cls._a

    assert Test.a == 1
    assert Test.a == 1

# Generated at 2022-06-12 08:15:16.176297
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def i(cls):
            return 0

    a = A()
    b = A()
    A.i = 1

    assert a.i == 1
    assert b.i == 1


# Generated at 2022-06-12 08:15:25.478437
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        foo = 1
        def __init__(self, foo):
            self.foo = foo

        @lazyclassproperty
        def static_foo(cls):
            return cls.foo

        @lazyclassproperty
        def static_foo_instance(cls):
            return cls(cls.foo)

    class Bar(Foo):
        foo = 2


# Generated at 2022-06-12 08:16:15.407007
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class a(object):
        @lazyperclassproperty
        def x(cls):
            return 'x'

    class b(a):
        @lazyperclassproperty
        def x(cls):
            return 'y'

    class bb(b):
        pass

    assert a.x == 'x'
    assert b.x == 'y'
    assert bb.x == 'y'



# Generated at 2022-06-12 08:16:24.948024
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:16:28.127778
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class testclass(object):

        @lazyperclassproperty
        def attr(cls):
            return object()

    assert testclass.attr is testclass.attr

    class testclass2(testclass):
        pass

    assert testclass.attr is not testclass2.attr



# Generated at 2022-06-12 08:16:35.019187
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    attr_name = '_lazy_' + "attr"

    class TestClass(object):
        @lazyclassproperty
        def attr(cls):
            return "Hello World!"

        @classmethod
        def classmethod(cls):
            return True

    assert not hasattr(TestClass, attr_name)
    assert TestClass.attr == "Hello World!"
    assert hasattr(TestClass, attr_name)
    assert TestClass.attr == "Hello World!"
    assert TestClass.attr == TestClass().attr
    assert TestClass.classmethod()
    assert TestClass.classmethod() == TestClass().classmethod()



# Generated at 2022-06-12 08:16:39.916454
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    foo1 = Foo()
    foo2 = Foo()
    # Check that the same instance of 'bar' is returned
    assert foo1.bar is foo2.bar



# Generated at 2022-06-12 08:16:49.670438
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    A = type("A", (object,), {})
    B = type("B", (A,), {})

    @lazyperclassproperty
    def myfunc(cls):
        return cls

    assert A.myfunc is A
    assert B.myfunc is B

    @lazyperclassproperty
    def myfunc2(cls):
        return cls
    assert B.myfunc is B
    assert B.myfunc2 is B
    assert A.myfunc is A
    assert A.myfunc2 is A

    # Test the 'hasattr' and 'getattr' interaction
    @lazyperclassproperty
    def myfunc3(cls):
        return cls
    b = B()
    b.myfunc3 = True
    assert b.myfunc3 is True



# Generated at 2022-06-12 08:16:53.888171
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(c):
            return 'A'

    class B(A):
        pass

    assert A.a == 'A'
    assert B.a == 'A'
    A.a = 'AAA'
    assert A.a == 'AAA'
    assert B.a == 'A'


# Generated at 2022-06-12 08:16:57.072956
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 1

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return 2

    assert A.foo == 1
    assert B.foo == 2



# Generated at 2022-06-12 08:17:05.313948
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 3
        @lazyclassproperty
        def y(cls):
            return 7

    class B(A):
        @lazyclassproperty
        def x(cls):
            return 5

    print(A.x, A.y)  # 3, 7
    print(B.x, B.y)  # 5, 7

    A.x = 4
    print(A.x, A.y)  # 3, 7
    print(B.x, B.y)  # 5, 7

    A.y = 6
    print(A.x, A.y)  # 3, 6
    print(B.x, B.y)  # 5, 6

    B.y = 8

# Generated at 2022-06-12 08:17:08.579202
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            print("called")
            return 'bar'
    assert Foo.foo == 'bar'
    assert Foo.foo == 'bar'
    assert Foo.__dict__['_lazy_foo'] == 'bar'



# Generated at 2022-06-12 08:18:50.076561
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    
    class TestClass(object):

        @lazyclassproperty
        def test_property(cls):
            return cls
    
    test_obj = TestClass()
    assert isinstance(test_obj.test_property, TestClass)

# Generated at 2022-06-12 08:18:54.856039
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:57.129873
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return random.random()

    assert Foo.bar == Foo.bar

    class Bar(Foo):
        pass

    assert Bar.bar != Foo.bar



# Generated at 2022-06-12 08:19:05.780494
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:19:14.825352
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            return "result"
    assert C.prop == "result"
    assert C.__dict__["_lazy_prop"] == "result"
    C.__dict__.clear()
    assert C.prop == "result"
    assert C.__dict__["_lazy_prop"] == "result"
    C.__dict__.clear()
    class D(C):
        pass
    assert C.prop == "result"
    assert C.__dict__["_lazy_prop"] == "result"
    assert D.__dict__["_lazy_prop"] == "result"
    assert D.prop == "result"



# Generated at 2022-06-12 08:19:18.908672
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        @lazyclassproperty
        def x(cls):
            return 'bx'

    assert A.x == 'x'
    assert B.x == 'bx'


# Generated at 2022-06-12 08:19:29.788597
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            self.name = 'Base'

        def get_name(self):
            return self.name

    class C1(Base):
        pass

    class C2(Base):
        pass

    assert lazyperclassproperty.__doc__ is not None

    Base.test = lazyperclassproperty(C1.get_name)
    Base.test2 = lazyperclassproperty(C2.get_name)

    c1 = C1()
    c2 = C2()

    c1.name = 'c1'
    c2.name = 'c2'

    assert Base.test == 'c1'
    assert Base.test2 == 'c2'


if __name__ == '__main__':
    test_lazyperclassproperty()