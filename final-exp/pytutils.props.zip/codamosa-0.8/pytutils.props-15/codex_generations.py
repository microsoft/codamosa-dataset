

# Generated at 2022-06-12 08:09:33.279949
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print('init')
            return 'test'

    assert A.prop == 'test'
    A.prop = 'other'
    assert A.prop == 'other'



# Generated at 2022-06-12 08:09:37.163050
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def test(cls):
            return cls

    assert Test.test is Test
    assert Test().test is Test

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:09:41.744580
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            print("Setting x")
            return 42

    print(A.x)
    print(A.x)
    assert A.x == 42

    # Check that it is set correctly on the class, not another object
    class B:
        pass

    print(B.x)
    assert B.x == 42

# Generated at 2022-06-12 08:09:49.074391
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyClass(object):
        def __init__(self, name):
            self.name = name

    class MySubClass(MyClass):
        pass

    def get_lazy_property(cls):
        return cls.__name__

    MyClass.lazy = lazyperclassproperty(get_lazy_property)
    MySubClass.lazy = lazyperclassproperty(get_lazy_property)

    my_class = MyClass('Hello')
    my_subclass = MySubClass('Hello')

    # Check that the lazy properties return when we expect
    assert my_class.lazy == 'MyClass'
    assert my_subclass.lazy == 'MySubClass'

    # Check that the lazy properties set correctly in the class
    assert MyClass.lazy == 'MyClass'
    assert MySubClass

# Generated at 2022-06-12 08:09:55.372166
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def test(cls):
            return cls.__name__

    class A(Base):
        pass

    class B(A):
        pass

    assert Base.test == 'Base'
    assert A.test == 'A'
    assert B.test == 'B'

    from mock import patch

    with patch.object(Base, '__dict__', {'_Base_lazy_test': 'mock'}):
        assert Base.test == 'mock'



# Generated at 2022-06-12 08:09:58.586846
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'prop'

    assert A.prop == 'prop', 'Error found'


# Generated at 2022-06-12 08:10:01.861627
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def prop(cls):
            print("Calculating prop")
            return 5

    print(A.prop)
    print(A.prop)
    print(A.prop)



# Generated at 2022-06-12 08:10:07.816582
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'a'

        b = A.a

        @lazyclassproperty
        def c(cls):
            return object()

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A.b == A.a
    assert B.b == B.a
    assert A.a is not A.b
    assert B.a is not B.b

    assert A.c is A.c
    assert B.c is B.c
    assert A.c is not B.c



# Generated at 2022-06-12 08:10:16.855128
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            self.base_var = -1

    class A(Base):
        @lazyperclassproperty
        def var(cls):
            return cls().base_var + 1

    class B(Base):
        @lazyperclassproperty
        def var(cls):
            return cls().base_var * 2

    print(A.var)  # Output: 0
    print(B.var)  # Output: -2

    # A cannot access B's cached value
    print(A.var)  # Output: 0
    print(B.var)  # Output: -2



# Generated at 2022-06-12 08:10:22.143574
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):

        @lazyclassproperty
        def prop(cls):
            print("computing...")
            return 42

    assert TestClass.prop == 42
    assert TestClass.prop == 42

    class SubTestClass(TestClass):
        pass
    assert SubTestClass.prop == 42


_marker = object()



# Generated at 2022-06-12 08:10:27.710020
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def foo(cls):
            print("Computing")
            return 100

    foo = A.foo
    foo = A.foo



# Generated at 2022-06-12 08:10:36.102228
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Prepare testing vars
    class A:
        pass
    class B(A):
        pass
    called = False

    def f():
        nonlocal called
        called = True
        return 1

    # Test for class A
    A.lazyprop = lazyclassproperty(f)
    assert A.lazyprop == 1
    assert called
    assert A.lazyprop == 1
    called = False

    # Test for class B
    assert B.lazyprop == 1
    assert not called
    assert B.lazyprop == 1

    # Test for class A
    assert A.lazyprop == 1
    assert not called
    assert A.lazyprop == 1



# Generated at 2022-06-12 08:10:45.896834
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class foo(object):
        @lazyperclassproperty
        def bar(cls):
            return 'bar'

        @lazyperclassproperty
        def boo(cls):
            return 'boo'

    class goo(foo):
        pass

    foo_inst = foo()
    goo_inst = goo()

    assert foo.bar == 'bar'
    assert foo_inst.bar == 'bar'
    assert goo.bar == 'bar'
    assert goo_inst.bar == 'bar'

    assert foo.boo == 'boo'
    assert foo_inst.boo == 'boo'
    assert goo.boo == 'boo'
    assert goo_inst.boo == 'boo'


# Generated at 2022-06-12 08:10:51.198985
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        def one(self):
            return 1

        one = lazyclassproperty(one)

        def two(self):
            return 2

        two = lazyclassproperty(two)

    a = A()
    assert A.one == 1
    assert A.two == 2



# Generated at 2022-06-12 08:10:55.385989
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def test(cls):
            print("Setting lazy cls prop")
            return cls, "test"
    assert Foo.test == (Foo, "test"), "lazyclassproperty is not lazy"

    class Bar(Foo):
        pass

    # Unit test for classproperty
    assert Foo.test is Bar.test, "lazyclassproperty returns same value for parent and child"



# Generated at 2022-06-12 08:11:06.051550
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def x(cls):
            return 3
        @lazyclassproperty
        def y(cls):
            return 4

        def __init__(self):
            self.x = 5
            self.y = 6

    foo = Foo()
    assert foo.x == 5
    assert foo.y == 6
    assert Foo.x == 3
    assert Foo.y == 4

    class Bar(Foo):
        pass
    bar = Bar()
    assert bar.x == 5 # Bar should share Foo's x value
    assert bar.y == 6 # Bar should share Foo's y value
    assert Foo.x == 3
    assert Foo.y == 4



# Generated at 2022-06-12 08:11:09.257593
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'

    A.prop = 'test'
    assert A.prop == 'test'



# Generated at 2022-06-12 08:11:13.114274
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return list(range(3))

    class B(A):
        pass

    assert A.x is A.x
    assert B.x is not A.x
    assert B.x is B.x



# Generated at 2022-06-12 08:11:21.001161
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):

        @lazyperclassproperty
        def foo(cls):
            print("Called foo in", cls.__name__)
            return cls.__name__

    class Child(Parent):
        pass

    class Grandchild(Child):
        pass

    print("Parent.foo=", Parent.foo)
    print("Child.foo=", Child.foo)
    print("Grandchild.foo=", Grandchild.foo)


if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:11:27.878870
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty  #invokes __init__(self, cls, name, bases, kwargs)
        def x(self):
            """docstring for x"""
            return 17

    assert A.__dict__['_lazy_x'].__doc__ == 'docstring for x' # docstring copied
    assert A().x == 17  # invokes __get__(self, obj, type=None)
    assert A.__dict__['_lazy_x'] == 17


# Generated at 2022-06-12 08:11:42.284016
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return []

        @lazyclassproperty
        def baz(self):
            return []

    assert type(Foo.bar) is property
    assert type(Foo.baz) is property
    assert Foo.bar is not Foo().bar is not Foo.bar
    assert Foo.baz is Foo().baz

    a = Foo()
    a.bar.append(1)
    assert a.bar == [1]
    # Foo.bar is different
    assert Foo.bar == []

    a.baz.append(1)
    assert a.baz == [1]
    # Foo.baz is the same
    assert Foo.baz == [1]



# Generated at 2022-06-12 08:11:44.531708
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Hello(object):
        @lazyclassproperty
        def hi(cls):
            return 'hello'

    print(Hello.hi)



# Generated at 2022-06-12 08:11:48.460291
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Person:
        @lazyclassproperty
        def attribute(cls):
            print("Getting attribute ...")
            return 'spam' * 3

    assert(Person.attribute == "spamspamspam")
    assert(Person.attribute == "spamspamspam")



# Generated at 2022-06-12 08:11:54.337557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'a'
    assert A.prop == 'a'
    class B(A):
        pass
    assert B.prop == 'a'
    # Make sure the value is cached
    B.prop = 'b'
    assert B.prop == 'b'
    assert A.prop == 'a'
    class C(B):
        pass
    assert C.prop == 'b'

# Generated at 2022-06-12 08:12:01.334160
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):

        @lazyperclassproperty
        def bar(cls):
            print('Base.bar getter called')
            return 'baz'

    class Inheritor(Base):

        @lazyperclassproperty
        def bar(cls):
            print('Inheritor.bar getter called')
            return 'quux'

    assert Base.bar == 'baz'
    assert Inheritor.bar == 'quux'



# Generated at 2022-06-12 08:12:09.386137
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            cls.counter += 1
            return 1

    class B(A):
        counter = 0

    class C(A):
        counter = 0

    assert not hasattr(A, '_lazy_a')
    assert not hasattr(B, '_lazy_a')
    assert not hasattr(C, '_lazy_a')
    assert not hasattr(A, '_B_lazy_a')
    assert not hasattr(B, '_B_lazy_a')
    assert not hasattr(C, '_B_lazy_a')
    assert not hasattr(A, '_C_lazy_a')
    assert not hasattr(B, '_C_lazy_a')

# Generated at 2022-06-12 08:12:14.614768
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:19.622533
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class BaseClass(object):
        __slots__ = [
            '_BASE_CALLED_FLAG'
        ]

        @lazyperclassproperty
        def base_property(cls):
            cls._BASE_CALLED_FLAG = True
            return 'BaseClass'

    class DerivedClass(BaseClass):
        __slots__ = [
            '_DERIVED_CALLED_FLAG'
        ]

        @lazyperclassproperty
        def derived_property(cls):
            cls._DERIVED_CALLED_FLAG = True
            return 'DerivedClass'

    assert (not hasattr(BaseClass, '_BASE_CALLED_FLAG'))
    assert (not hasattr(DerivedClass, '_DERIVED_CALLED_FLAG'))


# Generated at 2022-06-12 08:12:23.153423
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('bar')
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo.bar == 'bar'



# Generated at 2022-06-12 08:12:28.216077
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f(cls):
        print("Executing f(%s)" % cls)
        return 42
    class A(object):
        x = lazyclassproperty(f)
    class B(A):
        pass
    assert A.x == 42
    assert B.x == 42
    assert A.x is B.x
    def g(cls):
        print("Executing g(%s)" % cls)
        return 24
    class A(object):
        x = lazyclassproperty(g)
    assert A.x == 24
    assert B.x == 42



# Generated at 2022-06-12 08:12:39.059510
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    _counter = 0

    def build_f():
        global _counter
        _counter += 1

        def f():
            return _counter

        return f

    class A(object):
        f = lazyclassproperty(build_f)

    class B(A):
        pass

    assert A.f == B.f == 1



# Generated at 2022-06-12 08:12:46.728255
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    print("A.prop =", A.prop)
    class B(A):
        pass
    print("B.prop =", B.prop)
    class C(A):
        pass
    print("C.prop =", C.prop)
    print("B.prop =", B.prop)


if __name__ == '__main__':
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:12:52.700588
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            print('x getter')
            return 'x value'
    print('A.x:', A.x)  # prints "x getter" followed by "x value"
    print('A.x:', A.x)  # prints "x value"
    class B(A):
        pass
    print('B.x:', B.x)  # prints "x value"



# Generated at 2022-06-12 08:13:00.913277
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    >>> class X:
    ...     @lazyperclassproperty
    ...     def foo(cls):
    ...         print("foo for %s" % cls.__name__)
    ...         return 16

    >>> X.foo
    foo for X
    16

    >>> class Y(X): pass

    >>> Y.foo
    foo for Y
    16

    >>> class Z(Y):
    ...     @lazyperclassproperty
    ...     def foo(cls):
    ...         print("foo for %s" % cls.__name__)
    ...         return 17

    >>> Z.foo
    foo for Z
    17
    """



# Generated at 2022-06-12 08:13:10.491350
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class Test(object):
        def __init__(self, value):
            self._value = value

    class TestTest(unittest.TestCase):
        def test_lazyclassproperty(self):
            class A(Test):
                @lazyclassproperty
                def a(cls):
                    return cls(1)

            a = A()
            self.assertEqual(a._value, 1)

            class B(A):
                @lazyclassproperty
                def b(cls):
                    return cls(2)

            b = B()
            self.assertEqual(b._value, 2)

            class C(B):
                @lazyclassproperty
                def c(cls):
                    return cls(3)

            c = C()

# Generated at 2022-06-12 08:13:14.264320
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def cache(self):
            return {'x': 1}

    class B(A):
        pass

    assert A.cache() is A.cache()
    assert A.cache() is not B.cache()
    assert A.cache().get('x') == 1


# Generated at 2022-06-12 08:13:20.385229
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'lazy'

        @lazyclassproperty
        def prop1(cls):
            raise Exception('Not this time.')

    assert isinstance(A.prop, classproperty)
    assert A.prop == A.prop
    assert isinstance(A.prop1, classproperty)
    assert A.prop1 == A.prop1
    assert A.prop != A.prop1



# Generated at 2022-06-12 08:13:22.995226
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def f(cls):
            return 42

    # first use

# Generated at 2022-06-12 08:13:28.252050
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f(cls):
        return cls.__name__

    class MyClass(object):
        class_name = lazyclassproperty(f)

    class MySubClass(MyClass): pass

    assert MyClass.class_name == 'MyClass'
    assert MySubClass.class_name == 'MySubClass'



# Generated at 2022-06-12 08:13:38.901508
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class FooClass(object):
        def __init__(self):
            self._prop = None

        @lazyperclassproperty
        def prop(cls):
            return 'prop'

        @property
        def prop_via_getter(self):
            return self._prop

        @prop_via_getter.setter
        def prop_via_getter(self, value):
            self._prop = value

    # test1
    foo_class_instance = FooClass()
    foo_class_instance.prop_via_getter = 'test'
    assert foo_class_instance.prop_via_getter == 'test'

    # test2
    assert FooClass.prop == 'prop'



# Generated at 2022-06-12 08:14:01.302630
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1
    class B(A):
        pass
    class C(B):
        pass
    assert A.a == 1
    assert B.a == 1
    assert C.a == 1
    A.a = 2
    assert A.a == 2
    assert B.a == 1
    assert C.a == 1
    B.a = 3
    assert A.a == 2
    assert B.a == 3
    assert C.a == 1
    C.a = 4
    assert A.a == 2
    assert B.a == 3
    assert C.a == 4



# Generated at 2022-06-12 08:14:05.689666
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        attr = 1

        @lazyperclassproperty
        def obj(cls):
            return A(2)

    class B(A):
        attr = 2

    obj = A.obj
    obj2 = B.obj

    assert obj.attr == 1
    assert obj2.attr == 2



# Generated at 2022-06-12 08:14:09.035986
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def toto(cls):
            return 1

    assert C.toto == 1
    assert C._lazy_toto == 1
    assert not hasattr(C, '_lazy_toto')

# Generated at 2022-06-12 08:14:13.433770
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:16.905584
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(B):
        pass

    assert A.x == "A"
    assert B.x == "B"
    assert C.x == "C"



# Generated at 2022-06-12 08:14:23.879746
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    # Base class
    class A(object):
        @lazyperclassproperty
        def perclass_foo(cls):
            print("Init perclass_foo in %s" % cls.__name__)
            if cls == A:
                return 5
            return 6

    # Inherit from class A
    class B(A):
        pass

    # Test
    assert A.perclass_foo == 5  # prints 'Init perclass_foo in A'
    assert B.perclass_foo == 6  # prints 'Init perclass_foo in B'
    assert A.perclass_foo == 5  # doesn't print
    assert B.perclass_foo == 6  # doesn't print



# Generated at 2022-06-12 08:14:27.027025
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def spam(cls):
            return 'foo'

    class Bar(Foo):
        @lazyperclassproperty
        def spam(cls):
            return 'bar'

    assert Foo.spam == 'foo'
    assert Bar.spam == 'bar'



# Generated at 2022-06-12 08:14:33.837668
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def foo(cls):
            x = (1, object(), object())
            return x

    class B(A):
        pass

    assert A.foo[0] == 1
    assert B.foo[0] == 1
    assert len(A.foo) == 3
    assert len(B.foo) == 3
    assert A.foo[1] is not A.foo[2]
    assert B.foo[1] is not B.foo[2]
    assert A.foo[1] is not B.foo[1]
    assert A.foo[2] is not B.foo[2]



# Generated at 2022-06-12 08:14:37.541873
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def f(cls):
            print('calculating')
            return 42

    class Bar(Foo):
        pass

    assert Foo.f == 42
    assert Bar.f == 42
    assert Foo.f is Bar.f



# Generated at 2022-06-12 08:14:40.677806
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def myprop(cls):
            return 'myprop'

    a = A()
    assert a.myprop == 'myprop'  # This call triggers the evaluation.
    # Now the value is in the class, so this call will return the value without re-evaluating.
    assert a.myprop == 'myprop'



# Generated at 2022-06-12 08:15:18.919134
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(self):
            print('a')
            return 42

        @lazyperclassproperty
        def b(self):
            print('b')
            return [1,2,3]

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def b(self):
            print('bb')
            return [4,5,6]
    c = C()
    a = A()
    c.a, c.b == a.a, a.b
    42 == 42



# Generated at 2022-06-12 08:15:21.399887
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            return "bar"

    assert Foo.bar == "bar"



# Generated at 2022-06-12 08:15:26.469125
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            print("Called")
            return cls.y + 1

        y = 10

    class D(C):
        pass

    assert C.x == 11
    assert D.x == 11
    C.y = 11
    assert C.x == 12
    assert D.x == 11
    D.y = 12
    assert C.x == 12
    assert D.x == 13



# Generated at 2022-06-12 08:15:34.472396
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo_A'

        @lazyclassproperty
        def bar(cls):
            print('bar')
            return 'bar_A'

    class B(A):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo_B'

        @lazyclassproperty
        def bar(cls):
            print('bar')
            return 'bar_B'

    print(A.foo)
    print(A.bar)
    print(A.foo)
    print(A.bar)
    print(B.foo)
    print(B.bar)
    print(B.foo)
    print(B.bar)



# Generated at 2022-06-12 08:15:38.516550
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        pass

    class Bar(Foo):
        x = 1

        @lazyperclassproperty
        def prop(cls):
            return cls.x + 1

    class Baz(Foo):
        x = 2

    assert Foo.prop == 2
    assert Bar.prop == 2
    assert Baz.prop == 3
    Bar.x = 10
    assert Foo.prop == 2
    assert Bar.prop == 11
    assert Baz.prop == 3



# Generated at 2022-06-12 08:15:44.724885
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ParentClass(object):
        @lazyperclassproperty
        def hello(cls):
            return 'hello'

        @lazyperclassproperty
        def world(cls):
            return 'world'

    class ChildClass(ParentClass):
        @lazyperclassproperty
        def wow(cls):
            return 'wow'

    class AnotherChildClass(ParentClass):
        @lazyperclassproperty
        def wow(cls):
            return 'sleep'

    assert ParentClass.hello == 'hello'
    assert ParentClass.world == 'world'
    assert ChildClass.hello == 'hello'
    assert ChildClass.world == 'world'
    assert ChildClass.wow == 'wow'
    assert AnotherChildClass.wow == 'sleep'



# Generated at 2022-06-12 08:15:49.506089
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls): return 'a'

        @lazyperclassproperty
        def prop2(cls): return cls().__class__.__name__

    class B(A):
        @lazyperclassproperty
        def prop(cls): return 'b'

    assert A.prop == 'a' and B.prop == 'b' and A.prop2 == 'A' and B.prop2 == 'B'



# Generated at 2022-06-12 08:15:51.982591
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a == 1
    assert B.a == 1



# Generated at 2022-06-12 08:15:59.021456
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        def __init__(self):
            self.foo = None

        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

        def test(self):
            print('parent: {}'.format(self.__class__.bar))

    class Child(Parent):
        pass

    parent = Parent()
    child = Child()

    assert parent.bar == 'Parent'
    assert Child.bar == 'Parent' # per-class property, bar is only defined for class Parent
    assert child.bar == 'Parent' # per-class property, bar is only defined for class Parent
    assert Child().bar == 'Parent'
    assert Child().__class__.bar == 'Parent'
    assert parent.bar == 'Parent' # per-class property, bar is only defined for class Parent

   

# Generated at 2022-06-12 08:16:02.329122
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class testclass:
        @lazyclassproperty
        def hello(cls):
            return "hello {}".format(cls.__name__)

    t1 = testclass()
    t2 = testclass()
    assert t1.hello == t2.hello == "hello testclass"
    testclass.__name__ = "testclass2"
    assert t1.hello == t2.hello == "hello testclass"



# Generated at 2022-06-12 08:17:21.569508
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:27.341507
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def val(cls):
            return 1

        @lazyclassproperty
        def val2(cls):
            return 2

    assert Test.val == 1
    assert Test.__dict__['_lazy_val'] == 1

    assert Test.val2 == 2
    assert Test.__dict__['_lazy_val2'] == 2

    class Test2(Test):
        pass

    assert Test2.val == 1
    assert '_lazy_val' not in Test2.__dict__
    assert Test.__dict__['_lazy_val'] == 1


# Generated at 2022-06-12 08:17:34.590807
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:17:40.221274
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def field2(cls):
            return 1

    class B(A):
        pass

    assert A.field2 == 1
    assert B.field2 == 1

    A.field2 = 2
    assert A.field2 == 2
    assert B.field2 == 1

    B.field2 = 3
    assert A.field2 == 2
    assert B.field2 == 3



# Generated at 2022-06-12 08:17:48.612786
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A1(object):
        @lazyperclassproperty
        def foo(cls):
            return {"A1": cls.__name__}

    class A2(object):
        @lazyperclassproperty
        def foo(cls):
            return {"A2": cls.__name__}

    class B1(A1):
        @lazyperclassproperty
        def foo(cls):
            return {"B1": cls.__name__}

    class B2(A2):
        @lazyperclassproperty
        def foo(cls):
            return {"B2": cls.__name__}

    assert A1.foo == {"A1": "A1"}
    assert A2.foo == {"A2": "A2"}

# Generated at 2022-06-12 08:17:53.895113
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> class MyClass(object):
    ...     @lazyclassproperty
    ...     def a(cls):
    ...         print "A"
    ...         return 1
    >>> MyClass.a
    A
    1
    >>> MyClass.a
    1
    >>> MyClass.__dict__['a']
    1
    >>> MyClass.__dict__
    {'_lazy_a': 1, ... }
    """



# Generated at 2022-06-12 08:18:01.578037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        foo = lazyperclassproperty(lambda x: 0)
    
    class Bar(Foo):
        foo = lazyperclassproperty(lambda x: 1)
    
    class Baz(Foo):
        foo = lazyperclassproperty(lambda x: 2)
    
    class Qux(Bar, Baz):
        foo = lazyperclassproperty(lambda x: 3)
    
    assert Foo.foo == 0
    assert Bar.foo == 1
    assert Baz.foo == 2
    assert Qux.foo == 3


# Generated at 2022-06-12 08:18:05.639568
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return cls.__name__

    class B(A):
        @lazyclassproperty
        def test(cls):
            return cls.__name__

    assert A.test == 'A'
    assert B.test == 'B'

# Generated at 2022-06-12 08:18:10.271237
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:12.881928
# Unit test for function lazyclassproperty