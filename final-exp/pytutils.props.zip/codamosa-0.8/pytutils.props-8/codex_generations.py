

# Generated at 2022-06-12 08:09:39.268208
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pytest import raises
    from types import MethodType

# Generated at 2022-06-12 08:09:43.438636
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        attr1 = 5

        @lazyperclassproperty
        def attr2(cls):
            return cls.attr1 + 1

    class Bar(Foo):
        attr1 = 6

    assert Foo.attr2 == 6
    assert Bar.attr2 == 7

# Generated at 2022-06-12 08:09:49.281924
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            self.a = 1

        @lazyclassproperty
        def atest(cls):
            return cls.a

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.a = 2

    assert A.atest == 1
    assert B.atest == 1

    a = A()
    assert a.atest == 1
    b = B()
    assert b.atest == 1

    A.a = 10

    assert a.atest == 1
    assert b.atest == 1
    assert A.atest == 10
    assert B.atest == 10



# Generated at 2022-06-12 08:09:55.270909
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            print('Calculating foo')
            return 42

        @lazyclassproperty
        def bar(cls):
            print('Calculating bar')
            return 13

    class Test2(Test):
        pass

    assert Test.foo == 42
    assert Test.foo == 42, "Cached version is returned"
    assert Test.bar == 13
    assert Test2.foo == 42
    assert Test2.bar == 13



# Generated at 2022-06-12 08:09:59.729784
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class(object):
        @lazyclassproperty
        def value(cls):
            print('Calculated value')
            return 42

    # Make sure that the value is calculated only once
    assert Class.value == 42
    assert Class.value == 42



# Generated at 2022-06-12 08:10:02.131487
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):

        @lazyclassproperty
        def x(cls):
            return 'x'

    assert Test.x == 'x'



# Generated at 2022-06-12 08:10:08.283242
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class class_one(object):
        @lazyperclassproperty
        def f(cls):
            return 'class_one'

    class class_two(class_one):
        pass

    class class_three(class_two):
        @lazyperclassproperty
        def f(cls):
            return 'class_three'

    class class_four(class_one):
        @lazyperclassproperty
        def f(cls):
            return 'class_four'

    assert class_one.f == 'class_one'
    assert class_two.f == 'class_one'
    assert class_three.f == 'class_three'
    assert class_four.f == 'class_four'



# Generated at 2022-06-12 08:10:13.270005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import random
    import time

    class MyClass:
        @lazyclassproperty
        def random(cls):
            time.sleep(random.randint(0, 2))
            return random.randint(1, 10)


# Generated at 2022-06-12 08:10:17.785451
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def a(cls):
            return 1

    assert TestClass.a is 1
    assert not hasattr(TestClass, '_lazy_a')


# Wrapper for 'lazyclassproperty' that allows the wrapped value to be set
# and retrieved like a normal property.
#

# Generated at 2022-06-12 08:10:22.236101
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        a = 1
        @lazyperclassproperty
        def add1(self):
            return self.a+1

    class B(A):
        a = 2

    assert A().add1 == 2
    assert B().add1 == 3



# Generated at 2022-06-12 08:10:34.930893
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        _test_property = None

        @staticmethod
        def get_test_property():
            return TestClass._test_property

        @staticmethod
        def set_test_property(value):
            TestClass._test_property = value

        @lazyclassproperty
        def test_property(cls):
            return cls.get_test_property()

    # Test property
    assert TestClass.test_property is None
    TestClass.set_test_property(1)
    assert TestClass.test_property == 1
    TestClass.set_test_property(2)
    assert TestClass.test_property == 2

    # Test lazy property
    class SubTestClass(TestClass):
        pass

    assert SubTestClass.test_property == 2
    SubTestClass.set_test_property

# Generated at 2022-06-12 08:10:39.023599
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            # if this is bound to Base, return 1
            if cls.__name__ == 'Base':
                return 1
            # else, return 2
            else:
                return 2

    class Child(Base):
        pass

    # test Base class
    assert Base.test == 1
    # test Child class
    assert Child.test == 2


# Generated at 2022-06-12 08:10:44.929809
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def MyProperty(cls):
            print('Assigning property to', cls)
            return 42

    assert MyClass.MyProperty == 42
    assert MyClass.MyProperty == 42

    class MySubClass(MyClass):
        pass
    
    assert MySubClass.MyProperty == 42
    assert MySubClass.MyProperty == 42
    assert MyClass.MyProperty == 42



# Generated at 2022-06-12 08:10:54.357650
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("Evaluating prop with cls = ", cls.__name__)
            return "foo"

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def prop(cls):
            return "bar"

    assert A.prop == "foo" # Evaluates
    assert B.prop == "foo" # Does not evaluate again
    assert C.prop == "bar" # Does not evaluate prop from A, but if caching is not done, A.prop will be evaluated
    assert B.prop == "foo" # Still returns "foo" because cached in class B



# Generated at 2022-06-12 08:10:57.876786
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_value(cls):
            print("Initializing value...")
            return 42

    assert TestClass.test_value == 42
    assert TestClass.test_value == 42

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:11:03.200866
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def name(cls):
            print("Computing name")
            return "A"

    class B(A):
        pass

    assert A.name == "A"
    assert A.name == "A"
    assert B.name == "A"



# Generated at 2022-06-12 08:11:07.295125
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print("Called")
            return 42

    class B(A):
        pass

    assert A.prop == 42
    assert A.prop == 42
    assert B.prop == 42
    assert B.prop == 42



# Generated at 2022-06-12 08:11:12.893577
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test for lazyperclassproperty function.
    """
    class BaseClass(object):

        @lazyperclassproperty
        def attribute(cls):
            return cls.__name__

    class FirstClass(BaseClass):
        pass

    class SecondClass(FirstClass):
        pass

    assert BaseClass.attribute == 'BaseClass'
    assert FirstClass.attribute == 'FirstClass'
    assert SecondClass.attribute == 'SecondClass'



# Generated at 2022-06-12 08:11:18.163249
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def get_docstring():
        return 'Docstring for this function'

    @lazyclassproperty
    def ds():
        return get_docstring()

    class A(object):
        ds = ds

    print(A.ds)
    print(A.ds)



# Generated at 2022-06-12 08:11:22.350783
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            print('Calculating')
            return 42

    class B(A):
        pass

    assert A.x == 42
    assert B.x == 42
    assert A.x == 42
    assert B.x == 42



# Generated at 2022-06-12 08:11:31.210829
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:37.861550
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from functools import partial
    from contextlib import ContextDecorator
    from unittest.mock import patch

    class A(object):
        @lazyperclassproperty
        def f(cls):
            return 'foo'


    class B(A):
        pass


    assert A.f == 'foo'
    assert A.f == 'foo'
    assert B.f == 'foo'
    assert B.f == 'foo'



# Generated at 2022-06-12 08:11:43.344765
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestCls(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class TestCls2(TestCls):
        pass

    assert TestCls.prop == 'TestCls'
    assert TestCls2.prop == 'TestCls2'
    assert TestCls.prop == 'TestCls'


# Generated at 2022-06-12 08:11:46.846509
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:52.179318
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Test(object):
        @lazyperclassproperty
        def test_prop(cls):
            print("In lazily loaded Test.test_prop")
            return Test()

    class SubTest(Test):
        pass

    print(SubTest.test_prop)
    print(Test.test_prop)
    print(SubTest.test_prop)
    print(Test.test_prop)



# Generated at 2022-06-12 08:11:54.859698
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:59.596451
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):

        def get_foo(self):
            return 'Base.foo'

    class Derived(Base):

        @lazyperclassproperty
        def foo(cls):
            return cls.get_foo()

    assert Base.foo == 'Base.foo'
    assert Derived.foo == 'Base.foo'

    def get_foo(self):
        return 'Derived.foo'

    Derived.get_foo = get_foo
    assert Base.foo == 'Base.foo'
    assert Derived.foo == 'Derived.foo'



# Generated at 2022-06-12 08:12:06.153639
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:10.556059
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop(cls):
            print("meth")
            return "prop"

    assert Test.prop == "prop"
    assert Test.prop == "prop"



# Generated at 2022-06-12 08:12:14.100711
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:12:25.589186
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        def foo(cls):
            print("foo")
            return 1
        foo = lazyclassproperty(foo)
    class B(A):
        pass

    assert A.foo is B.foo is 1, "lazyclassproperty doesn't work"



# Generated at 2022-06-12 08:12:30.253055
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def get_value(cls):
            return 1

    class Test2(Test):
        @lazyperclassproperty
        def get_value(cls):
            return 2

    assert Test.get_value == 1
    assert Test2.get_value == 2



# Generated at 2022-06-12 08:12:34.616761
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class foo(object):
        @lazyperclassproperty
        def value(self):
            return 1

    class bar(foo):
        pass

    instance = bar()
    assert instance.value == 1
    bar.value = 2
    assert instance.value == 2
    assert foo().value == 1



# Generated at 2022-06-12 08:12:41.658706
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'
    assert Foo.bar == 'bar'
    assert Foo.__dict__['_lazy_bar'] == 'bar'
    del Foo.__dict__['_lazy_bar']

    class Baz(Foo):
        pass
    assert Baz.bar == 'bar'
    assert Baz.__dict__['_lazy_bar'] == 'bar'
    # Foo's _lazy_bar should still be missing, though
    assert Foo.__dict__.get('_lazy_bar') is None


# Generated at 2022-06-12 08:12:46.919526
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Test: create class and set property
    class Class:
        @lazyclassproperty
        def prop(cls):
            return 'prop'
    assert Class.prop == 'prop'

    # Test: access property from instance
    class_instance = Class()
    assert class_instance.prop == 'prop'



# Generated at 2022-06-12 08:12:49.985565
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def f(cls):
            print('f evaluated')
            return 42

    assert A.f == 42
    assert A.f == 42



# Generated at 2022-06-12 08:12:54.423816
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 'A'

    class B(A):
        @lazyclassproperty
        def test(cls):
            return 'B'

    class C(A):
        pass

    assert A.test == 'A'
    assert B.test == 'B'
    assert C.test == 'A'



# Generated at 2022-06-12 08:13:00.267751
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @staticmethod
        def fn(cls):
            print("A called")
            return 1
        f = lazyperclassproperty(fn)

    class B(A):
        @staticmethod
        def fn(cls):
            print("B called")
            return 2
        f = lazyperclassproperty(fn)

    a = A()
    b = B()
    print(a.f)
    print(b.f)

# Generated at 2022-06-12 08:13:10.103818
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:13:13.400248
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def add(cls):
            return lambda x, y: x + y

    # Test if the property is set
    assert not A.__dict__.has_key('_lazy_add')

# Generated at 2022-06-12 08:13:40.013210
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f():
        print("run function f")
        return 3

    class A(object):
        f1 = lazyclassproperty(f)

    print("get f1.f1")
    assert A.f1 == 3
    print("get f1.f1 again")
    assert A.f1 == 3
    print("get f1.f1 again")
    assert A.f1 == 3

    class B(A):
        pass

    print("get f1.f1")
    assert B.f1 == 3
    print("get f1.f1 again")
    assert B.f1 == 3
    print("get f1.f1 again")
    assert B.f1 == 3



# Generated at 2022-06-12 08:13:44.797223
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def func(self):
            print ('testing')
            return 'success'

    t = Test()
    assert t.func == 'success'
    assert Test.func == 'success'
# End unit test for function lazyclassproperty



# Generated at 2022-06-12 08:13:55.297594
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyData(object):
        def __init__(self, value):
            self.value = value

    class MyClass(object):
        @lazyclassproperty
        def value(cls):
            return MyData(1)

    assert not hasattr(MyClass, '_lazy_value')
    assert isinstance(MyClass.value, MyData)
    assert MyClass.value.value == 1
    assert hasattr(MyClass, '_lazy_value'), "lazyclassproperty didn't memoize the result"
    MyClass._lazy_value = None
    assert isinstance(MyClass.value, MyData)
    assert MyClass.value.value == 1
    assert hasattr(MyClass, '_lazy_value'), "lazyclassproperty didn't memoize the result"


# Generated at 2022-06-12 08:14:00.595374
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

    class Foo1(Foo):
        pass

    class Foo2(Foo):
        pass

    assert Foo.bar == 'Foo'
    assert Foo1.bar == 'Foo1'
    assert Foo2.bar == 'Foo2'



# Generated at 2022-06-12 08:14:09.068775
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base():
        @lazyperclassproperty
        def test_property(self):
            return 'base'

    class Derived(Base):
        pass

    assert Base().test_property == 'base'
    assert Derived().test_property == 'base'
    assert Base.test_property == 'base'
    assert Derived.test_property == 'base'

    # Check that laziness is working, so we can be sure to avoid any cache problems
    # (which would fail the above test)
    Base._Derived_lazy_test_property = 'derived'
    assert Base().test_property == 'base'
    assert Derived().test_property == 'derived'
    assert Base.test_property == 'base'
    assert Derived.test_property == 'derived'

# Generated at 2022-06-12 08:14:12.307774
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def a(cls):
            return 'a'

    class B(A):
        pass

    assert A().a == B().a

    A.a = 'aa'
    assert A().a == 'aa'
    assert B().a == 'a'


# Generated at 2022-06-12 08:14:16.505763
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def f(cls):
            return "Base.f"

    class Derived(Base):
        pass

    assert Base.f == 'Base.f'
    assert Derived.f == 'Base.f'
    assert Base.f == 'Base.f'
    assert Derived.f == 'Base.f'



# Generated at 2022-06-12 08:14:21.873063
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def _foo(self):
            return "A"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return cls._foo()

    assert C.foo == "A"
    assert issubclass(C, A)
    assert issubclass(B, A)

    class D(B):
        pass

    assert D.foo == "A"  # Correct
    assert D.foo == "A"  # Cached
    assert issubclass(D, B)


# Generated at 2022-06-12 08:14:27.779803
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Decorator for lazy class instance variables.
    """
    # create base class
    class BaseClass(object):
        def __init__(self):
            pass

    # decorator to create lazy per class property

# Generated at 2022-06-12 08:14:31.535970
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:07.601114
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            cls._x = object()
            return cls._x

    assert A.x is A.x
    assert A.x is not A.x



# Generated at 2022-06-12 08:15:16.418435
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    #
    # Subclassing without data attribute
    #
    class A(object):
        @lazyperclassproperty
        def value(cls): return 5

    assert A.value == 5
    assert A.value == 5

    class B(A):
        pass

    assert B.value == 5
    assert B.value == 5

    #
    # Subclassing with data attribute
    #
    class A(object):
        @lazyperclassproperty
        def value(cls): return 5

    assert A.value == 5
    assert A.value == 5

    class B(A):
        @lazyperclassproperty
        def value(cls): return 6

    assert B.value == 6
    assert B.value == 6
    assert A.value == 5
    assert A.value == 5


# Generated at 2022-06-12 08:15:19.391810
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def x():
            return "Test Passed!"
    print(Foo.x)
    assert Foo.x == "Test Passed!"



# Generated at 2022-06-12 08:15:28.744828
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def fn(cls):
            return 'A'
        @lazyclassproperty
        def x(cls):
            return fn(cls)

    assert A.x == 'A'
    assert A._lazy_x == 'A'
    assert '_lazy_x' in A.__dict__

    # Test that it is cached
    A.x = 'B'
    assert A.x == 'A'
    assert A._lazy_x == 'A'

    # Test that it does not interfere with other classes
    class B(object):
        def fn(cls):
            return 'B'
        @lazyclassproperty
        def x(cls):
            return fn(cls)

    assert B.x == 'B'

# Generated at 2022-06-12 08:15:33.873735
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:38.660064
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:45.104163
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def a(self):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def a(self):
            return 2

    class D(C):
        pass

    a1 = A()
    b1 = B()
    c1 = C()
    d1 = D()

    assert a1.a == 1  # The value is calculated and stored
    assert id(a1.a) == id(a1.a)  # The value is stored with the same id
    assert b1.a == 1  # The value is calculated and stored
    assert b1.a == a1.a  # The value is stored and compared with the value of a1.a
    assert id(b1.a) != id

# Generated at 2022-06-12 08:15:52.428385
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):
        @lazyperclassproperty
        def prop1(cls):
            return cls.__name__ + '_1'

    class Class1(BaseClass):
        pass

    class Class2(BaseClass):
        pass

    assert Class1.prop1 == 'Class1_1'
    assert Class2.prop1 == 'Class2_1'
    assert BaseClass.prop1 == 'BaseClass_1'

    BaseClass.prop1 = 'BaseClass_2'
    assert Class1.prop1 == 'Class1_1'
    assert Class2.prop1 == 'Class2_1'
    assert BaseClass.prop1 == 'BaseClass_2'

    Class1.prop1 = 'Class1_2'
    assert Class1.prop1 == 'Class1_2'
    assert Class

# Generated at 2022-06-12 08:15:56.322459
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        _times = 0

        @lazyclassproperty
        def persistent_property(cls):
            cls._times += 1
            return 'value'

    assert TestClass.persistent_property == 'value'
    assert TestClass.persistent_property == 'value'
    assert TestClass.persistent_property == 'value'
    assert TestClass._times == 1

# Generated at 2022-06-12 08:16:02.617237
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class First:
        def __init__(self, name, value):
            self.name = name
            self.value = value

        @lazyperclassproperty
        def value(self):
            return self.foo + self.bar

        @value.setter
        def value(self, value):
            self.foo = value

    class Second(First):
        def __init__(self, name, value):
            self.name = name
            self.value = value

    a = First('a', 1)
    a.bar = 2
    assert a.value == 3

    b = First('b', 1)
    b.bar = 2
    assert b.value == 3

    c = Second('c', 1)
    c.bar = 2
    assert c.value == 3

    assert a.value == 3
    a

# Generated at 2022-06-12 08:17:22.780990
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def somelazyproperty(cls):
            return 2 + 2

        @lazyperclassproperty
        def someotherlazyproperty(cls):
            return 3 + 3

    class B(A):
        pass

    assert A.somelazyproperty == 4
    assert B.somelazyproperty == 4

    assert A.someotherlazyproperty == 6
    assert B.someotherlazyproperty == 6



# Generated at 2022-06-12 08:17:25.423637
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def b(cls):
            return 'x'

    class B(A):
        pass

    assert A.b == 'x', A.b
    assert B.b == 'x', B.b

# Generated at 2022-06-12 08:17:27.905842
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassProperty(object):
        @lazyclassproperty
        def test(cls):
            print("test called")
            return 0
    
    TestLazyClassProperty.test
    TestLazyClassProperty.test
    TestLazyClassProperty.test



# Generated at 2022-06-12 08:17:34.589722
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # The most generic form of classes
    class A(object):
        pass

    class B(A):
        pass

    class C(A):
        pass

    class D(C):
        pass

    class E(B, D):
        pass

    @lazyperclassproperty
    def test(cls):
        return 2

    assert test._lazyclassprop is 2

    for cls in [A, B, C, D, E]:
        # each class has its own attribute
        assert test._lazyclassprop is 2
        assert test._lazyclassprop is 2
        assert test._lazyclassprop is 2
        assert test._lazyclassprop is 2
        assert test._lazyclassprop is 2



# Generated at 2022-06-12 08:17:45.365882
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:17:48.928201
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def tag(cls):
            print("Inside tag")
            return "tag1"
        @lazyclassproperty
        def ttag(cls):
            print("Inside ttag")
            return "tag2"

    print(C.__dict__)
    print(C.tag)
    print(C.tag)
    print(C.__dict__)
    print(C.ttag)
    print(C.__dict__)



# Generated at 2022-06-12 08:17:58.678376
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    kv_store = dict()
    def get_value(cls):
        print("Getting value for %s" % cls.__name__)
        return kv_store.get(cls.__name__)

    def set_value(cls,value):
        kv_store[cls.__name__] = value
        print("Setting value for %s to %s" % (cls.__name__,value))

    class Cls(object):
        prop = lazyclassproperty(get_value)

    Cls.prop = set_value
    print("Cls.prop: %s" % Cls.prop) # calls the getter
    print("SubCls.prop: %s" % Cls.prop) # calls the getter

# Generated at 2022-06-12 08:18:03.219547
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("calling a()")
            return 1
    assert A.a == 1
    assert A.a == 1
    class B(A):
        pass
    assert B.a == 1
    assert B.a == 1

# Generated at 2022-06-12 08:18:05.045750
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1
    assert A.prop == 1

# Generated at 2022-06-12 08:18:09.634241
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def X(cls):
            return 'X'

        def __str__(self):
            return '<%s>' % (self.__class__.__name__,)

    class B(A):
        pass

    assert A.X == 'X'
    assert B.X == 'X'

