

# Generated at 2022-06-12 08:09:38.531639
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    class C(A):
        @classproperty
        def x(cls):
            return 'y'

    class D(C):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'
    assert D.x == 'y'



# Generated at 2022-06-12 08:09:46.005218
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @staticmethod
        def _fn(cls):
            return '%s_instance' % (cls.__name__,)

        @lazyperclassproperty
        def fn(cls):
            return '%s_instance' % (cls.__name__,)

    # note that even though they share the same code they have different data due to it being lazily evaluated
    x = A()
    y = A()

    assert x._fn is not y._fn
    assert x.fn is not y.fn
    assert x._fn == y._fn
    assert x.fn == y.fn



# Generated at 2022-06-12 08:09:55.540791
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def foo(cls):
            print("evaluate foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def bar(cls):
            print("evaluate bar")
            return 24

    a = A()
    b = B()
    c = C()
    assert A.foo == 42
    assert A.foo == 42
    assert B.foo == 42
    assert C.foo == 42
    assert a.foo == 42
    assert b.foo == 42
    assert c.foo == 42
    assert A.bar == 24
    assert B.bar == 24
    assert C.bar == 24
    assert a.bar == 24
    assert b.bar == 24
    assert c.bar == 24
    assert A

# Generated at 2022-06-12 08:10:05.351239
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object): 
        @lazyperclassproperty
        def lazyval(cls):
            return "This is a value from a class property"

    class SubClass(Base):
        pass

    # This should print "This is a value from a class property"
    print(Base.lazyval)
    # This should print "This is a value from a class property"
    print(SubClass.lazyval)

    class SubClass2(Base):
        @lazyperclassproperty
        def lazyval(cls):
            return "This is a value from a class property of a subclass"

    # This should print "This is a value from a class property"
    print(Base.lazyval)
    # This should print "This is a value from a class property of a subclass"

# Generated at 2022-06-12 08:10:16.225556
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def some_property(cls):
            return 5

    class A(Base):
        pass

    class B(Base):
        pass

    assert Base.some_property == 5
    assert A.some_property == 5
    assert B.some_property == 5
    assert Base.some_property == 5
    assert A.some_property == 5
    assert B.some_property == 5
    assert Base.some_property == 5

    A.some_property = 4
    assert Base.some_property == 5
    assert A.some_property == 4
    assert B.some_property == 5
    assert Base.some_property == 5
    assert A.some_property == 4
    assert B.some_property == 5
    assert Base.some_property == 5


# Generated at 2022-06-12 08:10:21.437049
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo: pass


# Generated at 2022-06-12 08:10:26.702428
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def p(cls):
            print('A')
            return 'A'

    class B(A):
        @lazyperclassproperty
        def p(cls):
            print('B')
            return 'B'

    assert A.p == 'A'
    assert B.p == 'B'


# Generated at 2022-06-12 08:10:36.384440
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            print("Initializing A.x")
            return 1

    class B(A):
        pass

    class C(A):
        pass

    print(A.x)
    print(A.x) # second call doesn't execute the function
    print(B.x)
    print(A.x) # A.x isn't affected by B.x
    print(C.x)
    print(B.x) # B.x isn't affected by C.x
    print(A.x) # A.x isn't affected by C.x
    print(C.x) # C.x isn't affected by A.x
    print(B.x) # B.x isn't affected by A.x



# Generated at 2022-06-12 08:10:43.523195
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class base(object):
        _a = 10


# Generated at 2022-06-12 08:10:50.928661
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def myprop(cls):
        print("init myprop")
        return "1"

    class TestClass(object):
        pass

    class TestClassSubclass(TestClass):
        pass

    # Test that the calculation is only done once
    assert TestClass.myprop == "1"
    assert TestClass.myprop == "1"

    # Test that subclassing doesn't break the calculation
    assert TestClassSubclass.myprop == "1"



# Generated at 2022-06-12 08:10:56.888376
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:05.385154
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

        @classproperty
        def nofoo(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert A.__dict__['_lazy_foo'] == 'foo'

    A.foo = 'foobar'
    assert A.foo == 'foobar'

    assert A.nofoo == 'bar'
    A.nofoo = 'barfoo'
    assert A.nofoo == 'barfoo'


# Generated at 2022-06-12 08:11:08.563096
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def get_number(cls):
            return 'number'

    assert A.get_number is A.get_number
    assert A.get_number == 'number'


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:11:14.170740
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyBaseClass(object):
        pass

    class MySubClass(MyBaseClass):
        pass

    @lazyperclassproperty
    def test_prop(cls):
        return cls.__name__

    assert MyBaseClass.test_prop == "MyBaseClass"
    assert MySubClass.test_prop == "MySubClass"

    MyBaseClass.__name__ = "ChangedBaseName"
    assert MyBaseClass.test_prop == "MyBaseClass"



# Generated at 2022-06-12 08:11:20.576695
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestA(object):
        @lazyperclassproperty
        def p(cls):
            return 'abc'
    class TestB(TestA):
        pass
    assert TestA.p == TestB.p
    TestA.p = 'qwer'
    assert TestA.p != TestB.p

if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:11:29.968539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def fn1(cls):
            return {'a': 1}

        @lazyclassproperty
        def fn2(cls):
            return ['x', 'y', 'z']

    assert A.fn1 == {'a': 1}
    assert A.fn2 == ['x', 'y', 'z']

    class B(A):
        pass

    B.fn1['b'] = 2
    B.fn2[2] = 'c'
    assert B.fn1 == {'a': 1, 'b': 2}
    assert A.fn1 == {'a': 1}

    assert B.fn2 == ['x', 'y', 'c']
    assert A.fn2 == ['x', 'y', 'z']


# Generated at 2022-06-12 08:11:34.320105
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def f():
        raise AssertionError()

    p = lazyclassproperty(f)
    for i in range(10):
        assert p == p
    try:
        f()
    except AssertionError:
        pass
    else:
        assert False, 'f() must have thrown an exception.'



# Generated at 2022-06-12 08:11:38.038487
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    a = A()
    b = B()
    assert a.foo == 'foo'
    assert b.foo == 'foo'
    assert A.foo == 'foo'
    assert B.foo == 'foo'
    # Assignments below should fail.
    try:
        a.foo = 'bar'
    except AttributeError:
        pass
    else:
        assert False
    try:
        b.foo = 'bar'
    except AttributeError:
        pass
    else:
        assert False
    try:
        A.foo = 'bar'
    except AttributeError:
        pass
    else:
        assert False

# Generated at 2022-06-12 08:11:44.970962
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def my_property(cls):
            print('setting my_property')
            return 'the result'

        def __init__(self):
            print('MyClass.__init__')

    print('Testing MyClass')
    c = MyClass()
    print('c.my_property =', c.my_property)
    print('Testing MyClass')
    c = MyClass()
    print('c.my_property =', c.my_property)



# Generated at 2022-06-12 08:11:49.466914
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def foo(self):
            return 'foo'

    class Sub(Base):
        pass

    assert Base().foo=='foo'
    assert Sub().foo=='foo'
    assert Base.foo=='foo'
    assert Sub.foo=='foo'


# Generated at 2022-06-12 08:11:57.208558
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:02.678742
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:07.213730
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def test1(cls):
            print('test1')
            return 1

    class B(A):
        pass

    assert (A.test1 == 1)
    assert (B.test1 == 1)
    A.test1 = 2
    assert (A.test1 == 2)
    assert (B.test1 == 1)

# Generated at 2022-06-12 08:12:11.900251
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    assert A.a is A.a
    assert A.a is not B.a
    assert B.a is B.a



# Generated at 2022-06-12 08:12:16.450898
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazy_property(cls):
            return "My lazy class property"

    class B(A):
        pass

    assert A.lazy_property == 'My lazy class property'
    assert B.lazy_property == 'My lazy class property'



# Generated at 2022-06-12 08:12:26.231930
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return "A.x"

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        @lazyperclassproperty
        def x(cls):
            return "D.x"

    assert A.x == "A.x"
    assert B.x == "A.x"
    assert C.x == "A.x"
    assert D.x == "D.x"
    assert A().x == "A.x"
    assert B().x == "A.x"
    assert C().x == "A.x"
    assert D().x == "D.x"



# Generated at 2022-06-12 08:12:34.183009
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def prop1(cls):
            return cls

    class Bar(Foo):
        pass

    assert hasattr(Foo, '_lazy_prop1')
    assert Foo.prop1 is Foo
    assert Foo._lazy_prop1 is Foo
    assert Bar.prop1 is Bar
    assert Bar._lazy_prop1 is Bar

    # Can still modify the original property
    Foo._lazy_prop1 = 'Foo'
    assert Foo.prop1 == 'Foo'



# Generated at 2022-06-12 08:12:39.427973
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class X(object):
        @lazyclassproperty
        def a(self):
            return 'x'

    class Y(X):
        @lazyclassproperty
        def a(self):
            return 'y'

    class Z(Y):
        pass

    assert X.a == 'x'
    assert X().a == 'x'

    assert Y.a == 'y'
    assert Y().a == 'y'

    assert Z.a == 'y'
    assert Z().a == 'y'

# Generated at 2022-06-12 08:12:50.784134
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def test_lazy(self):
            return self.x

    a = A(1)
    b = A(2)
    assert a.test_lazy == 1
    assert b.test_lazy == 2
    assert a.test_lazy == 1
    assert b.test_lazy == 2

    class B(A):
        def __init__(self, x, y):
            super(B, self).__init__(x)
            self.y = y

        @lazyperclassproperty
        def test_lazy(self):
            return self.y

    ar = A(3)
    br = B(4, 5)
    assert ar.test_l

# Generated at 2022-06-12 08:12:54.878011
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass_Parent(object):
        @lazyperclassproperty
        def foo(self):
            return {'a': 10}

    class TestClass_Child(TestClass_Parent):
        pass

    assert TestClass_Parent.foo == TestClass_Child.foo
    TestClass_Parent.foo['a'] = 20
    assert TestClass_Parent.foo != TestClass_Child.foo



# Generated at 2022-06-12 08:13:06.468889
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def b(cls):
            print('calling fn')
            return 1

    class B(A):
        pass

    assert A.b == A.b == 1
    assert B.b == B.b == 1


# Generated at 2022-06-12 08:13:11.180258
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        _foo = None
        @lazyperclassproperty
        def foo(cls):
            if cls._foo is None:
                cls._foo = 1
            else:
                cls._foo += 1
            return cls._foo

    class Bar(Foo):
        pass

    assert Foo.foo == 1
    assert Bar.foo == 1
    assert Foo.foo == 2



# Generated at 2022-06-12 08:13:16.436530
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(self):
            return "foo"
    assert A.foo == "foo"
    # Check that a class-level lazy property can be accessed by an instance
    assert A().foo == "foo"
    class B(A): pass
    assert B.foo == "foo"
    assert A.foo == B.foo
    assert A.foo == "foo"
    assert B.foo == "foo"



# Generated at 2022-06-12 08:13:27.189065
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ParentClass:
        @lazyperclassproperty
        def foo(cls):
            print('Initialization of foo')
            return 1

    class ChildClass(ParentClass):
        pass

    class OtherFromScratch:
        @lazyperclassproperty
        def foo(cls):
            print('Initialization of foo')
            return 2

    # Nothing is printed out at this point
    assert ParentClass.foo == 1
    assert ChildClass.foo == 1
    assert OtherFromScratch.foo == 2
    # But it will be printed out the next time
    ParentClass.foo = 3
    assert ParentClass.foo == 3
    # The parent class should not be affected
    assert ChildClass.foo == 1
    assert OtherFromScratch.foo == 2
    # We need to reset the parent property to get the cached value

# Generated at 2022-06-12 08:13:31.082040
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return [1, 2, 3]

    class B(A):
        pass

    a = A()
    b = B()

    assert id(b.prop) != id(a.prop)  # They are separate instances per class

    A.prop.append(4)
    assert b.prop == [1, 2, 3]

# Generated at 2022-06-12 08:13:41.577539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    # The class using this function as a class property
    class MyClass(object):
        @lazyclassproperty
        def myproperty(cls):
            return 3

    # Demonstration of lazyness
    print("Demonstration of lazyness:")
    print("obj.myproperty is uninitialized... %s %s" % (not hasattr(MyClass, '_lazy_myproperty'), not hasattr(MyClass, '_lazy_myproperty')))
    print("obj.myproperty is %s" % MyClass.myproperty)
    print("obj.myproperty is %s" % MyClass.myproperty)
    print("obj.myproperty is %s" % MyClass.myproperty)

# Generated at 2022-06-12 08:13:47.509329
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_foo(self):
            return self

    assert TestClass.test_foo is TestClass

    try:
        TestClass.test_foo = "bar"
        assert False, "lazyclassproperty is writeable, it should be read only!!!"
    except AttributeError:
        pass



# Generated at 2022-06-12 08:13:50.720269
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class B(A):
        pass

    assert A.prop == 'value'
    assert B.prop == 'value'



# Generated at 2022-06-12 08:13:53.895192
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def foo(cls):
            return 5
    assert TestClass.foo == 5
    assert TestClass.foo == 5  # second invocation should return cached value


# Generated at 2022-06-12 08:13:57.865030
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):

        @lazyclassproperty
        def prop(cls):
            return cls.__name__

    assert Test.prop == 'Test'
    assert Test.prop == 'Test' # Ensure the value is cached

    class Test2(Test):
        pass

    assert Test.prop == 'Test'
    assert Test2.prop == 'Test2'



# Generated at 2022-06-12 08:14:20.511052
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class Child(Parent):
        @lazyperclassproperty
        def prop(cls):
            # Override the inherited property
            return 2

    class ChildChild(Child):
        pass

    assert Parent.prop == 1
    assert Child.prop == 2
    assert ChildChild.prop == 2


# Generated at 2022-06-12 08:14:22.882765
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:29.524999
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(self):
            return 'x'
    a = A()
    # Check that property is lazy:
    assert a.__dict__ == {}
    assert a.x == 'x'
    # Check that property is cached:
    assert a.__dict__ == {'_A_lazy_x': 'x'}
    assert a.x == 'x'
    # Check that property is per-class
    class B(A):
        pass
    b = B()
    assert b.x == 'x'
    assert B.x == 'x'
    assert b.x == 'x'
    assert A.x == 'x'
    assert a.__dict__ == {'_A_lazy_x': 'x'}
    assert b.__

# Generated at 2022-06-12 08:14:31.282990
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class T(object):
        @lazyclassproperty
        def lazyprop(cls):
            return 1
    T.lazyprop
    assert T.lazyprop == 1



# Generated at 2022-06-12 08:14:37.536175
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class B:
        @lazyperclassproperty
        def foo(cls):
            return 'foo for %s' % cls.__name__
    class C(B):
        pass
    class D(C):
        pass
    class E(C, D):
        pass

    print(B.foo)
    print(C.foo)
    print(D.foo)
    print(E.foo)
    print(E.__mro__)



# Generated at 2022-06-12 08:14:40.271296
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class One():
        @lazyperclassproperty
        def x(cls):
            return cls.__name__

    class Two(One):
        pass

    assert One.x == 'One'
    assert Two.x == 'Two'
    assert Two().x == 'Two'
    assert One().x == 'One'



# Generated at 2022-06-12 08:14:44.788199
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        @lazyclassproperty
        def x(cls):
            print('x calculation')
            return 3

        @staticmethod
        def get_x():
            return A.x
    class B(A):
        pass

    for i in range(3):
        print(A.get_x())
        print(B.get_x())



# Generated at 2022-06-12 08:14:50.516553
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("lazyclassproperty A.A")
            return "ret"

    class B(A):
        @lazyclassproperty
        def a(cls):
            print("lazyclassproperty B.A")
            return "ret"

    class C(B):
        @lazyclassproperty
        def a(cls):
            print("lazyclassproperty C.A")
            return "ret"

    print(A.a)
    print(B.a)
    print(C.a)



# Generated at 2022-06-12 08:14:53.440697
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def prop(self):
            return 'Foo'

    class Bar(Foo):
        pass

    assert Foo.prop == 'Foo'
    assert Bar.prop == 'Foo'



# Generated at 2022-06-12 08:15:02.982560
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    print('---- lazyperclassproperty() unit test start: ----')

    class Base(object):
        @classmethod
        def a(cls):
            return 'BASE.a()'

        @lazyperclassproperty
        def b(cls):
            print('>>> Base.b() called')
            return 'BASE.b()'

    class D1(Base):
        @classmethod
        def a(cls):
            return 'D1.a()'

        @lazyperclassproperty
        def b(cls):
            print('>>> D1.b() called')
            return 'D1.b()'

    class D2(Base):
        @classmethod
        def a(cls):
            return 'D2.a()'


# Generated at 2022-06-12 08:15:43.554711
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        _x = 2

        @lazyclassproperty
        def x(cls):
            return cls._x
    assert A.x == 2
    A._x = 3
    assert A.x == 3



# Generated at 2022-06-12 08:15:45.255383
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 42

    assert A.x == 42
    assert A.x == 42



# Generated at 2022-06-12 08:15:52.589315
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def one(cls):
            print('A.one')
            return 'one'

    class B(A):
        @lazyperclassproperty
        def two(cls):
            print('B.two')
            return 'two'

    class C(A):
        @lazyperclassproperty
        def three(cls):
            print('C.three')
            return 'three'

    a = A()
    b = B()
    c = C()
    assert a.one == 'one'
    assert b.one == 'one'
    assert c.one == 'one'
    assert b.two == 'two'
    assert c.two == 'two'
    assert c.three == 'three'

    a.one = '1'

# Generated at 2022-06-12 08:15:54.967769
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return 2

    assert B.a == 2


# Generated at 2022-06-12 08:15:59.584492
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    @lazyclassproperty
    def test(cls):
        return 'hello'

    class Cls(object):
        test = test
        def __init__(self):
            pass

    # first access call the @lazyclassproperty
    assert Cls.test == 'hello'
    # second access don't do anything
    assert Cls.test == 'hello'

    # same thing with a instance
    cls = Cls()
    assert cls.test == 'hello'
    assert cls.test == 'hello'



# Generated at 2022-06-12 08:16:04.315542
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class F():
        def prop(self):
            return 42

    class G(F):
        prop = lazyperclassproperty(F.prop)

    class H(G):
        pass

    f = F()
    g = G()
    h = H()
    fn = F.prop
    gn = G.prop
    hn = H.prop
    assert f.prop() == 42
    assert g.prop() == 42
    assert h.prop() == 42
    assert fn(f) == 42
    assert fn(g) == 42
    assert fn(h) == 42
    assert gn(g) == 42
    assert gn(h) == 42
    assert hn(h) == 42



# Generated at 2022-06-12 08:16:08.125132
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.foo == "A"
    assert B.foo == "B"
    A.foo = "foo"
    assert A.foo == "foo"
    assert B.foo == "B"



# Generated at 2022-06-12 08:16:12.178005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            return 'foo'

    assert A.a == 'foo'
    class B(A):
        pass

    assert A.a == 'foo'
    assert B.a == 'foo'
    del A.a
    assert A.a != B.a


# Generated at 2022-06-12 08:16:17.164313
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def d(cls):
            return 1

        @lazyperclassproperty
        def c(cls):
            return 2

    class B(A):
        pass

    assert A.d == 1
    assert B.d == 1

    assert A.c == 2
    assert B.c == 2

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:16:21.631480
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('inited')
            return 'a'

    class B(A):
        pass

    print(A.prop)
    print(B.prop)


# Generated at 2022-06-12 08:17:48.678133
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:17:54.910595
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Foo(object):

        @lazyperclassproperty
        def prop(cls):
            return 1

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    f = Foo()
    b = Bar()
    z = Baz()

    assert f.prop == 1
    assert b.prop == 1
    assert z.prop == 1
    f.prop = 2
    assert f.prop == 1
    assert b.prop == 1
    assert z.prop == 1



# Generated at 2022-06-12 08:18:02.610959
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def tprop(cls):
            return [1,2]
    
    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def tprop(cls):
            return [2, 3]

    b = B()
    c = C()

    assert b.tprop == [1,2]
    assert c.tprop == [2,3]
    assert b.tprop == [1,2]
    assert c.tprop == [2,3]



# Generated at 2022-06-12 08:18:06.501768
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazyprop(cls):
            return True

    class B(A):
        pass

    assert A.lazyprop is True
    assert B.lazyprop is True

    A.lazyprop = False
    assert A.lazyprop is False
    assert B.lazyprop is True



# Generated at 2022-06-12 08:18:15.026691
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest

    class TestClass(object):
        @lazyperclassproperty
        def test_property(self):
            return "base class"

    class TestSubClass(TestClass):
        pass

    class TestSubSubClass(TestSubClass):
        pass

    class TestSubClassNoInherit(object):
        @lazyperclassproperty
        def test_property(self):
            return "no inheritance class"

    class TestSubClassInherit(TestClass):
        @lazyperclassproperty
        def test_property(self):
            return "overridden class"

        @classproperty
        def test_property_2(self):
            return "overridden class 2"


# Generated at 2022-06-12 08:18:20.459256
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test_fn(cls):
            print("calculate")
            return 10

    print(A.test_fn)
    print(A.test_fn)
    print("=======")
    class B(A):
        pass

    print(B.test_fn)
    print(B.test_fn)


test_lazyclassproperty()



# Generated at 2022-06-12 08:18:25.592341
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def lazyperclass(cls):
            return "A"

    class B(A):
        pass

    class C:
        @lazyperclassproperty
        def lazyperclass(cls):
            return "C"

    assert A.lazyperclass == "A"
    assert B.lazyperclass == "A"
    assert C.lazyperclass == "C"



# Generated at 2022-06-12 08:18:32.021588
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def _perclass_cached_property(cls):
            return "Base"

    class A(Base):
        pass

    class B(Base):
        pass

    class C(Base):
        @lazyperclassproperty
        def _perclass_cached_property(cls):
            return "C"

    assert Base._perclass_cached_property == "Base"
    assert A._perclass_cached_property == "Base"
    assert B._perclass_cached_property == "Base"
    assert C._perclass_cached_property == "C"



# Generated at 2022-06-12 08:18:36.529127
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Temp(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__

    class Temp1(Temp):
        pass

    class Temp2(Temp):
        pass

    assert Temp1.name == "Temp1"
    assert Temp2.name == "Temp2"
    # There could be some memory leak with this class
    assert hasattr(Temp, "_lazy_name") is False


# Generated at 2022-06-12 08:18:41.466532
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("foo of class A")
            return 'foo of A'

    class B(A):
        @lazyclassproperty
        def foo(cls):
            print("foo of class B")
            return 'foo of B'

    A.foo
    # A.foo ->  foo of class A
    # print A.foo
    # >> foo of A
    B.foo
    # B.foo ->  foo of class B
    # print B.foo
    # >> foo of B

