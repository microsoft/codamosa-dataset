

# Generated at 2022-06-12 08:09:40.787436
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:09:47.738245
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, name):
            self._name = name


# Generated at 2022-06-12 08:09:56.360431
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            pass
        @lazyclassproperty
        def prop(self):
            # This is a function that gets executed only once
            print("Expensive function call")
            return 1

    # Class property is evaluated only once
    a = A()
    print(a.prop)
    print(a.prop)
    print(a.prop)
    print(a.prop)
    print("===================")

    # Class property is evaluated in each inheritor
    class B(A):
        def __init__(self):
            pass
    b = B()
    print(b.prop)
    print(b.prop)
    print(b.prop)
    print(b.prop)


# Generated at 2022-06-12 08:10:02.041567
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass:
        num_calls = 0
        def mymethod(cls):
            cls.num_calls += 1
            return sum(range(100))

        myprop = lazyclassproperty(mymethod)

    assert MyClass.myprop == 4950
    assert MyClass.myprop == 4950
    assert MyClass.num_calls == 1



# Generated at 2022-06-12 08:10:07.525022
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo1(cls):
            return 1

        @lazyperclassproperty
        def foo2(cls):
            return 2

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo1(cls):
            return 3

    assert A.foo1 == 1
    assert B.foo1 == 1
    assert C.foo1 == 3

    assert A.foo2 == 2
    assert B.foo2 == 2
    assert C.foo2 == 2



# Generated at 2022-06-12 08:10:14.575316
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(metaclass=ABCMeta):

        @lazyperclassproperty
        def value(cls):
            return cls.__name__

        @classmethod
        def base_foo(cls):
            return cls.value

    class A(Base):
        pass

    class B(Base):
        pass

    a = A()
    b = B()

    assert b.base_foo() is A.value
    assert b.base_foo() is B.value

# Generated at 2022-06-12 08:10:23.674521
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:34.634844
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty.

    :return:
    """

    class MyBaseClass(object):
        @lazyperclassproperty
        def my_property(self):
            return "my_property value for MyBaseClass"

    class MyClass1(MyBaseClass):
        pass

    class MyClass2(MyBaseClass):
        pass

    obj1 = MyClass1()
    obj2 = MyClass2()

    assert obj1.my_property is obj1.my_property
    assert obj2.my_property is obj2.my_property
    assert obj1.my_property != obj2.my_property

    obj1.my_property = "changed value"
    assert obj1.my_property == "changed value"
    assert obj2.my_property is obj2.my_property

   

# Generated at 2022-06-12 08:10:40.677428
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:10:45.670701
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit tests for lazyclassproperty()
    """
    class TestCls(object):
        @lazyclassproperty
        def value(cls):
            return 1

    assert TestCls.value == 1
    assert TestCls.__value__ == 1

    TestCls.__value__ = 10

    assert TestCls.value == 10
    assert TestCls.__value__ == 10



# Generated at 2022-06-12 08:10:52.715751
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print("Calculating a")
            return 42
    class B(A):
        pass

    print(A.a)
    print(A.a)
    print(B.a)
    print(B.a)


# Generated at 2022-06-12 08:10:58.473917
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:08.722007
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:12.584106
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 2 * cls.__name__

    class B(A):
        pass

    class C(A):
        pass


# Generated at 2022-06-12 08:11:17.830798
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        @classmethod
        def b(cls):
            return 'abc'

    class B(object):
        pass

    assert B.b == 'abc'
    assert A.b == 'abc'
    assert A().b == 'abc'



# Generated at 2022-06-12 08:11:22.394456
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print ("Calculating value")
            return 42
    class B(A):
        pass

    print (A.foo)
    print (B.foo)

    assert A.foo == 42
    assert B.foo == 42
    print ("ok")



# Generated at 2022-06-12 08:11:28.003388
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:11:31.955397
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:11:35.813329
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 'test'

    class B(A):
        pass

    assert A.test == 'test'
    assert B.test == 'test'



# Generated at 2022-06-12 08:11:40.222539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def this(cls):
            return 'value'

    assert C.this == 'value'
    with pytest.raises(AttributeError):  # since we can't ensure static class attributes are deleted
        delattr(C, '_lazy_this')



# Generated at 2022-06-12 08:11:50.351410
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def myprop(cls):
            return "class_" + str(cls.__name__)


# Generated at 2022-06-12 08:11:55.764757
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base:
        @lazyperclassproperty
        def val(cls):
            print("Lazyval called")
            return ["Hello, world!"]

    class A(Base):
        pass

    class B(Base):
        pass

    print(A.val)
    print(A.val)
    print(B.val)
    print(B.val)
    print(Base.val)
    print(Base.val)


# Generated at 2022-06-12 08:12:02.593372
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        _test = 0

    class B(A):
        @lazyperclassproperty
        def test(cls):
            cls._test += 1
            return cls._test

    class C(B):
        pass

    assert A.test == 1
    assert B.test == 2
    assert C.test == 3

    assert A._test == 1
    assert B._test == 2
    assert C._test == 3



# Generated at 2022-06-12 08:12:07.180878
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):

        @lazyperclassproperty
        def a(cls):
            return "a"

    class B(A):

        @lazyperclassproperty
        def a(cls):
            return "b"

    a = A()

    assert a.a == "a"

    b = B()

    assert b.a == "b"


# Generated at 2022-06-12 08:12:12.920420
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def f(cls):
        return cls.__name__

    class A:
        foo = lazyperclassproperty(f)

    class B(A):
        pass

    class C(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'
    assert C.foo == 'C'



# Generated at 2022-06-12 08:12:15.485920
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def added(cls):
            return 2 + 2

    assert MyClass.added == 4


# Generated at 2022-06-12 08:12:19.916370
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        d = {}

        @lazyperclassproperty
        def x(cls):
            print('Initializing A.x')
            return cls.d[cls]

        @classmethod
        def init(cls):
            cls.d[cls] = {'x': 'A'}
        @classmethod
        def new(cls):
            print('Creating new class of A')
            class A(object):
                pass
            return A
    class B(A):
        @classmethod
        def init(cls):
            cls.d[cls] = {'x': 'B'}
    class C(A):
        pass

# Generated at 2022-06-12 08:12:27.991069
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X(object):
        @lazyperclassproperty
        def foo(cls):
            print('foo')
            return 'FOO'

    assert X.foo == 'FOO'
    assert X().foo == 'FOO'
    assert 'FOO' == X().foo
    assert 'FOO' == X().foo

    class Y(X):
        pass

    assert Y.foo == 'FOO'
    assert Y().foo == 'FOO'
    assert 'FOO' == Y().foo
    assert 'FOO' == Y().foo

    # Make sure there's no collision
    class X(object):
        @lazyperclassproperty
        def bar(cls):
            print('bar')
            return 'BAR'

    assert X.foo == 'FOO'

# Generated at 2022-06-12 08:12:34.138829
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            """docstring"""

# Generated at 2022-06-12 08:12:37.791062
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return list(cls.__name__)
    class B(A): pass
    class C(A): pass
    assert A.prop == B.prop == C.prop == ['A']
    assert B.prop is not C.prop  # Storages are separate per class



# Generated at 2022-06-12 08:12:50.834649
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def property(cls):
            return "property"

    class B(A):
        pass

    assert A.property == B.property
    assert A.property == "property"
    A.property = "new property"
    assert A.property == "new property"
    assert B.property == "property"

# Generated at 2022-06-12 08:12:57.665084
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from unittest import TestCase
    from . import test_pickle

    class Test(TestCase):
        counter = 0

        @lazyperclassproperty
        def ClassProp(cls):
            cls.counter = cls.counter + 1
            return cls.counter

        @lazyclassproperty
        def CounterProp(cls):
            cls.counter = cls.counter + 1
            return cls.counter

        class Inner(object):
            @lazyperclassproperty
            def ClassProp(cls):
                cls.counter = cls.counter + 1
                return cls.counter

        def test_class_prop(self):
            self.assertEqual(1, self.ClassProp)
            self.assertEqual(1, self.ClassProp)


# Generated at 2022-06-12 08:13:01.829385
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class g:
        @lazyclassproperty
        def bar(cls):
            print("bar()")
            return 'baz'
    assert g.bar == "baz"
    g.bar = "foo"
    assert g.bar == "foo"



# Generated at 2022-06-12 08:13:09.373189
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class SuperParent(object):
        @lazyperclassproperty
        def foo(cls):
            return 'SuperParent:' + cls.__name__

    class Parent(SuperParent):
        @lazyperclassproperty
        def foo(cls):
            return 'Parent:' + cls.__name__

    class Child(Parent):
        @lazyperclassproperty
        def foo(cls):
            return 'Child:' + cls.__name__

    assert SuperParent.foo == 'SuperParent:SuperParent'
    assert Parent.foo == 'Parent:Parent'
    assert Child.foo == 'Child:Child'



# Generated at 2022-06-12 08:13:12.185523
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):

        @lazyclassproperty
        def my_property(cls):
            return 'value'

    assert MyClass.my_property == 'value'
    assert MyClass.my_property == 'value'


# Generated at 2022-06-12 08:13:21.752405
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        first_attribute = "first"

        @lazyclassproperty
        def second_attribute(cls):
            return "second"

        @lazyclassproperty
        def third_attribute(cls):
            return "third"

    assert Foo.first_attribute == "first"
    assert Foo.second_attribute == "second"
    assert Foo.third_attribute == "third"

    class Bar(Foo):
        first_attribute = "another first"

        @lazyclassproperty
        def second_attribute(cls):
            return "another second"

    assert Bar.first_attribute == "another first"
    assert Bar.second_attribute == "another second"
    assert Bar.third_attribute == "third"
    assert Foo.second_attribute == "second"



# Generated at 2022-06-12 08:13:27.614089
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C1(object):
        @lazyclassproperty
        def prop(cls):
            return 'value'

    class C2(C1):
        pass

    assert C1.prop == 'value'
    assert C2.prop == 'value'
    assert C1.prop is C2.prop

# if __name__ == '__main__':
    # test_lazyclassproperty()



# Generated at 2022-06-12 08:13:37.910106
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            print("in test_lazyclassproperty.prop")
            return C.name

        @lazyclassproperty
        def prop2(cls):
            print("in test_lazyclassproperty.prop2")
            return 5

    class D(C):
        name = "D"

    print("Testing C")
    assert C.prop == "C"
    assert C.prop2 == 5

    print("Testing D")
    assert D.prop == "D"
    assert D.prop2 == 5
    assert C.prop == "C"
    assert C.prop2 == 5
test_lazyclassproperty()



# Generated at 2022-06-12 08:13:47.371130
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self, value):
            self._value = value

        @lazyperclassproperty
        def value(cls):
            return cls._value

    class Derived_1(Base):
        pass

    class Derived_2(Base):
        pass

    base = Base(0)
    print(base.value)
    # base.value = 1 # Not possible to set because value is class variable not instance variable.
    derived_1 = Derived_1(1)
    print(derived_1.value)
    derived_2 = Derived_2(2)
    print(derived_2.value)



# Generated at 2022-06-12 08:13:54.654814
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    x = []
    class A(object):
        @lazyclassproperty
        def prop(cls):
            x.append(cls.__name__)
            return cls.__name__
    class B(A):
        pass
    class C(B):
        pass
    assert x == ['A']
    assert A.prop == 'A'
    assert x == ['A']
    assert B.prop == 'A'
    assert x == ['A']
    assert C.prop == 'A'
    assert x == ['A']



# Generated at 2022-06-12 08:14:18.972031
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, name):
            self.name = name

        @lazyperclassproperty
        def test(cls):
            print("initializing...")
            return [1, 2, 3]

    class B(A):
        pass

    class C(A):
        pass

    a1 = A("a1")
    a2 = A("a2")
    b1 = B("b1")
    c1 = C("c1")

    assert a1.test == a2.test == b1.test
    assert a1.test is not c1.test


# Generated at 2022-06-12 08:14:24.872371
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test():
        some_data = 5
        @lazyperclassproperty
        def some_property(cls):
            return cls.some_data
    class Test2(Test):
        pass
    Test2.some_data = 3
    assert Test2.some_property == 3
    assert Test.some_property == 5
    Test.some_data = 4
    assert Test.some_property == 4
    # Test clearing the cache by deleting the property
    del Test2.some_property
    assert Test2.some_property == 3


# Generated at 2022-06-12 08:14:28.464493
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        @lazyclassproperty
        def x(cls):
            return super(B, cls).x + 1

    assert A.x  == 1
    assert B.x  == 2
    assert A.x  == 1
    assert B.x  == 2



# Generated at 2022-06-12 08:14:31.865561
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Act
    class C(object):
        @lazyclassproperty
        def foo(cls):
            return "foo"
    # Assert
    # for class property, you would use the class name
    assert C.foo == "foo"
    # for instance property, you would use the instance name
    assert C().foo == "foo"



# Generated at 2022-06-12 08:14:36.094945
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def bar():
            return 42
        bar = lazyclassproperty(bar)

    foo1 = Foo()
    assert foo1.bar == 42
    foo2 = Foo()
    assert foo2.bar == 42
    foo1.bar = 24
    assert foo1.bar == 24
    assert foo2.bar == 24



# Generated at 2022-06-12 08:14:44.824128
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'a'

        @lazyclassproperty
        def y(cls):
            return 'b'

    assert A.x == 'a'
    assert A.x == 'a'
    assert A.y == 'b'
    A.y = 'c'
    assert A.y == 'c'

    class B(A):
        @lazyclassproperty
        def x(cls):
            return 'd'

    assert B.x == 'd'
    assert A.x == 'a'
    assert B.y == 'b'
    assert B.y == 'b'
    B.y = 'e'
    assert B.y == 'e'



# Generated at 2022-06-12 08:14:49.337427
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return {}

    class FooChild(Foo):
        pass

    foo = Foo()
    fooc = FooChild()

    foo.bar['a'] = 1
    assert Foo.bar['a'] == 1
    assert FooChild.bar['a'] == 1
    assert foo.bar is not fooc.bar
    assert Foo.bar is not FooChild.bar



# Generated at 2022-06-12 08:14:54.087135
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 42

    assert A.x == 42
    assert A.x == 42

    class B(A):
        @lazyclassproperty
        def x(cls):
            return 43

    assert B.x == 43
    assert B.x == 43

    class C(A):
        pass

    assert C.x == 42
    assert C.x == 42



# Generated at 2022-06-12 08:14:58.788149
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return True

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def test(cls):
            return False

    assert A.test is True
    assert B.test is True
    assert C.test is False



# Generated at 2022-06-12 08:15:07.146549
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:54.093964
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def test_method(cls): return 'A'
        t = lazyperclassproperty(test_method)
    assert A.t == 'A'

    class B(A):
        def test_method(cls): return 'B'
    assert B.t == 'B'

    class C(B):
        pass
    assert C.t == 'B'

    class D(B):
        def test_method(cls): return 'D'
    assert D.t == 'D'


# Generated at 2022-06-12 08:15:57.923923
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:01.002935
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "bar"

    class B(A):
        pass

    assert A.foo == "bar"
    assert B.foo == "bar"
    A.foo = "baz"
    assert B.foo == "bar"



# Generated at 2022-06-12 08:16:07.271286
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def test(cls):   # No need to take self here
            print("Calculating...")
            return 42

    class Baz(Foo):
        pass

    class Bar(Foo):
        pass

    a = Foo()
    b = Baz()
    c = Bar()


# Generated at 2022-06-12 08:16:11.557693
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:17.228686
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(self):
            return 'A'

        @lazyclassproperty
        def b(self):
            return 'B'

    @lazyclassproperty
    def a(self):
        return 'C'

    class B(A):
        pass

    assert A.a == 'A'
    assert B.a == 'A'

    assert A.b == 'B'
    assert B.b == 'B'



# Generated at 2022-06-12 08:16:27.241523
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """Unit test for the decorator lazyclassproperty."""
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            "A lazy class property."
            return 1
    assert Foo.bar == 1
    assert Foo.__dict__['_lazy_bar'] == 1
    assert Foo.bar == 1
    class FooSub(Foo):
        pass
    assert FooSub.bar == 1  # the value is taken from the parent class
    assert '_lazy_bar' not in FooSub.__dict__
    assert FooSub.bar == 1
    assert '_lazy_bar' not in FooSub.__dict__
    class FooSubSub(FooSub):
        @lazyclassproperty
        def bar(cls):
            "A lazy class property."
            return 2
    assert FooSub

# Generated at 2022-06-12 08:16:32.583958
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:16:35.482110
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def f(cls):
            return 3

    assert A.f == 3


# Generated at 2022-06-12 08:16:43.112155
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestClass(object):
        @lazyclassproperty
        def test_property(cls):
            return 'test'

    assert TestClass.test_property == 'test'
    # check that the property is cached
    TestClass.test_property = 'test2'
    assert TestClass.test_property == 'test2'

    class TestSubClass(TestClass):
        pass

    assert TestSubClass.test_property == 'test'
    # check that the property is cached
    TestSubClass.test_property = 'test3'
    assert TestSubClass.test_property == 'test3'

    # check that subclass does not affect superclass
    assert TestClass.test_property == 'test2'



# Generated at 2022-06-12 08:18:19.682603
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    @lazyperclassproperty
    def a(cls):
        return "a"

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    assert Foo.a == "a"
    assert Bar.a == "a"
    assert Foo.a == Bar.a
    assert Foo.a is not Bar.a


# Generated at 2022-06-12 08:18:22.012808
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'Hello World !'

    assert Foo.bar == 'Hello World !'



# Generated at 2022-06-12 08:18:29.848519
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty.
    """


# Generated at 2022-06-12 08:18:31.604983
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def xxx(cls):
            return 1
    assert A.xxx == 1



# Generated at 2022-06-12 08:18:39.496138
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(clazz):
            print("a of A called")
            return "a of A"
    class B(A):
        @lazyperclassproperty
        def a(clazz):
            print("a of B called")
            return "a of B"
    class C(A):
        @lazyperclassproperty
        def a(clazz):
            print("a of C called")
            return "a of C"
    class D(B):
        @lazyperclassproperty
        def a(clazz):
            print("a of D called")
            return "a of D"
    class E(C):
        @lazyperclassproperty
        def a(clazz):
            print("a of E called")
            return "a of E"

# Generated at 2022-06-12 08:18:42.724769
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C:
        @lazyperclassproperty
        def f(cls):
            return cls.__name__ + ': ' + str(id(cls))
    class D(C):
        pass
    class E(C):
        pass

    assert C.f == D.f 
    assert D.f == E.f 
    assert C.f == E.f
    assert C.f != D.f 
    assert D.f != E.f 
    assert C.f != E.f



# Generated at 2022-06-12 08:18:48.611389
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test for function lazyclassproperty
    """
    class A(object):
        @lazyclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'
    assert A.__dict__.get('_lazy_x', None) is not None


# Generated at 2022-06-12 08:18:52.460488
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):
        @lazyperclassproperty
        def test_func(cls):
            return cls
    class SubClass(BaseClass):
        pass

    assert BaseClass.test_func() is BaseClass
    assert SubClass.test_func() is SubClass



# Generated at 2022-06-12 08:18:55.570733
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo():
        @lazyclassproperty
        def prop1(cls):
            return 42

    class Bar(Foo):
        pass

    assert Foo.prop1 == 42
    assert Bar.prop1 == 42
    assert Foo.prop1 is Bar.prop1


# Generated at 2022-06-12 08:19:03.628311
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Cls(object):
        @lazyclassproperty
        def myprop(cls):
            print("Reading myprop")
            return "myprop"
    assert Cls.myprop == "myprop"
    assert Cls.myprop == "myprop"
    Cls.myprop = "modified"
    assert Cls.myprop == "modified"

    class SubCls(Cls):
        pass
    assert SubCls.myprop == "myprop"
    assert SubCls.myprop == "myprop"
    SubCls.myprop = "modified"
    assert SubCls.myprop == "modified"
    assert SubCls.myprop == "modified"

