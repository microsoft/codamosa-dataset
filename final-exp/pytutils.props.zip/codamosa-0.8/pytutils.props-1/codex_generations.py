

# Generated at 2022-06-12 08:09:40.217112
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:09:43.968584
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def test_property(cls):
            return "I'm a class property!"
    assert A.test_property == "I'm a class property!"
    assert A._lazy_test_property == "I'm a class property!"



# Generated at 2022-06-12 08:09:49.961523
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # The super class to be tested.
    class ClassA(object):
        class A(object): pass

        @lazyclassproperty
        def A_instance(cls):
            return cls.A()

    # make a class inheriting from ClassA
    class ClassB(ClassA):
        class B(object): pass

        @lazyclassproperty
        def B_instance(cls):
            return cls.B()

        @lazyclassproperty
        def A_instance(cls):
            return cls.A()

        @lazyclassproperty
        def A2_instance(cls):
            return cls.A()

    # make a class inheriting from ClassB
    class ClassC(ClassB):
        class C(object): pass


# Generated at 2022-06-12 08:09:56.027781
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pytest import raises

    class Person(object):

        @lazyclassproperty
        def country(cls):
            return 'Finland'

    class FinnishPerson(Person):
        pass

    class SwedishPerson(Person):

        @lazyclassproperty
        def country(cls):
            return 'Sweden'

    assert Person.country == 'Finland'
    assert FinnishPerson.country == 'Finland'
    assert SwedishPerson.country == 'Sweden'

    with raises(AttributeError):
        Person.country = 'KPP'

# Generated at 2022-06-12 08:10:02.087754
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        @lazyperclassproperty
        def bar(cls):
            print("evaluating bar")
            return 'bar'

    class SubFoo(Foo):
        pass

    f = Foo()
    sf = SubFoo()

    print(f.bar)
    print(f.bar)
    print(sf.bar)
    print(sf.bar)



# Generated at 2022-06-12 08:10:07.123718
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class test(object):
        def __init__(self):
            self.__class__.test_value = 0

        @lazyclassproperty
        def test(cls):
            cls.test_value += 1
            return cls.test_value

    t1 = test()
    t2 = test()
    assert t1.test == t2.test == 1

    t1.test = 2
    assert t1.test == t2.test == 2

    del t1.test
    assert t1.test == t2.test == 3

# Generated at 2022-06-12 08:10:12.223849
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def x(cls):
            print("get x")
            return "x"

    f = Foo()
    assert f.x == 'x'
    assert Foo.x == 'x'
    assert Foo.x == 'x'



# Generated at 2022-06-12 08:10:20.473226
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def sum_multiply(self):
        return self.a + self.b

    class A(object):
        a = 1
        b = 2
        sum_multiply = lazyperclassproperty(sum_multiply)

    class B(A):
        a = 3

    class C(B):
        b = 4

    a = A()
    b = B()
    c = C()
    assert a.sum_multiply == b.sum_multiply
    assert c.sum_multiply != b.sum_multiply
    assert a.sum_multiply != c.sum_multiply



# Generated at 2022-06-12 08:10:23.773627
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'
    print(Foo.foo)
    print(Foo.__dict__['_lazy_foo'])



# Generated at 2022-06-12 08:10:27.444094
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def class_test_property(cls):
            return 'foo'

    assert TestClass.class_test_property == 'foo'



# Generated at 2022-06-12 08:10:37.803713
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def class_spam(cls):
        return cls.key

    def class_egg(cls):
        return cls.key + 100

    class Base(object):
        key = 1

    class Foo(Base):
        @lazyperclassproperty
        def spam(cls):
            return class_spam(cls)

        @lazyperclassproperty
        def egg(cls):
            return class_egg(cls)

    class Bar(Base):
        key = 2

    class Baz(Base):
        key = 3

        def __init__(self):
            # The following line will be replaced by the decorator
            self.spam = self.__class__.key

    assert Foo.spam == 1
    assert Bar.spam == 2
    assert Baz.spam == 3
    assert Foo

# Generated at 2022-06-12 08:10:42.503028
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    arr = []
    class A(object):
        @lazyclassproperty
        def x(cls):
            arr.append(1)
            return 2

    assert A.x == 2
    assert arr == [1]
    assert A.x == 2
    assert arr == [1]



# Generated at 2022-06-12 08:10:51.949127
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        __metaclass__ = withmeta

        @lazyclassproperty
        def x(cls):
            num = A.x.num = getattr(A.x, 'num', 1) + 1
            return num

    assert A.x == 1
    assert A.x == 1
    assert A.__dict__['_lazy_x'] == 1

    class B(A):
        pass

    assert B.x == 2
    assert B.__dict__['_lazy_x'] == 2
    assert A.x == 1
    assert A.__dict__['_lazy_x'] == 1



# Generated at 2022-06-12 08:10:59.718948
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def TestClassProperty(cls):
            return 42

        @lazyperclassproperty
        def TestClassProperty2(cls):
            return cls.TestClassProperty
    assert TestClass.TestClassProperty == 42
    assert TestClass().TestClassProperty == 42

    class TestClassSub(TestClass):
        pass

    assert TestClassSub.TestClassProperty == 42
    assert TestClassSub().TestClassProperty == 42

    assert TestClassSub.TestClassProperty2 == 42
    assert TestClassSub().TestClassProperty2 == 42

    # Assert that the property has been set, and we're not continually re-creating it
    assert TestClass.TestClassProperty == 42
    assert TestClassSub.TestClassProperty == 42


# Generated at 2022-06-12 08:11:09.091247
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from threading import Thread



# Generated at 2022-06-12 08:11:17.566080
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def fn(cls):
            print("Calling fn()")
            return 1

    assert A.fn == 1
    assert A.fn == 1
    assert A.fn == 1
    assert A.fn == 1

    class B(A):
        pass

    assert B.fn == 1
    assert B.fn == 1

    class C(A):
        @lazyclassproperty
        def fn(cls):
            print("Calling override fn()")
            return 2

    assert C.fn == 2
    assert C.fn == 2



# Generated at 2022-06-12 08:11:23.243431
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import itertools

    class Foo(object):
        def __init__(self, idx):
            self.idx = idx

    class Bar(Foo):
        @lazyperclassproperty
        def unique_number(cls):
            return next(itertools.count())

    class FooBar(Bar, Foo):
        pass

    assert Bar().unique_number == 0
    assert FooBar().unique_number == 1



# Generated at 2022-06-12 08:11:31.190526
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test lazyperclassproperty for correct operation.
    """


# Generated at 2022-06-12 08:11:40.643776
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        count = 0

        @lazyperclassproperty
        def x(self):
            self.count += 1
            return "A.x", self.count

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    assert a.x == b.x == c.x == ("A.x", 1)
    assert a.x == b.x == c.x == ("A.x", 1)

    assert B.x == C.x == ("A.x", 2)
    assert B.x == C.x == ("A.x", 2)


# Generated at 2022-06-12 08:11:46.973857
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def __prop(cls):
            return {'A': 'a'}

    class B(A):
        pass

    assert A.__prop == {'A': 'a'}
    assert B.__prop == {'A': 'a'}
    A.__prop['A'] = 'b'
    assert A.__prop == {'A': 'b'}
    assert B.__prop == {'A': 'a'}



# Generated at 2022-06-12 08:11:56.305490
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        cls_lazy = lazyperclassproperty(lambda *a: 1)

    class B(A):
        cls_lazy = lazyperclassproperty(lambda *a: 2)

    class C(A):
        cls_lazy = lazyperclassproperty(lambda *a: 3)

    assert A.cls_lazy == 1
    assert B.cls_lazy == 2
    assert C.cls_lazy == 3


# Generated at 2022-06-12 08:12:05.564532
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return 2

    class D(B, C):
        pass

    class E(D):
        pass

    a = A()
    b = B()
    c = C()
    d = D()
    e = E()

    assert a.x == 1
    assert b.x == 1
    assert c.x == 2
    assert d.x == 1
    assert e.x == 1



# Generated at 2022-06-12 08:12:12.782778
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return propvalue(cls)

        @classmethod
        def propvalue(cls):
            return 'base'

    class Derived(Base):
        @classmethod
        def propvalue(cls):
            return 'derived'

    assert Base.prop == 'base'
    assert Derived.prop == 'derived'



# Generated at 2022-06-12 08:12:20.106469
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        called_count = 0
        def __init__(self):
            self.called_count = 0
        @lazyclassproperty
        def prop(cls):
            cls.called_count += 1
            return cls.called_count

    # Lazy property should not be executed when class is defined.
    assert Test.called_count == 0
    # First access to property should call the lazy function
    assert Test.prop == 1
    # Second access should return the same value not executing the lazy function again
    assert Test.prop == 1
    # Get same result from instance
    assert Test().prop == 1
    # Third access should return the same value not executing the lazy function again
    assert Test.prop == 1



# Generated at 2022-06-12 08:12:25.206701
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):
        @lazyperclassproperty
        def base_var(cls):
            return 'base'
    class DerivedClass(BaseClass):
        @lazyperclassproperty
        def base_var(cls):
            return 'derived'
    assert BaseClass.base_var=='base'
    assert DerivedClass.base_var=='derived'



# Generated at 2022-06-12 08:12:28.956263
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:12:36.454475
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo(object):
        @lazyclassproperty
        def bar(cls):
            return cls.__name__

    foo.bar
    assert foo.bar == 'foo'
    assert foo.__dict__['_lazy_bar'] == 'foo'
    class bar(foo):
        pass

    bar.bar
    assert bar.bar == 'bar'
    assert foo.bar == 'foo'
    assert bar.__dict__['_lazy_bar'] == 'bar'
    assert '_lazy_bar' not in foo.__dict__

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-12 08:12:39.870655
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        pass

    class A(Foo):
        @lazyclassproperty
        def a(cls):
            return 'A'

    class B(Foo):
        @lazyclassproperty
        def a(cls):
            return 'B'

    assert A.a == 'A'
    assert B.a == 'B'
    assert Foo.a == 'A'
    assert not hasattr(Foo, '_lazy_a')



# Generated at 2022-06-12 08:12:48.377652
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.x = 4

    class B(A):
        def __init__(self):
            super(B, self).__init__()
            self.x = 5

    class C(object):
        @lazyperclassproperty
        def prop(cls):
            return cls().x

    assert C.prop == 4
    assert B.prop == 5


if __name__ == '__main__':
    # Unit test for function lazyperclassproperty
    test_lazyperclassproperty()

# Generated at 2022-06-12 08:12:54.228518
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return [1]

    class B(A):
        pass

    assert A.test == [1]
    assert B.test == [1]
    A.test.append(2)
    assert A.test == [1, 2]
    assert B.test == [1]

# decorator to add a cached property to instances of classes
# this caches the result of an instance method in the instance



# Generated at 2022-06-12 08:13:10.491126
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:12.523260
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return "value"

    assert A.prop == "value"



# Generated at 2022-06-12 08:13:15.421344
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def acme(cls):
            return 42

    class Boo(Foo):
        pass

    assert Foo.acme == 42
    assert Boo.acme == 42



# Generated at 2022-06-12 08:13:25.826798
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Test(object):
        @lazyperclassproperty
        def foo(cls):
            return cls.__name__

        @lazyclassproperty
        def bar(cls):
            return cls.__name__

    class TestSub1(Test):
        pass

    class TestSub2(Test):
        pass

    test = Test()
    test1 = TestSub1()
    test2 = TestSub2()

    assert(test1.foo == 'TestSub1')
    assert(test2.foo == 'TestSub2')
    assert(test2.foo != test1.foo)

    assert(test.foo == 'Test')
    assert(test1.foo == test.foo)

    assert(test.bar == 'Test')
    assert(test1.bar == test.bar)

# Generated at 2022-06-12 08:13:30.244229
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        a = 10

    class B(A):
        a = 20

        @lazyperclassproperty
        def test(cls):
            return cls.a

    assert B.test == 20
    assert A.test == 10
    A.a=30
    assert B.test == 20
    assert A.test == 30


# Generated at 2022-06-12 08:13:36.964419
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def b(x):
            return 1
    class B(object):
        @lazyperclassproperty
        def b(x):
            return 2
        c = []
    B.c.append(B.b)
    assert A.b==1
    assert B.b==2
    assert B.c==[2]



# Generated at 2022-06-12 08:13:44.295236
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:13:46.608962
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def prop(cls):
            return "hello"
    assert C.prop == 'hello'



# Generated at 2022-06-12 08:13:50.058898
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def get_5(cls):
            return 5

    assert A.get_5 == 5

    class B(A):
        pass

    assert B.get_5 == 5


# Generated at 2022-06-12 08:13:58.333701
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def myprop(cls):
            print('getting myprop')
            return cls.__name__

    assert MyClass.myprop == 'MyClass'
    print(MyClass.myprop)
    assert MyClass.myprop == 'MyClass'
    print(MyClass.myprop)

    class MyOtherClass(MyClass):
        pass

    assert MyOtherClass.myprop == 'MyOtherClass'
    print(MyOtherClass.myprop)
    assert MyOtherClass.myprop == 'MyOtherClass'
    print(MyOtherClass.myprop)
    assert MyClass.myprop == 'MyClass'
    print(MyClass.myprop)



# Generated at 2022-06-12 08:14:18.987151
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def attr(cls):
            return 42
    assert A.attr == 42



# Generated at 2022-06-12 08:14:24.584291
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            "I am the lazy property"
            return 1

    assert C.x == 1
    assert C.x == 1
    assert C.__dict__['_lazy_x'] == 1

    class D(C):
        pass

    assert D.x == 1
    assert C.x == 1
    assert '_lazy_x' not in D.__dict__
    assert D.__dict__['_lazy_x'] == 1



# Generated at 2022-06-12 08:14:30.805675
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class X:
        @lazyperclassproperty
        def a(cls):
            return cls + 1
    class Y(X):
        pass
    class Z(X):
        pass

    assert X.a == 2
    assert Y.a == 3
    assert Z.a == 4

    X.a = 42
    assert X.a == 42
    assert Y.a == 3
    assert Z.a == 4

    Y.a = 43
    assert X.a == 42
    assert Y.a == 43
    assert Z.a == 4

    Z.a = 44
    assert X.a == 42
    assert Y.a == 43
    assert Z.a == 44


# Generated at 2022-06-12 08:14:34.068878
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__

    assert MyClass.name == 'MyClass'



# Generated at 2022-06-12 08:14:42.192697
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "FOO"

    class B(A):
        @lazyclassproperty
        def foo(cls):
            return "B FOO"

    @lazyclassproperty
    def foo(cls):
        return "W FOO"

    class TestLazyClassProperty(unittest.TestCase):
        def test_lazyclassproperty(self):
            self.assertTrue(A.foo == "FOO")
            self.assertTrue(B.foo == "B FOO")
            self.assertTrue(foo == "W FOO")

    unittest.main()

# Generated at 2022-06-12 08:14:44.635539
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:14:47.972691
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def rand(self):
            return randint(0, 100)

    class B(A):
        pass

    a = A()
    b = B()


# Generated at 2022-06-12 08:14:56.035038
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            # print("Foo.bar")
            return "Foo.bar"

        class Bar(Foo):
            pass

        class Baz(Foo):
            pass

    class Baz(Foo):
        @lazyperclassproperty
        def bar(cls):
            # print("Baz.bar")
            return "Baz.bar"

    class Qux(Baz):
        pass

    assert Foo._lazy_bar == "Foo.bar"
    assert Foo.Bar._lazy_bar == "Foo.bar"
    assert Foo.Baz._lazy_bar == "Foo.bar"
    assert Baz._lazy_bar == "Baz.bar"

# Generated at 2022-06-12 08:15:01.023470
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo' + cls.stuff

        stuff = 'A'

    class B(A):
        stuff = 'B'

    assert A.foo == 'fooA'
    assert B.foo == 'fooB'
    assert A().foo == 'fooA'
    assert B().foo == 'fooB'



# Generated at 2022-06-12 08:15:05.269159
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return 1

    assert A.b == 1

    class B(A):
        @lazyclassproperty
        def b(cls):
            return 2

    assert B.b == 2
    assert A.b == 1



# Generated at 2022-06-12 08:15:49.272428
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:15:53.335175
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def calc(cls):
            print('Computing')
            return 1 + 2

    class B(A):
        pass

    assert A.calc == 3
    assert B.calc == 3

    A.calc = 3
    assert A.calc == 3
    assert B.calc == 3

    del A.calc
    assert A.calc == 3



# Generated at 2022-06-12 08:16:00.300995
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):

        @lazyclassproperty
        def count(cls):
            return 0

        @lazyperclassproperty
        def mycount(cls):
            return 0

    assert MyClass.count == 0
    assert MyClass.mycount == 0

    class YourClass(MyClass):
        pass

    assert YourClass.count == 0
    assert YourClass.mycount == 0

    class HisClass(MyClass):

        @lazyclassproperty
        def count(cls):
            return 1

        @lazyperclassproperty
        def mycount(cls):
            return 1

    assert HisClass.count == 1
    assert MyClass.count == 0
    assert YourClass.count == 0
    assert HisClass.mycount == 1
    assert MyClass.mycount == 0

# Generated at 2022-06-12 08:16:07.890236
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.var = None

        @lazyperclassproperty
        def my_prop(cls):
            print('Setting property for class {}'.format(cls.__name__))
            return cls()

    a = A()
    assert a.my_prop.var is None
    a.my_prop.var = 'value'
    assert a.my_prop.var == 'value'
    assert A.my_prop.var is None

    class B(A):
        pass

    b = B()
    assert b.my_prop.var is None
    b.my_prop.var = 'value'
    assert b.my_prop.var == 'value'
    assert B.my_prop.var is None



# Generated at 2022-06-12 08:16:10.026420
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    This is a very basic test unit for the non-normalization
    of the data.
    """
    import doctest
    doctest.testmod(verbose=True)


# Generated at 2022-06-12 08:16:18.012128
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:16:22.515113
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def f(cls):
            return sum(i for i in range(100))

    assert C.f == 4950

    class D(C):
        pass

    assert C.f == 4950
    assert D.f == 4950



# Generated at 2022-06-12 08:16:26.949922
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'foo'
    assert A.x == 'foo'
    A.x = 1
    assert A.x == 1  # Re-assignment should take
    class B(A):
        pass
    assert B.x == 1  # Should still be equal to 1



# Generated at 2022-06-12 08:16:34.088286
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def foo(cls):
            print('running foo')
            return 'foo'

        @lazyclassproperty
        def bar(cls):
            print('running bar')
            return 'bar'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert A.bar == 'bar'
    assert B.foo == 'foo'
    assert B.bar == 'bar'
    assert A.foo == B.foo == 'foo'
    assert A.bar == B.bar == 'bar'

# Generated at 2022-06-12 08:16:41.411675
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Dummy(object):
        pass

    class Dummy2(Dummy):
        pass

    class Dummy3(object):
        pass

    def _dummy_func(cls):
        return 1

    _lazy_dummy_func = lazyperclassproperty(_dummy_func)

    assert Dummy._lazy_dummy_func == 1
    assert Dummy2._lazy_dummy_func == 1
    assert Dummy3._lazy_dummy_func == 1



# Generated at 2022-06-12 08:18:16.224580
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def f(cls):
        print("Function f called for class %s" % cls)
        return 1

    class A(object):
        x = lazyperclassproperty(f)

    class B(A):
        pass

    class C(A):
        pass

    print(A.x, B.x, C.x)
    print(A.x, B.x, C.x)
    A.x = 2
    print(A.x, B.x, C.x)
    print(A.x, B.x, C.x)



# Generated at 2022-06-12 08:18:21.756573
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self,x):
            self.x=x
        @lazyperclassproperty
        def get_x(cls):
            return cls.x
    class B(A):
        x = 7
    class C(A):
        x = 3
    b=B()
    c=C()
    assert b.get_x == 7
    assert c.get_x == 3
    assert A.get_x == 0



# Generated at 2022-06-12 08:18:24.814803
# Unit test for function lazyclassproperty

# Generated at 2022-06-12 08:18:32.917862
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self, a):
            self.a = a

        @lazyclassproperty
        def clsprop(cls):
            print('clsprop')
            return cls.__name__

        @lazyclassproperty
        def clsprop_with_param(cls):
            return cls.__name__ + '_with_param'

    assert A.clsprop == 'A'
    assert A.clsprop == 'A'

    assert A('b').a == 'b'
    assert A('b').clsprop == 'A'
    assert A.clsprop_with_param == A.clsprop_with_param

    class B(A):
        @lazyclassproperty
        def clsprop(cls):
            print('clsprop')

# Generated at 2022-06-12 08:18:38.739283
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A():
        @lazyclassproperty
        def FOO(cls):
            return cls.__name__

        @lazyclassproperty
        def BAR(cls):
            return cls.__name__ + '1'

    class B(A):
        @lazyclassproperty
        def BAR(cls):
            return cls.__name__ + '2'

    assert A.FOO == 'A'
    assert A.BAR == 'A1'
    assert B.FOO == 'A'
    assert B.BAR == 'B2'



# Generated at 2022-06-12 08:18:41.001385
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("run...")
            return 1

    a1 = A()
    a2 = A()

    assert a1.prop == a2.prop == 1



# Generated at 2022-06-12 08:18:46.868384
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return cls.__name__

    class B(object):
        @lazyclassproperty
        def x(cls):
            return cls.__name__

    assert A.x == "A"
    assert B.x == "B"

    B.x = "C"
    assert B.x == "C"
    assert A.x == "A"



# Generated at 2022-06-12 08:18:55.894163
# Unit test for function lazyperclassproperty

# Generated at 2022-06-12 08:19:04.746585
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def func1(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def func1(cls):
            return "B"

    class C(B):
        @lazyperclassproperty
        def func1(cls):
            return "C"

    class D(C):
        @lazyperclassproperty
        def func1(cls):
            return "D"

    class E(D):
        @lazyperclassproperty
        def func1(cls):
            return "E"

    assert A().func1 == "A"
    assert B().func1 == "B"
    assert C().func1 == "C"
    assert D().func1 == "D"
    assert E().func

# Generated at 2022-06-12 08:19:12.452459
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(self):
            return {}

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()
    a.foo[1] = 1
    assert a.foo[1] == 1
    assert b.foo[1] == 1
    assert c.foo[1] == 1
    b.foo[2] = 2
    assert b.foo[2] == 2
    assert c.foo[1] == 1
    assert a.foo[1] == 1
    assert a.foo[2] == None

