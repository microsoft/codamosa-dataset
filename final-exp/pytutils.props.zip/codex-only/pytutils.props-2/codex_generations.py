

# Generated at 2022-06-24 03:03:54.565228
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop(cls):
            return cls.__name__ + ' prop_value'

    class TestSub(Test):
        pass

    assert Test.prop == 'Test prop_value'
    assert TestSub.prop == 'TestSub prop_value'
    assert TestSub.prop == 'TestSub prop_value'
    assert Test.prop == 'Test prop_value'



# Generated at 2022-06-24 03:04:00.575112
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass:
        @lazyclassproperty
        def attribute(cls):
            print("Called only once!")
            return True

        @classproperty
        def property(cls):
            print("Called every time!")
            return False

    print("Executing attribute:")
    print(MyClass.attribute)
    print(MyClass.attribute)
    print(MyClass.attribute)
    print("Executing property:")
    print(MyClass.property)
    print(MyClass.property)



# Generated at 2022-06-24 03:04:08.064794
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._value = 0

        @setterproperty
        def value(self, value):
            if value < 0:
                raise Exception("Invalid value for A.value.")
            self._value = value


    a = A()
    a.value = 10
    print("Assigned value to A.value using setterproperty method")
    print("A.value = %d \n" % a.value)
    a.value = -10



# Generated at 2022-06-24 03:04:11.580694
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    try:
        class Foo(object):
            @lazyclassproperty
            def foo(cls):
                return 'bar'

        assert Foo.foo == 'bar'
    except AssertionError:
        assert False, "lazyclassproperty unit test failed!"



# Generated at 2022-06-24 03:04:17.961584
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._x = 0

        @staticmethod
        def func(self):
            return self._x

        @setterproperty
        def x(self, value):
            self._x = int(value)

    a = A()
    a.x = 1
    assert a.x == a.func()


# Unit test lazyproperty

# Generated at 2022-06-24 03:04:28.035713
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class SomeClass(object):
        @lazyclassproperty
        def lazyprop(cls):
            return "The lazyprop value for class %s is %s" % (cls.__name__, hash(cls))

        @lazyclassproperty
        def lazyprop2(cls):
            return "The lazyprop2 value for class %s is %s" % (cls.__name__, hash(cls))

    class InheritedClass(SomeClass):
        pass

    # Test lazyprop
    assert SomeClass.lazyprop == "The lazyprop value for class SomeClass is %s" % hash(SomeClass)
    assert InheritedClass.lazyprop == "The lazyprop value for class InheritedClass is %s" % hash(InheritedClass)
    # Test lazyprop2
    assert SomeClass.lazyprop2

# Generated at 2022-06-24 03:04:32.448539
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def prop(obj, value):
            return value + 1
    obj = Foo()
    assert obj.prop == 2


# Generated at 2022-06-24 03:04:40.566085
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass:
        @lazyclassproperty
        def ClassCounter(cls):
            return sum([1 for c in cls.__subclasses__()])

    class TestClass2(TestClass):
        pass

    class TestClass3(TestClass):
        pass

    class TestClass4(TestClass3):
        pass

    class TestClass5(TestClass2):
        pass

    assert TestClass.ClassCounter == 3
    assert TestClass2.ClassCounter == 2
    assert TestClass3.ClassCounter == 2
    assert TestClass4.ClassCounter == 1
    assert TestClass5.ClassCounter == 1



# Generated at 2022-06-24 03:04:43.056693
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class F:
        @roclassproperty
        def a(cls):
            return 1

    assert F.a == 1

    # Check that you can't set the attribute
    try:
        F.a = 2
        assert False
    except AttributeError:
        pass


# Generated at 2022-06-24 03:04:49.773969
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            self._x = 1

        @lazyperclassproperty
        def x(cls):
            return getattr(cls, '_x')


    class Child(Base):
        def __init__(self):
            super(Child, self).__init__()
            self._x = 2


    class GrandChild(Child):
        def __init__(self):
            super(GrandChild, self).__init__()
            self._x = 3


    assert Base().x == 1
    assert Child().x == 2
    assert GrandChild().x == 3



# Generated at 2022-06-24 03:04:55.855322
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def prop(cls):
            return 20

    assert C.prop == 20
    c = C()


# Generated at 2022-06-24 03:05:00.746173
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class Bar(object):

        @roclassproperty
        def foo(cls):
            return cls

    assert Bar.foo is Bar, "Bar.foo is not Bar!"



# Generated at 2022-06-24 03:05:05.987166
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from datetime import date


    class Foo:
        def __init__(self, name):
            self.name = name

        @setterproperty
        def name(self, name):
            if name == 'hello':
                return 'hello'
            else:
                return TypeError('Name should be `hello`')

        @classmethod
        def today(cls):
            return date.today()


    foo = Foo('David')
    assert foo.name == 'David' and type(foo.name) is str
    assert type(Foo.today()) is date
    Foo.name = 'hello'
    assert Foo.name == 'hello' and type(Foo.name) is str



# Generated at 2022-06-24 03:05:14.065147
# Unit test for constructor of class setterproperty
def test_setterproperty():
    @setterproperty
    def a(self, val):
        self._a = val

    @setterproperty
    def b(self, val):
        a(self, val)

    @setterproperty
    def c(self, val):
        self._c = val

    class test(object):
        def __init__(self):
            self._a = self._c = 0

        a = a
        b = b
        c = c

    t = test()
    t.a = 5
    assert t._a == 5
    t.b = 7
    assert t._a == 7
    t.c = 9
    assert t._c == 9

# Generated at 2022-06-24 03:05:20.658973
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.x = 1

        @roclassproperty
        def c(cls):
            return cls.__name__

        @property
        def r(self):
            return self.x

    a = A()
    assert a.r == 1
    assert a.c == a.__class__.__name__
    # Change `x` does not affect a.r
    a.x = 3
    assert a.r == 1
    try:
        # Changing a.c is not allowed
        a.c = 4
    except AttributeError:
        pass


# Generated at 2022-06-24 03:05:25.475052
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def prop(cls):
            print('A')
            return 'A'
    class B(A):
        @lazyperclassproperty
        def prop(cls):
            print('B')
            return 'B'
    class C(A):
        pass
    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'A'


# Generated at 2022-06-24 03:05:34.918594
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def myp(cls):
            return 5

    class B:
        pass

    class Bar(B, Foo):
        pass

    class Baz(Foo):
        pass

    b = Bar()
    f = Foo()
    f2 = Foo()
    b2 = Bar()
    f3 = Foo()
    b3 = Bar()
    bz = Baz()

    assert b.myp == 5
    assert f.myp == 5
    assert f2.myp == 5
    assert f3.myp == 5
    assert b2.myp == 5
    assert b3.myp == 5
    assert bz.myp == 5



# Generated at 2022-06-24 03:05:40.010761
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object): pass
    c = C()
    c.x = 3

    def property_setter(o, v):
        o.x = v

    def property_getter(o):
        return o.x

    C.sp = setterproperty(property_setter)
    C.gp = property(property_getter)
    
    c.sp = 13
    
    assert c.sp == 13

# Generated at 2022-06-24 03:05:47.546005
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestSetterProperty:
        def __init__(self, foo):
            self.foo = foo
            self.flag = False
            self.value = None
   
        @setterproperty
        def foo(self, value):
            self.flag = True
            self.value = value

    obj = TestSetterProperty("foo")
    assert obj.flag is False
    obj.foo = "bar"
    assert obj.flag is True
    assert obj.foo == "bar"
    assert obj.value == "bar"

test_setterproperty___set__()

# Generated at 2022-06-24 03:05:51.527482
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:05:57.564138
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def a(cls):
            return 1

    assert A.a == 1
    assert A().a == 1



# Generated at 2022-06-24 03:06:07.094393
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test __set__ of class setterproperty
    """
    # Test with simple class with 2 properties
    class TestSetterProperty(object):
        def __init__(self):
            self.prop1 = None
            self.prop2 = None
        @setterproperty
        def prop1(self, value):
            self._prop1 = value
            return self._prop1
        @setterproperty
        def prop2(self, value):
            self._prop2 = value

    # Instantiate object
    obj = TestSetterProperty()

    # # prop1
    # Set value of prop1 using __set__ of setterproperty
    obj.prop1 = 10
    # Check the value of prop1
    assert obj._prop1 == 10

    # # prop2
    # Set value of prop2 using __set__ of set

# Generated at 2022-06-24 03:06:10.245920
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class class_new(object):
        @roclassproperty
        def property2(cls):
            return cls.__name__.upper()

    class class_new_new(class_new):
        pass

    print(class_new_new.property2)


# Generated at 2022-06-24 03:06:13.550789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.name == 'Foo'
    assert Foo.bar == 'bar'



# Generated at 2022-06-24 03:06:20.189283
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def ro_property(cls):
            return 'Test value'

    assert A.ro_property == 'Test value'
    B = A()
    assert B.ro_property == 'Test value'
    try:
        A.ro_property = 'Test value2'
    except AttributeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:06:26.260098
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def s(cls):
            return 'AAA'

    print(A.s)


    class B(A):
        pass

    print(A.s)
    print(B.s)
    A.s = 'BBB'
    print(A.s)
    print(B.s)



# Generated at 2022-06-24 03:06:32.748851
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        x = 1
        @lazyclassproperty
        def doublex(cls):
            return cls.x * 2

    assert Test.doublex == 2

    Test.x = 2
    assert Test.doublex == 4

    class Test2(Test):
        pass
    assert Test2.doublex == 4

    Test2.x = 3
    assert Test2.doublex == 6



# Generated at 2022-06-24 03:06:37.873129
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._p = None

        @setterproperty
        def p(self, x):
            if x < 0:
                raise ValueError('p must be positive')
            self._p = x

    a = A()

    a.p = -1
    assert a._p is None

    a.p = 1
    assert a._p == 1

# Generated at 2022-06-24 03:06:44.896239
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        pass

    class TestClass2(TestClass):
        pass

    @roclassproperty
    def test(cls):
        return cls.__name__

    # Test __get__ with a class
    assert TestClass.test == 'TestClass'
    # Test __get__ with an object
    assert TestClass().test == 'TestClass'
    # Test __get__ with an inheritor class
    assert TestClass2.test == 'TestClass2'
    # Test __get__ with an inheritor object
    assert TestClass2().test == 'TestClass2'



# Generated at 2022-06-24 03:06:51.172011
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Persons:
        def __init__(self, name):
            self._name = name

# Generated at 2022-06-24 03:06:59.592034
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, value=None):
            self.value = value

        @setterproperty
        def value(self, value):
            return value

    class B(A):
        def __init__(self, value=None):
             super(B, self).__init__(value)

    assert A().value is None
    assert B().value is None

    a = A(1)
    b = B(1)

    assert a.value == 1
    assert b.value == 1

    a.value = 2
    b.value = 2

    assert a.value == 2
    assert b.value == 2



# Generated at 2022-06-24 03:07:02.429393
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            self._x = value * 2

    a = A()
    a.x = 1
    assert a._x == 2



# Generated at 2022-06-24 03:07:04.900986
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self):
            self.x = roclassproperty(lambda c: c.y)
            self.y = 'Y'

    assert A().x == 'Y'



# Generated at 2022-06-24 03:07:09.253467
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def twice(cls):
            print('Executing')
            return 2

    assert A.twice == 2
    assert A.twice == 2
    # Check that subclasses work as well
    class B(A):
        pass

    assert B.twice == 2



# Generated at 2022-06-24 03:07:17.058930
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            return {'foo'}

    assert Foo.bar == {"foo"}
    assert not hasattr(Foo, '_lazy_bar')

    class Bar(Foo):
        pass

    assert Bar.bar == {"foo"}
    assert not hasattr(Bar, '_lazy_bar')

    class Foo(object):

        @lazyperclassproperty
        def bar(cls):
            return {'foo'}

    assert Foo.bar == {"foo"}
    assert not hasattr(Foo, '_Foo_lazy_bar')

    class Bar(Foo):
        pass

    assert Bar.bar == {"foo"}
    assert not hasattr(Bar, '_Bar_lazy_bar')



# Generated at 2022-06-24 03:07:19.542925
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:07:22.374090
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestSetterProperty:
        x = None

        @setterproperty
        def x(self, value):
            self.x = value

    a = TestSetterProperty()
    a.x = 10
    assert a.x == 10


# Generated at 2022-06-24 03:07:30.973436
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert A.foo == 'foo'
    assert A().foo == 'foo'

    a = A()
    a.foo = 'baz'
    assert a.foo == 'baz'

    assert A.bar == 'bar'
    assert a.bar == 'bar'

    assert not hasattr(A, '_lazy_bar')
    assert hasattr(a, '_lazy_bar')

    A.bar = 'baz'
    assert a.bar == 'baz'
    assert not hasattr(a, '_lazy_bar')


if __name__ == '__main__':
    test_ro

# Generated at 2022-06-24 03:07:36.563848
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        foo = 'foo'
        bar = roclassproperty(lambda klass: klass.foo.upper())

    assert Foo.bar == 'FOO'



# Generated at 2022-06-24 03:07:42.593990
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def __init__(self):
            self.x = 1

        @roclassproperty
        def y(cls):
            return cls.x + 1

    a = A()
    print(a.y)



# Generated at 2022-06-24 03:07:48.238678
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if self._x is None:
                self._x = value
            else:
                print('value x has been set!')

    obj = C()
    obj.x = 3
    obj.x = 4
    print(obj._x)


# Generated at 2022-06-24 03:07:55.103938
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from six import assertRaisesRegex

    class TestCase(object):
        @setterproperty
        def myprop(instance, value):
            return value

    # AttributeError is raised if value is not supplied
    obj = TestCase()
    assertRaisesRegex(AttributeError, 'value', obj.myprop)


# Generated at 2022-06-24 03:07:58.981464
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def random_prop(cls):
            return random.random()
    class Child(Parent):
        pass

    print(Parent.random_prop)
    print(Child.random_prop)
    


# Generated at 2022-06-24 03:08:03.249850
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def prop(cls):
            return 'prop'

    class B(A):
        pass

    assert A.prop == A.prop  # ensures that the property is read-only
    assert A.prop == B.prop  # ensures that the property is shared among subclasses



# Generated at 2022-06-24 03:08:07.159178
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):

        @lazyclassproperty
        def prop(cls):
            print("Calculating...")
            return 10

    t1 = Test()
    t2 = Test()

    print(t1.prop)
    print(t2.prop)
    print(Test.prop)


# Generated at 2022-06-24 03:08:15.049337
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class Cls(object):
        @roclassproperty
        def roProperty(cls):
            return 'ro'

    assert Cls.roProperty == Cls.roProperty
    assert Cls.__dict__['roProperty'] == 'ro', Cls.__dict__['roProperty']

    try:
        Cls.roProperty = 'CHANGED'
        assert False
    except:
        assert True

    print('__get__ test passed')


# Generated at 2022-06-24 03:08:25.031331
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def _square(x):
        return x**2

    class KlassBase(object):
        @lazyperclassproperty
        def property1(self):
            return 'base property'

        @lazyperclassproperty
        def property2(self):
            return _square(2)

    class KlassA(KlassBase):
        # no @lazyperclassproperty, inherits base

        @lazyperclassproperty
        def property3(self):
            return 'property3'

    class KlassB(KlassBase):
        @lazyperclassproperty
        def property2(self):
            return _square(3)

    a = KlassA()
    b = KlassB()
    assert a.property1 == 'base property'
    assert b.property1 == 'base property'
    assert a.property3

# Generated at 2022-06-24 03:08:35.955296
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        @lazyclassproperty
        def x(cls):
            print("Computing x")
            return 3
    assert(MyClass.x == 3)
    assert(MyClass.x == 3)
    try:
        MyClass.x = 9
        raise RuntimeError("Shouldn't be able to set MyClass.x")
    except AttributeError:
        pass
    except:
        raise RuntimeError("AttributeError should be raise when setting MyClass.x")

    class MyClass(object):
        @lazyclassproperty
        def x(cls):
            print("Computing x")
            return 3
        @x.setter
        def x(cls, value):
            cls._x = value
    assert(MyClass.x == 3)
    MyClass.x = 9
   

# Generated at 2022-06-24 03:08:38.546522
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    pass



# Generated at 2022-06-24 03:08:42.380924
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def foo(cls):
            return 'foo'
    class Bar(Foo):
        pass

    assert Foo.foo == 'foo'
    assert Bar.foo == 'foo'
    Bar.foo = 'bar'
    assert Bar.foo == 'bar'
    assert Foo.foo == 'foo'



# Generated at 2022-06-24 03:08:44.332359
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def t(cls):
            return 't'
    assert A.t == 't'


# Generated at 2022-06-24 03:08:49.371716
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        def _foo_get(cls):
            return 'test'
        foo = roclassproperty(_foo_get)
        pass
    assert Test.foo == 'test'
    assert Test().foo == 'test'



# Generated at 2022-06-24 03:08:56.814138
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        pass
    class Inheritor(Base):
        pass
    @lazyperclassproperty
    def static_dict(cls):
        return {}
    assert(Base.static_dict is not Inheritor.static_dict)  # separate instances for base and inheritor
    base_first_id = id(Base.static_dict)
    inheritor_first_id = id(Inheritor.static_dict)
    assert(base_first_id == id(Base.static_dict))  # cached/same instance for base
    assert(inheritor_first_id == id(Inheritor.static_dict))  # cached/same instance for inheritor


# Generated at 2022-06-24 03:09:01.339129
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def name(c):
            return c.__name__
    assert A.name == 'A'



# Generated at 2022-06-24 03:09:09.443676
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # parameterized decorator
    class C(object):
        @roclassproperty
        def length(cls):
            return len(cls.__name__)

    print(C.length)
    print(C().length)

    # direct construction
    class C(object):
        pass

    C.length = roclassproperty(lambda cls: len(cls.__name__))
    print(C.length)
    print(C().length)



# Generated at 2022-06-24 03:09:11.759970
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'foo'



# Generated at 2022-06-24 03:09:15.049174
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):

        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x

    foo._x = 2
    assert foo.x == 2


# Generated at 2022-06-24 03:09:19.444921
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        t = roclassproperty(lambda cls: 'Test')

        def __init__(self, name):
            self.name = name

    t = Test('name')
    assert t.t == 'Test', t.t



# Generated at 2022-06-24 03:09:26.942230
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self, value):
            self._x = value

        def get_x(self):
            return self._x

        def set_x(self, value):
            self._x = value

        x = setterproperty(get_x, set_x)

    a = A(42)
    assert a.x == 42
    a.x = 43
    assert a.x == 43

# Generated at 2022-06-24 03:09:33.970787
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A():
        def __init__(self):
            pass

        @lazyclassproperty
        def init_val(cls):
            return 'Initialized value 1'

    assert A.init_val == 'Initialized value 1'

    A.init_val = 'Initialized value 2'
    assert A.init_val == 'Initialized value 2'

    class B(A):
        def __init__(self):
            pass

        @lazyclassproperty
        def init_val_child(cls):
            return 'Initialized value 1 child'

    assert B.init_val_child == A.init_val_child == 'Initialized value 1 child'



# Generated at 2022-06-24 03:09:39.236547
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        def _not_loaded(cls):
            print("Loading...")
            return "loaded"

        cached = lazyclassproperty(_not_loaded)

    # Not loaded yet
    assert not hasattr(MyClass, "_lazy_not_loaded")

    # Call once
    assert MyClass.cached == "loaded"

    # Loaded
    assert hasattr(MyClass, "_lazy_not_loaded")

    # Calling again doesn't reload
    assert MyClass.cached == "loaded"



# Generated at 2022-06-24 03:09:45.577357
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'class property foo'

    class B(A):
        pass

    assert A.foo == 'class property foo'
    assert B.foo == 'class property foo'

    try:
        A.foo = 'another value'
    except AttributeError:
        pass
    else:
        raise AssertionError("roclassproperty writeable")


# Generated at 2022-06-24 03:09:54.280670
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Case 1: classmethod and roclassproperty
    class A:
        @classmethod
        @roclassproperty
        def prop(cls):
            return cls
    assert A.prop == A
    assert A() != A.prop     # A.prop is not an instance of A
    class B(A):
        pass
    assert B.prop == B
    class C(A):
        @roclassproperty
        def prop(cls):
            return 1
    assert C.prop == 1
    assert C() != C.prop     # Instance C() does not have instance property prop

    # Case 2: classmethod and classproperty
    class D:
        @classproperty
        def prop(cls):
            return cls
    assert D.prop == D
    assert D() != D.prop     # D.prop is not an

# Generated at 2022-06-24 03:10:00.324322
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return cls.__name__

        @classmethod
        def a_m(cls):
            return cls.__name__

    assert A.a == 'A'
    assert A.a_m() == 'A'
    assert A().a == 'A'
    assert A.a_m() == 'A'

# Generated at 2022-06-24 03:10:04.560115
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def prop(self, value):
            self.__value = value

    a = A()
    a.prop = 100
    assert a.__value == 100


# Generated at 2022-06-24 03:10:12.608498
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, x):
            if x < 0:
                self._x = 0
            elif x > 1000:
                self._x = 1000
            else:
                self._x = x

    foo = Foo()
    foo.x = 0
    assert foo._x == 0
    foo.x = -1
    assert foo._x == 0
    foo.x = 4000
    assert foo._x == 1000
    foo.x = 500
    assert foo._x == 500


# Generated at 2022-06-24 03:10:16.939604
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj:
        pass
    obj = Obj()
    props = setterproperty(lambda obj, val: setattr(obj, 'prop', val))
    assert 'prop' not in obj.__dict__
    props.__set__(obj, 'value')
    assert obj.__dict__['prop'] == 'value'

# Generated at 2022-06-24 03:10:19.797636
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def Bar(cls):
            return "baz"
    class Bar(Foo):
        pass
    foo = Foo()
    assert Foo.Bar == 'baz'
    assert Bar.Bar == 'baz'



# Generated at 2022-06-24 03:10:27.511981
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclassproperty_test(object):
        # This property can not be overridden in children classes
        cnt = roclassproperty(lambda cls: cls.get_cnt())

        @classmethod
        def get_cnt(cls):
            return 10

    # Both create the same instance of roclassproperty
    assert roclassproperty_test.cnt is roclassproperty_test.cnt
    # Both have different values
    assert roclassproperty_test.cnt == 10
    # No cnt in roclassproperty
    assert not hasattr(roclassproperty_test.cnt, 'cnt')



# Generated at 2022-06-24 03:10:28.457340
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    assert 1 == 1


# Generated at 2022-06-24 03:10:34.249083
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self, a):
            self.a = a

        @lazyperclassproperty
        def c(cls):
            print("Called")
            return 10

        @lazyclassproperty
        def b(cls):
            print("Called")
            return 20

    print(A.b)
    print(A.c)
    print(A(1).c)

    # Called
    # 20
    # Called
    # 10
    # 10



# Generated at 2022-06-24 03:10:36.728601
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test:
        def f(self, x):
            return x + 1

        f = roclassproperty(f)

    t = Test()
    assert t.f == Test().f



# Generated at 2022-06-24 03:10:41.592393
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        x = roclassproperty(lambda cls: cls.__name__)

    assert Foo.x == 'Foo'



# Generated at 2022-06-24 03:10:44.019321
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def m(cls):
            return 10

        m = roclassproperty(m)

    assert A.m == 10
    assert A().m == 10


# Generated at 2022-06-24 03:10:46.420499
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.x = 5
        @setterproperty
        def x(self, val):
            self._x = val

    a = A()
    assert a.x == 5
    a.x = 6
    assert a.x == 6
    assert a._x == 6



# Generated at 2022-06-24 03:10:48.568875
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @lazyclassproperty
        def test(cls):
            return 1

    assert Test.test == 1
    Test.test = 2
    assert Test.test == 1


# Generated at 2022-06-24 03:10:53.744072
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        _value = 0

        @roclassproperty
        def value(cls):
            return cls._value

        @value.setter
        def value(cls, value):
            cls._value = value

    assert MyClass._value == 0
    assert MyClass.value == 0

    MyClass.value = 42
    assert MyClass._value == 42
    assert MyClass.value == 42

# Generated at 2022-06-24 03:10:55.351489
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class c(object):
        @roclassproperty
        def class_value(cls):
            return 'some value'

    assert c.class_value == 'some value'
    assert c().class_value == 'some value'



# Generated at 2022-06-24 03:10:59.085880
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def amethod(self):
            return "the result"

    class B(A):
        @lazyclassproperty
        def myprop(cls):
            return cls.amethod()

    assert B.myprop == "the result"
    assert A.myprop == "the result"



# Generated at 2022-06-24 03:11:06.664972
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def foo(self, value):
            self.x = value + 1

    obj = Foo(1)

# Generated at 2022-06-24 03:11:12.296806
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        pass

    a = A()

    def setter(x, value):
        x.value = value

    class B(object):
        a = setterproperty(setter)

    b = B()
    b.a = 2
    assert(b.value == 2)


# Generated at 2022-06-24 03:11:20.778603
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'
    assert A.x == 'x'
    assert '_lazy_x' not in A.__dict__

    class B(A):
        pass
    assert B.x == 'x'
    assert '_lazy_x' in B.__dict__

    assert A().x == 'x'
    assert B().x == 'x'
    assert A.x == 'x'
    assert B.x == 'x'

# Generated at 2022-06-24 03:11:28.059706
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            if value > 10:
                self._value = value
            else:
                self._value = None

        @value.getter
        def value(self):
            return self._value

    obj = C(9)
    assert obj.value is None
    obj.value = 11
    assert obj.value == 11



# Generated at 2022-06-24 03:11:32.787636
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        func_setter = setterproperty(lambda cls, value: cls)

    assert MyClass.func_setter is None
    assert MyClass.func_setter is MyClass.func_setter
    assert MyClass.func_setter.__doc__ is None

    class MyClass2(MyClass):
        pass

    assert MyClass2.func_setter is MyClass.func_setter

    class MyClass3(MyClass):
        func_setter = setterproperty(lambda cls, value: cls, "docstring")

    assert MyClass3.func_setter is not MyClass.func_setter
    assert MyClass3.func_setter is MyClass3.func_setter
    assert MyClass3.func_setter.__doc__ == "docstring"

# Generated at 2022-06-24 03:11:34.527143
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    def hello():
        return 'world'

    assert(roclassproperty(hello) == 'world')



# Generated at 2022-06-24 03:11:40.795502
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo(cls):
            return cls

    A.foo == A
    a = A()
    assert isinstance(A.__dict__['foo'], roclassproperty)
    assert hasattr(a, 'foo')
    assert A.foo == A
    assert a.foo == A



# Generated at 2022-06-24 03:11:44.464886
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class mytestclass:
        def __init__(self):
            self.test_var = None

        @setterproperty
        def test_method(self, value):
            self.test_var = value

    mytestclass_instance = mytestclass()
    mytestclass_instance.test_method = 5
    assert mytestclass_instance.test_var == 5
    assert hasattr(mytestclass_instance, "test_method")



# Generated at 2022-06-24 03:11:52.169488
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.type = "A"

# Generated at 2022-06-24 03:12:00.740883
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class _lazytest(object):
        @lazyperclassproperty
        def value(cls):
            t = tuple(cls.__name__)
            print('in _lazytest.value')
            return t

    class _lazytest2(_lazytest):
        pass

    class _lazytest3(_lazytest):
        pass

    obj1 = _lazytest()
    obj2 = _lazytest2()
    obj3 = _lazytest3()
    assert obj1.value is obj1.value
    assert obj1.value is not obj2.value
    assert obj2.value is not obj3.value
    assert obj1.value is not obj3.value



# Generated at 2022-06-24 03:12:06.306520
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self): self.x = 1
        @setterproperty
        def a(self, value):
            self.x = value
    
    c = C()
    c.a = 2
    assert c.x == 2
    assert c.a == 2 # fails, because @setterproperty does not define a getter



# Generated at 2022-06-24 03:12:10.511746
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lazyclassproperty.__doc__ = 'lazy class property'
    class C(object):
        @lazyclassproperty
        def prop(cls):
            print("Calling func")
            return 1

    assert C.prop == 1
    # "Calling func" should be printed only once



# Generated at 2022-06-24 03:12:16.117212
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Create instances of the class class roclassproperty
    roclassproperty_instance_1 = roclassproperty('arg1')
    roclassproperty_instance_2 = roclassproperty('arg2')
    roclassproperty_instance_3 = roclassproperty('arg3')
    assert roclassproperty_instance_1.__get__('obj1', 'owner1') == 'arg1'
    assert roclassproperty_instance_2.__get__('obj1', 'owner1') == 'arg2'
    assert roclassproperty_instance_3.__get__('obj1', 'owner1') == 'arg3'


# Generated at 2022-06-24 03:12:23.178714
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Tests for method __set__
    """
    class A(object):
        myproperty = 3
        def __init__(self):
            pass
    @setterproperty
    def setter(self, value):
        self.myproperty = value
    a = A()
    a.setter = 5
    assert a.myproperty == 5


# Generated at 2022-06-24 03:12:27.466610
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class DummyClass(object):
        def __init__(self):
            self.a=1

    d = DummyClass()
    d.a = 2
    d.roclassproperty(2)

# Generated at 2022-06-24 03:12:33.252937
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class test:
        def __init__(self):
            self.a = 3

        @setterproperty
        def setter(self, val):
            self.a = val

    t = test()
    assert t.a == 3
    t.setter = 4
    assert t.a == 4

# Generated at 2022-06-24 03:12:40.830821
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def random_property(cls):
        return random.randint(1, 100)

    class Base():
        pass

    class A(Base):
        pass

    class B(Base):
        def __init__(self):
            pass

    Base.lazy = lazyperclassproperty(random_property)
    A.lazy = lazyperclassproperty(random_property)
    B.lazy = lazyperclassproperty(random_property)

    b = B()

    print(Base.lazy)
    print(Base.lazy)
    print(B.lazy)
    print(b.lazy)
    print(b.lazy)
    print(A.lazy)
    print(A.lazy)
    print(A.lazy)
    print(b.lazy)

# Generated at 2022-06-24 03:12:48.100283
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> class A(object):
    ...     @lazyclassproperty
    ...     def foo(cls):
    ...         print 'calculating for class %r' % cls.__name__
    ...         return sum(xrange(10))
    >>> A.foo
    calculating for class 'A'
    45
    >>> A.foo == A.foo
    True
    >>> class B(A):
    ...     pass
    >>> B.foo
    calculating for class 'B'
    45
    >>> A.foo == B.foo
    False
    >>> C = type('C', (A,), {'foo': lazyclassproperty(lambda cls: '42')})
    >>> C.foo
    '42'
    """
    pass


# Based on code from Django.

# Generated at 2022-06-24 03:12:54.364438
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def a(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def a(cls):
            return "B"

    assert A.a == "A", A.a
    assert B.a == "B", B.a


# Generated at 2022-06-24 03:12:57.651826
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def _helper(cls):
            return 1

        x = roclassproperty(_helper)

    assert A.x == 1
    a = A()
    assert a.x == 1
    assert a.x == 1



# Generated at 2022-06-24 03:13:00.925323
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test1:
        @lazyclassproperty
        def a(cls):
            return 1

    class Test2:
        @lazyclassproperty
        def a(cls):
            return 2

    assert Test1.a == 1
    assert Test2.a == 2


# Generated at 2022-06-24 03:13:02.453100
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def var(cls):
            return 1

        @lazyclassproperty
        def var1(cls):
            r

# Generated at 2022-06-24 03:13:07.526256
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:15.142084
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:17.736951
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Cls:
        @roclassproperty
        def method(cls):
            return cls

    assert Cls.method is Cls
    assert Cls().method is Cls


# Generated at 2022-06-24 03:13:24.081333
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def __set__(self, value):
        if value >= 5:
            print('Value must be less than 5')
        else:
            self._value = value


    class Foo(object):
        _value = 0

        bar = setterproperty(__set__)


    f = Foo()
    f.bar = 10
    print(f._value)



# Generated at 2022-06-24 03:13:29.739930
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestCase:
        def __init__(self,value):
            self.__value = value

        @setterproperty
        def setvalue(self,value):
            self.__value = value

        @property
        def value(self):
            return self.__value

    test_value = 5
    t = TestCase(test_value)
    assert t.value == test_value
    t.setvalue = 7
    assert t.value == 7


# Generated at 2022-06-24 03:13:37.684573
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # ensure that lazy properties are properly created and stored in separate slots
    class A(object):
        @lazyperclassproperty
        def test1(cls):
            return 'A.test1'

    class B(A):
        @lazyperclassproperty
        def test1(cls):
            return 'B.test1'

    class C(A):
        @lazyperclassproperty
        def test2(cls):
            return 'C.test2'

    class D(B,C):
        @lazyperclassproperty
        def test2(cls):
            return 'D.test2'

    assert A.test1 == 'A.test1'
    assert B.test1 == 'B.test1'
    assert C.test2 == 'C.test2'

# Generated at 2022-06-24 03:13:40.920778
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            self._x = value

    obj = Obj(1)
    assert obj.x == 1
    obj.x = 2
    assert obj.x == 2



# Generated at 2022-06-24 03:13:44.976373
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def __init__(self):
            self.x = None

        @setterproperty
        def setterproperty(self, value):
            self.x = value

    c = C()
    assert c.x is None

    c.setterproperty = 2
    assert c.x == 2

# Generated at 2022-06-24 03:13:47.943510
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def name(cls):
            return 'Name'

        @classmethod
        def get_name(cls):
            return cls.name

    assert A.name == A.get_name()


# Generated at 2022-06-24 03:13:52.696782
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test_setterproperty_class:
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, value):
            self.a = value

    o = test_setterproperty_class()
    o.a = 1
    assert o.a == 1


if __name__ == '__main__':
    test_setterproperty()