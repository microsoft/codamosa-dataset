

# Generated at 2022-06-24 03:03:54.751837
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 'x'
        @classproperty
        def y(cls):
            return 'y'
        @lazyclassproperty
        def z(cls):
            return 'z'
    assert A.x == 'x'
    assert A.y == 'y'
    assert A.z == 'z'
    A.z = 'foo'
    assert A.z == 'foo'

test_roclassproperty()


# Generated at 2022-06-24 03:03:58.878307
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("Calculate Foo.bar")
            return "This is Foo.bar"

    class Bar(Foo):
        pass

    print(Foo.bar)
    print(Bar.bar)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-24 03:04:06.873281
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def b(self):
            pass

    assert set(dir(roclassproperty(A.b))) == {'__get__'}

    assert roclassproperty(A.b).__get__.__name__ == '__get__'
    assert roclassproperty(A.b).__get__.__doc__ == 'Return the attribute of the object associated with this access.'

    a = A()
    assert roclassproperty(A.b).__get__(a, type(a)) is A.b



# Generated at 2022-06-24 03:04:13.477522
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, n):
            self.n = n

        def set_n(self, n):
            self.n = n

    n = 10.0
    t = Test(n)

    assert t.n == n
    t.n = 5.0
    assert t.n == 5.0
    t.set_n = setterproperty(Test.set_n)
    t.set_n = 10.0
    assert t.n == 10.0


# Generated at 2022-06-24 03:04:23.799037
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest

    class Test1(object):
        @lazyperclassproperty
        def attr(cls):
            return 'ATTR'

    class Test2(Test1):
        pass

    class Test3(Test2):
        pass

    class Test4(Test2):
        @lazyperclassproperty
        def attr(cls):
            return 'ATTR_MODIFIED'

    class LazyPerClassPropertyTest(unittest.TestCase):
        def test_lazyperclassproperty(self):
            self.assertEqual('ATTR', Test1.attr)
            self.assertEqual(Test1.attr, Test2.attr)
            self.assertEqual(Test1.attr, Test3.attr)
            self.assertEqual('ATTR_MODIFIED', Test4.attr)


# Generated at 2022-06-24 03:04:32.511109
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    called_times = 0
    class A(object):
        @lazyperclassproperty
        def x(self):
            nonlocal called_times
            called_times += 1
            return called_times
    class B(A):
        @lazyperclassproperty
        def x(self):
            nonlocal called_times
            called_times += 1
            return called_times
    class C(B):
        @lazyperclassproperty
        def x(self):
            nonlocal called_times
            called_times += 1
            return called_times

    a = A()
    b = B()
    c = C()

    assert a.x == 1
    assert b.x == 2
    assert C.x == 3
    assert b.x == 2
    assert c.x == 3



# Generated at 2022-06-24 03:04:37.984543
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Setup
    class TestClass:
        value = 3
        @setterproperty
        def setterproperty(self, value):
            self.value = value

    # Exercise
    obj = TestClass()
    obj.setterproperty = 5

    # Verify
    assert obj.value == 5


# Generated at 2022-06-24 03:04:41.377068
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def __init__(self, x):
            self.a = x

    class B(A):
        @roclassproperty
        def roclassa(cls):
            return cls.a

    a = A(2)

# Generated at 2022-06-24 03:04:43.910327
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def value(cls):
            return cls.__name__

    assert A("mika").value == "mika"
    assert A.value == "A"



# Generated at 2022-06-24 03:04:48.154537
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def prop(cls):
            print("calculating")
            return 'the result'

    class D(C):
        pass

    assert C.prop == 'the result'
    assert D.prop == 'the result'



# Generated at 2022-06-24 03:04:52.969079
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self._a = 'a'

        @roclassproperty
        def a(self):
            return self._a

    assert A.a == 'a'



# Generated at 2022-06-24 03:04:57.549992
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def s(self, value):
            self.a = value + 10

    a = A()
    for value in (1, 2, 3):
        a.s = value
        assert a.a == 10 + value


# Generated at 2022-06-24 03:05:04.428943
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):

        @lazyclassproperty
        def foo_lazy(cls):
            print('foo_lazy')
            return 1

        @lazyclassproperty
        def foo_lazy2(cls):
            print('foo_lazy2')
            return 2

    assert Foo.foo_lazy == 1, "test_lazyclassproperty failed"
    assert Foo.foo_lazy == 1, "test_lazyclassproperty failed"
    assert Foo.foo_lazy2 == 2, "test_lazyclassproperty failed"



# Generated at 2022-06-24 03:05:08.278182
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:05:11.694402
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Person:
        name = roclassproperty(lambda cls: 'Person')
        age = roclassproperty(lambda cls: 30)

    print(Person.name)  # Person
    print(Person.age)  # 30



# Generated at 2022-06-24 03:05:20.208289
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):

        @lazyperclassproperty
        def attr1(self):
            return object()

    class B(A):
        pass

    a = A()
    b = B()
    c = A()
    d = B()

    assert a.attr1 is a.attr1
    assert b.attr1 is b.attr1
    assert c.attr1 is c.attr1
    assert d.attr1 is d.attr1

    assert a.attr1 is not b.attr1
    assert a.attr1 is not c.attr1
    assert a.attr1 is not d.attr1

    assert b.attr1 is not c.attr1
    assert b.attr1 is not d.attr1

    assert c.attr1 is not d.attr1



# Generated at 2022-06-24 03:05:21.891078
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def f(cls):
            return 1

    assert A.f == 1


# Generated at 2022-06-24 03:05:25.322314
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Example(object):
        def __init__(self):
            self._a = 0
            
        @setterproperty
        def a(self, value):
            self._a = value
            return self._a
            
    ex = Example()
    assert(ex.a == 0)
    ex.a = 1
    assert(ex.a == 1)



# Generated at 2022-06-24 03:05:28.427710
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'spam'

    # Method __get__ works as expected
    A.__dict__['foo'].__get__(None, cls=A)
    # foo.__get__(None, A)
    # >>> 'spam'



# Generated at 2022-06-24 03:05:35.525311
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # https://raw.githubusercontent.com/python/cpython/master/Lib/test/test_descrtut.py

    class C(object):
        def getx(cls):
            return 1
        x = roclassproperty(getx)

    class D(C):
        pass

    assert C.x == 1
    try:
        C.x = 2
    except AttributeError:
        pass
    else:
        raise AssertionError
    try:
        del C.x
    except AttributeError:
        pass
    else:
        raise AssertionError

    assert D.x == 1


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:05:43.058928
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self):
            self.b_value = 'b'

        @roclassproperty
        def a(cls):
            return 'a'

        @roclassproperty
        def b(cls):
            return cls.b_value

    a = A()
    assert isinstance(A.a, str)
    assert A.a == 'a'
    assert A.b == 'b'
    A.a = 'b'
    assert isinstance(A.a, str)
    assert A.a == 'a'
    assert A.b == 'b'
    A.b = 'a'
    assert A.a == 'a'
    assert A.b == 'b'


# Generated at 2022-06-24 03:05:48.725413
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        @setterproperty
        def x(self, value):
            self._x = value

    foo = Foo()
    foo.x = 42
    assert foo._x == 42


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:05:52.173226
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(self):
            return 'a'

    assert A.a == 'a'
    a1 = A()
    a2 = A()
    assert a1.a == 'a'
    assert a2.a == 'a'



# Generated at 2022-06-24 03:05:55.782919
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Example(object):
        def __init__(self, f):
            self.f = f

        def __get__(self, obj, owner):
            return self.f(owner)

    assert Example is roclassproperty


# Generated at 2022-06-24 03:06:02.065936
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """
    # Simple test for setterproperty
    class TestClass(object):
        def __init__(self):
            self.value = None

        def value_setter(self, value):
            self.value = value

        value = setterproperty(value_setter)

    test_obj = TestClass()
    test_obj.value = 1
    assert test_obj.value == 1

# Generated at 2022-06-24 03:06:10.452116
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    method __set__ of class setterproperty
    """
    num_tests = 1
    def test_setterproperty___set__001(self):
        class TestSetterProperty__Set__(object):
            new_value = 3
            @setterproperty
            def value(self, value):
                assert self.new_value == value

        t = TestSetterProperty__Set__()
        t.value = t.new_value
    # Add test here
    # test_setterproperty___set__001(self)
    # Unit test for method __doc__ of class setterproperty
    def test_setterproperty___doc__():
        num_tests = 0

# Generated at 2022-06-24 03:06:16.298556
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class ClassA(object):
        @roclassproperty
        def fun(cls):
            cls.b='ttttt'
            return 'ttttt'
        @classproperty
        def fun2(cls):
            cls.a = 'xxxxx'
            return 'xxxxx'

    ClassA.fun


# Generated at 2022-06-24 03:06:25.630572
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class Test(object):
        val = 10

        @property
        def score(self):
            return self.val * 3

        @score.setter
        def score(self, value):
            self.val = value

        @classproperty
        def test(cls):
            return cls.val

        def __repr__(self):
            return 'Test(%s)' % self.val

    t = Test()
    Test.test = "Test"
    print(t.score)
    print(t.test)
    print(Test.test)
    print(t)
    t.score = 10
    print(t.score)
    print(t.test)
    print(Test.test)
    print(t)
    Test.test = "Test"
    print(t.score)

# Generated at 2022-06-24 03:06:31.252506
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def foo(cls):
            return "bar"

    assert Test.foo == "bar"
    try:
        Test.foo = "baz"
    except AttributeError as e:
        pass
    else:
        assert False, "Test.foo should not be writable"



# Generated at 2022-06-24 03:06:37.307601
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Tests lazyperclassproperty function.
    """

    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 2

    class D(A):
        pass

    assert(A.prop == B.prop == D.prop == 1)
    assert(C.prop == 2)

# Generated at 2022-06-24 03:06:45.936092
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class X(object):
        a = roclassproperty(lambda cls: cls('A'))
        b = roclassproperty(lambda cls: cls('B'))

        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

    x = X()
    assert x.a == 'A'
    assert x.b == 'B'

    assert X.a == 'A'
    assert X.b == 'B'

    try:
        X.a = 'Z'
    except Exception as e:
        assert type(e) == AttributeError

    try:
        x.a = 'Z'
    except Exception as e:
        assert type(e) == AttributeError



# Generated at 2022-06-24 03:06:48.751098
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class A:

        def get_x(self):
            return self.x

        def set_x(self, value):
            self.x = value

        x = setterproperty(set_x)

    a = A()
    a.x = 1
    assert(a.x == 1)



# Generated at 2022-06-24 03:06:53.736880
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Vector:
        def __init__(self, x, y):
            self.x, self.y = x, y

        # TODO TEST ME!
        @setterproperty
        def magnitude(self, magnitude):
            vx, vy = (self.x ** 2 + self.y ** 2) ** .5, 0
            ratio = magnitude / vx
            self.x, self.y = self.x * ratio, self.y * ratio

    assert Vector(3, 4).magnitude == 5

# Generated at 2022-06-24 03:06:59.178869
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def x(self):
            print("Init Base.x")
            return 10

    class Derived(Base):
        @lazyperclassproperty
        def x(self):
            print("Init Derived.x")
            return 20

    class BadDerived(Base):
        @lazyperclassproperty
        def x(self):
            print("Init BadDerived.x")
            return 20

        @lazyperclassproperty
        def y(self):
            print("Init BadDerived.y")
            return 30

    print("Base.x = %d" % Base.x)
    print("Base.x = %d" % Base.x)
    print("Derived.x = %d" % Derived.x)

# Generated at 2022-06-24 03:07:04.741185
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        @setterproperty
        def c(self, value):
            self.a = 10
            self.b = value
            return self.b

    test = Test()
    assert test.c == 2
    assert test.b == 2
    assert test.a == 1

    test.c = 100
    assert test.c == 100
    assert test.b == 100
    assert test.a == 10

if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:07:09.252905
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def list_of_three(cls):
            print("Creating list_of_three.")
            return [1, 2, 3]

    assert Test.list_of_three is Test.list_of_three
    assert Test.list_of_three is not [1, 2, 3]
    assert Test.list_of_three == [1, 2, 3]



# Generated at 2022-06-24 03:07:13.319236
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    def class_roproperty(cls):
        return "I am class {0}".format(cls)

    class Base(object):
        class_roproperty = roclassproperty(class_roproperty)

    class Sub(Base):
        pass

    assert Base.class_roproperty == 'I am class <class \'base.Base\'>'
    assert Sub.class_roproperty == 'I am class <class \'base.Sub\'>'

# Generated at 2022-06-24 03:07:19.623025
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Here we need to test that the class property is not cached when accessed
    # via the class and that it is cached when accessed via an instance.

    class A(object):
        def __init__(self, n_calls):
            self.n_calls = n_calls

        @lazyclassproperty
        def n_calls(cls):
            return 0

    assert A.n_calls == 0
    assert A.n_calls == 0  # Should not have increased.
    a = A(0)
    assert a.n_calls == 0
    assert a.n_calls == 0  # Should not have increased.
    assert A.n_calls == 0



# Generated at 2022-06-24 03:07:22.767921
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Compute(object):
        def __init__(self):
            self.value = 0

        @setterproperty
        def value(self, v):
            self._value = v ** 2

    compute = Compute()
    compute.value = 5
    assert compute._value == 25


# Generated at 2022-06-24 03:07:27.769096
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 'A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            return 'C'

    assert A.prop == 'A'
    assert B.prop == 'A'
    assert C.prop == 'C'


# Generated at 2022-06-24 03:07:31.876504
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class A(object):
        def __init__(self, name):
            self._name = name

        def set_name(self, name):
            self._name = name

        name = setterproperty(set_name)

    a = A("Jacques")
    assert(a.name is None)
    a.name = "Janet"
    assert(a._name == "Janet")

# Generated at 2022-06-24 03:07:39.380539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def b(cls):
            return 1

        @lazyclassproperty
        def c(cls):
            return 2

    class B(A):
        @lazyclassproperty
        def b(cls):
            return 3

    assert A.b == 1
    assert A.c == 2
    assert B.b == 3
    assert B.c == 2
    assert A.b == 1



# Generated at 2022-06-24 03:07:45.917594
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, val):
            self.__val = val

        @setterproperty
        def double(self, value):
            self.__val = value * 2

        @property
        def val(self):
            return self.__val

    t1 = Test(3)
    assert t1.val == 3
    t1.double = 7
    assert t1.val == 14

# Generated at 2022-06-24 03:07:49.033482
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class ValueHolder(object):
        @roclassproperty
        def some_value(cls):
            return "This is some value"
    assert ValueHolder.some_value == "This is some value"
  

# Generated at 2022-06-24 03:07:52.127812
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class AbstractBase(object):
        @lazyperclassproperty
        def _foo(cls):  # noqa
            return object.__new__(cls)

    class ConcreteDerived(AbstractBase):
        pass

    class ConcreteDerived2(AbstractBase):
        pass

    assert AbstractBase._foo is not ConcreteDerived._foo
    assert AbstractBase._foo is not ConcreteDerived2._foo
    assert ConcreteDerived._foo is not ConcreteDerived2._foo



# Generated at 2022-06-24 03:07:57.224480
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        property = lazyperclassproperty(lambda cls: cls.__name__)

    class Test2(Test):
        pass

    assert Test.property == 'Test' == Test2.property



# Generated at 2022-06-24 03:08:00.765308
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            "I am the 'x' property."
            self._x = value

    print(C.x.__doc__)

# Generated at 2022-06-24 03:08:07.948138
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        i = 1

        @lazyperclassproperty
        def j(cls):
            cls.i = cls.i + 1
            return cls.i

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()


# Generated at 2022-06-24 03:08:11.108646
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return id(cls)

    class B(A):
        pass

    class C(A):
        pass


# Generated at 2022-06-24 03:08:18.081442
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    setterproperty.__set__
    """

    # Check that setterproperty.__set__ captures their value properly
    class Foo:
        @setterproperty
        def foo(self, value):
            self.foo = value

    foo = Foo()
    foo.foo = 22
    assert foo.foo == 22



# Generated at 2022-06-24 03:08:21.689776
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @classproperty
        def prop(cls):
            return 'value'

    c = C()

# Generated at 2022-06-24 03:08:22.517546
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    pass


# Generated at 2022-06-24 03:08:29.211293
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TempClass(object):
        def __init__(self):
            self.x = None

        @lazyperclassproperty
        def static_get_x(cls):
            print("Calculating static_get_x")
            return 1

        @lazyperclassproperty
        def static_get_y(cls):
            print("Calculating static_get_y")
            return 2

        @lazyperclassproperty
        def static_get_z(cls):
            print("Calculating static_get_z")
            return 3

    class TempClass2(TempClass):
        def __init__(self):
            self.x = None

        @lazyperclassproperty
        def static_get_x(cls):
            print("Calculating static_get_x")
            return 4

       

# Generated at 2022-06-24 03:08:31.925995
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 15

    print('# Unit test for constructor of class roclassproperty')
    print(A.x)


# Generated at 2022-06-24 03:08:36.568751
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            self.__x = value

        @property
        def x(self):
            return self.__x

    obj = TestClass()
    obj.x = 'hello'
    if obj.x != 'hello':
        raise AssertionError("Setter property does not work.")

# Generated at 2022-06-24 03:08:41.354235
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass:
        passed = False

        def __init__(self):
            self.x = roclassproperty(lambda cls: cls.passed)

    obj = MyClass()
    assert not obj.x

    MyClass.passed = True
    assert obj.x


# Generated at 2022-06-24 03:08:46.159151
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('calculating')
            return 'bar'

    assert hasattr(Foo, '_lazy_bar')

    print('creating instances')
    a = Foo()
    b = Foo()

    print('asserting')
    assert a.bar == b.bar
    assert Foo.bar == 'bar'

    print('asserting cached')
    assert a.bar == b.bar
    assert Foo.bar == 'bar'



# Generated at 2022-06-24 03:08:49.933004
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazy(self):
            print ("Foo")
            return 1

    class B(A):
        pass

    assert A.lazy == 1
    assert B.lazy == 1


# Generated at 2022-06-24 03:08:52.465234
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass1(object):
        @lazyclassproperty
        def constant(cls):
            print ("Constant called")
            return 1


# Generated at 2022-06-24 03:08:59.486206
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """
    class B(object):
        def __init__(self, value):
            self._hidden_value = value

        @setterproperty
        def public(self, value):
            self._hidden_value = value

    b = B(1)
    assert b.public == b._hidden_value
    assert b.public == 1
    b.public = 2
    assert b.public == b._hidden_value
    assert b.public == 2
    assert b._hidden_value == 2


if __name__ == "__main__":
    test_setterproperty___set__()
    print('Tests Successful...')

# Generated at 2022-06-24 03:09:01.553371
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass:
        def __init__(self):
            pass

        @roclassproperty
        def prop_ro(self):
            return 'test'

    t1 = TestClass()
    t2 = TestClass()
    TestClass.prop_ro

# Generated at 2022-06-24 03:09:07.244511
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestUnit:
        @lazyclassproperty
        def cal1(cls):
            return 1
    assert TestUnit.cal1 == 1
    TestUnit.cal1 = 2
    assert TestUnit.cal1 == 2


# Generated at 2022-06-24 03:09:10.190222
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def answer(cls):
            return 42

    assert Test.answer == 42



# Generated at 2022-06-24 03:09:13.498535
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        _s = 5

        @roclassproperty
        def val(self):
            return A._s

    assert A.val == 5
    assert isinstance(A.val, int)



# Generated at 2022-06-24 03:09:20.992878
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        pass

    @lazyperclassproperty
    def attr(cls):
        return cls.__name__ + '_attr_value'

    assert Test.attr == 'Test_attr_value'
    Test.attr = 'Test_attr_fake_value'
    assert Test.attr == 'Test_attr_value'
    assert Test.__setattr__('attr', 'Test_attr_fake_value') == 'Test_attr_value'
    assert Test.attr == 'Test_attr_value'



# Generated at 2022-06-24 03:09:25.180287
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        _x = 0

        @setterproperty
        def x(self, value):
            self._x = value

    a = A()
    assert a.x is 0
    a.x = 3
    assert a._x is 3

# Generated at 2022-06-24 03:09:27.769030
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            return "foo"

    class Bar(Foo):
        pass

    test = Bar()
    assert(test.foo == "foo")



# Generated at 2022-06-24 03:09:31.755315
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def name(cls):
            return cls.__name__

    class Test2(Test):
        pass

    assert Test.name == 'Test'
    assert Test2.name == 'Test2'


# Generated at 2022-06-24 03:09:39.524824
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import numpy as np

    class A(object):
        def __init__(self):
            self.a = np.array([1, 2, 3, 4])
            self.b = np.array([10, 20, 30, 40])

        @classmethod
        def set_a_and_b(cls, data):
            print(cls)
            print(data)
            cls.b = np.array([10, 20, 30, 40])

        def set_new_data(self, data):
            self.a = data

        new_data = setterproperty(set_new_data)

        @setterproperty
        def new_data(self, data):
            self.a = data

        @classproperty
        def class_b(cls):
            return cls.b


# Generated at 2022-06-24 03:09:49.163523
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class P1(object):
        @roclassproperty
        def first(cls):
            return 1

        @property
        def second(self):
            return 2

    class P2(P1):
        @roclassproperty
        def third(cls):
            return 3

        @property
        def fourth(self):
            return 4

    # Testing class properties
    assert P1.first == 1
    assert P2.first == 1
    assert P2.third == 3
    # Calling property as a class method
    assert P2.first() == 1
    assert P2.third() == 3

    # Testing instance properties
    p1 = P1()
    p2 = P2()
    assert p1.second == 2
    assert p2.second == 2
    assert p2.fourth == 4
    # Calling property as

# Generated at 2022-06-24 03:09:55.216574
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    import sys
    class A(object):
        @lazyperclassproperty
        def version(cls):
            return sys.version_info
        
    class B(A):
        pass

    assert A.version is not B.version

# Unit tests for descriptors

# Generated at 2022-06-24 03:10:01.517200
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        def __init__(self):
            pass

        @lazyclassproperty
        def first(cls):
            print('first')
            return 1

    class B(A):
        pass

    class C(B):
        pass

    a = A()
    b = B()
    c = C()

    a.first
    b.first
    c.first

    assert a.first == b.first == c.first



# Generated at 2022-06-24 03:10:03.233891
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        x = 0

        @setterproperty
        def y(self, value):
            self.x = value

    c = C()
    c.y = 1
    assert c.x == 1



# Generated at 2022-06-24 03:10:11.962456
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    '''
    class Test():
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, val):
            self.__dict__['a'] = val

        @setterproperty
        def b(self):
            return 1
    '''

    class Test(object):
        def __init__(self):
            self._a = 1

        @property
        def a(self):
            print("a get")
            return self._a

        def __set__(self, instance, value):
            print("my __set__")

        @a.setter
        def a(self, val):
            print("a set")
            self._a = val

        @property
        def b(self):
            print("b get")
            return 1

    instance = Test()

# Generated at 2022-06-24 03:10:16.282568
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def foo(self, value):
            self.value_f = value

    a = A()
    a.foo = 7
    assert  a.value_f == 7


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:10:21.924632
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass1(object):
        def f(cls):
            return cls.__name__

        @roclassproperty
        def name(cls):
            return f(cls)

    class MyClass2(MyClass1):
        pass

    for cls in [MyClass1, MyClass2]:
        assert cls.name == cls.__name__
        assert cls.name == cls.__name__

    try:
        MyClass1.name = "Changing name"
    except:
        pass
    else:
        raise AssertionError("roclassproperty.__set__ should raise an exception")



# Generated at 2022-06-24 03:10:25.087469
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Car(object):
        def __init__(self, color):
            self.color = color

        @roclassproperty
        def color(cls):
            return cls.__name__

    c = Car(color='Red')
    assert c.__class__.__name__ == 'Car'
    assert c.__class__.color == c.__class__.__name__

# Generated at 2022-06-24 03:10:35.427464
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 6

        @setterproperty
        def a(self, value):
            if value == 3:
                return 7
            else:
                self._a = value

    a = A()
    try:
        a.a = 4
    except:
        assert False, 'test_setterproperty___set__: test #1 has failed'
    else:
        assert a._a == 4, 'test_setterproperty___set__: test #1 has failed'

    try:
        a.a = 3
    except:
        assert False, 'test_setterproperty___set__: test #2 has failed'
    else:
        assert a._a == 4, 'test_setterproperty___set__: test #2 has failed'

# Generated at 2022-06-24 03:10:37.392583
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def u(cls):
            return cls.__name__

    assert A.u == "A"


# Generated at 2022-06-24 03:10:46.079172
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class C(object):
        @lazyclassproperty
        def y(cls):
            return 42
        @lazyclassproperty
        def z(cls):
            return 42 + 6

    class D(C):
        @lazyclassproperty
        def z(cls):
            return 100

    class E(D):
        pass

    class Test(unittest.TestCase):
        def test_lazyclassproperty(self):
            self.assertEquals(C.y, 42)
            self.assertEquals(D.y, 42)
            self.assertEquals(C.z, 48)
            self.assertEquals(D.z, 100)
            self.assertEquals(E.y, 42)
            self.assertEquals(E.z, 100)

# Generated at 2022-06-24 03:10:48.301462
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):

        @roclassproperty
        def bar(cls):
            '''baz'''

    assert Foo.bar.__doc__ == 'baz'



# Generated at 2022-06-24 03:10:53.132777
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        class_attribute = setterproperty(lambda self, value: setattr(C, 'class_attribute', value))

    assert not hasattr(C, 'class_attribute')

    C.class_attribute = 'A'
    assert C.class_attribute == 'A'

    C.class_attribute = 'B'
    assert C.class_attribute == 'B'



# Generated at 2022-06-24 03:10:56.843143
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class S(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def prop(self, value):
            self.x = value

    s = S(0)

    assert s.x == 0
    s.prop = 20
    assert s.x == 20



# Generated at 2022-06-24 03:10:58.432291
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return "hello"

    assert Foo.foo == "hello"



# Generated at 2022-06-24 03:11:01.496487
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self.x = 'foo'

        @setterproperty
        def foo(self, value):
            self.x = value

    c = C()
    assert c.x == 'foo'
    c.foo = 'bar'
    assert c.x == 'bar'



# Generated at 2022-06-24 03:11:08.010725
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SetterPropertyTestCase(unittest.TestCase):
        def setUp(self):
            self.instance = self.object = self.cls = self.dummy = None

        def test_setterproperty___set__(self, instance=None, object=None, cls=None, dummy=None):
            """Setter property should call the method from object correctly."""
            self.instance, self.object, self.cls, self.dummy = instance, object, cls, dummy
            p = setterproperty(self._setterproperty_callback)

            with Stub(self, '_setterproperty_callback') as _setterproperty_callback:
                p.__set__(instance, object)

            _setterproperty_callback.assert_called_once_with(instance, object, cls)


# Generated at 2022-06-24 03:11:10.322490
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'

    class B(A):
        pass

    assert B.foo == 'foo'

# Generated at 2022-06-24 03:11:18.013741
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Example(object):
        def __init__(self):
            self.x = 'This is x'
            self.y = 'This is y'

        @setterproperty
        def x(self, value):
            self._x = value

    example = Example()

    assert example.x == 'This is x' and example.y == 'This is y'

    example.x = 'This is changed x'

    assert example.x == 'This is changed x' and example.y == 'This is y'



# Generated at 2022-06-24 03:11:24.077375
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 42

    class B(A):
        pass
    assert A.test == 42
    assert B.test == 42
    A.test = -1
    assert A.test == -1
    assert B.test == 42


# Generated at 2022-06-24 03:11:26.321469
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class X(object):
        @setterproperty
        def a(self, value):
            self._a = value

    x = X()
    x.a = 3
    assert x._a == 3



# Generated at 2022-06-24 03:11:36.655111
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test lazyperclassproperty
    
    It should return the same instance for each class without inheritance
    and a new instance for each child class.
    """
    class A(object):
        @lazyperclassproperty
        def f(cls):
            return cls
    
    class B(A):
        pass
        
    class C(B):
        pass
    
    assert A.f is A
    assert B.f is B
    assert C.f is C
    
    assert A.f is not B.f
    assert B.f is not C.f
    assert A.f is not C.f
    assert A.f is not A()
    
    
    
    
    
    
    
    
    
# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-24 03:11:41.535673
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def base_prop(cls):
            return 'base'

    class Derived(Base):
        @lazyperclassproperty
        def base_prop(cls):
            # base_prop is different, but with the same name
            return 'derived'

    assert Base.base_prop == 'base'
    assert Derived.base_prop == 'derived'

# Generated at 2022-06-24 03:11:45.146712
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        @lazyclassproperty
        def test(cls):
            print("I must do something complicated")
            return 5
    assert A.test == 5
    from time import sleep
    sleep(0.2)
    assert A.test == 5

    class B:
        @lazyclassproperty
        def test(cls):
            print("I must do something complicated")
            return 5
    assert B.test == 5
    assert A.test == 5


# Generated at 2022-06-24 03:11:46.350030
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Class:
        @roclassproperty
        def number(cls):
            return 42

    assert Class.number == 42
    assert Class.number == 42
    # test_roclassproperty___get__()


# Generated at 2022-06-24 03:11:53.380831
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Dog:
        def _get_name(cls):
            return cls.__name__
        name = roclassproperty(_get_name)
        def _get_sound(cls):
            return 'Woof!'
        sound = roclassproperty(_get_sound)

    class Chihuahua(Dog):
        pass

    assert Dog.name == 'Dog'
    assert Chihuahua.name == 'Chihuahua'
    try:
        Dog().name
        raise RuntimeError('Expected AttributeError')
    except AttributeError:
        pass

# Generated at 2022-06-24 03:12:00.992198
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        x = lazyclassproperty(lambda cls: 'x')
        y = lazyclassproperty(lambda cls: 'y')

    assert A.x == 'x'
    assert A.y == 'y'
    assert A.y == 'y'

    class B(A):
        def __init__(self):
            self.x = lazyclassproperty(lambda cls: 'x')
            self.y = lazyclassproperty(lambda cls: 'y')

    assert B.x == 'x'
    assert B.y == 'y'
    assert B().x == 'x'
    assert B().y == 'y'



# Generated at 2022-06-24 03:12:06.340930
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.say = "Hello"
        @setterproperty
        def mysetter(self, value):
            self.say = value

    c = C()
    assert c.say == "Hello"
    c.mysetter = "World!"
    assert c.say == "World!"


# Generated at 2022-06-24 03:12:12.511426
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    class C(B):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'
    assert C.foo == 'foo'

    A.foo = 'bar'

    assert A.foo == 'bar'
    assert B.foo == 'foo'
    assert C.foo == 'foo'


# Generated at 2022-06-24 03:12:15.155258
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def setter(self, value):
            self.value = value

        attr = setterproperty(setter, doc='setter property')

    a = A()

    a.attr = 1

    assert a.value == 1



# Generated at 2022-06-24 03:12:25.076271
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class S(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if value < 0:
                self._x = 0
            elif value > 1000:
                self._x = 1000
            else:
                self._x = value

        @property
        def x(self):
            return self._x

    s = S()
    s.x = 5
    assert s._x == 5
    s.x = -1
    assert s._x == 0
    s.x = 1500
    assert s._x == 1000


# Generated at 2022-06-24 03:12:27.600272
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo.bar == 'bar'



# Generated at 2022-06-24 03:12:38.190361
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Main1(object):
        @lazyperclassproperty
        def foo(cls):
            return 'bar'

    class Main2(Main1):
        pass

    class Main3(Main1):
        @lazyperclassproperty
        def foo(cls):
            return 'baz'

    assert Main1.foo == 'bar'
    assert Main2.foo == 'bar'
    assert Main3.foo == 'baz'
    assert Main1().foo == 'bar'
    assert Main2().foo == 'bar'
    assert Main3().foo == 'baz'

    Main1.foo == 'bar'
    Main2.foo == 'bar'
    Main3.foo == 'baz'
    Main1().foo == 'bar'
    Main2().foo == 'bar'

# Generated at 2022-06-24 03:12:42.926404
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            print('foo is called')
            return cls

    a = A()
    print(a.foo)
    print(a.foo is A)


# Generated at 2022-06-24 03:12:46.614148
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def bar(cls):
            print('Computing bar')
            return 42

    assert Foo.bar == 42
    assert Foo.bar == 42
    assert Foo.bar == 42

    class Baz(Foo):
        @lazyclassproperty
        def bar(cls):
            print('Computing baz')
            return 100500

    assert Baz.bar == 100500
    assert Baz.bar == 100500
    assert Baz.bar == 100500

    assert Foo.bar == 42
    assert Foo.bar == 42



# Generated at 2022-06-24 03:12:55.006229
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def my_prop(cls):
            return random.randint(1, 100)

    class B(A):
        pass

    class C(A):
        pass

    assert A.my_prop == B.my_prop
    assert A.my_prop != C.my_prop
    assert B.my_prop != C.my_prop



# Generated at 2022-06-24 03:12:58.990675
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass:
        @lazyperclassproperty
        def value(cls):
            return cls.__name__

    class Inheritor(BaseClass):
        """ Inheritor class """

    print("BaseClass.value '{}'".format(BaseClass.value))
    print("Inheritor.value '{}'".format(Inheritor.value))



# Generated at 2022-06-24 03:13:01.784911
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        _prop = 17
        @roclassproperty
        def prop(cls):
            return cls._prop

    class B(A):
        _prop = 43

    assert A.prop == 17
    assert B.prop == 43



# Generated at 2022-06-24 03:13:04.644582
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(self):
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo().bar == 'bar'



# Generated at 2022-06-24 03:13:11.496108
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    C=type('C', (), {})
    C.a=roclassproperty(lambda c: 1)
    assert C.a == 1
    assert isinstance(C.a, int)
    assert C.a == 1
    try:
        C.a=3
        assert False, 'Was able to overrun read only property'
    except AttributeError as e:
        assert True
    try:
        assert C.a == 3
        assert False, 'Was able to overrun read only property'
    except AttributeError as e:
        assert True


# Generated at 2022-06-24 03:13:13.231906
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        x = roclassproperty(lambda cls: cls)

    assert A.x == A



# Generated at 2022-06-24 03:13:16.440394
# Unit test for constructor of class setterproperty
def test_setterproperty():
    from vumi.utils import setterproperty

    class Foo(object):
        _x = 1

        @setterproperty
        def x(self, v):
            self._x = v

    foo = Foo()
    foo.x = 2
    assert foo._x == 2

# Generated at 2022-06-24 03:13:23.328488
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test_roclassproperty(object):
        def __init__(self):
            self.prop = 'prop'

        @roclassproperty
        def prop(cls):
            return cls.__name__

        @classmethod
        def method(cls):
            return cls.__name__
    assert Test_roclassproperty.prop == 'Test_roclassproperty'
    assert Test_roclassproperty.method() == 'Test_roclassproperty'



# Generated at 2022-06-24 03:13:26.861220
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class test(object):
        i = setterproperty(lambda self, v: setattr(self, "_i", v))

    t = test()
    t.i = 2
    assert t._i == 2

# Generated at 2022-06-24 03:13:35.776043
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, data):
            self.data = data

        def get_data(self):
            return self.data

        def set_data(self, data):
            self.data = data

        @setterproperty
        def mydata(self):
            return self.get_data()

        @mydata.setter
        def mydata(self, data):
            self.set_data(data)

    foo = Foo(3)
    assert foo.get_data() == foo.mydata
    foo.mydata = 5
    assert foo.get_data() == foo.mydata

test_setterproperty()


# Generated at 2022-06-24 03:13:41.800648
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def f(cls):
            return cls.__name__
        x = roclassproperty(f)

    class B(A):
        pass

    assert A.x == 'A'
    assert B.x == 'B'


# Generated at 2022-06-24 03:13:47.034748
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # A test class
    class A(object):
        @lazyperclassproperty
        def name(cls):
            return cls.__name__
    # A second test class using inheritance
    class B(A):
        pass
    # A third test class using inheritance
    class C(A):
        pass
    assert A.name == 'A'
    assert B.name == 'B'
    assert C.name == 'C'

# Generated at 2022-06-24 03:13:51.808759
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo_val'

    class B(A):
        pass

    assert A.foo == 'foo_val'
    assert B.foo == 'foo_val'

    A.foo = 'bar'

    assert A.foo == 'bar'
    assert B.foo == 'foo_val'

