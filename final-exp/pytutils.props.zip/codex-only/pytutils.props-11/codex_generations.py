

# Generated at 2022-06-24 03:03:50.030557
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class TestClass(object):
        @lazyclassproperty
        def test_func(cls):
            """
            Some test function.
            """
            return "LazyClassPropertyTest"

    assert TestClass.test_func == "LazyClassPropertyTest"



# Generated at 2022-06-24 03:03:56.830901
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'
    class B(A):
        pass
    class C(A):
        @lazyclassproperty
        def x(cls):
            return 'y'
    a, b, c = A(), B(), C()
    assert a.x == b.x == 'x'
    assert c.x == 'y'
    assert A.x == 'x'
    assert B.x == 'x'
    assert C.x == 'y'
    a.x = 1
    assert a.x == 1
    assert b.x == 'x'
    assert c.x == 'y'
    b.x = 2
    assert a.x == 1
    assert b.x == 2

# Generated at 2022-06-24 03:04:07.217185
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @setterproperty
        def x(self, x):
            self.__x = x

        @setterproperty
        def y(self, y):
            self.__y = y

    t = Test(1, 2)
    assert t.x == 1
    assert t.y == 2  # This fails with TypeError: x property is read only

# Generated at 2022-06-24 03:04:12.850055
# Unit test for constructor of class roclassproperty
def test_roclassproperty():


    class A(object):
        b = "roclassproperty"


# Generated at 2022-06-24 03:04:23.760419
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    class BaseUnitTest(unittest.TestCase):
        def test_netid(self):
            self.assertEqual(Base.netid, 'Base')
        def test_derive_netid(self):
            self.assertEqual(Derive.netid, 'Derive')
        def test_derive2_netid(self):
            self.assertEqual(Derive2.netid, 'Derive2')
        def test_base_id(self):
            self.assertEqual(Base.perclass_id, 'Base')
        def test_derive_id(self):
            self.assertEqual(Derive.perclass_id, 'Derive')

# Generated at 2022-06-24 03:04:29.125683
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def test_prop(cls):
            return TestClass()

    assert TestClass.test_prop is TestClass.test_prop
    assert TestClass.test_prop is not TestClass.test_prop

if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-24 03:04:36.770526
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:04:41.168345
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass():
        def _my_setter(self, value):
            self._received = value
        testprop = setterproperty(_my_setter)

    o1 = MyClass()
    o1.testprop = 1
    assert o1._received == 1
    o2 = MyClass()
    o2.testprop = 2
    assert o2._received == 2
    assert not hasattr(o1, '_received')


# Generated at 2022-06-24 03:04:44.932138
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo(object):
        foo_var = lazyclassproperty(lambda c: 1)

    class bar(foo):
        bar_var = lazyclassproperty(lambda c: 2)

    assert foo.foo_var == 1
    assert bar.foo_var == 1
    assert bar.bar_var == 2

    foo.foo_var = 3
    bar.bar_var = 4

    assert foo.foo_var == 3
    assert bar.foo_var == 3
    assert bar.bar_var == 4

# Generated at 2022-06-24 03:04:50.853550
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    c1 = []
    c2 = []

    class C1(object):

        @lazyperclassproperty
        def list(cls):
            c1.append(cls)
            return []

    class C2(C1):
        pass

    class C3(C1):
        pass

    assert C1.list is C1.list is C1().list
    assert C2.list is C2.list is C2().list
    assert C3.list is C3.list is C3().list
    assert C2.list is not C1.list
    assert c1 == [C1, C3]
    assert c2 == []



# Generated at 2022-06-24 03:05:00.096625
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Test method __set__ of class setterproperty
    global classproperty
    global setterproperty
    global lazyperclassproperty
    global lazyclassproperty

    class C(object):
        def __init__(self):
            self._value = 2

        @setterproperty
        def value(self, x):
            self._value = x

        @classproperty
        def classvalue(cls):
            return 1

        @lazyclassproperty
        def lazyclassvalue(cls):
            return 1

        @lazyperclassproperty
        def lazyperclassvalue(cls):
            return 1

    class D(C):
        pass

    c1 = C()
    c2 = C()
    d1 = D()
    d2 = D()

    assert c1.value == 2
    assert c2.value == 2

# Generated at 2022-06-24 03:05:04.203900
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo():
        def __init__(self):
            self._hash = hash('default')

        @setterproperty
        def hash(self, value):
            self._hash = hash(value)

    assert Foo().hash == hash('default')
    foo = Foo()
    foo.hash = 'abc'
    assert foo.hash == hash('abc')

# Generated at 2022-06-24 03:05:07.757400
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def my_prop(cls):
            return "my_prop"

    class B(A):
        pass

    assert A.my_prop == B.my_prop
    assert A.__dict__["_A_lazy_my_prop"] == B.__dict__["_B_lazy_my_prop"]



# Generated at 2022-06-24 03:05:10.334249
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'A'

    assert A.a == 'A'



# Generated at 2022-06-24 03:05:14.021911
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class MyClass(object):
        @roclassproperty
        def roclassp(cls):
            return cls.__name__

    assert MyClass.roclassp == 'MyClass'
    assert MyClass().roclassp == 'MyClass'


# Generated at 2022-06-24 03:05:17.250213
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:
        def __init__(self):
            self.n = 0

        @setterproperty
        def n(self, n):
            self.n = n + 1
    t = Test()
    t.n = 3
    assert t.n == 4



# Generated at 2022-06-24 03:05:25.069663
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:05:32.759880
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.x = 5

        @roclassproperty
        def y(cls):
            return cls.x

    a = A()
    assert a.x == 5
    assert a.y == 5
    # test that roclassproperty raises error on setting x
    try:
        a.y = 10
    except AttributeError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 03:05:39.487232
# Unit test for constructor of class setterproperty
def test_setterproperty():
    property_name = '_test_property'

    class PropertyTest(object):
        @setterproperty
        def test_prop(self, val):
            setattr(self, property_name, val)

    p = PropertyTest()
    p.test_prop = 1
    assert (p.__dict__[property_name] == 1)



# Generated at 2022-06-24 03:05:43.728165
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class X(object):
        def __init__(self):
            self.var = 0
        @setterproperty
        def var(self, val):
            self.var = val
            return val+1
    x = X()
    print(x.var)
    print(x.var)


# Generated at 2022-06-24 03:05:50.156387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class MyBaseClass(object):
        @lazyperclassproperty
        def some_property(cls):
            return cls.__name__

    class MySubClass(MyBaseClass):
        pass

    assert MySubClass.some_property == 'MySubClass'
    assert MyBaseClass.some_property == 'MyBaseClass'


# Generated at 2022-06-24 03:05:56.343748
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        def __init__(self):
            self.value = None


# Generated at 2022-06-24 03:06:00.631843
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A():
        def setterproperty(self, value):
            self.x = value

    a = A()
    a.setterproperty = setterproperty(a.setterproperty)
    a.setterproperty(42)
    assert a.x == 42


# Generated at 2022-06-24 03:06:03.340679
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 1

    class B(A):
        pass

    assert A.foo == 1
    assert B.foo == 1


# Generated at 2022-06-24 03:06:08.522886
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        pass

    class B(A):
        @roclassproperty
        def x(cls):
            return "B.x"

    class C(A):
        @roclassproperty
        def x(cls):
            return "C.x"

    assert A.x == 'B.x'
    assert B.x == 'B.x'
    assert C.x == 'C.x'



# Generated at 2022-06-24 03:06:11.461694
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        _x = 1

        @roclassproperty
        def x(cls):
            return cls._x
    assert C.x == 1
    # check some internals of the descriptor protocol
    assert C.__dict__['x'].f == C.x.f
    assert {'_x', 'x', '__module__', '__dict__', '__weakref__', '__doc__'} == set(C.__dict__.keys())

# Generated at 2022-06-24 03:06:18.450985
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def propset(self, value):
            self.__dict__['prop'] = value

        @roclassproperty
        def prop(cls):
            return cls.propset

        @prop.setter
        def prop(self, val):
            self.prop = val

    t = Test()
    t.prop = 1
    assert t.prop == 1, t.prop

    t.prop = 2
    assert t.prop == 2, t.prop



# Generated at 2022-06-24 03:06:24.447464
# Unit test for constructor of class setterproperty
def test_setterproperty():
    a = []

    class T(object):
        @setterproperty
        def a(self, val):
            a.append(val)
            return val

    t = T()
    assert t.a == 0
    t.a = 2
    assert t.a == 2
    assert a == [0, 2]

# Generated at 2022-06-24 03:06:26.576800
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def getx(self):
            return self._x
        def setx(self, value):
            self._x = value
        x = setterproperty(getx, setx)


# Generated at 2022-06-24 03:06:28.874926
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    assert isinstance(roclassproperty(None), roclassproperty)


# Generated at 2022-06-24 03:06:33.222571
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self):
            pass

        @roclassproperty
        def bar(cls):
            return 10

    tc = TestClass()
    assert TestClass.bar == 10
    assert tc.bar == 10
    del TestClass.bar
    assert tc.bar == 10


# Generated at 2022-06-24 03:06:36.754644
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        cls_mem = 3

        @roclassproperty
        def cls_prop(cls):
            return cls.cls_mem

    assert A.cls_prop == 3


# Generated at 2022-06-24 03:06:43.723774
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class X(object):

        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            value = float(value)
            self._value = value

        @value.getter
        def value(self):
            return self._value

        @value.setter
        def value(self, value):
            self._value = value

    assert X(2.0).value == 2.0
    x = X(2.0)
    assert x.value == 2.0
    x.value = 3.0
    assert x.value == 3.0


# Generated at 2022-06-24 03:06:50.287908
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class P(object):
        def __init__(self, val):
            self.val = ''
            self.set_val(val)

        @setterproperty
        def set_val(self, val_):
            """Set a val to a class instance."""
            self.val = val_

    p = P('test')
    assert p.val == 'test', 'Setterproperty did not set value'
    assert p.set_val.__doc__ == 'Set a val to a class instance.', 'Docstring was not copied into descriptor'



# Generated at 2022-06-24 03:06:52.484880
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        y = "y"

        @roclassproperty
        def x(cls):
            return cls.y

    assert A.x == "y"



# Generated at 2022-06-24 03:06:56.863284
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def setter(self, value):
            self.attr = value

        p = setterproperty(setter)

    a1 = A()
    a2 = A()
    assert hasattr(a1, "attr") is False
    assert hasattr(a2, "attr") is False
    a1.p = 'alpha'
    assert a1.attr == 'alpha'
    a2.p = 'beta'
    assert a2.attr == 'beta'
    assert a1.attr == 'alpha'



# Generated at 2022-06-24 03:07:01.053900
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import doctest
    from .classproperty.setterproperty import setterproperty
    from .classproperty import test_setterproperty___set__
    results = doctest.testmod(test_setterproperty___set__)
    assert results.failed == 0


# Generated at 2022-06-24 03:07:06.059195
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            print(value)
            self.__x = value

    foo = Foo()
    foo.x = 10
    print(foo._Foo__x)


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:07:11.218134
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # roclassproperty
    class A(object):
        def __init__(self, x):
            self.x = x

        @roclassproperty
        def cls_x(cls):
            return cls

    a = A(5)
    assert a.cls_x.__name__ == 'A'
    assert a.cls_x.__dict__['__module__'] == A.__dict__['__module__']
    assert a.x == 5



# Generated at 2022-06-24 03:07:13.031121
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def f(cls):
            return 1

    print(A.f)



# Generated at 2022-06-24 03:07:17.152961
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def prop(cls):
            return cls

    assert A.prop is A
    try:
        A().prop = 5
    except Exception as e:
        assert e.__class__.__name__ == 'AttributeError'
        assert str(e) == "attribute 'prop' of 'A' objects is not writable"

# Generated at 2022-06-24 03:07:20.895304
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def set_x(self, value):
            self.x = value * 2

    x = X()
    print('x: %s' % x.__dict__)
    assert x.x == 0
    x.set_x = 5
    print('x: %s' % x.__dict__)
    assert x.x == 10


# Generated at 2022-06-24 03:07:29.481084
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('hi')
            return 42

        @lazyclassproperty
        def baz(cls):
            print('hello')
            return lambda cls: None

    assert Foo.bar == 42
    assert Foo.baz(Foo) is None
    assert Foo.bar == 42
    assert Foo.baz(Foo) is None

    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('hi')
            return 42

    assert Foo.bar == 42

    def fn(cls):
        return 42

    Foo = type('Foo', (object,), dict(bar=lazyclassproperty(fn)))
    assert Foo.bar == 42

    class Bar(object):
        pass

   

# Generated at 2022-06-24 03:07:35.441970
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def A1(cls):
            return 'A1'

        @lazyclassproperty
        def A2(cls):
            print("Runs only once")
            return 'A2'

        def __init__(self):
            print("Running A constructor")

    class B(A):
        @lazyclassproperty
        def B1(cls):
            return 'B1'

        @lazyclassproperty
        def B2(cls):
            return 'B2'

    b = B()
    print(b.A1)
    print(b.A2)
    print(b.B1)
    print(b.B2)



# Generated at 2022-06-24 03:07:38.874131
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, value2):
            self.value2 = value2

        value = roclassproperty(lambda klass: klass.value2)

    a = A(123)
    assert a.value2 == 123
    assert a.value == 123

# Generated at 2022-06-24 03:07:45.000117
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def prop(cls):
            print("returning 12")
            return 12

    print(C.prop)
    assert C.prop == 12
    try:
        C.prop = 1
        assert False, "should have raised"
    except AttributeError:
        pass

# Generated at 2022-06-24 03:07:47.498610
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def f(cls):
            return cls.__name__

    assert C.f == 'C'



# Generated at 2022-06-24 03:07:52.496615
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @roclassproperty
        def Test_property(cls):
            return cls

    assert Test.Test_property is Test


# Generated at 2022-06-24 03:08:02.111102
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self, x):
            self.x = x


# Generated at 2022-06-24 03:08:05.810419
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def roclassproperty(cls):
            return 'roclassproperty'

    assert Foo.roclassproperty == 'roclassproperty'
    try:
        Foo().roclassproperty
    except AttributeError:
        pass
    else:
        assert False



# Generated at 2022-06-24 03:08:07.797409
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        def getx(self):
            print('getx')
            return 10
        x = roclassproperty(getx)

    obj = MyClass()
    assert obj.x == 10
    assert MyClass.x == 10



# Generated at 2022-06-24 03:08:14.915324
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:08:20.809109
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class T(object):
        def __init__(self):
            self._my_var = 1
        def set_my_var(self, value):
            self._my_var = value
        my_var = setterproperty(set_my_var)
    t = T()
    t.my_var = 3
    assert t.my_var == 3


# Generated at 2022-06-24 03:08:26.281881
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    global var
    class A:
        @setterproperty
        def var(self, value):
            global var
            var = value

    a = A()
    assert var == None
    a.var = 'value'
    assert var == 'value'


# Generated at 2022-06-24 03:08:28.155474
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def dummy(cls):
            return "This is a dummy"

    assert C.dummy == "This is a dummy"



# Generated at 2022-06-24 03:08:35.081121
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        def __init__(self, my_attr):
            self.my_attr = my_attr

        @setterproperty
        def my_attr(self, value):
            setattr(self, '__my_attr', value)

        @my_attr.getter
        def my_attr(self):
            return getattr(self, '__my_attr', None)

    my_class = MyClass("my_attr")
    assert my_class.my_attr == "my_attr"
    my_class.my_attr = "new_attr"
    assert my_class.my_attr == "new_attr"

# Generated at 2022-06-24 03:08:39.703987
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    def ttt(cls):
        return cls.__name__
    assert roclassproperty(ttt) is not None



# Generated at 2022-06-24 03:08:43.520540
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def _s_set(self, value):
            self._s = 'Hello ' + value

        s = setterproperty(_s_set, 'Test of setterproperty')
    a = A()
    a.s = 'world!'
    assert a._s == 'Hello world!'


if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-24 03:08:51.218098
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class X(object):
        @roclassproperty
        def a(cls):
            return "rua"

        @classproperty
        def b(cls):
            return "dub"

    assert X.a == "rua"
    assert X.b == "dub"

    # Not enough arguments
    with raises(TypeError):
        X.a()

    # Too many arguments
    with raises(TypeError):
        X.a("X")

    # Can't assign
    with raises(AttributeError):
        X.a = "X"


# Generated at 2022-06-24 03:08:54.253603
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        _bar = None

        @roclassproperty
        def bar(cls):
            return cls._bar

    class Baz(Foo):
        pass

    class Quux(Foo):
        pass

    Baz._bar = 'baz'
    Quux._bar = 'quux'

    assert Baz.bar == 'baz'
    assert Quux.bar == 'quux'


# Generated at 2022-06-24 03:08:59.583550
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return "class"

        @roclassproperty
        def bar(self):
            return "instance"

    a = A()

    try:
        a.foo = "bar"
    except AttributeError:
        pass
    else:
        raise AssertionError("Expected AttributeError on assignment")

    assert a.foo == "class"
    assert a.bar == "instance"
    assert A.foo == "class"



# Generated at 2022-06-24 03:09:04.161100
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TempClass(object):
        def __init__(self):
            self._x = None

        @roclassproperty
        def x(cls):
            return cls._x

        @x.setter
        def x(cls, value):
            cls._x = value

        @x.deleter
        def x(cls):
            del cls._x

    temp = TempClass()
    assert temp.x == None

    TempClass.x = 1
    assert temp.x == 1



# Generated at 2022-06-24 03:09:07.041716
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return id(cls)

    class B(A):
        pass

    assert A.prop != B.prop



# Generated at 2022-06-24 03:09:12.486431
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    Test.foo
    Test().foo
    try:
        Test().foo = None
    except AttributeError:
        pass
    else:
        assert False, "We should not be able to set Test().foo"



# Generated at 2022-06-24 03:09:19.444703
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    x, y = 2, 3
    def f(self, value):
        x, y = value

    setterprop = setterproperty(f)
    setterprop.__set__(None, (1, 1))
    assert (x, y) == (1, 1)
    return


# Generated at 2022-06-24 03:09:27.268638
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:09:32.528175
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            " The 'value' property. "
            self._value = value

    test = Test(42)
    test.value = "Hello, world!"
    assert test._value == "Hello, world!" # Enforce assert


# Generated at 2022-06-24 03:09:35.875498
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            print('test')
            return 'test'

    class B(A):
        pass

    print(set(A.test), set(B.test))


# Generated at 2022-06-24 03:09:39.168545
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            a = A()
            return a

    class B(A):
        pass

    a = A()
    b = B()

    assert a.x is not b.x
    assert b.x is not b.x



# Generated at 2022-06-24 03:09:42.865120
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def f(cls):
            return 'f (roclassproperty)'

    print(C.f)
    print(C().f)
#

# Generated at 2022-06-24 03:09:46.371511
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:

        @setterproperty
        def a(self, value):
            self._a = value

    assert hasattr(A, '_a') is False
    x = A()
    x.a = 42
    assert x._a == 42



# Generated at 2022-06-24 03:09:50.719902
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def name(cls):
            return 'Test'

    assert Test.name == Test.name == 'Test'

    class Test2(Test):
        pass

    assert Test2.name == Test2.name == 'Test'

    class Test3(object):
        @lazyclassproperty
        def name(cls):
            return 'Test3'

    assert Test3.name == Test3.name == 'Test3'



# Generated at 2022-06-24 03:10:00.452732
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:10:03.835474
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    clas=roclassproperty("abc")
    print(clas)
    assert(clas==roclassproperty("abc"))


# Generated at 2022-06-24 03:10:05.811179
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        @lazyclassproperty
        def f(cls):
            print(123)

    assert Foo.f == 123
    assert Foo.f == 123

# Generated at 2022-06-24 03:10:09.424692
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from abjad.tools.abctools import setterproperty

    class Foo(object):

        @setterproperty
        def foo(self, arg):
            if not arg < 4:
                raise Exception
            self._foo = arg

    foo = Foo()

    try:
        foo.foo = 5
        assert False
    except:
        assert True
    assert foo.foo is not AttributeError
    try:
        foo.foo = 4
        assert False
    except:
        assert True

# Generated at 2022-06-24 03:10:14.043272
# Unit test for constructor of class setterproperty
def test_setterproperty():
    c = Counter()
    c.value = 10
    assert c.value == 10
    c.value = 20
    assert c.value == 20
    c.value = 20
    assert c.value == 40
    c.value = -20
    assert c.value == 0


# Generated at 2022-06-24 03:10:18.645748
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class X(object):
        @roclassproperty
        def prop(cls):
            return 123

    assert X.prop == 123
    try:
        X().prop = 234
    except Exception:
        pass
    else:
        assert False, "Shouldn't be able to set read-only class property"



# Generated at 2022-06-24 03:10:25.895095
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclasspropertyTest(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def _value(cls):
            return cls.value

    t = roclasspropertyTest(1)
    assert t._value == 1


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:10:35.505352
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:10:38.220846
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @classmethod
        def some_method(cls):
            return 'Hello'

        @roclassproperty
        def some_property(cls):
            return cls.some_method()

    assert A.some_property == 'Hello'

# Generated at 2022-06-24 03:10:41.198872
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__x = 1


        @setterproperty
        def x(self, value):
            self.__x = value


    a = A()
    assert a.x == 1
    a.x = 42
    assert a.x == 42


# Generated at 2022-06-24 03:10:45.647167
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.setterProp = setterproperty(self._set)

        def _set(self, value):
            self._setterProp = value

    c = C()
    assert hasattr(c, 'setterProp')
    assert c.setterProp is not None
    assert not hasattr(c, '_setterProp')
    c.setterProp = 123
    assert hasattr(c, '_setterProp')
    assert c._setterProp == 123



# Generated at 2022-06-24 03:10:51.808974
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Testing method __set__ of class setterproperty
    """
    from sentinels import NotSpecified
    from .class_ import Bar

    class Foo(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            if value is NotSpecified:
                value = 100
            self._value = value

    foo = Foo(10)
    assert foo.value == 10
    foo.value = Bar(20)
    assert foo.value == Bar(20)


# Generated at 2022-06-24 03:10:55.539828
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self):
            self.foo = 'foo'

        def setter(self, value):
            self.foo = value

        bar = setterproperty(setter)

    foo = Foo()
    assert foo.foo == 'foo'
    foo.bar = 'bar'
    assert foo.foo == 'bar'



# Generated at 2022-06-24 03:10:58.733701
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        class property_foo(roclassproperty):
            def __get__(self, obj, owner):
                return 1

    assert_equal(1, MyClass.property_foo)



# Generated at 2022-06-24 03:11:08.015350
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, attr):
            self.attr = attr

        @lazyperclassproperty
        def foo(cls):
            return cls.attr

    class B(A):
        def __init__(self, attr3):
            super(B, self).__init__(attr3)

        @lazyperclassproperty
        def bar(cls):
            return cls.attr

    a = A(2)
    b = B(4)
    assert a.foo == 2
    assert b.bar == 4
    assert a.foo == 2
    assert b.bar == 4
    assert a.foo == 2



# Generated at 2022-06-24 03:11:11.755243
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__name__


# Generated at 2022-06-24 03:11:15.880729
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        _class_property = roclassproperty(lambda owner: 'foo')

    assert TestClass._class_property == 'foo'

# Generated at 2022-06-24 03:11:24.688659
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:11:27.368862
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def B(cls):
            return "test"
    a = A()
    A.B = "test1"
    assert a.B == "test1"



# Generated at 2022-06-24 03:11:32.173352
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def name(cls):
            return cls.__name__

    assert A.name == 'A'
    assert A().name == 'A'



# Generated at 2022-06-24 03:11:36.694096
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def x(cls):
            return 'x'

    assert Foo.x == 'x'



# Generated at 2022-06-24 03:11:44.291336
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):
        x = 2
        y = roclassproperty(lambda cls: cls.x)

    print(A)
    print(A.x, A.y)

    A.x = 3
    print(A.x, A.y)
    print('=' * 60)

    class B(A):
        pass

    print(B)
    print(B.x, B.y)
    print('=' * 60)

    B.x = 4
    print(B.x, B.y)

    class C(B):
        pass

    print(C)
    print(C.x, C.y)
    print('=' * 60)

    C.x = 7
    print(C.x, C.y)



# Generated at 2022-06-24 03:11:47.502941
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:11:54.084739
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class base(object):
        counter = 0
        @lazyperclassproperty
        def prop(cls):
            cls.counter += 1
            return cls.counter
    class x(base):
        pass
    class y(base):
        pass

    # 1
    assert base.prop == 1
    assert x.prop == 2
    assert y.prop == 3

    # 4
    assert x.prop == 4
    assert y.prop == 5


lazy_property = lazyclassproperty

# Generated at 2022-06-24 03:11:59.155150
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    @setterproperty
    def prop(self, value):
        self._prop = value * 2

    class C(object):
        prop = property(None, prop)

    o = C()
    o.prop = 2
    assert o._prop == 4



# Generated at 2022-06-24 03:12:09.189117
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # A class with a class property
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("lazyclassproperty called")
            return 'prop'

    # Test class property
    print(A.prop)
    print(A.prop)
    # Test inheritance
    class B(A):
        pass

    print(B.prop)
    print(B.prop)
    # Test inheritance
    class C(A):
        @lazyclassproperty
        def prop(cls):
            print("lazyclassproperty called")
            return 'prop of C'

    print(C.prop)
    print(C.prop)
    print(B.prop)
    print(A.prop)



# Generated at 2022-06-24 03:12:13.863419
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, x):
            self.x = x
        @setterproperty
        def x(self, x):
            if x < 0:
                raise ValueError("'x' must be positive")
            self.__x = x
        @property
        def x(self):
            return self.__x
    c = C(-1)



# Generated at 2022-06-24 03:12:15.762665
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return 123

    assert C.foo == 123
    assert C().foo == 123



# Generated at 2022-06-24 03:12:23.444661
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def var(cls):
            return "Base Value"

    class Derived1(Base):
        pass

    assert Base.var == "Base Value"
    assert Derived1.var == "Base Value"

    Base.var = "New Base Value"

    assert Base.var == "New Base Value"
    assert Derived1.var == "Base Value"



# Generated at 2022-06-24 03:12:26.371995
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:31.678279
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = 1

        @setterproperty
        def x(self, value):
            self.x = value * 2

    a = A()
    assert a.x == 1
    a.x = 10
    assert a.x == 20

# Generated at 2022-06-24 03:12:37.477228
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class class_roclassproperty(object):
        @roclassproperty
        def x(cls):
            return 'x'
    print('class_roclassproperty.x = {x}'.format(x=class_roclassproperty.x))



# Generated at 2022-06-24 03:12:44.548949
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method ``__get__`` of class :class:`roclassproperty`.
    """
    class A(object):
        @roclassproperty
        def x(cls):
            return 1
        @staticmethod
        def y():
            return 1
    assert A.x == 1
    assert A().y() == 1

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 03:12:48.497496
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test method __set__ of class setterproperty.
    """
    def _inc(self, value):
        self.value += value
        return self.value

    class Test(object):
        value = setterproperty(_inc)

    test = Test()
    resul = test.value = 5
    if resul != 10:
        print("ERROR. setterproperty fail")
    else:
        print("OK")

if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:12:50.907585
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo(cls):
            return cls
    a = A()
    assert A.foo is A
    # Uncomment the following line to check the __get__ method of class roclassproperty
    # assert a.foo is A



# Generated at 2022-06-24 03:12:54.767512
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> test_lazyclassproperty()
    """
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("Calling lazy class property")
            return 42

    assert Foo.bar == 42
    Foo.bar = 24
    assert Foo.bar == 42



# Generated at 2022-06-24 03:12:58.793604
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    class A(object):

        def _get_a(cls):
            return 'a'

        a = roclassproperty(_get_a)

    class B(A):
        pass

    assert A.a == 'a'
    assert B.a == 'a'
    assert A().a == 'a'
    assert B().a == 'a'



# Generated at 2022-06-24 03:13:04.561444
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def count(cls):
            n = 0
            for c in cls.__subclasses__():
                n += c.count
            return n + 1

        def __init__(self, parent):
            self.parent = parent

    class B(C):
        pass

    assert B.count == 1
    assert C.count == 2
    assert B().count == 1
    assert C().count == 2
    class D(C):
        pass

    assert D.count == 2
    assert B.count == 1
    assert C.count == 3
    assert D().count == 2
    assert B().count == 1
    assert C().count == 3
    class E(D):
        pass

    assert E.count == 3
    assert D.count == 2
   

# Generated at 2022-06-24 03:13:11.060248
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def some_property(self):
            return 'original_value'
    class D(C):
        pass

    assert C.some_property == 'original_value'
    assert D.some_property == 'original_value'
    C.some_property = 'modified_value'
    assert C.some_property == 'modified_value'
    assert D.some_property == 'original_value'



# Generated at 2022-06-24 03:13:18.947368
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, v):
            self._v = v

        @setterproperty
        def v(self, v):
            self._v = 2 * v

        @setterproperty
        def _v(self, v):
            self.__v = v

    a = A(10)
    assert a.v == 10
    assert a._v == 10
    a.v = 2
    assert a._v == 4
    assert a.v == 2
    assert a.__dict__['_v'] == 4
    assert a.__dict__['_A__v'] == 4


###############################################################################
#                                                                             #
#  Base classes                                                               #
#                                                                             #
###############################################################################


# Generated at 2022-06-24 03:13:25.804411
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    test_class = type('test_class', (object,), {'x': roclassproperty(lambda cls: '42'), 'y': roclassproperty(lambda cls: '43')})
    test_instance = test_class()
    assert test_class.x == '42'
    assert test_instance.x == '42'
    assert test_class.y == '43'
    assert test_instance.y == '43'


# Generated at 2022-06-24 03:13:33.894052
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # Test for various kinds of input
    class A(object):
        def __init__(self):
            self.A = 0

        @setterproperty
        def change(self, x):
            self.A = x
    a = A()
    a.change = 1
    assert a.A == 1
    a.change = 2.2
    assert a.A == 2.2
    a.change = -2
    assert a.A == -2

    # Test for constructor of class setterproperty
    def f_test(self, x):
        self.A = 2 * x

    a = A()
    a.change = setterproperty(f_test)
    assert a.A == 1


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:13:42.024221
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        def my_func(self):
            return 'MyClass method called'


        @roclassproperty
        def my_func_roclassproperty(cls):
            return 'roclassproperty method called'

        @classproperty
        def my_func_classproperty(cls):
            return 'classproperty method called'


    class MyChildClass(MyClass):
        pass


    assert MyClass().my_func() == 'MyClass method called'
    assert MyClass.my_func(MyClass) == 'MyClass method called'

    assert MyClass.my_func_roclassproperty == 'roclassproperty method called'
    assert MyChildClass.my_func_roclassproperty == 'roclassproperty method called'

    assert MyClass.my_func_classproperty == 'classproperty method called'
   

# Generated at 2022-06-24 03:13:46.298936
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            # Convert whatever is passed in to a string
            self._x = str(value)

    obj = C()
    obj.x = 3
    assert obj._x == "3"



# Generated at 2022-06-24 03:13:52.877673
# Unit test for constructor of class setterproperty
def test_setterproperty():
    x = 1
    y = 2

    class A(object):
        def __init__(self):
            self.__x = x
            self.__y = y

        @setterproperty
        def x(self, value):
            self.__x = value

        def set_y(self, value):
            self.__y = value

    a = A()
    assert a.__x == 1
    a.x = 2
    assert a.__x == 2
    assert a.__y == 2
    a.set_y(3)
    assert a.__y == 3
