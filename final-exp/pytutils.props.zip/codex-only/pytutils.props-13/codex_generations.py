

# Generated at 2022-06-24 03:03:52.503389
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty.
    """
    class MyClass:
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            self._x = value

    obj = MyClass()
    obj.x = 1
    assert obj.x == 1


# Generated at 2022-06-24 03:03:56.934541
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop(cls):
            return 'prop'

        @lazyperclassproperty
        def prop2(cls):
            return 'prop'

    assert Test.prop == 'prop'
    assert Test.prop2 == 'prop'

    class Test2(Test):
        pass

    assert Test2.prop == 'prop'
    assert Test2.prop2 == 'prop'

    Test.prop = 'change'
    Test2.prop2 = 'change'

    assert Test.prop == 'change'
    assert Test.prop2 == 'prop'



# Generated at 2022-06-24 03:04:01.669815
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def myprop(cls):
            return cls.__name__
    # Check that the class property is read only
    test = TestClass(1)
    test.myprop = "test"
    assert test.myprop == "TestClass"


# Generated at 2022-06-24 03:04:10.647723
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def prop1(cls):
            print("computing prop1")
            return 'prop1value'

    class B(A):
        pass

    class C(A):
        pass

    assert A().prop1 == 'prop1value'
    assert B().prop1 == 'prop1value'
    assert C().prop1 == 'prop1value'
    assert A.__dict__['_A_lazy_prop1'] is B.__dict__['_B_lazy_prop1']
    assert A.__dict__['_A_lazy_prop1'] is not C.__dict__['_C_lazy_prop1']

# Generated at 2022-06-24 03:04:13.538464
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, x):
            return x

    t = test(1)
    t.x = 2
    assert(t.x == 2)



# Generated at 2022-06-24 03:04:16.946764
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def value(cls):
            return cls
    assert A.value is A


# Generated at 2022-06-24 03:04:23.723923
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @classproperty
        def ro_class_property(cls):
            return 1

        def __init__(self):
            return

    class B(A):
        @classproperty
        def ro_class_property(cls):
            return 2

    class C(B):
        def __init__(self):
            return

    a = A()
    b = B()
    c = C()
    assert(a.ro_class_property == 1)
    assert(b.ro_class_property == 2)
    assert(c.ro_class_property == 2)

# Generated at 2022-06-24 03:04:29.982530
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        value = 10

        @classproperty
        def value_1(cls):
            return cls.value + 10

    assert Test.value_1 == 20
    # __get__ will raise AttributeError,
    # so next line will too.
    try:
        Test.__dict__['value_1'] = 20
        raise AssertionError('Expected AttributeError.')
    except AttributeError:
        pass


# Generated at 2022-06-24 03:04:33.249755
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

    foo = Foo()
    foo.x = 3
    assert foo._x == 3


# Generated at 2022-06-24 03:04:38.915103
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    assert A().foo == 'foo'


# Generated at 2022-06-24 03:04:47.849483
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:04:59.228901
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_class_a = lazyperclassproperty(lambda cls: 'a')
    test_class_b = lazyperclassproperty(lambda cls: 'b')

    class TestClassA(object):
        test_class = test_class_a

    class TestClassB(object):
        test_class = test_class_b

    class TestClassC(TestClassB):
        pass

    assert TestClassA.test_class == 'a', "TestClassA.test_class should be 'a'"
    assert TestClassB.test_class == 'b', "TestClassB.test_class should be 'b'"
    assert TestClassC.test_class == 'b', "TestClassC.test_class should be 'b'"


json_types = [int, float, str, bool, dict, list, type(None)]



# Generated at 2022-06-24 03:05:03.121806
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Spam:
        def _get_name(self):
            return 'Spam'

        def _set_name(self, value):
            self._name = value

        name = setterproperty(_set_name, _get_name.__doc__)

    spam = Spam()
    spam.name = 'foo'



# Generated at 2022-06-24 03:05:06.760410
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def setter(self, x):
            self.x = x

    a = A()
    a.setter = 5
    assert a.x == 5
    del a.x
    assert not hasattr(a, 'x')


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:05:11.404523
# Unit test for constructor of class setterproperty

# Generated at 2022-06-24 03:05:20.016387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test run for lazyperclassproperty
    """
    class A(object):
        _test = 0

        @lazyperclassproperty
        def test(cls):
            print("Calculating test value")
            cls._test += 1
            return cls._test

    class B(A):
        _test = 0

    class C(B):
        _test = 0

    # Should calculate value of _test
    print(A.test)
    assert A.test == 1

    # Should not calculate value again, should just fetch from cache
    print(A.test)
    assert A.test == 1

    # Should calculate value of _test
    print(B.test)
    assert B.test == 1

    # Should not calculate value again, should just fetch from cache
    print(B.test)

# Generated at 2022-06-24 03:05:25.776912
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class SomeClass(object):
        @roclassproperty
        def some_roproperty(cls):
            return 1

    class SomeOtherClass(object):
        some_roproperty = 2

    assert SomeClass.some_roproperty == 1
    try:
        SomeClass.some_roproperty = 2
    except Exception as e:
        assert isinstance(e, AttributeError)
    assert SomeOtherClass.some_roproperty == 2
    try:
        SomeOtherClass.some_roproperty = 1
    except Exception as e:
        assert isinstance(e, AttributeError)



# Generated at 2022-06-24 03:05:30.382524
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        x = roclassproperty(lambda cls: cls.y)
        y = 1

    assert A.x == 1

    A.y = 2
    assert A.x == 2



# Generated at 2022-06-24 03:05:36.946423
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def a(cls):
            return cls(1)

    class B(A):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def b(cls):
            return cls(2)

    class C(B):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def c(cls):
            return cls(3)

    assert A.a.x == 1
    assert B.a.x == 1
    assert C.a.x == 1
    assert A.b.x == 2
    assert B.b.x == 2

# Generated at 2022-06-24 03:05:39.143516
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test:
        @lazyclassproperty
        def test(cls):
            return "Test"

    assert Test.test == "Test"



# Generated at 2022-06-24 03:05:44.492523
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        x = lazyperclassproperty(lambda x: 'a')

    class B(object):
        x = lazyperclassproperty(lambda x: 'b')

    class C(A, B):
        pass

    class D(A, B):
        pass

    assert A.x == 'a'
    assert B.x == 'b'
    assert C.x == 'a'
    assert D.x == 'a'



# Generated at 2022-06-24 03:05:50.617962
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return 'class'

    assert C.foo == 'class'
    assert not hasattr(C(), 'foo')



# Generated at 2022-06-24 03:05:55.497291
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo(object):
        _value = 0

        def value(self, v):
            self._value = v

        value = setterproperty(value)

    assert foo._value == 0
    foo.value = 1
    assert foo._value == 1
    nono = foo()
    nono.value = 2
    assert nono._value == 2
    assert foo._value == 1



# Generated at 2022-06-24 03:06:00.520188
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def test_property(cls):
            return 1

    assert Test.test_property == 1
    Test.test_property = 2
    assert Test.test_property == 2

    class Test2(Test):
        pass

    assert Test2.test_property == 2



# Generated at 2022-06-24 03:06:04.491818
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class BaseClass:
        def __init__(self, instance=None):
            pass

        @lazyperclassproperty
        def lazy(self):
            return self.__class__.__name__

    class ClassA(BaseClass):
        pass

    class ClassB(BaseClass):
        pass

    assert ClassA().lazy == 'ClassA'
    assert ClassB().lazy == 'ClassB'



# Generated at 2022-06-24 03:06:12.801180
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Create the __main__.roclassproperty object
    roclassproperty_obj = roclassproperty(f=None)
    # Call method __get__ of roclassproperty with arguments
    # Create the __main__.type object representing a type
    # Call __new__ of type to create __main__.A instance
    A_instance = type.__new__(A)
    # Call A.__init__
    args = ()
    kwargs = {}
    A.__init__(A_instance, *args, **kwargs)
    # Create the __main__.type object representing a type
    # Call __new__ of type to create __main__.B instance
    B_instance = type.__new__(B)
    # Call B.__init__
    args = ()
    kwargs = {}
    B.__init

# Generated at 2022-06-24 03:06:19.631826
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.x = 3

    def setter(self, value):
        self.x = value

    prop = setterproperty(setter)
    test = Test()
    prop.__set__(test, 4)
    assert test.x == 4

# Generated at 2022-06-24 03:06:25.139924
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def test(cls):
            return 1

    foo = Foo()
    assert Foo.test == 1
    assert foo.test == 1
    with pytest.raises(AttributeError):
        foo.test = 42


# Generated at 2022-06-24 03:06:32.612399
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    roclassproperty: __get__ tests
    """
    class A(object):
        def test_roclassproperty___get__():
            print("Test: roclassproperty")

        @roclassproperty
        def __dict__(cls):
            return cls.__dict__

    assert dict is A.__dict__
    try:
        A.__dict__ = None
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 03:06:38.073476
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
        Unit test for method __set__ of class setterproperty
    """
    class Test(object):
        def __init__(self, value=None):
            self.val = value

        @setterproperty
        def val(self, value):
            return value

    test = Test()
    assert test.val is None
    test.val = "foo"
    assert test.val == "foo"



# Generated at 2022-06-24 03:06:44.788884
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def _lazy(cls):
        print ('Generating {}'.format(cls.__name__))
        return cls.__name__

    # Classes with same property _lazy should not return same object
    class Base:
        _lazy = lazyperclassproperty(_lazy)

    class Derived(Base):
        pass

    class Derived2(Base):
        pass

    assert Base._lazy != Derived._lazy
    assert Base._lazy != Derived2._lazy
    assert Derived._lazy != Derived2._lazy



# Generated at 2022-06-24 03:06:47.973357
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Ro(object):
        @roclassproperty
        def val(cls):
            return "%s" % cls.__name__
    a = Ro()
    assert a.val == 'Ro'
    b = Ro()
    assert b.val == 'Ro'


# Generated at 2022-06-24 03:06:55.004053
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from collections import namedtuple

    class Test(namedtuple('_Test', ['a', 'b'])):

        @lazyclassproperty
        def c(cls):
            return 2

        @lazyclassproperty
        def d(cls):
            return 3

        """@property
        def __len__(self):
            return len(tuple(self))"""

        # expected: 'tuple' object has no attribute 'd'
        # actual: 'Test.d' object is not iterable

    # expected: 'Test' object has no attribute 'd'
    assert Test(1, 2).d == 3
    # expected: 'Test' object has no attribute 'c'
    assert Test(1, 2).c == 2
    assert Test.d == 3
    assert Test.c == 2

# Generated at 2022-06-24 03:07:03.253540
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        @classproperty
        def a(cls):
            return cls.b

        @lazyperclassproperty
        def b(cls):
            return 2

    class C(A):
        @classproperty
        def a(cls):
            return cls.b

        @lazyperclassproperty
        def b(cls):
            return 3

    assert A.a == 1
    assert B.a == 2
    assert C.a == 3



# Generated at 2022-06-24 03:07:06.701290
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:07:10.267259
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):
        def __init__(self):
            pass

        @setterproperty
        def setter(self, value):
            self.value = [value]


    foo = Foo()
    foo.setter = "Blah"
    expected = [("Blah")]
    assert(foo.value == expected)

# Generated at 2022-06-24 03:07:16.962454
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def a(cls):
            print('Generating class A attribute a')
            return 1

    class B(A):
        @lazyperclassproperty
        def a(cls):
            print('Generating class B attribute a')
            return 2

    class C(B):
        @lazyperclassproperty
        def a(cls):
            print('Generating class C attribute a')
            return 3

    assert A.a == 1
    assert B.a == 2
    assert C.a == 3
    assert B.a == 2
    assert C.a == 3
    assert A.a == 1



# Generated at 2022-06-24 03:07:21.915733
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def __test(cls):
            return cls.__name__

    class A(Base):
        pass

    class B(Base):
        pass

    assert A.__test == 'A'
    assert B.__test == 'B'


# Generated at 2022-06-24 03:07:31.606642
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    test_data = {'A': 'One', 'B': 'Two', 'C': 'Three', 'D': 'Four'}

    class TestClassA(object):
        @lazyperclassproperty
        def test(cls):
            return test_data

    class TestClassB(TestClassA):
        pass

    class TestClassC(TestClassA):
        pass

    class TestClassD(TestClassB):
        @lazyperclassproperty
        def test(cls):
            return test_data

    a = TestClassA()
    b = TestClassB()
    c = TestClassC()
    d = TestClassD()

    assert a.test == test_data
    assert a.test is b.test is c.test

# Generated at 2022-06-24 03:07:37.383467
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def _get_attr(self, value):
            self._attr = value
        attr = setterproperty(_get_attr)

    a = A()
    a.attr = 'test'
    assert a._attr == 'test'

# Generated at 2022-06-24 03:07:46.433732
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def myattr(cls):
            print('myattr()')
            return 'the result'

        myattr = lazyclassproperty(myattr)

    print('Before first access:')
    assert not hasattr(Foo, '_lazy_myattr')
    print('After first access:')
    assert Foo.myattr == 'the result'
    print('After second access:')
    assert Foo.myattr == 'the result'



# Generated at 2022-06-24 03:07:50.003492
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, x):
            self.x = x

        @roclassproperty
        def prop(cls):
            return cls.__name__

    assert A.prop == "A"
    assert A(0).prop == "A"



# Generated at 2022-06-24 03:07:55.197164
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        @setterproperty
        def bar(self, value):
            self.baz = value

    foo = Foo()
    foo.bar = 42
    assert foo.baz == 42


# Generated at 2022-06-24 03:07:58.712867
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A:
        @lazyclassproperty
        def foo(cls):
            return "bar"

    class B(A):
        pass

    assert A.foo == "bar"
    assert B.foo == "bar"



# Generated at 2022-06-24 03:08:02.949905
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class TestSetterproperty:

        def __init__(self):
            self.x = 'a'

        @setterproperty
        def setter_property(self, value):
            self.x = value

    test = TestSetterproperty()
    test.setter_property = 'b'
    assert test.x == 'b'



# Generated at 2022-06-24 03:08:06.576227
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            print('Constructing')
            return 42

    print(A.x)
    print(A.x)

    class B(A):
        pass

    print(B.x)
    print(B.x)



# Generated at 2022-06-24 03:08:11.672891
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def foo(cls):
            print('init props')
            return 'bar'

    assert MyClass.foo == 'bar'

# Generated at 2022-06-24 03:08:15.190466
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method __get__ of class roclassproperty
    """

    class TestClass(object):
        @roclassproperty
        def test(cls):
            return 'test'

    obj = TestClass()
    assert obj.test == 'test'
    assert TestClass.test == 'test'

if __name__ == "__main__":
    test_roclassproperty___get__()

# Generated at 2022-06-24 03:08:19.372751
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test():
        @roclassproperty
        def test(cls):
            return "Hello"
    try:
        print(Test.test)
    except:
        assert False


# Generated at 2022-06-24 03:08:23.943066
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TestCase(object):

        @lazyperclassproperty
        def test(cls):
            return cls

    class TestCasesub(TestCase):
        pass

    c1 = TestCase()
    c2 = TestCasesub()

    assert c1.test is TestCase
    assert c2.test is TestCasesub

    assert (c1.test is not c2.test)

# Generated at 2022-06-24 03:08:34.761924
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self,x):
            self.x = x
            self.__l = []
        @setterproperty
        def f(self,value):
            self.__l.append(value)
    c = C(3)
    assert(c.x == 3)
    assert(c.f is None)
    c.f = 5
    assert(c.f is None)
    assert(c.__l == [5])
    del c.__l
    c.f = [1,2,3]
    assert(c.f is None)
    assert(c.__l == [[1,2,3]])
    c.f = c
    assert(c.f is None)
    assert(c.__l == [[1,2,3],c])



# Generated at 2022-06-24 03:08:38.646582
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        @setterproperty
        def a(self, value):
            def f():
                return value+3
            return f

    c = C()
    c.a = 10
    assert c.a() == 13

    try:
        c.a = "hi"
        assert False
    except TypeError:
        pass
    c.a = 20
    assert c.a() == 23



# Generated at 2022-06-24 03:08:41.990557
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls

    assert Foo.bar is Foo
    assert Foo().bar is Foo



# Generated at 2022-06-24 03:08:45.047258
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            print("Initializing foo")
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == 'foo'



# Generated at 2022-06-24 03:08:54.332363
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import pickle

    class X:
        def __init__(self):
            self._a = 0

        @setterproperty
        def a(self, value):
            self._a = value

        @setterproperty
        def b(self, value):
            '''Docstring for "b"'''
            self._a = value

        @property
        def c(self):
            return self._a

    x = X()
    x.a = 1
    assert x._a == 1
    assert x.a == 1

    # Check that setterproperty works with pickle, i.e. that the presence
    # of __set__ is not a problem.
    x2 = pickle.loads(pickle.dumps(x))
    assert x2._a == 1
    assert x2.a == 1

    assert X

# Generated at 2022-06-24 03:09:01.740500
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def _get_attr1(self):
            return self._attr1

        def _set_attr1(self, value):
            self._attr1 = value

        attr1 = setterproperty(_set_attr1, _get_attr1)

    a = A()
    a.attr1 = 1
    assert a.attr1 == 1

# Generated at 2022-06-24 03:09:05.500347
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'
    assert Foo.bar == 'bar'
    assert Foo._lazy_bar == 'bar'
    assert Foo.__dict__['_lazy_bar'] == 'bar'
    Foo.bar = 'foobar'
    assert Foo.bar == 'foobar'
    assert Foo._lazy_bar == 'foobar'
    assert Foo.__dict__['_lazy_bar'] == 'foobar'


# Generated at 2022-06-24 03:09:09.807887
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Temp(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            self._value = value

    temp = Temp(3)
    temp.value = 4
    assert temp._value == 4



# Generated at 2022-06-24 03:09:17.166590
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print("returning 42")
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert A.foo == 42  # Two calls, only one print statement

    assert B.foo == 42
    assert B.foo == 42  # B does not have its own foo, only a reference to A.foo

    assert B().foo == 42  # Works on instances too



# Generated at 2022-06-24 03:09:21.805984
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return "foo"
    assert(Foo.bar == "foo")

    class Bar(Foo):
        pass
    assert(Bar.bar == "foo")



# Generated at 2022-06-24 03:09:24.908735
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        __metaclass__ = type

        @roclassproperty
        def a(cls):
            return 1
    assert A.a == 1



# Generated at 2022-06-24 03:09:28.373883
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.counter = 0
        @setterproperty
        def value(self, value):
            self.counter += 1
    a = A()
    a.value = 3
    a.value = 4
    assert a.counter == 2

test_setterproperty()


# Generated at 2022-06-24 03:09:31.428349
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        foo = roclassproperty(lambda cls: 'foo')

    f = Foo()
    assert f.foo == 'foo'


# Generated at 2022-06-24 03:09:36.800003
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Test class roclassproperty
    """

    class MyClass(object):
        @roclassproperty
        def my_prop(cls):
            return 'My class : {}'.format(cls.__name__)

    assert MyClass.my_prop == 'My class : MyClass'
    try:
        MyClass.my_prop = 'test'
        raise AssertionError('Read only property can be modifified')
    except AttributeError:
        pass


# Generated at 2022-06-24 03:09:39.166773
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def f(cls):
            return cls

    assert A.__dict__['f'] == (lambda cls: cls)
    assert A.f == A


# Generated at 2022-06-24 03:09:40.559625
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert C.x == 1

# Generated at 2022-06-24 03:09:42.571012
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        @roclassproperty
        def version(cls):
            return 2.0

    assert MyClass.version == 2.0

# Generated at 2022-06-24 03:09:48.978056
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:09:53.831113
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @roclassproperty
        def prop(t):
            return 'prop'

    o = Test()
    assert o.prop == 'prop'



# Generated at 2022-06-24 03:10:01.832825
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method __get__ of class roclassproperty
    """
    class Test:
        def __init__(self, p):
            self.p = p
        @roclassproperty
        def get_p(self):
            return self.p
        @property
        def get_other(self):
            return self.p

    t = Test(1)
    assert t.get_p == Test.get_p and t.get_p == 1
    t.p = 2
    assert t.get_p == Test.get_p and t.get_p == 2 and t.get_other == 2
    assert Test.get_p == 2

    t = Test(1)
    assert t.get_other == 1



# Generated at 2022-06-24 03:10:06.372596
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'class bar'

        @roclassproperty
        def __name__(cls):
            return 'Foo'

        @roclassproperty
        def __module__(cls):
            return '__main__'


# Generated at 2022-06-24 03:10:09.097656
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            return 1

    class A(Base):
        pass

    class B(Base):
        @lazyperclassproperty
        def test(cls):
            return 2

    assert Base.test == 1
    assert A.test == 1
    assert B.test == 2


# Generated at 2022-06-24 03:10:12.266570
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def value(cls):
            return "abc"

    assert A.value == "abc"



# Generated at 2022-06-24 03:10:17.838703
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    '''
    Runs the unit test for method __set__ of class setterproperty
    '''

    # Sets variable to 0
    var = 0

    # Defines class Foo.
    class Foo:
        @setterproperty
        def foo(self, value):
            nonlocal var
            var = value

    # Calls function foo of class Foo.
    Foo().foo = 2

    # Checks if var equals 2
    assert var == 2

# Generated at 2022-06-24 03:10:22.582306
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.d = {}
        @setterproperty
        def a(self, value):
            self.d['a'] = value
        @setterproperty
        def b(self, value):
            self.d['b'] = value
    foo = Foo()
    foo.a = 'A'
    foo.b = 'B'
    if foo.d['a'] == 'A' and foo.d['b'] == 'B':
        return True
    else:
        return False


# Generated at 2022-06-24 03:10:26.070936
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test the lazyclassproperty decorator.
    """
    class A(object):
        def __init__(self):
            self.called = False

        @lazyclassproperty
        def prop(cls):
            self.called = True
            return 1

    obj = A()
    assert not obj.called
    assert obj.prop == 1
    assert obj.called
    obj2 = A()
    assert not obj2.called
    assert obj2.prop == 1
    assert not obj2.called



# Generated at 2022-06-24 03:10:32.023271
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.__private = 123

        def _set_private(self, private):
            self.__private = private

        def _get_private(self):
            return self.__private

        private = setterproperty(_set_private, 'private property')

    t = Test()

    t.private = 'abc'

    assert t._get_private() == 'abc'


# Generated at 2022-06-24 03:10:36.619502
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class User:
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            self._value = value

    user = User("test")
    assert user._value == "test"
    assert user.value == "test"

    user.value = "new_value"
    assert user._value == "new_value"
    assert user.value == "new_value"

# Generated at 2022-06-24 03:10:44.301154
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Class():
        @setterproperty
        def property(self, value):
            self.internal_value = value


    class InheritedClass(Class):
        pass

    instance = Class()
    instance.property = 1
    assert instance.property == 1

    inherited_instance = InheritedClass()
    inherited_instance.property = 2
    assert inherited_instance.property == 2

    assert inherited_instance.property == 2
    assert instance.property == 1


# Generated at 2022-06-24 03:10:46.854434
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test:
        @roclassproperty
        def p(cls):
            return id(cls)

    class Test2(Test):
        pass

    assert isinstance(Test.p, int)
    assert id(Test) == Test.p
    assert isinstance(Test2.p, int)
    assert id(Test2) == Test2.p



# Generated at 2022-06-24 03:10:51.411871
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 'test'
    class B(A):
        pass
    class C(A):
        pass
    class D(C):
        pass


# Generated at 2022-06-24 03:10:54.151877
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def x(cls):
            return 47

    assert Foo.x == 47
    try:
        Foo.x = 42
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-24 03:10:57.280564
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'

test_lazyclassproperty()



# Generated at 2022-06-24 03:11:02.180877
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self, value):
            self.value = value

    class A(Base):
        @lazyperclassproperty
        def foo(cls):
            return cls(1)
        @lazyperclassproperty
        def bar(cls):
            return cls(2)

    class B(Base):
        @lazyperclassproperty
        def bar(cls):
            return cls(3)
        @lazyperclassproperty
        def baz(cls):
            return cls(4)

    class C(A, B):
        @lazyperclassproperty
        def baz(cls):
            return cls(5)


# Generated at 2022-06-24 03:11:05.868718
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    Test the constructor of class setterproperty
    """
    class Foo():
        def __init__(self):
            self._x = "1"

        @setterproperty
        def x(self, value):
            if value > 10:
                self._x = "10"
            elif value < 0:
                self._x = "0"
            else:
                self._x = value

        def getx(self):
            return self._x

    foo = Foo()
    foo.x = 11
    assert foo.getx() == "10"
    foo.x = -1
    assert foo.getx() == "0"
    foo.x = 5
    assert foo.getx() == "5"



# Generated at 2022-06-24 03:11:08.942586
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 1
    assert C.x == 1
    c = C()
    assert c.x == 1

# Generated at 2022-06-24 03:11:11.034352
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def prop(self, value):
            self.value = float(value)

    c = C()
    c.prop = '2.2'
    assert c.value == 2.2

# Generated at 2022-06-24 03:11:19.260892
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, value=None):
            self.x = value

        @setterproperty
        def x(self, value):
            if value > 10:
                msglog.log('test_setterproperty___set__', msglog.types.WARN,
                       'value %d exceeds 10' % value)
                self._x = 10
            else:
                self._x = value

        @property
        def x(self):
            return self._x

    a = A()
    assert a.x == None
    a.x = 11
    assert a.x == 10

# Generated at 2022-06-24 03:11:27.144102
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A1(object):
        x = 1
        @roclassproperty
        def x(cls):
            return cls.x
    a1 = A1()
    a2 = A1()
    assert a1.x == a2.x, "should be equal"
    assert a1.x == 1, "should be 1"
    A1.x = 10
    assert a1.x == a2.x, "should be equal"
    assert a1.x == 10, "should be 10"


# Generated at 2022-06-24 03:11:35.326914
# Unit test for constructor of class setterproperty
def test_setterproperty():
  # Checks for a function that raises an exception
  def func(obj, value):
    if not isinstance(value, str):
      raise ValueError("value is expected to be a string")
    obj.value = value
  # Checks that the setterproperty constructor raises an exception when the function raises an exception
  pytest.raises(ValueError, lambda: setterproperty(func))
  # Checks that the setterproperty constructor does not raise an exception when the function does not raise an exception
  setterproperty(func, "this is a string")



# Generated at 2022-06-24 03:11:39.679020
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def foo(cls):
            return 'A'

    class B(A):
        foo = roclassproperty(foo)

    assert B.foo == 'A'
    assert B().foo == 'A'


# Generated at 2022-06-24 03:11:42.949880
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            return 'test'
        
    assert Test.test == Test().test

# Generated at 2022-06-24 03:11:51.899085
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def __init__(self, v):
            self.v = v

        @roclassproperty
        def getv(cls):
            return cls.name + str(cls.v)

        def __str__(self):
            return self.getv

    TestClass.name = 'class'
    TestClass.v = 'value'

    t1 = TestClass('instance')
    assert str(t1) == 'classvalue'

    # make sure that instance 'v' hasn't affected class 'v'
    assert TestClass.v == 'value'

    TestClass.v = 'newvalue'
    assert str(t1) == 'classvalue'


# unit test for class lazyclassproperty

# Generated at 2022-06-24 03:11:58.158949
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class X(object):

        @lazyclassproperty
        def lazy_prop(cls):
            return "lazy_prop for class %s" % cls.__name__

        @lazyperclassproperty
        def lazy_perclass_prop(cls):
            return "lazy_perclass_prop for class %s" % cls.__name__

    assert X.lazy_prop == 'lazy_prop for class X'
    assert X.lazy_perclass_prop == 'lazy_perclass_prop for class X'

    class Y(X):
        pass

    assert Y.lazy_prop == 'lazy_prop for class X'
    assert Y.lazy_perclass_prop == 'lazy_perclass_prop for class Y'



# Generated at 2022-06-24 03:12:00.469981
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def get_x(self):
            return 1

        x = roclassproperty(get_x)

    a = A()
    assert a.x == 1



# Generated at 2022-06-24 03:12:08.785465
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import itertools, os

    class Sink(object):

        def __init__(self):
            self.set = None

        @setterproperty
        def set(self, value):
            return value

    sink = Sink()
    for value in itertools.islice(itertools.cycle([os.getpid(), u"", None, lambda: True]), 1024):
        sink.set = value
        assert sink.set is value, value


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:12:13.042601
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class RoClassPropertyTest(object):
        def get_foo(self):
            return 5

        foo = roclassproperty(get_foo)

    assert RoClassPropertyTest.foo == 5
    assert RoClassPropertyTest().foo == 5

    try:
        RoClassPropertyTest.foo = 3
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-24 03:12:15.657179
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        x = roclassproperty(lambda cls: cls.name)

        @classmethod
        def name(cls):
            return "Test"

    test = Test()
    print(test.x)



# Generated at 2022-06-24 03:12:17.218143
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class example(object):
        @roclassproperty
        def a(cls):
            return 1

    assert example.a == 1
    assert example().a == 1



# Generated at 2022-06-24 03:12:22.116472
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def __init__(self, v):
            self.__dict__["x"] = v

        @setterproperty
        def x(self, v):
            assert v < 2

    a = C(1)
    a.x = 2


# Generated at 2022-06-24 03:12:25.674974
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class DemonstrateSetterProperty(object):
        def __init__(self):
            self._x = 50

        @setterproperty
        def x(self, value):
            self._x = value

        def getx(self):
            return self._x

    assert DemonstrateSetterProperty().getx() == 50
    DemonstrateSetterProperty().x = 100
    assert DemonstrateSetterProperty().getx() == 100

# Generated at 2022-06-24 03:12:30.030620
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        @setterproperty
        def x(self, value):
            self.y = value

    a = A()
    assert not hasattr(a, 'y')
    a.x = 5
    assert a.y == 5


# Generated at 2022-06-24 03:12:36.019291
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, v=''):
            self.__x = v

        @setterproperty
        def x(self, v):
            self.__x = v

    c = C()
    assert c.x == ''
    assert c._C__x == ''
    c.x = 'v'
    assert c.x == 'v'
    assert c._C__x == 'v'


# Generated at 2022-06-24 03:12:39.982417
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @setterproperty
        def a(self, value):
            self._a = value

        @setterproperty
        def b(self, value):
            self._b = value

    foo = Foo(1, 2)
    foo.a = 3
    foo.b = 4
    assert foo._a == 3
    assert foo._b == 4



# Generated at 2022-06-24 03:12:46.941543
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __init__(self):
            self.a = 0

    class B(A):
        def __init__(self, b):
            self.b = b

    class C(B):
        def __init__(self, c):
            self.c = c

    class D(C):
        def __init__(self, d):
            self.d = d

    class E(A):
        def __init__(self, e):
            self.e = e

    def getter(cls):
        return sum([getattr(cls, v) for v in cls.__dict__ if v[0] != '_'])

    for cls in (A, B, C, D, E):
        a = cls()
        b = cls()
        c = cls()

# Generated at 2022-06-24 03:12:54.549427
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test(object):
        def __init__(self):
            self._a = 0
            self._a2 = 0
        @setterproperty
        def a(self, value):
            self._a = value

    t = test()
    t.a = 1
    assert t._a == 1

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-24 03:12:56.770480
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Class(object):
        @roclassproperty
        def property_name(cls):
            return 'property'

    assert Class.property_name == 'property'

# Generated at 2022-06-24 03:13:04.479568
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(c):
            return 1

    class B(A):
        @lazyclassproperty
        def test(c):
            return 2

    class C(A):
        pass

    try:
        assert(A.test == 1)
        assert(B.test == 2)
        assert(C.test == 1)
        assert(A.test == 1)
    except:
        assert(False)
    else:
        assert(True)



# Generated at 2022-06-24 03:13:10.185153
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def foo(self, f):
            print(f)
        @setterproperty
        def foo1(self, f):
            print(f)
    a = A()
    a.foo = None
    a.foo1 = 13


# Generated at 2022-06-24 03:13:11.054665
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    pass # TODO: Implement test


# Generated at 2022-06-24 03:13:13.527353
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @classmethod
        def bar(cls):
            print("bar")
            return 42

        baz = lazyclassproperty(bar)

    assert Foo.baz == 42



# Generated at 2022-06-24 03:13:17.553361
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def a(cls):
            return 1

        @readonlyclassproperty
        def b(cls):
            return 2
    assert C.a == 1
    assert C.b == 2
    c = C()
    assert c.a == 1
    assert c.b == 2
# test_roclassproperty()



# Generated at 2022-06-24 03:13:28.995380
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Ensure that calls before first use of roclassproperty return None

    class TestClass(object):
        @roclassproperty
        def test_prop(cls):
            raise NotImplementedError()

    assert not (False in [hasattr(TestClass, prop) for prop in ['_test_prop', 'test_prop']])

    # Ensure that methods are not created or called before first use of roclassproperty

    class TestClass(object):
        @roclassproperty
        def test_prop(cls):
            raise NotImplementedError()

    assert not (False in [hasattr(TestClass, prop) for prop in ['_test_prop', 'test_prop']])

    # Make sure that using roclassproperty creates a method.


# Generated at 2022-06-24 03:13:30.826388
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:34.177174
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def foo(cls):
            return 42

        bar = roclassproperty(lambda cls: 13)

    assert Test.foo == 42
    assert Test.bar == 13

    assert Test().foo == 42
    assert Test().bar == 13



# Generated at 2022-06-24 03:13:38.705133
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__():
            self._x = None

        def set_x(self, value):
            self._x = value

        x = setterproperty(set_x, "I am the 'x' property.")

    c = C()
    c.x = 1
    assert c._x == 1



# Generated at 2022-06-24 03:13:46.879567
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        @lazyclassproperty
        def bar(cls):
            return cls(100)

    assert Foo.bar.value == 100

    # Make sure that Foo.bar is only initialized once
    Foo.bar.value = 50
    assert Foo.bar.value == 50
    assert Foo.bar.value == 50

    class Baz(Foo):
        pass

    assert Baz.bar.value == 100

    # Make sure that Foo.bar and Baz.bar are two seperate instances
    Baz.bar.value = 75
    assert Baz.bar.value == 75
    assert Foo.bar.value == 50

