

# Generated at 2022-06-24 03:03:50.982842
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from pluto.event.eventdispatcher import EventDispatcher
    from unittest.mock import patch

    class A(object):

        @lazyclassproperty
        def testprop(cls):
            return EventDispatcher()

    with patch("pluto.event.eventdispatcher.slot", None):
        assert isinstance(A.testprop, EventDispatcher)
        assert A.testprop == A.testprop


# Generated at 2022-06-24 03:03:59.092160
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test method __get__ of class roclassproperty.
    """

    class TestClass(object):
        """
        Test class for method __get__ of class roclassproperty.
        """

        def f(cls):
            return cls.__name__ + '_test'

        x = roclassproperty(f)

    test_class = TestClass()
    assert test_class.x == 'TestClass_test'

# Generated at 2022-06-24 03:04:01.759172
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def m(klass):
            return klass.__name__

    assert C.m == 'C'



# Generated at 2022-06-24 03:04:03.627767
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def bar(cls):
            return cls

    assert Foo.bar is Foo

# Generated at 2022-06-24 03:04:10.046934
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self.value = 0

        @roclassproperty
        def inc(cls):
            cls.value += 1
            return cls.value

    a1 = A()
    a2 = A()
    print(a1.inc)
    print(a1.inc)
    print(a2.inc)



# Generated at 2022-06-24 03:04:13.270702
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo:
        def _f(self):
            return "foo"

        f = roclassproperty(_f)

    class Bar(Foo):
        pass

    foo = Foo()
    bar = Bar()
    return foo.f == "foo" and bar.f == "foo" and foo.f is bar.f


# Generated at 2022-06-24 03:04:23.798160
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def __init__(self):
            self.f = 0
        @roclassproperty
        def test1(self):
            return self.f
    class TestSubClass(TestClass):
        def __init__(self):
            super(TestSubClass, self).__init__()
            self.f = 1
        @roclassproperty
        def test2(self):
            return self.f
    testclass = TestClass()
    testclass.test1 = 1
    assert testclass.test1 == testclass.f
    assert TestClass.test1 == testclass.f
    testclass.f = 2
    assert testclass.test1 == testclass.f
    assert TestClass.test1 == testclass.f
    with pytest.raises(AttributeError) as excinfo:
        Test

# Generated at 2022-06-24 03:04:28.265351
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return "bar"


# Generated at 2022-06-24 03:04:36.094751
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyStuff(object):
        @classproperty
        def whatever(cls):
            return "whatever"

    dummy_stuff = DummyStuff()
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy_stuff.whatever == "whatever"
    assert dummy

# Generated at 2022-06-24 03:04:38.879038
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    def f():
        return "f_result"

    prop = roclassproperty(f)
    assert prop.__get__(None, object) == "f_result"



# Generated at 2022-06-24 03:04:47.203879
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        _value = '_value'
        @roclassproperty
        def value(cls):
            return cls._value

        @classmethod
        def set_value(cls, value):
            cls._value = value

    assert TestClass.value == '_value'
    TestClass.set_value('new_value')
    assert TestClass.value == 'new_value'
    try:
        TestClass.value = 'test_test'
    except Exception as e:
        print(str(e))



# Generated at 2022-06-24 03:04:55.415208
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Person(object):
        name = 'Default'

# Generated at 2022-06-24 03:05:00.449546
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        foo = roclassproperty(lambda cls: 'bar')

    assert A.foo == 'bar'
    assert A().foo == 'bar'
    assert A().foo == 'bar'



# Generated at 2022-06-24 03:05:03.654971
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.name = None
        @setterproperty
        def name(self, value):
            self.name = value

    a = A()
    a.name = "john"

# Generated at 2022-06-24 03:05:06.348332
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return True

        @classproperty
        def bar(cls):
            return False

    assert C.foo == True
    assert C.bar == False
    assert C().foo == True
    assert C().bar == False



# Generated at 2022-06-24 03:05:08.267951
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class S(object):
        @roclassproperty
        def prop(cls):
            return 1
    assert S.prop == 1



# Generated at 2022-06-24 03:05:13.396893
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            if not isinstance(value, int):
                raise TypeError
            self.__x = value

        @x.getter
        def x(self):
            return self.__x

        @x.deleter
        def x(self):
            del self.__x

    test_obj = TestClass()
    print(test_obj.__dict__)
    test_obj.x = 1
    print(test_obj.__dict__)

# Generated at 2022-06-24 03:05:17.541518
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def a(self, value):
            if value in range(10):
                self.__a = value
            else:
                raise ValueError("ValueError, it's illegal")

        @property
        def a(self):
            return self.__a

    a = A()
    a.a = 1
    assert a.a == 1
    try:
        a.a = 11
    except Exception as e:
        assert "ValueError, it's illegal" == str(e)
    except:
        assert False



# Generated at 2022-06-24 03:05:25.092317
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Bar(object):
        @lazyperclassproperty
        def one(cls):
            return 6

    class Foo(Bar):
        pass

    class Foo2(Bar):
        pass

    assert(Foo.one == 6)
    assert(Foo2.one == 6)
    Foo.one = 'seven'
    assert(Foo.one == 'seven')
    assert(Foo2.one == 6)



# Generated at 2022-06-24 03:05:31.118351
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class DummyClass(object):
        x = 0
        @setterproperty
        def setx(self,value):
            self.x = value

    d = DummyClass()
    assert d.x == 0
    d.setx = 10
    assert d.x == 10



# Generated at 2022-06-24 03:05:36.291923
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Test for method __set__
    class C(object):
        _x = None

        def getx(self):
            return self._x

        @setterproperty
        def x(self, value):
            self._x = value

    c = C()
    # Verify that the object is initially empty.
    assert c.getx() is None

    # Verify that we can set the property on the object.
    c.x = 1
    assert c.getx() == 1

    # Verify that we override an existing property.
    c.x = 2
    assert c.getx() == 2

# Generated at 2022-06-24 03:05:38.186339
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def get_attr(cls):
            return 'attr'

    assert A.get_attr == 'attr'



# Generated at 2022-06-24 03:05:45.661155
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class Test(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            print('setting x to {}'.format(value))
            self._x = value

    class TestSetterproperty(unittest.TestCase):
        def test___set__(self):
            test = Test()

            test.x = 1
            self.assertEqual(test._x, 1)

            test.x = 2
            self.assertEqual(test._x, 2)

    unittest.main()



# Generated at 2022-06-24 03:05:54.028959
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @setterproperty
        def r(self, value):
            self.x = value
            self.y = value * 2

        @property
        def s(self):
            return self.x + self.y

    a = A(100, 200)
    assert a.s == 300
    a.r = 5
    assert a.s == 10

# Generated at 2022-06-24 03:05:57.701128
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def bar(self, value):
            self._bar = value

    f = Foo()
    f.bar = 1

# Generated at 2022-06-24 03:06:06.569376
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from collections import Counter
    from .models.util import get_fqdn

    class A:
        @lazyperclassproperty
        def b(self):
            return get_fqdn()

    class C(A):
        pass

    class D(A):
        pass

    a = A()
    a.b  # now b is populated
    c = C()
    c.b  # now b is populated
    d = D()
    d.b  # now b is populated

    results = Counter()
    a.b = results
    c.b = results
    d.b = results

    assert results['D'] == 1
    assert results['C'] == 1
    assert results['A'] == 1



# Generated at 2022-06-24 03:06:12.676439
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):

        @roclassproperty
        def prop(cls):
            return 42

        @prop.setter
        def prop(cls, value):
            raise TypeError("Can't set prop")

    class B(A):
        pass

    assert A.prop == 42
    assert B.prop == 42

    try:
        A.prop = 17
    except TypeError:
        pass
    else:
        raise AssertionError("Should raise TypeError")

    try:
        B.prop = 17
    except TypeError:
        pass
    else:
        raise AssertionError("Should raise TypeError")

# Generated at 2022-06-24 03:06:19.667961
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def prop(cls):
            return object()

        def __init__(self, **kwargs):
            for (k, v) in kwargs.iteritems():
                setattr(self, k, v)

    class Derived(Base):
        @lazyperclassproperty
        def prop(cls):
            return object()

    b = Base()
    d = Derived()

    assert b.prop is b.prop
    assert d.prop is d.prop
    assert b.prop is not d.prop

# Generated at 2022-06-24 03:06:26.311117
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def f(self, value):
        self.x = value

    class Foo():
        @setterproperty
        def abc(self, value):
            self.abc = value

    assert not hasattr(Foo, 'x')
    foo = Foo()
    assert not hasattr(foo, 'x')
    f(foo, 10)
    assert foo.x == 10
    foo.abc = 20
    assert foo.abc == 20



# Generated at 2022-06-24 03:06:29.425238
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    with raises(TypeError):
        setterproperty(None).__set__(None, None)


# Generated at 2022-06-24 03:06:34.564289
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert Foo.bar == 'bar'
    # Clean up
    del Foo.bar
    try:
        del Foo._lazy_bar
    except:
        pass
    try:
        del Foo.__dict__['bar']
    except:
        pass



# Generated at 2022-06-24 03:06:38.716226
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:06:43.521065
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass1:
        @lazyclassproperty
        def my_prop(cls):
            print('Called my_prop in MyClass1')
            return 'MyClass1'

    class MyClass2(MyClass1):
        pass

    print('my_prop of MyClass1 is', MyClass1.my_prop)
    print('my_prop of MyClass2 is', MyClass2.my_prop)



# Generated at 2022-06-24 03:06:48.607184
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def Foo(cls):
            return cls.__name__
    assert A.Foo == "A"
    assert A.__dict__.has_key("Foo") == False
    a = A()
    assert a.Foo == "A"
    assert a.__dict__.has_key("Foo") == False


# Generated at 2022-06-24 03:06:52.422675
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def meth(cls):
            return 42
        meth = roclassproperty(meth)
    assert C.meth == 42
    try:
        C.meth = 24
    except AttributeError:
        pass
    else:
        assert 0, "Shouldn't be allowed to set readonly attribute"

# Generated at 2022-06-24 03:06:55.956691
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        def __init__(self):
            self.foo = 1

        @roclassproperty
        def bar(cls):
            return cls

    assert isinstance(C.bar, roclassproperty)
    assert isinstance(C.bar.f, types.MethodType)
    assert C.bar.f.__self__ is None
    assert C().bar is C



# Generated at 2022-06-24 03:07:01.601122
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):

        @roclassproperty
        def instance_factory(cls):
            return cls()

    foo = Foo()
    g = lambda: None
    g.__class__ = Foo
    assert foo.instance_factory is Foo.instance_factory is g().instance_factory



# Generated at 2022-06-24 03:07:09.058655
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        a = False
        @lazyperclassproperty
        def b(cls):
            cls.a = True
            return 'b'
        @lazyperclassproperty
        def c(cls):
            cls.a = False
            return 'c'

    class B(A):
        pass

    assert A.a is False
    assert 'b' == A.b
    assert A.a is True
    assert A.b is A.b

    assert B.a is False
    assert 'b' == B.b
    assert B.a is True

    assert 'c' == A.c
    assert 'c' == B.c
    assert A.a is False and B.a is False
    assert A.b == B.b
    assert A.c == B.c



# Generated at 2022-06-24 03:07:12.514507
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    @classmethod
    def get_roclassproperty(cls):
        return cls.roclassproperty

    class A(object):
        roclassproperty = roclassproperty(get_roclassproperty)

    class B(A):
        pass

    assert A.roclassproperty == A
    assert B.roclassproperty == A



# Generated at 2022-06-24 03:07:16.993128
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    from zsl.utils.object_reflection import get_attribute_value

    def f(owner: object) -> object:
        return owner

    class X:
        value = roclassproperty(f)

    assert X.value is X
    assert get_attribute_value(X(), "value") is X

    class Y(X):
        pass

    assert Y.value is Y
    assert get_attribute_value(Y(), "value") is Y



# Generated at 2022-06-24 03:07:21.326925
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def foo(self):
            return 'bar'

    a = A()

    print(a.foo)
    print(a.foo)
    print(a.foo)
    print(a.foo)



# Generated at 2022-06-24 03:07:23.776865
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return id(cls)
    class B(A):
        pass
    class C(A):
        pass
    assert A.foo != B.foo
    assert A.foo != C.foo
    assert B.foo != C.foo


# Generated at 2022-06-24 03:07:27.925519
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def x(cls):
            return "B"

    assert A.x is "A"
    assert B.x is "B"

# Generated at 2022-06-24 03:07:31.749023
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def foo (self, value):
            self._val = value
            return value

    a = A()
    result = a.foo
    assert result is not None
    # a.foo = 'bar'
    # assert a.foo == 'bar'

if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:07:42.245712
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:

        def __init__(self):
            self.info = {}

        @setterproperty
        def name(self, info: dict):
            if info["first_name"] is None:
                raise ValueError("first_name is empty")

            if info["last_name"] is None:
                raise ValueError("last_name is empty")

            self.info = info

        def __str__(self):
            return f'{self.info["first_name"]} {self.info["last_name"]}'

    a = A()
    a.name = {"first_name": "John", "last_name": "Smith"}
    assert str(a) == "John Smith"


# Generated at 2022-06-24 03:07:45.820668
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        __bar = 1

        @roclassproperty
        def foo(cls):
            return cls.__bar

    assert A.foo == 1



# Generated at 2022-06-24 03:07:51.060704
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Example(object):
        _value = 0
        def _set_value(self, value):
            if not isinstance(value, int):
                raise TypeError('expected an int')
            self._value = value

        value = setterproperty(_set_value)

    ex = Example()
    assert ex.value == 0
    ex.value = 10
    assert ex.value == 10
    try:
        ex.value = '10'
        assert False, 'Exception expected'
    except TypeError:
        pass


# Generated at 2022-06-24 03:07:56.265101
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:08:01.111322
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class S(object):
        @setterproperty
        def x(self, value):
            self._x = value

    s = S()
    s.x = 42
    assert s._x == 42



# Generated at 2022-06-24 03:08:05.016862
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self.x = None

        @setterproperty
        def set_x(self, x):
            self.x = x

    a = A()
    a.set_x = 1
    assert a.x == 1


# Generated at 2022-06-24 03:08:06.219155
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import doctest
    doctest.testmod(lazyperclassproperty)



# Generated at 2022-06-24 03:08:15.754957
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from doctest import testmod

    class foo(object):
        _x = 42


# Generated at 2022-06-24 03:08:25.722320
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class class1(object):
        def __init__(self):
            self._strict_writable = False
            self._strict_readable = False
            self._value = True

        @classproperty
        def value(cls):
            return cls._value

        @value.setter
        def value(cls, value):
            cls._value = value

        @property
        def strict_writable(self):
            return self._strict_writable

        @strict_writable.setter
        def strict_writable(self, value):
            self._strict_writable = value

        @property
        def strict_readable(self):
            return self._strict_readable

        @strict_writable.setter
        def strict_readable(self, value):
            self._strict_readable

# Generated at 2022-06-24 03:08:34.686080
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foobar(object):
        pass
    @roclassproperty
    def test(cls):
        return 'this is a test'
    @setterproperty
    def setter(cls, foo):
        setattr(cls, '_foo', foo)
    Foobar.test = test
    Foobar.setter = setter
    assert(Foobar.test == 'this is a test')
    assert(Foobar().test == 'this is a test')
    Foobar.setter = 'bar'
    assert(Foobar._foo == 'bar')
    assert(Foobar()._foo == 'bar')


# Generated at 2022-06-24 03:08:42.454417
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Person:
        counter = 0

        @setterproperty
        def age(self, value):
            if value < 0 or value > 130:
                raise ValueError('Invalid age: {}'.format(value))

            Person.counter += 1

            self._age = value

        @property
        def counter(self):
            return Person.counter

    person = Person()
    person.age = 37
    assert person.age == 37
    assert person.counter == 1
    person.age = 37
    assert person.counter == 1
    with raises(ValueError):
        person.age = -1
    assert person.counter == 2
    with raises(ValueError):
        person.age = 9999
    assert person.counter == 3



# Generated at 2022-06-24 03:08:48.450713
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:
        def __init__(self, param=None):
            self.x = param
            self.cnt = 0

        @setterproperty
        def setter(self, value):
            self.x = value
            self.cnt += 1

        @property
        def prop(self):
            return self.x

    a = Test('Hello')
    print(a.prop)
    print(a.cnt)
    a.setter = 'World'
    print(a.prop)
    print(a.cnt)
    a.setter = 'uni'
    print(a.prop)
    print(a.cnt)
    a.setter = 'Potsdam'
    print(a.prop)
    print(a.cnt)


# Generated at 2022-06-24 03:08:52.121355
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        @setterproperty
        def foo(self, value):
            self.value = value

    foo = Foo()
    foo.foo = 1
    assert foo.value == 1



# Generated at 2022-06-24 03:08:55.949000
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class String(object):
        @setterproperty
        def str(self, value):
            self._str = value
        @classmethod
        def get_str(cls):
            return cls._str
    s = String()
    s.str = 'Hello World'
    assert String.get_str() == 'Hello World'


# Generated at 2022-06-24 03:09:03.498554
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class test_instance(object):
        def __init__(self, value):
            self._value = value

        @classproperty
        def value(cls):
            return cls._value

    class test_class(object):
        @roclassproperty
        def value(cls):
            return cls._value

        _value = True

    class test_subclass(test_class):
        _value = False

    assert test_instance(True).value
    assert test_instance(False).value

    assert test_class.value
    assert test_subclass.value


# Generated at 2022-06-24 03:09:12.618027
# Unit test for constructor of class setterproperty
def test_setterproperty():
    from itertools import product

    class TestClass(object):
        def __init__(self):
            self.a = 1
            self.b = 1

        @setterproperty
        def a(self, value):
            self._a = value + self.b

        @setterproperty
        def b(self, value):
            self._b = value

    test_object = TestClass()
    for a, b in product(range(10), range(10)):
        test_object.a = a
        test_object.b = b
        assert(test_object._a == a + b)
        assert(test_object._b == b)

# Generated at 2022-06-24 03:09:20.550570
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        def __init__(self):
            self.name = "Parent"

        @lazyperclassproperty
        def num(cls):
            return 8

    class Child(Parent):
        def __init__(self):
            super(Child, self).__init__()
            self.name = "Child"
            self.num = 10

    obj = Child()
    print(obj.name)
    print(obj.num)



# Generated at 2022-06-24 03:09:28.596227
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:09:33.937390
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:09:38.992208
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:09:42.399169
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test():
        def __init__(self):
            self.x = 0

        @lazyclassproperty
        def x2(self):
            self.x += 1
            return self.x

    t1 = Test()
    t2 = Test()
    t3 = Test()
    assert(t1.x2 == 1)
    assert(t2.x2 == 1)
    assert(t3.x2 == 1)


# Generated at 2022-06-24 03:09:47.879812
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @staticmethod
        def _get_static():
            return 1

        @roclassproperty
        def value(cls):
            return 2

        @classproperty
        def value2(cls):
            return 3

        @classproperty
        def value3(cls):
            return cls._get_static()

    assert A.value == 2

    assert A.value2 == 3

    assert A.value3 == 1



# Generated at 2022-06-24 03:09:54.482866
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # Unit test for class setterproperty
    class C(object):
        @setterproperty
        def _foo(self, v):
            print("Setting", v)
            self.foo = 10 * v

        @_foo.setter
        def _foo(self, v):
            print("Setting", v)
            self.foo = v

    c = C()
    c._foo = 1
    c._foo = 2
    # will get AttributeError since _foo is not readable
    try:
        print(c._foo)
    except AttributeError:
        print("_foo is not readable")



# Generated at 2022-06-24 03:10:00.646856
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A:
        @lazyperclassproperty
        def prop(cls):
            print("prop called for %r" % cls)
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.prop == "A"
    assert B.prop == "B"
    assert C.prop == "C"
    assert A.prop == "A"
    assert B.prop == "B"
    assert C.prop == "C"



# Generated at 2022-06-24 03:10:06.816154
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    Tests setterproperty class.
    """

    class myclass(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def method(self, value):
            self.value = value

    obj = myclass(10)

    assert obj.value == 10
    obj.method = 20
    assert obj.value == 20
    with pytest.raises(AssertionError):
        obj.method()



# Generated at 2022-06-24 03:10:08.056372
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    assert isinstance(setterproperty(lambda x, y: None).__set__(None, None), NoneType)

# Generated at 2022-06-24 03:10:11.172379
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def f(cls):
            return cls.__name__

    assert A.f == 'A'


# Generated at 2022-06-24 03:10:16.084619
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    def f():
        return 'test'

    class C(object):
        @roclassproperty
        def f(self):
            return 'test'

    c = C()

    assert C.f == 'test'
    assert c.f == 'test'

    assert roclassproperty(f).__get__({}, C) == 'test'



# Generated at 2022-06-24 03:10:18.733114
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # obj, owner = None, None
    class TestClass(object):
        @roclassproperty
        def property(cls):
            return cls.__name__
    assert TestClass.property == 'TestClass'



# Generated at 2022-06-24 03:10:24.790077
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo: {cls}, id(cls): {id_}'.format(cls=cls, id_=id(cls))

        @lazyclassproperty
        def bar(cls):
            return 'bar: {cls}, id(cls): {id_}'.format(cls=cls, id_=id(cls))

    class B(A):
        pass

    class C(A):
        @classproperty
        def foo(cls):
            return 'C.foo: {cls}, id(cls): {id_}'.format(cls=cls, id_=id(cls))

    class D(A):
        pass


# Generated at 2022-06-24 03:10:30.658388
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self.value = 0

        @roclassproperty
        def ro(cls):
            return cls.value

    test = Test()
    test
    print(Test.ro)


if __name__ == "__main__":
    test_roclassproperty()

# Generated at 2022-06-24 03:10:36.183448
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        x = 0

        @setterproperty
        def inc(self, value):
            self.x = self.x + value

    t = Test()
    t.inc = 10
    assert t.x == 10
    t.inc = 5
    assert t.x == 15

# Generated at 2022-06-24 03:10:43.039140
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    '__call__' is called when the the class is instanciated.
    """
    class A(object):
        @setterproperty
        def value(self, v):
            self._value = v

    a = A()
    a.value = 1  # __set__ is called



# Generated at 2022-06-24 03:10:57.045569
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SetterPropertyTest(object):
        attr = setterproperty(lambda inst, value: setattr(inst, 'attr', value + '\n'))

    stp = SetterPropertyTest()
    stp_str = 'Setter Property'
    stp.attr = stp_str
    assert stp.attr == stp_str + '\n'



# Generated at 2022-06-24 03:11:00.021548
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def x(cls):
            return 10

    # Attributes are created once
    assert '_lazy_x' not in A.__dict__
    assert A.x == 10
    assert '_lazy_x' in A.__dict__



# Generated at 2022-06-24 03:11:08.441529
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def ro_attr(self):
            return 100

        @classproperty
        def any_attr(self):
            return 100

        @classmethod
        def bar(self):
            return 100

    assert Foo.ro_attr == 100
    Foo.ro_attr = 101
    assert Foo.ro_attr == 100
    assert Foo.any_attr == 100
    assert Foo.bar() == 100
    f = Foo()
    assert f.ro_attr == 100
    assert f.any_attr == 100
    try:
        f.bar()
        assert False
    except AttributeError:
        pass



# Generated at 2022-06-24 03:11:09.609981
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method __get__ of class roclassproperty
    """
    pass


# Generated at 2022-06-24 03:11:12.249468
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Demo:
        def __init__(self):
            self.a = 1
        @setterproperty
        def seta(self,a):
            self.a = a
        def geta(self):
            return self.a
    D = Demo()
    D.seta = 3
    assert D.geta() == 3

# Generated at 2022-06-24 03:11:21.569259
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 1

    assert A.foo == 1
    assert A().foo == 1
    assert A.foo == 1  # caching test

    class B(A):
        pass

    assert B.foo == 1
    assert B().foo == 1
    assert B.foo == 1  # caching test

    class C(B):
        @classproperty
        def foo(cls):
            return super(C, cls).foo + 1

    assert C.foo == 2
    assert C().foo == 2
    assert C.foo == 2  # caching test

    class D(B):
        @classproperty
        def foo(cls):
            return super(D, cls).foo + 2

    assert D.foo == 3



# Generated at 2022-06-24 03:11:27.001151
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:11:36.672240
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            pass

        @lazyperclassproperty
        def f(self):
            return self.__class__.__name__

    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()

    # A, B, C have distinct f property, which is also lazy:
    A.f
    B.f
    C.f
    a.f
    b.f
    c.f

    assert(A.f == 'A')
    assert(B.f == 'B')
    assert(C.f == 'C')
    assert(a.f == 'A')
    assert(b.f == 'B')
    assert(c.f == 'C')




# Generated at 2022-06-24 03:11:40.771112
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            print('class:', cls.__name__)

        @lazyperclassproperty
        def baz(cls):
            print('class:', cls.__name__)

    class Qux(Foo):
        pass

    print('Foo.bar:', Foo.bar)
    print('Foo.bar:', Foo.bar)
    print('Qux.bar:', Qux.bar)
    print('Qux.bar:', Qux.bar)
    print('\n')
    print('Foo.baz:', Foo.baz)
    print('Foo.baz:', Foo.baz)
    print('Qux.baz:', Qux.baz)

# Generated at 2022-06-24 03:11:50.358339
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        x = None

        @setterproperty
        def x(self, val):
            print('C.{}.x = {}'.format(id(self), val))

    c = C()
    c.x = 100
    # prints:
    # C.<...>.x = 100
    # this will also be printed when c1's x attribute is set
    c1 = C()
    c1.x = 200
    # prints:
    # C.<...>.x = 100
    # C.<...>.x = 200

    # c's x attribute is not changed
    print(c.x) # None
    print(c1.x) # None

    # neither of these will print anything
    c.x = 300
    c1.x = 400
    print(c.x) # None

# Generated at 2022-06-24 03:11:55.874642
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    # Test simple usage
    class Dummy:

        def set_foo(self, value):
            self._foo = value

        foo = setterproperty(set_foo)

    x = Dummy()
    x.foo = "Hello"
    assert x._foo == "Hello"

    # Test overwriting
    class Dummy:
        def __init__(self):
            self.__foo = "Hello"

        def set_foo(self, value):
            self.__foo = value

        foo = setterproperty(set_foo)

    d = Dummy()
    assert d.foo == "Hello"
    d.foo = "World"
    assert d.foo == "World"
    d.foo = "Testing"
    assert d.foo == "Testing"

    # Test passing None

# Generated at 2022-06-24 03:11:59.987439
# Unit test for constructor of class roclassproperty

# Generated at 2022-06-24 03:12:09.496460
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Tests method __set__ of class setterproperty.
    """
    class A(object):
        def __init__(self):
            self._x = 0

        @setterproperty
        def prop(self, val):
            self._x = val

        @property
        def prop(self):
            return self._x

    a = A()
    a.prop = 1
    assert a._x == 1

    # Test setterproperty with doc
    class B(object):
        def __init__(self):
            self._x = 0

        @setterproperty('This is a test')
        def prop(self, val):
            self._x = val

        @property
        def prop(self):
            return self._x

    b = B()
    b.prop = 1
    assert b._x == 1

# Generated at 2022-06-24 03:12:18.441690
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def num(cls):
            print('Returning num value')
            return 10

        @lazyperclassproperty
        def num_list(cls):
            print('Returning num_list value')
            return [10, 20, 30]
    class B(A):
        pass

    a = A()
    b = B()
    print('a.num', a.num)
    print('b.num', b.num)
    print('a.num_list', a.num_list)
    print('b.num_list', b.num_list)

# test_lazyperclassproperty()

# Generated at 2022-06-24 03:12:21.400829
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        _x = 1

        @classproperty
        def x(cls):
            return cls._x

    print(C.x)

    class D(C):
        _x = 2
    print(D.x)

    assert C.x == 1
    assert D.x == 2


# Generated at 2022-06-24 03:12:24.424788
# Unit test for constructor of class setterproperty
def test_setterproperty():
    @setterproperty
    def property_setter(obj, value):
        obj.x = value

    class A(object):
        y = property_setter

    a = A()
    a.y = "foo"
    assert "foo" == a.x



# Generated at 2022-06-24 03:12:29.665285
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # create our class

    class A:
        @roclassproperty
        def foo(self):
            return 3

    # accessing class property
    assert A.foo == 3

    # check that we can't set it
    try:
        A.foo = 1
    except AttributeError as e:
        pass


# check read only class property

# Generated at 2022-06-24 03:12:33.747993
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClass(object):
        @roclassproperty
        def dummyprop(cls):
            return 1

    d = DummyClass()
    assert d.dummyprop == 1
    assert d.__class__.dummyprop == 1



# Generated at 2022-06-24 03:12:38.911038
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class V(object):
        def __init__(self):
            self.val = 0
        @setterproperty
        def val(self, new):
            if self._val < 0:
                self._val = 0
            else:
                self._val = new

    v = V()
    v.val = 1

    if v.val != 1:
        #raise Exception("Failed")
        print("Fail")
    else:
        print("Pass")

test_setterproperty___set__()

# Generated at 2022-06-24 03:12:41.167275
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        foo = roclassproperty(lambda cls: cls)

    assert Foo is Foo.foo
    assert Foo() is not Foo.foo



# Generated at 2022-06-24 03:12:45.047157
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, i):
            self.i = i

        @setterproperty
        def d(self, value):
            return value

    t = Test(1)
    assert t.d == 1
    t.d = 3
    assert t.d == 3



# Generated at 2022-06-24 03:12:48.921618
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):
        pass

    class TestClass1(BaseClass):
        pass

    class TestClass2(BaseClass):
        pass

    @lazyperclassproperty
    def prop(cls):
        return 'value.'

    assert TestClass1.prop == 'value.'
    assert TestClass2.prop == 'value.'
    assert BaseClass.prop == 'value.'



# Generated at 2022-06-24 03:12:51.625813
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def Test(cls):
            print("running Test")
            return 'Hello'

    class TestClassSub(TestClass):
        pass

    print(TestClass.Test)
    print(TestClassSub.Test)
    print(TestClass.Test is TestClassSub.Test)



# Generated at 2022-06-24 03:12:55.720537
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestClass(object):
        class __metaclass__(type):
            def __init__(cls, name, bases, dct):
                type.__init__(cls, name, bases, dct)
                cls.test_val = setterproperty(cls.f)

        def __init__(self):
            self.value = 100

        def f(self, value):
            self.value = value

    c = TestClass()
    c.test_val = 10
    assert(c.value == 10)
    assert(c.test_val != 10)
    assert(c.test_val == 100)


# Generated at 2022-06-24 03:12:59.321579
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.foo = 0
        @setterproperty
        def foo(self, value):
            self._foo = value
    a = A()
    a.foo = 1
    assert a._foo == 1

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-24 03:13:09.412443
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self, strClassName, strClassDescription):
            self.class_name = strClassName
            self.clas_description = strClassDescription

    class TestClass1(TestClass):
        def __init__(self):
            TestClass.__init__(self, "TestClass1", "Class 1")

    class TestClass2(TestClass):
        def __init__(self):
            TestClass.__init__(self, "TestClass2", "Class 2")

    @roclassproperty
    def class_name(cls):
        return cls.__name__

    @roclassproperty
    def class_description(cls):
        return cls.__doc__ if cls.__doc__ is not None else "No description"

    class_1 = TestClass1

# Generated at 2022-06-24 03:13:17.552721
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return "A"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return "C"

    class D(C):
        pass

    assert A.x == "A"
    assert B.x == "A"
    assert C.x == "C"
    assert D.x == "C"

    A.x = "AA"
    assert A.x == "AA"
    assert B.x == "A"
    assert C.x == "C"
    assert D.x == "C"

    C.x = "CC"
    assert A.x == "AA"
    assert B.x == "A"
    assert C

# Generated at 2022-06-24 03:13:23.986595
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Dummy(object):
        def __init__(self):
            self._value = None

        @setterproperty
        def value(self, value):
            self._value = "foo " + value

    dummy = Dummy()
    assert dummy._value is None
    dummy.value = "bar"
    assert dummy._value == "foo bar"


# Generated at 2022-06-24 03:13:32.948594
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def value_1(cls):
            return "this is value 1"

        @lazyclassproperty
        def value_2(cls):
            return "this is value 2"

    class B(A):
        @lazyclassproperty
        def value_1(cls):
            return "this is value 1 in another class"

        @lazyclassproperty
        def value_3(cls):
            return "this is value 3 in another class"

    assert A.value_1 == "this is value 1"
    assert A.value_2 == "this is value 2"
    assert B.value_1 == "this is value 1 in another class"
    assert B.value_2 == "this is value 2"

# Generated at 2022-06-24 03:13:40.889371
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        class_value = 'A'
        __metaclass__ = roclassproperty

        def __init__(self, instance_value):
            self.instance_value = instance_value

    class B(A):
        class_value = 'B'

    a_inst = A('a_inst')
    b_inst = B('b_inst')

    assert a_inst.__class__.class_value == 'A'
    assert b_inst.__class__.class_value == 'B'
    assert a_inst.class_value == 'A'
    assert b_inst.class_value == 'B'

# Generated at 2022-06-24 03:13:44.550409
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1
    assert A.x == 1
    assert A._lazy_x == 1
    A.x = 2
    assert A._lazy_x == 2



# Generated at 2022-06-24 03:13:49.546518
# Unit test for function lazyclassproperty