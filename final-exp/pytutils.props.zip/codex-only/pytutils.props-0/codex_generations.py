

# Generated at 2022-06-24 03:03:53.433821
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        pass

    @setterproperty
    def test(self, _):
        pass

    a = A()

    assert not hasattr(a, 'test')

    a.test = None

    assert hasattr(a, 'test')
    assert a.test is None



# Generated at 2022-06-24 03:03:58.292248
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('calculated')
            return 42

    class Bar(Foo):
        pass

    class Baz(Foo):
        pass

    assert Foo.bar == bar
    assert Bar.bar == bar
    assert Baz.bar == bar



# Generated at 2022-06-24 03:04:02.914191
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def f(self):
            return 42
        attr = roclassproperty(f)

    assert 42 == A().attr
    assert 42 == A.attr



# Generated at 2022-06-24 03:04:11.710649
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def spam(cls):
            print('A.spam')
            return 'spam'

    class B(A):
        @lazyclassproperty
        def spam(cls):
            print('B.spam')
            return 'spam'

    print(A.spam)
    print(A.spam)
    print(B.spam)
    print(B.spam)
    # The main difference with the other 2 implementations is that this one is "lazy" in the sense that the property is
    # only created once the class is accessed, not when the class is defined.



# Generated at 2022-06-24 03:04:20.501081
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return "A"
    class B(A):
        pass
    class C(A):
        @lazyperclassproperty
        def x(cls):
            return "C"
    class D(C):
        pass

    assert A.x is B.x is C.x is D.x
    assert A.x == "A"
    assert C.x == "C"



# Generated at 2022-06-24 03:04:23.206446
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class a(object):
        @lazyclassproperty
        def sample(cls):
            return 2
    assert a.sample == 2

# Generated at 2022-06-24 03:04:30.658433
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test for function lazyperclassproperty
    """
    # pylint: disable=C0111

    class Foo(object):
        pass

    class Bar(Foo):
        pass

    @lazyperclassproperty
    def name(foo):
        return foo.__name__

    assert name is Foo.name
    assert name is Bar.name
    assert name._lazyvalue is Bar.name._lazyvalue  # pylint: disable=W0212
    assert name._lazyvalue is not Foo.name._lazyvalue  # pylint: disable=W0212



# Generated at 2022-06-24 03:04:32.981187
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        @setterproperty
        def x(self, x):
            self.a = x

    a = A()
    a.x = 4

    assert a.a == 4


# Generated at 2022-06-24 03:04:39.018227
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Super(object):
        @lazyperclassproperty
        def child_property(cls):
            return cls.__name__

    assert Super.child_property == Super.__name__

    class SubClass(Super):
        pass

    assert Super.child_property == Super.__name__
    assert SubClass.child_property == SubClass.__name__


# Generated at 2022-06-24 03:04:43.600548
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def my_prop(cls):
            return 'abc'

    assert A.__dict__['my_prop'].__get__(A()) is 'abc'


# Generated at 2022-06-24 03:04:48.701958
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = None

    class B(A):
        _a = setterproperty(lambda self, v: setattr(self, 'a', v * 2))

    b = B()
    b.a = 2
    assert(b.a == 4)
    b._a = 5
    assert(b.a == 10)



# Generated at 2022-06-24 03:04:52.679056
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def value(cls):
            return 'value'

    # noinspection PyProtectedMember
    assert Test._value is Test.value



# Generated at 2022-06-24 03:04:57.009026
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Demo(object):
        @roclassproperty
        def foo(cls):
            return "foo"

    d = Demo() # no call to __init__ of demo

    assert Demo.foo == 'foo'
    assert d.foo == 'foo'
    assert d.foo == Demo.foo



# Generated at 2022-06-24 03:05:03.122023
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self):
            self._x = None

        @roclassproperty
        def x(cls):
            return 'x'

        @classproperty
        def y(cls):
            return 'y'

    o = A()
    assert o.x == 'x'
    assert A.x == 'x'
    assert o.y == 'y'
    assert A.y == 'y'

# Generated at 2022-06-24 03:05:08.029835
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class HasLazyProperty(object):
        @lazyclassproperty
        def lazyprop(cls):
            return id(cls)
    class InheritLazyProperty(HasLazyProperty):
        pass
    class InheritLazyAgain(InheritLazyProperty):
        pass

    assert HasLazyProperty.lazyprop != InheritLazyProperty.lazyprop
    assert InheritLazyProperty.lazyprop != InheritLazyAgain.lazyprop
    assert HasLazyProperty.lazyprop != InheritLazyAgain.lazyprop



# Generated at 2022-06-24 03:05:16.514792
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Person(object):
        def __init__(self, name):
            self.name = name

        @roclassproperty
        def foo(cls):
            return cls.name

    p = Person('sam')
    assert p.foo == 'sam'

    class Student(Person):
        def __init__(self, name, studentno):
            super(Student, self).__init__(name)
            self.studentno = studentno

        @roclassproperty
        def foo(cls):
            return '%s %s' % (cls.name, cls.studentno)

    s = Student('jam', '003')
    assert s.foo == 'jam 003'


# Generated at 2022-06-24 03:05:24.932135
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TClass1:
        a = 1
        def __init__(self):
            self.b = 2
        def __get__(self, obj, owner):
            return self.b
    class TClass2(TClass1):
        a = 3
        def __init__(self):
            super(TClass2, self).__init__()
            self.a = 4
        @roclassproperty
        def b(cls):
            return cls.a * 2
    assert TClass1().b == 2
    assert TClass2().b == 8


# Generated at 2022-06-24 03:05:27.824962
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def test(self, val):
            self.val = val


# Generated at 2022-06-24 03:05:34.735979
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        test_value = None
        def __init__(self):
            A.test_value = self

        @roclassproperty
        def test_property(cls):
            return cls.test_value

    class B(A):
        pass

    a = A.test_property
    b = B.test_property
    assert a is b is A.test_value
    assert a is b is B.test_value
    assert id(a) == id(b)
    assert id(a) == id(A.test_value)
    assert id(b) == id(B.test_value)



# Generated at 2022-06-24 03:05:38.010980
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return cls

    assert Foo.foo == Foo
    assert Foo().foo == Foo


# Generated at 2022-06-24 03:05:43.266207
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Start(object):
        _x = "X"

        @roclassproperty
        def x(self):
            return self._x

    class Middle(Start):
        _x = "M"

    class End(Middle):
        _x = "E"

    print(Start.x, Middle.x, End.x)
    Start.x = "lala"


if __name__ == "__main__":
    test_roclassproperty___get__()

# Generated at 2022-06-24 03:05:50.555593
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            self._value += value

    foo = Foo(0)
    foo.value = 1
    assert foo._value == 1
    foo.value = 100
    assert foo._value == 101
    foo.value = -foo._value
    assert foo._value == 0


# Generated at 2022-06-24 03:05:54.533485
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo'

    class B(A):
        pass

    assert A.foo == 'foo'
    assert B.foo == A.foo
    assert B.foo == 'foo'

    c = A()
    assert type(c).foo == 'foo'



# Generated at 2022-06-24 03:05:58.500799
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            return 1
    class B(A):
        pass

    assert A.prop == 1
    assert B.prop == 1


# Generated at 2022-06-24 03:06:02.929808
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @classproperty
        def c(cls):
            return 'lily'

    assert A.c == 'lily'
    a = A()
    assert a.c == 'lily'
    assert A.c == 'lily'
    assert a.c == 'lily'


# Generated at 2022-06-24 03:06:04.196156
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def __init__(self, x):
            self.x = x

    assert Foo.x == X

# Generated at 2022-06-24 03:06:08.141208
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):

        @setterproperty
        def setterproperty_test(self, value):
            self.test = value

    test = TestSetterProperty()
    test.setterproperty_test = 10
    assert test.test == 10, 'Setter property does not set test variable'



# Generated at 2022-06-24 03:06:11.039727
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        def __init__(self):
            self.a = 'a'
        a = roclassproperty(lambda x: 'b')
        __str__ = lambda x: x.a
    assert str(Test()) == 'b'


# Generated at 2022-06-24 03:06:16.598317
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def version(cls):
            return "1.0"

    assert A.version == "1.0"
    assert A.version == "1.0"
    assert A.__dict__.get('_lazy_version') == "1.0"



# Generated at 2022-06-24 03:06:19.934706
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import pytest
    class Foo(object):
        def __init__(self, x):
            self.x = x
        @setterproperty
        def x(self, x):
            return x**2
    foo = Foo(2)
    foo.x = 2
    assert foo.x == 4
    with pytest.raises(AttributeError):
        foo.x = 1



# Generated at 2022-06-24 03:06:26.470259
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class T1(object):
        @lazyclassproperty
        def foo(cls):
            return "foo"

    class T2(T1):
        @lazyclassproperty
        def foo(cls):
            return "foo2"

    assert T1().foo == T1().foo
    assert T1().foo == "foo"
    assert T2().foo == T2().foo
    assert T2().foo != T1().foo



# Generated at 2022-06-24 03:06:31.862008
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    attrs = {'x': 3}
    del attrs['x']
    class Foo(object):
        def __init__(self):
            self.__dict__.update(attrs)
        @roclassproperty
        def x(cls):
            return 20

    assert Foo().x == 20
    assert Foo.x == 20


# Generated at 2022-06-24 03:06:36.212294
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class UnitTestLazyClassProperty:
        @lazyclassproperty
        def x(cls):
            return "test"

    assert UnitTestLazyClassProperty.x == "test"
    assert UnitTestLazyClassProperty.__dict__['_lazy_x'] == "test"



# Generated at 2022-06-24 03:06:38.615249
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        classproperty = roclassproperty(lambda cls: "value")
    roclass_property = MyClass.classproperty
    assert roclass_property == "value"

# Generated at 2022-06-24 03:06:45.234091
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def a(cls):
            return 1

    class Child(Base):
        pass

    class Child2(Child):
        pass

    class Child3(Child2):
        pass

    assert Base.a == 1
    assert Base._Base__a_lazy_a == 1
    assert Child._Child__a_lazy_a == 1
    assert Child2._Child2__a_lazy_a == 1
    assert Child3._Child3__a_lazy_a == 1



# Generated at 2022-06-24 03:06:48.778572
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.variable = 0

        @setterproperty
        def setter(self, value):
            self.variable = value


    a = A()
    assert a.variable == 0
    a.setter = 1
    assert a.variable == 1

# Generated at 2022-06-24 03:06:53.998966
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    _l = property()

    def _fn(self, v):
        _l.__set__(self, v)

    class _Test(object):
        p1 = _fn

        @setterproperty
        def p2(self, v):
            _l.__set__(self, v)

    _t = _Test()
    _t.p1 = 1
    assert _l.__get__(_t) == 1
    _t.p2 = 2
    assert _l.__get__(_t) == 2



# Generated at 2022-06-24 03:06:57.919613
# Unit test for constructor of class setterproperty

# Generated at 2022-06-24 03:07:02.564027
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def lazyproperty(cls):
            print('in lazyproperty')
            return 666

    t = TestClass()
    TestClass.lazyproperty
    TestClass.lazyproperty
    TestClass.lazyproperty
    t.lazyproperty
    t.lazyproperty
    t.lazyproperty

test_lazyclassproperty()

# Generated at 2022-06-24 03:07:06.546910
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self.__test = 1

        @roclassproperty
        def test(cls):
            return cls.__test

        @test.setter
        def test(cls, value):
            cls.__test = value

    assert Test.test == 1
    Test.test = 2
    assert Test.test == 2



# Generated at 2022-06-24 03:07:09.252742
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class testclass(object):
        @roclassproperty
        def roprop(self):
            return "test"

    print(testclass.roprop)
    testobj = testclass()
    print(testobj.roprop)



# Generated at 2022-06-24 03:07:13.034628
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """It should set value to desired object"""
    class Person(object):
        def __init__(self):
            self.name = ""

        def setter(self, value):
            self.name = value

        name = setterproperty(setter)
    person = Person()
    # It should set value to desired object
    person.name = 'Jon'
    assert person.name == 'Jon'


# Generated at 2022-06-24 03:07:15.620039
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test __get__
    """

    class A(object):
        @roclassproperty
        def x(cls):
            return 3

    #class A:
    #    @roclassproperty
    #    def x(cls):
    #        return 3
    #        classmethod(x)

    assert A.x == 3


# Generated at 2022-06-24 03:07:22.653870
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self._val = None


# Generated at 2022-06-24 03:07:26.855566
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Test(object):
        @setterproperty
        def a(self, value):
            print('Setting "a" to', value)
            self._a = value

        @property
        def a(self):
            return self._a

    t = Test()
    t.a = 5
    assert t.a == 5



# Generated at 2022-06-24 03:07:30.274429
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClass(object):
        def get_dummy_value(cls):
            return 'dummy value'
        dummy_value = roclassproperty(get_dummy_value)

    result = DummyClass.dummy_value
    assert result == 'dummy value'



# Generated at 2022-06-24 03:07:36.194958
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import math

    class SquareRoot:
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            if value < 0:
                raise ValueError("Cannot calculate square root of negative number {}".format(value))
            self.__x = value

        @property
        def y(self):
            return math.sqrt(self.__x)


    sqrt = SquareRoot()
    sqrt.x = 9
    assert sqrt.y == 3

    # Setter must raise ValueError if value is negative
    try:
        sqrt.x = -9
        assert False
    except ValueError as ex:
        assert str(ex) == "Cannot calculate square root of negative number -9"

    assert sqrt.y == 3

    # Setter must

# Generated at 2022-06-24 03:07:40.554139
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return "bar"
    class B(A):
        @lazyclassproperty
        def foo(cls):
            return "spam"
    class C(B):
        pass

    assert A.foo == "bar"
    assert B.foo == "spam"
    assert C.foo == "spam"

# Generated at 2022-06-24 03:07:44.111023
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class A(object):

        def _initialize(self, x):
            self.x = x
        x = setterproperty(_initialize)

    a = A()
    a.x = 2
    assert a.x == 2

# Generated at 2022-06-24 03:07:49.968805
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def get_foo(self):
            return self._foo

        def set_foo(self, foo):
            self._foo = foo

        foo = setterproperty(get_foo, set_foo)

    # test the getter
    a = A()
    assert a.foo is None
    a._foo = 1
    assert a.foo == 1

    # test the setter
    a.foo = 2
    assert a._foo == 2

# Generated at 2022-06-24 03:07:58.539357
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def test(cls):
            print("Calculating", cls)
            return cls.__name__

    class Derived(Base):
        @lazyperclassproperty
        def test(cls):
            print("Calculating", cls)
            return cls.__name__

    assert Base.test == "Base"
    assert Derived.test == "Derived"


# Generated at 2022-06-24 03:08:01.174732
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        @setterproperty
        def f(self,value):
            self.temp = value

    A = C()
    A.f = 10
    print(A.temp)


# Generated at 2022-06-24 03:08:08.131008
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        def __init__(self, name):
            self.name = name

        @setterproperty
        def name(self, n):
            if n is None:
                raise ValueError('name must not be None')
            self.__myname__ = n

    o = Obj('harold')
    assert o.name == 'harold'
    o.name = 'lily'
    assert o.name == 'lily'

    try:
        o.name = None
    except ValueError as e:
        assert e.args[0] == 'name must not be None'
    else:
        assert False

# Generated at 2022-06-24 03:08:10.786244
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        z = setterproperty(lambda self, value: setattr(self, '_z', value))

    c = C()
    c.z = 2

    assert c._z == 2



# Generated at 2022-06-24 03:08:17.935969
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def __classprop(cls):
            return 1

    assert A.__classprop == 1
    assert A.__dict__['_lazy___classprop'] == 1
    A.__classprop = 2
    assert A.__dict__['_lazy___classprop'] == 2



# Generated at 2022-06-24 03:08:20.216094
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
	assert setterproperty(lambda self, value: self._value, '').__set__(None, 12) == 12

# Generated at 2022-06-24 03:08:26.632506
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def v(cls):
            return 'v in cls Base: %s' % id(cls)

    class Derived1(Base):
        pass

    class Derived2(Base):
        pass

    assert Base.v == 'v in cls Base: %s' % id(Base)
    assert Derived1.v == 'v in cls Base: %s' % id(Derived1)
    assert Derived2.v == 'v in cls Base: %s' % id(Derived2)
    assert Base.v == 'v in cls Base: %s' % id(Base)


# Generated at 2022-06-24 03:08:28.201145
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def get_x(cls):
            return 1

        x = roclassproperty(get_x)

    assert A.x == 1



# Generated at 2022-06-24 03:08:31.962905
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        a = 0
        @setterproperty
        def b(self, val):
            self.a += val
            return self.a
    a = A()
    assert a.b == 0
    assert a.b == 0
    a.a = 10
    assert a.b == 20

# Generated at 2022-06-24 03:08:38.715243
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        __test__ = False
        @lazyperclassproperty
        def random_number(cls):
            return random.randint(1, 100)

    class DerivedA(Base):
        __test__ = False

    class DerivedB(Base):
        __test__ = False

    for base in [Base, DerivedA, DerivedB]:
        assert base.random_number != Base.random_number
        assert base.random_number == base.random_number
        assert base.random_number != Base.random_number
    ## Test a second time, to check that memoization works
    for base in [Base, DerivedA, DerivedB]:
        assert base.random_number != Base.random_number
        assert base.random_number == base.random_number
        assert base.random_number

# Generated at 2022-06-24 03:08:45.681403
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Unit test function to test lazyclassproperty
    """
    class TestClass(object):
        flag_dynamic = False
        flag_static = False
        flag_lazy = False

        @classproperty
        def dynamic(cls):
            cls.flag_dynamic = True
            return 1

        static = 2
        @lazyclassproperty
        def lazy(cls):
            cls.flag_lazy = True
            return 3

    test_obj = TestClass()
    assert test_obj.dynamic == false, "Static class property dynamic has been called"
    assert test_obj.static == 2, "Static class property static has not been called"
    assert test_obj.lazy == 3, "Lazy class property lazy has not been called"
    TestClass.dynamic
    TestClass.lazy
   

# Generated at 2022-06-24 03:08:54.988338
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return cls

    class B(A):
        pass

    class C(B):
        pass

    class D(A):
        pass

    assert id(A.test) == id(A.test)
    assert id(B.test) == id(B.test)
    assert id(C.test) == id(C.test)
    assert id(D.test) == id(D.test)
    assert id(A.test) != id(B.test)
    assert id(A.test) != id(C.test)
    assert id(A.test) != id(D.test)
    assert id(B.test) != id(C.test)

# Generated at 2022-06-24 03:09:00.721218
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return "foo"

    assert A.foo == "foo"
    assert A().foo == "foo"



# Generated at 2022-06-24 03:09:06.018366
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Base(object):
        @roclassproperty
        def f(cls):
            return "hello from base"
    class Derived(Base):
        @roclassproperty
        def f(cls):
            return "hello from derived"

    assert Base.f is Derived.f
    assert Base.f == Base.f
    assert Base.f != Derived.f
    assert Base.f != "hello from derived"
    assert Derived.f != "hello from base"
    assert Base.f == "hello from base"
    assert Derived.f == "hello from derived"

    assert Base().f is Derived().f
    assert Base().f == Base().f
    assert Base().f != Derived().f
    assert Base().f != "hello from derived"
    assert Derived().f != "hello from base"
   

# Generated at 2022-06-24 03:09:10.055144
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        def _get_a(self):
            return 1

        a = roclassproperty(_get_a)

    from pytest import raises
    with raises(AttributeError):
        C.a = 2
    assert C.a == 1



# Generated at 2022-06-24 03:09:15.615451
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self, x):
            self.a = x

        @setterproperty
        def a(self, x):
            if x < 0:
                x = 0
            self.__dict__['a'] = x

    a = A(5)
    a.a = -10
    a.a = 10
    assert a.a == 10



# Generated at 2022-06-24 03:09:18.455280
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return "baz"

    assert Foo.bar == "baz"



# Generated at 2022-06-24 03:09:27.681404
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class _target(object):
        __slots__ = ['x']

        def __init__(self):
            self.x = 2

        @setterproperty
        def x(self, value):
            if not isinstance(value, int):
                raise ValueError()
            self.__x = value

        @x.getter
        def x(self):
            return self.__x

    o = _target()
    o.x = 3
    assert o.x == 3
    raises(ValueError, 'o.x = "a"')



# Generated at 2022-06-24 03:09:31.005813
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class D(object):
        pass

    dp = roclassproperty(lambda cls: cls.__name__)

    assert dp.__get__(None, D) == 'D'



# Generated at 2022-06-24 03:09:33.818896
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        _value = ''
        @setterproperty
        def value(self, value):
            self._value = value
    t = Test()
    t.value = '123'
    assert t._value == '123'

# Generated at 2022-06-24 03:09:36.316276
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def foo(self, value):
            self._foo = value
    foo = Foo()
    foo.foo = 10
    assert foo._foo == 10



# Generated at 2022-06-24 03:09:39.002749
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        @roclassproperty
        def myroproperty(cls):
            return 'this is the ro property of %s' % cls.__name__

    assert MyClass.myroproperty == 'this is the ro property of MyClass'



# Generated at 2022-06-24 03:09:45.114169
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class aclass:
        @setterproperty
        def prop(self, val):
            self.prop_val = val

    instance = aclass()
    instance.prop = 'Rocks.'
    assert hasattr(instance, 'prop_val')
    assert instance.prop_val == 'Rocks.'
    instance.prop = 'Fails.'
    assert instance.prop_val == 'Rocks.'



# Generated at 2022-06-24 03:09:46.437951
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'



# Generated at 2022-06-24 03:09:49.976605
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a = 1
        def set_a(self, value):
            self.a = value
        b = setterproperty(set_a)

    a = A()
    assert a.a == 1
    a.b = 2
    assert a.a == 2


# Unit test of the constructor of class lazyclassproperty

# Generated at 2022-06-24 03:09:55.472857
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Try to instantiate a roclassproperty object
    ocp = roclassproperty(str)
    # Try to get a property value from a roclassproperty object
    v = ocp.__get__(None, str)


# Generated at 2022-06-24 03:09:57.962357
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def func(cls):
            return cls
        x = roclassproperty(func)

    assert Foo.x is Foo
    assert Foo().x is Foo



# Generated at 2022-06-24 03:10:06.407827
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def _get_foo(self):
            return self._foo

        def _set_foo(self, v):
            self._foo = v

        foo = property(_get_foo, _set_foo)

    class B(A):
        foo = setterproperty(_set_foo)

    a = A()
    b = B()

    # a.foo = 'foo'
    b.foo = 'bar'
    assert b._foo == 'bar'

    try:
        a.foo = 'foo'
    except AttributeError:
        pass
    else:
        assert False



# Generated at 2022-06-24 03:10:08.614001
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def foo():
            return 'bar'
    class B(A):
        pass
    a = A()
    b = B()
    assert a.foo == 'bar'
    assert b.foo == 'bar'



# Generated at 2022-06-24 03:10:13.738672
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def bar(cls):
            return 'bar'

    class B(A):
        pass

    a = A()
    b = B()
    print(a.bar, A.bar, B.bar)
    print(b.bar, B.bar)
    # print(b.bar())


# Generated at 2022-06-24 03:10:19.320530
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def prop(cls):
            return {}

    class Bar(Foo):
        pass

    foo = Foo()
    bar = Bar()

    foo.prop['a'] = 1
    bar.prop['b'] = 2

    assert(foo.prop == {'a': 1})
    # Bar's prop should be isolated from Foo's.
    assert(bar.prop == {'b': 2})



# Generated at 2022-06-24 03:10:27.400195
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    public_value = 0
    class Test(object):
        @lazyclassproperty
        def my_lazy_property(cls):
            return public_value

    t = Test()
    assert t.my_lazy_property == 0
    public_value += 1
    assert t.my_lazy_property == 1

    public_value += 1
    assert t.my_lazy_property == 1

    class Test2(Test):
        pass

    t = Test2()
    assert t.my_lazy_property == 1

    public_value += 1
    assert t.my_lazy_property == 1

# Generated at 2022-06-24 03:10:33.093908
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            return 10
    assert isinstance(Test.test, roclassproperty)
    assert Test.test == 10
    try:
        t = Test()
        t.test = 20
    except Exception as e:
        # Caught exception
        print(e.__class__.__name__, str(e))
    else:
        assert False, "Expected exception not caught"



# Generated at 2022-06-24 03:10:37.563360
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """Unit test for method ``roclassproperty.__get__``"""

    class BaseFoo(object):

        @roclassproperty
        def bar(cls):
            return cls.__name__
    # param: obj:
    # param: owner:
    # return a new class BaseFoo() instance
    test_obj = BaseFoo()
    assert(test_obj.bar == "BaseFoo")



# Generated at 2022-06-24 03:10:45.109629
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Sparrow(object):
        __name = 'sparrow'
        __age  = 0
        @setterproperty
        def name(self, name):
            self.__name = name
        @setterproperty
        def age(self, age):
            self.__age = age
        def __str__(self):
            return 'name:%s, age:%d'%(self.__name, self.__age)
    sparrow = Sparrow()

# Generated at 2022-06-24 03:10:48.500227
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        class B(object):
            pass

        a = 1

        @roclassproperty
        def b(cls):
            cls.a = 2
            return cls.B

    assert TestClass.b is TestClass.B
    assert TestClass.a == 1



# Generated at 2022-06-24 03:10:51.410742
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        x = roclassproperty(lambda cls: 'result')
    assert(A.x == 'result')
    a = A()
    assert(a.x == 'result')


# Generated at 2022-06-24 03:10:53.859455
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    @addToClass(Test)
    class X:
        @roclassproperty
        def x(cls):
            return cls.__name__

    assert X.x == 'Test'


# Generated at 2022-06-24 03:11:01.294739
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self, val):
            self.val = val

    class B(A):
        pass

    class C(A):
        pass

    class D(B):
        pass

    class E(C):
        pass

    class F(D, E):
        pass

    @lazyperclassproperty
    def foo(cls):
        return cls.__name__ + '_instance'

    @lazyperclassproperty
    def bar(cls):
        return cls.__name__ + 'bar'

    a = A(1)
    b = B(2)
    c = C(3)
    d = D(4)
    e = E(5)
    f = F(6)

    assert(a.foo is A.foo)

# Generated at 2022-06-24 03:11:05.111058
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    from datetime import datetime

    class Foo:
        @roclassproperty
        def bar(cls):
            return datetime.today().isoformat()

    assert Foo.bar == Foo.bar
    assert Foo.bar != Foo.bar

    assert isinstance(Foo.bar, str)
    assert Foo.bar.__class__ == str

    foo = Foo()
    assert foo.bar == Foo.bar
    assert foo.bar.__class__ == str



# Generated at 2022-06-24 03:11:11.573267
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class BaseClass(object):
        @lazyclassproperty
        def test(cls):
            return "Hello World"

        def __init__(self, name):
            self.name = name

    class FirstInheritor(BaseClass):
        pass

    class SecondInheritor(BaseClass):
        pass

    assert BaseClass.test == "Hello World"
    assert FirstInheritor.test == "Hello World"
    assert SecondInheritor.test == "Hello World"
    assert FirstInheritor().test == "Hello World"
    assert SecondInheritor().test == "Hello World"

    FirstInheritor.test = "Hello Universe"
    assert BaseClass.test == "Hello World"
    assert FirstInheritor.test == "Hello Universe"
    assert SecondInheritor.test == "Hello World"

# Generated at 2022-06-24 03:11:21.351550
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from unittest import TestCase, main
    from g1.devtools import testutils

    class TestSpec:
        counter = 0

        @setterproperty
        def prop(self, value):
            self.counter += 1

        def __getattr__(self, name):
            # Prevent Unittest from blowing up.
            raise AttributeError

    class Test(TestCase):

        def setUp(self):
            self.x = TestSpec()
            self.x.counter = 0

        def tearDown(self):
            testutils.remove_if_exists(self.x, 'counter')

        @testutils.run_test_in_subprocess
        def test_setterproperty___set__(self):
            self.assertEqual(self.x.counter, 0)
            self.x.prop = 123
           

# Generated at 2022-06-24 03:11:24.740700
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class myclass(object):
        def __init__(self):
            self.__prop = 0

        @roclassproperty
        def prop(cls):
            return cls.__prop

        @prop.setter
        def prop(cls, val):
            cls.__prop = val


# Generated at 2022-06-24 03:11:27.000963
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test normal case
    class Test:
        @roclassproperty
        def test(cls):
            return "test"
    assert Test.test == "test"



# Generated at 2022-06-24 03:11:28.805160
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def _get_value(cls):
            return cls.__name__

        value = roclassproperty(_get_value)

    assert A.value == 'A'



# Generated at 2022-06-24 03:11:31.116577
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 1

    class B(A):
        pass

    assert A.x == 1
    assert B.x == 1
    A.x = 5
    assert A.x == 5
    assert B.x == 1



# Generated at 2022-06-24 03:11:40.796198
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Services(object):
        service_name = roclassproperty(lambda cls: cls.__name__.lower())
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    service_1 = Services("service_1")
    print(service_1.service_name)
    print(service_1.get_name())
    assert service_1.service_name == "services"
    assert service_1.get_name() == "service_1"


# Generated at 2022-06-24 03:11:50.068060
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            """I'm the x property"""
            self._x = value

        @x.getter
        def x(self):
            """I'm the x property"""
            return self._x

        @property
        def y(self):
            """I'm the y property"""
            return self._x

    obj = C()

    assert obj.x is None
    obj.x = 42
    assert obj.x == obj._x == 42
    assert obj.x == obj.y == 42
    assert C.x.__doc__ == obj.x.__doc__ == obj.y.__doc__ == "I'm the x property"

# Generated at 2022-06-24 03:11:51.984291
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        y = lazyperclassproperty(lambda cls: cls.x + ' hello')
        x = 'A'

    class B(A):
        x = 'B'

    assert A.y == 'A hello'
    assert B.y == 'B hello'

# Generated at 2022-06-24 03:11:56.620519
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test for method `setterproperty.__set__`
    """
    class OBJ:
        @setterproperty
        def a(self, value):
            self.a_ = value

    o = OBJ()

    o.a = 10

    assert o.a_ == 10



# Generated at 2022-06-24 03:11:58.725744
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class C(object):
        @roclassproperty
        def prop(cls):
            return 1
    assert C.prop == 1



# Generated at 2022-06-24 03:12:08.789413
# Unit test for constructor of class setterproperty
def test_setterproperty():

    def _setter(self, value):
        self._value = value

    # create setter
    s = setterproperty(_setter, 'The setter property')
    assert s.__doc__ == 'The setter property'

    # create class with property
    class MyClass:
        x = s     # this does the property binding
        y = 42    # normal attribute

    m = MyClass()
    assert m.x is None
    assert m.y == 42

    m.x = 100
    assert m.x == 100
    assert m.y == 42


# Generated at 2022-06-24 03:12:11.823737
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def foo(self, value):
            self.bar = value
    a = A()
    a.foo = setterproperty(a.foo)
    a.foo = 5
    assert a.bar == 5

# Generated at 2022-06-24 03:12:13.630658
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class X(object):
        @roclassproperty
        def foo(cls):
            return 1

    assert X.foo == 1
    assert X().foo == 1



# Generated at 2022-06-24 03:12:16.453138
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self): self.x = 0
        @setterproperty
        def prop(self, value): self.x = value
    c = C()
    c.prop = 1
    assert c.x == 1


# Generated at 2022-06-24 03:12:21.813657
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    if d.get_args().get_debug_level() > 2:
        print('BEGIN UNIT TEST %s()' % sys._getframe().f_code.co_name)

    class A(object):

        def __init__(self, v):
            self._v = v

        @roclassproperty
        def value(cls):
            return cls._v

    class B(A):

        def __init__(self):
            A.__init__(self, 'A')
            self._v = 'B'

    a = A(1)
    b = B()

    if d.get_args().get_debug_level() > 2:
        print('a.value: %s' % a.value)
        print('b.value: %s' % b.value)


# Generated at 2022-06-24 03:12:27.480618
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print('a')
            return 'A'

    class B(A):
        @lazyclassproperty
        def b(cls):
            print('b')
            return 'B'

    class C(A):
        @lazyclassproperty
        def b(cls):
            print('B')
            return 'B'

    class D(A):
        pass

    class X(B, A):
        pass

    class Y(C, D):
        pass

    class Z(C, B, D):
        pass

    assert A.a == 'A'
    assert B.a == 'A'
    assert B.b == 'B'
    assert C.b == 'B'

    assert D.a == 'A'

# Generated at 2022-06-24 03:12:32.222633
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__
    assert MyClass.name == 'MyClass'
    assert MyClass().name == 'MyClass'



# Generated at 2022-06-24 03:12:39.172351
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(self):
            return 'val'
    assert A.prop is A.prop
    assert A.prop == 'val'
    assert A().prop == 'val'

    class B(A):
        pass
    assert B.prop is A.prop

    class C(A):
        @lazyclassproperty
        def prop(self):
            return 'val2'
    assert C().prop == 'val2'
    assert C.prop is not A.prop



# Generated at 2022-06-24 03:12:41.972244
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class a(object):
        property1 = setterproperty(lambda self, value: setattr(self, '_prop', value))
    object1 = a()
    object1.property1 = "123"
    assert object1._prop == "123"

# Generated at 2022-06-24 03:12:47.490650
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 5

    foo = Foo()
    assert foo.bar == 5
    try:
        foo.bar = 2
    except Exception as e:
        return True
    return False


# Generated at 2022-06-24 03:12:54.718398
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:56.889985
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A():
        def getX(cls):
            return cls.x

        x = roclassproperty(getX)

    assert A.x == None



# Generated at 2022-06-24 03:13:05.396622
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def get(self):
            pass

        def set(self, val):
            pass

        def del_(self):
            pass

        x = property(get, set, del_)

        def set_test(self, value):
            return 'test.%s' % value

        test = setterproperty(set_test)

    a = A()
    assert a.test == 'test.None'
    a.test = 'bla'
    assert a.test == 'test.bla'



# Generated at 2022-06-24 03:13:07.836141
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        a = roclassproperty(lambda cls: cls.__name__)

    assert A.a == 'A'



# Generated at 2022-06-24 03:13:10.685378
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):
        @roclassproperty
        def attr(cls):
            return 1

    a = foo()

    if a.attr != 1:
        return False

    return True



# Generated at 2022-06-24 03:13:13.488750
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:16.975149
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def setterprop(x):
        def decorated(cls):
            return SetterTest(x)
        return decorated

    class SetterTest(setterproperty):
        def __init__(self, x):
            self.x = x

    assert SetterTest(1).x == 1



# Generated at 2022-06-24 03:13:20.842835
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def bar(cls):
            return 'bar'

    assert A.bar == 'bar'
    assert B.bar == 'bar'



# Generated at 2022-06-24 03:13:30.472836
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Example(object):
        @lazyperclassproperty
        def prop1(cls):
            return 123

        @lazyperclassproperty
        def prop2(cls):
            return 'prop2'

    class ExampleChild(Example):
        @lazyperclassproperty
        def prop1(cls):
            return 'child prop1'

    a = Example()
    b = Example()
    c = ExampleChild()
    d = ExampleChild()

    assert a.prop1 == 123
    assert a.prop1 is b.prop1
    assert c.prop1 == 'child prop1'
    assert c.prop1 is d.prop1

    assert a.prop2 == 'prop2'
    assert a.prop2 is b.prop2
    assert c.prop2 == 'prop2'
    assert c.prop2

# Generated at 2022-06-24 03:13:35.342435
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def __init__(self):
            self._prop = 0

        @roclassproperty
        def prop(cls):
            return cls._prop

        @prop.setter
        def prop(cls, prop):
            cls._prop = prop

    test_class = TestClass()
    assert(test_class.prop == 0)
    test_class.prop = 1
    assert(test_class.prop == 1)


# Generated at 2022-06-24 03:13:38.176000
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):

        @roclassproperty
        def BAR(cls):
            return "BAR"

    assert Foo.BAR == "BAR"



# Generated at 2022-06-24 03:13:46.182524
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def setter(self, value):
            self.x = value

    assert MyClass.setter.__doc__ is None, "Improperly set __doc__ attribute of setterproperty"
    assert setterproperty(setterproperty, MyClass.setter.__doc__).__doc__ is None, "Improperly set __doc__ attribute of setterproperty"
    mc = MyClass()
    mc.setter = 5
    assert mc.x == 5, "Failed to properly set value in setterproperty"

# Generated at 2022-06-24 03:13:50.696272
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from g1.devtools.assertions import assert_not_reached

    class Example(object):
        def __init__(self, value):
            self._value = value

        def _set_value(self, _):
            assert_not_reached()

        def _get_value(self):
            return self._value

        property_ = setterproperty(_set_value)
        value = property(_get_value, property_)

    example = Example(123)
    assert example.value == 123
    with should_warn_deprecated_property():
        example.property_ = 321
    assert example.value == 123