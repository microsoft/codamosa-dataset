

# Generated at 2022-06-24 03:03:55.740866
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:
        val = 0
        @lazyclassproperty
        def bar(cls):
            cls.val += 1
            return cls.val

    print("before 1", Foo.val)
    print("before 1", Foo.bar)
    print("after 1", Foo.val)
    print("after 1", Foo.bar)

    class Bar(Foo):
        pass

    print("before 2", Foo.val)
    print("before 2", Bar.val)
    print("before 2", Foo.bar)
    print("before 2", Bar.bar)
    print("after 2", Foo.val)
    print("after 2", Bar.val)
    print("after 2", Foo.bar)
    print("after 2", Bar.bar)
    assert Foo.bar == 1
    assert Bar.bar == 2



# Generated at 2022-06-24 03:03:57.763794
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def f(cls):
            return "class A"

    class B(A):
        pass

    class C(A):
        pass

    assert A.f == "class A"
    assert B.f == "class A"
    assert C.f == "class A"



# Generated at 2022-06-24 03:04:02.125077
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def test(cls):
            return 1
    assert C.test == 1



# Generated at 2022-06-24 03:04:07.550780
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls.__name__

    foo = Foo()

    assert(foo.bar == 'Foo')
    assert(Foo.bar == 'Foo')


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:04:10.361197
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def f(cls): return 42
    assert A.f is 42



# Generated at 2022-06-24 03:04:14.931765
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, x):
            self.__x = x

        @roclassproperty
        def x(cls):
            return cls.__x

    class B(A):
        pass

    class C(A):
        @roclassproperty
        def x(cls):
            return cls.__x + 1

    assert A(1).x == A.x == 1
    assert B(2).x == B.x == 1
    assert C(3).x == C.x == 4



# Generated at 2022-06-24 03:04:17.067338
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        x = roclassproperty(lambda cls: 10)

    assert A.x == A().x == 10



# Generated at 2022-06-24 03:04:21.925932
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self, val):
            self._val = val

        @setterproperty
        def val(self, value):
            self._val = value

    obj = MyClass(0)
    assert obj._val == 0

    # it should be safely set, too
    obj.val = 'test string'
    assert obj._val == 'test string'



# Generated at 2022-06-24 03:04:25.912422
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def foo(self, val):
            self.x = val

    a = A(42)
    a.foo = 'bar'
    assert a.x == 'bar'

# Generated at 2022-06-24 03:04:29.652689
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def roproperty(cls):
            return 'bravo'

    assert TestClass.roproperty == 'bravo'
    with pytest.raises(AttributeError):
        TestClass.roproperty = 'charlie'

# Generated at 2022-06-24 03:04:33.219915
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):
        @roclassproperty
        def roproperty(cls):
            return cls.__name__

    assert foo.roproperty == "foo"
    with raises(AttributeError):
        f = foo()
        f.roproperty = "bar"



# Generated at 2022-06-24 03:04:40.474510
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            return cls

    t1 = Test()
    t2 = Test()

    Test.test == Test
    Test.test == t1.test
    Test.test == t2.test
    t1.test == Test
    t1.test == Test.test
    t1.test == t2.test
    t2.test == Test
    t2.test == Test.test
    t2.test == t1.test


# Generated at 2022-06-24 03:04:45.400400
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Simple(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            print('Setting value of object %s to %s' % (self, value))
            self._value = value

        def __str__(self):
            return str(self._value)

    print('An example of complex class property')
    s = Simple(42)
    print('Object s = %s' % s)
    s.value = 43
    print('Object s = %s' % s)


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:04:50.729077
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        @setterproperty
        def x(self, value):
            """Test docstring"""
            self.value = value

        # Test alternative setter (no argument)
        @x.setter
        def x(self, value):
            self.value = value

        # Test alternative setter (equality)
        @x.setter
        def x(self):
            return self.value == 3

    assert TestClass.x.__doc__ == "Test docstring"
    t = TestClass()
    t.x = 3
    assert t.value == 3
    assert t.x

# Generated at 2022-06-24 03:04:58.099279
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.value = 0

        @setterproperty
        def value(self, new_value):
            if new_value >= 0:
                self.__value = new_value
            else:
                print("Negative value not allowed")

        @value.getter
        def value(self):
            return self.__value

    a = A()
    assert a.value == 0
    a.value = -1
    assert a.value == 0
    a.value = 1
    assert a.value == 1



# Generated at 2022-06-24 03:05:00.704707
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    subject = setterproperty(lambda self, value: value)
    subject.__set__(None, 'Hello, World!')



# Generated at 2022-06-24 03:05:02.664612
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def A(cls):
            return 1
    assert A.A == 1



# Generated at 2022-06-24 03:05:07.729768
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def ro(cls):
            return "roclassproperty {0}".format(cls.__name__)

        @classproperty
        def ro2(cls):
            return "classproperty {0}".format(cls.__name__)

    a = A(123)
    assert a.value == 123
    assert a.ro == "roclassproperty A"
    assert a.ro2 == "classproperty A"



# Generated at 2022-06-24 03:05:17.211665
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Test method __get__ of class roclassproperty
    """

    class A(object):
        def __init__(self, x):
            self.x = x

        def __str__(self):
            return '{0}({1})'.format(self.__class__.__name__, self.x)

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(E, D):
        foo = roclassproperty(str)

    class G(F):
        pass

    class H(G):
        pass

    class I(H):
        pass

    class J(I):
        pass

    class K(J):
        pass


# Generated at 2022-06-24 03:05:24.162441
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            print('setter of x called')
            self._x = value

    a = A()
    a.x = 1


# Generated at 2022-06-24 03:05:34.639885
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def return_value(self, value):
            return value

        def return_value_and_class(self, value):
            return (value, type(self))

        p = setterproperty(return_value, "Test property")
        q = setterproperty(return_value_and_class, "Test property with class reference")

    a = A()
    assert (a.p == None)
    a.p = 10
    assert (a.p == 10)
    assert (a.q == None)
    a.q = 10
    assert (a.q[0] == 10)
    assert (a.q[1] == A)

test_setterproperty()

# Generated at 2022-06-24 03:05:43.585920
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from hyperspy.signals.spectrum import Spectrum
    s = Spectrum([1, 2, 3])

    @setterproperty
    def set_metadata_value(self, value):
        self.metadata.set_item(value)

    s.set_metadata_value = 4

    assert s.metadata.as_dictionary() == {'General': {},
                                          'Signal': {'record_by': 'spectrum',
                                                     'quantity': '',
                                                     'signal_type': ''},
                                          'set_metadata_value': 4}


if __name__ == '__main__':
    run_module_suite()

# Generated at 2022-06-24 03:05:48.688792
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @classproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'
    f = Foo()
    assert f.bar == 'baz'



# Generated at 2022-06-24 03:05:55.876083
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest
    class A(object):
        @lazyclassproperty
        def f(cls):
            return 42
    class B(A):
        pass
    class C(B):
        pass
    class D(C):
        pass
    class Test(unittest.TestCase):
        def test(self):
            self.assertEqual(A.f, 42)
            self.assertEqual(B.f, 42)
            self.assertEqual(C.f, 42)
            self.assertEqual(D.f, 42)
    unittest.main()


# Generated at 2022-06-24 03:06:05.193907
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if not isinstance(value, int):
                raise TypeError("x has to be an integer")
            if value < 0:
                raise ValueError("x cannot be negative")
            self._x = value
            return value

        def __str__(self):
            return 'C(x=%x)' % self.x

    c = C()
    assert c.x == 0
    assert c.__str__() == 'C(x=0)'

    c.x = 3
    assert c.x == 3
    assert c.__str__() == 'C(x=3)'

    c.x = -1
    assert c.x == 0
    assert c.__

# Generated at 2022-06-24 03:06:09.431704
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo:
        bar = "baz"

    class PropertyContainer:
        @setterproperty
        def bar(self, value):
            Foo.bar = value

    pc = PropertyContainer()
    assert pc.bar == "baz"
    pc.bar = "qux"
    assert Foo.bar == "qux"



# Generated at 2022-06-24 03:06:14.380716
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a = 'A'
            self.b = 'B'

        @setterproperty
        def set_a(self, value):
            self.a = value
        @setterproperty
        def set_b(self, value):
            self.b = value

    a = A()
    a.set_a = 'a'
    a.set_b = 'b'
    assert a.a == 'a'
    assert a.b == 'b'



# Generated at 2022-06-24 03:06:22.968074
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass
    class B(A):
        pass
    class C(A):
        pass

    class Test:
        @lazyperclassproperty
        def test(self):
            d = {self.__class__: self.__class__.__name__}
            print('test property evaluated for', d)
            return d

    t_a = Test()
    t_b = Test()
    t_c = Test()

    assert t_a.test is t_b.test is t_c.test

    t_a.test is Test.test

    Test.test is not t_b.test
    Test.test is not t_c.test

    Test.test is B.test
    Test.test is C.test



# Generated at 2022-06-24 03:06:29.432951
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    test_field_name = 'test'
    test_field_value = 'content'

    class TestClass(object):
        __setterproperty_test_field = setterproperty(lambda obj, value: setattr(obj, test_field_name, value))

    obj = TestClass()
    obj.__setterproperty_test_field = test_field_value
    assert getattr(obj, test_field_name) == test_field_value



# Generated at 2022-06-24 03:06:32.396429
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @roclassproperty
        def roclsprop(cls):
            return 2
    assert 2 == MyClass.roclsprop
    assert 2 == MyClass().roclsprop



# Generated at 2022-06-24 03:06:36.378128
# Unit test for constructor of class setterproperty
def test_setterproperty():
    value = 1

    class A():
        @setterproperty
        def value(self, v):
            global value
            value = v
            return value

    a = A()
    assert a.value == 1
    a.value = 3
    assert value == 3


# Generated at 2022-06-24 03:06:42.237443
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, x):
            self.b = x * 10

    a = A(10)
    assert a.x == None
    assert a.b == None

    a.x = 5
    assert a.x == None
    assert a.b == 50

    a.x = 10
    assert a.x == None
    assert a.b == 100



# Generated at 2022-06-24 03:06:46.371703
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyClassproperty(object):
        @lazyclassproperty
        def name(cls):
            return "TestLazyClassproperty"

    t = TestLazyClassproperty()

    assert t.name == "TestLazyClassproperty"
    assert TestLazyClassproperty.name == "TestLazyClassproperty"


# Generated at 2022-06-24 03:06:50.213055
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class c1:
        @lazyperclassproperty
        def test(cls):
            return cls

    class c2(c1):
        pass

    assert c1.test == c1
    assert c2.test == c2
    assert c1().test == c1



# Generated at 2022-06-24 03:06:54.115791
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 1
        @roclassproperty
        def y(cls):
            return "hello"

    assert A.x == 1
    with pytest.raises(AttributeError):
        A.x = 2
    assert A.y == "hello"
    with pytest.raises(AttributeError):
        A.y = "world"


# Generated at 2022-06-24 03:06:58.214308
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self.tprop = 4
        @roclassproperty
        def cprop(cls):
            return cls.tprop
    t = Test()
    assert t.cprop == 4


# Generated at 2022-06-24 03:07:02.238696
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, val):
            self.x = val
            return val

    o = Test()
    o.x = 10
    assert o.x == 10
    o.x = 20
    assert o.x == 20


# Generated at 2022-06-24 03:07:06.824295
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    def fn(cls, *args, **kwargs):
        return Foo(cls, *args, **kwargs)

    class Bar(object):
        @lazyperclassproperty
        def foo(cls):
            return fn(cls)

    class Baz(Bar):
        pass

    assert Bar().foo == Baz().foo == Foo(Bar)
    assert not Bar.foo == Baz.foo == Foo(Bar)
    """


# Generated at 2022-06-24 03:07:10.665891
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:07:12.456152
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def test_method(cls):
            return
        test_method(TestClass)


# Generated at 2022-06-24 03:07:16.677269
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class roclassproperty_test(object):
        def __init__(self):
            self.count = 0
            self.val = 0

        @roclassproperty
        def count(self):
            return self.count

        @roclassproperty
        def val(self):
            return self.val

    roclassproperty_test()

    print('Module classproperty run successfully!')


# Generated at 2022-06-24 03:07:25.536255
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # Create a class
    class C(object):
        # Declare a read-only property
        @roclassproperty
        def readonly(cls):
            return "This is a readonly property"
    # Verify the existence of readonly
    assert hasattr(C, "readonly")
    # Verify it is readonly
    try:
        C.readonly = "This should raise an exception"
    except TypeError as e:
        # Verify the exception message
        assert str(e) == "can't set attributes of built-in/extension type 'object'"
    c = C()
    # Verify we can read the property
    assert c.__class__.readonly == "This is a readonly property"

# Generated at 2022-06-24 03:07:29.548082
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Test(object):

        @lazyperclassproperty
        def test(cls):
            print("Running test of class {}".format(cls))
            return cls.__name__

    class SubTest(Test):
        pass

    assert Test.test == "Test"
    assert SubTest.test == "SubTest"



# Generated at 2022-06-24 03:07:33.551576
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class testclass(object):
        @lazyclassproperty
        def myprop(self):
            print('evaluate')
            return 42

    assert testclass.myprop == 42
    assert testclass.myprop == 42

    class subtestclass(testclass):
        pass

    assert subtestclass.myprop == 42
    assert subtestclass.myprop == 42
    assert testclass.myprop == 42



# Generated at 2022-06-24 03:07:36.515779
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(self):
            return 'bar'
    assert A.foo == 'bar'
    assert A().foo == 'bar'

# Generated at 2022-06-24 03:07:40.505403
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        a = 1

    class B(C):
        b = lazyclassproperty(lambda cls: cls.a)

    class D(B):
        a = 2

    class E(C):
        a = 3

    assert B.b == 1
    assert D.b == 2
    assert E.b == 3
    
    

# Generated at 2022-06-24 03:07:50.310966
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class A(object):
        @setterproperty
        def foo(self, value):
            self._foo = value
            return 42

    class B(A):
        pass

    class C(object):
        @setterproperty
        def foo(self, value):
            self._foo = value
            return 24

    class TestSetterProperty(unittest.TestCase):
        def test_class_attribute(self):
            x = A()
            self.assertEqual(42, x.foo)
            self.assertEqual(42, x.foo)

        def test_inherited_class_attribute(self):
            x = B()
            self.assertEqual(42, x.foo)
            self.assertEqual(42, x.foo)


# Generated at 2022-06-24 03:07:56.921010
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def x(cls):
            return cls.__class__.__name__

    class B(A):
        pass


# Generated at 2022-06-24 03:08:01.330800
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def x(cls):
            return 0

    # test reading class property
    assert C.x == 0

    # test reading class property from instance
    assert C().x == 0


# Generated at 2022-06-24 03:08:03.674995
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class foo(object):
        @roclassproperty
        def p(cls):
            return "p"
    assert foo.p == "p"


# Generated at 2022-06-24 03:08:05.974735
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def foo(self, x):
            self._foo = x
        foo = foo()

    c = C()
    c.foo = 1
    print(c._foo)

# Generated at 2022-06-24 03:08:11.061039
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):

        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, value):
            if value >= 0:
                self._x = value
            else:
                self._x = 0

        @x.getter
        def x(self):
            return self._x
    a = A()
    print('test_setterproperty___set__ a.x: ', a.x)
    a.x = -1
    print('test_setterproperty___set__ a.x: ', a.x)
    a.x = 3
    print('test_setterproperty___set__ a.x: ', a.x)

if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:08:19.821168
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from time import time

    class T:
        @lazyclassproperty
        def p(cls):
            print("Calculate...")
            return time()

    t = time()
    print("t:", t)

    print("T.p:", T.p)
    assert t == T.p

    print("T.p:", T.p)
    assert t == T.p

    t1 = T()
    print("t1.p:", t1.p)
    assert t == t1.p

    t2 = T()
    print("t2.p:", t2.p)
    assert t == t2.p


# Generated at 2022-06-24 03:08:27.243025
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """__get__(object, class)

    A descriptor is used with an instance of class C, then returns
    instance.__dict__['f'].

    This test uses class methods instead of instances, so it will always
    return the function object.

    """

    class C(object):
        @roclassproperty
        def meth(cls):
            return cls

    assert C.__dict__['meth'].__get__(None, C) is C.__dict__['meth']


# Generated at 2022-06-24 03:08:32.023041
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.a = "0"
        @setterproperty
        def a(self, value):
            self.a = value
    t = Test()
    assert t.a == "0"
    t.a = "2"
    assert t.a == "2"



# Generated at 2022-06-24 03:08:35.767083
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    '''
    class Test:
        def __init__(self):
            self.__x = None
    
        @setterproperty
        def x(self, value):
            self.__x = value
    '''
    class Test(object):
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, value):
            self.__x = value

    t = Test()
    t.x = 'bla'
    assert hasattr(t, '__x')
    assert t.__x == 'bla'



# Generated at 2022-06-24 03:08:40.651421
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    foo = 1

    class Example(object):
        @roclassproperty
        def foo(cls):
            return foo
    # end class Example

    print(Example.foo)
    print(Example().foo)



# Generated at 2022-06-24 03:08:48.768762
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, x):
            if not isinstance(x, int):
                raise TypeError('x must be an int')
            self._x = x

        @x.getter
        def x(self):
            return self._x

        @x.deleter
        def x(self):
            del self._x
        pass

    foo = Foo()
    foo.x = 12
    assert foo.x == 12
    del foo.x
    assert not hasattr(foo, '_x')

# Generated at 2022-06-24 03:08:52.794002
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    def value_getter_func(theclass):
        return theclass.value + 1
    class testclass(object):
        value = 1
        prop = roclassproperty(value_getter_func, 'read only property')
    assert testclass.prop == 2
    

# Generated at 2022-06-24 03:08:58.086708
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.foo = ''
            self.bar = ''

        @setterproperty
        def foo(self, value):
            """Setter property"""
            self.foo = value

    # All tests of setterproperty __set__.
    a = A()
    a.foo = 'Hello'
    assert a.foo == 'Hello'
    assert a.foo == 'Hello'
    assert a.__doc__ == "Setter property"



# Generated at 2022-06-24 03:08:59.928599
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__

    print(A.name)



# Generated at 2022-06-24 03:09:08.086374
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import random

    class Four(object):
        _four = 4

        @setterproperty
        def four(self, x):
            Four._four = x

        @classproperty
        def four(cls):
            return Four._four

    for _ in range(1000):
        Four.four = random.randint(0, 1000)
        assert Four.four == 4

    for _ in range(1000):
        Four.four = random.randint(-1000, -1)
        assert Four.four == 4


# Generated at 2022-06-24 03:09:17.919886
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class P(object):
        def get_x(cls):
            return cls.x

        x = roclassproperty(get_x)

        def set_x(cls, value):
            raise Exception("Read only")

        x = setterproperty(set_x, "x")

    class C(P):
        x = 1
        y = 2

    assert C.x == 1, C.x
    assert C.y == 2, C.y

    # Test that roclassproperty can be overwritten by a setterproperty.
    C.x = 7
    assert C.x == 7, C.x

if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:09:27.957670
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class testa(object):
        def __init__(self, x):
            self.x = x

        @lazyperclassproperty
        def y(cls):
            return cls(3)

    class testb(testa):
        def __init__(self, x):
            super().__init__(x)


    t1 = testa(1)
    t2 = testa(2)
    t3 = testa.y
    t4 = testb(4)
    t5 = testb(5)
    t6 = testb.y
    assert(t1.x == 1 and t2.x == 2 and t3.x == 3 and t4.x == 4 and t5.x == 5 and t6.x == 3)



# Generated at 2022-06-24 03:09:33.254385
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def __init__(self):
            self.val = 1

        @classproperty
        def val(self):
            return self._val

        @val.setter
        def val(self, val):
            self._val = val

    a = A()
    print(a.val)
    a.val = 3
    print(a.val)



# Generated at 2022-06-24 03:09:38.104775
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def b(self, value):
            self._b = value

        @b.getter
        def b(self):
            return self._b
            #end of class A
    test_a = A()
    test_a.b = 5
    if test_a.b == 5:
        print(True)
    else:
        print(False)
        #end of test_setterproperty()
#test_setterproperty()

# Generated at 2022-06-24 03:09:39.867784
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 'x'

    assert C.x == 'x'


# Generated at 2022-06-24 03:09:45.281438
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, value):
            self.__a = value + 1

    a = A()
    assert a.a == 1
    a.a = 10
    assert a.a != 10
    assert a.a == 11


# Test for method __get__ of class lazyclassproperty

# Generated at 2022-06-24 03:09:50.263592
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):

        class _valueproperty(object):
            def __get__(self, obj, objtype):
                return obj._value

            def __set__(self, obj, value):
                obj._value = value

        _value = 0

        @setterproperty
        def value(self, value):
            self.value = value

    a = Test()
    a.value = 5
    a.value = 10
    assert_equals(a._value, 10)



# Generated at 2022-06-24 03:09:56.013725
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def c(self, value):
            self.a = value

    t = Test()
    t.c = 1
    assert t.a == 1



# Generated at 2022-06-24 03:09:59.413623
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class test_class(object):

        @roclassproperty
        def test_property(self):
            return self.__class__

    test_instance = test_class()

    print(test_instance.test_property)

if __name__ == "__main__":

    test_roclassproperty()

# Generated at 2022-06-24 03:10:04.917562
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):

        @lazyclassproperty
        def x(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert(A.x == 'A')
    assert(B.x == 'B')
    assert(C.x == 'C')

test_lazyclassproperty()

# Generated at 2022-06-24 03:10:08.673268
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    def __testfn(cls):
        return "test value"

    class TestClass(object):
        # Test lazyclassproperty(__testfn)
        testvar = lazyclassproperty(__testfn)

    assert TestClass.testvar == TestClass.testvar == __testfn(TestClass)
    assert TestClass.testvar == "test value"



# Generated at 2022-06-24 03:10:14.437717
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, x):
            assert isinstance(x, int)
            self.__x = x

        @property
        def x(self):
            return self.__x

    a = A()
    a.x = 1
    assert a.x == 1

test_setterproperty()

# Generated at 2022-06-24 03:10:17.386491
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert C.x == 1



# Generated at 2022-06-24 03:10:24.023792
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        __doc__ = "I am A"
        @setterproperty
        def hello(self,value):
            return value
    a = A()
    a.hello = 'hello,world'
    result = a.hello
    expected = 'hello,world'
    assert (expected == result)


# Generated at 2022-06-24 03:10:24.689072
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    pass


# Generated at 2022-06-24 03:10:32.844192
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    def fn(cls):
        return cls.__name__

    property_1 = roclassproperty(fn)

    @roclassproperty
    def property_2(cls):
        return cls.__name__

    class Test(object):
        property1 = property_1
        property2 = property_2

    test_instance = Test()
    # Test if property is read-only
    try:
        test_instance.property1 = 'test'
    except AttributeError:
        print('Test for constructor of class roclassproperty passed.')


# Generated at 2022-06-24 03:10:39.170571
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def roclassprop1(cls):
            return 1

        @lazyclassproperty
        def lazy_prop(cls):
            return 1

    assert A.roclassprop1 == 1
    assert A.lazy_prop == 1

    try:
        A.roclassprop1 = 2
        assert False, "Failing to detect write access to a read-only property"
    except AttributeError:
        pass

    try:
        A.lazy_prop = 2
        assert False, "Failing to detect write access to a read-only property"
    except AttributeError:
        pass



# Generated at 2022-06-24 03:10:41.345299
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def foo(self, value):
            self.bar = value

    foo = Foo()
    foo.foo = "bar"
    assert foo.bar == "bar"



# Generated at 2022-06-24 03:10:43.839122
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def roproperty(cls):
            return 'roclassproperty'
    assert A.roproperty == 'roclassproperty'


# Generated at 2022-06-24 03:10:57.943989
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def setter(self, value):
            self.value = value

        @setterproperty
        def prop(self):
            pass

    assert not hasattr(A, 'value')

    A().prop = 2

    assert A.value == 2

    class B(A):
        def setter(self, value):
            self.value = value * 2

    assert not hasattr(B, 'value')

    B().prop = 2

    assert B.value == 4


# Generated at 2022-06-24 03:11:07.779427
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass

    class B(A):
        def __init__(self):
            self.x = 2

        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class C(A):
        def __init__(self):
            self.y = 3

        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    assert A._A_lazy_prop == 'A'
    assert B._B_lazy_prop == 'B'
    assert C._C_lazy_prop == 'C'
    assert B().prop == 'B'
    assert C().prop == 'C'


# Generated at 2022-06-24 03:11:11.373612
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def b(cls):
            return "Baz"

    class B(A):
        pass

    assert A.b == "Baz"
    assert B.b == "Baz"
    A.b = "Bar"
    assert A.b == "Bar"
    assert B.b == "Baz"



# Generated at 2022-06-24 03:11:16.423907
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        @setterproperty
        def value(self, value):
            return value
    t = Test()
    assert t.value is None
    t.value = 1
    assert t.value == 1


# Generated at 2022-06-24 03:11:21.569262
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def setter(obj, value):
        obj.values.append(value)

    class Foo:
        x = setterproperty(setter)

    obj = Foo()
    obj.values = []
    obj.x = 42
    assert obj.values == [42]



# Generated at 2022-06-24 03:11:26.097632
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @roclassproperty
        def value(cls):
            return 'value'
    assert Test.value == 'value'
    assert Test().value == 'value'
    try:
        Test.value = 'new-value'
        assert False
    except AttributeError as e:
        assert type(e) == AttributeError
        assert str(e) == "'type' object is not writable"
    try:
        Test().value = 'new-value'
        assert False
    except AttributeError as e:
        assert isinstance(e, AttributeError)
        assert str(e) == "'Test' object is not writable"

# Generated at 2022-06-24 03:11:35.844084
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    @roclassproperty
    def test(cls):
        return cls.__name__
    class A:
        pass
    class B(A):
        pass
    assert test.__get__(None, A) == 'A'
    assert test.__get__(None, B) == 'B'
    assert test.__get__(None, A) == 'A'
    assert test.__get__(None, B) == 'B'
    assert test.__doc__ is None
    class C:
        def __init__(self):
            self.x = 5
    assert C.x == 5
    assert C().x == 5

# Generated at 2022-06-24 03:11:39.087078
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert C.x == 1



# Generated at 2022-06-24 03:11:41.631745
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self):
            self.inited = True

        @roclassproperty
        def exists(self):
            return self.inited

    assert TestClass().exists



# Generated at 2022-06-24 03:11:50.662731
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        def __init__(self):
            self.counter = 0

        @lazyclassproperty
        def my_prop(cls):
            cls.my_prop.counter += 1
            return cls.__name__

    assert MyClass.my_prop == 'MyClass'
    assert MyClass.my_prop.counter == 1
    assert MyClass.my_prop.counter == 1
    assert MyClass.my_prop == 'MyClass'

    class MySubClass(MyClass):
        pass

    assert MySubClass.my_prop == 'MySubClass'
    assert MySubClass.my_prop.counter == 1
    assert MySubClass.my_prop.counter == 1
    assert MySubClass.my_prop == 'MySubClass'
    assert MyClass.my_prop.counter

# Generated at 2022-06-24 03:11:59.211345
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import pytest
    class Test(object):
        def __init__(self):
            self.a = 0

        def _set_a(self, value):
            self.a = value + 1
        a = setterproperty(_set_a)

    def test_setterproperty_bad_value():
        with pytest.raises(TypeError):
            Test.a = 1

    def test_setterproperty():
        t = Test()
        t.a = 2
        assert t.a == 3

# Runs tests if run directly
if __name__ == '__main__':
    import pytest
    pytest.main('test_setterproperty.py')

# Generated at 2022-06-24 03:12:03.642751
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        foo = roclassproperty(lambda x: 3)

    assert A.foo == 3



# Generated at 2022-06-24 03:12:10.923817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):

        @lazyperclassproperty
        def hello(cls):
            print('lazyperclassproperty')
            return 'hello, %s!' % cls.__name__

    class A(Base):
        pass

    class B(Base):
        pass

    class C(Base):
        pass

    print(Base.hello)
    print(A.hello)
    print(B.hello)
    print(C.hello)



# Generated at 2022-06-24 03:12:14.196345
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:20.491955
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty
    """
    class A(object):
        @lazyperclassproperty
        def f(cls):
            print("\nCalled A.f")
            return cls.__name__

        @lazyperclassproperty
        def b(cls):
            print("\nCalled A.b")
            return cls.__name__

    class B(A):
        @lazyperclassproperty
        def f(cls):
            print("\nCalled B.f")
            return cls.__name__

    c = A
    d = B
    print("first call of A.f")
    a = A.f
    print("first call of B.f")
    b = B.f
    print("second call of A.f")
   

# Generated at 2022-06-24 03:12:24.705680
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, x):
            if not (0 <= x <= 100):
                raise ValueError('x must be between 0 and 100')
            self._x = x

    a = A(0)
    a.x = 50
    assert a.x == 50



# Generated at 2022-06-24 03:12:27.532069
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Class:
        @roclassproperty
        def property_ro(cls):
            return 7
    assert Class.property_ro == 7
    assert Class().property_ro == 7
    

# Generated at 2022-06-24 03:12:32.958922
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class MyClass(object):
        @lazyclassproperty
        def function_return_zero(self):
            return 0

    assert MyClass.function_return_zero == 0

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-24 03:12:37.303414
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def set_x(self, x):
            self.__x = x

        x = setterproperty(set_x)

    t = Test()
    t.x = 12
    assert t.__x == 12

# Generated at 2022-06-24 03:12:42.830549
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def _set_x(self, x):
            self.__x = x

        x = setterproperty(_set_x)

    a = A()
    a.x = 1
    assert a.__x == 1

# Generated at 2022-06-24 03:12:48.521726
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

        @setterproperty
        def age(self, age):
            if not isinstance(age, int):
                raise TypeError('Age must be integer')
            if age <= 0:
                raise ValueError('Age must be positive')
            if self._age is None:
                self._age = age
            else:
                print('Age cannot be changed')

    person = Person('Zakir', 12)
    print(person.age)
    person.age = 13
    print(person.age)
    person.age = 10
    print(person.age)



# Generated at 2022-06-24 03:12:50.697280
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def value(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.value == 'A'
    assert B.value == 'B'



# Generated at 2022-06-24 03:12:56.003301
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return cls.bar

        bar = "bar"

    assert A.foo == "bar"
    with pytest.raises(AttributeError):
        A.foo = "baz"

    a = A()

    assert a.foo == "bar"
    with pytest.raises(AttributeError):
        a.foo = "baz"


# Generated at 2022-06-24 03:13:03.701757
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass:
        pass
    p = roclassproperty(lambda x: x)
    assert p.__get__(MyClass, MyClass) == MyClass
    try:
        p.__set__(MyClass, MyClass)
    except AttributeError:
        pass
    else:
        assert False, 'roclassproperty should not have a setter'


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:13:13.631046
# Unit test for constructor of class setterproperty
def test_setterproperty():
    test_class = type('test_class', (), {})

    classproperty_name = '_test_setterproperty'
    classproperty_val = 'test_val'
    setterproperty_name = '_test_setterproperty_with_setter'
    setterproperty_val = 'test_val_new'

    setattr(test_class, classproperty_name, classproperty(lambda x: classproperty_val))
    assert getattr(test_class, classproperty_name) == classproperty_val

    setattr(test_class, setterproperty_name, setterproperty(lambda obj, val: setattr(obj, setterproperty_name, val)))
    getattr(test_class, setterproperty_name.lstrip('_'))(setterproperty_val)

# Generated at 2022-06-24 03:13:20.545819
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    #-------------------------------------------------------#
    #------------- Classes used for the test ---------------#
    #-------------------------------------------------------#
    class Base(object):
        def __init__(self):
            self.base_value = 0

        @lazyperclassproperty
        def lazy_value(cls):
            return cls.base_value + 1

    class Child(Base):
        def __init__(self):
            super(Child, self).__init__()
            self.base_value = 1

    class Grandchild(Child):
        def __init__(self):
            super(Grandchild, self).__init__()
            self.base_value = 2

    #-------------------------------------------------------#
    #------------- Test the function ------------------------#
    #-------------------------------------------------------#
    print()
    print('-- Test lazyperclassproperty --')


# Generated at 2022-06-24 03:13:23.945959
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return 1
    c = C()
    assert c.foo == 1
    assert C.foo == 1


# Generated at 2022-06-24 03:13:32.949265
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        a = 4
        def __init__(self, x, y=5):
            self.x = x
            self.y = y

        @roclassproperty
        def s(cls):
            return cls.a + cls.b

        @roclassproperty
        def w(cls):
            return [cls.a, cls.b]

        @roclassproperty
        def p(cls):
            return cls(2, 3)

    class D(C):
        b = 7

    assert C.s == D.s == 11
    assert C.w == D.w == [4, 7]
    assert D.p.__dict__ == {'x': 2, 'y': 3}
    assert D.p.x == 2



# Generated at 2022-06-24 03:13:38.253231
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def func(obj, value):
        obj.value = value

    o = setterproperty(func)
    o1 = object
    o1.value = None
    o.__set__(o1, 'Hello World')
    assert(o1.value == 'Hello World')


# Generated at 2022-06-24 03:13:43.892134
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo():
        def __init__(self, value):
            self._value = value
        @setterproperty
        def value(self, value):
            self._value = value
            return value
    f = foo(5)
    print(f.value)
    print(f.value)
    f.value = 3
    print(f.value)
    print(f._value)



# Generated at 2022-06-24 03:13:45.790737
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def m(cls):
            return 42
    assert C.m == 42


# Generated at 2022-06-24 03:13:47.521048
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        f = roclassproperty(lambda: 10)
    obj = Test()
    assert obj.f == 10

