

# Generated at 2022-06-24 03:03:50.539337
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 'foo'

    assert C.x == 'foo'
    assert C().x == 'foo'



# Generated at 2022-06-24 03:03:53.644622
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def d(cls):
            return {'foo':'bar'}

    class B(A):
        pass

    assert A.d is not B.d



# Generated at 2022-06-24 03:04:01.142272
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        def __init__(self, val1, val2):
            self.val1 = val1
            self.val2 = val2

        @roclassproperty
        def val2(cls):
            return 2

        @roclassproperty
        def val1(self):
            return 1

        @roclassproperty
        def val3(self):
            return 3

    my_class = MyClass(0, 0)
    assert my_class.val1 == 1
    assert my_class.val2 == 2
    assert my_class.val3 == 3


# Generated at 2022-06-24 03:04:10.918817
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            self._x = None

        @lazyperclassproperty
        def x(cls):
            print("lazy")
            return cls._x

        def _setx(self, val):
            self._x = val

        x = property(fget=x, fset=_setx)

    class Derived(Base):
        pass

    b = Base()
    d = Derived()

    assert b._x == None
    assert d._x == None
    b._setx(1)
    assert b.x == 1
    assert d.x == None
    d._setx(2)
    assert b.x == 1
    assert d.x == 2



# Generated at 2022-06-24 03:04:15.289738
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, value, multiplier=1):
            self.value = value
            self.multiplier = multiplier

        @setterproperty
        def multiplier(self, multiplier):
            self._multiplier = multiplier

        def total(self):
            return self.value * self.multiplier

    assert Foo(2, 3).total() == 6
    assert Foo(2).total() == 2
    foo = Foo(2)
    foo.multiplier = 3
    assert foo.total() == 6

if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:04:17.987355
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            return self._value

        @value.setter
        def value(self, value):
            self._value = value

    foo = Foo(1)
    assert foo._value == 1
    assert foo.value == 1

    foo.value = 2
    assert foo._value == 2
    assert foo.value == 2



# Generated at 2022-06-24 03:04:21.879633
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def size(self, value):
            self._size = value

    a = A()
    assert(not hasattr(a, '_size'))
    a.size = 10
    assert(a._size == 10)


# Generated at 2022-06-24 03:04:24.129049
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    
    class A(object):
        def __init__(self, x):
            self.x = x
            
    class B(A):
        @lazyperclassproperty
        def y(cls):
            return cls(14)

    assert B.y.x == 14
    assert A.y.x == 14
    assert B.y.x == 14



# Generated at 2022-06-24 03:04:32.728475
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        my_var = 10
        @setterproperty
        def my_var(self, value):
            if value < 1:
                raise ValueError("value should be greater than 1")
            else:
                self._value = value
        @setterproperty
        def my_var2(self, value):
            if value < 1:
                raise ValueError("value should be greater than 1")
            else:
                self._value = value
    my_class = MyClass()
    try:
        my_class.my_var = 0
    except ValueError as e:
        assert e.args[0] == "value should be greater than 1"
    except:
        assert False
    try:
        my_class.my_var2 = 0
    except ValueError as e:
        assert e.args

# Generated at 2022-06-24 03:04:37.583560
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        def _get_foo(cls):
            return 'foo'
        foo = lazyclassproperty(_get_foo)

    assert C.foo == 'foo'
    assert C().foo == 'foo'



# Generated at 2022-06-24 03:04:41.567230
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self, description):
            self.description = description

        @roclassproperty
        def description(cls):
            print("executing roclassproperty: Test.description")
            return "An instance of class '%s'" % cls.__name__

    t = Test("Test")
    assert t.description == "An instance of class 'Test'"


# Generated at 2022-06-24 03:04:46.736631
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Dummy(object):
        def __init__(self, a):
            self.dummy_attr = a

        @setterproperty
        def dummy_attr(self, val):
            self._dummy_attr = val

        @dummy_attr.setter
        def dummy_attr(self, val):
            self._dummy_attr = val

        @setterproperty
        def dummy_attr_with_doc(self, val):
            '''This is dummy doc string'''
            self._dummy_attr = val

    d1 = Dummy(0)
    d2 = Dummy(1)
    d1.dummy_attr = 10
    assert d1._dummy_attr == 10
    assert d2._dummy_attr == 1
    d1.dummy_attr_with_doc = 20


# Generated at 2022-06-24 03:04:53.568476
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def bar(self):
            return self.__bar
        @bar.setter
        def bar(self, value):
            self.__bar = value

    foo = Foo()
    foo.bar = 42
    assert foo.__dict__['_Foo__bar'] == 42



# Generated at 2022-06-24 03:05:00.708244
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from .introspection import codec_for_encoding_name, write_to_file

    class A(object):
        @setterproperty
        def a(self, v):
            self.v = v

    a = A()
    a.a = None

    assert a.v is None

    assert codec_for_encoding_name('ascii') is not None
    assert codec_for_encoding_name('ascii').name == 'ascii'
    assert codec_for_encoding_name('ascii').encode('foo') == 'foo'

    assert write_to_file(__file__, 'testing') is True
    assert write_t

# Generated at 2022-06-24 03:05:02.812365
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.i = 0
        @setterproperty
        def s(self, value):
            self.i = 1
    a = A()
    a.s = 1
    assert 1 == a.i


# Generated at 2022-06-24 03:05:06.396005
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('Calculating foo')
            return 42

    class B(A):
        pass

    print(A.foo)
    print(B.foo)
    print(A.foo)
    print(B.foo)

    assert A.foo == 42
    assert B.foo == 42
    assert A.foo is B.foo



# Generated at 2022-06-24 03:05:09.021132
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def _getx(cls): return 1
        x = roclassproperty(_getx)

    assert Test.x == 1



# Generated at 2022-06-24 03:05:14.106300
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def lazy(cls):
            return [cls, cls]
    class D(C):
        pass
    class E(D):
        pass

    assert C.lazy == [C, C]
    assert D.lazy == [D, D]
    assert E.lazy == [E, E]


# Generated at 2022-06-24 03:05:16.109572
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def attr(self, value):
            self.__attr = value

    a = A()
    a.attr = 3

    assert hasattr(a, '_A__attr')

    assert a._A__attr == 3



# Generated at 2022-06-24 03:05:23.599154
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def foo(cls):
            return "foo"
        bar = roclassproperty(foo)

        def bar_of_class(self):
            return C.bar
        bar_of_class = classmethod(bar_of_class)

        def bar_of_obj(self):
            return self.bar
        bar_of_obj = property(bar_of_obj)

    assert C.bar == "foo"
    assert C().bar_of_class() == "foo"
    assert C().bar_of_obj == "foo"
    try:
        C().bar = "auto"
        assert False, "expected AttributeError"
    except AttributeError:
        pass


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:05:25.573402
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    @lazyclassproperty
    def prop():
        return 42

    assert prop == 42

    class Cls:
        @lazyclassproperty
        def prop():
            return 42

    assert Cls.prop == 42



# Generated at 2022-06-24 03:05:30.392878
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class x:
        @setterproperty
        def some(self, val):
            self.some_val = val

    x = x()
    x.some = 'hello'
    assert x.some_val == 'hello'

# Generated at 2022-06-24 03:05:36.615835
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Define a base class
    class Base(object):
        @lazyperclassproperty
        def val(cls):
            return 'val'

    # Define a derived class
    class Derived(Base):
        pass

    assert Base.val == 'val'
    assert Derived.val == 'val'

    class Base(object):
        @lazyperclassproperty
        def val(cls):
            return 'val'

    # Derived class has its own copy of the perclassproperty
    class Derived(Base):
        @lazyperclassproperty
        def val(cls):
            return 'val_derived'

    assert Base.val == 'val'
    assert Derived.val == 'val_derived'



# Generated at 2022-06-24 03:05:41.271467
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("Baz")
            return "Baz"

    print("Foo.bar", Foo.bar)
    print("Foo.bar", Foo.bar)
    print("Foo.bar", Foo.bar)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-24 03:05:51.640598
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import unittest

    class PropertyTester(unittest.TestCase):
        class_attr_set = False
        class_attr_value = None

        @lazyclassproperty
        def test_attr(cls):
            cls.class_attr_set = True
            cls.class_attr_value = 1
            return 1

    class SubclassPropertyTest(PropertyTester):
        pass

    p = PropertyTester()
    self = SubclassPropertyTest()
    self.assertEqual(PropertyTester.test_attr, 1)
    self.assertTrue(PropertyTester.class_attr_set)
    self.assertTrue(SubclassPropertyTest.class_attr_set)
    self.assertEqual(SubclassPropertyTest.class_attr_value, 1)

# Generated at 2022-06-24 03:05:54.936651
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 1

    assert A.foo is A.foo

    class B(A):
        pass

    assert B.foo is A.foo



# Generated at 2022-06-24 03:06:01.583134
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):

        @lazyclassproperty
        def test(cls):
            return len(cls.__name__)

    class TestClass2(TestClass):
        pass

    class TestClass3(TestClass2):
        pass

    class TestClass4(TestClass3):
        pass

    assert TestClass.test == 9
    assert TestClass2.test == 9
    assert TestClass3.test == 9
    assert TestClass4.test == 9



# Generated at 2022-06-24 03:06:05.421583
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo:
        @roclassproperty
        def prop1(cls):
            return cls.__name__

        @roclassproperty
        def prop2(cls):
            return cls.__name__
    # Test for constructor
    assert(Foo.prop1 == 'Foo')
    assert(Foo.prop2 == 'Foo')


# Generated at 2022-06-24 03:06:13.763895
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, newvalue):
            self._value = newvalue

        @classproperty
        def value_class(cls):
            print(str(cls))
            return 'Hello from class method!'

    a = A('abc')
    a.value = 'abcdef'
    assert a._value == 'abcdef'

    assert a.value_class == 'Hello from class method!'

# Generated at 2022-06-24 03:06:15.959079
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    _lazy = lazyperclassproperty
    class A(object):
        @_lazy
        def a(self):
            return 1

    class B(A): pass
    class C(A): pass

    assert A().a==1
    assert B().a==1
    assert C().a==1



# Generated at 2022-06-24 03:06:18.734558
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('BAR!')
            return 'bar'

    class Qux(Foo):
        pass

    assert Foo.bar == 'bar'
    assert Qux.bar == 'bar'

# Generated at 2022-06-24 03:06:26.872644
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        def _get_x(cls):
            return 42

        x = roclassproperty(_get_x)

    assert Foo.x == 42
    # if you want to disable the set, you can use property as well
    # https://stackoverflow.com/questions/128573/using-property-on-classmethods
    # class Foo(object):
    #     def _get_x(cls):
    #         return 42
    #
    #     x = property(_get_x)
    #
    # assert Foo.x == 42


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:06:36.546446
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    @lazyperclassproperty
    def lazyperclassproperty_test(cls):
        return cls, cls.name

    class Parent(object):
        lazyperclassproperty_test = lazyperclassproperty_test
        name = 'parent'

    class Child(Parent):
        name = 'child'

    assert Child.lazyperclassproperty_test[0] is Child
    assert Child.lazyperclassproperty_test[1] == Child.name

    assert Parent.lazyperclassproperty_test[0] is Parent
    assert Parent.lazyperclassproperty_test[1] == Parent.name

    assert Parent.lazyperclassproperty_test is Child.lazyperclassproperty_test



# Generated at 2022-06-24 03:06:38.972032
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        a1 = roclassproperty(lambda x: 1)

    assert A.a1 == 1
    assert A().a1 == 1


# Generated at 2022-06-24 03:06:43.654108
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self._x = x
        @setterproperty
        def x(self, x):
            self._x = x
    a = A(1)
    assert a._x == 1
    a.x = 2
    assert a._x == 2

if __name__ == '__main__':
    print('Running unit tests...')
    test_setterproperty()

# Generated at 2022-06-24 03:06:49.991575
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def value(cls):
            return 1

    class B(A):
        pass

    class C(B):
        pass

    class D(C):
        @lazyperclassproperty
        def value(cls):
            return 2

    class E(D):
        pass

    assert A.value == 1
    assert B.value == 1
    assert C.value == 1
    assert D.value == 2
    assert E.value == 2



# Generated at 2022-06-24 03:07:00.072743
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class ParentClass(object):
        def __init__(self):
            self.my_value = 10

        @lazyperclassproperty
        def prop(cls):
            return cls().my_value

    class ChildClass(ParentClass):
        def __init__(self):
            self.my_value = 20

    p = ParentClass()
    c = ChildClass()
    assert p.prop == 10
    assert c.prop == 20
    p.my_value = 100
    assert p.prop == 10
    assert c.prop == 20
    p.my_value = -1
    assert p.prop == 10
    assert c.prop == 20
    c.my_value = -10
    assert p.prop == 10
    assert c.prop == 20
    c.my_value = 'not an int'
   

# Generated at 2022-06-24 03:07:02.325834
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A():
        @roclassproperty
        def attr(cls):
            return 1

    assert A.attr == 1, 'test failed - roclassproperty.__get__ must return 1'



# Generated at 2022-06-24 03:07:09.964298
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class C1(object):
        @lazyclassproperty
        def prop(cls):
            print("C1.prop getting evaluated")
            return 'the result'

    class C2(C1):
        pass

    class C3(C1):
        pass

    # Check that the property is only evaluated once, upon first access
    assert C1.prop == 'the result'
    assert '_lazy_prop' in C1.__dict__

    # Check that subclasses inherit the property
    assert C2.prop == 'the result'
    assert C3.prop == 'the result'

    # Check that subclasses have their own property
    C3.prop = 'toast'
    assert C3.prop == 'toast'
    assert C1.prop == 'the result'

# Generated at 2022-06-24 03:07:12.090287
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert C.x == 1


# Unit tests for class roclassproperty

# Generated at 2022-06-24 03:07:15.146815
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self._var = 0

        @setterproperty
        def var(self, value):
            self._var = value

        def get_var(self):
            return self._var

    test_obj = Test()
    test_obj.var = 5
    assert test_obj.get_var() == 5


# Generated at 2022-06-24 03:07:21.732725
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 123

        @setterproperty
        def a(self, v):
            print('setterproperty a')
            self._a = v

    a = A()
    a.a = a.a + 1
    return a


# Generated at 2022-06-24 03:07:27.796905
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(self):
            return 42
    assert C.x == 42
    assert C().x == 42



# Generated at 2022-06-24 03:07:34.421764
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):

        def __init__(self):
            self._bar = 0
            self._baz = "default foo"

        @setterproperty
        def bar(self, value):
            assert isinstance(value, integer_types), "value must be an integer"
            self._bar = value

        @setterproperty
        def baz(self, value):
            """Set me"""
            self._baz = value

        def __str__(self):
            return "bar={bar} baz={baz}".format(bar=self.bar, baz=self.baz)
    f = Foo()
    f.bar = 1
    assert f.bar == 1
    f.bar = "1"
    assert f.bar == 1  # should not be set

# Generated at 2022-06-24 03:07:40.832697
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Example class
    class Foo:
        _lazy_bar = lazyperclassproperty(lambda x: 'baz')
        def __init__(self):
            self.bar = None
        def get_bar(self):
            self.bar = Foo._lazy_bar
            return self.bar
    # Create a class and set its _lazy_bar
    foo = Foo()
    foo.bar = 'qux'
    # Update _lazy_bar
    foo.get_bar()
    # Validate that _lazy_bar is not modified
    assert foo.bar=='qux'



# Generated at 2022-06-24 03:07:46.163454
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            if value < 0:
                raise ValueError('x must be nonnegative')
            self._x = value

    a = A(1)
    a.x = 5

# Generated at 2022-06-24 03:07:50.067316
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):

        def __init__(self):
            self.x = 1

        @setterproperty
        def set_x(self, value):
            self.x = value

    a = A()

    assert a.x == 1
    a.set_x = 2
    assert a.x == 2


# Generated at 2022-06-24 03:07:59.597509
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(self):
            return 'test'

    assert A.test == 'test'
    assert A.test == 'test'

    class B(A):
        pass

    assert B.test == 'test'
    assert B.test == 'test'
    assert A.test == 'test'

    class C:
        @lazyclassproperty
        def test(self):
            return 'test'

    assert C.test == 'test'
    assert C.test == 'test'


# Generated at 2022-06-24 03:08:03.509734
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, state=0):
            self.state = state

        @setterproperty
        def x(self, value):
            self.state = value

    c = C()
    c.x = 5
    assert c.state == 5



# Generated at 2022-06-24 03:08:07.080960
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        c = roclassproperty(lambda a: 'c')
        def __init__(self):
            self.a = 'a'
            self.b = 'b'

    a = A()

# Generated at 2022-06-24 03:08:15.634702
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a_instance_value = 1

        @setterproperty
        def a_setter(self, value):
            self.a_setter_value = value

    a = A()
    assert not hasattr(a, 'a_setter_value')
    a.a_setter = 10
    assert a.a_setter_value == 10

# Generated at 2022-06-24 03:08:22.712073
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Uncomment following line to see the test code:
    # raise NotImplementedError(test_setterproperty___set__.__doc__)
    class A(object):
        def __init__(self, _property):
            self._property = _property

        @setterproperty
        def value(self, value):
            self._property = value
    a = A('b')
    a.value = 'c'
    assert a._property == 'c'


# Generated at 2022-06-24 03:08:25.232809
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test for correct output for valid input for method __get__ by calling it
    # and comparing the result against a known good value.
    # An exception should be raised for invalid input for method __get__.
    assert True


# Generated at 2022-06-24 03:08:31.815203
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def setter(self, value):
            pass

    assert isinstance(setterproperty(C.setter), setterproperty)
    c = C()
    assert isinstance(setterproperty(c.setter), setterproperty)


if __name__ == '__main__':
    # Unit test for the class setterproperty
    test_setterproperty()

# Generated at 2022-06-24 03:08:38.612821
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # The descriptor has priority over the (base) class
    class SpecialMethod(object):
        def __init__(self):
            self.x = None

        @roclassproperty
        def x(cls):
            return cls.__name__ + ' x is here'

    o = SpecialMethod()
    assert o.x == 'SpecialMethod x is here'

    # Subclasses get their own descriptors
    class D(SpecialMethod):
        pass

    assert D.x == 'D x is here'

    # Correct behavior for descriptor of a base class
    class E(SpecialMethod):
        @roclassproperty
        def x(cls):
            return 'E.x is here'

    assert E.x == 'E.x is here'
    assert SpecialMethod.x == 'SpecialMethod x is here'

# Generated at 2022-06-24 03:08:44.078372
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """

    class A(object):
        def __init__(self):
            self.x = 0

        def setter(self, value):
            self.x = value

        y = setterproperty(setter)

    a = A()
    a.y = 10

    assert a.x == 10
    a.y = 20
    assert a.x == 20

    print('test_setterproperty___set__ ok')



# Generated at 2022-06-24 03:08:46.440922
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def func(cls):
            return 5

        c_attr = roclassproperty(func)

    assert A.c_attr == 5



# Generated at 2022-06-24 03:08:52.592761
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo from class A'

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def foo(cls):
            return 'foo from class C'

    assert A.foo == 'foo from class A'
    assert B.foo == 'foo from class A'
    assert C.foo == 'foo from class C'


# Generated at 2022-06-24 03:08:55.430359
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return cls.__name__ + "bar"

    assert A.foo == "Abar"
    assert A.foo == "Abar"



# Generated at 2022-06-24 03:09:01.889822
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        def __init__(self):
            self._bar = 'Bar'

        @setterproperty
        def foo(self, value):
            self._bar = value + self._bar

    obj = Obj()
    obj.foo = 'Foo'
    assert 'FooBar' == obj._bar, obj._bar



# Generated at 2022-06-24 03:09:07.021527
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import types

    last_names = {}

    class SelfReferential(object):
        @lazyperclassproperty
        def a(a):
            assert isinstance(a, types.FunctionType), "a should be a function"
            assert a.__name__ == "a", "a's name should be 'a'"
            a.__doc__ = "SelfReferential.a()"
            return a

        @a.setter
        def a(a, value):
            a.__docs__ = "SelfReferential.a.setter()"

    assert hasattr(SelfReferential, "a"), "SelfReferential should have its own 'a'"

    s = SelfReferential()
    assert hasattr(s, "a"), "SelfReferential object should have its own 'a'"


# Generated at 2022-06-24 03:09:14.119414
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClassFor_roclassproperty(object):
        foo = roclassproperty(lambda c: "foo")

        def __init__(self):
            self.bar = "bar"

        @roclassproperty
        def foobar(cls):
            return "foobar"

    dummy_object = DummyClassFor_roclassproperty()
    assert dummy_object.foo == "foo"
    assert dummy_object.foobar == "foobar"


# Generated at 2022-06-24 03:09:20.740436
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self._x = 10


# Generated at 2022-06-24 03:09:27.882448
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self):
            self.roproperty = 'ro'
            self.property = 'r/w'
            self.class_property = "class prop"

        @roclassproperty
        def classroproperty(cls):
            return cls.class_property

    tc = TestClass()
    assert tc.roproperty == 'ro'
    assert tc.property == 'r/w'
    assert tc.classroproperty == 'class prop'
    with raises(AttributeError):
        tc.classroproperty = 'fail'
    assert tc.classroproperty == 'class prop'

# Generated at 2022-06-24 03:09:37.016087
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        pass

    def make_roclassproperty(x):
        def f(obj):
            return x
        return roclassproperty(f)

    cp = make_roclassproperty(1)
    C.cp = cp
    assert C.cp == 1
    c = C()
    assert c.cp == 1
    try:
        c.cp = 2
    except AttributeError:
        pass
    else:
        assert False, "AttributeError not raised"


if __name__ == '__main__':
    # Unit test for function lazyperclassproperty
    class C(object):
        @lazyperclassproperty
        def foo(cls):
            return object()

    c1 = C()
    c2 = C()
    assert c1.foo is c1.foo
    assert c2

# Generated at 2022-06-24 03:09:43.247432
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):
        @setterproperty
        def x(self, x):
            self._x = x

    foo = Foo()
    assert not hasattr(foo, "_x")
    foo.x = 1
    assert foo.x == 1
    assert foo._x == 1
    foo.x = 2
    assert foo.x == 2
    assert foo._x == 2

if __name__ == "__main__":
    test_setterproperty()

# Generated at 2022-06-24 03:09:48.562545
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """Unit test for method ``setterproperty.__set__``. """

    class Cls(object):
        def __init__(self):
            self.__attr = None

        @setterproperty
        def attr(self, val):
            self.__attr = val

        @property
        def prp(self):
            return self.__attr

    inst = Cls()
    inst.attr = 1
    assert inst.prp == 1



# Generated at 2022-06-24 03:09:54.566661
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Test(object):
        @roclassproperty
        def f(cls):
            return cls

        def g(self):
            return Test

    assert Test.f is Test
    assert Test().f is Test
    assert Test.g() is Test


# Generated at 2022-06-24 03:09:59.558015
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.a = 1

        @setterproperty
        def a(self, value):
            if value < 0:
                raise ValueError('Argument must be greater than 0')
            self.__a = value

    a = A()

    try:
        a.a = -1
        assert False, 'error must be raised here'
    except ValueError:
        pass

    a.a = 10
    assert a.a == 10

# Generated at 2022-06-24 03:10:03.267872
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def _method(cls):
            return 'test'
    assert Test._method == 'test'



# Generated at 2022-06-24 03:10:06.441852
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class T:
        def __init__(self, value):
            self._value = value

        @setterproperty
        def value(self, value):
            self._value = value

    a = T(1)
    assert a.value == 1
    a.value = 3
    assert a.value == 3



# Generated at 2022-06-24 03:10:08.811498
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):

        @lazyperclassproperty
        def prop(cls):
            return 1

    class Child(Base):
        @lazyperclassproperty
        def prop(cls):
            return 12

    assert Base.prop == 1
    assert Child.prop == 12



# Generated at 2022-06-24 03:10:13.330235
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class c:
        pass

    cp = roclassproperty(lambda x: 1)
    c.cp = cp
    assert c.cp == 1

    try:
        c.cp = 2
        assert False, "Assignment should fail with AttributeError"
    except AttributeError:
        pass



# Generated at 2022-06-24 03:10:18.130384
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def value(cls):
            return cls

    assert A.value == A
    try:
        A.value = 1
        assert False
    except AttributeError:
        pass

    class B(A):
        pass

    assert B.value == B
    assert A.value == A


# Generated at 2022-06-24 03:10:21.660567
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    dynamic_name = 'dynamic_name'
    class Test(object):
        @lazyclassproperty
        def test_lazyclassproperty(cls):
            print('The only time you should see this is when this test runs.')
            return dynamic_name

    assert Test.test_lazyclassproperty is dynamic_name

test_lazyclassproperty() # Run the test on import



# Generated at 2022-06-24 03:10:24.122105
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self, value):
            self.__value = value

        @roclassproperty
        def value(cls):
            return cls.__value
    t = Test('test_roclassproperty')
    assert t.value == 'test_roclassproperty'



# Generated at 2022-06-24 03:10:34.248450
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from six import with_metaclass
    class Base(object):
        @lazyperclassproperty
        def get_toto(cls):
            return 1 # We could use other class here but I keep this simple
        
    class C(with_metaclass(type, Base)):
        pass
        
    class D(with_metaclass(type, Base)):
        pass
        
    assert C.get_toto == 1
    assert D.get_toto == 1
    assert type(C.get_toto) == int
    assert type(D.get_toto) == int
    assert type(C.get_toto) == type(D.get_toto)
    assert id(C.get_toto) != id(D.get_toto)


# Generated at 2022-06-24 03:10:39.400791
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return cls.__name__ + 'foo'

    assert A.__dict__ == {"__module__": "__main__", "foo": "Afoo"}

    class B(A):
        pass

    assert A.__dict__ == {"__module__": "__main__", "foo": "Afoo"}
    assert B.__dict__ == {"__module__": "__main__", "foo": "Bfoo"}



# Generated at 2022-06-24 03:10:44.482178
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Provider(object):
        def __init__(self):
            self._name = 'John Doe'

        @setterproperty
        def name(self, value):
            self._name = value

        @property
        def name(self):
            return self._name

    provider = Provider()
    assert(provider.name == 'John Doe')
    provider.name = 'Jane Doe'
    assert(provider.name == 'Jane Doe')


# Generated at 2022-06-24 03:10:53.614717
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        def __init__(self):
            self._a = 10

        @lazyclassproperty
        def a(cls):
            return cls()

    # Check that instance of TestClass is created once.
    assert TestClass.a._a == 10

    # Check that the same instance is returned.
    assert TestClass.a is TestClass.a

    # Check that a new instance is created, if instance of OtherTestClass is created.
    class OtherTestClass(object):
        def __init__(self):
            self._a = 20

        @lazyclassproperty
        def a(cls):
            return cls()

    assert isinstance(OtherTestClass.a, OtherTestClass)
    assert OtherTestClass.a._a == 20

    # Check that a new instance is created, if TestClass

# Generated at 2022-06-24 03:10:57.598211
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    global i

    class A(object):
        @lazyclassproperty
        def prop(cls):
            global i
            if i == 0:
                return 'A'
            else:
                return 'B'

    class B(A):
        pass

    print(A.prop)
    i = 1
    print(A.prop)
    print(B.prop)



# Generated at 2022-06-24 03:11:01.055210
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        def get_attr(self):
            return 1

        @lazyclassproperty
        def lazy_attr(cls):
            return cls()

        @lazyclassproperty
        def lazy_attr2(cls):
            return cls.get_attr()

    assert Foo.lazy_attr.lazy_attr2 == 1


# Generated at 2022-06-24 03:11:07.094242
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class c(object):
        @lazyclassproperty
        def x(cls):
            return 1
    assert c.x == 1
    assert c.__dict__['_lazy_x'] == 1
    assert not hasattr(c, 'x')
    object.__setattr__(c, '_lazy_x', 2)
    assert c.x == 2


# Generated at 2022-06-24 03:11:09.653758
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def f(cls):
            return cls is C

    assert C.f

    try:
        C().f
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:11:18.998784
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class RoClassPositive:
        name = 'class property'

        @roclassproperty
        def class_prop(cls):    # it's ok to have cls as the only parameter
            return cls.name

        @roclassproperty
        def class_prop2(a):
            return a

    class RoClassNegative:
        # raise exception since `instance` is not in scope
        @roclassproperty
        def class_prop(cls, instance):
            return instance.name

    assert RoClassPositive.class_prop == 'class property'
    assert RoClassPositive.class_prop2 == RoClassPositive
    with pytest.raises(NameError):
        RoClassNegative.class_prop



# Generated at 2022-06-24 03:11:24.952886
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 1

    assert Foo.bar == 1
    assert Foo.bar == 1
    Foo.bar = 2
    assert Foo.bar == 1   # Read-only class property cannot be overwritten.


# Generated at 2022-06-24 03:11:28.249233
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if value < 0:
                raise ValueError('Must be non-negative')
            self._x = value

    c = C()

# Generated at 2022-06-24 03:11:30.552163
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class _X(object):
        def _get_x(self):
            return self._x

        def _set_x(self, x):
            self._x = x
        x = setterproperty(_set_x)

    x = _X()
    x.x = 42
    assert x._x == 42



# Generated at 2022-06-24 03:11:35.844084
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def a(cls):
            return 'a'

    class B(object):
        @roclassproperty
        def a(cls):
            return 'b'

    assert A.a == 'a'
    assert B.a == 'b'
    assert A().a == 'a'
    assert B().a == 'b'

# Unit test __get__ of class lazyclassproperty

# Generated at 2022-06-24 03:11:37.456244
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class ClassUnderTest:
        @setterproperty
        def Field(self, value):
            self.field = value

    cu = ClassUnderTest()
    cu.Field = True # this calls the "setter"
    assert cu.field == True



# Generated at 2022-06-24 03:11:38.416542
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def b(cls):
            return cls
    assert A.b == A



# Generated at 2022-06-24 03:11:50.140505
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Tests lazyclassproperty decorator.
    """

    class MyClass(object):
        def __init__(self, name):
            self.name = name

        @lazyclassproperty
        def someclassattr(cls):
            print("Setting someclassattr value")
            return "some class attribute"

        @lazyclassproperty
        def someotherclassattr(cls):
            print("Setting someotherclassattr value")
            return self.name

    class MyClass2(MyClass):
        pass

    my_class = MyClass("my_class")
    my_class2 = MyClass2("my_class2")

    # Test lazyclassproperty
    assert my_class.someclassattr == "some class attribute"
    assert MyClass.someclassattr == "some class attribute"
    assert my_class2.some

# Generated at 2022-06-24 03:11:51.663285
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def a(cls):
            return 1

    class D(C):
        pass

    print(C.a, D.a)



# Generated at 2022-06-24 03:11:56.595663
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:12:02.243529
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def foo(cls):
            print('Calculating foo...')
            return 'foo'

        @lazyclassproperty
        def bar(cls):
            print('Calculating bar...')
            return 'bar'

    class D(C):
        pass

    assert C.foo == 'foo'
    assert D.foo == 'foo'
    assert C.foo is D.foo

    assert C.bar == 'bar'
    assert D.bar == 'bar'
    assert C.bar is D.bar



# Generated at 2022-06-24 03:12:06.093012
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        def f(cls):
            return cls.__name__
        p = roclassproperty(f)
    assert C.p == 'C'
    assert C().p == 'C'


# Generated at 2022-06-24 03:12:10.508723
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.x = None

        def set_x(self, value):
            self.x = value + 10

        X = setterproperty(set_x)

    a = A()
    a.X = 20
    assert a.x == 30

# Generated at 2022-06-24 03:12:15.517204
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def foo(self, value):
        self.__tmp = value

    x = setterproperty(foo)
    assert x.func == foo
    assert x.__doc__ is None
    assert hasattr(x, '__set__') is False
    assert x.__set__ is foo

    # Test with non-empty doc string
    x = setterproperty(foo, doc='Test property')
    assert x.__doc__ == 'Test property'



# Generated at 2022-06-24 03:12:25.104071
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):

        def myprop1(cls):
            return 1

        myprop1 = lazyclassproperty(myprop1)

        def myprop2(cls):
            return 2

        myprop2 = lazyclassproperty(myprop2)

    class Bar(Foo):
        def myprop3(cls):
            return 3

        myprop3 = lazyclassproperty(myprop3)

    assert Foo.myprop1 == 1
    assert Foo.myprop2 == 2
    assert Bar.myprop1 == 1
    assert Bar.myprop2 == 2
    assert Bar.myprop3 == 3



# Generated at 2022-06-24 03:12:29.869843
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        pass

    c = C()
    assert not hasattr(c, 'name')

    @roclassproperty
    def name(cls):
        return "name"

    assert "name" == C.name
    assert "name" == c.name


# Generated at 2022-06-24 03:12:37.477051
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestLazyProperty(object):
        def __init__(self, name):
            self._name = name

        @lazyclassproperty
        def name(cls):
            return cls._name

    assert TestLazyProperty.name == TestLazyProperty._name
    TestLazyProperty._name = 'test2'
    assert TestLazyProperty.name == TestLazyProperty._name



# Generated at 2022-06-24 03:12:43.688508
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):

        @setterproperty
        def bar(self, bar):
            self.bar = bar
            return bar

    foo = Foo()
    assert foo.bar is None
    assert setattr(foo, "bar", "baz") == "baz"
    assert foo.bar == "baz"



# Generated at 2022-06-24 03:12:46.620428
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def x(self, value):
            self.__x = value

        def getx(self):
            return self.__x

    t = A()
    t.x = 10
    assert t.getx() == 10



# Generated at 2022-06-24 03:12:58.512593
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def f(self):
            return 'Hello'

        @roclassproperty
        def p(klass):
            return klass.f(klass)

    c = Test()
    assert c.p == 'Hello'


if sys.version_info < (3, 0):
    classinstancemethod = types.MethodType
else:
    # Taken from Python 3.3 stdlib.
    #
    # classmethod has become a "builtin" in Python 3.3, so this is just here to support older
    # versions.
    def classinstancemethod(func):
        @functools.wraps(func)
        def wrapper(self, *args, **kwargs):
            return func(self.__class__, *args, **kwargs)
        return wrapper

# Generated at 2022-06-24 03:13:04.372351
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Person(object):
        def __init__(self, age=None, name=None):
            self._age = age
            self._name = name

        def get_age(self):
            return self._age

        def set_age(self, value):
            if value < 0 or value > 150:
                raise ValueError('Invalid age: {}'.format(value))
            self._age = value

        def get_name(self):
            return self._name

        def set_name(self, value):
            if not isinstance(value, str):
                raise TypeError('Invalid name: {}'.format(value))
            self._name = value

        age = setterproperty(get_age, set_age)
        name = setterproperty(get_name, set_name)

    p = Person()
    # setter functions

# Generated at 2022-06-24 03:13:10.812881
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import os, time

    class A(object):

        @lazyperclassproperty
        def lazyproperty(cls):
            print('lazyproperty called in class {}'.format(cls))
            time.sleep(1)
            return os.urandom(16).encode('hex')

    class B(A): pass

    class C(A): pass

    assert A.lazyproperty == B.lazyproperty
    print('OK')


# Generated at 2022-06-24 03:13:14.523801
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        _x = 2
        @roclassproperty
        def x(cls):
            return cls._x
    assert C.x == 2
    c = C()
    assert c.x == 2
    C._x = 3
    assert C.x == 3



# Generated at 2022-06-24 03:13:20.931871
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class A(object):
        @setterproperty
        def x(self, value):
            self.y = value

    a = A()
    a.x = 3
    assert a.y == 3

    # Test of @setterproperty as decorator
    class B(object):
        @setterproperty
        def x(self, value):
            self.y = value

    b = B()
    b.x = 3
    assert b.y == 3

    # Test of @setterproperty as decorator and __doc__ is None
    class C(object):
        @setterproperty
        def x(self, value):
            """
            This is the docstring of x.
            """
            self.y = value

    c = C()
    c.x = 3
    assert c.y == 3

    # Test

# Generated at 2022-06-24 03:13:23.169385
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def p(cls):
            return cls

    assert C.p is C



# Generated at 2022-06-24 03:13:32.663060
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class ClassProperty:
        def __init__(self):
            self.x = 1
            self.y = 2
            self.z = 3

    class foo(ClassProperty):
        @lazyclassproperty
        def not_lazy(cls): return cls.x + cls.y

        @lazyclassproperty
        def lazy(cls):
            cls.z += 1
            return cls.x + cls.z

    f = foo()
    assert f.not_lazy == 1 + 2
    f.x = 10
    assert f.not_lazy == 1 + 2
    f.y = 20
    assert f.not_lazy == 1 + 2
    f.z = 30
    assert f.not_lazy == 1 + 2
    assert f.lazy == 10 + 31
    f

# Generated at 2022-06-24 03:13:36.952209
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            print("Foo.foo called")
            return 42

    assert Foo.foo == 42
    assert Foo.foo == 42



# Generated at 2022-06-24 03:13:44.417942
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class TestSetterProperty(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def test(self, new_value):
            self.value = new_value

    test_setter_property_instance = TestSetterProperty(10)
    assert test_setter_property_instance.value == 10
    test_setter_property_instance.test = 2000
    assert test_setter_property_instance.value == 2000

# Generated at 2022-06-24 03:13:48.833813
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.x = 0
        @setterproperty
        def x(self, value):
            print('setter of x called')
            self.x = value
        def __repr__(self):
            return 'A(%s)' % self.x
    obj = A()
    print(obj)
    obj.x = 10
    print(obj)

