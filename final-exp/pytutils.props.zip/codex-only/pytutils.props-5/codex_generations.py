

# Generated at 2022-06-24 03:03:55.717998
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Base(object):
        @lazyclassproperty
        def value(cls):
            return cls.__name__

    assert Base.value == 'Base'
    assert Base._lazy_value == 'Base'

    class SubClass(Base):
        pass

    assert SubClass.value == 'SubClass'
    assert SubClass._lazy_value == 'SubClass'
    # Note that the following is not true:
    assert Base._lazy_value == 'SubClass'

    class SubSubClass(SubClass):
        pass

    assert SubSubClass.value == 'SubSubClass'
    assert SubSubClass._lazy_value == 'SubSubClass'
    assert SubClass._lazy_value == 'SubClass'
    assert Base._lazy_value == 'Base'



# Generated at 2022-06-24 03:03:59.372531
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def x(self):
            return 1729

        @roclassproperty
        def y(self):
            return 'seven'

    assert Foo.x == 1729
    foo = Foo()
    assert Foo.x == 1729
    assert foo.y == 'seven'



# Generated at 2022-06-24 03:04:02.538065
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def foo(cls):
            return 'bar'

        ro_foo = roclassproperty(foo)

    assert C.ro_foo == 'bar'



# Generated at 2022-06-24 03:04:12.473239
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def x(cls):
            return 'apple'
        @roclassproperty
        def y(cls):
            return 'oranges'

        @classproperty
        def z(cls):
            return 'pears'

    c = C()

    assert c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x == c.x

# Generated at 2022-06-24 03:04:18.496445
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def getter(cls):
            return cls.__name__

    class B(A):
        pass

    assert(A.getter == 'A')
    assert(B.getter == 'B')


# Generated at 2022-06-24 03:04:27.466080
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        """
        A test class to test the constructor of setterproperty
        """
        _my_property = None

        @setterproperty
        def my_property(self, value):
            """
            A test method to test the constructor of setterproperty
            """
            self._my_property = value

        @setterproperty
        def my_property2(self, value):
            """
            A test2 method to test the constructor of setterproperty
            """
            self._my_property = value+1

    obj = MyClass()
    obj.my_property = "my_property"
    assert obj._my_property == "my_property"
    print("Constructor of setterproperty works!")



# Generated at 2022-06-24 03:04:34.185405
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self, value):
            self._x = value
    obj = C()
    obj.x = 4
    assert obj.x == 4
    assert obj._x == 4
    # Tests the case of doubled assignment
    obj.x = 5
    assert obj.x == 5
    assert obj._x == 5

# Generated at 2022-06-24 03:04:38.222758
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls): return 'x {0:s}'.format(cls.__name__)

    assert C.x == 'x C'
    assert C().x == 'x C'


# Generated at 2022-06-24 03:04:40.187796
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class X(object):
        @roclassproperty
        def f(cls):
            return cls
    assert X.f is X
    assert X().f is X

# Generated at 2022-06-24 03:04:44.376674
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def myprop(cls):
            print("Generating value")
            return 1

    print("%d, %d" % (C.myprop, C.myprop))

if __name__ == "__main__":
    test_lazyclassproperty()

# Generated at 2022-06-24 03:04:48.548703
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            return {'x': cls}

    class D(C):
        pass

    assert C.x == {'x': C}
    assert D.x == {'x': D}



# Generated at 2022-06-24 03:04:53.769286
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    classclassproperty = roclassproperty

    class MyClass:
        def __init__(self):
            self.x = 3

        @classclassproperty
        def x(self):
            return 4

    assert MyClass.x == 4

    a = MyClass()
    assert a.x == 3



# Generated at 2022-06-24 03:05:02.368564
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:05:04.399042
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'spam'

    assert Foo.bar == 'spam'



# Generated at 2022-06-24 03:05:06.318147
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def f(cls):
            return 1

    assert A.f == 1
    assert A().f == 1



# Generated at 2022-06-24 03:05:09.956910
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return cls.__name__

    class B(A):
        pass

    assert A.foo == 'A'
    assert B.foo == 'B'



# Generated at 2022-06-24 03:05:14.358862
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def _get_ro_instance():
            return "ro_instance"

        ro_instance = roclassproperty(_get_ro_instance)

    a = A()
    assert a.ro_instance == A.ro_instance
    assert 'ro_instance' == A.ro_instance



# Generated at 2022-06-24 03:05:20.648979
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return "x"

    assert C.x == "x"
    # assert C().x == "x"
    # Will get an exception


# Generated at 2022-06-24 03:05:24.952745
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @roclassproperty
        def f(cls):
            return 'I am {0}'.format(cls)

    assert A.f == 'I am __main__.A'
    a = A(42)
    assert a.f == 'I am __main__.A'
    assert a.x == 42



# Generated at 2022-06-24 03:05:33.841587
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def num(cls):
            return 1

    class B(A):
        pass

    assert A.num == 1
    assert B.num == 1
    A.num = 2
    assert A.num == 2
    assert B.num == 1
    assert '_A_lazy_num' in A.__dict__
    assert '_B_lazy_num' in B.__dict__
    assert not '_lazy_num' in A.__dict__
    assert not '_lazy_num' in B.__dict__



# Generated at 2022-06-24 03:05:36.300349
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        _x = None
        @setterproperty
        def x(self, value):
            self._x = value

    a = A()
    assert a._x is None
    a.x = 1
    assert a._x == 1
    a.x = 2
    assert a._x == 2

# Generated at 2022-06-24 03:05:40.368365
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        def __init__(self):
            self.x = 0

        @setterproperty
        def setx(self, value):
            self.x = value

    instance = MyClass()
    assert instance.x == 0
    instance.setx = 1
    assert instance.x == 1



# Generated at 2022-06-24 03:05:41.689485
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:05:49.094989
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @property
        def prop(self):
            return self.prop

        @roclassproperty
        def roclassprop(cls):
            return cls.roclassprop

        @classproperty
        def classprop(cls):
            return cls.classprop

    my = MyClass()
    assert my.prop == my.prop
    assert MyClass.classprop == MyClass.classprop
    assert MyClass.roclassprop == MyClass.roclassprop



# Generated at 2022-06-24 03:05:58.809422
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, value):
            if not isinstance(value, (int, float)):
                raise TypeError("I don't like %s" % value)
            self._x = value

        @x.getter
        def x(self):
            return self._x

        @x.deleter
        def x(self):
            del self._x

    a = A(1)
    assert a.x == 1
    a.x = 2
    assert a.x == 2
    del a.x
    assert not hasattr(a, 'x')
    # Should raise TypeError because I specified only (int, float)

# Generated at 2022-06-24 03:06:03.191896
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        @setterproperty
        def bar(self, value):
            self.value = value

    foo = Foo()
    foo.bar = 3
    pythontest(foo.value == 3)
    foo.value = 5
    pythontest(foo.value == 5)



# Generated at 2022-06-24 03:06:07.877306
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # class Cone(object):
    #     def __init__(self, diameter, height):
    #         self.diameter = diameter
    #         self.height = height
    #
    #     @roclassproperty
    #     def volume(cls):
    #         return cls.pi * cls.height / 3 * (cls.diameter / 2) ** 2
    #
    #     pi = 3.1415
    #
    #
    # print(Cone(2, 4).volume)

    class Dummy(object):
        @roclassproperty
        def value(cls):
            return 100

    d = Dummy()
    print(d.value)



# Generated at 2022-06-24 03:06:09.818358
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass:
        @roclassproperty
        def myproperty(self):
            return 'myproperty'

    assert MyClass.myproperty == 'myproperty'



# Generated at 2022-06-24 03:06:14.606989
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # We create a class to test this
    class TestClass(object):
        # Here we apply the decorator as an annotation
        @roclassproperty
        def roclassproperty_attribute(cls):
            return 'test'

        # And then we call the object
        def roclassproperty_test(self):
            return self.__class__.roclassproperty_attribute
    # Creating the object
    test = TestClass()
    # Asserting it's equal to the expected value
    assert test.roclassproperty_test() == 'test'

# Generated at 2022-06-24 03:06:23.536550
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    from pydicom.valuerep import PersonName3

    class TestPersonName3(PersonName3):
        """Test class for read-only class property."""

        @roclassproperty
        def testdoc(cls):
            """Test docstring."""
            return 'test'

        @roclassproperty
        def testmethod(cls):
            """Test method run on a class."""
            return 'test'

        def notaclassproperty(self):
            return 'test'

    assert TestPersonName3.testdoc == 'test'
    assert TestPersonName3.testmethod() == 'test'
    with pytest.raises(AttributeError):
        TestPersonName3.notaclassproperty()
    assert TestPersonName3.testmethod.__doc__ == 'Test method run on a class.'



# Generated at 2022-06-24 03:06:25.805821
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Obj(object):
        @setterproperty
        def prop(self, value):
            self.value = value

    obj = Obj()
    obj.prop = 42
    assert obj.value == 42
    assert obj.prop is None



# Generated at 2022-06-24 03:06:34.721229
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.a = 1
            self.b = 2

        @setterproperty
        def p(self, value):
            if value == 5:
                self.a = 5
            self.b = value

    t = Test()
    t.p = 3
    assert t.a == 1
    assert t.b == 3
    t.p = 1
    assert t.a == 1
    assert t.b == 1
    t.p = 5
    assert t.a == 5
    assert t.b == 5



# Generated at 2022-06-24 03:06:40.580826
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.x = None
        @setterproperty
        def x(self, value):
            self.__x = value
        @x.getter
        def x(self):
            return self.__x

    foo = Foo()
    foo.x = 1

    assert foo.x == 1

# Generated at 2022-06-24 03:06:49.133150
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def getX(cls):
            return 23
        x = roclassproperty(getX)

    a = A()
    # x is property, there is no getX method
    assert not hasattr(a, 'getX')
    # Access to class attribute x
    assert a.x == 23
    # class attribute x is read-only
    try:
        a.x = 42
    except AttributeError as e:
        assert str(e) == "'A' object attribute 'x' is read-only"
    else:
        # Setting x should have raised an AttributeError exception
        assert 0



# Generated at 2022-06-24 03:06:58.506241
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 1


    class B(A):
        pass

    class C(A):
        pass

    a = A()
    b = B()
    c = C()
    assert not hasattr(A, '_A_lazy_test')
    assert not hasattr(B, '_B_lazy_test')
    assert not hasattr(C, '_C_lazy_test')
    assert a.test == b.test == c.test
    assert hasattr(A, '_A_lazy_test')
    assert hasattr(B, '_B_lazy_test')
    assert hasattr(C, '_C_lazy_test')
    assert a.test == b.test == c.test


# Generated at 2022-06-24 03:07:02.644779
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def x(cls):
            return "A"

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def x(cls):
            return "C"

    assert A.x == "A"
    assert B.x == "A"
    assert C.x == "C"



# Generated at 2022-06-24 03:07:10.342466
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @classproperty
        def test_roclassprop(cls):
            return cls.__name__

        @roclassproperty
        def test_roclassprop2(cls):
            return cls.__name__

        @setterproperty
        def test_setter_classprop(self, value):
            self.test_setter_classprop = value

    class B(A): pass

    assert A.test_roclassprop == 'A'
    assert B.test_roclassprop == 'B'

    assert A.test_roclassprop2 == 'A'
    assert B.test_roclassprop2 == 'B'

    a = A()
    b = B()

    # using setter property
    a.test_setter_classprop = 3
    assert a.test_

# Generated at 2022-06-24 03:07:15.835509
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class TestBase:
        def __init__(self):
            self.uniquevalue = 'Test'

    class Test(TestBase):
        @lazyperclassproperty
        def cache(cls):
            return cls.uniquevalue

    assert Test.cache == 'Test'

    class TestSub(Test):
        @lazyperclassproperty
        def cache(cls):
            return cls.uniquevalue

    assert TestSub.cache == 'Test'
    assert Test.cache == 'Test'


# Generated at 2022-06-24 03:07:23.209508
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    import collections
    decorator = lazyclassproperty

    class A:
        @decorator
        def value(cls):
            return 'something'

    class B(A):
        pass

    class C(A):
        @decorator
        def value(cls):
            return 'something else'

    assert A.value == 'something'
    assert B.value == 'something'
    assert C.value == 'something else'
    print("lazyclassproperty test passed")


# Generated at 2022-06-24 03:07:26.502967
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test_setterproperty():
        @setterproperty
        def func(self, value):
            self.value = value

    obj = Test_setterproperty()
    obj.func = 1
    assert obj.value == 1


# Generated at 2022-06-24 03:07:29.739075
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Unit test for method __get__ of class roclassproperty
    """

    class C(object):
        @roclassproperty
        def some_prop(cls):
            return 'test'

    assert C.some_prop == 'test'



# Generated at 2022-06-24 03:07:33.325699
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class MyClass(object):
        @lazyclassproperty
        def my_method(cls):
            return 'foo'

    assert MyClass.my_method == 'foo'
    assert MyClass.__dict__['_lazy_my_method'] == 'foo'
    MyClass._lazy_my_method = 'bar'
    assert MyClass.my_method == 'bar'



# Generated at 2022-06-24 03:07:39.796674
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class A:
        def __init__(self):
            self.x = None
        @setterproperty
        def x(self, value):
            print("setterproperty: x =", value)
            self._x = value
        @property
        def x(self):
            print("property: x =", self._x)
            return self._x

    a = A()
    a.x = 1
    assert a.x == 1
    assert a._x == 1



# Generated at 2022-06-24 03:07:47.749163
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from types import MethodType

    class B(object):
        @lazyclassproperty
        def f(cls):
            return cls.__name__

    class A(B):
        pass

    assert B.f == 'B'
    assert A.f == 'A'
    B.f = 'a'
    assert B.f == 'a'
    assert A.f == 'A'

    try:
        B._lazy_f = 'a'
    except AttributeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 03:07:54.451832
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test1(object):
        @lazyclassproperty
        def testmethod(cls):
            print("1")
            return 1

    class Test2(Test1):
        pass
    assert Test1.testmethod == 1
    assert Test2.testmethod == 1



# Generated at 2022-06-24 03:07:56.226471
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def func(cls):
            return cls

        prop = roclassproperty(func)

    assert A.prop is A



# Generated at 2022-06-24 03:08:03.675044
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestSetter(object):

        def __init__(self):
            self._age = 0

        @setterproperty
        def age(self, value):
            self._age = value

        @property
        def age(self):
            return self._age

    obj = TestSetter()
    assert obj.age == 0
    obj.age = 12
    assert obj.age == 12
    try:
        obj.age
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:08:11.599231
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestBase:
        def __init__(self, name):
            self.name = name

    class TestClass(TestBase):
        @lazyperclassproperty
        def test_property(cls):
            """
            This is a lazy/cached class property.
            """
            print(cls.__name__, ": Calculating test_property")
            return (cls.__name__, ": Test property value")

    class TestChildClass(TestClass):
        def __init__(self, name):
            self.name = name

    class TestGrandChildClass(TestChildClass):
        def __init__(self, name):
            self.name = name

    # Create instances
    test_instance = TestClass("TestClass")
    test_child_instance = TestChildClass("TestChildClass")
    test_

# Generated at 2022-06-24 03:08:18.436732
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def value(self):
            return 5

    class B(A):
        pass

    assert A().value == 5
    assert B().value == A().value

    A().value = 10
    assert A().value == 10
    assert B().value == 5



# Generated at 2022-06-24 03:08:23.906757
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            print('calling foo()')
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42
    print('type(A.foo):', type(A.foo))
    print('type(B.foo):', type(B.foo))
    assert id(A.foo) != id(B.foo)



# Generated at 2022-06-24 03:08:29.905176
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    import unittest

    class A(object):
        def getB(cls):
            return B()

        def getC(cls):
            return C()

        get_b = roclassproperty(getB)
        get_c = roclassproperty(getC)

    class B(object):
        pass

    class C(B):
        pass

    class Test(unittest.TestCase):
        """
        Unit test for method __get__ of class roclassproperty.
        """
        def test___get__(self):
            """
            Tests method __get__ of class roclassproperty.
            """
            self.assertIsInstance(A.get_b, roclassproperty)
            self.assertIsInstance(A.get_c, roclassproperty)


# Generated at 2022-06-24 03:08:34.162848
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def the_answer(cls):
            return 6 * 7

    class B(A):
        pass
    assert A.the_answer == 42
    assert B.the_answer == 42
    assert A.__dict__['_lazy_the_answer'] is B.__dict__['_lazy_the_answer']



# Generated at 2022-06-24 03:08:35.593904
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        @setterproperty
        def bar(self, value):
            self.value = value

    f = Foo()
    f.bar = 'bar'
    assert f.value == 'bar'


# Generated at 2022-06-24 03:08:43.070245
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def bar(self, value):
            self.value = value
            return value

    foo = Foo()
    # test correct value assignment
    assert foo.bar == 'baz'
    # docstring is propagated
    assert foo.bar.__doc__ == setterproperty.__doc__
    # setterproperty is returned, not the callee function
    assert foo.bar is not Foo.bar

    assert foo.value == 'baz'


# Generated at 2022-06-24 03:08:53.474386
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        _cached = 'cached on A'

        @lazyperclassproperty
        def a(cls):
            assert cls is A
            return cls.a_impl() + '_A'

        @classmethod
        def a_impl(cls):
            return 'a'

        @lazyperclassproperty
        def cached(cls):
            assert cls is A
            return cls._cached

    class B(A):
        _cached = 'cached on B'

        @lazyperclassproperty
        def a(cls):
            assert cls is B
            return cls.a_impl() + '_B'

        @classmethod
        def a_impl(cls):
            return 'b'

    assert A.a == 'a_A'


# Generated at 2022-06-24 03:08:58.121731
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, val):
            self.val = val
            self.setterval = val

        @setterproperty
        def val(self, val):
            """
            Setter docstring
            """
            self.setterval = val

    a = A(20)
    a.val = 10

    assert a.val == 20
    assert a.setterval == 10


# Generated at 2022-06-24 03:09:01.012325
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 'the result'
    c = C()
    assert c.prop == 'the result'
    c.prop = 'abc'
    assert c.prop == 'abc'


# Generated at 2022-06-24 03:09:09.021462
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import types

    class A(object):
        def __init__(self):
            self.value = None

        @setterproperty
        def prop(self, value):
            self.value = value

    a = A()
    a.prop = 42
    assert a.value == 42
    assert type(a.prop) == types.MethodType


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:09:13.870933
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.x = 'X'

        @setterproperty
        def x(self, x):
            self.__dict__['x'] = x * 2

    a = A()
    a.x = 'y'
    assert a.x == 'yy'


# Generated at 2022-06-24 03:09:19.595717
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls):
            return 1
        x = roclassproperty(getx)
    assert C.x == 1
    with pytest.raises(AttributeError):
        C.x = 2
    c = C()
    c.x = 2
    assert c.x == 2

# Generated at 2022-06-24 03:09:24.897296
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo():
        @roclassproperty
        def foo(cls):
            return cls

    assert Foo() is not Foo
    assert Foo().foo is Foo
    assert Foo.foo is Foo



# Generated at 2022-06-24 03:09:28.673781
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Base(object):
        def get_x(x):
            return x

    class Test(Base):
        x = roclassproperty(Base.get_x)

    print(Test.x)
    print(Base.x)
    try:
        Test.x = 1
    except:
        print("Exception: Test.x cannot be assigned")


# Generated at 2022-06-24 03:09:37.756895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from collections import OrderedDict

    class Foo(object):
        def __init__(self, name):
            self.name = name

    class Bar(object):
        def __init__(self, name):
            self.name = name

    class FooBar(Foo, Bar):
        def __init__(self, name):
            super(FooBar, self).__init__(name)

    class Test(object):
        @lazyperclassproperty
        def dict_cls_inst(cls):
            return OrderedDict()

    foobars = [FooBar('foo'), FooBar('bar')]
    t = Test()
    print(t.dict_cls_inst)
    t.dict_cls_inst[FooBar] = foobars

# Generated at 2022-06-24 03:09:45.022671
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Class:
        @lazyclassproperty
        def prop(cls):
            print('setting prop')
            return 42

    c1 = Class()
    c2 = Class()

    print(c1.prop)
    print(c1.prop)

    # Changing the descriptor does change the value for all instances!
    Class.prop = property(lambda cls: 24)
    print(c1.prop)
    print(c2.prop)

    print(Class.prop)
    print(Class.prop)



# Generated at 2022-06-24 03:09:47.228237
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def myval(cls):
            return 1

    assert Foo.myval == 1
    assert Foo().myval == 1



# Generated at 2022-06-24 03:09:49.578554
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def test(cls):
            return cls.__name__

    assert TestClass.test == 'TestClass'



# Generated at 2022-06-24 03:09:57.407573
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def x(cls):
            return 1

    instance = A()
    assert(A.x == 1)
    assert(instance.x == 1)
    with pytest.raises(AttributeError):
        A.x = 2
    with pytest.raises(AttributeError):
        instance.x = 3
    assert(A.x == 1)
    assert(instance.x == 1)


# Generated at 2022-06-24 03:10:07.545467
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class AClass(object):
        _lazy_static_method_calls = 0

        def __init__(self):
            self._lazy_method_calls = 0

        @lazyclassproperty
        def lazy_class_property(cls):
            # print self
            cls._lazy_static_method_calls += 1
            return cls._lazy_static_method_calls

        @lazyclassproperty
        def lazy_class_property2(cls):
            # print self
            return 'this is the second call'

        @lazyclassproperty
        def lazy_class_property_with_docstring(cls):
            """
            This lazy class property has the docstring copied over to itself by the lazyclassproperty decorator.
            It is a very nice property.
            """

# Generated at 2022-06-24 03:10:17.689478
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from collections import namedtuple
    from functools import partial
    import unittest

    class TestSetterProperty(unittest.TestCase):

        def test_setterproperty_on_tuple_class(self):

            TestTuple = namedtuple('TestTuple', ['x', 'y'])

            class TupleWithSetterProperty(TestTuple):
                @setterproperty
                def x(self, new_x):
                    return self.__class__(new_x, self.y)

            t = TupleWithSetterProperty(1, 2)
            self.assertEqual(t, (1, 2))
            self.assertEqual(t.x, 1)
            self.assertEqual(t.y, 2)
            new_t = t.x(3)
            self.assertE

# Generated at 2022-06-24 03:10:22.467621
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A(object):
        @lazyperclassproperty
        def b(cls):
            return cls.__name__

    assert A.b == 'A'
    assert A().b == 'A'

    class B(A):
        @lazyperclassproperty
        def b(cls):
            return cls.__name__ + '_b'

    assert A.b == 'A'
    assert A().b == 'A'
    assert B.b == 'B_b'
    assert B().b == 'B_b'


# Generated at 2022-06-24 03:10:31.128916
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazyprop(cls):
            return 1

    class B(A):
        pass

    class C(A):
        pass

    a_instance = A()
    b_instance = B()
    c_instance = C()

    assert A.lazyprop == 1
    assert B.lazyprop == 1
    assert C.lazyprop == 1
    # The following 3 lines ensure that each class has its own value for its lazyprop property
    A.lazyprop = 2
    assert A.lazyprop == 2
    assert B.lazyprop == 1
    assert C.lazyprop == 1

if __name__ == "__main__":
    test_lazyperclassproperty()

# Generated at 2022-06-24 03:10:38.696856
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def foo_get(cls):
        print('foo_get called for ' + cls.__name__)
        return 1


# Generated at 2022-06-24 03:10:42.331034
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass:
        @lazyperclassproperty
        def prop(cls):
            print('BaseClass:', cls.__name__)
            return 'BaseClass'

    class SubClass(BaseClass):
        pass

    class SubSubClass(SubClass):
        pass

    assert BaseClass.prop == 'BaseClass'
    assert SubClass.prop == 'BaseClass'
    assert SubSubClass.prop == 'BaseClass'



# Generated at 2022-06-24 03:10:58.885346
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.a = 10
            self.b = 10
            self.c = 10

        @setterproperty
        def x(self, val):
            self.a = val

        @setterproperty
        def y(self, val):
            self.b = val

        @setterproperty
        def z(self, val):
            self.c = val

    a = A()
    a.x = 1
    a.y = 2
    a.z = 3

    assert a.a == 1
    assert a.b == 2
    assert a.c == 3



# Generated at 2022-06-24 03:11:05.364414
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Car(object):
        @classproperty
        def BRAND(cls):
            return 'VOLVO'

    assert Car.BRAND == 'VOLVO'

    car1 = Car()

    assert car1.BRAND == 'VOLVO'

    assert Car.BRAND == 'VOLVO'



# Generated at 2022-06-24 03:11:13.702347
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Property(object):
        def __init__(self, value):
            self._value = value

        def __get__(self, obj, owner):
            return self._value

        def __set__(self, obj, value):
            raise AttributeError('Read-only attribute')

    class A(object):
        p = roclassproperty(Property(5))

    assert A.p == 5
    a = A()
    assert a.p == 5
    with pytest.raises(AttributeError) as excinfo:
        a.p = 6
    assert 'Read-only attribute' in str(excinfo.value)



# Generated at 2022-06-24 03:11:21.041652
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    global x
    class A(object):
        x = 3
        @roclassproperty
        def y(cls):
            return cls.x ** 2

    class B(A):
        x = 4

    print(A.y)
    print(B.y)
    print(A.__dict__)
    A.x = 2
    print(A.y)
    print(B.y)
    print(A.__dict__)


# Generated at 2022-06-24 03:11:28.968746
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):

        @roclassproperty
        def prop(cls):
            print("prop getter")
            return 'prop'

    class B(A):
        pass

    a = A()
    b = B()

    result_a = a.prop;  print("result_a:", result_a)
    result_b = b.prop; print("result_b:", result_b)
    #result_c = A.prop; print("result_c:", result_c)
    result_d = B.prop; print("result_d:", result_d)

    assert result_a == result_b == result_d




# Generated at 2022-06-24 03:11:32.805316
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def set_tst_value(self, v):
            self.tst_value = v

        def get_tst_value(self):
            return self.tst_value

        tst_prop = setterproperty(set_tst_value, doc='test property')

    a1 = A()
    a1.tst_prop = 11
    assert a1.tst_value == 11, 'Unexpected value is assigned to the property'
    a1.tst_value = 12
    assert a1.get_tst_value() == 12, 'Unexpected value is returned by the getter'


# Generated at 2022-06-24 03:11:39.718170
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo'

    class Sub(Base):
        pass

    class Sub2(Base):
        @lazyperclassproperty
        def foo(cls):
            return 'foo2'

    assert Base.foo == "foo"
    assert Sub.foo == "foo"
    assert Sub2.foo == "foo2"

# Generated at 2022-06-24 03:11:49.656955
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from .test import UnitTest

    class TestObject(object):
        def __init__(self, value):
            self._value = value

        @lazyperclassproperty
        def lazy(cls):
            return cls._value

    class A(TestObject):
        _value = 10

    class B(TestObject):
        _value = 20

    class Test(UnitTest):
        def test_basic(self):
            a = A()
            b = B()
            self.assertEqual(A.lazy, 10)
            self.assertEqual(B.lazy, 20)
            self.assertEqual(a.lazy, 10)
            self.assertEqual(b.lazy, 20)

    Test().run()



# Generated at 2022-06-24 03:11:51.603680
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 'x'
    assert A.x == 'x'
    assert A.x == 'x'
    assert A.x == 'x'



# Generated at 2022-06-24 03:11:59.117026
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def b(cls):
            return 'A.b'
    class B(A):
        pass
    assert A.b == 'A.b'
    assert B.b == 'A.b'
    A.b = 'A.b2'
    assert A.b == 'A.b2'
    assert B.b == 'A.b'
    B.b = 'B.b'
    assert A.b == 'A.b2'
    assert B.b == 'B.b'


# Generated at 2022-06-24 03:12:09.466708
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Create a class hierarchy
    class A:
        pass

    class B(A):
        pass

    class C(A):
        def return_value(self):
            return 'class C'

    class D(B):
        def return_value(self):
            return 'class D'

    class E(C, D):
        pass

    class F(E):
        pass

    # Define the property and add it to the hierarchy
    @lazyperclassproperty
    def p(cls):
        try:
            return cls.return_value()
        except:
            return 'default (class %s)' % cls.__name__

    A.p = p
    B.p = p
    C.p = p
    D.p = p
    E.p = p
    F.p = p



# Generated at 2022-06-24 03:12:16.306155
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class O(object):
        @setterproperty
        def some_property(self, value):
            self.__dict__['some_property'] = value
    o = O()
    o.some_property = "value"
    assert o.__dict__['some_property'] == "value"

# Generated at 2022-06-24 03:12:19.249546
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo of A'
    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return 'foo of B'

    assert A.foo == 'foo of A'
    assert B.foo == 'foo of B'

    # To check that we are getting per-class results, create a new class that is a subclass of A
    class C(A):
        pass

    assert C.foo == 'foo of A'
    assert C().foo == 'foo of A'

# Generated at 2022-06-24 03:12:25.359738
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """
    class cls1:
        @setterproperty
        def prop1(self, val):
            print(val)
            self._val = val
            return self._val

        @setterproperty
        def prop2(self, val):
            self._val = val
            return self._val

    c1 = cls1()
    s1 = c1.prop1 = 'one'
    assert c1._val == 'one'
    assert str(s1) == "one"

    c1.prop2 = 2
    assert c1._val == 2


# Generated at 2022-06-24 03:12:29.994419
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class foo(object):
        def __init__(self, val):
            self.val = val

        @roclassproperty
        def foo(cls):
            return cls.__name__.lower()

    assert foo.foo == 'foo'
    assert foo(100).foo == 'foo'


# Generated at 2022-06-24 03:12:37.975371
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    def check_lazyperclassproperty():
        class A(object):
            @lazyperclassproperty
            def a(cls):
                return repr(cls)

        a = A()
        assert A.a == 'test_lazyperclassproperty.<locals>.A'
        assert a.a == 'test_lazyperclassproperty.<locals>.A'

        class B(A):
            pass

        b = B()
        assert B.a == 'test_lazyperclassproperty.<locals>.B'
        assert b.a == 'test_lazyperclassproperty.<locals>.B'

    check_lazyperclassproperty()



# Generated at 2022-06-24 03:12:46.016733
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class test_roclassproperty(object):
        a = roclassproperty(lambda cls: 'a')
        b = roclassproperty(lambda cls: 'b')
        c = staticmethod(lambda: 'c')

    assert test_roclassproperty.a == 'a'  # check that the lambda is called again
    assert test_roclassproperty.a == 'a'  # check that the lambda is not called again
    assert test_roclassproperty.b == 'b'  # check that the lambda is called again
    assert test_roclassproperty.c() == 'c'  # check that the staticmethod is called

# Generated at 2022-06-24 03:12:48.341067
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, value):
            self.val = value

        @setterproperty
        def val(self, value):
            self.val = value



# Generated at 2022-06-24 03:12:54.812105
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def lazy_foo(cls):
            return 'lazy_foo of {}'.format(cls.__name__)

    class B(A):
        pass

    assert A.lazy_foo == 'lazy_foo of A'
    assert B.lazy_foo == 'lazy_foo of B'



# Generated at 2022-06-24 03:12:59.090733
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    cache = []

    class A:
        @lazyclassproperty
        def a(cls):
            cache.append(cls)
            return 'A.a'

    class B(A):
        pass

    a = A()
    b = B()

    assert a.a == 'A.a'
    assert b.a == 'A.a'

    assert cache == [A]


# Generated at 2022-06-24 03:13:02.505778
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 1

    assert A.foo == 1
    assert A.foo == 1, "Lazy class property should cache it's value"

    class B(A):
        pass

    assert B.foo == 1, "Derived classes should use the same value"



# Generated at 2022-06-24 03:13:03.596793
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    return True


# Generated at 2022-06-24 03:13:10.008849
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # usage:
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return 42
    # end of usage

    class B(A):
        pass

    aa = A()
    bb = B()
    aa.prop += 1
    assert bb.prop == 42, repr(bb.prop)
    assert A.prop == 43, repr(A.prop)



# Generated at 2022-06-24 03:13:16.914265
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass:
        __version__ = '0.0.01'
        _version = roclassproperty(lambda _x: _x.__version__)

    assert TestClass._version == '0.0.01'
    try:
        TestClass._version = '0.0.02'
    except Exception as e:
        assert type(e) == AttributeError


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:13:21.521605
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self.x = None

        @setterproperty
        def xproperty(self, value):
            self.x = value

    c = C()
    c.xproperty = 42
    assert c.x == 42

# Generated at 2022-06-24 03:13:28.259045
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:34.304387
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop1(cls):
            return 'prop1'

    class B(A):
        pass

    assert A.prop1 == 'prop1'
    assert B.prop1 == 'prop1'
    assert A.prop1 is not B.prop1
    assert isinstance(A.prop1, str)
    assert isinstance(B.prop1, str)


# Generated at 2022-06-24 03:13:38.137580
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def my_property(self):
            return self

    class Bar(Foo):
        pass

    assert Foo().my_property.__class__ == Foo
    assert Bar().my_property.__class__ == Bar



# Generated at 2022-06-24 03:13:44.187409
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X:
        @setterproperty
        def a(x, value):
            x.___r = value
        @setterproperty
        @lazyclassproperty
        def b(x):
            return None

    x = X()
    x.a = 1
    if x.___r != 1: print('failed')
    x.b = 2
    if x.b != 2: print('failed')


# Generated at 2022-06-24 03:13:49.149566
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo:
        def __init__(self, val):
            self.value = val

        @setterproperty
        def value(self, value):
            if value >= 0:
                self._value = value
            else:
                raise ValueError("Value must be >= 0")

    foo = Foo(10)
    foo.value = 20
    print(foo.value)  # -> 20

    foo.value = -1  # raises ValueError, because value of instance foo is < 0

