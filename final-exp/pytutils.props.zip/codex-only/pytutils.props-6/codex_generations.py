

# Generated at 2022-06-24 03:03:50.931500
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'bar of {}'.format(cls.__name__)

    assert Foo.bar == 'bar of Foo'



# Generated at 2022-06-24 03:03:56.621307
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):

        @roclassproperty
        def prop(cls):
            return 123

    t = TestClass()
    assert t.prop == 123

# Generated at 2022-06-24 03:04:03.011990
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A():
        @roclassproperty
        def x(cls):
            return 'x'

    class B(A):
        pass

    assert A.x == 'x'
    assert B.x == 'x'
    try:
        A.x = 'X'
    except AttributeError:
        pass
    else:
        assert False

    try:
        B.x = 'X'
    except AttributeError:
        pass
    else:
        assert False


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:04:09.744793
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    Unit test for constructor of class setterproperty
    """
    class Foo(object):
        def __init__(self, x):
            self._x = x

        @property
        def x(self):
            return self._x

        @x.setter
        def x(self, value):
            self._x = value

    f = Foo(1)
    f.x = 2
    assert f.x == 2



# Generated at 2022-06-24 03:04:12.229880
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def f(cls):
            return 1
    assert A.f == A.f == 1
    class B(A):
        pass
    assert B.f == B.f == 1



# Generated at 2022-06-24 03:04:17.767114
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return 'hello'

    assert Foo.foo == 'hello'
    foo = Foo()
    assert foo.foo == 'hello'



# Generated at 2022-06-24 03:04:22.282050
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo():pass
    @setterproperty
    def foo(self, value):
        self.value = value*10
    a, b = Foo(), Foo()
    a.foo, b.foo = 1, 2
    assert a.value == 10 and b.value == 20


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:04:24.022838
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class C(object):
        @lazyperclassproperty
        def foo(cls):
            return 42

    class D(C):
        pass

    assert C.foo == 42
    assert D.foo == 42
    assert C.foo is not D.foo


# Generated at 2022-06-24 03:04:27.558383
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class X:
        @roclassproperty
        def y(cls):
            return(cls.__name__)

    assert X.y == 'X'



# Generated at 2022-06-24 03:04:36.080130
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class SomeClass(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return "<%s: %s>" % (self.__class__.__name__, self.value)

        @lazyperclassproperty
        def some_property(cls):
            return SomeClass(cls.__name__)

    class SomeSubclass(SomeClass):
        pass

    # Test

    assert SomeClass.__name__ == SomeClass.some_property.value
    assert SomeSubclass.__name__ == SomeSubclass.some_property.value

    # Test cached values
    assert SomeClass.some_property is SomeClass.some_property

    # Test that the cached value is different for different classes
    assert SomeClass.some_property is not SomeSubclass.some_

# Generated at 2022-06-24 03:04:43.301784
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class roclasspropertyTest(object):
        @roclassproperty
        def foo(cls):
            return cls

        @setterproperty
        def set_foo(self, x):
            raise NotImplementedError()

    assert roclasspropertyTest.foo == roclasspropertyTest

    t = roclasspropertyTest()
    try:
        t.foo = 3
    except NotImplementedError:
        pass
    else:
        assert False, "wrong behavior"



# Generated at 2022-06-24 03:04:50.166119
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def _regex(cls):
            return re.compile(r"^([A-Za-z]*)$")

    class Sub1(Base):
        pass

    class Sub2(Base):
        pass

    assert(Base._regex is Base._regex)
    assert(Sub1._regex is Sub1._regex)
    assert(Sub2._regex is Sub2._regex)
    assert(Base._regex is not Sub1._regex)
    assert(Base._regex is not Sub2._regex)
    assert(Sub1._regex is not Sub2._regex)

# Generated at 2022-06-24 03:04:59.797406
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Test(object):
        @lazyclassproperty
        def thing(cls):
            return 'value'

    assert Test.thing == 'value'
    assert Test.__dict__['_lazy_thing'] == 'value'

    class Sub(Test):
        pass

    assert Sub.thing == 'value'
    assert Sub.__dict__['_lazy_thing'] == 'value'
    assert Test.__dict__['_lazy_thing'] == 'value'
    assert Sub.__dict__.get('_lazy_thing', None) is None

    Test.thing = 'modified'
    assert Test.thing == 'modified'
    assert Sub.thing == 'modified'
    assert Test.__dict__['_lazy_thing'] == 'modified'

# Generated at 2022-06-24 03:05:05.938675
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.my_list = []

        @setterproperty
        def my_list(self, value):
            self.my_list = value

    class Foo2(Foo):
        pass

    f = Foo()
    f.my_list = [1, 2]
    assert f.my_list == [1, 2]

    f2 = Foo2()
    f2.my_list = [3, 4]
    assert f2.my_list == [3, 4]
    assert f.my_list == [1, 2]

# Generated at 2022-06-24 03:05:09.790444
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        @setterproperty
        def value(self, val):
            self.val = val
            return self.val

    t = Test()
    t.value = 2
    assert t.value == 2
    assert t.__dict__["val"] == 2


# Generated at 2022-06-24 03:05:18.733551
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test with no arguments
    no_args = roclassproperty(lambda: None)

    class c():
        prop = no_args

    assert c.prop == no_args
    assert c().prop == no_args

    # Test with one argument
    def one_arg(x):
        return x

    no_args = roclassproperty(one_arg)

    class c():
        prop = no_args

    assert c.prop == no_args
    assert c().prop == no_args

    # Test with two arguments
    def two_args(x, y):
        return x, y

    no_args = roclassproperty(two_args)

    class c():
        prop = no_args

    assert c.prop == no_args
    assert c().prop == no_args


# Generated at 2022-06-24 03:05:21.069852
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def msg(cls):
            return 'Hello world'

    assert Foo.msg == 'Hello world'
    assert Foo().msg == 'Hello world'



# Generated at 2022-06-24 03:05:26.503294
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo1:
        def getx(self):
            return self._x
        def setx(self, value):
            self._x = value
        x = property(getx,setx,"I'm the 'x' property.")

        @setterproperty
        def gety(self):
            return self._y
        @gety.setter
        def sety(self, value):
            self._y = value
        y = property(gety,sety,"I'm the 'y' property.")

    f = Foo1()
    f.x = 5
    assert f.x == 5
    f.y = 10
    assert f.y == 10



# Generated at 2022-06-24 03:05:29.061597
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self):
            self._foo = None

        @setterproperty
        def foo(self, value):
            self._foo = value

    foo = Foo()
    foo.foo = 1
    assert foo._foo == 1



# Generated at 2022-06-24 03:05:32.251662
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        __metaclass__ = StaticTypeCheckingMeta
        @roclassproperty
        def get_a(cls):
            return  cls + 10

    assert TestClass.get_a == 10


# Generated at 2022-06-24 03:05:40.622874
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    '''
    Test method __get__ of class roclassproperty
    '''
    global method_name
    method_name = "roclassproperty.__get__"
    global input_list
    input_list = []
    def fn(cls):
        return "Hello, world"

    ro_class_property = roclassproperty(fn)

    if ro_class_property.__get__(None, None) == "Hello, world":
        return True
    else:
        return False



# Generated at 2022-06-24 03:05:43.102238
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        _x = 0

        @setterproperty
        def x(self, value):
            self.x = value

    o = Foo()
    o.x = 1
    assert o._x == 1


# Generated at 2022-06-24 03:05:50.378419
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self, val=None):
            self.x = val

        @setterproperty
        def x(self, val):
            if val < 10:
                return
            self.__x = val

    foo = Foo(10)
    assert foo.x == 10
    foo.x = 11
    assert foo.x == 11
    foo.x = 9
    assert foo.x == 11



# Generated at 2022-06-24 03:05:53.587483
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C():
        @roclassproperty
        def x():
            return 'xyz'

    assert C.x == 'xyz'
    assert C().x == 'xyz'
    c = C()
    C.x = 'abc'
    assert c.x == 'xyz'  # No change


# Generated at 2022-06-24 03:05:59.019891
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def PLAIN(cls):
            return 42
    ro = Foo.PLAIN
    try:
        Foo.PLAIN = 24
        assert False, "AttributeError should be raised"
    except AttributeError:
        pass
    assert ro == 42, "incorrect value"


# Generated at 2022-06-24 03:06:05.177663
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A():
        @lazyperclassproperty
        def a(cls):
            return 1

    class B(A):
        pass

    class C(B):
        @lazyperclassproperty
        def a(cls):
            return 3

    assert A.a == 1
    assert B.a == 1
    assert C.a == 3



# Generated at 2022-06-24 03:06:13.627950
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self, x): self.x = x
        @setterproperty
        def attr(self, value):
            self.x = value
        @classmethod
        @setterproperty
        def attr_class(cls, value):
            cls.x = value

    assert not hasattr(Foo, 'attr')
    with pytest.raises(AttributeError):
        Foo.attr = None

    a = Foo(1)
    assert not hasattr(a, 'attr')
    with pytest.raises(AttributeError):
        a.attr = None

    print(Foo.attr_class.__doc__)
    assert not hasattr(Foo, 'attr_class')
    with pytest.raises(AttributeError):
        Foo.attr_class = None

   

# Generated at 2022-06-24 03:06:22.461047
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        def __init__(self, a=0, b=0, c=0):
            self.a = a
            self.b = b
            self.c = c

        @setterproperty
        def a(self, x):
            self._a = x

        @property
        def a(self):
            return self._a

        @a.setter
        def a(self, x):
            self._a = x

    t = Test(1, 2, 3)
    t.a(10)

    assert t.a == 10
    assert t.b == 2
    assert t.c == 3

# Generated at 2022-06-24 03:06:26.346140
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ObjectA(object):
        @lazyperclassproperty
        def fn(cls):
            return 'a'

    class ObjectB(ObjectA):
        @lazyperclassproperty
        def fn(cls):
            return 'b'

    class ObjectC(object):
        @lazyperclassproperty
        def fn(cls):
            return 'c'

    class ObjectD(ObjectB):
        @lazyperclassproperty
        def fn(cls):
            return 'd'

    assert ObjectA.fn == 'a'
    assert ObjectB.fn == 'b'
    assert ObjectC.fn == 'c'
    assert ObjectD.fn == 'd'

# Generated at 2022-06-24 03:06:31.349761
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SetterPropertyClass(object):
        @setterproperty
        def test(self, value):
            self.value = value

    obj = SetterPropertyClass()
    obj.test = 1
    assert ("value" in obj.__dict__) and (obj.value == 1)


# Generated at 2022-06-24 03:06:35.375525
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def value(cls):
            return 'value of A'

    class B(A):
        pass

    assert A.value == 'value of A'
    assert B.value == 'value of A'


# Generated at 2022-06-24 03:06:39.695849
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class C(object):
        @roclassproperty
        def prop(cls):
            return 'value'

    assert C.prop == 'value'
    assert type(C.prop) == str
    assert C().prop == 'value'
    assert type(C().prop) == str

# Generated at 2022-06-24 03:06:43.315510
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def _set_x(self, x):
            self._x = x

        x = setterproperty(_set_x)

    c = C()
    assert not hasattr(c, '_x')
    c.x = 42
    assert c._x == 42
    assert c.x == 42



# Generated at 2022-06-24 03:06:47.055818
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        f = roclassproperty(lambda cls: "I am %s" % cls.__name__)

    assert TestClass.f == "I am TestClass"
    assert TestClass().f == "I am TestClass"



# Generated at 2022-06-24 03:06:50.956603
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SomeClass(object):
        @setterproperty
        def a(self, val):
            self._a = val
    a = SomeClass()
    a.a = 'someval'
    assert a._a is 'someval'

# Generated at 2022-06-24 03:07:00.291116
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def a(cls):
            print('get a')
            return 1
        @property
        def b(self):
            print('get b')
            return 1

    print(A.a, A.a)

    a = A()
    print(a.a, a.a, a.a)
    print(a.b, a.b)

    class B(A):
        pass

    print(B.a, B.a, B.a)
    print(B.b, B.b)

    b = B()
    print(b.a, b.a, b.a)
    print(b.b, b.b)


if __name__ == '__main__':
    test_lazyclassproperty()

# Generated at 2022-06-24 03:07:08.647399
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        class _C(object):
            pass

        @setterproperty
        def c(self, value):
            self._c = value
            return self._c

        @property
        def d(self):
            return self._c

    a = A()
    assert a.c is None

    # Make sure we can set it and get it
    a.c = 'a'
    assert a.c == 'a'
    assert a.d == 'a'

    # Make sure we can change it
    a.c = 'b'
    assert a.c == 'b'
    assert a.d == 'b'

    # Use constructor
    a.c = A._C()
    assert isinstance(a.c, A._C)
    assert isinstance(a.d, A._C)

# Generated at 2022-06-24 03:07:13.530383
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):

        def __init__(self, value):
            self.x = value

        @roclassproperty
        def clsp(cls):
            return cls.__name__

    class B(A):
        pass

    a = A(10)

# Generated at 2022-06-24 03:07:18.520822
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    from uuid import uuid4

    class Foo():
        def bar(self):
            """
            Return an instance specific UUID4.
            """
            return uuid4()

    class Bar(Foo):
            pass

    assert Foo().bar != Bar().bar
    assert Foo().bar != Foo().bar
    assert Bar().bar != Bar().bar

    # Lazy version
    class LazyFoo():
        @lazyperclassproperty
        def bar(cls):
            return uuid4()

    class LazyBar(LazyFoo):
        pass

    assert LazyFoo().bar != LazyBar().bar
    assert LazyFoo().bar != LazyFoo().bar
    assert LazyBar().bar != LazyBar().bar

# Generated at 2022-06-24 03:07:22.373991
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class foo(object):
        # classproperty (roclassproperty) with func
        @roclassproperty
        def roclassfunc(cls):
            return
        # classproperty (roclassproperty) with lambda
        roclasslambda = roclassproperty(lambda cls: None)
    assert foo.roclassfunc is None
    assert foo.roclasslambda is None


# Generated at 2022-06-24 03:07:28.290463
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def CProperty(cls):
            return "CProperty"

        @roclassproperty
        def CPropertyReadOnly(cls):
            return "CPropertyReadOnly"
        CPropertyReadOnly = property(CPropertyReadOnly)

    assert C.CProperty == "CProperty"
    assert C.CPropertyReadOnly == "CPropertyReadOnly"
    with pytest.raises(AttributeError):
        C.CProperty = "Dummy"


# Generated at 2022-06-24 03:07:34.695344
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass1(object):
        @roclassproperty
        def foo(cls):
            return "class"

    class TestClass2(TestClass1):
        @property
        def foo(self):
            return "instance"

    class TestClass3(object):
        foo = roclassproperty(lambda cls: "class")

    class TestClass4(TestClass3):
        foo = property(lambda self: "instance")

    assert TestClass1.foo == "class"
    assert TestClass2.foo == "class"
    assert TestClass3.foo == "class"
    assert TestClass4.foo == "class"

    assert TestClass1().foo == "instance"
    assert TestClass2().foo == "instance"
    assert TestClass3().foo == "instance"
    assert TestClass4().foo == "instance"

# Generated at 2022-06-24 03:07:38.570539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A():
        @lazyclassproperty
        def prop(cls):
            return -1
    class B(A):
        pass

    assert A.prop == -1
    assert B.prop == -1
    assert A.prop == -1
    assert B.prop == -1



# Generated at 2022-06-24 03:07:42.894617
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
        class C(object):
            @roclassproperty
            def f(cls):
                return 'roclassproperty'

        c = C()
        assert c.f == 'roclassproperty'



# Generated at 2022-06-24 03:07:49.296536
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            print('called class method')
            return 'some value'

    class FooChild(Foo):
        pass

    assert Foo.bar == 'some value'
    assert Foo.bar == 'some value'
    assert FooChild.bar == 'some value'
    assert FooChild.bar == 'some value'

    assert Foo.bar is not FooChild.bar



# Generated at 2022-06-24 03:08:00.557180
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def static_fn(cls):
            return "static_fn_%s" % cls.__name__
        static_fn = lazyperclassproperty(static_fn)

    class SubA(Base):
        pass

    class SubB(Base):
        def static_fn(cls):
            return "static_fn_%s" % cls.__name__
        static_fn = lazyperclassproperty(static_fn)

    assert Base.static_fn == "static_fn_Base"
    assert SubA.static_fn == "static_fn_Base"
    assert SubB.static_fn == "static_fn_SubB"

# Generated at 2022-06-24 03:08:09.602868
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    Unit test for constructor of class setterproperty
    """
    class Person(object):
        def __init__(self, name=None, age=None):
            self.name = name
            self.age = age

    def set_name(self, value):
        print("In set_name")
        self.name = value

    def set_age(self, value):
        print("In set_age")
        self.age = value

    set_property_name = setterproperty(set_name)
    set_property_age = setterproperty(set_age)

    p = Person()
    p.name = "Test Name"
    p.age = 12

    assert p.name == "Test Name"
    assert p.age == 12

    p.name = "New Test Name"
    assert p.name

# Generated at 2022-06-24 03:08:13.131883
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 'bar'

    class B(A):
        pass

    a = A()
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert a.foo == 'bar'

    del A.foo
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert a.foo == 'bar'

    del B.foo
    assert A.foo == 'bar'
    assert B.foo == 'bar'
    assert a.foo == 'bar'



# Generated at 2022-06-24 03:08:15.541825
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def prop(cls):
            return "B"

    assert A.prop == 'A'
    assert B.prop == 'B'

# Generated at 2022-06-24 03:08:24.155764
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        _x = 5

        @roclassproperty
        def x(cls):
            return cls._x

        @x.setter
        def x(cls, value):
            cls._x = value

        @x.deleter
        def x(cls):
            del cls._x

    assert A.x == 5
    a = A()
    assert a.x == 5
    a.x = 9
    assert a.x == 9
    A.x = 8
    assert A.x == 8
    assert a.x == 9
    # del A.x # AttributeError: can't delete attribute

# Generated at 2022-06-24 03:08:30.839298
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def dummy(cls): return cls.__name__

    class C1(Base): pass
    class C2(Base): pass

    assert Base.dummy == "Base"
    assert C1.dummy == "C1"
    assert C2.dummy == "C2"



# Generated at 2022-06-24 03:08:37.220423
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class A(object):
        def __init__(self, foo, bar):
            self.foo = foo
            self.bar = bar

        @setterproperty
        def foo(self, v):
            self._foo = v
            self.bar = v * 2

    a = A(1, 2)
    assert a.foo == 1
    assert a.bar == 2

    a.foo = 10
    assert a.foo == 10
    assert a.bar == 20



# Generated at 2022-06-24 03:08:40.197679
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'class property value'

    assert Foo.bar == 'class property value'

# Generated at 2022-06-24 03:08:42.802329
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def __init__(self):
            self.x = 42

        @roclassproperty
        def y(cls):
            return cls.x

    c = C()
    assert c.y == 42

# Generated at 2022-06-24 03:08:45.681970
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._value = 0

        @setterproperty
        def value(self, v):
            self._value = v

    a = A()
    assert a._value == 0
    a.value = 1
    assert a._value == 1


# Generated at 2022-06-24 03:08:51.987165
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        def __init__(self):
            self.a = 0

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return cls()

    a1 = A()
    b1 = B()
    a1.a = 1
    b1.a = 2

# Generated at 2022-06-24 03:08:55.345920
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class classA(object):
        @lazyperclassproperty
        def property_a(cls):
            print("fetching property A")
            return 1

    class classB(classA):
        @lazyperclassproperty
        def property_b(cls):
            print("fetching property B")
            return 2

    a = classA()
    print(a.property_a)

    b = classB()
    print(b.property_a, b.property_b)



# Generated at 2022-06-24 03:08:58.911568
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self): self.x = 1
        @setterproperty
        def a(self, value): self.x = value

    a = A()
    assert a.x == 1
    a.a = 10
    assert a.x == 10
    assert a.a == 10



# Generated at 2022-06-24 03:09:01.862329
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def f(a):
        pass

    prop = setterproperty(f)
    assert prop.__set__(1, 2) == None
    assert prop.func(1, 2) == None

# Generated at 2022-06-24 03:09:07.020456
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def get_x(cls):
            return 'x'

        x = roclassproperty(get_x)

    assert A.x == 'x'


# Generated at 2022-06-24 03:09:12.324482
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def name(c):
            return c.__name__

    class A(Base):
        pass

    class B(Base):
        pass

    a = A()
    b = B()
    assert a.name == "A"
    assert b.name == "B"



# Generated at 2022-06-24 03:09:17.376296
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def foo(self, value):
            self.value = value

    obj = Foo()
    obj.foo = 'bar'
    assert obj.value == 'bar'
    """
    >>> obj = Foo()
    >>> obj.foo = 'bar'
    >>> obj.value
    'bar'
    """



# Generated at 2022-06-24 03:09:27.887424
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        x_list = []

        @lazyperclassproperty
        def x(cls):
            cls.x_list.append(cls.__name__)
            return cls.__name__

    class TestClassSubclass(TestClass):
        pass

    class TestClassSubclass2(TestClass):
        pass

    class TestClassSubclassSubclass(TestClassSubclass):
        pass

    assert TestClass.x_list == []
    assert TestClass.x == "TestClass"
    assert TestClass.x_list == ["TestClass"]
    assert TestClassSubclass.x_list == ["TestClass"]
    assert TestClassSubclass.x == "TestClassSubclass"
    assert TestClassSubclass.x_list == ["TestClass", "TestClassSubclass"]
    assert Test

# Generated at 2022-06-24 03:09:34.815028
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None
        def getx(self):
            return self._x
        def setx(self, value):
            self._x = value
        def delx(self):
            del self._x
        x = property(getx, setx, delx, "I'm the 'x' property.")
        x2 = setterproperty(setx)

    c = C()
    c.x = 1
    c.x2 = 2
    assert c.x == 1
    assert c.x2 == 2

# Generated at 2022-06-24 03:09:38.269509
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClass(object):
        def __init__(self, prop):
            self._prop = prop

        def _get_prop(self):
            return self._prop

        prop = roclassproperty(_get_prop)

    assert DummyClass.prop == 10
    assert DummyClass(20).prop == 10

# Generated at 2022-06-24 03:09:42.989331
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        @lazyperclassproperty
        def foo(cls):
            return "A"

    class B(A):
        @lazyperclassproperty
        def foo(cls):
            return "B"

    assert A.foo == "A"
    assert B.foo == "B"

# Generated at 2022-06-24 03:09:50.824570
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    # Example class
    class cls:
        def _lazy_prop():
            return sum([i for i in range(1,10)])

        lazy_prop = lazyclassproperty(_lazy_prop)

    # Example child class
    class cls_child(cls):
        pass

    # Checks
    assert cls.lazy_prop == cls_child.lazy_prop == 45
    assert "lazy_prop" in cls.__dict__
    assert "lazy_prop" not in cls_child.__dict__
    assert "lazy_prop" not in cls.__dict__["__dict__"]
    assert "lazy_prop" not in cls_child.__dict__["__dict__"]
    assert "lazy_prop" in cls.__dict__["__class__"]


# Generated at 2022-06-24 03:10:01.280391
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self):
            self.foo = 'foo'
            self.__bar = 'bar'

        @roclassproperty
        def roclassprop_foo(cls):
            return cls.foo

        @roclassproperty
        def roclassprop_getbar(cls):
            return cls.__bar

        def get_bar(cls):
            return cls.__bar

        @setterproperty
        def roclassprop_setbar(cls):
            cls.__bar = 'new_bar'
            return cls.__bar

    assert TestClass.roclassprop_foo == TestClass().foo
    # TestClass.roclassprop_foo = 'bar'
    # assert TestClass.roclassprop_foo == TestClass().foo


# Generated at 2022-06-24 03:10:04.233139
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 42

    assert A.x == 42
    assert A().x == 42


# Generated at 2022-06-24 03:10:09.972128
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def x(self, v):
            self.foo = v

    c = C()
    c.x = 12
    assert c.foo == 12

# Generated at 2022-06-24 03:10:17.652189
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def FOO(self):
            return 'FOO_VALUE'

    class Bar(Foo):
        @lazyperclassproperty
        def BAR(self):
            return 'BAR_VALUE'

    assert Foo.FOO == 'FOO_VALUE'
    assert Foo().FOO == 'FOO_VALUE'
    assert Bar.FOO == 'FOO_VALUE'

    assert Bar.BAR == 'BAR_VALUE'
    assert Bar().BAR == 'BAR_VALUE'



# Generated at 2022-06-24 03:10:21.064861
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def __init__(self, val):
            self.val = val
        @roclassproperty
        def prop(cls):
            return 42
        def method(self):
            return self.val

    assert A.prop == 42
    a = A(33)
    assert a.prop == 42
    assert a.method() == 33


# Generated at 2022-06-24 03:10:28.275883
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test():
        @setterproperty
        def prop_1(self, value):
            # Assign 'prop_1' with the value passed
            self.prop_1 = value

        @setterproperty
        def prop_2(self, value):
            # Call another method where the value passed
            # is assigned to another attribute
            self.prop_3(value)

        def prop_3(self, value):
            self.prop_2 = value
    test_1 = Test()
    test_1.prop_1 = 1
    assert test_1.prop_1 == 1
    test_1.prop_2 = 2
    assert test_1.prop_2 == 2


# Generated at 2022-06-24 03:10:36.943236
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test:
        def __init__(self):
            self.prop = 1
        @roclassproperty
        def prop(cls):
            return cls.__name__
        @roclassproperty
        def prop2(cls):
            if not hasattr(cls, '_prop_'):
                cls._prop_ = cls.__name__
            return cls._prop_

    t = Test()
    assert t.prop == 'Test'
    assert t.prop2 == 'Test'
    assert t.prop == 'Test'
    assert t.prop2 == 'Test'
    assert Test.prop == 'Test'
    assert Test.prop2 == 'Test'
    assert Test.prop == 'Test'
    assert Test.prop2 == 'Test'
    t.prop = 2
    assert t.prop

# Generated at 2022-06-24 03:10:43.230895
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class BaseClass(object):
        @lazyperclassproperty
        def test_lazyperclassproperty(cls):
            return 'test'

    class Inheritor(BaseClass):
        pass

    class InheritorTwo(Inheritor):
        pass

    assert BaseClass.test_lazyperclassproperty == Inheritor.test_lazyperclassproperty == 'test'
    assert BaseClass.test_lazyperclassproperty != InheritorTwo.test_lazyperclassproperty == 'test'
    assert not hasattr(Inheritor, '_Inheritor_lazy_test_lazyperclassproperty')
    assert not hasattr(InheritorTwo, '_Inheritor_lazy_test_lazyperclassproperty')

# Generated at 2022-06-24 03:10:56.843917
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self, val):
            self._x = val + 2

    obj = C()
    assert obj._x is None
    obj.x = 3
    assert obj._x == 5



# Generated at 2022-06-24 03:11:00.141591
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:11:08.448943
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Bin(object):
        def __init__(self, name=''):
            self.name = name

        @setterproperty
        def name(self, name):
            if not isinstance(name, str):
                raise TypeError('Expected type: str!')
            self.name = name

    a = Bin('a')
    assert a.name == 'a', 'Incorrect property value!'
    a.name = 'b'
    assert a.name == 'b', 'Incorrect property value!'
    try:
        a.name = None
    except TypeError:
        pass
    else:
        raise AssertionError('TypeError excepted!')



# Generated at 2022-06-24 03:11:17.021293
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test1(object):
        def __init__(self):
            self.value = 1
        @lazyperclassproperty
        def lazy_test(cls):
            print("Assigning value in Test1")
            return Test2(self)
    class Test2(object):
        def __init__(self, other):
            self.value = other.value
    t1 = Test1()
    assert type(t1.lazy_test) == Test2
    assert t1.lazy_test.value == 1
    t1.value = 2
    assert t1.lazy_test.value == 1
    assert Test2(t1).value == 2



# Generated at 2022-06-24 03:11:24.544980
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Tests method __get__ of class roclassproperty.
    """

    class MyClass(object):
        def __init__(self, myattr):
            self.myattr = myattr

    class Cls(object):
        @roclassproperty
        def myclass(self):
            return MyClass(myattr=5)

    assert Cls.myclass.myattr == 5



# Generated at 2022-06-24 03:11:27.264537
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def property(self, value):
            self.foo = value
            return self.foo
    foo = Foo()
    foo.property = 1
    assert foo.foo == foo.property == 1


# Generated at 2022-06-24 03:11:33.932724
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(cls):
            return 1
    assert A.foo == 1

    class B(A):
        pass
    assert B.foo == 1

    class C(B):
        @lazyclassproperty
        def bar(cls):
            return 2
    assert C.bar == 2
    assert B.bar == 2



# Generated at 2022-06-24 03:11:37.356238
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 42

    assert C.x == 42


# Generated at 2022-06-24 03:11:43.874645
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty.
    """
    class A(object):
        @lazyperclassproperty
        def spam(cls):
            print('init spam()')
            return 'spam'

        @lazyperclassproperty
        def ham(cls):
            print('init ham()')
            return 'ham'

    class B(A):
        @lazyperclassproperty
        def ham(cls):
            print('init B.ham()')
            return 'B.ham'

    print(A.ham, B.ham)
    print(A.ham, B.ham)


# Generated at 2022-06-24 03:11:48.631189
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    @roclassproperty
    def foo(cls):
        return 'bar'

    class baz(object):
        foo = foo

    assert baz.foo == 'bar'
    assert baz().foo == 'bar'


# Generated at 2022-06-24 03:11:51.292005
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class class1(object):
        @setterproperty
        def property1(self, value):
            self._property1 = value * 2.0

    obj = class1()
    assert not hasattr(obj, "_property1")
    obj.property1 = 1.0
    assert obj._property1 == 2.0


# Generated at 2022-06-24 03:11:55.227369
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class FooBar:
        def __init__(self):
            self.x = 0

        @setterproperty
        def x(self, new_x):
            return 1

    assert FooBar().x == 1



# Generated at 2022-06-24 03:12:01.955427
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Foo(object):

        @lazyclassproperty
        def bar(cls):
            print("calculating bar")
            return "bar"

    assert 'bar' not in Foo.__dict__
    assert Foo.bar == "bar"
    assert Foo.bar == "bar"
    assert '_lazy_bar' in Foo.__dict__

    class Baz(Foo):
        pass

    assert "bar" not in Baz.__dict__
    assert Baz.bar == "bar"
    assert Baz.bar == "bar"
    assert "_lazy_bar" in Baz.__dict__

# Generated at 2022-06-24 03:12:09.037529
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):
        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

        @setterproperty
        def name(self, name):
            self.name = name


    foo = Foo("test")
    assert foo.get_name() == "test"
    foo.name = "test2"
    assert foo.get_name() == "test2"
    try:
        foo.name
        assert False, "Should have thrown AttributeError"
    except AttributeError:
        pass



# Generated at 2022-06-24 03:12:14.052455
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def _get_x(self):
            return 1
        def _set_x(self, value):
            self.__dict__["x"] = value
        x = setterproperty(_get_x, _set_x)
    c = C()
    assert c.x == 1
    c.x = 2
    assert c.x == 2
    assert c.__dict__["x"] == 2


# Generated at 2022-06-24 03:12:18.063851
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A:
        @lazyclassproperty
        def foo(cls):
            print("Computing foo")
            return 42

    class B(A):
        pass

    class C(A):
        @lazyclassproperty
        def foo(cls):
            print("Computing foo")
            return 43

    class D(B, C):
        pass

    print(A.foo, B.foo, C.foo, D.foo)



# Generated at 2022-06-24 03:12:21.449407
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self.a = 1

        @roclassproperty
        def get_a(cls):
            return cls.a

    t = Test()
    t.get_a = 2 #Should not change a value
    assert (t.get_a == 1) #Test that it is read only


# Unit Test for constructor of class setterproperty

# Generated at 2022-06-24 03:12:26.077997
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'

    class Foo2(Foo):
        pass

    assert Foo2.bar == 'baz'
    assert Foo.bar == 'baz'

    class Foo3(Foo):
        @lazyclassproperty
        def bar(cls):
            return 'newbaz'

    assert Foo3.bar == 'newbaz'
    assert Foo.bar == 'baz'



# Generated at 2022-06-24 03:12:29.785982
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    def x(cls):
        return 100
    assert roclassproperty(x).__get__(None,None) == 100
    assert classproperty(x).__get__(None,None) == 100


# Generated at 2022-06-24 03:12:35.866465
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    Base = type("Base", (), {})
    Derived = type("Derived", (Base,), {})

    def testf(cls): return cls.__name__

    Base.testf = lazyperclassproperty(testf)
    Derived.testf = lazyperclassproperty(testf)

    assert Base.testf == "_Base_lazy_testf"
    assert Derived.testf == "_Derived_lazy_testf"

# Generated at 2022-06-24 03:12:40.243314
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:43.365632
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:45.386207
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class Setter:

        def _set_foo(self, value):
            self._foo = value

        foo = setterproperty(_set_foo)

    s = Setter()
    s.foo = 27
    assert s._foo == 27



# Generated at 2022-06-24 03:12:47.797347
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def prop(self):
            return 'foo'

    class Derived(Base):
        pass

    assert Base().prop != Derived().prop



# Generated at 2022-06-24 03:12:54.000200
# Unit test for method __set__ of class setterproperty

# Generated at 2022-06-24 03:13:05.248949
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    if sys.version_info >= (2, 6):

        # Create class and initialize class property
        class C(object):
            x = roclassproperty(lambda c: c.y)

            def __init__(self):
                self.y = "class y"

        # Initialize a new instance of the class and read the property
        # The value 'class y' should be returned
        o = C()
        result = o.x
        expected = "class y"

        # Check the result
        if result != expected: raise Exception("Test failed. Expected '" + str(expected) + "' but got '" + str(result) + "'")


# Generated at 2022-06-24 03:13:10.073594
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.a = 0

        @setterproperty
        def b(self, value):
            self.a = value

    t = Test()
    t.b = 5
    assert t.a == 5



# Generated at 2022-06-24 03:13:17.858091
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        def __init__(self):
            self.value = 0

        @setterproperty
        def value(self, value):
            if value < 0:
                self.__value = 0
            elif value > 10:
                self.__value = 10
            else:
                self.__value = value

        @value.getter
        def value(self):
            return self.__value

    mc = MyClass()
    assert mc.value == 0
    mc.value = 3
    assert mc.value == 3
    mc.value = 15
    assert mc.value == 10



# Generated at 2022-06-24 03:13:27.075213
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def value(cls):
            return cls.__name__

    class Child(Base):
        pass

    instance = Base()
    assert instance.value == 'Base'
    instance = Child()
    assert instance.value == 'Child'

    class ChildTwo(Base):
        @lazyperclassproperty
        def value(cls):
            return 'ChildTwo'

    instance = ChildTwo()
    assert instance.value == 'ChildTwo'
    instance = Base()
    assert instance.value == 'Base'



# Generated at 2022-06-24 03:13:32.744197
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def i(cls):
            return cls.__name__
    class B(A):
        pass
    assert A.i == 'A'
    assert A().i == 'A'
    assert B.i == 'B'
    assert B().i == 'B'

# Generated at 2022-06-24 03:13:38.853282
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Dummy(object):
        x = 0

    def inc(self, value):
        self.x += value

    d = Dummy()
    sp = setterproperty(inc)
    sp.__set__(d, 1)
    assert d.x == 1
    sp.__set__(d, 1)
    assert d.x == 2



# Generated at 2022-06-24 03:13:47.806457
# Unit test for constructor of class roclassproperty

# Generated at 2022-06-24 03:13:52.664349
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def x(cls):
            return 2*cls.y

        y = 1

    assert C.x == 2
    assert C().x == 2

    try:
        C.x = 2
    except AttributeError as e:
        pass
    else:
        assert False, 'changing class roclassproperty did not cause AttributeError'
