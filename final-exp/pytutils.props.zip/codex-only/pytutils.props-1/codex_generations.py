

# Generated at 2022-06-24 03:03:53.778372
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class A(object):
        @lazyclassproperty
        def func(cls):
            print("I am created")
            return "first"

    class B(A):
        pass

    a = A()
    b = B()
    assert(A.func == "first")
    assert(B.func == "first")
    assert(a.func == "first")
    assert(b.func == "first")

# Generated at 2022-06-24 03:03:57.396807
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert A.foo == 'foo'
    A.foo = 'bar'  # Raises AttributeError


# Generated at 2022-06-24 03:04:01.854732
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X:
        def __init__(self):
            self.att = 0

        @setterproperty
        def inc_att(self, value):
            self.att += value

    x = X()
    assert x.att == 0
    x.inc_att = 1
    assert x.att == 1
    x.inc_att = 10
    assert x.att == 11

# Generated at 2022-06-24 03:04:04.042612
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def name(cls):
            return cls.__name__
    assert A.name == 'A'


# Generated at 2022-06-24 03:04:13.654884
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    from . import LazyProperty

    # A mock class
    class X(object):
        _x = 'x'
        _y = 'y'

        def __init__(self, x):
            self.__x = x

        @LazyProperty
        def x(self):
            return self.__x

        @roclassproperty
        def y(cls):
            return cls._y

    # Instantiate the class
    x = X('x')

    # Check instance property
    assert x.x == 'x'

    # Check read-only class property
    assert x.y == 'y'

    # Check wrong assignment to class property
    try:
        x.y = 'y'
    except AttributeError:
        pass
    except:
        assert False

    # Check wrong assignment to instance property

# Generated at 2022-06-24 03:04:17.266976
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def test(cls):
            return "hello world"
        
    assert Foo.test == "hello world"


# Generated at 2022-06-24 03:04:21.879628
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, x):
            self.__x = x

    a = A()
    a.x = 1
    assert a.__x == 1
    with pytest.raises(AttributeError):
        a.x



# Generated at 2022-06-24 03:04:25.462216
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass(object):
        def __init__(self):
            pass
        @roclassproperty
        def prop1(cls):
            return 'prop1_value'
    tc = TestClass()
    assert tc.prop1 == 'prop1_value'


# Generated at 2022-06-24 03:04:28.413525
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        def foo(cls):
            return 0

        bar = roclassproperty(foo)

    assert A.bar == 0



# Generated at 2022-06-24 03:04:35.424035
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('prop called')
            return 1

    class B(A):
        pass

    class C(A):
        @lazyperclassproperty
        def prop(cls):
            print('prop called')
            return 2


    assert A.prop == 1
    assert B.prop == 1
    assert C.prop == 2

    a = A()
    b = B()
    c = C()

    assert a.prop == 1
    assert b.prop == 1
    assert c.prop == 2



# Generated at 2022-06-24 03:04:42.884178
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Testclass:
        @lazyclassproperty
        def test1(cls):
            return "test1"
        @lazyclassproperty
        def test2(cls):
            return "test2"

    class Testclass2(Testclass):
        @lazyclassproperty
        def test2(cls):
            return "test2 of Testclass2"

    class Testclass3(Testclass2):
        pass

    assert Testclass.test1 == "test1"
    assert Testclass.test2 == "test2"
    assert Testclass2.test1 == "test1"
    assert Testclass2.test2 == "test2 of Testclass2"
    assert Testclass3.test1 == "test1"
    assert Testclass3.test2 == "test2 of Testclass2"



# Generated at 2022-06-24 03:04:47.324902
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Testing method __get__.
    """

    class cls(object):
        def __init__(self, val):
            self.val = val

        @roclassproperty
        def prop(cls):
            return cls.val

    a = cls(123)
    assert a.prop == 123



# Generated at 2022-06-24 03:04:58.562964
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Dummy:
        def __init__(self, **d):
            for k, v in d.items():
                setattr(self, k, v)

    def setter1(obj, value):
        print("Running setter1")
        obj.value = value

    def setter2(obj, value):
        print("Running setter2")
        obj.value = value

    dummy = Dummy(value=None)
    dummy.setter = setterproperty(setter1, 'value setter')
    dummy.setter = 1
    print(dummy.value)
    dummy.setter = setterproperty(setter2)
    dummy.setter = 2
    print(dummy.value)

#test_setterproperty()

# Generated at 2022-06-24 03:05:00.819961
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class T(object):
        def f(cls):
            return cls

        p = roclassproperty(f)

    assert T.p is T

# Generated at 2022-06-24 03:05:06.744690
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    from wbia.other import ibsfuncs
    from wbia.other import dtool
    ibsfuncs.register_prefs()
    dtool.set_pref('lazy_cache', True)
    # dtool.set_pref('lazy_cache', False)
    class_ = ibsfuncs.__class__
    assert hasattr(class_, '__lazy_annotmatch_cfgstr__')
    assert hasattr(class_, '__lazy_chip_cfgstr__')
    assert hasattr(class_, '__lazy_feat_cfgstr__')
    assert hasattr(class_, '__lazy_featweight_cfgstr__')
    assert hasattr(class_, '__lazy_smk_cfgstr__')

# Generated at 2022-06-24 03:05:11.118831
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self):
            self._var = None

        @setterproperty
        def var(self, value):
            self._var = value

    test = TestClass()
    assert test.var is None
    test.var = 'value'
    assert test.var == 'value'


# Generated at 2022-06-24 03:05:15.725291
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def bar(cls):
            return 'quux'

    assert Foo.bar == 'quux'
    # __get__ of roclassproperty returns a static method, so the following line raises an error
    # print(Foo().bar)  # raises AttributeError: 'function' object has no attribute 'bar'


# Generated at 2022-06-24 03:05:19.068852
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:05:22.824405
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo(object):
        _x_ = 0
        @setterproperty
        def x(self, value):
            self._x_ = value

    class bar(foo):
        pass

    f = foo()
    f.x = 12
    b = bar()
    b.x = 13
    assert f._x_ == 12
    assert b._x_ == 13

# Generated at 2022-06-24 03:05:28.044033
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test:
        def __init__(self, a):
            self.a = a

    @setterproperty
    def test_setter(inst, value):
        inst.a = value

    @setterproperty
    def test_setter_2(inst, value):
        inst.a = value

    obj = test(1)
    assert obj.a == 1
    obj.test_setter = 2
    assert obj.a == 2
    obj.test_setter_2 = 3
    assert obj.a == 3



# Generated at 2022-06-24 03:05:30.932029
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class foo(object):
        @roclassproperty
        def bar(cls):
            return 42
    assert foo.bar == 42

    c = foo()
    assert c.bar == 42

    try:
        c.bar = 3
    except AttributeError:
        pass
    else:
        assert False, 'AttributeError expected'



# Generated at 2022-06-24 03:05:34.919454
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass:
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            self._x = value - 1

        def get_x(self):
            return self._x

    my_instance = MyClass(4)
    my_instance.x = 2
    assert my_instance.get_x() is 1

# Generated at 2022-06-24 03:05:41.366250
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class c:
        x = roclassproperty(lambda self: self.prop)

        def __init__(self, prop):
            self.prop = prop
    assert c(1).x == 1, 'Unable to read property value'
    try:
        c(1).x = 3
    except AttributeError:
        pass
    else:
        assert False, 'Should not be able to write to property'


# Generated at 2022-06-24 03:05:49.320105
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestSetterProperty(object):

        def __init__(self):
            self.__x = None

        @setterproperty
        def x(self, x):
            if not isinstance(x, int):
                raise TypeError("'x' must be an integer")
            self.__x = x

        @property
        def x(self):
            return self.__x

    test = TestSetterProperty()
    test.x = 10
    assert test.x == 10
    with pytest.raises(Exception):
        test.x = 'string'



# Generated at 2022-06-24 03:05:59.023695
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Animal:
        def eat(self):
            return "Eat like an animal"

        @lazyperclassproperty
        def digest(cls):
            return "I can digest like a " + cls.__name__

    class Person(Animal):
        def eat(self):
            return "Eat like a person"

    class Gecko(Animal):
        def eat(self):
            return "Eat like a gecko"

    assert hasattr(Animal, "_Animal__lazy_digest")
    assert hasattr(Person, "_Person__lazy_digest")
    assert hasattr(Gecko, "_Gecko__lazy_digest")

    assert Animal.digest == "I can digest like a Animal"
    assert Person.digest == "I can digest like a Person"

# Generated at 2022-06-24 03:06:07.192505
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            return 'This should just be printed once'

    class B(A):
        pass

    # A() and B() should be different objects
    assert A().__class__ != B().__class__, 'Class A() and class B() should different objects'

    # But their test attributes should be the same
    assert A().test == B().test, 'Class A().test and class B().test should be equal'

    # A() and B() should be different objects
    assert A().__class__ != B().__class__, 'Class A() and class B() should different objects'

    # But their test attributes should be the same
    assert A().test == B().test, 'Class A().test and class B().test should be equal'



# Generated at 2022-06-24 03:06:10.699062
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def foo(cls):
            return 'bar'

    assert A.foo == 'bar'
    assert A().foo == 'bar'

    try:
        A.foo = 'baz'
    except AttributeError:
        pass
    else:
        assert False, 'AttributeError not raised'

# Generated at 2022-06-24 03:06:20.224733
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class A(object):

        @roclassproperty
        def x(cls):
            return 'A'

    class B(A):
        pass

    class C(A):

        @roclassproperty
        def x(cls):
            return 'C'

    class D(B, C):
        pass

    class E(C, B):
        pass

    class F(D, E):
        pass


# Generated at 2022-06-24 03:06:29.301782
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        @roclassproperty
        def test(cls):
            return 'test'

    def test_roclassproperty_assertions():
        t = TestClass(1)
        assert t.test == 'test'
        assert isinstance(t.test, basestring)
        assert t.value == 1
        try:
            t.test = 'someValue'
        except:
            pass
        assert t.value == 1
        assert t.test == 'test'
    test_roclassproperty_assertions()



# Generated at 2022-06-24 03:06:32.533322
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class FooBar(object):
        @roclassproperty
        def foo_bar(cls):
            return 'foo_bar'

    assert FooBar.foo_bar == 'foo_bar'
    assert FooBar().foo_bar == 'foo_bar'



# Generated at 2022-06-24 03:06:39.828160
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def a(cls):
            print("Called only once: %s" % cls)
            return [1, 2, 3]

    a = A()
    assert a.a == [1, 2, 3]
    assert a.a == [1, 2, 3]
    assert a.a == [1, 2, 3]

    class B(A):
        pass

    b = B()
    assert b.a == [1, 2, 3]
    assert b.a == [1, 2, 3]
    assert b.a == [1, 2, 3]

# Generated at 2022-06-24 03:06:44.923279
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            if not (0 <= value <= 1):
                raise ValueError("value should be between 0 and 1.")
            self._x = value
    foo = Foo()
    foo.x = 0.5 # This is OK
    try:
        foo.x = 2  # This will raise an exception
    except Exception as e:
        print(e)

    try:
        foo.x = -1  # This will raise an exception
    except Exception as e:
        print(e)

# Generated at 2022-06-24 03:06:49.723576
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test:
        def __init__(self):
            self.targets = []

        @setterproperty
        def target(self, new_value):
            self.targets.append(new_value)

    t = Test()
    t.target = 1
    t.target = 2
    t.target = 3

    assert t.targets == [1, 2, 3]



# Generated at 2022-06-24 03:06:53.961816
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def __init__(self, val):
            self.val = val

        def __str__(self):
            return 'A:{}'.format(self.val)

        @classproperty
        def myclass(cls):
            return cls

    class B(A):
        pass

    a = A(1)
    b = B(2)

    assert a.myclass() is A
    assert b.myclass() is B



# Generated at 2022-06-24 03:06:59.737040
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test(object):
        def __init__(self):
            self.a = None

        @setterproperty
        def seta(self, val):
            self.a = val

    t = test()
    assert t.a is None, "a should be None"
    t.seta = 1
    assert t.a == 1, "a should be 1"



# Generated at 2022-06-24 03:07:02.816845
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return cls.__name__

    class Baz(Foo):
        pass

    class Qux(Foo):
        pass

    print(Foo.bar)
    print(Baz.bar)



# Generated at 2022-06-24 03:07:05.785278
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def roproperty(cls):
            return 'foo'

    assert C.roproperty == 'foo'
    with pytest.raises(AttributeError):
        C().roproperty



# Generated at 2022-06-24 03:07:13.289614
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        def __init__(self):
            self.data = 'Base'

        @property
        def prop(self):
            return self.data

    class A(Base):
        def __init__(self):
            Base.__init__(self)

        @lazyperclassproperty
        def _lazy_prop(cls):
            return 'A'

    class B(Base):
        def __init__(self):
            Base.__init__(self)

        @lazyperclassproperty
        def _lazy_prop(cls):
            return 'B'

    a = A()
    b = B()
    assert a.prop == 'A'
    assert b.prop == 'B'

    a.data = 'foo'
    assert a.prop == 'A'

    #

# Generated at 2022-06-24 03:07:17.612400
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def prop(cls):
            print("calculating...")
            return 42

    class B(A):
        pass

    print(A.prop)  # prints "calculating..."
    print(A.prop)  # doesn't print anything
    print(B.prop)  # prints "calculating..."
    print(B.prop)  # doesn't print anything



# Generated at 2022-06-24 03:07:24.496264
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """
    Check that roclassproperty(f) returns a property that returns f(owner) when called on owner.
    """
    # Define two classes
    def f(cls):
        return cls.__name__
    class A(object):
        attr = roclassproperty(f)
    class B(A):
        pass

    assert A.attr == 'A'
    assert B.attr == 'B'
    assert A().attr == 'A'
    assert B().attr == 'B'
    assert type(A.attr).__name__ == 'property'
    assert type(B.attr).__name__ == 'property'

# Generated at 2022-06-24 03:07:31.071341
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo(object):
        def __init__(self):
            self.__foo = None

        @setterproperty
        def set_foo(self, value):
            self.__foo = value

        @property
        def get_foo(self):
            return self.__foo

    f = foo()
    f.set_foo = 100
    assert f.get_foo == 100

    try:
        f.set_foo
    except Exception:
        pass
    else:
        assert False, "setterproperty failed for method __set__"


# Generated at 2022-06-24 03:07:37.962226
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def setter(self, value):
            self.value = value

    obj = TestClass(5)
    assert obj.value == 5
    obj.setter = 10
    assert obj.value == 10



# Generated at 2022-06-24 03:07:49.863591
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TEST:
       def __init__(self):
           self._lock_val = 1
           self._lock_val2 = 1

       @setterproperty
       def lock_val(self, value):
           self._lock_val = value

       @setterproperty
       def lock_val2(self, value):
           self._lock_val = value

    inst = TEST()
    assert inst.lock_val2 == 1

    try:
        inst.lock_val = "abc"
    except Exception:
        assert False, "Should not throw exception"

    try:
        inst.lock_val2 = "abc"
    except Exception:
        assert False, "Should not throw exception"

    try:
        inst.lock_val = 1
    except Exception:
        assert False, "Should not throw exception"


# Generated at 2022-06-24 03:07:56.277173
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def __init__(self, d):
            self.d = d

        @setterproperty
        def d(self, value):
            self._d = value

        @d.setter
        def d(self, value):
            self._d = value

    t = Test(10)
    t.d = 20
    assert t._d == 20
    t.d = 30
    assert t._d == 30

    t2 = Test(10)
    t2.d = 42
    assert t2._d == 42



# Generated at 2022-06-24 03:08:06.002061
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class Dummy:
        def __init__(self):
            self._x = "init"
            self._y = None
            self._z = None

        @setterproperty
        def x(self, value):
            self._x = value

        @setterproperty
        def y(self, value):
            self._y = value

        @setterproperty
        def z(self, value):
            self._z = value

    class UnitTest(unittest.TestCase):
        def test(self):
            dummy = Dummy()
            dummy.x = "hello"
            dummy.y = "world"
            dummy.z = "!"

            self.assertEqual("hello", dummy._x)
            self.assertEqual("world", dummy._y)

# Generated at 2022-06-24 03:08:10.213731
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    from types import MethodType
    class A(object):
        count = 0
        @lazyperclassproperty
        def f0(cls):
            A.count += 1
            return cls.count
        @lazyperclassproperty
        def f1(cls):
            A.count += 1
            return cls.count
    class B(A):
        @lazyperclassproperty
        def f0(cls):
            A.count += 1
            return cls.count
        @lazyperclassproperty
        def f1(cls):
            A.count += 1
            return cls.count
    class C(B):
        @lazyperclassproperty
        def f0(cls):
            A.count += 1
            return cls.count

# Generated at 2022-06-24 03:08:14.493684
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('evaluating cls.prop for %s' % cls.__name__)
            return 1

    class B(A):
        pass

    class C(A):
        pass

    class D(A):
        pass

    a = A()
    b = B()
    c = C()
    d = D()

    assert a.prop == b.prop == c.prop == d.prop == 1
    assert a.__class__.prop == b.__class__.prop == c.__class__.prop == d.__class__.prop == 1

    for c in (A, B, C, D):
        assert c.prop == 1



# Generated at 2022-06-24 03:08:23.789826
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    import unittest

    class Example(object):
        def __init__(self):
            self.value = "old value"

        @setterproperty
        def my_string(self, value: str):
            """A string that can only be set"""
            self.value = value

    def test_set_value():
        example = Example()
        example.my_string = "new value"
        assert example.value == "new value"

    def test_init_value():
        example = Example()
        assert example.value == "old value"

    def test_docstring():
        assert Example.my_string.__doc__ == "A string that can only be set"

    unittest.main()



# Generated at 2022-06-24 03:08:26.904500
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    s = setterproperty(lambda self, x: setattr(self, 'x', x))
    assert s.__set__(None, 3) is None


# Generated at 2022-06-24 03:08:34.500102
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class MyClass(object):
        @roclassproperty
        def myroprop(cls):
            return 1729

    assert MyClass.myroprop == 1729
    try:
        MyClass.myroprop = 'hello'
    except AttributeError:
        pass
    else:
        assert False, 'Expected AttributeError not raised'

    mc = MyClass()
    assert mc.myroprop == 1729
    try:
        mc.myroprop = 'hello'
    except AttributeError:
        pass
    else:
        assert False, 'Expected AttributeError not raised'


# Generated at 2022-06-24 03:08:42.675318
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Class definition
    from random import random
    class X():
        def __init__(self,xval):
            self.xval = xval
        @lazyperclassproperty
        def x(cls):
            return random()

    # Create an instance of the class, initialize per-class attribute
    x0 = X(0)
    x1 = X(1)

    # Set attribute on instance twice
    x0.x = 12.
    x0.x = 11.

    # Check that attribute is indeed different for the different instances
    assert x0.x != x1.x
    assert x0.x != 11.

    # Check that access to the superclass of the class yields the correct result
    class Y(X):
        pass

    y0 = Y(0)
    assert y0.x == x0.x

# Generated at 2022-06-24 03:08:46.685604
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    # Test case:
    # get class property

    class Class1(object):
        @roclassproperty
        def property_1(cls):
            return '1'

    assert_equal(Class1.property_1, '1')

    # Test case:
    # get class property inherited from super class

    class Class2(Class1):
        pass

    assert_equal(Class2.property_1, '1')

    # Test case:
    # get class property overriden in subclass

    class Class3(Class1):
        @roclassproperty
        def property_1(cls):
            return '3'

    assert_equal(Class3.property_1, '3')


# Generated at 2022-06-24 03:08:47.786703
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    ...
    pytest.skip('Tested elsewhere')


# Generated at 2022-06-24 03:08:53.055090
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class DummyClass(object):
        def __init__(self):
            self.__roproperty__ = 1
        @roclassproperty
        def roproperty(cls):
            return cls.__roproperty__
    dummy_instance = DummyClass()
    assert DummyClass.roproperty == 1
    assert dummy_instance.roproperty == 1


# Generated at 2022-06-24 03:08:55.909263
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass (object):
        @roclassproperty
        def prop(cls):
            return 'prop is set'

    assert MyClass.prop == 'prop is set'
    assert MyClass().prop is None



# Generated at 2022-06-24 03:09:01.054789
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def myattr(cls):
            return 'myattr'
    class Child(Parent):
        pass
    class Grandchild(Child):
        pass
    assert Parent.myattr == 'myattr'
    assert Child.myattr == 'myattr'
    assert Grandchild.myattr == 'myattr'
    Parent.myattr = 'another'
    assert Parent.myattr == 'another'
    assert Child.myattr == 'myattr'
    assert Grandchild.myattr == 'myattr'



# Generated at 2022-06-24 03:09:09.050151
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    Test of the lazyclassproperty function.
    """
    class Target:
        def func(cls):
            func.call_count += 1
            return func.call_count

        func.call_count = 0

        test = lazyclassproperty(func)

    assert Target.test == 1
    assert Target.func.call_count == 1

    assert Target.test == 1
    assert Target.func.call_count == 1



# Generated at 2022-06-24 03:09:17.412548
# Unit test for constructor of class setterproperty
def test_setterproperty():
    d = collections.OrderedDict()

    class foo(object):
        def __init__(self):
            self.__d = collections.OrderedDict()

        def set_value(self, k, v):
            self.__d[k] = v

        def get_value(self, k):
            return self.__d[k]

        v = setterproperty(set_value, get_value)

    f = foo()

    f.v['a'] = 42
    f.v['b'] = 43
    assert f.v['a'] == 42
    assert f.v['b'] == 43


# Generated at 2022-06-24 03:09:26.725610
# Unit test for constructor of class setterproperty
def test_setterproperty():
    """
    class setterproperty(object):
        def __init__(self, func, doc=None):
            self.func = func
            self.__doc__ = doc if doc is not None else func.__doc__

        def __set__(self, obj, value):
            return self.func(obj, value)
    """
    @setterproperty
    def abc(self,value):
        """
        abc
        """
        self.xyz = value

    class A:
        pass

    a = A()
    a.abc = 2
    assert a.xyz == 2
    assert A.abc.__doc__ == 'abc'



# Generated at 2022-06-24 03:09:36.332643
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:09:45.872541
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

    # Test class
    class Tester:

        def __init__(self):
            self.x = "not called"
            self.y = "not called"
            self.z = "not called"

        @roclassproperty
        def get_x(cls):
            print("Calling get_x, class %s" % cls)
            return "x"

        @roclassproperty
        def get_y(cls):
            print("Calling get_y, class %s" % cls)
            return cls.y

        def _set_y(cls, x):
            print("Calling set_y, class %s, value %s" % (cls, x))
            cls.y = x

        y = property(roclassproperty(fget=get_y), _set_y)


# Generated at 2022-06-24 03:09:47.931237
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class test_roclassproperty(object):
        __var = 123
        @roclassproperty
        def var(cls):
            return cls.__var
    assert test_roclassproperty.var.__get__(None, test_roclassproperty) == 123



# Generated at 2022-06-24 03:09:49.927948
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    l = lazyclassproperty(lambda c: sum(range(10)))
    assert l == 45
    assert l == 45



# Generated at 2022-06-24 03:09:55.032376
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def a(cls):
            return 'hello'
        a = C.a
    assert C.a == 'hello'



# Generated at 2022-06-24 03:10:01.405447
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test:
        @setterproperty
        def x(self, v):
            print("setter x to %s" % v)
            self.__x = v

        def __init__(self):
            self.x = 12

        def get_x(self):
            return self.__x

    t = Test()
    assert t.get_x() == 12
    t.x = 42
    assert t.get_x() == 42


# Generated at 2022-06-24 03:10:06.059112
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X():
        def __init__(self, x):
            self.x = x

        @setterproperty
        def x(self, value):
            self.__x = value

        @x.getter
        def x(self):
            return self.__x

    x = X(1)
    x.x = 2
    assert x.x == 2



# Generated at 2022-06-24 03:10:10.749900
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def test(cls):
            return [1]
    class DerivedOne(Base):
        pass
    class DerivedTwo(Base):
        pass
    assert Base.test == [1]
    assert DerivedOne.test == [1]
    assert DerivedTwo.test == [1]
    Base.test.append(2)
    assert Base.test == [1, 2]
    assert DerivedOne.test == [1]
    assert DerivedTwo.test == [1]
    DerivedOne.test.append(3)
    assert Base.test == [1, 2]
    assert DerivedOne.test == [1, 3]
    assert DerivedTwo.test == [1]
    DerivedTwo.test.append(4)

# Generated at 2022-06-24 03:10:15.248136
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        @lazyperclassproperty
        def foo(self):
            print("execute foo")
            return 11

    class Test1(Test):
        pass

    class Test2(Test):
        pass

    assert Test().foo == 11
    assert Test1().foo == 11
    assert Test2().foo == 11

# Generated at 2022-06-24 03:10:19.262153
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        def _get_bar(cls):
            return 'baz'
        bar = roclassproperty(_get_bar)

    assert Foo.bar == 'baz'


# Generated at 2022-06-24 03:10:22.154592
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    def f(self, value):
        self.y = value * 2
        return value

    class C(object):
        x = 0

    c = C()
    c.p = setterproperty(f)

    c.p = 10
    assert c.p == 10
    assert c.y == 20



# Generated at 2022-06-24 03:10:23.921845
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            return 3
    class B(A):
        pass
    assert A.x == 3
    assert B.x == 3



# Generated at 2022-06-24 03:10:29.005982
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def foo(self):
            return self.bar

        @roclassproperty
        def bar(cls):
            return 'bar'

    assert A.bar == 'bar'
    assert A().foo() == 'bar'
    assert A.__dict__['bar'].f(A) == 'bar'


# Generated at 2022-06-24 03:10:32.599080
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class MyClass(object):
        @setterproperty
        def foo(self, value):
            return "setter value " + value
    a = MyClass()
    a.foo = "b"
    assert(a.foo == "setter value b")



# Generated at 2022-06-24 03:10:35.993058
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.val = 0

        @setterproperty
        def a(self, newval):
            self.val = newval

    a = A()
    a.a = 5
    return a.val == 5



# Generated at 2022-06-24 03:10:44.049234
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Setup
    class Foo(object):
        pass

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    @classproperty
    def x(cls):
        return cls

    # Exercise
    actual = x.__get__(None, Baz)

    # Verify
    expected = Baz
    assert actual is expected, 'Expected: %r, Actual: %r' % (expected, actual)



# Generated at 2022-06-24 03:10:46.444390
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def num(cls):
            return 99

    assert A.num == 99
    a = A()
    assert a.num == 99
    with raises(AttributeError) as excinfo:
        a.num = 90  # roclassproperty should make sure this is not allowed



# Generated at 2022-06-24 03:10:52.277115
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    print('test_setterproperty___set__')

    class Struct:
        a = 1

    class Foo:
        @setterproperty
        def foo(self, x):
            Struct.a = x
            return x

    foo = Foo()
    foo.foo = 3
    assert Struct.a == 3

    Struct.a = 0
    assert Struct.a == 0

    print('test_setterproperty___set__; pass')


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:10:56.658460
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        count = 0

        @roclassproperty
        def count(cls):
            return C.count

        def __init__(self):
            C.count += 1

    c1 = C()
    assert c1.count == 1
    c2 = C()
    assert c2.count == 2
    c3 = C()
    assert c3.count == 3


# Generated at 2022-06-24 03:10:59.601827
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def t(cls): return 4
    eq_(4, Test.t)
    assert_raises(AttributeError, setattr, Test, 't', 5)



# Generated at 2022-06-24 03:11:03.566986
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        __visit_name__ = setterproperty(
            lambda self, val: setattr(self, '_visit_name', val)
        )

        def __init__(self):
            self._visit_name = None

        def __repr__(self):
            return "<A: {0}>".format(self.__visit_name__)

    a = A()
    a.__visit_name__ = "test1"

# Generated at 2022-06-24 03:11:07.429259
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.x = 17

        @setterproperty
        def x(self, value):
            if value > 5:
                self._x = value
            else:
                print("value should be bigger than 5")

    a = A()
    a.x = 6
    print(a.x)
    a.x = 4
    print(a.x)


test_setterproperty()

# Generated at 2022-06-24 03:11:10.422626
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class TestClass:
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            self._x = value

    test = TestClass(42)
    assert test._x == 42

    test.x = 100
    assert test._x == 100


# Generated at 2022-06-24 03:11:15.477966
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        __doc__ = "This is the doc string of class A."
        def __init__(self, value):
            self._value = value
        @setterproperty
        def attribute(self, value):
            self._value = value
        @classmethod
        def get_attribute(cls, self):
            return self._value
        @classmethod
        def check_attribute(cls, self):
            assert self.get_attribute(self) == self._value
        def check(self):
            self.__class__.check_attribute(self)
    a = A(10)
    assert a._value == 10
    assert a.get_attribute(a) == 10
    a.check()
    
    a.attribute = 15
    assert a._value == 15
    a.check()

    b

# Generated at 2022-06-24 03:11:22.855781
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class S(object):
        @lazyclassproperty
        def foo(cls):
            return 'foo' + str(cls.__name__)

    class C(S):
        @lazyclassproperty
        def foo(cls):
            return 'bar' + str(cls.__name__)

    class D(C):
        pass

    assert S.foo == 'fooS'
    assert C.foo == 'barC'
    assert D.foo == 'barD'



# Generated at 2022-06-24 03:11:24.422339
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class SomeClass(object):
        def __init__(self, *args):
            self.args = args


# Generated at 2022-06-24 03:11:28.059611
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Animal:
        @lazyperclassproperty
        def foo(cls):
            return [10]

    class Dog(Animal): pass
    class Cat(Animal): pass

    assert Dog.foo == [10]
    assert Cat.foo == [10]

    Dog.foo[0] = 20
    assert Dog.foo == [20]
    assert Cat.foo == [10]


# Generated at 2022-06-24 03:11:33.489065
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Tmp:
        def test_method(self):
            return 'call test_method'

    # Create a descriptor for class Tmp
    descriptor = roclassproperty(Tmp.test_method)

    assert descriptor.__get__(Tmp(), Tmp.__bases__) == 'call test_method'



# Generated at 2022-06-24 03:11:40.227723
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        def __init__(self):
            self.x = 1

        @lazyclassproperty
        def get_y(cls):
            return Test.x

    a = Test()
    b = Test()

# Generated at 2022-06-24 03:11:45.462042
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self, value=0):
            self.__value = value

        @setterproperty
        def value(self, value):
            self.__value = value

    test = Test(value=100)

    assert test.value == 100
    test.value = 200
    assert test.value == 200



# Generated at 2022-06-24 03:11:52.169732
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(cls):
            print(cls.__name__, 'test')
            return 1
    class B(A):
        pass
    class C(A):
        @lazyperclassproperty
        def test(cls):
            print(cls.__name__, 'test')
            return 2
    class D(C):
        pass
    assert A.test != B.test != C.test != D.test != C.test
    assert A.test == B.test


# Generated at 2022-06-24 03:12:01.699364
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:12:08.755727
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print("Called bar on class %s, should only be called once." % cls)
            return 42

    class FooSub(Foo):
        pass

    f = Foo()

    # Should print "Called bar on class <class '__main__.Foo'>, should only be called once."
    print(f.bar, Foo.bar, FooSub.bar)

    # Should print "42 42 42"
    print(f.bar, Foo.bar, FooSub.bar)



# Generated at 2022-06-24 03:12:12.108186
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def name(cls):
            return cls.__name__ + 'X'

    class D(C):
        pass

    assert 'CX' == C.name
    assert 'DX' == D.name



# Generated at 2022-06-24 03:12:15.944310
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def getx(self):
            return self._x

        def setx(self, value):
            self._x = value

        x = setterproperty(setx, getx.__doc__)

    c = C()
    c.x = 1
    assert c._x == 1
    assert c.x == 1

    c = C()
    c._x = 1
    assert c.x == 1


# Generated at 2022-06-24 03:12:21.992615
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def prop(cls):
            return 1

    t = Test()
    assert t.prop == t.prop
    assert Test.prop == Test.prop
    assert Test().prop == Test().prop
    assert Test.prop == 1

# Generated at 2022-06-24 03:12:28.923967
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        @staticmethod
        def name():
            return 'class'

        @property
        def name2(self):
            return 'class2'

    assert A.name == 'class'
    a = A()
    assert a.name == 'class'
    assert a.name2 == 'class2'

# Generated at 2022-06-24 03:12:38.307704
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    
    class LazyTest(object):
        @lazyperclassproperty
        def x(cls):
            return 'x: %s' % cls

        @lazyperclassproperty
        def y(cls):
            return 'y: %s' % cls

    class LazyTestChild(LazyTest):
        @classproperty
        def z(cls):
            return 'z: %s' % cls
    
    assert LazyTest.x == 'x: <class \'__main__.LazyTest\'>'
    assert LazyTest.x == 'x: <class \'__main__.LazyTest\'>'
    assert LazyTestChild.x == 'x: <class \'__main__.LazyTestChild\'>'

# Generated at 2022-06-24 03:12:41.880286
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def name(cls):
            return cls.__name__

    assert A.name == 'A'
    assert A().name == 'A'

    class B(A):
        pass

    assert B.name == 'B'
    assert B().name == 'B'



# Generated at 2022-06-24 03:12:48.423906
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self._a = 0

        @setterproperty
        def a(self, value):
            self._a += value

    a = A()
    a.a = 10
    assert a._a == 10
    a.a = 10
    assert a._a == 20
    a.a = -15
    assert a._a == 5

# Generated at 2022-06-24 03:12:50.398852
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Cls1(object):
        @setterproperty
        def x(self, value):
            self.__x = value

    obj = Cls1()
    obj.x = 123
    assert obj.__x == 123



# Generated at 2022-06-24 03:12:54.324252
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base:
        @lazyperclassproperty
        def test(cls):
            return "test"

    class Child(Base):
        pass

    assert Base.test == "test"
    assert Child.test == "test"

    assert Child.test is not Base.test



# Generated at 2022-06-24 03:13:05.542855
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def lazyprop(cls):
            """
            Lazy property
            :return:
            """
            return 'Lazy property'

    assert A.lazyprop == 'Lazy property'
    assert A.lazyprop == 'Lazy property'
    assert A.lazyprop == 'Lazy property'
    assert A().lazyprop == 'Lazy property'
    assert A().lazyprop == 'Lazy property'
    assert A().lazyprop == 'Lazy property'

    class B(A):
        pass

    assert B.lazyprop == 'Lazy property'
    assert B().lazyprop == 'Lazy property'


# Generated at 2022-06-24 03:13:08.226539
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test for method __set__
    """
    def testfunc(obj, value):
        obj.value = value
    p = setterproperty(testfunc)
    o = object()
    o.value = 0
    p.__set__(o, 1)
    assert o.value == 1

# Generated at 2022-06-24 03:13:14.486793
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    '''
    purpose:
        To test constructor of class roclassproperty
    method:
        Create an object of roclassproperty class,
        and call constructor.
    expected:
        return True if all the attribute are set
    '''
    from vegadns.api.models.domains import Domains
    roclassproperty_obj = roclassproperty(Domains.dnssec_enabled)
    if roclassproperty_obj.f == Domains.dnssec_enabled:
        return True
    else:
        return False



# Generated at 2022-06-24 03:13:17.844970
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        @setterproperty
        def foo(self, value):
            self.foo = value
            self.bar = value
    a = A()
    a.foo = 1
    a.foo = 2
    assert a.foo == 2
    assert a.bar == 2


# Generated at 2022-06-24 03:13:24.131171
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        def __init__(self):
            self.x = 1

        @roclassproperty
        def foo(cls):
            return cls.x

    test = Test()
    Test.x = 2
    assert Test.foo == 2
    assert test.foo == 2  # <- no self.x in Test class


# Generated at 2022-06-24 03:13:28.995620
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class TestClass:
        def __init__(self):
            self.__x = None
        def set_x(self, value):
            self.__x = value
        x = setterproperty(set_x)
    test = TestClass()
    test.x = 10
    assert test.__dict__['_TestClass__x'] == 10


# Generated at 2022-06-24 03:13:33.715330
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class a:
        def __init__(self):
            self.x = 0
            #self.y = 1
            self.yprop = setterproperty(self.sety)

        def sety(self, value):
            self.y = value

    t1 = a()
    t2 = a()

    t1.yprop = 10
    t2.yprop = 20

    assert t1.y == 10
    assert t2.y == 20


# Generated at 2022-06-24 03:13:38.016598
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls

    assert A.prop == A
    class B(A):
        pass
    assert B.prop == B
    assert A.prop == A


# Generated at 2022-06-24 03:13:47.701715
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class T:
        _cache = {}

        @lazyperclassproperty
        def test(cls):
            t = cls._cache.get(cls.__name__, 0)
            t += 1
            cls._cache[cls.__name__] = t
            return t

    class X1(T):
        pass

    class X2(T):
        pass

    class X3(X1):
        pass

    assert T.test == 1
    assert X1.test == 1
    assert X2.test == 1
    assert X3.test == 1

    T._cache = {}
    X1._cache = {}
    X2._cache = {}
    X3._cache = {}

    assert T.test == 1
    assert X1.test == 1
    assert X2.test == 1
   

# Generated at 2022-06-24 03:13:53.126897
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class A:
        def __init__(self, value):
            self.value = value

    class B(A):
        pass

    class C:
        @lazyperclassproperty
        def my_prop(cls):
            return cls(1)

    assert C.my_prop.value == 1
    assert C.my_prop.value == 1
    assert B.my_prop.value == 1
    assert B.my_prop.value == 1

