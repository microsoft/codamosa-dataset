

# Generated at 2022-06-24 03:03:51.908258
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class MyClass(object):
        def get_value(cls):
            return 'the value'
        value = roclassproperty(get_value)

    assert MyClass.value == 'the value'
    # MyClass.value = 'other value'  # must raise AttributeError



# Generated at 2022-06-24 03:03:57.955198
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C:
        @lazyclassproperty
        def prop(cls):
            print('eval')
            return 42

    assert C.prop == 42
    assert C.prop == 42

    class D(C):
        pass

    assert D.prop == 42
    assert D.prop == 42



# Generated at 2022-06-24 03:04:05.886564
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def __name__(cls):
            return str("Foo")

    class Bar(Foo):
        @lazyperclassproperty
        def __name__(cls):
            return str("Bar")

    class Baz(Foo):
        @lazyperclassproperty
        def __name__(cls):
            return str("Baz")

    classes = [Foo, Bar, Baz]
    for cls in classes:
        for other_cls in classes:
            assert cls.__name__ == cls.__name__


# Generated at 2022-06-24 03:04:12.239997
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        x = 1

        @lazyclassproperty
        def y(cls):
            return cls.x + 1

    class B(A):
        x = 2

    assert A.y == 2
    assert B.y == 3

    A.x = 3
    assert A.y == 4
    assert B.y == 3



# Generated at 2022-06-24 03:04:17.430267
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 'ry'
    assert A.x == 'ry'
    assert A().x == 'ry'



# Generated at 2022-06-24 03:04:27.174500
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo:
        @lazyperclassproperty
        def test_property(cls):
            print('Create new property for class {}'.format(cls.__name__))
            return cls.__name__

    class Bar(Foo):
        pass

    class Baz(Bar):
        pass

    class FooBar:
        @lazyperclassproperty
        def test_property(cls):
            print('Create new property for class {}'.format(cls.__name__))
            return cls.__name__

    assert Foo.test_property == 'Foo'
    assert Bar.test_property == 'Bar'
    assert Baz.test_property == 'Baz'
    assert FooBar.test_property == 'FooBar'


# Generated at 2022-06-24 03:04:35.452741
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # NOTE: if you raise an exception and then decorate the class or
    # method the exception text is lost ...
    print('Starting unit test for roclassproperty...')
    try:
        class Foo(object):
            @roclassproperty
            def foo(cls):
                return 'foo'

            @roclassproperty
            def bar():
                return 'bar'

        assert Foo.foo == 'foo'
        assert Foo().foo == 'foo'
        assert Foo.bar == 'bar'
        assert Foo().bar == 'bar'
    except Exception as e:
        print('Unit test for roclassproperty terminated with exception: "' + str(e) + '"!')
        assert False
    print('Unit test for roclassproperty finished successfully!')


# Generated at 2022-06-24 03:04:41.901641
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        pass

    def make_roclassproperty():
        @roclassproperty
        def p(cls):
            return 3

        return p()

    # modify C
    C.p = make_roclassproperty()

    # run the test
    assert 3 == C.p

# Generated at 2022-06-24 03:04:49.924355
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self, x_val=1, y_val=2):
            self._x = x_val
            self._y = y_val
            self._total = None

        x = setterproperty(lambda self, val: setattr(self, '_x', val))
        y = setterproperty(lambda self, val: setattr(self, '_y', val))

        @setterproperty
        def total(self, val):
            self._total = val

        @lazyclassproperty
        def x_plus_y(cls):
            return cls.x + cls.y

    assert Foo.x == 1
    assert Foo.y == 2
    assert Foo.x_plus_y == 3
    assert Foo().x_plus_y == 3


# Generated at 2022-06-24 03:04:53.720303
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):

        @lazyclassproperty
        def foo(cls):
            return 42

    class B(A):
        pass

    assert A.foo == 42
    assert B.foo == 42


# Generated at 2022-06-24 03:04:56.967364
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, value):
            self.value = value
    assert Foo(1).value == 1
    assert Foo(2).value == 2



# Generated at 2022-06-24 03:05:06.287934
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test for with class
    class Foo(object):
        def __init__(self):
            self.__one = 1

        @roclassproperty
        def one(cls):
            return cls.__one

        @roclassproperty
        def two(cls):
            return cls.__one + 1

    foo = Foo()
    assert(foo.one == 1)
    assert(foo.two == 2)
    try:
        foo.one = 3
    except AttributeError:
        pass
    else:
        assert(False)

    # Test for without class
    def bar_one():
        return 1

    def bar_two(bar):
        return bar.one + 1

    bar_one_get = roclassproperty(bar_one)

# Generated at 2022-06-24 03:05:10.251750
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def getx(cls): return 1
        x = roclassproperty(getx)

    assert C.x == 1
    try:
        C.x = 2
    except AttributeError:
        pass
    else:
        raise Exception("roclassproperty allows set")


# Generated at 2022-06-24 03:05:15.348637
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:05:25.557192
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class test(object):
        @lazyperclassproperty
        def classprop(self):
            return 'classprop'

        @lazyperclassproperty
        def classprop2(self):
            return 'classprop2'

    class test2(test):
        pass

    class test3(test2):
        pass

    assert test.classprop != test2.classprop
    assert test.classprop != test3.classprop
    assert test2.classprop != test3.classprop

    # The 'test' class instances should share the same property
    t = test()
    t2 = test()
    assert t.classprop == t2.classprop

    # The 'test2' class instances should share the same property
    t = test2()
    t2 = test2()

# Generated at 2022-06-24 03:05:31.497842
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self,value):
            self.value=value
        @setterproperty
        def set_value(self,value):
            self.value=value
            return self.value
    a=A(0)
    assert a.set_value(1)==1
    assert a.value==1

# Generated at 2022-06-24 03:05:35.725639
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    import unittest
    class Foo(object):
        @roclassproperty
        def bar(cls): return 42
        
    class Bar(Foo):
        pass
        
    class Test(unittest.TestCase):
        def test_roclassproperty___get__(self):
            self.assertEqual(Foo.bar, 42)
            self.assertEqual(Bar.bar, 42)
    unittest.main()


# Generated at 2022-06-24 03:05:41.514837
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from wineggdrop.helpers import setterproperty

    class SampleClass(object):
        def __init__(self):
            self.props = {}

        @setterproperty
        def prop(self, value):
            self.props.setdefault(prop.__name__, [])
            self.props[prop.__name__].append(value)

    s = SampleClass()

    s.prop = 1
    s.prop = 2

    assert s.props == {"prop": [1, 2]}



# Generated at 2022-06-24 03:05:51.873252
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A:
        def __repr__(self):
            return 'a'
    a = A()

    class B:
        @lazyperclassproperty
        def attr(cls):
            return a

        @lazyperclassproperty
        def attr2(cls):
            return cls.attr

    class C(B):
        pass

    class D(C):
        pass

    class E(D):
        pass

    class F(A):
        def __repr__(self):
            return 'f'

    class G(B):
        attr = F()

    assert B.attr is a
    assert C.attr is a
    assert D.attr is a
    assert E.attr is a
    assert B.attr2 is a
    assert C.attr2 is a

# Generated at 2022-06-24 03:05:58.472134
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class testclass(object):
        def __init__(self, x, y):
            self.x = x
            self.y = y

        @roclassproperty
        def z(cls):
            return cls(self.x, self.y)

    testclass1 = testclass(12, 34)
    testclass1.z
    assert testclass1.z == testclass1


# Generated at 2022-06-24 03:06:01.986541
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        def set_value(self, value):
            self.value = value

        value = setterproperty(set_value)

    t = Test()
    t.value = 100
    assert t.value == 100



# Generated at 2022-06-24 03:06:10.376551
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:06:13.847397
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        __metaclass__ = MetaClass
        @roclassproperty
        def x(cls):
            return 'hello'

    assert A.x == 'hello'

    try:
        A.x = 'world'
    except Exception as e:
        assert 1
    else:
        assert 0



# Generated at 2022-06-24 03:06:17.868895
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self):
            self._pro_name = None 
        
        @setterproperty
        def pro_name(self, name):
            self._pro_name = name
            print(self._pro_name)
            
        @setterproperty
        def pro_describe(self, name):
            if name == 'default':
                print(self._pro_name)
    
    a = A()
    a.pro_name = 'change name'
    a.pro_describe = 'default'

# Generated at 2022-06-24 03:06:20.714345
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self, value):
            self._x = value

        @setterproperty
        def x(self, value):
            self._x = value

    c = C(1)
    print(c.x)
    c.x = 2
    print(c.x)
    c.x = 3
    print(c.x)

    print(C(2).x)


if __name__ == '__main__':
    test_setterproperty___set__()

# Generated at 2022-06-24 03:06:30.442769
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        def __init__(self, value=5):
            self.value = value

        @setterproperty
        def value(self, value):
            if not isinstance(value, int):
                raise ValueError("Not an int")
            return value

    foo = Foo()
    assert foo.value == 5
    foo.value = 6
    assert foo.value == 6
    assert hasattr(foo, "_value")
    try:
        foo.value = 'invalid'
        assert False
    except ValueError:
        pass
    assert foo.value == 6
    assert hasattr(foo, "_value")

# Generated at 2022-06-24 03:06:34.010156
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def foo(cls):
            print('foo invoked!')
            return 42

    assert Foo.foo == 42
    assert Foo.foo == 42  # Pay attention, no more print here!



# Generated at 2022-06-24 03:06:38.615198
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class C(object):
        @lazyclassproperty
        def x(cls):
            return 2

    assert C.x == 2
    C.x = 3
    assert C.x == 2


# Generated at 2022-06-24 03:06:43.136161
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def foo(cls):
            print('foo')
            return 'foo'

    assert Test.foo == 'foo'
    # Only one print statement should be executed
    assert Test.foo == 'foo'
    # Make sure that the attribute is not already set on the class object
    assert not hasattr(Test, '_lazy_foo')


# Generated at 2022-06-24 03:06:49.766554
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):

        @roclassproperty
        def bar(cls):
            return 'this is bar from class %s' % cls.__name__

    class Bar(Foo):
        pass

    assert Foo.bar == 'this is bar from class Foo'
    assert Bar.bar == 'this is bar from class Bar'

    try:
        Bar.bar = 'bar'
    except TypeError:
        pass
    else:
        raise AssertionError('The roproperty cannot be written.')



# Generated at 2022-06-24 03:06:53.215685
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class TestClass(object):
        @lazyclassproperty
        def name(self):
            return "NAME"

        @lazyclassproperty
        def test_one(self):
            return 1

    assert TestClass.name == TestClass.name
    assert TestClass.test_one == TestClass.test_one



# Generated at 2022-06-24 03:06:57.268497
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            print('creating class property bar')
            return 'bar'

    assert Foo.bar == 'bar'
    assert Foo.bar == 'bar'

    class Baz(Foo):
        pass

    assert Foo.bar == 'bar'
    assert Baz.bar == 'bar'
    assert Baz.bar == 'bar'

    Foo.bar = 'bar2'
    assert Baz.bar == 'bar'



# Generated at 2022-06-24 03:07:02.530902
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Ex(object):
        @lazyperclassproperty
        def f(cls):
            return 1

        @lazyperclassproperty
        def f2(cls):
            return 2

    class ExB(Ex):
        @lazyperclassproperty
        def f(cls):
            return 3

    assert Ex.f == 1
    assert Ex.f2 == 2
    assert ExB.f == 3
    assert ExB.f2 == 2

# Generated at 2022-06-24 03:07:05.558722
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def attr_func(cls):
            return 'test'
        @roclassproperty
        def attr_str(cls):
            return 'test'

    assert A.attr_func == 'test'
    assert A.attr_str == 'test'

# Generated at 2022-06-24 03:07:07.997492
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def foo(self, value):
            self.foo = value

    a = A()
    a.foo = 42
    assert a.foo == 42


# Generated at 2022-06-24 03:07:11.443081
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class B(A):
        pass

    class C(A):
        pass

    assert A.prop == 'A'
    assert B.prop == 'B'
    assert C.prop == 'C'


# Generated at 2022-06-24 03:07:17.184869
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

    class Person(object):
        first_name = "John"
        last_name = "Smith"

        @setterproperty
        def name(self, name):
            first_name, last_name = name.split(' ', 2)
            self.first_name = first_name
            self.last_name = last_name


    person = Person()
    print(person.first_name, person.last_name)  # John Smith
    person.name = "Larry Page"
    print(person.first_name, person.last_name)  # Larry Page



# Generated at 2022-06-24 03:07:23.018914
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        pass

    class B(object):
        pass

    class C(B):
        pass

    @lazyperclassproperty
    def x(cls):
        """
        Docstring for x.
        """
        return object()

    assert x.__doc__ == "Docstring for x."
    assert x.fget is None
    assert x.fset is None
    assert x.fdel is None

    assert x.__get__(None, A) is not x.__get__(None, B)
    assert x.__get__(None, B) is not x.__get__(None, A)
    assert x.__get__(None, A) is x.__get__(None, A)

# Generated at 2022-06-24 03:07:27.729773
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Parent(object):
        @lazyperclassproperty
        def prp(cls):
            return 'prp'

    class Child(Parent):
        pass

    assert Parent.prp == 'prp'
    assert Child.prp == 'prp'
    assert Parent().prp == 'prp'
    assert Child().prp == 'prp'



# Generated at 2022-06-24 03:07:30.939294
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def what_am_i(cls):
            return "This is a class property."

    print(Foo.what_am_i)  # This is a class property.


if __name__ == '__main__':
    test_roclassproperty()

# Generated at 2022-06-24 03:07:39.022691
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def foo(cls):
            return 'foo'

    assert TestClass.foo == 'foo'

    try:
        TestClass().foo = 'wtf'
    except AttributeError as e:
        assert str(e) == "'TestClass' object has no attribute 'foo'"
    else:
        raise AssertionError('AttributeError not raised')



# Generated at 2022-06-24 03:07:42.482884
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class MyClass(object):
        @setterproperty
        def test1(self, value):
            self.__test1 = value

        @setterproperty
        def test2(self, value):
            self.__test2 = value

    class_instance = MyClass()
    class_instance.test1 = 1
    class_instance.test2 = 2
    assert class_instance.__test1 == 1
    assert class_instance.__test2 == 2

# Generated at 2022-06-24 03:07:51.213830
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    # pylint: disable=too-few-public-methods, missing-class-docstring
    class A(object):
        _ro = "This should be read-only"

        @roclassproperty
        def ro(cls):
            return cls._ro

    assert issubclass(A, object)
    # Test read
    assert A.ro == "This should be read-only"
    # Test write
    try:
        A.ro = "This should throw an exception"
        raise Exception("A.ro = ... should throw an exception")
    except AttributeError:
        pass

    # Unit test for constructor of class lazyclassproperty
    class B(object):
        def __init__(self):
            self.called = 0
            self.val = 0


# Generated at 2022-06-24 03:07:57.757145
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class O:
        @lazyperclassproperty
        def lent(cls):
            return len(cls.l)
        l = []

    class A(O):
        l = [1, 2]
    class B(O):
        l = [3, 4, 5]

    assert A.lent == 2
    assert B.lent == 3



# Generated at 2022-06-24 03:08:00.253273
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def x(cls):
            return 'x'

    assert A.x == 'x'



# Generated at 2022-06-24 03:08:05.824562
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Test(object):
        pass

    @setterproperty
    def test(self, value):
        Test.test = value

    Test().test = 'test_setterproperty___set__'
    Test.test = 'test_setterproperty___set__'



# Generated at 2022-06-24 03:08:07.798726
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        _flag = False

        @setterproperty
        def flag(self, value):
            self._flag = bool(value)

    c = C()
    c.flag = 1
    ok_(c._flag)



# Generated at 2022-06-24 03:08:14.635058
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:08:18.895017
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        pass
        
    @setterproperty
    def foo(self, value):
        self.foo = value
    Foo.foo = "bar"
    assert Foo.foo=="bar"


# Generated at 2022-06-24 03:08:26.001911
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    # Test when owner is None
    class Foo(object):
        @roclassproperty
        def my_class_property(cls):
            return cls.__name__

    foo = Foo()
    assert foo.my_class_property == 'Foo'

    # Test when owner is not None
    class Bar(object):
        @roclassproperty
        def my_class_property(cls):
            return cls.__name__

    class NewFoo(Bar):
        pass

    new_foo = NewFoo()
    assert new_foo.my_class_property == 'NewFoo'


if __name__ == '__main__':
    test_roclassproperty___get__()

# Generated at 2022-06-24 03:08:32.221061
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self, value):
            self.value = value

        @setterproperty
        def value(self, value):
            self.__value = 100 + value

        @value.getter
        def value(self):
            return self.__value

    t = Test(50)
    assert t.value == 150



# Generated at 2022-06-24 03:08:35.183840
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        object_number = 0

        @lazyperclassproperty
        def object_number(cls):
            TestClass.object_number += 1
            return TestClass.object_number

    class TestClassInheritor(TestClass):
        pass

    assert TestClass.object_number is 1
    assert TestClassInheritor.object_number is 2
    assert TestClassInheritor.object_number is 2



# Generated at 2022-06-24 03:08:42.125650
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class TestClass:
        @roclassproperty
        def test_roclassproperty(cls):
            return "test_roclassproperty"

        def __init__(self):
            self.test_roclassproperty = "test_roclassproperty"

    assert TestClass.test_roclassproperty == "test_roclassproperty"
    assert TestClass().test_roclassproperty == "test_roclassproperty"



# Generated at 2022-06-24 03:08:48.198539
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class bigparent(object):
        @lazyclassproperty
        def test(cls):
            return "test"

    class parent(bigparent):
        pass

    class child(parent):
        pass

    assert '_lazy_test' not in bigparent.__dict__

# Generated at 2022-06-24 03:08:51.845809
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class TestClass(object):
        @roclassproperty
        def test(cls):
            return 123

    assert TestClass.test == 123
    assert TestClass().test == TestClass.test


# Generated at 2022-06-24 03:08:56.658194
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():

       def f(obj, value):
           obj.attr = value

       class Foo(object):
           attr = None

           def __init__(self):
               self.sp = setterproperty(f)

       foo = Foo()
       foo.sp = '1'
       assert foo.attr == '1'

if __name__ == "__main__":
    test_setterproperty___set__()
    print("Done.")

# Generated at 2022-06-24 03:09:01.709253
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Test for roclassproperty
    """
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return cls.__name__

    assert Foo.bar == 'Foo'



# Generated at 2022-06-24 03:09:05.613071
# Unit test for constructor of class roclassproperty
def test_roclassproperty():

    class car(object):
        def __init__(self, brand, color):
            self.brand = brand
            self.color = color

        def __repr__(self):
            return '<%s brand, %s color>' % (self.brand, self.color)

        @roclassproperty
        def driver(cls):
            return 'Mr. %s' % cls.__name__

    # Test roclassproperty
    assert car.driver == 'Mr. car'

    # Test roclassproperty with an object
    assert car('honda', 'green').driver == 'Mr. car'

    # Test roclassproperty with an object
    honda = car('honda', 'green')
    honda.driver = 'Daehee Park'
    assert honda.driver == 'Mr. car'


# Generated at 2022-06-24 03:09:11.380018
# Unit test for constructor of class setterproperty
def test_setterproperty():
    pass


# def _test_setterproperty():
#     class A(object):
#         def set_x(self, value):
#             raise ValueError
#
#         x = setterproperty(set_x)
#
#     a = A()
#     try:
#         a.x = 1
#     except ValueError:
#         pass
#     else:
#         assert False



# Generated at 2022-06-24 03:09:14.707716
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def a(cls):
            return 1

    for cls in [A, A()]:
        assert cls.a == 1


# Generated at 2022-06-24 03:09:19.666063
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None

        @setterproperty
        def x(self, value):
            self._x = value

    c = C()
    assert c._x == None
    c.x = 1
    assert c._x == 1


# Generated at 2022-06-24 03:09:26.771383
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

        @roclassproperty
        def getName(cls):
            return cls.name

    def main():
        p = Person("John", 36)
        print(p.getName)
        p.getName = "Mohit"



# Generated at 2022-06-24 03:09:35.886073
# Unit test for constructor of class setterproperty
def test_setterproperty():
    import unittest
    class A(object):
        def __init__(self, x):
            self.x = x
        def getx(self):
            return self.x
        def setx(self, x):
            self.x = x
        x = setterproperty(setx)
        y = setterproperty(getx, doc="y doc")
        z = setterproperty(getx)
    class A2(object):
        def __init__(self, y):
            self.y = y
        def gety(self):
            return self.y
        def sety(self, y):
            self.y = y
        y = setterproperty(sety)
        z = setterproperty(gety)
    class B(A, A2):
        pass

# Generated at 2022-06-24 03:09:44.627185
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Example(object):
        def __init__(self):
            self.old_value = None
            self.new_value = 0

        def _set_new_value(self, new_value):
            self.old_value = self.new_value
            self.new_value = new_value

        new_value = setterproperty(_set_new_value)

    example = Example()
    assert example.new_value == 0
    example.new_value = 1
    assert example.new_value == 1
    assert example.old_value == 0
    example.new_value = 2
    assert example.new_value == 2
    assert example.old_value == 1

# Generated at 2022-06-24 03:09:48.480193
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Cls(object):
        def __init__(self, x):
            self.x = x

        @roclassproperty
        def cprop(cls):
            return cls.__name__

    assert Cls.cprop == "Cls"
    assert Cls(6).cprop == "Cls"



# Generated at 2022-06-24 03:09:54.253176
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self, x=0, y=0):
            self.x = x
            self.y = y

        @setterproperty
        def x(self, value):
            print("The x property is set as: " + str(value))

        @setterproperty
        def y(self, value):
            print("The y property is not changed!")

    a = A()
    a.x = "2"
    a.y = 1


# Generated at 2022-06-24 03:09:59.881606
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class c1(object):

        @setterproperty
        def x(self, value):
            self.v = value

    i = c1()
    i.x = 1
    assert(i.v == 1)

    j = c1()
    j.x = 2
    assert(j.v == 2)



# Generated at 2022-06-24 03:10:07.576898
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class ExampleClass1(object):
        @lazyperclassproperty
        def example_per_class_property_1(cls):
            return 1

        @lazyperclassproperty
        def example_per_class_property_2(cls):
            return 2

    class ExampleClass2(ExampleClass1):
        pass

    assert ExampleClass1.example_per_class_property_1 == 1
    assert ExampleClass1.example_per_class_property_2 == 2

    assert ExampleClass2.example_per_class_property_1 == 1
    assert ExampleClass2.example_per_class_property_2 == 2



# Generated at 2022-06-24 03:10:12.346682
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    """
    >>> test_lazyclassproperty()
    True
    """
    class A(object):
        @lazyclassproperty
        def b(cls):
            cls.b1 = 2
            return cls.b1

    a = A()
    assert a.b is 2
    assert a.b1 is 2


# Generated at 2022-06-24 03:10:17.312696
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class c(object):
        def __init__(self, v):
            self.v = v
        @setterproperty
        def v(self, v):
            return v.upper()
    o = c('spam')
    assert o.v == 'SPAM'
    o.v = 'eggs'
    assert o.v == 'EGGS'


# Generated at 2022-06-24 03:10:20.546285
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.x = 0

        def _set_x(self, value):
            self.x = 2 * value

        x = setterproperty(_set_x)

    a = A()
    a.x = 4
    assert a.x == 8, "should be 8"



# Generated at 2022-06-24 03:10:23.595364
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Test(object):
        @lazyclassproperty
        def func(cls):
            return cls.__name__

    assert Test.func == "Test"
    assert Test().func == "Test"

    class SubTest(Test):
        pass

    assert SubTest.func == "SubTest"
    assert SubTest().func == "SubTest"



# Generated at 2022-06-24 03:10:28.136061
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class K1(object):
        def setter(self, x):
            self.__dict__['x'] = x

        x = setterproperty(setter)

    k = K1()
    k.x = 'abc'
    assert k.x == 'abc'


# Generated at 2022-06-24 03:10:36.837212
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    import unittest
    from functools import wraps

    class Meta(type):
        @lazyperclassproperty
        def foo(cls):
            return lambda x:x

    class Test(with_metaclass(Meta)):
        pass

    class Test2(Test):
        pass

    class Test3(Test):
        pass

    class Test4(Test3):
        pass

    class Test5(Test4):
        pass

    class Test6(Test2):
        pass

    class Test7(Test6):
        pass

    class Test8(Test7):
        pass

    class Test9(Test8):
        pass

    class Test10(Test9):
        pass

    class Test11(Test10):
        pass

    class Test12(Test11):
        pass


# Generated at 2022-06-24 03:10:46.060122
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class K(object):

        def __init__(self):
            self.count = 0

        @classproperty
        def predicate(cls):
            return cls.count <= 10

        @setterproperty
        def predicate(self, value):
            self.count = value

        @classproperty
        def pos(cls):
            return cls.count

    k = K()
    assert(k.pos == 0)
    assert(k.predicate is True)
    k.predicate = 5
    assert(k.pos == 5)
    assert(k.predicate is True)
    k.predicate = 15
    assert(k.pos == 15)
    assert(k.predicate is False)


if __name__ == '__main__':
    test_setterproperty()

# Generated at 2022-06-24 03:10:48.001890
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    @roclassproperty
    def foo(cls):
        return 'hello, world'

    assert TestClass.foo == 'hello, world'



# Generated at 2022-06-24 03:10:51.109602
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):

        @setterproperty
        def attr(self, val):
            self._attr = val

    c = C()
    c.attr = 'foo'
    assert c._attr == 'foo'


# Generated at 2022-06-24 03:10:55.262881
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        @roclassproperty
        def bar(cls):
            return 42

        @classproperty
        def baz(cls):
            return 43

    assert Foo.bar == 42
    assert Foo.baz == 43
    with pytest.raises(AttributeError):
        Foo().bar
    with pytest.raises(AttributeError):
        Foo().baz



# Generated at 2022-06-24 03:11:00.088874
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def foo(cls):
            return 'foo value'

    class B(A): pass

    class C(B): pass

    assert A().foo == 'foo value'
    assert B().foo == 'foo value'
    assert C().foo == 'foo value'
    assert A.foo == 'foo value'
    assert B.foo == 'foo value'
    assert C.foo == 'foo value'

# Generated at 2022-06-24 03:11:08.936363
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class ClassProperty(object):
        def __init__(self):
            self.attr1 = 1
        @classproperty
        def attr2(self):
            return 2
        @roclassproperty
        def attr3(self):
            return 3
    obj1 = ClassProperty()

# Generated at 2022-06-24 03:11:11.568717
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def set_message(obj, value):
        obj._message = value
    prop = setterproperty(set_message)
    class A(object):
        message = prop
    a = A()
    a.message = 'Some message'

# Generated at 2022-06-24 03:11:17.187231
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 0
        @setterproperty
        def a(self, value):
            self.a = value
    a = A()
    a.a = 3
    assert a.a == 3

test_setterproperty___set__()

# Generated at 2022-06-24 03:11:19.642859
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        @roclassproperty
        def foo(cls):
            return 'foo'

    a = A()
    assert a.foo == 'foo'



# Generated at 2022-06-24 03:11:25.975479
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def f(self, value):
            self.val = value

        a = setterproperty(f)

    a = A()
    a.a = 3
    assert a.val == 3
    assert A.a.__doc__ == A.f.__doc__

test_setterproperty()

# Generated at 2022-06-24 03:11:30.783138
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo(object):
        _number = 5

        @roclassproperty
        def number(cls):
            return cls._number

    assert Foo.number == 5



# Generated at 2022-06-24 03:11:34.370159
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo:
        def __init__(self):
            self.x = 0

        @setterproperty
        def set_x(self, value):
            self.x = value

    f = Foo()
    f.set_x = 2
    assert f.x == 2



# Generated at 2022-06-24 03:11:40.374812
# Unit test for constructor of class setterproperty
def test_setterproperty():

    teststring = 'stringvalue'

    class TestClass(object):
        def __init__(self):
            self.property = None

        @setterproperty
        def property(self, string):
            self.property = string

    test = TestClass()
    test.property = teststring

    assert test.property == teststring



# Generated at 2022-06-24 03:11:50.321430
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        a = 3
        @roclassproperty
        def b(cls):
            return cls.a + 1
        def __init__(self):
            self.a = 4

    class B(A):
        a = 5

    # A.b --- classproperty.__get__(None, A, A) --- roclassproperty.__get__(None, A, A)
    assert A.b == 5, A.b
    # A().b --- A.b.__get__(A(), A, A)
    assert A().b == 5, A().b

    # B.b --- classproperty.__get__(None, B, B) --- roclassproperty.__get__(None, B, B)
    assert B.b == 6, B.b
    # B().b --- B.b

# Generated at 2022-06-24 03:11:54.295587
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            return 1
    assert hasattr(A, '_lazy_test') is False
    assert A.test == 1
    assert hasattr(A, '_lazy_test') is True

    class B(A):
        pass
    assert B.test == 1
    assert hasattr(A, '_lazy_test') is True
    assert hasattr(B, '_lazy_test') is False
    assert A.test == 1



# Generated at 2022-06-24 03:11:58.871129
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class cls(object):
        @roclassproperty
        def prop(cls):
            return cls
    
    assert cls.prop == cls
    assert cls().prop == cls    # Instance method called and returns class


# Generated at 2022-06-24 03:12:08.137930
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        v = 3

        @roclassproperty
        def myprop(cls):
            return cls.__name__ + '_' + str(cls.v)

    # print 'test_roclassproperty: C.myprop = ', C.myprop  # C_3
    assert C.myprop == 'C_3'
    # print 'test_roclassproperty: C().myprop = ', C().myprop  # C_3
    assert C().myprop == 'C_3'



# Generated at 2022-06-24 03:12:14.156821
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # setup
    class AwesomeObject(object):
        """
        A test object that uses the setterproperty
        """
        def __init__(self):
            self._number = None

        @setterproperty
        def number(self, value):
            """
            The number property
            """
            self._number = value


    obj1 = AwesomeObject()

    expected = 5
    # call the method
    obj1.number = 5
    result = obj1._number

    assert result == expected


# Generated at 2022-06-24 03:12:17.464898
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self, a=1):
            self._a = a
        @setterproperty
        def a(self, value):
            self._a = value
    a = A()
    assert a.a == 1
    a.a = 3
    assert a.a == 3
    assert a._a == 3

# Generated at 2022-06-24 03:12:19.542168
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def Bar(cls):
            return 42

    assert Foo.Bar == 42
    obj = Foo()
    assert Foo.Bar == 42
    assert obj.Bar == 42


# Generated at 2022-06-24 03:12:24.483479
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def p(cls):
            print("p A")
            return 1

    class B(A):
        pass

    class C(A):
        pass

    print(A.p)
    print(B.p)
    print(C.p)
    print(A.p)
    print(B.p)
    print(C.p)
    print(A.p)



# Generated at 2022-06-24 03:12:33.641007
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def name(cls):
            return 'Base'

    class A(Base):
        @lazyperclassproperty
        def name(cls):
            return 'A'

    class B(Base):
        @lazyperclassproperty
        def name(cls):
            return 'B'

    assert Base.name == 'Base'
    assert A.name == 'A'
    assert B.name == 'B'
    assert Base.name == 'Base'
    assert A.name == 'A'
    assert B.name == 'B'



# Generated at 2022-06-24 03:12:39.396438
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A:
        def __init__(self, val):
            self.val = val

    class B(A):
        x = roclassproperty(lambda cls: cls.__name__)

        def __init__(self, val):
            super(B, self).__init__(val)
            self.initval = val

    obj = B(42)
    assert obj.val == 42
    assert obj.initval == 42

    assert obj.x == "B"
    assert B.x == "B"
    assert A.x == "A"


# Generated at 2022-06-24 03:12:43.938471
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:12:48.855476
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    '''
    Test lazyperclassproperty by running tests on its functionality from previous test_lazyclassproperty
    '''
    class A(object):
        @lazyperclassproperty
        def prop(cls):
            print('calling prop')
            return 1

    class B(A):
        @lazyperclassproperty
        def prop(cls):
            print('calling prop')
            return 1

    a1 = A()
    a2 = A()
    b1 = B()
    b2 = B()

    # calculate A.prop
    p = a1.prop
    assert p == 1
    # If a2.prop was not lazy and cached then calling it will print "calling prop"
    p = a2.prop
    # calculate B.prop
    p = b1.prop
    assert p == 1
    #

# Generated at 2022-06-24 03:12:54.859724
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        value = roclassproperty(lambda cls: cls.__name__)
    assert A.value == 'A'
    assert A().value == 'A'
    a = A()
    try:
        a.value = 'b'
    except AttributeError as e:
        return
    assert False, 'Expected an AttributeError'


# Generated at 2022-06-24 03:13:05.927929
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    memories = []
    class MyClass(object):
        def __init__(self, a=2):
            self.a = a

        @lazyclassproperty
        def b(cls):
            memories.append('call')
            return 5
    assert 0 == len(memories)
    assert 5 == MyClass().b
    assert 5 == MyClass.b
    assert 5 == MyClass().b
    assert 5 == MyClass.b
    assert 1 == len(memories)

    memories = []
    class OtherClass(MyClass):
        pass
    assert 0 == len(memories)
    assert 5 == OtherClass().b
    assert 5 == OtherClass.b
    assert 5 == OtherClass().b
    assert 5 == OtherClass.b
    assert 1 == len(memories)

    memories = []

# Generated at 2022-06-24 03:13:07.645525
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        _a = 1

        @roclassproperty
        def a(cls):
            return cls._a

    assert(A.a == 1)



# Generated at 2022-06-24 03:13:16.441875
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    import pytest
    from fickle.cached_property import roclassproperty

    class A:

        count = 0

        @classmethod
        def inc(cls):
            cls.count += 1

        @roclassproperty
        @classmethod
        def test(cls):
            cls.inc()
            return cls.count

    a1 = A()
    a2 = A()

    assert a1.test == 1
    assert a1.test == 1
    assert a1.test == 1
    assert a2.test == 1
    assert a2.test == 1
    assert a2.test == 1
    assert A.test == 1
    assert a1.test == 1
    assert a1.test == 1
    assert a1.test == 1
    assert a2.test == 1
    assert a2

# Generated at 2022-06-24 03:13:20.086548
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:13:24.672740
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def test(cls):
            print("Getting..")
            return 1

    assert A.test is A.test, "Same lazy property value must be reused"
    assert A.test is not A.test, "Separate lazy properties must exist for different classes"



# Generated at 2022-06-24 03:13:27.878939
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Foo(object):
        @setterproperty
        def a(self, value):
            self._a = value
    foo = Foo()
    foo.a = 1
    assert foo._a == 1


# Generated at 2022-06-24 03:13:34.022400
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self._x = None


# Generated at 2022-06-24 03:13:38.056938
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C:
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self, value):
            self._x = value

    c = C()
    c.x = 10
    assert(c._x == 10)

# Generated at 2022-06-24 03:13:42.089768
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, x):
            self._x = x

    a = A(10)
    a.x = 20
    assert a.x == 20



# Generated at 2022-06-24 03:13:45.748399
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def roclassprop(cls):
            return 'read-only class property'

    assert Test.roclassprop == 'read-only class property'
    assert Test().roclassprop == 'read-only class property'

