

# Generated at 2022-06-24 03:03:51.871839
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """Unit test for method __set__ of class setterproperty"""
    class A:
        def f(self, value):
            self._i = value

        rs = setterproperty(f)

    a = A()

    a.rs = 1
    assert a._i == 1



# Generated at 2022-06-24 03:03:58.841707
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # Fixture:
    class Foo(object):
        @setterproperty
        def a(self, value):
            self.a1 = value
            return self.a1
    f = Foo()
    f.a = 3
    assert_true(f.a1 == 3)
    # The setterproperty __set__ method should return a value also
    assert_true(f.a == 3)


# Generated at 2022-06-24 03:04:02.538052
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    '''
    Test method __get__ of class roclassproperty
    '''
    class A(object):
        @roclassproperty
        def test(clazz):
            return clazz

    a = A()
    assert a.test is A


# Generated at 2022-06-24 03:04:06.705949
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        @roclassproperty
        def test(cls):  # cls must be added here
            return "test"

    assert A.test == "test"


# Generated at 2022-06-24 03:04:12.568959
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class myclass(object):
        __doc__ = 'myclass'

        @roclassproperty
        def f(cls):
            return 'myfunction'

    m = myclass()
    assert_equal(myclass.__doc__, 'myclass')
    assert_equal(myclass.f, 'myfunction')
    with assert_raises(AttributeError):
        m.f


# Generated at 2022-06-24 03:04:23.721988
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    global test_setterproperty___set___counter

    test_setterproperty___set___counter = 0

    test_setterproperty___set___obj_in_set1 = None

    def test_setterproperty___set___set1(o, v):
        global test_setterproperty___set___obj_in_set1
        global test_setterproperty___set___counter

        test_setterproperty___set___counter += 1

        test_setterproperty___set___obj_in_set1 = o

        return test_setterproperty___set___counter

    test_setterproperty___set___obj_in_set2 = None

    def test_setterproperty___set___set2(o, v):
        global test_setterproperty___set___obj_in_set1
       

# Generated at 2022-06-24 03:04:27.222522
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class A(object):
        def getx(cls):
            return 1

        x = roclassproperty(getx)

    assert A.x == 1


# Generated at 2022-06-24 03:04:33.159057
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        @setterproperty
        def f(self, value):
            self.value = value
    c = C()
    c.f = 'spam'
    assert c.value == 'spam', c.value


# Generated at 2022-06-24 03:04:40.462971
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def fn(cls):
            return "foo"

    class B(A):
        pass

    class C(B):
        @lazyclassproperty
        def fn(cls):
            return "bar"

    assert A.fn == "foo"
    assert B.fn == "foo"
    assert C.fn == "bar"

    b = B()
    assert b.fn == "foo"

    c = C()
    assert c.fn == "bar"

# Generated at 2022-06-24 03:04:42.960366
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class_ = type('MockClass', (object, ), {'MockProperty': roclassproperty(lambda cls: 'MockValue')})
    class_.MockProperty  # Retrieve property value to invoke __get__ method of roclassproperty class
    pass



# Generated at 2022-06-24 03:04:45.186865
# Unit test for constructor of class setterproperty
def test_setterproperty():
    def set_x(self, arg):
        assert isinstance(self, Foo)
        self._x = arg

    class Foo(object):
        x = setterproperty(set_x)

    foo = Foo()
    foo.x = 10
    assert foo._x == 10



# Generated at 2022-06-24 03:04:51.446606
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Unit test for function lazyperclassproperty.
    """
    class Base(object):
        pass

    class A(Base):
        @lazyperclassproperty
        def foo(cls):
            return 'foo' + cls.__name__

        @lazyperclassproperty
        def bar(cls):
            return 'bar' + cls.__name__

    class B(Base):
        @lazyperclassproperty
        def bar(cls):
            return 'bar' + cls.__name__

        @lazyperclassproperty
        def baz(cls):
            return 'baz' + cls.__name__

    class C(A):
        @lazyperclassproperty
        def baz(cls):
            return 'baz' + cls.__name__


# Generated at 2022-06-24 03:05:00.408406
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    from .typeutils import MutableMapping

    class Test(MutableMapping):
        def __setitem__(self, key, value):
            self.__dict__[key] = value

        def __getitem__(self, key):
            return self.__dict__[key]

        def __iter__(self, key=None):
            return iter(self.__dict__)

        def __len__(self, key=None):
            return len(self.__dict__)

        def __del__(self, key):
            del self.__dict__[key]

    @setterproperty
    def value(self, value):
        self['value'] = value

    test = Test()
    assert test.value == None
    test.value = 'test'
    assert test.value == 'test'

# Generated at 2022-06-24 03:05:02.690830
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def foo(cls):
            return cls.__name__

    assert Foo.foo == 'Foo'



# Generated at 2022-06-24 03:05:07.984259
# Unit test for constructor of class setterproperty
def test_setterproperty():
    # Define a class with instance setter property
    class C(object):
        def __init__(self, x):
            self.x = x

        def getx(self):
            return self.x

        @setterproperty
        def x(self, value):
            self.__dict__["x"] = value

    # Instantiate the class
    c = C(5)
    # Test the class
    c.x = 3
    assert c.getx() == 3
    # Test the type of the attribute to be property
    assert type(c.x) == property
    return



# Generated at 2022-06-24 03:05:14.107990
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:05:17.007341
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo:

        @lazyclassproperty
        def bar(cls):
            print('first time')
            return 42

    assert Foo.bar == 42
    Foo.bar = 24
    assert Foo.bar == 24



# Generated at 2022-06-24 03:05:24.130297
# Unit test for method __get__ of class roclassproperty

# Generated at 2022-06-24 03:05:32.721678
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    # see https://github.com/10degres/alchemist/issues/434
    class Test():
        @setterproperty
        def test_setter_property(self, value):
            self._value = value

    t = Test()
    t.test_setter_property = 'test'

    try:
        assert t._value == 'test'
    except AttributeError:
        raise AssertionError('Attribute _value undefined, __set__ did not work')

# Generated at 2022-06-24 03:05:40.616171
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self._x = None
        @setterproperty
        def x(self, value):
            self._x = value
    c = C()
    c.x = 1
    assert c._x == 1

################################################################################
# ENUM
################################################################################



# Generated at 2022-06-24 03:05:51.052828
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base:
        @lazyperclassproperty
        def dict_property(cls):
            return {}

    class Child(Base):
        pass

    class Child2(Base):
        pass

    assert 'dict_property' not in Base.__dict__
    assert 'dict_property' not in Child.__dict__
    assert 'dict_property' not in Child2.__dict__
    assert Base.dict_property != Child.dict_property != Child2.dict_property
    assert Base.dict_property is Base.dict_property
    assert Child.dict_property is Child.dict_property
    assert Child2.dict_property is Child2.dict_property

    Base.dict_property['a'] = 'A'
    Child.dict_property['a'] = 'B'

# Generated at 2022-06-24 03:05:53.692692
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def set_x(self, n):
            self.x = n

        x = setterproperty(set_x)

    a = A()
    a.x = 2
    assert a.x == a.__dict__['x']



# Generated at 2022-06-24 03:05:58.014605
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        @roclassproperty
        def bar(cls):
            return 'baz'

    assert Foo.bar == 'baz'
    f = Foo()
    assert f.bar == 'baz'



# Generated at 2022-06-24 03:06:04.141566
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def x(cls):
            """a lazy class property"""
            return 42

        @lazyclassproperty
        def y(cls):
            """a lazy class property"""
            return 24

    print(A.x, A.y)
    assert A.x == 42
    assert A.y == 24
    A.x = 24
    assert A.x == 24
    assert A.y == 24



# Generated at 2022-06-24 03:06:10.155168
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:06:13.485373
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class S(object):
        @setterproperty
        def property(self, value):
            self._property = value

        @property
        def property(self):
            return self._property

    s = S()
    s.property = 1
    assert s.property == 1


# Generated at 2022-06-24 03:06:22.430819
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.__num = 0
        @setterproperty
        def num(self, val):
            if val < 0:
                return
            self.__num = val
        @property
        def num(self):
            return self.__num

    t = Test()
    assert t.num == 0
    t.num = 10
    assert t.num == 10

    try:
        t.num = -1
    except Exception as e:
        assert "must be positive" in str(e) or "must be non-negative" in str(e)

# Generated at 2022-06-24 03:06:30.191123
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class B(object):
        def _get_a(self):
            return 1

        def _set_a(self, value):
            self.b = value

        a = setterproperty(_set_a, _get_a)

    b = B()
    b.a = 2
    assert b.b == 2
    assert b.a == 1

    # Unit test for constructor of class lazyclassproperty
    class C(object):
        @lazyclassproperty
        def a(cls):
            return 1

    c = C()
    assert c.a == 1



# Generated at 2022-06-24 03:06:33.423620
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class Foo:
        clsvar = "clsvar"

        @roclassproperty
        def clsmethod(cls):
            return cls.clsvar

    assert Foo().clsmethod == "clsvar"



# Generated at 2022-06-24 03:06:37.496659
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class test_class(object):
        @setterproperty
        def test_property(self, value):
            self.value = value

    test_obj = test_class()
    test_obj.test_property = "hello, world"
    assert test_obj.value == 'hello, world'



# Generated at 2022-06-24 03:06:41.862832
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self.value = 42

        @setterproperty
        def value(self, value):
            self._value = value

        @value.getter
        def value(self):
            return self._value

    assert C().value == 42
    C().value = 1
    assert C().value == 1



# Generated at 2022-06-24 03:06:48.579391
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class Base(object):
        @lazyperclassproperty
        def test(cls):
            return [0 for i in range(10)]

    class A(Base):
        pass

    class B(Base):
        pass

    assert A.test is not B.test
    assert A.test[0] is 0
    assert B.test[0] is 0
    A.test[0] = 1
    assert A.test[0] is 1
    assert B.test[0] is 0



# Generated at 2022-06-24 03:06:51.567537
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def f(cls):
            return 42

        x = roclassproperty(f)

    assert C.x == 42
    try:
        C.x = 24
    except TypeError:
        assert True


# Generated at 2022-06-24 03:06:54.622716
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @roclassproperty
        def test(cls):
            return cls.__name__

    assert Test().test == Test.__name__
    assert Test.test == Test.__name__
    try:
        Test().test = None
    except AttributeError:
        assert True
    else:
        assert False



# Generated at 2022-06-24 03:07:03.082945
# Unit test for function lazyclassproperty
def test_lazyclassproperty():

    class Dummy(object):
        @lazyclassproperty
        def a(cls):
            return 1
        a = lazyclassproperty(a)

        @lazyclassproperty
        def b(cls):
            return 2
        b = lazyclassproperty(b)

    class ChildDummy(Dummy):
        @lazyclassproperty
        def a(cls):
            return 3
        a = lazyclassproperty(a)

    assert Dummy.a == 1
    assert ChildDummy.a == 3
    assert ChildDummy.b == 2



# Generated at 2022-06-24 03:07:10.484486
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Foo(object):
        @lazyperclassproperty
        def bar(cls):
            return "This is bar"

    class FooChild(Foo):
        pass

    assert hasattr(Foo, '_Foo_lazy_bar') is False
    assert hasattr(FooChild, '_FooChild_lazy_bar') is False

    assert Foo.bar == "This is bar"
    assert hasattr(Foo, '_Foo_lazy_bar')
    assert FooChild.bar == "This is bar"
    assert hasattr(FooChild, '_FooChild_lazy_bar')

    # Check that the value is cached
    assert Foo.bar == "This is bar"
    assert FooChild.bar == "This is bar"



# Generated at 2022-06-24 03:07:13.189885
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        def f(cls):
            return 7

        g = roclassproperty(f)

    assert A.g == 7
    assert A().g == 7
    assert A.__dict__['g'] == 7

# Generated at 2022-06-24 03:07:15.567297
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Data(object):
        @lazyclassproperty
        def value(cls):
            return "value"
    d = Data()
    assert d.value == Data.value == "value"



# Generated at 2022-06-24 03:07:23.189801
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Foo(object):
        def __init__(self):
            self.__foo = None

        @setterproperty
        def foo(self, value):
            if value < 0:
                raise AttributeError()
            self.__foo = value

        def __str__(self):
            return str(self.__foo)

    foo = Foo()

# Generated at 2022-06-24 03:07:31.846841
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        @lazyclassproperty
        def foo(self):
            print("Generating foo")
            return 42

        def bar(self):
            print("in bar")
            return self.foo

    print("Before instantiation")
    print(A.__dict__)
    assert not A.__dict__.get('foo')
    assert not A.__dict__.get('_lazy_foo')

    print("Generating instance")
    a = A()
    print(a.__dict__)
    assert a.__dict__.get('_lazy_foo')
    assert a.foo == 42

    print("Direct access to class property")
    assert A.foo == 42

    print("Second instance")
    b = A()
    assert a.__dict__.get('_lazy_foo')

# Generated at 2022-06-24 03:07:38.416317
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    """
    Unit test for class roclassproperty
    """
    class Test(object):
        @roclassproperty
        def x(cls):
            return 5

    assert Test.x == 5
    # Cannot modify var x because it's read-only
    try:
        Test.x = 6
        assert False
    except AttributeError:
        assert True


# Generated at 2022-06-24 03:07:48.271431
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class foo:
        def __init__(self, x,y):
            self.x = x
            self.y = y

    def _get_x(cls):
        return cls.x

    def _get_y(cls):
        return cls.y

    x = roclassproperty(_get_x)
    y = roclassproperty(_get_y)

    foo.x = 1
    foo.y = 2

    if not foo.x==x.__get__(None,foo):
        raise BaseException
    if not foo.y==y.__get__(None,foo):
        raise BaseException



# Generated at 2022-06-24 03:07:57.191099
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    NONE = object()

    class A(object):
        @property
        def a(self):
            return self._a

        @a.setter
        def a(self, value):
            self._a = value

        @roclassproperty
        def b(cls):
            return 'b'

        @property
        def c(self):
            return 'c'

        @c.deleter
        def c(self):
            pass

    a = A()
    a.a = 1
    assert a.a == 1
    with pytest.raises(AttributeError):
        a.b = 2
    assert a.b == 'b'
    with pytest.raises(AttributeError):
        a.c = 3
    assert a.c == 'c'

# Generated at 2022-06-24 03:08:01.778924
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    result = None
    def f(obj, value):
        global result
        result = 123
        return result
        
    sp = setterproperty(f)
    assert sp.__set__(None, 456) == 123
    assert result == 123


# Generated at 2022-06-24 03:08:09.748363
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    """
    Test for lazyperclassproperty
    """
    @add_metaclass(abc.ABCMeta)
    class BaseClass(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @lazyperclassproperty
        def mylazyperclassprop(cls):
            return cls.a + cls.b

    class DerivedClass(BaseClass):
        a = 2
        b = 3

    class AnotherClass(BaseClass):
        a = 5
        b = 7

    assert BaseClass.mylazyperclassprop == 0
    assert DerivedClass.mylazyperclassprop == 2 + 3
    assert AnotherClass.mylazyperclassprop == 5 + 7



# Generated at 2022-06-24 03:08:11.043437
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        def _f(cls):
            return "value"

        p = roclassproperty(_f)

    assert C.p == "value"



# Generated at 2022-06-24 03:08:18.214664
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class testclass(object):
        def __init__(self):
            self.x = 0
        @setterproperty
        def settertest(self, value):
            self.x = value
    a = testclass()
    a.settertest = 3
    assert a.x == 3
    a.settertest = 4
    assert a.x == 4

# Generated at 2022-06-24 03:08:19.221237
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Foo(object):
        pass
    foo = Foo()
    assert foo is not None



# Generated at 2022-06-24 03:08:25.097978
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():

    class ExampleClass(object):
        @lazyperclassproperty
        def testclassprop(cls):
            return cls

    class ExampleSubclass(ExampleClass):
        pass

    assert ExampleClass.testclassprop is ExampleClass
    assert ExampleSubclass.testclassprop is ExampleSubclass



# Generated at 2022-06-24 03:08:36.024964
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Test(object):
        def __init__(self):
            self.a = 5

    def get_a_copy(cls):
        return cls.get_a()

    Test.get_a = lazyperclassproperty(lambda cls: cls().a)
    Test.get_a_copy = lazyperclassproperty(get_a_copy)
    assert Test.get_a == 5
    assert Test.get_a_copy == 5

    class Test_Inherit(Test):
        pass

    assert Test_Inherit.get_a == 5
    assert Test_Inherit.get_a_copy == 5
    assert Test_Inherit.get_a is not Test.get_a
    assert Test_Inherit.get_a_copy is not Test.get_a_copy


# Unit

# Generated at 2022-06-24 03:08:41.317952
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class Test(object):
        def __init__(self):
            self.count = 0

        @setterproperty
        def increment_count(self, value):
            self.count += value

    test = Test()
    test.increment_count = 1
    assert test.count == 1



# Generated at 2022-06-24 03:08:43.298896
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class C(object):
        @roclassproperty
        def foo(cls):
            return 1

    assert C.foo == 1
    assert C().foo == 1



# Generated at 2022-06-24 03:08:49.721154
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A:
        def __init__(self):
            self.a = None

        @setterproperty
        def a(self, value):
            self.a = value

    a = A()
    a.a = 1
    assert a.a == 1, '%s' % repr(a.a)


# Generated at 2022-06-24 03:08:58.338438
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Unit test for method __set__ of class setterproperty
    """
    import lib_util
    import lib_common

    try:
        _CrtMemState = lib_util.CrtMemState
        _CrtMemCheckpoint = lib_util.CrtMemCheckpoint
        _RmPrintRtn = lib_util.RmPrintRtn
        _RmInitTest = lib_util.RmInitTest
        _CrtMemDifference = lib_util.CrtMemDifference
    except:
        # Classes might not be imported, but their global variables are.
        pass

    g_verbose = True

    # Checks the current state of the process's available memory
    def CheckMem():
        stateNow = _CrtMemState()
        noLeaks = _CrtMemCheckpoint(stateNow)

# Generated at 2022-06-24 03:09:03.470836
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class roclassproperty_Test(object): pass
    class roclassproperty_Get(object):
        @roclassproperty
        def value(self):
            return 'value'

    assert isinstance(roclassproperty_Test, roclassproperty_Get)
    assert roclassproperty_Test.value == 'value'
    assert roclassproperty_Get.value == 'value'
    assert roclassproperty_Get().value == 'value'


# Generated at 2022-06-24 03:09:11.026007
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    '''
    This function mainly tests the __get__() function of the roclassproperty class.
    It is a unit test function.
    '''

    class X:
        def fn(self):
            return 'fn'

        f = roclassproperty(fn)

    assert X.fn is not X.f, "Wrong: X.fn is X.f"
    assert X.fn() == X.f()
    # print(X.fn)
    # print(X.f)



# Generated at 2022-06-24 03:09:15.334416
# Unit test for constructor of class setterproperty
def test_setterproperty():

    class Foo(object):

        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, x):
            self._x = x

    foo = Foo(1)

    foo.x = 2

    print(foo._x)


# Generated at 2022-06-24 03:09:20.016284
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:09:28.707418
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    # Test Parent/Child classes
    class TestParent(object):
        @lazyperclassproperty
        def test_lazy_prop(cls):
            print("TestParent test_lazy_prop")
            return 'TestParent'

    class TestChild(TestParent):
        pass

    assert TestParent.test_lazy_prop == 'TestParent'
    assert TestChild.test_lazy_prop == 'TestParent'
    assert TestChild().test_lazy_prop == 'TestParent'

    # Test for multiple calls
    assert TestParent.test_lazy_prop == 'TestParent'
    assert TestChild.test_lazy_prop == 'TestParent'
    assert TestChild().test_lazy_prop == 'TestParent'

    # Test for different instance

# Generated at 2022-06-24 03:09:34.734230
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A:
        def __init__(self, a, b):
            self.a = a
            self.b = b

        @classproperty
        def a_plus_b(cls):
            return cls.a + cls.b


    var_a = A(1, 2)
    assert var_a.a == 1
    assert var_a.b == 2
    assert var_a.a_plus_b == 3


# Generated at 2022-06-24 03:09:44.745961
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        """Class with lazy class property b"""

        @lazyclassproperty
        def b(cls):
            print('Initializing class property b')
            return 1

    class B(A):
        pass

    a = A()
    a.b  # prints: Initializing class property b
    assert a.b == 1, a.b
    A.b
    assert A.b == 1, A.b
    b = B()
    b.b  # prints: Initializing class property b
    assert b.b == 1, b.b
    b.b = 2
    assert b.b == 2, b.b
    assert B.b == 1, B.b
    assert a.b == 1, a.b
    assert A.b == 1, A.b


# Generated at 2022-06-24 03:09:53.770093
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        @lazyperclassproperty
        def test(self):
            print("test A")
            return "test A"

    class B(A):
        @lazyperclassproperty
        def test(self):
            print("test B")
            return "test B"

    class C(A):
        pass

    class D(B):
        pass

    a = A()
    b = B()
    c = C()
    d = D()

    assert hasattr(a, '_A_lazy_test')
    assert hasattr(b, '_B_lazy_test')
    assert not hasattr(a, '_lazy_test')
    assert not hasattr(b, '_lazy_test')
    assert hasattr(c, '_A_lazy_test')


# Generated at 2022-06-24 03:09:56.952095
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C:
        attr = None
        @setterproperty
        def setter(self, value):
            self.attr = value
    obj = C()
    obj.setter = 'value'
    assert obj.attr == 'value'



# Generated at 2022-06-24 03:10:03.749711
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class X(object):
        def __init__(self, val):
            self.x = val
        @roclassproperty
        def m(cls):
            return cls.x
        m = classmethod(m)
    assert X(1).m == X(2).m
    assert X(1).m == 1
    assert X(2).m == 2
    assert X(1).m is X(2).m


# Generated at 2022-06-24 03:10:07.895852
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class X(object):
        def __init__(self):
            self.n = 123

        @setterproperty
        def get_n(self):
            pass

        @get_n.setter
        def get_n(self, n):
            self.n = n

    x = X()
    assert x.n == 123
    x.get_n = 456
    assert x.n == 456



# Generated at 2022-06-24 03:10:14.437302
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def foo(self, value):
            self._foo = value

        @property
        def bar(self):
            return getattr(self, '_bar', None)

    a = A()
    a.foo = 'hello'
    assert a._foo == 'hello'
    a.bar = 'world'
    assert a._bar == 'world'
    a.foo = 'foo'
    assert a._foo == 'foo'
    assert a.foo == 'foo'

# Generated at 2022-06-24 03:10:18.838225
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    def test_func(cls):
        return cls

    class Foo(object):
        __metaclass__ = lazyperclassproperty(test_func)

    class Bar(Foo):
        pass

    assert isinstance(Foo.__metaclass__, type)
    assert isinstance(Bar.__metaclass__, type)



# Generated at 2022-06-24 03:10:21.803445
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        @setterproperty
        def num(self, v):
            """ Testing setterproperty """
            self.__num = v
        """ Testing setterproperty """

    a = A()
    assert_equal(a.num, None)
    a.num = 2
    assert_equal(a.num, None)

# Generated at 2022-06-24 03:10:24.442522
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        @roclassproperty
        def x(self):
            return 1
    a = A()
    a.x
    try:
        a.x = 2
    except AttributeError:
        pass
    A.x
    try:
        A.x = 2
    except AttributeError:
        pass

# Generated at 2022-06-24 03:10:30.183953
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class B(object):
        @roclassproperty
        def x(cls):
            return cls.__name__

    class C(B):
        pass

    assert B.x == 'B'
    assert C.x == 'C'

    assert B().x == 'B'
    assert C().x == 'C'


# Generated at 2022-06-24 03:10:34.785407
# Unit test for constructor of class setterproperty
def test_setterproperty():
    c = setterproperty(str)
    assert c.__doc__ == str.__doc__
    assert c.func == str



# Generated at 2022-06-24 03:10:38.547057
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        a = lazyclassproperty(lambda cls: 1)
    assert A.a == 1

    class B(A):
        pass
    assert B.a == 1

    A.b = lazyclassproperty(lambda cls: 2)
    assert A.b == 2

    class C(A):
        pass
    assert C.b == 2

# Generated at 2022-06-24 03:10:46.123572
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class A(object):
        a = lazyperclassproperty(lambda cls: 'class A')
        b = 1

    class B(A):
        a = lazyperclassproperty(lambda cls: 'class B')
        b = 2

    class C(B):
        a = lazyperclassproperty(lambda cls: 'class C')
        b = 3

    class D(C):
        a = lazyperclassproperty(lambda cls: 'class D')
        b = 4

    assert A.a == 'class A'
    assert A.b == 1
    assert B.a == 'class B'
    assert B.b == 2
    assert C.a == 'class C'
    assert C.b == 3
    assert D.a == 'class D'
    assert D.b == 4


# This automatically creates properties for

# Generated at 2022-06-24 03:10:48.869623
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class s:
        def __init__(self):
            self.a = 0

        @setterproperty
        def a(self, value):
            self.a = value

    t = s()
    t.a = 10
    assert t.a == 10



# Generated at 2022-06-24 03:10:53.780038
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class testClass(object):
        def __init__(self):
             self.prop = 5

        @roclassproperty
        def prop(cls):
            return cls.__name__ + 'abc'

        @classmethod
        def prop2(cls):
            return cls.__name__ + 'abc'


    a = testClass()
    assert a.prop == 'testClassabc'



# Generated at 2022-06-24 03:11:00.223968
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.a = 1
            self.b = 2
            self.c = 3
        a = setterproperty(lambda self, x: setattr(self, "a", x))
        b = setterproperty(lambda self, x: setattr(self, "b", x))
        c = setterproperty(lambda self, x: setattr(self, "c", x))

    c = C()
    c.a = 2
    c.b = 4
    c.c = 6
    assert c.a == 2
    assert c.b == 4
    assert c.c == 6


# Generated at 2022-06-24 03:11:01.643708
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    """ 
    Test method roclassproperty.__get__ 
    """
    pass # TODO: Implementation


# Generated at 2022-06-24 03:11:04.210149
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test case for method __set__ of class setterproperty
    """
    @setterproperty
    def f(self, value):
        self._v = value

    o = object()
    o.f = 5

    if not hasattr(o, '_v'):
        fail()



# Generated at 2022-06-24 03:11:07.045955
# Unit test for function lazyclassproperty

# Generated at 2022-06-24 03:11:12.846789
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class foo(object):
        @lazyclassproperty
        def foo(cls):
            return cls.__name__


# Generated at 2022-06-24 03:11:16.652864
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        value = roclassproperty(lambda clazz: clazz.__name__)


# Generated at 2022-06-24 03:11:23.534019
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    """
    Test for method __set__.
    """
    class DummyFoo(object):
        def __init__(self, d=2):
            self.d = d

        @setterproperty
        def x(self, value):
            self.d = value

        def test_x(self, value):
            x = value
            self.x = x

    a = DummyFoo()
    a.test_x(3)
    a.x = 5
    assert a.d == 5, a.d



# Generated at 2022-06-24 03:11:26.773171
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A(object):
        def __init__(self):
            self.value = None

        @setterproperty
        def add(self, x):
            return self.value + x

    a = A()
    a.value = 3
    a.add = 2
    assert a.value == 2
    try:
        print(a.add)
    except AttributeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 03:11:33.902606
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    lcp = lazyclassproperty(lambda cls: [])
    class A:
        lcp = lcp
    a = A()
    b = A()
    assert a.lcp is a.lcp
    assert a.lcp is b.lcp
    assert id(a.lcp) == id(b.lcp)
    assert a.lcp is not A.lcp



# Generated at 2022-06-24 03:11:39.363267
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            pass

        def set_value(self, value):
            self.value = value

        x = setterproperty(set_value)

    a = A()
    a.x = 5
    assert a.value == 5

# Generated at 2022-06-24 03:11:43.254273
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return "bar"

    assert Foo.bar == "bar"



# Generated at 2022-06-24 03:11:49.959135
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):

        def __init__(self):
            self.name = 'name'
            self.num = 1

        @roclassproperty
        def name(self):
            return self.name

        @roclassproperty
        def num(self):
            return self.num

    t = Test()
    print(t.num)
    t.num = 2
    print(t.num)


# Generated at 2022-06-24 03:11:51.892966
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class TestClass(object):
        @lazyperclassproperty
        def prop(cls):
            return cls.__name__

    class TestSubClass(TestClass):
        pass

    assert TestClass.prop == TestSubClass.prop == TestSubClass().prop == 'TestSubClass'

# Generated at 2022-06-24 03:12:01.262001
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class SampleClass(object):
        class _ValueWrapper(object):
            def __init__(self,value):
                self.value = value
            def __repr__(self):
                return '<ValueWrapper: {!r}>'.format(self.value)
        sample_value = None
        @setterproperty
        def value(self,value):
            self.sample_value = self._ValueWrapper(value)
        @setterproperty
        def value_and_return(self,value):
            self.sample_value = self._ValueWrapper(value)
            return value
        @setterproperty
        def value_in_upper_case(self,value):
            self.sample_value = self._ValueWrapper(value)
            return value.upper()
    o = SampleClass()
    o.value

# Generated at 2022-06-24 03:12:05.609990
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class X:
        def __init__(self):
            self.a = 1
        @roclassproperty
        def a(cls):
            return 2
    obj = X()
    assert obj.a == 1


# Generated at 2022-06-24 03:12:10.629034
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class test(object):
        def __init__(self):
            self.a = 4

        @roclassproperty
        def a(self):
            return 100

        @setterproperty
        def a(self, value):
            self.a = value

    t = test()
    assert t.a == 100

    t.a = 10

    assert t.a == 100

# Generated at 2022-06-24 03:12:13.206328
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class A:
        @setterproperty
        def f(self, value):
            self._f = value
    a = A()
    a.f = 'hello'
    assert a._f == 'hello'

# Generated at 2022-06-24 03:12:17.662445
# Unit test for function lazyperclassproperty

# Generated at 2022-06-24 03:12:19.605298
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self, x):
            self._x = x

        @setterproperty
        def x(self, value):
            self._x = value

    assert C(4)._x == 4
    C(5).x = 6
    assert C(5)._x == 6



# Generated at 2022-06-24 03:12:23.179061
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class foo(object):
        def __init__(self):
            self.k = 42
        @setterproperty
        def p(self, v):
            self.k = v

    obj = foo()
    assert obj.k == 42
    obj.p = 13
    assert obj.k == 13



# Generated at 2022-06-24 03:12:31.232547
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self._x = None
            self._init = False
            self._set_x = None

        @setterproperty
        def x(self, x):
            print('Updating value for x')
            self._x = x
            self._set_x = x
            self._init = True

        def f(self):
            return self._init

    c = C()
    assert c._x is None
    assert c._set_x is None
    assert not c.f()
    c.x = 1
    assert c._x == c._set_x
    assert c._x == 1
    assert c._set_x == 1
    assert c.f()



# Generated at 2022-06-24 03:12:38.769147
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():

	class TestClass(object):
		@roclassproperty
		def test_roclassproperty(cls):
			if not hasattr(cls, '_test_roclassproperty_attr'):
				setattr(cls, '_test_roclassproperty_attr', [])
			return getattr(cls, '_test_roclassproperty_attr')

	assert TestClass.test_roclassproperty is TestClass.test_roclassproperty

# Generated at 2022-06-24 03:12:41.869357
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class Foo(object):
        @lazyclassproperty
        def bar(cls):
            return 'baz'
    assert Foo.bar == 'baz'



# Generated at 2022-06-24 03:12:48.194046
# Unit test for function lazyclassproperty
def test_lazyclassproperty():
    class A(object):
        # Normal class property
        @classproperty
        def cp1(cls):
            """class property"""
            return 1

        # Lazy class property
        @lazyclassproperty
        def cp2(cls):
            """class property"""
            return 1

    class B(A):
        pass

    class C(B):
        pass

    assert A.cp1 == 1
    assert B.cp1 == 1
    assert C.cp1 == 1
    A.cp1 = 2
    assert A.cp1 == 2
    assert B.cp1 == 2
    assert C.cp1 == 2

    assert A.cp2 == 1
    assert B.cp2 == 1
    assert C.cp2 == 1
    A.cp2 = 2
    assert A.cp2 == 2
    assert B

# Generated at 2022-06-24 03:12:58.919413
# Unit test for constructor of class roclassproperty
def test_roclassproperty():
    class Test(object):
        @classproperty
        def get_prop(cls):
            return cls

        @roclassproperty
        def get_roprop(cls):
            return cls

    test_obj = Test()
    print("get_prop.f is {}".format(Test.get_prop.f))
    Test.get_prop.f = Test
    print("get_prop.f is {}".format(Test.get_prop.f))
    print("Test.get_prop = {}".format(Test.get_prop))
    print("test_obj.get_prop = {}".format(test_obj.get_prop))

    print("Test.get_roprop.f is {}".format(Test.get_roprop.f))
    # Test.get_roprop.f = Test
    # print("

# Generated at 2022-06-24 03:13:06.712190
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Bar(object):
        def __init__(self):
            self.stuff = []

        @setterproperty
        def foo(self, value):
            self.stuff.append(value)

    b = Bar()
    b.foo = 'bar'
    assert b.stuff == ['bar'], b.stuff
    b.foo = 'bazz!'
    assert b.stuff == ['bar', 'bazz!'], b.stuff


# Generated at 2022-06-24 03:13:11.316844
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class Cls(object):
        def __init__(self):
            self._s = 0

        @setterproperty
        def s(self, x):
            self._s = x*x

        def get_s(self):
            return self._s

    c = Cls()
    c.s = 4
    assert c.get_s() == 16



# Generated at 2022-06-24 03:13:16.743744
# Unit test for constructor of class roclassproperty

# Generated at 2022-06-24 03:13:24.084404
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.__x = 0

        def get_x(self):
            return self.__x

        def set_x(self, value):
            self.__x = value

        x = setterproperty(set_x, "I'm the 'x' property.")

    a = A()
    assert a.get_x() == 0
    a.x = 42
    assert a.get_x() == 42



# Generated at 2022-06-24 03:13:28.923114
# Unit test for constructor of class setterproperty
def test_setterproperty():
    class C(object):
        def __init__(self):
            self.value = 0

        @setterproperty
        def prop(self, newvalue):
            if newvalue < 0:
                raise ValueError
            self.value = newvalue

    x = C()
    assert x.value == 0
    x.prop = 1
    assert x.value == 1



# Generated at 2022-06-24 03:13:33.541722
# Unit test for function lazyperclassproperty
def test_lazyperclassproperty():
    class Base(object):
        @lazyperclassproperty
        def lazyprop(cls):
            return cls.__name__

    class A(Base):
        pass

    class B(Base):
        pass

    assert A.lazyprop == 'A'
    assert B.lazyprop == 'B'
    assert Base.lazyprop == 'Base'

    # make sure that we have lazyprop only in the classes
    assert 'lazyprop' not in set(dir(Base()))
    assert 'lazyprop' not in set(dir(A()))
    assert 'lazyprop' not in set(dir(B()))

    # make sure that we do not override existing instant attribute
    class C(Base):
        lazyprop = 'dummy'

    assert C.lazyprop == 'dummy'
    assert Base

# Generated at 2022-06-24 03:13:37.385332
# Unit test for method __get__ of class roclassproperty
def test_roclassproperty___get__():
    class A(object):
        _a = 1
        @roclassproperty
        def a(cls):
            return cls._a
    assert A.a == 1
    with pytest.raises(AttributeError):
        A.a = 2

# Generated at 2022-06-24 03:13:40.858345
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class A(object):
        def __init__(self):
            self.a = 1
        @setterproperty
        def a(self, value):
            self.a = value
            return self.a

    a = A()
    assert a.a == 1
    a.a = 10
    assert a.a == 1

# Generated at 2022-06-24 03:13:45.870659
# Unit test for method __set__ of class setterproperty
def test_setterproperty___set__():
    class C(object):
        def __init__(self):
            self.x = None

        @setterproperty
        def setter(self, value):
            self.x = value

    assert C().setter is None
    i = C()
    i.setter = 4
    assert i.x == 4
    i.setter = 'four'
    assert i.x == 'four'