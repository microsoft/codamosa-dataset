

# Generated at 2022-06-18 07:07:37.333282
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_root
    from .rules.git import _get_git_command
    from .rules.git import _get_git_command_args
    from .rules.git import _get_git_command_args_str
    from .rules.git import _get_git_command_str
    from .rules.git import _get_git_command_str_with_args
    from .rules.git import _get_git_command_str_with_args_and_root
    from .rules.git import _get_git_command_str_with_args_and_root_and_side_effect

# Generated at 2022-06-18 07:07:42.590091
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:45.702269
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell(), 'ls', 'ls -a'))
    show_corrected_command(CorrectedCommand(Shell(), 'ls', 'ls -a', True))

# Generated at 2022-06-18 07:07:46.573998
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:50.280738
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:07:55.866582
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.java import match, get_new_command
    from .rules.gcc import match, get_new_command
    from .rules.go import match, get_new_command
    from .rules.cargo import match, get

# Generated at 2022-06-18 07:08:00.484175
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:08:04.521247
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    configuration_details = Shell.from_shell(get_closest('bash')).get_aliases()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:08:15.713377
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:08:17.186956
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:22.349681
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al'))
    show_corrected_command(Command('ls', 'ls -al', True))


# Generated at 2022-06-18 07:08:26.692791
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from . import const
    from .conf import settings
    from . import __version__
    import sys
    import os
    import tempfile

    def get_configuration_details(shell):
        return Shell(shell, get_closest(shell, settings.priority),
                     get_alias(shell)).get_command()

    def get_shell_info(shell):
        return Shell(shell, get_closest(shell, settings.priority),
                     get_alias(shell)).get_shell_info()

    def get_python_version():
        return '{}.{}.{}'.format(*sys.version_info)

    def get_thefuck_version():
        return __version__


# Generated at 2022-06-18 07:08:28.638301
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:08:30.727729
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:42.227553
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    import sys
    import io
    sys.stderr = io.StringIO()
    confirm_text(CorrectedCommand('ls', 'ls -a', '', Shell()))

# Generated at 2022-06-18 07:08:43.165040
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:51.055432
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import side_effect
    from thefuck.rules.git_push import enabled_by_default

    with wrap_settings(no_colors=True):
        confirm_text(Command('git push', 'git push', 'git push',
                             side_effect=side_effect))
        confirm_text(Command('git push', 'git push', 'git push',
                             side_effect=side_effect,
                             script='git push -f'))

# Generated at 2022-06-18 07:08:54.397308
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand(
        'ls', 'ls -a', Shell('bash', '', '')))



# Generated at 2022-06-18 07:08:58.814102
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .types import Command

    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls -a')
    shell = Shell('', '', '', '', '', '', '', '')
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:09:02.796258
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))


# Generated at 2022-06-18 07:09:09.433408
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:09:13.779803
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from . import utils
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        utils.confirm_text(utils.CorrectedCommand('ls', False))
        assert mock_stderr.getvalue() == '{}ls [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:09:16.124787
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:25.655917
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand

# Generated at 2022-06-18 07:09:27.643120
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:28.592291
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:32.925107
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:36.951996
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))


# Generated at 2022-06-18 07:09:40.278856
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -G'))
    show_corrected_command(CorrectedCommand('ls', 'ls -G', True))


# Generated at 2022-06-18 07:09:41.779347
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:46.313189
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:48.585037
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'



# Generated at 2022-06-18 07:09:59.591268
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:10:00.163882
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:10:02.664192
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:10:06.758077
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('msg'):
            pass
        debug.assert_called_once_with(
            u'msg took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:07.802306
# Unit test for function debug
def test_debug():
    assert debug('test') == None


# Generated at 2022-06-18 07:10:08.762607
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:10.046186
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=u'ls') == u'ls'

# Generated at 2022-06-18 07:10:15.489367
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    with patch('sys.stderr', new=open('/dev/null', 'w')):
        confirm_text(Shell().from_shell('ls', 'ls', '', '', '', ''))

# Generated at 2022-06-18 07:10:21.533692
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:10:27.607630
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        debug('test')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        settings.debug = True
        debug('test')
        assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:10:28.885527
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:33.633667
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with('foo\n')

# Generated at 2022-06-18 07:10:34.909063
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:41.157938
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:42.841474
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:44.124615
# Unit test for function debug
def test_debug():
    from . import debug
    debug('test')

# Generated at 2022-06-18 07:10:47.556680
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:50.084561
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:55.179055
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:10:59.169016
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .utils import get_closest

    command = Command('ls', 'ls')
    corrected_command = get_closest(command, 'git')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '$ git\n'



# Generated at 2022-06-18 07:11:06.271928
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    out = StringIO()
    sys.stderr = out
    confirm_text('ls')
    output = out.getvalue().strip()
    assert output == '>ls [enter/↑/↓/ctrl+c]'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:11:15.282230
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .types import ConfigurationDetails
    from .utils import get_closest
    from . import const
    from .conf import settings
    settings.no_colors = False
    settings.debug = False
    shell = Shell('bash', 'bash', 'bash', 'bash', 'bash')
    configuration_details = ConfigurationDetails(
        '~/.bashrc',
        'source ~/.bashrc',
        'echo "eval $(thefuck --alias)" >> ~/.bashrc',
        True)
    how_to_configure_alias(configuration_details)
    assert get_closest(shell.get_alias(), 'fuck') == 'fuck'
    assert get_closest(shell.get_alias(), 'fuck') == 'fuck'

# Generated at 2022-06-18 07:11:25.129035
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .utils import get_closest
    from .command import Command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.cd import match, get_new_command
    from .rules.ls import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.default import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.brew import match, get_new_command

# Generated at 2022-06-18 07:11:35.108637
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        confirm_text('ls')
    output = out.getvalue().strip()
    assert output == 'ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:11:36.448062
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:11:40.107794
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:11:42.775575
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))


# Generated at 2022-06-18 07:11:44.682237
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:11:51.338530
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    shell.from_shell('echo "test"')
    corrected_command = CorrectedCommand('echo "test"', 'echo "test"', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:55.731586
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:57.574634
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la'))


# Generated at 2022-06-18 07:11:59.548387
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:03.113345
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))



# Generated at 2022-06-18 07:12:14.213255
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:00\n')

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:00\n')


# Generated at 2022-06-18 07:12:17.957127
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:21.205390
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:27.344720
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:30.248186
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:40.276298
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:12:42.808923
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:12:43.614114
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:48.332630
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=True,
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc'))

# Generated at 2022-06-18 07:12:53.971500
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:03.580585
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        settings.debug = True
        debug('test')
        assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'



# Generated at 2022-06-18 07:13:06.400669
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:14.679718
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_command_names
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_name_from_alias
    from .rules.git import _get_git_command_name_from_alias_or_name
    from .rules.git import _get_git_command_name_from_alias_or_name_or_path
    from .rules.git import _get_git_command_name_from_alias_or_name_or_path_or_none

# Generated at 2022-06-18 07:13:15.185989
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:13:20.637783
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:27.154124
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:13:30.302747
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:35.063388
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    from .utils import confirm_text
    settings.no_colors = False
    confirm_text(const.CorrectedCommand(u'ls', False))
    settings.no_colors = True
    confirm_text(const.CorrectedCommand(u'ls', False))

# Generated at 2022-06-18 07:13:43.884471
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:13:49.822920
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=True):
        assert confirm_text(Command('ls', '', '')) == \
            '>ls [enter/↑/↓/ctrl+c]'
        assert confirm_text(Command('ls', '', '', side_effect=True)) == \
            '>ls (+side effect) [enter/↑/↓/ctrl+c]'
        assert confirm_text(Command('ls', '', '')) == \
            '>ls [enter/↑/↓/ctrl+c]'
        assert confirm_text(Command('ls', '', '', side_effect=True)) == \
            '>ls (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:14:00.522708
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .rules.bash import BashRule
    from .rules.git import GitRule
    from .rules.python import PythonRule
    from .rules.man import ManRule
    from .rules.pip import PipRule
    from .rules.ruby import RubyRule
    from .rules.perl import PerlRule
    from .rules.node import NodeRule
    from .rules.haskell import HaskellRule
    from .rules.java import JavaRule
    from .rules.go import GoRule
    from .rules.php import PhpRule
    from .rules.docker import DockerRule
    from .rules.docker_compose import DockerComposeRule
    from .rules.vagrant import VagrantRule
    from .rules.systemctl import SystemctlRule
    from .rules.systemd import System

# Generated at 2022-06-18 07:14:04.415444
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))



# Generated at 2022-06-18 07:14:07.865705
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:14:19.118576
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', None))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', 'side effect'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', ''))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', ' '))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', '  '))

# Generated at 2022-06-18 07:14:22.008470
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:14:27.965707
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:14:37.241725
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=False))


# Generated at 2022-06-18 07:14:38.178043
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:43.798587
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:14:46.322433
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:14:51.229242
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:14:59.735219
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path=u'~/.bashrc',
            content=u'eval $(thefuck --alias)',
            reload=u'source ~/.bashrc',
            can_configure_automatically=False))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path=u'~/.bashrc',
            content=u'eval $(thefuck --alias)',
            reload=u'source ~/.bashrc',
            can_configure_automatically=True))

# Generated at 2022-06-18 07:15:01.700037
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True



# Generated at 2022-06-18 07:15:06.186331
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('msg'):
            pass
        debug.assert_called_once_with(
            u'msg took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:15:07.050817
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:15:22.867717
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:15:23.366131
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:15:24.044437
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:15:25.316400
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:28.105853
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:30.986557
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:15:37.648483
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:15:42.018943
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:15:50.567191
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')

# Generated at 2022-06-18 07:15:54.999623
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:09.130112
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from .const import CONFIG_FILE_PATH
    from . import __version__
    import os
    import tempfile
    import shutil
    import sys
    import io

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()
    # Create the temporary file
    temp_file = os.path.join(temp_dir, CONFIG_FILE_PATH)
    # Create a temporary shell
    temp_shell = Shell('temp', temp_file, 'temp', 'temp', 'temp')
    # Create a temporary configuration

# Generated at 2022-06-18 07:16:16.124429
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:16:22.585138
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    from thefuck.utils import settings
    settings.no_colors = True
    confirm_text(CorrectedCommand('ls', 'ls -a', 'ls -a', Shell('', '')))
    settings.no_colors = False
    confirm_text(CorrectedCommand('ls', 'ls -a', 'ls -a', Shell('', '')))

# Generated at 2022-06-18 07:16:27.261580
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} test\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:16:33.161585
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_closest_executable
    from .const import CONFIGURATION_FILES
    from .conf import Config
    from .types import ConfigurationDetails
    from .utils import get_closest_executable
    from .shells import Shell
    from .types import ConfigurationDetails
    from .utils import get_closest, get_closest_executable
    from .const import CONFIGURATION_FILES
    from .conf import Config
    from .types import ConfigurationDetails
    from .utils import get_closest_executable
    from .shells import Shell
    from .types import ConfigurationDetails
    from .utils import get_closest, get_closest_executable
    from .const import CONFIGURATION_FILES

# Generated at 2022-06-18 07:16:35.557798
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:37.823353
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:16:41.629725
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:50.836442
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import __version__

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:16:54.960182
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:17:00.751285
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:17:01.976644
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:07.811885
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:17:10.863695
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:17:17.239372
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(corrected_command='ls -la')
    assert sys.stderr.getvalue() == u'{prefix}ls -la [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:17:18.117988
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:21.243959
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:17:24.161474
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))