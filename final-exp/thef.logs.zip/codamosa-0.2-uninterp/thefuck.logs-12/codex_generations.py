

# Generated at 2022-06-18 07:07:33.719900
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:38.014925
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))


# Generated at 2022-06-18 07:07:40.641363
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:07:43.085881
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called

# Generated at 2022-06-18 07:07:46.469430
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:07:48.284452
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-18 07:07:49.453778
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:07:54.965483
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:59.680408
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')

    assert out.getvalue() == ''
    assert err.getvalue() == ''


# Generated at 2022-06-18 07:08:01.799143
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', False))



# Generated at 2022-06-18 07:08:07.636439
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:11.650672
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls -la')
    assert sys.stderr.getvalue() == '$ ls -la [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:08:22.350040
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    shell = Shell()
    shell.from_shell('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')
    shell.history.append('echo "fuck"')

# Generated at 2022-06-18 07:08:23.648499
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand(script='ls', side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:28.638312
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    import os
    import tempfile
    import shutil


# Generated at 2022-06-18 07:08:39.470010
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .utils import wrap_text
    from .types import CorrectedCommand
    from .conf import settings
    settings.no_colors = False
    settings.side_effect_free = False
    settings.debug = False
    settings.wait_command = False
    settings.require_confirmation = False
    settings.exclude_rules = []
    settings.priority = []
    settings.alias = 'fuck'
    settings.wait_slow_command = 0
    settings.slow_commands = []
    settings.no_colors = False
    settings.wait_command = False
    settings.require_confirmation = False
    settings.exclude_rules = []
    settings.priority = []
    settings.alias = 'fuck'
    settings.wait_slow_command = 0
    settings.slow_commands

# Generated at 2022-06-18 07:08:40.922641
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:44.750656
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:47.046071
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('bash')))


# Generated at 2022-06-18 07:08:49.835388
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:56.961375
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:09:07.162546
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import tempfile
    import shutil
    import subprocess
    import sys
    import time

    def run_script(script):
        with tempfile.NamedTemporaryFile(delete=False) as script_file:
            script_file.write(script)
            script_file.flush()
            os.fsync(script_file.fileno())
            return subprocess.check_output(['bash', script_file.name])


# Generated at 2022-06-18 07:09:10.650240
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:09:12.004904
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:09:14.154446
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:09:15.685607
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:25.320014
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    import sys
    from io import StringIO
    from unittest.mock import patch

    with patch.object(sys, 'stderr', StringIO()) as mock_stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:09:27.021298
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:27.893381
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:35.149464
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:09:38.700233
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:39.622725
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:51.132532
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(object())

# Generated at 2022-06-18 07:09:52.443146
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:09:54.112209
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:10:04.203490
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell

    shell = Shell()
    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls -a', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a\n'.format(const.USER_COMMAND_MARK)

    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls -a', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a (+side effect)\n'.format(const.USER_COMMAND_MARK)

    sys.stderr.truncate(0)
   

# Generated at 2022-06-18 07:10:07.495559
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with('foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:10:12.945653
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass

        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:23.265987
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime
    from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''


# Generated at 2022-06-18 07:10:24.882259
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))



# Generated at 2022-06-18 07:10:39.258326
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')
    confirm_text('ls -la')
    confirm_text('ls -la | grep')
    confirm_text('ls -la | grep -i')
    confirm_text('ls -la | grep -i | wc -l')
    confirm_text('ls -la | grep -i | wc -l | sort')
    confirm_text('ls -la | grep -i | wc -l | sort -r')
    confirm_text('ls -la | grep -i | wc -l | sort -r | uniq')
    confirm_text('ls -la | grep -i | wc -l | sort -r | uniq | head')

# Generated at 2022-06-18 07:10:42.663388
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:43.925078
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:45.422982
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:48.881554
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(True)
    how_to_configure_alias(False)

# Generated at 2022-06-18 07:10:50.218012
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:59.239109
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    import os
    import tempfile
    import shutil
    import sys
    import io
    import unittest
    import mock

    class TestHowToConfigureAlias(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.old_home = os.environ['HOME']
            os.environ['HOME'] = self.tempdir
            self.old_stdout = sys.stdout
            sys.stdout = io.BytesIO()

        def tearDown(self):
            shutil.rmtree(self.tempdir)
            os.environ['HOME'] = self.old_home
           

# Generated at 2022-06-18 07:11:10.977669
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(corrected_command=None)

# Generated at 2022-06-18 07:11:14.907996
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:11:24.804901
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr', new_callable=lambda: sys.stderr):
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', False))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', True))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', False))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', True))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', False))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', True))
        confirm_text(CorrectedCommand('ls', 'ls', 'ls', False))

# Generated at 2022-06-18 07:11:33.577551
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('/dev/null', 'w')
    confirm_text(const.CorrectedCommand('ls', False))
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:11:36.165628
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''
    settings.no_colors = False
    assert color('') == ''

# Generated at 2022-06-18 07:11:37.568762
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass

# Generated at 2022-06-18 07:11:43.872585
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to_configure_alias(None)
    how_to

# Generated at 2022-06-18 07:11:48.221285
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:58.815267
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:12:00.771188
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''



# Generated at 2022-06-18 07:12:01.796001
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:06.587508
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as mock_debug:
        with log.debug_time('test'):
            pass
        mock_debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:09.684902
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:16.428498
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:12:27.556068
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:12:37.214848
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('')
    how_to_configure_alias('test')
    how_to_configure_alias(True)
    how_to_configure_alias(False)
    how_to_configure_alias(1)
    how_to_configure_alias(0)
    how_to_configure_alias(0.1)
    how_to_configure_alias(0.0)
    how_to_configure_alias(1.0)
    how_to_configure_alias(1.1)
    how_to_configure_alias(['test'])
    how_to_configure_alias(['test', 'test'])

# Generated at 2022-06-18 07:12:39.246409
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:12:44.660734
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:12:48.894174
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:59.526334
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = True
    from . import const
    from .types import CorrectedCommand
    corrected_command = CorrectedCommand(script='ls', side_effect=False)
    confirm_text(corrected_command)
    assert sys.stderr.getvalue() == (
        u'{prefix}{clear}{script} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
        u'/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            script=corrected_command.script,
            clear='\033[1K\r',
            green='',
            red='',
            reset='',
            blue=''))
    sys.stderr.trunc

# Generated at 2022-06-18 07:13:08.424617
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:13:09.571744
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:16.593012
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const

    configuration_details = Configuration(
        shell_type=Shell.BASH,
        can_configure_automatically=True,
        reload='source ~/.bashrc',
        path='~/.bashrc',
        content='eval $(thefuck --alias)')

    how_to_configure_alias(configuration_details)

    configuration_details = Configuration(
        shell_type=Shell.ZSH,
        can_configure_automatically=True,
        reload='source ~/.zshrc',
        path='~/.zshrc',
        content='eval $(thefuck --alias)')

    how_to_configure_alias(configuration_details)


# Generated at 2022-06-18 07:13:25.251048
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:26.773381
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:13:29.580170
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:13:32.126455
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:13:37.013954
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:39.012459
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:13:47.182067
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.virtualenv import virtualenv_rule
    from .rules.yarn import yarn_rule
    from .rules.npm import npm_rule
    from .rules.nvm import nvm_rule
    from .rules.gcloud import gcloud_rule
    from .rules.docker import docker_rule
    from .rules.docker_compose import docker_compose_rule
    from .rules.docker_machine import docker_machine_rule
    from .rules.kubectl import kubectl_rule

# Generated at 2022-06-18 07:13:50.731451
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:52.155031
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:56.394382
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:09.454855
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_closest_executable
    from .conf import ConfigurationDetails
    from . import const
    import os
    import tempfile
    import shutil
    import sys

    def get_shell_info():
        return u'{} {}'.format(get_closest_executable(
            get_closest(Shell, 'name', os.environ['SHELL'])),
            sys.version.split()[0])


# Generated at 2022-06-18 07:14:10.838656
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:16.198028
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:27.185509
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from . import const

    corrected_command = CorrectedCommand(
        script=u'ls',
        side_effect=False)

    show_corrected_command(corrected_command)

    assert sys.stderr.getvalue() == (
        u'{prefix}{script}\n'.format(
            prefix=const.USER_COMMAND_MARK,
            script=corrected_command.script))

    corrected_command = CorrectedCommand(
        script=u'ls',
        side_effect=True)

    show_corrected_command(corrected_command)


# Generated at 2022-06-18 07:14:29.518989
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:14:31.440487
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:32.443681
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:33.997589
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:35.196299
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:14:43.796964
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:14:51.404724
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:56.552706
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:14:57.767388
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')

# Generated at 2022-06-18 07:14:58.677994
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:05.400394
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_commands_names
    from .rules.git import _get_git_commands_names_set
    from .rules.git import _get_git_commands_names_set_lower
    from .rules.git import _get_git_commands_names_set_upper
    from .rules.git import _get_git_commands_names_set_title
    from .rules.git import _get_git_commands_names_set_swapcase
    from .rules.git import _get_git_commands_names_set_replace
    from .rules.git import _get

# Generated at 2022-06-18 07:15:14.668241
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True

# Generated at 2022-06-18 07:15:15.627562
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:17.549952
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:15:22.359660
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:29.692350
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text(corrected_command='ls -l')
    confirm_text

# Generated at 2022-06-18 07:15:37.868001
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = False
    assert confirm_text(None) == None
    settings.no_colors = True
    assert confirm_text(None) == None

# Generated at 2022-06-18 07:15:40.036937
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))


# Generated at 2022-06-18 07:15:49.211678
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
        assert out.getvalue() == ''

# Generated at 2022-06-18 07:15:49.978660
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:51.855907
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:54.853934
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:04.377065
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __python_version__
    from . import __shells__
    from . import __shells_configs__

    shell_name = get_closest(__shells__, 'bash')
    shell = Shell(shell_name, __shells_configs__[shell_name])
    alias = get_alias(shell)

# Generated at 2022-06-18 07:16:05.418640
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:07.728550
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:16:16.276648
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:16:23.418621
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:28.481836
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:16:29.223252
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:35.558516
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:16:45.583567
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:16:52.932268
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:16:53.895474
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:58.190843
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:17:10.216649
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from .conf import settings
    settings.no_colors = True
    settings.debug = False
    settings.require_confirmation = False
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.slow_commands = []
    settings.exclude_rules = []
    settings.priority = {}
    settings.alias = 'fuck'
    settings.env = {}
    settings.exclude_commands = []
    settings.include_commands = []
    settings.rules = []
    settings.wait_slow_command = 0
    settings.wait_command = 0
    settings.no_colors = False
    settings.require_

# Generated at 2022-06-18 07:17:12.753894
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls', False))

# Generated at 2022-06-18 07:17:19.242661
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None


# Generated at 2022-06-18 07:17:22.448740
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:17:24.352543
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:17:31.420918
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_with_colorama
    from . import const

    class FakeShell(Shell):
        @property
        def name(self):
            return 'fake'

        @property
        def path(self):
            return 'fake'

        @property
        def history_file(self):
            return 'fake'

        @property
        def history_length(self):
            return 'fake'

        @property
        def alias(self):
            return 'fake'

        @property
        def app_alias(self):
            return 'fake'

        @property
        def prefix(self):
            return 'fake'

        @property
        def suffix(self):
            return 'fake'
