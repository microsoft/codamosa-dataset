

# Generated at 2022-06-18 07:07:33.187087
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:37.442300
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand

    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:07:47.614481
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')
    confirm_text('ls -la')
    confirm_text('ls -la | grep')
    confirm_text('ls -la | grep -i')
    confirm_text('ls -la | grep -i | wc -l')
    confirm_text('ls -la | grep -i | wc -l | cat')
    confirm_text('ls -la | grep -i | wc -l | cat | grep')
    confirm_text('ls -la | grep -i | wc -l | cat | grep -i')
    confirm_text('ls -la | grep -i | wc -l | cat | grep -i | wc -l')

# Generated at 2022-06-18 07:07:52.125182
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:03.023292
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __file__ as thefuck_path
    from . import __main__ as thefuck_main
    from . import __doc__ as thefuck_doc
    from . import __name__ as thefuck_name
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import re
    import platform

    def get_shell_info():
        return u'{} {}'.format(platform.system(), platform.release())


# Generated at 2022-06-18 07:08:06.406152
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:08:08.852863
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al', True))


# Generated at 2022-06-18 07:08:11.275860
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.BRIGHT) == ''

# Generated at 2022-06-18 07:08:15.317081
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:16.833581
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:21.986075
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:29.499099
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:08:34.344338
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_with(u'test took: {}\n'.format(timedelta()))

# Generated at 2022-06-18 07:08:42.708982
# Unit test for function debug
def test_debug():
    from . import conf
    from . import utils
    from . import shell
    from . import rules
    from . import types
    from . import main
    from . import history
    from . import logs
    from . import applications
    from . import shells
    from . import aliases
    from . import installer
    from . import tests
    from . import __main__
    from . import __init__
    from . import __version__

    settings.debug = True
    debug(u'Debug message')
    settings.debug = False
    debug(u'Debug message')

# Generated at 2022-06-18 07:08:46.588860
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)
    assert shell.get_from_history() == 'ls -a'

# Generated at 2022-06-18 07:08:47.576939
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:08:48.396802
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:51.415290
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:52.416802
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:03.289000
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text('corrected_command')

# Generated at 2022-06-18 07:09:12.405457
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stderr():
        old_stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr

    with capture_stderr() as stderr:
        debug('test')
    assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:09:13.293871
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:17.906850
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:25.309760
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    assert u'foo' in out.getvalue()

    with captured_output() as (out, err):
        debug(u'bar')
    assert u'bar' not in out.get

# Generated at 2022-06-18 07:09:36.180375
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest


# Generated at 2022-06-18 07:09:38.605433
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:09:41.786432
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:45.712045
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:53.553254
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug('foo')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as stderr:
        settings.debug = True
        debug('foo')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'



# Generated at 2022-06-18 07:10:00.294068
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    command = Command('ls', '', '', '', '', '', '', '')
    corrected_command = CorrectedCommand(command, 'ls -a', False)
    show_corrected_command(corrected_command)
    assert shell.get_history()[-1] == 'ls -a'



# Generated at 2022-06-18 07:10:06.607695
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:09.207385
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell(), 'ls', 'ls -a'))


# Generated at 2022-06-18 07:10:14.088883
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))


# Generated at 2022-06-18 07:10:15.578173
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:10:20.020315
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:21.910832
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:22.807542
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:25.678012
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'



# Generated at 2022-06-18 07:10:28.052706
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al'))
    show_corrected_command(Command('ls', 'ls -al', True))

# Generated at 2022-06-18 07:10:29.804735
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la', 'ls -la'))



# Generated at 2022-06-18 07:10:34.765350
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:37.762817
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))



# Generated at 2022-06-18 07:10:44.864132
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .utils import get_closest, get_all_executables
    from .rules import get_rules
    from .command import Command
    from .shells import Shell

    shell_obj = Shell()
    rules = get_rules(get_all_executables())
    command = Command('pwd', '', '', '', '', '')
    corrected_command = get_closest(command, rules, shell_obj)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:10:56.640801
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import ConfigurationDetails
    from .conf import settings
    settings.no_colors = False
    how_to_configure_alias(ConfigurationDetails(
        path=u'~/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))
    settings.no_colors = True
    how_to_configure_alias(ConfigurationDetails(
        path=u'~/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))
    settings.no_colors = False

# Generated at 2022-06-18 07:10:58.925735
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:02.055192
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:03.474620
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:13.360803
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    out = StringIO()
    sys.stderr = out
    confirm_text('test')
    output = out.getvalue().strip()

# Generated at 2022-06-18 07:11:17.956893
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    out = StringIO.StringIO()
    sys.stderr = out
    show_corrected_command('ls')
    output = out.getvalue().strip()
    assert output == '$ ls'
    out.close()
    sys.stderr = sys.__stderr__


# Generated at 2022-06-18 07:11:19.519028
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:11:23.257301
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:23.839879
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:11:26.651962
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))

# Generated at 2022-06-18 07:11:33.527297
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from .conf import settings
    settings.debug = True
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 07:11:42.053740
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.fish import Fish
    from thefuck.shells.tcsh import Tcsh
    from thefuck.shells.xonsh import Xonsh
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.cmd import Cmd
    from thefuck.shells.elvish import Elvish
    from thefuck.shells.ion import Ion
    from thefuck.shells.rc import Rc
    from thefuck.shells.scsh import Scsh
    from thefuck.shells.es import Es
    from thefuck.shells.dash import Dash
    from thefuck.shells.busybox import BusyBox

# Generated at 2022-06-18 07:11:43.058420
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:45.512393
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:49.901408
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.set_shell(Bash())
    corrected_command = CorrectedCommand('ls', 'ls -l')
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:12:00.723654
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:12:09.633150
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import CorrectedCommand
    import sys
    import StringIO
    sys.stderr = StringIO.StringIO()
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('', '')))
    assert sys.stderr.getvalue() == '> ls -l\n'
    sys.stderr = StringIO.StringIO()
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('', ''), True))
    assert sys.stderr.getvalue() == '> ls -l (+side effect)\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:12:18.629056
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:12:20.668186
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:26.583116
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as stderr:
        debug('test')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:12:27.962799
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:32.743482
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:39.161280
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import wrap_in_a_list
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings
    from . import const
    from .conf import settings


# Generated at 2022-06-18 07:12:41.797718
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:12:42.646692
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:43.462794
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:47.417180
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:12:59.952534
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:13:00.473365
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:13:11.886522
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .utils import get_closest
    from .types import CorrectedCommand
    from .rules.git import match, get_new_command
    from .shells import Shell

    shell_obj = Shell()

# Generated at 2022-06-18 07:13:14.234031
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='echo "Hello World"') == 'echo "Hello World" [enter/↑/↓/ctrl+c]'


# Generated at 2022-06-18 07:13:19.316572
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:13:23.121873
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:29.369277
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import wrap_in_fnmatch_any
    from .rules.git import match, get_new_command
    from .rules.git import _get_aliases
    from .rules.git import _get_git_commands

    shell = Shell('bash')
    command = Command('git', 'sttaus', '', '', '', 1)
    corrected_command = CorrectedCommand(
        shell, command, 'git', 'status', '', '', '', 1)

    show_corrected_command(corrected_command)



# Generated at 2022-06-18 07:13:36.914272
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == ''

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        settings.debug = True
        debug('test')
        assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:13:40.537198
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:42.071214
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:13:46.541559
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.types import CorrectedCommand
    confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:13:56.339139
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:13:57.403687
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:00.141251
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:14:08.871565
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest

    assert confirm_text(CorrectedCommand(
        'git push origin master', 'git push origin master',
        get_closest('git push origin master', Bash()))) == \
        '{}git push origin master [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)

    assert confirm_text(CorrectedCommand(
        'git push origin master', 'git push origin master',
        get_closest('git push origin master', Bash()), True)) == \
        '{}git push origin master (+side effect) [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:14:15.473116
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} test\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:14:26.639920
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:14:37.860593
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:14:42.153385
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from mock import patch

    with patch.object(sys, 'stderr', StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'



# Generated at 2022-06-18 07:14:52.574125
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    confirm_text(Command('ls', '', '', '', '', '', '', '', '', '', '', ''))
    confirm_text(Command('ls', '', '', '', '', '', '', '', '', '', '', '',
                         side_effect=True))
    confirm_text(Command('ls', '', '', '', '', '', '', '', '', '', '', '',
                         side_effect=True, script_parts=['ls', '-l']))

# Generated at 2022-06-18 07:14:57.001371
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('ls', False))
    show_corrected_command(CorrectedCommand('ls', True))

# Generated at 2022-06-18 07:14:59.574339
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:15:05.868587
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:15:09.496535
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls')
    assert sys.stderr.getvalue() == 'ls [enter/↑/↓/ctrl+c]'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:15:13.441222
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log
    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:15:24.744150
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .types import Command
    from .utils import get_closest
    from .rules.any_command import match, get_new_command
    from .rules.python_command import match as python_match
    from .rules.git_command import match as git_match
    from .rules.man import match as man_match
    from .rules.sudo import match as sudo_match
    from .rules.cd import match as cd_match
    from .rules.apt_get import match as apt_get_match
    from .rules.brew import match as brew_match
    from .rules.gem import match as gem_match
    from .rules.pip import match as pip_match
    from .rules.yarn import match as yarn_match

# Generated at 2022-06-18 07:15:25.823589
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:36.577251
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:15:37.550023
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:46.451636
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(const.CorrectedCommand(script='ls', side_effect=False))
    assert sys.stderr.getvalue() == u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:16:01.982138
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('fuck')

# Generated at 2022-06-18 07:16:06.351553
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:08.563069
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('/dev/null', 'w')
    confirm_text(None)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:16:10.215867
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la'))


# Generated at 2022-06-18 07:16:12.572863
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:16:13.705413
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:16:16.147820
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:16:17.328292
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-18 07:16:22.236871
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import settings
    settings.debug = True
    out = StringIO()
    sys.stderr = out
    debug('test')
    assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:16:22.568993
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:16:30.877413
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:31.910932
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:16:37.418327
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:16:41.991897
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:16:43.354026
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text(u'ls')

# Generated at 2022-06-18 07:16:51.814746
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:16:54.505844
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:16:58.035385
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))



# Generated at 2022-06-18 07:17:10.117955
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    import os
    import tempfile
    import shutil

    def get_configuration_details(shell_name):
        shell = Shell(shell_name)
        return Configuration(
            shell=shell,
            path=shell.app_alias_path,
            content=shell.app_alias,
            reload=shell.app_alias_reload_cmd,
            can_configure_automatically=shell.can_configure_automatically)

    def get_configuration_details_for_current_shell():
        return get_configuration_details(get_closest(get_alias()))


# Generated at 2022-06-18 07:17:12.865603
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))


# Generated at 2022-06-18 07:17:19.855269
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:21.344662
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:24.238137
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))