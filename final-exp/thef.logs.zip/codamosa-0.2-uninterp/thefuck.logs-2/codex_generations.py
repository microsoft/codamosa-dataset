

# Generated at 2022-06-18 07:07:30.544747
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:33.637871
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:07:37.301692
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:07:41.768027
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:07:49.098488
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    import os
    import tempfile
    import shutil
    import sys

    def _get_shell_info(shell_name):
        return Shell(shell_name, '', '', '', '', '')


# Generated at 2022-06-18 07:08:00.868034
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:08:12.072013
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand

# Generated at 2022-06-18 07:08:14.417460
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Fore.BLUE) == ''

# Generated at 2022-06-18 07:08:23.923695
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_once_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:08:24.765332
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:31.197852
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:34.933922
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:46.214252
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import Configuration
    from . import const
    from . import __version__
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import platform

    def get_configuration_details(shell):
        return Configuration(
            shell=shell,
            reload=get_closest(shell.reload_command, const.RELOAD_COMMANDS),
            path=os.path.join(os.path.expanduser('~'), shell.config_file),
            content=shell.get_alias(settings.alias),
            can_configure_automatically=shell.can_configure_automatically)


# Generated at 2022-06-18 07:08:47.738202
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand

    corrected_command = CorrectedCommand('ls -la', 'ls -al', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:56.771930
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:08:58.518874
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:08.549365
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    from StringIO import StringIO
    import sys

    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    shell = Shell('bash')
    old_stdout = sys.stdout
    sys.stdout = StringIO()
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:09:10.030073
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:09:20.790185
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:09:24.866116
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    output = StringIO.StringIO()
    sys.stderr = output
    debug('test')
    sys.stderr = sys.__stderr__
    assert output.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:09:30.717474
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls'))
    show_corrected_command(CorrectedCommand('ls', 'ls', True))

# Generated at 2022-06-18 07:09:38.701568
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=True,
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc'))
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=False,
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc'))

# Generated at 2022-06-18 07:09:39.305260
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:09:50.795111
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()

# Generated at 2022-06-18 07:10:01.116838
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    from .utils import wrap_in_fnmatch_any
    from .rules.git import git_rule
    from .rules.pip import pip_rule
    from .rules.python import python_rule
    from .rules.sudo import sudo_rule
    from .rules.system import system_rule
    from .rules.yarn import yarn_rule
    from .rules.zsh import zsh_rule

    rules = [
        git_rule,
        pip_rule,
        python_rule,
        sudo_rule,
        system_rule,
        yarn_rule,
        zsh_rule,
    ]


# Generated at 2022-06-18 07:10:05.522717
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:08.430888
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:10:09.634768
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:10:17.538448
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import settings
    settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 07:10:19.280254
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:10:23.650215
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.5)

# Generated at 2022-06-18 07:10:27.301879
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:32.401284
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules.git import match, get_new_command
    from thefuck.types import Command

    command = Command('git commit', '', '', '', '', 0)
    corrected_command = get_new_command(command)
    assert match(command)
    show_corrected_command(corrected_command)



# Generated at 2022-06-18 07:10:39.585751
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.shells import Bash

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        confirm_text(Bash('ls', 'ls -a', False))
        assert stderr.getvalue() == u'\x1b[1K\r\x1b[1m\x1b[1mls\x1b[0m ' \
                                    u'[\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/' \
                                    u'\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'

# Generated at 2022-06-18 07:10:47.841021
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from thefuck.types import CorrectedCommand

    sys.stderr = io.StringIO()
    confirm_text(CorrectedCommand('ls', 'ls -a'))
    assert sys.stderr.getvalue() == u'{prefix}ls -a [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:10:48.717658
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:10:50.060265
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:59.169126
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand

    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:11:02.268338
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:12.602769
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest


# Generated at 2022-06-18 07:11:16.380661
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:25.962515
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:11:36.731781
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __python_version__
    from . import __shells__
    from . import __shells_configs__
    from . import __all__
    from . import __title__
    from . import __description__
    from . import __url__
    from . import __author__
    from . import __author_email__
    from . import __license__
    from . import __copyright__
    from . import __keywords__
    from . import __classifiers__
    from . import __requires__
    from . import __install_requires__
    from . import __entry_points__
    from . import __project_urls__

# Generated at 2022-06-18 07:11:40.363682
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:42.961469
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:46.071549
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:11:56.870665
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __python_version__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
    from . import __shells__
   

# Generated at 2022-06-18 07:12:07.580125
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_root
    from .rules.git import _get_git_command
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_args
    from .rules.git import _get_git_command_args_str
    from .rules.git import _get_git_command_args_str_with_subcommand
    from .rules.git import _get_git_command_args_str_without_subcommand
    from .rules.git import _get_git_command_args_str_with_subcommand_and_options

# Generated at 2022-06-18 07:12:08.624070
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:12:13.590951
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import wrap_command
    corrected_command = wrap_command(Shell(), 'ls', 'ls -l')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'fuck ls -l\n'



# Generated at 2022-06-18 07:12:27.344157
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_closest, get_closest_details
    from .shells import Shell
    from .conf import ConfigurationDetails
    from . import const
    import os
    import tempfile
    import shutil

    def _get_configuration_details(shell_name):
        shell = Shell(shell_name)
        return ConfigurationDetails(
            shell.get_alias(),
            shell.get_alias_path(),
            shell.get_reload_command(),
            shell.can_configure_automatically())

    def _get_configuration_details_for_shell(shell_name):
        return _get_configuration_details(shell_name)


# Generated at 2022-06-18 07:12:31.584019
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .types import CorrectedCommand
    command = Command('ls', 'ls')
    corrected_command = CorrectedCommand(command, 'ls -a', False)
    show_corrected_command(corrected_command)


# Generated at 2022-06-18 07:12:33.244182
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:36.819047
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == '> '

# Generated at 2022-06-18 07:12:39.998297
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))

# Generated at 2022-06-18 07:12:41.989666
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:44.346894
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))


# Generated at 2022-06-18 07:12:45.167218
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:51.509735
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import get_closest

    command = Command('ls', 'ls')
    corrected_command = CorrectedCommand(command, 'ls -l', 'ls -l')
    show_corrected_command(corrected_command)
    assert get_closest(sys.stderr.write, 'ls -l')

    corrected_command = CorrectedCommand(command, 'ls -l', 'ls -l', True)
    show_corrected_command(corrected_command)
    assert get_closest(sys.stderr.write, 'ls -l (+side effect)')



# Generated at 2022-06-18 07:12:53.898050
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:57.949410
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=None)

# Generated at 2022-06-18 07:12:59.347897
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "ls -la"
    show_corrected_command(corrected_command)


# Generated at 2022-06-18 07:13:00.733187
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:06.668693
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:09.615568
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:13:11.491041
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:13.079264
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:13:14.909973
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:20.276235
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:28.606517
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from .conf import settings
    settings.no_colors = True
    settings.require_confirmation = True
    shell.from_shell = lambda: Bash()
    shell.to_shell = lambda x: x
    shell.and_app_code = lambda x: x
    shell.get_aliases = lambda: {}
    shell.get_history = lambda: wrap_in_a_list(CorrectedCommand('ls'))
    shell.get_app_by_alias = lambda x: None
    shell.put_to_history = lambda x: None
    shell.get_history_without_current = lambda: wrap_in_a_list(CorrectedCommand('ls'))
    shell

# Generated at 2022-06-18 07:13:34.872488
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al'))
    show_corrected_command(Command('ls', 'ls -al', True))


# Generated at 2022-06-18 07:13:39.804595
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('foo'):
            pass
        stderr.write.assert_called_once_with(
            u'{} took: {}\n'.format(
                'foo', datetime.now() - datetime.now()))

# Generated at 2022-06-18 07:13:45.804324
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        confirm_text(const.CorrectedCommand('ls', False))
        assert fake_stderr.getvalue() == u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:13:49.172921
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:53.100920
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:56.783814
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:14:06.446790
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:14:08.821181
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:14:20.518941
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _git_command_has_file_arguments
    from .rules.git import _git_command_has_branch_arguments

    def test_confirm_text(script, side_effect, expected):
        corrected_command = CorrectedCommand(script, side_effect)
        confirm_text(corrected_command)
        assert sys.stderr.getvalue() == expected

    def test_confirm_text_with_side_effect(script, side_effect, expected):
        corrected_command = CorrectedCommand(script, side_effect)
        confirm_text(corrected_command)
        assert sys.stderr

# Generated at 2022-06-18 07:14:21.551164
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:27.623759
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:33.234309
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import ConfigurationDetails
    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    assert True

# Generated at 2022-06-18 07:14:39.666079
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:14:42.979625
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:14:46.766884
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))
    confirm_text(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:14:50.232221
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))

# Generated at 2022-06-18 07:14:55.448466
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:14:57.357108
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:59.587940
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:15:08.345237
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    from thefuck.utils import color
    from thefuck.utils import colorama
    from thefuck.utils import const
    from thefuck.utils import settings
    from thefuck.utils import sys
    from thefuck.utils import warn
    from thefuck.utils import exception
    from thefuck.utils import rule_failed
    from thefuck.utils import failed
    from thefuck.utils import show_corrected_command
    from thefuck.utils import confirm_text
    from thefuck.utils import debug
    from thefuck.utils import debug_time
    from thefuck.utils import how_to_configure_alias
    from thefuck.utils import already_configured
    from thefuck.utils import configured_successfully

# Generated at 2022-06-18 07:15:17.457170
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    show_corrected_command(CorrectedCommand(Command('ls', 'ls'), False))
    show_corrected_command(CorrectedCommand(Command('ls', 'ls'), True))

# Generated at 2022-06-18 07:15:24.378267
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} test\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))



# Generated at 2022-06-18 07:15:26.784982
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    configuration_details = Shell.get_closest(get_closest('bash'))
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:15:29.634761
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:39.485414
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.get_shell = lambda: Bash()


# Generated at 2022-06-18 07:15:41.874230
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:15:50.445269
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_command_names
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_name_from_alias
    from .rules.git import _get_git_command_name_from_alias_or_script
    from .rules.git import _get_git_command_name_from_script
    from .rules.git import _get_git_command_name_from_alias_or_script
    from .rules.git import _get_git_command_name_from_alias_or

# Generated at 2022-06-18 07:15:51.348465
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:55.564947
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:57.800455
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:16:12.606122
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('bash')))
    assert sys.stderr.getvalue() == '{}ls -l\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:16:22.541074
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')


# Generated at 2022-06-18 07:16:23.309913
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:24.689897
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:28.132336
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    debug('test')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:16:30.274628
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:37.823124
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    output = StringIO()
    settings.debug = True
    sys.stderr = output
    debug('test')
    assert output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    settings.debug = False
    debug('test')
    assert output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:16:47.622731
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import conf
    import os
    import tempfile
    import shutil
    import sys
    import io

    class FakeShell(Shell):
        @property
        def path(self):
            return '~/.zshrc'

        @property
        def reload(self):
            return 'source ~/.zshrc'

        @property
        def name(self):
            return 'zsh'

        @property
        def alias(self):
            return 'alias fuck=\'eval $(thefuck $(fc -ln -1))\''

        @property
        def app_alias(self):
            return 'alias fuck=\'eval $(thefuck $(fc -ln -1 | tail -n 1))\''

# Generated at 2022-06-18 07:16:54.468596
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('')
    how_to_configure_alias('test')
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='test',
            content='test',
            reload='test',
            can_configure_automatically=True))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='test',
            content='test',
            reload='test',
            can_configure_automatically=False))

# Generated at 2022-06-18 07:16:57.723213
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('shell', '', '', '', '')))


# Generated at 2022-06-18 07:17:10.903004
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', False))
    show_corrected_command(CorrectedCommand('ls', True))



# Generated at 2022-06-18 07:17:13.896406
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:17:14.539730
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:18.271768
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:17:22.446193
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:17:24.352323
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-18 07:17:28.214089
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))