

# Generated at 2022-06-18 07:07:27.206043
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:07:29.489601
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:07:36.302082
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import __version__

    configuration_details = ConfigurationDetails(
        shell_name=get_closest(Shell, 'bash'),
        shell_config='~/.bashrc',
        reload='source ~/.bashrc',
        can_configure_automatically=True,
        fuck_alias='eval $(thefuck --alias)')

    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:07:39.495763
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:07:43.128189
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:07:46.793914
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass

        stderr.write.assert_called_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:07:51.904627
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:57.700879
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('msg'):
            pass
        debug.assert_called_once_with(u'msg took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:08.134548
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')


# Generated at 2022-06-18 07:08:12.172494
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:19.081687
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    shell = get_closest(Shell, 'bash')
    configuration_details = shell.get_configuration_details()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:08:20.045896
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:22.579003
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:26.944988
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('foo')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('foo')

# Generated at 2022-06-18 07:08:36.556747
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
   

# Generated at 2022-06-18 07:08:47.201404
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.conf import settings
    from thefuck.const import USER_COMMAND_MARK
    from thefuck.utils import confirm_text
    from thefuck.utils import color
    from thefuck.utils import colorama
    from thefuck.utils import const
    from thefuck.utils import warn
    from thefuck.utils import exception
    from thefuck.utils import rule_failed
    from thefuck.utils import failed
    from thefuck.utils import show_corrected_command
    from thefuck.utils import debug
    from thefuck.utils import debug_time
    from thefuck.utils import how_to_configure_alias
    from thefuck.utils import already_configured

# Generated at 2022-06-18 07:08:50.445892
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:52.371678
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:08:56.817998
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:01.921836
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time
    with patch('thefuck.utils.debug') as debug:
        with debug_time('msg'):
            pass
        debug.assert_called_once_with(
            u'msg took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:09:05.021178
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:09:07.722327
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:10.841629
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:15.637729
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:09:16.635632
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:26.001582
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const

    configuration_details = Configuration(
        can_configure_automatically=True,
        reload='reload',
        path='path',
        content='content')

    how_to_configure_alias(configuration_details)

    configuration_details = Configuration(
        can_configure_automatically=False,
        reload='reload',
        path='path',
        content='content')

    how_to_configure_alias(configuration_details)

    configuration_details = Configuration(
        can_configure_automatically=False,
        reload='reload',
        path='path',
        content='content')


# Generated at 2022-06-18 07:09:27.598616
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))



# Generated at 2022-06-18 07:09:29.295107
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:33.742665
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:36.849295
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:42.555729
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:09:44.213459
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:50.346013
# Unit test for function debug
def test_debug():
    from StringIO import StringIO

    debug_output = StringIO()
    settings.debug = True
    with debug_time('test'):
        debug('test')
    sys.stderr = debug_output
    debug('test')
    assert debug_output.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:09:52.488894
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:54.536221
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:58.687693
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:03.363341
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(
            timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:05.562880
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:10:10.069030
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:10:11.012716
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:16.906620
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:10:20.741124
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:21.954563
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:10:29.866880
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import Command

# Generated at 2022-06-18 07:10:34.294532
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ''))
    show_corrected_command(CorrectedCommand('ls', '', True))


# Generated at 2022-06-18 07:10:36.558302
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:10:40.211635
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))

# Generated at 2022-06-18 07:10:48.572778
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from . import const

    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master',
        wrap_in_a_list(Shell('bash', 'bash', '', '', '', '', '')), False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'git push origin master\n'

    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master',
        wrap_in_a_list(Shell('bash', 'bash', '', '', '', '', '')), True)

# Generated at 2022-06-18 07:10:52.056961
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug(u'foo')
        assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-18 07:10:52.857130
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:02.253058
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        confirm_text(const.CorrectedCommand(script='ls', side_effect=False))
        assert fake_stderr.getvalue() == u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:11:04.800231
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'

# Generated at 2022-06-18 07:11:08.513052
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:11.406478
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:13.564695
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:14.510493
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:24.480504
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', False))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', True))

# Generated at 2022-06-18 07:11:26.559169
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:37.372004
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:11:38.387203
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:50.880875
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:11:54.153543
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:11:58.763804
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:00.723899
# Unit test for function color
def test_color():
    assert color('red') == '\x1b[31m'
    assert color('red') == ''

# Generated at 2022-06-18 07:12:01.740911
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:03.635563
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=u'ls -la') == u'Corrected command: ls -la'

# Generated at 2022-06-18 07:12:08.834677
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -l\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:12:12.661097
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:12:13.995480
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:16.839502
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell('bash'), 'ls', False))
    show_corrected_command(CorrectedCommand(Shell('bash'), 'ls', True))

# Generated at 2022-06-18 07:12:22.040664
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:32.021483
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell('shell', '', '', '', '', '')
    corrected_command = CorrectedCommand('command', '', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{prefix}{bold}{script}{reset}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script=corrected_command.script,
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-18 07:12:38.026634
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls -la')
    assert sys.stderr.getvalue() == '\x1b[1K\rls -la [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]\n'

# Generated at 2022-06-18 07:12:40.535083
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:41.831959
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ''))
    show_corrected_command(CorrectedCommand('ls', '', True))

# Generated at 2022-06-18 07:12:42.728161
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:44.716761
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:12:46.999893
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:50.685747
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:51.505443
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:12:56.429807
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:12:59.525751
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:01.781666
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))

# Generated at 2022-06-18 07:13:07.111539
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:15.137513
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand

    class TestShell(Shell):
        @property
        def _alias(self):
            return u'fuck'

        @property
        def _script(self):
            return u'eval $(thefuck $(fc -ln -1))'

        @property
        def _use_temporary_alias(self):
            return False

        @property
        def _get_alias(self):
            return u'fuck'

        @property
        def _put_alias(self):
            return u'fuck'

        @property
        def _remove_alias(self):
            return u'fuck'

        @property
        def _get_aliases(self):
            return u'fuck'


# Generated at 2022-06-18 07:13:24.311490
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.datetime') as datetime_mock:
        datetime_mock.now.return_value = timedelta(seconds=1)
        with debug_time('test'):
            datetime_mock.now.return_value = timedelta(seconds=2)
        datetime_mock.now.return_value = timedelta(seconds=3)

    with patch('thefuck.shells.base.debug') as debug_mock:
        debug_mock.assert_called_once_with('test took: 1:00:00')

# Generated at 2022-06-18 07:13:29.645051
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('foo'):
            pass
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo took: {time}\n'.format(
                time=timedelta(0),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:13:39.893112
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    assert sys.stderr.getvalue() == '> ls -l\n'
    sys.stderr.truncate(0)
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))
    assert sys.stderr.getvalue() == '> ls -l (+side effect)\n'
    sys.stderr.truncate(0)
    show_corrected_command(CorrectedCommand('ls', 'ls -l', False))
    assert sys.stderr.getvalue() == '> ls -l\n'
    sys.stderr.truncate(0)


# Generated at 2022-06-18 07:13:41.785050
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', True))



# Generated at 2022-06-18 07:13:42.968508
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:13:58.640237
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    from .utils import wrap_in_fnmatch_any

    shell = Shell()
    shell.get_history = lambda: [Command('ls', 'ls')]
    shell.get_aliases = lambda: {'ls': 'ls -la'}
    shell.get_app_alias = lambda app: wrap_in_fnmatch_any(app)
    shell.put_to_history = lambda command: None
    shell.append_to_history = lambda command: None
    shell.remove_from_history = lambda command: None
    shell.get_history_without_current = lambda: []
    shell.get_script_from_history = lambda command: command.script

# Generated at 2022-06-18 07:14:00.196030
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:08.888740
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import Command

# Generated at 2022-06-18 07:14:11.815103
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:14:23.513346
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.default import match, get_new_command
    from .rules.composer import match, get_new_command
   

# Generated at 2022-06-18 07:14:28.195323
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)
    assert shell.get_from_history() == 'ls -a'

# Generated at 2022-06-18 07:14:31.389566
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:14:34.096704
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:36.463146
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:14:38.078711
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:45.513542
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))

# Generated at 2022-06-18 07:14:50.384046
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('shell', 'shell')))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('shell', 'shell'), True))


# Generated at 2022-06-18 07:14:52.740147
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:14:57.441335
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:15:00.947706
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('test')
    assert sys.stderr.getvalue() == '>test [enter/↑/↓/ctrl+c]\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:15:03.825240
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))


# Generated at 2022-06-18 07:15:12.390550
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:15:23.334610
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:15:23.831762
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:26.135681
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('test')
    assert sys.stderr.getvalue() == 'fuck test [enter/↑/↓/ctrl+c]\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:15:33.277688
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la', False))


# Generated at 2022-06-18 07:15:35.965025
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:15:42.111638
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import settings
    settings.debug = True
    out = StringIO()
    sys.stderr = out
    debug('test')
    assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    settings.debug = False
    out = StringIO()
    sys.stderr = out
    debug('test')
    assert out.getvalue() == u''

# Generated at 2022-06-18 07:15:45.594500
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:15:47.438703
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell(), 'ls', False))


# Generated at 2022-06-18 07:15:50.293977
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell('shell', 'shell', 'shell', 'shell')
    corrected_command = CorrectedCommand('command', 'script', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:00.161746
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __file__ as thefuck_file
    from . import __main__ as thefuck_main
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import platform
    import re

    def get_shell_info():
        shell = os.environ.get('SHELL')
        if not shell:
            return 'unknown shell'
        else:
            return shell

    def get_python_version():
        return '{}.{}.{}'.format(*sys.version_info[:3])

    def get_thefuck_version():
        return __version__


# Generated at 2022-06-18 07:16:02.030756
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:16:05.656364
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import shell

    with patch.object(shell, 'from_shell', return_value=shell('bash')):
        confirm_text(const.CorrectedCommand('ls', 'ls', False))

# Generated at 2022-06-18 07:16:09.321056
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:16:18.009593
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:19.143212
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:28.482777
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{}ls -l\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)
    corrected_command = CorrectedCommand('ls', 'ls -l', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{}ls -l (+side effect)\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)


# Generated at 2022-06-18 07:16:30.852468
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:41.991687
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=False, wait_command=0):
        confirm_text(Command('ls', '', '', '', '', '', ''))
        confirm_text(Command('ls', '', '', '', '', '', '', side_effect=True))
        confirm_text(Command('ls', '', '', '', '', '', '',
                             side_effect=True, script_parts=['ls', '-la']))
        confirm_text(Command('ls', '', '', '', '', '', '',
                             side_effect=True, script_parts=['ls', '-la'],
                             shell=Bash()))

# Generated at 2022-06-18 07:16:44.889058
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:46.620366
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:55.431385
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:16:59.575038
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass

        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:17:11.549726
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest
    from thefuck.rules.git import match, get_new_command
    from thefuck.rules.git import _parse_git_error
    from thefuck.rules.git import _get_command_script
    from thefuck.rules.git import _get_error_msg
    from thefuck.rules.git import _get_error_msg_without_git_cmd
    from thefuck.rules.git import _get_error_msg_with_git_cmd
    from thefuck.rules.git import _get_error_msg_with_git_cmd_and_subcmd
    from thefuck.rules.git import _get_error_msg_with_git_cmd_and_subcmd_and_

# Generated at 2022-06-18 07:17:26.410136
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Bash
    from .command import Command
    from .types import CorrectedCommand
    from .utils import wrap_in_fn

    shell = Bash()
    corrected_command = CorrectedCommand(
        Command('ls', 'ls'),
        'ls -a',
        shell.get_history(),
        False)

    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == wrap_in_fn(
        u'{}ls -a\n'.format(const.USER_COMMAND_MARK))

    corrected_command = CorrectedCommand(
        Command('ls', 'ls'),
        'ls -a',
        shell.get_history(),
        True)

    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue