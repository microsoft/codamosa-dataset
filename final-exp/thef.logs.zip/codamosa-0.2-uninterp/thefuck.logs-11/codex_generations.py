

# Generated at 2022-06-18 07:07:37.551177
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from .const import DEFAULT_ALIAS
    from .utils import get_alias
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type
    from .utils import get_shell_type

# Generated at 2022-06-18 07:07:47.394908
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:07:51.762063
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:07:53.712860
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:07:58.693956
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:07:59.509429
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:01.922885
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:06.406123
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al', False))
    assert sys.stderr.getvalue() == u'{}ls -al\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:08:09.631935
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:14.327271
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell('', '', '', '', '', '', '', '', '', '')
    corrected_command = CorrectedCommand('', '', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:19.218421
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(u'ls', False))



# Generated at 2022-06-18 07:08:27.809222
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
        assert out.getvalue() == ''

# Generated at 2022-06-18 07:08:30.957757
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell('bash'), 'ls', False))
    show_corrected_command(CorrectedCommand(Shell('bash'), 'ls', True))

# Generated at 2022-06-18 07:08:35.096924
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('msg'):
            pass

        debug.assert_called_with(u'msg took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:40.580443
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:44.797745
# Unit test for function debug
def test_debug():
    import mock
    from thefuck.utils import debug
    with mock.patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:47.085031
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:08:50.062770
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:58.814983
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(corrected_command='ls -la')
    assert sys.stderr.getvalue() == u'{prefix}ls -la [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-18 07:09:03.485173
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell

    shell = Shell('shell', 'shell', 'shell', 'shell', 'shell', 'shell', 'shell', 'shell', 'shell', 'shell')
    configuration_details = shell.get_configuration_details()
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:09:12.727004
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-18 07:09:17.206640
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:20.357864
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:09:22.733137
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:29.014032
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:09:29.931627
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:09:32.101477
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:37.368340
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:40.233310
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:09:43.406088
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:09:59.116862
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:03.447079
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:06.869225
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:07.803156
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:12.784656
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:14.251042
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:16.452456
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text(u'git push origin master')

# Generated at 2022-06-18 07:10:17.455120
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:19.885867
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:10:28.487330
# Unit test for function confirm_text
def test_confirm_text():
    from . import conf
    conf.settings.no_colors = False

# Generated at 2022-06-18 07:10:43.277014
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:49.518451
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:10:52.090271
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(object())
        assert stderr.write.called

# Generated at 2022-06-18 07:10:53.283276
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:56.027571
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:10:57.628959
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:58.921710
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:10.148531
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:11:12.106388
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:16.328964
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:11:31.637881
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -la', 'ls -al'))
    show_corrected_command(CorrectedCommand('ls -la', 'ls -al', True))

# Generated at 2022-06-18 07:11:33.316918
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:37.473244
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:43.821697
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    def get_configuration_details(shell):
        return Shell(shell, get_closest('.')).get_configuration_details()

    assert how_to_configure_alias(get_configuration_details('bash')) == None
    assert how_to_configure_alias(get_configuration_details('zsh')) == None
    assert how_to_configure_alias(get_configuration_details('fish')) == None
    assert how_to_configure_alias(get_configuration_details('powershell')) == None
    assert how_to_configure_alias(get_configuration_details('cmd')) == None
    assert how_to_configure_alias(get_configuration_details('tcsh')) == None

# Generated at 2022-06-18 07:11:46.028764
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:46.914436
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:49.585804
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:11:53.872598
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:04.432932
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells.bash import Bash


# Generated at 2022-06-18 07:12:06.639291
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:30.994983
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __file__ as fuck_file
    from . import __main__ as fuck_main
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import platform

    def get_shell_info():
        return u'{} {}'.format(platform.system(), platform.release())

    def get_python_version():
        return u'{}.{}.{}'.format(sys.version_info.major,
                                  sys.version_info.minor,
                                  sys.version_info.micro)

    def get_thefuck_version():
        return __version__


# Generated at 2022-06-18 07:12:33.318195
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:12:36.859954
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:41.114615
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    command = Command('ls', 'ls')
    corrected_command = CorrectedCommand(command, 'ls -l', False)
    confirm_text(corrected_command)

    assert get_closest(shell.get_history(), 'ls -l') == 'ls -l'

# Generated at 2022-06-18 07:12:42.110335
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:49.526636
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .shells import Bash
    from .shells.bash import BashAlias, BashRule
    from .shells.common import get_alias
    from .shells.generic import to_shell
    from .shells.zsh import ZshAlias, ZshRule
    from .shells.fish import FishAlias, FishRule
    from .shells.powershell import PowerShellAlias, PowerShellRule
    from .shells.cmd import CmdAlias, CmdRule
    from .shells.tcsh import TcshAlias, TcshRule
    from .shells.xonsh import XonshAlias, XonshRule
    from .shells.elvish import El

# Generated at 2022-06-18 07:12:57.885688
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_once_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:13:01.890912
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:13:03.362274
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:04.401190
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:13:21.740381
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls -la')
    assert sys.stderr.getvalue() == '$ ls -la [enter/↑/↓/ctrl+c]\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:13:25.498136
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:13:28.480170
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('test')
    settings.debug = False
    debug('test')

# Generated at 2022-06-18 07:13:30.703048
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''



# Generated at 2022-06-18 07:13:32.093864
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:13:36.914114
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import debug_time
    with patch('thefuck.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:13:41.167236
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as mock_debug:
        with log.debug_time('test'):
            pass
        mock_debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:13:44.607236
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', None))

# Generated at 2022-06-18 07:13:45.903139
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:13:48.439050
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls'))
    show_corrected_command(CorrectedCommand('ls', 'ls', True))

# Generated at 2022-06-18 07:14:08.746340
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:14:13.106341
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:14:17.181478
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:14:28.003969
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand

    show_corrected_command(CorrectedCommand('ls', 'ls -a', 'ls -a'))
    assert sys.stderr.getvalue() == '{}ls -a\n'.format(const.USER_COMMAND_MARK)

    show_corrected_command(CorrectedCommand('ls', 'ls -a', 'ls -a', True))
    assert sys.stderr.getvalue() == '{}ls -a (+side effect)\n'.format(
        const.USER_COMMAND_MARK)

    show_corrected_command(CorrectedCommand('ls', 'ls -a', 'ls -a', False))

# Generated at 2022-06-18 07:14:29.469351
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:34.717996
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:14:38.292824
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:42.229965
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        stderr.write.assert_called_once_with(u'[fuck] [enter]/[↑]/[↓]/[ctrl+c]')

# Generated at 2022-06-18 07:14:45.830811
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:14:57.399066
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.utils import confirm_text

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:15:12.426915
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:16.937598
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:21.374746
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))


# Generated at 2022-06-18 07:15:29.181923
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    from .utils import wrap_in_shell_code

    shell = Shell('shell', 'shell', 'shell', 'shell', 'shell', 'shell')
    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls',
                                         'ls', shell)
    show_corrected_command(corrected_command)

# Generated at 2022-06-18 07:15:39.126325
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from . import const
    from .conf import Configuration
    from .types import Command

    configuration_details = Configuration(
        can_configure_automatically=True,
        reload='reload',
        path='path',
        content='content')


# Generated at 2022-06-18 07:15:48.485121
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import wrap_streams
    from .shells import Shell
    from .types import CorrectedCommand
    with wrap_streams() as (out, err):
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:15:52.274096
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', None))



# Generated at 2022-06-18 07:15:54.072298
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:15:58.221584
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:16:07.519038
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration import ConfigurationDetails
    from .shells import Shell
    from .utils import get_closest
    from . import const

    configuration_details = ConfigurationDetails(
        path=get_closest('~/.bashrc'),
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True)

    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:16:32.895832
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:43.644927
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import __version__

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:16:52.213111
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    out = StringIO()
    sys.stderr = out
    confirm_text(None)
    output = out.getvalue().strip()

# Generated at 2022-06-18 07:16:54.265460
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''

# Generated at 2022-06-18 07:17:00.284152
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False, Bash()))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True, Bash()))

# Generated at 2022-06-18 07:17:03.840720
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:17:10.158186
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as mock_debug:
        with log.debug_time('foo'):
            pass
        mock_debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:17:11.350887
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:13.097969
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:17:14.170777
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)