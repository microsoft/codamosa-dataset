

# Generated at 2022-06-18 07:07:24.158437
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:31.722252
# Unit test for function debug
def test_debug():
    import mock
    import sys
    from thefuck.utils import debug
    with mock.patch.object(sys, 'stderr', mock.Mock()) as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:36.554421
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -a'))



# Generated at 2022-06-18 07:07:47.185566
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text('corrected_command')

# Generated at 2022-06-18 07:07:50.803256
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:07:57.358598
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time
    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:01.034290
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:06.141523
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-18 07:08:07.384911
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:08:11.860918
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:17.840231
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:19.539336
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-18 07:08:27.991328
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys
    from . import conf
    from . import const
    from . import utils
    from . import shell

    class TestConf(conf.Conf):
        def __init__(self):
            self.no_colors = False
            self.require_confirmation = False
            self.wait_command = 0
            self.rules = []
            self.exclude_rules = []
            self.priority = {}
            self.history_limit = None
            self.env = {}
            self.debug = False
            self.slow_commands = []
            self.alias = None
            self.wait_slow_command = 0
            self.alter_history = True
            self.wait_slow_command = 0
            self.alter_history = True
            self.wait_command = 0
            self.require_

# Generated at 2022-06-18 07:08:29.672314
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:31.825708
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:35.954005
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:39.277926
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    corrected_command = Shell.from_shell('bash').get_command('pwd', 'cd')
    show_corrected_command(corrected_command)


# Generated at 2022-06-18 07:08:43.973096
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:08:50.156012
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('foo'):
            pass
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo took: {time}\n'.format(
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                time=timedelta(0)))

# Generated at 2022-06-18 07:08:52.007788
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Fore.BLUE) == ''

# Generated at 2022-06-18 07:09:04.977177
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest


# Generated at 2022-06-18 07:09:07.335165
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:09:15.006131
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert 'test' in out.getvalue()

    with captured_output() as (out, err):
        debug('test')
        assert '' == out.getvalue()


# Generated at 2022-06-18 07:09:22.382300
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_closest
    from .shells import Shell

    def get_configuration_details(shell):
        return Shell(shell, '', '', '', '', '', '', '', '', '', '').get_command()

    for shell in get_closest('bash'):
        configuration_details = get_configuration_details(shell)
        how_to_configure_alias(configuration_details)
        already_configured(configuration_details)
        configured_successfully(configuration_details)

# Generated at 2022-06-18 07:09:23.638762
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:09:30.857959
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:09:32.925094
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:35.251993
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'ls') == u'\033[1K\rls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:09:40.278840
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:42.266051
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:46.701755
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:54.975709
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(const.CorrectedCommand(u'ls', False))
        assert stderr.write.called
        assert stderr.write.call_args[0][0].startswith(const.USER_COMMAND_MARK)
        assert stderr.write.call_args[0][0].endswith(u'[enter/↑/↓/ctrl+c]')
        assert u'ls' in stderr.write.call_args[0][0]

# Generated at 2022-06-18 07:09:57.208181
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:01.251412
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:03.271625
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:10.282243
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:10:21.954752
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
        assert out.get

# Generated at 2022-06-18 07:10:26.028870
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:10:29.163043
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:10:33.632915
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command

    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))



# Generated at 2022-06-18 07:10:47.696530
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    from StringIO import StringIO
    import sys
    import colorama

    colorama.init()
    out = StringIO()
    sys.stderr = out
    confirm_text(CorrectedCommand('ls', 'ls -a', Shell()))

# Generated at 2022-06-18 07:10:54.453617
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:11:01.994688
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from datetime import timedelta
    from contextlib import contextmanager
    import sys
    from mock import patch
    from thefuck.utils import debug_time

    @contextmanager
    def debug_time_mock(msg):
        yield

    with patch('thefuck.utils.debug_time', debug_time_mock):
        with debug_time('test'):
            pass

    with patch('thefuck.utils.debug', lambda msg: sys.stderr.write(msg + '\n')):
        with debug_time('test'):
            pass

    with patch('thefuck.utils.debug', lambda msg: sys.stderr.write(msg + '\n')):
        with debug_time('test'):
            time.sleep(0.1)

    assert sys.stderr

# Generated at 2022-06-18 07:11:03.415988
# Unit test for function debug
def test_debug():
    debug('test')



# Generated at 2022-06-18 07:11:05.383615
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:11:07.533052
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:16.972090
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from . import const
    from .const import CONFIG_FILE_PATH, CONFIG_FILE_NAME
    from . import __version__
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import unittest

    class TestHowToConfigureAlias(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, CONFIG_FILE_NAME)
            self.old_stdout = sys.stdout
            self.old_stderr = sys.stderr
            self.old_env = os.environ

# Generated at 2022-06-18 07:11:26.559817
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.apt_get import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.php import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.java import match, get_new_command
    from .rules.javac import match, get_new_command

# Generated at 2022-06-18 07:11:30.394848
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:33.682256
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:44.676966
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:11:45.386764
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:11:49.020456
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))


# Generated at 2022-06-18 07:11:59.648320
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:12:03.636216
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:14.628262
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    settings.no_colors = False

# Generated at 2022-06-18 07:12:15.338412
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:18.997728
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('msg'):
            pass
        debug.assert_called_once_with(
            u'msg took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:31.583824
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import sys
    import thefuck.shells.base
    from thefuck.shells.base import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text

    with mock.patch.object(thefuck.shells.base, 'shell', Shell):
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:12:32.200210
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:48.922298
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.shells import Shell

    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        confirm_text(Shell().from_shell('ls', '', '', '', '', ''))

# Generated at 2022-06-18 07:12:52.975867
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))



# Generated at 2022-06-18 07:13:01.342202
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_closest_executable
    from .conf import ConfigurationDetails


# Generated at 2022-06-18 07:13:02.961332
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:06.049688
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:07.025408
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:09.626502
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:13:11.938795
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:19.896868
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))


# Generated at 2022-06-18 07:13:28.444273
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_corrected_command
    from .rules.git import _get_corrected_command_with_side_effect
    from .rules.git import _get_corrected_command_with_side_effect_and_script
    from .rules.git import _get_corrected_command_with_side_effect_and_to
    from .rules.git import _get_corrected_command_with_side_effect_and_from
    from .rules.git import _get_corrected_command_with_side_effect_and_from_and_to
    from .rules.git import _get_

# Generated at 2022-06-18 07:13:46.029528
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
   

# Generated at 2022-06-18 07:13:52.553252
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:14:03.565302
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    import mock
    import sys
    import StringIO
    import colorama
    colorama.init()
    with mock.patch('sys.stdout', new_callable=StringIO.StringIO) as mock_stdout:
        shell.confirm_text(mock.Mock(script='ls', side_effect=False))

# Generated at 2022-06-18 07:14:04.552368
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:07.453578
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:14:09.396251
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Fore.BLUE) == ''

# Generated at 2022-06-18 07:14:11.617986
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:16.126590
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:27.100318
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture():
        old_stdout, old_stderr = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = StringIO(), StringIO()
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_stdout, old_stderr

    with capture() as (out, err):
        debug(u'foo')
    assert out.getvalue() == u''
    assert err.getvalue() == u''

    settings.debug = True
    with capture() as (out, err):
        debug(u'foo')
    assert out.getvalue() == u''
    assert err.getvalue() == u

# Generated at 2022-06-18 07:14:35.273850
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:14:57.358683
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls', False))
    show_corrected_command(CorrectedCommand('ls', 'ls', True))


# Generated at 2022-06-18 07:15:00.868800
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:05.267129
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == '> ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:15:08.849054
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time
    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:15:19.035583
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
       

# Generated at 2022-06-18 07:15:28.264881
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash, Zsh
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list

    for shell_class in wrap_in_a_list(Bash, Zsh):
        shell_instance = shell_class()
        shell.enable_alias = shell_instance.enable_alias
        shell.get_aliases = shell_instance.get_aliases
        shell.get_history_file_name = shell_instance.get_history_file_name
        shell.put_to_history = shell_instance.put_to_history
        shell.get_history = shell_instance.get_history
        shell.and_ = shell_instance.and_
        shell.app_alias = shell_instance.app_alias
        shell.set_alias = shell_instance.set

# Generated at 2022-06-18 07:15:32.317930
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:36.458375
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:38.455360
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:48.166830
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import Command
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match as python_match, get_new_command as python_get_new_command
    from .rules.pip import match as pip_match, get_new_command as pip_get_new_command
    from .rules.perl import match as perl_match, get_new_command as perl_get_new_command
    from .rules.ruby import match as ruby_match, get_new_command as ruby_get_new_command
    from .rules.npm import match as npm_match, get_new_command as npm_get_new_command
    from .rules.php import match as php_match, get_new_command as php

# Generated at 2022-06-18 07:16:25.690083
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))



# Generated at 2022-06-18 07:16:37.111110
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:16:41.353775
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')


# Generated at 2022-06-18 07:16:43.439947
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:16:46.723921
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('test')
    assert sys.stderr.getvalue() == '>test [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:16:49.386588
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:52.637558
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', 'ls -a', True))

# Generated at 2022-06-18 07:16:57.075237
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', '', Bash()))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', '', Bash(), True))


# Generated at 2022-06-18 07:17:00.637976
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from .utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:17:03.933453
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))