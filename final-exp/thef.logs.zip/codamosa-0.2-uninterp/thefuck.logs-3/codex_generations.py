

# Generated at 2022-06-18 07:07:27.984252
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:07:37.950701
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import wrap_in_bash_colors
    from .conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.wait_slow_terminal = 0
    settings.wait_slow_rules = 0
    settings.wait_slow_rule = 0
    settings.wait_slow_side_effect = 0
    settings.wait_slow_output = 0
    settings.wait_slow_app = 0
    settings.wait_slow_app_crash = 0
    settings.wait_slow_app_not_found = 0
    settings.wait_slow_no_rules = 0
    settings.wait

# Generated at 2022-06-18 07:07:47.810791
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest
    from thefuck.rules.git import match, get_new_command
    from thefuck.rules.git import _get_git_commands

    git_commands = _get_git_commands()
    assert git_commands
    assert get_closest('git', git_commands) == 'git'
    assert get_closest('gut', git_commands) == 'git'
    assert get_closest('gut', ['git', 'gut']) == 'gut'
    assert get_closest('gut', ['git', 'gut', 'gut-foo']) == 'gut'

# Generated at 2022-06-18 07:07:51.177523
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:07:56.194958
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand

# Generated at 2022-06-18 07:08:00.746022
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text

    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:08:03.439711
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    shell = Shell()
    from .command import Command
    command = Command('ls', 'ls -la', '', '', '', '', '', '')
    confirm_text(command)

# Generated at 2022-06-18 07:08:07.785556
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))


# Generated at 2022-06-18 07:08:10.910524
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:13.820728
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:20.269897
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:23.131234
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:26.225622
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand

    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))
    confirm_text(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:34.669222
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.now() - started))

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-18 07:08:40.922587
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules import get_rules

    shell = Shell()
    rules = get_rules()
    corrected_command = CorrectedCommand(
        get_closest('puthon'), 'python', rules[0])
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:49.800278
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:08:50.564286
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:53.275015
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))



# Generated at 2022-06-18 07:08:57.776379
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:09:02.928685
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:09:06.422444
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:09:09.082925
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))



# Generated at 2022-06-18 07:09:10.066043
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:14.129547
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:09:15.525911
# Unit test for function debug
def test_debug():
    from . import conf
    conf.settings.debug = True
    debug('test')
    conf.settings.debug = False
    debug('test')

# Generated at 2022-06-18 07:09:20.305666
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:09:29.161928
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    import os
    import tempfile
    import shutil


# Generated at 2022-06-18 07:09:30.186256
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:09:32.571567
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:09:34.497300
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la'))


# Generated at 2022-06-18 07:09:42.903948
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = False
    assert confirm_text(
        const.CorrectedCommand(u'ls', False)) == u'$ ls [enter/↑/↓/ctrl+c]'
    settings.no_colors = True
    assert confirm_text(
        const.CorrectedCommand(u'ls', False)) == u'$ ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:09:47.163231
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:58.180065
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import wrap_in_a_list
    from .conf import ConfigurationDetails

    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True)

    how_to_configure_alias(configuration_details)

    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False)

    how_to_configure_alias(configuration_details)

    how_to_configure_alias(None)


# Generated at 2022-06-18 07:10:02.579201
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import datetime
    from time import sleep

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            sleep(0.1)
        debug.assert_called_once_with(u'foo took: 0:00:00.100000')

# Generated at 2022-06-18 07:10:05.480928
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:10:11.374568
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True

# Generated at 2022-06-18 07:10:12.675242
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:23.130374
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import get_closest
    from .rules.git import git_support
    from .rules.python import python_support
    from .rules.pip import pip_support
    from .rules.system import system_support
    from .rules.npm import npm_support
    from .rules.gem import gem_support
    from .rules.brew import brew_support
    from .rules.default import default_support
    from .rules.docker import docker_support
    from .rules.composer import composer_support
    from .rules.php import php_support
    from .rules.gulp import gulp_support
    from .rules.svn import svn_support
    from .rules.vagrant import vagrant

# Generated at 2022-06-18 07:10:26.867756
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:27.554005
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:10:35.817737
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .types import ConfigurationDetails
    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:10:41.501297
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:45.126480
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:51.399044
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:54.612437
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell('bash', 'fuck', 'fuck', 'fuck')
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:10:56.598002
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:11:05.813030
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .conf import settings
    settings.no_colors = True
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls', 'ls', True)
    confirm_text(corrected_command)
    assert get_closest('ls', shell.get_history()) == 'ls'
    settings.no_colors = False

# Generated at 2022-06-18 07:11:07.448818
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', True))



# Generated at 2022-06-18 07:11:16.878071
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:11:19.888280
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:32.399088
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.shell = Bash()
    corrected_command = CorrectedCommand(
        script='git push origin master',
        side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:36.072175
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:11:42.971759
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_once_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:11:47.123976
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(corrected_command='ls -la')
    assert sys.stderr.getvalue() == '>ls -la [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:11:51.182418
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:54.104820
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:04.684495
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    import sys
    from thefuck.shells import Shell

    class FakeCorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    sys.stderr = StringIO()
    confirm_text(FakeCorrectedCommand('ls', False))

# Generated at 2022-06-18 07:12:15.451748
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from . import log
    with patch('sys.stderr') as stderr:
        log.confirm_text(None)

# Generated at 2022-06-18 07:12:16.530244
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:17.904454
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:23.296312
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:26.134841
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:30.506847
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'red') == colorama.Fore.RED + 'red'
    assert color(colorama.Fore.RED + 'red') != 'red'
    assert color(colorama.Fore.RED + 'red') == ''

# Generated at 2022-06-18 07:12:32.332529
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('')
    how_to_configure_alias('test')

# Generated at 2022-06-18 07:12:40.513347
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import git_rule
    from .rules.python import python_rule
    from .rules.pip import pip_rule
    from .rules.ruby import ruby_rule
    from .rules.perl import perl_rule
    from .rules.haskell import haskell_rule
    from .rules.go import go_rule
    from .rules.nodejs import nodejs_rule
    from .rules.java import java_rule
    from .rules.php import php_rule
    from .rules.docker import docker_rule
    from .rules.default import default_rule
    from .rules.any_command import any_command_rule
    from .rules.bash import bash_rule

# Generated at 2022-06-18 07:12:45.257563
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from . import const
    from . import __version__
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    import platform
    import colorama
    import re

    def get_shell_info():
        if sys.platform == 'win32':
            return 'Windows'
        else:
            return '{} {}'.format(platform.system(), platform.release())

    def get_python_version():
        return '{}.{}.{}'.format(*sys.version_info[:3])


# Generated at 2022-06-18 07:12:57.072759
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(const.CorrectedCommand('ls', False))
        stderr.write.assert_called_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:13:03.362618
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:05.186340
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:13:08.203834
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:13:11.061416
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:13:21.706046
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:13:25.497618
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:30.452714
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:40.930745
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    settings.no_colors = False
    settings.side_effect = True
    settings.debug = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.alter_history = False
    settings.priority = {}
    settings.exclude_rules = []
    settings.rules = []
    settings.env = {}
    settings.no_colors = False
    settings.wait_slow_command = 0
    settings.wait_command = 0
    settings.require_confirmation = True
    settings.history_limit = 0
    settings.alter_history = False
    settings.priority = {}
    settings.exclude_rules = []
    settings.rules = []

# Generated at 2022-06-18 07:13:48.279173
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from . import const
    from .conf import Configuration
    from . import settings
    from . import __version__
    from . import __file__ as thefuck_file
    from . import __main__ as thefuck_main
    from . import __doc__ as thefuck_doc
    from . import __name__ as thefuck_name
    from . import __package__ as thefuck_package
    from . import __all__ as thefuck_all
    from . import __path__ as thefuck_path
    from . import __loader__ as thefuck_loader
    from . import __spec__ as thefuck_spec
    from . import __builtins__ as thefuck_builtins
    from . import __cached__ as thefuck_cached

# Generated at 2022-06-18 07:13:52.246536
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:53.138379
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:55.191414
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell(), 'ls', False))

# Generated at 2022-06-18 07:13:56.991079
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:03.381716
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', side_effect=True))

# Generated at 2022-06-18 07:14:06.726435
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:14:08.401254
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:14:09.596716
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=None) is None

# Generated at 2022-06-18 07:14:17.194992
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False, Bash()))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True, Bash()))

# Generated at 2022-06-18 07:14:18.217594
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:29.479823
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:14:31.440764
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:36.230416
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = False
    assert confirm_text(None) == '> [enter/↑/↓/ctrl+c]'
    settings.no_colors = True
    assert confirm_text(None) == '> [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:14:44.399196
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_commands_from_git_help
    import mock
    import os
    import tempfile

    with tempfile.NamedTemporaryFile() as temp:
        temp.write(b'git commit -m "test"\n')
        temp.flush()

# Generated at 2022-06-18 07:14:50.873572
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:51.801459
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:01.783857
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:15:11.159477
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    confirm_text(None)

# Generated at 2022-06-18 07:15:22.370769
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import wrap_in_a_list
    from .types import Command

    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls -a',
                                         side_effect=True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a (+side effect)\n'.format(
        const.USER_COMMAND_MARK)

    sys.stderr = StringIO()
    corrected_command = CorrectedCommand(Command('ls', 'ls'), 'ls -a',
                                         side_effect=False)
    show_corrected_command(corrected_command)

# Generated at 2022-06-18 07:15:23.289696
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:26.656063
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:15:27.580487
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:29.311988
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:32.864609
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:15:48.025230
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:15:57.970088
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:16:05.103167
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('foo'):
            pass
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo took: {time}\n'.format(
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                time=timedelta(0)))

# Generated at 2022-06-18 07:16:13.553114
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import Configuration
    from . import const
    import os

    def _get_configuration_details(shell):
        return Configuration(
            shell.app_alias,
            shell.get_alias(),
            shell.get_aliases(),
            shell.get_history_file(),
            shell.get_reload_command(),
            shell.get_env_prefix(),
            os.path.expanduser(shell.get_config_path()),
            shell.get_config_filename(),
            shell.get_config_extension(),
            shell.get_config_content())

    def _get_shell():
        return get_closest(const.SHELLS, os.environ.get('SHELL'))


# Generated at 2022-06-18 07:16:16.123356
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    shell_name = get_closest(Shell, 'bash')
    shell = Shell(shell_name)
    configuration_details = shell.get_configuration_details()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:16:18.835996
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from time import sleep
    from .conf import settings
    settings.debug = True
    with debug_time('test'):
        sleep(0.1)
    settings.debug = False

# Generated at 2022-06-18 07:16:23.785425
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'



# Generated at 2022-06-18 07:16:24.504107
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:16:28.271558
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:40.755095
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import get_shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest

    shell = get_shell()
    corrected_command = CorrectedCommand(
        script='git log',
        side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:50.057899
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as mock_debug:
        with log.debug_time('foo'):
            pass
        mock_debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:17:00.088757
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import wrap_streams
    from . import const
    from .conf import Configuration
    from .conf import ConfigurationDetails

    configuration_details = ConfigurationDetails(
        path=u'~/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True)

    with wrap_streams() as (out, err):
        how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:17:02.558544
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:17:05.478197
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:17:08.526965
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:17:09.472056
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:10.546499
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:19.404217
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime
    from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''


# Generated at 2022-06-18 07:17:28.995288
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime
    from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

