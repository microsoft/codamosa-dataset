

# Generated at 2022-06-18 07:07:31.680417
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:32.636459
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:34.227574
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:40.410179
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:44.615149
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:07:48.353073
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:54.534098
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:56.171759
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:07:58.228944
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:08.820324
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')
    confirm_text('ls -l')
    confirm_text('ls -l -a')
    confirm_text('ls -l -a -h')
    confirm_text('ls -l -a -h -r')
    confirm_text('ls -l -a -h -r -t')
    confirm_text('ls -l -a -h -r -t -d')
    confirm_text('ls -l -a -h -r -t -d -f')
    confirm_text('ls -l -a -h -r -t -d -f -g')
    confirm_text('ls -l -a -h -r -t -d -f -g -s')

# Generated at 2022-06-18 07:08:22.261174
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to_configure_alias('test')
    how_to

# Generated at 2022-06-18 07:08:25.124170
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', 'ls -l', True))

# Generated at 2022-06-18 07:08:26.152199
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:28.380295
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:30.483831
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:34.669057
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:08:37.562062
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:38.666982
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:39.658382
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:44.399744
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:08:48.407342
# Unit test for function confirm_text
def test_confirm_text():
    from . import utils
    utils.confirm_text(utils.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:08:50.603509
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:08:54.090536
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:57.304770
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:09:02.066549
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:04.712078
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', False))
    show_corrected_command(CorrectedCommand('ls', True))


# Generated at 2022-06-18 07:09:08.507919
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.zshrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.zshrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:09:11.516894
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:17.732930
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo\n'.format(
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)))



# Generated at 2022-06-18 07:09:22.001011
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:09:27.896608
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:29.629827
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''



# Generated at 2022-06-18 07:09:32.147687
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    shell = Shell()
    shell.from_shell('echo test')
    confirm_text(shell.history[0])

# Generated at 2022-06-18 07:09:43.450452
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import sys
    import tempfile
    import unittest
    from thefuck.shells import get_shell

    class ConfirmTextTest(unittest.TestCase):
        def setUp(self):
            self.shell = get_shell()
            self.temp = tempfile.NamedTemporaryFile()
            self.temp.write(self.shell.script_from_shell(
                u'echo "test"', self.shell.get_aliases()))
            self.temp.flush()
            self.temp.seek(0)

        def tearDown(self):
            self.temp.close()

        def test_confirm_text(self):
            from thefuck.main import Command

# Generated at 2022-06-18 07:09:49.283860
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.get_shell') as get_shell:
        get_shell.return_value.debug.return_value = True
        with debug_time('foo'):
            pass
        get_shell.return_value.debug.assert_called_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:09:54.396637
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:56.618692
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))


# Generated at 2022-06-18 07:10:01.473184
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time
    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:06.720203
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import CorrectedCommand
    shell = Shell('shell', 'shell', 'shell')
    corrected_command = CorrectedCommand('command', 'script', 'side_effect')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}command (+side effect)\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:10:10.709569
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:10:18.201509
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass

        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:10:20.951394
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))



# Generated at 2022-06-18 07:10:24.281776
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell('shell'), 'script', False))
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'script\n'



# Generated at 2022-06-18 07:10:31.009831
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')

# Generated at 2022-06-18 07:10:36.078686
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))



# Generated at 2022-06-18 07:10:46.912295
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import shells
    from . import conf
    from . import utils
    from . import __version__
    import sys
    import colorama
    import sys
    import os
    import subprocess
    import sys
    import re
    import os
    import sys
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
    import os
    import subprocess
    import sys
   

# Generated at 2022-06-18 07:10:48.251623
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:52.605581
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:53.316411
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:10:55.046074
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:06.355595
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from .conf import settings
    settings.no_colors = True
    shell.shell = Bash()
    shell.shell.from_shell('echo "test"')
    corrected_command = CorrectedCommand('echo "test"', 'echo "test"')
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:07.903312
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:11:10.105349
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:11:12.057512
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:14.464959
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', False))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:11:16.924814
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:19.117257
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:11:22.946538
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:24.989739
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:25.608144
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:11:30.201727
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:40.365220
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand

# Generated at 2022-06-18 07:11:44.678895
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:11:45.729713
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:46.956675
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:11:48.469883
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:53.511137
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:11:55.229103
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))


# Generated at 2022-06-18 07:11:58.219950
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:59.756649
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:12:03.532130
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:06.210164
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:12:07.681097
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -l') == 'ls -l'

# Generated at 2022-06-18 07:12:13.109683
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_with(
            u'test took: {}\n'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:20.301987
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.types import CorrectedCommand
    from thefuck.types import Rule
    from thefuck.rules.git import match
    from thefuck.rules.git import get_new_command
    from thefuck.rules.git import side_effect
    from thefuck.rules.git import enabled_by_default
    from thefuck.rules.git import _parse_branch_name
    from thefuck.rules.git import _get_branch_name
    from thefuck.rules.git import _get_branch_names
    from thefuck.rules.git import _get_branch_names_with_remotes
    from thefuck.rules.git import _get_branch_names_with_remotes_and_local

# Generated at 2022-06-18 07:12:21.194046
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:25.577128
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:12:26.269082
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:12:30.167818
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', True))


# Generated at 2022-06-18 07:12:31.111680
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:36.901121
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:12:45.417922
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.tcsh import Tcsh
    from .shells.xonsh import Xonsh
    from .shells.powershell import Powershell
    from .shells.cmd import Cmd
    from .shells.elvish import Elvish
    from .shells.rc import Rc
    from .shells.scsh import Scsh
    from .shells.dash import Dash
    from .shells.busybox import BusyBox
    from .shells.posh import Posh
   

# Generated at 2022-06-18 07:12:46.822319
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''



# Generated at 2022-06-18 07:12:58.762217
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from .conf import settings
    settings.no_colors = False
    settings.side_effect = True
    settings.debug = False
    settings.wait_command = 0
    settings.require_confirmation = True
    settings.exclude_rules = []
    settings.priority = {}
    settings.history_limit = None
    settings.env = {}
    settings.alias = 'fuck'
    settings.wait_slow_command = 0
    settings.slow_commands = []
    settings.exclude_commands = []
    settings.rules = []
    settings.no_colors = False
    settings.wait_command = 0
    settings.require_confirmation = True
    settings.exclude_rules = []
    settings.priority = {}
    settings.history_limit = None

# Generated at 2022-06-18 07:13:04.548424
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest


# Generated at 2022-06-18 07:13:05.269739
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:06.515766
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-18 07:13:07.423077
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:12.855314
# Unit test for function debug
def test_debug():
    import StringIO
    import sys

    settings.debug = True
    saved_stderr = sys.stderr
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        debug(u'foo')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    finally:
        sys.stderr = saved_stderr

# Generated at 2022-06-18 07:13:13.774918
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:19.989758
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:13:27.170521
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import settings
    settings.no_colors = False
    shell = Shell('bash', 'bash', 'bash', 'bash', 'bash', 'bash', 'bash')
    configuration_details = ConfigurationDetails(
        shell.get_alias(),
        shell.get_alias_path(),
        shell.get_reload_command(),
        shell.get_closest_to_the_fuck(),
        shell.can_configure_automatically())
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:13:35.677613
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:13:44.697708
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import show_corrected_command
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -l\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.seek(0)
    sys.stderr.truncate()
    corrected_command = CorrectedCommand('ls', 'ls -l', True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-18 07:13:46.886365
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:49.337276
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:51.864786
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:52.816183
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)

# Generated at 2022-06-18 07:13:57.572500
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:14:01.781840
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    with patch('sys.stderr') as mock_stderr:
        with debug_time('test'):
            pass
        mock_stderr.write.assert_called_with(u'test took: 0:00:00\n')

# Generated at 2022-06-18 07:14:09.084924
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:13.453118
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:21.877786
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:14:26.513049
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:28.727336
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:31.053249
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.types import CorrectedCommand
    confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:14:38.377506
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:14:45.686771
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import wrap_in_a_list
    from .settings import Settings
    from .rules.python import match, get_new_command
    from .rules.python import _get_python_path
    from .rules.python import _get_python_version
    from .rules.python import _get_python_version_from_path
    from .rules.python import _get_python_version_from_version_output
    from .rules.python import _get_python_version_from_version_string
    from .rules.python import _get_python_version_from_version_tuple
    from .rules.python import _get_python_version_from_version_tuple_string

# Generated at 2022-06-18 07:14:50.557514
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:14:56.083510
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:15:10.446980
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    shell.from_shell('ls')

# Generated at 2022-06-18 07:15:13.282253
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:15:16.163964
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:15:26.620801
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import Command

# Generated at 2022-06-18 07:15:27.543463
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:30.938654
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:15:40.537100
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    settings.no_colors = True
    assert confirm_text(const.CorrectedCommand('ls', False)) == '{}ls [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)
    settings.no_colors = False

# Generated at 2022-06-18 07:15:41.543453
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:44.726480
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la'))
    show_corrected_command(Command('ls', 'ls -la', True))

# Generated at 2022-06-18 07:15:45.314368
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:00.203532
# Unit test for function confirm_text
def test_confirm_text():
    from . import main
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.man import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.default import match, get_new_command
    from .rules.docker import match, get_new_command
    from .rules.systemctl import match, get_new_command
    from .rules.apt import match, get_new_

# Generated at 2022-06-18 07:16:02.947550
# Unit test for function confirm_text
def test_confirm_text():
    from . import conf
    conf.settings.no_colors = False
    assert confirm_text(None) == None
    conf.settings.no_colors = True
    assert confirm_text(None) == None

# Generated at 2022-06-18 07:16:04.054054
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:06.226196
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:16:08.757754
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:17.289621
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:16:18.133403
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:16:21.137936
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == ''
    settings.no_colors = False
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE

# Generated at 2022-06-18 07:16:25.052337
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:16:27.997434
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:35.489092
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:37.373816
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:37.982725
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:16:39.906256
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:42.761669
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:16:45.260129
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la'))
    show_corrected_command(Command('ls', 'ls -la', True))

# Generated at 2022-06-18 07:16:49.765001
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.shell = Bash()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)
    assert get_closest('ls -l') == 'ls -l'

# Generated at 2022-06-18 07:16:51.775886
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')


# Generated at 2022-06-18 07:17:01.263563
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import memoize
    from .utils import wrap_settings
    from .utils import wrap_retry
    from .utils import wrap_history
    from .utils import wrap_alias
    from .utils import wrap_wait
    from .utils import wrap_slow_call
    from .utils import wrap_notify
    from .utils import wrap_require_confirmation
    from .utils import wrap_require_output
    from .utils import wrap_require_long_running_command
    from .utils import wrap_require_correct_command
    from .utils import wrap_require_correct_script
    from .utils import wrap_require_correct_script_with_side_effect
    from .utils import wrap_require_correct_script_with_side_effect

# Generated at 2022-06-18 07:17:07.560973
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:17:15.566426
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls'
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{}ls\n'.format(const.USER_COMMAND_MARK)



# Generated at 2022-06-18 07:17:25.907104
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'