

# Generated at 2022-06-18 07:07:34.741231
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:07:41.017863
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:07:47.324945
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='~/.bashrc',
            content='eval $(thefuck --alias)',
            reload='source ~/.bashrc',
            can_configure_automatically=True))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='~/.bashrc',
            content='eval $(thefuck --alias)',
            reload='source ~/.bashrc',
            can_configure_automatically=False))

# Generated at 2022-06-18 07:07:59.974576
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.debug = False
    settings.priority = {}
    settings.exclude_rules = []
    settings.history_limit = None
    settings.alter_history = False
    settings.wait_slow_command = 0
    settings.slow_commands = []
    settings.exclude_commands = []
    settings.rules = []
    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.debug = False
    settings.priority = {}
    settings.exclude_rules = []
    settings.history_limit

# Generated at 2022-06-18 07:08:01.753050
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:13.099844
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_in_fnmatch_any
    from .rules.git import match, get_new_command
    from .rules.git import _get_aliases, _get_alias_value
    from .rules.git import _get_alias_command
    from .rules.git import _get_alias_command_with_args
    from .rules.git import _get_alias_command_with_args_and_flags
    from .rules.git import _get_alias_command_with_flags
    from .rules.git import _get_alias_command_with_flags_and_args
    from .rules.git import _get_alias_command_with_flags_and_args_and_flags
    from .rules.git import _get_alias_command

# Generated at 2022-06-18 07:08:15.507590
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:18.582126
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:08:23.592655
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('foo'):
            pass
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo took: {}\n'.format(
                timedelta(0)))

# Generated at 2022-06-18 07:08:29.425725
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command(const.CorrectedCommand('ls', False))
    assert sys.stderr.getvalue() == '{}ls\n'.format(const.USER_COMMAND_MARK)
    sys.stderr = StringIO.StringIO()
    show_corrected_command(const.CorrectedCommand('ls', True))
    assert sys.stderr.getvalue() == '{}ls (+side effect)\n'.format(const.USER_COMMAND_MARK)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:08:33.976613
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:08:38.507493
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:42.522178
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc',
        'eval $(thefuck --alias)',
        'source ~/.bashrc',
        True))

# Generated at 2022-06-18 07:08:45.386534
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -a'))

# Generated at 2022-06-18 07:08:51.311802
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:08:52.012775
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:08:56.435357
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:06.643263
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import mock

    sys.stderr = mock.Mock()
    confirm_text(mock.Mock(script='script', side_effect=True))

# Generated at 2022-06-18 07:09:09.912137
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:09:11.537038
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:17.513967
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:09:19.310845
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:09:21.587388
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:24.233597
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:09:27.893196
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:32.659122
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-18 07:09:37.607261
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:48.286016
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True

# Generated at 2022-06-18 07:09:59.352922
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __python_version__
    from . import __shells__

    shell = Shell(get_closest(get_alias()))
    configuration_details = Configuration(
        shell=shell,
        path=shell.app_alias.format(alias=const.ALIAS,
                                    command=const.COMMAND),
        content=const.COMMAND,
        reload=shell.reload_command,
        can_configure_automatically=shell.can_configure_automatically)

    how_to_configure_alias(configuration_details)
    already_configured(configuration_details)
    configured_successfully

# Generated at 2022-06-18 07:09:59.976281
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:10:04.768902
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=const.CorrectedCommand(script='ls', side_effect=False)) == 'ls [enter/↑/↓/ctrl+c]'
    assert confirm_text(corrected_command=const.CorrectedCommand(script='ls', side_effect=True)) == 'ls (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:10:08.436830
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as mock_debug:
        with debug_time('test'):
            pass
        mock_debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:10:17.992259
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:10:21.786132
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:10:23.390539
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:28.288295
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'{blue}{bold}DEBUG:{reset} foo\n'.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:10:38.177021
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from . import const
    from .conf import settings
    from .types import ConfigurationDetails
    from .utils import get_closest, get_alias
    from .shells import Shell
    from . import const
    from .conf import settings
    from .types import ConfigurationDetails
    from .utils import get_closest, get_alias
    from .shells import Shell
    from . import const
    from .conf import settings
    from .types import ConfigurationDetails
    from .utils import get_closest, get_alias
    from .shells import Shell
    from . import const
    from .conf import settings
    from .types import ConfigurationDetails
    from .utils import get_closest, get_alias
    from .shells import Shell


# Generated at 2022-06-18 07:10:46.980358
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__

    configuration_details = Configuration(
        shell=Shell.from_shell_name('bash'),
        script=get_closest('bash'),
        path=get_alias('bash'),
        reload=const.RELOAD_COMMAND,
        can_configure_automatically=True)

    how_to_configure_alias(configuration_details)
    already_configured(configuration_details)
    configured_successfully(configuration_details)
    version(__version__, '3.4.3', 'bash')

# Generated at 2022-06-18 07:10:57.629627
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.bash import match, get_new_command
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.haskell import match, get_new_command
    from .rules.java import match, get_new_command
    from .rules.nodejs import match, get_new_command
    from .rules.go import match, get_new_command
    from .rules.php import match, get_new_command
    from .rules.common import match, get_new_command

# Generated at 2022-06-18 07:11:03.562110
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:11.643041
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:11:19.119393
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text
    from StringIO import StringIO
    import sys

    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    confirm_text(CorrectedCommand('ls', 'ls', Shell()))
    assert mystdout.getvalue() == u'{}ls [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)

    sys.stdout = old_stdout

# Generated at 2022-06-18 07:11:22.946714
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:33.474971
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_corrected_command
    from .rules.git import _get_corrected_command_with_side_effect
    from .rules.git import _get_corrected_command_with_side_effect_and_script
    from .rules.git import _get_corrected_command_with_side_effect_and_to_command
    from .rules.git import _get_corrected_command_with_side_effect_and_to_script
    from .rules.git import _get_corrected_command_with_side_effect_and_to_command_and_script
    from .rules.git import _get_

# Generated at 2022-06-18 07:11:41.551464
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command(corrected_command=const.CorrectedCommand(script='ls', side_effect=False))
    assert sys.stderr.getvalue() == u'{}ls\n'.format(const.USER_COMMAND_MARK)
    sys.stderr = StringIO.StringIO()
    show_corrected_command(corrected_command=const.CorrectedCommand(script='ls', side_effect=True))
    assert sys.stderr.getvalue() == u'{}ls (+side effect)\n'.format(const.USER_COMMAND_MARK)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:11:42.407345
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:45.236754
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called

# Generated at 2022-06-18 07:11:47.122617
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:11:58.128363
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import GitPushRule
    from thefuck.rules.git_push import _get_push_command
    from thefuck.rules.git_push import _get_push_command_with_side_effect
    from thefuck.rules.git_push import _get_push_command_with_side_effect_and_branch
    from thefuck.rules.git_push import _get_push_command_with_side_effect_and_branch_and_remote
    from thefuck.rules.git_push import _get_push_command_with_side_effect_and_br

# Generated at 2022-06-18 07:12:01.386784
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:12:08.252627
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass

# Generated at 2022-06-18 07:12:13.258758
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert shell.get_history()[-1] == 'fuck ls'

# Generated at 2022-06-18 07:12:14.555615
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:18.240959
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:12:19.533375
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:20.787938
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:33.195178
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.conf import settings
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import side_effect
    from thefuck.rules.git_push import enabled_by_default
    from thefuck.rules.git_push import _parse_git_push_error
    from thefuck.rules.git_push import _get_git_push_error_msg
    from thefuck.rules.git_push import _get_git_push_error_msg_for_branch
    from thefuck.rules.git_push import _get_git_push_error_msg_for_tag
    from thefuck.rules.git_push import _get_

# Generated at 2022-06-18 07:12:37.410717
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.shell = Bash()
    corrected_command = CorrectedCommand(
        script='ls',
        side_effect=False,
        history=get_closest('ls'))
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:12:43.814050
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import shells
    from . import conf
    from . import utils
    from . import __version__
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import colorama
    import platform
    import re
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.old_cwd = os.getcwd()
            os.chdir(self.temp_dir)
            self.old_shell = conf.settings.shell
            self.old_no_colors = conf.settings.no_col

# Generated at 2022-06-18 07:12:47.825525
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:56.859736
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:06.359433
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    from .utils import confirm_text
    settings.no_colors = False
    confirm_text(const.CorrectedCommand('ls', False))
    settings.no_colors = True
    confirm_text(const.CorrectedCommand('ls', False))
    settings.no_colors = False
    confirm_text(const.CorrectedCommand('ls', True))
    settings.no_colors = True
    confirm_text(const.CorrectedCommand('ls', True))

# Generated at 2022-06-18 07:13:14.659880
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from .conf import settings
    from . import const

    settings.no_colors = False
    settings.side_effect = True
    settings.debug = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.exclude_rules = []
    settings.priority = {}
    settings.rules = []
    settings.history_limit = 0
    settings.env = {}
    settings.no_colors = False
    settings.wait_slow_command = 0
    settings.wait_command = 0
    settings.require_confirmation = True
    settings.exclude_rules = []
    settings.priority = {}
    settings.rules = []
    settings.history_limit = 0
    settings.env = {}
    settings

# Generated at 2022-06-18 07:13:19.848453
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import os
    import sys
    from thefuck.utils import confirm_text
    from thefuck.types import Command

    with mock.patch.object(sys, 'stderr', os.devnull):
        confirm_text(Command('ls', 'ls', '', '', '', ''))



# Generated at 2022-06-18 07:13:20.967996
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:29.010235
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    assert u'foo' in out.getvalue()

    with captured_output() as (out, err):
        debug(u'bar')

# Generated at 2022-06-18 07:13:33.790646
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:13:36.363197
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:37.332178
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:39.504039
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = sys.stdout
    confirm_text(const.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:13:47.446813
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:58.100578
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from . import const
    from .conf import settings
    from . import shells
    from . import utils
    from . import conf
    from . import __version__
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import platform
    import colorama
    import contextlib
    import datetime
    import traceback
    import colorama
    import contextlib
    import datetime
    import traceback
    import colorama
    import contextlib
    import datetime
    import traceback
    import colorama
    import contextlib
    import datetime
    import traceback
    import colorama
    import contextlib
    import datetime
    import traceback
    import colorama
    import contextlib

# Generated at 2022-06-18 07:14:02.109570
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:03.520238
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:14:05.105036
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))


# Generated at 2022-06-18 07:14:09.274307
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:14:10.650229
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:22.051726
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master', False)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master', True)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master', False)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        'git push origin master', 'git push origin master', True)
    confirm_text(corrected_command)


# Generated at 2022-06-18 07:14:26.681073
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:28.486899
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:35.421545
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:14:41.655256
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:14:42.125330
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:14:44.362912
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'



# Generated at 2022-06-18 07:14:55.832538
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from . import const
    import os
    import tempfile
    import shutil

    def get_configuration_details(shell):
        return Configuration(
            shell=shell,
            reload=get_closest(get_all_executables(), 'source')[0],
            path=os.path.expanduser('~/.bashrc'),
            content=u'eval $(thefuck --alias)',
            can_configure_automatically=True)

    def get_shell(shell_name):
        return Shell(shell_name, '', '', '', '', '', '')

    def get_configuration_details_for_shell(shell_name):
        return get_

# Generated at 2022-06-18 07:14:56.716871
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:58.638863
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:05.366881
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells.bash import Bash
    from thefuck.types import Command
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import side_effect
    from thefuck.rules.git_push import enabled_by_default

    assert match(Command('git push', 'fatal: The current branch master has no upstream branch.\n'
                                     'To push the current branch and set the remote as upstream, use\n'
                                     '\n'
                                     '    git push --set-upstream origin master\n'
                                     '\n'))

# Generated at 2022-06-18 07:15:14.621418
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from datetime import timedelta
    from mock import patch
    from thefuck.shells import get_shell_info
    from thefuck.utils import debug_time
    from thefuck.utils import debug
    from thefuck.utils import settings

    settings.debug = True

    with patch('thefuck.utils.debug') as debug_mock:
        with debug_time('test'):
            pass

        debug_mock.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

    with patch('thefuck.utils.debug') as debug_mock:
        with debug_time('test'):
            time.sleep(0.1)


# Generated at 2022-06-18 07:15:16.282607
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:25.986725
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_once_with('\033[1K\r\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:00.000001\n')

# Generated at 2022-06-18 07:15:30.363175
# Unit test for function color
def test_color():
    assert color('red') == ''
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'
    assert color('red') == 'red'
    settings.no_colors = True

# Generated at 2022-06-18 07:15:34.561355
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:15:44.727204
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import get_closest

    class TestShell(Shell):
        @property
        def _alias(self):
            return u'test'

        @property
        def _script(self):
            return u'test'

        @property
        def _no_colors(self):
            return True

        @property
        def _and(self):
            return u'and'

        @property
        def _app_alias(self):
            return u'app'

        @property
        def _get_aliases(self):
            return lambda: {}

        @property
        def _put_to_history(self):
            return lambda x: None

        @property
        def _get_history(self):
            return

# Generated at 2022-06-18 07:15:47.110590
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:56.820125
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
   

# Generated at 2022-06-18 07:15:57.800561
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:59.642504
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:16:08.955962
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.main import confirm_text

    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:16:12.413137
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:19.188551
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:16:22.801767
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:23.664403
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:25.828394
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:16:26.901192
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:16:29.158051
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:33.777529
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    configuration_details = Shell.from_shell(get_closest('bash')).get_aliases()
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:16:38.594077
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))

# Generated at 2022-06-18 07:16:40.100201
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:43.632014
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', Shell()))
    assert sys.stderr.getvalue() == '> ls -a\n'



# Generated at 2022-06-18 07:16:53.018885
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:55.214626
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:57.957492
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))
    show_corrected_command(Command('ls', 'ls -G', side_effect=True))

# Generated at 2022-06-18 07:17:10.086381
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr', new=StringIO()) as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:17:13.444643
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:17:16.432105
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:17:18.307422
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:17:18.847317
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:17:20.039882
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:17:21.595035
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass