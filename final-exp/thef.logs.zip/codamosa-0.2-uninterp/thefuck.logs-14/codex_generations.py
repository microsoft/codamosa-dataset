

# Generated at 2022-06-18 07:07:37.112955
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=False))



# Generated at 2022-06-18 07:07:47.463975
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    assert u'foo' in out.getvalue()

    with captured_output() as (out, err):
        debug(u'bar')
    assert u'bar' in out.getvalue

# Generated at 2022-06-18 07:07:48.983559
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:51.542919
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='git push origin master') == 'git push origin master'

# Generated at 2022-06-18 07:07:56.965113
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:00.899909
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from .conf import settings
    settings.no_colors = True
    from . import utils
    from .types import CorrectedCommand
    utils.confirm_text(CorrectedCommand('ls', 'ls -l'))
    assert sys.stderr.getvalue() == '>ls -l [enter/↑/↓/ctrl+c]\n'
    sys.stderr = StringIO()
    settings.no_colors = False
    utils.confirm_text(CorrectedCommand('ls', 'ls -l'))
    assert sys.stderr.getvalue() == '>ls -l [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:08:02.128144
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -l') == 'ls -l'

# Generated at 2022-06-18 07:08:13.776106
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list

    shell.get_shell = lambda: Bash()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:15.664113
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:08:18.335440
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:25.955420
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''
    settings.no_colors = False
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == (colorama.Back.RED +
                                              colorama.Fore.WHITE
                                              + colorama.Style.BRIGHT)

# Generated at 2022-06-18 07:08:27.613718
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:36.195078
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    from .utils import get_closest

    class TestShell(Shell):
        @property
        def history(self):
            return [u'git push origin master']

        @property
        def _script_from_history(self, command):
            return get_closest(command, self.history)

    shell = TestShell()
    command = Command(u'git push origin master', u'', u'', shell)
    corrected_command = CorrectedCommand(u'git push origin master', False)
    show_corrected_command(corrected_command)



# Generated at 2022-06-18 07:08:46.588634
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert 'test' in out.getvalue()

    with captured_output() as (out, err):
        debug('test')
        assert not out.getvalue()

# Generated at 2022-06-18 07:08:53.088094
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash, Zsh
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from .conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.history_limit = None
    settings.exclude_rules = []
    settings.priority = {}
    settings.alias = 'fuck'
    settings.debug = False
    settings.wait_slow_command = 10
    settings.slow_commands = ['lein', 'react-native', 'gradle', './gradlew',
                              'vagrant']
    settings.exclude_commands = []
    settings.require_confirmation = True
    settings.wait_command = 0

# Generated at 2022-06-18 07:08:56.435969
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:08:59.663092
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls')
    assert sys.stderr.getvalue() == 'fuck ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:09:02.441542
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:11.219954
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')
    confirm_text('ls -la')
    confirm_text('ls -la | grep')
    confirm_text('ls -la | grep -i')
    confirm_text('ls -la | grep -i | wc -l')
    confirm_text('ls -la | grep -i | wc -l | sort')
    confirm_text('ls -la | grep -i | wc -l | sort | uniq')
    confirm_text('ls -la | grep -i | wc -l | sort | uniq | xargs')
    confirm_text('ls -la | grep -i | wc -l | sort | uniq | xargs -n1')

# Generated at 2022-06-18 07:09:12.680508
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:09:21.727585
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:28.923554
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import Command
    from thefuck.utils import confirm_text

    with patch('sys.stderr', new_callable=lambda: sys.stdout):
        confirm_text(Command('ls', '', '', '', '', ''))
        confirm_text(Command('ls', '', '', '', '', '', side_effect=True))
        confirm_text(Command('ls', '', '', '', '', '', side_effect=False))
        confirm_text(Command('ls', '', '', '', '', '', side_effect=None))
        confirm_text(Command('ls', '', '', '', '', '', side_effect=''))

# Generated at 2022-06-18 07:09:32.568981
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    corrected_command = Shell.from_shell('bash').get_command(
        'pwd', '', '', '', '', '')
    show_corrected_command(corrected_command)

# Generated at 2022-06-18 07:09:43.878471
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_command_names
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_name_from_alias
    from .rules.git import _get_git_command_name_from_alias_name
    from .rules.git import _get_git_command_name_from_alias_value
    from .rules.git import _get_git_command_name_from_alias_value_name
    from .rules.git import _get_git_command_name_from_alias_value

# Generated at 2022-06-18 07:09:55.498137
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __python_version__

    shell = Shell('bash', 'bash', 'bash', 'bash', 'bash', 'bash')
    configuration_details = Configuration(
        shell,
        get_closest(shell.alias, 'fuck'),
        get_alias('fuck'),
        const.CONFIG_FILE,
        const.ALIASES_FILE,
        'source ~/.bashrc',
        True)

    how_to_configure_alias(configuration_details)

    shell = Shell('zsh', 'zsh', 'zsh', 'zsh', 'zsh', 'zsh')

# Generated at 2022-06-18 07:09:56.569543
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:06.190539
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('ls')
    confirm_text('ls -l')
    confirm_text('ls -l -a')
    confirm_text('ls -l -a -h')
    confirm_text('ls -l -a -h -t')
    confirm_text('ls -l -a -h -t -r')
    confirm_text('ls -l -a -h -t -r -e')
    confirm_text('ls -l -a -h -t -r -e -d')
    confirm_text('ls -l -a -h -t -r -e -d -f')
    confirm_text('ls -l -a -h -t -r -e -d -f -g')

# Generated at 2022-06-18 07:10:15.295614
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='~/.bashrc',
            content='eval $(thefuck --alias)',
            reload='source ~/.bashrc',
            can_configure_automatically=False))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path='~/.bashrc',
            content='eval $(thefuck --alias)',
            reload='source ~/.bashrc',
            can_configure_automatically=True))

# Generated at 2022-06-18 07:10:18.157317
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:10:27.188407
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_with_color
    from .conf import settings
    settings.no_colors = False
    settings.side_effect = False
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('/bin/bash')))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('/bin/bash'), True))
    settings.no_colors = True
    settings.side_effect = False
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('/bin/bash')))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell('/bin/bash'), True))
    settings.no_colors = False
    settings

# Generated at 2022-06-18 07:10:40.480280
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:10:46.096430
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            content='content',
            path='path',
            reload='reload',
            can_configure_automatically=True))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            content='content',
            path='path',
            reload='reload',
            can_configure_automatically=False))

# Generated at 2022-06-18 07:10:57.177807
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:11:01.845954
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:06.862141
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:10.064077
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:10.948137
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:12.695773
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:16.533010
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:20.297527
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:40.572489
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:11:45.060716
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:11:47.470930
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.zshrc', 'source ~/.zshrc', True))

# Generated at 2022-06-18 07:11:51.448383
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:55.868869
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell()))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', Shell(), True))

# Generated at 2022-06-18 07:12:00.771750
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug

    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:12:11.692840
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .utils import wrap_in_namedtuple
    from .types import CorrectedCommand

    corrected_command = CorrectedCommand(
        script='git push origin master', side_effect=False)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        script='git push origin master', side_effect=True)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        script='git push origin master', side_effect=False)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        script='git push origin master', side_effect=True)
    confirm_text(corrected_command)

    corrected_command = CorrectedCommand(
        script='git push origin master', side_effect=False)


# Generated at 2022-06-18 07:12:15.775185
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')



# Generated at 2022-06-18 07:12:18.620263
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:12:23.098374
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        Shell('bash', '~/.bashrc', 'source ~/.bashrc'),
        'eval $(thefuck --alias)',
        'eval $(thefuck --alias)',
        True))

# Generated at 2022-06-18 07:12:53.701852
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called

# Generated at 2022-06-18 07:13:01.646968
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import wrap_in_a_list
    from .conf import settings
    from . import const

    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.exclude_rules = []
    settings.include_rules = []
    settings.priority = {}
    settings.debug = False
    settings.slow_commands = []
    settings.alias = 'fuck'
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.exclude_rules = []


# Generated at 2022-06-18 07:13:07.025642
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:14.371617
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('foo'):
            pass
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo took: 0:00:00\n')

    with patch('sys.stderr') as stderr:
        with debug_time('foo'):
            pass
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo took: 0:00:00\n')

# Generated at 2022-06-18 07:13:15.267123
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:18.674312
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:20.977371
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:22.954159
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:13:25.251576
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al'))
    show_corrected_command(Command('ls', 'ls -al', True))

# Generated at 2022-06-18 07:13:26.800213
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:14:23.320012
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:14:25.748181
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:28.632591
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))



# Generated at 2022-06-18 07:14:33.020758
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command('ls')
    assert sys.stderr.getvalue() == '> ls\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:14:36.180410
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:14:39.663903
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:41.848839
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    shell = Shell()
    from .command import Command
    command = Command('ls', 'ls -l')
    confirm_text(command)

# Generated at 2022-06-18 07:14:45.398017
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:50.968677
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from thefuck.utils import debug_time
    with debug_time('test'):
        pass
    assert Mock().debug.called
    assert Mock().debug.call_args[0][0].startswith('test took: ')
    assert isinstance(Mock().debug.call_args[0][0][-1], timedelta)

# Generated at 2022-06-18 07:14:55.074113
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:16:48.278473
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:16:51.616178
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:16:55.509570
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:58.226947
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:17:09.386978
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:17:17.053663
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .conf import settings
    settings.no_colors = True
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.exclude_rules = []
    settings.prioritize_matching = False
    settings.debug = False
    settings.slow_commands = []
    settings.alias = 'fuck'
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.wait_slow_command = 0
    settings.history_limit = 0
    settings.exclude_rules = []

# Generated at 2022-06-18 07:17:19.519298
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:17:23.212272
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -la', 'ls -la'))
    show_corrected_command(CorrectedCommand('ls -la', 'ls -la', True))


# Generated at 2022-06-18 07:17:27.949602
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    corrected_command = CorrectedCommand(
        script='ls', side_effect=False)
    confirm_text(corrected_command)
    assert get_closest('ls', shell.get_history()) == corrected_command.script