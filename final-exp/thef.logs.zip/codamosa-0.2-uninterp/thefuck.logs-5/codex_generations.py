

# Generated at 2022-06-18 07:07:31.454676
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:07:37.478595
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('foo'):
            pass
        stderr.write.assert_called_with(
            u'{blue}{bold}DEBUG:{reset} foo took: {time}\n'.format(
                time=timedelta(0),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:07:45.280903
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:07:46.851507
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:07:59.509725
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import memoize
    from thefuck.conf import settings
    settings.no_colors = True
    shell = Shell('bash', '', '', '', '', '')
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)
    settings.no_colors = False
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:02.244898
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    out = StringIO.StringIO()
    sys.stderr = out
    debug('test')
    assert out.getvalue() == 'DEBUG: test\n'

# Generated at 2022-06-18 07:08:09.788266
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:08:10.910019
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:12.424854
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:08:14.833416
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:08:27.001063
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
        assert out.get

# Generated at 2022-06-18 07:08:28.783916
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', Shell('bash')))


# Generated at 2022-06-18 07:08:39.708922
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import memoize
    from .conf import settings
    from . import const
    import sys
    import os
    import tempfile
    import colorama
    import mock

    @memoize
    def get_shell():
        return Shell()

    @memoize
    def get_settings():
        return settings

    @memoize
    def get_const():
        return const

    @memoize
    def get_sys():
        return sys

    @memoize
    def get_os():
        return os

    @memoize
    def get_tempfile():
        return tempfile

    @memoize
    def get_colorama():
        return colorama


# Generated at 2022-06-18 07:08:49.268331
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:08:51.920284
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from time import sleep
    with debug_time('test'):
        sleep(0.5)
    assert datetime.now() - started > datetime.timedelta(seconds=0.5)

# Generated at 2022-06-18 07:08:53.612612
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:57.677780
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al', '', '', '', ''))
    show_corrected_command(Command('ls', 'ls -al', '', '', '', '', True))


# Generated at 2022-06-18 07:09:04.976279
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:09:13.299422
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell

    class FakeCorrectedCommand(object):
        script = 'ls -la'
        side_effect = True

    class FakeShell(Shell):
        def get_history(self):
            return []

    confirm_text(FakeCorrectedCommand())

# Generated at 2022-06-18 07:09:17.514419
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:29.629489
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text(None)
    sys.stderr.seek(0)

# Generated at 2022-06-18 07:09:32.148226
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:36.901281
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:39.830839
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:09:51.369633
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .rules.python import match, get_new_command
    from .shells import Bash
    from .utils import wrap_settings
    from .types import CorrectedCommand
    from .conf import settings
    from . import const
    import sys
    import os
    import tempfile
    import shutil
    import colorama

    with wrap_settings(no_colors=True):
        with tempfile.NamedTemporaryFile() as script:
            script.write(b'echo "Hello, World!"')
            script.flush()
            os.chmod(script.name, 0o755)

            with tempfile.TemporaryDirectory() as temp_dir:
                with Bash(temp_dir) as shell_:
                    shell_.set_alias('fuck', 'eval $(thefuck $(fc -ln -1))')


# Generated at 2022-06-18 07:09:52.348836
# Unit test for function debug
def test_debug():
    debug('test')
    assert True

# Generated at 2022-06-18 07:09:54.444767
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'

# Generated at 2022-06-18 07:09:56.271666
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = False
    assert confirm_text(None) == None

# Generated at 2022-06-18 07:09:57.647557
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:10:00.971543
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))


# Generated at 2022-06-18 07:10:14.559807
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:10:15.577876
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:19.673812
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    configuration_details = Shell.from_shell(get_closest('zsh')).get_aliases()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:10:21.238364
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:22.807842
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:24.451393
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'


# Generated at 2022-06-18 07:10:25.348172
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:29.185368
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:10:37.943875
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text('test')
        stderr.write.assert_called_with(
            u'{prefix}test [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:10:41.905724
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:10:48.671025
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:52.565994
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))


# Generated at 2022-06-18 07:10:55.488245
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))
    show_corrected_command(Command('ls', 'ls -a', side_effect=False))


# Generated at 2022-06-18 07:10:57.047879
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=None) == None

# Generated at 2022-06-18 07:11:01.702119
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:11:07.072580
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:10.609560
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:12.695776
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -la'))



# Generated at 2022-06-18 07:11:14.682398
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:17.471999
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:11:26.007393
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))



# Generated at 2022-06-18 07:11:27.335390
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'fuck'
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:37.799330
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:11:39.391947
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:11:49.813291
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .conf import settings
    settings.no_colors = True
    shell = Shell()

# Generated at 2022-06-18 07:12:00.621592
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import shell
    from .shells import Bash, Zsh, Fish, Xonsh, PowerShell
    from .utils import get_closest, get_alias
    from .types import Configuration
    from .const import ALIAS, DEFAULT_ALIAS, DEFAULT_EXECUTABLE_RULE_NAMES
    from .conf import settings
    from .rules.base import Rule
    from .rules.python import get_all_executables
    from .rules.pip import get_all_packages
    from .rules.gem import get_all_gems
    from .rules.npm import get_all_packages as get_all_npm_packages
    from .rules.brew import get_all_formulae
    from .rules.composer import get_all_packages as get_all_composer_packages

# Generated at 2022-06-18 07:12:05.441060
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:12:08.096388
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:13.109352
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:12:14.159437
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:26.442207
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:27.263342
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))

# Generated at 2022-06-18 07:12:31.556440
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:33.193444
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = False
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:12:35.417576
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:12:42.722363
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.fish import Fish
    from thefuck.shells.tcsh import Tcsh
    from thefuck.shells.xonsh import Xonsh
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.cmd import Cmd
    from thefuck.shells.elvish import Elvish
    from thefuck.shells.ion import Ion
    from thefuck.shells.rc import Rc
    from thefuck.shells.scsh import Scsh
    from thefuck.shells.es import Es
    from thefuck.shells.dash import Dash
    from thefuck.shells.oash import Oash

# Generated at 2022-06-18 07:12:50.010055
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.tcsh import Tcsh
    from .shells.xonsh import Xonsh
    from .shells.powershell import Powershell
    from .shells.cmd import Cmd
    from .shells.unknown import Unknown

    assert confirm_text(Bash('ls')) == '$ ls [enter/↑/↓/ctrl+c]'
    assert confirm_text(Zsh('ls')) == '$ ls [enter/↑/↓/ctrl+c]'
    assert confirm_text(Fish('ls')) == '$ ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:12:51.438701
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:52.760337
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:57.043492
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Bash
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', Bash()))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', Bash(), True))

# Generated at 2022-06-18 07:13:08.381331
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:13:16.033351
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.tcsh import Tcsh
    from .shells.xonsh import Xonsh
    from .shells.powershell import Powershell
    from .shells.cmd import Cmd
    from .shells.elvish import Elvish
    from .shells.ion import Ion
    from .shells.rc import Rc
    from .shells.scsh import Scsh
    from .shells.es import Es
    from .shells.dash import Dash
    from .shells.busybox import Busybox
    from .shells.fish import Fish
    from .shells.ksh import Ksh

# Generated at 2022-06-18 07:13:18.674729
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:13:25.336753
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:13:37.151920
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=False):
        confirm_text(Command('ls', 'ls', '', '', '', '', '', ''))
        confirm_text(Command('ls', 'ls', '', '', '', '', '', '', side_effect=True))
        confirm_text(Command('ls', 'ls', '', '', '', '', '', '', side_effect=False))
        confirm_text(Command('ls', 'ls', '', '', '', '', '', '', side_effect=True))
        confirm_text(Command('ls', 'ls', '', '', '', '', '', '', side_effect=False))

# Generated at 2022-06-18 07:13:39.191572
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:41.910959
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.get_shell = lambda: Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))

# Generated at 2022-06-18 07:13:43.726469
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:46.064955
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:48.784784
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell('shell'), 'script', False))
    show_corrected_command(CorrectedCommand(Shell('shell'), 'script', True))

# Generated at 2022-06-18 07:13:58.871133
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:14:08.008274
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text

    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:14:08.577513
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:14:11.424301
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:14:23.086122
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None
    assert how_to_configure_alias('') == None
    assert how_to_configure_alias(' ') == None
    assert how_to_configure_alias('\n') == None
    assert how_to_configure_alias('\t') == None
    assert how_to_configure_alias('\r') == None
    assert how_to_configure_alias('\r\n') == None
    assert how_to_configure_alias('\r\n\t') == None
    assert how_to_configure_alias('\r\n\t ') == None
    assert how_to_configure_alias('\r\n\t \n') == None

# Generated at 2022-06-18 07:14:27.005121
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:29.712139
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:40.166304
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from mock import patch
    from thefuck.utils import debug

    with patch.object(sys, 'stderr', StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == ''

    with patch.object(sys, 'stderr', StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == ''

    with patch.object(sys, 'stderr', StringIO()) as mock_stderr:
        with patch.object(settings, 'debug', True):
            debug('test')
            assert mock_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:14:41.405687
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:43.796341
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:14:59.253115
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:01.663633
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))


# Generated at 2022-06-18 07:15:10.993684
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _parse_git_error

    command = Command('git', 'status', '')
    corrected_command = CorrectedCommand(command, 'git status', '', '',
                                         Shell('bash', '', ''))
    show_corrected_command(corrected_command)

    command = Command('git', 'stauts', '')
    corrected_command = CorrectedCommand(command, 'git status', '', '',
                                         Shell('bash', '', ''))
    show_corrected_command(corrected_command)

    command = Command('git', 'stauts', '')
   

# Generated at 2022-06-18 07:15:13.482662
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:15:14.947952
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=None)

# Generated at 2022-06-18 07:15:16.893165
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:20.176436
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:22.692944
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:15:23.947384
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:15:32.027954
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from contextlib import contextmanager
    from mock import patch

    @contextmanager
    def debug_time(msg):
        yield

    with patch('thefuck.shells.base.debug_time', debug_time):
        with patch('thefuck.shells.base.debug') as debug:
            with debug_time('msg'):
                pass
            debug.assert_called_once_with(u'msg took: 0:00:00')

        with patch('thefuck.shells.base.debug') as debug:
            with debug_time('msg'):
                raise Exception()
            debug.assert_called_once_with(u'msg took: 0:00:00')

# Generated at 2022-06-18 07:16:00.001167
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:16:02.571936
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))



# Generated at 2022-06-18 07:16:05.374310
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:16:08.021851
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from time import sleep
    with debug_time('test'):
        sleep(1)
    assert datetime.now() - started > timedelta(seconds=1)

# Generated at 2022-06-18 07:16:16.568385
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == ''
        assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
        assert out.get

# Generated at 2022-06-18 07:16:26.328521
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_root
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_command_names
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_name_from_alias
    from .rules.git import _get_git_command_name_from_alias_or_config
    from .rules.git import _get_git_command_name_from_config
    from .rules.git import _get_git_command_name_from_config_or_alias

# Generated at 2022-06-18 07:16:30.591515
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls -l'
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{}ls -l\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:16:41.724395
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import tempfile
    import shutil
    from .conf import ConfigurationDetails

    def get_configuration_details(can_configure_automatically=False):
        return ConfigurationDetails(
            path=os.path.join(tempfile.gettempdir(), 'test'),
            content='fuck = "echo"',
            reload='reload',
            can_configure_automatically=can_configure_automatically)

    def get_output(configuration_details):
        output = []
        sys.stderr.write = lambda x: output.append(x)
        how_to_configure_alias(configuration_details)
        return ''.join(output)

    configuration_details = get_configuration_details()
    output = get_output(configuration_details)

# Generated at 2022-06-18 07:16:50.906051
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .utils import wrap_in_box
    from .shells import Shell
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.tcsh import Tcsh
    from .shells.xonsh import Xonsh
    from .shells.powershell import Powershell
    from .shells.cmd import Cmd
    from .shells.elvish import Elvish
    from .shells.ion import Ion
    from .shells.rc import Rc
    from .shells.scsh import Scsh
    from .shells.es import Es
    from .shells.dash import Dash
    from .shells.ksh import Ksh
    from .shells.fish import Fish

# Generated at 2022-06-18 07:16:56.427327
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a (+side effect)\n'.format(const.USER_COMMAND_MARK)
