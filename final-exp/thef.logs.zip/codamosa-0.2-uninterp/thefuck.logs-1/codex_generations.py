

# Generated at 2022-06-18 07:07:35.868601
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))



# Generated at 2022-06-18 07:07:41.317664
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:07:44.124735
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:07:47.136860
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:07:59.781623
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:08:04.343528
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    out = StringIO.StringIO()
    sys.stderr = out
    show_corrected_command('ls')
    output = out.getvalue().strip()
    assert output == '$ ls'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:08:05.487180
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:08:09.587866
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:13.865979
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:18.626841
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:21.803180
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:26.001284
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    shell = Shell()
    shell.from_shell('fuck')
    corrected_command = CorrectedCommand('ls', 'ls', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:28.417638
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:32.134126
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:34.980068
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:41.211197
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .types import ConfigurationDetails
    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    assert True

# Generated at 2022-06-18 07:08:45.386033
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:52.368332
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .utils import get_alias
    from .utils import get_version
    from .utils import get_python_version
    from .utils import get_shell_info
    from .utils import get_closest_configuration_file
    from .utils import get_path_to_configuration_file
    from .utils import get_reload_command
    from .utils import get_configuration_details
    from .utils import get_configuration_details_for_shell
    from .utils import get_configuration_details_for_shell_name
    from .utils import get_configuration_details_for_shell_path
    from .utils import get_configuration_details_for_shell_path_and_name
    from .utils import get_configuration_

# Generated at 2022-06-18 07:08:58.384141
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} test\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-18 07:09:03.115954
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')


# Generated at 2022-06-18 07:09:08.143187
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True



# Generated at 2022-06-18 07:09:10.266811
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:09:12.850474
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))


# Generated at 2022-06-18 07:09:17.363570
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:09:21.302914
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:23.980722
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:27.731851
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))

# Generated at 2022-06-18 07:09:31.719386
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('ls -la')
    assert sys.stderr.getvalue() == '$ ls -la [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:09:43.081455
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:09:45.090049
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:52.208447
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:09:53.646917
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -al') == 'ls -al'

# Generated at 2022-06-18 07:09:54.929553
# Unit test for function debug
def test_debug():
    debug('test')
    assert True

# Generated at 2022-06-18 07:09:58.300913
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:10:01.205931
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:10:03.574312
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))


# Generated at 2022-06-18 07:10:04.451185
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:10.877546
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls', False))

# Generated at 2022-06-18 07:10:16.907045
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:22.975526
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:10:28.085140
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:10:33.333475
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:45.290945
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .utils import wrap_in_fnmatch_any
    from .rules.git import match, get_new_command
    from .rules.git import _get_aliases
    from .rules.git import _get_alias_for_command
    from .rules.git import _get_alias_for_command_from_aliases
    from .rules.git import _get_alias_for_command_from_config
    from .rules.git import _get_alias_for_command_from_config_and_aliases
    from .rules.git import _get_alias_for_command_from_config_and_aliases_with_args
    from .rules.git import _get_alias_for_command_from_config

# Generated at 2022-06-18 07:10:49.871477
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:10:51.876008
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))



# Generated at 2022-06-18 07:10:55.488054
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:10:58.241698
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('/dev/null', 'w')
    confirm_text(None)
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:11:10.357691
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import wrap_in_a_list
    from .const import USER_COMMAND_MARK

    class FakeShell(Shell):
        def __init__(self, *args, **kwargs):
            pass

        def and_(self, *args, **kwargs):
            pass

        def get_history(self, *args, **kwargs):
            pass

        def get_aliases(self, *args, **kwargs):
            pass

        def get_app_alias(self, *args, **kwargs):
            pass

        def how_to_configure(self, *args, **kwargs):
            pass

        def is_a_function(self, *args, **kwargs):
            pass


# Generated at 2022-06-18 07:11:20.342574
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from .const import CONFIGURATION_FILES
    from . import __version__
    from . import __python_version__
    from . import __shells__
    from . import __shells_configurations__
    from . import __shells_reloads__
    from . import __shells_no_colors__
    from . import __shells_priorities__


# Generated at 2022-06-18 07:11:22.296457
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:28.165074
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:38.955763
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import Command

# Generated at 2022-06-18 07:11:40.028548
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:11:42.676251
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:47.167150
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:11:51.574543
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:11:56.374456
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:59.647780
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:02.817203
# Unit test for function debug
def test_debug():
    debug(u'foo')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-18 07:12:13.953864
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import Configuration
    from .conf import ConfigurationDetails
    from .conf import ConfiguredShell
    from .conf import ConfiguredShells
    from .conf import ConfiguredShellsList
    from .conf import ConfiguredShellsListItem
    from .conf import ShellConfigurator
    from .conf import ShellConfigurators
    from .conf import ShellConfiguratorsList
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfiguratorsListItem
    from .conf import ShellConfigur

# Generated at 2022-06-18 07:12:18.050666
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:21.540470
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:12:33.574466
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:12:41.414327
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from . import const
    from .conf import Configuration
    from .conf import settings
    from . import const
    from .utils import get_closest
    from .shells import Shell
    from . import conf
    from . import const
    from .utils import get_closest
    from .shells import Shell
    from . import conf
    from . import const
    from .utils import get_closest
    from .shells import Shell
    from . import conf
    from . import const
    from .utils import get_closest
    from .shells import Shell
    from . import conf
    from . import const
    from .utils import get_closest
    from .shells import Shell
    from . import conf
    from . import const

# Generated at 2022-06-18 07:12:44.811852
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:12:57.585636
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_commands_output
    from .rules.git import _get_git_commands_output_with_side_effect
    from .rules.git import _get_git_commands_output_with_side_effect_and_alias
    from .rules.git import _get_git_commands_output_with_alias
    from .rules.git import _get_git_commands_output_with_alias_and_side_effect
    from .rules.git import _get_git_commands_output_with_alias_and_side_effect

# Generated at 2022-06-18 07:13:02.101607
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:07.302247
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:10.883158
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:13:14.084977
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:18.370748
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:24.091529
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys

    settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug('test')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 07:13:26.843263
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -la', side_effect=True))
    show_corrected_command(Command('ls', 'ls -la', side_effect=False))


# Generated at 2022-06-18 07:13:29.679546
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:13:31.082907
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:13:39.802196
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.get_shell = lambda: Bash()
    shell.get_history = lambda: [
        u'ls',
        u'ls -la',
        u'ls -lah',
        u'ls -lah | grep']
    shell.to_shell = lambda x: x
    get_closest = lambda x, y: y[-1]

    confirm_text(CorrectedCommand(u'ls -lah | grep', False))
    confirm_text(CorrectedCommand(u'ls -lah | grep', True))

# Generated at 2022-06-18 07:13:41.043990
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:13:43.436324
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls', False))
    assert sys.stderr.getvalue() == '{}ls\n'.format(const.USER_COMMAND_MARK)



# Generated at 2022-06-18 07:13:46.619294
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:13:50.117413
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:13:57.274049
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:14:02.606351
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.conf import settings
    settings.no_colors = True
    confirm_text(CorrectedCommand('ls', 'ls', False, Bash()))
    settings.no_colors = False
    confirm_text(CorrectedCommand('ls', 'ls', False, Bash()))

# Generated at 2022-06-18 07:14:05.240525
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:14:10.994373
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    from . import __version__
    from . import __python_version__
    from . import __shells__

    shell_name = get_closest(const.SHELLS, 'bash')
    shell = Shell(shell_name, __shells__[shell_name])
    configuration_details = ConfigurationDetails(
        shell,
        '~/.bashrc',
        'source ~/.bashrc',
        True)

    how_to_configure_alias(configuration_details)
    already_configured(configuration_details)
    configured_successfully(configuration_details)
    version(__version__, __python_version__, shell_name)

# Generated at 2022-06-18 07:14:14.655570
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))



# Generated at 2022-06-18 07:14:26.174876
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import wrap_command
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .rules.git_rules import git_rule
    from .rules.pip_rules import pip_rule
    from .rules.python_rules import python_rule
    from .rules.ruby_rules import ruby_rule
    from .rules.sudo_rules import sudo_rule
    from .rules.system_rules import system_rule
    from .rules.yarn_rules import yarn_rule


# Generated at 2022-06-18 07:14:29.615369
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))


# Generated at 2022-06-18 07:14:34.047578
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:43.015177
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.rules.git_rebase import match, get_new_command
    from thefuck.types import Command

    with patch('sys.stderr', new_callable=lambda: sys.stderr):
        confirm_text(get_new_command(Command('git rebase --continue', '', ''),
                                     Shell()))

# Generated at 2022-06-18 07:14:46.762268
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:52.309224
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:14:59.735085
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:15:03.413962
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -al', side_effect=True))
    assert sys.stderr.getvalue() == '{}ls -al (+side effect)\n'.format(
        const.USER_COMMAND_MARK)



# Generated at 2022-06-18 07:15:05.136800
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:06.020161
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:15.362308
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    settings.no_colors = False
    settings.side_effect = True
    settings.alias = 'fuck'
    settings.require_confirmation = True
    settings.wait_command = 0.1
    settings.history_limit = None
    settings.priority = {}
    settings.exclude_rules = []
    settings.include_rules = []
    settings.rules = []
    settings.wait_slow_command = 1
    settings.slow_commands = ['lein', 'react-native-cli']
    settings.debug = False
    settings.env = {}
    settings.no_colors = False
    settings.alter_history = True
    settings.wait_command = 0.1
    settings.wait_slow_command = 1

# Generated at 2022-06-18 07:15:21.140107
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.utils import confirm_text
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        confirm_text('ls')
        assert stderr.getvalue() == '>ls [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:15:27.303008
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import settings
    settings.debug = True
    out = StringIO()
    sys.stderr = out
    debug(u'Test')
    assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n'
    settings.debug = False
    out = StringIO()
    sys.stderr = out
    debug(u'Test')
    assert out.getvalue() == u''
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:15:37.909683
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    import os
    import tempfile
    import shutil
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-18 07:15:40.737674
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:15:45.915563
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:15:49.312447
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:58.993006
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import wrap_command
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .rules.git_dirty_worktree import match, get_new_command
    from .rules.git_dirty_worktree import GitDirtyWorktreeRule
    from .rules.git_dirty_worktree import _parse_status_output
    from .rules.git_dirty_worktree import _get_status_output
    from .rules.git_dirty_worktree import _get_git_status_output
    from .rules.git_dirty_worktree import _get_hg_status_output
    from .rules.git_dirty_worktree import _get_svn_status_output
    from .rules.git_dirty_worktree import _get_bzr_status_

# Generated at 2022-06-18 07:16:02.163542
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command('ls')
    assert sys.stderr.getvalue() == '> ls\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:16:04.551207
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:16:08.397067
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:16:10.694845
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:16:11.271988
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:16:13.895998
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc',
        'eval $(thefuck --alias)',
        'source ~/.bashrc',
        True))

# Generated at 2022-06-18 07:16:23.954322
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=False):
        confirm_text(CorrectedCommand('ls', 'ls -a', False, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', True, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', False, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', True, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', False, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', True, Bash()))
        confirm_text(CorrectedCommand('ls', 'ls -a', False, Bash()))

# Generated at 2022-06-18 07:16:35.048460
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('msg'):
            pass

        debug.assert_called_once_with(u'msg took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:16:36.901426
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:40.803062
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    shell = get_closest(Shell, 'bash')
    configuration_details = shell.get_configuration_details()
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:16:42.534472
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)
    assert True

# Generated at 2022-06-18 07:16:43.917533
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:16:44.843782
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:48.017731
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(Shell('shell'), 'script', False))
    show_corrected_command(CorrectedCommand(Shell('shell'), 'script', True))

# Generated at 2022-06-18 07:16:52.556888
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from mock import patch

    with patch.object(sys, 'stderr', StringIO.StringIO()) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:16:53.525838
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:00.284313
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:17:09.074174
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:17:16.859741
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:17:19.048263
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:17:20.244309
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:17:23.794249
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

