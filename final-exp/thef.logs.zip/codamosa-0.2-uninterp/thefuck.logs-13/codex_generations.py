

# Generated at 2022-06-18 07:07:32.974640
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', True))
    show_corrected_command(CorrectedCommand('git push', False))


# Generated at 2022-06-18 07:07:39.570258
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(
            timedelta(seconds=0)))

# Generated at 2022-06-18 07:07:45.121978
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -a\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:07:49.632899
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import mock
    from thefuck.utils import confirm_text
    confirm_text(mock.Mock(script='ls', side_effect=False))
    assert sys.stderr.getvalue() == '>ls [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:07:52.216556
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell('shell', 'shell', 'shell')
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:07:52.604194
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:07:53.780482
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'

# Generated at 2022-06-18 07:07:55.932591
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log
    with patch('thefuck.log.debug') as mock_debug:
        with log.debug_time('test'):
            pass
        mock_debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:07:57.433077
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:05.486782
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.zshrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.zshrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.zshrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.zshrc',
        can_configure_automatically=False))



# Generated at 2022-06-18 07:08:18.764654
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.get

# Generated at 2022-06-18 07:08:19.728510
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:20.316950
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:08:26.378199
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from thefuck.utils import debug_time

    mock_debug = Mock()
    with debug_time('test', debug=mock_debug):
        pass
    assert mock_debug.called
    assert mock_debug.call_args[0][0].startswith('test took: ')
    assert timedelta(0) < timedelta(
        *[int(x) for x in mock_debug.call_args[0][0].split()[-1].split(':')])

# Generated at 2022-06-18 07:08:27.730849
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))

# Generated at 2022-06-18 07:08:29.709247
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:08:33.071746
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', False))
    show_corrected_command(Command('ls', 'ls -a', True))



# Generated at 2022-06-18 07:08:34.760365
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:36.987903
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:08:47.547659
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from .conf import settings
    settings.no_colors = False

# Generated at 2022-06-18 07:08:56.386073
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_with(u'test took: 0:00:00\n')

    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_with(u'test took: 0:00:00\n')

# Generated at 2022-06-18 07:09:02.259117
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest

    shell = Shell()
    corrected_command = CorrectedCommand(
        script=u'git push origin master',
        side_effect=False)
    confirm_text(corrected_command)
    assert get_closest(shell.get_history(), corrected_command.script) == corrected_command.script

# Generated at 2022-06-18 07:09:05.056187
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))


# Generated at 2022-06-18 07:09:07.761624
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:09:09.968688
# Unit test for function confirm_text
def test_confirm_text():
    from .application import Application
    from .shells import Bash
    from .rules.echo import match, get_new_command
    from .utils import wrap_settings
    from .types import CorrectedCommand

    app = Application(Bash(), wrap_settings({'rules': [
        {'match': match, 'get_new_command': get_new_command}]}))
    confirm_text(CorrectedCommand('ls', 'echo'))

# Generated at 2022-06-18 07:09:20.410064
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:09:29.160930
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    shell = get_closest(Shell, 'bash')

# Generated at 2022-06-18 07:09:40.834520
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import wrap_with_color
    shell = Shell()
    corrected_command = CorrectedCommand(u'ls', u'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:09:52.024640
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_closest_executable
    from .conf import ConfigurationDetails
    import os

    shell = Shell('shell', 'shell', 'shell', 'shell', 'shell', 'shell')

# Generated at 2022-06-18 07:09:56.473487
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))

# Generated at 2022-06-18 07:10:01.706856
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', side_effect=True))

# Generated at 2022-06-18 07:10:05.958932
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:07.630745
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:10:11.114505
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:22.767865
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import __version__

    shell = Shell('bash', '', '', '', '', '', '', '', '', '', '', '', '', '')

# Generated at 2022-06-18 07:10:30.301441
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:10:34.554537
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:10:35.787317
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:40.411022
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:10:41.769213
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:49.870737
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .utils import get_closest

    shell = Shell('bash')
    corrected_command = CorrectedCommand('ls', 'ls -l', side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:10:56.418537
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from .conf import Configuration
    from . import const
    from . import __version__
    from . import __file__ as thefuck_path
    from . import __main__ as thefuck_main
    from . import __doc__ as thefuck_doc
    from . import __name__ as thefuck_name
    from . import __package__ as thefuck_package
    from . import __path__ as thefuck_paths

    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import platform
    import distutils.spawn
    import distutils.sysconfig

    def get_python_version():
        return '{}.{}.{}'.format(*sys.version_info)


# Generated at 2022-06-18 07:10:57.553337
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-18 07:10:59.398256
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:11:03.630728
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called


# Generated at 2022-06-18 07:11:13.442313
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:11:14.387298
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:18.283172
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:11:19.518858
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:11:22.165670
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:26.559529
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:28.964030
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-18 07:11:39.645626
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const
    from . import conf
    from . import shells
    from . import utils
    from . import __version__

    # Test for zsh
    conf.settings.shell = Shell.zsh
    conf.settings.no_colors = False
    conf.settings.alias = get_alias(conf.settings.shell)
    conf.settings.exclude_rules = []
    conf.settings.require_confirmation = False
    conf.settings.wait_command = 3
    conf.settings.wait_slow_command = 10
    conf.settings.priority = {}
    conf.settings.rules = []
    conf.settings.history_limit = None
    conf.settings.env = {}
   

# Generated at 2022-06-18 07:11:41.606011
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:11:43.248247
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:11:47.664323
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:57.471757
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log
    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_with(u'test took: 0:00:00')

    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_with(u'test took: 0:00:00')

    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:12:07.371600
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_once_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:12:08.472123
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:13.450119
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', False))

# Generated at 2022-06-18 07:12:16.938710
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:18.038985
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:12:30.339257
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_all_executables
    from . import const

    def get_configuration_details(shell_name):
        shell = Shell(shell_name)
        executables = get_all_executables()
        return shell.get_configuration_details(
            get_closest(executables, const.DEFAULT_EXECUTABLE),
            const.DEFAULT_EXECUTABLE)

    how_to_configure_alias(get_configuration_details('bash'))
    how_to_configure_alias(get_configuration_details('zsh'))
    how_to_configure_alias(get_configuration_details('fish'))

# Generated at 2022-06-18 07:12:34.086111
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:12:39.650562
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:12:41.342672
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:12:42.930174
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:46.170805
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command('ls -la')
    assert sys.stderr.getvalue() == '> ls -la\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:12:52.693477
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:12:58.645221
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=False):
        show_corrected_command(CorrectedCommand('ls', 'ls', False))
        assert sys.stderr.getvalue() == u'{}ls{}\n'.format(
            const.USER_COMMAND_MARK, Bash.set_title)



# Generated at 2022-06-18 07:13:03.363946
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls -l') == 'ls -l'

# Generated at 2022-06-18 07:13:06.266846
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        assert stderr.write.called

# Generated at 2022-06-18 07:13:09.965048
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:15.104931
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        debug('foo')
        assert stderr.getvalue() == ''

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        settings.debug = True
        debug('foo')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-18 07:13:20.518588
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:28.753916
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    show_corrected_command(const.CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:13:29.772424
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:13:38.789079
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path=u'~/.bashrc',
            content=u'eval $(thefuck --alias)',
            reload=u'source ~/.bashrc',
            can_configure_automatically=True))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            path=u'~/.bashrc',
            content=u'eval $(thefuck --alias)',
            reload=u'source ~/.bashrc',
            can_configure_automatically=False))



# Generated at 2022-06-18 07:13:42.890767
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:13:43.730972
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:52.685799
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('foo'):
            pass
        debug.assert_called_once_with(u'foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:13:57.089235
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:58.525432
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(const.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:14:07.698578
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import memoize
    from .conf import settings
    settings.no_colors = False
    settings.require_confirmation = True
    shell = Shell('', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
    shell.get_history = lambda: ['ls', 'ls -la']
    shell.get_history_item = lambda index: shell.get_history()[index]
    shell.get_history_length = lambda: len(shell.get_history())
    shell.get_current_line = lambda: 'ls'
    shell.get_command_position = lambda: 0
    shell.get_command_mode = lambda: 'command'
    shell.get_command_

# Generated at 2022-06-18 07:14:18.933213
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.00000')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.00000')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.00000')


# Generated at 2022-06-18 07:14:21.830642
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:14:32.972590
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_commands_aliases
    from .rules.git import _get_git_commands_with_aliases
    from .rules.git import _get_git_commands_with_aliases_and_subcommands
    from .rules.git import _get_git_subcommands
    from .rules.git import _get_git_subcommands_aliases
    from .rules.git import _get_git_subcommands_with_aliases
    from .rules.git import _get_git_subcommands_with_aliases_

# Generated at 2022-06-18 07:14:35.368487
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:37.457021
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:41.184117
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:47.260676
# Unit test for function confirm_text
def test_confirm_text():
    from . import utils
    utils.confirm_text(utils.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:14:52.575014
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        assert stderr.write.called
        assert stderr.write.call_args[0][0] == '> ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:14:57.645401
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:01.137394
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:10.003756
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-18 07:15:12.918834
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand

    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:15:15.403701
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:20.788620
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:15:24.254574
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand

    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))
    confirm_text(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:15:27.483767
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:15:39.467485
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_with(u'test took: 0:00:00\n')

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_with(u'test took: 0:00:00\n')

# Generated at 2022-06-18 07:15:41.874224
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:15:44.332985
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:46.180603
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:15:52.147053
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:15:54.425473
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:03.915009
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command

    assert confirm_text(Command('ls', '', '', '', '', '', '')) == \
        u'{prefix}{clear}{bold}ls{reset} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            clear='\033[1K\r',
            bold=color(colorama.Style.BRIGHT),
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

    assert confirm_

# Generated at 2022-06-18 07:16:06.475754
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:16:07.685838
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='') == ''

# Generated at 2022-06-18 07:16:11.249056
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:16:21.648915
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:16:23.624782
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:28.823531
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00')

# Generated at 2022-06-18 07:16:29.964750
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:41.353183
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def capture_output():
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        sys.stdout = StringIO.StringIO()
        sys.stderr = StringIO.StringIO()
        try:
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    with capture_output() as (stdout, stderr):
        debug(u'Test')
        assert u'Test' in stderr.getvalue()

    with capture_output() as (stdout, stderr):
        debug(u'Test')
        assert u'Test' not in stderr

# Generated at 2022-06-18 07:16:42.352740
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:16:44.102543
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:46.572589
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))

# Generated at 2022-06-18 07:16:49.573186
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))



# Generated at 2022-06-18 07:16:52.211494
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:17:11.799844
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls -la') == 'ls -la'

# Generated at 2022-06-18 07:17:13.516538
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:17:14.597173
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:17:15.482661
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:19.780450
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:17:21.685906
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:17:23.917491
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:17:31.173172
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest

    shell.shell = Bash()
    shell.shell.from_shell = lambda x: x
    shell.shell.to_shell = lambda x: x
    shell.shell.app_alias = 'fuck'
    shell.shell.app_alias_escaped = 'fuck'

    confirm_text(CorrectedCommand('ls', 'ls -l'))
    confirm_text(CorrectedCommand('ls', 'ls -l', side_effect=True))
    confirm_text(CorrectedCommand('ls', 'ls -l', side_effect=True))
    confirm_text(CorrectedCommand('ls', 'ls -l'))