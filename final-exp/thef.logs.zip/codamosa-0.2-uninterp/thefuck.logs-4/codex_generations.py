

# Generated at 2022-06-18 07:07:28.823472
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:07:31.770035
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:07:37.368745
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:07:38.062826
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:39.495840
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:07:41.104632
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', False))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:07:49.783913
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:08:01.592016
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:08:02.515291
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:08:07.735552
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('msg'):
            pass
        debug.assert_called_once_with('msg took: {}'.format(
            timedelta(seconds=0)))

# Generated at 2022-06-18 07:08:14.640085
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:18.901228
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:27.580456
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    def assert_configuration_details(configuration_details):
        assert configuration_details.path == '~/.bashrc'
        assert configuration_details.reload == 'source ~/.bashrc'
        assert configuration_details.content == 'eval $(thefuck --alias)'

    configuration_details = Shell.from_shell(get_closest('bash')).get_aliases()
    assert_configuration_details(configuration_details)

    configuration_details = Shell.from_shell(get_closest('zsh')).get_aliases()
    assert_configuration_details(configuration_details)

    configuration_details = Shell.from_shell(get_closest('fish')).get_aliases()

# Generated at 2022-06-18 07:08:31.389113
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch.object(log, 'debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:08:42.801899
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_commands
    from .rules.git import _get_git_command_names
    from .rules.git import _get_git_command_names_with_aliases
    from .rules.git import _get_git_command_names_with_aliases_and_subcommands
    from .rules.git import _get_git_command_names_with_aliases_and_subcommands_and_options
    from .rules.git import _get_git_command_names_with_aliases_and_subcommands_and_options_and_files
    from .rules.git import _get_git

# Generated at 2022-06-18 07:08:45.664358
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:08:46.547290
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-18 07:08:53.066688
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand

    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:08:57.535886
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-18 07:09:05.904685
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from thefuck.utils import debug_time
    with debug_time('test'):
        pass
    assert Mock().debug.called
    assert Mock().debug.call_args[0][0].startswith('test took: ')
    assert isinstance(Mock().debug.call_args[0][0], str)
    assert isinstance(Mock().debug.call_args[0][0][len('test took: '):], str)
    assert isinstance(timedelta(seconds=float(Mock().debug.call_args[0][0][len('test took: '):])), timedelta)

# Generated at 2022-06-18 07:09:10.226588
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:09:12.515830
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:14.037119
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:09:24.476681
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .correct import CorrectedCommand
    from .types import Command
    from .utils import memoize
    from .rules.any_command import match, get_new_command
    from .rules.python_command import get_new_command as get_new_command_python

    @memoize
    def get_aliases():
        return {'fuck': 'thefuck'}

    shell = Shell('bash', get_aliases=get_aliases)
    corrected_command = CorrectedCommand(Command('pwd', '', ''), 'ls',
                                         side_effect=False)
    confirm_text(corrected_command)

    shell = Shell('zsh', get_aliases=get_aliases)

# Generated at 2022-06-18 07:09:27.143871
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:09:28.783999
# Unit test for function confirm_text
def test_confirm_text():
    from . import utils
    utils.confirm_text(utils.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:09:32.389588
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    shell = get_closest(Shell, 'zsh')
    how_to_configure_alias(shell.get_configuration_details())



# Generated at 2022-06-18 07:09:43.711512
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:09:48.057698
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest

    shell = get_closest(Shell, 'bash')
    configuration_details = shell.get_configuration_details()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-18 07:09:52.489674
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:09:56.959987
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:10:06.190448
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    bash = Bash()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -l\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)
    corrected_command = CorrectedCommand('ls', 'ls -l', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == \
        u'{}ls -l (+side effect)\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:10:10.425508
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:16.778685
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:18.842127
# Unit test for function debug
def test_debug():
    from . import conf
    conf.settings.debug = True
    debug('test')
    conf.settings.debug = False
    debug('test')

# Generated at 2022-06-18 07:10:27.032137
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:10:28.478357
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:38.314317
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    from contextlib import contextmanager

    @contextmanager
    def capture():
        oldout, olderr = sys.stdout, sys.stderr
        try:
            out = [StringIO.StringIO(), StringIO.StringIO()]
            sys.stdout, sys.stderr = out
            yield out
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    with capture() as out:
        debug('test')
    assert out[0] == ''
    assert out[1] == ''

    with capture() as out:
        settings.debug = True
        debug('test')
    assert out[0] == ''

# Generated at 2022-06-18 07:10:39.608069
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:42.381182
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-18 07:10:51.259281
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:10:52.153196
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:10:59.683023
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys
    from .conf import ConfigurationDetails

    out = io.StringIO()
    sys.stdout = out

    how_to_configure_alias(ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

    sys.stdout = sys.__stdout__

# Generated at 2022-06-18 07:11:04.874122
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a', False))
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'ls -a\n'



# Generated at 2022-06-18 07:11:06.610613
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-18 07:11:09.478758
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:11:15.570904
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('msg'):
            pass
        debug.assert_called_once_with(u'msg took: 0:00:00')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('msg'):
            pass
        debug.assert_called_once_with(u'msg took: 0:00:00')

# Generated at 2022-06-18 07:11:19.117653
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc',
        'eval $(thefuck --alias)',
        'source ~/.bashrc',
        True))

# Generated at 2022-06-18 07:11:22.946289
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:26.826452
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:11:32.258652
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc', 'source ~/.bashrc', True))

# Generated at 2022-06-18 07:11:39.607214
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:11:41.556821
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:11:43.193141
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:47.664353
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta(0)))

# Generated at 2022-06-18 07:11:49.945206
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:11:50.835608
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:12:01.843591
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand

    with patch('sys.stderr') as stderr:
        confirm_text(CorrectedCommand('ls', 'ls -a', False))

# Generated at 2022-06-18 07:12:06.639583
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:12:08.513124
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:17.114616
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(0)))

# Generated at 2022-06-18 07:12:19.301004
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', False))
    show_corrected_command(CorrectedCommand('git push', True))


# Generated at 2022-06-18 07:12:24.418700
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:12:30.394392
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:12:32.293713
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))



# Generated at 2022-06-18 07:12:40.512902
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from . import conf
    from . import const
    from . import shells
    from . import utils
    from . import rules
    from . import types
    from . import main
    from . import application
    from . import history
    from . import ui
    from . import logs
    from . import manager
    from . import process
    from . import scripts
    from . import shells
    from . import utils
    from . import version
    from . import which
    from . import __main__
    from . import __init__
    from . import __version__
    from . import __about__
    from . import __pkginfo__
    from . import __copyright__
    from . import __license__
    from . import __docformat__


# Generated at 2022-06-18 07:12:48.529859
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''

# Generated at 2022-06-18 07:12:59.379075
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:13:01.254128
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls', False))
    show_corrected_command(CorrectedCommand('ls', 'ls', True))

# Generated at 2022-06-18 07:13:06.982294
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:19.415767
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=True,
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc'))
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=False,
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc'))

# Generated at 2022-06-18 07:13:22.449742
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:13:24.447235
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:13:28.897272
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(const.CorrectedCommand('ls', False))
        assert stderr.write.called
        assert stderr.write.call_args[0][0].startswith(const.USER_COMMAND_MARK)
        assert stderr.write.call_args[0][0].endswith('[enter/↑/↓/ctrl+c]')

# Generated at 2022-06-18 07:13:30.302825
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:13:32.083761
# Unit test for function confirm_text
def test_confirm_text():
    from . import utils
    utils.confirm_text(utils.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:13:34.529199
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:13:41.168012
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:13:42.029805
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:13:48.895135
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(const.CorrectedCommand('ls', False))
        assert stderr.write.called
        assert stderr.write.call_args[0][0].startswith(const.USER_COMMAND_MARK)
        assert stderr.write.call_args[0][0].endswith('[enter/↑/↓/ctrl+c]')
        assert 'ls' in stderr.write.call_args[0][0]
        assert '+side effect' not in stderr.write.call_args[0][0]

        confirm_text(const.CorrectedCommand('ls', True))
        assert stderr.write.called

# Generated at 2022-06-18 07:13:58.101567
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))



# Generated at 2022-06-18 07:14:00.695485
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:14:02.782204
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:14:04.757644
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:05.295178
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-18 07:14:08.247576
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:14:12.946075
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass

        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:14:18.570640
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:14:24.028674
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    sys.stderr = StringIO.StringIO()
    show_corrected_command(u'ls')
    assert sys.stderr.getvalue() == u'{}ls\n'.format(const.USER_COMMAND_MARK)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:14:35.127109
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys
    from thefuck.shells import get_shell
    from thefuck.utils import get_closest

    output = io.StringIO()
    sys.stdout = output
    how_to_configure_alias(get_closest(get_shell()))
    sys.stdout = sys.__stdout__

# Generated at 2022-06-18 07:14:43.262870
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-18 07:14:51.802620
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
        assert 'test' in out.getvalue()

# Generated at 2022-06-18 07:14:55.229175
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))



# Generated at 2022-06-18 07:14:59.172909
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        const.ConfigurationDetails(
            path=u'~/.bashrc',
            content=u'eval $(thefuck --alias)',
            reload=u'source ~/.bashrc',
            can_configure_automatically=True))



# Generated at 2022-06-18 07:15:00.986378
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-18 07:15:05.050580
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as stderr:
        debug('test')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:15:06.271686
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:15:07.847775
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:11.611163
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:15:12.468123
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:15:27.302435
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.rules.git_push import match, get_new_command
    from thefuck.rules.git_push import side_effect
    from thefuck.rules.git_push import enabled_by_default
    from thefuck.rules.git_push import _parse_git_push_error
    from thefuck.rules.git_push import _get_push_url
    from thefuck.rules.git_push import _get_push_branch
    from thefuck.rules.git_push import _get_push_remote
    from thefuck.rules.git_push import _get_push_remote_url
    from thefuck.rules.git_push import _get_push_remote_branch

# Generated at 2022-06-18 07:15:32.097499
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:15:41.923301
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings

    with wrap_settings(no_colors=True):
        assert confirm_text(Command('ls', '', '')) == \
            '{prefix}ls [enter/↑/↓/ctrl+c]'.format(prefix=const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:15:50.476666
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import ConfigurationDetails
    from . import const

    shell = Shell('bash', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        reload='source ~/.bashrc',
        path=get_closest(shell.paths, 'bashrc'),
        content=get_alias(shell, const.ALIAS))
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-18 07:15:51.725903
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:15:54.374965
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))


# Generated at 2022-06-18 07:15:55.796841
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-18 07:15:56.864824
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-18 07:16:00.765848
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.utils import confirm_text
    with patch('sys.stderr', new_callable=StringIO) as stderr:
        confirm_text('ls')
        assert stderr.getvalue() == '>ls [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:16:04.504249
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:16:13.280377
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc',
        can_configure_automatically=True))

# Generated at 2022-06-18 07:16:15.705359
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:17.733458
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = True
    debug('test')
    settings.debug = False
    debug('test')

# Generated at 2022-06-18 07:16:22.539948
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a', False))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', None))

# Generated at 2022-06-18 07:16:24.700536
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:16:27.565749
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:16:28.990366
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:16:37.159418
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from thefuck.conf import settings

    settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug(u'foo')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 07:16:47.040409
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import ConfigurationDetails
    from . import const
    from .conf import settings
    settings.no_colors = False
    settings.debug = False
    configuration_details = ConfigurationDetails(
        '~/.bashrc',
        'source ~/.thefuck/alias',
        'source ~/.bashrc',
        True)
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-18 07:16:50.649463
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    sys.stderr = StringIO()
    confirm_text('test')
    assert sys.stderr.getvalue() == '>test [enter/↑/↓/ctrl+c]\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-18 07:17:05.578388
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -a', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:17:15.134772
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from . import const
    import os
    import tempfile
    import shutil
    import sys
    import io

    def get_configuration_details(shell_name):
        shell = Shell(shell_name, '', '')
        return shell.get_configuration_details()

    def get_configuration_details_for_shell(shell_name):
        return get_configuration_details(get_closest(shell_name, const.SHELLS))

    def get_configuration_details_for_shell_name(shell_name):
        return get_configuration_details(shell_name)


# Generated at 2022-06-18 07:17:17.179767
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:17:18.355092
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:17:22.528730
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')