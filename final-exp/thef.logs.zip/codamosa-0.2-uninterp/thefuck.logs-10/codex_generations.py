

# Generated at 2022-06-18 07:07:36.673170
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_changed_files
    from .rules.git import _get_changed_files_from_output
    from .rules.git import _get_changed_files_from_status
    from .rules.git import _get_changed_files_from_diff
    from .rules.git import _get_changed_files_from_diff_index
    from .rules.git import _get_changed_files_from_diff_files
    from .rules.git import _get_changed_files_from_diff_cached
    from .rules.git import _get_changed_files_from_diff_commit

# Generated at 2022-06-18 07:07:41.016940
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:07:41.791820
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='ls') == 'ls'

# Generated at 2022-06-18 07:07:43.740510
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:07:56.404176
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.shells import Shell
    from thefuck.types import Configuration
    from thefuck.utils import wrap_settings
    from thefuck.conf import settings
    from thefuck.const import CONFIG_FILE_PATH
    from thefuck.tests.utils import Mock

    with wrap_settings(no_colors=False):
        how_to_configure_alias(Configuration(
            can_configure_automatically=True,
            reload='reload',
            path=CONFIG_FILE_PATH,
            content='content'))

    with wrap_settings(no_colors=True):
        how_to_configure_alias(Configuration(
            can_configure_automatically=True,
            reload='reload',
            path=CONFIG_FILE_PATH,
            content='content'))


# Generated at 2022-06-18 07:07:57.336059
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:02.043829
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}ls -l\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-18 07:08:07.186772
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .conf import settings
    settings.no_colors = False
    shell = Shell('bash')
    corrected_command = CorrectedCommand('ls', 'ls -l', False)
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:08:15.076669
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const

    def test_configuration_details(can_configure_automatically=False):
        return ConfigurationDetails(
            const.ALIAS,
            get_closest(Shell, 'bash').path,
            'source ~/.bashrc',
            can_configure_automatically)

    how_to_configure_alias(test_configuration_details())
    how_to_configure_alias(test_configuration_details(True))

# Generated at 2022-06-18 07:08:21.986680
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys
    from .conf import settings
    settings.debug = True
    sys.stderr = StringIO()
    debug('test')
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    settings.debug = False
    sys.stderr = StringIO()
    debug('test')
    assert sys.stderr.getvalue() == ''

# Generated at 2022-06-18 07:08:26.816911
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push', False))



# Generated at 2022-06-18 07:08:29.408429
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:33.838493
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:08:45.190929
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.conf import settings

    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.debug = False
    settings.priority = {}
    settings.alias = 'fuck'
    settings.exclude_rules = []
    settings.history_limit = None
    settings.wait_slow_command = 10
    settings.slow_commands = ['lein', 'react-native', 'gradle', './gradlew']
    settings.exclude_commands = []
    settings.rules = []
    settings.wait_command = 0
    settings.require_confirmation = True
    settings.no_colors = False
    settings.priority

# Generated at 2022-06-18 07:08:45.803543
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:08:46.595912
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:08:47.795865
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G', False))


# Generated at 2022-06-18 07:08:49.994767
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=const.CorrectedCommand(script='ls', side_effect=True))
    confirm_text(corrected_command=const.CorrectedCommand(script='ls', side_effect=False))

# Generated at 2022-06-18 07:08:51.346396
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''

# Generated at 2022-06-18 07:08:53.508218
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:09:06.430300
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

    with patch('thefuck.shells.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

# Generated at 2022-06-18 07:09:08.752869
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:09:11.142030
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('git push origin master', ''))
    show_corrected_command(Command('git push origin master', '', True))



# Generated at 2022-06-18 07:09:13.631175
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    assert sys.stderr.getvalue() == '> ls -a\n'



# Generated at 2022-06-18 07:09:17.001678
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import settings
    settings.debug = True
    try:
        out = StringIO()
        sys.stderr = out
        debug(u'foo')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-18 07:09:18.005395
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:09:21.494861
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))


# Generated at 2022-06-18 07:09:28.818299
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Shell
    from thefuck.types import CorrectedCommand
    from thefuck.utils import confirm_text

# Generated at 2022-06-18 07:09:38.278380
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert 'test' in out.getvalue()



# Generated at 2022-06-18 07:09:48.633066
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-18 07:10:04.657511
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.pip import match, get_new_command
    from .rules.npm import match, get_new_command
    from .rules.gem import match, get_new_command
    from .rules.brew import match, get_new_command
    from .rules.apt import match, get_new_command
    from .rules.yum import match, get_new_command
    from .rules.pacman import match, get_new_command
    from .rules.systemctl import match, get_new_command
    from .rules.docker import match, get_new_command
   

# Generated at 2022-06-18 07:10:05.906837
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:10:07.589130
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-18 07:10:12.469038
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:10:20.615604
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))



# Generated at 2022-06-18 07:10:29.023099
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import CorrectedCommand
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=True):
        assert confirm_text(CorrectedCommand('ls', 'ls', False)) == \
            u'{prefix}ls [enter/↑/↓/ctrl+c]'.format(prefix=const.USER_COMMAND_MARK)
        assert confirm_text(CorrectedCommand('ls', 'ls', True)) == \
            u'{prefix}ls (+side effect) [enter/↑/↓/ctrl+c]'.format(prefix=const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:10:33.438149
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:10:40.079620
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from .utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:10:48.528471
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    settings.debug = True
    with captured_output() as (out, err):
        debug('test')
   

# Generated at 2022-06-18 07:10:50.330058
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-18 07:11:03.034496
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from . import const
    from .conf import ConfigurationDetails
    from .conf import settings
    settings.no_colors = False
    settings.debug = False
    configuration_details = ConfigurationDetails(
        path=get_closest(const.CONFIG_FILE, const.CONFIG_FILE_ALIASES),
        content=Shell(const.SHELL_NAME).get_aliases(),
        reload=Shell(const.SHELL_NAME).app_alias,
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    settings.no_colors = True
    how_to_configure_alias(configuration_details)
    how_to_configure_alias(None)

#

# Generated at 2022-06-18 07:11:07.863863
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('thefuck.log.debug') as debug:
        with log.debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: {}'.format(timedelta()))

# Generated at 2022-06-18 07:11:17.345594
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(None)

# Generated at 2022-06-18 07:11:20.387737
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', side_effect=True))

# Generated at 2022-06-18 07:11:22.696949
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True

# Generated at 2022-06-18 07:11:28.349516
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command

    shell = Shell()
    corrected_command = CorrectedCommand(
        script=get_new_command('git', 'sttaus', 'status'),
        side_effect=False)
    confirm_text(corrected_command)
    assert shell.get_input() == 'git status'

# Generated at 2022-06-18 07:11:39.123480
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    with patch('sys.stderr') as stderr:
        with log.debug_time('msg'):
            pass
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg took: 0:00:00.000000\n')

    with patch('sys.stderr') as stderr:
        with log.debug_time('msg'):
            pass
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg took: 0:00:00.000000\n')

# Generated at 2022-06-18 07:11:40.227839
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-18 07:11:46.788356
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(u'test took: 0:00:00.000000')

# Generated at 2022-06-18 07:11:50.160077
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called

# Generated at 2022-06-18 07:12:05.069536
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))
    show_corrected_command(CorrectedCommand('ls', 'ls -a', True))

# Generated at 2022-06-18 07:12:08.149216
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -a'))
    show_corrected_command(Command('ls', 'ls -a', True))


# Generated at 2022-06-18 07:12:10.402759
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:12:19.398638
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.utils import ConfigurationDetails
    from thefuck.shells import Shell
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.fish import Fish
    from thefuck.shells.tcsh import Tcsh
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.xonsh import Xonsh
    from thefuck.shells.elvish import Elvish
    from thefuck.shells.ion import Ion
    from thefuck.shells.cmd import Cmd
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.elvish import Elvish
    from thefuck.shells.ion import Ion
    from thefuck.shells.cmd import Cmd


# Generated at 2022-06-18 07:12:24.621457
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('foo')
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')



# Generated at 2022-06-18 07:12:35.709706
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        confirm_text(const.CorrectedCommand('ls', False))

# Generated at 2022-06-18 07:12:37.848902
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('ls', 'ls -l', True))

# Generated at 2022-06-18 07:12:39.831710
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:12:48.166750
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.python import match, get_new_command
    from .rules.perl import match, get_new_command
    from .rules.ruby import match, get_new_command
    from .rules.golang import match, get_new_command
    from .rules.haskell import match, get_new_command
    from .rules.nodejs import match, get_new_command
    from .rules.php import match, get_new_command
    from .rules.java import match, get_new_command
    from .rules.rust import match, get_new_command
    from .rules.swift import match, get_new_command


# Generated at 2022-06-18 07:12:51.088703
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('foo'):
            pass
        debug.assert_called_once_with(
            u'foo took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:13:08.337597
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('test_confirm_text.txt', 'w')
    confirm_text('test')
    sys.stderr.close()
    with open('test_confirm_text.txt', 'r') as f:
        assert f.read() == '>test [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-18 07:13:11.808463
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:22.954590
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .utils import get_closest
    from .conf import settings
    from . import const

    settings.no_colors = False
    settings.require_confirmation = True
    settings.wait_command = 0.1

    shell = Shell()
    shell.get_command = lambda: 'ls'
    shell.get_history = lambda: ['ls', 'ls -la']
    shell.put_to_history = lambda x: None

    corrected_command = CorrectedCommand('ls -la', None)
    confirm_text(corrected_command)
    assert get_closest(shell.get_history(), 'ls') == 'ls -la'

    corrected_command = CorrectedCommand('ls -la', None)

# Generated at 2022-06-18 07:13:25.404711
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-18 07:13:37.289599
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_root
    from .rules.git import _get_git_command
    from .rules.git import _get_git_command_name
    from .rules.git import _get_git_command_args
    from .rules.git import _get_git_command_args_str
    from .rules.git import _get_git_command_args_str_with_subcommand
    from .rules.git import _get_git_command_args_str_without_subcommand
    from .rules.git import _get_git_command_args_str_without_subcommand_and_br

# Generated at 2022-06-18 07:13:41.209630
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-18 07:13:42.072507
# Unit test for function confirm_text
def test_confirm_text():
    # TODO: write unit test
    pass

# Generated at 2022-06-18 07:13:45.737069
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr') as stderr:
        confirm_text(None)
        assert stderr.write.called
        assert stderr.write.call_args[0][0].startswith(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:13:54.703190
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text

    with patch('sys.stderr') as stderr:
        confirm_text('ls')
        stderr.write.assert_called_once_with(
            u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            u'/{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-18 07:14:05.475249
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from mock import patch

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    output = out.getvalue().strip()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test'


# Generated at 2022-06-18 07:14:18.264858
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-18 07:14:21.928646
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))

# Generated at 2022-06-18 07:14:33.069303
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .utils import wrap_command
    from .command import Command
    from .rules.git import match, get_new_command
    from .rules.git import _get_git_root
    from .rules.git import _get_git_cmd
    from .rules.git import _get_git_cmd_output
    from .rules.git import _get_git_cmd_output_lines
    from .rules.git import _get_git_cmd_output_lines_with_commit
    from .rules.git import _get_git_cmd_output_lines_with_commit_and_file
    from .rules.git import _get_git_cmd_output_lines_with_commit_and_file_and_line
    from .rules.git import _get_git_cmd_output_lines_with_

# Generated at 2022-06-18 07:14:38.042315
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from thefuck.utils import debug_time

    with patch('thefuck.utils.debug') as debug:
        with debug_time('test'):
            pass
        debug.assert_called_once_with(
            u'test took: {}'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:14:40.092913
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:14:40.991325
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:14:51.180895
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue() == ''
    assert err.getvalue() == ''

    with captured_output() as (out, err):
        settings.debug = True
        debug('test')
   

# Generated at 2022-06-18 07:15:01.283916
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    with wrap_settings(no_colors=False):
        confirm_text(Command('ls', '', '', '', '', '', ''))
        confirm_text(Command('ls', '', '', '', '', '', '', side_effect=True))
        confirm_text(Command('ls', '', '', '', '', '', '',
                             script_parts=Bash().script_from_shebang('#!/bin/bash')))
        confirm_text(Command('ls', '', '', '', '', '', '',
                             script_parts=Bash().script_from_shebang('#!/bin/bash'),
                             side_effect=True))

# Generated at 2022-06-18 07:15:03.119860
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -l'))



# Generated at 2022-06-18 07:15:05.899779
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    shell.shell = Bash()
    confirm_text(CorrectedCommand('ls', 'ls -l'))

# Generated at 2022-06-18 07:15:33.765728
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    import sys
    import io
    sys.stderr = io.StringIO()
    show_corrected_command(Command('ls', 'ls -a'))
    assert sys.stderr.getvalue() == u'{}ls -a\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-18 07:15:35.345783
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-18 07:15:45.475511
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .shells import Bash
    from .types import CorrectedCommand
    import sys
    import io
    sys.stderr = io.StringIO()

# Generated at 2022-06-18 07:15:48.195671
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    corrected_command = Mock()
    corrected_command.script = 'ls -la'
    corrected_command.side_effect = False
    confirm_text(corrected_command)
    corrected_command.side_effect = True
    confirm_text(corrected_command)

# Generated at 2022-06-18 07:15:58.138941
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Bash
    from thefuck.types import Command
    from thefuck.utils import wrap_settings
    from thefuck.rules.git import match, get_new_command
    from thefuck.rules.git import _parse_branch
    from thefuck.rules.git import _get_branch_name
    from thefuck.rules.git import _get_branch_names
    from thefuck.rules.git import _get_branch_names_with_remotes
    from thefuck.rules.git import _get_branch_names_with_remotes_and_current
    from thefuck.rules.git import _get_branch_names_with_remotes_and_current_and_stash
    from thefuck.rules.git import _get_branch_names_with_remotes_and_

# Generated at 2022-06-18 07:16:07.439475
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest, get_alias
    from .conf import Configuration
    from . import const

    shell = Shell('bash', 'bash', 'bash')

# Generated at 2022-06-18 07:16:13.135001
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.bashrc',
        can_configure_automatically=False))

# Generated at 2022-06-18 07:16:14.515075
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls', 'ls -G'))

# Generated at 2022-06-18 07:16:16.689243
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='git push origin master') == 'git push origin master [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-18 07:16:21.373820
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('sys.stderr') as stderr:
        with debug_time('test'):
            pass
        stderr.write.assert_called_once_with(
            u'test took: {}\n'.format(timedelta(seconds=0)))

# Generated at 2022-06-18 07:17:14.318333
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    from .conf import ConfigurationDetails
    from . import const
    import os
    import tempfile
    import shutil

    def get_configuration_details(shell):
        return ConfigurationDetails(
            shell.app_alias,
            shell.get_aliases(),
            shell.get_aliases_source_name(),
            shell.get_aliases_source_path(),
            shell.reload_command,
            shell.app_alias in shell.get_aliases())

    def get_shell(shell_name):
        return get_closest(shell_name, const.AVAILABLE_SHELLS)

    def get_temp_file_path():
        temp_dir = tempfile.mkdtemp()
        temp_file = os.path

# Generated at 2022-06-18 07:17:17.095033
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-18 07:17:17.945137
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-18 07:17:21.810581
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')