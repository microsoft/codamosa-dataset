

# Generated at 2022-06-22 00:51:03.749031
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise RuntimeError('BOOOM')
    except RuntimeError as e:
        assert rule_failed(object(), sys.exc_info()) == exception(u'Rule ', sys.exc_info())
        assert rule_failed(object(), sys.exc_info()).split('\n')[0] == '[WARN] Rule '
        assert rule_failed(object(), sys.exc_info()).split('\n')[1] == '----------------------------'

# Generated at 2022-06-22 00:51:04.797426
# Unit test for function warn
def test_warn():
    warn('Title')



# Generated at 2022-06-22 00:51:08.382609
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:51:11.999106
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .manage import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=True,
        path='~/.zshrc',
        reload='source ~/.zshrc'))



# Generated at 2022-06-22 00:51:14.638318
# Unit test for function color
def test_color():
    assert color('RED') == 'RED'
    settings.no_colors = True
    assert color('RED') == ''



# Generated at 2022-06-22 00:51:15.797880
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:51:20.961571
# Unit test for function version
def test_version():
    # sys.stderr = ...
    print(version('2.0', '3.6', 'bash'))
    # ... = sys.stderr
    assert(sys.stderr.write == u'The Fuck 2.0 using Python 3.6 and bash\n')


# Generated at 2022-06-22 00:51:22.086868
# Unit test for function warn
def test_warn():
    warn(u'error')

# Generated at 2022-06-22 00:51:24.656679
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    print('Test how_to_configure_alias - OK')


# Generated at 2022-06-22 00:51:30.592123
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command:
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(corrected_command('echo 1', False)) == None
    assert show_corrected_command(corrected_command('echo 1', True)) == None

# Generated at 2022-06-22 00:51:44.948374
# Unit test for function already_configured
def test_already_configured():
    from .utils import capture_output
    from . import shells

    def shell_info(shell):
        return shells.get_shell_info(shell)['shell_info']

    with capture_output() as (out, _):
        already_configured(shell_info('bash'))
        assert u'thefuck' in out.getvalue()
        assert u'Bash' in out.getvalue()

    with capture_output() as (out, _):
        already_configured(shell_info('fish'))
        assert u'thefuck' in out.getvalue()
        assert u'Fish' in out.getvalue()

    with capture_output() as (out, _):
        already_configured(shell_info('zsh'))
        assert u'thefuck' in out.getvalue()

# Generated at 2022-06-22 00:51:47.960913
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Some error')
    except RuntimeError:
        exception(u'Foo', sys.exc_info())

# Generated at 2022-06-22 00:51:57.031564
# Unit test for function configured_successfully
def test_configured_successfully():
    with patch('sys.stdout', new_callable=StringIO) as fake_out:
        configuration_details = ConfigurationDetails(
            can_configure_automatically=True,
            path='~/.config/fish/test.test',
            reload='reload')
        configured_successfully(configuration_details)
        assert fake_out.getvalue() == ('\x1b[1mfuck\x1b[21m alias configured'
                                       ' successfully!\nFor applying changes '
                                       'run \x1b[1mreload\x1b[21m or restart '
                                       'your shell.\n')

# Generated at 2022-06-22 00:51:58.861214
# Unit test for function debug_time
def test_debug_time():
    with debug_time('some operation'):
        pass

# Generated at 2022-06-22 00:52:03.190407
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.zsh import Zsh
    from .shells.autosuggestions import ZshWithAutosuggestions

    plain = Zsh()
    enhanced = ZshWithAutosuggestions()

    assert confirm_text(plain) == '>'
    assert confirm_text(enhanced) == '> '

# Generated at 2022-06-22 00:52:05.722844
# Unit test for function rule_failed
def test_rule_failed():
    from .types import Rule
    rule_failed(Rule('Name', lambda x: x, 'Match'), ('t', 'v', 'tb'))
    assert True

# Generated at 2022-06-22 00:52:09.811902
# Unit test for function failed
def test_failed():
    """
    TODO: because stderr is used, it would be cool to get tested text
    >>> print failed('test text')
    """
    pass



# Generated at 2022-06-22 00:52:12.971378
# Unit test for function version
def test_version():
    version('3.2', '2.7', 'Bash 3.2')
    version('3.2', '2.7', 'Bash 3.2')



# Generated at 2022-06-22 00:52:14.156323
# Unit test for function already_configured
def test_already_configured():
    assert already_configured == already_configured

# Generated at 2022-06-22 00:52:22.450020
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import print_output
    with print_output() as (out, _):
        from .corrector import CorrectedCommand
        confirm_text(CorrectedCommand('ls', ''))
        assert out.getvalue() == const.USER_COMMAND_MARK + 'ls [+side effect] '\
            '[\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/'\
            '\x1b[31mctrl+c\x1b[0m]\n'

# Generated at 2022-06-22 00:52:28.516318
# Unit test for function color
def test_color():
    assert color(None) == ''
    settings.no_colors = True
    assert color(None) == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:52:31.036073
# Unit test for function failed
def test_failed():
    assert failed('a') == u'\x1b[31ma\x1b[0m\n'



# Generated at 2022-06-22 00:52:34.803208
# Unit test for function color
def test_color():
    colorama.init()
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-22 00:52:37.160712
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('test') == 'Seems like fuck alias already configured!\nFor applying changes run test or restart your shell.'



# Generated at 2022-06-22 00:52:39.832556
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(
        how_to_configure_alias.configuration_details)

# Generated at 2022-06-22 00:52:40.893624
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('source ~/.bashrc')

# Generated at 2022-06-22 00:52:42.347454
# Unit test for function warn
def test_warn():
    warn('Title')
    # TODO: assert sys.stderr


# Generated at 2022-06-22 00:52:45.129455
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    rule = Rule('', '', '', lambda c: None)
    rule.name = 'restart-server'
    rule_failed(rule, 'testing')

# Generated at 2022-06-22 00:52:54.284683
# Unit test for function debug
def test_debug():
    result = []

    class Writer(object):
        def write(self, msg):
            result.append(msg)

    # Mock stdout
    old_stdout = sys.stderr
    sys.stderr = Writer()

    debug(u'foobar')
    assert u'\033[1K\r\x1b[34;1mDEBUG:\x1b[0m foobar\n' == result[0]
    assert result == [u'\033[1K\r\x1b[34;1mDEBUG:\x1b[0m foobar\n']

    # Restore stdout
    sys.stderr = old_stdout

# Generated at 2022-06-22 00:52:55.994533
# Unit test for function configured_successfully
def test_configured_successfully():
    import colorama
    from .conf import settings
    configured_successfully(colorama,settings)

# Generated at 2022-06-22 00:53:09.183302
# Unit test for function show_corrected_command
def test_show_corrected_command():
    for script, output in [
        ('git comm', u'\x1b[0;1m$ git comm\x1b[0m\n'),
        ('git comm', u'$ git comm\n'),
        ('git comm', u'\x1b[0;1m$ git comm (+side effect)\x1b[0m\n'),
        ('git comm', u'$ git comm (+side effect)\n'),
    ]:
        corrected_command = settings.CorrectedCommand(script, False)
        assert show_corrected_command(corrected_command) == output

test_show_corrected_command()

# Generated at 2022-06-22 00:53:11.379283
# Unit test for function version
def test_version():
    assert version(2, 3, 4) == u'The Fuck 2 using Python 3 and 4\n'

# Generated at 2022-06-22 00:53:13.529741
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.git import git_support
    rule_failed(git_support, ('type', 'value', 'traceback'))


# Generated at 2022-06-22 00:53:18.455802
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrector import CorrectedCommand
    from .shells import Shell

    assert show_corrected_command(
        CorrectedCommand(Command(), Shell())) == '> ls -alF'



# Generated at 2022-06-22 00:53:20.177953
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:53:21.568442
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:53:31.858062
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import unittest
    import mock

    class TestShowCorrectedCommand(unittest.TestCase):
        def test_without_side_effect(self):
            from .command import Command
            with mock.patch('sys.stderr') as mock_stderr:
                show_corrected_command(Command(script='script', side_effect=False))
            mock_stderr.write.assert_called_with(u'[FUCK] script\n')

        def test_with_side_effect(self):
            from .command import Command
            with mock.patch('sys.stderr') as mock_stderr:
                show_corrected_command(Command(script='script', side_effect=True))

# Generated at 2022-06-22 00:53:33.006939
# Unit test for function warn
def test_warn():
    warn('This is test warning')



# Generated at 2022-06-22 00:53:38.481851
# Unit test for function failed
def test_failed():
    print(failed('This is a message!'))
    # Seems like alias already configured!
    # For applying changes run
    # 'source ~/.bashrefresh' or restart your shell.
    print(how_to_configure_alias('configuration_details'))


# Generated at 2022-06-22 00:53:39.959445
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(rule='rule', exc_info='exc_info')


# Generated at 2022-06-22 00:53:43.985039
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('configuration_details')

# Generated at 2022-06-22 00:53:46.095724
# Unit test for function version
def test_version():
    version(u'3.13', u'3.3', u'BASH 3.2.57')

# Generated at 2022-06-22 00:53:56.045638
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    result = """\
Seems like {bold}fuck{reset} alias isn't configured!

Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.

Or run {bold}fuck{reset} a second time to configure it automatically.

More details - https://github.com/nvbn/thefuck#manual-installation""".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        path='',
        content='',
        reload='')
    assert result == how_to_configure_alias(None)


# Generated at 2022-06-22 00:53:56.914649
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('[fuck]')

# Generated at 2022-06-22 00:54:06.702779
# Unit test for function exception
def test_exception():
    msg = 'some message'
    exc_info = (ArithmeticError, ArithmeticError(msg), None)

    exception('test', exc_info)

    assert sys.stderr.getvalue() == \
        u'{warn}[WARN] test:{reset}\n{trace}'\
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            trace=format_exception(*exc_info))



# Generated at 2022-06-22 00:54:12.647457
# Unit test for function debug
def test_debug():
    import mock
    import _pytest.monkeypatch
    from thefuck.utils import debug
    monkeypatch = _pytest.monkeypatch.monkeypatch()
    try:
        with mock.patch('thefuck.utils.sys.stderr') as stderr:
            debug('test debug')
            assert stderr.write.called
        debug('test debug')
        assert not stderr.write.called
    finally:
        monkeypatch.undo()

# Generated at 2022-06-22 00:54:23.112932
# Unit test for function confirm_text
def test_confirm_text():
    # mock module sys
    class test_module_class:
        def __init__(self): self.stderr = ''
        def write(self, str): self.stderr += str
    sys = test_module_class()

    confirm_text(const.CorrectedCommand('a', False))
    assert sys.stderr == u'\033[1K\r%fuck a [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m] '

# Generated at 2022-06-22 00:54:24.317265
# Unit test for function configured_successfully
def test_configured_successfully():
    assert True



# Generated at 2022-06-22 00:54:29.126174
# Unit test for function color
def test_color():
    assert not settings.no_colors
    assert color('\033[0m\033[43m') == '\033[0m\033[43m'
    settings.no_colors = True
    assert color('\033[0m\033[43m') == ''

# Generated at 2022-06-22 00:54:32.876421
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    rule_failed(rule, sys.exc_info())
    try:
        raise Exception('error')
    except:
        rule_failed(rule, sys.exc_info())


# Generated at 2022-06-22 00:54:36.496535
# Unit test for function warn
def test_warn():
    warn('test_title')



# Generated at 2022-06-22 00:54:48.616979
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import subprocess

    from thefuck import conf


# Generated at 2022-06-22 00:54:52.697222
# Unit test for function color
def test_color():
    assert color('fail') == 'fail'
    assert color('fail') != '{fail}'
    settings.no_colors = True
    assert color('fail') == ''
    assert color('fail') != '{fail}'



# Generated at 2022-06-22 00:55:00.997769
# Unit test for function debug
def test_debug():
    import os
    import mock
    import sys

    with mock.patch.dict(
            os.environ, {'TF_DEBUG': ''}, clear=True):
        assert not settings.debug
        debug('msg')
        assert not sys.stderr.getvalue()

    with mock.patch.dict(
            os.environ, {'TF_DEBUG': '1'}, clear=True):
        assert settings.debug
        debug('msg')
        assert 'DEBUG: msg' in sys.stderr.getvalue()

# Generated at 2022-06-22 00:55:03.108928
# Unit test for function already_configured

# Generated at 2022-06-22 00:55:07.244088
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('upgrade') == u'\x1b[1K\r➜ upgrade [\x1b[92menter\x1b[0m/\x1b[94m↓\x1b[0m]'

# Generated at 2022-06-22 00:55:14.103572
# Unit test for function failed
def test_failed():
    if sys.version_info[0] == 3:
        from io import StringIO
    else:
        from StringIO import StringIO

    if sys.version_info[0] == 3:
        output = StringIO()
    else:
        output = StringIO(unicode(''))
    sys.stderr = output
    failed(u'foo')
    assert output.getvalue() == u'foo\n'

# Generated at 2022-06-22 00:55:23.020338
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    for request_get_script in ['ls', 'ls -al', 'ls -al /tmp']:
        mocked_corrected_command = mock.Mock(script=request_get_script,
                                             side_effect=True)
        with mock.patch('sys.stdout') as mocked_output:
            confirm_text(mocked_corrected_command)

        expected = """\
>ls -al
ls: cannot access -al: No such file or directory

Did you mean `ls --all`"""

        mocked_output.write.assert_called_once_with(expected)

# Generated at 2022-06-22 00:55:26.462339
# Unit test for function configured_successfully
def test_configured_successfully():
    details = {'path': "path", 'content': "content", 'reload': "reload"}
    configured_successfully(details)


# Generated at 2022-06-22 00:55:27.730556
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:55:34.565540
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command(corrected_command)
    print('\033[1K\r')
    confirm_text(corrected_command)
    #print('\033[1K\r')
    #confirm_text(corrected_command)

# Generated at 2022-06-22 00:55:42.198392
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('\u041f\u0440\u0438\u0432\u0435\u0442, '
                           '\u043c\u0438\u0440!')
    except RuntimeError:
        exception('\u041f\u0440\u0438\u0432\u0435\u0442, \u043c\u0438\u0440!',
                  sys.exc_info())

# Generated at 2022-06-22 00:55:43.299630
# Unit test for function debug
def test_debug():
    debug('Test')



# Generated at 2022-06-22 00:55:44.722939
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:55:47.373761
# Unit test for function failed
def test_failed():
    try:
        raise Exception('fail')
    except Exception as e:
        failed('Error')
        assert '\033[31mError\033[0m\n' in e.output



# Generated at 2022-06-22 00:55:47.971919
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass


# Generated at 2022-06-22 00:55:50.994543
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass
    try:
        raise TestException()
    except TestException:
        exception('Test', sys.exc_info())

# Generated at 2022-06-22 00:55:56.950066
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        assert const.USER_COMMAND_MARK * 3 + u'[WARN] TestException:' + '\n' + \
               const.USER_COMMAND_MARK * 15 + '\n\n' \
               == exception(u'TestException', sys.exc_info())



# Generated at 2022-06-22 00:55:57.742046
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:56:00.306618
# Unit test for function color
def test_color():
    assert color(u'foo') == 'foo'
    settings.no_colors = True
    assert color(u'foo') == ''

# Generated at 2022-06-22 00:56:11.471903
# Unit test for function configured_successfully
def test_configured_successfully():
    for line in configured_successfully({
        'source': '~/.bashrc',
        'reload': 'source ~/.bashrc'}).split('\n'):
        assert line in (
            (u'{bold}fuck{reset} alias configured successfully!'
             u'\nFor applying changes run {bold}source ~/.bashrc{reset}'
             u' or restart your shell.').format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)),
            u'')

# Generated at 2022-06-22 00:56:14.728636
# Unit test for function version
def test_version():
    assert version('3.11', '3.5.2', 'bash') == u'The Fuck 3.11 using Python 3.5.2 and bash\n'

# Generated at 2022-06-22 00:56:23.729005
# Unit test for function confirm_text
def test_confirm_text():
    from . import settings
    settings._no_colors = False
    from .utils import confirm_text
    from .command import Command
    import sys
    sys.stderr = open('test_write.txt', 'w')
    confirm_text(Command('test'))
    sys.stderr.close()
    f = open('test_write.txt', 'r')
    test_string = f.readline()
    f.close()
    return test_string == '$ test [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-22 00:56:26.258547
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules import RulesCollection
    from thefuck.shit import CorrectedCommand
    show_corrected_command(CorrectedCommand(
        script=u'fuck cd /usr/share/nginx/html && ls *.jpg',
        side_effect=False))



# Generated at 2022-06-22 00:56:39.521794
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('tests/test_log.txt', 'w')
    show_corrected_command("ls -a")
    sys.stderr.close()
    try:
        with open("tests/test_log.txt", "r") as test_file:
            assert test_file.readline() == u'{prefix}ls -a{reset}\n'.format(
                prefix=const.USER_COMMAND_MARK,
                script=corrected_command.script,
                reset=color(colorama.Style.RESET_ALL))
        os.remove("tests/test_log.txt")
        print("\nCorrected Command Output")
        print("\nTest Passed")
    except AssertionError:
        print("\nCorrected Command Output")
        print("\nTest Failed")


# Generated at 2022-06-22 00:56:40.648376
# Unit test for function warn
def test_warn():
    warn('Title')



# Generated at 2022-06-22 00:56:43.589422
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(''.join(format_exception(1, 2, 3)))

if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-22 00:56:47.035132
# Unit test for function warn
def test_warn():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    warn('title')
    assert '[WARN] title' in out.getvalue()


# Generated at 2022-06-22 00:56:49.380402
# Unit test for function warn
def test_warn():
    result = u'[WARN] Test warn\n'
    warn('Test warn')
    assert sys.stderr.getvalue() == result



# Generated at 2022-06-22 00:56:52.252196
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(const.ConfigurationDetails(reload=u'source $HOME/.bashrc', can_configure_automatically=True))



# Generated at 2022-06-22 00:56:59.916608
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command

    assert show_corrected_command(Command('', '')) == '   '

    assert show_corrected_command(Command('ls', 'ls')) == 'ls'

    assert show_corrected_command(Command('ls', 'ls', side_effect=True)) == 'ls (+side effect)'

# Generated at 2022-06-22 00:57:02.033338
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'git push origin master'
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:57:12.499505
# Unit test for function already_configured
def test_already_configured():
    fake_configuration_details = configuration_details = get_configuration_details()
    # Mocking sys.stdout.write
    sys.stdout.write = Mock()
    already_configured(fake_configuration_details)
    sys.stdout.write.assert_called_with(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.\n".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload))



# Generated at 2022-06-22 00:57:25.110302
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """
    test for function how_to_configure_alias
    """
    # def how_to_configure_alias(configuration_details):
    configuration_details = (1, 2, 3, 4, 5)
    # print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
    #         bold=color(colorama.Style.BRIGHT),
    #         reset=color(colorama.Style.RESET_ALL)))
    # if configuration_details:
    #     print(
    #         u"Please put {bold}{content}{reset} in your "
    #         u"{bold}{path}{reset} and apply "
    #         u"changes with {bold}{reload}{reset} or restart your shell.".format(
    #             bold=color(colorama.Style.BRIGHT),

# Generated at 2022-06-22 00:57:27.516156
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('foo')
    except ValueError:
        exception(u'Exception title', sys.exc_info())

# Generated at 2022-06-22 00:57:29.430992
# Unit test for function confirm_text
def test_confirm_text():
    x = correct_command(u'ls', False, False)
    confirm_text(x)


# Generated at 2022-06-22 00:57:31.645572
# Unit test for function exception
def test_exception():
    exception('Foo', ('Bar', 'Baz', 'Qux'))


# Generated at 2022-06-22 00:57:37.506031
# Unit test for function rule_failed
def test_rule_failed():
    from .utils import wrap_streams
    with wrap_streams() as (out, err):
        warn(u'Title')
        assert out.getvalue() == u''
        assert err.getvalue() == \
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] Title\x1b[0m\n'



# Generated at 2022-06-22 00:57:42.919587
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            can_configure_automatically=True,
            content=u'content',
            path=u'path',
            reload=u'reload'))



# Generated at 2022-06-22 00:57:43.692438
# Unit test for function failed
def test_failed():
    failed(u'Гавно')



# Generated at 2022-06-22 00:57:48.542277
# Unit test for function warn
def test_warn():
    from mock import patch
    from StringIO import StringIO

    stdout = sys.stderr
    sys.stderr = StringIO()

    warn('title')

    assert sys.stderr.getvalue() == u'[WARN] title\n'
    sys.stderr = stdout



# Generated at 2022-06-22 00:57:49.674949
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-22 00:57:58.194506
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock
    mocked_stdout = StringIO.StringIO()
    with patch('sys.stderr', mocked_stdout):
        show_corrected_command(MagicMock(side_effect=True))
    assert mocked_stdout.getvalue() == '> ' + color(colorama.Style.BRIGHT) + '()' + color(colorama.Style.RESET_ALL) + ' (+side effect)\n'

# Generated at 2022-06-22 00:58:00.005273
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    show_corrected_command(CorrectedCommand(u'command', True))
    assert sys.stderr.getvalue() == u'>command (+side effect)\n'

    show_corrected_command(CorrectedCommand(u'command', False))
    assert sys.stderr.getvalue() == u'>command\n'



# Generated at 2022-06-22 00:58:02.483291
# Unit test for function already_configured

# Generated at 2022-06-22 00:58:08.822668
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out

    from types import SimpleNamespace
    corrected_command = SimpleNamespace(script='git push origin master:master',
                                        side_effect=False)

    show_corrected_command(corrected_command)
    output = out.getvalue().strip()
    assert output == '$ git push origin master:master'


# Generated at 2022-06-22 00:58:21.387735
# Unit test for function configured_successfully
def test_configured_successfully():
    import click
    import mock
    import os

    dir = '/tmp/thefuck-testing'
    os.mkdir(dir)

    with mock.patch('thefuck.shells.get_shell', return_value='bash'):
        with mock.patch('os.environ', {'HOME': dir,
                                       'XDG_CONFIG_HOME': '',
                                       'XDG_DATA_HOME': '',
                                       'ZDOTDIR': '',
                                       'USERPROFILE': '',
                                       'APPDATA': ''}):
            with mock.patch('click.secho') as secho:
                configured_successfully(click.types.Dict())


# Generated at 2022-06-22 00:58:26.719746
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .app import fuck_alias_configured
    from .shells import Shell
    from .utils import get_closest

    configuration_details = fuck_alias_configured(Shell('bash', ''))
    details = get_closest([configuration_details])[0]
    how_to_configure_alias(details)



# Generated at 2022-06-22 00:58:27.592332
# Unit test for function warn
def test_warn():
    warn('Title')


# Generated at 2022-06-22 00:58:29.466706
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None) == None

# Generated at 2022-06-22 00:58:34.207449
# Unit test for function warn
def test_warn():
    warn('Test')



# Generated at 2022-06-22 00:58:36.393315
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells.bash import Bash
    assert 'fuck' in configured_successfully(Bash())

# Generated at 2022-06-22 00:58:39.097883
# Unit test for function exception
def test_exception():
    try:
        exec('1/0')
    except:
        exception('Test exception', sys.exc_info())



# Generated at 2022-06-22 00:58:40.913825
# Unit test for function debug_time
def test_debug_time():
    from time import time
    from .conf import settings
    settings.debug = True
    with debug_time('test'):
        time.sleep(0.1)


# Generated at 2022-06-22 00:58:50.233444
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .prompt import ConfigurationDetails
    from .shells import Shell
    from .shells.zsh import Zsh

    zsh_shell = Zsh()
    zsh_configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        reload='source ~/.zshrc',
        path='.zshrc',
        content='eval $(thefuck --alias)')
    assert how_to_configure_alias(zsh_configuration_details) is None

    bash_shell = Shell()
    bash_configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        reload='source ~/.bashrc',
        path='.bashrc',
        content='eval $(thefuck --alias)')

# Generated at 2022-06-22 00:58:54.244669
# Unit test for function color
def test_color():
    assert color(u'привет') == u'привет'
    settings.no_colors = True
    assert color(u'привет') == u''

# Generated at 2022-06-22 00:58:58.283859
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.git_reset import match, get_new_command
    rule_failed(type('git_reset', (object,), {'name':'git_reset'}),
                get_new_command('git dod', match))

# Generated at 2022-06-22 00:59:01.271064
# Unit test for function configured_successfully
def test_configured_successfully():
    config_details = type('', (), {'reload': u'dot source'})()
    assert configured_successfully(config_details) == None

# Generated at 2022-06-22 00:59:06.661532
# Unit test for function warn
def test_warn():
    import testfixtures
    with testfixtures.OutputCapture() as out:
        warn(u'Unit test')
    assert out.captured == [u'\x1b[41m\x1b[37m\x1b[1m[WARN] Unit test\x1b[0m\n']



# Generated at 2022-06-22 00:59:15.497531
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(const.ConfigurationDetails(
        reload='source ~/.bashrc',
        can_configure_automatically=True,
        path='~/.bashrc',
        content=('eval $(thefuck --alias)',
                 'eval $(thefuck --alias --enable-experimental-instant-mode)'))) == \
        u'\x1b[1mfuck\x1b[21m alias configured successfully!\n' \
        u'For applying changes run \x1b[1msource ~/.bashrc\x1b[21m or ' \
        u'restart your shell.'

# Generated at 2022-06-22 00:59:30.481506
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from string import Template
    t = Template(u"$boldSeems like $boldfuck$reset alias isn't configured!")
    assert how_to_configure_alias(None) == t.substitute(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))
    t = Template(u"Please put $bold$content$reset in your $bold$path$reset and apply changes with $bold$reload$reset or restart your shell.")

# Generated at 2022-06-22 00:59:41.878668
# Unit test for function debug
def test_debug():
    from mock import patch
    from functools import partial

    with patch('sys.stderr') as mock_stderr:
        debug('foo')
    debug_call = partial(mock_stderr.write.assert_called_once_with,
                         u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

    with patch.dict('os.environ', {'TF_DEBUG': '1'}):
        debug_call()


# Generated at 2022-06-22 00:59:46.725389
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with open('data', 'w') as f:
        f.write(u'git push origin master\n')
    with open('data', 'r') as f:
        #assert show_corrected_command(u'git push origin master') == f.read()
        pass

# Generated at 2022-06-22 00:59:51.542433
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(u'configuration_details') == print(u'fuck alias configured successfully!\nFor applying changes run \u001b[1m\u001b[34mconfiguration_details\u001b[39m\u001b[0m or restart your shell.')


# Generated at 2022-06-22 00:59:52.833298
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text("ls -al")
    confirm_text("ls")

# Generated at 2022-06-22 00:59:54.529094
# Unit test for function already_configured

# Generated at 2022-06-22 00:59:58.831114
# Unit test for function exception
def test_exception():
    sys.stderr = open('/dev/null', 'w')
    exception(u'Error', ('title', None, None))
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 01:00:01.959079
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    from thefuck.utils import CorrectedCommand
    show_corrected_command(
        CorrectedCommand(u'ls', u'ls', Shell()))

# Generated at 2022-06-22 01:00:07.413441
# Unit test for function version
def test_version():
    from thefuck.conf import get_version as thefuck_version
    from thefuck.shells import get_shell_info
    import platform
    import sys
    assert version(thefuck_version(),
                   '{}.{}.{}'.format(*sys.version_info[:3]),
                   get_shell_info(platform.system()))

# Generated at 2022-06-22 01:00:09.761902
# Unit test for function version
def test_version():
    version('1.2.3', '2.7.10', 'ZSH 5.0.8')



# Generated at 2022-06-22 01:00:24.554885
# Unit test for function debug
def test_debug():
    class TestStderr(object):
        def __init__(self):
            self.content = u''

        def write(self, content):
            self.content = content

        def flush(self):
            pass

    sys.modules['sys'].stderr = TestStderr()
    debug(u'foobar')
    assert u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foobar' in sys.stderr.content, sys.stderr.content
    del sys.modules['sys'].stderr



# Generated at 2022-06-22 01:00:27.976482
# Unit test for function confirm_text
def test_confirm_text():
    from .command import Command
    from .rule import Rule

    corrected_command = Command(script="echo", side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-22 01:00:29.954821
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time("test"):
        time.sleep(0.1)

# Generated at 2022-06-22 01:00:31.532193
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('Debug msg')
    settings.debug = False

# Generated at 2022-06-22 01:00:41.820602
# Unit test for function debug_time
def test_debug_time():
    import os
    import mock

    # We can't mock datetime.now because it returns a mocked object.
    # So we patch it inside the function and unpatch it after test.
    def now():
        return 'now'
    with mock.patch('thefuck.shells.generic.datetime') as mock_datetime:
        mock_datetime.now.side_effect = now
        with mock.patch.object(sys.stderr, 'write') as mock_stderr:
            with debug_time('msg'):
                pass
            mock_stderr.assert_called_once_with('{} took: now\n'.format(os.linesep))

# Generated at 2022-06-22 01:00:51.062810
# Unit test for function warn
def test_warn():
    import sys
    from . import conf
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output(stream_name):
        try:
            original_stdout = getattr(sys, stream_name)
            temp_stdout = StringIO()
            setattr(sys, stream_name, temp_stdout)
            yield temp_stdout
        finally:
            setattr(sys, stream_name, original_stdout)

    with captured_output('stderr') as output:
        warn(u'error')
        assert u'[WARN] error' in output.getvalue()

    with captured_output('stderr') as output:
        conf.settings.no_colors = True
        warn('error')
        assert 'error' in output.getvalue()


#

# Generated at 2022-06-22 01:00:52.581056
# Unit test for function debug_time
def test_debug_time():
    with debug_time('some guess'):
        sleep(0.1)