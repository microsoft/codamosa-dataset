

# Generated at 2022-06-22 00:51:05.689719
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('') == ''
    assert color('foo') == ''

# Generated at 2022-06-22 00:51:06.834177
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias('') == ''



# Generated at 2022-06-22 00:51:10.804485
# Unit test for function rule_failed
def test_rule_failed():
    from unittest import TestCase
    from .rules import AlwaysFail
    from .shells import Shell
    rule = AlwaysFail(shell=Shell)
    rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:51:17.072548
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('1.2.3') == 'Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.'.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='1.2.3')


# Generated at 2022-06-22 00:51:25.432247
# Unit test for function confirm_text
def test_confirm_text():
    colorama.init(autoreset=True)
    confirmed_text = 'fuck\n'
    show_corrected_command(confirmed_text)
    confirm_text(confirmed_text)
    for i in range(4):
        data = '{0}\n'.format(i + 1)
        sys.stdin.write(data)
        sys.stdin.flush()
        confirmed_text = data[:-1]
        show_corrected_command(confirmed_text)
        confirm_text(confirmed_text)
    sys.stdin.close()
    sys.stdin = open('/dev/tty')



# Generated at 2022-06-22 00:51:28.029773
# Unit test for function color
def test_color():
    import re
    assert re.match('\x1b\[30mT\x1b\[0m', color('T'))



# Generated at 2022-06-22 00:51:30.828743
# Unit test for function exception
def test_exception():
    try:
        1/0
    except ZeroDivisionError:
        exception('Title', sys.exc_info())


# Generated at 2022-06-22 00:51:33.707426
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple('ConfigDetails', ['reload'])
    already_configured(configuration_details._asdict())

# Generated at 2022-06-22 00:51:34.540242
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'wrong'
    exc_info = ('wrong', 'wrong', 'wrong')
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:51:36.596408
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'cat'
    exc_info = 'fail'
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:51:41.266538
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('\033[1m') == ''



# Generated at 2022-06-22 00:51:45.536075
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=True,
        reload='source .bashrc',
        path='.bashrc',
        content='eval $(thefuck --alias)',
    ))

# Generated at 2022-06-22 00:51:48.071131
# Unit test for function configured_successfully
def test_configured_successfully():
    conf_details = "Configured successfully"
    assert configured_successfully(conf_details)

# Generated at 2022-06-22 00:51:54.837812
# Unit test for function version
def test_version():
    thefuck_version = '3.11'
    python_version = '2.7.13 |Anaconda custom (64-bit)| (default, Dec 19 2016, 13:29:36) [MSC v.1500 64 bit (AMD64)]'
    shell_info = 'Shell "cmd", unknown version'
    version(thefuck_version, python_version, shell_info)


# Generated at 2022-06-22 00:51:56.193738
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(1,2)


# Generated at 2022-06-22 00:52:02.948689
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import re
    from . import shell

    with shell.create('bash') as shell:
        configuration_details = shell.get_automatically_configured_alias()
        if configuration_details:
            how_to_configure_alias(configuration_details)
            assert re.search(u'Seems like fuck alias isn\'t configured!',
                open('/tmp/thefuck-configure-test-output-1').read(), re.U)

# Generated at 2022-06-22 00:52:09.397892
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .const import ConfigurationDetails
    from .shells import Shell

    class TestOutput(object):
        def __init__(self):
            self.content = ""

        def write(self, msg):
            self.content = self.content + msg

    output = TestOutput()
    sys.stdout = output
    how_to_configure_alias(ConfigurationDetails(
        path='.config/fish/config.fish',
        content='alias fuck=\'eval (thefuck $(fc -ln -1))\'',
        reload='source .config/fish/config.fish',
        can_configure_automatically=True))


# Generated at 2022-06-22 00:52:14.219357
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    with StringIO() as buf, redirect_stderr(buf):
        confirm_text(CorrectedCommand('test', True))
        assert buf.getvalue().startswith('>test (+side effect) [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-22 00:52:17.256838
# Unit test for function rule_failed
def test_rule_failed():
    from tests.utils import RuleMock
    rule = RuleMock()
    rule_failed(rule, (None, None, None))

# Generated at 2022-06-22 00:52:21.747861
# Unit test for function debug_time
def test_debug_time():
    import io
    from datetime import timedelta

    stream = io.BytesIO()
    with debug_time('Testing'):
        import time
        time.sleep(0.1)

    output = stream.getvalue()
    assert 'Testing took: {}'.format(timedelta(seconds=0,
                                               microseconds=100000)) == output.decode('utf-8')

# Generated at 2022-06-22 00:52:30.181982
# Unit test for function rule_failed
def test_rule_failed():
    """
    >>> class Rule(object):
    ...   pass

    >>> rule = Rule()
    >>> rule.name = 'test_rule'
    >>> rule_failed(rule, ('Exception description', None, None))
    [WARN] Rule test_rule:
    Traceback (most recent call last):
    Exception description
    ----------------------------

    """

# Generated at 2022-06-22 00:52:31.766068
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('echo "hello world"')



# Generated at 2022-06-22 00:52:35.257385
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    from .rules import Command

    out = StringIO()
    sys.stderr = out
    confirm_text(Command('ls foo', 'ls'))
    assert out.getvalue()

# Generated at 2022-06-22 00:52:39.313755
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from .main import debug_time
    started = datetime.now()
    with debug_time('time'):
        pass
    assert(datetime.now() - started)

# Generated at 2022-06-22 00:52:40.368016
# Unit test for function debug
def test_debug():
    debug("message")



# Generated at 2022-06-22 00:52:47.047573
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    my_stream = StringIO()
    sys.stdout = my_stream
    configured_successfully(('source ~/.bash_profile',))
    assert my_stream.getvalue() == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}source ~/.bash_profile{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:52:48.759296
# Unit test for function exception
def test_exception():
    exception(u'Title', ('TypeError', TypeError(), None))


# Generated at 2022-06-22 00:52:52.493867
# Unit test for function rule_failed
def test_rule_failed():
    import pytest
    from .rules import Bash, get_rules

    rules = get_rules()
    rule = [_ for _ in rules if _.__class__ == Bash][0]

    with pytest.raises(Exception):
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:52:57.592121
# Unit test for function failed
def test_failed():
    import io
    import sys
    buf = io.StringIO()
    sys.stderr = buf
    failed('123')
    sys.stderr = sys.__stderr__
    assert u'\x1b[31m123\x1b[0m\n' == buf.getvalue()



# Generated at 2022-06-22 00:53:00.149415
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-22 00:53:03.953270
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("ahoj")


# Generated at 2022-06-22 00:53:09.009265
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'


# Generated at 2022-06-22 00:53:12.842049
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        '/home/user/.bashrc', '$PATH:/home/user/bin', 'source ~/.bashrc',
        True))


# Generated at 2022-06-22 00:53:19.145125
# Unit test for function warn
def test_warn():
    sys.stderr = open('/tmp/thefuck-test_warn','w')
    title = "This is a title"
    warn(title)
    sys.stderr.close()

    with open('/tmp/thefuck-test_warn') as f:
        text = f.read()
        assert title in text


# Generated at 2022-06-22 00:53:30.350218
# Unit test for function debug
def test_debug():
    class TestStream(object):
        def __init__(self):
            self.output = ''

        def write(self, msg):
            self.output += msg

    test_stream = TestStream()
    sys.stderr = test_stream
    settings.debug = True
    debug('test debug')
    assert test_stream.output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n'
    settings.debug = False
    debug('test debug')
    assert test_stream.output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n'

# Generated at 2022-06-22 00:53:36.874264
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    import sys
    old_stderr = sys.stderr
    stringio = StringIO.StringIO()
    sys.stderr = stringio

# Generated at 2022-06-22 00:53:46.525596
# Unit test for function failed
def test_failed():
    from .utils import trap
    from .utils import make_temp_directory
    from .utils import reset
    from .utils import set_env
    from .utils import unicode_argv
    from .main import get_logger

    logger = get_logger('test_failed')

    with make_temp_directory() as temp_dir, \
            trap(logger.failed, 'No such rule: `root`') as (logged_exc_info,), \
            set_env({'PATH': temp_dir}):
        unicode_argv('thefuck', '--no-colors', 'root')

    assert logged_exc_info is None



# Generated at 2022-06-22 00:53:57.428025
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    mock_stdout = StringIO()
    sys.stdout = mock_stdout
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:53:59.984720
# Unit test for function version
def test_version():
    sys.stderr.write(u'The Fuck 3.1 using Python 2.7 and Bash')



# Generated at 2022-06-22 00:54:03.659196
# Unit test for function failed
def test_failed():
    from tests.utils import mock

    with mock.patch('sys.stderr') as stderr:
        failed(u'Random_text')

        assert stderr.write.called == True

# Generated at 2022-06-22 00:54:13.814177
# Unit test for function warn
def test_warn():
    mock_sys = MagicMock()
    sys.stderr = mock_sys
    warn('title')
    mock_sys.write.assert_called_once_with(
        u'{warn}[WARN] {title}{reset}\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title='title'))
    sys.stderr = sys.__stderr__



# Generated at 2022-06-22 00:54:17.168282
# Unit test for function failed
def test_failed():
    failed('Message_test')
    assert sys.stderr.getvalue() == \
        u'\033[31mMessage_test\033[0m\n'

# Generated at 2022-06-22 00:54:20.761825
# Unit test for function color
def test_color():
    # colorama.init()  # uncomment if you want to see colored output
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''



# Generated at 2022-06-22 00:54:31.035245
# Unit test for function version
def test_version():
    def assert_output(capsys):
        sys.stderr.write('The Fuck {} using Python {} and {}\n'.format(
            '3.6', '3.4', 'fish'))
        sys.stderr.flush()
        expected, _ = capsys.readouterr()
        assert expected == 'The Fuck 3.6 using Python 3.4 and fish\n'

    class RunFake:
        def __init__(self):
            self.script = 'EXAMPLE'

        def __repr__(self):
            return u'<RunFake>'

    version('3.6', '3.4', 'fish')
    assert_output(capsys)

# Generated at 2022-06-22 00:54:38.980171
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import __version__
    configured_successfully(
        configuration_details=const.ConfigurationDetails('reload', 'path', 'content', True))
    assert sys.stdout.getvalue()

# Generated at 2022-06-22 00:54:40.662475
# Unit test for function version
def test_version():
    version("v3","Python 2.7.11","Bash")

# Generated at 2022-06-22 00:54:41.867494
# Unit test for function debug
def test_debug():
    debug(u'hello')

# Generated at 2022-06-22 00:54:52.528733
# Unit test for function rule_failed
def test_rule_failed():
    import tempfile
    from .rules.shells import Bash, Zsh

    with tempfile.NamedTemporaryFile() as tf:
        class TestRule(Bash, Zsh):
            name = 'test'
            version = '1.0'
            file = tf.name
            prioritity = 100

            def match(self, **kwargs):
                raise Exception('match')

            def get_new_command(self, **kwargs):
                raise Exception('new')

        exception = None
        try:
            TestRule().match()
        except Exception as e:
            exception = e

        assert exception is not None

        rule_failed(TestRule(), sys.exc_info())



# Generated at 2022-06-22 00:54:57.842548
# Unit test for function already_configured
def test_already_configured():
    assert(already_configured(u'"source ~/.bashrc"') == u'"Seems like \
            \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \
            \x1b[1msource ~/.bashrc\x1b[21m or restart your shell."')


# Generated at 2022-06-22 00:54:59.043296
# Unit test for function exception
def test_exception():
    exception("test", (Exception, Exception("test"), None))

# Generated at 2022-06-22 00:55:06.093642
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    import sys
    import re

    out = StringIO()
    sys.stdout = out
    already_configured(configuration_details = {'reload': 'fuck --reload'})
    output = out.getvalue().strip()

    assert re.match(r'^Seems like \033\[1mfuck\033\[21m alias already configured!\nFor applying changes run \033\[1mfuck --reload\033\[21m or restart your shell\.$', output)

# Generated at 2022-06-22 00:55:13.003979
# Unit test for function failed
def test_failed():
    from . import conf
    from .utils import wrap_streams
    stream = wrap_streams()
    assert stream.stderr == []
    try:
        conf.settings = None
        failed('Hello, world!')
    finally:
        conf.settings = settings
    assert stream.stderr == [u'\x1b[31mHello, world!\x1b[0m\n']

# Generated at 2022-06-22 00:55:14.176309
# Unit test for function rule_failed
def test_rule_failed():
    """test_rule_failed is a test function"""
    rule = rule_failed(3, 2)



# Generated at 2022-06-22 00:55:15.460336
# Unit test for function warn
def test_warn():
    warn(u'Thanks for using The Fuck!')
    warn(u'Have a great day!')



# Generated at 2022-06-22 00:55:20.725110
# Unit test for function warn
def test_warn():
    assert (warn('test title')
            == color(colorama.Back.RED + colorama.Fore.WHITE
                     + colorama.Style.BRIGHT)
            + "[WARN] test title"
            + color(colorama.Style.RESET_ALL) + '\n')



# Generated at 2022-06-22 00:55:28.444938
# Unit test for function version
def test_version():
    from . import __version__
    from .shells import get_shell_info

    sys.stderr = StringIO()

    version(__version__, sys.version, get_shell_info())

    assert sys.stderr.getvalue() == 'The Fuck {} using Python {} and {}\n'.format(
        __version__, sys.version, get_shell_info())

from contextlib import contextmanager
from StringIO import StringIO

# Generated at 2022-06-22 00:55:35.957173
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('Test'), None)
    exception('Test', exc_info)
    assert sys.stderr.getvalue() == u'[WARN] Test:\n' \
                                    u'Traceback (most recent call last):\n' \
                                    u'  File "<string>", line 1, in <module>\n' \
                                    u'Exception: Test\n' \
                                    u'\n' \
                                    u'----------------------------\n\n'



# Generated at 2022-06-22 00:55:39.761581
# Unit test for function exception
def test_exception():
    _, exc_val, exc_tb = sys.exc_info()
    exception('test', (exc_val, exc_val, exc_tb))

# Generated at 2022-06-22 00:55:43.910960
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .types import Command

    corrected_command = CorrectedCommand(Command('echo', 'test'), 'echo foo')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '> echo foo\n'

# Generated at 2022-06-22 00:55:50.579518
# Unit test for function rule_failed
def test_rule_failed():
    from unittest import TestCase
    from thefuck.rules import Rule
    from .const import Command, DEFAULT_TIMEOUT, NO_OUTPUT
    from .utils import get_loaded_rules

    class TestRule(Rule):
        name = "test"
        priority = 1

        def _match(self, command):
            return False

        def _get_new_command(self, command):
            return Command("echo test", "echo test")

    class _TestRuleFailed(TestCase):
        def test_rule_failed(self):
            try:
                raise Exception("Aaa")
            except Exception:
                exc_info = sys.exc_info()
                rule_failed(get_loaded_rules().rules[0], exc_info)

# Generated at 2022-06-22 00:55:54.551466
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-22 00:55:57.603401
# Unit test for function rule_failed
def test_rule_failed():
    exc_info = None
    rule = None
    try:
        raise ValueError
    except ValueError:
        exc_info = sys.exc_info()
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:55:59.365143
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configured_successfully)
test_configured_successfully()

# Generated at 2022-06-22 00:56:01.510609
# Unit test for function already_configured
def test_already_configured():
    from .shells import Shell
    already_configured(Shell(reload='reload'))


# Generated at 2022-06-22 00:56:03.301552
# Unit test for function already_configured
def test_already_configured():
    already_configured({'reload':'a'})


# Generated at 2022-06-22 00:56:14.222445
# Unit test for function exception
def test_exception():
    title = u'Title'
    exc_info = (SyntaxError, SyntaxError('Bad syntax'), None)
    result = u'{warn}[WARN] {title}:'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            title=title)
    result += ''.join(format_exception(*exc_info))
    result += '{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))
    assert ''.join(format_exception(*exc_info)) == ''.join(format_exception(*exc_info))

# Generated at 2022-06-22 00:56:19.850776
# Unit test for function warn
def test_warn():
    import io
    import sys
    sys.stderr = io.StringIO()
    warn(u"Test warn function")
    assert sys.stderr.getvalue() == u'\x1b[91m[WARN] Test warn function\x1b[0m\n'



# Generated at 2022-06-22 00:56:23.549231
# Unit test for function version
def test_version():
    import thefuck
    version(thefuck.__version__,
            sys.version.replace('\n', ' '),
            str(thefuck.shells.get_shell()))
# End unit test

# Generated at 2022-06-22 00:56:26.358673
# Unit test for function color
def test_color():
    assert '\x1b[0m' == color('')
    assert '\x1b[31m' == color(colorama.Fore.RED)



# Generated at 2022-06-22 00:56:29.055129
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('foo')
    settings.debug = False
    debug('bar')



# Generated at 2022-06-22 00:56:33.578195
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("test")
    rule_failed("test")

# Generated at 2022-06-22 00:56:45.698750
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import unittest

    # Subject under test
    from fuck_you.ui import show_corrected_command
    # Case dependent objects
    from fuck_you import Command
    # Dependencies
    import sys


    class StdOutStdErr(object):
        """Class to capture and store stdout and stderr output."""

        def __enter__(self):
            self.stdout = sys.stdout
            self.stderr = sys.stderr

            # We do not actually want to print data to console,
            # so we replace stdout and stderr with class
            # which will store data instead of printing
            sys.stdout = self.out = []
            sys.stderr = self.err = []

        def __exit__(self, *a, **kw):
            sys.stdout = self

# Generated at 2022-06-22 00:56:51.562329
# Unit test for function version
def test_version():
    import sys
    import mock
    import platform
    from thefuck.utils import version
    from thefuck.conf import settings
    from thefuck import __version__
    version('1.1', '1.1.1', 'bash')
    assert sys.stderr.getvalue() == u'The Fuck 1.1 using Python 1.1.1 and bash\n'



# Generated at 2022-06-22 00:56:53.995440
# Unit test for function version
def test_version():
    assert version(3, 2, u'zsh') == \
        u'The Fuck 3 using Python 2 and zsh\n'



# Generated at 2022-06-22 00:56:55.952072
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test_debug_time"):
        print("Hello")
        print("World")

# Generated at 2022-06-22 00:56:57.089841
# Unit test for function debug
def test_debug():
    debug('Test')
    debug('T'*30)

# Generated at 2022-06-22 00:56:58.967710
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception:
        exception('thrown', sys.exc_info())

# Generated at 2022-06-22 00:57:00.513853
# Unit test for function confirm_text
def test_confirm_text():
    # Unfortunately, there is no way to test it without any interaction
    # with input
    pass

# Generated at 2022-06-22 00:57:02.208683
# Unit test for function debug_time
def test_debug_time():
    from thefuck.utils import debug_time
    with debug_time(''):
        pass

# Generated at 2022-06-22 00:57:04.833932
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception(u'Test', sys.exc_info())


# Generated at 2022-06-22 00:57:14.820750
# Unit test for function debug_time
def test_debug_time():
    class test_debug_time:
        def __init__(self):
            self.msg = ''
        def write(self, msg):
            self.msg = msg
    class MockSettings:
        debug = True
    settings.debug = True
    sys.stderr = test_debug_time()

    with debug_time('test_debug_time'):
        pass
    assert sys.stderr.msg.startswith('test_debug_time took:')

# Generated at 2022-06-22 00:57:24.526164
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    output = []
    def print_mock(msg):
        output.append(msg)
    configuration_details = ConfigurationDetails('', '', '', '', True)
    how_to_configure_alias(configuration_details)
    assert(output ==
           ['Seems like fuck alias isn\'t configured!',
            'Please put fuck in your path and apply changes with reload or restart your shell.',
            'Or run fuck a second time to configure it automatically.',
            'More details - https://github.com/nvbn/thefuck#manual-installation'])

# Generated at 2022-06-22 00:57:31.121806
# Unit test for function failed
def test_failed():
    assert failed("Hello, error!") == "Hello, error!"
    assert failed("Привет, ошибка!") == u"\x1b[31m\u041f\u0440\u0438\u0432\u0435\u0442, \u043e\u0448\u0438\u0431\u043a\u0430!\x1b[0m\n"

# Generated at 2022-06-22 00:57:37.949044
# Unit test for function failed
def test_failed():
    # Patch sys.stderr.write
    write = sys.stderr.write

    sys.stderr.write = lambda string: setattr(test_failed, 'result', string)
    failed(u'foo')

    # Cleanup
    sys.stderr.write = write

    assert test_failed.result == u'\x1b[31mfoo\x1b[0m\n'



# Generated at 2022-06-22 00:57:43.721209
# Unit test for function failed
def test_failed():
    from io import StringIO
    sys.stderr = buffer = StringIO()
    print("test_failed_1")

    failed("test_failed_2")
    assert sys.stderr.getvalue() == u"test_failed_1\n\x1b[31mtest_failed_2\x1b[0m\n"

# Generated at 2022-06-22 00:57:44.839413
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-22 00:57:56.560078
# Unit test for function debug
def test_debug():
    from .tests.utils import mock_popen, noop
    from .shells.bash import Bash

    with mock_popen(u'/usr/bin/env python --version',
                    u'Python 2.7.6\n'):
        debug(u'python --version')
    with mock_popen(u'/usr/bin/env python --version',
                    u'Python 3.4.3\n'):
        debug(u'python --version')
    with mock_popen(u'/usr/bin/env python --version',
                    u'Python 2.7.6\n'):
        debug(u'python --version')
    with mock_popen(u'/usr/bin/env python --version',
                    u'Python 2.7.6\n'):
        debug(u'python --version')

# Generated at 2022-06-22 00:58:02.203411
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    import sys
    from datetime import datetime
    saved_stdout = sys.stdout
    sys.stdout = StringIO()
    configured_successfully(datetime.now())
    output = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = saved_stdout
    return output

# Generated at 2022-06-22 00:58:03.338103
# Unit test for function already_configured
def test_already_configured():
    already_configured(u"This is a test")

# Generated at 2022-06-22 00:58:06.406777
# Unit test for function color
def test_color():
    assert color('a')
    assert not color('b')

    settings.no_colors = True
    assert not color('a')
    assert not color('b')



# Generated at 2022-06-22 00:58:13.421168
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass
    assert True

# Generated at 2022-06-22 00:58:14.624701
# Unit test for function warn
def test_warn():
    warn('test')

# Generated at 2022-06-22 00:58:17.102901
# Unit test for function color
def test_color():
    assert color('asd') == 'asd'
    settings.no_colors = True
    assert color('asd') == ''

# Generated at 2022-06-22 00:58:20.239144
# Unit test for function warn
def test_warn():
    warn(u'title')
    sys.stderr.truncate(0)
    sys.stderr.seek(0)



# Generated at 2022-06-22 00:58:21.815082
# Unit test for function debug
def test_debug():
    debug(u'Проверка')

# Generated at 2022-06-22 00:58:30.120225
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.base import Shell
    from .utils import wrap_command

    confirm_text(wrap_command('ls -al'))
    confirm_text(wrap_command('ls -al', side_effect=True))

    class MyShell(Shell):
        @property
        def name(self):
            pass

        @property
        def history_file(self):
            pass

        def _get_history(self):
            pass

        def and_(self, *commands):
            pass

        def how_to_configure(self):
            pass

        def get_aliases(self):
            pass

        def build_alias(self, correct_sh, alias):
            pass

# Generated at 2022-06-22 00:58:37.198457
# Unit test for function failed
def test_failed():
    from thefuck import shells
    shells.get_shell('bash').venv_path = '/tmp/venv'
    shells.get_shell('bash')._alias = 'fuck'
    settings.no_colors = False
    failed('Sorry, fuck')
    assert sys.stderr.getvalue() == u'\x1b[31mSorry, fuck\x1b[0m\n'



# Generated at 2022-06-22 00:58:38.547192
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(None, None)

# Generated at 2022-06-22 00:58:47.933700
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    def get_stdout(configuration_details):
        from io import StringIO
        out = StringIO()
        sys.stdout = out
        how_to_configure_alias(configuration_details)
        sys.stdout = sys.__stdout__
        return out.getvalue()
    assert u'Seems like fuck alias isn\'t configured!' in get_stdout(ConfigurationDetails(
        path=u'/path', content=u'content',
        reload=u'command', can_configure_automatically=True))


# Generated at 2022-06-22 00:58:51.099670
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details)
    with open('how_to_configure_alias.txt', 'r', encoding='UTF-8') as expected:
        assert expected.read() == sys.stderr.getvalue()



# Generated at 2022-06-22 00:58:57.954586
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test')
    except Exception:
        return exception('Test exception', sys.exc_info())

# Generated at 2022-06-22 00:59:03.845383
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details= [
        {
            "path": "~/.",
            "content": "eval $(thefuck --alias)",
            "reload": "source ~/."
        }
    ]
    configured_successfully(configuration_details[0])


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 00:59:05.440160
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(123) is None

# Generated at 2022-06-22 00:59:07.838150
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(u'hello')
    finally:
        settings.debug = False



# Generated at 2022-06-22 00:59:10.067333
# Unit test for function debug_time
def test_debug_time():
    from .. import test
    import time
    with test.mock.patch('sys.stdout', new_callable=test.mock.StringIO) as stdout:
        with debug_time('foo'):
            time.sleep(0.01)
        assert 'foo took: 0:' in stdout.getvalue()

# Generated at 2022-06-22 00:59:10.830213
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details=None) == None

# Generated at 2022-06-22 00:59:14.793075
# Unit test for function warn
def test_warn():
    import mock
    import StringIO
    sys.stderr = StringIO.StringIO()
    with mock.patch('thefuck.shells.get_shell', return_value=''):
        warn('Test')
    sys.stderr = sys.__stderr__
    assert sys.stderr.getvalue() == '[WARN] Test\n'


# Generated at 2022-06-22 00:59:16.055082
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)

# Generated at 2022-06-22 00:59:17.825576
# Unit test for function debug_time
def test_debug_time():
    debug_time('Test msg')

# Generated at 2022-06-22 00:59:19.669905
# Unit test for function debug
def test_debug():
    debug('test debug')
    debug(u'юнит тест')

# Generated at 2022-06-22 00:59:27.723453
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test exception')
    except RuntimeError:
        exception('test', sys.exc_info())


# Generated at 2022-06-22 00:59:30.377234
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('error')
    except RuntimeError:
        exception('Unit test', sys.exc_info())


# Generated at 2022-06-22 00:59:32.658350
# Unit test for function color
def test_color():
    assert color('\x1b[41m\x1b[37m\x1b[1m') == ''

# Generated at 2022-06-22 00:59:35.181065
# Unit test for function version
def test_version():
    assert version('3.6', '3.6.3', 'bash-3.2')



# Generated at 2022-06-22 00:59:37.803417
# Unit test for function color
def test_color():
    assert colorama.Style.BRIGHT in color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT not in color(None)

# Generated at 2022-06-22 00:59:38.852566
# Unit test for function confirm_text
def test_confirm_text():
    pass



# Generated at 2022-06-22 00:59:41.178046
# Unit test for function failed
def test_failed():
    failed('test')
    assert sys.stderr.getvalue() == u'\x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-22 00:59:43.872006
# Unit test for function version
def test_version():
    version('3.10', '3.5', 'Fish')


# Generated at 2022-06-22 00:59:44.991123
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=None)

# Generated at 2022-06-22 00:59:46.108837
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-22 00:59:53.309600
# Unit test for function already_configured
def test_already_configured():
    configuration_details = {'reload': 'source ~/.bash_profile'}
    already_configured(configuration_details)
    return True

# Generated at 2022-06-22 00:59:55.705036
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text = confirm_text('grep')
    assert confirm_text == 'The Fuck grep [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 01:00:02.289017
# Unit test for function debug_time
def test_debug_time():
    import time
    import datetime
    from contextlib import contextmanager
    @contextmanager
    def debug_time(msg):
        started = datetime.datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.datetime.now() - started))
    debug_time("lel")

# Generated at 2022-06-22 01:00:10.288713
# Unit test for function version
def test_version():
    from mock import patch, Mock
    import sys
    from thefuck.shells import shell
    sys.stderr = Mock(write=Mock())
    from thefuck.util import VERSION
    from sys import version

    version('1.1', '2.7', shell.get_shell())

    sys.stderr.write.assert_called_once_with(u'The Fuck 1.1 using Python 2.7 and Bash\n')
    sys.stderr.write.reset_mock()



# Generated at 2022-06-22 01:00:13.744142
# Unit test for function already_configured
def test_already_configured():
    fake_configuration_details = ('', '', '', '', True, True)
    assert already_configured(fake_configuration_details)



# Generated at 2022-06-22 01:00:14.391894
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-22 01:00:16.027282
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError("Test exception")
    except RuntimeError:
        exception("Test rule", sys.exc_info())


# Generated at 2022-06-22 01:00:19.798168
# Unit test for function rule_failed
def test_rule_failed():
    def test_func():
        raise RuntimeError("test_func")
    class TestRule(object):
        name = 'TestRule'
    try:
        test_func()
    except Exception as e:
        rule_failed(TestRule(), sys.exc_info())

# Generated at 2022-06-22 01:00:22.940056
# Unit test for function rule_failed
def test_rule_failed():
    rule={"name":"test"}
    exc_info = ("python2.7.12", "exception2", "trace1")
    assert rule_failed(rule, exc_info) == None

# Generated at 2022-06-22 01:00:29.121857
# Unit test for function debug_time
def test_debug_time():
    count = 0

    class Count(object):
        def __init__(self, val):
            self.val = val

        def __sub__(self, other):
            return Count(self.val + other.val)

    with debug_time('test'):
        pass
    assert count == 1

    with debug_time('test'):
        raise Exception()
    assert count == 2

# Generated at 2022-06-22 01:00:40.621024
# Unit test for function failed
def test_failed():
    from io import StringIO
    output = StringIO()
    old_stdout = sys.stderr
    try:
        sys.stderr = output
        failed('Error')
        assert output.getvalue() == '\x1b[31mError\x1b[0m\n'
    finally:
        sys.stderr = old_stdout



# Generated at 2022-06-22 01:00:41.355340
# Unit test for function show_corrected_command
def test_show_corrected_command():
     pass

# Generated at 2022-06-22 01:00:46.479617
# Unit test for function configured_successfully
def test_configured_successfully():
    with settings.using_password(False):
        assert configured_successfully('foo') == \
            u'{bold}fuck{reset} alias configured successfully!\n' \
            u'For applying changes run {bold}foo{reset} or restart your shell.'.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 01:00:49.230796
# Unit test for function configured_successfully

# Generated at 2022-06-22 01:00:50.860298
# Unit test for function debug
def test_debug():
    debug(u'message 1')
    debug(u'message 2')

# Generated at 2022-06-22 01:00:52.366279
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('git push')


# Generated at 2022-06-22 01:00:54.419036
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = u'apt-get insatll'
    confirm_text(corrected_command)

# Generated at 2022-06-22 01:01:03.512723
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = type('A', (object,), {
        'script': u'npm test',
        'side_effect': None})
    assert show_corrected_command(corrected_command) == u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script=corrected_command.script,
        side_effect=' (+side effect)' if corrected_command.side_effect else '',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))

