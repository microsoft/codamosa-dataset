

# Generated at 2022-06-22 00:51:10.608470
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    sys.stderr = io.StringIO()
    show_corrected_command(const.CorrectedCommand('sudo ls', False))
    assert sys.stderr.getvalue() == 'fuck sudo ls\n'
    sys.stderr.close()
    sys.stderr = io.StringIO()
    show_corrected_command(const.CorrectedCommand('sudo ls', True))
    assert sys.stderr.getvalue() == 'fuck sudo ls +side effect\n'
    sys.stderr.close()



# Generated at 2022-06-22 00:51:12.631910
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('source ~/.bashrc\n') == 'Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell.'


# Generated at 2022-06-22 00:51:14.936763
# Unit test for function failed
def test_failed():
    failed('msg') == '\x1b[31mmsg\x1b[0m\n'

# Generated at 2022-06-22 00:51:21.533296
# Unit test for function confirm_text
def test_confirm_text():
    """
    >>> class TestCorrectedCommand:
    ...     def __init__(self, script):
    ...          self.script = script
    ...          self.side_effect = False
    ...     def run(self):
    ...          return None
    >>> corrected_command = TestCorrectedCommand('ls')
    >>> confirm_text(corrected_command)
    >>> corrected_command.script = 'rm -rf'
    >>> corrected_command.side_effect = True
    >>> confirm_text(corrected_command)
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 00:51:24.397450
# Unit test for function warn
def test_warn():
    assert warn('some warning') == '\x1b[41m\x1b[1m\x1b[37m[WARN] some warning\x1b[0m\n'


# Generated at 2022-06-22 00:51:26.781254
# Unit test for function failed
def test_failed():
    '''
    Test function failed
    '''
    failed(u'\nTest Failed: Test function failed')

# Generated at 2022-06-22 00:51:31.009277
# Unit test for function rule_failed
def test_rule_failed():
    from unittest.mock import Mock
    rule = Mock(name='rule')
    rule.name = 'rule'

    try:
        raise Exception()
    except Exception:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:51:38.206327
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias_content = "alias fuck='~/.local/share/thefuck/venv/bin/thefuck'" 
    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        content=how_to_configure_alias_content,
        path="/home/travis/.bashrc",
        reload="source /home/travis/.bashrc")
    return configuration_details


# Generated at 2022-06-22 00:51:39.667371
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:51:41.569624
# Unit test for function debug_time
def test_debug_time():
    import time
    def sleep():
        time.sleep(1)
    with debug_time('sleep'):
        sleep()

# Generated at 2022-06-22 00:51:56.427908
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    buffer = sys.stderr

# Generated at 2022-06-22 00:51:57.390631
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc_info')

# Generated at 2022-06-22 00:52:01.026895
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError("Test")
    except:
        return u''.join(exception(u'Unit test', exc_info=sys.exc_info()))



# Generated at 2022-06-22 00:52:03.189764
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('yellow') == colorama.Fore.YELLOW
    assert color('') == ''

# Generated at 2022-06-22 00:52:06.506479
# Unit test for function debug
def test_debug():
    from thefuck.shells.shell import Shell
    settings.debug = True
    shell = Shell('default')
    with shell.prefix(''):
        debug(u'foo_bar')
    settings.debug = False



# Generated at 2022-06-22 00:52:11.345963
# Unit test for function debug_time
def test_debug_time():
    import time
    import nose
    with debug_time('foo'): time.sleep(1)
    assert 'DEBUG: foo took' in nose.core.TestProgram().result.errors[0][0]

# Generated at 2022-06-22 00:52:15.004930
# Unit test for function confirm_text
def test_confirm_text():
    test_command = 'ls -lah'
    assert confirm_text(test_command) == 'fuckls -lah (+side effect)[enter]/[↑]/[↓]/[ctrl+c]'

# Generated at 2022-06-22 00:52:23.005668
# Unit test for function exception
def test_exception():
    class FakeStdErr(object):
        def __init__(self):
            self.content = []

        def write(self, content):
            self.content.append(content)

    fake_stderr = FakeStdErr()
    sys.stderr = fake_stderr
    exception('Title', ('type', 'value', 'traceback'))
    sys.stderr = sys.__stderr__
    assert u'[WARN] Title:\ntype value\ntraceback' in ''.join(fake_stderr.content)
    assert u'[WARN] ---------------------------' in ''.join(fake_stderr.content)



# Generated at 2022-06-22 00:52:32.136414
# Unit test for function failed
def test_failed():
    warn('test')
    exception('test', sys.exc_info())
    # rule_failed() is tested in test_rules
    failed('test')
    # confirm_text() is tested in test_input
    # how_to_configure_alias() is tested in test_conf
    # already_configured() is tested in test_conf
    # configured_successfully() id tested in test_conf
    debug('test')

    with debug_time('test'):
        # Do nothing
        pass

    version('3.1', '3.5', 'zsh')

# Generated at 2022-06-22 00:52:34.609127
# Unit test for function already_configured
def test_already_configured():
    already_configured('fuck --alias')
    already_configured('source ~/.bashrc')
    already_configured('source ~/.zshrc')

# Generated at 2022-06-22 00:52:40.681498
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-22 00:52:44.304312
# Unit test for function version
def test_version():
    assert version('0.8', '2.7.10', 'fish v2.2.0') == \
           u'The Fuck 0.8 using Python 2.7.10 and fish v2.2.0\n'



# Generated at 2022-06-22 00:52:45.757455
# Unit test for function color
def test_color():
    assert '\x1b[31m' == color(colorama.Fore.RED)

# Generated at 2022-06-22 00:52:46.939041
# Unit test for function failed
def test_failed():
    failed('failed')



# Generated at 2022-06-22 00:52:50.277228
# Unit test for function version
def test_version():
    assert version('3.0.0', 'Python 2.7', 'Shell 3.4') == 'The Fuck 3.0.0 using Python 2.7 and Shell 3.4\n'


# Generated at 2022-06-22 00:52:51.702854
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-22 00:52:53.977705
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception('Title', sys.exc_info())

# Generated at 2022-06-22 00:52:56.986814
# Unit test for function rule_failed
def test_rule_failed():
    exc = Exception('Error')
    rule = lambda x: x
    rule.name = 'rule_name'
    rule_failed(rule, exc)

# Generated at 2022-06-22 00:52:57.597450
# Unit test for function warn
def test_warn():
    warn('title')

# Generated at 2022-06-22 00:53:10.162662
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('fake error')
    except Exception:
        sys.stderr = open('exception.txt', 'w', 0)
        exception('Unit Test', sys.exc_info())
        sys.stderr.close()
        f = open('exception.txt', 'r')
        output = f.read()
        f.close()

# Generated at 2022-06-22 00:53:17.223448
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except:
        return sys.exc_info()



# Generated at 2022-06-22 00:53:22.047292
# Unit test for function confirm_text
def test_confirm_text():
    result = u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'
    assert confirm_text(result)



# Generated at 2022-06-22 00:53:28.613973
# Unit test for function debug
def test_debug():
    from mock import patch, MagicMock
    settings.debug = True
    with patch('sys.stderr', new_callable=MagicMock) as mock_stderr:
        debug('test')
        mock_stderr.assert_has_calls([
            '\033[94m\033[1mDEBUG:\033[0m test\n'.encode()
        ])



# Generated at 2022-06-22 00:53:31.505867
# Unit test for function rule_failed
def test_rule_failed():
    import pytest

    with pytest.raises(Exception) as excinfo:
        exception(
            "Test exception",
            (Exception, Exception("Test exception"), None))

# Generated at 2022-06-22 00:53:34.078771
# Unit test for function already_configured
def test_already_configured():
    configuration_details = {'reload': '. ~/.bashrc'}
    already_configured(configuration_details)



# Generated at 2022-06-22 00:53:46.431418
# Unit test for function configured_successfully
def test_configured_successfully():
    """
    Test function configured_successfully
    :return: result of test
    """
    from .conf import ConfigurationDetails
    from .shells import Zsh
    from . import __version__
    import sys
    import colorama
    if sys.version_info.major == 3:
        shell = 'zsh 5.0.7'
        version_ = 'The Fuck 3.11 using Python 3.6.0 and zsh 5.0.7\n'
        expected = u'{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}source ~/.zshrc{reset} or restart your shell.\n'.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:53:50.163019
# Unit test for function exception
def test_exception():
    def test_func():
        raise Exception()

    try:
        test_func()
    except Exception:
        exception('Unit test', sys.exc_info())


# Generated at 2022-06-22 00:53:51.464734
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:53:52.619160
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None)



# Generated at 2022-06-22 00:53:55.860246
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('foo', 'bar') == u'\033[1K\r\x1b[01mfoo\x1b[0m bar [\x1b[0;32menter\x1b[0m]\x1b[0m '

# Generated at 2022-06-22 00:54:05.325628
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock

    with debug_time('debug_time'):
        pass

    assert Mock == Mock  # Silence pyflakes

    with debug_time('debug_time'):
        raise AssertionError('Mock is not a Mock')

# Generated at 2022-06-22 00:54:07.261349
# Unit test for function color
def test_color():
    assert not color(colorama.Fore.WHITE)



# Generated at 2022-06-22 00:54:13.857590
# Unit test for function warn
def test_warn():
    import mock
    import io
    import sys
    import colorama
    out = io.StringIO()
    sys.stderr = out
    colorama.Fore.RED = 'red'
    colorama.Style.RESET_ALL = 'reset'
    warn('test')
    assert out.getvalue() == '\x1b[' + colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT + ']WARN] test\x1b[reset\n'



# Generated at 2022-06-22 00:54:21.577138
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('a rule',
                ('type', 'value', 'a traceback object'))
    assert sys.stderr.getvalue() == \
        u'\x1b[41;37;1m[WARN] Rule a rule:\x1b[0m\n' \
        u'\x1b[41;37;1m----------------------------\x1b[0m\n\n' \
        u"a traceback object"

# Generated at 2022-06-22 00:54:25.074067
# Unit test for function debug_time
def test_debug_time():
    import subprocess
    import os
    os.environ['THEFUCK_DEBUG'] = 'true'
    with debug_time('test'):
        subprocess.Popen.wait(subprocess.Popen('ls'))

# Generated at 2022-06-22 00:54:26.708162
# Unit test for function configured_successfully
def test_configured_successfully():
    print(configured_successfully('thefuck', '3.5', 'fish'))

# Generated at 2022-06-22 00:54:28.379766
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully({'reload': 'source ~/.bashrc'})


# Generated at 2022-06-22 00:54:33.032303
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.BRIGHT) != ''
    settings.no_colors = True
    assert color(colorama.Style.BRIGHT) == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:54:35.523782
# Unit test for function color
def test_color():
    assert color('\033[0;32m') == '\033[0;32m'
    assert color('\033[0;32m') == ''

# Generated at 2022-06-22 00:54:40.374775
# Unit test for function color
def test_color():
    settings.no_colors = True
    assert color('') == ''
    assert color('\x1b[33mfoo') == ''
    settings.no_colors = False
    assert color('') == ''
    assert color('\x1b[33mfoo') == '\x1b[33mfoo'

# Generated at 2022-06-22 00:54:49.087935
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    failed(u'ЬЪЭЮ')
    result = out.getvalue()
    out.close()
    return result


# Generated at 2022-06-22 00:54:52.212650
# Unit test for function confirm_text
def test_confirm_text():
    class corrected_command:
        def __init__(self):
            self.script = 'ls'
            self.side_effect = True
    confirm_text(corrected_command())

# Generated at 2022-06-22 00:55:00.886427
# Unit test for function debug_time
def test_debug_time():
    from thefuck.tests.utils import Expect

    class Check:
        called = False

    @debug_time('Inner function')
    def inner():
        Check.called = True
        return []

    outer = Expect('thefuck.shells.base.debug', ['Outer function took: '])
    inner = Expect('thefuck.shells.base.debug', ['Inner function took: '])
    with debug_time('Outer function'):
        outer | inner | inner() | inner() | inner()
        assert Check.called

    assert outer.called
    assert inner.called



# Generated at 2022-06-22 00:55:02.155014
# Unit test for function confirm_text
def test_confirm_text():
    return u'fuck\n'



# Generated at 2022-06-22 00:55:04.029999
# Unit test for function confirm_text
def test_confirm_text():
    import re
    confirm_text('1')
    p = re.compile(u'^\[^\]\n')
    assert p.match(sys.stderr.getvalue())

# Generated at 2022-06-22 00:55:13.867948
# Unit test for function debug
def test_debug():
    # Replace stdout by StringIO
    import StringIO
    sys.stdout = StringIO.StringIO()

    # If settings.debug is False, nothing should be printed
    debug(u"Hello")
    assert sys.stdout.getvalue() == ""

    # If settings.debug is True, a log message should be print
    settings.debug = True
    debug(u"Hello")
    assert sys.stdout.getvalue() == "\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello\n"
    settings.debug = False
    sys.stdout = sys.__stdout__

# Generated at 2022-06-22 00:55:16.152625
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception:
        exception(u'Title', sys.exc_info())

# Generated at 2022-06-22 00:55:20.318858
# Unit test for function confirm_text
def test_confirm_text():
    # Test default
    corrected_command = None
    confirm_text(corrected_command)

    # Test corrected command
    corrected_command = 'fuck && ./RUN.sh'
    confirm_text(corrected_command)



# Generated at 2022-06-22 00:55:27.089869
# Unit test for function exception
def test_exception():
    try:
        x = 1/0
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        exception(e, fname, exc_tb.tb_lineno)

# Generated at 2022-06-22 00:55:35.325885
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = sys.stdout
    settings.no_colors = False
    settings.debug = True
    corrected_command = const.CorrectedCommand('foo', False)
    confirm_text(corrected_command)
    assert not sys.stderr.isatty()
    assert sys.stderr.getvalue() == u'[CMD] foo [enter/↑/↓/ctrl+c]\n'
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:55:43.399381
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand

    show_corrected_command(CorrectedCommand('ls .'))
    show_corrected_command(CorrectedCommand('ls .', side_effect=True))

# Generated at 2022-06-22 00:55:48.970333
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import ConfigurationDetails

    how_to_configure_alias(ConfigurationDetails(
        path='fuck.sh',
        content='eval $(thefuck --alias fuck)',
        reload='source fuck.sh',
        can_configure_automatically=False))

    how_to_configure_alias(ConfigurationDetails(
        path='fuck.sh',
        content='eval $(thefuck --alias fuck)',
        reload='source fuck.sh',
        can_configure_automatically=True))

# Generated at 2022-06-22 00:55:56.495052
# Unit test for function already_configured
def test_already_configured():
    given = {'reload': 'reload'}

    expected = u"Seems like {bold}fuck{reset} alias already configured!\n" \
               u"For applying changes run {bold}{reload}{reset}" \
               u" or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload=given['reload'])

    print(expected)

    assert expected == already_configured(given)

# Generated at 2022-06-22 00:56:00.945221
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    sys.stderr = StringIO()
    expected_result = color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) + '[WARN] test' + color(colorama.Style.RESET_ALL) + '\n'
    warn('test')
    assert sys.stderr.getvalue().decode('utf-8') == expected_result


# Generated at 2022-06-22 00:56:02.738830
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(CorrectedCommand('$ echo fuck', 'echo fuck', True))

# Generated at 2022-06-22 00:56:03.515923
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    s = Shell(None, 'bash')
    confirm_text("fuck", s)

# Generated at 2022-06-22 00:56:13.749077
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand

    show_corrected_command(CorrectedCommand('git pussh', side_effect=True))
    # Result:
    #    [+git pussh +side effect]

    show_corrected_command(CorrectedCommand('git pussh', side_effect=False))
    # Result:
    #    [+git pussh]

    show_corrected_command(CorrectedCommand('git pussh origin', side_effect=True))
    # Result:
    #    [+git pussh origin +side effect]

    show_corrected_command(CorrectedCommand('git pussh origin', side_effect=False))
    # Result:
    #    [+git pussh origin]

# Generated at 2022-06-22 00:56:14.981469
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-22 00:56:26.445586
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(dict(script=u'git push origin master', side_effect=True))
    show_corrected_command(dict(script=u'git push origin master', side_effect=False))
    show_corrected_command(dict(script=u'git push origin master', side_effect=True))
    show_corrected_command(dict(script=u'git push origin master', side_effect=False))
    show_corrected_command(dict(script=u'git push origin master', side_effect=True))
    show_corrected_command(dict(script=u'git push origin master', side_effect=False))


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-22 00:56:29.686657
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Error')
    except Exception as e:
        exception('Test exception', sys.exc_info())



# Generated at 2022-06-22 00:56:37.388711
# Unit test for function debug_time
def test_debug_time():
    from fake_popen import fuck

    with fuck.with_builtin_funcs():
        with debug_time('Test'):
            pass

# Generated at 2022-06-22 00:56:46.009977
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime

    def local_debug(msg):
        sys.stderr.write('{}\n'.format(msg))

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            local_debug('{} took: {}'.format(msg, datetime.now() - started))

    with debug_time('test'):
        pass

    assert sys.stderr.getvalue() == 'test took: 0:00:00.000001\n'

# Generated at 2022-06-22 00:56:56.745213
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    import sys

    configuration_details = type(
        '', (), {'reload': 'source $HOME/.thefuck.sh', 'path': '~/.thefuck.sh'}
    )
    stdout = sys.stdout
    stderr = sys.stderr

    try:
        out = StringIO()
        sys.stdout = out
        configured_successfully(configuration_details)
        output = out.getvalue().strip()
        assert (u'fuck alias configured successfully!'
                in output)
        assert (u'For applying changes run source $HOME/.thefuck.sh'
                in output)
    finally:
        sys.stdout = stdout
        sys.stderr = stderr

# Generated at 2022-06-22 00:56:59.540981
# Unit test for function version
def test_version():
    version('1', '2', '3')
    assert (sys.stderr.getvalue() ==
            u'The Fuck 1 using Python 2 and 3\n')

# Generated at 2022-06-22 00:57:01.605940
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except Exception as e:
        exception(u'test exception', sys.exc_info())

# Generated at 2022-06-22 00:57:02.801138
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-22 00:57:06.056150
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = CorrectedCommand('touch file', False)
    assert confirm_text(corrected_command) == '>touch file [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:57:07.687175
# Unit test for function warn
def test_warn():
    assert warn('title') == '[WARN] title\n'


# Generated at 2022-06-22 00:57:13.240179
# Unit test for function failed
def test_failed():
    import StringIO
    import sys
    out = StringIO.StringIO()
    sys.stderr = out
    failed('msg')
    sys.stderr = sys.__stderr__
    return out.getvalue() == u'\x1b[31mmsg\x1b[0m\n'


# Generated at 2022-06-22 00:57:14.492612
# Unit test for function debug
def test_debug():
    debug("Test debug")



# Generated at 2022-06-22 00:57:26.268901
# Unit test for function already_configured
def test_already_configured():
    assert already_configured({'reload': 'reload'}) == \
        u"Seems like {bold}fuck{reset} alias already configured!\n" \
        u"For applying changes run {bold}reload{reset} or restart your shell.".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-22 00:57:33.415535
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    import os.path

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        temp.write('test')
        temp.close()
        temp_file_name = os.path.basename(temp.name)
        configuration_details = const.ConfigurationDetails(
            'test', temp_file_name, 'test', 0, 'false')
        how_to_configure_alias(configuration_details)

    os.remove(temp.name)

# Generated at 2022-06-22 00:57:34.977320
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None



# Generated at 2022-06-22 00:57:47.143267
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    def settings():
        settings = mock.Mock()
        settings.fast_mode = False
        return settings

    def configuration_details():
        return namedtuple(
            'ConfigurationDetails',
            'reload content path can_configure_automatically')(
                'reload', 'content', 'path', True)

    from thefuck.shells.exceptions import NoAliasError
    from thefuck import conf
    from contextlib import contextmanager
    import sys
    import os
    import tempfile

    class _:
        @contextmanager
        def stdout(self):
            _, path = tempfile.mkstemp()
            stdout = open(path, 'w')
            try:
                yield stdout
            finally:
                stdout.close()

# Generated at 2022-06-22 00:57:51.490976
# Unit test for function failed
def test_failed():
    try:
        sys.stderr.write('\n')
        failed('ERROR:')
        raise Exception
    except Exception:
        exception('Exception', sys.exc_info())
    finally:
        sys.stderr.write('\n')



# Generated at 2022-06-22 00:57:58.193583
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import timedelta

    @contextmanager
    def fake_time(delta):
        started = datetime.now()
        try:
            yield
        finally:
            ended = (datetime.now() - started) - delta

    with fake_time(timedelta(seconds=1)) as ended:
        with debug_time('test'):
            pass
    assert ended < timedelta(seconds=2)

# Generated at 2022-06-22 00:58:02.037780
# Unit test for function warn
def test_warn():
    from . import conf
    from . import log
    from . import utils

    class Settings(object):
        no_colors = True
    settings = Settings()
    assert str(log.warn('test')) == '[WARN] test'



# Generated at 2022-06-22 00:58:04.516609
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'find ./ -name "*.png"'
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:58:08.120925
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command

    show_corrected_command(Command('ls', 'ls -l'))
    show_corrected_command(Command('git brnch', 'git branch', True))

# Generated at 2022-06-22 00:58:12.682507
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'ls (+side effect)\n'



# Generated at 2022-06-22 00:58:27.105776
# Unit test for function warn
def test_warn():
    import StringIO
    import sys
    stringio = StringIO.StringIO()
    sys.stderr = stringio
    warn('some title')
    sys.stderr = sys.__stderr__
    assert u'[WARN] some title\n' == stringio.getvalue()


# Generated at 2022-06-22 00:58:32.070453
# Unit test for function version
def test_version():
    from .utils import get_shell_info
    thefuck_version = '1.32'
    python_version = '2.7.16'
    shell_info = get_shell_info()
    version(thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:58:38.894024
# Unit test for function version
def test_version():
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        sys.stderr = f
        version('0.0.9', '2.7.10', 'bash')
    assert open(path).read() == 'The Fuck 0.0.9 using Python 2.7.10 and bash\n'

# Generated at 2022-06-22 00:58:44.414485
# Unit test for function version
def test_version():
    thefuck_version = "3.0"
    python_version = "2.7.6"
    shell_info = "/bin/bash"
    expected_string = 'The Fuck 3.0 using Python 2.7.6 and /bin/bash\n'
    assert version(thefuck_version, python_version, shell_info) is None
    assert sys.stderr.getvalue() == expected_string

# Generated at 2022-06-22 00:58:50.828702
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    orig_stderr = sys.stderr
    sys.stderr = StringIO()
    failed(u'проверка')
    assert u'проверка' in sys.stderr.getvalue()
    sys.stderr = orig_stderr



# Generated at 2022-06-22 00:58:56.417405
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .shells.bash import BashCommand
    from copy import copy
    bash_command = copy(Bash.from_shell(''))
    bash_command.script = 'ls'
    confirm_text(bash_command)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 00:59:00.090912
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -la', ''))
    #assert sys.stderr.write('fuck ls -la\n') == True

# Generated at 2022-06-22 00:59:01.864236
# Unit test for function rule_failed
def test_rule_failed():
    exception(u'Rule test', sys.exc_info())


# Generated at 2022-06-22 00:59:02.607053
# Unit test for function debug_time
def test_debug_time():
    assert debug_time

# Generated at 2022-06-22 00:59:13.715938
# Unit test for function warn
def test_warn():
    from mock import mock_open, patch
    from StringIO import StringIO
    open_name = '__builtin__.open' if sys.version_info < (3,) \
        else 'builtins.open'

    with patch(open_name, mock_open()) as m:
        with patch('sys.stderr', new_callable=StringIO) as stderr:
            m.return_value.write.side_effect = IOError
            warn('title')
            assert stderr.getvalue() == ''

        with patch('sys.stderr', new_callable=StringIO) as stderr:
            warn('title')
            assert stderr.getvalue() == u'[WARN] title\n'



# Generated at 2022-06-22 00:59:24.539696
# Unit test for function configured_successfully
def test_configured_successfully():
    pass

# Generated at 2022-06-22 00:59:32.657760
# Unit test for function version
def test_version():
    assert 'The Fuck' in version('1.2.3', '2.7', 'sh')
    assert 'Python' in version('1.2.3', '2.7', 'sh')
    assert 'sh' in version('1.2.3', '2.7', 'sh')
    assert '1.2.3' in version('1.2.3', '2.7', 'sh')
    assert '2.7' in version('1.2.3', '2.7', 'sh')



# Generated at 2022-06-22 00:59:36.123509
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details=None)
    how_to_configure_alias(configuration_details=True)


# Generated at 2022-06-22 00:59:39.510441
# Unit test for function color
def test_color():
    assert color('\x1b[1m') == '\x1b[1m'
    settings.no_colors = True
    assert color('\x1b[1m') == ''

# Generated at 2022-06-22 00:59:47.156992
# Unit test for function rule_failed
def test_rule_failed():
    import sys
    import pytest
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO(*args, **kwargs)
        command()
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    def test_stdout(monkeypatch):
        monkeypatch.setattr('sys.stderr', StringIO())
        rule_failed('Rule', ('Failed', '', ''))
        return sys.stderr

    def test_stdout_content(monkeypatch):
        monkeypatch.setattr('sys.stderr', StringIO())
        rule_failed('Rule', ('Failed', '', ''))
       

# Generated at 2022-06-22 00:59:53.707138
# Unit test for function failed
def test_failed():
    import six
    if six.PY2:
        from StringIO import StringIO
    else:
        from io import StringIO

    expected_msg = 'Error: could not find any command.\n'

    with open('/dev/null', 'w') as devnull:
        sys.stderr = StringIO()
        failed('Error: could not find any command.')
        sys.stderr = devnull
        assert sys.stderr.getvalue() == expected_msg

# Generated at 2022-06-22 01:00:06.017744
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    from contextlib import contextmanager
    @contextmanager
    def capture_stream(stream):
        old_stream = getattr(sys, stream)
        setattr(sys, stream, StringIO())
        try:
            yield getattr(sys, stream)
        finally:
            setattr(sys, stream, old_stream)
    with capture_stream('stderr') as stderr:
        confirm_text(MagicMock(script='fuck', side_effect=False))
    assert stderr.getvalue() == '{}fuck [] [enter/↑/↓/ctrl+c]'.format(const.USER_COMMAND_MARK)
    with capture_stream('stderr') as stderr:
        confirm_text(MagicMock(script='ls', side_effect=True))


# Generated at 2022-06-22 01:00:18.624387
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.types import ConfigurationDetails
    from StringIO import StringIO
    import sys

    def patch_print(fn):
        def wrapper(*args, **kwargs):
            old_print = sys.stdout
            sys.stdout = StringIO()
            fn(*args, **kwargs)
            output = sys.stdout.getvalue()
            sys.stdout = old_print
            return output
        return wrapper

    @patch_print
    def patch_how_to_configure_alias():
        how_to_configure_alias(None)


# Generated at 2022-06-22 01:00:20.604175
# Unit test for function exception
def test_exception():
    exception('TEST EXCEPTION TITLE', (type(u''), 'test exception', None))

# Generated at 2022-06-22 01:00:22.302244
# Unit test for function already_configured
def test_already_configured():
    already_configured('configuration_details')



# Generated at 2022-06-22 01:00:35.666712
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == ''
    settings.no_colors = False
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    settings.no_colors = True

# Generated at 2022-06-22 01:00:38.454694
# Unit test for function exception
def test_exception():
    try:
        raise Exception("foo")
    except Exception:
        exception("bar", sys.exc_info())

# Generated at 2022-06-22 01:00:43.853375
# Unit test for function confirm_text
def test_confirm_text():
    example_command = 'ls'
    confirm_text(example_command)
    confirm_text(example_command + ' --all')
    confirm_text(example_command + ' --all' + ' (without side effect)')

    settings.no_colors = True
    confirm_text(example_command)
    settings.no_colors = False

# Generated at 2022-06-22 01:00:45.046059
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('test')


# Generated at 2022-06-22 01:00:47.603355
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.types import CorrectedCommand
    assert confirm_text(CorrectedCommand(u'echo "fuck"', False)) == None


# Generated at 2022-06-22 01:00:53.718338
# Unit test for function warn
def test_warn():
    import StringIO
    sys.stderr = StringIO.StringIO()
    warn('message')
    output = sys.stderr.getvalue()
    expected = colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT + '[' + 'WARN' + ']' + ' ' + 'message' + colorama.Style.RESET_ALL + '\n'
    assert output == expected

# Generated at 2022-06-22 01:00:55.334367
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=None)


# Generated at 2022-06-22 01:00:57.460337
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('Error')
    except Exception:
        exception('Title', sys.exc_info())

# Generated at 2022-06-22 01:01:01.576358
# Unit test for function version
def test_version():
    assert const.THEFUCK_VERSION
    assert 'Python ' in const.PYTHON_VERSION
    assert ' ' in const.SHELL_INFO
    assert version(*const.VERSION) == None