

# Generated at 2022-06-22 00:50:58.303389
# Unit test for function version
def test_version():
    sys.stderr = sys.stdout
    colorama.init()
    version(u'3.0', u'3.5', u'zsh')
    assert sys.stdout.getvalue().strip() == u'The Fuck 3.0 using Python 3.5 and zsh'

# Generated at 2022-06-22 00:51:00.870760
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None
test_how_to_configure_alias()


# Generated at 2022-06-22 00:51:01.878742
# Unit test for function rule_failed
def test_rule_failed():
    rule = mock.Mock(name='mock rule')
    exc_info = (None, None, None)
    print(rule_failed(rule, exc_info))

# Generated at 2022-06-22 00:51:13.446254
# Unit test for function exception
def test_exception():
    sys.stderr.write(u'\n')
    exception('Title', ('a', 'b', 'c'))
    assert sys.stderr.getvalue() == u'\x1b[41m[WARN] Title:\x1b[0m\n' \
                                    u'  Traceback (most recent call last):\n' \
                                    u'    File "<string>", line 1, in <module>\n' \
                                    u'a\n' \
                                    u'b\n' \
                                    u'c\n' \
                                    u'\n' \
                                    u'\x1b[41m----------------------------\x1b[0m\n' \
                                    u'\n'



# Generated at 2022-06-22 00:51:24.651493
# Unit test for function configured_successfully
def test_configured_successfully():
    import io
    import sys
    from thefuck.utils import get_closest, get_shell_info
    from thefuck.types import Configuration
    from thefuck.conf import load_configuration
    from .test_not_configured import MockOpen
    from .test_correct import mock_configuration_details, mock_shell

    # For get_closest to work
    load_configuration()

    buffer = io.BytesIO()
    sys.stderr = buffer

    configured_successfully(
        configuration_details=Configuration(
            reload=u'{} --reload'.format(get_closest('fish')[0]),
            path=mock_configuration_details.path,
            content=u'fuck'))


# Generated at 2022-06-22 00:51:27.573286
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git commint'))


# Generated at 2022-06-22 00:51:35.811333
# Unit test for function color
def test_color():
    # pylint: disable=protected-access
    if sys.version_info[0] < 3:
        assert color('test') == colorama.Fore._RESET + 'test' +\
            colorama.Fore._RESET
    else:
        assert color('test') == colorama.Fore._RESET_ALL + 'test' +\
            colorama.Fore._RESET_ALL
    colorama.init(strip=True)
    settings._no_colors = True
    assert color('test') == ''

# Generated at 2022-06-22 00:51:37.095990
# Unit test for function rule_failed
def test_rule_failed():
    exception_type, exception_value, traceback = sys.exc_info()
    rule_failed('test', (exception_type, exception_value, traceback))

# Generated at 2022-06-22 00:51:42.024983
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import fuck_alias_details
    from .compat import python_version_tuple
    assert how_to_configure_alias(
               fuck_alias_details(
                   python_version_tuple().major,
                   '~/.zshrc',
                   'source ~/.zshrc')) == None


# Generated at 2022-06-22 00:51:44.029651
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias('configuration_details') == None



# Generated at 2022-06-22 00:51:53.874225
# Unit test for function rule_failed
def test_rule_failed():
    #set fake parameters
    rule = "testrule"
    exc_info ="testexception"

    #set trace output to stdout for catching messages
    tmp = sys.stderr
    sys.stderr = sys.stdout

    #execute tested code
    rule_failed(rule, exc_info)

    #reset stdout and set trace output to stderr
    sys.stdout = tmp
    sys.stderr = sys.stdout

# Generated at 2022-06-22 00:51:55.890251
# Unit test for function version
def test_version():
    assert version('test', 'test', 'test') == None



# Generated at 2022-06-22 00:52:06.452369
# Unit test for function confirm_text
def test_confirm_text():
    for corrected_command in [
            const.Command('echo "hi"',
                          is_corrected=True,
                          has_side_effect=False,
                          side_effect_description=None),
            const.Command('echo "hi"',
                          is_corrected=True,
                          has_side_effect=True,
                          side_effect_description=u'will remove all files')]:
        sys.stderr = sys.__stderr__ = sys.stdout = sys.__stdout__ = StringIO()
        with nested(patch('thefuck.utils.settings.no_colors', False),
                    patch('thefuck.utils.color', lambda x: x)):
            confirm_text(corrected_command)

# Generated at 2022-06-22 00:52:13.693701
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    try:
        sys.stderr = StringIO()
        failed(u'Something wrong')
        assert sys.stderr.getvalue() == u'\x1b[31mSomething wrong\x1b[0m\n'
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:52:18.549261
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    _stdout = sys.stdout
    try:
        sys.stdout = sys.stderr
        confirm_text(
            thefuck.types.CorrectedCommand('git co', 'git checkout', False))
    finally:
        sys.stdout = _stdout

# Generated at 2022-06-22 00:52:19.398621
# Unit test for function debug
def test_debug():
    debug('some debug message')



# Generated at 2022-06-22 00:52:22.422708
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    debug('msg')
    assert sys.stderr.getvalue() == 'msg\n'

# Generated at 2022-06-22 00:52:24.122601
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigurationDetails('false', 'already'))

# Generated at 2022-06-22 00:52:26.279396
# Unit test for function warn
def test_warn():
    assert u'[WARN] title\n' == warn(u'title')



# Generated at 2022-06-22 00:52:28.859518
# Unit test for function rule_failed
def test_rule_failed():
    rule = ""
    exc_info = ""
    rule_failed(rule, exc_info)


# Generated at 2022-06-22 00:52:41.532285
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, can_configure_automatically, path, reload, content):
            self.can_configure_automatically = can_configure_automatically
            self.path = path
            self.reload = reload
            self.content = content

        def _asdict(self):
            return self.__dict__

    for configuration_details in [None, ConfigurationDetails(True, "~/.zshrc", "source ~/.zshrc", "eval $(thefuck --alias)")]:
        how_to_configure_alias(configuration_details)



# Generated at 2022-06-22 00:52:52.398690
# Unit test for function debug_time
def test_debug_time():
    from_ = datetime(2015, 1, 1, 1, 1, 1)
    to_ = datetime(2015, 1, 1, 1, 1, 3)

    class Tester(object):
        def __init__(self):
            self.debug_msgs = []

        def debug(self, msg):
            self.debug_msgs.append(msg)

    tester = Tester()

    def datetime_now():
        datetime_now.counter += 1
        return from_ if datetime_now.counter == 1 else to_

    datetime_now.counter = 0

    with debug_time_('test', datetime_now, tester.debug):
        pass

    assert tester.debug_msgs == ['test took: 0:00:02']


test_debug_time()

# Generated at 2022-06-22 00:52:55.854266
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr.write('test_rule_failed')
    rule_failed('rule','exc_info')
    sys.stderr.write('test_rule_failed')


# Generated at 2022-06-22 00:52:57.809630
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('test')
    settings.debug = False
    debug('test')

# Generated at 2022-06-22 00:52:58.874578
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-22 00:53:03.843077
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command.script = "test"
    corrected_command.side_effect = True
    show_corrected_command(corrected_command)
    corrected_command.script = "test2"
    corrected_command.side_effect = False
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:53:06.538893
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('\n') == None  #doctest: +NORMALIZE_WHITESPACE


# Generated at 2022-06-22 00:53:11.969565
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    f = StringIO()
    sys.stdout = f
    class CorrectedCommand():
        script = u'fuck'
        side_effect = False
    confirm_text(CorrectedCommand())
    assert f.getvalue() == u'$fuck [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-22 00:53:13.655511
# Unit test for function configured_successfully
def test_configured_successfully():
    ret = configured_successfully("source ~/.bashrc")
    assert ret == 0



# Generated at 2022-06-22 00:53:17.447162
# Unit test for function exception
def test_exception():
    def test_func():
        raise Exception('Test')

    try:
        test_func()
    except Exception:
        exception('Rule test', sys.exc_info())

# Generated at 2022-06-22 00:53:21.625795
# Unit test for function confirm_text
def test_confirm_text():
    print(u'\033[1K\r')



# Generated at 2022-06-22 00:53:31.889492
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Command(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    from tests.utils import stdout

    def runner(*args):
        return args

    com1 = Command('ls', None)
    show_corrected_command(com1)
    assert stdout.getvalue() == u'{}ls\n'.format(const.USER_COMMAND_MARK)

    com2 = Command('ls', True)
    show_corrected_command(com2)
    assert stdout.getvalue() == u'{}ls\n{}ls (+side effect)\n'.format(const.USER_COMMAND_MARK, const.USER_COMMAND_MARK)
    stdout.flush()

# Generated at 2022-06-22 00:53:44.570321
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    import os
    import re

    config_path = tempfile.mkdtemp()
    os.environ['SHELL'] = config_path + '/bash'

    from .conf import ConfigurationDetails
    from . import __version__

    how_to_configure_alias(ConfigurationDetails(
        'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        config_path + '/.bashrc',
        'source ~/.bashrc',
        False))

    with open(os.path.join(config_path + '/.bashrc')) as bashrc:
        bashrc_text = bashrc.read()

    with open(os.path.join(config_path + '/bash')) as bash:
        shell_path = bash.read()


# Generated at 2022-06-22 00:53:52.250865
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    configuration_details1 = ConfigurationDetails('', '',
                                                  '', '', '', '',
                                                  False)
    configuration_details2 = ConfigurationDetails('', '',
                                                  '', '', '', '',
                                                  True)
    assert how_to_configure_alias(configuration_details1) == None

    assert how_to_configure_alias(configuration_details2) == None



# Generated at 2022-06-22 00:53:53.041659
# Unit test for function warn
def test_warn():
    return warn


# Generated at 2022-06-22 00:53:55.898858
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('')
    already_configured('/tmp/fuck')
    already_configured('/tmp/fuck')
    already_configured('/tmp/fuck')
    already_configured('/tmp/fuck')

# Generated at 2022-06-22 00:53:56.831947
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-22 00:53:57.652367
# Unit test for function debug
def test_debug():
    debug(u'test debug message')

# Generated at 2022-06-22 00:54:06.011403
# Unit test for function confirm_text
def test_confirm_text():
    def my_input(s=''):
        return s

    corrected_command = type('', (), {})()
    corrected_command.script = 'fuck python'
    corrected_command.side_effect = False
    import sys
    import contextlib
    from io import StringIO
    out = StringIO()
    with contextlib.redirect_stdout(out):
        confirm_text(corrected_command)
    assert out.getvalue().strip() == '💩fuck python [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:54:07.735002
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == '\x1b[31m'

# Generated at 2022-06-22 00:54:18.371294
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    from contextlib import contextmanager
    from io import BytesIO

    class FakeStdOut(object):
        def __init__(self):
            self._buf = BytesIO()

        @property
        def content(self):
            return self._buf.getvalue()

        def write(self, value):
            self._buf.write(value)
            self._buf.flush()

    fake_sys_stdout = FakeStdOut()

    @contextmanager
    def patched_stderr(stream):
        original_stderr = sys.stderr
        sys.stderr = stream
        try:
            yield
        finally:
            sys.stderr = original_stderr


# Generated at 2022-06-22 00:54:20.497959
# Unit test for function debug_time
def test_debug_time():
    from . import debug
    settings.debug = True
    with debug_time('test_debug'):
        pass

# Generated at 2022-06-22 00:54:22.086338
# Unit test for function color
def test_color():
    assert color('green') == colorama.Fore.GREEN
    assert color('green') == ''

# Generated at 2022-06-22 00:54:23.690832
# Unit test for function version
def test_version():
    assert version("1.0","2.7","bash")


# Generated at 2022-06-22 00:54:35.785729
# Unit test for function rule_failed
def test_rule_failed():
    import re
    rule_failed('git-add', ('a', 'b', 'c'))
    rule_failed('git-commit', ('a', 'b', 'c'))
    rule_failed('git-push', ('g', 'h', 'i'))
    rule_failed('fuck', ('d', 'e', 'f'))
    rule_failed('fuck', ('j', 'k', 'l'))
    rule_failed('fuck', ('m', 'n', 'o'))
    assert re.search(r'^\[WARN\] Rule git-add:', sys.stderr.getvalue())
    assert re.search(r'^\[WARN\] Rule git-commit:', sys.stderr.getvalue())

# Generated at 2022-06-22 00:54:46.020666
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import mock
    import os

    import thefuck.main

    with mock.patch.object(thefuck.main, 'settings', autospec=True):
        with mock.patch.object(thefuck.main.sys, 'stderr',
                               StringIO()) as stderr:
            thefuck.main.settings.debug = False
            thefuck.main.debug('some message')
            assert os.linesep == stderr.getvalue()
            thefuck.main.settings.debug = True
            thefuck.main.debug('other message')
            assert u'debug: other message\n' == stderr.getvalue()

# Generated at 2022-06-22 00:54:47.838737
# Unit test for function already_configured
def test_already_configured():
    configuration_details = ('~/.config/fish/config.fish', 'source')
    already_configured(configuration_details)

# Generated at 2022-06-22 00:54:54.602958
# Unit test for function already_configured
def test_already_configured():
    from .utils import sectostr, python_version
    from .shells import shell_info
    reload_command = "alias fuck='eval $(thefuck $(fc -ln -1))'"
    already_configured(dict(reload=reload_command))
    sys.stderr.write(u'The Fuck {} using Python {} and {}\n'.format('3.22',
        python_version(), shell_info('bash', None)))

# Generated at 2022-06-22 00:55:03.810193
# Unit test for function color
def test_color():
    assert not settings.no_colors
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == '\x1b[41m\x1b[37m\x1b[1m'
    assert color(colorama.Style.RESET_ALL) == '\x1b[0m'
    settings.no_colors = True
    assert not color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT)
    assert not color(colorama.Style.RESET_ALL)



# Generated at 2022-06-22 00:55:13.718108
# Unit test for function configured_successfully
def test_configured_successfully():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stdout', new_callable=StringIO) as fake_out:
        configured_successfully(None)
        assert (u'{bold}fuck{reset} alias configured successfully!\n'
                u'For applying changes run {bold}{reload}{reset}'
                u' or restart your shell.'.format(
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL),
                    reload=None)) == fake_out.getvalue().splitlines()[0]

# Generated at 2022-06-22 00:55:26.554540
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from StringIO import StringIO
    from . import utils
    from .correct import Command, CorrectedCommand
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    settings.no_colors = False
    show_corrected_command(CorrectedCommand(Command(script='git log'), 'git log --all'))
    sys.stderr.seek(0)
    result = sys.stderr.read()
    sys.stderr = old_stderr
    assert result == '{prefix}{bold}git log{reset}\n'.format(prefix=const.USER_COMMAND_MARK, bold=utils.colorama.Style.BRIGHT)

# Generated at 2022-06-22 00:55:34.047438
# Unit test for function exception
def test_exception():
    exc_info = (None, None, None)
    exception(u'title', exc_info)
    assert sys.stderr.getvalue() == (
        u'\x1b[41m\x1b[37m\x1b[1m[WARN] title:\x1b[0m\n'
        u'\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m\n\n')

# Generated at 2022-06-22 00:55:36.482557
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigurationDetails(
        can_configure_automatically=True,
        reload='reload',
        path='.bashrc',
        content='fuck'))

# Generated at 2022-06-22 00:55:42.048034
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {
        'can_configure_automatically': True,
        'content': 'content',
        'path': 'path',
        'reload': 'reload'
    }

    how_to_configure_alias(configuration_details)
    assert True

# Generated at 2022-06-22 00:55:45.986389
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    try:
        raise Exception('some error')
    except Exception as e:
        rule = Rule('some rule', 'some command', 'some regex', True, True, lambda match: match)
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:55:49.813184
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False
    assert color('green') == colorama.Fore.GREEN

# Generated at 2022-06-22 00:55:59.960034
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .types import ConfigurationDetails

    # ipython has weird output
    sys.stderr, stderr = sys.stderr, sys.__stderr__
    # but it's nice to verify it anyway
    sys.stdout, stdout = sys.stdout, sys.__stdout__

    # regular case
    how_to_configure_alias(ConfigurationDetails('source ~/.bashrc',
                                                '/home/user/.bashrc',
                                                'source ~/.bashrc'))

# Generated at 2022-06-22 00:56:12.107022
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

    print(
        u"Please put {bold}{content}{reset} in your "
        u"{bold}{path}{reset} and apply "
        u"changes with {bold}{reload}{reset} or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            content=u'x',
            path=u'x',
            reload=u'x'))


# Generated at 2022-06-22 00:56:25.505102
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    import sys
    import StringIO
    class FakeRule(object):
        def __init__(self):
            self.name = "fake rule name"

    class TestLog(unittest.TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            sys.stderr = StringIO.StringIO()

        def tearDown(self):
            sys.stderr = self.stderr

        def test_rule_failed(self):
            fake_exc_info = ("type", "val", "trace")
            rule_failed(FakeRule(), fake_exc_info)

# Generated at 2022-06-22 00:56:26.858385
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(configuration_details=configuration_details)

# Generated at 2022-06-22 00:56:34.443552
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell

    shell = Shell(False)
    how_to_configure_alias(shell.configuration_details)



# Generated at 2022-06-22 00:56:43.320166
# Unit test for function already_configured
def test_already_configured():
    try:
        import io
        from contextlib import redirect_stdout
        a = io.StringIO()
        already_configured(None)
        with redirect_stdout(a):
            already_configured(None)
        assert a.getvalue() == (u"Seems like \x1b[1mfuck\x1b[22m alias already configured!\n"
                                u"For applying changes run \x1b[1mreload\x1b[22m or restart your shell.\n")
    except ImportError:
        pass



# Generated at 2022-06-22 00:56:49.727974
# Unit test for function failed
def test_failed():
    from six import StringIO
    import sys

    with mock.patch.object(sys, 'stderr', StringIO()):
        failed(u'Ошибка')

    sys.stderr.seek(0)
    assert sys.stderr.read() == u'\x1b[31mОшибка\x1b[0m\n'



# Generated at 2022-06-22 00:56:52.148856
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('1')
    except ValueError:
        exception('1', sys.exc_info())

# Generated at 2022-06-22 00:56:56.368545
# Unit test for function confirm_text
def test_confirm_text():
    test_input = ['test', 'test2\r', 'test3 +side effect\r', 'test4 +side effect\r']

    for command in test_input:
        confirm_text(command)

if __name__ == "__main__":
    test_confirm_text()

# Generated at 2022-06-22 00:56:57.041050
# Unit test for function debug
def test_debug():
    debug('Test')

# Generated at 2022-06-22 00:57:03.069093
# Unit test for function configured_successfully
def test_configured_successfully():
    sys.stderr.write('stderr')
    print('stdout')
    configured_successfully(what)
    configured_successfully(what)
    configured_successfully(what)

    # Output:
    # stderr
    # stdout
    # \033[1mfuck\033[0m alias configured successfully!
    # For applying changes run \033[1mreload\033[0m or restart your shell.

# Generated at 2022-06-22 00:57:08.258471
# Unit test for function already_configured
def test_already_configured():
    from thefuck.shells import get_shell
    import StringIO
    new_std = StringIO.StringIO()
    old_std = sys.stderr
    sys.stderr = new_std
    already_configured(get_shell())
    sys.stderr = old_std


# Generated at 2022-06-22 00:57:16.546386
# Unit test for function debug
def test_debug():
    """This test should be runned with -s flag for coverage"""
    import os
    import tempfile
    from .conf import settings
    from .settings_manager import reload_settings

    fd, settings_path = tempfile.mkstemp()
    settings.CONFIG_PATH = settings_path
    settings.DEBUG = True
    reload_settings()
    debug(u'123')
    assert open(settings_path).read() == ('[fuck]\n'
                                          'debug = True\n')
    os.remove(settings_path)

# Generated at 2022-06-22 00:57:19.066441
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time(u'str'):
        time.sleep(1)
    debug(u'1')

# Generated at 2022-06-22 00:57:27.727798
# Unit test for function warn
def test_warn():
    from .utils import capture_stderr

    with capture_stderr() as stderr:
        warn(u'test')
    assert u'[WARN] test\n' in stderr.content



# Generated at 2022-06-22 00:57:30.182955
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type('', (), {'reload': u'zsh reload'})
    already_configured(configuration_details)

# Generated at 2022-06-22 00:57:33.813945
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == ''
    settings.no_colors = False
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN


# Generated at 2022-06-22 00:57:38.119131
# Unit test for function already_configured
def test_already_configured():
    actual_output = [u'']

    def fake_print(value):
        actual_output[0] = value

    with mock.patch('thefuck.shells.print', fake_print):
        already_configured(ConfigurationDetails('reload'))

    assert actual_output[0] ==\
        ('Seems like \x1b[1mfuck\x1b[0m alias already configured!\n'
         'For applying changes run \x1b[1mreload\x1b[0m or restart your shell.')



# Generated at 2022-06-22 00:57:44.364229
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('unalias fuck') == u"alias fuck = 'eval $(thefuck $(fc -ln -1)); history -r' [enter/↑/↓/ctrl+c]"
    assert confirm_text('unalias fuck') == u"alias fuck = 'eval $(thefuck $(fc -ln -1)); history -r' [enter/↑/↓/ctrl+c]"



# Generated at 2022-06-22 00:57:45.006591
# Unit test for function configured_successfully
def test_configured_successfully():
    pass

# Generated at 2022-06-22 00:57:48.416341
# Unit test for function configured_successfully
def test_configured_successfully():
    from ..shells import Shell
    assert configured_successfully(Shell(
        'fish', '~/.config/fish/functions/fuck.fish', 'source ~/.config/fish/config.fish')
    ) == None

# Generated at 2022-06-22 00:57:49.111332
# Unit test for function debug
def test_debug():
    debug('Hello')

# Generated at 2022-06-22 00:57:51.605341
# Unit test for function configured_successfully
def test_configured_successfully():
    setattr(settings, 'no_colors', False)
    configured_successfully({"reload": "fuck --reload"})

# Generated at 2022-06-22 00:57:53.737484
# Unit test for function color
def test_color():
    assert color('test') == ''
    settings.no_colors = False
    assert color('test') == 'test'

# Generated at 2022-06-22 00:58:05.978585
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    import os
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False) as t:
        t.write(u'export PATH="{}":$PATH'.format(os.getcwd())
                .encode('utf-8'))
        t.flush()
        configuration_details = Shell('bash').get_aliases() \
            ._replace(path='/tmp/xxx', content=t.name)
    configured_successfully(configuration_details)



# Generated at 2022-06-22 00:58:11.336138
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    >>> show_corrected_command(CorrectedCommand('ls -lah', side_effect=False))
    ➜  ls -lah
    >>> show_corrected_command(CorrectedCommand('apt-get install git', side_effect=True))
    ➜  apt-get install git (+side effect)
    """


# Generated at 2022-06-22 00:58:21.166476
# Unit test for function warn
def test_warn():
    import sys
    from StringIO import StringIO

    class _Warn(object):
        def __init__(self):
            self._buffer = StringIO()
            self._stdout = sys.stdout

        def __enter__(self):
            sys.stderr = self._buffer
            return self

        def __exit__(self, *args):
            sys.stderr = self._stdout

        def read(self):
            return self._buffer.getvalue()

    with _Warn() as warn:
        warn('title')
        assert u'[WARN] title' in warn.read()


# Generated at 2022-06-22 00:58:28.381346
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = type(
        'configuration_details',
        (object,),
        {'reload': 'reload', 'loaded': True, 'can_configure_automatically': False})
    import sys
    import __builtin__
    builtin_open = __builtin__.open
    __builtin__.open = lambda path, mode: sys.__stdout__
    try:
        configured_successfully(configuration_details)
    finally:
        __builtin__.open = builtin_open

# Generated at 2022-06-22 00:58:30.723972
# Unit test for function already_configured
def test_already_configured():
    # should pass
    already_configured(configuration_details)


# Generated at 2022-06-22 00:58:35.994984
# Unit test for function failed
def test_failed():
    settings.no_colors = True
    settings.debug = False
    import StringIO
    with StringIO.StringIO() as buf:
        sys.stderr = buf
        failed(u"failed")
        assert buf.getvalue() == u'failed\n'



# Generated at 2022-06-22 00:58:36.748887
# Unit test for function already_configured
def test_already_configured():
    assert True

# Generated at 2022-06-22 00:58:38.062035
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details)


# Generated at 2022-06-22 00:58:39.263597
# Unit test for function warn
def test_warn():
    warn('title')


# Generated at 2022-06-22 00:58:41.907759
# Unit test for function debug_time
def test_debug_time():
    """
    >>> debug_time('name'):
    >>>     __import__('time').sleep(1)
    >>>
    DEBUG: name took: 1 sec
    """
    pass

# Generated at 2022-06-22 00:58:50.101541
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert color(colorama.Style.BRIGHT) == '', 'color() should return empty string'
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:58:51.714571
# Unit test for function failed
def test_failed():
    assert failed('Title') == '\n[WARN] Title'



# Generated at 2022-06-22 00:58:54.795377
# Unit test for function debug_time
def test_debug_time():
    import datetime
    with debug_time('start'):
        #delta = datetime.timedelta(seconds=3)
        #time.sleep(3)
        pass

# Generated at 2022-06-22 00:58:58.409602
# Unit test for function already_configured
def test_already_configured():
    output = u"Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell."
    assert output == already_configured(u"source ~/.bashrc")


# Generated at 2022-06-22 00:59:05.232748
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT) == '\x1b[101m\x1b[97m\x1b[1m'
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:59:06.271362
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:59:09.905914
# Unit test for function version
def test_version():
    from . import __version__
    import platform
    from .shells import shell
    from .log import init
    init()
    version(__version__, platform.python_version(), shell.get_shell_info())

# Generated at 2022-06-22 00:59:12.063206
# Unit test for function color
def test_color():
    assert not color('foo')
    settings.no_colors = False
    assert color('foo') == 'foo'

# Generated at 2022-06-22 00:59:18.556383
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .shells.posix import PosixShell
    config = Bash()
    const.USER_COMMAND_MARK = ''
    corrected_command = PosixShell.from_shell('echo test', None)
    confirm_text(corrected_command)

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 00:59:19.568389
# Unit test for function already_configured
def test_already_configured():
    already_configured(u'Already configured')

# Generated at 2022-06-22 00:59:27.671886
# Unit test for function failed
def test_failed():
    failed(u'Error!')
    assert sys.stderr.getvalue().endswith(u'Error!\n')

# Generated at 2022-06-22 00:59:30.324945
# Unit test for function exception
def test_exception():
    try:
        int('hello')
    except:
        exception('Testing exception', sys.exc_info())


# Generated at 2022-06-22 00:59:32.143250
# Unit test for function debug
def test_debug():
    assert 'DEBUG: msg' == debug('msg')
    assert '' == debug('msg')

# Generated at 2022-06-22 00:59:35.181252
# Unit test for function rule_failed
def test_rule_failed():
    # TODO: rule_failed is not tested, because
    # I don't know, how to test exc_info
    pass


# Generated at 2022-06-22 00:59:38.647894
# Unit test for function version
def test_version():
    v = version('3.0', '2.7', 'compatible with Bash')
    assert v == (
        u'The Fuck 3.0 using Python 2.7 and compatible with Bash\n')



# Generated at 2022-06-22 00:59:41.697197
# Unit test for function configured_successfully
def test_configured_successfully():
    print(u'configured_successfully')
    assert configured_successfully(u'1', u'2', u'3') == u'The Fuck {} using Python {} and {}'.format(u'1', u'2', u'3')

# Generated at 2022-06-22 00:59:53.545054
# Unit test for function how_to_configure_alias

# Generated at 2022-06-22 00:59:55.992921
# Unit test for function debug_time
def test_debug_time():

    try:
        with debug_time('msg'):
            assert 1 == 1
    except AssertionError:
        assert 1 == 2

# Generated at 2022-06-22 01:00:01.215099
# Unit test for function version
def test_version():
    import io
    output = io.BytesIO()
    sys.stderr = output
    version('3.0', '3.4', 'Bash')
    assert output.getvalue() == b'The Fuck 3.0 using Python 3.4 and Bash\n'

# Generated at 2022-06-22 01:00:06.124538
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from . import conf
    old_stdout = sys.stdout
    stdout = sys.stdout = StringIO()

    try:
        from .types import ConfigurationDetails
        with conf.override_settings(no_colors=True):
            configured_successfully(ConfigurationDetails(
                reload='reload',
                can_configure_automatically=True))
        assert 'alias configured successfully' in stdout.getvalue()
        assert 'reload' in stdout.getvalue()
    finally:
        sys.stdout = old_stdout



# Generated at 2022-06-22 01:00:18.266079
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from mock import patch
    from thefuck import shells
    from thefuck.shells.base import BaseShell

    class TestShell(BaseShell):
        _get_history = lambda self: []
        _get_aliases = lambda self: []

        @property
        def name(self):
            return u'TestShell'

        @property
        def how_to_configure(self):
            return {}

        def _is_running(self, *commands):
            return True

        def get_history(self):
            return []

    shells.enable_support(TestShell())

    with patch('sys.stderr', new=open('/dev/null', 'w')):
        show_corrected_command(
            TestShell().get_aliases()[0].get_new_command('pwd'))


# Unit test

# Generated at 2022-06-22 01:00:19.299419
# Unit test for function failed
def test_failed():
    failed("Hello, world!")

# Generated at 2022-06-22 01:00:25.177215
# Unit test for function failed
def test_failed():
    import sys
    old_stderr = sys.stderr
    try:
        sys.stderr = output = StringIO()
        failed("Something wrong")
        assert output.getvalue() == u'\x1b[31mSomething wrong\x1b[0m\n'
    finally:
        sys.stderr = old_stderr



# Generated at 2022-06-22 01:00:28.535986
# Unit test for function color
def test_color():
    assert color(True) is True
    assert color(False) is False
    assert color(None) is None
    assert color(u'test') == u'test'



# Generated at 2022-06-22 01:00:29.644333
# Unit test for function debug_time
def test_debug_time():
    debug_time("hello")

# Generated at 2022-06-22 01:00:32.535605
# Unit test for function exception
def test_exception():
    exc = Exception()
    try:
        raise exc
    except Exception:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-22 01:00:41.619178
# Unit test for function configured_successfully
def test_configured_successfully():
    from io import StringIO

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stdout', new=StringIO()) as mock_stdout:
        configured_successfully('test_reload_command')

        assert mock_stdout.getvalue() == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}test_reload_command{reset} or restart your shell.\n".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 01:00:43.596047
# Unit test for function exception
def test_exception():
    try:
        raise Exception
    except Exception:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-22 01:00:45.962209
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('Error message')
    except ValueError:
        exception('Title', sys.exc_info())



# Generated at 2022-06-22 01:00:49.634145
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = open('/dev/null', 'w')
    settings.no_colors = True
    confirm_text('command')
    settings.no_colors = False
    confirm_text('command')