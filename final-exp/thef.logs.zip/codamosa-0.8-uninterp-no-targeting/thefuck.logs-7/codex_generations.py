

# Generated at 2022-06-22 00:51:03.854351
# Unit test for function rule_failed
def test_rule_failed():
    """
    >>> import mock
    >>> rule = mock.MagicMock()
    >>> rule.name='test'
    >>> rule.is_enabled = mock.Mock(return_value=True)
    >>> rule.match = mock.Mock(return_value=True)
    >>> exception = mock.MagicMock()
    >>> trace = mock.MagicMock()
    >>> rule_failed(rule,[exception,trace,trace])
    [WARN] Rule test:
    ----------------------------
    """
    pass

# Generated at 2022-06-22 00:51:06.987824
# Unit test for function debug
def test_debug():
    from thefuck.utils import reset_settings
    from thefuck import debug

    reset_settings()
    settings.debug = True
    debug('some debug message')
    assert settings.debug



# Generated at 2022-06-22 00:51:14.753547
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . import corrector as corrector_module

    corrected_command = corrector_module.CorrectedCommand(
        script='git merga origin/feature', side_effect=True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '> git merga origin/feature (+side effect)\n'  # noqa


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 00:51:16.816520
# Unit test for function exception
def test_exception():
    """Utility function for unit testing function exception"""
    try:
        raise Exception('Test Exception')
    except Exception:
        exception('Test', sys.exc_info())

# Generated at 2022-06-22 00:51:18.429292
# Unit test for function already_configured
def test_already_configured():
    from .types import ConfigurationDetails
    already_configured(ConfigurationDetails())

# Generated at 2022-06-22 00:51:20.139617
# Unit test for function failed
def test_failed():
    failed('failed')


# Generated at 2022-06-22 00:51:22.087033
# Unit test for function color
def test_color():
    assert color('bold') == colorama.Style.BRIGHT
    assert color('bold') == ''


# Generated at 2022-06-22 00:51:31.311140
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import sys
    import const
    show_corrected_command(const.CorrectedCommand('ls\n', True))
    assert sys.stderr.getvalue() == '{mark}ls\n (+side effect)\n'.format(mark=const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)
    show_corrected_command(const.CorrectedCommand('ls\n', False))
    assert sys.stderr.getvalue() == '{mark}ls\n\n'.format(mark=const.USER_COMMAND_MARK)

# Generated at 2022-06-22 00:51:43.155516
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    from .rules.python import match, get_new_command
    import sys
    import io

    sys.stderr = io.StringIO()
    rule = rules.Rule('python', match, get_new_command)
    exception('Rule {}'.format(rule.name), sys.exc_info())

# Generated at 2022-06-22 00:51:55.316743
# Unit test for function already_configured
def test_already_configured():
    configuration_details = '123'
    class FakeStream:
        def __init__(self, test):
            self.test = test

        def write(self, msg):
            self.test.assertEqual(
                msg,
                u'Seems like {bold}fuck{reset} alias already configured!'
                u'\nFor applying changes run {bold}{reload}{reset}'
                u' or restart your shell.\n'.format(
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL),
                    reload=configuration_details))

    from . import test
    test.captured_stderr = FakeStream(test)
    already_configured(configuration_details)


# Generated at 2022-06-22 00:52:02.995407
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = '''
        u'{bold}fuck{reset} alias configured successfully!\n'''
    configuration_details += \
        u'For applying changes run {bold}{reload}{reset}'
    configuration_details += \
        u' or restart your shell.'
    print(configuration_details)



# Generated at 2022-06-22 00:52:03.761940
# Unit test for function debug
def test_debug():
    with debug_time("foo"):
        pass

# Generated at 2022-06-22 00:52:05.627062
# Unit test for function warn
def test_warn():
    warn(u'Война и мир')



# Generated at 2022-06-22 00:52:14.508417
# Unit test for function debug
def test_debug():
    formats = [
        u'"{}"',
        u'{}',
        u'"{} "{}" "{}"',
        u'{}{}{}',
        u'""',
        u'',
    ]
    msgs = map(str, [str(i) for i in xrange(1024)])
    msgs.append('тест')

    for format_ in formats:
        for msg in msgs:
            yield check_debug, format_.format(msg)


# Generated at 2022-06-22 00:52:17.973643
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        exception('test', sys.exc_info())

if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-22 00:52:19.737890
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = None
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-22 00:52:28.685664
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrected_command import CorrectedCommand
    from .conf import Config
    from .shells import Shell
    show_corrected_command(CorrectedCommand(
        'touch test', True)) == None
    assert Config.init({
        'command_not_found': 'off',
        'no_colors': True,
        'debug': False,
        'require_confirmation': False,
        'rules': [],
        'exclude_rules': []}) == None
    assert Shell.init('sh') == None

# Generated at 2022-06-22 00:52:32.504698
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'fuck fuck'
    confirm_text(corrected_command)
    updated = u'┌┤ fuck fuck├┘ [enter/↑/↓/ctrl+c]'
    assert updated == corrected_command

# Generated at 2022-06-22 00:52:34.345587
# Unit test for function exception
def test_exception():
    try:
        raise Exception("Test exception")
    except Exception:
        exception("Test",
        sys.exc_info())

# Generated at 2022-06-22 00:52:40.313079
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    out = StringIO()
    sys.stdout = out
    configured_successfully({'reload': 'source ~/.bash_profile'})
    result = out.getvalue()
    assert 'fuck alias configured successfully!' in result
    assert 'source ~/.bash_profile' in result
    sys.stdout = sys.__stdout__

# Generated at 2022-06-22 00:52:44.976989
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:52:48.909773
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    try:
        with debug_time('test'):
            # Wait 1 second
            pass
    except:
        pass
    else:
        passed = (datetime.now() - started).microseconds < 50000



# Generated at 2022-06-22 00:52:51.516299
# Unit test for function already_configured
def test_already_configured():
    import colorama
    from .conf import settings

    settings.no_colors = True
    already_configured('reload')
    settings.no_colors = False
    colorama.init()
    already_configured('reload')

# Generated at 2022-06-22 00:52:53.691492
# Unit test for function version
def test_version():
    version("3.2.2", "2.7.6", "Linux")

if __name__ == "__main__":
    test_version()

# Generated at 2022-06-22 00:52:58.873418
# Unit test for function exception
def test_exception():
    import sys
    import StringIO
    # sys.stderr.write(u'omg\n')
    sys.stderr = StringIO.StringIO()
    try:
        raise Exception("oops")
    except:
        exception("title", sys.exc_info())
    assert "oops" in sys.stderr.getvalue()

# Generated at 2022-06-22 00:53:01.645199
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exception('test', sys.exc_info())



# Generated at 2022-06-22 00:53:08.398794
# Unit test for function debug
def test_debug():
    with _mocked_debug() as mock_print:
        debug(u'foo')
        assert mock_print.mock_calls == []
        settings.debug = True
        debug(u'foo')
        assert len(mock_print.mock_calls) == 1
        assert u'foo' in mock_print.mock_calls[0][1][0]



# Generated at 2022-06-22 00:53:13.119513
# Unit test for function rule_failed
def test_rule_failed():
    import pytest
    exception_msg = u'Test'
    exc_info = (Exception, Exception(exception_msg),
                Exception(exception_msg).__traceback__)
    with pytest.raises(SystemExit):
        rule_failed(None, exc_info)



# Generated at 2022-06-22 00:53:17.000009
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text({'script': 'echo', 'side_effect': True})
    assert confirm_text({'script': 'echo', 'side_effect': False})

# Generated at 2022-06-22 00:53:19.696880
# Unit test for function already_configured
def test_already_configured():
    try:
        already_configured(['source ~/.bash_profile'])
    except Exception:
        raise AssertionError(already_configured)

# Generated at 2022-06-22 00:53:25.708472
# Unit test for function debug
def test_debug():
    debug(u'Test debug message')

# Generated at 2022-06-22 00:53:27.291164
# Unit test for function failed
def test_failed():
    failed(u'Some error')
    return colorama.Fore.RED + 'Some error' + colorama.Style.RESET_ALL + '\n'

# Generated at 2022-06-22 00:53:30.565139
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(const.ConfigurationDetails(
        path=u'/Users/user/.bashrc')) == 'fuck alias configured successfully!\nFor applying changes run reload or restart your shell.'


# Generated at 2022-06-22 00:53:42.967974
# Unit test for function confirm_text
def test_confirm_text():
    from os import system as _system
    from os import environ as _environ
    from os import getenv as _getenv
    from os import remove as _remove

    _test_environ = _environ.copy()
    _test_environ['TERM'] = 'xterm-256color'

    try:
        _remove('.test')
    except:
        pass

    def _system(cmd):
        with open('.test', 'w') as _file:
            _file.write(cmd + '\n')

    def _getenv(key, default=None):
        if key == 'TERM':
            return 'xterm-256color'
        return default


# Generated at 2022-06-22 00:53:54.490864
# Unit test for function exception
def test_exception():
    def mock_format_exception(ttype, value, tb):
        return ['ttype: {}\n'.format(ttype),
                'value: {}\n'.format(value),
                'tb: {}\n'.format(tb),
                '----------------------------']

    sys.stderr.write('stderr_start')
    with settings(no_colors=True):
        exception('title', (None, None, None), format_exception=mock_format_exception)
    sys.stderr.write('stderr_end')
    assert sys.stderr.getvalue() == 'stderr_start[WARN] title:ttype: None\nvalue: None\ntb: None\n----------------------------\nstderr_end'

# Generated at 2022-06-22 00:54:06.350351
# Unit test for function rule_failed
def test_rule_failed():
    """
    checks if the error message is the same as the one in the defined function
    rule_failed
    """
    error_mess = "File \"/Users/tina/Desktop/SS2017/The-Fuck/thefuck/utils.py\", line 18, in rule_failed\n    exception(u'Rule {}'.format(rule.name), exc_info)\n"
    exc_info = "File \"/Users/tina/Desktop/SS2017/The-Fuck/thefuck/types.py\", line 43, in filter_match\n    len([r for r in self.rules if r.match(command)]),\nTypeError: object of type 'NoneType' has no len()\n"
    assert error_mess in rule_failed(exc_info)

# Generated at 2022-06-22 00:54:11.756385
# Unit test for function debug_time
def test_debug_time():
    print("import unittest")
    import unittest
    print("class Test(unittest.TestCase):")
    class Test(unittest.TestCase):
        print("def test_debug_time(self):")
        def test_debug_time(self):
            print("with debug_time('test'):")
            with debug_time('test'):
                print("@@ pass @@")
                pass
            print("@@ pass @@")
            pass


if __name__ == '__main__':
    print("test_debug_time()")
    test_debug_time()
    print("unittest.main()")
    unittest.main()

# Generated at 2022-06-22 00:54:14.293447
# Unit test for function debug_time
def test_debug_time():
    def run():
        time.sleep(0.1)

    with debug_time('test'):
        run()


# Generated at 2022-06-22 00:54:15.378426
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-22 00:54:17.427594
# Unit test for function warn
def test_warn():
    assert warn('hello') == '[WARN] hello\n'

# Generated at 2022-06-22 00:54:23.166489
# Unit test for function already_configured
def test_already_configured():
    assert already_configured() == True


# Generated at 2022-06-22 00:54:28.149799
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'content': 'alias fuck=\'eval $(thefuck $(fc -ln -1))\'', 'path': '.bashrc', 'reload': 'source .bashrc && exec $(SHELL) -l'}
    assert how_to_configure_alias(configuration_details) == None


# Generated at 2022-06-22 00:54:37.227632
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug(u'test')
        assert stderr.write.called
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

        debug(u'test2')
        assert stderr.write.called
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test2\n')



# Generated at 2022-06-22 00:54:45.279742
# Unit test for function already_configured
def test_already_configured(): # pragma: no cover
    already_configured(const.ConfigurationDetails(conf_path='source ~/.zshrc',
                                                  can_configure_automatically=False,
                                                  reload='source ~/.zshrc'))
    sys.stderr.write(u'\n')
    already_configured(const.ConfigurationDetails(conf_path='.zshrc',
                                                  can_configure_automatically=True,
                                                  reload='source ~/.zshrc'))

# Generated at 2022-06-22 00:54:50.146379
# Unit test for function debug
def test_debug():
    class FakeStderr(object):
        content = []

        def write(self, data):
            self.content.append(data)

    debug(u'test message')  # Should not get written

    settings.debug = True
    try:
        stderr = FakeStderr()
        sys.stderr = stderr
        debug(u'test message')
    finally:
        settings.debug = False
        sys.stderr = sys.__stderr__

    assert u'DEBUG: test message\n' == stderr.content[0]

# Generated at 2022-06-22 00:54:51.941119
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details)


# Generated at 2022-06-22 00:55:03.919245
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rules.git_dirty_worktree import match, get_new_command
    from .shells.bash import Bash

    assert match('git blah blah blah', None)
    assert get_new_command('git blah blah blah', None) == 'git stash; git blah blah blah; git stash pop'
    assert not match('git stash', None)
    assert not get_new_command('git stash; git blah blah blah; git stash pop', None) == 'git stash; git blah blah blah; git stash pop'

    corrected_command = get_new_command('git stash; git blah blah blah; git stash pop', None)
    script = corrected_command.script
    side_effect = corrected_command.side_effect

    show_corrected_command(corrected_command)


# Generated at 2022-06-22 00:55:05.681665
# Unit test for function exception
def test_exception():
    exception(u'Cool', (TypeError, TypeError('cool'), None))



# Generated at 2022-06-22 00:55:11.272073
# Unit test for function debug
def test_debug():
    from .utils import capture_stderr
    with capture_stderr() as stderr:
        debug(u'test')
    assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-22 00:55:15.259772
# Unit test for function failed
def test_failed():

    # Given
    msg = 'Hello world!'

    # When
    failed(msg)

    # Then
    assert sys.stderr.getvalue() == '\x1b[31mHello world!\x1b[0m\n'



# Generated at 2022-06-22 00:55:22.869698
# Unit test for function failed
def test_failed():
    failed('some message')
    assert u'\x1b[31msome message\x1b[0m\n' in sys.stderr.getvalue()



# Generated at 2022-06-22 00:55:34.154532
# Unit test for function rule_failed
def test_rule_failed():
    class FakeRule:
        def __init__(self, name):
            self.name = name

    rule_failed(FakeRule('rule_name'), 'exc_info')
    assert ['[WARN] Rule rule_name:\n',
            'Traceback (most recent call last):\n',
            '  File "thefuck/shells/utils.py", line 81, in rule_failed\n'
            '    title=title, trace=\'\'.join(format_exception(*exc_info)))\n',
            'AssertionError\n',
            '----------------------------\n'
            '\n'] == sys.stderr.getvalue().splitlines()



# Generated at 2022-06-22 00:55:38.692125
# Unit test for function rule_failed
def test_rule_failed():
    from mock import MagicMock
    from .rules import Rule
    rule = Rule(name='foo', side_effect=False)
    rule_failed(rule, exc_info=('type', 'value', 'traceback'))

# Generated at 2022-06-22 00:55:44.488437
# Unit test for function exception
def test_exception():
    title = u'fake'
    msg = u'fake exception'
    exc_info = (Exception, Exception(msg), None)
    _stdout, sys.stdout = sys.stdout, sys._stdout = StringIO(), StringIO()
    try:
        exception(title, exc_info)
        sys.stdout.seek(0)
        result = sys.stdout.read()
        assert u'[WARN] fake:' in result
        assert u'Exception: fake exception' in result
    finally:
        sys.stdout = _stdout

# Generated at 2022-06-22 00:55:45.927164
# Unit test for function failed
def test_failed():
    failed(u'Кириллица')  # Is a bad example as tests should be in ASCII

# Generated at 2022-06-22 00:55:47.532506
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None

# Generated at 2022-06-22 00:55:57.777310
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK='fuck'
    corrected_command=u'ls'
    expect_output='''\r
fuckls [enter/↑/↓/ctrl+c]'''  #YES, there MUST be \r at beginning of the string
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    stdout=StringIO()
    sys.stderr=stdout
    confirm_text(corrected_command)
    assert expect_output==stdout.getvalue(),\
    "test confirm_text(): expect_output=%s,got=%s"%(expect_output,stdout.getvalue())


# Generated at 2022-06-22 00:56:00.355312
# Unit test for function rule_failed
def test_rule_failed():
    rule = type(u'Rule', (), {'name': u'name'})
    rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:56:02.740526
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.Configuration('PS1', 'reload', '~/.bashrc', 'source ~/.bashrc'))

# Generated at 2022-06-22 00:56:03.498020
# Unit test for function configured_successfully
def test_configured_successfully():
    assert (configured_successfully('configuration_details')),\
        "configured_successfully(variable) always returns True"

# Generated at 2022-06-22 00:56:09.137501
# Unit test for function failed
def test_failed():
    failed('Test fail message')

# Generated at 2022-06-22 00:56:10.712310
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('fuck')


# Generated at 2022-06-22 00:56:15.131825
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.bash import Bash
    from .utils import get_closest
    bash = Bash()
    configuration_details = get_closest(bash.get_aliases())
    assert how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:56:17.608099
# Unit test for function version
def test_version():
    assert version('1.1.1', '2.7.5', 'Zsh 5.0.2') == ''

# Generated at 2022-06-22 00:56:21.508229
# Unit test for function debug
def test_debug():
    from .utils import get_closest, restore_last_command

    restore_last_command()
    assert get_closest(['ls']) == ('ls', 0)
    assert get_closest(['ls']) == ('ls', 0)
    assert get_closest(['2']) == ('ls', 1)
    debug(u'1')
    debug(u'2')
    debug(u'3')
    print(u'OK')

# Generated at 2022-06-22 00:56:27.264282
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ['-l']))
    show_corrected_command(CorrectedCommand('rm', ['f.txt'], side_effect=u"rm -r directory"))
    show_corrected_command(CorrectedCommand('rm', ['f.txt']))
    sys.stderr.write('\n')

# Generated at 2022-06-22 00:56:28.846873
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-22 00:56:41.429498
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rules.git import match, get_new_command
    import os
    import sys
    from colorama import Fore, Style
    from thefuck.utils import get_closest

    #given
    script = "git"
    user_input = "git c"
    #when
    corrected_command = get_new_command(script, match(script, get_closest(script, user_input)))
    sys.stderr.write(const.USER_COMMAND_MARK)
    sys.stderr.write(Fore.GREEN)
    sys.stderr.write(Style.BRIGHT)
    sys.stderr.write(corrected_command)
    sys.stderr.write(Style.RESET_ALL)
    sys.stderr.write('\n')

# Generated at 2022-06-22 00:56:47.447155
# Unit test for function exception
def test_exception():
    """
    >>> try:
    ...     1/0
    ... except ZeroDivisionError:
    ...     exception('Test exception', sys.exc_info())
    [WARN] Test exception:
    Traceback (most recent call last):
      File "<stdin>", line 2, in <module>
    ZeroDivisionError: integer division or modulo by zero
    ----------------------------
    """


# Generated at 2022-06-22 00:56:49.315904
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except:
        exception('Test', sys.exc_info())

# Generated at 2022-06-22 00:56:57.677083
# Unit test for function version
def test_version():
    """
    Function test version()
    """
    sys.stderr.write(
        u'The Fuck {} using Python {} and {}\n'.format('v3.6',
                                                       'v7.5',
                                                       'bash'))

# Generated at 2022-06-22 00:56:59.127077
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'foo')  # noqa



# Generated at 2022-06-22 00:57:00.237557
# Unit test for function debug
def test_debug():
    debug('123')
    debug('中文')

# Generated at 2022-06-22 00:57:04.324453
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(3, (ValueError, ValueError('Test'), None))
    rule_failed(0, (ValueError, ValueError('Test'), None))
    rule_failed(None, (ValueError, ValueError('Test'), None))

# Generated at 2022-06-22 00:57:08.545890
# Unit test for function version
def test_version():
    assert 'The Fuck %s using Python %s and %s\n' % (const.VERSION, sys.version, const.UNIX_SHELL) == \
           version(const.VERSION,sys.version,const.UNIX_SHELL)

# Generated at 2022-06-22 00:57:13.516625
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
            can_configure_automatically=True,
            content='export <path_to>/fuck.py',
            path='~/.bash_profile',
            reload='. ~/.bash_profile'))

# Generated at 2022-06-22 00:57:25.678218
# Unit test for function version
def test_version():
    import io
    import sys
    output = io.StringIO()
    sys.stderr = output
    thefuck_version = '3.0'
    python_version = '2.7.13 (default, Jan 19 2017, 14:48:08) \n[GCC 6.3.0 20170118]'
    shell_info = 'Zsh 5.4.2'
    version(thefuck_version, python_version, shell_info)
    sys.stderr = sys.__stderr__
    assert output.getvalue() == 'The Fuck 3.0 using Python 2.7.13 (default, Jan 19 2017, 14:48:08) \n[GCC 6.3.0 20170118] and Zsh 5.4.2\n'

# Generated at 2022-06-22 00:57:26.760878
# Unit test for function failed
def test_failed():
    failed('foo')



# Generated at 2022-06-22 00:57:29.974165
# Unit test for function failed
def test_failed():
    failed(u'Message')
    output = sys.stderr.getvalue()
    expected = u'\x1b[31mMessage\x1b[0m\n'
    assert output == expected



# Generated at 2022-06-22 00:57:35.850673
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('error'), None)
    title = 'test exception'
    exception(title, exc_info)
    assert u'[WARN] {title}:\n{trace}'.format(title=title,
                                              trace=''.join(format_exception(*exc_info))) in sys.stderr.getvalue()


# Generated at 2022-06-22 00:57:42.493190
# Unit test for function warn
def test_warn():
    sys.stderr.write('\n')
    warn('Test warn')



# Generated at 2022-06-22 00:57:52.176954
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf import ConfigurationDetails
    from thefuck.shells import Bash
    how_to_configure_alias(ConfigurationDetails(
        path='.bashrc',
        content=("eval $(thefuck --alias fuck)\n"
                 "[ -f ~/.fck ] && source ~/.fck"),
        reload='run source ~/.bashrc'))
    how_to_configure_alias(ConfigurationDetails(
        path='.bashrc',
        content=("eval $(thefuck --alias fuck)\n"
                 "[ -f ~/.fck ] && source ~/.fck"),
        reload='run source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-22 00:58:03.842807
# Unit test for function debug
def test_debug():
    from . import utils
    from .conf import settings
    import mock
    import sys
    from .tests.utils import Target

    with Target() as target:
        settings.debug = True
        mock_time = mock.patch('thefuck.utils.datetime', mock.Mock()).start()
        mock_time.datetime.now.return_value = utils.datetime(2016, 4, 1, 0, 0)
        utils.debug(u"debug")
        mock_time.datetime.now.return_value = utils.datetime(2016, 4, 1, 0, 1)
        utils.debug(u"test")

# Generated at 2022-06-22 00:58:05.461774
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) == None


# Generated at 2022-06-22 00:58:15.727870
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime
    import sys
    from .conf import settings

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            sys.stderr.write(u'{} took: {}\n'.format(msg, datetime.now() - started))
    settings.debug = True
    with debug_time('message'):
        x = 0
        while x < 100:
            x += 1
    settings.debug = False
    with debug_time('message'):
        x = 0
        while x < 100:
            x += 1

# Generated at 2022-06-22 00:58:16.950599
# Unit test for function debug
def test_debug():
    debug('test_debug')

# Generated at 2022-06-22 00:58:25.335562
# Unit test for function rule_failed
def test_rule_failed():
    assert rule_failed('Rule', 'Exception') == sys.stderr.write(
        u'{warn}[WARN] {title}:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title='Rule',
            trace='Exception'))



# Generated at 2022-06-22 00:58:27.712679
# Unit test for function rule_failed
def test_rule_failed():
    try:
        1 / 0
    except ZeroDivisionError:
        exc_info = sys.exc_info()
    import logging
    rule_failed(logging.Logger, exc_info)



# Generated at 2022-06-22 00:58:30.128690
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-22 00:58:32.669345
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('test_message')
    except ValueError:
        exception('test_title', sys.exc_info())



# Generated at 2022-06-22 00:58:39.049317
# Unit test for function warn
def test_warn():
    warn(u'title') == u'[WARN] title'

# Generated at 2022-06-22 00:58:47.933819
# Unit test for function confirm_text
def test_confirm_text():
    class CorrectedCommand(object):
        side_effect = False

    corrected_command = CorrectedCommand()

    corrected_command.script = u'fuck pwd'
    confirm_text(corrected_command)

    assert sys.stderr.getvalue() == u'{prefix}{clear}{bold}{script}{reset} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        script=u'fuck pwd',
        side_effect='',
        clear='\033[1K\r',
        bold='',
        green='',
        red='',
        reset='',
        blue='')

# Generated at 2022-06-22 00:58:59.146794
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    import colorama

    with settings(no_colors=False):
        original_stderr = sys.stderr
        try:
            sys.stderr = StringIO()
            colorama.init()
            warn(u'!!!')
            result = sys.stderr.getvalue()
            colorama.deinit()
            assert result == u'{warn}[WARN] !!!{reset}\n'.format(
                warn=color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL))
        finally:
            sys.stderr = original_stderr



# Generated at 2022-06-22 00:59:00.286072
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls -la') == const.USER_COMMAND_MARK + 'ls -la'

# Generated at 2022-06-22 00:59:04.437756
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('Not Implemented')
    except Exception:
        exc_info = sys.exc_info()
        class rule:
            name = 'rule_name'
        rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:59:06.873208
# Unit test for function color
def test_color():
    from thefuck.utils import wrap_color
    assert wrap_color(colorama.Back.RED)
    assert color(colorama.Back.RED) == ''

# Generated at 2022-06-22 00:59:16.484098
# Unit test for function already_configured
def test_already_configured():
    configuration_details = (
        "''",
        '~/.bashrc',
        '~/.bashrc',
        'source ~/.bashrc'
    )
    assert (already_configured(configuration_details) ==
            u"Seems like {bold}fuck{reset} alias already configured!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell.\n".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload=configuration_details.reload))

# Generated at 2022-06-22 00:59:21.531254
# Unit test for function warn
def test_warn():
    warn('test')
    warn('test2')
    assert sys.stderr.getvalue() ==\
        '\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'\
        '\x1b[41m\x1b[37m\x1b[1m[WARN] test2\x1b[0m\n'

# Generated at 2022-06-22 00:59:27.079423
# Unit test for function warn
def test_warn():
    '''Warn should write coloured text to stderr.'''
    sys.stderr = StdoutSpy()
    warn('Sample title')
    assert sys.stderr.out == '\x1b[41m\x1b[37m\x1b[1m[WARN] Sample title\x1b[0m\n'



# Generated at 2022-06-22 00:59:39.461990
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    from contextlib import contextmanager
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.sh import Sh

    @contextmanager
    def mocked_std_streams(out=None):
        old_output = sys.stdout
        if out is None:
            out = StringIO()
        sys.stdout = out
        try:
            yield out
        finally:
            sys.stdout = old_output

    def test_bash(out):
        bash = Bash()
        corrected_command = bash.get_command(u'echo "hello world"', 1)
        confirm_text(corrected_command)
        assert u'echo "hello world" [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:59:50.949337
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = fc.CorrectedCommand('ls ~', False)
    confirm_text(corrected_command)

# Generated at 2022-06-22 00:59:53.169544
# Unit test for function debug_time
def test_debug_time():
    def test_function():
        with debug_time('test_function'):
            import time
            time.sleep(1)
    test_function()

# Generated at 2022-06-22 00:59:59.004504
# Unit test for function failed
def test_failed():
    from io import StringIO
    from unittest.mock import patch
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        failed(u'Тест!')
        assert mock_stderr.getvalue() == u'Тест!\n'

# Generated at 2022-06-22 01:00:02.123325
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception('test', sys.exc_info())


# Unit tests for function rule_failed

# Generated at 2022-06-22 01:00:06.226873
# Unit test for function configured_successfully
def test_configured_successfully():
    class ConfigurationDetails:
        reload = "reload_command"

    assert (u"{bold}fuck{reset} alias configured successfully!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell." == configured_successfully(ConfigurationDetails))

# Generated at 2022-06-22 01:00:08.481660
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-22 01:00:20.378657
# Unit test for function debug
def test_debug():
    def _test(expected_msg, debug_enabled=True, **settings):
        import io
        import six

        std_err = io.StringIO()
        six.moves.builtins.open = lambda _: std_err
        sys.stderr = std_err
        settings.save()
        settings.set(**settings)

        for i in reversed(range(len(expected_msg))):
            debug(expected_msg[i])
            assert std_err.getvalue() == expected_msg[:i + 1] + '\n'

    _test(['foo', 'bar', 'baz'], debug=False)
    _test(['foo', 'bar', 'baz'])
    _test(['foo', 'bar', 'baz'], no_colors=True)

# Generated at 2022-06-22 01:00:24.385767
# Unit test for function debug
def test_debug():
    from sh import Command
    from thefuck.utils import memoize

    @memoize
    def echo(*args, **kwargs):
        return Command('echo')(*args, **kwargs)

    echo('hello', _tty_out=False)

# Generated at 2022-06-22 01:00:25.254974
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Exception message')
    except Exception:
        exception('Title', sys.exc_info())
        assert True

# Generated at 2022-06-22 01:00:26.258100
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from mock import patch

    with patch('sys.stdout') as mock:
        how_to_configure_alias(None)
    assert mock.write.call_count == 4



# Generated at 2022-06-22 01:00:42.633060
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from tests.utils import wrap_stdout
    title = 'test'
    with wrap_stdout() as fake_stdout:
        warn(title)
    result = fake_stdout.getvalue()
    assert result == u'\x1b[41m\x1b[37m\x1b[1m[WARN] {}\x1b[0m\n'.format(title)



# Generated at 2022-06-22 01:00:44.281943
# Unit test for function failed
def test_failed():
    cmd = u'ls bla bla'
    failed(cmd)



# Generated at 2022-06-22 01:00:50.977123
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(
        script='ls', side_effect=False)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(
        script='ls --help', side_effect=False)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(
        script='ls --help', side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-22 01:00:53.828373
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(
        CorrectedCommand('ls -lah', 'ls -la'))


# Unit tests for function confirm_text