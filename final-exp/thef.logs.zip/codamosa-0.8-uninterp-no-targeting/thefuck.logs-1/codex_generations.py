

# Generated at 2022-06-22 00:51:15.194625
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    from .rule import incorrect_syntax

    corrected_command = Mock(
        script=u'rm non-existing-file',
        side_effect=False,
        rule=Mock(name=Mock(return_value=u'Rm')))

    sys.stderr = Mock()
    confirm_text(corrected_command)

# Generated at 2022-06-22 00:51:20.400885
# Unit test for function already_configured
def test_already_configured():
    already_configured(
        settings.ConfigurationDetails(
            path='/home/user/.bashrc',
            content='. /home/user/.config/thefuck/alias',
            reload='source /home/user/.bashrc',
            can_configure_automatically=False))



# Generated at 2022-06-22 00:51:24.720488
# Unit test for function already_configured
def test_already_configured():
    existing_config = "fuck --alias"
    settings.config_file = "Config file"
    print(settings.config_file)
    settings.current_shell = "bash"
    assert "fuck --alias" in existing_config
    assert "Config file" in settings.config_file
    assert "bash" in settings.current_shell


# Generated at 2022-06-22 00:51:26.663806
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('pip install dora')
    assert True

# Generated at 2022-06-22 00:51:29.905408
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = True
    assert debug(u'test')
    settings.debug = False
    assert debug(u'test') is None



# Generated at 2022-06-22 00:51:32.247085
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception('test', sys.exc_info())

# Generated at 2022-06-22 00:51:32.996177
# Unit test for function rule_failed
def test_rule_failed():
    pass

# Generated at 2022-06-22 00:51:34.665272
# Unit test for function warn
def test_warn():
    warn(u"test warn")
    # TODO: assert

# Generated at 2022-06-22 00:51:46.597274
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import tempfile
    from .command import Command

    class CommandTest(Command):

        def __eq__(self, command_str):
            return self.script == command_str

        def __ne__(self, command_str):
            return not self == command_str

    stdout_dir = os.path.join(tempfile.gettempdir(), 'thefuck-stdout')
    stderr_dir = os.path.join(tempfile.gettempdir(), 'thefuck-stderr')
    os.mkdir(stdout_dir)
    os.mkdir(stderr_dir)

    command = CommandTest(script='git commit -m "change"',
                          side_effect=False)

# Generated at 2022-06-22 00:51:48.633585
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command() == const.USER_COMMAND_MARK + corrected_command


# Generated at 2022-06-22 00:51:56.427060
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    import os
    import shlex
    show_corrected_command(CorrectedCommand(
        script=shlex.split(u'ls foo'),
        side_effect=os.makedirs('foo')))
    show_corrected_command(CorrectedCommand(
        script=shlex.split(u'ls foo')))



# Generated at 2022-06-22 00:52:03.142701
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    exc_out = StringIO()
    sys.stderr = exc_out

    already_configured('hello')
    assert(exc_out.getvalue() == u"Seems like \x1b[1mfuck\x1b[22m alias already configured!\nFor applying changes run \x1b[1mhello\x1b[22m or restart your shell.\n")



# Generated at 2022-06-22 00:52:04.111463
# Unit test for function confirm_text
def test_confirm_text():
    assert(confirm_text(None) == None)

# Generated at 2022-06-22 00:52:08.817722
# Unit test for function failed
def test_failed():
    sys.stderr = sys.stdout
    failed('Failed')
    assert sys.stdout.getvalue().split('\n') == [u'\x1b[31mFailed\x1b[0m', '']



# Generated at 2022-06-22 00:52:12.712379
# Unit test for function exception
def test_exception():
    with open('/dev/null', 'w') as sys.stderr:
        try:
            1 / 0
        except ZeroDivisionError:
            exception('This is title', sys.exc_info())

# Generated at 2022-06-22 00:52:13.924928
# Unit test for function warn
def test_warn():
    warn(u'Test')



# Generated at 2022-06-22 00:52:15.610559
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("configuration_details") == None



# Generated at 2022-06-22 00:52:18.940475
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.pip import _Errors as PipErrors
    rule_failed(PipErrors.get_rule(lambda script: True),
                sys.exc_info())

# Generated at 2022-06-22 00:52:20.753111
# Unit test for function exception
def test_exception():
    try:
        raise Exception('qwe')
    except Exception:
        exception('some error', sys.exc_info())

# Generated at 2022-06-22 00:52:23.561972
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception(u'test', sys.exc_info())

# Generated at 2022-06-22 00:52:31.590260
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    class DummyShell(Shell):

        @property
        def app_alias(self):
            return 'fuck'

        @property
        def every_executable_is_app(self):
            return False

        @property
        def history_filename(self):
            raise NotImplementedError()


# Generated at 2022-06-22 00:52:34.880940
# Unit test for function exception
def test_exception():
    sys.stderr = sys.stdout
    exception('title', (Exception, Exception('exc'), None))
    exception('title', (Exception, Exception('exc'), None))

# Generated at 2022-06-22 00:52:39.312834
# Unit test for function exception
def test_exception():
    exc_info = None
    try:
        raise OSError("mocked error")
    except OSError as e:
        exc_info = sys.exc_info()
    exception("mocked error", exc_info)



# Generated at 2022-06-22 00:52:43.730063
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write("\n")
    from .rules.expect import ExpectCommand
    from .shells import Bash
    fn = 'echo "Hello world"'
    show_corrected_command(ExpectCommand(fn, Bash, None))
    sys.stderr.write("\n")

# Generated at 2022-06-22 00:52:45.236141
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigureShellCommand(reload='test'))



# Generated at 2022-06-22 00:52:47.941755
# Unit test for function configured_successfully
def test_configured_successfully():
    assert u"fuck alias configured successfully!" in configured_successfully([])
    assert u"fuck alias" in configured_successfully(["hey"])



# Generated at 2022-06-22 00:52:50.180828
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test error')
    except RuntimeError:
        exception(u'Test title', sys.exc_info())



# Generated at 2022-06-22 00:52:53.500522
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rules.command import Command
    show_corrected_command(Command(u'command', u'script', u'message'))
    show_corrected_command(Command(u'command', u'script', u'message', True))

# Generated at 2022-06-22 00:52:57.861274
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    corrected_command = CorrectedCommand(script='ls -l', side_effect=False)
    show_corrected_command(corrected_command)

if __name__ == "__main__":
    test_show_corrected_command()

# Generated at 2022-06-22 00:52:59.972067
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.git import get_new_command
    rule_failed(get_new_command, None)

# Generated at 2022-06-22 00:53:06.023394
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # test show_corrected_command
    corrected_command = 'command'
    assert show_corrected_command(corrected_command) == True


# Generated at 2022-06-22 00:53:13.167407
# Unit test for function failed
def test_failed():
    import io
    _stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stderr = out
        failed(u'тест')
        assert out.getvalue() == u'{red}тест{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL))
    finally:
        sys.stderr = _stderr

# Generated at 2022-06-22 00:53:19.023939
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'RED') == colorama.Fore.RED + 'RED'
    assert color(colorama.Fore.RED + 'RED') != colorama.Fore.GREEN + 'RED'
    assert color(colorama.Fore.RED + 'RED') != ''



# Generated at 2022-06-22 00:53:21.862074
# Unit test for function color
def test_color():
    assert color(u'RED') == 'RED'
    settings.no_colors = True
    assert color(u'RED') == ''

# Generated at 2022-06-22 00:53:23.069099
# Unit test for function already_configured
def test_already_configured():
    print(already_configured())

# Generated at 2022-06-22 00:53:28.262110
# Unit test for function failed
def test_failed():
    msg = 'Message'
    failed(msg)
    assert sys.stderr.getvalue() == u'{red}{msg}{reset}\n'.format(
        msg=msg,
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:53:38.166669
# Unit test for function debug
def test_debug():
    class TestOutput(object):
        def __init__(self):
            self.result = ""

        def write(self, s):
            self.result += s

    settings.debug = True
    test_output = TestOutput()
    std_err = sys.stderr
    sys.stderr = test_output
    debug(u"DEBUG_MESSAGE")
    sys.stderr = std_err
    settings.debug = False
    assert test_output.result == '\x1b[34m\x1b[1mDEBUG:\x1b[0m DEBUG_MESSAGE\n'

# Generated at 2022-06-22 00:53:46.189777
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(script="script",
                                               side_effect=True)

# Generated at 2022-06-22 00:53:49.902070
# Unit test for function exception
def test_exception():
    class MyError(Exception):
        pass

    try:
        raise MyError('my message')
    except MyError:
        exception('my title', sys.exc_info())

# Generated at 2022-06-22 00:53:52.093753
# Unit test for function exception
def test_exception():
    try:
        raise Exception
    except Exception as e:
        exception('test', sys.exc_info())

# Generated at 2022-06-22 00:53:59.561076
# Unit test for function rule_failed
def test_rule_failed():
    from .types import Rule, Command
    rule = Rule('test', '', lambda: True, None)
    command = Command('ls', '', '', 'ls')
    rule_failed(rule, command)



# Generated at 2022-06-22 00:54:01.210442
# Unit test for function debug_time
def test_debug_time():
    with debug_time('1 second'):
        import time
        time.sleep(1)

# Generated at 2022-06-22 00:54:04.795003
# Unit test for function debug
def test_debug():
    debug('test')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'



# Generated at 2022-06-22 00:54:07.937434
# Unit test for function already_configured
def test_already_configured():
    assert u"Seems like {}fuck{} alias already configured!".format(
            color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL)) == already_configured(
                'configuration_details')

# Generated at 2022-06-22 00:54:11.858329
# Unit test for function exception
def test_exception():
    title = u'foo'
    exc_info = ('text', 'text', 'text')
    sys.stderr = open('exception_sys.stderr', 'w')
    exception(title, exc_info)
    print('test_exception passed')


# Generated at 2022-06-22 00:54:13.626471
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(0)


# Generated at 2022-06-22 00:54:21.311962
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command
    from io import StringIO
    output = StringIO()
    sys.stderr = output
    show_corrected_command(Command('ls', 'ls -a', '', 0, True))
    assert output.getvalue() == u'\033[1K\r\x1b[1m\x1b[38;5;11m$\x1b[0m '+u'ls -a (+side effect)\n'

# Generated at 2022-06-22 00:54:28.090036
# Unit test for function failed
def test_failed():
    """
    >>> import os, sys, io; s = io.StringIO(); sys.stderr = s
    >>> failed('test_failed')
    >>> sys.stderr = sys.__stderr__
    >>> s.getvalue().startswith('\\x1b[31mtest_failed')
    True
    >>> s.truncate(0); s.seek(0)
    0
    """
    pass

# Generated at 2022-06-22 00:54:31.394249
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import CorrectedCommand
    show_corrected_command(CorrectedCommand(u"git sttus", None))

# Generated at 2022-06-22 00:54:32.976362
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details=None) is None

# Generated at 2022-06-22 00:54:37.337612
# Unit test for function debug
def test_debug():
    '''debug() function test'''
    debug('hey')

# Generated at 2022-06-22 00:54:49.400883
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = HowToConfigureAliasDetails(
        path=u'/home/user/.local/etc',
        reload=u'source ~/.zshrc',
        content=u'eval $(thefuck --alias)',
        can_configure_automatically=True,
    )

    how_to_configure_alias(configuration_details)

    assert u"Seems like \x1b[1mfuck\x1b[22m alias isn't configured!" in sys.stderr.getvalue()

# Generated at 2022-06-22 00:55:01.647260
# Unit test for function debug
def test_debug():
    """ Check that debug and debug_time works well.
    """
    import mock
    import datetime
    from ..main import debug

    with mock.patch('sys.stderr.write') as m:
        debug('message')
        debug('another message')

        assert m.call_count == 2
        assert m.call_args_list[0][0][0] == '\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n'
        assert m.call_args_list[1][0][0] == '\x1b[34m\x1b[1mDEBUG:\x1b[0m another message\n'

    with mock.patch('thefuck.main.debug') as m:
        with debug_time('message'):
            pass
        m.assert_

# Generated at 2022-06-22 00:55:06.636634
# Unit test for function warn
def test_warn():
    try:
        import StringIO
        result = StringIO.StringIO()
        sys.stderr = result
        warn("message")
        assert result.getvalue() == "[WARN] message\n"
        result.close()
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:55:19.172798
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(
        configuration_details='bashrc') == "fuck alias configured successfully!\n"
    "For applying changes run bashrc or restart your shell."
    assert configured_successfully(
        configuration_details='bash') == "fuck alias configured successfully!\n"
    "For applying changes run bash or restart your shell."
    assert configured_successfully(
        configuration_details='zsh') == "fuck alias configured successfully!\n"
    "For applying changes run zsh or restart your shell."
    assert configured_successfully(
        configuration_details='zshrc') == "fuck alias configured successfully!\n"
    "For applying changes run zshrc or restart your shell."
    assert configured_successfully(
        configuration_details='python') == "fuck alias configured successfully!\n"
    "For applying changes run python or restart your shell."
   

# Generated at 2022-06-22 00:55:21.883442
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.git_add_file import match, get_new_command
    if rule_failed(match, get_new_command):
        pass

# Generated at 2022-06-22 00:55:29.250607
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == u'\x1b[41m\x1b[37m\x1b[1m'
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == u''

# Generated at 2022-06-22 00:55:31.956542
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test_exception')
    except Exception as e:
        exception('test_exception', sys.exc_info())

# Generated at 2022-06-22 00:55:43.109121
# Unit test for function warn
def test_warn():
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def redirect_output():
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        new_out = StringIO()
        sys.stdout = new_out
        sys.stderr = new_out
        try:
            yield new_out
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    title = u'unicode test'
    with redirect_output() as out:
        warn(title)
    assert title + u'\n' == out.getvalue()

    # Now test with non-UTF8 locale
    import locale
    current_locale = locale.getlocale()

# Generated at 2022-06-22 00:55:53.582872
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell, Command
    from .shells.bash import Bash, BashAlias, BashHistory, BashSorry
    from .shells.zsh import Zsh, ZshHistory, ZshSorry
    from thefuck.rules import Rule

    class TestRule(Rule):
        name = 'test_name'

        def get_new_command(self, command):
            return 'echo 1'

        def side_effect(self, command):
            return 'echo 2'

    class TestBash(Bash):
        name = 'test_bash'

        @property
        def sorry_rule(self):
            return TestBashSorry()

        @property
        def _alias(self):
            return TestBashAlias()

        @property
        def _history(self):
            return TestBashHistory()


# Generated at 2022-06-22 00:55:58.554547
# Unit test for function debug_time
def test_debug_time():
    from time import time, sleep
    for _ in range(10):
        with debug_time('sleep'):
            sleep(1)

# Generated at 2022-06-22 00:56:07.491735
# Unit test for function debug_time
def test_debug_time():
    import time
    from . import proc
    from .proc import ExecutedCommand
    from .debug import debug_time
    
    ret_code, stdout, stderr = proc.call(ExecutedCommand('sleep 1', ''))
    start = datetime.now()
    with debug_time('sleep'):
        ret_code, stdout, stderr = proc.call(ExecutedCommand('sleep 1', ''))
    end = datetime.now()
    diff = (end - start).total_seconds()
    assert diff > 1.0

# Generated at 2022-06-22 00:56:10.504248
# Unit test for function color
def test_color():
    assert color(u'bold') == colorama.Style.BRIGHT
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT

# Generated at 2022-06-22 00:56:11.759488
# Unit test for function exception
def test_exception():
    exception('title', (Exception, Exception('error'), None))



# Generated at 2022-06-22 00:56:19.273985
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from .mswindows import testcase

    class Case(testcase.BaseCase):

        def test_works_as_context_manager(self):
            start = datetime.now()
            with debug_time('foo'):
                delta = datetime.now() - start
            self.assertTrue(delta > timedelta(milliseconds=100))

    Case.run()

# Generated at 2022-06-22 00:56:28.586414
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class TestClass(object):
        def __init__(self):
            self.reload = 'reload'
            self.can_configure_automatically = False
            self.path = 'path'
            self.content = 'content'
        def __iter__(self):
            return iter(self._asdict().items())
        def _asdict(self):
            return {'reload': self.reload,
                    'can_configure_automatically': self.can_configure_automatically,
                    'path': self.path,
                    'content': self.content}
    how_to_configure_alias(TestClass())
    how_to_configure_alias(False)

# Generated at 2022-06-22 00:56:36.470632
# Unit test for function already_configured
def test_already_configured():
    configuration_details = 'reload'
    msg = already_configured(configuration_details)
    assert msg == u"Seems like {bold}fuck{reset} alias already configured!\n" \
           u"For applying changes run {bold}reload{reset} or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload=configuration_details)


# Generated at 2022-06-22 00:56:43.914763
# Unit test for function configured_successfully
def test_configured_successfully():
    try:
        import StringIO
    except ImportError:
        import io as StringIO
    import tempfile
    import os.path
    import subprocess
    from .configuration_details import ConfigurationDetails

    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'sys_path.py')

    with open(tmp_file, 'w') as sys_path:
        sys_path.write('test = "test"')

    os.environ['PYTHONPATH'] = tmp_dir

    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        path=tmp_file,
        content='test = "test"',
        reload='. ~/.bashrc')

    out = StringIO.StringIO()

# Generated at 2022-06-22 00:56:46.751375
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'red') == '\x1b[31mred'
    assert color(colorama.Fore.GREEN + 'green') == ''

# Generated at 2022-06-22 00:56:50.858282
# Unit test for function color
def test_color():
    colorama.init()  # XXX: For Windows
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''
    delattr(settings, 'no_colors')

# Generated at 2022-06-22 00:57:00.182813
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'hello world')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hello world\n'
    sys.stderr.truncate(0)
    settings.debug = False
    debug(u'hello world')
    assert sys.stderr.getvalue() == ''


# Generated at 2022-06-22 00:57:01.874774
# Unit test for function version
def test_version():
    version('3.3', '3.4', 'bash 4.4')

# Generated at 2022-06-22 00:57:11.413079
# Unit test for function already_configured

# Generated at 2022-06-22 00:57:19.009435
# Unit test for function exception
def test_exception():
    exception('Test', 1)
    assert sys.stderr.getvalue() == (
        u'{warn}[WARN] Test:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            trace=''.join(format_exception(1))))

# Generated at 2022-06-22 00:57:21.536605
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-22 00:57:28.849344
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(['']) == \
           print(u"Seems like {bold}fuck{reset} alias already configured!\n"
                 u"For applying changes run {bold}{reload}{reset}"
                 u" or restart your shell.".format(
                     bold=color(colorama.Style.BRIGHT),
                     reset=color(colorama.Style.RESET_ALL),
                     reload=['']))


# Generated at 2022-06-22 00:57:29.645641
# Unit test for function warn
def test_warn():
    warn(1)


# Generated at 2022-06-22 00:57:35.202191
# Unit test for function color
def test_color():
    class FakeSettings(object):
        no_colors = True

    settings.update(FakeSettings())
    colorama.init(strip=False)
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Style.DIM) == ''
    settings.update(const.DEFAULT_SETTINGS)



# Generated at 2022-06-22 00:57:36.187476
# Unit test for function confirm_text
def test_confirm_text():
    assert u"\x1b[1K\r" == confirm_text(None)

# Generated at 2022-06-22 00:57:37.262009
# Unit test for function already_configured
def test_already_configured():
    already = already_configured(configuration_details=None)
    assert already == None

# Generated at 2022-06-22 00:57:41.986634
# Unit test for function already_configured
def test_already_configured():
    already_configured("source ~/.bashrc")


# Generated at 2022-06-22 00:57:53.519910
# Unit test for function configured_successfully
def test_configured_successfully():
    from io import StringIO
    from sys import platform
    from .conf import ConfigurationDetails
    output = StringIO()
    print = output.write
    configured_successfully(
        ConfigurationDetails(**{
            'path': '~/test',
            'reload': 'ls',
            'extends_bashrc': platform.startswith('linux')}))
    print('\n')
    configured_successfully(
        ConfigurationDetails(**{
            'path': '~/test',
            'reload': 'ls',
            'extends_bashrc': True}))
    print('\n')
    configured_successfully(
        ConfigurationDetails(**{
            'path': '~/test',
            'reload': 'ls',
            'extends_bashrc': False}))
    output = output.getvalue()

# Generated at 2022-06-22 00:57:56.958321
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('exception')
    except RuntimeError:
        exception('title', sys.exc_info())


if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-22 00:58:01.252272
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Back.RED) == ''
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Back.RED) == ''


# Generated at 2022-06-22 00:58:13.277259
# Unit test for function version
def test_version():
    from mock import patch
    from sys import version as python_version
    from thefuck.shells import Shell
    from thefuck.version import __version__
    stderr = u''

    def write(s):
        global stderr
        stderr += s

    with patch('thefuck.utils.get_version', return_value='3.7'):
        with patch('thefuck.utils.get_shell') as get_shell:
            get_shell.return_value = Shell('Shell', 'sh')
            with patch('thefuck.utils.sys.stderr.write', write):
                version(__version__, python_version, 'Shell')
                assert stderr == u'The Fuck {} using Python {} and Shell\n'.format(__version__, python_version)



# Generated at 2022-06-22 00:58:25.836777
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import os
    from tempfile import mkdtemp
    from contextlib import contextmanager

    from thefuck.types import Command

    @contextmanager
    def mock_io():
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        fake_out = io.BytesIO()
        fake_err = io.BytesIO()
        sys.stdout = fake_out
        sys.stderr = fake_err
        yield fake_err
        sys.stdout = old_stdout
        sys.stderr = old_stderr

    with mock_io() as fake_err:
        confirm_text(Command('ls', '', '', False))

# Generated at 2022-06-22 00:58:28.593147
# Unit test for function debug_time
def test_debug_time():
    # GIVEN
    import thefuck.main
    thefuck.main.settings.debug = True
    with thefuck.main.debug_time('test'):
        # THEN
        assert True



# Generated at 2022-06-22 00:58:31.160593
# Unit test for function warn
def test_warn():
    warn('a')
    sys.stderr = None
    warn('a')


# Generated at 2022-06-22 00:58:36.449240
# Unit test for function exception
def test_exception():
    try:
        raise OSError('Bad')
    except OSError as e:
        exception('Test', sys.exc_info())
        assert u'[WARN] Test:Bad\n' in e.message
        assert u'----------------------------' in e.message


# Generated at 2022-06-22 00:58:37.588837
# Unit test for function confirm_text
def test_confirm_text():
    # Make sure the confirm_text is working correctly.
    show_corrected_command('ls -la')
    # Make sure the confirm_text is working correctly.
    confirm_text('ls -la')

# Generated at 2022-06-22 00:58:45.680733
# Unit test for function debug
def test_debug():
    from mock import patch
    # Set all options to False
    settings.no_colors = False
    settings.debug = False
    # Call debug with message
    debug('alpha')
    # Set all options to True
    settings.no_colors = True
    settings.debug = True
    # Call debug with message
    debug('bravo')
    # Call debug without message
    debug(None)


# Generated at 2022-06-22 00:58:50.392593
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('Rule', (), {'name': 'test'})()
    try:
        raise Exception('error')
    except Exception:
        rule_failed(rule, sys.exc_info())

if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-22 00:59:00.946755
# Unit test for function configured_successfully
def test_configured_successfully():
    output = u""
    configuration_details = "test"
    def fake_print(*args, **kwargs):
        output = u' '.join(map(unicode, args))
    try:
        configured_successfully.__globals__['print'] = fake_print
        configured_successfully(configuration_details)
        assert output == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload = configuration_details)
    except:
        pass


# Generated at 2022-06-22 00:59:04.147776
# Unit test for function failed
def test_failed():
    failed('test')
    assert sys.stderr.getvalue() == '\x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-22 00:59:11.435004
# Unit test for function already_configured
def test_already_configured():
    assert already_configured({}) == ("Seems like {bold}fuck{reset} alias already "
                                      "configured!\n"
                                      "For applying changes run {bold}{reload}{reset}"
                                      " or restart your shell.".format(
                                          bold=color(colorama.Style.BRIGHT),
                                          reset=color(colorama.Style.RESET_ALL),
                                          reload='{reload}'))


# Generated at 2022-06-22 00:59:14.972666
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('text') == 'text'

    settings.no_colors = True
    colorama.init()
    assert color('') == ''
    assert color('text') == ''

# Generated at 2022-06-22 00:59:22.730337
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command, CorrectedCommand
    from thefuck.utils import wrap_stdout
    command = Command('git status', '')
    corrected_command = CorrectedCommand(command, 'git log')
    with wrap_stdout() as stdout:
        show_corrected_command(corrected_command)
        assert stdout.getvalue() == u'{prefix}git log\n'.format(
            prefix=const.USER_COMMAND_MARK)

# Generated at 2022-06-22 00:59:28.666851
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from .utils import wrap_streams
    stream = StringIO()

    with wrap_streams(stream):
        warn('foo')
        assert stream.read() == (u'\x1b[41m\x1b[37m\x1b[1m[WARN] foo\x1b[0m\n')



# Generated at 2022-06-22 00:59:30.271541
# Unit test for function debug
def test_debug():
    assert debug('') is None


# Unit tests for function failed

# Generated at 2022-06-22 00:59:31.179090
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:59:39.704897
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as mock_stderr:
        debug('msg')
        mock_stderr.write.assert_called_once_with(
            '\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n')


# Generated at 2022-06-22 00:59:48.109447
# Unit test for function configured_successfully
def test_configured_successfully():
    import io
    import sys
    sys.stderr = io.StringIO()
    configuration_details = 1
    configured_successfully(configuration_details)
    assert sys.stderr.getvalue().strip() == u'\x1b[1mfuck\x1b[21m alias configured successfully!\nFor applying changes run \x1b[1m1\x1b[21m or restart your shell.'

# Generated at 2022-06-22 00:59:52.319500
# Unit test for function failed
def test_failed():
    from .utils import capture_stderr
    from . import shell

    with capture_stderr():
        failed('some message')
    assert shell.stderr.getvalue() == '\x1b[31msome message\x1b[0m\n'



# Generated at 2022-06-22 00:59:53.978773
# Unit test for function already_configured
def test_already_configured():
    already_configured("source ~/.bashrc")
    already_configured("source ~/.zshrc")

# Generated at 2022-06-22 01:00:03.263946
# Unit test for function debug
def test_debug():
    from . import settings
    from .utils import memoize

    @memoize
    def out():
        return sys.stderr.write

    @contextmanager
    def mock():
        try:
            settings.debug = False
            sys.stderr.write = lambda x: None
            yield
        finally:
            sys.stderr.write = out()

    def should_not_echo_anything():
        with mock():
            debug('test')

    def should_echo_debug():
        with mock():
            settings.debug = True
            debug('test')

# Generated at 2022-06-22 01:00:09.544259
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    _stderr = sys.stderr
    sys.stderr = StringIO()
    failed('msg')
    ret = sys.stderr.getvalue()
    sys.stderr = _stderr
    return ret == u'\x1b[31mmsg\x1b[0m\n'



# Generated at 2022-06-22 01:00:18.677282
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    old_stdout = sys.stdout
    captured_stdout = StringIO()
    sys.stdout = captured_stdout
    already_configured(const.ConfigurationDetails('reload', 'path', 'content', True))
    assert captured_stdout.getvalue() == u"Seems like \x1b[1mfuck\x1b[22m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[22m or restart your shell.\n"
    sys.stdout = old_stdout


# Generated at 2022-06-22 01:00:20.263251
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None) == 'Seems like fuck alias already configured!'

# Generated at 2022-06-22 01:00:23.806932
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(const.ConfigurationDetails(u'echo', u'echo',
                                                        u'/home/test', u'echo',
                                                        True, u'echo'))



# Generated at 2022-06-22 01:00:30.795131
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('thefuck.log.sys.stderr') as stderr, \
            patch('thefuck.log.settings') as settings:
        settings.debug = True
        debug('Test')
        assert stderr.write.called
        msg = sys.stderr.write.call_args[0][0]
        assert u'DEBUG:' in msg
        assert u'Test' in msg



# Generated at 2022-06-22 01:00:41.615213
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,), {
        'script': u'sudo ls'
    })()
    assert confirm_text(corrected_command) == \
        u'fuck \033[1K\rsudo ls [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'

# Generated at 2022-06-22 01:00:43.638505
# Unit test for function exception
def test_exception():
    try:
        1/0
    except:
        exception('exception', sys.exc_info())

# Generated at 2022-06-22 01:00:45.247462
# Unit test for function debug
def test_debug():
    debug(u'This is example of debug message.')


# Generated at 2022-06-22 01:00:45.886222
# Unit test for function failed
def test_failed():
    failed('Test!!')

# Generated at 2022-06-22 01:00:58.012884
# Unit test for function exception
def test_exception():
    import os
    import sys
    import time
    import subprocess
    from tempfile import NamedTemporaryFile

    thefuck_script = '\n'.join([
        'import sys',
        'from thefuck.utils import exception, warn',
        'warn("warn message")',
        'try:',
        '    1 / 0',
        'except ZeroDivisionError:',
        '    exception("exception message", sys.exc_info())'])

    with NamedTemporaryFile(suffix='.py') as f:
        f.write(thefuck_script)
        f.flush()
        process = subprocess.Popen(['python', f.name],
                                   stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE)
        time.sleep(0.1)
       

# Generated at 2022-06-22 01:01:04.470330
# Unit test for function exception
def test_exception():
    import StringIO
    from .shells import Shell

    orig_stdout = sys.stdout
    try:
        out = sys.stdout = StringIO.StringIO()
        exception(u'Rule foo', ('exc', 'exc_obj', 'tb'))
        assert u'[WARN] Rule foo' in out.getvalue()
        assert u'exc\nexc_obj\ntb' in out.getvalue()
        assert u'----------------------------' in out.getvalue()
    finally:
        sys.stdout = orig_stdout

