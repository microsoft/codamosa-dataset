

# Generated at 2022-06-22 00:51:05.689731
# Unit test for function color
def test_color():
    assert(color('\x1b[30;42m') == '\x1b[30;42m')
    settings.no_colors = True
    assert(color('\x1b[30;42m') == '')



# Generated at 2022-06-22 00:51:08.382383
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('') == ''

# Generated at 2022-06-22 00:51:09.170354
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(None) == None

# Generated at 2022-06-22 00:51:12.732647
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(script='git add -p') == 'git add -p (+side effect) [enter/↑/↓/ctrl+c]'
    assert confirm_text(script='git add -p', side_effect=False) == 'git add -p [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-22 00:51:15.928452
# Unit test for function failed
def test_failed():
    test_msg = "[testing] Testing function failed"

    failed(test_msg)
    # TODO(xion): Test assertEqual of stderr


# Generated at 2022-06-22 00:51:16.961476
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('')

# Generated at 2022-06-22 00:51:18.122964
# Unit test for function failed
def test_failed():
    assert 'NVBN' in failed('NVBN')

# Generated at 2022-06-22 00:51:22.458424
# Unit test for function exception
def test_exception():
    """Test logs exception."""
    try:
        1 / 0
    except ZeroDivisionError:
        exception('test', sys.exc_info())


if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-22 00:51:24.064026
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details)
    return 1



# Generated at 2022-06-22 00:51:25.943835
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test_debug"):
        pass



# Generated at 2022-06-22 00:51:34.665522
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = _ConfigurationDetails(
        content="alias fuck='eval $(thefuck $(fc -ln -1))'",
        path="~/.bash_profile",
        reload="source ~/.bash_profile",
        can_configure_automatically=True)

    how_to_configure_alias(configuration_details)



# Generated at 2022-06-22 00:51:35.095390
# Unit test for function debug_time
def test_debug_time():
    "test_debug_time"



# Generated at 2022-06-22 00:51:37.773751
# Unit test for function debug_time
def test_debug_time():  # pylint:disable=R0201
    from time import sleep
    with debug_time('test'):
        sleep(1)

# Generated at 2022-06-22 00:51:41.364714
# Unit test for function color
def test_color():
    assert color('asd') == 'asd'
    colorama.init()
    assert color('asd') == ''
    settings.no_colors = False
    assert color('asd') == 'asd'

# Generated at 2022-06-22 00:51:45.185933
# Unit test for function configured_successfully
def test_configured_successfully():
    try:
        del sys.modules['thefuck.shells']
    except KeyError:
        pass

    configuration_details = settings.get_configuration_details()
    assert configuration_details is not None
    configured_successfully(configuration_details)

# Generated at 2022-06-22 00:51:47.738828
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:51:54.133082
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    old_stdout = sys.stderr
    sys.stderr = out = StringIO()
    try:
        failed('test')
        assert out.getvalue() == '\x1b[31mtest\x1b[0m\n'
    finally:
        sys.stderr = old_stdout



# Generated at 2022-06-22 00:52:05.561883
# Unit test for function failed
def test_failed():
    from io import StringIO
    from thefuck.utils import wrap_streams
    from thefuck.types import Command

    with wrap_streams([StringIO()]) as (stdout, stderr):
        failed(u'Привет')
        assert stderr.getvalue() == (u'\x1b[31mПривет\x1b[0m\n')

    with wrap_streams([StringIO()]) as (stdout, stderr):
        msg = u'😈'
        failed(msg)
        assert stderr.getvalue() == u'\x1b[31m{}\x1b[0m\n'.format(msg)


# Generated at 2022-06-22 00:52:06.554309
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:52:13.280048
# Unit test for function rule_failed
def test_rule_failed():
    def wtf(correct_cmd, side_effect):
        print(u"WTF?!\nCommand '{}' on '{}' failed, should be:\n{}".format(
            correct_cmd.script, correct_cmd.side_effect, side_effect))
    rule_failed(None, (None, None, None))



# Generated at 2022-06-22 00:52:20.114393
# Unit test for function color
def test_color():
    settings.no_colors = True
    assert color('red') == ''



# Generated at 2022-06-22 00:52:27.772512
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command
    for shell in ['zsh', 'bash', 'fish', 'cmd', 'ps']:
        with settings(shell=shell):
            show_corrected_command(Command('ls', 'ls -a'))
            show_corrected_command(Command('apt-get install vim',
                                           'sudo apt-get install vim',
                                           side_effect=True))

# Generated at 2022-06-22 00:52:29.802290
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("configuration successfully")
    print("test_configured_successfully() test passed")
    

# Generated at 2022-06-22 00:52:32.867031
# Unit test for function failed
def test_failed():
    from mock import patch

    with patch('sys.stderr') as stderr:
        failed(u'Конец-с')
    assert stderr.write.call_args[0][0].startswith(u'\033[31m')
    assert stderr.write.call_args[0][0].endswith(u'\033[0m\n')
    assert stderr.write.call_args[0][0].find(u'Конец-с') > 0



# Generated at 2022-06-22 00:52:36.806945
# Unit test for function version
def test_version():
    str_io = StringIO()
    sys.stderr = str_io
    version(u'3.11', u'2.7', u'bash')
    str_io.getvalue() == u'The Fuck 3.11 using Python 2.7 and bash\n'

# Generated at 2022-06-22 00:52:40.313389
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command({'script': 'git fuck', 'side_effect': True})
    show_corrected_command({'script': 'git fuck', 'side_effect': False})

# Generated at 2022-06-22 00:52:47.531314
# Unit test for function version
def test_version():
    from StringIO import StringIO
    from thefuck import __version__
    import platform
    from . import shell
    with StringIO() as buf:
        sys.stderr = buf
        version(__version__, platform.python_version(),
                shell.get_shell_info())
        assert buf.getvalue() == \
            u'The Fuck {} using Python {} and {}\n'.format(__version__,
                                                           platform.python_version(),
                                                           shell.get_shell_info())

# Generated at 2022-06-22 00:52:49.114004
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(show_corrected_command('ls -la'))


# Generated at 2022-06-22 00:52:50.133639
# Unit test for function warn
def test_warn():
    warn('test warn')


# Generated at 2022-06-22 00:52:53.115208
# Unit test for function failed
def test_failed():
    failed('test')
    assert sys.stderr.getvalue() == color(colorama.Fore.RED) + 'test' + color(colorama.Style.RESET_ALL) + '\n'



# Generated at 2022-06-22 00:53:01.867108
# Unit test for function debug_time
def test_debug_time():
    import mock
    debug = mock.Mock()
    with debug_time("foo"):
        pass
    debug.assert_called_once_with("foo took: 0:00:00")

# Generated at 2022-06-22 00:53:09.122330
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(CorrectedCommand('echo "hello"', False))
    confirm_text(CorrectedCommand('ls ~', True))
    confirm_text(CorrectedCommand('python', False))
    confirm_text(CorrectedCommand('git commit', True))
    confirm_text(CorrectedCommand('git commit', False))
    confirm_text(CorrectedCommand('git commit', True))
    confirm_text(CorrectedCommand('git commit', False))

# Generated at 2022-06-22 00:53:17.781859
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = lambda x: None
    test_cases = [
            (1, ['', '/bin/bash', '-c', 'git pull origin'],
                '\033[1K\r\x1b[1m$ git pull origin\x1b[22m'),
            (2, ['', '/bin/bash', '-c', 'git push origin master'],
                '\033[1K\r\x1b[1m$ git push origin master\x1b[22m')]
    settings.no_colors = False
    for index, args, expected in test_cases:
        corrected_command = Command(args)
        show_corrected_command(corrected_command)
        assert expected == sys.stderr.write.call_args[0][0]

# Generated at 2022-06-22 00:53:23.069476
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('Some error')
    except:
        rule_failed(const.Rule(script="echo test", name='TestRule',
                               side_effect=False,
                               priority=10,
                               is_multy_entry=False,
                               is_shell=False), sys.exc_info())

# Generated at 2022-06-22 00:53:25.409794
# Unit test for function exception
def test_exception():
    try:
        raise Exception('samples')
    except:
        exception(u'Rule with simple error', sys.exc_info())

# Generated at 2022-06-22 00:53:28.262015
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('pwd', 'cd'))
    show_corrected_command(Command('ls', 'll', side_effect=True))

# Generated at 2022-06-22 00:53:30.676574
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exception('Something', sys.exc_info())



# Generated at 2022-06-22 00:53:32.225887
# Unit test for function debug
def test_debug():
    # Tests the debug
    debug("test")


# Generated at 2022-06-22 00:53:38.160218
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('Debug message')
    stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debug message\n')

# Generated at 2022-06-22 00:53:41.325306
# Unit test for function color
def test_color():
    assert color('something') == ''
    assert color('something') != 'something'
    settings.no_colors = False
    assert color('something') != ''
    assert color('something') == 'something'



# Generated at 2022-06-22 00:53:52.200567
# Unit test for function color
def test_color():
    assert 'before' + color('colored') + 'after' == (
        'beforecoloredafter' if settings.no_colors
        else 'before' + colorama.Fore.RED + 'colored' + colorama.Style.RESET_ALL + 'after')

# Generated at 2022-06-22 00:53:59.941716
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .shells import Configuration
    from .shells import XonshConfiguration
    from colorama import Fore

    configuration_details = Configuration(
        shell_name='test_shell',
        shell_conf='~/.config/testrc',
        exec_alias='test_exec_alias',
        reload='test_reload',
        no_colors=True)
    xonsh_configuration_details = XonshConfiguration(
        shell_name='test_xonsh_shell',
        shell_conf='~/.xonshrc',
        exec_alias='test_exec_alias',
        reload='test_xonsh_reload',
        no_colors=False)
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:54:08.451161
# Unit test for function rule_failed
def test_rule_failed():
    rule = "test"
    exc_info = "test"
    test_rule_failed = print(u'{warn}[WARN] {title}:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title=rule,
            trace=''.join(format_exception(*exc_info))))
    assert rule_failed(rule, exc_info) == test_rule_failed


# Generated at 2022-06-22 00:54:10.836547
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('cd /root')
    confirm_text('sudo start nginx')
    confirm_text('echo $RANDOM')


# Generated at 2022-06-22 00:54:20.498653
# Unit test for function exception
def test_exception():
    import pytest
    try:
        {}['a']
    except Exception as e:
        exception(u'Test exception', sys.exc_info())
        lines = sys.stderr.getvalue().split('\n')
        assert lines[0] == u'\x1b[41m\x1b[37m\x1b[1m[WARN] Test exception:\x1b[0m'
        assert lines[1] == u'Traceback (most recent call last):'
        assert lines[-3] == u"KeyError: 'a'"
        assert lines[-2] == u'----------------------------'



# Generated at 2022-06-22 00:54:23.001289
# Unit test for function debug_time
def test_debug_time():
    import datetime
    from time import sleep

    with debug_time('aaa'):
        sleep(0.1)

    assert debug.called

# Generated at 2022-06-22 00:54:24.203145
# Unit test for function version
def test_version():
    assert version('1', '2', '3') == None

# Generated at 2022-06-22 00:54:34.432400
# Unit test for function debug_time
def test_debug_time():
    from unittest.mock import Mock
    with debug_time('test'):
        pass

    from datetime import timedelta
    from time import sleep
    delta = timedelta(seconds=0)
    with debug_time('test'):
        sleep(1)
        delta = timedelta(seconds=1)

    settings.debug = True
    mock_stderr = Mock()
    with debug_time('test'):
        pass
    mock_stderr.write.assert_not_called()

    with debug_time('test'):
        pass
    mock_stderr.write.assert_called_with(
        u'test took: {}\n'.format(delta))

# Generated at 2022-06-22 00:54:46.020562
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class CD():
        _fields = ['can_configure_automatically', 'content', 'path', 'reload']
        def __init__(self, can_configure_automatically, content, path, reload):
            self.can_configure_automatically = can_configure_automatically
            self.content = content
            self.path = path
            self.reload = reload
        def _asdict(self):
            return {'can_configure_automatically': self.can_configure_automatically,
                    'content': self.content,
                    'path': self.path,
                    'reload': self.reload}
    how_to_configure_alias(CD(True, 'foo', 'bar', 'baz'))


# Generated at 2022-06-22 00:54:46.488967
# Unit test for function warn
def test_warn():
    warn('some warning')

# Generated at 2022-06-22 00:54:57.092129
# Unit test for function debug
def test_debug():
    from io import StringIO
    buf = StringIO()
    buf.encoding = 'utf-8'
    sys.stderr = buf
    debug(u'fuck')
    assert buf.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[m fuck\n'

# Generated at 2022-06-22 00:55:00.171071
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command("echo hello world"))
    confirm_text(corrected_command("echo hello world", side_effect=True))


# Generated at 2022-06-22 00:55:11.095155
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    configuration_details = namedtuple(
        'configuration_details', [
            'path', 'content', 'reload', 'can_configure_automatically'])
    configuration_details.path = '~/.bashrc'
    configuration_details.content = 'set pythonpath=~/.config/thefuck'
    configuration_details.reload = 'source ~/.bashrc'
    configuration_details.can_configure_automatically = False
    how_to_configure_alias(configuration_details)
    configuration_details.can_configure_automatically = True
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:55:22.831798
# Unit test for function exception
def test_exception():
    from unittest.mock import Mock
    try:
        raise Exception()
    except Exception:
        exc_info = sys.exc_info()
    stdout = Mock()
    stderr = Mock()
    logger = Logger(stdout=stdout, stderr=stderr)
    logger.exception('Fake exception')

# Generated at 2022-06-22 00:55:25.678190
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None
    assert how_to_configure_alias("") is None


# Generated at 2022-06-22 00:55:34.668657
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from tempfile import mkstemp
    import os
    os.name = 'posix'
    tmp_file, tmp_filename = mkstemp()
    os.close(tmp_file)
    try:
        show_corrected_command(
            CorrectedCommand('pwd', 'cd /tmp', True))
        show_corrected_command(
            CorrectedCommand('pwd', 'cd {}'.format(tmp_filename), False))
    finally:
        os.unlink(tmp_filename)

# Generated at 2022-06-22 00:55:41.533869
# Unit test for function configured_successfully
def test_configured_successfully():
    from io import StringIO
    from .shells import Bash
    output = StringIO()
    configured_successfully(Bash().get_configuration_details(alias='fuck'))
    assert output.getvalue() == "fuck alias configured successfully!\n" \
                                "For applying changes run \n" \
                                "or restart your shell."


# Generated at 2022-06-22 00:55:49.975524
# Unit test for function debug
def test_debug():

    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def stdio(stdin=None, stdout=None, stderr=None):
        old = sys.stdin, sys.stdout, sys.stderr
        if stdin:
            sys.stdin = stdin
        if stdout:
            sys.stdout = stdout
        if stderr:
            sys.stderr = stderr
        try:
            yield
        finally:
            sys.stdin, sys.stdout, sys.stderr = old

    with stdio(stdout=StringIO()) as (stdin, stdout, stderr):
        debug('foo', reset=True)

    assert u'DEBUG: foo'.encode('utf-8') in stdout.getvalue()

# Generated at 2022-06-22 00:55:58.633964
# Unit test for function debug
def test_debug():
    class Log(object):
        def __init__(self):
            self.values = []

        def write(self, msg):
            self.values.append(msg)

    orig_debug = settings.debug
    settings.debug = True
    log = Log()
    sys.stderr = log
    try:
        debug(u'fxxk')
        assert log.values == [
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m fxxk\n']
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = orig_debug

# Generated at 2022-06-22 00:56:10.293689
# Unit test for function confirm_text
def test_confirm_text():
    _, _, corrected_command = _parse_confirm_text(u'git push origin ma[y]ster')
    assert (corrected_command == u'git push origin master')

    _, _, corrected_command = _parse_confirm_text(u'git push origi[n] master')
    assert (corrected_command == u'git push origin master')

    _, _, corrected_command = _parse_confirm_text(u'git push or[i]gin master')
    assert (corrected_command == u'git push origin master')

    _, _, corrected_command = _parse_confirm_text(u'git push origin [m]aster')
    assert (corrected_command == u'git push origin master')



# Generated at 2022-06-22 00:56:18.580388
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("Content")
    how_to_configure_alias("Content", "Reload")



# Generated at 2022-06-22 00:56:29.010438
# Unit test for function debug
def test_debug():
    class FakeStream(object):
        def __init__(self):
            self.content = []

        def write(self, msg):
            self.content.append(msg)

    fake_stream = FakeStream()

    original_debug = settings.debug

    settings.debug = True
    sys.stderr = fake_stream
    debug(u'foo')
    assert len(fake_stream.content) == 1
    assert fake_stream.content[0] == \
        u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
            msg=u'foo',
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT))

    sys.stderr = fake_stream

# Generated at 2022-06-22 00:56:35.313805
# Unit test for function already_configured

# Generated at 2022-06-22 00:56:37.956444
# Unit test for function exception
def test_exception():
    try:
        "BAD_STRING".index("_")
    except ValueError:
        ex_type, ex_value, ex_traceback = sys.exc_info()
        exception("Test exception", (ex_type, ex_value, ex_traceback))



# Generated at 2022-06-22 00:56:41.096850
# Unit test for function version
def test_version():
    from thefuck.utils import get_shell_info
    assert sys.stderr.write == version(
        '3.27', '2.7.9', get_shell_info())

# Generated at 2022-06-22 00:56:46.315183
# Unit test for function failed
def test_failed():
    from StringIO import StringIO

    buf = StringIO()
    sys.stderr = buf
    failed(u"message")
    sys.stderr = sys.__stderr__

    assert(buf.getvalue() == u"\x1b[31mmessage\x1b[0m\n")


# Generated at 2022-06-22 00:56:48.275340
# Unit test for function color
def test_color():
    assert color('a') == 'a'
    settings.no_colors = True
    assert color('a') == ''

# Generated at 2022-06-22 00:56:53.325399
# Unit test for function warn
def test_warn():
    from tests.utils import capture_stderr
    with capture_stderr() as stderr:
        warn(u'The title')
    assert stderr[0].startswith(u'\x1b[41m[WARN] The title\x1b[0m')



# Generated at 2022-06-22 00:56:55.737876
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .app import Command
    command = Command('ps aux', 'ps aux|grep python')
    show_corrected_command(command)

# Generated at 2022-06-22 00:57:00.731595
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    from .rules.echo import side_effect as se
    match = match('e')
    get_new_command = get_new_command('e')
    se = se('e', 'echo')
    rule_failed(match, get_new_command, se)



# Generated at 2022-06-22 00:57:18.458661
# Unit test for function version
def test_version():
    import sh
    import click
    import six
    import os
    from thefuck.utils import get_closest, get_closest_mapping

    if six.PY2:
        from mock import patch
    else:
        from unittest.mock import patch

    def get_version(cmd, base_cmd=None, history=None):
        return '3.4.0'

    def get_shell_info():
        return 'bash'

    example_cmd = lambda *examples: u'cd /etc && ls'
    example_script = 'cd /etc && ls'
    current_command = lambda: u'cd /etc && ls'

    examples = [example_cmd, example_cmd, example_cmd, example_cmd]


# Generated at 2022-06-22 00:57:25.571141
# Unit test for function version
def test_version():
    """
    If settings.no_colors is True,
    we will use only function name and params
    if False, we should add extra text like \n, \t, \b etc.
    """
    if settings.no_colors is True:
        assert version('', '', '') == ''
    else:
        assert version('', '', '') == 'The Fuck  using Python  and \n'



# Generated at 2022-06-22 00:57:27.073195
# Unit test for function debug
def test_debug():
    try:
        raise Exception("foo")
    except:
        debug("bar")

# Generated at 2022-06-22 00:57:32.785680
# Unit test for function failed
def test_failed():
    import sys
    import StringIO

    output = StringIO.StringIO()
    sys.stderr = output
    failed("test")
    sys.stderr = sys.__stderr__
    assert output.getvalue().splitlines() == \
        ['\x1b[31mtest\x1b[0m\n']



# Generated at 2022-06-22 00:57:36.656683
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details) == \
        u"{bold}fuck{reset} alias configured successfully!\n" \
        u"For applying changes run {bold}{reload}{reset}" \
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload)

# Generated at 2022-06-22 00:57:39.306699
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(False)
    how_to_configure_alias(True)

# Generated at 2022-06-22 00:57:48.758963
# Unit test for function debug
def test_debug():
    output = []

    def write(txt):
        output.append(txt)

    old_debug = settings.debug
    old_write = sys.stderr.write
    sys.stderr.write = write
    settings.debug = True
    try:
        debug('spam')
        assert output == [u'\x1b[34m\x1b[1mDEBUG:\x1b[0m spam\n']
        output.pop()
        settings.debug = False
        debug('spam')
        assert output == []
    finally:
        sys.stderr.write = old_write
        settings.debug = old_debug

# Generated at 2022-06-22 00:57:58.192795
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)
    # same as
    started = datetime.now()
    time.sleep(1)
    msg = 'test'
    if settings.debug:
        sys.stderr.write(u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
            msg=u'{} took: {}'.format(msg, datetime.now() - started),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-22 00:58:00.688456
# Unit test for function configured_successfully

# Generated at 2022-06-22 00:58:01.813898
# Unit test for function failed
def test_failed():
    failed('test failed')


# Generated at 2022-06-22 00:58:16.232202
# Unit test for function version
def test_version():
    from StringIO import StringIO
    import platform

    captured_stdout = StringIO()
    sys.stdout = captured_stdout
    thefuck_version = '3.8'
    python_version = '3.5.2'
    shell_info = ''.join(platform.linux_distribution())

    version(thefuck_version, python_version, shell_info)

    sys.stdout = sys.__stdout__
    assert captured_stdout.getvalue() == 'The Fuck {} using Python {} and {}\n'.format(thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:58:20.298276
# Unit test for function version
def test_version():
    """
    >>> version('3.14', '3.4.3', 'ZSH')
    The Fuck 3.14 using Python 3.4.3 and ZSH
    """
    pass


# Generated at 2022-06-22 00:58:20.989139
# Unit test for function configured_successfully
def test_configured_successfully():
    return configured_successfully()

# Generated at 2022-06-22 00:58:21.662358
# Unit test for function configured_successfully
def test_configured_successfully():
    pass

# Generated at 2022-06-22 00:58:30.953366
# Unit test for function rule_failed
def test_rule_failed():
    # Write to stderr
    class FakeSTDErr(object):
        def write(self, s):
            print(s)
    sys.stderr = FakeSTDErr()

    # Create a test class
    class TestRule(object):
        name = 'test_rule_name'

    # Run function
    rule = TestRule()
    rule_failed(rule,("Unexpected error:", RuntimeError("brocken"), None))

    # Expected output
    # [WARN] Rule test_rule_name:
    # Traceback (most recent call last):
    #   File "thefuck/main.py", line 307, in rule_failed
    #     exception(u'Rule {}'.format(rule.name), exc_info)
    #   File "thefuck/main.py", line 276, in exception
    #    

# Generated at 2022-06-22 00:58:33.094902
# Unit test for function exception
def test_exception():
    try:
        1/0
    except Exception:
        exception('test title', sys.exc_info())

# Generated at 2022-06-22 00:58:37.363556
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully({
        'reload': 'reload',
        'path': 'path'
    }) == """\
The Fuck alias configured successfully!
For applying changes run reload or restart your shell."""



# Generated at 2022-06-22 00:58:39.424142
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-22 00:58:42.412613
# Unit test for function configured_successfully
def test_configured_successfully():
    import tempfile
    import os.path
    reload = 'this is reload'
    details = type('', (), {})()
    details.reload = reload
    with tempfile.NamedTemporaryFile() as tmp:
        configured_successfully(details)
        tmp.seek(0)
        result = tmp.read()
        assert reload in result

# Generated at 2022-06-22 00:58:44.218458
# Unit test for function configured_successfully
def test_configured_successfully():
    class FakeArgs(object):
        reload = 'reload'

    configured_successfully(FakeArgs)

# Generated at 2022-06-22 00:58:57.588498
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigurationDetails(
        alias='ls',
        reload='. ~/.bashrc',
        can_configure_automatically=True))


# Generated at 2022-06-22 00:59:01.006931
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'ls -l') == (
        u'\033[1K[?] ls -l [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-22 00:59:01.831208
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:59:07.512227
# Unit test for function failed
def test_failed():
    import io
    import sys
    orig_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        failed(u'oh noes!')
        assert sys.stdout.getvalue() == u'\033[31moh noes!\033[0m\n'
    finally:
        sys.stdout = orig_stdout

# Generated at 2022-06-22 00:59:11.262012
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import which_os
    how_to_configure_alias(configuration_details=None)
    how_to_configure_alias(configuration_details=which_os())

# Generated at 2022-06-22 00:59:17.416318
# Unit test for function version
def test_version():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    version('1.1.1', '2.7.5', 'Bash')
    output.seek(0)
    assert output.read() == 'The Fuck 1.1.1 using Python 2.7.5 and Bash\n'



# Generated at 2022-06-22 00:59:18.455674
# Unit test for function debug_time
def test_debug_time():
    assert debug_time

# Generated at 2022-06-22 00:59:23.677062
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    corrected_command = Mock(script=u'echo "fuu!"',
                             side_effect=True)
    confirm_text(corrected_command)
    corrected_command = Mock(script=u'echo "fuu!"',
                             side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-22 00:59:26.696763
# Unit test for function version
def test_version():
    """ $ thefuck --version """
    assert version('', '', 'bash') == \
        u'The Fuck  using Python  and bash\n'



# Generated at 2022-06-22 00:59:31.347288
# Unit test for function version
def test_version():
    version('3.9', '2.6', 'Bash')
    version('3.9', '2.6', 'ZSH')
    version('3.9', '2.6', 'Fish')
    version('3.9', '2.6', 'Shell')

# Generated at 2022-06-22 00:59:46.264894
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'

# Generated at 2022-06-22 00:59:47.846169
# Unit test for function debug
def test_debug():
    debug(u'Удалось возьми')

# Generated at 2022-06-22 00:59:50.795408
# Unit test for function confirm_text
def test_confirm_text():
    i = 0
    while i < 32:
        confirm_text('fuck')
        i += 1

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 00:59:52.662699
# Unit test for function failed
def test_failed():
    def _test():
        failed('test')
    assert _test.__name__ != '_test'


# Generated at 2022-06-22 00:59:56.261100
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    out = StringIO.StringIO()
    sys.stdout = out
    confirm_text(1)
    output = out.getvalue().strip()
    assert output == '> 1 [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 01:00:09.329114
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details=None)
    how_to_configure_alias(configuration_details=const.ConfigurationDetails(
        can_configure_automatically=False,
        path=u'~/.config/fish/fish.conf',
        content='set -g ENABLE_FUCK_ALIAS yes',
        reload=u'fish_config'))
    how_to_configure_alias(configuration_details=const.ConfigurationDetails(
        can_configure_automatically=True,
        path=u'~/.config/fish/fish.conf',
        content='set -g ENABLE_FUCK_ALIAS yes',
        reload=u'fish_config'))

# Generated at 2022-06-22 01:00:10.963915
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO

    f = StringIO()

    sys.stderr = f

    confirm_text('string')

    sys.stderr = sys.__stderr__

    f.seek(0)

    output = f.read()
    assert output == '>string ['


# Generated at 2022-06-22 01:00:14.812781
# Unit test for function debug_time
def test_debug_time():
    import time
    from . import main as test_main
    settings.debug = True
    with test_main._debug_time('Test'):
        time.sleep(1)
    settings.debug = False

# Generated at 2022-06-22 01:00:20.432081
# Unit test for function failed
def test_failed():
    from io import StringIO

    stderr = StringIO()
    sys.stderr = stderr
    try:
        failed('msg')
    finally:
        sys.stderr = sys.__stderr__
    assert stderr.getvalue() == '\x1b[31mmsg\x1b[0m\n'



# Generated at 2022-06-22 01:00:27.668470
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    theconfigure = """Seems like fuck alias isn't configured!
    Please put alias fuck='eval $(thefuck $(fc -ln -1))' in your .bashrc and apply changes with source ~/.bashrc or restart your shell.
    Or run fuck a second time to configure it automatically.
    More details - https://github.com/nvbn/thefuck#manual-installation"""
    assert how_to_configure_alias(theconfigure) == theconfigure

# Generated at 2022-06-22 01:00:40.621366
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo') as bar:
        pass
    with debug_time('foo') as bar:
        pass

# Generated at 2022-06-22 01:00:46.339966
# Unit test for function configured_successfully
def test_configured_successfully():
    from io import StringIO
    from .main import ConfigurationDetails
    out = StringIO()
    sys.stderr = out
    configured_successfully(ConfigurationDetails(
        path='test',
        reload='test_reload',
        content='test_content',
        can_configure_automatically=True))
    assert u"fuck alias configured successfully!" in out.getvalue()# Unit test for function already_configured

# Generated at 2022-06-22 01:00:50.457429
# Unit test for function color
def test_color():
    assert color('red') == ''
    assert color('red') == ''

    settings.no_colors = False

    assert color('red') == 'red'
    assert color('red') == 'red'

    settings.no_colors = True



# Generated at 2022-06-22 01:00:51.571516
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(object) == None

# Generated at 2022-06-22 01:00:54.924533
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    from .exceptions import FuckError
    try:
        raise FuckError()
    except FuckError:
        rule_failed(Rule('ls', 'ls'), sys.exc_info())
    assert True

# Generated at 2022-06-22 01:00:57.516950
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {'reload': 'source ~/.bashrc'}
    return configured_successfully(configuration_details['reload'])



# Generated at 2022-06-22 01:01:01.676311
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.sudo import sudo_support
    from tests.utils import RuleTest

    sudo_support()
    rule = RuleTest(sudo_support, None, 'fuck')
    rule_failed(rule, None)