

# Generated at 2022-06-22 00:51:01.839240
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('sleeping'):
        time.sleep(.5)

# Generated at 2022-06-22 00:51:04.221491
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    corrected_command = Mock(script='script', side_effect=True)
    confirm_text(corrected_command)



# Generated at 2022-06-22 00:51:06.107385
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully() == "fuck alias configured successfully!\nFor applying changes run reload or restart your shell."

# Generated at 2022-06-22 00:51:09.676270
# Unit test for function configured_successfully
def test_configured_successfully():
    print('testing configured_successfully')
    assert configured_successfully({'reload': 'source ~/.bashrc'}) == None
    print('configured_successfully passed')



# Generated at 2022-06-22 00:51:12.426181
# Unit test for function failed
def test_failed():
    failed('Test')
    assert sys.stderr.getvalue() == u'\x1b[31mTest\x1b[0m\n'



# Generated at 2022-06-22 00:51:14.209789
# Unit test for function warn
def test_warn():
    warn('It will show [WARN] It will show')
    assert True


# Generated at 2022-06-22 00:51:22.147257
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from py.test import raises

    started = datetime.now()
    with debug_time('test'):
        assert datetime.now() - started < timedelta(seconds=1)
    assert datetime.now() - started > timedelta(seconds=1)

    started = datetime.now()
    with raises(ZeroDivisionError):
        with debug_time('test'):
            1/0
    assert datetime.now() - started > timedelta(seconds=1)

# Generated at 2022-06-22 00:51:27.861378
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """Unit test for function show_corrected_command."""
    from thefuck.shells import Shell
    show_corrected_command(Shell('', None, 'echo $0 $1').get_history('')[0])
    show_corrected_command(Shell('', None, 'echo $0 $1').get_history('fuck')[0])

# Generated at 2022-06-22 00:51:30.142671
# Unit test for function version
def test_version():
    version('0.0.0', '2.7.10', 'zsh 5.0.2')



# Generated at 2022-06-22 00:51:31.873582
# Unit test for function debug

# Generated at 2022-06-22 00:51:34.780321
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-22 00:51:38.361490
# Unit test for function version
def test_version():
    thefuck_version = '3.3'
    python_version = '3.3'
    shell_info = 'Bash'
    version(thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:51:39.381177
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-22 00:51:40.451864
# Unit test for function already_configured
def test_already_configured():
    already_configured('test')

# Generated at 2022-06-22 00:51:49.470214
# Unit test for function configured_successfully
def test_configured_successfully():
    thefuck_version = 'The Fuck 1.0'
    python_version = 'Python 3.5'
    shell_info = 'Bash 4.4'
    output = (u'{bold}fuck{reset} alias configured successfully!\n'
            u'For applying changes run {bold}{reload}{reset} or restart your shell.'.format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload='source ~/.bashrc'))
    assert configured_successfully('source ~/.bashrc') == output


# Generated at 2022-06-22 00:51:51.289648
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed({}, {})

# Generated at 2022-06-22 00:52:00.160674
# Unit test for function configured_successfully
def test_configured_successfully():
    from tempfile import NamedTemporaryFile
    from .shells.bash import Bash
    from thefuck.utils import which

    with NamedTemporaryFile() as temp_config:
        temp_config.write('\n'.join([
            'eval $(thefuck --alias)',
            'alias fuck="eval $(thefuck $(fc -ln -1 | tail -n 1))"',
            'alias f="fuck"'
        ]))
        temp_config.flush()


# Generated at 2022-06-22 00:52:02.836608
# Unit test for function color
def test_color():
    assert color('some string') == 'some string'
    assert settings.no_colors
    settings.no_colors = False
    assert color('some string') == 'some string'

# Generated at 2022-06-22 00:52:04.586248
# Unit test for function exception
def test_exception():
    msg = sys.stderr.write()
    assert msg == '\n'


# Generated at 2022-06-22 00:52:08.756620
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == '\x1b[32m'
    with settings(no_colors=True):
        assert color(colorama.Fore.GREEN) == ''

# Generated at 2022-06-22 00:52:19.270853
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .types import Command
    from .rule import Rule, AppendArg, Command

    rule = Rule(
        name='echo',
        match=lambda *args: True,
        get_new_command=lambda *args: CorrectedCommand(
            Command('echo', 'hello'), 'echo "hello"'))

    corrected_command = rule.get_new_command(
        Command('echo', 'hello'))
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:52:20.754561
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import colorama
    colorama.init()
    show_corrected_command("xxx")

# Generated at 2022-06-22 00:52:22.576902
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-22 00:52:24.289054
# Unit test for function warn
def test_warn():
    colorama.init()
    warn('warn_title')



# Generated at 2022-06-22 00:52:30.243194
# Unit test for function warn
def test_warn():
    title = u'Test warn'
    warn(title)
    assert sys.stderr.getvalue() == (
        u'\x1b[41m\x1b[37m\x1b[1m[WARN] {title}\x1b[0m\n'.format(
            title=title))



# Generated at 2022-06-22 00:52:33.864719
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    f = io.StringIO()
    sys.stderr = f
    corrected_command = "test"
    show_corrected_command(corrected_command)
    assert f.getvalue() == "$test\n"

# Generated at 2022-06-22 00:52:36.858040
# Unit test for function failed
def test_failed():
    from mock import Mock
    output = Mock()
    failed('test')
    output.write.assert_called_with(u'\x1b[31mtest\x1b[0m\n')



# Generated at 2022-06-22 00:52:45.077892
# Unit test for function version
def test_version():
    from tests.output_utils import OutputBuffer
    # prepare for testing
    thefuck_version = '3.7'
    python_version = '3.6.1'
    shell_info = 'BASH'

    with OutputBuffer() as stdout:
        version(thefuck_version, python_version, shell_info)
    assert stdout.get_value() == \
        u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                       python_version,
                                                       shell_info)

# Generated at 2022-06-22 00:52:47.646307
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'Debug string')
    settings.debug = False
    debug(u'Debug string')



# Generated at 2022-06-22 00:52:51.542672
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    (how_to_configure_alias(None))
    (how_to_configure_alias(const.ConfigurationDetails(
        path=u'~/.bashrc',
        content=u'eval $(thefuck --alias)',
        reload=u'source ~/.bashrc')))

# Generated at 2022-06-22 00:52:55.282529
# Unit test for function debug_time
def test_debug_time():
    with debug_time('my test'):
        pass

# Generated at 2022-06-22 00:52:57.146652
# Unit test for function already_configured
def test_already_configured():
    try:
        already_configured('configuration_details')
    except NameError:
        pass


# Generated at 2022-06-22 00:52:58.186884
# Unit test for function already_configured
def test_already_configured():
    already_configured('fuck')

# Generated at 2022-06-22 00:53:03.130988
# Unit test for function rule_failed
def test_rule_failed():
    class TestRule:
        name = 'testrule'
    exception_str = 'TestException: Test exception occured'
    try:
        raise Exception(exception_str)
    except:
        exc_info = sys.exc_info()
    rule_failed(TestRule(), exc_info)

# Generated at 2022-06-22 00:53:07.144773
# Unit test for function rule_failed
def test_rule_failed():
    rule = dict()
    rule['name'] = "ls"
    try:
        raise ValueError()
    except ValueError as exc:
        rule_failed(rule, sys.exc_info())


# Generated at 2022-06-22 00:53:16.746916
# Unit test for function how_to_configure_alias

# Generated at 2022-06-22 00:53:19.934845
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = namedtuple('configuration_details',
                                       ['reload'])
    configured_successfully(configuration_details('source ~/.bashrc'))

# Generated at 2022-06-22 00:53:26.524724
# Unit test for function debug
def test_debug():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    try:
        debug(u'test')
        assert output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-22 00:53:28.805262
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Bash
    assert configured_successfully(Bash) == {'bash': None, 'reload': '$(source ~/.bashrc)'}

# Generated at 2022-06-22 00:53:30.434948
# Unit test for function exception
def test_exception():
    exception('title', ['exc_info'])



# Generated at 2022-06-22 00:53:40.877822
# Unit test for function version
def test_version():
    """assert version output"""
    # Version of The Fuck
    thefuck_version = '3.15'
    # Version of Python
    python_version = u'#{}'.format(sys.version.split(u' ')[0])
    # Version of Shell
    shell_info = u'Shell not specified'
    version = version(thefuck_version, python_version, shell_info)
    assert version == 'The Fuck 3.15 using Python #3.4.3 and Shell not specified'

# Generated at 2022-06-22 00:53:43.717946
# Unit test for function color
def test_color():
    assert color('a') == 'a'
    settings.no_colors = True
    assert color('a') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:53:55.065570
# Unit test for function already_configured
def test_already_configured():
    import mock
    import io
    import sys
    text = u'Seems like {}fuck{} alias already configured!\n' \
           u'For applying changes run {}source ~/.bashrc{} or restart your shell.' \
        .format(color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL),
                color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL))
    with mock.patch('sys.stderr', new=io.StringIO()) as m:
        already_configured(configuration_details=mock.Mock(reload=u'source ~/.bashrc'))
        assert m.getvalue() == text
        sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:54:07.120655
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    actual = 'Seems like \x1b[1mfuck\x1b[22m alias isn\'t configured!\nPlease put \x1b[1m# Put this into your ~/.bashrc\n# eval "$(thefuck --alias fuck)"\x1b[22m in your \x1b[1m~/.bashrc\x1b[22m and apply changes with \x1b[1m. ~/.bashrc\x1b[22m or restart your shell.\nOr run \x1b[1mfuck\x1b[22m a second time to configure it automatically.\nMore details - https://github.com/nvbn/thefuck#manual-installation'
    assert(how_to_configure_alias(None) == actual)


# Generated at 2022-06-22 00:54:16.608767
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import cStringIO
    out = cStringIO.StringIO()
    with mock.patch('sys.stderr', out):
        confirm_text(CorrectedCommand('ls -lah', False))

# Generated at 2022-06-22 00:54:28.960320
# Unit test for function exception
def test_exception():
    import io
    import sys
    import unittest

    class ExceptionTest(unittest.TestCase):
        def setUp(self):
            self.output = io.StringIO()
            self.saved_stderr = sys.stderr
            sys.stderr = self.output

        def tearDown(self):
            sys.stderr = self.saved_stderr

        def test_exception(self):
            try:
                raise Exception()
            except Exception:
                exception(u'Test', sys.exc_info())
            finally:
                self.assertIn(u'[WARN] Test:\n', self.output.getvalue())

    suite = unittest.TestLoader().loadTestsFromTestCase(ExceptionTest)
    unittest.TextTestRunner().run(suite)




# Generated at 2022-06-22 00:54:31.773559
# Unit test for function color
def test_color():
    assert color('color_') == 'color_'
    settings.no_colors = True
    assert color('') == ''

# Generated at 2022-06-22 00:54:36.050455
# Unit test for function warn
def test_warn():
    sys.stderr.write = lambda x: x
    assert '\x1b[31m\x1b[47m\x1b[1m[WARN] test\x1b[0m\n' == warn(u'test')



# Generated at 2022-06-22 00:54:48.116901
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
            path='/home/.bashrc', reload=u'bashd reload',
            content=u'eval "$(thefuck --alias)"',
            can_configure_automatically=False))
    how_to_configure_alias(const.ConfigurationDetails(
            path='/home/.bashrc', reload=u'bashd reload',
            content=u'eval "$(thefuck --alias)"',
            can_configure_automatically=True))
    how_to_configure_alias(const.ConfigurationDetails(
            path='/home/.bashrc', reload=u'bashd reload',
            content=u'eval "$(thefuck --alias)"',
            can_configure_automatically=False))


# Generated at 2022-06-22 00:55:00.112075
# Unit test for function confirm_text
def test_confirm_text():
    with open('tests_output', 'w+') as fp:
        std_stderr = sys.stderr
        sys.stderr = fp
        confirm_text(const.CorrectedCommand(u'command', side_effect=False))
        sys.stderr = std_stderr

# Generated at 2022-06-22 00:55:04.214124
# Unit test for function configured_successfully
def test_configured_successfully():
    l = [u'fuck alias configured successfully!', u'run source ~/.bashrc or restart your bash']
    for i in l:
        assert i in configured_successfully('source ~/.bashrc').lower()

# Generated at 2022-06-22 00:55:11.778866
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """
    Test for function how_to_configure_alias

    """
    from .const import ConfigurationDetails
    from .utils import how_to_configure_alias
    how_to_configure_alias(ConfigurationDetails(
        path='~/.bashrc',
        content='alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        can_configure_automatically=False,
        reload='source ~/.bashrc'))

# Generated at 2022-06-22 00:55:13.385800
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc_info')



# Generated at 2022-06-22 00:55:16.516189
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-22 00:55:24.242028
# Unit test for function failed
def test_failed():
    from contextlib import nested
    from .utils import wrap_retry
    from .shells import Shell

    with nested(wrap_retry(), Shell('noop')) as (retry, shell):
        @retry.retry()
        def _():
            raise ValueError('test')

        with open('debug.log', 'w') as debug:
            with nested(failed.output_to(debug),
                        _.output_to(debug)):
                _()

    with open('debug.log') as debug:
        assert u"test" in debug.read()

# Generated at 2022-06-22 00:55:29.434934
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED) == ''
    settings.no_colors = False
    assert color(colorama.Back.RED) == '\x1b[41m'



# Generated at 2022-06-22 00:55:33.450610
# Unit test for function warn
def test_warn():
    warn('test')
    assert sys.stderr.getvalue() == u'\x1b[41m\x1b[1m\x1b[37m[WARN] test\x1b[0m\n'



# Generated at 2022-06-22 00:55:42.250705
# Unit test for function exception
def test_exception():
    msg = "testmsg"
    exc_info = 1

    error_msg = u'{warn}[WARN] {title}:{reset}\n{trace}'\
                u'{warn}----------------------------{reset}\n\n'.format(
                    warn=color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL),
                    title=msg,
                    trace=''.join(format_exception(*exc_info)))
    assert(error_msg == exception(msg, exc_info))

# Generated at 2022-06-22 00:55:44.325959
# Unit test for function debug_time
def test_debug_time():
    import time
    import thefuck.utils
    thefuck.utils.settings.debug = True
    with thefuck.utils.debug_time('msg'):
        time.sleep(0.1)

# Generated at 2022-06-22 00:55:55.575384
# Unit test for function version
def test_version():
    from mock import patch
    from .utils import get_version
    from . import __version__
    from .shells import Shell

    mock_python_version = '3.3.3'
    mock_shell_info = 'bash'

# Generated at 2022-06-22 00:55:59.269204
# Unit test for function debug
def test_debug():
    debug(u'foo')


# Generated at 2022-06-22 00:56:03.427147
# Unit test for function show_corrected_command
def test_show_corrected_command():
    out = ">>> show_corrected_command(['fuck', '-h'])\n"
    correct_out = const.USER_COMMAND_MARK + 'fuck -h\n'
    assert out == correct_out


# Generated at 2022-06-22 00:56:06.681894
# Unit test for function version
def test_version():
    from mock import Mock
    from thefuck.conf import __version__

    version(__version__, '2.7.10', Mock(path='/bin/bash'))

# Generated at 2022-06-22 00:56:07.903065
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("rule_name",("exc_info"))

# Generated at 2022-06-22 00:56:16.246677
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        import cPickle as pickle
    except ImportError:
        import pickle
    import cStringIO
    import mock

    class MockStream(object):
        def write(self, msg):
            self.msg = msg

    class MockCorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

        def __eq__(self, other):
            return ((self.script == other.script) and
                    (self.side_effect == other.side_effect))

    assert show_corrected_command(
        MockCorrectedCommand(u'/bin/ls', True)) == None
    assert show_corrected_command(
        MockCorrectedCommand(u'/bin/ls', False)) == None

    # https://github

# Generated at 2022-06-22 00:56:22.053248
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    with StringIO() as out:
        sys.stderr = out
        debug(u'Test')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n'
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:56:24.642474
# Unit test for function debug
def test_debug():
    settings.debug = True
    expected = '[DEBUG] test\n'
    debug(u'test')
    settings.debug = False

# Generated at 2022-06-22 00:56:29.280394
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # If the corrected command has NOT side effect.
    corrected_command = const.CorrectedCommand('command', False)
    show_corrected_command(corrected_command)

    # If the corrected command has side effect.
    corrected_command = const.CorrectedCommand('command', True)
    show_corrected_command(corrected_command)

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-22 00:56:31.064384
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color('test') != 'Test'

# Generated at 2022-06-22 00:56:43.481049
# Unit test for function configured_successfully
def test_configured_successfully():
    import tempfile
    import os
    temp_f = tempfile.NamedTemporaryFile(delete=False)

# Generated at 2022-06-22 00:56:51.346439
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug('test')
    assert sys.stderr.getvalue() == ''

    settings.debug = True
    debug('test')
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-22 00:56:54.632514
# Unit test for function confirm_text
def test_confirm_text():
    spinner = set(['-', '\\', '|', '/'])
    conf_text = confirm_text(None)
    assert conf_text[-2] in spinner



# Generated at 2022-06-22 00:57:06.409818
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.base import BaseShell
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.shell import Shell
    from .conf import Config
    import os
    import sys

    config = Config(None)
    assert '\033[1K\r' in confirm_text(BaseShell(config).from_shell(
        'ls'))
    assert '\033[1K\r' not in confirm_text(Bash(config).from_shell(
        'ls'))
    assert '\033[1K\r' not in confirm_text(Zsh(config).from_shell(
        'ls'))

# Generated at 2022-06-22 00:57:15.700241
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import tempfile
    _, path = tempfile.mkstemp()

    try:
        sys.stderr = os.fdopen(sys.stderr.fileno(), 'w', 0)
        show_corrected_command(const.CorrectedCommand('ls', 'ls -a'))
        sys.stderr.seek(0)

        assert sys.stderr.read() == '{0}ls -a\n'.format(const.USER_COMMAND_MARK)
    finally:
        sys.stderr.close()
        os.remove(path)

# Generated at 2022-06-22 00:57:20.021590
# Unit test for function confirm_text
def test_confirm_text():
    # Test function with side_effect
    confirm_text(corrected_command={"script":"fuck",
                                    "side_effect":True})
    # Test function with no side_effect
    confirm_text(corrected_command={"script":"fuck",
                                    "side_effect":False})

# Generated at 2022-06-22 00:57:23.780535
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) != ''
    settings.no_colors = True
    assert color(colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:57:27.222460
# Unit test for function color
def test_color():
    assert color('hello') == ''
    assert color('world') == ''

    settings.no_colors = False
    assert color('hello') == 'hello'
    assert color('world') == 'world'

# Generated at 2022-06-22 00:57:32.561154
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rules import ConfigurationDetails

    details = ConfigurationDetails(
        path='~/.zshrc',
        content='eval $(thefuck --alias fuck)',
        can_configure_automatically=True,
        reload='source ~/.zshrc',
        reload_command='source ~/.zshrc')
    how_to_configure_alias(details)

# Generated at 2022-06-22 00:57:35.143294
# Unit test for function exception
def test_exception():
    try:
        raise NameError
    except NameError:
        exception(u'exceptionforunitest', sys.exc_info())


# Generated at 2022-06-22 00:57:42.971368
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('sys_stderr.txt', 'w')
    show_corrected_command('ls; ddd')
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    with open('sys_stderr.txt') as f:
        assert f.read() == 'Corrected command: ls; ddd\n'

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-22 00:57:49.048197
# Unit test for function already_configured
def test_already_configured():
    already_configured("!")



# Generated at 2022-06-22 00:57:52.005817
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import get_closest

    correct_command = get_closest('fck')
    show_corrected_command(correct_command)


# Generated at 2022-06-22 00:57:55.041667
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'some command to test'
    confirm_text(corrected_command)

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 00:57:55.750660
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass

# Generated at 2022-06-22 00:57:58.708129
# Unit test for function color
def test_color():
    assert color('\x1b[31mred\x1b[0m') == '\x1b[31mred\x1b[0m'



# Generated at 2022-06-22 00:58:00.744270
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise ValueError()
    except ValueError:
        rule_failed(object, sys.exc_info())

# Generated at 2022-06-22 00:58:12.741428
# Unit test for function version
def test_version():  # pragma: no cover
    import sys
    from thefuck.utils import get_version, get_shell_info, get_python_version
    thefuck_version = get_version()
    python_version = get_python_version()
    shell_info = get_shell_info()
    backup_sys_stderr = sys.stderr
    out = 'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                    python_version,
                                                    shell_info)
    sys.stderr = open('./temp', 'w')
    version(thefuck_version, python_version, shell_info)
    sys.stderr.close()
    sys.stderr = backup_sys_stderr

# Generated at 2022-06-22 00:58:25.337902
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = _ConfigurationDetails(
        path='~/.config/zshrc',
        reload='zsh',
        content='fuck = fuck',
        can_configure_automatically=True)

    output = []

    def mocked_sys_stderr_write(msg):
        output.append(msg)

    sys.stderr.write = mocked_sys_stderr_write

    how_to_configure_alias(configuration_details)


# Generated at 2022-06-22 00:58:28.263322
# Unit test for function rule_failed
def test_rule_failed():
    class TmpRule:
        name = 'name'
    try:
        raise Exception('Some exception')
    except Exception as e:
        rule_failed(TmpRule(), sys.exc_info())


# Generated at 2022-06-22 00:58:38.727751
# Unit test for function configured_successfully
def test_configured_successfully():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as temp_dir:
        assert not os.path.exists(os.path.join(temp_dir, '.bashrc'))
        configured_successfully(
            const.ConfigurationDetails(
                path=os.path.join(temp_dir, '.bashrc'),
                reload='bash',
                content='eval $(thefuck --alias)',
                can_configure_automatically=True))
        assert os.path.exists(os.path.join(temp_dir, '.bashrc'))

# Generated at 2022-06-22 00:58:49.603681
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-22 00:58:53.691490
# Unit test for function already_configured
def test_already_configured():
    from sys import stderr
    from thefuck.utils import already_configured
    already_configured({'reload': 'RELOAD'})
    assert u'RELOAD' in stderr.getvalue()


# Generated at 2022-06-22 00:58:56.021705
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(u'. ~/.bashrc') == u"Seems like fuck alias already configured!\nFor applying changes run . ~/.bashrc or restart your shell."


# Generated at 2022-06-22 00:58:59.493812
# Unit test for function color
def test_color():
    assert (color(colorama.Fore.GREEN + 'test') ==
            colorama.Fore.GREEN + 'test')
    settings.no_colors = True
    assert color(colorama.Fore.GREEN + 'test') == ''

# Generated at 2022-06-22 00:59:09.965280
# Unit test for function debug_time
def test_debug_time():
    from . import test_compatibility
    from . import test_utils
    from . import utils

    test_compatibility.mock(utils, 'debug', test_utils.MockedCallable())

    with debug_time('Test'):
        pass

    assert utils.debug.calls == [u'Test took: 0:00:00.000000']

    # Check that context doesn't break with exception
    try:
        with debug_time('Test'):
            raise Exception()
    except:
        pass

    assert utils.debug.calls == [u'Test took: 0:00:00.000000',
                                 u'Test took: 0:00:00.000000']

# Generated at 2022-06-22 00:59:11.196942
# Unit test for function failed
def test_failed():
    failed('Error') == 'Error'

# Generated at 2022-06-22 00:59:18.607752
# Unit test for function configured_successfully
def test_configured_successfully():
    expected = (
        u"{bold}fuck{reset} alias configured successfully!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='/bin/bash'))

    assert (configured_successfully('/bin/bash') == expected)

# Generated at 2022-06-22 00:59:30.009431
# Unit test for function failed
def test_failed():
    """Unit test for function __main__.failed"""

    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def capture_sys_output():
        capture_out, capture_err = StringIO(), StringIO()
        current_out, current_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = capture_out, capture_err
            yield capture_out, capture_err
        finally:
            sys.stdout, sys.stderr = current_out, current_err

    with capture_sys_output() as (out, err):
        failed('Some error')
    assert err.getvalue() == u'\x1b[31mSome error\x1b[0m\n'

# Generated at 2022-06-22 00:59:31.289036
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-22 00:59:38.496995
# Unit test for function already_configured
def test_already_configured():
        assert already_configured('configuration_details') == \
        print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload))

# Generated at 2022-06-22 00:59:56.533840
# Unit test for function confirm_text
def test_confirm_text():
    sys.stdout.write("Should write confirm message for user\n")
    answer_file = open("tests/answer.txt", "w+")
    answer_file.writelines(["I",
                            "should",
                            "be",
                            "able",
                            "to",
                            "write",
                            "in",
                            "this",
                            "fuckin",
                            "file"])
    answer_file.close()
    answer_file = open("tests/answer.txt", "r")

    lines = answer_file.readlines()
    i = 0
    for line in lines:
        correct_command = type('', (), {})()
        correct_command.script = line
        correct_command.side_effect = False
        confirm_text(correct_command)
        sys.std

# Generated at 2022-06-22 01:00:09.329070
# Unit test for function failed
def test_failed():
    from mock import Mock
    from thefuck import shells

    def test(mocked_stderr):
        original_shell = shells.get_shell()
        shells._shells = {'default': Mock(get_app_alias=Mock(
                return_value='fuck'))}

        failed(u'Это тест!')
        assert mocked_stderr.write.called

        shells._shells = {'default': original_shell}

    sys.modules['colorama'] = Mock()
    import colorama
    colorama.init = Mock()
    colorama.Fore = Mock(RED=Mock())
    colorama.Style = Mock(RESET_ALL=Mock())

    sys.modules['thefuck.settings'] = Mock(no_colors=False)

    import sys

# Generated at 2022-06-22 01:00:10.390145
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('success') == None

# Generated at 2022-06-22 01:00:19.507131
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck import shells

    with patch.object(sys, 'stderr', open('/dev/null', 'w')):
        debug('x')

    with patch.object(sys.stderr, 'write') as mock:
        debug('x')
        mock.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} x\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-22 01:00:22.591739
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type('NOTHING', (), {'reload': 'source ~/.zshrc'})
    assert already_configured(configuration_details)


# Generated at 2022-06-22 01:00:34.296814
# Unit test for function exception
def test_exception():
    import unittest
    import StringIO

    class ExceptionTest(unittest.TestCase):
        @staticmethod
        def _call(title, exc_info=None):
            sys.stdout = StringIO.StringIO()
            exception(title, exc_info or sys.exc_info())
            return sys.stdout.getvalue()

        def test_exception(self):
            self.assertTrue('KeyboardInterrupt' in self._call(''))

        def test_title(self):
            self.assertTrue('[WARN] Title' in self._call('Title'))

        def test_exc_info(self):
            self.assertTrue('KeyboardInterrupt' in self._call(
                '', sys.exc_info()))

    unittest.main()

# Generated at 2022-06-22 01:00:38.789164
# Unit test for function version
def test_version():
    from .. import __version__
    from site import getsitepackages

    sys.stderr = open('/dev/null', 'w')  # Ignore stdout
    version(__version__, '2.7.1', 'ZSH')



# Generated at 2022-06-22 01:00:40.672247
# Unit test for function exception
def test_exception():
    exc_info = sys.exc_info()
    exception('Title', exc_info)


# Generated at 2022-06-22 01:00:43.961982
# Unit test for function warn
def test_warn():
    warn(u'Test')
    assert '[WARN] Test' in sys.stderr.getvalue()
    assert 'Test' in sys.stderr.getvalue()



# Generated at 2022-06-22 01:00:47.208976
# Unit test for function configured_successfully
def test_configured_successfully():
    old_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        configured_successfully(None)
    finally:
        sys.stdout = old_stdout