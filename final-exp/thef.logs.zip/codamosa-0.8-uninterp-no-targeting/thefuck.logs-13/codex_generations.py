

# Generated at 2022-06-22 00:50:58.917866
# Unit test for function exception
def test_exception():
    exc_info = (None, TypeError("it's a test exception"), None)
    exception('test', exc_info)

# Generated at 2022-06-22 00:51:02.530448
# Unit test for function exception
def test_exception():  # noqa
    from .utils import unic
    def _():
        raise RuntimeError()
    exception(unic(u'Rule {}').format(unic(u'name')),
              sys.exc_info())

# Generated at 2022-06-22 00:51:09.530914
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = lambda x: None
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script=u'script',
        side_effect=u'',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-22 00:51:16.549503
# Unit test for function version
def test_version():
    class Buffer(object):
        content = ''

        def write(self, s):
            self.content += s

    buffer = Buffer()

    version(
        thefuck_version='3.9',
        python_version='3.6.2',
        shell_info='Sh 3.2.57',
        buffer=buffer)

    assert buffer.content == \
        'The Fuck 3.9 using Python 3.6.2 and Sh 3.2.57\n'

# Generated at 2022-06-22 00:51:22.952050
# Unit test for function warn
def test_warn():
    stderr = sys.stderr
    try:
        sys.stderr = []
        warn('Test warn')
        assert sys.stderr == [u'\x1b[41m\x1b[37m\x1b[1m[WARN] Test warn\x1b[0m\n']
    finally:
        sys.stderr = stderr



# Generated at 2022-06-22 00:51:28.431168
# Unit test for function color
def test_color():
    assert color('\x1b[1;31mtest\x1b[0m') == '\x1b[1;31mtest\x1b[0m'
    settings.no_colors = True
    assert color('\x1b[1;31mtest\x1b[0m') == ''

# Generated at 2022-06-22 00:51:40.609854
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    with StringIO.StringIO() as buf:
        sys.stderr = buf
        confirm_text(object())
        assert buf.getvalue() == '{prefix}{clear}{bold}{script}{reset}{side_effect} ' \
            '[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            script='<object object at 0x7f7c49e67a70>',
            side_effect=u'',
            clear='\033[1K\r',
            bold=u'',
            green=u'',
            red=u'',
            reset=u'',
            blue=u'')


# Generated at 2022-06-22 00:51:42.074481
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(object) == None


# Generated at 2022-06-22 00:51:44.094417
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-22 00:51:53.409460
# Unit test for function debug
def test_debug():
    from . import utils
    from thefuck.shells import shell

    # Test for colors on win32 system
    utils.debug.reset_mock()
    utils.debug('test')
    utils.debug.assert_called_once_with('test')

    # Test for colors on linux system
    utils.debug.reset_mock()
    utils.settings._set_no_colors(True)
    utils.debug('test')
    utils.debug.assert_called_once_with('test')

# Generated at 2022-06-22 00:52:06.651890
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Test case when configuration_details == None
    sys.stdout = open('trash', 'w')
    how_to_configure_alias(None)
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    f = open('trash', 'r')
    text = f.read()
    assert (u"Seems like \x1b[1mfuck\x1b[22m alias isn't configured!\n\n"
            u"Or run \x1b[1mfuck\x1b[22m a second time to configure"
            u" it automatically.\n"
            u"More details - https://github.com/nvbn/thefuck#manual-installation") in text
    f.close()

    # Test case when configuration_details != None

# Generated at 2022-06-22 00:52:07.366719
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:52:12.911669
# Unit test for function exception
def test_exception():
    def inner():
        try:
            raise ValueError('test')
        except Exception:
            exception(u'Some fucking title', sys.exc_info())
    stream = sys.stderr
    sys.stderr = sys.stdout
    inner()
    sys.stderr = stream



# Generated at 2022-06-22 00:52:20.303777
# Unit test for function exception
def test_exception():
    from PyQt4 import QtCore
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    @contextmanager
    def uncaptured_output():
        old_out, old_err = sys.stdout, sys.stderr
        try:
            yield
        finally:
            sys.stdout, sys.stderr = old_out, old_err


# Generated at 2022-06-22 00:52:21.027339
# Unit test for function warn
def test_warn():
    warn('title')

# Generated at 2022-06-22 00:52:33.909522
# Unit test for function rule_failed
def test_rule_failed():
    import io
    import sys
    import colorama
    from .conf import settings
    from . import const
    from .version import __version__
    from .shells import shell

    sys.stdout = io.BytesIO()
    sys.stderr = io.BytesIO()
    settings.no_colors = True
    settings.debug = True

    def run_rule(command, *args):
        from .rules import Command
        from .rules import RulesCollection

        class Rule(object):
            name = 'test'

            enabled_by_default = True

            def get_new_command(self, command):
                return command

        rules_collection = RulesCollection([Rule('test')])
        failed_command = Command('not command', 'not command')

# Generated at 2022-06-22 00:52:41.053189
# Unit test for function version
def test_version():
    thefuck_version = '3.9'
    python_version = '2.7.11'
    shell_info = 'bash-4.3.30'

    error_message = 'Expected message is not the same as generated message.'
    expected_message = 'The Fuck 3.9 using Python 2.7.11 and bash-4.3.30\n'
    assert expected_message == version(thefuck_version, python_version, shell_info), error_message

# Generated at 2022-06-22 00:52:43.364796
# Unit test for function exception
def test_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        exception('ZeroDivisionError', sys.exc_info())
        assert True

# Generated at 2022-06-22 00:52:44.461527
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-22 00:52:48.403707
# Unit test for function rule_failed
def test_rule_failed():
    import thefuck.main
    from thefuck.rules import Command

    rule = Command('pwd; cd /etc; ls -al')
    rule_failed(rule, thefuck.main.sys.exc_info())
    sys.exc_clear()

# Generated at 2022-06-22 00:52:52.304006
# Unit test for function warn
def test_warn():
    warn('test warn')



# Generated at 2022-06-22 00:52:59.274157
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('test'), None)

    msg = u'[WARN] Exception: Please check logs\n'\
          u'----------------------------\n\n'\
          u'Traceback (most recent call last):\n'\
          u'  File "<stdin>", line 1, in <module>\n'\
          u'Exception: test\n'

    exception('Exception', exc_info)
    assert sys.stderr.getvalue() == msg

# Generated at 2022-06-22 00:53:03.242470
# Unit test for function version
def test_version():
    # Check complite string
    version('test ver', 'test python ver', 'test shell_info')
    assert sys.stderr.getvalue() == 'The Fuck test ver using Python test python ver and test shell_info\n'

# Generated at 2022-06-22 00:53:13.571498
# Unit test for function show_corrected_command
def test_show_corrected_command():
    for command in [
            Command(script='ls', side_effect=False),
            Command(script='rm xxx', side_effect=False),
            Command(script='git branch', side_effect=False),
            Command(script='git branch', side_effect=True)]:
        sys.stderr = sys.__stderr__
        show_corrected_command(command)
        output = sys.stderr.getvalue().strip()
        assert output == u'{}\u001b[1K\r{} {}'.format(
            const.USER_COMMAND_MARK,
            command.script,
            ' (+side effect)' if command.side_effect else '')

# Generated at 2022-06-22 00:53:20.416734
# Unit test for function confirm_text
def test_confirm_text():
    with settings(no_colors=False):
        confirm_text(CorrectedCommand('ls', 'ls -al'))
        confirm_text(CorrectedCommand('ls', 'ls -al', True))
        confirm_text(CorrectedCommand('ls', 'ls -al', True))
        confirm_text(CorrectedCommand('ls', 'ls -al', True))



# Generated at 2022-06-22 00:53:31.349200
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.utils import ConfigurationDetails
    sys.stdout = output = StringIO()
    how_to_configure_alias(ConfigurationDetails(
        path='~/.bashrc', content="eval $(thefuck --alias)",
        reload='$ exec $SHELL'))
    sys.stdout = sys.__stdout__

# Generated at 2022-06-22 00:53:40.326528
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.main import ConfigurationDetails
    from thefuck.shells import get_data
    import os
    import sys
    old_stdout = sys.stdout
    try:
        # redirect output
        sys.stdout = open(os.devnull, 'w')
        how_to_configure_alias(ConfigurationDetails(
            "~/.bashrc", "echo 'eval $(thefuck --alias)' >> ~/.bashrc", "source ~/.bashrc"))
    finally:
        # restore output
        sys.stdout = old_stdout

# Generated at 2022-06-22 00:53:41.375162
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully


# Generated at 2022-06-22 00:53:44.197817
# Unit test for function color
def test_color():
    assert color('bold') == colorama.Style.BRIGHT
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-22 00:53:46.237529
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''



# Generated at 2022-06-22 00:53:52.040192
# Unit test for function configured_successfully
def test_configured_successfully():
    shell_info = 'shell {}\n'.format('bash')
    configuration_details = ConfigurationDetails('source ~/.bashrc')
    configured_successfully(configuration_details)

# Generated at 2022-06-22 00:53:57.154515
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('configuration_details') == \
           u"{bold}fuck{reset} alias configured successfully!\n" \
           u"For applying changes run {bold}{reload}{reset}" \
           u" or restart your shell.".format(
               bold=color(colorama.Style.BRIGHT),
               reset=color(colorama.Style.RESET_ALL),
               reload=configuration_details.reload)



# Generated at 2022-06-22 00:53:59.263594
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(conf.ConfigurationDetails())



# Generated at 2022-06-22 00:54:04.308796
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class TempCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(TempCommand('echo "fuck"', False))
    show_corrected_command(TempCommand('echo "fuck"', True))

# Generated at 2022-06-22 00:54:06.350895
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command()

# Generated at 2022-06-22 00:54:08.407075
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    colorama.deinit()

# Generated at 2022-06-22 00:54:09.499175
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("bash")

if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 00:54:11.336489
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck import shells

    how_to_configure_alias(shells.get_shell())


# Generated at 2022-06-22 00:54:23.502544
# Unit test for function warn
def test_warn():
    from .application import Application
    from . import conf
    from .types import CorrectedCommand
    from .utils import replace_argument
    from .rules import get_rules
    import mock

    # When
    rules = get_rules()
    app = Application(mock.Mock(), rules, conf.Conf([]))
    app.rules = [replace_argument('sed', 's/{}/{}/', 'foo', 'bar')]
    app.run_rule = mock.Mock(
        side_effect=lambda *args, **kwargs:
        CorrectedCommand('echo correct', None, False))
    with mock.patch('thefuck.main.sys') as mock_sys:
        mocked_stream = mock.Mock()
        mock_sys.stderr = mocked_stream

# Generated at 2022-06-22 00:54:26.119059
# Unit test for function show_corrected_command
def test_show_corrected_command():
    const.USER_COMMAND_MARK = "fuck "
    show_corrected_command("hello") == "fuck hello"

# Generated at 2022-06-22 00:54:32.813234
# Unit test for function failed
def test_failed():
    import io
    sys.stderr = io.BytesIO()
    failed(u'foo')
    assert sys.stderr.getvalue() == u'\x1b[31mfoo\x1b[0m\n'

# Generated at 2022-06-22 00:54:34.923162
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls')
    show_corrected_command('ls -al')

# Generated at 2022-06-22 00:54:46.903764
# Unit test for function version
def test_version():
    import sys
    import platform
    import tempfile
    import os
    import importlib
    from .const import THEFUCK_VERSION

    fd, test_version = tempfile.mkstemp()
    os.write(fd, '''def version(thefuck_version, python_version, shell_info):
    sys.stdout.write("{}".format(thefuck_version))''')

    sys.path.insert(0, os.path.dirname(test_version))

# Generated at 2022-06-22 00:54:48.022678
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = None
    configured_successfully(configuration_details)

# Generated at 2022-06-22 00:54:51.993056
# Unit test for function version
def test_version():
    from .utils import get_shell_info

    shell_info = get_shell_info()
    version('3.13', '3.5.0', shell_info)
    version('3.13', '3.5.0', shell_info)

# Generated at 2022-06-22 00:55:03.964696
# Unit test for function version
def test_version():
    import subprocess
    from . import __version__ as VERSION
    from . import get_shell_info
    from . import get_python_version
    from unittest.mock import patch
    with patch('sys.stderr') as stderr, patch('tracemalloc.get_object_traceback') as object_traceback:
        stderr.write = lambda msg: object_traceback(msg)
        version(VERSION, get_python_version(), get_shell_info())
        object_traceback.assert_called_once_with(
            'The Fuck {} using Python {} and {}\n'.format(VERSION,
                                                          get_python_version(),
                                                          get_shell_info()))

# Generated at 2022-06-22 00:55:13.818186
# Unit test for function already_configured
def test_already_configured():
    sys.stderr.write('\n\n')
    already_configured(const.ConfigurationDetails(
        can_configure_automatically=True,
        path='~/fucks',
        content='alias fuck="eval $(thefuck $(fc -ln -1))"',
        reload='source ~/fucks'))
    already_configured(const.ConfigurationDetails(
        can_configure_automatically=False,
        path='~/fucks',
        content='alias fuck="eval $(thefuck $(fc -ln -1))"',
        reload='source ~/fucks'))


# Generated at 2022-06-22 00:55:24.718799
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch

    stderr_patch = patch('sys.stderr')
    stderr_mock = stderr_patch.start()

    with patch.dict(const.__dict__, {'USER_COMMAND_MARK': '#'}):
        confirm_text('ls')

    stderr_mock.write.assert_called_once_with(
        '%sls [\x1b[32menter\x1b[0m/\x1b[34m\x1b[0m/\x1b[34m\x1b[0m/'
        '\x1b[31mctrl+c\x1b[0m]' % const.USER_COMMAND_MARK)

    stderr_patch.stop()

# Generated at 2022-06-22 00:55:26.964561
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)

# Generated at 2022-06-22 00:55:28.688698
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None

# Generated at 2022-06-22 00:55:39.288544
# Unit test for function debug
def test_debug():
    import mock
    from thefuck.utils import debug
    with mock.patch('sys.stderr') as stderr:
        debug('hello world')
        stderr.write.assert_called_with(u'{blue}{bold}DEBUG:{reset} hello world\n'.format(
            blue=colorama.Fore.BLUE,
            bold=colorama.Style.BRIGHT,
            reset=colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:55:48.874867
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch, Mock

    with patch('thefuck.shells.get_shell_info') as get_shell_info:
        get_shell_info.return_value = 'bash'

        sys.stderr.write = Mock()
        with debug_time('msg'):
            pass
        assert sys.stderr.write.called
        #######
        get_shell_info.return_value = 'zsh'

        sys.stderr.write = Mock()
        with debug_time('msg'):
            pass
        assert sys.stderr.write.called
        #######
        get_shell_info.return_value = 'fish'

        sys.stderr.write = Mock()
        with debug_time('msg'):
            pass
        assert sys.stder

# Generated at 2022-06-22 00:55:53.929350
# Unit test for function version
def test_version():
    from mock import NonCallableMock
    from thefuck.utils import get_shell_info, get_python_version, \
                              get_thefuck_version

    version(get_thefuck_version(), get_python_version(),
            get_shell_info(NonCallableMock())) is None

# Generated at 2022-06-22 00:55:57.462186
# Unit test for function version
def test_version():
    version('3.1' , '2.7' , 'bash')
    version('3.1' , '3.0' , 'zsh')
    version('3.1' , '2.7' , 'sh')


# Generated at 2022-06-22 00:56:06.207585
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # if corrected_command is None
    if show_corrected_command(None) == None:
        print("Test case 1 [show_corrected_command] passed")
    else:
        print("Test case 1 [show_corrected_command] failed")

    # if corrected_command is not None
    if show_corrected_command("dir") == None:
        print("Test case 2 [already_configured] passed")
    else:
        print("Test case 2 [already_configured] failed")


# Generated at 2022-06-22 00:56:06.924790
# Unit test for function debug
def test_debug():
    debug("test debug")

# Generated at 2022-06-22 00:56:08.614559
# Unit test for function version
def test_version():
    assert version(1.2, 3, 4) == None


# Generated at 2022-06-22 00:56:16.160796
# Unit test for function debug
def test_debug():
    import StringIO
    from thefuck.utils import settings
    settings.debug = True
    cur_stdout = sys.stderr

    try:
        sys.stderr = StringIO.StringIO()
        debug(u'test')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

        settings.debug = False
        sys.stderr.truncate(0)
        debug(u'test')
        assert sys.stderr.getvalue() == u''
    finally:
        sys.stderr.close()
        sys.stderr = cur_stdout
        settings.debug = False

# Generated at 2022-06-22 00:56:23.905501
# Unit test for function version
def test_version():
    from unittest.mock import Mock
    from thefuck.thefuck.shells import Shell

    sys.stderr = Mock()
    version('0.0.0', '3.4.3', Shell('').info)
    assert sys.stderr.write.called_once_with(
        u'The Fuck 0.0.0 using Python 3.4.3 and Shell (default)\n')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:56:25.495306
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(const.CONFIGURATION_DETAILS)

# Generated at 2022-06-22 00:56:29.366535
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule','error')

# Generated at 2022-06-22 00:56:31.145626
# Unit test for function failed
def test_failed():
    failed(u"Well, it's fucked.")



# Generated at 2022-06-22 00:56:39.901890
# Unit test for function version
def test_version():
    # Get version of thefuck and other version
    thefuck_version = const.__version__
    python_version = sys.version
    shell_info = 'test'
    # Get calling this function
    sys.stderr = io = StringIO()
    version(thefuck_version, python_version, shell_info)
    # Compare with the result that should be
    assert sys.stderr.getvalue() == 'The Fuck {} using Python {} and {}\n'.format(thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:56:51.724071
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    results = []
    configuration_details = None
    def print_impl(output):
        results.append(output)

    # Test with supported shell
    from thefuck.utils import _get_shell_cwd
    _get_shell_cwd = lambda: '/root/'
    import subprocess
    subprocess.check_output = lambda args, stderr: 'bash'
    how_to_configure_alias(configuration_details, print=print_impl)
    assert results[0] == u"Seems like fuck alias isn't configured!"
    assert results[1] == (u"Please put eval $(thefuck --alias) in your "
                          u"~/.bashrc and apply changes with "
                          u"source ~/.bashrc or restart your shell.")

# Generated at 2022-06-22 00:56:52.766575
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:56:57.883540
# Unit test for function version
def test_version():
    from StringIO import StringIO

    data = StringIO()
    sys.stderr = data
    version('1.2.3', '2.7.6', 'zsh shell')
    assert data.getvalue() == 'The Fuck 1.2.3 using Python 2.7.6 and zsh shell\n'



# Generated at 2022-06-22 00:57:00.238048
# Unit test for function version
def test_version():
    import mock
    version(thefuck_version='1.1',
            python_version='2.7',
            shell_info='ShellName')



# Generated at 2022-06-22 00:57:02.853805
# Unit test for function already_configured
def test_already_configured():
    configuration_details = const.ConfigDetails('.bash_profile', 'user', 'reload')
    already_configured(configuration_details)

# Generated at 2022-06-22 00:57:12.830278
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.conf import ConfigurationDetails
    from . import __version__

    path = '~/.bash'  # Unix Shell
    reload = '. ~/.bash'
    can_configure_automatically = True
    content = 'export PATH=$PATH:/usr/local/bin:$HOME/bin\n' + \
              'alias fuck=\'eval $(thefuck $(fc -ln -1))\''
    configuration_details = ConfigurationDetails(
        path, reload, can_configure_automatically, content)

    how_to_configure_alias(configuration_details)
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:57:24.461142
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    import thefuck
    out = StringIO()
    sys.stdout = out
    configuration_details = thefuck.ConfigurationDetails(
        '~/.bash_profile',
        'source ~/.bash_profile',
        False)
    already_configured(configuration_details)
    sys.stdout = sys.__stdout__
    expected_result = u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}source ~/.bash_profile{reset} or restart your shell.\n".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))
    assert out.getvalue() == expected_result



# Generated at 2022-06-22 00:57:28.633937
# Unit test for function version
def test_version():
    assert version('thefuck_version', 'python_version', 'shell_info') == None

# Generated at 2022-06-22 00:57:31.703916
# Unit test for function already_configured
def test_already_configured():
    import tempfile
    with tempfile.NamedTemporaryFile() as config_file:
        already_configured(config_file.name, '{reload}')

# Generated at 2022-06-22 00:57:36.514737
# Unit test for function exception
def test_exception():
    from .rules import Command

    try:
        raise Exception
    except Exception:
        exception(u'Rule {}'.format(Command.name), sys.exc_info())
        sys.stderr.seek(0)
        assert u'[WARN] Rule Command:\n' in sys.stderr.read()

# Generated at 2022-06-22 00:57:39.606845
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'fuck') == '> fuck [enter/↑/↓/ctrl+c]'


# Generated at 2022-06-22 00:57:41.410550
# Unit test for function version
def test_version():
    version('2.1', '2.7.9', 'TEST')

# Generated at 2022-06-22 00:57:46.421088
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .utils import noop
    with debug_time('msg'):
        assert noop(datetime.now() + timedelta(milliseconds=100)) is None  # noqa
    assert noop(datetime.now() + timedelta(milliseconds=100)) is None  # noqa

# Generated at 2022-06-22 00:57:50.391098
# Unit test for function version
def test_version():
    version('3.1', '2.7.5', 'ZSH')
    test_version.result = sys.stderr.getvalue()
    sys.stderr.truncate(0)
test_version.result = None

# Generated at 2022-06-22 00:57:58.493877
# Unit test for function version
def test_version():
    assert version('The Fuck 1.1', '2.7.10', 'zsh on Darwin') == None
    assert version('The Fuck 2.1', '2.7.10', 'bash on Windows') == None
    assert version('The Fuck 3.1', '3.7.10', 'csh on Linux') == None
    assert version('The Fuck 4.1', '2.1.10', 'zsh on MacOS') == None
    assert version('The Fuck 5.1', '2.7.10', 'bash on Linux') == None

# Generated at 2022-06-22 00:58:10.377512
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from datetime import datetime
    import os

    from py.test import raises
    from mock import patch, MagicMock

    from thefuck.utils import ConfigurationDetails

    def _do_the_test(configuration_details, expected, env_mock):
        with patch.dict(os.environ, {}, clear=True):
            with patch('thefuck.utils.getenv', env_mock), \
                    patch('thefuck.utils.sys.stderr',
                          new=MagicMock(write=MagicMock())), \
                    patch('thefuck.utils.sys.stdout',
                          new=MagicMock(write=MagicMock())):
                if configuration_details:
                    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:58:11.506732
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(('a', 'b'))

# Generated at 2022-06-22 00:58:24.945905
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u"\033[1K\r")
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script=u"ls",
        side_effect=u' (+side effect)',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-22 00:58:29.626778
# Unit test for function rule_failed
def test_rule_failed():
    def test_rule():
        raise RuntimeError('Unexpected exception')
    try:
        with pytest.raises(RuntimeError):
            test_rule()
    except Exception:
        exception_details = sys.exc_info()
    rule_failed(Rule(name='name', match='match', get_new_command='get_new_command',
                     side_effect=None), exception_details)


# Generated at 2022-06-22 00:58:39.317632
# Unit test for function warn
def test_warn(): # pragma: no cover
    from . import application
    from .cmd_runner import Command
    import sys
    import os

    class TestSettings(object):
        no_colors = False
        debug = False
        put_typed_command = True

    try:
        sys.stderr = sys.stdout = open(os.devnull, 'w')
        settings = TestSettings()
        warn('test')
    finally:
        sys.stderr = sys.__stderr__
        sys.stdout = sys.__stdout__


# Generated at 2022-06-22 00:58:40.352502
# Unit test for function warn
def test_warn():
    warn(u'Title')



# Generated at 2022-06-22 00:58:41.808508
# Unit test for function already_configured
def test_already_configured():
    # Test
    assert already_configured('test/test') == None



# Generated at 2022-06-22 00:58:43.290591
# Unit test for function exception
def test_exception():
    exception(u'title', sys.exc_info())



# Generated at 2022-06-22 00:58:46.240486
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Rule
    rule_failed(Rule('', ''), ("", "", "",))



# Generated at 2022-06-22 00:58:53.857714
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import wrap_command
    from .conf import ConfigurationDetails
    shell = Shell('sh')
    shell.script = 'which fuck'
    shell.path = '/Users/avr'
    how_to_configure_alias(ConfigurationDetails(
        wrap_command('fuck'),
        '/Users/avr/.config',
        'source ~/.config/bashrc',
        True))
    how_to_configure_alias(None)



# Generated at 2022-06-22 00:58:54.856464
# Unit test for function warn
def test_warn():
    warn('test title')



# Generated at 2022-06-22 00:58:55.987968
# Unit test for function version
def test_version():
    version('3.9', '1.2', 'Zsh 3.2')



# Generated at 2022-06-22 00:59:08.005707
# Unit test for function confirm_text
def test_confirm_text():
    ret = []

    def fake_stderr_write(msg):
        ret.append(msg)

    _confirm_text = globals()['confirm_text']


# Generated at 2022-06-22 00:59:11.723120
# Unit test for function version
def test_version():
    from unittest import mock
    from . import __version__
    from . import shell
    version(__version__, '3.3.3', shell.from_shell('echo 1').decode())

# Generated at 2022-06-22 00:59:13.343353
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''



# Generated at 2022-06-22 00:59:15.496795
# Unit test for function failed
def test_failed():
    """
    Unit test for function failed
    """
    failed('failed')



# Generated at 2022-06-22 00:59:27.344785
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import shell_info
    from .types import ConfigurationDetails

    configuration_details = ConfigurationDetails({
        'clear': '\033[1K\r',
        'bold': '\033[1m',
        'reset': '\033[0m',
        'green': '\033[32m',
        'red': '\033[31m',
        'blue': '\033[34m',
        'path': '/home/user/.bashrc',
        'reload': shell_info('/home/user/.bashrc'),
        'content': 'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        'can_configure_automatically': True
    })

    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:59:30.428402
# Unit test for function rule_failed
def test_rule_failed():
    import sys
    import traceback
    try:
        raise ValueError
    except ValueError as e:
        rule_failed(e, sys.exc_info())

# Generated at 2022-06-22 00:59:32.724559
# Unit test for function configured_successfully
def test_configured_successfully():
    class ShellInfo:
        reload = 'reload'

    configured_successfully(ShellInfo)



# Generated at 2022-06-22 00:59:35.681649
# Unit test for function configured_successfully
def test_configured_successfully():
    return u'fuck alias configured successfully!\nFor applying changes run \033[1;32mreload\033[0m or restart your shell.'

# Generated at 2022-06-22 00:59:39.882829
# Unit test for function failed
def test_failed():
    from .tests.utils import MockStdErr
    with MockStdErr() as err:
        failed('Foo message')
    assert err.getvalue() == '\x1b[31mFoo message\x1b[0m\n'



# Generated at 2022-06-22 00:59:53.301789
# Unit test for function version
def test_version():
    import sys
    import re
    import os
    from . import version as fuck_version
    from . import conf

    saved_argv = sys.argv
    saved_stderr = sys.stderr
    saved_stdout = sys.stdout
    saved_getenv = os.getenv
    saved_getpid = os.getpid
    with open('/dev/null') as dev_null:
        sys.argv = ['thefuck']
        sys.stderr = sys.stdout = dev_null
        os.getenv = lambda e, **kw: {
            'SHELL': '/bin/bash',
            'SHLVL': '1'
            }.get(e, saved_getenv(e, **kw))
        os.getpid = lambda: 123

# Generated at 2022-06-22 01:00:06.066129
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand:
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    # We should have prefix "> " before any command
    show_corrected_command(CorrectedCommand(script='', side_effect=False))
    show_corrected_command(CorrectedCommand(script='printf', side_effect=False))
    show_corrected_command(CorrectedCommand(script='printf', side_effect=True))



# Generated at 2022-06-22 01:00:18.676690
# Unit test for function debug_time
def test_debug_time():
    """it should print passed message with spent time and value of message
    """
    from unittest import mock
    from datetime import timedelta

    with mock.patch('datetime.datetime') as mock_datetime:
        mock_datetime.now.side_effect = [
            datetime(2014, 6, 3, 16),
            datetime(2014, 6, 3, 16, 0, 1)]
        with debug_time('test_debug_time'):
            pass
    assert mock_datetime.now.call_count == 2

    mock_debug = mock.MagicMock()
    debug.__globals__['debug'] = mock_debug
    debug_time('test_debug_time')(lambda: None)()
    assert mock_debug.called

# Generated at 2022-06-22 01:00:26.201335
# Unit test for function debug
def test_debug():
    import StringIO

    from . import utils

    old_stdout = sys.stderr
    sys.stderr = StringIO.StringIO()
    try:
        utils.debug(u'foo bar')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo bar\n'
    finally:
        sys.stderr = old_stdout



# Generated at 2022-06-22 01:00:27.354664
# Unit test for function debug
def test_debug():
    debug("hi")



# Generated at 2022-06-22 01:00:31.532870
# Unit test for function color
def test_color():
    """Test for function color."""
    settings.no_colors = False
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    settings.no_colors = True
    assert color(colorama.Fore.BLUE) == ''



# Generated at 2022-06-22 01:00:32.925053
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(settings)

# Generated at 2022-06-22 01:00:42.107409
# Unit test for function color
def test_color():
    assert not '\x1b[' in color(colorama.Fore.CYAN)
    assert not '\x1b[' in color(colorama.Back.BLACK)
    assert not '\x1b[' in color(colorama.Style.DIM)
    assert '\x1b[' in color(colorama.Fore.CYAN, enable_colors=True)
    assert '\x1b[' in color(colorama.Back.BLACK, enable_colors=True)
    assert '\x1b[' in color(colorama.Style.DIM, enable_colors=True)

# Generated at 2022-06-22 01:00:44.810022
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.bash import Bash
    rule = Bash('fuck')
    try:
        raise Exception()
    except:
        rule_failed(rule, sys.exc_info())



# Generated at 2022-06-22 01:00:53.663699
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    assert color(u'red') == 'red'
    assert color(u'желтый') == '\xd0\xb6\xd0\xb5\xd0\xbb\xd1\x82\xd1\x8b\xd0\xb9'
    assert color(u'желтый'.encode('utf-8')) == '\xd0\xb6\xd0\xb5\xd0\xbb\xd1\x82\xd1\x8b\xd0\xb9'