

# Generated at 2022-06-22 00:50:59.492756
# Unit test for function exception
def test_exception():
    try:
        raise ValueError("test exception")
    except ValueError:
        exception("exception", sys.exc_info())

# Generated at 2022-06-22 00:51:11.453184
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .tools import replace_argument_value
    from .types import ConfigurationDetails, ShellInfo
    from .shells import make_shell
    shell_info = ShellInfo(
        name=u'shell',
        can_configure_automatically=True,
        reload_command=u'reload')
    configuration_details = ConfigurationDetails(
        path=u'~/.zshrc',
        content=u'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        reload=shell_info.reload_command,
        can_configure_automatically=shell_info.can_configure_automatically)
    shell = make_shell(shell_info.name, settings)

    with replace_argument_value(sys, 'stdout',
                                shell.stdout.fileno()):
        how_

# Generated at 2022-06-22 00:51:17.280637
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck import types
    corrected_command = types.CorrectedCommand(
        script='ls /', side_effect=False)
    show_corrected_command(corrected_command)

    corrected_command = types.CorrectedCommand(script='ls -l /',
                                               side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:51:26.714908
# Unit test for function debug
def test_debug():
    import contextlib

    @contextlib.contextmanager
    def capture_stdout(command, *args, **kwargs):
        # pycharm doesn't know six very well, so we have to ignore that
        # noinspection PyUnresolvedReferences
        import StringIO
        # noinspection PyUnresolvedReferences
        import sys
        out, sys.stdout = sys.stdout, StringIO.StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out


    from . import settings
    from . import debug
    with capture_stdout(debug, u'test debug') as output:
        assert u'test debug' in output
        settings.debug = False
        debug(u'test debug')



# Generated at 2022-06-22 00:51:30.469956
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("alias fuck='eval $(thefuck $(fc -ln -1))'") == \
           "alias fuck='eval $(thefuck $(fc -ln -1))' configured successfully!"



# Generated at 2022-06-22 00:51:31.666863
# Unit test for function failed
def test_failed():
    failed(u'пакет')

# Generated at 2022-06-22 00:51:33.127698
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-22 00:51:34.320501
# Unit test for function debug_time
def test_debug_time():
    debug_time(msg)

# Generated at 2022-06-22 00:51:38.361553
# Unit test for function failed
def test_failed():
    import StringIO
    buffer = StringIO.StringIO()
    sys.stderr = buffer
    failed('error')
    assert buffer.getvalue() == '\x1b[31merror\x1b[0m\n'

# Generated at 2022-06-22 00:51:40.004734
# Unit test for function already_configured
def test_already_configured():
    # First we create a test object
    configuration_details = type('obj', (object,), {'reload': 'test'})()
    # We call the function we want to test with the test object
    already_configured(configuration_details)

if __name__ == '__main__':
    test_already_configured()

# Generated at 2022-06-22 00:51:43.241816
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(const.config_reload)

# Generated at 2022-06-22 00:51:49.055688
# Unit test for function already_configured
def test_already_configured():
    expected_output = u"""Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.""".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload=configuration_details.reload)
    return expected_output

# Generated at 2022-06-22 00:51:55.485929
# Unit test for function debug
def test_debug():
    def run(input):
        settings.debug = True
        try:
            sys.stderr.write._mock_captured = input
            debug(u'$test')
        finally:
            settings.debug = False

    assert run(u'debug\n') == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m $test\n'



# Generated at 2022-06-22 00:51:56.526460
# Unit test for function debug
def test_debug():
    assert debug('message') == None


# Generated at 2022-06-22 00:52:00.123981
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert (u"Seems like \x1b[1mfuck\x1b[0m alias isn't configured!"
            == how_to_configure_alias(None))

# Generated at 2022-06-22 00:52:01.939073
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import thefuck.utils
    thefuck.utils.show_corrected_command("ls -a")
    assert True

# Generated at 2022-06-22 00:52:03.717647
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('Test exception')
    except ValueError:
        exception('foo', sys.exc_info())

# Generated at 2022-06-22 00:52:09.185841
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:52:11.644754
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.git import git_show
    rule_failed(git_show, sys.exc_info())



# Generated at 2022-06-22 00:52:14.839026
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    settings.no_colors = True
    assert color('color') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:52:25.709401
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = ('~/.bashrc', '~/.bashrc', '~/.bashrc', 'source ~/.bashrc', True)
    assert (configured_successfully(configuration_details) ==
            u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}source ~/.bashrc{reset} or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload=configuration_details.reload))


# Generated at 2022-06-22 00:52:28.812404
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Boom!')
    except RuntimeError:
        exception('test_exception', sys.exc_info())

# Generated at 2022-06-22 00:52:33.820256
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    ConfigurationDetails = namedtuple('ConfigurationDetails',
                                      'reload can_configure_automatically')
    how_to_configure_alias(ConfigurationDetails('somereload', True))
    how_to_configure_alias(ConfigurationDetails('somereload', False))



# Generated at 2022-06-22 00:52:35.811784
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls -l'
    assert show_corrected_command(corrected_command) == '$ ls -l'



# Generated at 2022-06-22 00:52:47.945455
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from datetime import date
    import thefuck.utils as utils
    import thefuck.shells as shells
    import thefuck.utils as utils
    mock_shell_info = shells.ShellInfo(
        name='test',
        history_file=r'\\\test\test',
        conf_file=r'\\\test\test',
        conf_template=r'\\\test\test',
        prefix='test',
        suffix='test',
        can_modify_alias=False,
        can_modify_script=False)
    mock_configuration_details = utils.ConfigurationDetails(
        "test", r'\\\test\test', r'\\\\test\\test', mock_shell_info, False)
    capture_out, capture_err = capsys.readouterr()
    how_to_configure

# Generated at 2022-06-22 00:52:49.402218
# Unit test for function version
def test_version():
    assert version("a", "b", "c") is None


# Generated at 2022-06-22 00:52:53.976333
# Unit test for function warn
def test_warn():
    try:
        import StringIO
        output = StringIO.StringIO()
        sys.stderr = output
        warn("Title")
        output.seek(0)
        assert output.read() == '[WARN] Title\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-22 00:53:06.187032
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command(corrected_command)
    assert confirm_text(corrected_command) == correct_confirm_text

correct_confirm_text = u'{prefix}\033[1K\r{bold}{script}{reset} {side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'
correct_confirm_text_prefixed = u'{prefix}\033[1K\r{bold}{script}{reset} {side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'

# Generated at 2022-06-22 00:53:09.343068
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    assert settings.no_colors is False
    settings.no_colors = True
    assert color('color') == ''



# Generated at 2022-06-22 00:53:11.968981
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(corrected_command='fuck') == const.USER_COMMAND_MARK + 'fuck'

# Generated at 2022-06-22 00:53:18.270735
# Unit test for function already_configured
def test_already_configured():
    assert 1 == 2

# Generated at 2022-06-22 00:53:19.513443
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('', '')


# Generated at 2022-06-22 00:53:22.363276
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    assert configured_successfully(Shell(
        'shell', 'reload', False, False)) == None

# Generated at 2022-06-22 00:53:28.058882
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time
    import random

    with mock.patch('thefuck.utils.debug') as debug:
        with debug_time('some debug message'):
            time.sleep(random.random())
        debug.assert_called_once_with(
            'some debug message took: {}'.format(time.time()))

# Generated at 2022-06-22 00:53:33.047859
# Unit test for function already_configured
def test_already_configured():
    # Create class
    class ConfigurationDetails():
        def __init__(self):
            self.reload = 'reload'
    # Fail if configuration details is None
    assert already_configured(None) != 0
    # Pass
    configuration_details = ConfigurationDetails()
    assert already_configured(configuration_details) == 0


# Generated at 2022-06-22 00:53:40.228369
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import wrap_streams
    from . import shell
    from . import conf
    from . import utils
    from . import __version__
    with wrap_streams('utf-8'):
        how_to_configure_alias(shell.get_shell_info().configuration_details)
        already_configured(shell.get_shell_info().configuration_details)
        configured_successfu

# Generated at 2022-06-22 00:53:52.520922
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """This unit test is to check the content and format
    of how_to_configure_alias function

    Args: The output when a user runs The Fuck without
    configuring it.

    Returns: The assert failed or passed.
    """

    # The output when a user runs The Fuck without configuring it.
    configuration_details = {
        u'bold': '',
        u'path': u'~/.config/fish/config.fish',
        u'reload': u'source ~/.config/fish/config.fish',
        u'content': u'eval (thefuck --alias fuck)',
        u'can_configure_automatically': True,
    }

    # The expected output when a user runs The fuck without configuring it.

# Generated at 2022-06-22 00:53:53.463552
# Unit test for function failed
def test_failed():
    failed('some')



# Generated at 2022-06-22 00:53:56.712217
# Unit test for function warn
def test_warn():
    # Arrange
    title = "Hello World"
    expected = u'[WARN] Hello World\n'
    stdout = sys.stderr

    # Act
    with stdout_as_string() as actual:
        warn(title)

    # Assert
    assert expected == actual

# Generated at 2022-06-22 00:53:58.912631
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stderr', StringIO()) as err:
        failed(u'foo')
        assert len(err.getvalue()) is not None



# Generated at 2022-06-22 00:54:11.433862
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from io import StringIO
    from .types import Command

    out = StringIO()
    sys.stdout = out
    show_corrected_command(Command(script='ls', side_effect=False))
    out.seek(0)
    assert out.read() == u'\x1b[33m$\x1b[0m\x1b[1mls\x1b[0m\n'


# Generated at 2022-06-22 00:54:12.298784
# Unit test for function configured_successfully
def test_configured_successfully():
    assert not configured_successfully('')

# Generated at 2022-06-22 00:54:13.674139
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('command')



# Generated at 2022-06-22 00:54:26.018554
# Unit test for function confirm_text
def test_confirm_text():
    import unittest
    import StringIO
    import sys

    class MockCorrectedCommand:
        script = 'script'
        side_effect = True

    output = StringIO.StringIO()

    class TestConfirmText(unittest.TestCase):

        def test_confirm_text(self):
            sys.stderr = output
            confirm_text(MockCorrectedCommand())
            output.seek(0)
            first_line = output.readline()
            second_line = output.readline()
            self.assertEqual(first_line, '\033[1K\r')

# Generated at 2022-06-22 00:54:33.030599
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class TestType(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def __iter__(self):
            return self

        def next(self):
            return self._asdict()

    how_to_configure_alias(TestType(
        content='content', path='path',
        reload='reload', can_configure_automatically=True))



# Generated at 2022-06-22 00:54:42.547252
# Unit test for function exception
def test_exception():
    exc_info = (Exception('TestException'),
                Exception('TestException'),
                Exception('TestException'))
    expected_output = u"""\
[WARN] Rule TestRule:
--------------------------------------------------------------------------------

Traceback (most recent call last):
  File "[Errno 32] Broken pipe", line 1, in <module>
Exception: TestException

----------------------------\
"""
    output = ''
    try:
        raise
    except:
        exception('Rule TestRule',sys.exc_info())
    output = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__
    assert output == expected_output

# Generated at 2022-06-22 00:54:54.545943
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from datetime import datetime
    from thefuck.conf.definition import ConfigurationDetails
    from thefuck.conf.shells import shell

    with open('test_configure_alias.txt', 'w') as f:
        f.write('')  # clear file

    how_to_configure_alias(ConfigurationDetails(
        'content', 'path', 'reload', True, datetime(2015, 10, 6)))

    with open('test_configure_alias.txt', 'r') as f:
        assert f.read() == const.HOW_TO_CONFIGURE_ALIAS_MESSAGE.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            content='content',
            path='path',
            reload='reload') + const

# Generated at 2022-06-22 00:54:57.592872
# Unit test for function rule_failed
def test_rule_failed():
    print("unit test for function rule_failed")
    class A:
        name = 'rule'

    rule_failed(A(), ('test', 'test', 'test'))

# Generated at 2022-06-22 00:55:00.230346
# Unit test for function color
def test_color():
    from colorama import Fore

    assert color(Fore.BLACK) == Fore.BLACK
    assert color(Fore.BLACK) == ''

# Generated at 2022-06-22 00:55:10.657042
# Unit test for function version
def test_version():
    v_list = []

    # Use StringIO to capture the value of sys.stderr
    import StringIO
    old_stderr = sys.stderr
    sys.stderr = mystdout = StringIO.StringIO()

    version('3.8', '3.5.1', 'Bash')
    v_list[:] = mystdout.getvalue().splitlines()

    assert len(v_list) == 1
    assert v_list[0] == 'The Fuck 3.8 using Python 3.5.1 and Bash'

    sys.stderr.close()
    sys.stderr = old_stderr

# Generated at 2022-06-22 00:55:25.870352
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from unittest import TestCase
    from .conf import Config
    from .utils import DEBUG

    DEBUG = False

    class TestDebugTime(TestCase):
        def setUp(self):
            self.config = Config().load({'debug': False})

        def test_debug_time(self):
            with debug_time('First'):
                with debug_time('Second'):
                    with debug_time('Third'):
                        pass
            with debug_time('Fourth'):
                with debug_time('Fifth'):
                    pass
            self.assertTrue(True)

    class TestDebugTimeWithDebug(TestCase):
        def setUp(self):
            self.config = Config().load({'debug': True})


# Generated at 2022-06-22 00:55:28.979175
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == '\x1b[34m'
    assert color(colorama.Fore.BLUE) == ''

# Generated at 2022-06-22 00:55:30.241252
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debug_time'):
        pass

# Generated at 2022-06-22 00:55:32.428608
# Unit test for function confirm_text
def test_confirm_text():
    # Confirm text is printed to stderr
    assert sys.stderr.write('test') == 4

# Generated at 2022-06-22 00:55:36.337323
# Unit test for function confirm_text
def test_confirm_text():
    import re
    corrected_command = mock.Mock(script='script', side_effect=True)
    confirm_text(corrected_command)
    sys.stderr.flush()
    sys.stderr.getvalue().rstrip() == (
        "> (script) (+side effect) [enter/↑/↓/ctrl+c]")

# Generated at 2022-06-22 00:55:44.824054
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    config_details = ('~/.bashrc', 'source ~/.thefuck/alias')
    assert how_to_configure_alias(config_details) == \
        """Seems like fuck alias isn't configured!

        Please put source ~/.thefuck/alias in your ~/.bashrc and apply 
        changes with source ~/.bashrc or restart your shell.

        Or run fuck a second time to configure it automatically.

        More details - https://github.com/nvbn/thefuck#manual-installation"""


# Generated at 2022-06-22 00:55:46.217453
# Unit test for function debug
def test_debug():
    u'sys.stderr.write should be called'



# Generated at 2022-06-22 00:55:54.216667
# Unit test for function configured_successfully
def test_configured_successfully():
    def assert_configured_successfully(reload_cmd):
        from io import StringIO
        from collections import namedtuple

        io = StringIO()

        with io, io.redirect_stdout():
            configured_successfully(namedtuple('Config', ['reload'])(reload_cmd))

        return io.getvalue()

    assert 'fuck alias configured successfully' in assert_configured_successfully('reload')
    assert 'fuck alias configured successfully' in assert_configured_successfully('reload --all')

# Generated at 2022-06-22 00:55:54.981899
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.5)

# Generated at 2022-06-22 00:55:56.028092
# Unit test for function already_configured
def test_already_configured():
    already_configured('test')

# Generated at 2022-06-22 00:56:03.744198
# Unit test for function already_configured
def test_already_configured():
    assert(already_configured({'reload': 'reload'}) == None)



# Generated at 2022-06-22 00:56:05.491503
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        print("test")


# Generated at 2022-06-22 00:56:09.589559
# Unit test for function debug_time
def test_debug_time():
    # _reset_debug_log()
    # with debug_time('test'):
    #     time.sleep(0.1)
    # assert debug_log() == 'test took: 0:00:00.001000'
    pass

# Generated at 2022-06-22 00:56:11.118846
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'Test the time'):
        pass

# Generated at 2022-06-22 00:56:12.063433
# Unit test for function warn
def test_warn():
    warn('Test')


# Generated at 2022-06-22 00:56:23.669694
# Unit test for function already_configured
def test_already_configured():
    output = ""
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    old_stdout = sys.stdout
    result = """Seems like \x1b[1mfuck\x1b[22m alias already configured!
For applying changes run \x1b[1m. ~/.bashrc\x1b[22m or restart your shell."""
    sys.stdout = StringIO()
    already_configured(const.ConfigurationDetails('. ~/.bashrc', '', True))
    output = sys.stdout.getvalue().strip()
    sys.stdout = old_stdout
    assert(output == result)

# Generated at 2022-06-22 00:56:28.126198
# Unit test for function version
def test_version():
    thefuck_version = '3.5'
    python_version = '2.7'
    shell_info = 'Shell not found'

    sys.stderr.write(
        u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                       python_version,
                                                       shell_info))
    sys.stderr.flush()


# Generated at 2022-06-22 00:56:35.255814
# Unit test for function color
def test_color():
    assert color(u'привет') == u'привет'
    assert color(u'привет') != u''
    settings.no_colors = True
    assert color(u'привет') == u''
    assert color(u'привет') != u'привет'
    settings.no_colors = False

# Generated at 2022-06-22 00:56:37.117840
# Unit test for function already_configured
def test_already_configured():
     already_configured({
         'reload': 'source ~/.bashrc'
     })

# Generated at 2022-06-22 00:56:38.249076
# Unit test for function debug
def test_debug():
    assert debug('text') is None

# Generated at 2022-06-22 00:56:46.058346
# Unit test for function rule_failed
def test_rule_failed():
    from .new_history import Rule
    from .types import Command
    Rule.name = 'new_history'
    rule_failed(Rule, Command)

# Generated at 2022-06-22 00:56:52.766390
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script="cd /etc",
        side_effect=' (+side effect)',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))
    #output: [commands]cd /etc +side effect

# Generated at 2022-06-22 00:56:56.587780
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLACK + colorama.Style.BRIGHT) == colorama.Fore.BLACK + colorama.Style.BRIGHT
    assert color(colorama.Fore.BLACK + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:57:07.967262
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.range import Range
    from .utils import get_closest
    from .utils import unicode

    rule_failed(Range(get_closest), sys.exc_info())
    rule_failed(Range(get_closest, True), sys.exc_info())
    rule_failed(Range(get_closest, True, u'c'), sys.exc_info())
    rule_failed(Range(get_closest, True, u'c'.encode()), sys.exc_info())
    rule_failed(Range(get_closest, True, u'{load}'), sys.exc_info())
    rule_failed(Range(get_closest, True, u'{load}'.format(load=unicode)), sys.exc_info())

# Generated at 2022-06-22 00:57:09.205148
# Unit test for function version
def test_version():
    assert 'Python' in version('', '', '')

# Generated at 2022-06-22 00:57:20.523452
# Unit test for function version
def test_version():
    # Example of output with python version, shell info and the fuck version
    version_output = u'The Fuck 3.5.dev0 using Python 2.7.13 (default, Apr 28 2017, 14:15:59) \n[GCC 5.4.0 20160609] and ShellInfo(shell_name=Bash, shell_version=4.2.53(1)-release)\n'  # noqa
    assert version(thefuck_version='3.5.dev0', python_version='2.7.13 (default, Apr 28 2017, 14:15:59) \n[GCC 5.4.0 20160609]', shell_info='ShellInfo(shell_name=Bash, shell_version=4.2.53(1)-release)') == version_output  # noqa



# Generated at 2022-06-22 00:57:29.222094
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from datetime import datetime
    from .conf import settings
    settings.no_colors = False
    failed('msg')
    out = sys.stderr.getvalue()
    assert out == u'\x1b[31mmsg\x1b[0m\n'
    sys.stderr = StringIO()

    settings.no_colors = True
    failed('msg')
    out = sys.stderr.getvalue()
    assert out == u'msg\n'



# Generated at 2022-06-22 00:57:34.254188
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from StringIO import StringIO
    import contextlib
    output = StringIO()
    with contextlib.redirect_stdout(output):
        with debug_time('asd'):
            pass
    assert len(output.getvalue()) > len('DEBUG: asd took: ')

# Generated at 2022-06-22 00:57:37.072535
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.ConfigurationDetails('zsh', '~/.zshrc',
                                              'source ~/.zshrc', True)) == None


# Generated at 2022-06-22 00:57:43.522708
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch

    with patch('thefuck.shells.ansi_safe_wcwidth', lambda x: len(x)) as debug:
        with debug_time('msg'):
            pass
    debug.assert_called_once_with(u'{} took: {}'.format('msg',
                                                        timedelta(0)))

# Generated at 2022-06-22 00:58:01.365515
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(
        configuration_details=None) == (
            u"Seems like {}fuck{} alias already configured!\n"
            u"For applying changes run {}{}{} or restart your shell.".format(
                color(colorama.Style.BRIGHT),
                color(colorama.Style.RESET_ALL),
                color(colorama.Style.BRIGHT),
                "None",
                color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-22 00:58:03.393577
# Unit test for function version
def test_version():
    version('2.0', '3.5', 'sh 1.2.3')


# Generated at 2022-06-22 00:58:04.957381
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('msg')



# Generated at 2022-06-22 00:58:08.063005
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-22 00:58:17.275935
# Unit test for function configured_successfully
def test_configured_successfully():
    from mock import patch
    with patch('thefuck.shells.generic.print') as mocked_print:
        configured_successfully({'a': 'b'})
        mocked_print.assert_called_once_with(
            u"{bold}fuck{reset} alias configured successfully!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload={'a': 'b'}.get('reload')))


# Generated at 2022-06-22 00:58:18.932930
# Unit test for function failed
def test_failed():
    failed(u'failed')



# Generated at 2022-06-22 00:58:24.238980
# Unit test for function failed
def test_failed():
    from contextlib import redirect_stderr
    from io import StringIO

    err = StringIO()
    with redirect_stderr(err):
        failed('mistake')

    assert err.getvalue() == '\x1b[31mmistake\x1b[0m\n'

# Generated at 2022-06-22 00:58:25.243430
# Unit test for function debug
def test_debug():
    debug("debug")



# Generated at 2022-06-22 00:58:27.020946
# Unit test for function debug
def test_debug():
    from test.utils import frange
    for i in frange(1, 100000):
        debug(u"Hello world!")

# Generated at 2022-06-22 00:58:40.300500
# Unit test for function version
def test_version():
    class CaptureStdoutStderr(object):
        """
        A context manager for doing a "deep diversion" of stdout and stderr in
        Python, i.e. redirection even if the caller has replaced sys.stdout with
        their own stream.
        """

        def __init__(self):
            # Open a couple of null files
            self.null_files = [open(os.devnull, mode) for mode in ('w', 'wb')]
            # Save the actual stdout (1) and stderr (2) file descriptors.
            self.save_fds = (os.dup(1), os.dup(2))



# Generated at 2022-06-22 00:59:03.902116
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    import sys
    # bypassing the sys.modules
    sys.modules.pop("thefuck.shells.bash")
    sys.modules.pop("thefuck.shells.fish")
    sys.modules.pop("thefuck.shells.zsh")
    sys.modules.pop("thefuck.shells.default")
    sys.modules.pop("thefuck.rules")
    sys.modules.pop("thefuck.utils")
    sys.modules.pop("thefuck.conf")
    sys.modules.pop("thefuck.const")
    from .utils import rule_failed
    from .conf import Settings
    from .rules.git_dirty import match
    from .rules.git_dirty import get_new_command
    from .rules.git_dirty import enabled_by_default
    import traceback, colorama

# Generated at 2022-06-22 00:59:11.197584
# Unit test for function version
def test_version():
    from mock import patch

    def reset_stdout():
        sys.stderr = sys.__stderr__

    with patch('sys.stderr') as stdout:
        version('3.7', '3.6.3', 'ZSH 5.2')
        assert stdout.write.call_args[0][0] == u'The Fuck 3.7 using Python 3.6.3 and ZSH 5.2\n'
        reset_stdout()

# Generated at 2022-06-22 00:59:18.304378
# Unit test for function debug_time
def test_debug_time():
    import time
    import os
    import tempfile
    import unittest

    try:
        with open(os.devnull, "w") as dev_null:
            std_err = os.dup(2)
            os.dup2(dev_null.fileno(), 2)

            with debug_time("Seeing is believing"):
                time.sleep(0.1)

            os.dup2(std_err, 2)

            fd, name = tempfile.mkstemp()
            with open(name, "r") as f:
                output = f.read()
                f.close()
            os.remove(name)
    except IOError:
        print("Can't open /dev/null")
    else:
        unittest.TestCase().assertEqual(output[:5], "DEBUG")


# Generated at 2022-06-22 00:59:19.317078
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-22 00:59:27.506200
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = class_corrected_command()
    corrected_command.script = "git push origin master"
    corrected_command.side_effect = False
    #import pdb; pdb.set_trace()
    assert "git push origin master\n" == show_corrected_command(corrected_command)

    corrected_command.script = "git push origin master"
    corrected_command.side_effect = True
    assert "git push origin master (+side effect)\n" == show_corrected_command(corrected_command)


# Generated at 2022-06-22 00:59:29.736165
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully.__doc__ == 'configured_successfully(configuration_details)'


# Generated at 2022-06-22 00:59:30.819482
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('thefuck')

# Generated at 2022-06-22 00:59:32.035685
# Unit test for function already_configured
def test_already_configured():
    already_configured(1,2)

# Generated at 2022-06-22 00:59:35.066531
# Unit test for function warn
def test_warn():
    warn('warn message') == u'\x1b[41m[WARN] warn message\x1b[0m\n'



# Generated at 2022-06-22 00:59:36.625280
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(lambda: '', ('', '', ''))

# Generated at 2022-06-22 01:00:04.568843
# Unit test for function confirm_text
def test_confirm_text():
    prev = sys.stderr
    sys.stderr = sys.stdout
    try:
        corrected_command = corrected_command = corrected_command.CorrectedCommand('ls -asl', True)
        confirm_text(corrected_command)
    finally:
        sys.stderr = prev


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 01:00:07.946733
# Unit test for function debug
def test_debug():
    import sys
    from io import StringIO
    from contextlib import contextmanager

    saved_stderr = sys.stderr
    output = StringIO()
    try:
        sys.stderr = output
        with debug_time('some time'):
            pass

        debug('some debug')

    finally:
        sys.stderr = saved_stderr
    assert output.getvalue().startswith('\x1b[1mdebug:\x1b[0m ')



# Generated at 2022-06-22 01:00:20.037679
# Unit test for function failed
def test_failed():
    import sys
    import mock
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        failed('{} failed {}')
        output = err.getvalue().strip()

# Generated at 2022-06-22 01:00:32.536404
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    bash = Bash()
    bash.script = 'ls -l'
    assert confirm_text(bash) == u'\x1b[1K\r\x1b[1m\x1b[1mls -l\x1b[0m \x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'
    bash.script = 'ls -la'

# Generated at 2022-06-22 01:00:38.141097
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,), {})
    corrected_command.script = 'git log'
    corrected_command.side_effect = True
    confirm_text(corrected_command)
    corrected_command.side_effect = False
    confirm_text(corrected_command)
    corrected_command.side_effect = True
    confirm_text(corrected_command)
    corrected_command.side_effect = False
    confirm_text(corrected_command)
    corrected_command.side_effect = False
    confirm_text(corrected_command)
    corrected_command.side_effect = True
    confirm_text(corrected_command)

# Generated at 2022-06-22 01:00:45.347289
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple('configuration_details', ['path', 'content', 'can_configure_automatically',
                                                                 'reload'])
    configuration_details.path = '~/.bashrc'
    configuration_details.content = "eval $(thefuck --alias)"
    configuration_details.can_configure_automatically = True
    configuration_details.reload = "source ~/.bashrc"
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-22 01:00:46.450421
# Unit test for function color
def test_color():
    assert color('red') == ''

# Generated at 2022-06-22 01:00:50.116816
# Unit test for function configured_successfully
def test_configured_successfully():
    class FakeConfig():
        def reload():
            return "reload"

    configured_successfully(FakeConfig())


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 01:00:56.241402
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('git comit -m "Test"') == "git comit -m \"Test\""
    assert show_corrected_command('git comit -m "Test"\n') == "git comit -m \"Test\"\n"
    assert show_corrected_command(4) == 4
    assert show_corrected_command(4.0) == 4.0