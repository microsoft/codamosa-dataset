

# Generated at 2022-06-22 00:51:00.023898
# Unit test for function color
def test_color():
    assert color('color') == ''
    settings.no_colors = False
    assert color('color') == 'color'

# Generated at 2022-06-22 00:51:09.009920
# Unit test for function exception
def test_exception():
    try:
        raise TypeError()
    except:
        import StringIO
        buf = StringIO.StringIO()
        exception('Test exception', sys.exc_info())
        output = buf.getvalue()
        assert "[WARN] Test exception:" in output
        assert "TypeError()" in output
        assert "----------------------------" in output

        buf.truncate(0)
        buf.seek(0)
        exception('Test exception', None)
        output = buf.getvalue()
        assert "[WARN] Test exception:" in output
        assert "----------------------------" in output


# Generated at 2022-06-22 00:51:13.777844
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import _get_test_settings
    _get_test_settings()  # hackish reset of settings
    from types import SimpleNamespace

    corrected_command = SimpleNamespace(
        script=u'node .',
        side_effect=False)
    confirm_text(corrected_command)



# Generated at 2022-06-22 00:51:15.877454
# Unit test for function already_configured
def test_already_configured():
    assert already_configured is not None, "Define a function 'already_configured'"



# Generated at 2022-06-22 00:51:17.333393
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("configuration_details")



# Generated at 2022-06-22 00:51:18.662027
# Unit test for function already_configured
def test_already_configured():
    already_configured(".bash_profile")


# Generated at 2022-06-22 00:51:27.325697
# Unit test for function version
def test_version():
    from . import __version__
    from .utils import get_shell_info
    import sys
    import types
    import mock

    orig_stderr = sys.stderr
    mock_stderr = types.FileType(
        sys.stderr.fileno(),
        sys.stderr.mode,
        sys.stderr.name,
        'strict',
        sys.stderr.closefd)


# Generated at 2022-06-22 00:51:35.125461
# Unit test for function version
def test_version():
    """Unit test for function version"""
    sys.stderr = open('/tmp/thefuck.log', 'w')
    try:
        version('0.1', '2.7.12-final-0', 'test')
        assert open('/tmp/thefuck.log', 'r').read() == \
            'The Fuck 0.1 using Python 2.7.12-final-0 and test\n'
    finally:
        sys.stderr.close()

# Generated at 2022-06-22 00:51:36.336901
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # input
    corrected_command = 'ls'

    show_corrected_command(corrected_command)

    # output
    assert_equals(corrected_command, 'ls')



# Generated at 2022-06-22 00:51:40.606388
# Unit test for function failed
def test_failed():
    from io import StringIO
    from . import utils
    stream = StringIO()
    utils.sys.stderr = stream
    failed('Test')
    assert stream.getvalue() == u'\x1b[31mTest\x1b[0m\n'

# Generated at 2022-06-22 00:51:47.457979
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = const.ConfigurationDetails(reload=u'reload')
    assert u"fuck alias configured successfully!\nFor applying changes run reload or restart your shell." \
           == configured_successfully(configuration_details)

# Generated at 2022-06-22 00:51:49.699547
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('fuck') == 'The Fuck: fuck [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:51:52.821596
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import doctest
    failure_count, test_count = doctest.testmod()
    assert test_count > 0
    assert failure_count == 0

# Generated at 2022-06-22 00:52:05.056405
# Unit test for function exception

# Generated at 2022-06-22 00:52:10.923200
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object, ), {
        'script': u'fuck',
        'side_effect': False,
    })
    try:
        confirm_text(corrected_command)
    except UnicodeEncodeError:
        pass  # tty is not able to decode output, it's normal

# Generated at 2022-06-22 00:52:13.574993
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    with debug_time('test_debug_time') as debug_time:
        debug_time.join()

# Generated at 2022-06-22 00:52:14.837962
# Unit test for function warn
def test_warn():
    warn(u'check')



# Generated at 2022-06-22 00:52:21.374676
# Unit test for function failed
def test_failed():
    from . import tests
    with tests.mock.patch('sys.stderr') as mock_stderr:
        failed(u'Миша')
    mock_stderr.write.assert_called_once_with(
        u'{red}Миша{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL)))



# Generated at 2022-06-22 00:52:23.674384
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()
    # Todo: write unit test

# Generated at 2022-06-22 00:52:35.162977
# Unit test for function version
def test_version():
    from .shells.fish import FishShell
    from .shells.bash import BashShell
    from .shells.zsh import ZshShell
    from .shells.xonsh import XonshShell
    from .shells.pwsh import PwshShell

    shells = [FishShell(), BashShell(), ZshShell(), XonshShell()]
    for shell in shells:
        version(thefuck_version='3.1', python_version='2.7', shell_info=shell)

    # test if it works when we have a type error in the shell info
    version(thefuck_version='3.1', python_version='2.7',
            shell_info=type('Shell', (), {}))

# Generated at 2022-06-22 00:52:48.105041
# Unit test for function color
def test_color():
    colorama.init(strip=False)
    assert not settings.no_colors
    assert u'\x1b[31m\x1b[40m\x1b[1m' == color(colorama.Back.RED +
                                               colorama.Fore.WHITE +
                                               colorama.Style.BRIGHT)
    assert u'\x1b[0m' == color(colorama.Style.RESET_ALL)
    settings.no_colors = True
    assert u'' == color(colorama.Back.RED + colorama.Fore.WHITE +
                        colorama.Style.BRIGHT)
    assert u'' == color(colorama.Style.RESET_ALL)

# Generated at 2022-06-22 00:52:49.936811
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand

    show_corrected_command(CorrectedCommand('ls', None))

# Generated at 2022-06-22 00:52:52.835112
# Unit test for function already_configured
def test_already_configured():
    class Mock(object):
        def __init__(self):
            pass

        @property
        def reload(self):
            return 'reload.sh'
    already_configured(Mock())

# Generated at 2022-06-22 00:52:59.389267
# Unit test for function failed
def test_failed():
    import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    failed(u'Стало плохо')
    assert sys.stderr.getvalue() == u'\x1b[91mСтало плохо\x1b[0m\n'
    sys.stderr = stderr



# Generated at 2022-06-22 00:53:02.910543
# Unit test for function exception
def test_exception():

    class TestError(Exception):
        pass

    try:
        raise TestError(u'unicode')
    except TestError:
        exception(u'Rule confirmation', sys.exc_info())


# Generated at 2022-06-22 00:53:13.976295
# Unit test for function exception
def test_exception():
    import io
    import sys
    import traceback

    try:
        raise RuntimeError('test')
    except RuntimeError:
        exc_info = sys.exc_info()

    exc_type = exc_info[0]
    exc_value = exc_info[1]
    exc_traceback = exc_info[2]
    exc_tb_info = traceback.extract_tb(exc_traceback)

    with io.open('/dev/null', 'w') as out:
        def exception(*_):
            out.write('exception')

        sys.stderr.write = exception
        exception('title', exc_info)

    assert (exc_value.args[0]
            in out.getvalue())

# Generated at 2022-06-22 00:53:16.605677
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN
    assert color('') == ''



# Generated at 2022-06-22 00:53:19.268175
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import exec_script
    exec_script('echo 123')
    assert confirm_text.__doc__ == u'The Fuck alias'

# Generated at 2022-06-22 00:53:28.469021
# Unit test for function rule_failed
def test_rule_failed():
    """
    Test if rule_failed function works properly
    """
    try:
        class RuleMock(Rule):
            name = 'fail'
            def match(self, command):
                return True
            def get_new_command(self, args):
                raise Exception('Fails')

        rule = RuleMock()
        rule_failed(rule, sys.exc_info())
    except:
        # If test fails then exception will be raised
        assert False
    else:
        # If test is successful then no exception will be raised
        assert True


# Generated at 2022-06-22 00:53:31.763085
# Unit test for function debug_time
def test_debug_time():
    sys.stderr = StringIO()
    with debug_time('test_for_debug_time'):
        pass
    assert sys.stderr.getvalue().startswith('DEBUG:')



# Generated at 2022-06-22 00:53:37.433433
# Unit test for function version
def test_version():
    import subprocess
    version('3.1', '2.7.10', 'Shell(3.1)')


# Generated at 2022-06-22 00:53:49.647001
# Unit test for function failed
def test_failed():
    from contextlib import contextmanager
    from io import StringIO
    from textwrap import dedent

    @contextmanager
    def _captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    expected = dedent('\n'.join([
        '',
        '{red}Test Message{reset}',
        ''
    ])).format(
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:53:51.362239
# Unit test for function warn
def test_warn():
    warn(u'Hello, world!')



# Generated at 2022-06-22 00:53:55.025382
# Unit test for function version
def test_version():
    sys.stderr.write(
        u'The Fuck {} using Python {} and {}\n'.format(3.1,
                                                       3.1,
                                                       'shell'))

if __name__ == '__main__':
    test_version()

# Generated at 2022-06-22 00:53:59.042700
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('find /etc/passwd') == '[{}]find /etc/passwd'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-22 00:54:00.684794
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details='fuck')


# Generated at 2022-06-22 00:54:05.633169
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug(u'test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')



# Generated at 2022-06-22 00:54:11.190841
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED + colorama.Fore.BLUE) == (colorama.Fore.RED + colorama.Fore.BLUE)
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Fore.RED + colorama.Fore.BLUE) == ''

# Generated at 2022-06-22 00:54:12.599838
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-22 00:54:22.144809
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, path, content, reload, can_configure_automatically):
            self.path = path
            self.content = content
            self.reload = reload
            self.can_configure_automatically = can_configure_automatically

    configuration_details = ConfigurationDetails(
        path=u'~/.config/fish/conf.d/fuck.fish',
        content=u'Fuck',
        reload=u'fuck --alias',
        can_configure_automatically=True)

    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:54:27.323660
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(
        'test') == u'fuck test [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:54:30.192964
# Unit test for function color
def test_color():
    class C(object):
        def __str__(self):
            return 'red'
    assert color(C()) == color(colorama.Fore.RED)

# Generated at 2022-06-22 00:54:33.666633
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    settings.debug = False
    configuration_details = const.ConfigurationDetails(
        '~/.config/fish/config.fish',
        'eval (thefuck --alias)',
        True,
        'source ~/.config/fish/config.fish')
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:54:40.778756
# Unit test for function warn
def test_warn():
    from mock import call

    test = u'this is a test'
    sys.stderr = mock_stderr = MagicMock()

    warn(test)
    mock_stderr.write.assert_has_calls([
        call(u'\x1b[41m\x1b[97m\x1b[1m[WARN] {title}\x1b[0m\n'.format(
            title=test))])



# Generated at 2022-06-22 00:54:48.616057
# Unit test for function warn
def test_warn():
    from . import mock

    warn(u'test warning')
    assert mock.sys.stderr.write.call_count == 1
    assert mock.sys.stderr.write.call_args[0] == (
        u'{warn}[WARN] test warning{reset}\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL)),)



# Generated at 2022-06-22 00:54:57.769949
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        msg = u''
        exception(u'Rule', sys.exc_info())
        for line in sys.stderr.getvalue().splitlines():
            msg += u'\n' + line
        assert (
            msg == u'\n[WARN] Rule:RuntimeError'
            u'\nTraceback (most recent call last):'
            u'\n  File "tests/test_output.py", line 145, in test_exception'
            u'\n    raise RuntimeError()'
            u'\nRuntimeError')



# Generated at 2022-06-22 00:55:03.261473
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.reset_default_settings()
    assert color('') == color(colorama.Style.RESET_ALL)
    assert color('test') == 'test'

    settings.no_colors = True
    assert color('') == ''
    assert color('test') == 'test'



# Generated at 2022-06-22 00:55:04.449665
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:55:05.743055
# Unit test for function warn
def test_warn():
    warn(u'title')



# Generated at 2022-06-22 00:55:16.977393
# Unit test for function debug
def test_debug():
    import tests
    from mock import patch

    with patch('sys.stderr') as stderr:
        tests.set_env(thefuck_debug='true')
        debug('msg')
        stderr.write.assert_called_with(u'{blue}{bold}DEBUG:{reset} msg\n'.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT)))

    with patch('sys.stderr') as stderr:
        tests.set_env(thefuck_debug='')
        debug('msg')
        assert stderr.write.called is False

# Generated at 2022-06-22 00:55:27.791428
# Unit test for function confirm_text
def test_confirm_text():
    from six.moves import input
    confirm_text(Script('command', side_effect=False, examples=None))
    input()
    confirm_text(Script('command', side_effect=True, examples=None))
    input()
    confirm_text(Script('command', side_effect=False, examples=None))
    input()
    confirm_text(Script('command', side_effect=True, examples=None))
    input()

# Generated at 2022-06-22 00:55:32.879142
# Unit test for function failed
def test_failed():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    failed('test')
    sys.stderr = sys.__stderr__
    assert output.getvalue() == u'\x1b[31mtest\x1b[0m\n'

# Generated at 2022-06-22 00:55:33.520341
# Unit test for function debug
def test_debug():
    debug('hi')

# Generated at 2022-06-22 00:55:39.221496
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(['git ', 'ls-files', ' -o', ' --directory',
                         ' --exclude-standard']) == (
        'git ls-files -o  --directory  --exclude-standard '
        '[enter/↑/↓/ctrl+c]')



# Generated at 2022-06-22 00:55:45.027973
# Unit test for function version
def test_version():
    import StringIO
    buf = StringIO.StringIO()
    stdout = sys.stdout
    sys.stdout = buf
    version('1.2.3', '2.7.13', 'fish 2.2.0')
    sys.stdout = stdout
    assert buf.getvalue() == 'The Fuck 1.2.3 using Python 2.7.13 and fish 2.2.0\n'



# Generated at 2022-06-22 00:55:46.394202
# Unit test for function confirm_text
def test_confirm_text():
    import getpass
    assert confirm_text(None, "test", getpass.getuser())

# Generated at 2022-06-22 00:55:47.533007
# Unit test for function version
def test_version():
    assert version('a', 'b', 'c') == None

# Generated at 2022-06-22 00:55:50.491262
# Unit test for function failed
def test_failed():
    assert failed(u'Test message') == '\x1b[31mTest message\x1b[0m\n'


# Generated at 2022-06-22 00:55:53.009827
# Unit test for function version
def test_version():
    assert version('3.0', '2.7', 'bash') == 'The Fuck 3.0 using Python 2.7 and bash\n'



# Generated at 2022-06-22 00:55:58.514403
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Check that unicode command is displayed correctly
    """
    corrected_command = const.CorrectedCommand(u'ls --ignore-case', False)
    show_corrected_command(corrected_command)
    assert(sys.stderr.getvalue() == u'{}ls --ignore-case\n'.format(
        const.USER_COMMAND_MARK))


# Generated at 2022-06-22 00:56:13.147872
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules import Rule
    ru = Rule(
        name='test',
        match='test',
        get_new_command='test',
        enabled_by_default=True
    )

# Generated at 2022-06-22 00:56:14.776383
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-22 00:56:17.727795
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test'):
        pass

    assert datetime.now() - started

# Generated at 2022-06-22 00:56:21.575957
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == '\x1b[1m'
    assert color(colorama.Style.RESET_ALL) == '\x1b[0m'

# Generated at 2022-06-22 00:56:25.545350
# Unit test for function rule_failed
def test_rule_failed():
    class TestRule(object):
        @property
        def name(self):
            return 'test'
    rule = TestRule()
    try:
        raise Exception
    except:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:56:26.139560
# Unit test for function failed
def test_failed():
    failed('')

# Generated at 2022-06-22 00:56:28.381404
# Unit test for function confirm_text
def test_confirm_text():
    code = 'ls /'
    show_corrected_command(code)

# Generated at 2022-06-22 00:56:33.578556
# Unit test for function version
def test_version():
    thefuck_version = '3.0'
    python_version = '3.5'
    shell_info = 'bash'
    expected = 'The Fuck 3.0 using Python 3.5 and bash\n'
    assert version(thefuck_version, python_version, shell_info) == expected

# Generated at 2022-06-22 00:56:35.854427
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        return exception('test_title', sys.exc_info())

# Generated at 2022-06-22 00:56:37.963746
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        import time
        time.sleep(0.5)

# Generated at 2022-06-22 00:56:42.633811
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details=None) is None

# Generated at 2022-06-22 00:56:51.238826
# Unit test for function version
def test_version():
    from StringIO import StringIO
    from .. import __version__
    from . import (_get_python_version, _get_shell_info)
    stream = StringIO()
    sys.stderr = stream
    version(__version__, _get_python_version(), _get_shell_info())
    sys.stderr = sys.__stderr__
    assert stream.getvalue() == (
        'The Fuck {} using Python {} and {}\n'.format(
            __version__, _get_python_version(), _get_shell_info())
    )

# Generated at 2022-06-22 00:57:02.587159
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import load_settings_from_file
    from unittest import TestCase
    import mock
    import tempfile

    class DebugTest(TestCase):
        def setUp(self):
            self.temp_file = tempfile.NamedTemporaryFile()
            self.addCleanup(self.temp_file.close)
            with open(self.temp_file.name, 'w') as settings_file:
                settings_file.write(u'[settings]\n')
                settings_file.write(u'debug = true\n')
            self.output = StringIO()
            self.addCleanup(self.output.close)
            self.addCleanup(sys.stderr, sys.stderr)
            sys.stderr = self.output
            load_

# Generated at 2022-06-22 00:57:04.249602
# Unit test for function debug
def test_debug():
    with debug_time('foo'):
        pass
    # nothing


# Generated at 2022-06-22 00:57:07.438078
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck import types
    corrected_command = types.CorrectedCommand('ls', u'ls -l', side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-22 00:57:09.206601
# Unit test for function version
def test_version():
    version('1.1', '2.7', 'fish')

# Generated at 2022-06-22 00:57:17.801054
# Unit test for function warn
def test_warn():
    from .conf import settings
    colorama.init()
    settings.no_colors = False
    warn_text = 'test'
    warn(warn_text)
    assert sys.stderr.getvalue() == u'{warn}[WARN] {title}{reset}\n'.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title=warn_text)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:57:30.197561
# Unit test for function debug
def test_debug():
    from six import StringIO

    from . import debug as debug_

    debug.__wrapped__ = debug_

    out = StringIO()
    err = StringIO()
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    sys.stdout = out
    sys.stderr = err
    try:
        debug('Hello')
        debug('World')
        assert out.getvalue() == ''
        assert err.getvalue() == (
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello\n'
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m World\n')
    finally:
        sys.stdout = orig_stdout
        sys.stderr

# Generated at 2022-06-22 00:57:31.828511
# Unit test for function version
def test_version():
    from . import _version
    import platform
    import colorama
    version(_version.__version__, platform.python_version(), colorama.win32.shell)


# Generated at 2022-06-22 00:57:44.159909
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    _reset = color(colorama.Style.RESET_ALL)
    _bold = color(colorama.Style.BRIGHT)
    _blue = color(colorama.Fore.BLUE)
    _green = color(colorama.Fore.GREEN)
    _red = color(colorama.Fore.RED)
    assert (how_to_configure_alias(None) ==
            'Seems like {}fuck{} alias isn\'t configured!\n'
            'More details - http://github.com/nvbn/thefuck#manual-installation'.format(_bold, _reset))

# Generated at 2022-06-22 00:57:49.733201
# Unit test for function warn
def test_warn():
    import mock
    stderr = mock.Mock()
    warn(u'foo')
    assert stderr.write.called


# Generated at 2022-06-22 00:57:54.115420
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import correct_command

    class Correction(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(Correction('ls', False)) == None

# Generated at 2022-06-22 00:58:05.751002
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import sys
    import datetime

    before = sys.stderr

# Generated at 2022-06-22 00:58:09.353852
# Unit test for function warn
def test_warn():
    import StringIO
    try:
        sys.stderr = StringIO.StringIO()
        warn('Warning message')
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:58:13.935039
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))
    assert sys.stderr.getvalue() == '> ls (+side effect)\n'
    sys.stderr.truncate(0)



# Generated at 2022-06-22 00:58:23.352600
# Unit test for function configured_successfully
def test_configured_successfully():
    class ConfigurationDetails(object):
        def __init__(self, path, can_configure_automatically, reload):
            self.path = path
            self.can_configure_automatically = can_configure_automatically
            self.reload = reload

    configuration_details = ConfigurationDetails(path='~/.zshrc',
                                                 can_configure_automatically=True,
                                                 reload='source ~/.zshrc')
    configured_successfully(configuration_details)


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 00:58:23.938016
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-22 00:58:31.584741
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import errno
    from .utils import get_all_executables, get_shell_info
    from .conf import get_alias
    from .shells import shell_support
    shell_info = get_shell_info(os.environ)
    al = get_alias()
    test_conf = shell_support(shell_info)()
    test_conf.get_alias(al)
    test_conf.get_script_path(al)
    test_conf.get_reload_cmd(al)
    do = test_conf.can_configure_automatically
    how_to_configure_alias(test_conf)
    assert how_to_configure_alias == how_to_configure_alias


# Generated at 2022-06-22 00:58:33.274605
# Unit test for function failed
def test_failed():
    scalar = 'test'
    failed(scalar)

# Generated at 2022-06-22 00:58:36.619363
# Unit test for function rule_failed
def test_rule_failed():
    rule = object()
    rule.name = "name1"
    exception(u'Rule {}'.format(rule.name), None)

# Generated at 2022-06-22 00:58:47.147873
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .compat import StringIO
    from .conf import Settings
    from .main import get_settings

    stream = StringIO()
    settings = Settings(get_settings())
    # TODO: Use PyMock
    settings.no_colors = True
    command = CorrectedCommand('ls', 'll')
    old_stream = sys.stderr
    sys.stderr = stream
    show_corrected_command(command)
    assert stream.getvalue().strip() == '' \
        ':: corrected command: ls (side effect)'
    sys.stderr = old_stream



# Generated at 2022-06-22 00:58:51.274627
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)
    already_configured(u'source ~/.bashrc')
    already_configured(u'source ~/.zshrc')
    already_configured(u'source ~/.config/fish/config.fish')


# Generated at 2022-06-22 00:59:02.420870
# Unit test for function debug_time
def test_debug_time():
    # mock sys
    original_sys = sys
    sys = MockSys()
    # mock datetime
    class MockDatetime(datetime):
        def __new__(cls):
            # datetime.now() / (1 second)
            return datetime(*(1976, 1, 1, 1, 1, 1))

    original_datetime = datetime
    datetime = MockDatetime()

    # run the function
    with debug_time('test'):
        pass

    # check output
    assert sys.stderr.last_output == u'debug: test took: 0:00:00'

    # restore mock
    sys = original_sys
    datetime = original_datetime



# Generated at 2022-06-22 00:59:06.220609
# Unit test for function version
def test_version():
    thefuck_version = '1.1.0'
    python_version = '3.5.1'
    shell_info = 'bash'
    out = sys.stderr
    sys.stderr = str()
    version(thefuck_version, python_version, shell_info)
    assert sys.stderr == 'The Fuck 1.1.0 using Python 3.5.1 and bash\n'
    sys.stderr = out

# Generated at 2022-06-22 00:59:14.168602
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from pytest import raises

    class FakeStream(StringIO):

        def write(self, text):
            self.value = text

    with raises(SystemExit):
        with FakeStream() as fake:
            sys.stderr = fake
            failed('foo')
            assert fake.value == u'{red}foo{reset}\n'.format(
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-22 00:59:15.914785
# Unit test for function version
def test_version():
    assert version("3.16", "2.7.5", "zsh 5.0") == 'The Fuck 3.16 using Python 2.7.5 and zsh 5.0\n'



# Generated at 2022-06-22 00:59:25.275969
# Unit test for function failed
def test_failed():
    failed('Failed')
    out, err = sys.stdout, sys.stderr
    sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
    try:
        from StringIO import StringIO
        out = StringIO()
        err = StringIO()
        sys.stdout, sys.stderr = out, err
        failed('Failed')
        assert u'\x1b[91mFailed\x1b[0m\n' == out.getvalue()
    finally:
        sys.stdout, sys.stderr = out, err

# Generated at 2022-06-22 00:59:29.507124
# Unit test for function color
def test_color():
    colorama.init()
    assert u'\x1b[30m' == color(colorama.Fore.BLACK)
    settings.no_colors = True
    assert u'' == color(colorama.Fore.BLACK)

# Generated at 2022-06-22 00:59:35.839623
# Unit test for function color
def test_color():
    with color('\x1b[31m'):
        assert color('\x1b[32m') == ''
        assert color('\x1b[37m') == ''
    assert color('\x1b[32m') == '\x1b[32m'
    assert color('\x1b[37m') == '\x1b[37m'



# Generated at 2022-06-22 00:59:38.026799
# Unit test for function rule_failed
def test_rule_failed():
    rule = None
    exc_info = None
    rule_failed(rule,exc_info)

# Generated at 2022-06-22 00:59:45.841139
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='git commit')
    assert True


# Generated at 2022-06-22 00:59:48.265848
# Unit test for function configured_successfully
def test_configured_successfully():
    assert(configured_successfully('fuck') == "fuck alias configured successfully!\nFor applying changes run or restart your shell.")


# Generated at 2022-06-22 00:59:54.808932
# Unit test for function failed
def test_failed():
    import io
    sysio = io.StringIO()
    old = sys.stderr
    try:
        sys.stderr = sysio
        failed(u'foo')
        failed(u'Бар')
    finally:
        sys.stderr = old

    assert sysio.getvalue() == u'\x1b[31mfoo\x1b[0m\n\x1b[31mБар\x1b[0m\n'



# Generated at 2022-06-22 00:59:58.584203
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test'):
        assert datetime.now() - started < 1
    assert datetime.now() - started > 1

# Generated at 2022-06-22 01:00:01.728693
# Unit test for function color
def test_color():
    assert color('asd') == colorama.Style.RESET_ALL + 'asd' + colorama.Style.RESET_ALL
    assert color('asd') == ''

# Generated at 2022-06-22 01:00:04.129863
# Unit test for function already_configured
def test_already_configured():
    already_configured_test = already_configured(configuration_details='configuration_details')
    assert already_configured_test



# Generated at 2022-06-22 01:00:06.066019
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.3)

# Generated at 2022-06-22 01:00:08.378612
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(True) == True


# Generated at 2022-06-22 01:00:10.027154
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-22 01:00:17.488966
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import _get_configuration_details
    from mock import patch
    details = _get_configuration_details('bash', ':', '/data/home')
    with patch('sys.stdout', new=six.StringIO()) as fake_stdout:
        how_to_configure_alias(details)
    assert fake_stdout.getvalue().startswith(u"Seems like \x1b[1mfuck\x1b[22m alias isn't configured!")

# Generated at 2022-06-22 01:00:24.668588
# Unit test for function debug
def test_debug():
    assert debug('test') == None


# Generated at 2022-06-22 01:00:34.486971
# Unit test for function version
def test_version():
    thefuck_version = '3.3.3'
    python_version = '3.3.3'
    shell_name = 'bash'
    shell_version = '3.3.3'
    if sys.platform in ('cygwin', 'win32'):
        shell_name = 'cmd'
    expected = \
        'The Fuck %s using Python %s and %s %s\n' % \
        (thefuck_version, python_version, shell_name, shell_version)
    version(thefuck_version, python_version, shell_version)
    assert sys.stderr.getvalue() == expected

# Generated at 2022-06-22 01:00:36.424271
# Unit test for function color
def test_color():
    assert color('red')('text') == 'text'
    settings.no_colors = True
    assert color('red')('text') == ''
    settings.no_colors = False

# Generated at 2022-06-22 01:00:38.351273
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.ConfigurationDetails(
        path='~/.bashrc',
        content='fuck',
        reload='source ~/.bashrc',
        can_configure_automatically=True))



# Generated at 2022-06-22 01:00:40.060891
# Unit test for function already_configured
def test_already_configured():
    class Config:
        def _asdict(self):
            return {'reload': 'reload'}
    already_configured(Config())

# Generated at 2022-06-22 01:00:41.233926
# Unit test for function exception
def test_exception():
    return sys.stderr.write('It works!')

# Generated at 2022-06-22 01:00:49.571171
# Unit test for function failed
def test_failed():
    class TestStderr(object):
        def __init__(self):
            self.buffer = ''

        def write(self, text):
            self.buffer += text

        def writelines(self, lines):
            self.buffer += ''.join(lines)

        def __unicode__(self):
            return self.buffer

        def __str__(self):
            return unicode(self).encode('utf-8')

    sys.stderr = TestStderr()
    failed('foo bar baz')
    assert unicode(sys.stderr) == u'\x1b[31mfoo bar baz\x1b[0m\n'



# Generated at 2022-06-22 01:00:52.050981
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:  # NOQA
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-22 01:00:55.452861
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(True)


if __name__ == '__main__':
    import doctest
    doctest.testmod()