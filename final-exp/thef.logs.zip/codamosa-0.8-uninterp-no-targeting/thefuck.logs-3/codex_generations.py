

# Generated at 2022-06-22 00:51:03.434191
# Unit test for function color
def test_color():
    for color in (colorama.Back, colorama.Fore, colorama.Style):
        assert color() not in color(color())

# Generated at 2022-06-22 00:51:04.487764
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'fuck')

# Generated at 2022-06-22 00:51:14.265582
# Unit test for function failed
def test_failed():
    class GetTextStderr(object):
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

        @property
        def message(self):
            return self.text.strip('\n').split(' ')[2]

    stderr = GetTextStderr()
    sys.stderr, old_stderr = stderr, sys.stderr
    try:
        failed(u'msg')
        assert stderr.message == u'msg'
    finally:
        sys.stderr = old_stderr



# Generated at 2022-06-22 00:51:15.927242
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('0')

# Generated at 2022-06-22 00:51:18.788347
# Unit test for function color
def test_color():
    assert color('red') == ''

    settings.no_colors = False
    assert color('red') == 'red'
    settings.no_colors = True

# Generated at 2022-06-22 00:51:23.310313
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-22 00:51:25.888051
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('Test exception')
    except:
        rule_failed('rule', sys.exc_info())

# Generated at 2022-06-22 00:51:27.080539
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:51:39.503867
# Unit test for function show_corrected_command

# Generated at 2022-06-22 00:51:40.964482
# Unit test for function already_configured
def test_already_configured():
    try:
        already_configured(None)
    except:
        assert False

# Generated at 2022-06-22 00:51:44.099345
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:51:47.171412
# Unit test for function warn
def test_warn():
    try:
        warn("")
    except:
        assert "cannot write to any streams" in sys.exc_info()[1]


# Generated at 2022-06-22 00:51:55.528045
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text(corrected_command='') ==
            (u'[incorrect command {}] '
             u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
             u'/{red}ctrl+c{reset}]').format(
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-22 00:52:05.636096
# Unit test for function rule_failed
def test_rule_failed():
    expected_stdout = (u'[WARN] Rule foo:\n'
                       u'Traceback (most recent call last):\n'
                       u'  File "tests/tests.py", line 497, in test_rule_failed\n'
                       u'    raise Exception\n'
                       u'Exception\n'
                       u'\n'
                       u'----------------------------\n')
    try:
        raise Exception
    except:
        from thefuck.rules.base import Rule
        rule_failed(Rule('foo', lambda *a, **kw: None,
                         r'.*', lambda *a, **kw: u'',
                         False), sys.exc_info())
        assert sys.stderr.getvalue() == expected_stdout

# Generated at 2022-06-22 00:52:06.647699
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-22 00:52:19.928510
# Unit test for function warn
def test_warn():
    from pytest import raises
    from io import StringIO
    with raises(SystemExit):
        warn('Hobbit')
    with raises(SystemExit):
        warn('Вельможа')

    with StringIO() as stderr:
        sys.stderr = stderr
        warn('Hobbit')
        output = stderr.getvalue()
    assert output == u'[WARN] Hobbit\n'

    if sys.version_info.major == 2:
        with StringIO() as stderr:
            sys.stderr = stderr
            warn(u'Вельможа')
            output = stderr.getvalue()

# Generated at 2022-06-22 00:52:21.797245
# Unit test for function version
def test_version():
    assert version('1.0', '2.7', 'zsh') == None

# Generated at 2022-06-22 00:52:23.772966
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == '\x1b[1m'

# Generated at 2022-06-22 00:52:27.386335
# Unit test for function version
def test_version():
    version('3.11', '3.4.0', 'Fish 2.2.0') == 'The Fuck 3.11 using Python 3.4.0 and Fish 2.2.0\n'

# Generated at 2022-06-22 00:52:35.049788
# Unit test for function version
def test_version():
    import StringIO
    from StringIO import StringIO as BytesIO
    from thefuck.utils import get_shell

    with StringIO() as out:
        orignal = sys.stderr
        sys.stderr = out
        try:
            version(u'1.1', u'2.7.11', get_shell())
        finally:
            sys.stderr = orignal

    assert (
        out.getvalue()
        == 'The Fuck 1.1 using Python 2.7.11 and {}\n'.format(get_shell()))



# Generated at 2022-06-22 00:52:39.936926
# Unit test for function configured_successfully
def test_configured_successfully():
    class configuration_details:
        reload = 'reload'
    configured_successfully(configuration_details)


# Generated at 2022-06-22 00:52:40.996517
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('test') is None

# Generated at 2022-06-22 00:52:41.638306
# Unit test for function failed
def test_failed():
    failed("Hello World")

# Generated at 2022-06-22 00:52:52.117075
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # If a corrected_command.script is a single character
    from .command import Command
    corrected_command = Command(u"a", u"")
    assert show_corrected_command(corrected_command) == u'$a\n'
    # If a corrected_command.script is a multiple characters
    corrected_command2 = Command(u"git pull", u"")
    assert show_corrected_command(corrected_command2) == u'$git pull\n'
    # If a corrected_command.script is a multiple characters and has side effect
    corrected_command3 = Command(u"git pull", u"", u"+side effect")
    assert show_corrected_command(corrected_command3) \
        == u'$git pull (+side effect)\n'

# Generated at 2022-06-22 00:52:55.945680
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Exception message')
    except Exception:
        traceback = format_exception(*sys.exc_info())
        exception(u'Exception generated by unit test', traceback)
    assert False, 'Exception message'

# Generated at 2022-06-22 00:53:01.218312
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    class TestRuleFailed(unittest.TestCase):
        def test_log(self):
            class Rule():
                def __init__(self):
                    self.name = 'test_rule'
            rule_failed(Rule(), ('Error: test_rule()', None, None))

    unittest.main()


# Generated at 2022-06-22 00:53:06.538573
# Unit test for function debug
def test_debug():
    import sys
    from cStringIO import StringIO
    sys.stderr = StringIO()
    debug('Testing')
    assert(sys.stderr.getvalue() == u'\x1b[94m\x1b[1mDEBUG:\x1b[0m Testing\n')

# Generated at 2022-06-22 00:53:08.629598
# Unit test for function already_configured
def test_already_configured():
    return already_configured(const.ConfigurationDetails('reload', False, True))


# Generated at 2022-06-22 00:53:09.933121
# Unit test for function debug_time
def test_debug_time():
    with debug_time('name'):
        pass

# Generated at 2022-06-22 00:53:14.131857
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(const.CorrectedCommand(script=u'test', side_effect=False))
    show_corrected_command(const.CorrectedCommand(script=u'test', side_effect=True))


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-22 00:53:24.081933
# Unit test for function already_configured
def test_already_configured():
    output = u''
    try:
        already_configured('{reload}')
    except SystemExit:
        output += sys.stderr.getvalue()
    assert (u"Seems like {}fuck{} alias already configured!\n"
            u"For applying changes run {reload} or restart your shell.".format(
                color(colorama.Style.BRIGHT),
                color(colorama.Style.RESET_ALL)) == output)

# Generated at 2022-06-22 00:53:28.930165
# Unit test for function configured_successfully
def test_configured_successfully():
    import io
    stdout = io.StringIO()
    sys.stdout = stdout
    configured_successfully("reload")
    result = stdout.getvalue().split("\n")[0]
    assert result == u'\x1b[1mfuck\x1b[22m alias configured successfully!'

# Generated at 2022-06-22 00:53:41.425018
# Unit test for function confirm_text
def test_confirm_text():
    test_command="dmesg"

# Generated at 2022-06-22 00:53:42.968095
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(' ')


# Generated at 2022-06-22 00:53:54.825508
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    import sys
    capturedOutput = StringIO.StringIO()
    sys.stderr = capturedOutput
    rule = object()
    rule.name = 'name'
    rule.side_effect = 'side_effect'
    try:
        raise Exception('raised')
    except Exception:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:53:55.475740
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully()

# Generated at 2022-06-22 00:54:00.034716
# Unit test for function rule_failed
def test_rule_failed():
    import pytest
    rule = pytest.Mock()
    rule.name = 'test_rule'
    rule_failed(rule, exc_info=('x', 'y', 'z'))

# Generated at 2022-06-22 00:54:02.807920
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED) == ''
    assert color(colorama.Fore.WHITE + colorama.Back.RED) == ''

# Generated at 2022-06-22 00:54:05.273656
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception('ZeroDivisionError', sys.exc_info())


# Generated at 2022-06-22 00:54:08.845404
# Unit test for function debug_time
def test_debug_time():
    import time
    sleep_time = 0.1
    def do_smth():
        time.sleep(sleep_time)
    with debug_time("do_smth"):
        do_smth()

# Generated at 2022-06-22 00:54:12.298447
# Unit test for function already_configured
def test_already_configured():
    already_configured('configuration_details')

# Generated at 2022-06-22 00:54:13.674433
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc_info')

# Generated at 2022-06-22 00:54:16.036477
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    try:
        how_to_configure_alias(None)
    except SystemExit:
        pass

# Generated at 2022-06-22 00:54:23.802088
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(const.DEFAULT_CONFIGURATION_DETAILS)
    # how to configure with Bash
    how_to_configure_alias(const.BASH_CONFIGURATION_DETAILS)
    # how to configure with Fish
    how_to_configure_alias(const.FISH_CONFIGURATION_DETAILS)
    # how to configure with Zsh
    how_to_configure_alias(const.ZSH_CONFIGURATION_DETAILS)

# Generated at 2022-06-22 00:54:34.118987
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import conf
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile('w', delete=False) as bashrc:
        # Bash configuration
        bashrc.write("""
        alias fuck='eval $(thefuck $(fc -ln -1)); fc -R'
        """)
        bashrc.close()
        details = conf.Alias(
            can_configure_automatically=True,
            path=bashrc.name,
            reload='source ' + bashrc.name,
            content='alias fuck="eval $(thefuck $(fc -ln -1)); fc -R"')
        configured_successfully(details)
    from . import utils
    utils.execu

# Generated at 2022-06-22 00:54:36.955397
# Unit test for function debug_time
def test_debug_time():
    x = 0
    with debug_time('test'):
        for i in range(100000):
            x += i
    assert x == 4999950000


# Generated at 2022-06-22 00:54:38.488486
# Unit test for function already_configured
def test_already_configured():
    assert type(already_configured('configuration_details')) == None

# Generated at 2022-06-22 00:54:47.793377
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple

    ConfigurationDetails = namedtuple('ConfigurationDetails',
                                      ('path', 'content', 'reload',
                                       'can_configure_automatically'))
    details = ConfigurationDetails('~/dotfiles/bashrc', 'export StOp_tHe_FuCk_I_WaNt_To_G',
                                   'source ~/dotfiles/bashrc', True)

    with mock.patch('thefuck.utils._how_to_configure_alias._print') as m:
        how_to_configure_alias(details)
        assert m.call_count == 2


# Generated at 2022-06-22 00:54:56.466448
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    import mock
    with mock.patch('sys.stderr', mock.Mock()) as mock_stderr:
        with debug_time('foo'):
            pass
        mock_stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} foo took: {}\n'.format(
                timedelta(0),
                blue=color(colorama.Fore.BLUE),
                reset=color(colorama.Style.RESET_ALL),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-22 00:54:57.655278
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:55:03.810032
# Unit test for function rule_failed
def test_rule_failed():
    exc_info = [None, None, None]
    rule = 'test'
    rule_failed(rule,exc_info)
    print("rule_failed test is successful")


# Generated at 2022-06-22 00:55:06.105875
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('../thefuck/conf.py') == 'git commit -m "Test commit"'

# Generated at 2022-06-22 00:55:13.492777
# Unit test for function debug_time
def test_debug_time():
    call_counter = [0]

    @contextmanager
    def debug_time(msg):
        call_counter[0] += 1
        yield
        assert(call_counter and call_counter[0] == 1)

    def _test_debug_time():
        with debug_time('test'):
            raise Exception()

    try:
        _test_debug_time()
        assert(False)
    except:
        pass

# Generated at 2022-06-22 00:55:15.724032
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('TEST')
    except ValueError:
        exception('Test', sys.exc_info())

# Generated at 2022-06-22 00:55:24.646462
# Unit test for function configured_successfully
def test_configured_successfully():
    import io as cStringIO
    sys.stdout = cStringIO.StringIO()
    test_data = {'path': u'/home/USER', 'reload': u'fuck --reload'}
    configured_successfully(**test_data)
    assert (sys.stdout.getvalue() ==
            u'{bold}fuck{reset} alias configured successfully!\n'
            u'For applying changes run {bold}{reload}{reset}'
            u' or restart your shell.\n'.format(
                bold=u'',
                reset=u'',
                reload=test_data['reload']))
    sys.stdout = sys.__stdout__


# Generated at 2022-06-22 00:55:26.905143
# Unit test for function exception
def test_exception():
    exception('Test', (Exception, Exception('Test'), None))

# Generated at 2022-06-22 00:55:35.572540
# Unit test for function warn
def test_warn():
    import mock
    import sys
    with mock.patch('sys.stderr') as stderr_mock:
        warn(u'Tests')
        stderr_mock.write.assert_called_once_with(u'{warn}[WARN] {title}{reset}\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title=u'Tests'))


# Generated at 2022-06-22 00:55:46.171912
# Unit test for function version
def test_version():
    import io
    import sys
    import shutil

    python_version = '{0}.{1}'.format(sys.version_info[0],
                                      sys.version_info[1])
    out = io.StringIO()
    try:
        sys.stderr = out
        version('1.11', python_version, 'bash 4.3.11')
        assert '1.11' in out.getvalue()
        assert python_version in out.getvalue()
        assert 'bash 4.3.11' in out.getvalue()
    finally:
        sys.stderr = sys.__stderr__
        out.close()



# Generated at 2022-06-22 00:55:50.026639
# Unit test for function configured_successfully
def test_configured_successfully():
    fake_output = StringIO()
    with patch('sys.stderr', fake_output):
        configured_successfully('some reload command')
    assert 'some reload command' in fake_output.getvalue()



# Generated at 2022-06-22 00:55:54.831017
# Unit test for function exception
def test_exception():
    class exc:
        @staticmethod
        def get_exc():
            raise Exception
    try:
        exc.get_exc()
    except:
        exception_str = ''.join(format_exception(*sys.exc_info()))
    assert(u'Exception\n' in exception_str)

# Generated at 2022-06-22 00:56:03.680288
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.git import get_new_command
    sys.stderr.write = lambda x: _write_to_stdout(x)

    rule_failed(get_new_command, (None, None, None))

    assert _get_stdout() == '\x1b[41;1m[WARN] Rule git\x1b[0m\n\n'

# Generated at 2022-06-22 00:56:05.961238
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls'))

# Generated at 2022-06-22 00:56:07.664613
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        debug('str')
        assert True

# Generated at 2022-06-22 00:56:11.068342
# Unit test for function configured_successfully
def test_configured_successfully():
    my_configuration_details = settings.ConfigureDetails.manual('fuck',
                                                                '/etc',
                                                                'reload')
    configured_successfully(my_configuration_details)

# Generated at 2022-06-22 00:56:24.301445
# Unit test for function failed
def test_failed():
    """Unit test for function failed."""
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.fish import Fish
    from thefuck.shells.tcsh import Tcsh
    from thefuck.shells.xonsh import Xonsh
    from thefuck.shells.xonsh import Env
    from thefuck.shells.bpython import Bpython
    from thefuck.shells.idle import Idle
    from thefuck.shells.lazy_pdb import LazyPdb

    _failed("Some error", [], (Idle,))
    _failed("Some error", [], (Idle, Fish,))
    _failed("Some error", [], (Idle, Fish, Tcsh,))

# Generated at 2022-06-22 00:56:31.574863
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    configured_successfully(('source ~/.bashrc', ))
    out.seek(0)
    assert out.read().replace('\033[0m', '') == \
        u'\033[1mfuck\033[0m alias configured successfully!\n' \
        'For applying changes run \033[1msource ~/.bashrc\033[0m' \
        ' or restart your shell.\n'


# Generated at 2022-06-22 00:56:33.908546
# Unit test for function warn
def test_warn():
    warn(u'Предупреждение')


# Generated at 2022-06-22 00:56:36.200791
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except:
        exception("test", sys.exc_info())

# Generated at 2022-06-22 00:56:40.753244
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from test.factories import CorrectedCommand

    corrected_command = CorrectedCommand(script='final script', side_effect=True)
    assert show_corrected_command(corrected_command) == '''▶️final script (+side effect)
'''



# Generated at 2022-06-22 00:56:52.508610
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.CONFIG_DETAILS['bash']
    last_lines = []
    for line in how_to_configure_alias(configuration_details):
        last_lines.append(line)


# Generated at 2022-06-22 00:56:57.194935
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except ZeroDivisionError:
        exception('Title', sys.exc_info())

# Generated at 2022-06-22 00:57:00.836153
# Unit test for function version
def test_version():
    thefuck_version = '3.17'
    python_version = '3.6'
    shell_info = 'ZSH'
    version(thefuck_version, python_version, shell_info)

test_version()

# Generated at 2022-06-22 00:57:02.088701
# Unit test for function failed
def test_failed():
    failed('Fail')

# Generated at 2022-06-22 00:57:12.547213
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    with settings.override(no_colors=True):
        assert (u'Seems like fuck alias isn\'t configured!\n'
                u'More details - https://github.com/nvbn/thefuck#manual-installation') \
            == how_to_configure_alias(None)
    with settings.override(no_colors=False):
        assert (u'\x1b[1mSeems like fuck alias isn\'t configured!\x1b[0m\n'
                u'More details - https://github.com/nvbn/thefuck#manual-installation') \
            == how_to_configure_alias(None)



# Generated at 2022-06-22 00:57:19.676861
# Unit test for function version
def test_version():
    class EmptyStringIO(object):
        def __init__(self):
            self.buffer = ''

        def write(self, s):
            self.buffer += s

    buffer = EmptyStringIO()
    sys.stderr = buffer
    version('3.6', '2.7', 'zsh')
    assert buffer.buffer == 'The Fuck 3.6 using Python 2.7 and zsh\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:57:21.770296
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import colorama
    colorama.init()
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:57:25.180610
# Unit test for function warn
def test_warn():
    assert warn('test') == '\x1b[103m\x1b[100m[WARN] test\x1b[0m\n'

# Generated at 2022-06-22 00:57:28.859011
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('test') == (
        u"{bold}fuck{reset} alias configured successfully!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.")

# Generated at 2022-06-22 00:57:29.876290
# Unit test for function failed
def test_failed():
    failed(u'Не правильно')

# Generated at 2022-06-22 00:57:31.645365
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()



# Generated at 2022-06-22 00:57:37.288161
# Unit test for function version
def test_version():
    """
    >>> import unittest
    >>> import sys
    >>> import mock
    >>> from thefuck.main import version
    >>> version('The Fuck 2.0', 'Python 2.7.8', 'bash-3.2')
    The Fuck 2.0 using Python 2.7.8 and bash-3.2
    """

# Generated at 2022-06-22 00:57:38.444531
# Unit test for function confirm_text

# Generated at 2022-06-22 00:57:42.496390
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Given
    from .shells.bash import Bash
    configuration_details = Bash.configuration_details()
    # When
    from . import style
    style.how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:57:43.982474
# Unit test for function version
def test_version():
    import platform
    import thefuck
    version(thefuck.__version__,
            platform.python_version(),
            '%s, %s' % (platform.system(), platform.release()))

# Generated at 2022-06-22 00:57:46.421578
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED) == '\x1b[41m'
    assert color(colorama.Back.RED) == ''

# Generated at 2022-06-22 00:57:49.508569
# Unit test for function failed
def test_failed():
    import StringIO
    result = StringIO.StringIO()
    failed(msg='test')
    assert result.getvalue() == 'test\n'



# Generated at 2022-06-22 00:57:52.005645
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == '\033[32m'
    assert color(colorama.Fore.GREEN) == ''



# Generated at 2022-06-22 00:57:53.169033
# Unit test for function warn
def test_warn():
    warn(u'hello world')



# Generated at 2022-06-22 00:57:55.283008
# Unit test for function color
def test_color():
    assert color(123) == 123
    assert color('') == ''
    assert color('a') == ''

# Generated at 2022-06-22 00:57:58.707840
# Unit test for function version
def test_version():
    assert version('2.0', '3.3.3', 'GNU bash') == \
        u'The Fuck 2.0 using Python 3.3.3 and GNU bash\n'



# Generated at 2022-06-22 00:58:05.681604
# Unit test for function color
def test_color():
    assert color(u'I am red!' + colorama.Fore.RED) == u'I am red!' + colorama.Fore.RED
    settings.no_colors = True
    assert color(u'I am red!' + colorama.Fore.RED) == u''

# Generated at 2022-06-22 00:58:09.290862
# Unit test for function debug_time
def test_debug_time():
    import mock

    with mock.patch('thefuck.utils.sys') as mock_sys:
        with debug_time('foo'):
            pass
        mock_sys.stderr.write.assert_called_once()

# Generated at 2022-06-22 00:58:21.816852
# Unit test for function already_configured
def test_already_configured():
    from thefuck.shells import FishShell
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.cmd import Cmd
    commands = [
        dict(shell_class=Bash, descr='~/.bashrc'),
        dict(shell_class=FishShell, descr='~/.config/fish/config.fish'),
        dict(shell_class=Zsh, descr='~/.zshrc'),
        dict(shell_class=Cmd, descr='registry entry')
    ]
    res = open('test_already_configured.txt', 'w')
    for one in commands:
        shell = one['shell_class'].from_shell(None)

# Generated at 2022-06-22 00:58:25.478000
# Unit test for function exception
def test_exception():
    import pytest

    try:
        raise RuntimeError('test')
    except Exception:
        exc_info = sys.exc_info()
    exception('test', exc_info)
    assert True

# Generated at 2022-06-22 00:58:26.475387
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None)



# Generated at 2022-06-22 00:58:31.002962
# Unit test for function failed
def test_failed():
    out, err = sys.stdout, sys.stderr
    try:
        sys.stdout = sys.stderr = StringIO()
        failed('Foo')
        assert sys.stderr.getvalue() == '\x1b[31mFoo\x1b[0m\n'
    except AssertionError:
        raise
    finally:
        sys.stdout, sys.stderr = out, err



# Generated at 2022-06-22 00:58:34.835076
# Unit test for function failed
def test_failed():
    from tests.utils import capture_stderr

    assert u'Error' in capture_stderr(
        lambda: failed(u'Error'))[0]

# Generated at 2022-06-22 00:58:45.601132
# Unit test for function confirm_text
def test_confirm_text():
    u'[\u001b[1K\r\u001b[1m\u001b[1m$ fkd\u001b[0m \u001b[1m\u001b[92menter\u001b[0m/\u001b[1m\u001b[94m\u2191\u001b[0m/\u001b[1m\u001b[94m\u2193\u001b[0m/\u001b[1m\u001b[91mctrl+c\u001b[0m]'

# Generated at 2022-06-22 00:58:51.274057
# Unit test for function debug_time
def test_debug_time():
    import StringIO
    from StringIO import StringIO as Python2StringIO
    out = StringIO() if sys.version_info[0] >= 3 else Python2StringIO()
    settings.debug = True
    with debug_time(u'foo'):
        sys.stderr = out
    assert u'foo took: ' in out.getvalue()

# Generated at 2022-06-22 00:59:03.844980
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import subprocess
    import tempfile
    import sys

    with tempfile.NamedTemporaryFile() as fd:
        proc = subprocess.Popen(
            'python -c "import sys\n'
            'sys.stdout.write(\'{}\')\n'
            'sys.stderr.write(\'{}\')\n'
            'sys.exit({})"'.format(
                const.USER_COMMAND_MARK,
                const.USER_COMMAND_MARK,
                os.EX_OK),
            stdout=fd,
            stderr=fd,
            shell=True)
        proc.wait()

        fd.seek(0)

        stdout = fd.read()
        stderr = fd.read()


# Generated at 2022-06-22 00:59:16.961586
# Unit test for function debug
def test_debug():
    import os
    import io
    try:
        debug_io = io.StringIO()
        sys.stderr.write = debug_io.write
        debug('testing debug')
        assert len(debug_io.getvalue()) == 0
        os.environ['THEFUCK_DEBUG'] = "True"
        debug('testing debug')
        assert len(debug_io.getvalue()) != 0
    finally:
        del os.environ['THEFUCK_DEBUG']
        sys.stderr.write = sys.__stderr__.write


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-22 00:59:19.268933
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception('title', sys.exc_info())
        return True
    return False

# Generated at 2022-06-22 00:59:22.005593
# Unit test for function color
def test_color():
    assert colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT in color('foo')
    assert '' == color('')

# Generated at 2022-06-22 00:59:24.679735
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exc_info = sys.exc_info()
        exception('Test exception', exc_info)


# Generated at 2022-06-22 00:59:25.898863
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("")


# Generated at 2022-06-22 00:59:30.481043
# Unit test for function failed
def test_failed():
    failed(u'msg')
    assert sys.stderr.getvalue() == \
        u'{red}msg{reset}\n'.format(red=color(colorama.Fore.RED),
                                    reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-22 00:59:32.838184
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:59:34.886666
# Unit test for function failed
def test_failed():
    assert failed(u'привет!') == None

# Generated at 2022-06-22 00:59:37.971307
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple('configuration_details', 'reload')
    already_configured(configuration_details('. $HOME/.bashrc'))


# Generated at 2022-06-22 00:59:40.812378
# Unit test for function failed
def test_failed():
    msg = 'Fail'
    expected = '\x1b[31mFail\x1b[0m\n'
    assert failed(msg) == expected, 'Failed function works properly'


# Generated at 2022-06-22 00:59:47.950903
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    err = StringIO()
    sys.stderr = err
    failed(u'msg')
    assert err.getvalue().strip() == u'\x1b[31msg\x1b[0m\n'



# Generated at 2022-06-22 00:59:52.958087
# Unit test for function color
def test_color():
    # colorama.Fore.GREEN return string like this \033[32m
    # colorama.Style.RESET_ALL return string like this \033[0m
    assert color(colorama.Fore.GREEN) == '\033[32m'
    assert color(colorama.Style.RESET_ALL) == '\033[0m'

# Generated at 2022-06-22 00:59:54.295319
# Unit test for function version
def test_version():
    version('The Fuck 1.0', 'Python 2.1', 'sh')

# Generated at 2022-06-22 01:00:00.050941
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=True,
        path=u'~/.bash_profile',
        content=u'alias fuck pyhton -m thefuck --alias',
        reload=u'source ~/.bash_profile'))



# Generated at 2022-06-22 01:00:05.589028
# Unit test for function debug
def test_debug():
    from mock import patch

    stderr = patch('sys.stderr')
    with stderr:
        debug('test')
        stderr.write.assert_called_once_with(u'test\n')

    settings.debug = False
    with stderr:
        debug('test')
        stderr.write.assert_not_called()


# Generated at 2022-06-22 01:00:18.214873
# Unit test for function configured_successfully
def test_configured_successfully():

    clear_settings()
    settings.clear_history = True

    # Check default
    settings.confirm = False
    settings.require_confirmation = True
    configured_successfully(autoconf.ConfigureCommand())
    eq_(sys.stdout.getvalue(),
        u"{bold}fuck{reset} alias configured successfully!\n"
        u"For applying changes run {bold}{reload}{reset} or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='source ~/.bashrc'))

    clear_settings()
    settings.clear_history = True

    # Check default
    settings.confirm = True
    settings.require_confirmation = False
    configured_successfully(autoconf.ConfigureCommand())
   

# Generated at 2022-06-22 01:00:19.289369
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    conf = False
    how_to_configure_alias(conf)
    assert True

# Generated at 2022-06-22 01:00:21.874375
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand('ls', u'', False)
    confirm_text(corrected_command)

# Generated at 2022-06-22 01:00:29.850016
# Unit test for function confirm_text
def test_confirm_text():
    # (script, side_effect)
    tests = [('ls', True), ('ls', False)]
    for script, side_effect in tests:
        corrected_command = type('', (), {'script': script, 'side_effect': side_effect})
        confirm_text(corrected_command)
        assert sys.stderr.getvalue() == u'❯ ls (+side effect) [enter/↑/↓/ctrl+c]'.format(
            const.USER_COMMAND_MARK, script)

# Generated at 2022-06-22 01:00:33.918139
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class TestCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(TestCommand("echo test", True))

# Generated at 2022-06-22 01:00:42.700246
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(['fuck'])
    already_configured(['fuck'])
    how_to_configure_alias(['fuck'])
    debug_time(['fuck'])
    debug('fuck')
    sys.stderr.write('fuck')
    failed('fuck')
    rule_failed(['fuck'], 'fuck')
    exception('fuck', 'fuck')
    warn('fuck')
    color('fuck')
    version('fuck', 'fuck', 'fuck')
    show_corrected_command('fuck')
    confirm_text('fuck')
    const.USER_COMMAND_MARK

# Generated at 2022-06-22 01:00:54.307830
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import mock
    from collections import namedtuple
    from thefuck.utils import how_to_configure_alias
    from thefuck import const
    with mock.patch('sys.stderr', new=mock.Mock(write=mock.Mock())) as stderr:
        how_to_configure_alias(None)
        stderr.write.assert_called_with(u'Seems like {}fuck{} alias isn\'t configured!\n'.format(color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL)))
        stderr.write.assert_any_call(u'More details - https://github.com/nvbn/thefuck#manual-installation\n')

# Generated at 2022-06-22 01:01:04.393196
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    with patch('sys.stderr') as stderr:
        sys.stderr = '<mocked stderr>'
        corrected_command = 'ls -la'
        confirm_text(corrected_command)