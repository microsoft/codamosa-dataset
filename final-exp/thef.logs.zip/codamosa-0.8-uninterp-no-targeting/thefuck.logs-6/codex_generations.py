

# Generated at 2022-06-22 00:51:02.198367
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell

    corrected_command = shell.CorrectedCommand('ls', False)
    confirm_text(corrected_command)
    assert sys.stdout.getvalue() is not None
    sys.stdout.truncate(0)



# Generated at 2022-06-22 00:51:05.845933
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import timedelta, datetime
    _array = []

    @contextmanager
    def fake_time(fake_time):
        yield

    with debug_time('fake_time'):
        pass

# Generated at 2022-06-22 00:51:08.957006
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception:
        exception(u'Title', sys.exc_info())



# Generated at 2022-06-22 00:51:11.730127
# Unit test for function warn
def test_warn():
    assert warn('test') == u'\x1b[107m\x1b[30m\x1b[1m[WARN] test\x1b[0m\n'

# Generated at 2022-06-22 00:51:12.804332
# Unit test for function configured_successfully
def test_configured_successfully():
    assert defined_successfully(configuration_details) == ""

# Generated at 2022-06-22 00:51:14.745166
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command(const.CorrectedCommand('ls -a /home', False))
    confirm_text(const.CorrectedCommand('ls -a /home', False))

# Generated at 2022-06-22 00:51:20.858924
# Unit test for function warn
def test_warn():
    sys.stderr = StderrMock()
    warn(u'title')

    assert sys.stderr.value == u'\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-22 00:51:22.785711
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stderr = sys.stdout
    how_to_configure_alias(None)

# Generated at 2022-06-22 00:51:31.667138
# Unit test for function warn
def test_warn():
    from .utils import WrappedSys
    from .utils import capture
    import contextlib
    import sys

    _sys = WrappedSys()
    _sys.stderr.write = capture

    warn('Title')
    with contextlib.nested(
            contextlib.ExitStack(),
            contextlib.redirect_stdout(sys.stderr)):
        warn('Title')

    assert len(_sys.stderr.write.calls) == 2
    assert 'Title' in _sys.stderr.write.calls[1][0]

# Generated at 2022-06-22 00:51:33.133191
# Unit test for function already_configured
def test_already_configured():
    already_configured({'reload': 'h'})

# Generated at 2022-06-22 00:51:37.402648
# Unit test for function debug
def test_debug():
    lines = []
    sys.stderr.write = lambda x: lines.append(x)
    settings.debug = True
    debug(u'test')
    assert len(lines) == 1
    assert u'DEBUG: test' in lines[-1]


# Generated at 2022-06-22 00:51:42.732519
# Unit test for function already_configured
def test_already_configured():
    print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload))

# Generated at 2022-06-22 00:51:45.704870
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    settings.no_colors = True
    assert color('color') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:51:54.331776
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import RulesCollection, Rule
    exc_info = (ValueError, ValueError('error'), None)
    collection = RulesCollection()
    rule = Rule(name='test', match=lambda _: True)
    sys.stderr = sys.stdout
    collection.add(rule)
    rule_failed(rule, exc_info)
    assert sys.stdout.getvalue() == (
        u'[WARN] Rule test: ValueError: error\n'
        u'----------------------------\n\n')

# Generated at 2022-06-22 00:52:02.321204
# Unit test for function version
def test_version():
    version('3.11', '2.7.11', 'Fish 2.2.0')
    version('3.11', '2.7.11', 'Zsh 5.0.2')
    version('3.11', '2.7.11', 'Bash 4.3.30(1)-release')
    version('3.11', '2.7.11', 'Cmd 2.0.0')
    version('3.11', '2.7.11', 'PowerShell 2.0')

# Generated at 2022-06-22 00:52:04.112064
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-22 00:52:10.000675
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # with side effect
    show_corrected_command(const.CorrectedCommand(script='echo "1"',
                                                  side_effect=True))
    # without side effect
    show_corrected_command(const.CorrectedCommand(script='echo "1"',
                                                  side_effect=False))

# Generated at 2022-06-22 00:52:21.109753
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from io import BytesIO
    with patch('sys.stderr', BytesIO()) as mock_sys_stderr:
        from . import output
        from .command import Command
        confirm_text(Command('git commit', 'git commit -v'))
        assert mock_sys_stderr.getvalue() == (u'>git commit -v (+side effect) '
                                              u'[\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]').encode('utf-8')


# test the color function

# Generated at 2022-06-22 00:52:27.387141
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'text') == '\x1b[31mtext'
    assert color(colorama.Fore.RED + colorama.Style.BRIGHT + 'text') == '\x1b[31;1mtext'
    assert color('text') == 'text'

# Generated at 2022-06-22 00:52:32.308004
# Unit test for function debug_time
def test_debug_time():
    from .main import mocked_datetime_now as datetime_now
    from .main import mocked_time_sleep as time_sleep

    debug_log = []

    def debug_py2(msg):
        debug_log.append(msg)

    def debug_py3(msg, *args):
        debug_log.append(msg.format(*args))

    if sys.version_info[0] == 2:
        debug_orig = globals()['debug']
        debug = debug_py2

# Generated at 2022-06-22 00:52:46.612702
# Unit test for function failed
def test_failed():
    from contextlib import contextmanager
    from io import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    msg = u"string with unicode \u0442\u0435\u0441\u0442"
    with captured_output() as (out, err):
        failed(msg)

    output = err.getvalue().strip()

# Generated at 2022-06-22 00:52:50.044962
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('test')
    except Exception as e:
        exc_info = sys.exc_info()
        rule = mock_rule()
        rule_failed(rule, exc_info)



# Generated at 2022-06-22 00:53:01.273516
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    from .utils import get_closest


# Generated at 2022-06-22 00:53:03.679065
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Dummy exception')
    except Exception:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-22 00:53:15.090856
# Unit test for function show_corrected_command
def test_show_corrected_command():
    #Corrected command is non-empty
    test_command_non_empty = 'fuck'
    test_side_effect = False
    #No side-effects in the corrected command
    def run_test(test_command_non_empty, test_side_effect = False):
        show_corrected_command(const.CorrectedCommand(test_command_non_empty, test_side_effect))
    run_test(test_command_non_empty)

    #Side-effects in the corrected command
    test_command_non_empty = 'fuck'
    test_side_effect = True
    run_test(test_command_non_empty, test_side_effect)

    #Corrected command is empty
    test_command_non_empty = ''
    test_side_effect = False

# Generated at 2022-06-22 00:53:27.805142
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .shells.posix import POSIXShell
    from .shells.fish import FishShell

    posix_shell_configurator = POSIXShell('zsh').configurator
    # @posix_shell_configurator.get_configuration_details()
    details = ConfigurationDetails(
        'From ~/.bashrc append ~/.config/thefuck/thefuck-aliases',
        '~/.bashrc',
        'source ~/.config/thefuck/thefuck-aliases',
        False,
        'source ~/.config/thefuck/thefuck-aliases'
    )
    how_to_configure_alias(details)

    fish_shell_configurator = FishShell.configurator
    # @fish_shell_configurator.get_configuration_details()
    details = Configuration

# Generated at 2022-06-22 00:53:31.764539
# Unit test for function debug
def test_debug():
    from mock import patch
    stderr = patch('sys.stderr')
    debug('test')
    stderr.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-22 00:53:40.729194
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from collections import namedtuple
    import StringIO
    CorrectedCommand = namedtuple('CorrectedCommand', 'script side_effect')
    corrected_command = CorrectedCommand(script='ls', side_effect=True)
    stderr = StringIO.StringIO()
    sys.stderr = stderr
    show_corrected_command(corrected_command)
    out = stderr.getvalue()
    assert out == u'{}ls (+side effect)\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-22 00:53:42.696289
# Unit test for function rule_failed
def test_rule_failed():
    # Call exceptions with valid arg
    rule_failed('test', ('title', 'test'))



# Generated at 2022-06-22 00:53:44.196961
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details) == 'fuck'


# Generated at 2022-06-22 00:53:50.926413
# Unit test for function exception
def test_exception():
    from .shells import Shell
    try:
        int('1' + None)
    except Exception as e:
        exception(u'Test Rule', sys.exc_info())


# Generated at 2022-06-22 00:53:58.295779
# Unit test for function debug
def test_debug():
    from io import StringIO
    from .conf import Settings
    from . import version

    settings = Settings(debug=True)
    stdout = StringIO()
    sys.stderr = stdout

    debug(u'Debug message')
    sys.stderr = sys.__stderr__

    assert stdout.getvalue() == u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
            msg=u'Debug message',
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT))


# Generated at 2022-06-22 00:53:59.618177
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('pwd')

# Generated at 2022-06-22 00:54:01.265754
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details) == None



# Generated at 2022-06-22 00:54:08.703712
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = lambda x: x
    corrected_command = lambda: None
    corrected_command.script = 'test script'
    corrected_command.side_effect = False
    show_corrected_command(corrected_command) == '\x1b[31mfuck test script\x1b[0m\n'
    corrected_command.side_effect = True
    show_corrected_command(corrected_command) == '\x1b[31mfuck test script (+side effect)\x1b[0m\n'


# Generated at 2022-06-22 00:54:16.856014
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    import tempfile

    temp_out = tempfile.TemporaryFile()
    with tempfile.TemporaryFile() as temp_in:
        shell = Shell('test',
                      alias='fuck',
                      script='echo "sudo ls"',
                      get_aliases=lambda x: '',
                      side_effect=False)
        command = CorrectedCommand('sudo ls', 'ls', shell, temp_out)
        show_corrected_command(command)
        temp_out.seek(0)
        result = temp_out.read()
        temp_out.close()
        assert result == 'fuck ls\n'

# Unit Test for function exception

# Generated at 2022-06-22 00:54:29.298498
# Unit test for function already_configured
def test_already_configured():
    from io import StringIO
    from .configuration_details import ConfigurationError, ConfigurationDetails
    out = StringIO()
    sys.stdout = out
    already_configured(ConfigurationDetails('test', 'test', True, 'test', 'test'))
    sys.stdout = sys.__stdout__
    assert out.getvalue() == u"Seems like \x1b[1mfuck\x1b[0m alias already configured!\nFor applying changes run \x1b[1mtest\x1b[0m or restart your shell.\n"
    #assert out.getvalue() == 'Seems like \x1b[1mfuck\x1b[0m alias already configured!\nFor applying changes run \x1b[1mtest\x1b[0m or restart your shell.\n'

# Generated at 2022-06-22 00:54:33.638130
# Unit test for function version
def test_version():
    from . import __version__
    from .shells import shell_info
    from .utils import get_python_version
    from .cmd_runner import Command

    print(version(__version__, get_python_version(),
                  shell_info(Command('fuck'))))

# Generated at 2022-06-22 00:54:34.760970
# Unit test for function warn
def test_warn():
    warn('Test')


# Generated at 2022-06-22 00:54:35.838230
# Unit test for function debug_time
def test_debug_time():
    with debug_time("TEST"):
        pass

# Generated at 2022-06-22 00:54:40.548669
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exception('Test title', sys.exc_info())

# Generated at 2022-06-22 00:54:43.714084
# Unit test for function version
def test_version():
    """
    >>> version('3.14', '2.7', 'bash-4.0')
    The Fuck 3.14 using Python 2.7 and bash-4.0
    """

# Generated at 2022-06-22 00:54:44.929476
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:54:45.625068
# Unit test for function already_configured
def test_already_configured():
    assert True

# Generated at 2022-06-22 00:54:57.475898
# Unit test for function exception
def test_exception():
    import six
    import io

    out = io.StringIO() if six.PY3 else io.BytesIO()
    with contextmanager(lambda: (yield out)) as get_out:
        try:
            raise Exception('The aaaaaaaaaaaaaaaaaaaaaaaa')
        except:
            exception('How are you?', sys.exc_info())

# Generated at 2022-06-22 00:55:03.425513
# Unit test for function debug
def test_debug():
    from unittest.mock import MagicMock
    from thefuck import settings
    settings.debug = True
    mock_stderr = MagicMock()
    with debug_time('test'):
        pass

    # assert_called_once_with(mock_stderr.write,
    #                                 b'DEBUG: test took: 0:00:00.000001\n')

# Generated at 2022-06-22 00:55:08.100172
# Unit test for function rule_failed
def test_rule_failed():
    rule = const.Rule(name='testrule',
                      match='ls',
                      get_new_command='echo "newcommand"',
                      enabled_by_default=1)
    exc_info=(None, None, None)
    rule_failed(rule,exc_info)

# Generated at 2022-06-22 00:55:11.270513
# Unit test for function rule_failed
def test_rule_failed():
    try:
        rule_failed('test_rule_failed', sys.exc_info())
    except:
        assert False


# Generated at 2022-06-22 00:55:13.326511
# Unit test for function configured_successfully
def test_configured_successfully():
    assert len(list(configured_successfully(
            const.ConfigurationDetails(*['reload'])))) == 1

# Generated at 2022-06-22 00:55:22.769690
# Unit test for function configured_successfully
def test_configured_successfully():
    args = object()
    output = object()

    class ConfigurationDetails(object):
        def __init__(self, reload):
            self.reload = reload

    with mock.patch('sys.stdout', output):
        configured_successfully(ConfigurationDetails('reload!'))

    assert output.write.called_with(
        u"{bold}fuck{reset} alias configured successfully!\n"
        u"For applying changes run {bold}reload!{reset}"
        u" or restart your shell.\n".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-22 00:55:33.781713
# Unit test for function exception
def test_exception():
    import StringIO

    exc_info = (Exception, Exception('foo'), None)

    original_stderr = sys.stderr
    try:
        sys.stderr = StringIO.StringIO()
        exception('bar', exc_info)
        assert u'[WARN] bar' in sys.stderr.getvalue()
        assert u'foo' in sys.stderr.getvalue()
    finally:
        sys.stderr = original_stderr



# Generated at 2022-06-22 00:55:34.824360
# Unit test for function already_configured
def test_already_configured():
    t = already_configured(configuration_details)

# Generated at 2022-06-22 00:55:46.865589
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    from datetime import timedelta
    from unittest import TestCase

    class DebugTimeTest(TestCase):
        def test_debug_time(self):
            @contextmanager
            def debug_time(msg):
                started = datetime.now()
                try:
                    yield
                finally:
                    debug(u'{} took: {}'.format(msg, datetime.now() - started))
            with debug_time('Debug'):
                sleep(2)
            self.assertEqual(u'Debug took: 0:00:02.002000\n', mock_stdout.getvalue())

    from cStringIO import StringIO
    mock_stdout = StringIO()
    sys.stdout = mock_stdout
    DebugTimeTest().test_debug_time()

# Generated at 2022-06-22 00:55:47.490707
# Unit test for function warn
def test_warn():
    warn('thefuck')

# Generated at 2022-06-22 00:55:50.427258
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN + 'foo') == colorama.Fore.GREEN + 'foo'
    assert color('foo') == ''

# Generated at 2022-06-22 00:55:51.610122
# Unit test for function debug
def test_debug():
    assert(debug('test') == None)

# Generated at 2022-06-22 00:55:54.988993
# Unit test for function warn
def test_warn():
    from tests.utils import capture_stderr
    print(capture_stderr(warn, 'test'))
    assert capture_stderr(warn, 'test') == '[WARN] test\n'



# Generated at 2022-06-22 00:55:56.828837
# Unit test for function debug
def test_debug():
    assert debug('test') == sys.stderr.write('\x1b[2m\x1b[34mDEBUG:\x1b[0m test\n')


# Generated at 2022-06-22 00:56:09.252673
# Unit test for function warn
def test_warn():
    from . import conf
    from .tools import replace_argument

    # given
    saved_no_colors = conf.no_colors
    conf.no_colors = True
    with replace_argument('sys.stderr.write', lambda a: _saved['write'](a + '\n')):
        # when
        warn('TEXT')

        # then
        assert _saved['write'] == '[WARN] TEXT'

    # given
    conf.no_colors = False
    with replace_argument('sys.stderr.write', lambda a: _saved['write'](a + '\n')):
        # when
        warn('TEXT')

        # then

# Generated at 2022-06-22 00:56:14.257579
# Unit test for function warn
def test_warn():
    from .utils import wrap_streams
    from .utils import get_closest
    import StringIO
    test_stderr = StringIO.StringIO()
    err_msg = 'test warn'
    with wrap_streams([sys.stderr], [test_stderr]):
        warn(err_msg)
    assert get_closest(test_stderr, [err_msg])

# Generated at 2022-06-22 00:56:28.050225
# Unit test for function debug
def test_debug():
    from . import main
    import mock

    with mock.patch('sys.stderr'):
        with open(__file__) as script:
            main.debug(script.read())

# Generated at 2022-06-22 00:56:30.233584
# Unit test for function already_configured
def test_already_configured():
    return already_configured({'reload': '. ~/.bash_profile'})



# Generated at 2022-06-22 00:56:34.982891
# Unit test for function warn
def test_warn():
    if __file__ == 'thefuck/ui/ui.py':
        from unittest import mock

        with mock.patch('sys.stderr') as err:
            warn(u'Title')
            assert err.buffer.write.call_count == 1



# Generated at 2022-06-22 00:56:39.250078
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    from .shells import Shell

    shell = Shell()
    cmd = CorrectedCommand('ls', '-la', 'ls -la')
    show_corrected_command(cmd)



# Generated at 2022-06-22 00:56:40.807707
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(configuration_details)
    configured_successfully(None)

# Generated at 2022-06-22 00:56:45.642945
# Unit test for function failed
def test_failed():
    from .utils import captured_stderr
    with captured_stderr(lambda: failed(u'привет')) as output:
        assert output == u'\x1b[31mпривет\x1b[0m\n'



# Generated at 2022-06-22 00:56:49.265657
# Unit test for function rule_failed
def test_rule_failed():
    def rule():
        pass
    rule.name = 'sample'
    try:
        raise AssertionError('1+1=3')
    except AssertionError:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-22 00:57:00.024030
# Unit test for function color
def test_color():
    # disable colors
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

    # check colors are working correctly
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

    # disable colors again
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''
    assert color(colorama.Style.RESET_ALL) == ''

# Generated at 2022-06-22 00:57:05.037147
# Unit test for function warn
def test_warn():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        warn('title')

    assert stderr.getvalue() == u'[WARN] title\n'



# Generated at 2022-06-22 00:57:06.814832
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("rule", "exc_info")

# Generated at 2022-06-22 00:57:14.821087
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {"path": '~/.bash_profile',
                             "content": 'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
                             "reload": 'source ~/.bash_profile',
                             "can_configure_automatically": True}
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:57:27.223626
# Unit test for function exception
def test_exception():
    msg = u'error'
    exception_info = ('', UnicodeDecodeError('', b'', 1, 2, ''), '')
    from cStringIO import StringIO
    stderr = StringIO()
    system_stderr = sys.stderr

# Generated at 2022-06-22 00:57:30.661051
# Unit test for function warn
def test_warn():
    import io
    stderr = io.StringIO()
    sys.stderr = stderr
    warn('title')
    assert stderr.getvalue() == u'[WARN] title\n'



# Generated at 2022-06-22 00:57:42.213059
# Unit test for function failed
def test_failed():
    from testing.mocks import MockMaster
    from testing.mocks import MockSettings
    from testing.mocks import MockedPopen, MockedPopenSideEffect

    class MockedSys:
        stderr = None

    mock_sys = MockedSys()
    mock_sys.stderr = MockMaster()

    with MockedPopen(MockedPopenSideEffect(), 'stderr'):
        settings = MockSettings()
        settings.no_colors = False
        failed('Error')
        assert mock_sys.stderr.write.call_count == 1
        assert mock_sys.stderr.write.call_list == [((u'\033[91mError\033[0m\n',), {})]

# Generated at 2022-06-22 00:57:51.892623
# Unit test for function already_configured
def test_already_configured():
    class ConfigurationDetails(object):
        def __init__(self):
            self.old_alias = 'fuck'

    configuration_details = ConfigurationDetails()

    from io import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()

    already_configured(configuration_details)

    sys.stdout = old_stdout
    assert mystdout.getvalue() == u"Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1mfuck\x1b[21m or restart your shell.\n"

# Generated at 2022-06-22 00:57:53.061651
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("echo 'thefuck'")


# Generated at 2022-06-22 00:57:56.098795
# Unit test for function failed
def test_failed():
    msg = "test"
    try:
        failed(msg)
    except SystemExit:
        pass
    else:
        assert False, "Should raise SystemExit"



# Generated at 2022-06-22 00:57:57.683533
# Unit test for function already_configured
def test_already_configured():
    print (already_configured(reload))

# Generated at 2022-06-22 00:58:00.167248
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception as e:
        exception('Testing exception', sys.exc_info())


# Generated at 2022-06-22 00:58:06.970377
# Unit test for function warn
def test_warn():
    import io
    import sys
    stderr = io.StringIO()
    sys.stderr = stderr
    warn('test')
    sys.stderr = sys.__stderr__
    assert stderr.getvalue() == u'\x1b[101m\x1b[97m\x1b[1m[WARN] test\x1b[0m\n'


# Generated at 2022-06-22 00:58:13.222116
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('`bliblip`')
    show_corrected_command('`bliblob`')
    show_corrected_command('`blibloup`')


# Generated at 2022-06-22 00:58:17.622246
# Unit test for function exception
def test_exception():
    def raise_exception():
        raise RuntimeError('foo')
    try:
        raise_exception()
    except:
        import sys
        exception('msg', sys.exc_info())

if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-22 00:58:20.390238
# Unit test for function version
def test_version():
    from mock import patch
    from thefuck.utils import wrap_popen
    from .shells import ShellInfo
    from . import __version__ as version

    with patch.object(sys.modules[__name__], 'sys') as sys,\
            patch('{}.Popen'.format(sys.modules[__name__].__name__),
                  new=wrap_popen(ShellInfo('', '', ''))):
        sys.version = 'VersionString'
        version(version, sys.version, ShellInfo('', '', ''))
        assert sys.stderr.write.called

# Generated at 2022-06-22 00:58:21.550901
# Unit test for function already_configured
def test_already_configured():
    print (already_configured)


# Generated at 2022-06-22 00:58:25.686355
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    from .conf import Config
    Config.PATH = 'DummyPath'
    Config.REPLACE_COMMAND = 'DummyCommand'
    print(already_configured(Config))



# Generated at 2022-06-22 00:58:26.671575
# Unit test for function already_configured
def test_already_configured():
    already_configured("Hello")


# Generated at 2022-06-22 00:58:28.343439
# Unit test for function exception
def test_exception():
    with pytest.raises(SystemExit):
        exception(1, 1)


# Generated at 2022-06-22 00:58:38.230913
# Unit test for function failed
def test_failed():
    import mock

    message = 'Test message'
    with mock.patch('thefuck.shells.colorama') as colorama_mock:
        with mock.patch('thefuck.shells.sys') as sys_mock:
            colorama_mock.Fore.RED = 'red'
            colorama_mock.Style.RESET_ALL = 'reset'
            failed(message)
            sys_mock.stderr.write.assert_called_once_with(
                u'red{msg}reset\n'.format(msg=message))

# Generated at 2022-06-22 00:58:39.422198
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("fuck", "3.5")

# Generated at 2022-06-22 00:58:40.763822
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('foo'):
        time.sleep(0.5)

# Generated at 2022-06-22 00:58:53.149575
# Unit test for function already_configured
def test_already_configured():
    already_configured_details = const.ConfigurationDetails(
        reload='reload',
        can_configure_automatically=False,
        path='path',
        content='content')
    assert (u'Seems like {bold}fuck{reset} alias already configured!\n'
            u'For applying changes run {bold}reload{reset} or restart your shell.'.format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)) ==
            already_configured(already_configured_details))

# Generated at 2022-06-22 00:58:54.300660
# Unit test for function warn
def test_warn():
    warn(u'foo')



# Generated at 2022-06-22 00:58:55.175085
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-22 00:58:56.532448
# Unit test for function exception
def test_exception():
    try:
        raise Exception('fuck')
    except Exception:
        exception('test', sys.exc_info())

# Generated at 2022-06-22 00:58:59.945244
# Unit test for function warn
def test_warn():
    from .utils import capture_stderr
    from .types import Command

    with capture_stderr() as stderr:
        warn('Message')
    assert stderr.getvalue() == u'[WARN] Message\n'



# Generated at 2022-06-22 00:59:06.872965
# Unit test for function already_configured
def test_already_configured():
    import cStringIO
    import sys
    out = cStringIO.StringIO()
    sys.stdout = out
    already_configured(None)
    output = out.getvalue().strip()
    assert output == u"Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[21m or restart your shell."


# Generated at 2022-06-22 00:59:10.520632
# Unit test for function already_configured
def test_already_configured():
    error = u'Seems like fuck alias already configured!\n'
    error += u"For applying changes run reload or restart your shell."
    assert already_configured('reload') == error


# Generated at 2022-06-22 00:59:14.112243
# Unit test for function failed
def test_failed():
    assert failed(u'\nпроблема\n') == u'\x1b[31m\nпроблема\n\x1b[0m\n'

# Generated at 2022-06-22 00:59:16.483409
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except Exception:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-22 00:59:28.601596
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    content = 'alias fuck=\'eval $(thefuck $(fc -ln -1))\''
    path = '~/.bashrc'
    reload = 'source ~/.bashrc'
    can_configure_automatically = True
    configuration_details = const.ConfigurationDetails(content,
                                                        path,
                                                        reload,
                                                        can_configure_automatically)
    script = 'sudo ls'
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-22 00:59:38.440188
# Unit test for function debug
def test_debug():
    import mock
    import thefuck
    from thefuck.types import Shell

    with mock.patch('thefuck.utils.sys') as mock_sys:
        thefuck.enable_debug(Shell())
        thefuck.debug('message')
        mock_sys.stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n')



# Generated at 2022-06-22 00:59:41.178780
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rules.tolerance import _tolerance_variables
    assert how_to_configure_alias(None) is None
    assert how_to_configure_alias(_tolerance_variables()) is None

# Generated at 2022-06-22 00:59:44.794732
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exception('test_exception', sys.exc_info())

# Generated at 2022-06-22 00:59:47.743497
# Unit test for function exception
def test_exception():
    def test():
        try:
            int('123a')
        except Exception as e:
            exception('exception', sys.exc_info())
    test()

# Generated at 2022-06-22 00:59:53.826174
# Unit test for function debug
def test_debug():
    import io
    import sys

    try:
        debug_text = io.StringIO()
        sys.stderr = debug_text
        settings.debug = True

        debug('test debug')

        assert debug_text.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:59:58.404757
# Unit test for function failed
def test_failed():
    import io
    stdout = sys.stderr
    sys.stderr = io.BytesIO()
    failed('test')
    assert sys.stderr.getvalue().decode('utf-8') == u'reset\n'

# Generated at 2022-06-22 01:00:03.316599
# Unit test for function already_configured
def test_already_configured():
    from .shells.bash import Bash
    from .shells.base import reload_command
    from .configuration_details import ConfigurationDetails

    details = ConfigurationDetails(Bash(),
                                   reload_command=reload_command,
                                   can_configure_automatically=True)
    already_configured(details)

# Generated at 2022-06-22 01:00:05.450863
# Unit test for function confirm_text
def test_confirm_text():
    confirmed = ''
    corrected_command = 'ls -la'
    confirm_text(corrected_command)
    confirmed = sys.stderr.getvalue()
    assert confirmed == '>ls -la [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-22 01:00:08.596921
# Unit test for function color
def test_color():
    assert color(u'a') == u'a'
    settings.no_colors = True
    assert color(u'a') == u''

# Generated at 2022-06-22 01:00:14.709970
# Unit test for function color
def test_color():
    assert color(u'a') == u''
    assert color(u'\033[1;30m') == u''

    settings.no_colors = False
    assert color(u'a') == u'a'
    assert color(u'\033[1;30m') == u'\033[1;30m'

    settings.no_colors = True

# Generated at 2022-06-22 01:00:22.250760
# Unit test for function color
def test_color():
    assert color(u'Hello') == u'Hello'
    assert color(u'Hello') != u'!Hello'

# Generated at 2022-06-22 01:00:28.844242
# Unit test for function version
def test_version():
    f = sys.stderr
    sys.stderr = sys.stdout
    version('1.2.3-4', '2.7.8', 'shell 1.2.3')
    version('1.2.3-4', '2.7.8', 'shell 1.2.3')
    sys.stderr = f

if __name__ == '__main__':
    test_version()

# Generated at 2022-06-22 01:00:35.775894
# Unit test for function debug
def test_debug():
    from unittest import mock
    import io

    with mock.patch('sys.stderr', new=io.StringIO()) as err:
        debug(u'message')
    # On Python 2 output is encoded as ascii
    if sys.version_info[0] == 2:
        assert u'message'.encode('ascii') in err.getvalue()
    else:
        assert u'message' in err.getvalue()



# Generated at 2022-06-22 01:00:39.868892
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Test the show corrected command to make sure that the color
    """
    assert show_corrected_command(('fuck', '--no-colors')) == 'fuck'


# Generated at 2022-06-22 01:00:44.423888
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .compat import unicode
    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=True,
        path=unicode('path'),
        content=unicode('content'),
        reload=unicode('reload')))

# Generated at 2022-06-22 01:00:46.261788
# Unit test for function already_configured
def test_already_configured():
    #Check the function works
    assert(already_configured('something') == None)

# Generated at 2022-06-22 01:00:49.461953
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-22 01:00:52.837073
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {"reload": "source ~/.bash_profile"}
    configured_successfully(configuration_details)


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 01:01:02.340762
# Unit test for function failed
def test_failed():
    class TestStream(object):
        def __init__(self):
            self.written = ''

        def write(self, content):
            self.written += content
    old_stderr, sys.stderr = sys.stderr, TestStream()
    try:
        failed(u'Test message')
        assert sys.stderr.written == u'{red}Test message{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL))
    finally:
        sys.stderr = old_stderr