

# Generated at 2022-06-22 00:51:14.933486
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'rule'
    exc_info = ()
    rule = 'rule'
    rule_failed(rule, exc_info)
    rule_failed(rule, ())
    rule_failed(rule, (1, 2, 'three'))
    rule_failed(rule, (1, 2, 3, 4))
    rule_failed(rule, (1, 'two', 3, 4))
    rule_failed(rule, (1, 2, 'three', 4))
    rule_failed(rule, (1, 2, 3, 'four'))
    rule_failed(rule, (1, 'two', 3, 'four'))
    rule_failed(rule, ('one', 2, 'three', 'four'))
    rule_failed(rule, ('one', 2, 3,'four'))

# Generated at 2022-06-22 00:51:16.084329
# Unit test for function failed
def test_failed():
    failed(u'foo')



# Generated at 2022-06-22 00:51:20.004343
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    assert match(u'echo test')
    rule_failed(get_new_command, u'echo test', (
        None, None, None, ))

# Generated at 2022-06-22 00:51:21.464681
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:51:28.244319
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .shells import Zsh
    from .types import CorrectedCommand

    corrected_command = CorrectedCommand('git log --oneline', True)
    confirm_text(corrected_command)

# Generated at 2022-06-22 00:51:31.937464
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Command object for testing
    class Command(object):
        script = "I'm a command"
        side_effect = False

    # test
    show_corrected_command(Command())
    assert True

# Generated at 2022-06-22 00:51:38.994369
# Unit test for function debug
def test_debug():
    from mock import call, patch
    with patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_has_calls([call(u'{blue}{bold}DEBUG:{reset} foo\n'.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT)))])

# Generated at 2022-06-22 00:51:45.418408
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import datetime, timedelta
    from .runner import debug
    with patch('datetime.datetime') as datetime_mock:
        datetime_mock.now.return_value = datetime(2013, 1, 1)
        with debug_time('some task'):
            datetime_mock.now.return_value += timedelta(seconds=2)
    assert debug.called



# Generated at 2022-06-22 00:51:56.584270
# Unit test for function rule_failed
def test_rule_failed():
    # output = sys.stderr.write(u'{warn}[WARN] {title}{reset}\n'.format(
    #     warn=color(colorama.Back.RED + colorama.Fore.WHITE
    #                + colorama.Style.BRIGHT),
    #     reset=color(colorama.Style.RESET_ALL),
    #     title=title))
    output = u'{warn}[WARN] {title}{reset}\n'.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title=title)
    assert(output == colored_output)


# Generated at 2022-06-22 00:52:02.559771
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        const.ConfigurationDetails(
            'content', 'path', 'reload', can_configure_automatically=True))
    how_to_configure_alias(
        const.ConfigurationDetails(
            'content', 'path', 'reload', can_configure_automatically=False))

# Generated at 2022-06-22 00:52:18.795138
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import tempfile

    old_stderr = sys.stderr
    sys.stderr = io.StringIO()
    try:
        settings._set_no_colors()
        const.USER_COMMAND_MARK = u'>>> '
        show_corrected_command(u'echo 42')
        assert sys.stderr.getvalue() == u'>>> echo 42\n'
    finally:
        sys.stderr = old_stderr
    settings._set_colors()

    const.USER_COMMAND_MARK = u'>>> '
    show_corrected_command(u'echo 42')
    assert sys.stderr.getvalue() == u'>>> echo 42\n'

    const.USER_COMMAND_MARK = u'>>> '
    show

# Generated at 2022-06-22 00:52:22.576090
# Unit test for function warn
def test_warn():
    with settings(no_colors=False):
        assert warn('title') == '\x1b[40;37;1m[WARN] title\x1b[0m\n'



# Generated at 2022-06-22 00:52:30.012050
# Unit test for function debug_time
def test_debug_time():
    import datetime
    import re
    import time

    with debug_time('test'):
        time.sleep(0.01)

    debug_msg = sys.stderr.getvalue()
    sys.stderr = StringIO()

    seconds_str = re.search('took: (.*)', debug_msg).group(1)
    seconds = float(seconds_str[:-1])
    assert seconds > 0.0

# Generated at 2022-06-22 00:52:31.146222
# Unit test for function debug
def test_debug():
    print('')
    debug('test')

# Generated at 2022-06-22 00:52:43.627701
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import subprocess
    import tempfile
    import platform
    import os
    import filecmp
    import shutil

    BASH_HISTORY_TEST_CONTENTS = 'wrong command\n'
    BASH_INIT_TEST_CONTENTS = 'export SHELL=~/.bashrc\n'
    ZSH_INIT_TEST_CONTENTS = 'export SHELL=~/.zshrc\n'
    CONFIG_TEST_CONTENTS = 'alias fuck=\'/bin/test-script\'\n'
    BASH_TEST_CONTENTS = '#!/bin/bash\n'
    ZSH_TEST_CONTENTS = '#!/bin/zsh\n'
    ZSH_HISTORY_TEST_CONTENTS = 'cd ~\n'
    CONFIG_TEST_FILE = 'test-config'


# Generated at 2022-06-22 00:52:47.365913
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails

    how_to_configure_alias(ConfigurationDetails(path='test',
                                                reload='test',
                                                content='test',
                                                can_configure_automatically=True))

# Generated at 2022-06-22 00:52:49.797097
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError(u'test')
    except RuntimeError:
        exception(u'title', sys.exc_info())



# Generated at 2022-06-22 00:52:50.578861
# Unit test for function warn
def test_warn():
    warn('test_warn')



# Generated at 2022-06-22 00:52:57.969086
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    from thefuck.main import Command, State
    original_stderr = sys.stderr

# Generated at 2022-06-22 00:52:59.626501
# Unit test for function version
def test_version():
    version('1.0', '2.7', 'shell')



# Generated at 2022-06-22 00:53:07.540799
# Unit test for function failed
def test_failed():
    assert failed(u'foo bar') == u'\x1b[31mfoo bar\x1b[0m\n'

# Generated at 2022-06-22 00:53:11.595138
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('MockedRule', (object,), dict(name='MockedRule'))()
    try:
        raise ValueError('This is a dummy error')
    except:
        rule_failed(rule, sys.exc_info())



# Generated at 2022-06-22 00:53:15.804748
# Unit test for function failed
def test_failed():
    from unittest import mock
    from io import StringIO
    stream = StringIO()
    with mock.patch('sys.stderr', new=stream):
        failed(u'foo')
        assert stream.getvalue() == color(colorama.Fore.RED) + 'foo' + \
                                   color(colorama.Style.RESET_ALL) + '\n'

# Generated at 2022-06-22 00:53:28.470728
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from mock import patch, call
    from thefuck.utils import debug, debug_time
    from contextlib import contextmanager
    from datetime import datetime, timedelta
    from mock import patch, call
    from thefuck.utils import debug, debug_time
    import sys

    @contextmanager
    def _debug_time(msg):
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, timedelta(seconds=1)))

    with patch('thefuck.utils.debug', return_value=None) as debug:
        with _debug_time('test'):
            pass

        assert debug.called
        assert debug.call_args_list == [
            call(u'test took: 0:00:01'),
        ]


# Generated at 2022-06-22 00:53:33.589701
# Unit test for function version
def test_version():
    colorama.init()
    output = ''
    sys.stderr.write = output.write
    version('3.11.0', '3.6.2', shell_info='Bash 4.4.12')
    assert output == u'The Fuck 3.11.0 using Python 3.6.2 and Bash 4.4.12\n'

# Generated at 2022-06-22 00:53:37.078439
# Unit test for function version
def test_version():
    assert version('3.2', '3.5', 'bash') == \
        u'The Fuck 3.2 using Python 3.5 and bash\n'

# Generated at 2022-06-22 00:53:40.184742
# Unit test for function version
def test_version():
    import thefuck.shells
    thefuck.shells.get_shell = lambda: 'Shell'
    version('2.0', '2.7.5', 'Shell')



# Generated at 2022-06-22 00:53:44.571175
# Unit test for function warn
def test_warn():
    warn(u'msg') == u'\x1b[101m[WARN] msg\x1b[0m\n'
    with settings(no_colors=True):
        warn(u'msg') == u'[WARN] msg\n'


# Generated at 2022-06-22 00:53:48.352350
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    exc_info = (Exception, Exception('test'), None)
    rule = Rule('test', lambda *args: None, 'test')
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:53:54.342790
# Unit test for function failed
def test_failed():
    sys.stderr = open('/tmp/thefuck_test.log', 'w')
    failed(u'Тест')
    sys.stderr.close()
    with open('/tmp/thefuck_test.log', 'r') as f:
        assert f.read() == u'\x1b[31mТест\x1b[0m\n'

# Generated at 2022-06-22 00:54:09.534626
# Unit test for function debug_time
def test_debug_time():
    from unittest import TestCase, main
    from datetime import timedelta
    from mock import MagicMock, patch

    class DebugTimeTestCase(TestCase):
        def call_debug_time(self, debug_time_, time_, msg):
            with debug_time(msg):
                time_.return_value = timedelta(seconds=5)
                debug_time_.assert_called_once_with(u'{} took: {}'.format(msg, time_.return_value))
                debug_time_.reset_mock()

        def test_debug_time(self):
            time_ = MagicMock(return_value=timedelta(seconds=5))
            debug_time_ = MagicMock()
            msg = 'command'

            self.call_debug_time(debug_time_, time_, msg)

           

# Generated at 2022-06-22 00:54:20.761985
# Unit test for function confirm_text
def test_confirm_text():
    from .application import Application
    from .models import Command
    from .shells import BaseShell
    from .utils import memoize

    # This will be called instead of `input`, for testing.
    def user_input(s):
        return 'y'

    class TestShell(BaseShell):
        @memoize
        def _get_executed_script(self, command):
            return u'pwd'

    a = Application(
        [], None, None, TestShell())

    confirm_text(Command('whoami', u'whoami', u'whoami', None))
    confirm_text(Command('whoami', u'whoami', u'whoami', u'echo "fuck!"'))

    # test that confirm_text doesn't break after new command is given
    a.correct_command(user_input)
    confirm_

# Generated at 2022-06-22 00:54:23.692022
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls -al'))
    sys.stderr.write(u'\n')



# Generated at 2022-06-22 00:54:24.966840
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Debug time test'):
        pass

# Generated at 2022-06-22 00:54:26.119280
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-22 00:54:34.433156
# Unit test for function failed
def test_failed():
    msg = 'test_failed'

    import StringIO
    from contextlib import contextmanager
    save_stdout = sys.stderr
    try:
        sys.stderr = StringIO.StringIO()
        failed(msg)
        sys.stderr.seek(0)
        assert sys.stderr.read() == color(colorama.Fore.RED) + msg + color(colorama.Style.RESET_ALL) + '\n'
    finally:
        sys.stderr = save_stdout



# Generated at 2022-06-22 00:54:43.080719
# Unit test for function already_configured
def test_already_configured():
    import StringIO
    import sys

    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out

        already_configured({'reload': 'echo "hi"'})
        output = out.getvalue().strip()
        assert output == u'Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1mecho "hi"\x1b[21m or restart your shell.'
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-22 00:54:47.536660
# Unit test for function color
def test_color():
    assert color('red') == ''
    assert not settings.no_colors
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == unicode(colorama.Fore.RED)

# Generated at 2022-06-22 00:54:49.550111
# Unit test for function exception
def test_exception():
    try:
        raise Exception("foo")
    except Exception:
        exception(u'foo', sys.exc_info())

# Generated at 2022-06-22 00:54:54.154057
# Unit test for function color
def test_color():
    assert color('red text') == u'\x1b[31mred text\x1b[0m'
    settings.no_colors = True
    assert color('red text') == u'red text'
    settings.no_colors = False



# Generated at 2022-06-22 00:55:12.189610
# Unit test for function confirm_text
def test_confirm_text():
    test = confirm_text
    assert test(
        CorrectedCommand('ls', False)) == (
            '\n{prefix}{clear}{bold}{script}{reset}{side_effect} '
            '[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
            '/{red}ctrl+c{reset}]').format(
                prefix=const.USER_COMMAND_MARK,
                script='ls',
                side_effect='',
                clear='\033[1K\r',
                bold=color(colorama.Style.BRIGHT),
                green=color(colorama.Fore.GREEN),
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE))


# Generated at 2022-06-22 00:55:14.249199
# Unit test for function warn
def test_warn():
    warn(u'Тестовая ошибка')



# Generated at 2022-06-22 00:55:15.993934
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''
    settings.no_colors = False



# Generated at 2022-06-22 00:55:25.901796
# Unit test for function version
def test_version():
    """Unit test for function version

    This is a unit test for the version function. It was built for the thefuck
    project by the team at Teclo. It has been open sourced and can be found at
    the following link:
    https://github.com/nvbn/thefuck/blob/master/tests/test_utils.py
    """

    # Function inputs
    thefuck_version = '3.11'
    python_version = 2.7
    shell_info = 'zsh'

    # Function output
    output = 'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                           python_version,
                                                           shell_info)

    # Call the function
    sys.stderr = open('tests/output', 'w')

# Generated at 2022-06-22 00:55:27.532840
# Unit test for function already_configured
def test_already_configured():
    already_configured("qa")


# Generated at 2022-06-22 00:55:35.664964
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.BLUE + colorama.Back.GREEN) == (
        colorama.Fore.BLUE + colorama.Back.GREEN)
    assert color('') == ''
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Fore.BLUE + colorama.Back.GREEN) == ''
    assert color('') == ''
    settings.no_colors = False

# Generated at 2022-06-22 00:55:39.936349
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(
        configuration_details=None)\
        == 'The Fuck alias configured successfully!\n' +\
           'For applying changes run source ~/.bashrc or restart your shell.'

# Generated at 2022-06-22 00:55:47.050778
# Unit test for function warn
def test_warn():
    import io
    from thefuck.utils import get_closest, get_closest_exe

    def test_warn_impl(stderr, title):
        colorama.init()
        # Reset STDERR
        stderr.truncate(0)
        stderr.seek(0)
        warn(title)
        return stderr.getvalue()

    with open(__file__) as script_file:
        test_warn_impl(io.StringIO(), script_file.read())



# Generated at 2022-06-22 00:55:49.456473
# Unit test for function color
def test_color():
    assert color('hello') == colorama.Back.RED + 'hello' + colorama.Style.RESET_ALL

# Generated at 2022-06-22 00:55:51.610283
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-22 00:55:58.254587
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='ls -l')


# Generated at 2022-06-22 00:55:59.714351
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # TODO: implement it.
    pass

# Generated at 2022-06-22 00:56:00.733618
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command() == None

# Generated at 2022-06-22 00:56:12.834798
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from types import SimpleNamespace
    from . import main

    if main.settings.no_colors:
        assert show_corrected_command(SimpleNamespace(script='sudo')) == '> sudo\n'
        assert show_corrected_command(SimpleNamespace(script='grep', side_effect=True)) == '> grep (+side effect)\n'
    else:
        assert show_corrected_command(SimpleNamespace(script='sudo')) == \
            '\x1b[0;32m>\x1b[0m sudo\n'

# Generated at 2022-06-22 00:56:17.846646
# Unit test for function debug_time
def test_debug_time():
    # Can't test output, but can test that it returns the same value,
    # and that debug_time dones't kill anything
    value = False
    with debug_time('test'):
        value = True

    assert value, "debug_time kills executed code inside"


# Generated at 2022-06-22 00:56:19.050535
# Unit test for function already_configured
def test_already_configured():
	already_configured(1)
	


# Generated at 2022-06-22 00:56:25.597562
# Unit test for function exception
def test_exception():
    sys.stderr.write(u'\nTest exception function :\n')
    exception(u'Test title 1', (Exception, Exception(u'test msg 1'),
                               Exception))
    exception(u'Test title 2', (Exception, Exception(u'test msg 2'),
                               Exception))
    exception(u'Test title 3', (Exception, Exception(u'test msg 3'),
                               Exception))

# Generated at 2022-06-22 00:56:35.684643
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    import contextlib
    class Rule:
        def __init__(self, name):
            self.name = name
        def enabled_by_default(self):
            return True
    rule = Rule('test_rule')
    buff = StringIO.StringIO()
    with contextlib.redirect_stderr(buff):
        rule_failed(rule, (Exception, Exception('test'), None))
    assert 'rule test_rule' in buff.getvalue()
    assert 'test' in buff.getvalue()
    assert 'Exception' in buff.getvalue()


# Generated at 2022-06-22 00:56:39.357036
# Unit test for function debug
def test_debug():
    from . import utils
    settings.debug = True
    utils.debug('test')
    settings.debug = False
    utils.debug('test')

# Unit tests for colors

# Generated at 2022-06-22 00:56:41.374542
# Unit test for function version
def test_version():
    version("v3.11.0", "3.5.2", "GNU bash, version 3.2.57")

# Generated at 2022-06-22 00:56:47.548280
# Unit test for function warn
def test_warn():
    warn(u'Test title')


# Generated at 2022-06-22 00:56:50.262476
# Unit test for function confirm_text
def test_confirm_text():
    result = confirm_text('ls -l')
    assert result == 'ls -l [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:56:57.143507
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(dict(reload='source ~/.bashrc')) == print(
            u"Seems like {bold}fuck{reset} alias already configured!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload='source ~/.bashrc'))


# Generated at 2022-06-22 00:56:58.185006
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("source ~/.bash_profile")

# Generated at 2022-06-22 00:57:00.625743
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('configuration_details') == None

if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 00:57:04.250533
# Unit test for function color
def test_color():
    assert color('Any string') == 'Any string'
    settings.no_colors = True
    assert color('Any string') == ''
    settings.no_colors = False



# Generated at 2022-06-22 00:57:14.711241
# Unit test for function version
def test_version():
    import sys
    import pkg_resources
    from thefuck.shells import get_shell_info

    # Allocate the new stdout
    new_stdout = sys.stdout
    sys.stdout = sys.__stdout__

    # Get the versions of The Fuck and Python
    thefuck_version = pkg_resources.get_distribution('thefuck').version
    python_version = sys.version.split()[0]

    # Get the shell info
    shell_info = get_shell_info()

    # Print the informations
    version(thefuck_version, python_version, shell_info)

    # Reset the stdout
    sys.stdout = new_stdout

# Generated at 2022-06-22 00:57:19.456619
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rules.utils import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        path='~/.bashrc',
        reload='source ~/.bashrc',
        content="eval '(thefuck $(fc -ln -1))'",
        can_configure_automatically=True))



# Generated at 2022-06-22 00:57:20.577971
# Unit test for function failed
def test_failed():
    failed(u'test')

# Generated at 2022-06-22 00:57:21.770431
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(dict(reload="fuck"))

# Generated at 2022-06-22 00:57:29.589061
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import Command

    show_corrected_command(
        Command('ls', 'ls', '', '', side_effect=True))



# Generated at 2022-06-22 00:57:30.892895
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass



# Generated at 2022-06-22 00:57:33.582047
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.git_aware_prompt import match, get_new_command
    rule_failed(match, get_new_command)

# Generated at 2022-06-22 00:57:37.495011
# Unit test for function rule_failed
def test_rule_failed():
    try:
        1 / 0
    except ZeroDivisionError:
        the_traceback = sys.exc_info()

    # This is test for rule_failed
    rule_failed("rule", the_traceback)


# Generated at 2022-06-22 00:57:38.663835
# Unit test for function already_configured
def test_already_configured():
    already_configured('test')

# Generated at 2022-06-22 00:57:40.877964
# Unit test for function configured_successfully
def test_configured_successfully():
    print('testing configured_successfully')
    configured_successfully(None)
    assert True

# Generated at 2022-06-22 00:57:43.308442
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(Script('ls', side_effect=False)) == 'fuck ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:57:51.204315
# Unit test for function failed
def test_failed():
    import mock
    import os
    fd, tmp_file = os.pipe()
    with mock.patch('sys.stderr', os.fdopen(fd, 'w')):
        failed('msg')
    os.close(fd)
    with os.fdopen(tmp_file) as f:
        output = f.read()
        assert output == u'{red}msg{reset}\n'.format(red=color(colorama.Fore.RED),
                                                     reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-22 00:57:53.792631
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(123) == 'Seems like fuck alias already configured!\nFor applying changes run 123 or restart your shell.'

# Generated at 2022-06-22 00:57:57.310268
# Unit test for function version
def test_version():
    import os
    version('3.14', '2.7', ('shell', '3.14'))

    # Shell version can be None
    version('3.14', '2.7', ('shell', None))

# Generated at 2022-06-22 00:58:09.354981
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details) == \
        u"{bold}fuck{reset} alias configured successfully!\n" \
        u"For applying changes run {bold}{reload}{reset}" \
        u" or restart your shell.".format(bold=color(colorama.Style.BRIGHT),
                                          reset=color(colorama.Style.RESET_ALL),
                                          reload=configuration_details.reload)

# Generated at 2022-06-22 00:58:11.992538
# Unit test for function debug
def test_debug():
    assert 'DEBUG' in debug('123')
    assert const.USER_COMMAND_MARK in show_corrected_command('123')

# Generated at 2022-06-22 00:58:23.353026
# Unit test for function warn
def test_warn():
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('warn message')

    assert err.getvalue() == u'[WARN] warn message\n'



# Generated at 2022-06-22 00:58:32.973496
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import thefuck
    import thefuck.shells
    import thefuck.utils
    thefuck.shells.get_alias = lambda x: "fuck"
    thefuck.shells.get_history_file_name = lambda x: ".history"
    thefuck.conf.load_config = lambda: "{}"
    thefuck.conf.load_source = lambda x: "{}"
    thefuck.conf.reload_config = lambda: None
    thefuck.conf.update_config = lambda x: None
    thefuck.types.CorrectedCommand = lambda x, y: "corrected-command"
    thefuck.utils.get_all_matched_commands = lambda: ["cd /var/www/html && git status"]
    test_command = "git status"
    thefuck.main.get_key_presses = lambda: None

# Generated at 2022-06-22 00:58:38.349999
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN)('green') == 'green'
    assert color(colorama.Fore.BLUE)('red') == 'red'
    assert color(lambda x: colorama.Fore.GREEN + 'green')('not green') == ''

# Generated at 2022-06-22 00:58:40.351967
# Unit test for function color
def test_color():
    assert color('test')
    settings.no_colors = True
    assert not color('test')

# Generated at 2022-06-22 00:58:43.832390
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('Rule', (object,), {'name': 'test'})()
    try:
        raise BaseException()
    except BaseException:
        exc_info = sys.exc_info()

    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:58:56.569072
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    from .application import Application

    class EmptyRule(object):
        name = 'echo'
        priority = 0

        def match(self, *args, **kwargs):
            return match(*args, **kwargs)

        def get_new_command(self, *args, **kwargs):
            return get_new_command(*args, **kwargs)

    class TestApplication(Application):
        def __init__(self, *args, **kwargs):
            self._rules = [EmptyRule()]
            self._settings = settings._replace(no_colors=True, debug=False)

    sys.stderr = FakeStderr()
    app = TestApplication()

    exc_info = (Exception, Exception('foo'), None)

# Generated at 2022-06-22 00:58:58.174957
# Unit test for function exception
def test_exception():
    def test_func():
        raise Exception('test')
    test_func()



# Generated at 2022-06-22 00:59:00.028499
# Unit test for function debug
def test_debug():
    with DebugMode():
        debug('test_debug')



# Generated at 2022-06-22 00:59:17.775279
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import sys, StringIO
    class ConfigurationDetails(object):
        def __init__(self, path, content, reload, can_configure_automatically):
            self.path = path
            self.content = content
            self.reload = reload
            self.can_configure_automatically = can_configure_automatically

    def run_test(configuration_details, result):
        real_stdout = sys.stdout
        try:
            out = StringIO.StringIO()
            sys.stdout = out
            how_to_configure_alias(configuration_details)
            output = out.getvalue().strip()
            assert output == result
        finally:
            sys.stdout = real_stdout


# Generated at 2022-06-22 00:59:20.359586
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand

    show_corrected_command(CorrectedCommand('cmd', '', '', ''))



# Generated at 2022-06-22 00:59:27.231786
# Unit test for function configured_successfully
def test_configured_successfully():
    #Check whether we get correct output, when the input is correct
    assert (configured_successfully('configuration_details')==
            u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload))


# Generated at 2022-06-22 00:59:28.942519
# Unit test for function warn
def test_warn():
    assert(warn("Test warning") == "[WARN] Test warning")


# Generated at 2022-06-22 00:59:40.772601
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck import conf
    from thefuck.types import Command

# Generated at 2022-06-22 00:59:50.586045
# Unit test for function debug_time
def test_debug_time():
    import os
    import time
    import shutil
    import tempfile
    import re
    import sys
    time.sleep(0.01)
    filename = os.path.join(tempfile.mkdtemp(), 'debug.log')
    with open(filename, 'w') as f:
        sys.stderr = f
        with debug_time('Whatever'):
            time.sleep(0.01)
        assert re.match(
            r'Whatever took: .*', f.read())
    shutil.rmtree(os.path.dirname(filename))

# Generated at 2022-06-22 00:59:53.253691
# Unit test for function color
def test_color():
    assert color('red') == u'\x1b[31m'
    settings.no_colors = True
    assert color('red') == ''



# Generated at 2022-06-22 00:59:56.103088
# Unit test for function color
def test_color():
    assert color(u'\x1b[31m') == u'\x1b[31m'
    assert color(u'\x1b[31m') == u''

# Generated at 2022-06-22 01:00:02.618471
# Unit test for function version
def test_version():
    import tempfile
    tmp_file = tempfile.NamedTemporaryFile(delete=True)
    sys.stderr = tmp_file
    version('1.1', '2.7', 'bash')
    assert 'The Fuck 1.1 using Python 2.7 and bash' in sys.stderr.read()
    tmp_file.close()



# Generated at 2022-06-22 01:00:11.011397
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    _rst = sys.stderr
    sys.stderr = StringIO.StringIO()
    configured_successfully({'reload': 'reload_command'})
    sys.stderr.seek(0)
    assert(sys.stderr.read() == '\x1b[1mfuck\x1b[22m alias configured successfully!\nFor applying changes run \x1b[1mreload_command\x1b[22m or restart your shell.\n')
    sys.stderr = _rst

# Generated at 2022-06-22 01:00:17.945673
# Unit test for function already_configured
def test_already_configured():
    already_configured({"bold":"nvbn","reset":"nvbn","reset":"nvbn","reload":"nvbn"})

# Generated at 2022-06-22 01:00:20.832714
# Unit test for function exception

# Generated at 2022-06-22 01:00:21.333251
# Unit test for function debug
def test_debug():
    debug(u'test')


# Generated at 2022-06-22 01:00:23.921636
# Unit test for function debug_time
def test_debug_time():
    from thefuck.utils import debug_time

    @debug_time('some_name')
    def something():
        pass



# Generated at 2022-06-22 01:00:26.980224
# Unit test for function version
def test_version():
    return (version, ['The Fuck 3.5', 'Python 2.7.5', 'GNU bash, version 4.3.11'])

# Generated at 2022-06-22 01:00:28.433066
# Unit test for function warn
def test_warn():
    assert warn('Wrong command') == '[WARN] Wrong command\n'


# Generated at 2022-06-22 01:00:37.617693
# Unit test for function version
def test_version():
    from .utils import get_closest_shell

    try:
        from setuptools import __version__ as setuptools_version
    except ImportError:
        setuptools_version = '-'
    try:
        from pip import __version__ as pip_version
    except ImportError:
        pip_version = '-'

    shell = get_closest_shell()
    sys.stderr.write(
        u'The Fuck 3.0rc0 using Python 2.7.13, pip {} and {}\n'.format(
            pip_version, shell))



# Generated at 2022-06-22 01:00:38.737320
# Unit test for function already_configured
def test_already_configured():
    assert(already_configured('')) == 0

# Generated at 2022-06-22 01:00:39.719221
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()



# Generated at 2022-06-22 01:00:42.163635
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.bash import Bash
    how_to_configure_alias(Bash().get_aliases())



# Generated at 2022-06-22 01:00:51.093571
# Unit test for function warn
def test_warn():
    sys.stderr = sys.__stderr__ = open('/dev/null', 'w')
    warn('Hello, World!')
    sys.stderr.close()
    sys.__stderr__.close()

# Generated at 2022-06-22 01:00:54.917327
# Unit test for function already_configured
def test_already_configured():
    shell = 'Zsh'
    alias = 'fuck'
    command = 'source ~/.zshrc'

    assert already_configured(configured_successfully(shell, alias, command)) == \
        u"Seems like The Fuck alias already configured!\nFor applying changes run source ~/.zshrc or restart your shell."



# Generated at 2022-06-22 01:01:04.616847
# Unit test for function confirm_text