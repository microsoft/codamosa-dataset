

# Generated at 2022-06-22 00:50:59.856395
# Unit test for function failed
def test_failed():
    failed(u'проблема')

# Generated at 2022-06-22 00:51:01.211483
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-22 00:51:02.732077
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('foo'):
        time.sleep(1)

# Generated at 2022-06-22 00:51:09.729640
# Unit test for function warn
def test_warn():
    import mock
    warn('test warn')
    sys.stderr.flush() == '[WARN] test warn\n'

    # test warn with no_colors
    with mock.patch('thefuck.utils.settings') as settings_mock:
        settings_mock.no_colors = True
        warn('test warn')
        sys.stderr.flush() == '[WARN] test warn\n'



# Generated at 2022-06-22 00:51:13.194760
# Unit test for function exception
def test_exception():
    try:
        try:
            raise ValueError(u'привет')
        except ValueError as e:
            exception(u'Rule', sys.exc_info())
    except SystemExit:
        pass

# Generated at 2022-06-22 00:51:21.113399
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr') as mock_stderr:
        warn(u'text')
        mock_stderr.write.assert_called_once_with(
            u'{warn}[WARN] text{reset}\n'.format(
                warn=color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                title=u'text'))


# Generated at 2022-06-22 00:51:22.704066
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('message')



# Generated at 2022-06-22 00:51:32.058966
# Unit test for function failed
def test_failed():
    sys.stderr = open('/tmp/thefuck-logs', 'w')
    failed(u"Pусский текст не выводится\n")
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    with open('/tmp/thefuck-logs') as logs:
        assert u'Pусский текст не выводится\n' in logs.read()

# Generated at 2022-06-22 00:51:32.491612
# Unit test for function confirm_text
def test_confirm_text():
    colorama.init()
    confirm_text(None)

# Generated at 2022-06-22 00:51:40.557710
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    orig_stderr = sys.stderr
    stderr = StringIO.StringIO()
    try:
        sys.stderr = stderr
        show_corrected_command(object())
    finally:
        sys.stderr = orig_stderr
    if not stderr.getvalue().startswith(const.USER_COMMAND_MARK):
        raise Exception("Output string should contain '{}'".format(
            const.USER_COMMAND_MARK))

# Generated at 2022-06-22 00:51:48.532653
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .utils import decode_command_output

    with debug_time('Time'):
        decode_command_output(['sleep', '0.05'])

    debug(u'Time took: {}'.format(timedelta(seconds=0.05)))

# Generated at 2022-06-22 00:51:49.873912
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(3) == None

# Generated at 2022-06-22 00:51:52.548565
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', ('type', 'value', 'traceback'))



# Generated at 2022-06-22 00:51:56.505926
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from .shells import Shell

    out = StringIO()
    configured_successfully(Shell('zsh', 'reload-zsh'))
    assert out.getvalue() == "fuck"


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-22 00:52:01.317255
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple('configuration_details',
                                       'reload')
    reload = 'source ~/.bash_profile'
    configuration_details = configuration_details._make([reload])
    already_configured(configuration_details)


# Generated at 2022-06-22 00:52:02.322357
# Unit test for function rule_failed
def test_rule_failed():
     rule_failed(u'description', u'exception')

# Generated at 2022-06-22 00:52:03.718366
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:52:16.644499
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys
    sys.stderr = io.StringIO()
    how_to_configure_alias(None)
    sys.stderr.seek(0)
    assert sys.stderr.read() == u"Seems like The Fuck isn't configured!\nMore details - https://github.com/nvbn/thefuck#manual-installation\n"
    sys.stderr.seek(0)
    how_to_configure_alias("")
    sys.stderr.seek(0)
    assert sys.stderr.read() == u"Seems like The Fuck isn't configured!\nMore details - https://github.com/nvbn/thefuck#manual-installation\n"
    sys.stderr.seek(0)

# Generated at 2022-06-22 00:52:20.454987
# Unit test for function rule_failed
def test_rule_failed():
    import thefuck.rules.dummy
    test_rule_failed = thefuck.rules.dummy.dummy_rule
    exc_info = (Exception, Exception("error"), "traceback")
    rule_failed(test_rule_failed, exc_info)
    assert 1 == 1

# Generated at 2022-06-22 00:52:28.180910
# Unit test for function failed
def test_failed():
    import StringIO
    saved_stderr = sys.stderr
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        failed('failed')
        output = out.getvalue().strip()
    finally:
        sys.stderr = saved_stderr
    assert output == '\x1b[31mfailed\x1b[0m'

test_failed()

# Generated at 2022-06-22 00:52:33.864272
# Unit test for function version
def test_version():
    thefuck_version = '3.3'
    python_version = '3.6'
    shell_info = 'Shell'
    version(thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:52:35.858583
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("configuration_details") == u'fuck alias configured successfully!\nFor applying changes run configuration_details or restart your shell.'


# Generated at 2022-06-22 00:52:40.843710
# Unit test for function warn
def test_warn():
    assert warn(u'No such command') == '\x1b[107m\x1b[30m\x1b[1m' \
                                       '[WARN] No such command' \
                                       '\x1b[0m\n'



# Generated at 2022-06-22 00:52:49.013385
# Unit test for function version
def test_version():
    from . import __version__
    from .shells.factory import _get_shell_info

    import platform
    import re
    import subprocess

    version(__version__, platform.python_version(), _get_shell_info())

    output = subprocess.check_output(
        ['git', 'rev-list', '--count', 'HEAD'],
        stderr=subprocess.STDOUT)
    commit_count = int(re.search(r'\d+', output).group(0))

    assert str(commit_count) in open('tests/output', 'r').read()

# Generated at 2022-06-22 00:52:50.425592
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({})  # for coverage



# Generated at 2022-06-22 00:52:53.741266
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details="") \
        ==  u"{bold}fuck{reset} alias configured successfully!\n" \
            u"For applying changes run {bold}{reload}{reset}" \
            u" or restart your shell."

# Generated at 2022-06-22 00:52:55.129652
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:52:56.094511
# Unit test for function already_configured
def test_already_configured():
    print('aliases already configured.')

# Generated at 2022-06-22 00:53:00.373147
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Failure message')
    except Exception:
        _, _, traceback = sys.exc_info()
        exception('Title', (Exception, Exception('Failure message'),
                            traceback))
        exception('Second title', sys.exc_info())



# Generated at 2022-06-22 00:53:08.627836
# Unit test for function version
def test_version():
    assert version(
        thefuck_version="3.8",
        python_version="2.7.12",
        shell_info="bash") == None
    assert version(
        thefuck_version="3.8",
        python_version="2.7.12",
        shell_info="zsh") == None
    assert version(
        thefuck_version="3.8",
        python_version="2.7.12",
        shell_info="fish") == None


# Generated at 2022-06-22 00:53:12.278213
# Unit test for function debug_time
def test_debug_time():
    print(__name__)


# Generated at 2022-06-22 00:53:17.281822
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails

    class ShellInfo(object):
        can_configure_automatically = True
        name = 'shell'
        reload = 'reload shell'

    details = ConfigurationDetails(
        path='.bashrc',
        content='fuck = \n  eval $(thefuck $(fc -ln -1))',
        reload='reload shell',
        can_configure_automatically=True,
        shell_info=ShellInfo())

    how_to_configure_alias(details)



# Generated at 2022-06-22 00:53:25.933725
# Unit test for function exception

# Generated at 2022-06-22 00:53:28.177747
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        a = 1 + 2
        print(a)


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-22 00:53:30.998279
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time(msg='test') as f:
            pass
    except:
        raise
    else:
        pass
    finally:
        pass

# Generated at 2022-06-22 00:53:36.627331
# Unit test for function debug_time
def test_debug_time():
    expected = 'test_debug_time took: 0:00:00.000010'
    with debug_time('test_debug_time'):
        pass
    res = sys.stderr.getvalue()
    sys.stderr.close()
    assert res == expected + '\n'

# Generated at 2022-06-22 00:53:39.357744
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = ['git commit -am "fix tests"']

    confirm_text(corrected_command) == confirm_text(corrected_command)

# Generated at 2022-06-22 00:53:40.777946
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == '\x1b[31m'

# Generated at 2022-06-22 00:53:42.284908
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass


# Generated at 2022-06-22 00:53:44.966314
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('123')
    except RuntimeError:
        exception(u'Rule test', sys.exc_info())



# Generated at 2022-06-22 00:53:53.828989
# Unit test for function debug_time
def test_debug_time():
    import time
    from mock import patch
    with patch('sys.stderr') as stderr:
        with debug_time(u'hi'):
            time.sleep(0.002)
        stderr.write.assert_called_with(
            '\x1b[34m\x1b[1mDEBUG:\x1b[0m hi took: 0:00:00.002000\n')

# Generated at 2022-06-22 00:54:06.387572
# Unit test for function version
def test_version():
    from subprocess import CalledProcessError
    from thefuck.utils import get_shell_info
    from thefuck.version import __version__
    from sys import version
    from unittest import TestCase
    from unittest.mock import patch


# Generated at 2022-06-22 00:54:09.677098
# Unit test for function already_configured
def test_already_configured():
    already_configured(u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.")

# Generated at 2022-06-22 00:54:10.292396
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:54:14.614676
# Unit test for function debug
def test_debug():
    lines = []

    def fake_debug(msg):
        lines.append(msg)

    old_debug = log.debug
    try:
        log.debug = fake_debug
        debug('foo')
        debug('bar')
        assert lines == ['foo', 'bar']
    finally:
        log.debug = old_debug



# Generated at 2022-06-22 00:54:16.308695
# Unit test for function warn
def test_warn():
    warn('test title')


# Generated at 2022-06-22 00:54:17.486959
# Unit test for function debug
def test_debug():
    debug('test')



# Generated at 2022-06-22 00:54:18.764400
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(1, 2)

# Generated at 2022-06-22 00:54:20.930235
# Unit test for function failed
def test_failed():
    sys.stderr.write('\n')  # Line needed for coverage
    failed('msg')

# Generated at 2022-06-22 00:54:24.373493
# Unit test for function exception
def test_exception():
    try:
        raise AssertionError('failed')
    except AssertionError:
        exc_info = sys.exc_info()

    exception('Test', exc_info)

    assert True

# Generated at 2022-06-22 00:54:35.522701
# Unit test for function warn
def test_warn():
    from mock import patch

    with patch('sys.stderr') as stderr:
        warn('TEST TITLE')
        stderr.write.assert_called_once_with(
            u'\x1b[41m\x1b[37m\x1b[1m'
            u'[WARN] TEST TITLE\x1b[0m\n')



# Generated at 2022-06-22 00:54:37.093899
# Unit test for function rule_failed
def test_rule_failed():
    rule = "TEST_RULE"
    exc_info = (Exception, Exception("test"), None)
    rules = ["TEST_RULE"]
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 00:54:43.140520
# Unit test for function color
def test_color():
    def test_color_with_color_disabled():
        settings.no_colors = True
        assert color(u'foo') == ''
        settings.no_colors = False

    def test_color_with_color_enabled():
        settings.no_colors = False
        assert color(u'foo') == u'foo'
        settings.no_colors = True

# Generated at 2022-06-22 00:54:44.932874
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('')



# Generated at 2022-06-22 00:54:45.970070
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('text') == 'text'



# Generated at 2022-06-22 00:54:47.803985
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Fuck you, Fuck them all')
    except RuntimeError as e:
        exception('Testing', sys.exc_info())

# Generated at 2022-06-22 00:54:49.764850
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'foo' + colorama.Style.RESET_ALL) == ''

# Generated at 2022-06-22 00:54:56.759921
# Unit test for function configured_successfully
def test_configured_successfully():
    output = u''
    for line in configured_successfully:
        output += line

    assert output == u'{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.'.format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        reload=configuration_details.reload)


# Generated at 2022-06-22 00:55:03.645555
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('foo', ('bar', 'baz'))
    exepcted = ('[WARN] Rule foo: Traceback (most recent call last):\n'
                '  File "<stdin>", line 1, in <module>\n'
                "NameError: name 'foo' is not defined\n"
                '[WARN] ----------------------------\n\n')
    assert sys.stderr.getvalue() == exepcted


# Generated at 2022-06-22 00:55:07.373443
# Unit test for function color
def test_color():
    assert color('red')('red') == '\x1b[31mred\x1b[39m'
    settings.no_colors = True
    assert color('red')('red') == 'red'

# Generated at 2022-06-22 00:55:15.095312
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test error')
    except Exception:
        exception(u'Title', sys.exc_info())
        return True
    return False

# Generated at 2022-06-22 00:55:19.438349
# Unit test for function exception
def test_exception():
    with open('testfile', 'w') as f:
        f.write('content')

    try:
        with open('testfile') as f:
            f.read()
    except Exception:
        exception('Test exception', sys.exc_info())
        assert True

# Generated at 2022-06-22 00:55:21.353097
# Unit test for function version
def test_version():
    version('3.3.3', '3.3.3', 'bash')

# Generated at 2022-06-22 00:55:29.123829
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    output = StringIO.StringIO()
    sys.stdout = output
    configured_successfully(None)
    sys.stdout = sys.__stdout__
    assert output.getvalue() == u'\x1b[1mfuck\x1b[0m alias configured successfully!\nFor applying changes run \x1b[1mreload\x1b[0m or restart your shell.\n'

# Generated at 2022-06-22 00:55:32.311314
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    confirm_text(Shell('ls').get_command('', '', 'ls')) == const.USER_COMMAND_MARK + 'ls'

# Generated at 2022-06-22 00:55:33.940332
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-22 00:55:44.262504
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = const.CorrectedCommand(script='fuck' + 'it', side_effect=False)
    show_corrected_command(corrected_command)
    sys.stderr.flush()
    output = sys.stderr.getvalue()
    # remove \r and \n
    output = ''.join(output.splitlines())
    if output != const.USER_COMMAND_MARK + 'fuckit':
        raise Exception('Incorrect result of function show_corrected_command: ' + output)
    sys.stderr.truncate(0)
    corrected_command = const.CorrectedCommand(script='fuck' + 'it', side_effect=True)
    show_corrected_command(corrected_command)
    sys.stderr.flush()

# Generated at 2022-06-22 00:55:46.378505
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(['git', 'bla', 'blabla']) == "git bla blabla [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-22 00:55:49.116968
# Unit test for function debug_time
def test_debug_time():
    times = []
    with debug_time('foo'):
        foo = 1
        times.append(foo)
    assert times == [1]

# Generated at 2022-06-22 00:55:50.312048
# Unit test for function warn
def test_warn():
    warn("test title")


# Generated at 2022-06-22 00:56:06.564479
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import sys
    import StringIO
    import thefuck.rules.python_command as python_command
    from thefuck.shells.bash import Bash

    # Get current function
    f = python_command.match('import os', Bash())

    stdout = sys.stdout
    stdin = sys.stdin

# Generated at 2022-06-22 00:56:10.555901
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('Rule', (object,), dict(name='ls', enabled_by_default=True))
    try:
        1 / 0
    except ZeroDivisionError:
        rule_failed(rule, sys.exc_info())
        assert True

# Generated at 2022-06-22 00:56:11.435367
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command = 'test command')

# Generated at 2022-06-22 00:56:15.186288
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("corrected_command", "") == "\x1b[1K\rcorrected_command [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-22 00:56:27.264588
# Unit test for function debug_time
def test_debug_time():
    import time
    from contextlib import contextmanager
    from unittest import TestCase

    from . import conf
    from . import context

    class DebugTimeTestCase(TestCase):
        def setUp(self):
            conf.settings = conf.Settings()
            conf.settings.debug = True
            self.context = context.Context()
            # Allow tests to pass stupidly fast
            @contextmanager
            def fake_sleep():
                yield
            time.sleep = fake_sleep

        def tearDown(self):
            self.context.__exit__(*sys.exc_info())


# Generated at 2022-06-22 00:56:30.829117
# Unit test for function show_corrected_command

# Generated at 2022-06-22 00:56:37.157687
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details) == u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload)

# Generated at 2022-06-22 00:56:38.739235
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("ruleName", ['error_type', 'error_value'])

# Generated at 2022-06-22 00:56:40.020705
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None

# Generated at 2022-06-22 00:56:41.704332
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc')


# Generated at 2022-06-22 00:56:53.170960
# Unit test for function version
def test_version():
    import io
    import mock
    import platform
    import builtins
    thefuck_version = '3.1.0'
    python_version = platform.python_version()
    shell_info = str(mock.Mock())
    with mock.patch.object(builtins, 'print') as mock_print:
        with mock.patch('sys.stderr', new=io.StringIO()) as mock_stderr:
            version(thefuck_version, python_version, shell_info)
            assert mock_stderr.getvalue() == u'The Fuck {} using Python {} and {}\n'.format(
                thefuck_version, python_version, shell_info)

# Generated at 2022-06-22 00:56:56.001549
# Unit test for function debug_time
def test_debug_time():
    global debug
    debug = lambda msg: msg
    assert u'debug_time took: 0:00:00.000001' == debug_time('debug_time').next()

# Generated at 2022-06-22 00:57:00.133307
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug, settings

    settings.debug = True
    debug('test me')

    with patch('sys.stderr') as stderr:
        debug('test me')
        assert stderr.write.called



# Generated at 2022-06-22 00:57:02.248917
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception:
        exception(u'Title', sys.exc_info())

# Generated at 2022-06-22 00:57:03.844455
# Unit test for function failed
def test_failed():
    failed("test_failed")
    assert(True)


# Generated at 2022-06-22 00:57:07.517933
# Unit test for function version
def test_version():
    from unittest import TestCase, main
    from mock import patch
    from thefuck.utils import version as v
    import sys


# Generated at 2022-06-22 00:57:11.702470
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(u'test message')
        assert False, 'Catch unexpected debug print'
    except AssertionError:
        assert True
    settings.debug = False



# Generated at 2022-06-22 00:57:18.348915
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from mock import Mock

    logger = Mock()

    with debug_time('testing time', logger):
        assert logger.call_args_list == []
        datetime.now = Mock(return_value=started + timedelta(seconds=10))
    assert logger.called
    args, _ = logger.call_args
    assert args[0] == 'testing time took: 0:00:10.000000'

# Generated at 2022-06-22 00:57:20.412419
# Unit test for function exception
def test_exception():
    try:
        1/0
    except ZeroDivisionError as e:
        exception('test', sys.exc_info())

# Generated at 2022-06-22 00:57:23.720168
# Unit test for function rule_failed
def test_rule_failed():
    class rule:
        name = "rule_name"

    rule_failed(rule,sys.exc_info())
# End test function


# Generated at 2022-06-22 00:57:31.052617
# Unit test for function debug_time
def test_debug_time():
    import mock
    debug_time = mock.MagicMock()

# Generated at 2022-06-22 00:57:43.469925
# Unit test for function confirm_text
def test_confirm_text():
    yield lambda: confirm_text(script='ls') == \
                  u'{prefix}{clear}{bold}ls{reset} ' \
                  u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}' \
                  u'/{red}ctrl+c{reset}]'.format(
                      prefix=const.USER_COMMAND_MARK,
                      clear='\033[1K\r',
                      bold=color(colorama.Style.BRIGHT),
                      green=color(colorama.Fore.GREEN),
                      red=color(colorama.Fore.RED),
                      reset=color(colorama.Style.RESET_ALL),
                      blue=color(colorama.Fore.BLUE))


# Generated at 2022-06-22 00:57:47.691882
# Unit test for function exception
def test_exception():
    exc_info = (None, TypeError("Can't convert 'int' object to str implicitly"), None)

    try:
        raise TypeError("Can't convert 'int' object to str implicitly")
    except TypeError:
        exception("Exception Title", sys.exc_info())



# Generated at 2022-06-22 00:57:51.605942
# Unit test for function failed
def test_failed():
    from io import StringIO

    out = StringIO()
    sys.stderr = out
    failed('That is not true')
    assert u'\033[91mThat is not true\033[0m\n' == out.getvalue()

# Generated at 2022-06-22 00:57:58.320081
# Unit test for function warn
def test_warn():
        import StringIO
        from .conf import settings
        from . import const
        settings.no_colors = False
        sys.stderr = StringIO.StringIO()
        warn('test')
        assert sys.stderr.getvalue() == (
            const.NO_COLORS + '[WARN] test' + const.NO_COLORS + '\n'
        )
        sys.stderr = sys.__stderr__


# Generated at 2022-06-22 00:57:59.893050
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None)



# Generated at 2022-06-22 00:58:03.281770
# Unit test for function failed

# Generated at 2022-06-22 00:58:09.641083
# Unit test for function failed
def test_failed():
    sys.stderr = StringIO()
    failed('Fail')
    multi_line = [
        u'{red}Fail{reset}\n'.format(red=color(colorama.Fore.RED),
                                     reset=color(colorama.Style.RESET_ALL))
    ]
    assert sys.stderr.getvalue() == u''.join(multi_line)



# Generated at 2022-06-22 00:58:13.277055
# Unit test for function debug
def test_debug():
    from sets import Set

    with debug_time('some'):
        l = Set([])
        for i in range(100000):
            l.add(i)
    print('%s' % sys.stderr)

# Generated at 2022-06-22 00:58:20.973727
# Unit test for function debug
def test_debug():
    import sys
    output = sys.stderr
    try:
        from StringIO import StringIO
        sys.stderr = StringIO()
        settings.debug = True
        debug(u'Debug message')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debug message\n'
    finally:
        sys.stderr.close()
        sys.stderr = output

# Generated at 2022-06-22 00:58:31.793704
# Unit test for function warn
def test_warn():
    from io import BytesIO
    from contextlib import redirect_stdout
    from . import colors

    colors.no_colors = True
    out = BytesIO()
    with redirect_stdout(out):
        warn('test')
    assert out.getvalue() == b'[WARN] test\n'

    colors.no_colors = False
    out = BytesIO()
    with redirect_stdout(out):
        warn('test')
    assert out.getvalue() == b'\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'



# Generated at 2022-06-22 00:58:40.002732
# Unit test for function failed
def test_failed():
    import mock
    import six
    from contextlib import contextmanager
    from io import StringIO
    from thefuck.shells import Shell

    @contextmanager
    def assert_stream():
        output = six.StringIO()
        with mock.patch('sys.stderr', output):
            yield output

    with assert_stream() as stderr:
        failed('foo bar')
    assert stderr.getvalue() == u'foo bar\n'



# Generated at 2022-06-22 00:58:43.441687
# Unit test for function warn
def test_warn():
    exit = sys.stderr.write
    sys.stderr.write = lambda x: sys.stderr.buffer.write(x.encode())
    warn('test')
    sys.stderr.write = exit



# Generated at 2022-06-22 00:58:46.860638
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = ['git banch --remote']
    assert show_corrected_command(corrected_command) == True


# Generated at 2022-06-22 00:58:50.506994
# Unit test for function debug
def test_debug():
    assert debug("TEST#1") is None
    assert debug("TEST#2") is None
    assert debug("TEST#3") is None
    assert debug("TEST#4") is None



# Generated at 2022-06-22 00:58:53.149454
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(None)
    configured_successfully({})
    configured_successfully({"reload":"restart"})


# Generated at 2022-06-22 00:58:55.335063
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(('test_configured_successfully')) == 'test_configured_successfully'


# Generated at 2022-06-22 00:59:04.437688
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.cp import cp
    assert sys.stderr.getvalue() == ('[WARN] Rule cp:\n'
                                     '------------------------------------------\n'
                                     '\n'
                                     'Traceback (most recent call last):\n'
                                     '  File "/Users/macbook/Desktop/LadiesCode/GitHub/thefuck/thefuck/tests/test_rules.py", line 10, in test_with_result\n'
                                     "    raise Exception('msg')\n"
                                     'Exception: msg\n')

# Generated at 2022-06-22 00:59:13.116952
# Unit test for function failed
def test_failed():
    from StringIO import StringIO

    result = StringIO()

    with settings(no_colors=True):
        failed(u'Foo', _err=result)

    assert result.getvalue() == u'Foo\n'

    result = StringIO()
    with settings(no_colors=False):
        failed(u'Foo', _err=result)

    assert result.getvalue() == color(colorama.Fore.RED) + u'Foo' + \
                               color(colorama.Style.RESET_ALL) + u'\n'


# Generated at 2022-06-22 00:59:18.258840
# Unit test for function version
def test_version():
    '''
    test for the version function
    '''
    sys.stderr.write(
        u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                       python_version,
                                                       shell_info))


# Generated at 2022-06-22 00:59:28.287485
# Unit test for function color
def test_color():
    assert color(None) == ''
    assert color('') == ''
    assert color('1') == ''
    assert color('1') == ''

    settings.no_colors = False
    assert color(None) == ''
    assert color('') == ''
    assert color('1') == '1'



# Generated at 2022-06-22 00:59:34.752605
# Unit test for function debug_time
def test_debug_time():
    import StringIO
    import time

    stderr = sys.stderr
    try:
        sys.stderr = StringIO.StringIO()
        with debug_time('test'):
            time.sleep(.1)
        assert 'test took: ' in sys.stderr.getvalue()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-22 00:59:43.974645
# Unit test for function rule_failed
def test_rule_failed():
    from unittest import TestCase
    from .utils import wrap_retry
    from .rules.python import match, get_new_command

    @wrap_retry
    def rule(command):
        raise RuntimeError('Some error')

    rule.name = 'test_rule'
    rule.priority = 100
    rule.enabled_by_default = True
    rule.get_new_command = get_new_command

    class MockedStderr(TestCase):
        def __init__(self):
            self.written = []

        def write(self, value):
            self.written.append(value)

    stderr = MockedStderr()
    sys.stderr = stderr

    rule(command='ls', stderr='', stdout='', stdin='')


# Generated at 2022-06-22 00:59:47.400833
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.python import ipdb
    try:
        raise Exception('Test exception')
    except:
        rule_failed(ipdb, sys.exc_info())
        assert 1 == 1


# Generated at 2022-06-22 00:59:54.212152
# Unit test for function debug
def test_debug():
    from mock import patch, call

    with patch('sys.stderr', autospec=True) as sys_stderr:
        debug('test')
        sys_stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

        sys_stderr.reset_mock()
        debug('test')
        assert sys_stderr.write.call_count == 0

# Generated at 2022-06-22 00:59:58.405186
# Unit test for function exception
def test_exception():
    exc_info = (RuntimeError, RuntimeError(u'foo'), None)
    output = u''
    exception(u'bar', exc_info)
    assert output == sys.stderr.getvalue()

# Generated at 2022-06-22 01:00:07.688951
# Unit test for function failed
def test_failed():
    import mock
    import six
    with mock.patch('six.print_') as print_:
        failed(six.u('msg'))
        print_.assert_called_once_with(six.u('\x1b[31mmsg\x1b[0m\n'))
        print_.reset_mock()

        assert not settings.no_colors
        settings.no_colors = True
        try:
            failed(six.u('msg'))
            print_.assert_called_once_with(six.u('msg\n'))
        finally:
            settings.no_colors = False

# Generated at 2022-06-22 01:00:16.859637
# Unit test for function debug
def test_debug():
    from mock import Mock
    from . import conf
    settings.debug = True
    sys.stderr = Mock()

    debug(u'hello world')
    sys.stderr.write.assert_called_once_with(
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hello world\n')

    settings.debug = False
    sys.stderr.write.reset_mock()
    debug(u'hello world')
    assert not sys.stderr.write.called
    settings.debug = True

# Generated at 2022-06-22 01:00:18.164617
# Unit test for function version
def test_version():
    pass

# Generated at 2022-06-22 01:00:18.873937
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(how_to_configure_alias())

# Generated at 2022-06-22 01:00:39.209849
# Unit test for function failed
def test_failed():
    from cStringIO import StringIO
    from .application import Application

    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out

        with Application(argv=[]).fuck([], '', ['pidof']) as app:
            app.run()
            failed(''.join(const.NO_RULES_MATCH.format(script='pidof')))
            assert out.getvalue() == \
                '\x1b[31m[!] pidof: no matches found: pidof\x1b[0m\n'
    finally:
        sys.stderr = saved_stderr


# Generated at 2022-06-22 01:00:42.478650
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class Mock:
        path = 'test'
        content = 'test'
        can_configure_automatically = False
        reload = 'test'

    how_to_configure_alias(Mock())



# Generated at 2022-06-22 01:00:44.365854
# Unit test for function failed
def test_failed():
    sys.stderr = open('/dev/null', 'w')
    failed(u'msg')
    assert True

# Generated at 2022-06-22 01:00:52.365908
# Unit test for function rule_failed
def test_rule_failed():
    import logging
    import StringIO
    sio = StringIO.StringIO()
    l = logging.getLogger('thefuck')
    h = logging.StreamHandler(sio)
    h.setLevel(logging.DEBUG)
    l.setLevel(logging.DEBUG)
    l.addHandler(h)
    try:
        raise Exception('Error!')
    except:
        rule_failed(None, sys.exc_info())
    assert "Rule  failed" in sio.getvalue()



# Generated at 2022-06-22 01:00:57.355122
# Unit test for function debug
def test_debug():
    def test_output(msg):
        assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m {}\n'.format(msg)

    settings.debug = True

    for msg in ['hello', 'the world', '', ' the fuck?']:
        sys.stderr = StringIO()
        debug(msg)
        test_output(msg)

    settings.debug = False

