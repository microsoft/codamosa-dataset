

# Generated at 2022-06-22 00:50:59.439366
# Unit test for function failed
def test_failed():
    from pytest import raises
    with raises(SystemExit):
        failed(u'Mocked error')

if __name__ == '__main__':
    test_failed()

# Generated at 2022-06-22 00:51:00.817058
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    colorama.init(autoreset=True)
    how_to_configure_alias(None)
    how_to_configure_alias([])
    how_to_configure_alias({})


# Generated at 2022-06-22 00:51:11.887638
# Unit test for function debug_time
def test_debug_time():
    from StringIO import StringIO
    import sys
    import time

    test_output = StringIO()

    def fake_output():
        sys.stderr = test_output

    def restore_output():
        sys.stderr = sys.__stderr__

    with debug_time('msg'):
        time.sleep(0.001)

    with debug_time('msg'):
        pass

    with debug_time('msg1') as debug_time:
        debug_time('msg2')

    fake_output()
    debug_time('msg').__enter__()
    restore_output()
    print(test_output.getvalue())


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-22 00:51:23.309948
# Unit test for function confirm_text
def test_confirm_text():
    from six import moves
    from unittest import mock

    from thefuck.rules.git_rebase import match, get_new_command
    from thefuck.types import Command

    rule = type('Rule', (object, ),
                {'name': 'git_rebase',
                 'match': staticmethod(match),
                 'get_new_command': staticmethod(get_new_command)})()

    with mock.patch('sys.stderr', moves.StringIO()) as stderr:
        confirm_text(Command('git', 'show', '7890'),
                     'git show 7890',
                     rule.get_new_command(Command('git', 'show', '7890'), None))

        assert u'git show 7890' in stderr.getvalue()

# Generated at 2022-06-22 00:51:26.369891
# Unit test for function failed
def test_failed():
    failed(u'Ошибка')
    # output:
    # Ошибка



# Generated at 2022-06-22 00:51:29.113026
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test')
    except RuntimeError:
        return exception(u'Title', sys.exc_info())



# Generated at 2022-06-22 00:51:33.474805
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = "git push origin master"

    corrected_command.script = "git push origin master"
    # corrected_command.side_effect = " (+side effect)"


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-22 00:51:39.719325
# Unit test for function already_configured
def test_already_configured():
    return u"Seems like {bold}fuck{reset} alias already configured!\n" \
        u"For applying changes run {bold}{reload}{reset}" \
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='fuck --reload')


# Generated at 2022-06-22 00:51:44.307400
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('No value defined')
    except ValueError as error:
        _, _, exc_info = sys.exc_info()
        exception(u'Тест на ошибку', exc_info)
test_exception()

# Generated at 2022-06-22 00:51:49.358853
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    origin_command = 'ls -lhta'
    corrected_command = '/bin/ls -lhta'
    assert show_corrected_command(CorrectedCommand(origin_command,
                                                   corrected_command)) is None

# Generated at 2022-06-22 00:51:53.925381
# Unit test for function debug_time
def test_debug_time():
    with debug_time('it takes long time'):
        pass

# Generated at 2022-06-22 00:51:56.333680
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.ConfigurationDetails('bash', True, 'source ~/.bashrc')) == None


# Generated at 2022-06-22 00:52:02.322097
# Unit test for function warn
def test_warn():
    from tests.utils import capture_stderr
    with capture_stderr() as stderr:
        warn(u'test title')
    assert stderr.getvalue() == (
        u'\x1b[41m\x1b[37m\x1b[1m[WARN] test title\x1b[0m\n')



# Generated at 2022-06-22 00:52:03.181062
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Hello, world!'):
        pass

# Generated at 2022-06-22 00:52:09.481398
# Unit test for function exception
def test_exception():
    from unittest import mock
    from io import StringIO
    exc_info = (Exception, Exception('test'), None)
    with mock.patch('sys.stderr') as stderr:
        exception('test', exc_info)

# Generated at 2022-06-22 00:52:21.223404
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from colorama import Fore, Style
    from mock import MagicMock, patch
    from thefuck.shells import Shell, Zsh
    from thefuck.utils import ConfigurationDetails

    mock_fore = Style.RESET_ALL
    mock_style = Style.RESET_ALL

    with patch('sys.stdout', new=MagicMock()):
        with patch('thefuck.utils.color', side_effect=lambda color:
                   mock_fore if 'Fore' in color else mock_style):
            with patch('thefuck.utils.settings',
                       new_callable=MagicMock) as mock_settings:
                mock_settings.no_colors = True
                how_to_configure_alias(ConfigurationDetails(
                    '~/.bashrc', 'bash', '', True, 'source ~/.bashrc'))
                assert mock_fore

# Generated at 2022-06-22 00:52:34.083551
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from subprocess import check_output

    with settings(no_colors=True):
        how_to_configure_alias(None)
        how_to_configure_alias(None)

        how_to_configure_alias(
            configuration_details=const.ConfigurationDetails(
                path='$HOME/.bashrc',
                content='source $HOME/.thefuck/aliases.sh',
                reload='bash',
                can_configure_automatically=True))
        how_to_configure_alias(
            configuration_details=const.ConfigurationDetails(
                path='$HOME/.bashrc',
                content='source $HOME/.thefuck/aliases.sh',
                reload='bash',
                can_configure_automatically=False))


# Generated at 2022-06-22 00:52:38.286833
# Unit test for function color
def test_color():
    assert color('bold') == 'bold'
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = True
    assert color('bold') == ''
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-22 00:52:45.290898
# Unit test for function exception
def test_exception():
    import StringIO
    stderr = StringIO.StringIO()
    exception('Exception', (Exception, Exception(), None))
    assert(stderr.getvalue() == (
        u'[WARN] Exception:{reset}\n'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))))

# Generated at 2022-06-22 00:52:55.184460
# Unit test for function already_configured
def test_already_configured():
    mock_configuration_details = type(
        'MockConfigurationDetails', (object,), {
            'reload': u'$ source ~/.bash_profile'})
    expected_output = (
        u'Seems like \x1b[1mfuck\x1b[21m alias already configured!\n'
        u'For applying changes run \x1b[1m$ source ~/.bash_profile\x1b[21m or restart your shell.\n')
    capture_stdout = StringIO()
    with patch('sys.stdout', capture_stdout):
        already_configured(mock_configuration_details)
        assert capture_stdout.getvalue() == expected_output



# Generated at 2022-06-22 00:53:01.054525
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push origin master', False))



# Generated at 2022-06-22 00:53:05.840279
# Unit test for function configured_successfully
def test_configured_successfully():
    text_template = "fuck alias configured successfully!\nFor applying changes run {} or restart your shell."
    assert configured_successfully(thefuck.shells.get_shell()[0]).text.strip() == text_template.format(thefuck.shells.get_shell()[0])

# Generated at 2022-06-22 00:53:10.969047
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('thefuck.utils.settings', debug=False):
        debug('msg')
        debug.assert_not_called()
    with mock.patch('thefuck.utils.settings', debug=True):
        debug('msg')
        debug.assert_called_with('msg')



# Generated at 2022-06-22 00:53:16.246049
# Unit test for function failed
def test_failed():
    from tempfile import NamedTemporaryFile
    from .conf import load_settings
    from .utils import wrap_settings
    with wrap_settings(no_colors=True):
        with NamedTemporaryFile() as f:
            f.write(u'STDERR_LOGGING = "false"'.encode('utf-8'))
            f.flush()
            with wrap_settings(load_settings(f.name)):
                failed(u'\u2693')

# Generated at 2022-06-22 00:53:28.763895
# Unit test for function warn
def test_warn():
    from contextlib import contextmanager
    from io import BytesIO
    from .utils import get_encoded_stream
    import sys

    @contextmanager
    def mock(encoding, errors):
        _stdout = sys.stderr
        sys.stderr = get_encoded_stream(BytesIO(), encoding, errors)
        try:
            yield sys.stderr
        finally:
            sys.stderr = _stdout

    with mock('utf-8', 'replace') as stderr:
        warn(u'предупреждение')

# Generated at 2022-06-22 00:53:33.966200
# Unit test for function warn
def test_warn():
    output = u''
    sys.stderr.write = lambda content: setattr(test_warn, 'output', content)
    warn("Warning")
    assert test_warn.output == '\x1b[41m\x1b[37m\x1b[1m[WARN] Warning\x1b[0m\n'



# Generated at 2022-06-22 00:53:36.396597
# Unit test for function warn
def test_warn():
    warn('title') == u'[WARN] title\n'


# Generated at 2022-06-22 00:53:37.775675
# Unit test for function version
def test_version():
    version('3.22', 'Python 2.7.13', 'Powershell 5.1.14393.693')



# Generated at 2022-06-22 00:53:42.236851
# Unit test for function version
def test_version():
    assert version('3.14', '2.7.1', 'ZSH 5.0.2 (x86_64-apple-darwin14.0)') == """The Fuck 3.14 using Python 2.7.1 and ZSH 5.0.2 (x86_64-apple-darwin14.0)
"""

# Generated at 2022-06-22 00:53:46.864940
# Unit test for function already_configured
def test_already_configured():
    def mocked_print(msg):
        print(msg)
    import __builtin__ as builtins
    builtins.print = mocked_print
    already_configured(configuration_details=type('configuration_details',(object,),{'reload':'source ~/.bashrc'}))
    builtins.print = print

# Generated at 2022-06-22 00:53:54.746172
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    old_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    try:
        configured_successfully(None)
        assert u"fuck alias configured successfully!" in sys.stderr.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-22 00:53:59.203753
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = namedtuple('configuration_details', 'reload')
    configuration_details.reload = 'source ~/.bash_profile'
    assert configured_successfully(configuration_details) == None


# Generated at 2022-06-22 00:54:00.857417
# Unit test for function warn
def test_warn():
    # test_warn
    warn('ahoy')



# Generated at 2022-06-22 00:54:04.904596
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLACK) == ''
    assert color(colorama.Fore.WHITE) == colorama.Fore.WHITE
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

# Generated at 2022-06-22 00:54:15.530393
# Unit test for function version
def test_version():
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')
    assert version('3.1', '3.5.2', 'bash 3.2.57')

# Generated at 2022-06-22 00:54:17.893924
# Unit test for function warn
def test_warn():
    try:
        warn('test_warn')
    except TypeError:
        raise

test_warn()

# Generated at 2022-06-22 00:54:28.559434
# Unit test for function configured_successfully
def test_configured_successfully():
    from contextlib import contextmanager
    from io import StringIO
    from thefuck.shells import get_shell
    from thefuck.types import Shell
    shell = get_shell()

    @contextmanager
    def patch_stdout():
        stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            yield sys.stdout
        finally:
            sys.stdout = stdout

    with patch_stdout() as mock_stdout:
        configured_successfully(shell_info(shell))
    assert mock_stdout.getvalue() == u'fuck alias configured successfully!\nFor applying changes run exec $SHELL -l or restart your shell.\n'



# Generated at 2022-06-22 00:54:30.713665
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(Command('command')) == 'cd ~/'

# Generated at 2022-06-22 00:54:42.492703
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch

    confirm_text(
        const.CorrectedCommand(u'git push -f', False))

    with patch('sys.stderr') as stderr:
        confirm_text(
            const.CorrectedCommand(u'git push -f', False))

# Generated at 2022-06-22 00:54:50.636361
# Unit test for function already_configured
def test_already_configured():
    # Check that the function already_configured prints something
    stream = sys.stderr
    output = '''
Seems like fuck alias already configured!
For applying changes run 'source $HOME/.bash_profile' or restart your shell.
'''.strip()
    if getattr(stream, "encoding", None) is None:
            stream = open(stream.fileno(), mode='w', encoding="utf-8")
    with Capturing(stream) as output:
        already_configured('source $HOME/.bash_profile')
    assert output == output

# Generated at 2022-06-22 00:54:55.869338
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details='asd') == None

test_configured_successfully()

# Generated at 2022-06-22 00:55:08.158420
# Unit test for function rule_failed
def test_rule_failed():
    import sys
    import StringIO
    class CustomException(Exception):
        pass
    test_out = StringIO.StringIO()
    try:
        raise CustomException('Test Exception')
    except:
        exception('Test Exception', sys.exc_info())
        test_out.seek(0)

# Generated at 2022-06-22 00:55:20.971613
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Test that it can output the command in the correct format
    """
    from mock import Mock

# Generated at 2022-06-22 00:55:22.479506
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(CorrectedCommand('ls -al', True))

# Generated at 2022-06-22 00:55:24.538333
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully({
        'shell': 'shell',
        'reload': 'reload'
    })

# Generated at 2022-06-22 00:55:26.780671
# Unit test for function failed
def test_failed():
    failed(u'foo')



# Generated at 2022-06-22 00:55:36.162644
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Bash
    from .utils import get_closest
    from .rules.python import match, get_new_command

    assert u'fuck' in str(how_to_configure_alias(
            Bash(get_closest('fuck',
                             [u'fuck'],
                             get_new_command)).from_shell()))
    assert u'fuck' in str(how_to_configure_alias(
            Bash(get_closest('fuck',
                             [u'fuck'],
                             get_new_command),
                can_configure_automatically=True).from_shell()))

# Generated at 2022-06-22 00:55:38.692434
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-22 00:55:40.698415
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test_sleep'):
        time.sleep(1)
    assert True

# Generated at 2022-06-22 00:55:46.903197
# Unit test for function debug
def test_debug():
    from . import main
    import tempfile
    import os
    from . import utils
    with tempfile.TemporaryDirectory() as td:
        debug_file = os.path.join(td, 'f')
        with open(debug_file, 'w') as w:
            w.write(u'fuck')
        os.environ['TF_DEBUG'] = debug_file
        main.main(settings_path=None)
        os.unlink(debug_file)

# Generated at 2022-06-22 00:55:59.760115
# Unit test for function debug
def test_debug():
    from thefuck import core
    from contextlib import contextmanager

    @contextmanager
    def mock_settings(settings):
        class MockSettings(object):
            def __init__(self, **kwargs):
                self.__dict__ = kwargs

        original_settings = core.settings
        core.settings = MockSettings(**settings)
        try:
            yield
        finally:
            core.settings = original_settings

    with mock_settings(debug=True):
        assert core.debug('msg') == sys.stderr.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[21m\x1b[39m msg\n')
    with mock_settings(debug=False):
        assert core.debug('msg') == None

# Generated at 2022-06-22 00:56:01.457328
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-22 00:56:05.754173
# Unit test for function debug
def test_debug():
    from test.utils import capture_stderr

    with capture_stderr(stderr) as stderr:
        debug('Test debug')

    assert stderr.getvalue() == '# DEBUG: Test debug\n'



# Generated at 2022-06-22 00:56:08.905099
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rules.bash import get_alias_details
    configuration_details = get_alias_details()
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-22 00:56:12.106220
# Unit test for function exception
def test_exception():
    try:
        raise NameError(u'bar')
    except NameError:
        exc_info = sys.exc_info()
        exception(u'foo', exc_info)



# Generated at 2022-06-22 00:56:17.180399
# Unit test for function rule_failed
def test_rule_failed():
    def _raise_error():
        raise NotImplementedError('Not Implemented')

    try:
        _raise_error()
    except Exception as e:
        rule_failed('test_rule_failed', e.__traceback__)
        assert True

# Generated at 2022-06-22 00:56:20.918952
# Unit test for function debug_time
def test_debug_time():
    import time
    settings.debug = True
    with debug_time('test'):
        time.sleep(1)
    settings.debug = False
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-22 00:56:21.787037
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-22 00:56:26.130017
# Unit test for function warn
def test_warn():
    from test.utils import Command

    with Command('echo', 'Hello') as c:
        warn('title')
        assert c.stdout == ''
        assert c.stderr == '[WARN] title\n'
        assert c.ran is False



# Generated at 2022-06-22 00:56:33.333660
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(
        Command(script=u'test script', side_effect=True, stdout=None)) == \
        '> test script (+side effect) [enter/↑/↓/ctrl+c]'
    confirm_text(Command(script=u'test script', side_effect=False, stdout=None))\
        == '> test script [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-22 00:56:39.578072
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except:
        # type, value, traceback
        exception(u'Test exception', sys.exc_info())



# Generated at 2022-06-22 00:56:42.990760
# Unit test for function debug
def test_debug():
    from .test_utils import Mock
    settings.debug = True
    mock = Mock()
    sys.stderr = mock
    debug(u'test')
    assert mock.write.called


# Generated at 2022-06-22 00:56:46.003399
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'): 2
    debug('msg took: 0:00:00.000002')

if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-22 00:56:51.022377
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    failed('some message')
    assert output.getvalue() == '\x1b[31msome message\x1b[0m\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:56:52.508115
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed({
        'name': 'test',
    }, Exception('test'))

# Generated at 2022-06-22 00:57:04.020599
# Unit test for function debug
def test_debug():
    try:
        open('/path/to/inexisting/file', 'rb')
    except Exception as e:
        debug_msg = u'Hello world'
        debug(debug_msg)
        exception_msg = u'Oops'
        exception(exception_msg, sys.exc_info())
        assert debug_msg in sys.stderr.getvalue()
        assert exception_msg in sys.stderr.getvalue()
        assert repr(e) in sys.stderr.getvalue()

# Generated at 2022-06-22 00:57:07.687231
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + colorama.Back.GREEN) == '\x1b[31;42m'
    assert color(colorama.Fore.RED + colorama.Back.GREEN) == ''

# Generated at 2022-06-22 00:57:08.970195
# Unit test for function warn
def test_warn():
    warn('test warn')


# Generated at 2022-06-22 00:57:20.806782
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    from .rules import get_rule
    import os

    class Rule(object):
        name = 'test'

        def __init__(self):
            self.enabled = True
            self.side_effect = False
            self.priority = 0

        def match(self, **kwargs):
            return match(**kwargs)

        def get_new_command(self, **kwargs):
            return get_new_command(**kwargs)

    orig_get_rule = get_rule
    get_rule = lambda: Rule()


# Generated at 2022-06-22 00:57:25.623478
# Unit test for function color
def test_color():
    settings.no_colors = False
    assert color(colorama.Back.RED) == '\x1b[41m'
    settings.no_colors = True
    assert color(colorama.Back.RED) == ''

# Generated at 2022-06-22 00:57:31.412690
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import time
    with debug_time('test_debug_time'):
        time.sleep(1)

# Generated at 2022-06-22 00:57:36.676824
# Unit test for function warn
def test_warn():
    from test.utils import CaptureOutput
    from thefuck.types import Command

    with CaptureOutput() as captured:
        warn(u'foo')
    assert captured.out == u'\x1b[41m\x1b[37m\x1b[1m[WARN] foo\x1b[0m\n'



# Generated at 2022-06-22 00:57:40.933964
# Unit test for function color
def test_color():
    from . import utils
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    utils.is_os('Windows', False)

# Generated at 2022-06-22 00:57:42.043692
# Unit test for function debug
def test_debug():
    assert debug('debug') == None

# Generated at 2022-06-22 00:57:44.072130
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails()
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-22 00:57:45.125217
# Unit test for function version
def test_version():
    import platform
    import thefuck
    version(thefuck.__version__, platform.python_version(), 'Terminal')


# Generated at 2022-06-22 00:57:46.211237
# Unit test for function warn
def test_warn():
    warn('warn')



# Generated at 2022-06-22 00:57:47.909511
# Unit test for function debug
def test_debug():
    """
    Test the debug function
    """
    assert debug("my message") == 1

# Generated at 2022-06-22 00:57:50.390841
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("ls") == u'[FUCK] ls [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-22 00:57:51.549829
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(dict())

# Generated at 2022-06-22 00:58:06.407542
# Unit test for function debug
def test_debug():
    import unittest
    import sys

    class DebugTest(unittest.TestCase):

        def setUp(self):
            self.saved_debug_value = settings.debug
            settings.debug = True
            self.old_stdout = sys.stdout
            sys.stdout = self.stdout = unittest.mock.Mock()

        def tearDown(self):
            sys.stdout = self.old_stdout
            settings.debug = self.saved_debug_value

        def test_debug_when_debug_enabled(self):
            debug('test debug')
            self.stdout.write.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n')


# Generated at 2022-06-22 00:58:09.466499
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls',
                                            side_effect=False))


# Generated at 2022-06-22 00:58:11.569399
# Unit test for function color
def test_color():
    assert color('red')('test') == 'test'
    assert color('red') == ''



# Generated at 2022-06-22 00:58:12.854880
# Unit test for function rule_failed
def test_rule_failed():
    pass


# Generated at 2022-06-22 00:58:14.569777
# Unit test for function exception
def test_exception():
    exception("test_title", "test_debug_info")
    assert True

# Generated at 2022-06-22 00:58:26.866503
# Unit test for function version
def test_version():
    from types import ModuleType
    import sys
    import mock
    import platform

    # We need to mock all the imports because version() uses color().
    # color() loads the colorama module, which we can't import here.
    thefuck_metadata = ModuleType('thefuck.metadata')
    thefuck_metadata.__file__ = 'thefuck/metadata.py'
    thefuck_metadata.__version__ = '0.1'
    sys.modules['thefuck.metadata'] = thefuck_metadata

    sys.version = '2.7.6'

    _raw_platform = platform.platform
    _raw_system = platform.system

# Generated at 2022-06-22 00:58:30.398709
# Unit test for function warn
def test_warn():
    try:
        sys.stderr = sys.stdout
        warn(u'title')
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-22 00:58:33.456051
# Unit test for function confirm_text
def test_confirm_text():
    import re
    assert re.match("\[<>/\\|:;=,]*\s*\[\\\[//\[//", confirm_text("msg"))

# Generated at 2022-06-22 00:58:35.765413
# Unit test for function color
def test_color():
    assert not color(colorama.Fore.LIGHTBLACK_EX)

# Generated at 2022-06-22 00:58:36.928926
# Unit test for function warn
def test_warn():
    warn(u'hello, world')



# Generated at 2022-06-22 00:58:41.559130
# Unit test for function already_configured
def test_already_configured():
    already_configured("test_commmand")


# Generated at 2022-06-22 00:58:46.156364
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias({'path': 'a', 'content': 'b', 'reload': 'c'})
    how_to_configure_alias({'path': 'a', 'content': 'b', 'reload': 'c',
                            'can_configure_automatically': True})

# Generated at 2022-06-22 00:58:56.241041
# Unit test for function version
def test_version():
    from mock import patch
    from sys import version_info
    from . import version as target
    import thefuck.shells

    with patch.object(sys, 'stderr', open('/dev/null', 'w')),\
         patch.object(thefuck, '__version__', 'X'),\
         patch.object(thefuck.shells, 'get_shell_info', lambda: 'Y'):
        target()
        assert sys.stderr.read() == \
            'The Fuck X using Python {}.{}.{} and Y\n'.format(
                version_info[0], version_info[1], version_info[2])

# Generated at 2022-06-22 00:59:01.007143
# Unit test for function failed
def test_failed():
    assert failed('a') == sys.stderr.write(u'{red}{msg}{reset}\n'.format(
        msg='a',
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-22 00:59:02.218828
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-22 00:59:05.289164
# Unit test for function exception
def test_exception():
    try:
        a = 1
        b = 0
        c = a/b
    except Exception as exception:
        exception('test exception', sys.exc_info())




# Generated at 2022-06-22 00:59:06.322713
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(object())==None

# Generated at 2022-06-22 00:59:10.399291
# Unit test for function already_configured
def test_already_configured():
    with settings.override({'confirm': False}):
        profile_path = '/home/user/.bashrc'
        reload_alias = 'reload'
        already_configured(profile_path, reload_alias)



# Generated at 2022-06-22 00:59:10.766422
# Unit test for function failed
def test_failed():
    pass

# Generated at 2022-06-22 00:59:21.600271
# Unit test for function debug

# Generated at 2022-06-22 00:59:25.741188
# Unit test for function debug
def test_debug():
    debug('foo')

# Generated at 2022-06-22 00:59:27.452310
# Unit test for function version
def test_version():
    version('3.3', '3.3.3', 'unknown shell')



# Generated at 2022-06-22 00:59:31.162515
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rules.system import SystemRule
    show_corrected_command(SystemRule('ls', 'ls -lh'))
    assert sys.stderr.getvalue() == u'@@ ls -lh\n'

# Generated at 2022-06-22 00:59:42.194521
# Unit test for function version
def test_version():
    from io import StringIO
    from thefuck.conf import version as tf_version
    from thefuck.conf import get_shell_info

    # thefuck.conf.version should return only thefuck version
    assert tf_version() == '1.1'

    sys.stderr = StringIO()
    version('2.2', '3.3', get_shell_info('bash'))

    # sys.stderr value should be as expected
    assert sys.stderr.getvalue() == \
        u'The Fuck 2.2 using Python 3.3 and Bash 4.3.42\n'

    sys.stderr = StringIO()
    version('2.2', '3.3', get_shell_info('unknown shell'))

    # sys.stderr value should be as expected
    assert sys.stderr

# Generated at 2022-06-22 00:59:44.744985
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('My test'):
        time.sleep(0.3)

# Generated at 2022-06-22 00:59:55.082677
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rules.utils import get_closest
    from .shells import Zsh
    from .types import Settings
    zsh_cfg = Zsh.from_shell(None).app_alias.format(
        script_file=get_closest(__file__, 'thefuck/rules'))

    assert how_to_configure_alias(None) == None
    assert how_to_configure_alias(Settings(
        path=None, content=None, reload='',
        can_configure_automatically=False)) == None

    how_to_configure_alias(Settings(
        path=None, content='', reload='',
        can_configure_automatically=True)) == None


# Generated at 2022-06-22 00:59:58.830923
# Unit test for function configured_successfully
def test_configured_successfully():
    assert (configured_successfully == 'fuck alias configured successfully!\n'
                                       'For applying changes run\n'
                                       'or restart your shell.')



# Generated at 2022-06-22 00:59:59.303777
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(1) == None



# Generated at 2022-06-22 01:00:02.781521
# Unit test for function debug
def test_debug():
    from tests.utils import Mock
    settings.debug = True
    debug = Mock()
    debug(u'msg')
    debug.assert_called_once_with(u'msg')



# Generated at 2022-06-22 01:00:10.338991
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from thefuck.utils import get_closest
    from thefuck.shells import Bash, Zsh, Fish

    for shell in [Bash, Zsh, Fish]:
        for with_side_effect in [True, False]:
            corrected_command = get_closest('echo test',
                                            [u'corrected command', [],
                                             with_side_effect])
            confirm_text(corrected_command)
            assert True

# Generated at 2022-06-22 01:00:20.794738
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from datetime import timedelta
    from .command import CorrectedCommand
    import sys
    mock_sys = sys
    sys = mock_sys
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    # Error :
    show_corrected_command("")
    show_corrected_command(CorrectedCommand("", "", timedelta(0, 0, 0)))
    # Error :
    show_corrected_command("")
    # Error :

# Generated at 2022-06-22 01:00:24.384736
# Unit test for function failed
def test_failed():
    sys.stderr.write = lambda msg: msg
    assert failed('foo') == u'\x1b[31mfoo\x1b[0m\n'
    del sys.stderr.write

# Generated at 2022-06-22 01:00:29.173311
# Unit test for function version
def test_version():
    import platform
    import sys
    shell_info = 'shell {} {}'.format(platform.system(),
                                      platform.release())
    version('1.1', '2.7', shell_info)
    sys.stderr.write(u'Test success')  # noqa



# Generated at 2022-06-22 01:00:30.218440
# Unit test for function warn
def test_warn():
    warn("test")



# Generated at 2022-06-22 01:00:33.024643
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT)('foo') == colorama.Style.BRIGHT + 'foo'
    assert color('foo') == 'foo'

# Generated at 2022-06-22 01:00:44.848695
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Command(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    from io import StringIO
    from unittest import TestCase
    from .conf import settings
    from . import utils
    old_stderr = sys.stderr
    sys.stderr = StringIO()
    settings.no_colors = False

# Generated at 2022-06-22 01:00:49.231209
# Unit test for function rule_failed
def test_rule_failed():
    rule = object()
    rule.name = 'test_rule'
    exc_info = (type("exception", (Exception,), {}),
                type("exception", (Exception,), {})(),
                None)
    rule_failed(rule, exc_info)

# Generated at 2022-06-22 01:00:50.400903
# Unit test for function warn
def test_warn():
    warn('Test')


# Generated at 2022-06-22 01:00:59.141783
# Unit test for function failed
def test_failed():
    old_stderr = sys.stderr
    try:
        sys.stderr = sys.stdout
        failed(u'Привет')
        failed(u'Мир')
        sys.stderr.seek(0)
        assert sys.stderr.read() == u'\033[31mПривет\033[0m\n\033[31mМир\033[0m\n'
    finally:
        sys.stderr = old_stderr
