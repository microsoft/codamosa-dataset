

# Generated at 2022-06-26 05:14:31.389209
# Unit test for function color
def test_color():
    assert color('white') == ''
    assert color('red') == '\x1b[31m'


# Generated at 2022-06-26 05:14:33.942202
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'j_F.C2D\rda{|IjY'
    var_0 = debug_time(str_0)


# Generated at 2022-06-26 05:14:40.746930
# Unit test for function debug_time
def test_debug_time():
    @contextmanager
    def cm(msg):
        started = datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.now() - started))

    # TODO: Add your test case here
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = cm(str_0)


# Generated at 2022-06-26 05:14:42.096377
# Unit test for function debug
def test_debug():
    if settings.debug:
        pass
    else:
        pass

# Generated at 2022-06-26 05:14:43.138982
# Unit test for function color
def test_color():
    str_1 = 'regjg(jneR;H^0r\r'
    var_1 = color(str_1)


# Generated at 2022-06-26 05:14:50.512909
# Unit test for function confirm_text
def test_confirm_text():
    # test case 0
    # assume that the input is "echo haha && rm -f hahaha"
    # assume that the side effect is false
    str_0 = "echo haha && rm -f hahaha"
    side_effect_0 = False
    var_0 = confirm_text(str_0, side_effect_0)
    # if the two output is the same return true, else return false
    # if the two output is the same return true, else return false
    return var_0 == u'$ echo haha && rm -f hahaha [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-26 05:14:56.804318
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = confirm_text(str_0)
    assert var_0 == u'{bold}{script}{reset} [+]side effect [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'


# Generated at 2022-06-26 05:14:58.613625
# Unit test for function debug
def test_debug():
    str_0 = 'n'
    var_0 = debug(str_0)


# Generated at 2022-06-26 05:15:00.757913
# Unit test for function debug_time
def test_debug_time():
    debug_time(u'{} took: {}'.format('', ''))


# Generated at 2022-06-26 05:15:03.280097
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'r!ud}t'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:15:07.329238
# Unit test for function debug
def test_debug():
    str_3 = 'jy'
    var_3 = debug(str_3)


# Generated at 2022-06-26 05:15:10.844472
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'i(13,4)}4$|Qmjqm:MTE'
    var_0 = how_to_configure_alias(str_0)



# Generated at 2022-06-26 05:15:12.953029
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'The fuck you talking about'
    var_0 = confirm_text(str_0)
    assert var_0 == var_0



# Generated at 2022-06-26 05:15:25.021937
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    str_1 = 'pN(sBw;\rj]G*\ry"fQ>'
    int_0 = 208
    int_1 = -40
    int_2 = -40
    int_3 = 208
    int_4 = 90
    int_5 = 1
    int_6 = -17

    # Testing with random integer
    show_corrected_command(str_0)

    # Testing with random integer
    show_corrected_command(str_1)


# Generated at 2022-06-26 05:15:27.551694
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'R@f|;X(Eun\rtSYhz^"m|'
    var_0 = warn(str_0)


# Generated at 2022-06-26 05:15:30.096408
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'su'
    str_1 = 'sudo su'
    var_0 = show_corrected_command(str_1)


# Generated at 2022-06-26 05:15:33.601897
# Unit test for function debug_time
def test_debug_time():
    test_case_0()

# Generated at 2022-06-26 05:15:36.690545
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = False
    with debug_time('correction'):
        with debug_time('correcting_script'):
            corrected_command = confirm_text(corrected_command)
    return corrected_command


# Generated at 2022-06-26 05:15:40.544808
# Unit test for function debug
def test_debug():
    str_0 = 'lEeq"i;t|\nN}N\t_uY'
    var_0 = debug(str_0)


# Generated at 2022-06-26 05:15:44.210228
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = how_to_configure_alias(str_0)
    return var_0


# Generated at 2022-06-26 05:15:49.037302
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'GHxn]BK&ke!e/Pp/@,eo\t'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:16:00.388084
# Unit test for function color
def test_color():
    var_0 = color("\x1b[1K\r\x1b[1A\r\x1b[1K\r")

# Generated at 2022-06-26 05:16:03.217993
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text == confirm_text('oF[;X(Eun\rtSYhz^"m|')


# Generated at 2022-06-26 05:16:04.637015
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass



# Generated at 2022-06-26 05:16:16.214872
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        from .types import Correction
        from .corrected_command import CorrectedCommand
        from .utils import memoize
        from unittest.mock import Mock, patch
        import thefuck
        type(thefuck)._get_history = Mock(return_value=[])
    except ImportError:
        print("Unable to import one of the required modules")
        return

    class CommandMock(Mock):
        def __init__(self, *args, **kwargs):
             super(CommandMock, self).__init__(wraps=CorrectedCommand(*args,
                                                                     **kwargs))

        def __getattr__(self, name):
            return getattr(self.corrected_command, name)


# Generated at 2022-06-26 05:16:25.587303
# Unit test for function confirm_text

# Generated at 2022-06-26 05:16:28.804891
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = show_corrected_command(str_0)


# Generated at 2022-06-26 05:16:29.969363
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('msg') == msg


# Generated at 2022-06-26 05:16:31.704996
# Unit test for function debug_time
def test_debug_time():
    assert str(debug_time('debug_time test'))


# Generated at 2022-06-26 05:16:32.622290
# Unit test for function debug
def test_debug():
    assert debug("test_debug") == None


# Generated at 2022-06-26 05:16:37.894331
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = ''
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:16:40.412272
# Unit test for function show_corrected_command
def test_show_corrected_command():
    script = 'git push'
    corrected_command = 'git push'
    side_effect = False
    assert show_corrected_command(corrected_command) == script


# Generated at 2022-06-26 05:16:44.969900
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:16:51.013038
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = confirm_text(str_0)



# Generated at 2022-06-26 05:16:53.171154
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'arg_1'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:16:54.974954
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    confirm_text(str_0)


# Generated at 2022-06-26 05:17:02.624043
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . import corrected_command
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_1 = corrected_command.CorrectedCommand(str_0, False)
    str_1 = 'W8i9svb,\\]&_`K;n~[8xg'
    show_corrected_command(var_1)
    str_2 = ']mK_\nW8i9svb,\\]&_`K;n~[8xg'
    assert str_1 == str_2


# Generated at 2022-06-26 05:17:04.988433
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'There is no need to configure alias automatically.'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:17:07.356856
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'Press <ENTER> to confirm your command'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:17:10.646754
# Unit test for function debug_time
def test_debug_time():
    # Test with debug disabled
    settings.debug = False
    with debug_time('test_function'):
        pass

    # Test with debug enabled
    settings.debug = True
    with debug_time('test_function'):
        pass


# Generated at 2022-06-26 05:17:14.167229
# Unit test for function debug
def test_debug():
    var_0 = debug(123)


# Generated at 2022-06-26 05:17:17.286225
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'B~Y|p8>z,_?n-{1Iws\x7f'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:17:18.321376
# Unit test for function debug
def test_debug():
    debug('j')


# Generated at 2022-06-26 05:17:26.297259
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_1 = 't)G2Qlsc'
    str_2 = '|f}]k'
    str_3 = 'X0D:+L'
    var_1 = vars()
    var_2 = var_1.get(str_1)
    str_4 = 't1S{L'
    var_3 = var_2.get(str_4)
    str_5 = '#&_vy'
    str_6 = "dw;'b"
    str_7 = '`W3qgl'
    str_8 = 'gU:'
    str_9 = 'H\x7fTzIs'
    str_10 = '"G)<Z%h'
    str_11 = '`?Il'
    str_12 = '\'a:~'
   

# Generated at 2022-06-26 05:17:27.405773
# Unit test for function debug
def test_debug():
    test_case_0()


# Generated at 2022-06-26 05:17:29.161668
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('oF[;X(Eun\rtSYhz^"m|') == None

# Generated at 2022-06-26 05:17:37.215190
# Unit test for function confirm_text
def test_confirm_text():
    try:
        str_0 = 'HZJ$~{gY| ?f3\',/@"y^'
        str_1 = '#:T6T$7&U{o6U%o*Fw\x7f'
        str_2 = '73?;^9[p]nwiPkM[Y4b'
        var_0 = confirm_text(str_1, str_2, str_0)
    except:
        print('Exception caught in function confirm_text')


# Generated at 2022-06-26 05:17:40.460025
# Unit test for function debug
def test_debug():
    str_0 = 'SjhLJg[wZx\x7f[]]uV^lj\x7fV\x7f'
    var_0 = debug(str_0)


# Generated at 2022-06-26 05:17:46.820407
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    debug_context = debug_time('context')
    with debug_context:
        next
    debug_time('msg')
    assert(debug_context.__exit__.__name__ == '__exit__')


# Generated at 2022-06-26 05:17:47.800345
# Unit test for function debug
def test_debug():
    debug("Error")


# Generated at 2022-06-26 05:17:55.937512
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    str_1 = '7}::9n{p[7V'
    str_2 = 'n'
    var_0 = show_corrected_command(str_0)
    var_1 = show_corrected_command(str_1)


# Generated at 2022-06-26 05:17:57.983346
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    with patch('builtins.print') as mocked_print:
        with patch('sys.stderr', new=sys.stdout):
            with debug_time('testing!'):
                pass
            assert mocked_print.call_count == 1



# Generated at 2022-06-26 05:18:00.344123
# Unit test for function color
def test_color():
    str_1 = '\x1b[37;41m[WARN] \x1b[m'
    var_1 = color(str_1)


# Generated at 2022-06-26 05:18:01.233081
# Unit test for function debug
def test_debug():
    debug("Hello world")


# Generated at 2022-06-26 05:18:05.358943
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'g;v:^H&W8.}_\r\\2k"d#Kr'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:18:06.763051
# Unit test for function debug_time
def test_debug_time():
    f = debug_time('test_debug_time')
    assert f != None



# Generated at 2022-06-26 05:18:08.614929
# Unit test for function debug
def test_debug():
    assert debug(var_0) is None


# Generated at 2022-06-26 05:18:10.220829
# Unit test for function confirm_text
def test_confirm_text():
    assert(confirm_text('corrected_command') == [])

# Generated at 2022-06-26 05:18:13.503207
# Unit test for function color
def test_color():
    color_0 = u'\x1b[0m'
    assert color(color_0) == u''


# Generated at 2022-06-26 05:18:14.790902
# Unit test for function debug_time
def test_debug_time():
    assert debug_time(test_case_0) == str_0

# Generated at 2022-06-26 05:18:21.968617
# Unit test for function debug
def test_debug():
    try:
        print('Testing debug: ', end='')
        try:
            test_case_0()
        except Exception as err:
            print('Fail')
            sys.exit(1)
        print('Pass')
    except Exception as err:
        print('Fail\n', err)

# Generated at 2022-06-26 05:18:33.230739
# Unit test for function confirm_text
def test_confirm_text():
    var_0 = str(settings)
    var_0 = int(sys.version_info[0]) if var_0 else 1
    if var_0 is not 1 or var_0 is not 3:
        var_0 = color(colorama.Fore.GREEN) + 'enter' + color(colorama.Style.RESET_ALL)
        var_0 = color(colorama.Fore.BLUE) + '↑' + color(colorama.Style.RESET_ALL)
        var_0 = color(colorama.Fore.BLUE) + '↓' + color(colorama.Style.RESET_ALL)
        var_0 = color(colorama.Fore.RED) + 'ctrl+c' + color(colorama.Style.RESET_ALL)

# Generated at 2022-06-26 05:18:36.030553
# Unit test for function debug_time
def test_debug_time():
    debug_time()
    return "p\x1f\x1ee\r,\rwwwwwwww"


# Generated at 2022-06-26 05:18:37.759662
# Unit test for function color
def test_color():
    assert color('test') == colorama.Fore.GREEN + 'test' + colorama.Style.RESET_ALL


# Generated at 2022-06-26 05:18:41.164497
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import timedelta
    with patch('datetime.datetime') as MockDateTime:

        instance = MockDateTime.now.return_value
        instance.__sub__.return_value = timedelta(seconds=1)
        var_1 = debug_time('msg')
        var_1.__enter__()
        var_1.__exit__('type', 'value', 'traceback')


# Generated at 2022-06-26 05:18:43.884142
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    show_corrected_command(str_0)

# Generated at 2022-06-26 05:18:46.763589
# Unit test for function debug
def test_debug():
    # prepare
    str_1 = 'HVTuV7;G[:lgVwJ"0=zF'
    var_1 = debug(str_1)


# Generated at 2022-06-26 05:18:56.906918
# Unit test for function debug
def test_debug():
    var_0 = debug(' ')
    var_1 = debug('+')
    var_2 = debug('\n')
    var_3 = debug('+')
    var_4 = debug('\t')
    var_5 = debug('\n')
    var_6 = debug('+')
    var_7 = debug('\n')
    var_8 = debug('+')
    var_9 = debug('\n')
    var_10 = debug('+')
    var_11 = debug('\n')
    var_12 = debug('+')
    var_13 = debug('\n')
    var_14 = debug('+')
    var_15 = debug('\n')
    var_16 = debug('+')
    var_17 = debug('\t')
    var_18 = debug('\n')

# Generated at 2022-06-26 05:18:59.999964
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = ';/xn6/<U6'
    how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:19:02.190833
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:19:06.210975
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    test_case_0()


# Generated at 2022-06-26 05:19:07.355690
# Unit test for function debug_time

# Generated at 2022-06-26 05:19:08.850086
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    test_0 = how_to_configure_alias(None)


# Generated at 2022-06-26 05:19:10.849164
# Unit test for function debug_time
def test_debug_time():
    import pytest
    with pytest.raises(Exception):
        raise Exception
    pass


# Generated at 2022-06-26 05:19:14.034688
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'LsA{Qn;mG8U6_ao'
    func_0 = debug_time(str_0)
    func_0.__enter__()
    func_0.__exit__()


# Generated at 2022-06-26 05:19:16.592328
# Unit test for function color
def test_color():
    assert color('color_') == color('color_')


# Generated at 2022-06-26 05:19:20.131377
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'EbAmtJ{'
    var_0 = debug_time(str_0)


# Generated at 2022-06-26 05:19:24.203928
# Unit test for function debug_time
def test_debug_time():
    # Output of function should be true
    # Function takes one argument with value 'debug_time'
    debug_time('debug_time')

# Generated at 2022-06-26 05:19:33.519233
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    lis_0 = ['N']
    str_0 = 'N'
    struc_0 = namedtuple('NamedTuple', 'bold path reload reset content can_configure_automatically')
    var_0 = how_to_configure_alias(struc_0(bold='', path='profile', reload='exec $SHELL', reset='', content='', can_configure_automatically=lis_0, ))
    var_0 = str_0


# Generated at 2022-06-26 05:19:37.244337
# Unit test for function color
def test_color():
    expected_0 = '\x1b[31m'
    expected_1 = ''
    actual_0 = color('\x1b[31m')
    actual_1 = color('')
    assert actual_0 == expected_0 and actual_1 == expected_1

# Generated at 2022-06-26 05:19:41.426890
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('Corrected_command') == None


# Generated at 2022-06-26 05:19:43.026981
# Unit test for function debug
def test_debug():
    var_0 = '>Wcjr|vtz\x7f'
    var_1 = debug(var_0)


# Generated at 2022-06-26 05:19:45.457383
# Unit test for function debug_time
def test_debug_time():
    start_time = datetime.now()
    time.sleep(.5)
    assert(datetime.now() - start_time > 500)


# Generated at 2022-06-26 05:19:47.744993
# Unit test for function debug
def test_debug():
    debug('This is a test')
    # TODO: Add custom assertions
    assert True


# Generated at 2022-06-26 05:19:53.056478
# Unit test for function color
def test_color():
    # int
    assert color(1) == 1
    # float
    assert color(1.0) == 1.0
    # tuple
    dummy_tuple = (1, 2, 3)
    assert color(dummy_tuple) == dummy_tuple
    # string
    assert color("1") == "1"
    # list
    dummy_list = [1, 2, 3]
    assert color(dummy_list) == dummy_list
    # dict
    dummy_dict = {"x": 1, "y": 2, "z": 3}
    assert color(dummy_dict) == dummy_dict


# Generated at 2022-06-26 05:19:56.285830
# Unit test for function debug
def test_debug():
    var_0 = 'sssssss'
    var_1 = debug(var_0)


# Generated at 2022-06-26 05:20:01.673427
# Unit test for function color
def test_color():
    str_1 = '\x1b[0m'
    str_2 = '\x1b[0m'
    var_1 = color(str_2)
    assert var_1 == str_1


# Generated at 2022-06-26 05:20:04.748757
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    obj_0 = debug_time(str_0)


# Generated at 2022-06-26 05:20:06.302963
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debugger'):
        pass



# Generated at 2022-06-26 05:20:07.291741
# Unit test for function debug_time
def test_debug_time():
    debug_time('message')

# Generated at 2022-06-26 05:20:13.415906
# Unit test for function debug
def test_debug():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = debug(str_0)


# Generated at 2022-06-26 05:20:17.654608
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'npm install --save angular-material angular-aria'
    show_corrected_command(str_0)

if __name__ == '__main__':
    test_case_0()

    test_show_corrected_command()

# Generated at 2022-06-26 05:20:19.591095
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'd\x1c'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:20:22.114688
# Unit test for function debug_time
def test_debug_time():
    str_input = 'str_input'
    with debug_time(str_input):
        str_input = 'after_with'
    assert str_input == 'after_with'

# Generated at 2022-06-26 05:20:27.347520
# Unit test for function debug
def test_debug():
    pass

# Load the unit test
test_debug()


# Generated at 2022-06-26 05:20:34.585759
# Unit test for function show_corrected_command
def test_show_corrected_command():
    dict_0 = {"shell": "bash",
    "get_aliases": "[['fuck', 'env SHELL=bash thefuck']]",
    "reload": "source ~/.bashrc",
    "put_to_history": "fuck",
    "sudo_support": False,
    "extras": "eval \"$(thefuck --alias fuck)\""}
    str_0 = 'fuck'
    show_corrected_command(dict_0, str_0)


# Generated at 2022-06-26 05:20:45.285564
# Unit test for function how_to_configure_alias

# Generated at 2022-06-26 05:20:55.326295
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    obj_10 = settings.__class__
    obj_10.no_colors = str_0
    str_1 = 'nvbn*DQ"`\x0c3F=_=>'
    obj_10.debug = str_1
    str_2 = '\\;,|h%9\x0b"sYbKg'
    obj_10.no_colors = str_2
    str_3 = '"'
    obj_20 = const.__class__
    obj_20.USER_COMMAND_MARK = str_3
    str_4 = 'M5R%cH\x0eQ)tLZ.t'

# Generated at 2022-06-26 05:20:57.987979
# Unit test for function debug_time
def test_debug_time():
    str_1 = 'b6Mx#E,|>s(\\<2&'
    var_1 = debug_time(str_1)
    return var_1


# Generated at 2022-06-26 05:21:05.751487
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('Message 1'):
        time.sleep(0.2)
    time.sleep(0.2)
    with debug_time('Message 2'):
        time.sleep(0.2)
    time.sleep(0.2)
    with debug_time('Message 3'):
        time.sleep(0.2)
    time.sleep(0.2)
    with debug_time('Message 4'):
        time.sleep(0.2)
    time.sleep(0.2)


# Generated at 2022-06-26 05:21:18.057735
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand

    script = 'ls -la'
    side_effect = True
    command = Command(script=script, side_effect=side_effect)
    corrected_command = CorrectedCommand(command, script, side_effect)

# Generated at 2022-06-26 05:21:29.111666
# Unit test for function color

# Generated at 2022-06-26 05:21:30.404863
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("How to configure alias ?")


# Generated at 2022-06-26 05:21:39.907239
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from .utils import debug, debug_time
    # Use with statement to ensure execution of finally block.
    # Create initial time variable.
    started = datetime.now()
    time_delta = timedelta(seconds=6)
    time_delta_str = '6 seconds'
    # Create context manager variable.
    with debug_time(time_delta_str) as debug_time_var:
        # context manager variable is the same.
        assert debug_time_var == debug_time

# Generated at 2022-06-26 05:21:42.148250
# Unit test for function debug
def test_debug():
	# Loop for every string in the output
	for str_0 in var_0:
		assert(debug(str_0))


# Generated at 2022-06-26 05:21:51.549692
# Unit test for function debug_time
def test_debug_time():
    contextman_0 = debug_time()
    next(contextman_0)
    str_0 = 'pFvyR<|-W7&uN0\n'
    var_1 = contextman_0.send(str_0)
    var_2 = contextman_0.throw(str_0)
    var_3 = contextman_0.close()
    # Test case 0: Execution of function debug_time
    contextman_1 = debug_time()
    next(contextman_1)
    var_4 = contextman_1.close()
    # Test case 1: Execution of function debug_time


# Test case 0: Execution of function test_case_0
test_case_0()
# Test case 1: Execution of function test_debug_time
test_debug_time()

# Generated at 2022-06-26 05:21:57.024659
# Unit test for function debug_time
def test_debug_time():
    var_0 = 6.4
    str_0 = 'R>XJ*<r\r]xk\rkdg*n'
    var_1 = debug_time(str_0)
    var_1.__enter__()
    var_2 = const.fuck.__sub__(var_0)
    var_1.__exit__(var_2, str_0, str_0)


# Generated at 2022-06-26 05:21:59.505687
# Unit test for function confirm_text
def test_confirm_text():
    str_1 = 'a[!89*OJg@lN%T}T>l[L'
    var_1 = confirm_text(str_1)



# Generated at 2022-06-26 05:22:02.379873
# Unit test for function color
def test_color():
    str_0 = '-Xf/vF0.4'
    var_0 = color(str_0)


# Generated at 2022-06-26 05:22:07.379116
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = debug_time(str_0)


# Generated at 2022-06-26 05:22:11.453938
# Unit test for function debug
def test_debug():
    print(debug('This is a test message'))



# Generated at 2022-06-26 05:22:15.340029
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = debug_time(str_0)
    expected = debug_time(str_0)
    assert var_0 == expected


# Generated at 2022-06-26 05:22:18.512849
# Unit test for function debug_time
def test_debug_time():
    var_0 = debug_time(function_name)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 05:22:30.477258
# Unit test for function color
def test_color():
    print("Test case 1")
    print("-----------")
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    str_1 = ''
    str_2 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = color(str_0)
    var_1 = color(str_1)
    var_2 = color(str_2)

# Generated at 2022-06-26 05:22:34.731934
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'Ld[`rB]r#XA\x0bEg\x7fO`wF^V\x19>' # Corrected command string
    show_corrected_command(str_0)
    return


# Generated at 2022-06-26 05:22:39.726321
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    '''
    This function get an argument as a tuple and print the results
    :return: None
    '''
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = how_to_configure_alias(str_0)


# Generated at 2022-06-26 05:22:46.288992
# Unit test for function debug_time
def test_debug_time():
    def test_case_1(var_0, var_1):
        return var_0 == var_1
    var_0 = '\r2Eh?(dWyj'
    var_1 = version(var_0)
    is_passed = test_case_1(var_0, var_1)

# Generated at 2022-06-26 05:22:48.371672
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = 'LBl_hE[iFqZe'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:22:51.467634
# Unit test for function debug
def test_debug():
    str_0 = 'tCp!VwDnMuv'
    var_0 = debug(str_0)


# Generated at 2022-06-26 05:22:55.842906
# Unit test for function confirm_text
def test_confirm_text():
    assert 1 == 1


# Generated at 2022-06-26 05:23:03.902742
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'oF[;X(Eun\rtSYhz^"m|'
    try:
        show_corrected_command(corrected_command)
    except Exception as e:
        print ('show_corrected_command threw an exception!')


# Generated at 2022-06-26 05:23:06.659514
# Unit test for function debug
def test_debug():
    str_0 = "test string for debug"
    debug(str_0)



# Generated at 2022-06-26 05:23:09.515573
# Unit test for function confirm_text
def test_confirm_text():
    cmd = '-v'
    out = 'fuck -v [enter/↑/↓/ctrl+c]'
    assert out == confirm_text(cmd)


# Generated at 2022-06-26 05:23:10.757900
# Unit test for function debug_time
def test_debug_time():
    with settings.debug_time('test'):
        pass



# Generated at 2022-06-26 05:23:20.095064
# Unit test for function debug_time
def test_debug_time():

    # TEST CASE # 0
    test_case_0()

    # TEST CASE # 1
    str_1 = 'BWJzta*xD)0"\x7f~^M*'
    var_1 = debug_time(str_1)

    var_1.__enter__()

    # TEST CASE # 2
    str_2 = 'J~b*lYp!;n_#Cn(m|'
    var_2 = debug_time(str_2)

    var_2.__enter__()

    # TEST CASE # 3
    str_3 = 'N+wMv6@sW6U8D>U{'
    var_3 = debug_time(str_3)

    var_3.__enter__()

    # TEST CASE # 4

# Generated at 2022-06-26 05:23:23.821062
# Unit test for function color
def test_color():
    assert color('helllo') == colorama.Fore.RED + 'helllo' + colorama.Style.RESET_ALL
    assert color('') == ''


# Generated at 2022-06-26 05:23:31.072191
# Unit test for function color
def test_color():
    main_var = 'dd'
    var_0 = color('dd')
    if main_var == var_0:
        print('color function is working fine')
    else:
        print('color function is not working')


# Generated at 2022-06-26 05:23:35.366768
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_1 = 'gg(Eui'
    str_2 = '{}({})'.format(str_1[1:2],
                            str_1[3:4])
    var_1 = show_corrected_command(str_2)


# Generated at 2022-06-26 05:23:37.648406
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_1 = 'oF[;X(Eun\rtSYhz^"m|'
    var_1 = how_to_configure_alias(str_1)


# Generated at 2022-06-26 05:23:40.034416
# Unit test for function debug_time
def test_debug_time():
    str_1 = 'fgMH\x1c[^#\x00VDK\x0b\x0eU6W\x19{m\x1eRv\x15'
    var_1 = debug_time(str_1)

# Generated at 2022-06-26 05:23:46.811034
# Unit test for function color
def test_color():
    assert color() != None


# Generated at 2022-06-26 05:23:54.005240
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = None
    str_1 = 'oF[;X(Eun\rtSYhz^"m|'
    str_1 = str_1.decode('utf-8')
    ret_1 = (var_0.decode("utf-8")).encode("utf-8")
    ret_1 = ret_1.decode("utf-8")
    ret_1 = ret_1.encode("utf-8")
    assert ret_1 == show_corrected_command(str_1)

if __name__ == '__main__':
    test_case_0()
    test_show_corrected_command()

# Generated at 2022-06-26 05:23:59.254557
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        script = 'ls'
        side_effect = False

    show_corrected_command(CorrectedCommand())


# Generated at 2022-06-26 05:24:02.424661
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = show_corrected_command(str_0)


# Generated at 2022-06-26 05:24:06.591549
# Unit test for function debug
def test_debug():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_0 = 'oF[;X(Eun\rtSYhz^"m|'
    var_1 = debug(var_0)
    assert var_1 is None


# Generated at 2022-06-26 05:24:07.670108
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
  how_to_configure_alias(0)


# Generated at 2022-06-26 05:24:15.709617
# Unit test for function debug_time
def test_debug_time():
    str_0 = '/"\x1dZ:&,\'a}\x18'
    var_0 = debug_time(str_0)
    assert isinstance(var_0, contextmanager)
    with var_0 as var_1:
        str_1 = '%cP_E['
        var_2 = debug(str_1)


# Generated at 2022-06-26 05:24:16.949489
# Unit test for function color
def test_color():
    assert color("hello") == ""


# Generated at 2022-06-26 05:24:24.955365
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'oF[;X(Eun\rtSYhz^"m|'
    thefuck_version = '3.5'
    python_version = '2.7.12'
    shell_info = 'zsh 5.0.7 (x86_64-ubuntu-linux-gnu)'
    var_0 = debug_time(str_0)
    with var_0:
        test_case_0()
        version(thefuck_version, python_version, shell_info)


# Generated at 2022-06-26 05:24:28.504801
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = 'HvGZPIFQn[~\t"n'
    var_0 = how_to_configure_alias(str_0)
