

# Generated at 2022-06-26 05:14:33.697338
# Unit test for function debug
def test_debug():
    debug("debug unit test success!")



# Generated at 2022-06-26 05:14:37.928755
# Unit test for function confirm_text
def test_confirm_text():
    with debug_time("confirm_text"):
        str_0 = '\'DWt0UYcH1"fkVRVz>'
        var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:14:42.279666
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        assert func_0 == '\'DWt0UYcH1"fkVRVz>'
        print('Test case 0 of show_corrected_command is passed!')
    except AssertionError as e:
        print('Test case 0 of show_corrected_command is failed!')


# Generated at 2022-06-26 05:14:51.422050
# Unit test for function color
def test_color():
    message_0 = u'[WARN] Rule {rule}\n----------------------------\nVa'
    test_0 = u'\x1b[41m\x1b[37m\x1b[1m[WARN] Rule {rule}\n----------------------------\nVa\x1b[0m'
    assert test_0 == color(message_0)

    exception_0 = u'[WARN] Rule {rule}:\nTraceback (most recent call last)\n{rule.name}:\n'
    test_1 = u'\x1b[41m\x1b[37m\x1b[1m[WARN] Rule {rule}:\nTraceback (most recent call last)\n{rule.name}:\n\x1b[0m'
    assert test_1 == color(exception_0)

    test

# Generated at 2022-06-26 05:14:56.114709
# Unit test for function debug_time
def test_debug_time():
    var_0 = 'c'
    var_1 = 'z'
    with debug_time('test_debug_time'):
        var_0 += var_1

    var_2 = 'c' + 'z'
    return var_0 == var_2


# Generated at 2022-06-26 05:14:58.706186
# Unit test for function debug_time
def test_debug_time():
    str_0 = '\'DWt0UYcH1"fkVRVz>'
    var_0 = debug_time(str_0)


# Generated at 2022-06-26 05:15:03.876790
# Unit test for function debug_time
def test_debug_time():
    str_0 = 'ybYF=O:A_9a1W'
    str_1 = 'r85x!G^*u'
    var_0 = debug_time(str_0)
    debug(str_1)

if __name__ == '__main__':
    test_case_0()
    test_debug_time()

# Generated at 2022-06-26 05:15:07.399736
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        var_0 = '\'DWt0UYcH1"fkVRVz>'
        show_corrected_command(var_0)
    except:
        print('Failed to test show_corrected_command')
        raise


# Generated at 2022-06-26 05:15:09.160538
# Unit test for function debug
def test_debug():
    str_0 = ';v0RkLx8'
    debug(str_0)


# Generated at 2022-06-26 05:15:11.799774
# Unit test for function debug_time
def test_debug_time():
    test_case = 1
    print("Test case " + str(test_case))
    debug_time("blabla")


# Generated at 2022-06-26 05:15:18.550106
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('None')


# Generated at 2022-06-26 05:15:19.540934
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    test_case_0()

# Generated at 2022-06-26 05:15:22.090723
# Unit test for function debug_time
def test_debug_time():
    with debug_time(settings.no_colors):
        pass

# Generated at 2022-06-26 05:15:26.309312
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = '-a --help'
    var_0 = confirm_text(str_0)


# Generated at 2022-06-26 05:15:28.596073
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = '\'DWt0UYcH1"fkVRVz>'
    var_0 = show_corrected_command(str_0)
    print(var_0)

# vim: set expandtab ts=4 sw=4 tw=80 :

# Generated at 2022-06-26 05:15:29.933053
# Unit test for function color
def test_color():
    var_0 = color(u'')
    var_1 = color('HE')

# Generated at 2022-06-26 05:15:36.500902
# Unit test for function confirm_text
def test_confirm_text():
    str_0 = '$\xc2\xb5\xc2\x8d'
    var_0 = confirm_text(str_0)

if __name__ == '__main__':
    test_case_0()
    test_confirm_text()

# Generated at 2022-06-26 05:15:39.981013
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True
    assert color('red') == ''


# Generated at 2022-06-26 05:15:43.293204
# Unit test for function debug_time
def test_debug_time():
    test_debug_time_0()
    test_debug_time_1()
    test_debug_time_2()
    test_debug_time_3()


# Generated at 2022-06-26 05:15:48.095949
# Unit test for function debug_time
def test_debug_time():
    start_time = datetime.now()
    str_0 = '\'DWt0UYcH1"fkVRVz>'
    str_1 = '\x1d'
    var_0 = debug_time(str_0)
    var_1 = debug_time(str_1)


# Generated at 2022-06-26 05:15:51.613460
# Unit test for function debug
def test_debug():
    debug('message')


# Generated at 2022-06-26 05:15:53.235630
# Unit test for function debug_time
def test_debug_time():
    int_0 = None
    x = debug_time(int_0)
    return x



# Generated at 2022-06-26 05:15:54.943634
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'ls'
    show_corrected_command(command)


# Generated at 2022-06-26 05:15:58.481285
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.conf import CorrectedCommand
    # TODO add test for side effect
    corrected_command = CorrectedCommand(script='echo fuck', side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-26 05:16:08.916550
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from .conf import settings
    from . import const
    from .__main__ import debug_time
    from . import conf
    from . import rules
    from . import shell
    from . import utils

    if __name__ == '__main__':
        settings.debug = True
    else:
        settings.debug = False

    with debug_time('a'):
        print('ok!')

    with debug_time('debug_time'):
        print('ok!')

    with debug_time('debug_time'):
        print('ok!')


# Generated at 2022-06-26 05:16:10.448770
# Unit test for function debug
def test_debug():
    debug("thefuck")
    assert True


# Generated at 2022-06-26 05:16:11.401191
# Unit test for function debug
def test_debug():
    debug('msg')



# Generated at 2022-06-26 05:16:13.947245
# Unit test for function confirm_text
def test_confirm_text():
    correct_res = u'test_script [enter/↑/↓/ctrl+c]'
    assert confirm_text('test_script') == correct_res

# Generated at 2022-06-26 05:16:16.086197
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    unit_test_how_to_configure_alias = how_to_configure_alias(None)


# Generated at 2022-06-26 05:16:18.636991
# Unit test for function debug
def test_debug():
    assert debug('msg') == sys.stderr.write('\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n')


# Generated at 2022-06-26 05:16:22.881188
# Unit test for function debug
def test_debug():
    if settings.debug:
        debug(u"")


# Generated at 2022-06-26 05:16:24.291578
# Unit test for function confirm_text
def test_confirm_text():
    int_0 = 'python sads.py'
    int_1 = True
    var_0 = confirm_text(int_0, int_1)

# Generated at 2022-06-26 05:16:25.446831
# Unit test for function debug
def test_debug():
    int_0 = None
    var_0 = debug(int_0)

# Generated at 2022-06-26 05:16:27.810074
# Unit test for function debug_time
def test_debug_time():
    with debug_time(msg="Test message"):
        var_1 = failed(int_0)

# Generated at 2022-06-26 05:16:29.435615
# Unit test for function debug_time
def test_debug_time():
    with debug_time("hello") as msg:
        pass


# Generated at 2022-06-26 05:16:32.577831
# Unit test for function debug_time
def test_debug_time():
    with debug_time("hello"):
        pass
    # disabling debug
    settings.debug = False
    with debug_time("hello"):
        pass
    settings.debug = True
# testing for function confirm_text

# Generated at 2022-06-26 05:16:35.172105
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    corrected_command = CorrectedCommand(script = 'ls', side_effect=True)
    show_corrected_command(corrected_command)


# Generated at 2022-06-26 05:16:37.597725
# Unit test for function show_corrected_command
def test_show_corrected_command():
    string_0 = None
    show_corrected_command(string_0)


# Generated at 2022-06-26 05:16:38.565262
# Unit test for function debug_time
def test_debug_time():
    debug_time(1)

# Generated at 2022-06-26 05:16:44.794657
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_1 = "ls"
    bool_0 = True
    corrected_command_0 = show_corrected_command(str_1)
    corrected_command_1 = show_corrected_command(bool_0)


# Generated at 2022-06-26 05:16:52.749064
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys

    backup = sys.stdout
    sys.stdout = StringIO.StringIO()
    sys.stderr = StringIO.StringIO()

    test_case_0()

    sys.stdout = backup
    sys.stderr = backup


# Generated at 2022-06-26 05:16:54.642424
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls -a') == 'ls -a'

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-26 05:16:55.272939
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-26 05:16:57.088981
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_msg'):
        pass



# Generated at 2022-06-26 05:17:00.014084
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    int_0 = CorrectedCommand('ls', 'ls -la', False, False)
    var_0 = show_corrected_command(int_0)


# Generated at 2022-06-26 05:17:08.700497
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script='ls',
        side_effect=u' (+side effect)',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-26 05:17:10.487179
# Unit test for function debug
def test_debug():
    debug('This is a utest for function debug()')
    # TODO: invoke function debug()

# Generated at 2022-06-26 05:17:11.605150
# Unit test for function debug_time
def test_debug_time():
    with debug_time("TEST") as test:
        print(test)


# Generated at 2022-06-26 05:17:17.621563
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    int_0 = None
    var_0 = how_to_configure_alias(int_0)


# Generated at 2022-06-26 05:17:20.009212
# Unit test for function debug
def test_debug():
    format_0 = "%s"
    arg_0 = "test_debug"
    assert debug(format_0 % arg_0) == sys.stderr.write(u'test_debug\n')

# Generated at 2022-06-26 05:17:27.731786
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Sends 1, 2, 3, 4, and 5 as input to show_corrected_command
    Tests that the function correctly displays on the screen each input
    """
    input_list = ['1', '2', '3', '4', '5']
    for input in input_list:
        show_corrected_command(input)
        

# Generated at 2022-06-26 05:17:29.399153
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Command

    confirm_text(Command(script='script', side_effect=False))


# Generated at 2022-06-26 05:17:30.270199
# Unit test for function color
def test_color():
    assert color('test') == 'test'


# Generated at 2022-06-26 05:17:30.924100
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(test_case_0)



# Generated at 2022-06-26 05:17:33.621896
# Unit test for function show_corrected_command
def test_show_corrected_command():
    int_0 = None
    show_corrected_command(int_0)


# Generated at 2022-06-26 05:17:34.991620
# Unit test for function debug
def test_debug():
    debug('msg')


# Generated at 2022-06-26 05:17:38.528249
# Unit test for function color
def test_color():
    import colorama
    color_ = 'red'
    if settings.no_colors:
        color(color_) == ''
    else:
        color(color_) == color(colorama.Fore.RED)


# Generated at 2022-06-26 05:17:45.180897
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import thefuck.shells.default
    import sys
    import StringIO
    args = thefuck.shells.default.ConfigureParams(
        path='~/.bashrc',
        reload='source ~/.bashrc',
        can_configure_automatically=True,
        content=u'eval $(thefuck --alias)'
    )
    _stdout = sys.stdout

# Generated at 2022-06-26 05:17:48.974505
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_case_1'):
        int_0 = None
        var_1 = failed(int_0)
    # Expected print:
    # DEBUG: test_case_1 took: 0:00:00.000026


# Generated at 2022-06-26 05:17:53.329138
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import CorrectedCommand
    from .history import Command

    command = Command(script='ls', stderr='')
    corrected_command = CorrectedCommand(command)
    show_corrected_command(corrected_command)


# Generated at 2022-06-26 05:17:56.415891
# Unit test for function debug
def test_debug():
    debug(debug)

# Generated at 2022-06-26 05:17:58.135623
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-26 05:18:05.251258
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .application import Application
    from .shells import Shell
    from .utils import wrap_command
    from .rules import FuckRule
    from .correctors import PerfectCorrector
    from .shells.bash import Bash

    class TestRule(FuckRule):

        def match(self, command):
            return True

        def get_new_command(self, command):
            return 'echo test', 'echo test'

    rule = TestRule('test', '', '', lambda *args: True)
    corrector = PerfectCorrector(rule)
    application = Application(
        rules_dir='', shell=Bash(), excluded_rules=[], require_confirmation=False,
        wait_command=1, accept_entire_script=False)
    wrapped = wrap_command(['echo', 'test'], application)

    # test function
    show

# Generated at 2022-06-26 05:18:06.683454
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debug_time'):
        pass


# Generated at 2022-06-26 05:18:11.014549
# Unit test for function debug_time
def test_debug_time():
    var_0 = debug_time('var_0')
    var_1 = var_0.__exit__()
    bool_0 = bool(var_1)
    int_0 = 7 / bool_0
    print(int_0)

# Generated at 2022-06-26 05:18:17.197218
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time("test"):
        time.sleep(1)


# Generated at 2022-06-26 05:18:26.669761
# Unit test for function debug
def test_debug():
    import os

    def file_abs_path(filename):
        return os.path.join(os.path.dirname(__file__), filename)

    with open(file_abs_path('debug.txt'), 'w') as debug_file:
        with open(os.devnull, 'w') as devnull:
            debug('test debug')
            sys.stderr.flush()
            debug_file.flush()
            assert debug_file.read() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n'
            assert devnull.read() == ''



# Generated at 2022-06-26 05:18:29.020916
# Unit test for function debug
def test_debug():
    try:
        debug("Test")
    except Exception:
        return False
    else:
        return True



# Generated at 2022-06-26 05:18:31.377499
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        sys.stdout.write('test!')


# Generated at 2022-06-26 05:18:32.988562
# Unit test for function debug_time
def test_debug_time():

    with debug_time("Test debug_time"):
        pass

# Generated at 2022-06-26 05:18:37.449925
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('git a')


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-26 05:18:40.258725
# Unit test for function debug_time
def test_debug_time():
    from thefuck.utils import debug_time
    from datetime import datetime
    from time import sleep

    waited_time = datetime.now() + datetime.timedelta(seconds=1)
    with debug_time('wait 1 sec'):
        while datetime.now() < waited_time:
            sleep(0.1)



# Generated at 2022-06-26 05:18:49.952584
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == '\x1b[31m'
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.BRIGHT) == '\x1b[1m'
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == '\x1b[37;41;1m'
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL
    assert color(colorama.Style.RESET_ALL) == '\x1b[0m'

# Generated at 2022-06-26 05:18:52.911354
# Unit test for function show_corrected_command
def test_show_corrected_command():
    str_0 = 'echo aaa'
    bool_0 = False
    test_case_0 = CorrectedCommand(script=str_0, side_effect=bool_0)
    var_0 = show_corrected_command(test_case_0)


# Generated at 2022-06-26 05:18:57.043599
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        int_0 = 0
        var_0 = int_0
    return var_0

# Generated at 2022-06-26 05:18:59.726607
# Unit test for function confirm_text
def test_confirm_text():
    var_0 = confirm_text('var_0')
    assert var_0 == None


# Generated at 2022-06-26 05:19:00.684580
# Unit test for function debug
def test_debug():
    debug("input")


# Generated at 2022-06-26 05:19:01.243901
# Unit test for function debug_time
def test_debug_time():
    pass

# Generated at 2022-06-26 05:19:06.099348
# Unit test for function confirm_text
def test_confirm_text():
    command = "fuck"
    confirm_text(command)
    assert command == "fuck"

# Generated at 2022-06-26 05:19:07.462359
# Unit test for function debug
def test_debug():
    debug('Hello world')


# Generated at 2022-06-26 05:19:11.829235
# Unit test for function debug
def test_debug():
    test_0 = debug('meow')
    test_1 = debug('woof')


# Generated at 2022-06-26 05:19:14.172148
# Unit test for function debug_time

# Generated at 2022-06-26 05:19:16.656391
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-26 05:19:18.288027
# Unit test for function debug
def test_debug():
    debug(str())


# Generated at 2022-06-26 05:19:26.813937
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    int_0 = ConfigurationDetails(path='/Users/travis/.bashrc', can_configure_automatically=True, content='eval $(thefuck --alias)', reload='source ~/.bashrc')
    var_0 = how_to_configure_alias(int_0)


# Generated at 2022-06-26 05:19:30.349921
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == ''
    assert color(colorama.Fore.RED) == ''



# Generated at 2022-06-26 05:19:33.304539
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Test without side effect
    test_case_0 = {"command": "cd /path/", "side_effect": None}
    show_corrected_command(test_case_0)
    # Test with side effect
    test_case_1 = {"command": "cd /path/", "side_effect": "sudo ls -l"}
    show_corrected_command(test_case_1)


# Generated at 2022-06-26 05:19:37.795356
# Unit test for function debug_time
def test_debug_time():
    try:
        from datetime import datetime
        msg = 'test'
        with debug_time(msg):
            started = datetime.now()
            debug(u'{} took: {}'.format(msg, datetime.now() - started))
        return True
    except:
        return False


# Generated at 2022-06-26 05:19:38.283210
# Unit test for function debug
def test_debug():
    assert debug('msg')


# Generated at 2022-06-26 05:19:45.334331
# Unit test for function confirm_text
def test_confirm_text():
    from .command import Command
    from .corrected_command import CorrectedCommand
    from .shells import Shell
    import pytest
    from .utils import get_closest

    command = Command('ls', '/')
    corrected_command = CorrectedCommand(get_closest('ls', []), 'ls')
    shell = Shell('test','test',['test'])
    
    confirm_text(corrected_command)
    var_1 = 0
    assert var_1 == 0


# Generated at 2022-06-26 05:19:49.411238
# Unit test for function debug
def test_debug():
    int_0 = None
    var_0 = debug(int_0)


# Generated at 2022-06-26 05:19:51.917358
# Unit test for function confirm_text
def test_confirm_text():
    import datetime
    from .shells import Zsh
    
    corrected_command = Zsh(u'pwd')
    a = confirm_text(corrected_command)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-26 05:19:53.888223
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    str_0 = None
    var_0 = how_to_configure_alias(str_0)

# Generated at 2022-06-26 05:19:59.561659
# Unit test for function debug_time
def test_debug_time():
    import time
    t = time.time()
    with debug_time('test_debug_time') as v1:
        v1 = time.time() - t
        time.sleep(.5)
    # This line is for test_debug_time must to print <value> = 0.525848197937
    print('test_debug_time must to print <value> = %s' %v1)


# Generated at 2022-06-26 05:20:00.684947
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)


# Generated at 2022-06-26 05:20:09.613157
# Unit test for function debug
def test_debug():
    # Test message
    test_msg = 'test message'
    # Let's backup original value
    saved_settings_debug = settings.debug
    # Set debug mode to True
    settings.debug = True
    # Set stdout to string stream
    import StringIO
    saved_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    # Debug message
    debug(test_msg)
    # Get output message
    result = sys.stderr.getvalue()
    # Cleanup stdout
    sys.stderr = saved_stderr
    # Let's restore original value
    settings.debug = saved_settings_debug
    assert '[DEBUG] %s' % test_msg in result


# Generated at 2022-06-26 05:20:11.789381
# Unit test for function debug
def test_debug():
    test_case_0()


# Generated at 2022-06-26 05:20:12.871260
# Unit test for function debug_time
def test_debug_time():
    failed('error')


# Generated at 2022-06-26 05:20:14.792344
# Unit test for function confirm_text
def test_confirm_text():
    # Initialising arguments
    corrected_command = None
    confirm_text(corrected_command)


# Generated at 2022-06-26 05:20:18.868474
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import pytest

    try:
        show_corrected_command(
            const.CorrectedCommand('ls -la', 'ls -lah'))
    except:
        pytest.fail('Function show_corrected_command raises exception.')

# Generated at 2022-06-26 05:20:26.765914
# Unit test for function debug
def test_debug():
    debug('test debug')
    return



# Generated at 2022-06-26 05:20:30.821201
# Unit test for function show_corrected_command
def test_show_corrected_command():
    int_0 = None
    var_0 = show_corrected_command(int_0)


# Generated at 2022-06-26 05:20:34.714669
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # This is example for semantic code
    # int_0 = ''
    # string_0 = show_corrected_command(int_0)
    # This is example for semantic code
    # int_0 = ''
    # int_1 = ''
    # string_0 = confirm_text(int_0, int_1)
    int_0 = ''
    string_0 = debug(int_0)
    # This is example for semantic code
    # class_0 = type('', (object,), {})
    # int_0 = ''
    # with class_0(int_0):
    #     pass
    # This is example for semantic code
    # int_0 = ''
    # int_1 = ''
    # string_0 = how_to_configure_alias(int_0, int_1)
    #

# Generated at 2022-06-26 05:20:35.904169
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-26 05:20:36.457835
# Unit test for function debug_time
def test_debug_time():
    pass

# Generated at 2022-06-26 05:20:41.258745
# Unit test for function debug
def test_debug():
    int_1 = 1
    var_1 = debug(int_1)
    assert var_1 == None or var_1 == '1'
    # AssertionError: assert None or var_1 == '1' 
    int_2 = None
    var_2 = debug(int_2)
    assert var_2 == None or var_2 == ''
    # AssertionError: assert None or var_2 == '' 


# Generated at 2022-06-26 05:20:46.004191
# Unit test for function debug_time
def test_debug_time():
    var_1 = '<function debug_time at 0x7ff5e5c5d378>'
    var_1 = debug_time()
    return var_1


# Generated at 2022-06-26 05:20:48.053164
# Unit test for function debug_time
def test_debug_time():
    with debug_time(msg=u'This is test case for debug time'):
        print(u'This is test case for debug time')
    pass

# Generated at 2022-06-26 05:20:50.179339
# Unit test for function debug_time
def test_debug_time():
    str_0 = "test_msg"
    with debug_time(str_0):
        pass

# Generated at 2022-06-26 05:20:51.768010
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color('test') != 'fail'


# Generated at 2022-06-26 05:21:04.347048
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Example for default arguments
    how_to_configure_alias()
    output = sys.stdout.getvalue().strip()
    assert output == "Seems like \x1b[1mfuck\x1b[0m alias isn't configured!\nPlease put \x1b[1mcontent\x1b[0m in your \x1b[1mpath\x1b[0m and apply changes with \x1b[1mreload\x1b[0m or restart your shell.\nOr run \x1b[1mfuck\x1b[0m a second time to configure it automatically.\nMore details - https://github.com/nvbn/thefuck#manual-installation"


# Generated at 2022-06-26 05:21:06.390991
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    int_0 = None
    var_0 = how_to_configure_alias(int_0)


# Generated at 2022-06-26 05:21:09.198972
# Unit test for function color
def test_color():
    assert type(color(colorama.Fore.RED)) == str
    assert type(color("value")) == str
    assert color("value") == "value"


# Generated at 2022-06-26 05:21:12.206396
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    example_command = CorrectedCommand("example", False)
    show_corrected_command(example_command)



# Generated at 2022-06-26 05:21:16.195085
# Unit test for function confirm_text
def test_confirm_text():
    global settings
    settings = Settings()
    settings.no_colors = 1
    settings.wait_command = 1
    # Corrected command of thefuck script
    settings.corrected_command = 'ls -al'
    settings.use_colors = 0
    confirm_text(settings)


# Generated at 2022-06-26 05:21:18.947503
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """Test the display of corrected command."""
    from thefuck.utils import CorrectedCommand
    show_corrected_command(CorrectedCommand('echo "echo"', False))
    show_corrected_command(CorrectedCommand('echo ""', True))


# Generated at 2022-06-26 05:21:21.193722
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''


# Generated at 2022-06-26 05:21:24.787140
# Unit test for function confirm_text

# Generated at 2022-06-26 05:21:26.056598
# Unit test for function debug_time
def test_debug_time():
    sys.stderr.write('>>debug_time<<')


# Generated at 2022-06-26 05:21:28.289137
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias() == None


# Generated at 2022-06-26 05:21:37.385727
# Unit test for function color
def test_color():
    assert color('color') == ''
    settings.no_colors = False
    assert color('color') == 'color'
    settings.no_colors = True


# Generated at 2022-06-26 05:21:43.885737
# Unit test for function debug
def test_debug():
    int_0 = 2059929481
    var_0 = ''
    var_1 = True
    var_2 = True
    var_3 = debug(int_0)
    var_4 = None
    var_5 = False
    var_6 = False
    var_7 = debug(var_0)
    var_8 = debug(var_1)
    var_9 = debug(var_2)
    var_10 = debug(var_3)
    var_11 = debug(var_4)
    var_12 = debug(var_5)
    var_13 = debug(var_6)
    var_14 = debug(var_7)
    var_15 = debug(var_8)
    var_16 = debug(var_9)
    var_17 = debug(var_10)
    var_

# Generated at 2022-06-26 05:21:44.837669
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    the_fuck()


# Generated at 2022-06-26 05:21:46.010623
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass


# Generated at 2022-06-26 05:21:48.234725
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    try:
        yield
    finally:
        debug(u'{} took: {}'.format("this", datetime.now() - started))

# Generated at 2022-06-26 05:21:52.941243
# Unit test for function debug_time
def test_debug_time():
    int_0 = None
    var_0 = datetime.now()
    var_1 = debug_time(int_0)
    with var_1:
        var_1 = (datetime.now() - var_0)
        var_2 = (u' took: ' + var_1)
        var_2 = (int_0 + var_2)
        var_3 = debug(var_2)



# Generated at 2022-06-26 05:21:55.923955
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.rule import Command, Corrections
    str_0 = Command("str_0")
    list_0 = Corrections("list_0")
    confirm_text(list_0)


# Generated at 2022-06-26 05:21:57.451429
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = object()
    show_corrected_command(command)

# Generated at 2022-06-26 05:21:59.219072
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(int_0) == const.USER_COMMAND_MARK


# Generated at 2022-06-26 05:22:00.432653
# Unit test for function debug_time
def test_debug_time():
    debug_time("debug time")

# Generated at 2022-06-26 05:22:06.860195
# Unit test for function debug_time
def test_debug_time():
    with debug_time('function'):
        a = 1
        b = 2
        c = a + b
    assert c == 3


# Generated at 2022-06-26 05:22:09.201103
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
# Test case end


# Generated at 2022-06-26 05:22:14.255277
# Unit test for function confirm_text
def test_confirm_text():
    from . import corrector
    try:
        # Test case 0
        test_instance = corrector.CorrectedCommand(int_0)
        corrected_command = test_instance
        confirm_text(corrected_command)
    except:
        traceback.print_exc()


# Generated at 2022-06-26 05:22:16.191117
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import CorrectedCommand
    corrected_command = CorrectedCommand.CorrectedCommand()
    show_corrected_command(corrected_command)


# Generated at 2022-06-26 05:22:25.285199
# Unit test for function confirm_text
def test_confirm_text():
    print("Confirm text TEST:")
    # confirming_command: thefuck.types.CorrectedCommand
    class CorrectedCommand(object):
        def __init__(self):
            self.script = "Test script"
            self.side_effect = True

    confirming_command = CorrectedCommand()
    confirm_text(confirming_command)
    # Excepted result is:
    """
    Confirm text TEST:
    $Test script (+side effect) [enter/↑/↓/ctrl+c]
    """

# Generated at 2022-06-26 05:22:29.373822
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    try:
        yield
    finally:
        debug(u'{} took: {}'.format(msg, datetime.now() - started))


# Generated at 2022-06-26 05:22:31.224816
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details)

#Unit test for function already_configured

# Generated at 2022-06-26 05:22:32.627014
# Unit test for function debug
def test_debug():
    debug('msg')
    assert True

# test for function warn

# Generated at 2022-06-26 05:22:34.863008
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(True)


# Generated at 2022-06-26 05:22:39.498396
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_command = 'ls'
    corrected_command = {'script': test_command, 'side_effect': False}
    const.USER_COMMAND_MARK = '$ '
    show_corrected_command(corrected_command)



# Generated at 2022-06-26 05:22:45.708106
# Unit test for function debug_time
def test_debug_time():
    debug_time('Hello')


# Generated at 2022-06-26 05:22:50.726312
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_settings
    from .shells import Bash
    from .shells.bash import BashCommand
    from .shells.zsh import ZshCommand
    from .shells.fish import FishCommand
    from .shells.common import Command
    import os
    import sys

    commands = [
        BashCommand(
            script='sudo ls',
            side_effect=True),
        ZshCommand(
            script='sudo ls',
            side_effect=True
        ),
        FishCommand(script='sudo ls',
                    side_effect=True
        ),
        Command(
            script='sudo ls',
            side_effect=True
        )
    ]


# Generated at 2022-06-26 05:22:57.163141
# Unit test for function debug_time
def test_debug_time():
    test_debug_time_1()
    test_debug_time_2()

# Test debug_time function with a valid argument and a error value

# Generated at 2022-06-26 05:23:03.584144
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(0)
    how_to_configure_alias(1)
    how_to_configure_alias(2)
    how_to_configure_alias(3)
    how_to_configure_alias(4)
    how_to_configure_alias(5)


if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-26 05:23:04.662596
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_show_corrected_command_0()


# Generated at 2022-06-26 05:23:08.051660
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("python3 raynor.py")

# Generated at 2022-06-26 05:23:09.764929
# Unit test for function confirm_text
def test_confirm_text():
    # confirm_text(None)
    failed(confirm_text(None))


# Generated at 2022-06-26 05:23:18.690251
# Unit test for function confirm_text
def test_confirm_text():
    global const
    const = reload(const)
    warn('Function tested')
    const.USER_COMMAND_MARK = '>'
    
    def test_case_0():
        global corrected_command
        corrected_command = 'test_case_0'
        confirm_text(corrected_command)
    test_case_0()
    

# Generated at 2022-06-26 05:23:20.815949
# Unit test for function how_to_configure_alias

# Generated at 2022-06-26 05:23:22.041700
# Unit test for function debug
def test_debug():
    debug('hello')

# Generated at 2022-06-26 05:23:29.369468
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time("Test debug time"):
        time.sleep(2)



# Generated at 2022-06-26 05:23:31.978445
# Unit test for function debug
def test_debug():
    for int_0 in range(10):
        if (int_0 == 3):
            debug(var_0)


# Generated at 2022-06-26 05:23:33.690863
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(True)
# Test case for function how_to_configure_alias

# Generated at 2022-06-26 05:23:34.830509
# Unit test for function debug_time
def test_debug_time():
    passed = True
    with debug_time('test_debug_time'):
        time.sleep(1)
    return passed


# Generated at 2022-06-26 05:23:41.184175
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Stub for corrected_command
    class Stub_corrected_command():
        # Stub for script
        class script:
            value = None

        script = script()
        # Stub for side_effect
        class side_effect:
            value = None

        side_effect = side_effect()
    # Stub for instance
    class Stub_instance():
        # Stub for corrected_command
        class corrected_command:
            value = None

        corrected_command = corrected_command()
    # Stub for shell
    class Stub_shell():
        # Stub for instance
        instance = Stub_instance()
    # Stub for corrected_command
    corrected_command = Stub_corrected_command()
    var_0 = show_corrected_command(corrected_command)


# Generated at 2022-06-26 05:23:43.513171
# Unit test for function debug_time
def test_debug_time():
    with debug_time("abc"):
        var_0 = 1 + 1

# Generated at 2022-06-26 05:23:45.063630
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("corrected_command") is None



# Generated at 2022-06-26 05:23:47.391303
# Unit test for function debug_time
def test_debug_time():
    my_time = debug_time()
    my_time.next()
    my_time.next()

    assert(debug_time().next()[2] == 2)

# Generated at 2022-06-26 05:23:53.332271
# Unit test for function debug
def test_debug():
    from mock import patch
    content = 'test'
    with patch('sys.stderr') as sys_stderr:
        debug(content)
        sys_stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
                msg=content,
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-26 05:23:54.948999
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-26 05:23:59.923715
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command == sys.stderr.write


# Generated at 2022-06-26 05:24:08.581866
# Unit test for function color
def test_color():
    # First test case
    # Check it works and returns the expected result
    expected_result_0 = u''
    result_0 = color('')
    assert result_0 == expected_result_0
    # Second test case
    # Check it works and returns the expected result
    expected_result_1 = u'\x1b[31m\x1b[1m\x1b[7mHello world!\x1b[0m'
    result_1 = color('\x1b[31m\x1b[1m\x1b[7mHello world!\x1b[0m')
    assert result_1 == expected_result_1


# Generated at 2022-06-26 05:24:11.830730
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')



# Generated at 2022-06-26 05:24:13.879065
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    int_1 = None
    var_1 = how_to_configure_alias(int_1)


# Generated at 2022-06-26 05:24:22.879097
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Local variables
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    int_0 = None
    int_1 = None
    int_2 = None
    int_3 = None
    int_4 = None
    int_5 = None
    int_6 = None
    int_7 = None
    int_8 = None
    int_9 = None
    int_10 = None
    int_11 = None
    int_12 = None
    int_13 = None
    int_14 = None
    int_15 = None
    int_16 = None
    int_17 = None
    int_18 = None

# Generated at 2022-06-26 05:24:25.813230
# Unit test for function color
def test_color():
	# AssertionError: '\x1b[41m\x1b[30m\x1b[1m[WARN] \x1b[0m' != ''
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''


# Generated at 2022-06-26 05:24:32.114960
# Unit test for function debug_time
def test_debug_time():
    # Test with no exception
    with debug_time('test'):
        int_1 = 1 + 1
    # Test with exception
    try:
        with debug_time('test'):
            raise ValueError('test message')
    except ValueError as e:
        if not e.message == 'test message':
            raise ValueError('debug_time test failed')
