

# Generated at 2022-06-26 05:14:37.094306
# Unit test for function confirm_text
def test_confirm_text():
    class corrected_command:
        def __init__(self, script, side_effect = False):
            self.script = script
            self.side_effect = side_effect
        
    test_case_confirm_text_0(corrected_command(u'fuck', False))
    test_case_confirm_text_1(corrected_command(u'fuck', True))



# Generated at 2022-06-26 05:14:38.913113
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)


# Generated at 2022-06-26 05:14:47.187033
# Unit test for function color

# Generated at 2022-06-26 05:14:51.039662
# Unit test for function debug_time
def test_debug_time():
    try:
        start_time = datetime.now()
        with debug_time('test'):
            time.sleep(1)
        print(datetime.now() - start_time)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    test_case_0()
    test_debug_time()

# Generated at 2022-06-26 05:14:52.790049
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)



# Generated at 2022-06-26 05:14:59.079049
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf import ConfigurationDetails
    ConfigurationDetails('source ~/.bash_profile', '~/.bash_profile', True)
    assert ConfigurationDetails.import_config == (
        u'Please put {bold}{content}{reset} in your'
        u'{bold}{path}{reset} and apply '
        u'changes with {bold}{reload}{reset} or restart your shell.')


# Generated at 2022-06-26 05:15:00.480033
# Unit test for function color
def test_color():
    print(color('color'))


# Generated at 2022-06-26 05:15:01.394593
# Unit test for function debug
def test_debug():
    debug(tuple_0)


# Generated at 2022-06-26 05:15:03.536009
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = debug_time(tuple_0)


# Generated at 2022-06-26 05:15:04.844437
# Unit test for function color
def test_color():
    assert color(False) == ''
    assert color(True) != ''


# Generated at 2022-06-26 05:15:09.829513
# Unit test for function debug_time
def test_debug_time():
    debug_time('test_debug_time')
    #sys.stderr.write('test_debug_time took ' + delta + '\n')



# Generated at 2022-06-26 05:15:17.828495
# Unit test for function confirm_text
def test_confirm_text():
    from collections import namedtuple
    from . import corrector
    from .utils import memoize
    from .rules.python import match, get_new_command
    from .rules.python import match_against_cmd

    print(confirm_text(corrected_command="test"))

    class PythonRule(object):
        name = "Python"

        @staticmethod
        @memoize
        def get_new_command(command):
            return get_new_command(command)

        def match(self, command):
            return match(command)

        def get_new_command(self, command):
            return self.get_new_command(command.script)

        def enabled_by_default(self, command):
            return True

    # Create an instance of class PythonRule
    python_rule = PythonRule()

    # Create an

# Generated at 2022-06-26 05:15:27.747156
# Unit test for function color

# Generated at 2022-06-26 05:15:36.587118
# Unit test for function debug
def test_debug():
    import sys
    import StringIO

    old_stdout = sys.stdout
    redirect_stdout = sys.stdout = StringIO.StringIO()

    try:
        debug('test_debug')

        sys.stdout = old_stdout
        return redirect_stdout.getvalue() == '\x1b[94m\x1b[1mDEBUG:\x1b[0m test_debug\n'
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-26 05:15:39.675345
# Unit test for function debug
def test_debug():
    debug_text = 'test debug message'
    debug(debug_text)


# Generated at 2022-06-26 05:15:41.888899
# Unit test for function show_corrected_command
def test_show_corrected_command():
    int_1 = 1
    show_corrected_command(int_1)


# Generated at 2022-06-26 05:15:46.371829
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test case") as debug_time.debug_time_result:
        test_case_0()
    assert(debug_time_result.msg == "test case")
    assert(debug_time_result.started != None)


# Generated at 2022-06-26 05:15:46.946527
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert 1 == 1

# Generated at 2022-06-26 05:15:48.226018
# Unit test for function confirm_text
def test_confirm_text():
    #confirm_text("test")
    test_case_0()

# Generated at 2022-06-26 05:15:52.103071
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = FakeCorrectedCommand(script='ls',
                                             side_effect=False)
    confirm_text(corrected_command)
    assert_equal(corrected_command.script, 'ls')


# Generated at 2022-06-26 05:15:56.778296
# Unit test for function debug
def test_debug():
    msg = 'f...'  # check that f... word is replaced with fuck
    debug(msg)


# Generated at 2022-06-26 05:16:01.633430
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = debug_time(tuple_0)


# Generated at 2022-06-26 05:16:03.543935
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)


# Generated at 2022-06-26 05:16:06.557166
# Unit test for function debug
def test_debug():
    sys.stdout.write("Unit test for function debug\n")
    msg="Test"
    debug(msg)
    return True


# Generated at 2022-06-26 05:16:16.864851
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import thefuck.shells
    import tempfile
    import os
    script = u'git log'
    side_effect = False
    shells = thefuck.shells.get_enabled_shells()
    temp_folder = os.path.join(tempfile.gettempdir(), 'test_folder')
    os.mkdir(temp_folder)
    os.chdir(temp_folder)
    for shell in shells:
        if shell.supported:
            corrected_command = shell.get_command(command=script,
                                                  side_effect=side_effect)
            show_corrected_command(corrected_command)
    os.chdir(os.pardir)
    os.rmdir(temp_folder)

# Generated at 2022-06-26 05:16:20.116812
# Unit test for function show_corrected_command

# Generated at 2022-06-26 05:16:22.319002
# Unit test for function debug
def test_debug():
    tuple_0 = 'test_debug'
    debug(tuple_0)
    show_corrected_command(tuple_0)


# Generated at 2022-06-26 05:16:24.599764
# Unit test for function color
def test_color():
    color_0 = color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT)
    assert color_0 == '[WARN] '


# Generated at 2022-06-26 05:16:29.750242
# Unit test for function debug_time
def test_debug_time():
    # Setup
    t0 = time.time()
    time.sleep(3)  # sleep for 3 seconds
    # Call function
    with debug_time("New Message"):
        time.sleep(2)
    t1 = time.time()
    delta = t1 - t0
    assert delta >= 5  # because we slept twice for 3 seconds each


# Generated at 2022-06-26 05:16:31.831282
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = debug_time(tuple_0)


# Generated at 2022-06-26 05:16:35.640193
# Unit test for function debug
def test_debug():
    test_0 = "test_0"
    debug(test_0)


# Generated at 2022-06-26 05:16:40.695358
# Unit test for function confirm_text
def test_confirm_text():
    class CorrectedCommand:
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    corrected_command = CorrectedCommand('script test', True)
    output = confirm_text(corrected_command)

# Generated at 2022-06-26 05:16:44.162932
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("ls -l")


# Generated at 2022-06-26 05:16:48.796592
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time(tuple_0):
            tuple_0 = 10
    except:
        name = 'Exception'



# Generated at 2022-06-26 05:16:50.143397
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    tuple_1 = (1,2,3,4)
    how_to_configure_alias(tuple_1)

# Generated at 2022-06-26 05:16:52.567554
# Unit test for function show_corrected_command
def test_show_corrected_command():
    tuple_1 = (1, )
    var_1 = show_corrected_command(tuple_1)


# Generated at 2022-06-26 05:16:56.738253
# Unit test for function confirm_text
def test_confirm_text():
    test_script = "./test.py"
    corrected_command = Command(test_script, True)
    print("test is passed") if confirm_text(corrected_command) is True else print("test is failed")



# Generated at 2022-06-26 05:16:58.923909
# Unit test for function debug
def test_debug():
    # TODO
    pass
    # print(debug(const.COMMAND_FAILED_STDERR))

# Generated at 2022-06-26 05:17:00.326835
# Unit test for function color
def test_color():
    assert color(colorama.Style.RESET_ALL) == '\x1b[0m'


# Generated at 2022-06-26 05:17:05.777195
# Unit test for function debug
def test_debug():
    try:
        tuple_0 = ()
        var_0 = debug(tuple_0)
    except Exception as err:
        print(err)
        raise err


# Generated at 2022-06-26 05:17:15.216728
# Unit test for function debug_time
def test_debug_time():
    var_debug_time_1 = debug_time('var_debug_time_1')
    setattr(var_debug_time_1, 'started', True)
    var_debug_time_0 = debug_time('var_debug_time_0')
    setattr(var_debug_time_0, 'started', True)
    var_debug_time_2 = debug_time('var_debug_time_2')
    setattr(var_debug_time_2, 'started', True)
    setattr(var_debug_time_2, 'msg', 'var_debug_time_2')
    var_debug_time_2.__enter__()
    # Debug time should be more than 0
    time_diff = datetime.now() - var_debug_time_1.started

# Generated at 2022-06-26 05:17:21.715638
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    str_4 = debug(tuple_0)
    str_2 = debug(str_4)
    str_1 = debug(str_2)
    str_3 = debug(str_1)


# Generated at 2022-06-26 05:17:23.073952
# Unit test for function debug_time
def test_debug_time():
    debug_time("0")


# Generated at 2022-06-26 05:17:30.166488
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .types import ConfigurationDetails
    from .types import Shell
    from .conf import Settings
    from .utils import get_closest
    from .utils import replace_argument

    # Test with empty configuration details
    how_to_configure_alias(None)

    # Test with not empty configuration details
    settings = Settings(shell=Shell.suffix(''))
    settings.no_colors = True
    configuration_details = ConfigurationDetails(path='/test_config',
                                                 content='test_content',
                                                 reload='test_reload',
                                                 can_configure_automatically=False)
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-26 05:17:38.117302
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Get the class object of Command
    from thefuck.command import Command
    # Prepare the arguments for testing
    script = 'git commit -a -m "Did something awesome"'
    side_effect = False
    # Get the Command class object with the argument
    corrected_command = Command(script, side_effect)

    # Assert the result
    result = u'    git commit -a -m "Did something awesome"\n'
    assert show_corrected_command(corrected_command) == result
    
    

# Generated at 2022-06-26 05:17:40.460898
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    tuple_1 = ()
    var_1 = how_to_configure_alias(tuple_1)


# Generated at 2022-06-26 05:17:42.411810
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)


# Generated at 2022-06-26 05:17:52.062811
# Unit test for function debug_time
def test_debug_time():
    with debug_time(var_1):
        var_3 = True
        var_4 = True
        var_5 = True
        var_6 = True
        var_7 = True
        var_9 = debug_time(var_2)
        var_10 = var_9.send(var_2)
        var_12 = debug_time(var_8)
        var_13 = var_12.send(var_8)
        var_14 = var_9.throw(var_13)
        var_15 = var_12.send(var_14)
        var_17 = debug_time(var_16)
        var_18 = var_17.send(var_16)
        var_19 = var_9.throw(var_18)
        var_20 = var_12.send(var_19)

# Generated at 2022-06-26 05:17:55.129919
# Unit test for function confirm_text
def test_confirm_text():
    # Initiaalize corrected_command for testing function
    corrected_command = const.CorrectedCommand(script='fuck git',
                                               side_effect=True)
    var_0 = confirm_text(corrected_command)


# Generated at 2022-06-26 05:17:56.714591
# Unit test for function show_corrected_command
def test_show_corrected_command():
    tuple_0 = ()
    var_0 = show_corrected_command(tuple_0)


# Generated at 2022-06-26 05:18:00.422135
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)

# Generated at 2022-06-26 05:18:06.349870
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import sys
    import tempfile
    import platform
    import subprocess
    import time

    # Get the current platform
    platform_system = platform.system()
    # Get the current directory
    curr_dir = os.path.dirname(os.path.abspath(__file__))
    # Create a temporary directory to store temporary files
    temp_dir = tempfile.mkdtemp()
    # Store all the strings related with the temporary directory, files, etc.
    all_temp_strs = []

    # Get the environment variable `TMPDIR`
    tmpdir = os.environ.get('TMPDIR')
    # Remove the environment variable `TMPDIR` if it exists
    if tmpdir:
        del os.environ['TMPDIR']
    # Get the current time
    curr_

# Generated at 2022-06-26 05:18:07.690620
# Unit test for function debug_time
def test_debug_time():
    print(debug_time('test_debug_time'))

# Generated at 2022-06-26 05:18:17.895821
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import bash
    from thefuck.shells import fish
    from thefuck.shells import zsh
    from thefuck.types import Command
    from thefuck.types import CorrectedCommand
    from thefuck.util import show_corrected_command
    # test for bash
    var_1 = Command('pwd', 'pwd', '$ ')
    var_2 = CorrectedCommand(var_1, 'echo $PWD', True)
    var_3 = show_corrected_command(var_2)
    assert var_3 == 'pwd'
    # test for fish
    var_4 = Command('pwd', 'pwd', '> ')
    var_5 = CorrectedCommand(var_4, 'echo $PWD', True)

# Generated at 2022-06-26 05:18:19.613305
# Unit test for function color
def test_color():
    assert color(3) == 3
    assert color(3) != 4


# Generated at 2022-06-26 05:18:20.214404
# Unit test for function confirm_text
def test_confirm_text():
    pass


# Generated at 2022-06-26 05:18:21.123312
# Unit test for function confirm_text
def test_confirm_text():
    tuple_0 = ()
    var_0 = confirm_text(tuple_0)


# Generated at 2022-06-26 05:18:25.268926
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) ==  '\x1b[101m\x1b[97m\x1b[1m'


# Generated at 2022-06-26 05:18:26.771060
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass
    # how_to_configure_alias(configuration_details)

# Generated at 2022-06-26 05:18:28.273008
# Unit test for function confirm_text
def test_confirm_text():
    print(confirm_text(' '))

# Generated at 2022-06-26 05:18:33.029665
# Unit test for function debug
def test_debug():
    for i in range(2):
        var_0 = debug(i)


# Generated at 2022-06-26 05:18:36.761217
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command:
        def __init__(self):
            self.side_effect = False
            self.script = 'ls -l'

    var_1 = show_corrected_command(corrected_command)



# Generated at 2022-06-26 05:18:45.149709
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    tuple_1 = ()
    var_0 = debug(tuple_0)
    tuple_1 = (tuple_0,)
    var_0 = debug(tuple_0)
    tuple_1 = (tuple_0,)
    var_0 = debug(tuple_0)
    tuple_1 = (tuple_0,)
    var_0 = debug(tuple_0)
    tuple_1 = (tuple_0,)


# Generated at 2022-06-26 05:18:47.048648
# Unit test for function debug
def test_debug():
    var_0 = ''
    tuple_0 = (var_0,)
    var_1 = debug(tuple_0)


# Generated at 2022-06-26 05:18:48.469640
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    var_0 = how_to_configure_alias()
    print(var_0)


# Generated at 2022-06-26 05:18:50.119983
# Unit test for function confirm_text
def test_confirm_text():
    tuple_0 = ()
    var_0 = confirm_text(tuple_0)


# Generated at 2022-06-26 05:18:52.776277
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(const.ConfigurationDetails(can_configure_automatically=True, path='path', content='content', reload='reload'))
    how_to_configure_alias(None)


# Generated at 2022-06-26 05:18:57.043157
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)
# End unit test for function debug


# Generated at 2022-06-26 05:19:02.045519
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class test_case_1(object):
        script = 'echo'
        side_effect = False
    show_corrected_command(test_case_1)
    class test_case_2(object):
        script = 'cat'
        side_effect = True
    show_corrected_command(test_case_2)


# Generated at 2022-06-26 05:19:08.665188
# Unit test for function debug_time
def test_debug_time():
    import time
    time_debug = time.time()
    tuple_0 = ()
    var_0 = debug_time(tuple_0)
    time_debug = time.time() - time_debug
    print(time_debug)


# Generated at 2022-06-26 05:19:16.526844
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    tuple_0 = ()
    how_to_configure_alias(tuple_0)


# Generated at 2022-06-26 05:19:19.211142
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print('Should print this line and exit')
    sys.exit(0)


# Generated at 2022-06-26 05:19:28.378729
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    show_corrected_command(CorrectedCommand(u'ls', True))
    show_corrected_command(CorrectedCommand('ls', False))
    show_corrected_command(CorrectedCommand(u'ls', True))


# Generated at 2022-06-26 05:19:31.746102
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)



# Generated at 2022-06-26 05:19:33.723779
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias((None, None, None, None))

# Generated at 2022-06-26 05:19:35.314329
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)



# Generated at 2022-06-26 05:19:39.101248
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = debug_time(tuple_0)
    var_1 = debug_time(var_0)

# Generated at 2022-06-26 05:19:40.923473
# Unit test for function confirm_text
def test_confirm_text():
    tuple_0 = ()
    var_0 = confirm_text(tuple_0)


# Generated at 2022-06-26 05:19:43.096932
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrected_command import CorrectedCommand
    show_corrected_command(CorrectedCommand('echo hello', False))



# Generated at 2022-06-26 05:19:43.657321
# Unit test for function debug_time
def test_debug_time():
    debug_time(1)


# Generated at 2022-06-26 05:19:49.592435
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = None
    var = confirm_text(corrected_command)


# Generated at 2022-06-26 05:19:50.556112
# Unit test for function color
def test_color():
    test_case_0()


# Generated at 2022-06-26 05:19:52.801450
# Unit test for function debug_time
def test_debug_time():
    a = debug_time(1)
    assert a == None


# Generated at 2022-06-26 05:20:01.518044
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Find function how_to_configure_alias business logic
    str_0 = "Seems like {bold}fuck{reset} alias isn't configured!".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))
    str_1 = "Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell."
    str_2 = "Or run {bold}fuck{reset} a second time to configure it automatically."
    str_3 = "More details - https://github.com/nvbn/thefuck#manual-installation"
    class_0 = configuration_details
    call_0 = how_to_configure_alias(class_0)
    # For applying changes run reload or restart your shell.

# Generated at 2022-06-26 05:20:04.251399
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    show_corrected_command(Shell('', '', '', '').from_script('fuck'))


# Generated at 2022-06-26 05:20:06.078468
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print("Function : show_corrected_command")
    print("Test Case 0:")
    test_case_0()

# Generated at 2022-06-26 05:20:07.801568
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Function debug_time with parameters msg

# Generated at 2022-06-26 05:20:09.921553
# Unit test for function debug
def test_debug():
    tuple_1 = ()
    var_1 = debug(tuple_1)


# Generated at 2022-06-26 05:20:14.588791
# Unit test for function confirm_text
def test_confirm_text():
    class a:
        pass
    command = a
    command.script = "command"
    command.side_effect = "side_effect"
    confirm_text(command)
    print()

test_confirm_text()

# Generated at 2022-06-26 05:20:16.137899
# Unit test for function debug
def test_debug():
    debug("TEST MESSAGE")

test_case_0()
test_debug

# Generated at 2022-06-26 05:20:26.996530
# Unit test for function confirm_text
def test_confirm_text():
    try:
        tuple_0 = ()
        var_0 = confirm_text(tuple_0)
    except Exception as inst:
        print(type(inst))
        print(inst.args)
        print(inst)


# Generated at 2022-06-26 05:20:32.684406
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    ConfigurationDetails = namedtuple('ConfigurationDetails', 'path content reload can_configure_automatically')
    configuration_details = ConfigurationDetails('path', 'content', 'reload', True)
    tuple_0 = ()
    how_to_configure_alias(tuple_0)
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-26 05:20:34.965622
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({
        'path': '~/.bashrc',
        'reload': '$ source ~/.bashrc',
        'content': 'eval $(thefuck --alias)',
        'can_configure_automatically': False})


# Generated at 2022-06-26 05:20:38.563164
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    from .conf import CommandFormat
    from .utils import Traversal, TraverseDirection
    show_corrected_command(CorrectedCommand(
        CommandFormat(1, 0, True, Traversal(TraverseDirection.FROM_LEFT)),
        'dummy command'))


# Generated at 2022-06-26 05:20:40.547658
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = ''
    var_1 = how_to_configure_alias(configuration_details)


# Generated at 2022-06-26 05:20:41.855946
# Unit test for function debug
def test_debug():
    var_1 = debug(unicode('utf-8'))


# Generated at 2022-06-26 05:20:48.624398
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .types import Shell
    test_conf_details = ConfigurationDetails(
        '~/.zshrc', '~/.zshrc', '.zshrc', 'source ~/.zshrc', True, Shell.zsh)
    how_to_configure_alias(test_conf_details)



# Generated at 2022-06-26 05:20:49.962293
# Unit test for function debug_time
def test_debug_time():
    debug_time('test_debug_time')

# Generated at 2022-06-26 05:20:51.256370
# Unit test for function color
def test_color():
    assert color("f") == "f"


# Generated at 2022-06-26 05:20:53.414265
# Unit test for function confirm_text
def test_confirm_text():
    # Case 0
    tuple_0 = ()
    userscript_0 = UserScript(tuple_0)
    var_1 = confirm_text(userscript_0)


# Generated at 2022-06-26 05:21:00.234269
# Unit test for function show_corrected_command
def test_show_corrected_command():
    cmd = u'pwd'
    show_corrected_command(cmd)


# Generated at 2022-06-26 05:21:01.799808
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED


# Generated at 2022-06-26 05:21:10.158899
# Unit test for function color
def test_color():
    try:
        assert color('0') == ''
    except AssertionError as e:
        e.args += ('Failed at: {0}:\n{1} != {2}'.format('test_color()', e.args[0], ''),)
        raise

    try:
        assert color('1') == '1'
    except AssertionError as e:
        e.args += ('Failed at: {0}:\n{1} != {2}'.format('test_color()', e.args[0], '1'),)
        raise



# Generated at 2022-06-26 05:21:11.580705
# Unit test for function debug_time
def test_debug_time():
    with debug_time('session_id'):
        pass

# Generated at 2022-06-26 05:21:17.698991
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    colorama.init()
    import datetime
    ConfigurationDetails = collections.namedtuple('ConfigurationDetails', ['can_configure_automatically', 'path', 'reload', 'content'])
    configuration_details = ConfigurationDetails(can_configure_automatically = True, path = 'test_path', reload = 'test_reload', content = 'test_content')
    test_0 = how_to_configure_alias(configuration_details)
    assert test_0 == True


# Generated at 2022-06-26 05:21:21.644878
# Unit test for function debug
def test_debug():
    # disabled debug
    settings.debug = False
    tuple_0 = ()
    var_0 = debug(tuple_0)
    # enabled debug
    settings.debug = True
    tuple_1 = ()
    var_1 = debug(tuple_1)



# Generated at 2022-06-26 05:21:28.576716
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import ConfigurationDetails
    import sys
    import StringIO
    buf = StringIO.StringIO()
    sys.stderr = buf
    configuration_details = ConfigurationDetails(content='alias fuck=echo', path='.bashrc', reload='source ~/.bashrc', can_configure_automatically='True')
    var_0 = how_to_configure_alias(configuration_details)
    sys.stderr = sys.__stderr__


# Generated at 2022-06-26 05:21:33.108675
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_case'):
        for i in range(0, 100):
            test_case_0()
            test_case_0()
            test_case_0()


# Generated at 2022-06-26 05:21:39.959284
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED) == colorama.Fore.RED


# Generated at 2022-06-26 05:21:42.950166
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import settings
    with debug_time('test_debug_time'):
        assert True
    settings.debug = True
    with debug_time('test_debug_time'):
        assert True


# Generated at 2022-06-26 05:21:55.845208
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = False
    # Test return for function debug with argument msg
    test_msg = u'Some message'
    debug(test_msg)



# Generated at 2022-06-26 05:21:58.128227
# Unit test for function show_corrected_command
def test_show_corrected_command():
    tuple_0 = ('tuple_0',)
    str_0 = show_corrected_command(tuple_0)



# Generated at 2022-06-26 05:22:00.670986
# Unit test for function show_corrected_command
def test_show_corrected_command():
    tuple_0 = ()
    var_0 = show_corrected_command(tuple_0)


# Generated at 2022-06-26 05:22:05.542847
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_case_0()


# Generated at 2022-06-26 05:22:09.814465
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "ls -l"
    show_corrected_command(corrected_command)


# Generated at 2022-06-26 05:22:11.599119
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)


# Generated at 2022-06-26 05:22:13.559170
# Unit test for function debug
def test_debug():
    msg = 'Test'
    print(debug(msg))


# Generated at 2022-06-26 05:22:16.557080
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Case 0
    tuple_0 = (u'ls -l', True)
    var_0 = show_corrected_command(tuple_0)
    assert var_0 == u' > ls -l (+side effect)'


# Generated at 2022-06-26 05:22:24.900322
# Unit test for function confirm_text
def test_confirm_text():
    commands = ["cat /etc/hosts", "cd ~", "git commit --help", "flweaf",
        "fafasfaf", "fafafadadf", "git add --help"]
    for command in commands:
        cmd = command.split(' ')
        corrected_command = Command(cmd[0], cmd[1:])
        confirm_text(corrected_command)

test_case_0()
test_confirm_text()

# Generated at 2022-06-26 05:22:26.190419
# Unit test for function debug
def test_debug():
    debug('Unit test')
    
    

# Generated at 2022-06-26 05:22:38.862673
# Unit test for function debug
def test_debug():
    tuple_0 = ()
    var_0 = debug(tuple_0)


# Generated at 2022-06-26 05:22:40.746715
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = "{bold}fuck{reset} alias isn't configured!"
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-26 05:22:45.918997
# Unit test for function color
def test_color():
    before_color = "test_string"
    color_0 = color(before_color)
    after_color = color_0
    assert(before_color == after_color)


# Generated at 2022-06-26 05:22:49.379338
# Unit test for function debug
def test_debug():
    try:
        my_variable_0 = 1
        msg = '{}{}'.format(my_variable_0, my_variable_0)
        var_0 = debug(msg)
    except NameError as err:
        var_0 = str(err)



# Generated at 2022-06-26 05:22:52.956139
# Unit test for function debug_time
def test_debug_time():
    start = datetime.now()
    debug_time("debug_time")
    end = datetime.now()
    assert (end - start) == (end - start)

# Generated at 2022-06-26 05:22:54.509115
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-26 05:23:02.872041
# Unit test for function debug
def test_debug():
    # Init with default value
    try:
        print(settings.debug)
        debug("Some debug info.")
    except:
        assert False
    # Init with True
    try:
        settings.debug = True
        print(settings.debug)
        debug("Some debug info.")
    except:
        assert False
    # Init with False
    try:
        settings.debug = False
        print(settings.debug)
        debug("Some debug info.")
    except:
        assert False
    exit(0)



# Generated at 2022-06-26 05:23:09.675964
# Unit test for function show_corrected_command
def test_show_corrected_command():
    tuple_0 = ()
    tuple_1 = ('git commit -v --reset-author',)
    tuple_2 = ('git commit -v --reset-author', True)
    var_0 = show_corrected_command(tuple_0)
    var_1 = show_corrected_command(tuple_1)
    var_2 = show_corrected_command(tuple_2)

# Generated at 2022-06-26 05:23:13.414717
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rule import Command
    assert show_corrected_command(Command(script='ls',
                                          side_effect=False)) == '> ls'
    assert show_corrected_command(Command(script='ls',
                                          side_effect=True)) == '> ls (+side effect)'



# Generated at 2022-06-26 05:23:14.292672
# Unit test for function debug_time
def test_debug_time():
    debug_time(20)


# Generated at 2022-06-26 05:23:32.102290
# Unit test for function confirm_text
def test_confirm_text():
    class mock_corrected_command(object):
        def __init__(self):
            self.script = "test"
            self.side_effect = True
    mock_corrected_command = mock_corrected_command()
    var_0 = confirm_text(mock_corrected_command)


# Generated at 2022-06-26 05:23:35.113410
# Unit test for function debug
def test_debug():
    test_string = 'test_debug'
    debug(test_string)
    assert_equals(sys.stderr.getvalue(), test_string + '\n')

# Generated at 2022-06-26 05:23:36.368762
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u"confirm_text") is None


# Generated at 2022-06-26 05:23:37.211848
# Unit test for function debug
def test_debug():
    assert debug('test') == None


# Generated at 2022-06-26 05:23:39.928805
# Unit test for function confirm_text
def test_confirm_text():
    # msg = u'fuck'
    # msg = msg.strip()
    tuple_0 = ()
    tuple_1 = ()
    msg = u'ls --al'
    tuple_0 = ()
    tuple_1 = ()
    var_0 = confirm_text(msg)
    return (var_0)

# Generated at 2022-06-26 05:23:43.049341
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = debug_time(tuple_0)
    # Test no exception was raised
    assert var_0 is None

# Generated at 2022-06-26 05:23:46.358913
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        show_corrected_command({'script': 'script_string', 'side_effect': False})
    except TypeError:
        print("Test case 0 - Failed")
    else:
        print("Test case 0 - Passed")


# Generated at 2022-06-26 05:23:51.090745
# Unit test for function confirm_text

# Generated at 2022-06-26 05:23:54.294573
# Unit test for function debug_time
def test_debug_time():
    var_0 = 'test'
    var_1 = debug_time(var_0)
    assert var_1 is not None, 'Unit test failed'


# Generated at 2022-06-26 05:24:02.070585
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    var_0 = datetime.now()
    yield
    var_1 = datetime.now()
    var_2 = var_1 - var_0
    var_3 = u'{} took: {}'.format(tuple_0, var_2)
    var_4 = debug(var_3)

# Generated at 2022-06-26 05:24:15.321445
# Unit test for function debug_time
def test_debug_time():
    tuple_0 = ()
    debug_time(tuple_0)



# Generated at 2022-06-26 05:24:18.103076
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    try:
        tuple_1 = ()
        var_1 = how_to_configure_alias(tuple_1)
    except:
        var_1 = None


# Generated at 2022-06-26 05:24:22.747064
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import wrap_with_print
    from .command import Command
    from .shells import Shell, BashShell
    from .rule import Rule
    from .types import MatchedPillar
    from .main import ConfirmCommand
    command = Command('test.py')
    shell = Shell()
    confirm_command = ConfirmCommand(command, None, Shell(), {})
    confirm_command.confirm = True
    confirm_text(confirm_command)


# Generated at 2022-06-26 05:24:27.426715
# Unit test for function color
def test_color():
    var_0 = color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT)
    assert var_0 == "[WARN] "
