

# Generated at 2022-06-24 05:42:43.641369
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command("app.rb")
    assert('app.rb' in confirm_text("app.rb"))


# Generated at 2022-06-24 05:42:45.258075
# Unit test for function version
def test_version():
    assert version('version_1', 'python_version_1', 'shell_version_1') == None



# Generated at 2022-06-24 05:42:46.720790
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test')
    except RuntimeError:
        exception('Unittest', sys.exc_info())



# Generated at 2022-06-24 05:42:48.616410
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test_exception')
    except Exception:
        exception('test_exception', sys.exc_info())

# Generated at 2022-06-24 05:42:51.266004
# Unit test for function confirm_text
def test_confirm_text():
    with open('./tests/text_output.txt', 'w') as f:
        sys.stdout = f
        confirm_text(corrected_command='git fucking commit')


# Generated at 2022-06-24 05:42:53.329225
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command="pwd")



# Generated at 2022-06-24 05:42:55.164902
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug('foo')
    finally:
        settings.debug = False

# Generated at 2022-06-24 05:42:56.439587
# Unit test for function warn
def test_warn():
    warn('test')
    warn('test with colorama')

# Generated at 2022-06-24 05:43:01.341964
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .types import ConfigurationDetails

    how_to_configure_alias(ConfigurationDetails(None, None, None,
         Shell('bash', ['~/.bashrc'], 'source ~/.bashrc'), None))

    how_to_configure_alias(None)
    how_to_configure_alias(False)



# Generated at 2022-06-24 05:43:03.645263
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("") == const.USER_COMMAND_MARK + " [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-24 05:43:06.907742
# Unit test for function debug
def test_debug():
    # Output should be written to stderr
    assert debug.__code__.co_varnames[1:] == ('msg', 'sys')
    assert debug.__code__.co_name == 'debug'



# Generated at 2022-06-24 05:43:08.308450
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # TODO: Add some tests
    pass


# Generated at 2022-06-24 05:43:09.646737
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Some debug'):
        pass



# Generated at 2022-06-24 05:43:14.879568
# Unit test for function configured_successfully
def test_configured_successfully():
    assert 'fuck' in configured_successfully('The Fuck 3.8 using Python 2.7 and Bash 4.4.23\n')
    assert 'The Fuck 3.8' in configured_successfully('The Fuck 3.8 using Python 2.7 and Bash 4.4.23\n')
    assert 'Python 2.7' in configured_successfully('The Fuck 3.8 using Python 2.7 and Bash 4.4.23\n')
    assert 'Bash 4.4.23' in configured_successfully('The Fuck 3.8 using Python 2.7 and Bash 4.4.23\n')

# Generated at 2022-06-24 05:43:17.552182
# Unit test for function exception
def test_exception():
    exc_info = sys.exc_info()
    exc_info[0] = 'Test'
    exception('Test title', exc_info)

# Generated at 2022-06-24 05:43:23.584848
# Unit test for function warn
def test_warn():
    from StringIO import StringIO

    from mock import patch

    from . import main

    with patch.object(sys, 'stderr', StringIO()) as stderr:
        main.warn(u'Message')
        assert stderr.getvalue() == (
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] Message\x1b[0m\n'.encode('utf-8'))



# Generated at 2022-06-24 05:43:31.947042
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import load_settings
    from .utils import wrap_args
    from . import __version__ as thefuck_version
    from . import __requires__ as thefuck_requires
    from .const import HOW_TO_CONFIGURE_ALIAS
    from .parser import create_parser
    from .main import _handle_command

    settings = load_settings()
    settings.debug = True
    parser = create_parser(settings)
    args = parser.parse_args(wrap_args(['fuck', 'ls']))
    _handle_command(args, thefuck_version, thefuck_requires, settings)

# Generated at 2022-06-24 05:43:35.386512
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = \
        {
            'path': '~/.bashrc',
            'reload': 'source ~/.bashrc',
            'content': 'eval $(thefuck --alias)',
            'can_configure_automatically': True
        }

    how_to_configure_alias(configuration_details)



# Generated at 2022-06-24 05:43:47.317171
# Unit test for function already_configured
def test_already_configured():
    import tempfile
    from .utils import get_closest, get_aliases

    def is_bash(shell):
        return shell.kind == 'bash' and not shell.path.endswith('sh')

    def is_zsh(shell):
        return shell.kind == 'zsh'

    shell_info = next(get_closest(get_aliases(), is_bash, is_zsh))
    bashrc = tempfile.NamedTemporaryFile(mode='w', delete=False)
    bashrc.write(u'alias fuck="thefuck"')
    bashrc.close()
    configuration_details = const.ConfigurationDetails(
        '~/.bashrc', '. ~/.bashrc', 'bashrc', True)
    already_configured(configuration_details)


# Generated at 2022-06-24 05:43:48.790909
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('your shell.\n')


# Generated at 2022-06-24 05:43:56.913569
# Unit test for function exception
def test_exception():
    exc_info = (
        AttributeError,
        AttributeError('test'),
        None)
    correct_exception_string = (u'[WARN] test:\n'
                                u'Traceback (most recent call last):\n'
                                u'  File "<input>", line 1, in <module>\n'
                                u'AttributeError: test\n'
                                u'\n'
                                u'[WARN] ----------------------------\n'
                                u'\n')
    exception_string = sys.stderr.write(u'[WARN] test:')
    exception_string += sys.stderr.write(u'Traceback (most recent call last):')

# Generated at 2022-06-24 05:44:00.882963
# Unit test for function already_configured
def test_already_configured():
        assert already_configured('sourced .zshrc') ==\
               "Seems like {bold}fuck{reset} alias already configured!\n"\
               "For applying changes run {bold}sourced.zshrc{reset}"\
               " or restart your shell."

# Generated at 2022-06-24 05:44:01.755793
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass

# Generated at 2022-06-24 05:44:02.596954
# Unit test for function warn
def test_warn():
    warn(u"test title")


# Generated at 2022-06-24 05:44:03.802841
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command=None) is None



# Generated at 2022-06-24 05:44:05.224652
# Unit test for function exception
def test_exception():
    mock_exc = (Exception, Exception('Test'), None)
    exception('Test', mock_exc)

# Generated at 2022-06-24 05:44:11.803250
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from StringIO import StringIO
    stream = StringIO()
    sys.stderr, old_stderr = stream, sys.stderr
    colorama.init()

    show_corrected_command(corrected_command.CorrectedCommand(u'ls', u'test'))
    assert stream.getvalue() == '\x1b[92m' + u'fuck test (+side effect)\n' + '\n'
    show_corrected_command(corrected_command.CorrectedCommand(u'ls', None))
    assert stream.getvalue() == '\x1b[92m' + u'fuck test (+side effect)\n' + '\n' + '\x1b[92m' + u'fuck ls\n' + '\n'

    sys.stderr = old_stderr

# Generated at 2022-06-24 05:44:14.068789
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = "configuration_details"
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-24 05:44:15.033402
# Unit test for function already_configured
def test_already_configured():
    print("already_confiured")

# Generated at 2022-06-24 05:44:25.100649
# Unit test for function configured_successfully

# Generated at 2022-06-24 05:44:32.137930
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr = sys.__stderr__
    try:
        rule = None
        class Rule(object):
            def __init__(self):
                self.name = "test"
        rule = Rule()
        exc_info = None
        try:
            raise Exception("test")
        except Exception as e:
            exc_info = sys.exc_info()
        rule_failed(rule, exc_info)
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:44:34.846491
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Rule
    rule = Rule('name', 'echo', True)
    try:
        raise Exception
    except Exception:
        exception = sys.exc_info()
        rule_failed(rule, exception)



# Generated at 2022-06-24 05:44:36.479896
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Given
    configuration_details = None
    # When
    how_to_configure_alias(configuration_details)
    # Then

# Generated at 2022-06-24 05:44:37.279556
# Unit test for function version
def test_version():
    version('1', '2', '3')

# Generated at 2022-06-24 05:44:41.255103
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import shell
    from .shells import get_aliases
    from thefuck.types import Command

    alias = get_aliases(shell())['confirm']
    confirm_text(
        Command(alias.format('echo lol'), 'echo lol', '', '', [], None))

# Generated at 2022-06-24 05:44:44.035287
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import VERSION, PYTHON_VERSION, SHELL_INFO
    version(VERSION, PYTHON_VERSION, SHELL_INFO)

# Generated at 2022-06-24 05:44:44.642746
# Unit test for function rule_failed
def test_rule_failed():
    pass

# Generated at 2022-06-24 05:44:50.395432
# Unit test for function version
def test_version():
    from sys import version
    from os import path
    import sys
    import thefuck.shells as shells
    import thefuck as fuck
    shell = shells.get_shell()
    assert version(fuck.__version__, version, path.basename(shell.path)).split() == ["The", "Fuck", "3.1", "using", "Python", "3.5.1", "and", "zsh"]



# Generated at 2022-06-24 05:44:59.451832
# Unit test for function rule_failed
def test_rule_failed():
    def _test():
        raise Exception('Failed test')
    rule_failed(Rule(name='', match='', get_new_command=lambda cmd: cmd),
                sys.exc_info())
    # Test that exception is properly formated
    class TestRule(Rule):
        name = 'fake'
    test_rule = TestRule()
    rule_failed(test_rule, sys.exc_info())
    # Test that side effect is shown
    def _get_new_command(cmd):
        raise CommandNotFound('Failed test')
    rule_failed(
        Rule(name='broken', match='', get_new_command=_get_new_command,
             side_effect=True),
        sys.exc_info())
    # Test that exception is shown

# Generated at 2022-06-24 05:45:01.603718
# Unit test for function color
def test_color():
    assert color('foo') == ''
    settings.no_colors = False
    assert color('foo') == 'foo'



# Generated at 2022-06-24 05:45:05.265196
# Unit test for function configured_successfully
def test_configured_successfully():
    settings.no_colors = True
    assert configured_successfully('') == \
            'The Fuck alias configured successfully!\n'\
            'For applying changes run '\
            'or restart your shell.'


# Generated at 2022-06-24 05:45:10.249295
# Unit test for function version
def test_version():
    version(
        thefuck_version=u'3.5',
        python_version=u'3.5',
        shell_info=u'git 2.5.0') ==\
        u'The Fuck 3.5 using Python 3.5 and git 2.5.0\n'



# Generated at 2022-06-24 05:45:13.092716
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    rule = Rule('name', 'mock', '<args>', 'mock_call')
    rule_failed(rule, ['mock', 'mock_exc_info'])



# Generated at 2022-06-24 05:45:14.469366
# Unit test for function already_configured
def test_already_configured():
    print(already_configured(configuration_details))


# Generated at 2022-06-24 05:45:15.369721
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('test')


# Generated at 2022-06-24 05:45:17.195164
# Unit test for function exception
def test_exception():
    try:
        raise AssertionError('error')
    except AssertionError:
        exception('Exception!', sys.exc_info())

# Generated at 2022-06-24 05:45:22.232826
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    stderr = StringIO()

    sys.stderr = stderr
    try:
        warn('message')
        assert u'[WARN] message' in stderr.getvalue()
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:45:23.428242
# Unit test for function warn
def test_warn():
    pass



# Generated at 2022-06-24 05:45:26.350837
# Unit test for function rule_failed
def test_rule_failed():
    def is_logging_false(rule, exc_info):
        with settings(debug=False):
            rule_failed(rule, exc_info)


# Generated at 2022-06-24 05:45:29.592866
# Unit test for function debug
def test_debug():
    """
        Shows debug message
    """
    settings.debug = True
    debug(u'Test Debug')
    assert 1 == 1, "This is just checking if the function executed"

# Generated at 2022-06-24 05:45:37.378873
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = corrected_command(script=u'git push', side_effect=True)
    assert show_corrected_command(corrected_command) == \
        u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
            prefix=const.USER_COMMAND_MARK,
            script=corrected_command.script,
            side_effect=u' (+side effect)' if corrected_command.side_effect else u'',
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

if __name__ == '__main___':
    test_show_corrected_command()

# Generated at 2022-06-24 05:45:41.952300
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    output = StringIO()
    original = sys.stderr
    sys.stderr = output
    failed('test')
    sys.stderr = original
    assert 'test' in output.getvalue()



# Generated at 2022-06-24 05:45:46.516403
# Unit test for function version
def test_version():
    version(thefuck_version='3.16', python_version='3.5.1',
            shell_info='sh (test shell)')
    assert sys.stderr.getvalue() == \
        'The Fuck 3.16 using Python 3.5.1 and sh (test shell)\n'



# Generated at 2022-06-24 05:45:47.871584
# Unit test for function rule_failed
def test_rule_failed():
    rule = MockRule()
    rule_failed(rule, None)



# Generated at 2022-06-24 05:45:53.136729
# Unit test for function failed
def test_failed():
    class MockStderr(object):
        def __init__(self):
            self.buffer = ''

        def write(self, data):
            self.buffer += data

    stderr = MockStderr()
    with mock.patch('sys.stderr', stderr):
        failed(u'expected')
    assert stderr.buffer == u'\x1b[31mexpected\x1b[0m\n'



# Generated at 2022-06-24 05:45:54.538726
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'Fuck ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:45:57.616391
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .utils import wrap_streams
    with wrap_streams():
        sys.stderr = StringIO()
        debug(u'Text')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Text\n'

# Generated at 2022-06-24 05:46:01.983598
# Unit test for function version
def test_version():
    import sys
    import os
    sys.stderr = open(os.devnull, 'w')
    try:
        version('1.1.1', '2.7.12', 'Bash 4.3.42(1)')
    finally:
        sys.stderr.close()

# Generated at 2022-06-24 05:46:06.806398
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import FixedCommand
    from .types import Rule

    class fake_rule(object):
        name = 'Fake rule'

    show_corrected_command(FixedCommand('ls -la', 'ls', (), [],
                                       side_effect=False))
    show_corrected_command(FixedCommand('ls -la', 'ls', (), [],
                                       side_effect=True))

# Generated at 2022-06-24 05:46:17.207624
# Unit test for function version
def test_version():
    from thefuck.conf import Config
    from . import __version__ as thefuck_version
    from .types import ShellInfo
    thefuck_settings = Config('', load_system_config=False)
    thefuck_settings.exclude_rules = ['bash_history']
    version(thefuck_version, sys.version, ShellInfo('shell_type', 'version', 'path'))
    assert sys.stderr.getvalue() == 'The Fuck {} using Python {} and shell_type {}\n'.format(thefuck_version,
                                                                                   sys.version,
                                                                                   'version')
    sys.stderr.seek(0)
    sys.stderr.truncate()



# Generated at 2022-06-24 05:46:27.159791
# Unit test for function already_configured
def test_already_configured():
    ''' Checks whether the function already_configured() prints appropriate message when
        already_configured=True and the user is a root.
    '''
    from .app import print_log
    from .shells import Bash, Shell
    from .utils import wrap_retry, get_aliases_path, wrap_settings

    bash = Bash()
    is_configured_mock = wrap_settings(wrap_retry(bash.is_configured))
    already_configured_mock = wrap_settings(wrap_retry(bash.already_configured))
    aliases_path_mock = wrap_settings(get_aliases_path)
    print_log_mock = wrap_settings(print_log)
    print_log = print_log_mock()

    shell_name = Bash.name

# Generated at 2022-06-24 05:46:29.911628
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test Exception')
    except RuntimeError as err:
        exception('Exception function', sys.exc_info())
        assert True



# Generated at 2022-06-24 05:46:39.038173
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    from contextlib import contextmanager
    from . import shell

    @contextmanager
    def capture_output():
        original = sys.stdout
        sys.stdout = StringIO.StringIO()
        yield sys.stdout
        sys.stdout = original

    with capture_output() as out:
        how_to_configure_alias(shell.get_shell(lambda: 'bash')
                               .get_configuration_details())

# Generated at 2022-06-24 05:46:39.445008
# Unit test for function debug
def test_debug():
    debug('debug')

# Generated at 2022-06-24 05:46:48.943508
# Unit test for function exception
def test_exception():
    import StringIO
    from .utils import get_closest
    from StringIO import StringIO
    try:
        get_closest(
            'mam',
            list('man mom ram sam tam'.split()),
            lambda *args: args
        )
    except Exception:
        exc_info = sys.exc_info()
    file_ = StringIO()
    exception(u'Test exception', exc_info)

# Generated at 2022-06-24 05:46:59.494733
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Returns all the colors to default, in case they were changed already.
    colorama.init()
    alias_name = 'fuck'

    # Test output when there are no configuration details passed to
    # how_to_configure_alias function.
    how_to_configure_alias(None)
    expected_output_when_no_configuration_details = \
        'Seems like \x1b[1mfuck\x1b[21m alias isn\'t configured!\n' \
        'More details - https://github.com/nvbn/thefuck#manual-installation\n'
    assert sys.stdout.getvalue() == expected_output_when_no_configuration_details

    # Test output when configuration details are passed to
    # how_to_configure_alias function.
    mock_configuration_

# Generated at 2022-06-24 05:47:03.196040
# Unit test for function warn
def test_warn():
    # check if the call to warn writes to sys.stderr
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = io.StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old

    sys_stderr = sys.stderr
    sys.stderr = io.StringIO()
    with stdoutIO() as s:
        warn('a')
        assert sys.stderr.getvalue() == s.getvalue()
    sys.stderr.close()
    sys.stderr = sys_stderr

# Generated at 2022-06-24 05:47:06.913237
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import RulesCollection
    rule = RulesCollection.rules[0]

# Generated at 2022-06-24 05:47:12.474442
# Unit test for function exception
def test_exception():
    """Test for exception function. It has been mocked.
       Because exception function uses sys.stderr.write
       and it is hard to test it."""
    class MockException(Exception):
        pass
    try:
        raise MockException('Mocked')
    except MockException:
        exc_info = sys.exc_info()
        exception('Mocked title', exc_info)

# Generated at 2022-06-24 05:47:19.241762
# Unit test for function debug
def test_debug():
    from .conf import Config
    from io import StringIO
    settings = Config()
    out = StringIO()
    sys.stderr = out
    settings.debug = True
    msg = u'Тест'
    debug(msg)
    out.seek(0)
    assert out.readline().strip() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Тест'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:47:26.211702
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from .conf import get_settings
    backup = sys.stderr
    try:
        sys.stderr = StringIO()
        failed('msg')
        assert sys.stderr.getvalue() == \
            u'{red}msg{reset}\n'.format(
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL))
    finally:
        sys.stderr = backup

# Generated at 2022-06-24 05:47:34.531115
# Unit test for function version
def test_version():
    from thefuck.shells import Shell
    from thefuck.utils import get_metadata, get_shell_info
    from thefuck.const import VERSION
    thefuck_version = get_metadata('version')
    python_version = sys.version
    shell_info = get_shell_info(Shell)
    assert version(thefuck_version, python_version, shell_info) ==\
        u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                       python_version,
                                                       shell_info)


# Generated at 2022-06-24 05:47:40.294514
# Unit test for function warn
def test_warn():
    with settings(no_colors=True):
        assert u'[WARN] test\n' == warn('test')
    with settings(no_colors=False):
        assert (u'\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n' ==
                warn('test'))



# Generated at 2022-06-24 05:47:41.120045
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(Command('test script'))

# Generated at 2022-06-24 05:47:49.040499
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_colorama_stream
    sys.stderr = wrap_colorama_stream(sys.stderr)

    from contextlib import contextmanager
    from io import StringIO
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    from collections import namedtuple

# Generated at 2022-06-24 05:47:52.297582
# Unit test for function version
def test_version():
    version('thefuck version', 'python version', 'shell info')
    assert sys.stdout.getvalue() == 'The Fuck thefuck version using Python python version and shell info\n'

# Generated at 2022-06-24 05:48:03.378649
# Unit test for function already_configured
def test_already_configured():
    from thefuck.conf import ConfigurationDetails
    from contextlib import contextmanager
    from cStringIO import StringIO

    @contextmanager
    def capture_stdout():
        new_out = StringIO()
        old_out = sys.stdout
        try:
            sys.stdout = new_out
            yield sys.stdout
        finally:
            sys.stdout = old_out

    with capture_stdout() as stdout:
        details = ConfigurationDetails(
            path=u'/path',
            reload=u'false',
            content=u'contents',
            can_configure_automatically=False)
        already_configured(details)


# Generated at 2022-06-24 05:48:07.171878
# Unit test for function failed
def test_failed():
    sys.stderr = sys.__stderr__
    sys.stderr.write = mock.Mock()
    failed(u'Some error')
    sys.stderr.write.assert_called_once_with(u'redSome errorreset\n')



# Generated at 2022-06-24 05:48:14.955776
# Unit test for function show_corrected_command
def test_show_corrected_command():
    f = open('../test_file', 'w')
    corrected_command = mock()
    corrected_command.script = 'test'
    corrected_command.side_effect = False

    show_corrected_command(corrected_command)
    f.close()
    f = open('../test_file', 'r')

    content = '> test\n'
    assert f.read() == content

# Generated at 2022-06-24 05:48:18.501570
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED) == u'\x1b[41m'
    settings.no_colors = True
    assert color(colorama.Back.RED) == u''

# Generated at 2022-06-24 05:48:20.944855
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''



# Generated at 2022-06-24 05:48:23.285062
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('test')
    except Exception:
        rule_failed('test', sys.exc_info())


# Tests for function exception

# Generated at 2022-06-24 05:48:26.357186
# Unit test for function failed
def test_failed():
    try:
        with settings(no_colors=True):
            failed('msg')
            assert False
    except SystemExit:
        assert True



# Generated at 2022-06-24 05:48:28.716197
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-24 05:48:35.417297
# Unit test for function version
def test_version():
    thefuck_version = '0.2'
    python_version = '2.6.1'
    shell_info = 'Bash 4.3.42(1)-release'
    expected = u'The Fuck 0.2 using Python 2.6.1 and Bash 4.3.42(1)-release\n'

    assert version(thefuck_version,python_version,shell_info) == expected

if __name__ == '__main__':
    test_version()

# Generated at 2022-06-24 05:48:39.592382
# Unit test for function confirm_text
def test_confirm_text():
    user_command = 'rm -rf /tmp/test_confirm_text'
    expected = '$ rm -rf /tmp/test_confirm_text [enter/↑/↓/ctrl+c]'
    assert confirm_text(user_command) == expected


# Generated at 2022-06-24 05:48:46.005942
# Unit test for function debug
def test_debug():
    """Just a unit test for function debug()"""
    import StringIO
    test_stream = StringIO.StringIO()
    try:
        settings.debug = True
        settings.no_colors = True
        sys.stderr = test_stream
        debug(u'Testing function debug()')
        assert (test_stream.getvalue() ==
                u'DEBUG: Testing function debug()\n')
    finally:
        settings.debug = False
        settings.no_colors = False
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:48:57.441083
# Unit test for function failed
def test_failed():
    from io import BytesIO
    from . import utils
    from .utils import capture_stderr
    with capture_stderr(BytesIO()) as stderr:
        failed(u'проверка русского текста')

# Generated at 2022-06-24 05:49:08.069585
# Unit test for function debug
def test_debug():
    """We don't want to see debug message in output"""

    from .utils import capture_stderr, popen, putenv
    from .conf import config_loader, settings
    from .how_to import how_to_configure_alias, already_configured
    from . import main
    from .types import CorrectedCommand, ConfigurationDetails

    settings.debug = True

    with (capture_stderr()) as stderr:
        debug('Debug message')
    output = stderr.getvalue()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debug message\n'

    with (capture_stderr()) as stderr:
        main.main(['--debug', 'vim'])
    output = stderr.getvalue()

# Generated at 2022-06-24 05:49:12.418839
# Unit test for function exception
def test_exception():

    class Exc(Exception):
        pass

    try:
        raise Exc('Test')
    except Exc:
        exception(u'Test', sys.exc_info())

if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-24 05:49:15.420927
# Unit test for function color
def test_color():
    assert color("color") == ''
    settings.no_colors = False
    assert color("color") == 'color'
    settings.no_colors = True

# Generated at 2022-06-24 05:49:16.899408
# Unit test for function debug
def test_debug():
    for msg in [u'123', '123', 123]:
        debug(msg)

# Generated at 2022-06-24 05:49:20.999907
# Unit test for function rule_failed
def test_rule_failed():
    exception_message = 'Exception message'
    exc_info = ['Exception type: {}'.format(exception_message)]
    rule = 'Rule name'

    rule_failed(rule, exc_info)

    assert exception_message in sys.stderr.getvalue()


# Generated at 2022-06-24 05:49:29.590526
# Unit test for function version
def test_version():
    from .shells import Shell
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    import sys
    import pytest
    from .version import VERSION

    for shell in [Bash, Zsh]:
        orig = sys.stderr
        sys.stderr = captured_stderr = sys.stdout = StringIO()

        version(VERSION, '3.7.0', shell())
        assert captured_stderr.getvalue().strip() == (
            u'The Fuck {} using Python 3.7.0 and {}'.format(
                VERSION, shell()))
        captured_stderr.close()
        sys.stderr = orig


# Generated at 2022-06-24 05:49:33.184563
# Unit test for function color
def test_color():
    assert '\x1b[30m' == color(colorama.Fore.BLACK)
    assert '' == color(colorama.Fore.BLACK, True)



# Generated at 2022-06-24 05:49:36.360559
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import shells

    result = shells.parse_alias('alias fuck=\'eval $(thefuck $(fc -ln -1))\'')
    configured_successfully(result)

# Generated at 2022-06-24 05:49:42.219239
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('Test'), None)
    exception('Rule test', exc_info)
    assert u'[WARN] Rule test:\nTraceback (most recent call last):\n  File "thefuck/main.py", line 52, in exception\n    trace=\'\'.join(format_exception(*exc_info)))\nException: Test\n' in sys.stderr.getvalue()


# Generated at 2022-06-24 05:49:42.884200
# Unit test for function failed
def test_failed():
    failed('failed')

# Generated at 2022-06-24 05:49:50.802625
# Unit test for function debug_time
def test_debug_time():
    import time
    from contextlib import contextmanager
    from thefuck.utils import wrap_settings

    @contextmanager
    def ignore_except(exc):
        try:
            yield
        except exc:
            pass

    with wrap_settings(debug=True):
        with debug_time('test'):
            time.sleep(0.01)

    with wrap_settings(debug=False):
        with ignore_except(AssertionError):
            with debug_time('test'):
                time.sleep(0.01)

# Generated at 2022-06-24 05:49:53.500915
# Unit test for function debug
def test_debug():
    # pylint: disable=W0612
    settings.debug = True
    debug(u'Debug message')
    settings.debug = False
    debug(u'Debug message')

# Generated at 2022-06-24 05:49:56.033148
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test debug_time'):
        pass

# Generated at 2022-06-24 05:49:58.953951
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'fuck test'
    rule_failed(rule,exc_info='')
    assert rule_failed(rule,exc_info='') != None



# Generated at 2022-06-24 05:50:04.884916
# Unit test for function debug_time
def test_debug_time():
    debug_time_result = []

    @contextmanager
    def fake_debug_time(msg):
        time_object = datetime.now()
        debug_time_result.append(time_object.strftime('%S:%f'))
        yield

    from . import utils
    utils.debug_time = fake_debug_time
    debug_time('test_msg')
    # nanoseconds
    assert debug_time_result[0][-3] == '0'

# Generated at 2022-06-24 05:50:06.148783
# Unit test for function debug
def test_debug():
    import mock
    debug('Testing debug function')



# Generated at 2022-06-24 05:50:09.676491
# Unit test for function rule_failed
def test_rule_failed():
    def test_rule_name():
        class Rule:
            name = 'test_rule'

        rule = Rule()
        rule_failed(rule, None)



# Generated at 2022-06-24 05:50:18.751973
# Unit test for function already_configured
def test_already_configured():
    from unittest.mock import MagicMock
    sys.stdout = MagicMock()
    already_configured(MagicMock())
    sys.stdout.write.assert_called_once_with(
        '\n'.join([
            "Seems like {}fuck{} alias already configured!".format(
                color(colorama.Style.BRIGHT),
                color(colorama.Style.RESET_ALL)),
            "For applying changes run {}reload{} or restart your shell.".format(
                color(colorama.Style.BRIGHT),
                color(colorama.Style.RESET_ALL))
        ]) + '\n'
    )


# Generated at 2022-06-24 05:50:29.969149
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    class settings(object):
        debug = True

    @contextmanager
    def capture_output(stdout=None, stderr=None):
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        if stdout is None:
            stdout = StringIO()
        if stderr is None:
            stderr = StringIO()
        try:
            sys.stdout = stdout
            sys.stderr = stderr
            yield stdout, stderr
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

    with capture_output() as (out, err):
        debug(u'foo\n bar')

# Generated at 2022-06-24 05:50:32.276340
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('message')
        stderr.write.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n')



# Generated at 2022-06-24 05:50:36.620683
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from tests.utils import support_debug
    with support_debug():
        out = StringIO()
        sys.stderr = out
        debug(u'Привет, Мир!')
        assert u'Привет, Мир!\n' in out.getvalue()



# Generated at 2022-06-24 05:50:44.901349
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    how_to_configure_alias(None)
    out = StringIO.StringIO()
    sys.stdout = out
    how_to_configure_alias(None)
    configuration_details = const.ConfigurationDetails({
        'path': 'example_path',
        'content': 'example_content',
        'reload': 'example_reload',
    })

# Generated at 2022-06-24 05:50:48.895168
# Unit test for function rule_failed
def test_rule_failed():
    try:
        import datetime
        i = datetime.date(2017, 2, 13)
    except Exception as e:
        rule_failed(None, sys.exc_info())
        assert True
    assert True


# Generated at 2022-06-24 05:50:50.698407
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_configuration_details
    from .shells import ShellType
    for st in ShellType:
        conf = get_configuration_details(st)
        how_to_configure_alias(conf)

# Generated at 2022-06-24 05:50:56.905177
# Unit test for function debug
def test_debug():
    import StringIO
    from contextlib import closing
    with closing(StringIO.StringIO()) as fake_stderr:
        with closing(sys.stderr):
            sys.stderr = fake_stderr
            debug('test')
            assert fake_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-24 05:51:04.128620
# Unit test for function confirm_text
def test_confirm_text():
    from collections import namedtuple
    from cStringIO import StringIO
    from .utils import get_closest
    CorrectedCommand = namedtuple('CorrectedCommand',
                                  ['script', 'side_effect'])

# Generated at 2022-06-24 05:51:10.495769
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    errors = io.StringIO()
    sys.stderr = errors
    corrected_command = 'echo "hello world "; echo "bye" '
    show_corrected_command(corrected_command)
    expected_message = const.USER_COMMAND_MARK + corrected_command + '\n'
    assert errors.getvalue() == expected_message
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:51:14.605318
# Unit test for function debug
def test_debug():
    import mock

    settings.debug = True
    with mock.patch('sys.stderr') as stderr:
        debug('Hello!')
        stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello!\n')



# Generated at 2022-06-24 05:51:25.798487
# Unit test for function debug
def test_debug():
    from unittest import TestCase
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class DebugTest(TestCase):
        def test_debug(self):
            with captured_output() as (out, err):
                debug('debug msg')
            self.assertNotIn('debug msg', out.getvalue())

# Generated at 2022-06-24 05:51:27.817865
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    show_corrected_command(CorrectedCommand('git push heroku master', True))

# Generated at 2022-06-24 05:51:29.887283
# Unit test for function exception
def test_exception():
    # Fails if this method returns any value
    try:
        raise Exception('Exception!')
    except Exception:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-24 05:51:32.105497
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    assert color(u'foo') != u'bar'



# Generated at 2022-06-24 05:51:34.203785
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(const.ConfigurationDetails('', '', '', '', '')) == None


# Generated at 2022-06-24 05:51:38.590554
# Unit test for function debug_time
def test_debug_time():
    from mock import MagicMock
    settings.debug = True
    with debug_time('MyTest'):
        pass
    settings.debug = False


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-24 05:51:42.326558
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(u'Testing how_to_configure_alias')
    from .utils.module_builder import module_builder
    with module_builder.build() as mock_module:
        how_to_configure_alias(mock_module)
    print(u'all is well: how_to_configure_alias')

# Generated at 2022-06-24 05:51:48.219637
# Unit test for function failed
def test_failed():
    import StringIO
    try:
        stdout = sys.stdout
        stderr = sys.stderr
        sys.stdout = StringIO.StringIO()
        sys.stderr = StringIO.StringIO()
        failed(u'Error')
        assert sys.stderr.getvalue() == u'Error\n'
    finally:
        sys.stdout = stdout
        sys.stderr = stderr

# Generated at 2022-06-24 05:51:58.534248
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Correction
    from .rules import Command

    correction = Correction(
        corrected_script=u'ls',
        script=u'ls',
        stderr=None,
        stdout=u'',
        loop_breaker=False,
        side_effect=False)

    show_corrected_command(correction)

    correction = Correction(
        corrected_script=u'ls',
        script=u'ls',
        stderr=None,
        stdout=u'',
        loop_breaker=False,
        side_effect=True)

    show_corrected_command(correction)


# Generated at 2022-06-24 05:51:59.754840
# Unit test for function debug_time
def test_debug_time():
    # Make sure that the code actually works
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:52:02.273221
# Unit test for function show_corrected_command
def test_show_corrected_command():
    script = 'git log'
    assert show_corrected_command(script) == 'git log'



# Generated at 2022-06-24 05:52:04.089579
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('', (), {'script': 'echo "foo"', 'side_effect': False})()
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:52:06.717444
# Unit test for function exception
def test_exception():
    try:
        raise ValueError("foo")
    except (ValueError):
        exception("test", sys.exc_info())


# Generated at 2022-06-24 05:52:08.290414
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('test'), None)
    assert exception('test', exc_info) == "test"

# Generated at 2022-06-24 05:52:12.606218
# Unit test for function version
def test_version():
    thefuck_version = '1.0'
    python_version = '2.7'
    shell_info = 'fish, zsh'
    version(thefuck_version, python_version, shell_info)
    assert sys.stderr.getvalue() == 'The Fuck 1.0 using Python 2.7 and fish, zsh\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:52:20.758701
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .command import Command
    from .rules import get_rules

    settings.require_confirmation = True
    settings.no_colors = False
    settings.exclude_rules = []
    settings.priority = []
    settings.history_limit = None
    settings.wait_command = 3
    settings.debug = False

    rule = get_rules()[0]
    command = Command('pwd', '', '')
    corrected_command = rule.get_new_command(command)
    confirm_text(corrected_command)

    settings.no_colors = True
    confirm_text(corrected_command)



# Generated at 2022-06-24 05:52:27.217311
# Unit test for function version
def test_version():
    import os
    import platform
    import sys

    sys.argv = ['thefuck']
    from . import __version__
    from . import version

    thefuck_version = __version__
    python_version = '{} {}'.format(
        platform.python_implementation(),
        platform.python_version())
    shell_info = '{} {}'.format(platform.system(), os.environ.get('SHELL'))
    assert version(thefuck_version, python_version, shell_info) is None

# Generated at 2022-06-24 05:52:30.215193
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully({'reload': '~/.bashrc'}) == \
    'fuck alias configured successfully!\nFor applying changes run ~/.bashrc or restart your shell.'


# Generated at 2022-06-24 05:52:32.669944
# Unit test for function confirm_text
def test_confirm_text():
    assert """~~~ fuck a +b [enter/↑/↓/ctrl+c]""" == confirm_text((
        u'fuck', u'a +b', False))

# Generated at 2022-06-24 05:52:33.919372
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(1)

# Generated at 2022-06-24 05:52:38.179318
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    cmd = Command('ls', 'ls --color=auto')
    show_corrected_command(cmd)


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-24 05:52:41.540613
# Unit test for function configured_successfully
def test_configured_successfully():
    from .utils import _get_version
    from .utils import get_shell_info
    assert configured_successfully(_get_version(),
                                   u'{}'.format(sys.version),
                                   get_shell_info()) == None

# Generated at 2022-06-24 05:52:43.353009
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ''))
