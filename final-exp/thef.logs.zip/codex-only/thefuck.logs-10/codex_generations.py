

# Generated at 2022-06-24 05:42:44.165877
# Unit test for function debug
def test_debug():
    with debug_time('oo'):
        debug(u'aaa')
        raise ValueError()

# Generated at 2022-06-24 05:42:46.765875
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(const.Rule.from_type(const.RuleType.match, "test-rule", "", "", "", "", "", ""), (Exception, Exception("Test message"), "Test trace"))

# Generated at 2022-06-24 05:42:48.931896
# Unit test for function failed
def test_failed():
    for msg in ['correct message', u'correct message',
                'correct message\nsecond line\n', u'correct message\nsecond line\n']:
        yield check, msg



# Generated at 2022-06-24 05:42:49.806840
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-24 05:42:52.373473
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('') == ''

# Generated at 2022-06-24 05:42:57.999370
# Unit test for function confirm_text
def test_confirm_text():
    """
    Testing of confirm_text function
    """
    class Cmd:
        def __init__(self):
            self.script = 'echo script'
            self.side_effect = False

    corrected_command = Cmd()
    confirm_text(corrected_command)
    corrected_command.side_effect = True
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:43:00.011701
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    # i can't test it, because termios don't support emulation input
    # and i don't want to write monkey-patching
    pass

# Generated at 2022-06-24 05:43:01.368811
# Unit test for function failed
def test_failed():
    failed('fuck')
    assert sys.stderr.getvalue() == u'\x1b[31mfuck\x1b[0m\n'

# Generated at 2022-06-24 05:43:04.064278
# Unit test for function exception
def test_exception():
    try:
        raise NameError('test')
    except NameError:
        exc_info = sys.exc_info()
    exception('test', exc_info)

# Generated at 2022-06-24 05:43:07.641139
# Unit test for function color
def test_color():
    colorama.init()
    settings.no_colors = False
    assert color(colorama.Fore.RED + 'red') == colorama.Fore.RED + 'red'

    settings.no_colors = True
    assert color(colorama.Fore.RED + 'red') == ''

# Generated at 2022-06-24 05:43:09.883280
# Unit test for function color
def test_color():
    assert color('bold') == 'bold'
    settings.no_colors = True
    assert color('bold') == ''



# Generated at 2022-06-24 05:43:12.638398
# Unit test for function version
def test_version():
    assert u'The Fuck 3.9 using Python 3.5.2\n' in \
        version('3.9', '3.5.2', 'ShellInfo(bash, 4.3.11, /bin/bash)')



# Generated at 2022-06-24 05:43:23.483194
# Unit test for function confirm_text
def test_confirm_text():
    from sys import stdout
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = stdout, sys.stderr
        try:
            stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            stdout, sys.stderr = old_out, old_err

    # Unit test case 1: disable colored output
    settings.no_colors = True
    with captured_output() as (out, err):
        confirm_text("corrected_command")
        test_result = out.getvalue()

# Generated at 2022-06-24 05:43:32.223696
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    import sys
    import colorama
    out = StringIO()
    err = StringIO()
    sys.stdout = out
    sys.stderr = err
    warn(u"test")
    out.close()
    err.close()
    assert err.getvalue().strip() == colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT + u'[WARN] test' + colorama.Style.RESET_ALL
    assert out.getvalue().strip() == u''
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:43:33.713201
# Unit test for function debug
def test_debug():
    sys.stderr.write(u'')
    debug(u'42')

# Generated at 2022-06-24 05:43:34.852289
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert '$ abc' == show_corrected_command('abc')

# Generated at 2022-06-24 05:43:36.328146
# Unit test for function debug
def test_debug():
    assert u'DEBUG: test' in debug(u'test')


# Generated at 2022-06-24 05:43:47.859214
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = lambda x: None
    import subprocess
    import tempfile
    from .conf import Command
    p = subprocess.Popen('echo -n', shell=True,
                         stdin=subprocess.PIPE, stdout=tempfile.TemporaryFile())
    with tempfile.NamedTemporaryFile() as output:
        Command('echo "test"', 'echo "test"', 0, '/tmp', output).script
        show_corrected_command(Command('echo "test"', 'echo "test"', 0, '/tmp', output))
        output.seek(0)
        assert output.read() == '!\x1b[1K\r\x1b[1mecho "test"\x1b[0m'

# Generated at 2022-06-24 05:43:49.678453
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        t = datetime.now()
        t += 1

# Generated at 2022-06-24 05:44:01.186103
# Unit test for function color
def test_color():
    assert color('black') == '\x1b[30m'
    assert color('gray') == '\x1b[30m'
    assert color('red') == '\x1b[31m'
    assert color('green') == '\x1b[32m'
    assert color('yellow') == '\x1b[33m'
    assert color('blue') == '\x1b[34m'
    assert color('magenta') == '\x1b[35m'
    assert color('cyan') == '\x1b[36m'
    assert color('white') == '\x1b[37m'
    assert color('bg black') == '\x1b[40m'
    assert color('bg red') == '\x1b[41m'

# Generated at 2022-06-24 05:44:01.960160
# Unit test for function debug
def test_debug():
    assert debug('test')



# Generated at 2022-06-24 05:44:04.765677
# Unit test for function show_corrected_command
def test_show_corrected_command():
    colorama.init()
    show_corrected_command(const.CorrectedCommand(script='test.sh', side_effect=True))
    colorama.deinit()
    show_corrected_command(const.CorrectedCommand(script='test.sh', side_effect=False))

# Generated at 2022-06-24 05:44:06.073269
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'git push'
    confirm_text(corrected_command)


# Generated at 2022-06-24 05:44:11.488769
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """ Testcase to demonstrate the corrected_command is being printed"""
    sys.stderr = open('/dev/null', 'w')
    show_corrected_command(corrected_command="uptime")
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:44:14.161881
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_print_debug'):
        print('test')


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-24 05:44:16.921364
# Unit test for function exception
def test_exception():
    def test_rule(argument):
        raise RuntimeError('Fuck!')

    try:
        test_rule(42)
    except Exception:
        exception('Exception in rule', sys.exc_info())

# Generated at 2022-06-24 05:44:25.166351
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    config_details1 = {'content': '*************',
                     'path': '~/.bashrc',
                     'reload': 'source ~/.bashrc',
                     'can_configure_automatically': True
                    }
    config_details2 = {'content': '*************',
                     'path': '~/.bashrc',
                     'reload': 'source ~/.bashrc',
                     'can_configure_automatically': False
                    }
    how_to_configure_alias(config_details1)
    how_to_configure_alias(config_details2)
    how_to_configure_alias(None)


# Generated at 2022-06-24 05:44:27.688468
# Unit test for function exception
def test_exception():
    test_message = "test"
    try:
        raise Exception
    except Exception:
        exception(test_message, sys.exc_info())


# Generated at 2022-06-24 05:44:33.604887
# Unit test for function version
def test_version():
    thefuck_version = 'thefuck_version'
    python_version = 'python_version'
    shell_info = 'shell_info'
    expected = u'The Fuck ' + thefuck_version + \
        ' using Python ' + python_version + ' and ' + shell_info + '\n'
    assert version(thefuck_version, python_version, shell_info) == expected

# Generated at 2022-06-24 05:44:40.730254
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    _content = 'content'
    _path = 'path'
    _reload = 'reload'

    configuration_details = type(
        'ConfigurationDetails', (object,),
        {'content': _content, 'path': _path, 'reload': _reload})

    def test_(can_configure_automatically):
        original_stdout = sys.stdout
        sys.stdout = open('/dev/null', 'w')

        try:
            configuration_details.can_configure_automatically = can_configure_automatically
            how_to_configure_alias(configuration_details)
        finally:
            sys.stdout.close()
            sys.stdout = original_stdout

    test_(False)

# Generated at 2022-06-24 05:44:49.406444
# Unit test for function exception
def test_exception():
    import sys
    exc_info = (Exception, Exception('test'), None)
    msg = 'Test'
    try:
        raise Exception('test')
    except:
        exception(msg, sys.exc_info())
        sys.stderr.seek(0)
        assert sys.stderr.read().endswith(u'[WARN] Test:\nTraceback (most recent call last):\n  File "{path}", line XXX, in exception\n   Exception: test\n\n'.format(path=__file__))
        sys.stderr.truncate(0)
    return msg

# Generated at 2022-06-24 05:44:53.552868
# Unit test for function version
def test_version():
    from StringIO import StringIO
    from thefuck.main import get_versions
    with StringIO() as stream:
        sys.stderr = stream
        version(*get_versions())
        assert stream.getvalue() == u'The Fuck 3.6 using Python 2.7.10 and sh\n'

# Generated at 2022-06-24 05:45:01.185789
# Unit test for function configured_successfully
def test_configured_successfully():
    import re
    import subprocess
    # Get the version of python
    python_version = subprocess.check_output("python --version", shell=True)
    # Get the version of thefuck
    thefuck_version = subprocess.check_output("thefuck --version", shell=True)
    # Get the shell
    shell_info = subprocess.check_output("ps h -o comm -p $PPID", shell=True)
    config_msg = configured_successfully("''")
    regex_ver = re.compile('The Fuck {} using Python {} and {}'.format(
        thefuck_version, python_version, shell_info
    ))
    assert regex_ver.match(config_msg, re.MULTILINE | re.DOTALL)
    pass

# Generated at 2022-06-24 05:45:07.383809
# Unit test for function rule_failed
def test_rule_failed():
    with open('rule_failed_test.txt', 'w') as f:
        try:
            raise Exception('test')
        except:
            rule_failed(None, sys.exc_info())
        assert f.read() == '[WARN] Rule None:Traceback (most recent call last):\n  File "C:\\Users\\K\\Documents\\GitHub\\thefuck\\tests\\utils_test.py", line 110, in test_rule_failed\n    raise Exception(\'test\')\nException: test\n\n[WARN] ----------------------------\n\n'

# Generated at 2022-06-24 05:45:12.756787
# Unit test for function show_corrected_command
def test_show_corrected_command():
    old_stdout = sys.stdout
    import StringIO

    sys.stdout = mystdout = StringIO.StringIO()
    show_corrected_command(const.Command('ls', True))
    sys.stdout = old_stdout
    assert mystdout.getvalue() == '{}ls (+side effect)\\n'.format(
        const.USER_COMMAND_MARK)

# Generated at 2022-06-24 05:45:14.517404
# Unit test for function exception
def test_exception():
    try:
        raise Exception("Hello")
    except Exception:
        exception("Name", sys.exc_info())

# Generated at 2022-06-24 05:45:18.530849
# Unit test for function failed
def test_failed():
    from io import BytesIO
    from contextlib import contextmanager

    @contextmanager
    def get_stderr():
        old_stderr = sys.stderr
        sys.stderr = BytesIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old_stderr
    # End of test_failed



# Generated at 2022-06-24 05:45:19.129448
# Unit test for function configured_successfully
def test_configured_successfully():
    print('123')

# Generated at 2022-06-24 05:45:27.537266
# Unit test for function version
def test_version():
    from . import version
    from mock import patch
    with patch.object(version, 'python_version', '2.7.8'):
        with patch.object(version, '__version__', '1.2.3'):
            assert version.version('bash') == \
                   u'The Fuck 1.2.3 using Python 2.7.8 and bash\n'
            assert version.version('zsh') == \
                   u'The Fuck 1.2.3 using Python 2.7.8 and zsh\n'



# Generated at 2022-06-24 05:45:33.930976
# Unit test for function confirm_text
def test_confirm_text():
    """
    >>>confirm_text('root/home/user/a.py')
    const.USER_COMMAND_MARK + 'root/home/user/a.py' + ' [' +
    '\x1b[1K\r\x1b[1m\x1b[37m' + 'root/home/user/a.py' + '\x1b[0m' + ']'
    """



# Generated at 2022-06-24 05:45:35.686451
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('''
The Fuck 3.23 using Python 2.7.11 and Bash 4.3.30
''')


# Generated at 2022-06-24 05:45:46.120321
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (), {
        'script': 'echo hello world',
        'side_effect': False
    })
    assert confirm_text(corrected_command) == 'Fuck>'\
                                              '\033[1K\r' \
                                              '\033[1m' \
                                              'echo hello world' \
                                              '\033[0m' \
                                              ' [\033[32menter\033[0m/' \
                                              '\033[34m↑\033[0m' \
                                              '/\033[34m↓\033[0m/' \
                                              '\033[31mctrl+c\033[0m]'

# Generated at 2022-06-24 05:45:54.874946
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys

# Generated at 2022-06-24 05:46:06.209111
# Unit test for function already_configured
def test_already_configured():
    settings.use_colors = False
    expected = u"Seems like fuck alias already configured!\nFor applying changes run reload or restart your shell."
    assert already_configured(const.ConfigurationDetails(
        reload='reload',
        path='',
        content='')) == expected
    assert already_configured(const.ConfigurationDetails(
        reload='reload',
        path='',
        content='',
        can_configure_automatically=True)) == expected
    settings.use_colors = True
    expected = 'Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[21m or restart your shell.'

# Generated at 2022-06-24 05:46:08.565072
# Unit test for function version
def test_version():
    version('1.1.1', '2.7', 'bash 3.2')



# Generated at 2022-06-24 05:46:13.516287
# Unit test for function version
def test_version():
    import tempfile
    import io
    import sys
    out = io.StringIO()
    sys.stderr = out
    version('1.0', '2.7.9', 'Bash')
    output = out.getvalue().strip()
    assert output == u'The Fuck 1.0 using Python 2.7.9 and Bash'

# Generated at 2022-06-24 05:46:15.299344
# Unit test for function debug_time
def test_debug_time():
    def foo():
        with debug_time('foo_msg'):
            import time
            time.sleep(1)
    foo()

# Generated at 2022-06-24 05:46:17.445372
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test error')
    except:
        exception('', sys.exc_info())

# Generated at 2022-06-24 05:46:21.229110
# Unit test for function already_configured
def test_already_configured():
    configuration_details = const.ConfigurationDetails(
        path='.bashrc',
        reload='source .bashrc',
        content='eval $(thefuck --alias)',
        can_configure_automatically=True)
    already_configured(configuration_details)



# Generated at 2022-06-24 05:46:23.826445
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with colorama.init():
        show_corrected_command(corrected_command=const.CorrectedCommand(
            script=u'test', side_effect=False))

# Generated at 2022-06-24 05:46:26.998081
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'pip install'
    show_corrected_command(corrected_command)
    assert const.USER_COMMAND_MARK + corrected_command + '\n' == sys.stderr.getvalue()

# Generated at 2022-06-24 05:46:27.611535
# Unit test for function configured_successfully
def test_configured_successfully():
    assert '' == ''

# Generated at 2022-06-24 05:46:30.933807
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:46:37.746265
# Unit test for function debug
def test_debug():
    # Check old debug behaviour (without colors)
    settings.debug = True
    try:
        captured_output = _capture_output(debug, 'test message')
        assert 'DEBUG' in captured_output
    finally:
        settings.debug = False

    # Check new debug behaviour with colors
    settings.debug = True
    try:
        captured_output = _capture_output(debug, 'test message')
        assert '\x1b[34;1mDEBUG' in captured_output
    finally:
        settings.debug = False
        sys.stdout.write('\x1b[0m')



# Generated at 2022-06-24 05:46:38.827614
# Unit test for function version
def test_version():
    assert version('3.3', 'Python 3.3.3', 'bash 3.3') == None


# Generated at 2022-06-24 05:46:40.208693
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('fuck') == 'fuck'

# Generated at 2022-06-24 05:46:46.745065
# Unit test for function rule_failed
def test_rule_failed():
    rule = "rule"
    exc_info = "exception info"
    import sys
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    expected_output = u'[WARN] Rule rule:\nexception info----'
    rule_failed(rule, exc_info)
    sys.stderr = sys.__stderr__
    assert out.getvalue() == expected_output, "Expected output " + expected_output + " but got " + out.getvalue()

# Generated at 2022-06-24 05:46:55.994722
# Unit test for function exception
def test_exception():
    title = u'Title'
    err = Exception(u'err')
    exc_info = (type(err), err, None)

    exception(title, exc_info)

    assert sys.stderr.getvalue() == (u'{warn}[WARN] {title}:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title=title,
            trace=''.join(format_exception(*exc_info))))

# Generated at 2022-06-24 05:46:57.383768
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert 'git\n' == show_corrected_command()

# Generated at 2022-06-24 05:47:03.722433
# Unit test for function confirm_text
def test_confirm_text():
    from tempfile import NamedTemporaryFile
    from os import read, dup, dup2
    

    sys.stderr = NamedTemporaryFile()
    confirm_text()
    sys.stderr.seek(0)
    result = sys.stderr.readlines()
    sys.stderr.seek(0)
    sys.stderr.truncate()
    sys.stderr = sys.__stderr__
    assert result == '\033[1K\r' + const.USER_COMMAND_MARK + '[enter/↑/↓/ctrl+c] '

# Generated at 2022-06-24 05:47:12.831011
# Unit test for function failed
def test_failed():
    import click.testing as click_testing
    runner = click_testing.CliRunner()

    def run():
        import sys
        import io
        import click.testing as click_testing
        sys.stderr = io.BytesIO()
        runner = click_testing.CliRunner()
        try:
            from .main import main
            runner.invoke(main, ['fail'])
            sys.stderr.seek(0)
            assert 'Command "fail" failed' in sys.stderr.read()
        finally:
            sys.stderr = sys.__stderr__
    run()
    run()



# Generated at 2022-06-24 05:47:14.072039
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('aaa', 'bbb', 'ccc')
    pass

# Generated at 2022-06-24 05:47:16.641027
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', None, None, None))
    show_corrected_command(CorrectedCommand('ls', None, None, '-l'))

# Generated at 2022-06-24 05:47:18.929909
# Unit test for function version
def test_version():
    v = version('3.2', '2.7', 'Zsh 5.0.2')



# Generated at 2022-06-24 05:47:19.824133
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
   how_to_configure_alias()


# Generated at 2022-06-24 05:47:24.998421
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # storing the stdout for comparison
    stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    how_to_configure_alias(('. {path}', '. {reload}', '{content}', True))
    sys.stdout = stdout



# Generated at 2022-06-24 05:47:26.521262
# Unit test for function rule_failed
def test_rule_failed():
    def test_func(x, y):
        return x+y
    test_func(2, 'a')

# Generated at 2022-06-24 05:47:29.677517
# Unit test for function color
def test_color():
    assert color('uncolored') == 'uncolored'
    assert color('colored') == ''


# Generated at 2022-06-24 05:47:31.444359
# Unit test for function version
def test_version():
    assert version('1.1.1', '2.7', 'Bourne Again Shell') \
        == u'The Fuck 1.1.1 using Python 2.7 and Bourne Again Shell\n'

# Generated at 2022-06-24 05:47:33.364823
# Unit test for function color
def test_color():
    assert color(u'\x1b[1m') == u'\x1b[1m'
    settings.no_colors = True
    assert color(u'\x1b[1m') == ''

# Generated at 2022-06-24 05:47:34.840732
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rule import CorrectedCommand

    show_corrected_command(CorrectedCommand('echo "fuck"', side_effect=True))
    assert u'fuck "echo" "fuck"' == sys.stderr.getvalue()

# Generated at 2022-06-24 05:47:38.620315
# Unit test for function already_configured
def test_already_configured():
    sys.argv = ['thefuck', '--alias']
    configuration_details = settings._not_configured_alias()
    already_configured(configuration_details)


# Generated at 2022-06-24 05:47:45.990302
# Unit test for function version
def test_version():
    thefuck_version = '3.13'
    python_version = '2.7'
    shell_info = 'fish'
    expected = u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                              python_version,
                                                              shell_info)
    sys.stderr = fake_std_err = StringIO()
    version(thefuck_version, python_version, shell_info)
    assert fake_std_err.getvalue() == expected
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:47:48.245875
# Unit test for function color
def test_color():
    assert color('red text') == '\x1b[31mred text\x1b[0m'
    settings.no_colors = True
    assert color('red text') == ''



# Generated at 2022-06-24 05:47:59.349625
# Unit test for function show_corrected_command
def test_show_corrected_command():
    output = []
    sys.stderr = output

    r = lambda x: x
    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'hey',
        'side_effect': False
    })
    show_corrected_command(corrected_command)
    assert "hey" == output[0].split(const.USER_COMMAND_MARK)[1].strip('\n')

    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'hey',
        'side_effect': True
    })
    show_corrected_command(corrected_command)
    assert "hey (+side effect)" == \
        output[1].split(const.USER_COMMAND_MARK)[1].strip('\n')



# Generated at 2022-06-24 05:48:03.836605
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = sys.stderr.write
    corrected_command = type(
        'corrected_command', (object,), {'script': 'foo', 'side_effect': False})
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:48:05.380515
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert(how_to_configure_alias(None) == None)

# Generated at 2022-06-24 05:48:08.092802
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correction import CorrectedCommand
    corrected_command = CorrectedCommand('test', 'Test corrected command')
    show_corrected_command(corrected_command)
    assert corrected_command.script == 'Test corrected command'

# Generated at 2022-06-24 05:48:12.670948
# Unit test for function debug
def test_debug():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    debug("hi")

    assert out.getvalue().endswith("DEBUG: hi\n")

# Generated at 2022-06-24 05:48:14.672949
# Unit test for function debug
def test_debug():
    with settings(debug=True):
        debug('This is some debug message')



# Generated at 2022-06-24 05:48:19.466709
# Unit test for function warn
def test_warn():
    import StringIO
    sys.stderr = StringIO.StringIO()
    warn(u"test")
    output = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    assert output == "[WARN] test\n"

# Generated at 2022-06-24 05:48:23.894783
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from thefuck.types import Command
    output = io.StringIO()
    sys.stderr = output
    confirm_text(Command('ls', 3, '', ''))
    assert(output.getvalue() == '$ ls [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-24 05:48:29.336738
# Unit test for function warn
def test_warn():
    warn('foo')
    assert sys.stderr.getvalue() == '\x1b[41m\x1b[37m\x1b[1m[WARN] foo\x1b[0m\n'
    sys.stderr.truncate(0)



# Generated at 2022-06-24 05:48:30.822553
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('test') == u'TF>test'

# Generated at 2022-06-24 05:48:31.851551
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('message').__enter__() is None

# Generated at 2022-06-24 05:48:42.265658
# Unit test for function already_configured
def test_already_configured():
    from pyfakefs import fake_filesystem_unittest
    from thefuck.utils import already_configured
    from thefuck.utils import CheckConfig

    class TestConfig(CheckConfig):
        def _from_shell(self, shell_name):
            return self

        def _get_reload(self):
            return 'reload'

    class TestMain(fake_filesystem_unittest.TestCase):
        def setUp(self):
            self.setUpPyfakefs()

        def test_already_configured_called(self):
            # check that function works
            self.fs.CreateFile('.thefuckrc')
            self.assertIsNone(already_configured(TestConfig()))

    TestMain().test_already_configured_called()



# Generated at 2022-06-24 05:48:45.367041
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    try:
        old_command = 'echo "hello"'
        get_new_command(old_command)
    except Exception:
        exception('Rule match', sys.exc_info())

# Generated at 2022-06-24 05:48:51.994767
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stderr.write(u'Seems like {bold}fuck{reset} alias isn\'t configured!\n'.format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL)))
    sys.stderr.write(u'Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.\n'.format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), content=u'eval "$(thefuck --alias)"', path=u'~/.andrey/config/fish/config.fish', reload=u'fish'))

# Generated at 2022-06-24 05:49:03.567197
# Unit test for function configured_successfully
def test_configured_successfully():
    assert u'fuck alias configured successfully!\n' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'source' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'!' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'or restart your shell' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'shell' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'fuck' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'alias' in configured_successfully(
        {'reload':'source ~/.bashrc'})
    assert u'For applying changes run'

# Generated at 2022-06-24 05:49:04.265329
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details = None)

# Generated at 2022-06-24 05:49:09.265435
# Unit test for function confirm_text
def test_confirm_text():
    from colorama import Fore
    assert confirm_text('ls') == u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(prefix=const.USER_COMMAND_MARK, green=Fore.GREEN, reset=Fore.RESET, blue=Fore.BLUE, red=Fore.RED)

# Generated at 2022-06-24 05:49:11.368412
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception(u'Error', sys.exc_info())

# Generated at 2022-06-24 05:49:13.471843
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        import time
        time.sleep(1)

# Generated at 2022-06-24 05:49:14.616333
# Unit test for function already_configured
def test_already_configured():
    already_configured("reload")

# Generated at 2022-06-24 05:49:16.082329
# Unit test for function version
def test_version():
    version('The Fuck', 'Python', 'Shell')



# Generated at 2022-06-24 05:49:17.186279
# Unit test for function already_configured
def test_already_configured():
    already_configured()


# Generated at 2022-06-24 05:49:20.451325
# Unit test for function rule_failed
def test_rule_failed():
    class MockRule(object):
        def __init__(self, name):
            self.name = name

    rule_failed(MockRule('mock_rule_name'), [Exception('test message')])



# Generated at 2022-06-24 05:49:22.538071
# Unit test for function color
def test_color():
    assert color('bold') == 'bold'
    settings.no_colors = True
    assert color('bold') == ''

# Generated at 2022-06-24 05:49:24.698458
# Unit test for function debug_time
def test_debug_time():
    assert not settings.debug
    with debug_time('test'):
        assert True
        raise Exception()
    assert not settings.debug

# Generated at 2022-06-24 05:49:27.155545
# Unit test for function failed
def test_failed():
    failed(u'Text')
    assert sys.stderr.getvalue() == u'\x1b[31mText\x1b[0m\n'

# Generated at 2022-06-24 05:49:29.387482
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("successfully")
    configured_successfully("")
    configured_successfully("hello")

if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-24 05:49:31.026009
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('fuck')


# Generated at 2022-06-24 05:49:39.257410
# Unit test for function debug
def test_debug():
    import mock
    import thefuck.utils as utils
    from thefuck.utils import DEBUG_LOG

    mock_stdout = mock.Mock()

    with mock.patch.dict('sys.modules', {'__main__': mock.Mock(__file__='/fuck.py')}):
        utils.debug('msg')

    mock_stdout.assert_has_calls([
        mock.call.write(DEBUG_LOG),
        mock.call.write('msg\n'),
        mock.call.write('\n')])



# Generated at 2022-06-24 05:49:45.356376
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval "$(thefuck --alias fuck)"',
        can_configure_automatically=True,
        reload='. ~/.bashrc')) == (
    print(u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}. ~/.bashrc{reset} or restart your shell.".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        reload='. ~/.bashrc')))



# Generated at 2022-06-24 05:49:49.448216
# Unit test for function version
def test_version():
    assert version('1.2', '2.7', 'ZSH') == None
    # assert version('1.2', '2.7', 'ZSH') == u'The Fuck 1.2 using Python 2.7 and ZSH\n'


# Generated at 2022-06-24 05:49:50.899674
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-24 05:49:52.122044
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=None)
    import pytest

# Generated at 2022-06-24 05:49:54.365792
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "thefuck -h"
    show_corrected_command(corrected_command)



# Generated at 2022-06-24 05:50:00.842318
# Unit test for function configured_successfully
def test_configured_successfully():
    config = u'thefuck'
    my_detail = {'type':'start of comment', 'configuration':config}
    my_configuration_details = settings.ConfigurationDetails(
        **my_detail)
    configured_successfully(my_configuration_details)


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-24 05:50:05.327343
# Unit test for function failed
def test_failed():
    from .conf import settings
    settings.no_colors = False
    assert failed(u'foo') == color(colorama.Fore.RED) + u'foo' + color(colorama.Style.RESET_ALL) + u'\n'
    settings.no_colors = True
    assert failed(u'foo') == u'foo\n'


# Generated at 2022-06-24 05:50:07.003283
# Unit test for function warn
def test_warn():
    sys.stderr.write = lambda s: None
    warn(u'Привет, мир!')



# Generated at 2022-06-24 05:50:12.412952
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .models import CorrectedCommand
    corrected_command = CorrectedCommand('ls', 'ls -a')
    show_corrected_command(corrected_command)
    corrected_command = CorrectedCommand('ls', 'ls -a', None, True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:50:14.495252
# Unit test for function failed
def test_failed():
    failed("Debug")
    failed("Warning")
    failed("Failed")
    failed("Success")

# Generated at 2022-06-24 05:50:20.252868
# Unit test for function debug
def test_debug():
    """
    Test that debug function writes string starting
    with "DEBUG:" if debug flag is true.
    """
    msg = 'test'
    settings.debug = True
    old_stderr = sys.stderr
    from StringIO import StringIO
    sys.stderr = StringIO()
    debug(msg)
    sys.stderr.seek(0)
    debug_string = sys.stderr.read()
    assert debug_string.startswith('DEBUG:')
    sys.stderr = old_stderr

# Generated at 2022-06-24 05:50:29.600655
# Unit test for function debug
def test_debug():
    from .application import Application
    """
    >>> from thefuck.shells import Shell, Variable

    >>> class Env:
    ...    def __init__(self, **kwargs):
    ...        self.__dict__.update(kwargs)
    ...    def get(self, name, default=''):
    ...         try:
    ...             return self.__dict__[name]
    ...         except KeyError:
    ...             return default

    >>> env = Env()

    >>> application = Application(Shell('non-interactive'), env)
    >>> application.settings.no_colors = False
    >>> application.settings.debug = True
    >>> debug('test_debug')
    DEBUG: test_debug
    """

# Generated at 2022-06-24 05:50:30.418606
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:50:31.956359
# Unit test for function version
def test_version():
    version('thefuck_version', 'python_version', 'shell_info')



# Generated at 2022-06-24 05:50:35.403280
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.shells import (bash, zsh, fish)

    # TODO: find better way to test this function
    with debug_time('test rule_failed'):
        rule_failed(bash.BashRule(settings), sys.exc_info())

# Generated at 2022-06-24 05:50:36.842279
# Unit test for function debug
def test_debug():
    """Test function output."""
    debug('hello')



# Generated at 2022-06-24 05:50:40.979403
# Unit test for function confirm_text
def test_confirm_text():
    import re
    confirm_text('confirm_text')
    res = re.search(r'\d+.*?confirm_text.*?\[.*?\].*',
                    sys.stderr.getvalue().strip(), re.S)
    assert res is not None, 'confirm_text() is not work.'



# Generated at 2022-06-24 05:50:44.931385
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = (
        '{bold}~/.aliases{reset}\n'
        'alias {bold}fuck{reset}='
        '"eval $(thefuck $(fc -ln -1)); fc -R"\n\n'
        'And run {bold}source ~/.aliases{reset} or restart your shell.'
    )

    how_to_configure_alias(
        ''
    )



# Generated at 2022-06-24 05:50:48.072722
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == ''
    settings.no_colors = False
    assert color(colorama.Fore.GREEN) == '\x1b[32m'

# Generated at 2022-06-24 05:50:49.506992
# Unit test for function already_configured
def test_already_configured():
    assert 'Seems like fuck alias already configured!' in already_configured('source')



# Generated at 2022-06-24 05:50:51.448679
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Dummy')
    except:
        exception('Unit test', sys.exc_info())

# Generated at 2022-06-24 05:50:52.953252
# Unit test for function color
def test_color():
    assert color('RED') == colorama.Fore.RED
    assert color('RED') == ''

# Generated at 2022-06-24 05:50:55.245532
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('echo omfg', False))

# Generated at 2022-06-24 05:50:56.811007
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(False)



# Generated at 2022-06-24 05:51:03.382261
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    from .shells import _get_shell_info

    command = CorrectedCommand('echo "cd /tmp"', side_effect=True)
    show_corrected_command(command)

    print('=' * 78)
    print(const.USER_COMMAND_MARK + command.script + ' (+side effect)')
    print('=' * 78)

    assert sys.stdout.getvalue() == ''
    assert sys.stderr.getvalue().split('\n')[0] == u'\x1b[?25h\x1b[1Kecho "cd /tmp" (+side effect) '



# Generated at 2022-06-24 05:51:06.235224
# Unit test for function rule_failed
def test_rule_failed():
    colorama.init()
    rule_failed('rule', ('a', 'b', 'c'))
    assert(True)


# Generated at 2022-06-24 05:51:07.406476
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(None, None)

# Generated at 2022-06-24 05:51:16.529931
# Unit test for function failed
def test_failed():
    class Output(object):
        def __init__(self):
            self.output = []

        def write(self, text):
            self.output.append(text)

    output = Output()
    _stdout = sys.stderr
    sys.stderr = output

    try:
        failed(u'Привет')
        assert output.output == [u'\x1b[31mПривет\x1b[0m\n']

        settings.no_colors = True
        failed(u'Привет')
        assert output.output == [u'\x1b[31mПривет\x1b[0m\n', u'Привет\n']
    finally:
        sys.stder

# Generated at 2022-06-24 05:51:18.608320
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("fake_rule", "fake_exc_info")
    # TODO



# Generated at 2022-06-24 05:51:19.239860
# Unit test for function debug
def test_debug():
    pass

# Generated at 2022-06-24 05:51:21.629262
# Unit test for function color
def test_color():
    assert color('some-string') == 'some-string'
    with settings(no_colors=True):
        assert color('some-string') == ''

# Generated at 2022-06-24 05:51:26.216750
# Unit test for function confirm_text
def test_confirm_text():
    from tests.utils import Mock
    stdout = Mock()
    confirm_text(Mock(script=u'git push', side_effect=False,
                       is_corrected=False))
    assert stdout == u'\rFuck #git push [enter/↓/↑/ctrl+c]'



# Generated at 2022-06-24 05:51:30.535367
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = type('', (), {
        'reload': 'source ~/.zsh'
    })
    output = '\x1b[1mfuck\x1b[21m alias configured successfully!\nFor applying changes run \x1b[1msource ~/.zsh\x1b[21m or restart your shell.'
    assert configured_successfully(configuration_details) == output


# Generated at 2022-06-24 05:51:36.718870
# Unit test for function debug
def test_debug():
    from io import StringIO

    captured_output = StringIO()
    sys.stderr = captured_output
    debug('hello')

    captured_output.seek(0)
    output = captured_output.read()
    assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m hello\n'



# Generated at 2022-06-24 05:51:38.234060
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-24 05:51:44.225273
# Unit test for function debug
def test_debug():
    from mock import Mock

    settings.debug = True
    sys.stderr = Mock()
    debug('foo')
    sys.stderr.write.assert_called_with(
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')
    settings.debug = False



# Generated at 2022-06-24 05:51:48.339577
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    configuration_details = namedtuple('Details', 'reload path content'
                                                   ' can_configure_automatically')

# Generated at 2022-06-24 05:51:52.248900
# Unit test for function rule_failed
def test_rule_failed():
    from StringIO import StringIO
    from .rules.echo import match, get_new_command
    output = StringIO()
    sys.stderr = output
    rule_failed(match('echo hello'), (Exception, Exception('Echo'), 'None'))
    assert sys.stderr == output



# Generated at 2022-06-24 05:51:53.514385
# Unit test for function color
def test_color():
    assert color('red') == 'red'



# Generated at 2022-06-24 05:51:57.376690
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    confirm_text('git push origin maste')
    assert sys.stdout.getvalue() == u'\n'



# Generated at 2022-06-24 05:52:00.732916
# Unit test for function configured_successfully
def test_configured_successfully():
    out = sys.stdout
    sys.stdout = sys.stderr

    configuration_details = namedtuple('configuration_details', 'reload')
    try:
        configured_successfully(configuration_details('source ~/.bashrc'))
    finally:
        sys.stdout = out

# Generated at 2022-06-24 05:52:02.905701
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-24 05:52:12.094537
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    from . import const
    settings.debug = False
    settings.no_colors = True
    sys.stderr.write("test_confirm_text: ")
    confirm_text("command1")
    confirm_text("command2")
    confirm_text("command3")
    confirm_text("command4")
    confirm_text("command5")
    confirm_text("command6")
    confirm_text("command7")
    confirm_text("command8")
    confirm_text("command9")
    confirm_text("command10")
    confirm_text("command11")
    confirm_text("command12")
    confirm_text("command13")
    confirm_text("command14")
    confirm_text("command15")
    confirm_text("command16")

# Generated at 2022-06-24 05:52:12.977386
# Unit test for function version
def test_version():
    assert version('', '', '') is None

# Generated at 2022-06-24 05:52:15.980349
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import mock

    with mock.patch.object(sys.stderr, 'write') as write:
        with debug_time(u'test'):
            pass

        write.assert_called_once_with(u'DEBUG: test took: 0:00:00\n')

# Generated at 2022-06-24 05:52:18.265281
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'ж')
    except Exception:
        exception(u'title', sys.exc_info())

# Generated at 2022-06-24 05:52:21.042629
# Unit test for function warn
def test_warn():
    title = 'test'
    warn(title)
    import sys
    out = sys.stderr.getvalue().replace('\n','')
    assert out == u'[WARN] {}'.format(title)



# Generated at 2022-06-24 05:52:24.810361
# Unit test for function rule_failed
def test_rule_failed():
    class Rule(object):
        def __init__(self, name):
            self.name = name

    rule = Rule('a')
    try:
        raise Exception('test exception')
    except Exception as e:
        rule_failed(rule, sys.exc_info())



# Generated at 2022-06-24 05:52:34.309605
# Unit test for function version
def test_version():
    from mock import patch
    from sys import version_info

    from thefuck import version as version_
    from thefuck.shells import Shell

    version_.__wrapped__(u'thefuck_version', u'python_version',
                         Shell(u'shell_name', u'shell_version'))

    with patch('thefuck.version.sys.stderr.write') as stderr_write:
        stderr_write.return_value = None
        version_(u'thefuck_version', u'python_version',
                 Shell(u'shell_name', u'shell_version'))

        assert stderr_write.call_args[0][0] == (
            u'The Fuck thefuck_version using Python python_version and '
            u'shell_name shell_version\n')



# Generated at 2022-06-24 05:52:39.617835
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'That’s pretty funny.')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m That\u2019s pretty funny.\n'
    sys.stderr = StringIO()

# Generated at 2022-06-24 05:52:45.079698
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import get_closest
    from .main import fuck
    from .rules.git import _get_correct_command

    _, _, script = get_closest(u'status')
    rule, corrected_command = _get_correct_command(script, 'git')
    show_corrected_command(corrected_command)

    # assert show_corrected_command(corrected_command) == u'$ git status'

