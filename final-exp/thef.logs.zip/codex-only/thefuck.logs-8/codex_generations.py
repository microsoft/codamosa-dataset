

# Generated at 2022-06-24 05:42:45.430860
# Unit test for function debug
def test_debug():
    def assert_debug(expected):
        assert expected == sys.stderr.getvalue()

    try:
        sys.stderr = StringIO()
        debug('foo')
        assert_debug('')

        settings.debug = True
        debug('foo')
        assert_debug(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False


if __name__ == '__main__':
    from cStringIO import StringIO

    test_debug()

# Generated at 2022-06-24 05:42:49.479505
# Unit test for function color
def test_color():
    assert color('') == ''

    @contextmanager
    def use_no_colors():
        previous_no_colors = settings.no_colors
        try:
            settings.no_colors = True
            yield
        finally:
            settings.no_colors = previous_no_colors

    with use_no_colors():
        assert color(colorama.Fore.BLUE) == ''


# Generated at 2022-06-24 05:42:55.685926
# Unit test for function confirm_text
def test_confirm_text():
    import mock

    old_stdout = sys.stdout
    result_stdout = sys.stdout = mock.MagicMock()

    from . import output
    from .rule import Command

    output.confirm_text(Command('ls', 'pwd'))

    assert result_stdout.write.called

# Generated at 2022-06-24 05:42:57.657531
# Unit test for function rule_failed
def test_rule_failed():
    from unittest.mock import Mock

    rule_failed(Mock(name='Rule'), sys.exc_info())

# Generated at 2022-06-24 05:43:03.652902
# Unit test for function failed
def test_failed():
    import StringIO
    sys_stderr = sys.stderr
    message = 'Test error'
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        failed(message)
        sys.stderr.flush()
        assert out.getvalue() == '\x1b[31m' + message + '\x1b[0m\n'
    finally:
        sys.stderr = sys_stderr

# Generated at 2022-06-24 05:43:05.292711
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type('configuration_details', (), {
        'reload': 'reload'})

    assert already_configured(configuration_details) is None
    assert already_configured(configuration_details) is None

# Generated at 2022-06-24 05:43:14.329068
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import unittest
    import const
    import subprocess
    from mock import patch

    from thefuck.utils import show_corrected_command

    _stdout_patch = patch('sys.stdout')
    _stderr_patch = patch('sys.stderr')

    _stdout_mock = _stdout_patch.start()
    _stderr_mock = _stderr_patch.start()

    class ShowCorrectedCommandTest(unittest.TestCase):

        def tearDown(self):
            _stdout_mock.reset_mock()
            _stderr_mock.reset_mock()

        def test_show_corrected_command(self):
            from thefuck.types import CorrectedCommand

            show_corrected_command(CorrectedCommand('ls'))

            _

# Generated at 2022-06-24 05:43:18.287200
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(u"\n" + const.USER_COMMAND_MARK + "test1; +test2; +test3;\n")
    show_corrected_command("command")
    print(u"-------------------------------------------------\n")

# Generated at 2022-06-24 05:43:21.510524
# Unit test for function version
def test_version():
    thefuck_version = 'x.x'
    python_version = 'x.x.x'
    shell_info = 'shell'
    version(thefuck_version, python_version, shell_info)



# Generated at 2022-06-24 05:43:23.093092
# Unit test for function warn
def test_warn():
    assert warn('Something') == '[WARN] Something'



# Generated at 2022-06-24 05:43:30.630504
# Unit test for function failed
def test_failed():
    from tempfile import TemporaryFile
    from thefuck.utils import wrap_retry
    from thefuck.types import Command
    from thefuck import main
    from thefuck.shells import get_shell

    with TemporaryFile(encoding='utf-8') as f:
        with wrap_retry(main, fd_out=f) as main:
            main(Command('ls x', 'ls: x: No such file or directory'),
                 get_shell())
        f.seek(0)
        assert f.read() == u"ls: x: No such file or directory\n"

# Generated at 2022-06-24 05:43:32.845377
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''



# Generated at 2022-06-24 05:43:36.896278
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock

    input = mock.Mock()
    input.script = 'ls'
    input.side_effect = False
    show_corrected_command(input)

    assert sys.stderr.getvalue() == u'👉ls\n'

    sys.stderr.truncate(0)
    sys.stderr.seek(0)

    input.side_effect = True
    show_corrected_command(input)

    assert sys.stderr.getvalue() == u'👉ls (+side effect)\n'


# Generated at 2022-06-24 05:43:44.290124
# Unit test for function version
def test_version():
    import io
    import platform
    import thefuck
    version_out = io.StringIO()
    sys.stderr = version_out
    version(thefuck.__version__, platform.python_version(), 'Shell')
    sys.stderr = sys.__stderr__
    assert version_out.getvalue() == 'The Fuck {} using Python {} and {}\n'.format(thefuck.__version__, platform.python_version(), 'Shell')


# Generated at 2022-06-24 05:43:53.261778
# Unit test for function rule_failed
def test_rule_failed():
    from .compat import StringIO

    import sys

    from . import rules

    class DummyRule(rules.Rule):
        name = 'dummy'

        def match(self, command):
            raise Exception('Dummy error')

        def get_new_command(self, command):
            return 'new_command'

    sio = StringIO()
    sys.stderr = sio

    rule_failed(DummyRule(), sys.exc_info())
    sys.stderr = sys.__stderr__

    assert '[WARN] Rule dummy:' in sio.getvalue()
    assert '[WARN] ----------------------------' in sio.getvalue()
    assert 'Dummy error' in sio.getvalue()

# Generated at 2022-06-24 05:44:00.581813
# Unit test for function version
def test_version():
    from mock import patch, Mock

    with patch('sys.stderr') as stderr:
        version('1.1', '2.7.13', Mock(**{'shell_type.upper': 'SHELL',
                                        'version': '3.0.0'}))
        sys.stderr.write.assert_called_once_with(
            u'The Fuck 1.1 using Python 2.7.13 and SHELL 3.0.0\n')

# Generated at 2022-06-24 05:44:03.457295
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('reload') == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}reload{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT),reset=color(colorama.Style.RESET_ALL),reload='reload')

# Generated at 2022-06-24 05:44:05.460037
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:44:06.201951
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("")
    print("success")

# Generated at 2022-06-24 05:44:09.658698
# Unit test for function configured_successfully
def test_configured_successfully():
    class TestClass(object):
        def __init__(self):
            self.reload = 'reload'

    configured_successfully(TestClass())

# Generated at 2022-06-24 05:44:12.591753
# Unit test for function exception
def test_exception():
    """ Unit test for function exception( title, exc_info) """
    import sys
    try:
        raise Exception("Exception test")
    except Exception as e:
        exception("title", sys.exc_info())

# Generated at 2022-06-24 05:44:13.737508
# Unit test for function configured_successfully
def test_configured_successfully():
    return 'The Fuck 3.8'



# Generated at 2022-06-24 05:44:16.509363
# Unit test for function version
def test_version():
    thefuck_version = '3.6'
    python_version = '2.7'
    shell_info = 'bash'
    version(thefuck_version, python_version, shell_info)


# Generated at 2022-06-24 05:44:19.679833
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell, Setting, ConfigurationDetails
    configuration_details = ConfigurationDetails(shell=Shell('shell', 'any'),
                                                 reload='any',
                                                 setting=Setting('alias', 'fuck', '=', 'any'))
    configured_successfully(configuration_details)



# Generated at 2022-06-24 05:44:21.436615
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(configuration_details=("source ~/.bashrc", "run ~/.bashrc"))


# Generated at 2022-06-24 05:44:28.992316
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    from mock import patch
    from thefuck.utils import show_corrected_command
    stderr = io.StringIO()
    with patch('sys.stderr', new=stderr):
        corrected_command = ['echo', 'hello', 'world']
        show_corrected_command(corrected_command, side_effect=True)
        assert stderr.getvalue() == '$ echo hello world (+side effect)\n'
        corrected_command = ['echo', 'hello', 'world']
        show_corrected_command(corrected_command)
        assert stderr.getvalue() == '$ echo hello world (+side effect)\n$ echo hello world\n'


# Generated at 2022-06-24 05:44:31.124466
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except Exception:
        assert exception(u'Something', sys.exc_info()) == None



# Generated at 2022-06-24 05:44:34.381207
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr.write('\n')
    class obj(object):
        name = 'TestRule'
    exc_info = (Exception, Exception('TestRuleException'), None)
    rule_failed(obj, exc_info)
    sys.stderr.write('\n')


# Generated at 2022-06-24 05:44:36.628993
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type(
        'CorrectedCommand', (object,),
        {'script': 'echo test', 'side_effect': True})
    confirm_text(corrected_command)



# Generated at 2022-06-24 05:44:41.030332
# Unit test for function debug
def test_debug():
    import StringIO
    stderr = StringIO.StringIO()
    settings.debug = True

    debug(u'Debugging')
    assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debugging\n'

    debug(u'Not debugging')
    assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debugging\n'


# Generated at 2022-06-24 05:44:47.159434
# Unit test for function version
def test_version():
    from StringIO import StringIO
    import sys
    out = StringIO()
    sys.stderr = out
    version(thefuck_version="1.3.3", python_version="2.7.10", shell_info="sh")
    assert out.getvalue() == \
            u'The Fuck 1.3.3 using Python 2.7.10 and sh\n'

# Generated at 2022-06-24 05:44:47.745187
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert True

# Generated at 2022-06-24 05:44:48.661085
# Unit test for function warn
def test_warn():
    warn('test warn')



# Generated at 2022-06-24 05:44:50.055077
# Unit test for function failed
def test_failed():
    assert not failed('test fail'), 'Failed test output'



# Generated at 2022-06-24 05:44:52.992364
# Unit test for function rule_failed
def test_rule_failed():
    msg = u'Rule test'

    try:
        a = 1
        b = 0
        a / b
    except ZeroDivisionError:
        rule_failed(msg, sys.exc_info())



# Generated at 2022-06-24 05:44:59.350614
# Unit test for function warn
def test_warn():
    assert warn(u'foo') == u'\x1b[103m\x1b[30m\x1b[1m[WARN] foo\x1b[0m\n'
    assert warn(u'''foo
bar''') == u'\x1b[103m\x1b[30m\x1b[1m[WARN] foo\x1b[0m\n\x1b[103m\x1b[30m\x1b[1m[WARN] bar\x1b[0m\n'



# Generated at 2022-06-24 05:45:01.104062
# Unit test for function version
def test_version():
    assert 'The Fuck 3.10' in version('3.10', '3.5', 'ShellInfo')

# Generated at 2022-06-24 05:45:04.517372
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type('obj', (object,), {})()
    configuration_details.reload = 'reload'
    assert 'Seems like fuck alias already configured!' == already_configured(configuration_details)


# Generated at 2022-06-24 05:45:09.525603
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    stream = StringIO()
    sys.stderr = stream

    failed('msg')
    assert stream.getvalue() == '\x1b[31mmsg\x1b[0m\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:45:13.220484
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    output = u"Seems like {bold}fuck{reset} alias isn't configured!\n" \
             u"Please put {bold}{content}{reset} in your " \
             u"{bold}{path}{reset} and apply " \
             u"changes with {bold}{reload}{reset} or restart your shell." \
             u"\nOr run {bold}fuck{reset} a second time to configure" \
             u" it automatically.\nMore details - https://github.com/nvbn/thefuck#manual-installation"
    assert how_to_configure_alias(u"{bold}{content}{reset}", "~/.bashrc", "reload") == output



# Generated at 2022-06-24 05:45:15.831571
# Unit test for function failed
def test_failed():
    import StringIO
    old_stderr = sys.stderr
    sys.stderr = stderr = StringIO.StringIO()
    failed('message')
    assert 'message\n' == stderr.getvalue()
    sys.stderr = old_stderr



# Generated at 2022-06-24 05:45:19.232589
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock

    confirmed_command = Mock()
    confirmed_command.script = "git push origin master"
    confirmed_command.side_effect = None
    confirm_text(corrected_command=confirmed_command)

    confirmed_command.side_effect = True
    confirm_text(corrected_command=confirmed_command)

# Generated at 2022-06-24 05:45:30.953587
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import Configuration, ShellInfo

    configuration = Configuration(can_configure_automatically=True,
                                  file=u'/home/nvbn/.config',
                                  reload=u'source ~/.config')
    shell_info = ShellInfo(shell_type=u'bash')

    sys.stderr = open('/tmp/thefuck.log', 'w')
    how_to_configure_alias(configuration)
    sys.stderr.close()


# Generated at 2022-06-24 05:45:34.012867
# Unit test for function rule_failed
def test_rule_failed():  # pragma: no cover
    from .rules import Command
    rule_failed(Command(u'f', u'replace f with foobar', None), None)



# Generated at 2022-06-24 05:45:44.902383
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys

    sys.stderr = io.StringIO()
    corrected_command = 'ls a b c'
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == \
        u'{prefix}{bold}ls a b c{reset}\n'.format(
            prefix=const.USER_COMMAND_MARK,
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

    sys.stderr = io.StringIO()
    corrected_command = 'ls a b c'
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:45:53.900589
# Unit test for function color
def test_color():
    class Mock(object):
        def __init__(self):
            self.style = Mock()
            self.style.RESET_ALL = "reset_all"
            self.Fore = Mock()
            self.Fore.RED = "red"
            self.Fore.BLUE = "blue"
            self.Fore.GREEN = "green"
            self.Back = Mock()
            self.Back.RED = "red"
            self.Back.WHITE = "white"
            self.Style = Mock()
            self.Style.BRIGHT = "bright"

    global colorama
    colorama = Mock()

    assert color("red") == "red"
    assert color("red") == color("white")

    colorama.Fore.RED = ""
    colorama.Back.RED = ""

    assert color("red") == ""

# Generated at 2022-06-24 05:45:59.958794
# Unit test for function configured_successfully
def test_configured_successfully():
    if sys.version_info >= (2, 7):
        # Under Python 2.7 print is a function
        from io import StringIO
        from contextlib import redirect_stdout
        with StringIO() as buf:
            with redirect_stdout(buf):
                configured_successfully('source ~/.bashrc')
            assert buf.getvalue().strip('\n') == \
                u"\033[1mthefuck\033[22m alias configured successfully!\n" \
                u"For applying changes run \033[1msource ~/.bashrc\033[22m" \
                u" or restart your shell."
    else:
        # Under Python 2.6 it is a statement
        from cStringIO import StringIO
        import sys
        stdout = sys.stdout

# Generated at 2022-06-24 05:46:00.983061
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('fuck')


# Generated at 2022-06-24 05:46:08.404538
# Unit test for function version
def test_version():
    version(
        thefuck_version='3.21',
        python_version='3.5.2',
        shell_info='ShellInfo(bash, bash, /usr/bin/bash)')

    version(
        thefuck_version='3.21',
        python_version='3.5.2',
        shell_info='ShellInfo(zsh, zsh, /usr/bin/zsh)')

    version(
        thefuck_version='3.21',
        python_version='3.5.2',
        shell_info='ShellInfo(cmd, cmd.exe, C:\Windows\System32\cmd.exe)')
    assert True

# Generated at 2022-06-24 05:46:09.919169
# Unit test for function warn
def test_warn():
    warn(u'Hello') == u'\n[WARN] Hello\n'



# Generated at 2022-06-24 05:46:17.256698
# Unit test for function already_configured
def test_already_configured():
    import os

    backup = os.environ.pop('SHELL', None)
    os.environ['SHELL'] = 'not_existing'
    try:
        configuration_details = ("ignore", "ignore", "ignore", False, False,
                                 "ignore")
        already_configured(configuration_details)
    finally:
        if backup:
            os.environ['SHELL'] = backup

if __name__ == '__main__':
    test_already_configured()

# Generated at 2022-06-24 05:46:19.459949
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('test')
    except Exception:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:46:20.498006
# Unit test for function warn
def test_warn():
    warn('title')


# Generated at 2022-06-24 05:46:25.954196
# Unit test for function debug
def test_debug():
    result = u''
    output = []

    def capture_output(msg):
        output.append(msg)

    sys.stderr.write = capture_output
    debug(u'test')
    assert output[0] == u'DEBUG: test\n'
    assert result == u''
    output[:] = []
    settings.debug = False
    debug(u'test')
    assert output == []



# Generated at 2022-06-24 05:46:27.750702
# Unit test for function rule_failed
def test_rule_failed():
    class Rule(object):
        name = 'foo'

    rule_failed(Rule(), ('type', ValueError, None))

# Generated at 2022-06-24 05:46:37.709611
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from thefuck.util import ConfigurationDetails
    from sys import stdout
    out = StringIO()
    stdout = sys.stdout
    sys.stdout = out
    configuration_details = ConfigurationDetails(
        can_configure_automatically=False,
        path=u'/home/user/.bashrc',
        content=u"eval $(thefuck --alias)",
        reload=u'source /home/user/.bashrc')
    configured_successfully(configuration_details)
    sys.stdout = stdout
    assert out.getvalue() == u'\x1b[1mthefuck\x1b[22m alias configured successfully!\nFor applying changes run \x1b[1msource /home/user/.bashrc\x1b[22m or restart your shell.\n'

# Generated at 2022-06-24 05:46:39.006372
# Unit test for function color
def test_color():
    assert color('text') == 'text'
    settings.no_colors = True
    assert color('text') == ''

# Generated at 2022-06-24 05:46:42.394371
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import get_command

    def get_input():
        return '\n'

    with confirm_text(get_command('x', 'x')):
        get_input()


# Generated at 2022-06-24 05:46:45.496619
# Unit test for function failed
def test_failed():
    failed('mock')
    assert sys.stderr.getvalue() == color(colorama.Fore.RED) + 'mock' + color(colorama.Style.RESET_ALL) + '\n'

# Generated at 2022-06-24 05:46:46.417940
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('test') == None

# Generated at 2022-06-24 05:46:50.085349
# Unit test for function color
def test_color():
    assert '' == color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT == color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT == color(colorama.Style.BRIGHT)

# Generated at 2022-06-24 05:46:56.510450
# Unit test for function rule_failed
def test_rule_failed():
    with open('./test_log.txt', 'w') as test_log:
        old_stderr = sys.stderr
        sys.stderr = test_log
        rule_failed(('fuck', 'alias'), "intentionally")
        sys.stderr = old_stderr
    with open('./test_log.txt', 'r') as test_log:
        assert "[WARN] Rule fuck alias" in test_log.read()

# Generated at 2022-06-24 05:46:59.714185
# Unit test for function warn
def test_warn():
    warn('test')
    assert sys.stderr.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'

# Generated at 2022-06-24 05:47:02.080104
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except Exception:
        exception('Hello, world!', sys.exc_info())

test_exception()

# Generated at 2022-06-24 05:47:04.264130
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('fuck', 'exc_info')



# Generated at 2022-06-24 05:47:07.076637
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test_script') == (
        u'[user@host ~]$ test_script [enter/↑/↓/ctrl+c]'
    )

# Generated at 2022-06-24 05:47:08.975499
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("test_already_configured")



# Generated at 2022-06-24 05:47:14.588281
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('reload') == print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}reload{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='reload'))


# Generated at 2022-06-24 05:47:23.199820
# Unit test for function exception
def test_exception():
    title = u'Test exception'
    warn = u'Warning'
    exc_info = (Exception, Exception(warn), None)
    result = u'''{warn}[WARN] {title}:{reset}\n{trace}'''.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title=title,
            trace=''.join(format_exception(*exc_info)))
    assert result == exception(title, exc_info)


# Generated at 2022-06-24 05:47:25.096732
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(
        configuration_details=None)


# Generated at 2022-06-24 05:47:26.090952
# Unit test for function already_configured
def test_already_configured():
    assert already_configured == already_configured

# Generated at 2022-06-24 05:47:27.004463
# Unit test for function failed
def test_failed():
    failed(u'failed')

# Generated at 2022-06-24 05:47:29.517893
# Unit test for function failed
def test_failed():
    assert failed(u"Testing: папа")

# Generated at 2022-06-24 05:47:31.485116
# Unit test for function version
def test_version():
    # Assert the function version
    assert(version("3.10", "2.7", "bash"))

# Generated at 2022-06-24 05:47:33.848515
# Unit test for function confirm_text
def test_confirm_text():
    now = datetime.now()
    from .command import CorrectedCommand
    from .types import Command
    from .shells.bash import shell
    corrected_command = CorrectedCommand(now, Command(now, "o comando", "o comando", "ls -la"), shell)
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:47:38.030128
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('echo 1'))
    show_corrected_command(CorrectedCommand('echo 1', side_effect=True))

# Generated at 2022-06-24 05:47:42.627013
# Unit test for function warn
def test_warn():
    import sys
    import mock
    from thefuck.utils import warn
    with mock.patch.object(sys.stderr, 'write') as mock_write:
        warn('Title')
        mock_write.assert_called_once_with(
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] Title\x1b[0m\n')



# Generated at 2022-06-24 05:47:43.856838
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("configuration_details")


# Generated at 2022-06-24 05:47:47.551018
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo_output import match, get_new_command
    rule = type('', (object,), {'name': 'echo_output'})()
    match('', '', rule)
    try:
        get_new_command('', '', rule)
    except:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:47:53.743676
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import shell
    import sys
    import io
    sys.stdout = io.StringIO()
    how_to_configure_alias(shell.get_shell(False).get_aliases())
    print(sys.stdout.getvalue().strip())
    sys.stdout = sys.__stdout__

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-24 05:47:55.652584
# Unit test for function debug_time
def test_debug_time():
    time = datetime.now()
    with debug_time('name'):
        assert datetime.now() != time

# Generated at 2022-06-24 05:48:06.270037
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.get_shell_info import get_shell_info

    result = how_to_configure_alias(get_shell_info())
    output = ("Seems like {bold}fuck{reset} alias isn't configured!\n"
              "Please put {bold}eval $(thefuck --alias){reset} in "
              "your {bold}~/.bash_profile{reset} and apply changes "
              "with {bold}source ~/.bash_profile{reset} or restart "
              "your shell.\n"
              "Or run {bold}fuck{reset} a second time to configure "
              "it automatically.\n"
              "More details - https://github.com/nvbn/thefuck#manual-installation")

    print(output)


# Generated at 2022-06-24 05:48:13.361800
# Unit test for function already_configured
def test_already_configured():
    from . import compat
    from .utils import get_closest

    if compat.is_osx:
        configuration_details = get_closest('~/.bash_profile')
    else:
        configuration_details = get_closest('~/.bashrc')
    already_configured(configuration_details)

# Generated at 2022-06-24 05:48:17.854765
# Unit test for function exception
def test_exception():
    def some_function():
        raise Exception("This is exception")

    try:
        some_function()
    except Exception as e:
        exc_info = sys.exc_info()
        error = u'[WARN] Exception:'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title='Exception')
        trace = u''.join(format_exception(*exc_info))
        assert(error + trace) == (exception('Exception', exc_info))

# Generated at 2022-06-24 05:48:19.409650
# Unit test for function color
def test_color():
    assert color('should be here') == 'should be here'



# Generated at 2022-06-24 05:48:20.503793
# Unit test for function configured_successfully

# Generated at 2022-06-24 05:48:24.327758
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        can_configure_automatically=True, can_configure_automatically=True,
        content='TEST', path='TEST', reload='TEST'))

# Generated at 2022-06-24 05:48:28.660553
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(const.ConfigurationDetails(
        u'/home/nvbn/.bashrc',
        u'. /home/nvbn/.config/thefuck/venv/bin/activate; source ~/.bashrc')) == None


# Generated at 2022-06-24 05:48:35.301092
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    error_msg_1 = "Seems like fuck alias isn't configured!"
    error_msg_2 = "Please put content in your path and apply changes with reload or restart your shell."
    error_msg_3 = "Or run fuck a second time to configure it automatically."
    error_msg_4 = "More details - https://github.com/nvbn/thefuck#manual-installation"
    configuration_details = {'content': "fuck --alias"}
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-24 05:48:36.295498
# Unit test for function warn
def test_warn():
    warn(u'Foo Bar')



# Generated at 2022-06-24 05:48:37.244714
# Unit test for function already_configured
def test_already_configured():
    already_configured('')

# Generated at 2022-06-24 05:48:39.211937
# Unit test for function already_configured
def test_already_configured():
    assert already_configured({"reload": "someshell reload"})

# Generated at 2022-06-24 05:48:48.143493
# Unit test for function debug
def test_debug():
    import os
    import sys

    # Add some special argument to profile loading in config.py
    sys.argv.append('--debug')

    from thefuck import config

    # Remove special argument after it was handled in config.py
    sys.argv.pop()

    # Remove special flag from settings after it was handled in config.py
    delattr(config.settings, 'debug')

    from thefuck import output

    # Redirect stdout to stderr
    sys.stdout = sys.stderr

    # Hack for colorama for Windows platforms
    if os.name == 'nt':
        colorama.init()

    # Check if we can write to std* streams
    if not (sys.stdout and sys.stderr):
        raise Exception('Can not write to std* streams')


# Generated at 2022-06-24 05:48:51.626910
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test'):
        pass
    ended = datetime.now()

    debug(u'test took: {}'.format(ended - started))

# Generated at 2022-06-24 05:48:54.518657
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'test')
    except Exception as e:
        exception(u'title', sys.exc_info())
        assert True

# Generated at 2022-06-24 05:48:55.620161
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(None)


# Generated at 2022-06-24 05:49:02.562037
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from thefuck.types import Command

    old_stderr = sys.stderr
    new_stderr = StringIO()
    sys.stderr = new_stderr
    failed(u'Fuck')
    new_stderr.seek(0)
    assert new_stderr.read() == u'\x1b[31mFuck\x1b[0m\n'
    sys.stderr = old_stderr



# Generated at 2022-06-24 05:49:10.288176
# Unit test for function debug
def test_debug():
    import mock
    import six

    if six.PY2:
        mock_write = mock.Mock()
        mock_write.return_value = None
        debug('msg')
        assert mock.call('msg\n') in mock_write.mock_calls
    else:
        # Python 3 uses write-only streams
        mock_write = mock.Mock()
        mock_write.write = mock.Mock()
        mock_write.write.return_value = None
        debug('msg')
        assert mock.call(mock_write, 'msg\n') in mock_write.write.mock_calls

# Generated at 2022-06-24 05:49:13.309684
# Unit test for function exception
def test_exception():
    import pytest
    caption = 'some caption'
    exc_info = Exception('some behavior')
    with pytest.raises(Exception):
        exception(caption, exc_info)

# Generated at 2022-06-24 05:49:14.384626
# Unit test for function warn
def test_warn():
    warn(u'test')



# Generated at 2022-06-24 05:49:15.474159
# Unit test for function warn
def test_warn():
    warn('')



# Generated at 2022-06-24 05:49:26.179255
# Unit test for function configured_successfully
def test_configured_successfully():

    from . import shell_info
    configure_details = shell_info.ConfigureDetails('reload', 'path', 'content')

    class FakeStdOut(object):
        def __init__(self):
            self.content = []

        def write(self, text=''):
            self.content.append(text)

        def getvalue(self):
            return ''.join(self.content)

    import sys
    out = sys.stdout


# Generated at 2022-06-24 05:49:32.546675
# Unit test for function version
def test_version():
    from mock import patch, Mock
    from contextlib import contextmanager

    @contextmanager
    def _():
        yield

    with patch('sys.stderr', Mock()) as stderr:
        version('1.2.3', '2.4.5', 'zsh 1.2.3')
        stderr.assert_called_with(
            'The Fuck 1.2.3 using Python 2.4.5 and zsh 1.2.3\n')


# Generated at 2022-06-24 05:49:34.803702
# Unit test for function warn
def test_warn():
    try:
        raise NameError('name')
    except Exception as e:
        exception(u'Rule', sys.exc_info())

# Generated at 2022-06-24 05:49:43.939505
# Unit test for function exception
def test_exception():
    def func():
        try:
            raise Exception('Exception')
        except:
            exception('test title', sys.exc_info())

    result = call(func)
    expected = u'''\
\x1b[41m\x1b[37m\x1b[1m[WARN] test title\x1b[0m
Traceback (most recent call last):
  File "tests/shells/test_output.py", line 119, in func
    raise Exception('Exception')
Exception: Exception\x1b[0m
\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m

'''
    assert result == expected



# Generated at 2022-06-24 05:49:46.848971
# Unit test for function version
def test_version():
    version(thefuck_version=u"1.1", python_version=u"2.7", shell_info=u"bash")

# Generated at 2022-06-24 05:49:48.739282
# Unit test for function exception
def test_exception():
    try:
        float('teststring')
    except:
        exception('test', sys.exc_info())

# Generated at 2022-06-24 05:49:55.842909
# Unit test for function exception
def test_exception():
    import tempfile
    sys.stderr = output = tempfile.TemporaryFile()
    exception('title', ('exception_type', Exception('msg1'), None))
    output.seek(0)
    assert output.read() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\nTraceback (most recent call last):\n  File "<string>", line 1, in <module>\nException: msg1\n\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m\n\n\n'  # noqa
    output.close()



# Generated at 2022-06-24 05:50:02.489561
# Unit test for function already_configured
def test_already_configured():
	already_configured({'reload':'source ~/.bashrc'})

	try:
		from StringIO import StringIO
	except ImportError:
		from io import StringIO

	import sys

	buff = StringIO()
	sys.stdout = buff

	already_configured({'reload':'source ~/.bashrc'})

	assert "Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell." in buff.getvalue()

# Generated at 2022-06-24 05:50:04.132809
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand("", False)
    confirm_text(corrected_command)


# Generated at 2022-06-24 05:50:05.007853
# Unit test for function color
def test_color():
    assert color('colored') != 'colored'

# Generated at 2022-06-24 05:50:11.612198
# Unit test for function confirm_text
def test_confirm_text():
    correct_command = color(colorama.Style.BRIGHT) + 'git pull origin master' + color(colorama.Style.RESET_ALL) + ' '
    correct_command += color(colorama.Fore.GREEN) + 'enter' + color(colorama.Style.RESET_ALL) + '/'
    correct_command += color(colorama.Fore.BLUE) + '↑' + color(colorama.Style.RESET_ALL) + '/'
    correct_command += color(colorama.Fore.BLUE) + '↓' + color(colorama.Style.RESET_ALL) + '/'
    correct_command += color(colorama.Fore.RED) + 'ctrl+c' + color(colorama.Style.RESET_ALL)
    assert confirm_text(correct_command) == correct_command

# Unit

# Generated at 2022-06-24 05:50:20.161775
# Unit test for function debug
def test_debug():
    import StringIO
    import colorama
    from contextlib import contextmanager

    @contextmanager
    def mock_stderr():
        previous_stderr = sys.stderr
        sys.stderr = StringIO.StringIO()
        try:
            yield
        finally:
            sys.stderr = previous_stderr

    with mock_stderr():
        debug('test')
        assert sys.stderr.getvalue() == '{}\n'.format(colorama.Fore.BLUE +
                                                      colorama.Style.BRIGHT +
                                                      'DEBUG:' +
                                                      colorama.Style.RESET_ALL +
                                                      ' test' + '\n')



# Generated at 2022-06-24 05:50:24.416952
# Unit test for function already_configured
def test_already_configured():
    from mock import Mock
    print_mock = Mock()
    sys.stdout.write = print_mock
    configuration_details = Mock()
    configuration_details.reload = Mock()
    already_configured(configuration_details)
    assert print_mock.called

# Generated at 2022-06-24 05:50:25.764260
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)


# Generated at 2022-06-24 05:50:29.886889
# Unit test for function configured_successfully
def test_configured_successfully():
    assert_configured_successfully({"reload": "exec $SHELL -l"})
    assert_configured_successfully({"reload": "reload"})
    assert_configured_successfully({"reload": "rehash"})
    assert_configured_successfully({"reload": "hash -r"})


# Generated at 2022-06-24 05:50:34.086781
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    mock = StringIO()
    sys.stderr = mock
    try:
        warn("The warning")
        assert mock.getvalue() == '[WARN] The warning\n'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:50:38.302749
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    shell = Shell()
    corrected_command = CorrectedCommand(u'script', False, False)
    show_corrected_command(corrected_command) == \
        const.USER_COMMAND_MARK + shell.highlight('script')

# Generated at 2022-06-24 05:50:40.905787
# Unit test for function color
def test_color():
    assert u'\x1b[31mTest\x1b[0m' == color(colorama.Fore.RED + u'Test')
    assert u'Test' == color(u'Test')

# Generated at 2022-06-24 05:50:42.089218
# Unit test for function already_configured
def test_already_configured():
    already_configured({"reload": ". ~/.bash_profile"})

# Generated at 2022-06-24 05:50:45.033806
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE + 'test') == '\x1b[34mtest'
    assert not color(colorama.Fore.BLUE + 'test')

# Generated at 2022-06-24 05:50:51.207793
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import Command
    command = Command('ls', '', '', '')
    shell = Shell('bash')
    assert confirm_text(command) == 'ls'
    assert confirm_text(command.script) == 'ls'
    command = Command('ls', '', '', '', True)
    assert confirm_text(command) == 'ls (+side effect)'



# Generated at 2022-06-24 05:50:56.252575
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print("Testing function how_to_configure_alias")
    how_to_configure_alias("This is a test")
    # TODO: Validate that the output is the same as in the doc,
    # https://github.com/nvbn/thefuck/pull/583#issue-98706489

# Generated at 2022-06-24 05:51:00.366817
# Unit test for function failed
def test_failed():
    failed('something wrong')
    assert sys.stderr.getvalue() == (
        u'{red}{msg}{reset}\n'.format(
            msg='something wrong',
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-24 05:51:11.987287
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import datetime as module_datetime
    import time

    DELTA = datetime.now() - datetime.now()
    TIME = datetime.now() + DELTA
    MSG = u''

    patch = mock.patch('datetime.datetime')
    now = patch.start()
    now.now = lambda: TIME

    with debug_time(MSG) as time:
        time.sleep(0.1)
    assert const.DIRTY_PREFIX not in time.getvalue()  # noqa

    patch.stop()
    patch = mock.patch('thefuck.shells.get_history_file_name')
    mock_get_history_file_name = patch.start()
    mock_get_history_file_name.return_value = None
    settings.debug = True

# Generated at 2022-06-24 05:51:17.375092
# Unit test for function version
def test_version():
    import thefuck
    from .vcs import shell_info
    from . import __version__, sys
    from contextlib import contextmanager
    from cStringIO import StringIO
    @contextmanager
    def stdoutIO(stdout=None):
        old = sys.stdout
        if stdout is None:
            stdout = StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old
    version(__version__, thefuck.__version__, shell_info())
    with stdoutIO() as s:
        version(__version__, thefuck.__version__, shell_info())
        assert s.getvalue() == 'The Fuck {} using Python {} and {}\n'.format(__version__, thefuck.__version__, shell_info())

# Generated at 2022-06-24 05:51:18.553580
# Unit test for function exception
def test_exception():
    exc_info = (type(Exception), Exception('foo'), None)
    exception('title', exc_info)

# Generated at 2022-06-24 05:51:27.900716
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import re
    import subprocess
    from .shells import Shell
    from thefuck.shells import Bash
    from thefuck.rules.git import match, get_new_command
    from mock import patch
    from thefuck.rules.git import is_git_installed
    with patch('thefuck.rules.git.is_git_installed', return_value=True):
        output = subprocess.check_output(
                'git checkout master && git push origin master',
                stderr=subprocess.STDOUT, shell=True)
        command = 'git checkout master && git push origin master'
        new_command = get_new_command(Shell(), command, output)
        show_corrected_command(new_command)

# Generated at 2022-06-24 05:51:29.468284
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    assert True


# Generated at 2022-06-24 05:51:37.519845
# Unit test for function confirm_text
def test_confirm_text():
    # test for failed rule
    sys.stderr.write("\n")
    correct_command = "echo 'Hello World'"
    fail_command = "echo 'Hello World'"
    confirm_text(correct_command)
    assert sys.stderr.getvalue()[-97:] == "> " + correct_command + " [enter/↑/↓/ctrl+c]\n"
    sys.stderr = open("/dev/null", "w")

# Generated at 2022-06-24 05:51:38.541943
# Unit test for function already_configured
def test_already_configured():
    already_configured('reload')


# Generated at 2022-06-24 05:51:44.653681
# Unit test for function failed
def test_failed():
    import sys
    import tempfile
    import colorama
    import os
    saved_stderr = sys.stderr
    out_file = tempfile.NamedTemporaryFile(delete=False)
    sys.stderr = out_file
    try:
        failed("test")
    finally:
        out_file.close()
        sys.stderr.close()
        sys.stderr = saved_stderr
    with open(out_file.name, 'r') as f:
        assert f.read().strip() == colorama.Fore.RED + "test" + colorama.Style.RESET_ALL



# Generated at 2022-06-24 05:51:46.893441
# Unit test for function failed
def test_failed():
    try:
        failed(u'Проверка')
        assert False
    except UnicodeEncodeError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 05:51:55.004700
# Unit test for function show_corrected_command
def test_show_corrected_command():
        from .conf import Command
        from .utils import wrap_with_color
        from .colors import red, bold, cyan, white
        corrected_command = Command(script=wrap_with_color('fuck', bold),
                                    side_effect=True)
        expected_output = u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
            prefix=const.USER_COMMAND_MARK,
            script=wrap_with_color(u'fuck', white + bold),
            side_effect=wrap_with_color(u' (+side effect)', red),
            bold=wrap_with_color('', bold),
            reset=wrap_with_color('', cyan))
        show_corrected_command(corrected_command)
        assert sys.stderr.getvalue() == expected_output

# Generated at 2022-06-24 05:51:59.985024
# Unit test for function configured_successfully
def test_configured_successfully():
    expected = ("fuck alias configured successfully!\n"
                "For applying changes run reload or restart your shell.")

    class Struct:
        def __init__(self, **entries):
            self.__dict__.update(entries)

    result = configured_successfully(
        Struct(reload=u"reload"))

    assert result == expected



# Generated at 2022-06-24 05:52:09.864924
# Unit test for function version
def test_version():
    from io import BytesIO
    from thefuck.shells import get_shell_info
    from thefuck.utils import get_version
    from thefuck.tests.utils import input_stream
    import thefuck
    std = BytesIO()
    sys.stderr = std
    with input_stream(u'The Fuck 3.2 using Python 3.5 and {shell}\n'):
        version(get_version(), '3.5', get_shell_info())
    assert u'The Fuck 3.2 using Python 3.5 and {shell}'\
        .format(shell=color(colorama.Style.BRIGHT) +
                thefuck.shells.get_shell_name() +
                color(colorama.Style.RESET_ALL)) in std.getvalue().decode()

# Generated at 2022-06-24 05:52:11.531857
# Unit test for function exception
def test_exception():
    class MyException(Exception):
        """This is my exception"""

    exception('My title', sys.exc_info())

# Generated at 2022-06-24 05:52:21.008880
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .shells.bash import _parse_alias
    from .types import CorrectedCommand
    command = CorrectedCommand('echo test', 'echo test')
    shell = Bash(_parse_alias('fuck'), lambda cmd: None, lambda: '',
                 lambda cmd: None, lambda: None)
    shell.get_history = lambda: ['git commit']
    confirm_text(command)
    command = CorrectedCommand('echo test', 'echo test', True)
    confirm_text(command)
    with settings(no_colors=True):
        confirm_text(command)
    with settings(no_colors=True, require_confirmation=False):
        confirm_text(command)
    shell.get_history = lambda: []

# Generated at 2022-06-24 05:52:22.802221
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''

# Generated at 2022-06-24 05:52:25.712352
# Unit test for function color
def test_color():
    assert color(colorama.Fore.YELLOW) == ''
    settings.no_colors = False
    assert color(colorama.Fore.YELLOW) == colorama.Fore.YELLOW

# Generated at 2022-06-24 05:52:33.494167
# Unit test for function version
def test_version():
    try:
        import mock
    except ImportError:
        import unittest.mock as mock
    with mock.patch.object(sys.stderr, 'write') as write_mock:
        thefuck_version = '1.1'
        python_version = '2.7.6'
        shell_info = 'sh'
        version(thefuck_version, python_version, shell_info)
        write_mock.assert_called_with(
            u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                           python_version,
                                                           shell_info))

# Generated at 2022-06-24 05:52:37.198405
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    confirm_text(const.CorrectedCommand('msg', False))
    sys.stderr = sys.__stderr__
    assert output.getvalue() == '{}msg [enter/↑/↓/ctrl+c]'.format(
        const.USER_COMMAND_MARK)

# Generated at 2022-06-24 05:52:40.379280
# Unit test for function failed
def test_failed():
    import StringIO
    old_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    try:
        failed('ERROR')
        assert sys.stderr.getvalue() == '\x1b[31mERROR\x1b[0m\n'
    finally:
        sys.stderr = old_stderr

