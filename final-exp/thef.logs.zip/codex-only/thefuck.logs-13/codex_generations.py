

# Generated at 2022-06-24 05:42:48.578239
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    with open('test_how_to_configure_alias.txt', 'w+') as test_file:
        sys.stderr = test_file
        how_to_configure_alias('config')

# Generated at 2022-06-24 05:42:51.171326
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception as e:
        e_info = sys.exc_info()
        exception('Rule', e_info)



# Generated at 2022-06-24 05:43:02.364498
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Configuration details is not None
    notNoneConfigDetails = type('ConfigDetails', (object, ), {
        'can_configure_automatically': False,
        'path': 'path',
        'content': 'content',
        'reload': 'reload',
        'command': 'command',
        'error': 'error'})
    notNoneConfigDetails = notNoneConfigDetails()
    # Configuration details is None
    NoneConfigDetails = None
    # Expected result for how_to_configure_alias(notNoneConfigDetails)

# Generated at 2022-06-24 05:43:04.467123
# Unit test for function debug_time
def test_debug_time():
    debug_time_message = 'test_debug_time_message'
    with debug_time(debug_time_message):
        pass



# Generated at 2022-06-24 05:43:06.122109
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text == u'fuck ~/.config/nvim/init.vim [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:43:13.538670
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Function 'how_to_configure_alias' should output correct message
    # when configuration_details is given
    how_to_configure_alias(
        configuration_details='Test message'
    )
    # Function 'how_to_configure_alias' shouldn't output anything when
    # configuration_details is None
    how_to_configure_alias(configuration_details=None)
    # As a result, two messages should be print
    assert sys.stdout.getvalue() == 'Seems like fuck alias isn\'t configured!\nSeems like fuck alias isn\'t configured!\n'
    # Clear function 'print' output
    sys.stdout.truncate()

# Generated at 2022-06-24 05:43:22.151746
# Unit test for function color
def test_color():
    color_tests = [
        (color(''), ''),
        (color(u'{style}'.format(style=colorama.Style.BRIGHT)), ''),
        (color(u'{style}'.format(style=colorama.Style.BRIGHT)), '', True),
        (u'{style}'.format(style=colorama.Style.BRIGHT), '', False)
    ]
    for expected, actual, no_colors in color_tests:
        assert expected == actual, \
            'Expected {} for no_colors = {}'.format(expected, no_colors)



# Generated at 2022-06-24 05:43:23.920424
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('Something')
    except ValueError:
        exception('Title', sys.exc_info())



# Generated at 2022-06-24 05:43:26.850930
# Unit test for function color
def test_color():
    assert color(u'{}'.format(colorama.Back.RED + colorama.Fore.WHITE
                              + colorama.Style.BRIGHT)) == settings.no_colors

# Generated at 2022-06-24 05:43:32.130714
# Unit test for function version
def test_version():
    import sys
    import pkg_resources
    import platform

    expected_value = 'The Fuck {} using Python {} and {}\n'.format(
        pkg_resources.get_distribution('thefuck').version,
        platform.python_version(),
        'bash' if sys.platform != 'cygwin' else 'cygwin')

    assert version('1', '2.7', 'bash') == expected_value

# Generated at 2022-06-24 05:43:34.083043
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'correction'
    show_corrected_command(corrected_command)
    assert colorama.Fore.GREEN in corrected_command

# Generated at 2022-06-24 05:43:35.499061
# Unit test for function rule_failed
def test_rule_failed():
    assert rule_failed(object, 'exc_info') == None

# Generated at 2022-06-24 05:43:41.100821
# Unit test for function version
def test_version():
    thefuck_version = (1, 2, 3)
    python_version = (3, 4, 5)
    shell_info = ('bash', '5.0')
    assert version(thefuck_version, python_version, shell_info) == 'The Fuck 1.2.3 using Python 3.4.5 and bash 5.0'


# Generated at 2022-06-24 05:43:42.197816
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text is not None

# Generated at 2022-06-24 05:43:52.685213
# Unit test for function rule_failed
def test_rule_failed():
    import tempfile
    import sys
    import unittest
    import thefuck
    class TestRule(thefuck.rules.base.BaseRule):
        def match(self, command):
            return False
        def get_new_command(self, command):
            return ''
    class TestCase(unittest.TestCase):
        def test_exception(self):
            try:
                raise Exception()
            except Exception as exception:
                rule_failed(TestRule(), sys.exc_info())
                rule_failed(TestRule(), sys.exc_info())
                with tempfile.TemporaryFile('r+') as f:
                    sys.stderr = f
                    rule_failed(TestRule(), sys.exc_info())
                    sys.stderr = sys.__stderr__
                    f.seek(0)
                   

# Generated at 2022-06-24 05:43:56.988265
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("thefuck --alias") == u"Seems like {} alias already configured!\nFor applying changes run {reload} or restart your shell.".format("thefuck --alias")


# Generated at 2022-06-24 05:43:59.591129
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import wrap_with_prefix
    assert confirm_text(wrap_with_prefix('echo "Fuck"', 'fuck ')) == \
'''fuck echo "Fuck" [enter/↑/↓/ctrl+c]'''

# Generated at 2022-06-24 05:44:01.923375
# Unit test for function configured_successfully
def test_configured_successfully():
        class MockClass:
            reload = 'reload shell'

        configuration_details = MockClass()
        print_conf_detail = configured_successfully(configuration_details)
        assert print_conf_detail == True


# Generated at 2022-06-24 05:44:05.530672
# Unit test for function failed
def test_failed():
    from tests.utils import capture_stderr, eq

    msg = u'\u20ac'
    with capture_stderr() as stderr:
        failed(msg)
    eq(stderr.getvalue(), u'\x1b[31m€\x1b[0m\n')



# Generated at 2022-06-24 05:44:07.455219
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(0.1)
    with debug_time('debug_time'):
        time.sleep(0.1)

# Generated at 2022-06-24 05:44:10.476724
# Unit test for function color
def test_color():
    assert not color('x')
    colorama.init()
    settings.no_colors = False
    assert color('x') == 'x'

# Generated at 2022-06-24 05:44:17.907148
# Unit test for function confirm_text
def test_confirm_text():
    from colorama import init

    init()
    key = 'ahoj'
    side_effect = True
    confirm_text(key, side_effect)
    assert sys.stdout.getvalue() \
        == ">ahoj (+side effect) [enter/↑/↓/ctrl+c]\r\033[1K\r"
    side_effect = False
    confirm_text(key, side_effect)
    assert sys.stdout.getvalue() \
        == ">ahoj (+side effect) [enter/↑/↓/ctrl+c]\r\033[1K\r"

# Generated at 2022-06-24 05:44:22.278484
# Unit test for function debug
def test_debug():
    stdout = StringIO()
    sys.stderr = stdout
    debug('hi')
    result = stdout.getvalue()
    sys.stderr.write(result)
    assert result == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hi\n'

# Generated at 2022-06-24 05:44:24.644976
# Unit test for function already_configured
def test_already_configured():
    type(u'a')  # str for Python 2
    already_configured(type(u'a'))


# Generated at 2022-06-24 05:44:30.699576
# Unit test for function configured_successfully
def test_configured_successfully():
    out = configured_successfully(const.ConfigurationDetails(
        path='~/.bashrc',
        reload='source ~/.bashrc',
        content='eval "$(thefuck --alias)"',
        can_configure_automatically=True))
    assert out == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}source ~/.bashrc{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))


# Generated at 2022-06-24 05:44:32.400753
# Unit test for function exception
def test_exception():
    try:
        1/0
    except:
        exception('Test: ', sys.exc_info())

# Generated at 2022-06-24 05:44:34.560263
# Unit test for function color
def test_color():
    assert color('red') == '\x1b[31m'
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:44:37.124256
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.types import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=True,
        content='content',
        path='path',
        reload='reload'))

# Generated at 2022-06-24 05:44:40.030480
# Unit test for function version
def test_version():
    from .utils import get_version, python_version
    from .shells import Shell, get_shell_info
    s = Shell()

    for shell_info in ('zsh', 'bash'):
        assert version(get_version(),
                       python_version(),
                       get_shell_info(shell_info)) == None

# Generated at 2022-06-24 05:44:41.110586
# Unit test for function already_configured
def test_already_configured():
    already_configured('help')



# Generated at 2022-06-24 05:44:49.364695
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'RED') == colorama.Fore.RED + 'RED'
    assert color(colorama.Fore.RED + 'RED') != 'RED'
    assert color(colorama.Fore.RED + 'RED') != '\033[91m' + 'RED'
    assert color(colorama.Fore.RED + 'RED') ==\
        '\033[91m' + 'RED' if not settings.no_colors else ''
    settings.no_colors = True
    assert color(colorama.Fore.RED + 'RED') == ''

# Generated at 2022-06-24 05:44:56.818386
# Unit test for function exception
def test_exception():
    def test():
        x = 1
        y = 0
        z = x / y

    exc_info = None
    try:
        test()
    except Exception:
        exc_info = sys.exc_info()

    log = []
    sys.stderr = log
    exception('msg', exc_info)
    assert log[0].startswith(u'\x1b[41m[WARN] msg:\x1b[0m\n')
    assert log[-1] == u'\x1b[41m----------------------------\x1b[0m\n\n'

# Generated at 2022-06-24 05:45:01.008066
# Unit test for function warn
def test_warn():
    assert warn(u'RTFM') == u'\x1b[103m\x1b[30m\x1b[1m[WARN] RTFM\x1b[0m\n'



# Generated at 2022-06-24 05:45:08.656960
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import codecs
    import sys
    import unittest

    sys.stderr = codecs.getwriter('utf8')(sys.stderr)
    sys.stderr.errors = 'replace'
    command = u'sed s/foo/foo/'
    corrected_command = type('CorrectedCommand', (object,),
                             {'script': command, 'side_effect': False})
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + command + '\n'

    corrected_command = type('CorrectedCommand', (object,),
                             {'script': command, 'side_effect': True})
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:45:13.044691
# Unit test for function debug
def test_debug():
    import StringIO
    from contextlib import closing
    with closing(StringIO.StringIO()) as buf, closing(buf) as buf:
        sys.stderr = buf
        debug("test")
        assert buf.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-24 05:45:15.410055
# Unit test for function exception
def test_exception():
    def _exc():
        raise Exception("error message")

    try:
        _exc()
    except:
        exception("Fake", sys.exc_info())


# Generated at 2022-06-24 05:45:17.862704
# Unit test for function failed
def test_failed():
    failed("Failed")
    assert sys.stderr.getvalue() == u'\n\x1b[31mFailed\x1b[0m\n'


# Generated at 2022-06-24 05:45:21.606512
# Unit test for function already_configured
def test_already_configured():
    import os, tempfile
    tmp_file = tempfile.NamedTemporaryFile()
    configuration_details = { 'path' : tmp_file.name, 'reload' : 'source ' + tmp_file.name }
    already_configured(configuration_details)

# Generated at 2022-06-24 05:45:24.672228
# Unit test for function already_configured
def test_already_configured():
    configuration_details = 'source $HOME/.bashrc'
    already_configured(configuration_details)
    print(already_configured(configuration_details))


# Generated at 2022-06-24 05:45:27.254644
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-24 05:45:30.497153
# Unit test for function debug
def test_debug():
    from tests.utils import capture_output

    with capture_output() as (stdout, stderr):
        debug(u'foo')
    assert stdout.getvalue() == ''
    assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[21m\x1b[39m foo\n'


# Generated at 2022-06-24 05:45:38.710159
# Unit test for function debug_time
def test_debug_time():
    import mock

    class Context(object):
        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

    with mock.patch('thefuck.utils.datetime') as datetime_:
        datetime_.now.return_value = 2
        context = Context()
        with mock.patch('thefuck.utils.contextlib.contextmanager') as contextlib_:
            contextlib_.return_value = context
            with mock.patch('thefuck.utils.settings') as settings_:
                settings_.debug = True
                with debug_time('test_msg'):
                    pass
    datetime_.now.assert_called_with()
    contextlib_.assert_called_with()
    context.__enter__.assert_called_with()
    context

# Generated at 2022-06-24 05:45:41.846867
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException as e:
        exception('TestException', sys.exc_info())

# Generated at 2022-06-24 05:45:51.695837
# Unit test for function configured_successfully
def test_configured_successfully():
    import tempfile
    import os
    import shutil
    import platform
    import sys
    if platform.system().lower() in ['windows', 'darwin']:
        return

# Generated at 2022-06-24 05:45:56.598560
# Unit test for function already_configured
def test_already_configured():
    configuration_details = '~/.bashrc\n'
    assert already_configured(configuration_details) == print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=configuration_details.reload))

# Generated at 2022-06-24 05:46:04.333871
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from six import b

    out_buffer = StringIO()
    err_buffer = StringIO()

    sys.stdout = out_buffer
    sys.stderr = err_buffer

    try:
        failed(u'Something went wrong')
    finally:
        sys.stdout = sys.__stdout__
        sys.stderr = sys.__stderr__

    assert b('\x1b[31m') in err_buffer.getvalue()
    assert b('\x1b[0m') in err_buffer.getvalue()

# Generated at 2022-06-24 05:46:06.125175
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.main import Command
    show_corrected_command(Command('ls', ''))



# Generated at 2022-06-24 05:46:08.412753
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("alias fuck='eval $(thefuck $(fc -ln -1)); fc -R'")


# Generated at 2022-06-24 05:46:10.344859
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception('Fail', sys.exc_info())


# Generated at 2022-06-24 05:46:12.799992
# Unit test for function exception
def test_exception():
    title = "mytest"
    sys.stderr.write(u'[WARN] {title}\n'.format(
        title=title))

# Generated at 2022-06-24 05:46:23.500922
# Unit test for function version
def test_version():
    from . import __version__, platform
    from .types import ShellInfo
    from unittest import TestCase
    from unittest.mock import patch

    class VersionTest(TestCase):
        @patch('platform.python_version', lambda: '3.5.1')
        @patch('subprocess.check_output', lambda *args, **kwargs: 'shell')
        def test_version_message(self):
            with patch.object(sys, 'stderr') as stderr:
                version(__version__, platform.python_version(),
                        ShellInfo('shell', '', ''))
                self.assertTrue(stderr.write.called)
                self.assertEqual(stderr.write.call_count, 1)

# Generated at 2022-06-24 05:46:24.074478
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:46:26.821303
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError as e:
        exception(u'Test Exception', sys.exc_info())

# Generated at 2022-06-24 05:46:31.980082
# Unit test for function failed
def test_failed():
    from mock import patch
    from thefuck.utils import stderr

    mock_stderr = []

    with patch('sys.stderr', stderr(mock_stderr)):
        failed(u'Message')

    assert(u'Message\n' == mock_stderr[0][0])

# Generated at 2022-06-24 05:46:33.467452
# Unit test for function failed
def test_failed():
    def do_failed():
        failed(u'привет мир')
    assert do_failed() == None


# Generated at 2022-06-24 05:46:34.259496
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-24 05:46:35.825479
# Unit test for function confirm_text
def test_confirm_text():
	corrected_command = const.CorrectedCommand('script','side effect')
	confirm_text(corrected_command)

# Generated at 2022-06-24 05:46:37.851207
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.BLUE) == ''
    assert color(colorama.Fore.BLUE) != colorama.Fore.BLUE

# Generated at 2022-06-24 05:46:39.714603
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully({'reload': 'load ~/.bashrc'}) == None

# Generated at 2022-06-24 05:46:40.312197
# Unit test for function warn
def test_warn():
    pass


# Generated at 2022-06-24 05:46:42.133872
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        exception('test', sys.exc_info())

# Generated at 2022-06-24 05:46:42.759048
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass

# Generated at 2022-06-24 05:46:46.512914
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    stderr = sys.stderr = StringIO()
    warn(u'Hey')
    assert stderr.getvalue() == u'[WARN] Hey\n'
    stderr.close()


# Generated at 2022-06-24 05:46:48.016778
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('Error')
    except:
        exception(u'Title', sys.exc_info())

# Generated at 2022-06-24 05:46:50.085772
# Unit test for function already_configured
def test_already_configured():
    configuration_details = 'do'
    already_configured(configuration_details)

# Generated at 2022-06-24 05:46:55.324887
# Unit test for function version
def test_version():
    assert version('1.1', '2.7', 'zsh 4.3.9') == u'The Fuck 1.1 using Python 2.7 and zsh 4.3.9\n'
    assert version('3.8', '3.6', 'bash 3.2.57') == u'The Fuck 3.8 using Python 3.6 and bash 3.2.57\n'

# Generated at 2022-06-24 05:47:02.482077
# Unit test for function already_configured
def test_already_configured():
    import tempfile
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        already_configured(const.ConfigurationDetails(
            path=path,
            content='',
            reload='. ~/.bashrc'
        ))
    with open(path, 'r') as f:
        assert f.read() == \
            'Seems like \x1b[1mfuck\x1b[m alias already configured!\n' \
            'For applying changes run \x1b[1m. ~/.bashrc\x1b[m or restart your shell.\n'



# Generated at 2022-06-24 05:47:04.254572
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'echo 42',
        'side_effect': False})
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:47:04.930965
# Unit test for function failed
def test_failed():
    assert not failed("What the fuck?")


# Generated at 2022-06-24 05:47:08.714636
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    from thefuck.rules.git import match, get_new_command
    s = StringIO.StringIO()
    sys.stderr = s
    corrected_command = get_new_command('git commint', match('git commint'))
    show_corrected_command(corrected_command)
    sys.stderr.flush()
    val = s.getvalue()
    assert val == '> git commit\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:47:11.432429
# Unit test for function color
def test_color():
    assert color('bold') == 'bold'
    settings.no_colors = True
    assert color('bold') == ''
    settings.no_colors = False


# Generated at 2022-06-24 05:47:13.516773
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('test')
    except Exception:
        exception('msg', sys.exc_info())



# Generated at 2022-06-24 05:47:18.118921
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    import sys
    saved = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        warn("test")
        output = out.getvalue().strip()
        assert output == '[WARN] test'
    finally:
        sys.stderr = saved


# Generated at 2022-06-24 05:47:19.403242
# Unit test for function rule_failed
def test_rule_failed():
    exception(u'Rule Test',('', AssertionError('abc'), ''))

# Generated at 2022-06-24 05:47:29.268411
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from .utils import get_closest
    from .conf import Configurator
    from . import const

    class MockConfigurator(object):
        def __init__(self, shell_name, config_file_path, reload_cmd_str,
                     can_configure_automatically):
            self.shell_name = shell_name
            self.config_file_path = config_file_path
            self.reload_cmd_str = reload_cmd_str
            self.can_configure_automatically = can_configure_automatically


# Generated at 2022-06-24 05:47:34.428747
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('It is test exception')
    except Exception as e:
        exception('Test exception', sys.exc_info())
        assert 'Test exception' in sys.stderr.getvalue()
        assert '[WARN]' in sys.stderr.getvalue()
        assert 'It is test exception' in sys.stderr.getvalue()


# Generated at 2022-06-24 05:47:35.338875
# Unit test for function debug
def test_debug():
    debug(u'Foo')



# Generated at 2022-06-24 05:47:37.628973
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)



# Generated at 2022-06-24 05:47:38.222785
# Unit test for function configured_successfully
def test_configured_successfully():
    pass

# Generated at 2022-06-24 05:47:38.799886
# Unit test for function warn
def test_warn():
    warn("test")

# Generated at 2022-06-24 05:47:40.154941
# Unit test for function debug
def test_debug():
    debug('debug')
    assert 'debug' in sys.stderr.getvalue()

# Generated at 2022-06-24 05:47:41.897140
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == '\x1b[34m'
    assert color(u'foo') == 'foo'

# Generated at 2022-06-24 05:47:43.920632
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('hello'):
            pass
    except Exception as err:
        failed(err)

# Generated at 2022-06-24 05:47:46.380984
# Unit test for function configured_successfully
def test_configured_successfully():
    s = u"fuck alias configured successfully!\n"\
        u"For applying changes run or restart your shell."
    assert configured_successfully({"reload": "source ~/.bashrc"}) == (s)

# Generated at 2022-06-24 05:47:48.585838
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    try:
        raise Exception('Test')
    finally:
        return (u'Test took: {}'.format(datetime.now() - started) == debug_time)

# Generated at 2022-06-24 05:47:50.101678
# Unit test for function warn
def test_warn():
    import StringIO
    output = StringIO.StringIO()
    warn('Hey', file=output)
    assert output.getvalue() == '[WARN] Hey\n'



# Generated at 2022-06-24 05:47:53.639924
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls /usr/bin'
    show_corrected_command(corrected_command)

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-24 05:47:56.370490
# Unit test for function color
def test_color():
    colorama.init()
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''



# Generated at 2022-06-24 05:47:59.859419
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    with debug_time('test') as started:
        assert isinstance(started, datetime)
        assert datetime.now() - started < timedelta(seconds=1)

    debug_time._debug('test2')

# Generated at 2022-06-24 05:48:07.126650
# Unit test for function exception
def test_exception():
    error = RuntimeError("I'm exception")
    exc_info = sys.exc_info()
    exc_info = (type(error), error, error.__traceback__)
    bad_args = [1, 2, 3]
    try:
        (1, 2, 3) + bad_args
    except Exception:
        exc_info = sys.exc_info()
        exc_info = (type(error), error, error.__traceback__)
    exception("test_exception", exc_info)

# Generated at 2022-06-24 05:48:20.400934
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    import mock

    class TestRuleFailed(unittest.TestCase):
        @mock.patch('thefuck.shells.posix.Popen',
                    mock.Mock(side_effect=IOError('not implemented')))
        @mock.patch('sys.stderr', mock.Mock())
        def test_rule_failed_with_exception_show_exception(self):
            from thefuck.rules.echo import match, get_new_command
            sys.stderr.write = mock.Mock()
            sys.stderr.write.return_value = None

            exc_info = (None, None, None)

# Generated at 2022-06-24 05:48:26.850228
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.utils import get_shell_info
    from thefuck.types import ConfigurationDetails
    configuration_details = ConfigurationDetails(
        path='~/.zshrc',
        content='eval $(thefuck --alias)',
        reload='source ~/.zshrc',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    configuration_details.can_configure_automatically = False
    how_to_configure_alias(configuration_details)
    how_to_configure_alias(None)


# Generated at 2022-06-24 05:48:30.097409
# Unit test for function version
def test_version():
    """
    Test version function
    """
    sys.stderr.write(version(u'test_version', u'2.7', u'shell'))



# Generated at 2022-06-24 05:48:35.523578
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    with patch('thefuck.shells.common.settings') as settings_mock:
        settings_mock.debug = True
        with patch('thefuck.shells.common.debug') as debug_mock:
            with debug_time('foo'):
                pass
    debug_mock.assert_called_once_with(u'foo took: 0:00:00.000001')

# Generated at 2022-06-24 05:48:37.918895
# Unit test for function color
def test_color():
    assert color(u'test') == u'test'
    settings.no_colors = True
    assert color(u'test') == u''
    settings.no_colors = False

# Generated at 2022-06-24 05:48:41.051446
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import guess_shell
    import pytest

    with pytest.raises(SystemExit):
        show_corrected_command(None)



# Generated at 2022-06-24 05:48:42.771753
# Unit test for function color
def test_color():
    assert color(u'привет') == u'привет'

# Generated at 2022-06-24 05:48:44.096264
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED



# Generated at 2022-06-24 05:48:46.683854
# Unit test for function confirm_text
def test_confirm_text():
    correct_output = u'$ faaaa aaaaaaaaaa aaaaaaaa [+side effect] [enter/↑/↓/ctrl+c]'
    assert confirm_text(correct_output) == correct_output



# Generated at 2022-06-24 05:48:51.725181
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io as StringIO
    how_to_configure_alias(None)
    out = sys.stdout.getvalue().strip()
    sys.stdout = sys.__stdout__
    assert out == u'Seems like \x1b[1mfuck\x1b[21m alias isn\'t configured!'
    assert True


# Generated at 2022-06-24 05:48:56.810880
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(False) == 'Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.'

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-24 05:48:58.767498
# Unit test for function color
def test_color():
    assert not color("text")
    settings.no_colors = True
    assert color("text")



# Generated at 2022-06-24 05:49:03.356986
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.bash import BashRule
    rule = BashRule
    try:
        raise Exception()
    except Exception:
        rule_failed(rule, sys.exc_info())
        rule_failed(rule, sys.exc_info())


if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-24 05:49:07.795788
# Unit test for function failed
def test_failed():
    import mock
    from contextlib import contextmanager
    from thefuck.shells.bash import Bash
    from thefuck import config
    from thefuck.main import main
    from thefuck.types import Command

    def raise_exception(*args):
        raise Exception()

    mock_open = mock.mock_open()
    with mock.patch.object(config.__class__,
                           'from_pyproject',
                           return_value=config.Config()):
        with mock.patch('thefuck.rules.base') as mock_rules:
            mock_rules.get_corrected_commands.return_value = (
                lambda *args: raise_exception)

# Generated at 2022-06-24 05:49:11.921959
# Unit test for function failed
def test_failed():
    from .test_utils import captured_output
    with captured_output() as (out, err):
        failed(u'Some error')
    assert err.getvalue() == u'Some error\n'

# Generated at 2022-06-24 05:49:17.957961
# Unit test for function debug_time
def test_debug_time():
    def f():
        with debug_time('a'):
            pass
    import mock
    with mock.patch('thefuck.shells.get_shell.DEBUG', True):
        with mock.patch('sys.stderr') as mocked_stderr:
            f()
            assert any(u'DEBUG: a took:' in x[0][0] for x in mocked_stderr.write.mock_calls)

# Generated at 2022-06-24 05:49:24.939788
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .shells.posix import PosixShell

    assert how_to_configure_alias(Shell()) == \
        u"Seems like {bold}fuck{reset} alias isn't configured!\n"\
        u"More details - https://github.com/nvbn/thefuck#manual-installation"\
        .format(bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:49:29.179384
# Unit test for function rule_failed
def test_rule_failed():
    from .exceptions import FailedCommand
    from .rule import Rule

    rule = Rule(
        name='Foo',
        cmd_re='foo',
        match=lambda *args: True,
        side_effect=lambda *args: True)
    try:
        raise FailedCommand('bar')
    except FailedCommand:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:49:30.032633
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:49:35.110800
# Unit test for function confirm_text
def test_confirm_text():
    from . import corrector
    from .utils import get_closest

    corrected_command = corrector.CorrectedCommand(
        u'corrected', get_closest(u'corrected', [u'corrected']),
        side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:49:36.701040
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command="echo")

# Generated at 2022-06-24 05:49:38.896548
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc_info')
    rule_failed('rule', ('exc_info', 'exc_info', 'exc_info'))

# Generated at 2022-06-24 05:49:39.817346
# Unit test for function confirm_text
def test_confirm_text():
    raise NotImplementedError()

# Generated at 2022-06-24 05:49:41.240224
# Unit test for function debug
def test_debug():
    debug('Test message')



# Generated at 2022-06-24 05:49:45.316092
# Unit test for function confirm_text
def test_confirm_text():
    import io
    test_input_stream = io.StringIO(u"y\n")
    sys.stdin = test_input_stream
    import thefuck.main
    corrected_command = thefuck.main.Fuck()
    confirm_text(corrected_command)



# Generated at 2022-06-24 05:49:46.958384
# Unit test for function already_configured
def test_already_configured():
    already_configured("reload")


# Generated at 2022-06-24 05:49:49.696306
# Unit test for function color
def test_color():
    assert color('\x1b[31m')('foo') == '\x1b[31mfoo'
    assert color('')('foo') == 'foo'

# Generated at 2022-06-24 05:49:55.265805
# Unit test for function debug
def test_debug():
    from .conf import load_settings
    from .utils import wrap_settings
    wrap_settings(load_settings())

    settings.debug = True
    old_stderr = sys.stderr
    output = u''

    try:
        import StringIO
        stream = StringIO.StringIO()
        sys.stderr = stream
        debug(u"Debug message")
        output = stream.getvalue()
    finally:
        sys.stderr = old_stderr

    assert u'DEBUG: Debug message\n' == output

# Generated at 2022-06-24 05:49:57.390636
# Unit test for function version
def test_version():
    assert version(thefuck_version='1', python_version='2', shell_info='3') == None

# Generated at 2022-06-24 05:50:00.282682
# Unit test for function show_corrected_command
def test_show_corrected_command():
    ret_string = show_corrected_command('ls')
    assert ret_string == '\x1b[33m$ls\x1b[0m\n'



# Generated at 2022-06-24 05:50:02.849317
# Unit test for function configured_successfully
def test_configured_successfully():
    assert u'''fuck alias configured successfully!
For applying changes run source ~/.zshrc
or restart your shell.''' == \
        configured_successfully(configuration_details=None)

# Generated at 2022-06-24 05:50:06.873787
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys
    buffer = io.StringIO()
    sys.stderr = buffer
    corrected_command = const.CorrectedCommand(script='ls', side_effect=False)
    show_corrected_command(corrected_command)
    assert u'{prefix}ls{reset}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        reset=color(colorama.Style.RESET_ALL)) == buffer.getvalue()
    buffer.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:50:18.282729
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    def check_result(expected):
        out, err = capsys.readouterr()
        assert out == expected

    import pytest
    from collections import namedtuple

    ConfigurationDetails = namedtuple(
        'ConfigurationDetails',
        ['can_configure_automatically', 'path', 'content', 'reload']
    )

    with pytest.raises(SystemExit):
        how_to_configure_alias(None)
        check_result('Seems like \x1b[1mfuck\x1b[21m alias isn\'t configured!\n\
More details - https://github.com/nvbn/thefuck#manual-installation\n')


# Generated at 2022-06-24 05:50:25.558070
# Unit test for function warn
def test_warn():
    import os
    import tempfile
    out = tempfile.TemporaryFile()
    os.dup2(out.fileno(), sys.stderr.fileno())

    warn('Test')

    os.dup2(sys.__stderr__.fileno(), sys.stderr.fileno())
    out.seek(0)
    assert out.read() == '[WARN] Test\n'



# Generated at 2022-06-24 05:50:27.653171
# Unit test for function already_configured
def test_already_configured():
    assert already_configured.__name__ == 'already_configured'
    assert already_configured('test configuration') == None


# Generated at 2022-06-24 05:50:33.564597
# Unit test for function already_configured
def test_already_configured():
    import os
    from thefuck.utils import memoize
    from thefuck.shells import Shell

    class ConfigurationDetails(object):
        @property
        @memoize
        def reload(self):
            return 'reload'

    configuration_details = ConfigurationDetails()
    stdout_fd = os.open(os.devnull, os.O_RDONLY)
    os.dup2(stdout_fd, 1)
    try:
        already_configured(configuration_details)
    finally:
        os.dup2(1, stdout_fd)
        os.close(stdout_fd)


# Generated at 2022-06-24 05:50:36.381702
# Unit test for function debug
def test_debug():
    import StringIO
    sys.stderr = StringIO.StringIO()
    settings.debug = True
    debug('aaa')
    assert u'DEBUG: aaa\n' == sys.stderr.getvalue()
    settings.debug = False
    debug('bbb')
    assert u'DEBUG: aaa\n' == sys.stderr.getvalue()

# Generated at 2022-06-24 05:50:40.315584
# Unit test for function already_configured
def test_already_configured():
    import os
    import tempfile
    path = tempfile.mkdtemp()
    configuration_details = namedtuple('Config', ['path', 'reload'])(os.path.join(path, '.bashrc'), 'reload_command')
    already_configured(configuration_details)
    # assert True

# Generated at 2022-06-24 05:50:43.410580
# Unit test for function failed
def test_failed():
    import mock
    sys_stderr = sys.stderr
    sys.stderr = mock.Mock()
    failed("Test")
    assert sys.stderr.write.call_count == 1
    sys.stderr = sys_stderr

# Generated at 2022-06-24 05:50:55.490675
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from thefuck import utils
    from thefuck.utils import get_closest

    assert utils.conf.settings._replace(require_confirmation=False)

    configuration_details = get_closest('bash')

    fake_stdout = StringIO()
    fake_stderr = StringIO()
    sys.stdout = fake_stdout
    sys.stderr = fake_stderr

    configured_successfully(configuration_details)

    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:51:01.544141
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta

    class mytime(object):
        def __init__(self):
            self.count = 0

        def __call__(self):
            self.count += 1
            if self.count == 1:
                return datetime.now()
            else:
                return datetime.now() + timedelta(seconds=42)

    with debug_time('foo'):
        pass

    datetime_now = mytime()
    with debug_time('foo'):
        pass

# Generated at 2022-06-24 05:51:13.195606
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys
    from .rule import CorrectedCommand

    fake_stderr = io.StringIO()
    original_stderr = sys.stderr
    try:
        sys.stderr = fake_stderr
        command = CorrectedCommand('ls -l', '', True)
        show_corrected_command(command)
        assert (u'{prefix}{bold}{script}{reset}{side_effect}\n'
                .format(
                    prefix=const.USER_COMMAND_MARK,
                    script=command.script,
                    side_effect=u' (+side effect)',
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL))
                in fake_stderr.getvalue())
    finally:
        sys.st

# Generated at 2022-06-24 05:51:16.239951
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-24 05:51:17.951843
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(ConfigurationDetails('reload')) is None

# Generated at 2022-06-24 05:51:28.394333
# Unit test for function already_configured
def test_already_configured():
    from types import ModuleType

    class ConfigurationDetails(object):
        def __init__(self, reload):
            self.reload = reload

    class ShellInfo(object):
        def __init__(self, name):
            self.name = name
            self.config_script = '~/.config/fish/config.fish'
            self.reload_command = 'source {}'.format(self.config_script)

        def __str__(self):
            return u'Fish shell'

    class Settings(object):
        def __init__(self, no_colors):
            self.no_colors = no_colors

    settings = Settings(True)
    config_script = 'source ' + ShellInfo('fish').config_script

# Generated at 2022-06-24 05:51:38.541973
# Unit test for function warn
def test_warn():
    import sys
    from mock import patch
    from contextlib import contextmanager
    now = datetime.now()
    sys.stderr.write('\n')
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr,\
            patch('datetime.datetime') as mock_datetime:
        mock_datetime.now.return_value = now
        settings.no_colors = False
        warn('fail')
        settings.no_colors = True
        warn('fail')
        assert mock_stderr.getvalue() == \
            "[WARN] fail\n[WARN] fail\n"

# Generated at 2022-06-24 05:51:43.851696
# Unit test for function configured_successfully
def test_configured_successfully():
    # Test when thefuck is configured successfully
    class TestConfiguredSuccessfully(object):
        def __init__(self):
            self.reload = 'reload'
    configuration_details = TestConfiguredSuccessfully()
    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:51:44.826544
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('configured_successfully')

# Generated at 2022-06-24 05:51:47.985709
# Unit test for function confirm_text
def test_confirm_text():
    """ Unit test for function confirm_text """
    from .types import CorrectedCommand

    confirm_text(CorrectedCommand(
        script=u'ls -al',
        side_effect=False,
        costs=0))

# Generated at 2022-06-24 05:51:50.799183
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    output=StringIO.StringIO()
    sys.stderr=output
    rule_failed("rule",("exc_info"))
    assert sys.stderr.getvalue()==u'[WARN] Rule rule:\n\n'

# Generated at 2022-06-24 05:51:54.634770
# Unit test for function rule_failed
def test_rule_failed():
    rule_name = 'test_name'
    try:
        raise Exception()
    except:
        exc_info = sys.exc_info()
        rule_failed(TestRule(name=rule_name), exc_info=exc_info)


# Generated at 2022-06-24 05:52:00.190125
# Unit test for function warn
def test_warn():
    from cStringIO import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO()
    try:
        warn("a")
        sys.stderr.seek(0, 0)
        assert sys.stderr.read() == '\x1b[41m[WARN] a\x1b[0m\n'
    finally:
        sys.stderr = stdout


# Generated at 2022-06-24 05:52:08.508842
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from unittest.mock import MagicMock
    from .conf import settings

    settings.debug = True

    debug_time = MagicMock()
    debug = MagicMock()

    class Timedelta(timedelta):
        def total_seconds(self):
            return 0.5

    datetime.now = MagicMock(return_value=Timedelta())

    with debug_time('foo'):
        pass

    debug.assert_called_once_with(u'foo took: 0:00:00.500000')
    debug_time.assert_called_once_with('foo')

# Generated at 2022-06-24 05:52:11.120330
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    rule = Rule('test_rule1', '.*', '', '', None)
    try:
        raise Exception()
    except Exception:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:52:12.762904
# Unit test for function debug
def test_debug():
    sys.stderr = sys.stdout
    debug('msg')
#

# Generated at 2022-06-24 05:52:16.990869
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    import datetime
    from .app import debug
    from .conf import settings
    settings.debug = True
    @contextmanager
    def debug_time(msg):
        started = datetime.datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.datetime.now() - started))
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-24 05:52:19.787756
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    stdout = sys.stdout
    stdout.flush = lambda: None
    sys.stdout = io.StringIO()
    try:
        import io
    finally:
        sys.stdout = stdout

# Generated at 2022-06-24 05:52:22.229387
# Unit test for function warn
def test_warn():
    warn('title') == '\x1b[40m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'

# Generated at 2022-06-24 05:52:24.101034
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(CorrectedCommand(script='git pull', side_effect=False))



# Generated at 2022-06-24 05:52:27.744405
# Unit test for function version
def test_version():
    '''
    This unit test test version function
    '''
    version_result = version(
        thefuck_version='3.6',
        python_version='2.7',
        shell_info='Shell')
    # Check that version function return print
    assert version_result

# Generated at 2022-06-24 05:52:36.359017
# Unit test for function configured_successfully
def test_configured_successfully():
    from types import ModuleType
    from tests.utils import Mock

    sys = Mock()
    configuration_details = Mock(reload='reload')
    mock = Mock(**{'types.ModuleType': ModuleType,
                   'sys': sys,
                   'colorama.Style.BRIGHT': colorama.Style.BRIGHT,
                   'colorama.Style.RESET_ALL': colorama.Style.RESET_ALL})
    orig_sys = __import__('sys')
    builtins = __import__('__builtin__')
    builtins.__import__ = lambda *args: orig_sys if args[0] == 'sys' else mock

# Generated at 2022-06-24 05:52:40.295636
# Unit test for function warn
def test_warn():
    # Given warn message
    # When printing it
    warn('Some warn')
    # Then it should be printed with proper style
    assert sys.stderr.getvalue() == (
            u'{warn}[WARN] {title}{reset}\n'.format(
                warn=color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                title=u'Some warn'))