

# Generated at 2022-06-24 05:42:52.284825
# Unit test for function confirm_text
def test_confirm_text():
    test_corrected_command = const.CorrectedCommand('ls', False)
    test_confirm_text_want = u'\x1b[2K\r\x1b[1m\x1b[1mls\x1b[0m \x1b[92menter\x1b[0m/\x1b[94m↑\x1b[0m/\x1b[94m↓\x1b[0m/\x1b[91mctrl+c\x1b[0m'
    test_confirm_text_got = confirm_text(test_corrected_command)
    if test_confirm_text_want == test_confirm_text_got:
        print('confirm_text(test_corrected_command) is passed')

# Generated at 2022-06-24 05:43:02.967222
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO

    output = StringIO()
    sys.stderr = output
    from .conf import Configuration

    configuration_details = Configuration(
        reload='$ fuck',
        shell_type='shell',
        path='/home/user/.zshrc',
        content='alias fuck=\'eval $(thefuck $(fc -ln -1))\'')

    already_configured(configuration_details)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:43:06.660829
# Unit test for function debug
def test_debug():
    from tests.utils import capture_stderr
    with capture_stderr(lambda: debug('message')) as output:
        assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n'

# Generated at 2022-06-24 05:43:10.335567
# Unit test for function rule_failed
def test_rule_failed():
    import os
    import tempfile

    rule_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    rule_name = 'Test'

# Generated at 2022-06-24 05:43:21.875770
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'fuck\n') == \
        u'[The Fuck] fuck \n\033[1K\r[The Fuck] fuck [+side effect] [enter/↑/↓/ctrl+c]'
    assert confirm_text(u'fuck\n', True) == \
        u'[The Fuck] fuck\n\033[1K\r[The Fuck] fuck [+side effect] [enter/↑/↓/ctrl+c]'
    assert confirm_text(u'fuck\n', False) == \
        u'[The Fuck] fuck \n\033[1K\r[The Fuck] fuck [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:43:25.976863
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'content': 'content',
                             'path': 'path',
                             'reload': 'reload',
                             'can_configure_automatically': False}
    assert how_to_configure_alias(configuration_details) == None

# Generated at 2022-06-24 05:43:27.461269
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('alias configured successfully!') == \
           configured_successfully

# Generated at 2022-06-24 05:43:29.171079
# Unit test for function already_configured
def test_already_configured():
    configuration_details = ConfigurationDetails('reload')
    assert already_configured(configuration_details) is None

# Generated at 2022-06-24 05:43:30.918681
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE



# Generated at 2022-06-24 05:43:38.445974
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    corrected_command = Mock()
    corrected_command.script = '[Corrected command]'
    corrected_command.side_effect = False

# Generated at 2022-06-24 05:43:40.540320
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        import time
        time.sleep(0.5)

# Generated at 2022-06-24 05:43:43.388784
# Unit test for function failed
def test_failed():
    msg = u'test_failed'
    failed(msg)
    assert msg in sys.stderr.getvalue(), \
        'doesn\'t print message to stderr'

# Generated at 2022-06-24 05:43:47.316819
# Unit test for function already_configured
def test_already_configured():
    fn = open('./test.txt', 'w')
    try:
        already_configured('.bashrc')
        already_configured('.bashrc', fn)
    finally:
        fn.close()


# Generated at 2022-06-24 05:43:58.437274
# Unit test for function version
def test_version():
    import io
    import platform
    import sys
    import thefuck
    import thefuck.main

    sys_stdout = sys.stdout
    sys_stderr = sys.stderr
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

    try:
        thefuck.main.version(thefuck.__version__,
                             platform.python_version(),
                             thefuck.shells.shell_info())
    finally:
        res = sys.stderr.getvalue()
        sys.stdout = sys_stdout
        sys.stderr = sys_stderr


# Generated at 2022-06-24 05:44:03.313542
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('') == ''
    assert color('hello') == colorama.Fore.BLUE + 'hello' + colorama.Style.RESET_ALL
    settings.no_colors = True
    assert color('hello') == 'hello'
    assert color('hello') == 'hello'


if __name__ == '__main__':
    test_color()

# Generated at 2022-06-24 05:44:04.765335
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''

# Generated at 2022-06-24 05:44:05.566826
# Unit test for function warn
def test_warn():
    warn(u'Test warning')



# Generated at 2022-06-24 05:44:13.182941
# Unit test for function failed
def test_failed():
    try:
        sys.stdout.write(u'    ')
        sys.stdout.flush()
        failed(u'Not failed here')
    finally:
        sys.stdout.write(u'\033[1K\r')
        sys.stdout.flush()
    assert sys.stdout.read() == u'    \033[1K\r\x1b[31mNot failed here\x1b[0m\n'



# Generated at 2022-06-24 05:44:19.674479
# Unit test for function color
def test_color():
    assert colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT == color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT)
    assert colorama.Style.RESET_ALL == color(colorama.Style.RESET_ALL)
    assert '' == color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT)
    assert '' == color(colorama.Style.RESET_ALL)

# Generated at 2022-06-24 05:44:24.357793
# Unit test for function version
def test_version():
    from click.testing import CliRunner
    from thefuck.main import main

    runner = CliRunner()
    version = '3.15.4'
    result = runner.invoke(main, ['--version'], catch_exceptions=False)

    assert result.exit_code == 0
    assert version in result.output



# Generated at 2022-06-24 05:44:25.861929
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-24 05:44:30.547972
# Unit test for function warn
def test_warn():
    from StringIO import StringIO

    out = StringIO()
    temp_stderr, sys.stderr = sys.stderr, out
    try:
        warn('foo')
        assert u'[WARN] foo\n' == out.getvalue()
    finally:
        sys.stderr = temp_stderr



# Generated at 2022-06-24 05:44:33.645471
# Unit test for function failed
def test_failed():
    failed('test_failed')
    assert sys.stderr.getvalue() == '\x1b[31mtest_failed\x1b[0m\n'



# Generated at 2022-06-24 05:44:35.827927
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'
    settings.no_colors = True

# Generated at 2022-06-24 05:44:38.096935
# Unit test for function exception
def test_exception():
    from unittest.mock import Mock
    exc_info = sys.exc_info()
    try:
        raise ValueError('error')
    except ValueError:
        exception('foo', exc_info)



# Generated at 2022-06-24 05:44:41.137014
# Unit test for function debug
def test_debug():
    import mock
    import tempfile

    with mock.patch.object(sys, 'stderr', tempfile.TemporaryFile()):
        debug('msg')

    with mock.patch.object(sys, 'stderr', tempfile.TemporaryFile()):
        with settings.override(debug=False):
            debug('msg')

# Generated at 2022-06-24 05:44:47.645412
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED + 'RED') == \
        colorama.Back.RED + 'RED'
    assert color(colorama.Fore.RED + 'RED') == \
        colorama.Fore.RED + 'RED'
    assert color(colorama.Style.BRIGHT + 'BRIGHT') == \
        colorama.Style.BRIGHT + 'BRIGHT'

# Generated at 2022-06-24 05:44:50.097031
# Unit test for function color
def test_color():
    assert u'\x1b[0m' == color(u'')
    assert u'' == color(colorama.Style.RESET_ALL)



# Generated at 2022-06-24 05:44:52.677734
# Unit test for function how_to_configure_alias

# Generated at 2022-06-24 05:45:00.910837
# Unit test for function confirm_text
def test_confirm_text():
    # For test, change get_char() to yield '\n'
    from .utils import get_char
    original_get_char = get_char
    try:
        from .utils import get_char
        get_char = lambda: '\n'
        from .main import confirm
        import os
        import tempfile
        history_file = tempfile.mktemp()
        with open(history_file, 'w'): pass
        HISTFILE = os.environ.get('HISTFILE')
        os.environ['HISTFILE'] = history_file
        confirm(['echo'], {}, {}, {}, False)
        # If no exception is raised, this test passed
        os.environ['HISTFILE'] = HISTFILE
    finally:
        get_char = original_get_char

# Generated at 2022-06-24 05:45:04.402789
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='exec bash',
        can_configure_automatically=False))
    #assert True

# Generated at 2022-06-24 05:45:09.804140
# Unit test for function exception
def test_exception():
    def stdout_replaced():
        sys.stdout = open('/dev/null', 'w')
        try:
            exception('title', ('type', 'value', 'traceback'))
        finally:
            sys.stdout = sys.__stdout__

    # Ensure sys.stdout is not replaced
    assert stdout_replaced() is None

# Generated at 2022-06-24 05:45:11.486018
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("configuration_details") is None
    assert 1 == 1



# Generated at 2022-06-24 05:45:19.721532
# Unit test for function already_configured
def test_already_configured():
    from sys import version_info
    from thefuck.utils import py2_to_py3
    shell_info = u'Shell for unit test'
    expected_output = (
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.")
    expected_output = expected_output.format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        reload=shell_info)
    if version_info[0] == 3:
        if sys.stderr != sys.stdout:
            print(expected_output)
    else:
        expected_output = py2_to_py3(expected_output)

# Generated at 2022-06-24 05:45:31.099664
# Unit test for function debug
def test_debug():
    '''
    >>> import logging
    >>> logger = logging.getLogger('thefuck')

    >>> import StringIO
    >>> import sys
    >>> old_stderr = sys.stderr
    >>> sys.stderr = StringIO.StringIO()

    >>> debug('Fluttershy')
    >>> old_stderr.write(sys.stderr.getvalue())
    DEBUG: Fluttershy

    >>> old_stderr = sys.stderr
    >>> sys.stderr = StringIO.StringIO()
    >>> settings.debug = False
    >>> debug('Fluttershy')
    >>> sys.stderr.getvalue() == ''
    True

    >>> sys.stderr = old_stderr
    '''
    pass


# Generated at 2022-06-24 05:45:33.477695
# Unit test for function exception
def test_exception():
    exc_info = ('foo', 'bar')
    exception('Error', exc_info)


# Generated at 2022-06-24 05:45:34.935238
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test_debug'):
        time.sleep(0.1)

# Generated at 2022-06-24 05:45:37.654797
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = corrected_command.CorrectedCommand(script='echo "hi"',
                                                           side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:45:40.955129
# Unit test for function already_configured
def test_already_configured():
    already_configured(const.ConfigurationDetails(
        path=None,
        can_configure_automatically=False,
        reload=None))



# Generated at 2022-06-24 05:45:43.502196
# Unit test for function failed
def test_failed():
    # Check whether function call fails
    try:
        failed ("Test for failed function")
        assert True
    except:
        assert False


# Generated at 2022-06-24 05:45:47.739417
# Unit test for function failed
def test_failed():
    sys.stderr = open("log.txt", "w")
    failed("Error")
    sys.stderr.close()
    with open("log.txt", "r") as file:
        assert file.read() == "\x1b[31mError\x1b[0m\n"


# Generated at 2022-06-24 05:45:50.052898
# Unit test for function version
def test_version():
    version('1', '2', '3')
    assert sys.stderr.getvalue() == (
        u'The Fuck 1 using Python 2 and 3\n')

# Generated at 2022-06-24 05:45:52.854671
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False



# Generated at 2022-06-24 05:45:58.374776
# Unit test for function warn
def test_warn():
    from .test_utils import capture_stderr
    with capture_stderr() as stderr:
        warn('Title')
        assert '\x1b[41m\x1b[37m\x1b[1m[WARN] Title\x1b[0m\n' == stderr.getvalue()



# Generated at 2022-06-24 05:46:01.833091
# Unit test for function failed
def test_failed():
    from .conf import Const
    test_msg = 'test_msg'
    failed(test_msg)
    assert Const.RED + test_msg + Const.RESET + '\n' == sys.stderr.getvalue()

# Generated at 2022-06-24 05:46:04.471165
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Rule
    rule = Rule(u'a name', lambda x, y: None, u'a description')
    rule_failed(rule, Exception)

# Generated at 2022-06-24 05:46:08.507407
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    reload(sys)
    sys.setdefaultencoding('utf-8')
    sys.stdout = mystdout = StringIO()
    confirm_text(CorrectedCommand('command', None))
    output = mystdout.getvalue()
    assert output == u'$fuck\033[1K\r$command []\033[1K\r'

# Generated at 2022-06-24 05:46:10.025534
# Unit test for function version
def test_version():
    version('3.0', '2.7.10', 'shell')



# Generated at 2022-06-24 05:46:11.546111
# Unit test for function color
def test_color():
    assert settings.no_colors is True
    assert color('') == ''



# Generated at 2022-06-24 05:46:13.481737
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:46:15.391349
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.conf import Config

    assert confirm_text(Config('ls', '')) == None

# Generated at 2022-06-24 05:46:25.910571
# Unit test for function warn
def test_warn():
    colorama.init(autoreset=True)

# Generated at 2022-06-24 05:46:31.873354
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    command = "ls -alh"
    show_corrected_command(command)
    assert sys.stderr.getvalue() == '{}ls -alh\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.close()

# Generated at 2022-06-24 05:46:34.403235
# Unit test for function failed
def test_failed():
    failed(u'Проверка отображения сообщений в консоль в красном цвете')

# Generated at 2022-06-24 05:46:36.871631
# Unit test for function already_configured
def test_already_configured():
    name = "configuration_details"
    configuration_details = namedtuple(name, "reload")
    configuration_details.reload = "reload"
    already_configured(configuration_details)

# Generated at 2022-06-24 05:46:37.970539
# Unit test for function warn
def test_warn():
    assert warn('Title') == "[WARN] Title\n"


# Generated at 2022-06-24 05:46:42.346506
# Unit test for function color
def test_color():
    assert not settings.no_colors
    assert color(u'\x1b[0m') == u'\x1b[0m'

    settings.no_colors = True
    assert color(u'\x1b[0m') == ''



# Generated at 2022-06-24 05:46:46.500418
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import contextlib
    output = StringIO.StringIO()
    with contextlib.redirect_stdout(output):
        show_corrected_command(u'ls -la')
        assert output.getvalue() == u"$ ls -la\r\n"


# Generated at 2022-06-24 05:46:47.316924
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Testing'):
        pass

# Generated at 2022-06-24 05:46:49.524307
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)


if __name__ == '__main__':
    test_already_configured()

# Generated at 2022-06-24 05:46:50.700097
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:46:54.311439
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass

# Generated at 2022-06-24 05:46:55.758712
# Unit test for function warn
def test_warn():
    title = 'test'
    warn(title)



# Generated at 2022-06-24 05:46:57.141492
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass



# Generated at 2022-06-24 05:46:58.722990
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import wrap_line
    assert confirm_text(wrap_line('test')) == '>test [enter/↑/↓/ctrl+c] : '

# Generated at 2022-06-24 05:47:00.689080
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:47:01.261217
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-24 05:47:05.490019
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("rule", "exc_info")


if __name__ == '__main__':
    test_rule_failed()
    show_corrected_command("corrected_command")
    confirm_text("corrected_command")

# Generated at 2022-06-24 05:47:12.392914
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import colorama
    colorama.init()
    command_script = 'pwd'
    corrected_command = mock_corrected_command(command_script)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{0}{2}{3}pwd{1}\n'.format(const.USER_COMMAND_MARK, colorama.Style.RESET_ALL, colorama.Style.BRIGHT,'')


# Generated at 2022-06-24 05:47:18.532040
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text('fuck') ==
            u'\200b\033[1K\r\x1b[01mfuck\x1b[0m [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/'
            u'\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]')

# Generated at 2022-06-24 05:47:27.863581
# Unit test for function rule_failed
def test_rule_failed():  # pylint: disable=too-few-public-methods
    class MyTestException(BaseException):
        pass

    class MyRule(object):
        name = 'my-rule'

    rule_failed(MyRule(), sys.exc_info())
    rule_failed(MyRule(), sys.exc_info())
    rule_failed(MyRule(), sys.exc_info())
    sys.stderr.truncate(0)
    try:
        1 / 0
    except ZeroDivisionError:
        rule_failed(MyRule(), sys.exc_info())
    try:
        raise MyTestException('this is test')
    except MyTestException:
        rule_failed(MyRule(), sys.exc_info())

# Generated at 2022-06-24 05:47:30.691323
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from ..conf import settings
    settings.no_colors = False
    confirm_text('a'*80)



# Generated at 2022-06-24 05:47:34.531021
# Unit test for function exception
def test_exception():
    with open('thefuck/tests/output.txt', 'w') as output:
        try:
            raise ValueError('test')
        except:
            exception('Error', sys.exc_info())
            output.writelines(sys.stderr.getvalue())

# Generated at 2022-06-24 05:47:37.364307
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-24 05:47:45.268245
# Unit test for function version
def test_version():
    import re
    out_text = ''
    version_pattern = re.compile(
        r'The Fuck \d+\.\d+\.\d+ using Python \d+\.\d+ and .+')
    sys.stderr.write = lambda *args: out_text.__add__(''.join(*args))
    version(thefuck_version='1.1.1', python_version='2.7',
            shell_info='bash')
    assert version_pattern.match(out_text) is not None
    out_text = ''
    version(thefuck_version='1.2.3', python_version='2.7.1',
            shell_info='zsh')
    assert version_pattern.match(out_text) is not None



# Generated at 2022-06-24 05:47:56.919605
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import colorama
    from thefuck.utils import confirm_text

    # mock setup
    sys.stderr = mock.MagicMock()
    colorama.init = mock.MagicMock()

    # mock e
    def e(s):
        return s
    colorama.Fore.BLUE = e
    colorama.Fore.RED = e
    colorama.Fore.GREEN = e
    colorama.Style.BRIGHT = e
    colorama.Style.RESET_ALL = e

    # test
    confirm_text(mock.Mock(script='ls', side_effect=True))
    confirm_text(mock.Mock(script='ls', side_effect=False))
    confirm_text(mock.Mock(script='ls --la', side_effect=False))
    confirm_text

# Generated at 2022-06-24 05:47:58.797232
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE + 'foo') == colorama.Fore.BLUE + 'foo'



# Generated at 2022-06-24 05:48:09.183703
# Unit test for function configured_successfully
def test_configured_successfully():
    # setup
    from io import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO()
    import fuck
    configuration_details = fuck.conf.ConfigurationDetails(
        can_configure_automatically=False,
        reload='reload',
        path='path',
        content='content')

    # exercise
    configured_successfully(configuration_details)

    # verify
    assert mystdout.getvalue() == \
        u"{bold}fuck{reset} alias configured successfully!\n" \
            u"For applying changes run {bold}reload{reset}" \
            u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

   

# Generated at 2022-06-24 05:48:11.636548
# Unit test for function warn
def test_warn():
    assert u'[WARN] title\n' == \
        warn('title')

# Generated at 2022-06-24 05:48:18.434530
# Unit test for function debug_time
def test_debug_time():
    def foo():
        with debug_time(u'foo'):
            pass

    orig_stderr = sys.stderr
    try:
        from io import StringIO
        sys.stderr = StringIO()
        foo()
        assert u'foo took: 0:00:00.00' in sys.stderr.getvalue()
    finally:
        sys.stderr = orig_stderr

# Generated at 2022-06-24 05:48:19.961398
# Unit test for function debug
def test_debug():
    assert debug('test_debug') == None, "wrong output"


# Generated at 2022-06-24 05:48:28.086548
# Unit test for function debug_time
def test_debug_time():
    from tempfile import mkstemp
    from os import remove, close
    from contextlib import closing
    import logging
    import re

    with closing(mkstemp()[0]) as f:
        logger = logging.getLogger('thefuck')
        handler = logging.FileHandler(f)
        handler.setLevel(logging.DEBUG)
        logger.addHandler(handler)
        logger.setLevel(logging.DEBUG)
        with debug_time('foo'):
            pass
        logger.removeHandler(handler)
        with open(f) as handler:
            assert bool(re.match(r'debug: foo took: \d{2}:\d{2}:\d{2}\.\d{6}',
                                 handler.readline()))

# Generated at 2022-06-24 05:48:29.128867
# Unit test for function warn
def test_warn():
    warn('test_title')


# Generated at 2022-06-24 05:48:34.972848
# Unit test for function debug
def test_debug():
    # Base case
    err = u''
    with debug_time('debug'):
        debug(u'hello world')
    assert err in sys.stderr.getvalue()

    # Test err output
    err = u'hello world took: 0:00:00.000001\n'
    with debug_time('hello world'):
        pass
    assert err in sys.stderr.getvalue()



# Generated at 2022-06-24 05:48:37.511104
# Unit test for function failed
def test_failed():
    failed('hello')
    assert sys.stderr.getvalue() == u'\x1b[31mhello\x1b[0m\n'



# Generated at 2022-06-24 05:48:40.258888
# Unit test for function rule_failed
def test_rule_failed():
    rule = "tets_rule"
    rule_failed(rule, "test_exception")
    #Do you want to test this function again?

# Generated at 2022-06-24 05:48:41.609594
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(how_to_configure_alias('t'))


# Generated at 2022-06-24 05:48:46.128417
# Unit test for function debug_time
def test_debug_time():
    from io import StringIO
    from contextlib import redirect_stderr
    import time
    import re

    with redirect_stderr(StringIO()) as f:
        with debug_time(u'foo'):
            time.sleep(.01)
    assert re.match(r'DEBUG: foo took: \d+ms\n', f.getvalue())

# Generated at 2022-06-24 05:48:46.724146
# Unit test for function debug
def test_debug():
    debug('42')

# Generated at 2022-06-24 05:48:48.841594
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-24 05:48:52.372732
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(
        'git push origin master') == (u'{prefix}git push origin master'.
                                      format(prefix=const.USER_COMMAND_MARK))



# Generated at 2022-06-24 05:48:59.703245
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'123')
    assert sys.stderr.getvalue() == (u"\x1b[34m\x1b[1mDEBUG:\x1b[0m 123\n")

    settings.debug = False
    debug(u'123')
    assert sys.stderr.getvalue() == (u"\x1b[34m\x1b[1mDEBUG:\x1b[0m 123\n")



# Generated at 2022-06-24 05:49:05.441117
# Unit test for function failed
def test_failed():
    class Stream:
        def __init__(self):
            self.value = ''

        def write(self, value):
            self.value += value

    stream = Stream()
    sys.stderr = stream
    failed(u'msg')
    sys.stderr = sys.__stderr__
    assert stream.value == u'\x1b[31mmsg\x1b[0m\n'

# Generated at 2022-06-24 05:49:08.354230
# Unit test for function warn
def test_warn():
    assert warn('test') == '\x1b[40m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'


# Generated at 2022-06-24 05:49:15.631084
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from . import rules
    old = sys.stderr
    try:
        # Save stdout to StringIO
        sys.stderr = StringIO()

        # call function failed
        failed("Test")

        # assert result
        result = sys.stderr.getvalue()
        assert result == u'\x1b[31mTest\x1b[0m\n'

    finally:
        sys.stderr = old

# Generated at 2022-06-24 05:49:17.513371
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'corrected_command'
    with show_corrected_command(corrected_command):
        pass

# Generated at 2022-06-24 05:49:20.347717
# Unit test for function debug
def test_debug():
    class LocalSettings(object):
        debug = True

    with debug_time('debug'):
        debug('msg')
        debug('msg')


# Generated at 2022-06-24 05:49:22.840427
# Unit test for function failed
def test_failed():
    failed(u"Нихуя не работает!")



# Generated at 2022-06-24 05:49:24.606932
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        exception('test', sys.exc_info())

# Generated at 2022-06-24 05:49:28.771294
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    test_rule = type(
        'TestRule',
        (object,),
        {
            "name": "test",
            "match": match,
            "get_new_command": get_new_command})()
    rule_failed(test_rule, sys.exc_info())

# Generated at 2022-06-24 05:49:31.893659
# Unit test for function exception
def test_exception():
    def a_func():
        c_func()

    def b_func():
        a_func()

    def c_func():
        raise RuntimeError('test')

    try:
        b_func()
    except RuntimeError as e:
        exception('test', sys.exc_info())


# Generated at 2022-06-24 05:49:33.390199
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('test rule', ('test exception', 'test err', 'test traceback'))

# Generated at 2022-06-24 05:49:37.941524
# Unit test for function color
def test_color():
    class side_effect(object):
        def __getattr__(self, key):
            return key

    settings.no_colors = True
    assert color(side_effect()) == ''

    settings.no_colors = False
    assert color(side_effect()) == 'RED'

# Generated at 2022-06-24 05:49:41.545665
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells.base import Command

    show_corrected_command(Command('ls', 'ls -1a --color=always', True))
    show_corrected_command(Command('git', 'git push origin master', False))

# Generated at 2022-06-24 05:49:44.764696
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -lath', ''))
    show_corrected_command(CorrectedCommand('git branch', 'git branch +'))

# Generated at 2022-06-24 05:49:51.771791
# Unit test for function version
def test_version():
    from StringIO import StringIO

    thefuck_version = '3.11'
    python_version = '3.4'
    shell_info = 'bash'
    output = StringIO()
    sys.stderr = output
    version(thefuck_version, python_version, shell_info)
    assert output.getvalue().strip() ==\
        'The Fuck 3.11 using Python 3.4 and bash'



# Generated at 2022-06-24 05:49:56.149894
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = Command('ls')
    confirm_text(corrected_command)
    corrected_command = Command('ls', side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:50:00.392900
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'path': '~/.bash_profile',
                             'content': "eval $(thefuck --alias)",
                             'reload': 'source ~/.bash_profile'}
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-24 05:50:05.295227
# Unit test for function failed
def test_failed():
    from io import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO()
    failed(u'Another message')
    result = sys.stderr.getvalue().strip()
    sys.stderr.close()
    sys.stderr = stdout
    assert result == u'\x1b[31mAnother message\x1b[0m'



# Generated at 2022-06-24 05:50:11.790511
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    saved_output = sys.stderr
    try:
        sys.stderr = output = StringIO()

        debug(u'test')
        assert output.getvalue().strip() == (u'\x1b[34m\x1b[1mDEBUG:\x1b[0m '
                                             u'test')

        debug(u'test again')
        assert output.getvalue().strip() == (u'\x1b[34m\x1b[1mDEBUG:\x1b[0m '
                                             u'test\n'
                                             u'\x1b[34m\x1b[1mDEBUG:\x1b[0m '
                                             u'test again')

    finally:
        sys.stderr = saved_output

# Generated at 2022-06-24 05:50:13.462056
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {}
    configured_successfully(**configuration_details)

# Generated at 2022-06-24 05:50:14.970680
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("ls -l") == None


# Generated at 2022-06-24 05:50:16.834985
# Unit test for function debug
def test_debug():
    with settings.override_settings(debug=True):
        debug('msg')

# Generated at 2022-06-24 05:50:18.618493
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.CONFIG_DETAILS_BY_SHELL[u'bash'])

# Generated at 2022-06-24 05:50:21.286190
# Unit test for function already_configured
def test_already_configured():
    configuration_details = "reload"
    already_configured(configuration_details)


# Generated at 2022-06-24 05:50:31.196400
# Unit test for function show_corrected_command
def test_show_corrected_command():  # pragma: no cover
    import os
    import shutil
    import tempfile
    from .shells import Shell

    class Fake:
        @staticmethod
        def script():
            return 'test'

        @staticmethod
        def side_effect():
            return 'test'
    with tempfile.NamedTemporaryFile('w') as tmp:
        shell = Shell(tmp.name, tmp.name)
        os.environ['SHELL'] = "bash"
        show_corrected_command(Fake())
        os.environ['SHELL'] = "zsh"
        show_corrected_command(Fake())
        os.environ['SHELL'] = "cmd"
        show_corrected_command(Fake())
        os.environ['SHELL'] = "cmd"
        show_corrected_command(Fake())

# Generated at 2022-06-24 05:50:32.189914
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == None



# Generated at 2022-06-24 05:50:39.164307
# Unit test for function exception
def test_exception():
    """
        Test the exception function.
        >>> import StringIO
        >>> output = StringIO.StringIO()
        >>> sys.stderr = output
        >>> exception('test', ('test', 'test', 'test'))
        >>> sys.stderr = sys.__stderr__
        >>> output.seek(0)
        >>> output.read()
        '[WARN] test:\\n  File "<string>", line 1, in <module>\\n    test\\n[WARN] ----------------------------\\n\\n'
    """
    pass

# Generated at 2022-06-24 05:50:48.999051
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO

    import os

    from .shells.bash import reload_bash
    from .shells.zsh import reload_zsh
    from .shells.fish import reload_fish

    for reload_function in [reload_bash, reload_zsh, reload_fish]:
        f = StringIO()
        settings.configured_successfully_message = True
        settings.auto_confirm = True
        configuration_details = reload_function(None, None)
        configured_successfully(configuration_details)
        assert f.getvalue() == 'fuck alias configured successfully!\n' \
                               'For applying changes run source ~/.bashrc\n'
        f.close()


# Generated at 2022-06-24 05:51:00.113852
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    from .conf import settings

    settings.no_colors = False
    out = StringIO.StringIO()
    sys.stderr, save = out, sys.stderr
    try:
        confirm_text(None)
    finally:
        sys.stderr = save
    assert out.getvalue().startswith(
        u'\x01\033[1K\r\x1b[1m\x1b[32menter\x1b[0m/\x1b[34m\u2191\x1b[0m'
        u'/\x1b[34m\u2193\x1b[0m/\x1b[31mctrl+c\x1b[0m]')

    settings.no_colors = True
    out = StringIO

# Generated at 2022-06-24 05:51:06.016728
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock

    with mock.patch('thefuck.shells.common.debug') as debug_mock:
        with debug_time(msg='test'):
            time.sleep(0.1)
            assert debug_mock.call_count == 0
        debug_mock.assert_called_once_with('test took: 0:00:00.100000')

# Generated at 2022-06-24 05:51:08.320495
# Unit test for function debug_time
def test_debug_time():
    with debug_time('function foo'):
        __debug_time = datetime.now()
        pass
    return __debug_time

# Generated at 2022-06-24 05:51:17.076407
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .reloader import ConfigurationDetails
    import sys
    import StringIO
    from .conf import settings
    from . import const

    __stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    settings.no_colors = True

    how_to_configure_alias(None)
    assert sys.stdout.getvalue() == (
        u"Seems like fuck alias isn't configured!\n")

    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=False,
        path=u"path",
        content=u"content",
        reload=u"reload"))

# Generated at 2022-06-24 05:51:18.153986
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:51:21.767877
# Unit test for function failed
def test_failed():
    from StringIO import StringIO

    out = StringIO()
    sys.stderr = out
    failed("Test")
    sys.stderr = sys.__stderr__
    assert out.getvalue().strip() == "Test"

# Generated at 2022-06-24 05:51:29.958501
# Unit test for function version
def test_version():
    fuck_version, python_version, shell_info = '1.0', '2.7', 'Terminal'
    from cStringIO import StringIO
    last_stdout = sys.stdout
    output = StringIO()
    try:
        sys.stdout = output
        version(fuck_version, python_version, shell_info)
        sys.stdout.seek(0)
        out = sys.stdout.read()
        output_string = u'The Fuck {} using Python {} and {}\n'.format(fuck_version, python_version, shell_info)
        assert out == output_string
    finally:
        sys.stdout = last_stdout

# Generated at 2022-06-24 05:51:41.691139
# Unit test for function exception
def test_exception():
    import StringIO
    from mock import patch

    with patch('sys.stderr', new_callable=StringIO.StringIO) as mock_stderr:
        try:
            raise IOError('lol')
        except:
            exception(u'title', sys.exc_info())


# Generated at 2022-06-24 05:51:48.992957
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(configuration_details) == "Seems like" \
                                                            "fuck" \
                                                            "alias isn't configured! Please put" \
                                                            "fuck --alias in your ".lower() \
                                                        + "{path} and apply changes with {reload} or restart your shell. " \
                                                        + "Or run fuck a second time to configure it automatically. " \
                                                        + "More details - https://github.com/nvbn/thefuck#manual-installation"


# Generated at 2022-06-24 05:51:51.928367
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Rule
    rule = Rule()
    rule.name = 'Test'
    try:
        raise RuntimeError('test')
    except RuntimeError as e:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:51:52.543194
# Unit test for function debug_time
def test_debug_time():
    pass

# Generated at 2022-06-24 05:52:01.931614
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    import sys
    import thefuck.shells.bash
    import thefuck.utils
    from datetime import datetime
    import colorama

    thefuck.shells.bash.and_ = mock.Mock(return_value='and')
    thefuck.shells.bash.to = mock.Mock(return_value='to')
    thefuck.shells.bash.get_aliases = mock.Mock(return_value={})

    corrected_command = thefuck.shells.bash.Bash('cd',
                                                'cd /home/nvbn',
                                                [],
                                                datetime(2010, 1, 1, 1, 1))


# Generated at 2022-06-24 05:52:04.386117
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert color('') == ''
    assert color('\033[1K\r') != ''
    assert colorama.Back.RED + colorama.Fore.WHITE \
        + colorama.Style.BRIGHT != ''

# Generated at 2022-06-24 05:52:08.333196
# Unit test for function debug
def test_debug():
    settings.debug = True
    result = debug('lol')
    assert result is None
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m lol\n'


# Generated at 2022-06-24 05:52:09.270017
# Unit test for function warn
def test_warn():
    warn()
    assert 1 == 1

# Generated at 2022-06-24 05:52:16.633637
# Unit test for function confirm_text
def test_confirm_text():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    def get_confirm_text(corrected_command):
        sys.stderr.write = lambda s: None
        confirm_text(corrected_command)
        return sys.stderr.getvalue()


# Generated at 2022-06-24 05:52:18.078513
# Unit test for function already_configured
def test_already_configured():
    already_configured("alias fuck='eval $(thefuck $(fc -ln -1))'")

# Generated at 2022-06-24 05:52:19.385224
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('cmd') == u'$cmd\n'

# Generated at 2022-06-24 05:52:20.641762
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(u'Sorry, I don\'t support that shell.') is None

# Generated at 2022-06-24 05:52:21.600863
# Unit test for function warn
def test_warn():
    warn('test warn')



# Generated at 2022-06-24 05:52:25.384529
# Unit test for function failed
def test_failed():
    import mock
    with mock.patch('sys.stderr') as stderr:
        failed('Foo')
        assert stderr.write.called
        assert stderr.write.call_args[0][0].startswith(color(colorama.Fore.RED))

# Generated at 2022-06-24 05:52:34.745052
# Unit test for function confirm_text
def test_confirm_text():
    from io import BytesIO
    from . import ui
    from .conf import Config
    from .types import CorrectedCommand
    from .utils import wrap_result
    from .utils.debug import log_input

    command_script = 'git push --force origin master'
    corrected_command = CorrectedCommand(message='', script=command_script,
                                        side_effect=True)
    with wrap_result(lambda: confirm_text(corrected_command)) as log:
        log_input(command_script)


# Generated at 2022-06-24 05:52:41.242290
# Unit test for function warn
def test_warn():
    import io
    stream = io.StringIO()
    old_stderr = sys.stderr
    sys.stderr = stream
    try:
        warn('test')
    finally:
        sys.stderr = old_stderr
        assert stream.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'



# Generated at 2022-06-24 05:52:43.096079
# Unit test for function exception
def test_exception():
    try:
        raise Exception('inner')
    except:
        exception('outer', sys.exc_info())



# Generated at 2022-06-24 05:52:49.576855
# Unit test for function debug_time
def test_debug_time():
    import re
    import time

    time_regexp = re.compile(r'\d{2}:\d{2}:\d{2}\.\d{6}')

    with debug_time('test'):
        time.sleep(1)  # pragma: no cover

    result = sys.stderr.getvalue()
    assert result
    assert time_regexp.search(result.split()[1])