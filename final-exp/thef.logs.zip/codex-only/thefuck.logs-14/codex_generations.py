

# Generated at 2022-06-24 05:42:46.140138
# Unit test for function exception
def test_exception():
    # Test 1
    try:
        raise Exception('test')
    except:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:42:46.691044
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully()

# Generated at 2022-06-24 05:42:57.424242
# Unit test for function debug_time
def test_debug_time():
    import unittest
    from StringIO import StringIO
    class TestDebugTime(unittest.TestCase):
        def setUp(self):
            self.settings = settings
            settings.debug = True
            self.stdout = sys.stderr
            sys.stderr = StringIO()
 
        def test_debug_time(self):
            import time
            with debug_time('test'):
                time.sleep(0.1)
            result = sys.stderr.getvalue().split()

# Generated at 2022-06-24 05:42:59.619383
# Unit test for function version
def test_version():
    from thefuck.shells import Shell
    version('3.11', '3.4.3', Shell('Zsh').info())
    assert True



# Generated at 2022-06-24 05:43:01.000640
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Unit tests for function warn

# Generated at 2022-06-24 05:43:10.804686
# Unit test for function debug_time
def test_debug_time():
    from . import fuck
    import log
    import tempfile
    import os
    import shutil
    import re
    from datetime import timedelta

    fuck.settings = log.settings = None
    _, path = tempfile.mkstemp()

    tmp_dir = os.path.dirname(path)
    rules_dir = os.path.join(tmp_dir, 'rules_dir')
    cache_dir = os.path.join(tmp_dir, 'cache_dir')
    os.mkdir(rules_dir)

    fuck.settings = log.settings = settings

# Generated at 2022-06-24 05:43:12.269667
# Unit test for function already_configured
def test_already_configured():
    already_configured("configuration_details")



# Generated at 2022-06-24 05:43:23.202234
# Unit test for function debug
def test_debug():
    from os import environ
    from os import devnull
    from tempfile import mkstemp

    from .utils import TEST_DIR as original_test_dir
    from .utils import TEST_FILES as original_test_files

    def cleanup():
        sys.stderr = sys.__stderr__
        settings._clear()
        settings._load()
        TEST_DIR['fuck'] = original_test_dir
        TEST_FILES['fuck'] = original_test_files

    with open(devnull, 'w') as null:
        # Disable output
        settings.debug = True
        sys.stderr = null

        from .utils import TEST_DIR as test_dir
        from .utils import TEST_FILES as test_files
        from .utils import TEST_FILE

        test_dir['fuck'] = u'/tmp'


# Generated at 2022-06-24 05:43:28.503236
# Unit test for function rule_failed
def test_rule_failed():
    rule = type("rule", (), dict(name="test_rule"))()
    exc_info = (Exception("test_message"), Exception("test_message"), None)
    rule_failed(rule, exc_info)
    # result: "[WARN] Rule test_rule:
    #         test_message
    #         ----------------------------
    #
    #         "


# Generated at 2022-06-24 05:43:34.846969
# Unit test for function version
def test_version():
    from StringIO import StringIO
    from . import __version__ as thefuck_version
    from platform import python_version

    test_output = StringIO()
    sys.stderr = test_output

    version(thefuck_version, python_version(), 'shell')

    sys.stderr = sys.__stderr__

    assert u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                          python_version(),
                                                          'shell') == test_output.getvalue()



# Generated at 2022-06-24 05:43:36.738308
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(u'') == u''

# Generated at 2022-06-24 05:43:39.655752
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = sys.stdout
    show_corrected_command('fuck')
    show_corrected_command('git log')



# Generated at 2022-06-24 05:43:42.197735
# Unit test for function color
def test_color():
    assert color('red')('red') == '\x1b[31mred\x1b[39m'



# Generated at 2022-06-24 05:43:48.698501
# Unit test for function confirm_text
def test_confirm_text():
    text = ('\033[1K\r'
            'fuck --version [\x1b[32menter\x1b[39m/\x1b[34m↑\x1b[39m/\x1b[34m↓\x1b[39m/\x1b[31mctrl+c\x1b[39m]')
    assert confirm_text(
        const.CorrectedCommand('fuck --version', False)) == text

# Generated at 2022-06-24 05:43:53.221618
# Unit test for function rule_failed
def test_rule_failed():
    class Rule(object):
        def __init__(self, name, *args, **kwargs):
            self.name = name
    rule_failed(Rule("foo"), ('', '', ''))
    rule_failed(Rule("foo"), ('', '', '',))

    rule_failed(Rule("foo"), ('\n',))
    rule_failed(Rule("foo"), ('',))

# Generated at 2022-06-24 05:43:57.182444
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''
    settings.no_colors = False


# Generated at 2022-06-24 05:44:06.006821
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import sys
    import subprocess
    from datetime import date, timedelta
    from thefuck.conf import settings
    from thefuck import main, const
    from thefuck.main import Command
    from thefuck.utils import (color, warn, debug, debug_time,
                               rule_failed, failed, how_to_configure_alias,
                               already_configured, configured_successfully,
                               version)

    # Set-up environment for testing
    settings.env = {'PATH': os.path.dirname(os.path.abspath(__file__)),
                    'LC_ALL': 'C'}
    settings.debug = True
    settings.rules = [lambda c: (c, None)]
    settings.exclude_rules = []
    settings.priority = {}
    settings.no_colors

# Generated at 2022-06-24 05:44:11.759119
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ''))
    assert sys.stdout.getvalue() == "# ls\n"
    show_corrected_command(CorrectedCommand('ls', '', side_effect=True))
    assert sys.stdout.getvalue() == "# ls (+side effect)\n"

# Generated at 2022-06-24 05:44:12.731467
# Unit test for function warn
def test_warn():
    warn('Test for function warn')



# Generated at 2022-06-24 05:44:17.905653
# Unit test for function failed
def test_failed():
    from io import StringIO
    msg = 'Test message'
    buffer = StringIO()
    sys.stderr.write = buffer.write
    failed(msg)
    assert buffer.getvalue() == '{red}{msg}{reset}\n'.format(
        msg=msg,
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:44:21.150766
# Unit test for function version
def test_version():
    version(u'3.9', u'2.7', u'zsh 3.2 (x86_64-centos7.0.1406-el7.centos.1)')



# Generated at 2022-06-24 05:44:22.438711
# Unit test for function color
def test_color():
    assert color('red') == '\x1b[31m'



# Generated at 2022-06-24 05:44:23.606371
# Unit test for function warn
def test_warn():
    assert warn('my title') == '[WARN] my title\n'

# Generated at 2022-06-24 05:44:31.949645
# Unit test for function already_configured

# Generated at 2022-06-24 05:44:35.813090
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(('/etc/bash/bashrc',
                            'PATH="$PATH:$HOME/.local/bin:$HOME/bin"'))
    how_to_configure_alias(('/etc/bash/bashrc',
                            'PATH="$PATH:$HOME/.local/bin:$HOME/bin"', True))



# Generated at 2022-06-24 05:44:38.205680
# Unit test for function rule_failed
def test_rule_failed():
    def no_rule():
        "No rule"
    try:
        raise Exception(u'Test')
    except:
        rule_failed(no_rule, sys.exc_info())


# Generated at 2022-06-24 05:44:43.590721
# Unit test for function warn
def test_warn():
    from mock import patch
    with patch('sys.stderr.write') as sys_stderr_write:
        warn('sorry')

    sys_stderr_write.assert_called_once_with(u'\x1b[101m\x1b[97m\x1b[1m[WARN] sorry\x1b[0m\n')

# Generated at 2022-06-24 05:44:48.662533
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output

    msg = "This is a test message"
    failed(msg)
    assert color(colorama.Fore.RED) + msg + color(colorama.Style.RESET_ALL) + u"\n" == output.getvalue()


# Generated at 2022-06-24 05:44:49.578866
# Unit test for function debug_time
def test_debug_time():
    with debug_time('message'):
        pass

# Generated at 2022-06-24 05:44:52.991144
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # <script>
    # <side effect>
    # <prefix>
    str = "\033[1K\rfuck: git add . [enter/↑/↓/ctrl+c]"
    assert show_corrected_command(str) == str

# Generated at 2022-06-24 05:45:01.106680
# Unit test for function confirm_text
def test_confirm_text():
    import textwrap
    corrected_command = type('Command', (object, ), {
        'script': 'cd ~ && ls',
        'side_effect': False
    })

# Generated at 2022-06-24 05:45:02.922801
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-24 05:45:07.070574
# Unit test for function debug
def test_debug():
    assert debug(u"msg") == sys.stderr.write(u'\x1b[34m\x1b[1m'
                                             u'DEBUG: \x1b[0m msg\n')



# Generated at 2022-06-24 05:45:15.080722
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output

    confirm_text('')
    assert output.getvalue() == '> '

    confirm_text('ls')
    assert output.getvalue() == '> ls '

    confirm_text('ls -a')
    assert output.getvalue() == '> ls -a '

    confirm_text('ls +a')
    assert output.getvalue() == '> ls +a (+side effect) '

    confirm_text('ls -a +b')
    assert output.getvalue() == '> ls -a +b (+side effect) '


# Generated at 2022-06-24 05:45:18.149089
# Unit test for function rule_failed
def test_rule_failed():
    const.MockRule.mock_side_effect = RuntimeError('test')
    try:
        const.MockRule().get_new_command('git command', 'git')
    except:
        rule_failed(const.MockRule(), sys.exc_info())

# Generated at 2022-06-24 05:45:29.803729
# Unit test for function rule_failed
def test_rule_failed():
    msg = 'msg'
    exc = Exception(msg)
    exc_info = [type(exc), exc, exc.__traceback__]
    rule = type('Rule', (object, ), {})
    rule.name = 'rule'
    with settings(no_colors=True):
        yield rule_failed, rule, exc_info, u'[WARN] Rule rule:\nTraceback (most recent call last):\n  None\nException: msg\n----------------------------\n\n'

# Generated at 2022-06-24 05:45:36.988483
# Unit test for function confirm_text
def test_confirm_text():
    import subprocess

    # Get current terminal width
    terminal_width = int(subprocess.check_output(['stty', 'size']).split()[1])

    # Set terminal width to 80
    subprocess.call(['stty', 'rows', '80', 'cols', '80'])

    # Test confirm_text with various line lengths
    for i in range(1, 40):
        msg = 'a' * i
        confirm_text(msg)

    # Reset terminal width
    subprocess.call(['stty', 'rows', str(terminal_width), 'cols', str(terminal_width)])

# Generated at 2022-06-24 05:45:47.828077
# Unit test for function confirm_text
def test_confirm_text():
    # Check that we are writing output to stderr
    output = sys.stderr
    sys.stderr = sys.stdout
    try:
        import StringIO
        test_out = StringIO.StringIO('')
        sys.stderr = test_out
        confirm_text(object)
    finally:
        sys.stderr = output
        assert sys.stderr == output
        assert test_out.getvalue() == ('[fuck] <thefuck command> (+side effect) '
                                       '[\033[92menter\033[0m/\033[94m↑\033[0m/'
                                       '\033[94m↓\033[0m/\033[91mctrl+c\033[0m]')

# Generated at 2022-06-24 05:45:49.744098
# Unit test for function color
def test_color():
    assert not colorama.Fore.BLUE
    assert color(colorama.Fore.BLUE) == '\x1b[34m'

# Generated at 2022-06-24 05:45:51.015804
# Unit test for function color
def test_color():
    assert color('red') == ''
    assert color('red') != 'red'



# Generated at 2022-06-24 05:45:53.131207
# Unit test for function debug_time
def test_debug_time():
    from .main import main
    with debug_time('Main'):
        main(['echo', 'hello'])

# Generated at 2022-06-24 05:45:56.892581
# Unit test for function debug
def test_debug():
    assert not sys.stderr.getvalue()
    debug('Pupkin')
    assert sys.stderr.getvalue() == 'DEBUG: Pupkin\n'



# Generated at 2022-06-24 05:46:02.620190
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from datetime import datetime
    orig_stderr = sys.stderr
    sys.stderr = StringIO()
    ts = datetime.now()
    try:
        warn(u'Error')
        assert sys.stderr.getvalue().startswith(u'[WARN] Error')
    finally:
        sys.stderr = orig_stderr

# Generated at 2022-06-24 05:46:03.645893
# Unit test for function failed
def test_failed():
    failed(u'It works!')

# Generated at 2022-06-24 05:46:05.089298
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass



# Generated at 2022-06-24 05:46:08.132063
# Unit test for function debug_time
def test_debug_time():
    def test_decorator(function):
        def wrapper(arg):
            with debug_time('test'):
                function(arg)
        return wrapper

    @test_decorator
    def test_function(arg):
        return arg

    test_function(1)

# Generated at 2022-06-24 05:46:18.794284
# Unit test for function exception
def test_exception():
    class Error(Exception):
        pass

    try:
        raise Error('test')
    except Error:
        assert(exception('test', sys.exc_info()) ==
               u'\x1b[5;41;37m[WARN] test:\x1b[0m\n'
               u'Traceback (most recent call last):\n'
               u'  File "%s", line %d, in test_exception\n'
               u'    raise Error(\'test\')\n'
               u'Error: test\n'
               u'\x1b[5;41;37m----------------------------\x1b[0m\n\n'
               % (__file__, sys.exc_info()[2].tb_lineno))



# Generated at 2022-06-24 05:46:22.255758
# Unit test for function color
def test_color():
    assert color(colorama.Fore.CYAN) == colorama.Fore.CYAN
    settings.no_colors = True
    assert color(colorama.Fore.CYAN) == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:46:23.638916
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(CorrectedCommand('git log'))



# Generated at 2022-06-24 05:46:31.381846
# Unit test for function already_configured
def test_already_configured():
    # Test correct message output
    data = "Test"
    expected_output = 'Seems like \x1b[1mfuck\x1b[22m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[22m or restart your shell.\n'
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    out = StringIO()
    sys.stdout = out
    already_configured(data)
    sys.stdout = sys.__stdout__
    assert out.getvalue() == expected_output
    # Test with empty data
    data = ""

# Generated at 2022-06-24 05:46:32.290784
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully({'reload': 'source $HOME/.bashrc'})

# Generated at 2022-06-24 05:46:33.501020
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test_debug_time"):
        pass



# Generated at 2022-06-24 05:46:38.613671
# Unit test for function rule_failed
def test_rule_failed():
    import __init__
    import commands
    rule = __init__.Rule(name='name',
                         match=lambda *args: False,
                         get_new_command=lambda *args: 'ls -al',
                         enabled_by_default=True )

    try:
        raise Exception('some error')
    except:
        rule_failed(rule, sys.exc_info())


if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-24 05:46:42.863408
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import settings
    settings.debug = True
    sleep = timedelta(0, 0, 100)

    import time
    with debug_time('test function'):
        time.sleep(sleep.total_seconds())

    assert True



# Generated at 2022-06-24 05:46:44.357016
# Unit test for function version
def test_version():
    version('1.0', '2.7.6', 'shell')

# Generated at 2022-06-24 05:46:46.745544
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details)==u"fuck alias configured successfully!\nFor applying changes run source ~/.bashrc or restart your shell."


# Generated at 2022-06-24 05:46:48.271013
# Unit test for function exception
def test_exception():
    try:
        assert False
    except Exception:
        exception('Oops', sys.exc_info())



# Generated at 2022-06-24 05:46:50.849017
# Unit test for function warn
def test_warn():
    usage = '''\
133
[WARN] warn
'''
    assert warn('warn') == usage



# Generated at 2022-06-24 05:46:52.812296
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('bar') == ''

# Generated at 2022-06-24 05:46:55.422913
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test exception')
    except Exception as e:
        exception(u'Test exception', sys.exc_info())
        return True
    return False

# Generated at 2022-06-24 05:47:01.998928
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    path = 'test'
    reload = 'source test/test_fuck'
    content = 'test = test()'
    can_configure_automatically = True
    test_configuration_details = configuration_details(
        content, path, reload, can_configure_automatically)
    # assert how_to_configure_alias
    #   throws error when it doesn't have arguments
    with pytest.raises(TypeError):
        how_to_configure_alias()
    how_to_configure_alias(test_configuration_details)

# Generated at 2022-06-24 05:47:04.164034
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details) is None

# Generated at 2022-06-24 05:47:04.842405
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)



# Generated at 2022-06-24 05:47:10.600304
# Unit test for function confirm_text
def test_confirm_text():
    from . import rules
    from .shells import reverse_replace_command
    from .utils import which
    from . import application

    class CorrectedCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    def construct_application(rules):
        return application.Application(rules, {}, None, False, False)

    test_application = construct_application([
        rules.Rule(
            name='',
            matcher=lambda *a: True,
            get_new_command=lambda c: reverse_replace_command(c, c.script, c.script.split()),
            side_effect=lambda c: c.script)])

    java_available = which('java') is not None
    # TODO split this monster test


# Generated at 2022-06-24 05:47:20.829986
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    import mock
    import sys
    import os
    sys.stdout = mock.MagicMock(spec=sys.stdout)
    sys.stderr = mock.MagicMock(spec=sys.stderr)
    home = os.path.expanduser('~')
    prompt = u">>> "
    bash = Bash(mock.MagicMock(side_effect=[u'ee\n']))
    prompt_command = u'echo ">>> "'
    prefix = u'$'
    command = u'tee a.txt'
    corrected_command = bash.from_shell(command, prefix, prompt_command)
    corrected_command = corrected_command.split()
    corrected_command = u' '.join(corrected_command[1:])

# Generated at 2022-06-24 05:47:27.091788
# Unit test for function warn
def test_warn():
    with mock.patch('sys.stderr.write') as write_mock:
        warn(u'some text')
        write_mock.assert_called_once_with(
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] some text\x1b[22m\x1b[39m\x1b[49m\n')



# Generated at 2022-06-24 05:47:32.471846
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = config.ConfigurationDetails('\n'.join(sys.path),
                                                         '~/.bashrc',
                                                         '. ~/.bashrc',
                                                         False)

    how_to_configure_alias(configuration_details)
    # assert that this command prints something


# Generated at 2022-06-24 05:47:33.874277
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('test_rule_name','test_exc_info')

# Generated at 2022-06-24 05:47:35.303622
# Unit test for function color
def test_color():
    assert(color('red') == '')
    settings.no_colors = False
    assert(color('red') == colorama.Fore.RED)



# Generated at 2022-06-24 05:47:40.812575
# Unit test for function debug
def test_debug():
    output = []

    class FakeStderr(object):
        def write(self, text):
            output.append(text)

    old_stderr = sys.stderr
    sys.stderr = FakeStderr()
    settings.debug = True
    debug(u'foo')
    sys.stderr = old_stderr
    assert output[0] == '\x1b[94m\x1b[1mDEBUG:\x1b[0m foo\n'



# Generated at 2022-06-24 05:47:47.661909
# Unit test for function version
def test_version():
    import platform
    import sys
    import thefuck.__main__
    thefuck_version = 'test_version'
    stderr_bak = sys.stderr
    try:
        from StringIO import StringIO
    except:
        from io import StringIO
    f = StringIO()
    sys.stderr = f
    thefuck.__main__.version(thefuck_version, platform.python_version(), platform.platform())
    sys.stderr = stderr_bak
    assert f.getvalue() == 'The Fuck test_version using Python {} and {}\n'.format(platform.python_version(), platform.platform())



# Generated at 2022-06-24 05:47:48.264841
# Unit test for function configured_successfully
def test_configured_successfully():
    return True

# Generated at 2022-06-24 05:47:50.918410
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('Shell').endswith('Shell')
    assert configured_successfully('Shell').startswith('The Fuck')


# Generated at 2022-06-24 05:47:57.917438
# Unit test for function exception
def test_exception():
    # import unittest
    import StringIO
    sys.stderr = StringIO.StringIO()
    exception('title', sys.exc_info())
    sys.stderr.seek(0)
    assert sys.stderr.read() == \
        u'\x1b[91m[WARN] title:\x1b[0m\nNameError: name \'x\' is not defined\n\x1b[91m----------------------------\x1b[0m\n\n'



# Generated at 2022-06-24 05:48:08.217107
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import StringIO
    import sys
    from contextlib import nested
    from mock import patch

    with nested(
            patch('datetime.datetime'),
            patch.object(sys, 'stderr', StringIO.StringIO())):
        datetime.now.return_value = datetime(2015, 1, 1, 0, 0, 0, 0)
        with debug_time('test'):
            datetime.now.return_value = datetime(2015, 1, 1, 0, 0, 10, 0)
        sys.stderr.seek(0)
        assert sys.stderr.read() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:10\n'

# Generated at 2022-06-24 05:48:09.907173
# Unit test for function warn
def test_warn():
    warn(u'Test')
    assert u'[WARN] Test' in sys.stderr.getvalue()
    assert u'[WARN] Test' in color(sys.stderr.getvalue())


# Generated at 2022-06-24 05:48:21.548738
# Unit test for function debug
def test_debug():
    import io
    import contextlib

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('message')

    output = out.getvalue().strip()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m message'

# Generated at 2022-06-24 05:48:27.724297
# Unit test for function version
def test_version():
    import os
    import subprocess
    import sys
    python_version = sys.version
    thefuck_version = '3.11'
    shell = os.environ['SHELL'].split('/')[-1]
    shell_info = subprocess.check_output([shell, '--version']).decode('utf-8')
    result = u'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                       python_version,
                                                       shell_info)
    assert result == version(thefuck_version, python_version, shell_info)


# Generated at 2022-06-24 05:48:28.978595
# Unit test for function warn
def test_warn():
    warn('TEST')
    pass


# Generated at 2022-06-24 05:48:37.153999
# Unit test for function debug
def test_debug():
    from .runner import Runner
    from .shells import Bash, Zsh
    from .types import Settings
    from .utils import wrap_settings
    from click.testing import CliRunner

    for alias, shell in ((u'fuck', Bash), (u'f', Zsh)):
        settings = Settings(no_colors=True, alias=alias)
        runner = CliRunner()
        result = runner.invoke(Runner(wrap_settings(settings),
                                      wrap_settings(settings),
                                      None,
                                      debug=True),
                               input='echo "test"\n')
        assert u'DEBUG: Command "echo "test"" ' in result.output

# Generated at 2022-06-24 05:48:43.963470
# Unit test for function configured_successfully
def test_configured_successfully():
    from .configuration import ConfigurationDetails
    details = ConfigurationDetails(
        path_to_alias='~/.bash_profile',
        reload='source ~/.bash_profile',
        can_configure_automatically=True
    )
    expected_result = "\x1b[1mfuck\x1b[22m alias configured successfully!\nFor applying changes run \x1b[1msource ~/.bash_profile\x1b[22m or restart your shell."
    assert expected_result == configured_successfully(details)

# Generated at 2022-06-24 05:48:45.246004
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias() == None

# Generated at 2022-06-24 05:48:50.056216
# Unit test for function debug_time
def test_debug_time():
    from . import settings
    from .conf import set_settings
    import unittest

    settings = set_settings({'debug': True})
    class TestTime(unittest.TestCase):
        def test_true(self):
            with debug_time('test'):
                pass

    unittest.main()

# Generated at 2022-06-24 05:48:57.116436
# Unit test for function failed
def test_failed():
    # test output for stderr
    from cStringIO import StringIO

    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        failed('test')
        output = out.getvalue().strip()
        assert output == u'\x1b[31mtest\x1b[0m\n'
    finally:
        sys.stderr = saved_stderr



# Generated at 2022-06-24 05:48:59.902363
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        exception('No description', sys.exc_info())

# Generated at 2022-06-24 05:49:09.818574
# Unit test for function version
def test_version():
    import mock
    import platform
    import thefuck
    with mock.patch('thefuck.shells.get_shell_info') as get_shell_info:
        get_shell_info.return_value = u'zsh'
        with mock.patch.object(sys, 'stdout') as stdout, mock.patch('thefuck.version.python_version', lambda: u'2.7.9'):
            version(thefuck.__version__, thefuck.version.python_version(), get_shell_info())
            version(thefuck.__version__, u'2.7.9', get_shell_info())

# Generated at 2022-06-24 05:49:12.973387
# Unit test for function version
def test_version():
    def f():
        pass

    assert version(thefuck_version='1',
                   python_version=sys.version,
                   shell_info=f()) is None

# Generated at 2022-06-24 05:49:15.420882
# Unit test for function confirm_text
def test_confirm_text():
    colorama.init()
    corrected_command = 'git commig --amend'
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:49:16.540148
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('test exception')
    except:
        exception('test title', sys.exc_info())

# Generated at 2022-06-24 05:49:23.645613
# Unit test for function debug_time
def test_debug_time():
    from colorama import Fore
    from datetime import datetime
    import mock

    with mock.patch('sys.stderr') as sys_stderr:
        with debug_time('msg'):
            pass
        datetime_obj1 = datetime.now() - datetime.now()
        sys_stderr.write.assert_called_once_with(u'{}DEBUG:{} msg took: {}\n'.format(Fore.BLUE, Fore.RESET, datetime_obj1))

# Generated at 2022-06-24 05:49:32.136176
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import _is_interactive

    def _print(arg):
        return arg

    orig_print = print
    print = _print  # noqa

# Generated at 2022-06-24 05:49:37.481748
# Unit test for function failed
def test_failed():
    try:
        raise RuntimeError('command failed')
    except Exception as e:
        import sys, io

        _stdout = sys.stderr
        sys.stderr = io.StringIO()

        failed(e)
        result = sys.stderr.getvalue()

        sys.stderr = _stdout
        return result



# Generated at 2022-06-24 05:49:38.849812
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) is None


# Generated at 2022-06-24 05:49:39.773562
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully.__doc__ is not None

# Generated at 2022-06-24 05:49:43.538160
# Unit test for function debug_time
def test_debug_time():
    import time
    from mock import MagicMock
    settings.debug = True
    sys.stderr = MagicMock()

    with debug_time('test'):
        time.sleep(0.2)
    sys.stderr.write.assert_called_with('\n')
    settings.debug = False

# Generated at 2022-06-24 05:49:44.488770
# Unit test for function already_configured
def test_already_configured():
    already_configured("reload")


# Generated at 2022-06-24 05:49:51.854144
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    from .compat import unicode
    assert unicode(configured_successfully(Shell('shell', reload='source ~/.bashrc', how_to_configure='alias fuck=...', how_to_configure_auto=False))) == u'\x1b[1mfuck\x1b[22m alias configured successfully!\nFor applying changes run \x1b[1msource ~/.bashrc\x1b[22m or restart your shell.'



# Generated at 2022-06-24 05:50:00.726833
# Unit test for function warn
def test_warn():
    from . import mock_subprocess
    with mock_subprocess.subprocess():
        warn('title')
        mock_subprocess.check_call.assert_called_once_with(
            ['stty', '-ixon'], stderr=mock_subprocess.PIPE)
        assert sys.stderr.getvalue() == (
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n')



# Generated at 2022-06-24 05:50:02.078794
# Unit test for function exception
def test_exception():
    exception('Test title', [TypeError, TypeError('msg'), None])



# Generated at 2022-06-24 05:50:05.446086
# Unit test for function warn
def test_warn():
    from . import mock, output

    with mock.patch('sys.stderr'):
        output.warn(u'Hi!')
        colorama.Back.RED + colorama.Fore.WHITE + \
            colorama.Style.BRIGHT + u'[WARN] Hi!' + \
            colorama.Style.RESET_ALL + '\n'


# Generated at 2022-06-24 05:50:08.766013
# Unit test for function color
def test_color():
    assert color('a') == ''
    settings.no_colors = False
    assert color('a') == 'a'

# Generated at 2022-06-24 05:50:12.000614
# Unit test for function version
def test_version():
    """
    version()
    """
    sys.stderr.write(u'The Fuck 3.2 using Python 2.7 and /bin/bash')



# Generated at 2022-06-24 05:50:14.125526
# Unit test for function rule_failed
def test_rule_failed():
    try:
        1/0
    except ZeroDivisionError as e:
        rule_failed(e)

# Generated at 2022-06-24 05:50:21.789794
# Unit test for function version
def test_version():
    import imp
    import re
    import subprocess
    import unittest

    import mock


    class VersionTest(unittest.TestCase):
        @mock.patch('sys.stderr.write')
        @mock.patch('thefuck.shells.get_shell_info', lambda: u'ShellInfo')
        @mock.patch('thefuck.utils.get_python_version', lambda: u'PythonVersion')
        @mock.patch('thefuck.utils.get_thefuck_version', lambda: u'TheFuckVersion')
        def test_version(self, mock_sys):
            version('TheFuckVersion', 'PythonVersion', 'ShellInfo')
            mock_sys.assert_called_with(
                'The Fuck TheFuckVersion using Python PythonVersion and ShellInfo\n')


    return unittest

# Generated at 2022-06-24 05:50:23.882931
# Unit test for function confirm_text
def test_confirm_text():
    from six import StringIO

    confirm_text(None)
    assert 1 == 2


test_confirm_text()

# Generated at 2022-06-24 05:50:29.968954
# Unit test for function warn
def test_warn():
    class StreamStub(object):
        def __init__(self):
            self.content = u''

        def write(self, content):
            self.content += content

        def is_empty(self):
            return self.content == u''

    sys.stderr = StreamStub()
    try:
        warn(u'msg')
        assert not sys.stderr.is_empty()
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:50:32.113365
# Unit test for function debug_time
def test_debug_time():
    def _test_debug_time(*args):
        with debug_time('test_debug_time'):
            return args[0] + args[1]
    assert _test_debug_time(1, 2) == 3

# Generated at 2022-06-24 05:50:39.413655
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    has_stdout = "Seems like fuck alias isn't configured!\n"\
                 "Please put \n"\
                 "!alias fuck='eval $(thefuck $(fc -ln -1)); history -r' "\
                 "in your \n"\
                 "/home/jesse/.bashrc and apply "\
                 "changes with source /home/jesse/.bashrc or restart your "\
                 "shell.\n"\
                 "Or run fuck a second time to configure it automatically."
    assert how_to_configure_alias(has_stdout)


# Generated at 2022-06-24 05:50:42.804510
# Unit test for function color
def test_color():
    assert color(u'') == u''
    assert color(u'\x1b[1;31m') == u'\x1b[1;31m'
    assert color(u'\x1b[0m') == u'\x1b[0m'



# Generated at 2022-06-24 05:50:44.682296
# Unit test for function warn
def test_warn():
    assert warn('test') == '[WARN] test'


# Generated at 2022-06-24 05:50:45.685712
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(True)


# Generated at 2022-06-24 05:50:48.843699
# Unit test for function failed
def test_failed():
    mock = Mock()
    with patch('sys.stderr', mock):
        failed(u'Some message')
    assert mock.write.called


# Generated at 2022-06-24 05:50:51.597826
# Unit test for function color
def test_color():
    assert color('red' if sys.platform == 'win32' else '\x1b[31m') == ''
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-24 05:50:55.246717
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    text = how_to_configure_alias({"reload": "c", "content": "d", "path": "v", "can_configure_automatically": True})
    assert text is None


# Generated at 2022-06-24 05:50:59.377904
# Unit test for function debug
def test_debug():
    from mock import patch, MagicMock
    from . import conf

    with patch.object(conf, 'settings', MagicMock()) as settings:
        settings.debug = True
        debug('a')
        assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m a\n'

        sys.stderr.truncate(0)
        settings.debug = False
        debug('a')
        assert sys.stderr.getvalue() == ''

# Generated at 2022-06-24 05:51:06.281517
# Unit test for function debug
def test_debug():
    from thefuck.shells import guess

    if guess() == 'bash':
        assert debug('asd') == sys.stderr.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m asd\n')
    else:
        assert debug('asd') == sys.stderr.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m asd\n')

# Generated at 2022-06-24 05:51:08.131711
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("source")
    assert "fuck alias configured successfully!\nFor applying changes run" in sys.stderr.getvalue()


if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-24 05:51:10.313351
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('some'), None)
    exception(u'title', exc_info)



# Generated at 2022-06-24 05:51:11.747947
# Unit test for function version
def test_version():
    version('3.0', '3.7.2', 'bash')

# Generated at 2022-06-24 05:51:17.438256
# Unit test for function failed
def test_failed():
    import mock
    failed(u'Повторите команду')
    assert sys.stderr.getvalue() == \
        u'\x1b[31mПовторите команду\x1b[0m\n'
    sys.stderr = mock.Mock()
    failed('Repeat command')
    assert sys.stderr.getvalue() == \
        u'\x1b[31mRepeat command\x1b[0m\n'



# Generated at 2022-06-24 05:51:18.390382
# Unit test for function already_configured
def test_already_configured():
     assert(already_configured("test") == "test")

# Generated at 2022-06-24 05:51:20.294190
# Unit test for function color
def test_color():
    assert settings.no_colors
    assert color(colorama.Back.RED) == ''



# Generated at 2022-06-24 05:51:21.395352
# Unit test for function debug
def test_debug():
    debug(u'foo')

# Generated at 2022-06-24 05:51:28.109839
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from freezegun import freeze_time

    # Check that function works
    started = datetime.now()
    with debug_time('Test'):
        assert (datetime.now() - started) < timedelta(seconds=1)

    # Check that function measures time
    with freeze_time('2000-01-01') as frozen_time:
        with debug_time('Test'):
            frozen_time.tick(timedelta(seconds=1))



# Generated at 2022-06-24 05:51:33.989142
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from six.moves import mock
    with mock.patch('sys.stderr.write') as stderr_write_mock:
        with debug_time('my debug time'):
            pass
        stderr_write_mock.assert_called_with(u'my debug time took: {}\n'.format(
            timedelta(0)))

# Generated at 2022-06-24 05:51:38.430248
# Unit test for function warn
def test_warn():
    assert u'\x1b[41;37;1m[WARN] Foo\x1b[0m\n' == warn('Foo')
    assert u'[WARN] Foo\n' == warn('Foo')


# Generated at 2022-06-24 05:51:44.239978
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import Command
    from .utils import wrap_retry

    Shell.DEFAULT = None
    settings.no_colors = False
    
    cmd = Command('echo "a"', 'echo "b"', 'echo "c"')
    show_corrected_command(cmd)
    confirm_text(cmd)
    
    settings.no_colors = True
    
    cmd = Command('echo "a"', 'echo "b"', 'echo "c"')
    show_corrected_command(cmd)
    confirm_text(cmd)

# Generated at 2022-06-24 05:51:45.433951
# Unit test for function debug
def test_debug():
    """
    >>> debug('test')
    DEBUG: test
    """
    pass

# Generated at 2022-06-24 05:51:54.256946
# Unit test for function debug
def test_debug():
    # pylint: disable=W0612
    from io import StringIO
    from .conf import settings
    settings.debug = True
    fout = StringIO()
    debug_out = StringIO()
    #fout, debug_out = StringIO(), StringIO()
    sys.stdout = fout
    sys.stderr = debug_out
    debug(u'start')
    # print -> sys.stdout -> fout
    print(u'hello')
    assert fout.getvalue() == u'hello\n'
    # debug -> sys.stderr -> debug_out
    debug(u'world')
    assert debug_out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m world\n'
    settings.debug = False


# Generated at 2022-06-24 05:51:55.641160
# Unit test for function failed
def test_failed():
    failed(u'Проверь')

# Generated at 2022-06-24 05:52:03.676591
# Unit test for function rule_failed
def test_rule_failed():
    """Test that warn prints warning with prefix 'WARN' and given title in stderr"""
    import StringIO
    import sys
    import traceback

    try:
        raise Exception('some error')
    except Exception:
        exc_info = sys.exc_info()

    class Rule:
        name = 'rule'

    stderr = sys.stderr

# Generated at 2022-06-24 05:52:05.396974
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    result=how_to_configure_alias()
    assert result=="Seems like fuck alias isn't configured!"


# Generated at 2022-06-24 05:52:13.623605
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,),
                             {'script': 'lsjdflsjdflsjdflsd',
                              'side_effect': False})
    from cStringIO import StringIO
    from mock import patch
    with patch('sys.stderr', StringIO()) as output:
        confirm_text(corrected_command)


# Generated at 2022-06-24 05:52:18.122769
# Unit test for function failed
def test_failed():
    from .utils import capture_output

    with capture_output() as (stdout, stderr):
        failed('foo')

    assert u'\x1b[31mfoo\x1b[0m\n' == stderr.getvalue()
    assert u'' == stdout.getvalue()



# Generated at 2022-06-24 05:52:20.938262
# Unit test for function rule_failed
def test_rule_failed():
    from .command import Command
    from .rules.git import git_rule
    command = Command('fuck', '', '', '', '', 1)
    rule_failed(git_rule, (Exception, Exception('test'), None))


# Generated at 2022-06-24 05:52:24.343940
# Unit test for function rule_failed
def test_rule_failed():
    class f(object):
        def __init__(self, name):
            self.name = name
    rule_failed(f("name"), "type")

if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-24 05:52:25.326810
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('python3')

# Generated at 2022-06-24 05:52:33.230706
# Unit test for function show_corrected_command
def test_show_corrected_command():
    '''This output depends on console size, and this is good.
    That's why I'm using patch for sys.stdout.
    '''
    from mock import patch
    from .types import CorrectedCommand
    from .conf import settings
    settings.no_colors = True
    corrected_command = CorrectedCommand('ng serve --port 3000', True)
    with patch('sys.stdout') as mock_stdout:
        show_corrected_command(corrected_command)
        mock_stdout.write.assert_called_once_with(
            '$ ng serve --port 3000 +side effect\n'
        )



# Generated at 2022-06-24 05:52:37.803768
# Unit test for function failed
def test_failed():
    from .utils import captured_stderr
    with captured_stderr() as stderr:
        failed('test')
    assert stderr.getvalue() == u'\x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-24 05:52:41.241351
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple('configuration_details', 'reload')(
        reload=''.join(['source', ' ','~/.bashrc']))
    already_configured(configuration_details)



# Generated at 2022-06-24 05:52:46.027188
# Unit test for function version
def test_version():
    from io import StringIO
    from .tests.utils import get_without_dependencies, replace_module
    replace_module('platform', get_without_dependencies('platform'))

    sys.stderr = StringIO()
    version('3.12', '2.7.10', 'sh')
    assert sys.stderr.getvalue().strip() == \
        u'The Fuck 3.12 using Python 2.7.10 and sh'