

# Generated at 2022-06-24 05:42:42.609993
# Unit test for function warn
def test_warn():
    try:
        warn('Fake warning')
    except Exception:
        assert False, 'warn() should not raise Exception'



# Generated at 2022-06-24 05:42:43.895314
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . correct import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='rm . -rf'))

# Generated at 2022-06-24 05:42:50.911632
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    from .conf import ConfigurationDetails
    from . import version as fuck_version
    from . import __version__ as py_version
    class FakeStderr(object):
        def write(self, text):
            assert text == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.\n".format(
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL),
                    reload=None
            )
    sys.stderr = FakeStderr()
    configured_successfully(ConfigurationDetails(
        reload=''
    ))

# Generated at 2022-06-24 05:43:00.885483
# Unit test for function debug
def test_debug():
    from .application import Application
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .utils import wrap_settings
    from tempfile import NamedTemporaryFile

    # null shell for unit test
    class NullShell(Bash):
        def _get_history_file_name(self):
            return NamedTemporaryFile().name

        def _get_history_line(self, command_script):
            return ''

    with wrap_settings(debug=True):
        # use empty shell history, so tests would be independent from user one
        app = Application(shell=NullShell())

    with wrap_settings(debug=False):
        app = Application(shell=Zsh())

# Generated at 2022-06-24 05:43:10.676059
# Unit test for function rule_failed
def test_rule_failed():
    import mock
    import shutil
    from thefuck.types import Rule
    shutil.rmtree("/tmp/thefuck")
    exc = Exception("1")
    rule = Rule("1", "1", "1", "1", "1", "1", "1")
    rule_failed(rule, exc)

# Generated at 2022-06-24 05:43:20.530102
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError("foo")
    except Exception:
        output = sys.stderr.getvalue()
        assert output.startswith(
            u'\x1b[41m\x1b[37m\x1b[1m[WARN] Rule '
            u'None:\x1b[0m\nTraceback (most recent call last):\n')
        assert output.endswith(
            u'RuntimeError: foo\n\n\x1b[41m\x1b[37m\x1b[1m----------------'
            u'------------\x1b[0m\n\n')



# Generated at 2022-06-24 05:43:24.639391
# Unit test for function warn
def test_warn():
    caught = []

    class FakeStdErr(object):
        def write(self, msg):
            caught.append(msg)

    warn(u'Some text')
    assert (u'[WARN] Some text\n' == caught[0])


# Generated at 2022-06-24 05:43:26.240620
# Unit test for function color
def test_color():
    assert '\x1b[31m' == color(colorama.Fore.RED)

# Generated at 2022-06-24 05:43:27.323931
# Unit test for function debug
def test_debug():
    with debug_time('Test'):
        pass

# Generated at 2022-06-24 05:43:30.209362
# Unit test for function warn
def test_warn():
    title = "Test"
    warn(title)

    if sys.stderr.getvalue() != "[WARN] Test\n":
        raise AssertionError("Wrong output of warn function.")



# Generated at 2022-06-24 05:43:33.811224
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import how as how_to_configure_alias, settings
    how_to_configure_alias(None)
    settings.no_colors = True
    how_to_configure_alias(None)
    settings.reset()


# Generated at 2022-06-24 05:43:34.717718
# Unit test for function version
def test_version():
    version('thefuck_version', 'python_version', 'shell_info')

# Generated at 2022-06-24 05:43:36.159760
# Unit test for function version
def test_version():
    version('1.2.3', '4.5.6', 'fish')



# Generated at 2022-06-24 05:43:40.933033
# Unit test for function color
def test_color():
    assert color('foo') == colorama.Fore.BLACK + 'foo' + colorama.Style.RESET_ALL
    assert color('foo', colorama.Fore.BLACK) == colorama.Fore.BLACK + 'foo' + colorama.Style.RESET_ALL



# Generated at 2022-06-24 05:43:45.964827
# Unit test for function failed
def test_failed():
    _stdout = sys.stdout
    try:
        from io import StringIO
        output = StringIO()
        sys.stdout = output
        failed('Something')
        assert output.getvalue() == '\x1b[31mSomething\x1b[0m\n'
    finally:
        sys.stdout = _stdout



# Generated at 2022-06-24 05:43:48.980867
# Unit test for function warn
def test_warn():
    from .utils import Captured
    with Captured() as out:
        warn('test')
    assert out.getvalue() == '[WARN] test\n'


# Generated at 2022-06-24 05:43:51.050819
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    assert configured_successfully(Shell(None, None, None, None, None, None))



# Generated at 2022-06-24 05:43:53.046861
# Unit test for function already_configured
def test_already_configured():
    configuration_details = const.ConfigurationDetails('reload_cmd')
    already_configured(configuration_details)

# Generated at 2022-06-24 05:44:03.154980
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, path, content, reload,
                     can_configure_automatically):
            self.path = path
            self.content = content
            self.reload = reload
            self.can_configure_automatically = can_configure_automatically

    data = ConfigurationDetails(
        path='~/.config',
        content='fuck = thefuck',
        reload='source ~/.config',
        can_configure_automatically=True)
    how_to_configure_alias(data)

    def how_to_configure_alias_without_data():
        how_to_configure_alias(None)
    how_to_configure_alias_without_data()

# Generated at 2022-06-24 05:44:04.623614
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'ls'
    confirm_text(corrected_command)


# Generated at 2022-06-24 05:44:05.115929
# Unit test for function failed
def test_failed():
    failed('text')



# Generated at 2022-06-24 05:44:09.770393
# Unit test for function configured_successfully
def test_configured_successfully():
    import subprocess
    import tempfile
    with tempfile.NamedTemporaryFile() as script:
        script.write(u'#!/bin/sh\necho $@')
        script.flush()
        configuration_details = namedtuple(
            'Configuration',
            'path reload script_content can_configure_automatically')(
                path='/tmp',
                reload='/tmp',
                script_content=script.name,
                can_configure_automatically=True)
        with tempfile.NamedTemporaryFile() as tf:
            tf.write(u'#!/bin/sh\necho $@')
            tf.flush()

            configured_successfully(configuration_details)

# Generated at 2022-06-24 05:44:11.157434
# Unit test for function already_configured
def test_already_configured():
    already_configured('already_configured')


# Generated at 2022-06-24 05:44:14.946742
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from .conf import settings

    settings.no_colors = False
    assert confirm_text(Script('foo', 'foo')) is None
    assert confirm_text(Script('foo', 'foo', side_effect=True)) is None



# Generated at 2022-06-24 05:44:16.602471
# Unit test for function already_configured
def test_already_configured():
    configuration_details = ['source ~/.bashrc']
    already_configured(configuration_details)


# Generated at 2022-06-24 05:44:22.046510
# Unit test for function version
def test_version():
    import sys
    sys.stdout = open('test_version', 'w')
    version('version', 'python version', 'shell info')
    sys.stdout.close()
    f = open('test_version', 'r')
    message = f.read()
    f.close()
    import os
    os.remove('test_version')
    assert message == 'The Fuck version using Python python version and shell info\n'

# Generated at 2022-06-24 05:44:22.881316
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-24 05:44:24.925528
# Unit test for function version
def test_version():
    assert version('1.1.1', '3.5', 'bash') == None
    assert version('1.1.1', '3.5', 'zsh') == None

# Generated at 2022-06-24 05:44:25.862022
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('test_rule', 'test_info')

# Generated at 2022-06-24 05:44:29.014401
# Unit test for function version
def test_version():
    from .shells import Shell
    shell = Shell("bash")
    from sys import version_info
    from .__version__ import __version__

    version(__version__, version_info, shell)

# Generated at 2022-06-24 05:44:32.252747
# Unit test for function color
def test_color():
    assert color('text') == ''
    assert color('') == ''
    settings.no_colors = False
    assert color('') == ''
    assert color('text') == 'text'
    settings.no_colors = True

# Generated at 2022-06-24 05:44:34.424699
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(const.CorrectedCommand(script='ls', side_effect=False)) == 'FUCK ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:44:35.488213
# Unit test for function exception
def test_exception():
    _, _, exc_info = sys.exc_info()
    exception("Name", exc_info)

# Generated at 2022-06-24 05:44:38.062536
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck import types
    from .conf import Command
    from .conf import CorrectedCommand
    from .conf import ShellInfo
    from .conf import ConfigurationDetails

    show_corrected_command(CorrectedCommand(Command('pwd'), []))

# Generated at 2022-06-24 05:44:39.373732
# Unit test for function exception
def test_exception():
    warn('title')
    exception('title', (Exception, Exception('test'), None))



# Generated at 2022-06-24 05:44:44.425837
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    rule = rules.Rule('ls', lambda x: x, 'ls fuck')
    stream = sys.stderr
    error_message = 'foo'
    stream.write = lambda msg: error_message
    rule_failed(rule, [None, None, None])
    assert error_message == 'Rule ls'

# Generated at 2022-06-24 05:44:45.951223
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-24 05:44:48.533492
# Unit test for function version
def test_version():
    assert 'The Fuck 3.10 using Python 2.7.5+' == version('3.10', '2.7.5+', '')

# Generated at 2022-06-24 05:44:50.616275
# Unit test for function configured_successfully
def test_configured_successfully():
    print (configured_successfully(configuration_details={'path': "~/.bashrc", 'reload': "source ~/.bashrc"}))



# Generated at 2022-06-24 05:44:51.805642
# Unit test for function configured_successfully
def test_configured_successfully():
    return


# Generated at 2022-06-24 05:44:53.933118
# Unit test for function rule_failed
def test_rule_failed():
    import pytest

    with pytest.raises(SystemExit):
        rule_failed('111', '111')



# Generated at 2022-06-24 05:44:55.249876
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(['fake', 'data']) is None

# Generated at 2022-06-24 05:44:56.199657
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(FakeCorrectedCommand())



# Generated at 2022-06-24 05:45:01.612000
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == '\x1b[41m\x1b[37m\x1b[1m'
    assert color(colorama.Style.RESET_ALL) == '\x1b[0m'

# Generated at 2022-06-24 05:45:04.088990
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        exception('test_title', sys.exc_info())

# Generated at 2022-06-24 05:45:07.742007
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls', side_effect=True))
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))

# Generated at 2022-06-24 05:45:13.091636
# Unit test for function version
def test_version():
    thefuck_version = '3.0'
    python_version = '2.7'
    shell_info = 'bash'
    sys.stderr = open('testversion', 'w')
    version(thefuck_version, python_version, shell_info)
    assert open('testversion', 'r').read() == \
        u'The Fuck 3.0 using Python 2.7 and bash\n'

# Generated at 2022-06-24 05:45:20.673254
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import shell_info
    from . import configuration
    from .conf import Configuration
    from .utils import wrap_streams

    with wrap_streams():
        shell_info.get_shell_info = lambda: 'bash'
        configuration.get_configuration_details = Configuration(
            '~/bash_profile', '.bash_profile',
            'bash -c "source ~/bash_profile"', True).get_details
        how_to_configure_alias(
            configuration.get_configuration_details())


# Generated at 2022-06-24 05:45:24.200723
# Unit test for function failed
def test_failed():
    msg = u'foo'
    failed(msg)
    assert '\x1b[0;31m' + msg + '\x1b[0m' in sys.stderr.getvalue()

# Generated at 2022-06-24 05:45:34.488460
# Unit test for function confirm_text
def test_confirm_text():
    # Tests different states of side_effect
    assert confirm_text(corrected_command=const.CorrectedCommand(script='',
        side_effect=False)) == u'[sudo] password for  master ↑↓/ctrl+c]'
    assert confirm_text(corrected_command=const.CorrectedCommand(script='ls',
        side_effect=False)) == u'[sudo] password for  master ls↑↓/ctrl+c]'
    assert confirm_text(corrected_command=const.CorrectedCommand(script='ls',
        side_effect=True)) == u'[sudo] password for  master ls (+side effect)↑↓/ctrl+c]'



# Generated at 2022-06-24 05:45:36.145670
# Unit test for function exception
def test_exception():
    assert exception('test_title', []) == u"[WARN] test_title:\n\n"

# Generated at 2022-06-24 05:45:38.533135
# Unit test for function debug_time
def test_debug_time():
    warn('Test')
    try:
        with debug_time(u'test'):
            raise Exception()
    except Exception:
        pass

# Generated at 2022-06-24 05:45:43.143794
# Unit test for function version
def test_version():
    import platform
    import os
    import thefuck
    from mock import patch

    version(thefuck._version.__version__,
            platform.python_version(),
            u'{} {}'.format(os.path.basename(sys.executable),
                            platform.platform()))

# Generated at 2022-06-24 05:45:44.948519
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise RuntimeError()
    except RuntimeError:
        rule_failed(None,  sys.exc_info())

# Generated at 2022-06-24 05:45:47.963015
# Unit test for function exception
def test_exception():
    msg = u'exception'
    class Exct(Exception):
        pass

    try:
        raise Exct()
    except:
        exception(msg, sys.exc_info())


# Generated at 2022-06-24 05:45:48.658823
# Unit test for function debug_time
def test_debug_time():
        with debug_time('test'):
            pass

# Generated at 2022-06-24 05:45:52.591599
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('Rule', (object,), {'name': 'ls'})()
    exc_info = (ValueError, ValueError(), None)
    message = u'[WARN] Rule ls:\nTraceback (most recent call last):\n' \
              u'ValueError\n'
    assert rule_failed(rule, exc_info) is None

# Generated at 2022-06-24 05:45:57.067298
# Unit test for function color
def test_color():
    assert color('') == ''
    with settings(no_colors=True):
        assert color('') == ''
    with settings(no_colors=False):
        assert color('') == ''


# Unit tests for functions warn, exception, failed, debug and version

# Generated at 2022-06-24 05:45:59.117222
# Unit test for function rule_failed
def test_rule_failed():
    os.system("cd thefuck")
    os.system("nosetests tests/test_log.py -v")

# Generated at 2022-06-24 05:46:02.230485
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=const.ConfigurationDetails(path='/etc/profile', reload='source /etc/profile',
                                                                         can_configure_automatically=False))



# Generated at 2022-06-24 05:46:03.291409
# Unit test for function warn
def test_warn():
    warn('test_warn')



# Generated at 2022-06-24 05:46:10.518430
# Unit test for function confirm_text
def test_confirm_text():
    # Test if confirm_text return correct output
    # Create corrected_command object
    corrected_command = type('CorrectedCommand', (object,),
                             {'script': 'ls', 'side_effect': ''})
    # Get output from confirm_text
    output = confirm_text(corrected_command)


# Generated at 2022-06-24 05:46:13.325958
# Unit test for function rule_failed
def test_rule_failed():
    # with pytest.raises(Exception) as e:
    #     rule_failed()
    # assert e.value == 'Exception: msg'
    assert True

# Generated at 2022-06-24 05:46:21.586426
# Unit test for function exception

# Generated at 2022-06-24 05:46:28.052343
# Unit test for function exception
def test_exception():
    try:
        return 1 / 0
    except:
        # Python 2
        if sys.version_info[0] == 2:
            # Py 2.6
            if sys.version_info[1] == 6:
                exc_info = (sys.exc_type, sys.exc_value, sys.exc_traceback)
            # Py 2.7
            else:
                exc_info = sys.exc_info()
        # Python 3
        else:
            exc_info = sys.exc_info()
    return exc_info

# Generated at 2022-06-24 05:46:33.125894
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text('file.py') ==
            u'\r{prefix}{clear}{bold}{script}{reset} '
            u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]')



# Generated at 2022-06-24 05:46:34.999237
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck import __version__
    from . import shells
    how_to_configure_alias(shells.get_shell())

# Generated at 2022-06-24 05:46:36.172875
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully.__name__ == 'configured_successfully'



# Generated at 2022-06-24 05:46:37.298690
# Unit test for function debug
def test_debug():
    assert debug(u'Testing the debug function') is None

# Generated at 2022-06-24 05:46:43.892115
# Unit test for function rule_failed
def test_rule_failed():
    class Ex(Exception):
        pass

    def rule_executor(command):
        raise Ex('42')
    rule = type('Rule', (object,), {'name': 'test', 'match': lambda *a: True,
                                    'get_new_command': rule_executor})
    try:
        rule_executor('42')
    except:
        rule_failed(rule, sys.exc_info())
        return
    assert False, 'Exception not raised'

# Generated at 2022-06-24 05:46:53.790298
# Unit test for function exception
def test_exception():
    from StringIO import StringIO
    try:
        raise RuntimeError('test')
    except RuntimeError:
        exc_info = sys.exc_info()
        io = StringIO()
        exception('', exc_info, io)
        assert io.getvalue() == '\x1b[41m\x1b[37m\x1b[1m[WARN] \x1b[0m\n\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m\n\nTraceback (most recent call last):\n  File "thefuck/utils.py", line 7, in test_exception\n    raise RuntimeError(\'test\')\nRuntimeError: test\n'



# Generated at 2022-06-24 05:46:58.680643
# Unit test for function already_configured
def test_already_configured():

    from unittest import mock
    from . import output

    with mock.patch('sys.stdout', new_callable=mock.StringIO):
        output.already_configured(mock.Mock())
        sys.stderr.write(u'Seems like thefuck alias already configured!\nFor applying changes run reload or restart your shell.')


# Generated at 2022-06-24 05:47:01.848580
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls -la')
    show_corrected_command('cd ..')
    show_corrected_command('cat prueba.txt')

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-24 05:47:03.971349
# Unit test for function failed
def test_failed():
    failed('test_failed')
    out, err = capfd.readouterr()
    assert out == '\x1b[31mtest_failed\x1b[0m\n'



# Generated at 2022-06-24 05:47:05.413917
# Unit test for function warn
def test_warn():
    warn(u'title') == u'\x1b[101m[WARN] title\x1b[0m\n'



# Generated at 2022-06-24 05:47:06.555935
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    with debug_time('some_time'):
        sleep(0.5)

# Generated at 2022-06-24 05:47:08.107761
# Unit test for function warn
def test_warn():
    warn(u'Hello')



# Generated at 2022-06-24 05:47:13.261494
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_view
    corrected_command = wrap_view(u'git branch')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'{}git branch{}\n'.format(
        const.USER_COMMAND_MARK, color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:47:18.575963
# Unit test for function rule_failed
def test_rule_failed():
    import collections
    import sys
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    test_rule = collections.namedtuple('rule', 'name')
    rf = test_rule(name = 'test_rule_name')
    rule_failed(rf, 'test_error')
    assert "Rule test_rule_name" in out.getvalue()

# Generated at 2022-06-24 05:47:22.689158
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_colors = []
    test_colors.append(color(colorama.Style.BRIGHT))
    test_colors.append(color(colorama.Style.RESET_ALL))
    assert test_colors == ['', '']

# Generated at 2022-06-24 05:47:24.951669
# Unit test for function color
def test_color():
    assert color('color') == ''
    settings.no_colors = False
    assert color('color') == 'color'



# Generated at 2022-06-24 05:47:27.010532
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("thefuck") == "thefuck alias configured successfully!\nFor applying changes run shell_config or restart your shell."

# Generated at 2022-06-24 05:47:30.492887
# Unit test for function debug_time
def test_debug_time():
    counter = 0

    with debug_time('Test'):
        for x in range(0, 100):
            counter += x

    assert counter == 4950

# Generated at 2022-06-24 05:47:31.145593
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('corrected_command')

# Generated at 2022-06-24 05:47:35.588500
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with patch('sys.stderr') as stderr:
        show_corrected_command(CorrectedCommand(
            script='ls', side_effect=False))
        stderr.write.assert_called_once()
        msg = stderr.write.call_args[0][0]
        assert msg == '$>'

# Generated at 2022-06-24 05:47:42.892875
# Unit test for function debug
def test_debug():
    import os
    # Clear stderr and settings.debug
    sys.stderr = open(os.devnull, 'w')
    settings.debug = False
    debug('test')
    # Assert output is empty
    assert sys.stderr.read() == ''
    # Set settings.debug
    settings.debug = True
    debug('test')
    # Assert output is not empty
    assert sys.stderr.read() != ''

# Generated at 2022-06-24 05:47:46.666949
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
            content=u'',
            path=u'',
            reload=u'',
            can_configure_automatically=False)
    how_to_configure_alias(configuration_details)

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-24 05:47:58.596366
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from datetime import timedelta
    from contextlib import contextmanager
    from types import GeneratorType
    from thefuck.utils import debug, debug_time, settings

    settings.debug = True

    @contextmanager
    def dummy_context():
        with debug_time('foo'):
            yield

    with dummy_context() as c:
        assert isinstance(c, GeneratorType)

    debug.called = False

    with dummy_context():
        assert debug.called is True
        assert debug.msg.startswith(
            u'foo took: ')

    started = datetime.now()
    with debug_time('foo'):
        pass
    ended = datetime.now()
    assert debug.called is True

# Generated at 2022-06-24 05:47:59.602253
# Unit test for function color
def test_color():
    assert color('red') == ''



# Generated at 2022-06-24 05:48:05.023004
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'path': "~/.bashrc", 'reload': '. ~/.bashrc',
                             'content': "fuck=() { eval $(thefuck \"$@\"); }",
                             'can_configure_automatically': False}
    how_to_configure_alias(configuration_details)
    assert True

# Generated at 2022-06-24 05:48:08.495936
# Unit test for function version
def test_version():
    version('0.0.1', '2.6.3', 'bash 4.2.25')
    assert sys.stderr.getvalue() == \
        'The Fuck 0.0.1 using Python 2.6.3 and bash 4.2.25\n'

# Generated at 2022-06-24 05:48:14.231384
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()
    output = u''.join(sys.stdout)

    assert 'Seems like fuck alias isn' in output
    assert 'Users/username' in output
    assert 'https://github.com/nvbn/thefuck#manual-installation\n' in output



# Generated at 2022-06-24 05:48:18.653106
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("git push origin master")
    show_corrected_command("git pull origin master")

# Test script for function test_show_corrected_command
if __name__ == "__main__":
    test_show_corrected_command()

# Generated at 2022-06-24 05:48:21.111747
# Unit test for function configured_successfully
def test_configured_successfully():
    try:
        configured_successfully({"reload":"reload"})
        assert True
    except:
        assert False


# Generated at 2022-06-24 05:48:23.796942
# Unit test for function exception
def test_exception():
    def f():
        raise Exception('Test')

    try:
        f()
    except Exception as e:
        exception(u'Title', sys.exc_info())



# Generated at 2022-06-24 05:48:27.875019
# Unit test for function version
def test_version():
    assert version(thefuck_version='3.12',
                   python_version='2.7',
                   shell_info='shell info') == u'The Fuck 3.12 using Python 2.7 and shell info\n'



# Generated at 2022-06-24 05:48:30.418906
# Unit test for function rule_failed
def test_rule_failed():
    rule = "rule"
    exc_info = "exc_info"
    rule_failed(rule, exc_info)


# Generated at 2022-06-24 05:48:33.012090
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.python import python

    rule_failed(python, ['traceback'])

    # TODO: how to assert stderr here?


# Generated at 2022-06-24 05:48:43.369549
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = StringIO()
    settings.no_colors = False
    corrected_command = CorrectedCommand(script='cd ..', side_effect=None)
    confirm_text(corrected_command)
    settings.no_colors = True
    corrected_command = CorrectedCommand(script='cd ..', side_effect=None)
    confirm_text(corrected_command)
    corrected_command_with_side_effect = CorrectedCommand(
        script='cd ..', side_effect='cd bin')
    confirm_text(corrected_command_with_side_effect)
    settings.no_colors = False
    confirm_text(corrected_command_with_side_effect)

# Generated at 2022-06-24 05:48:44.694011
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None) == None


# Generated at 2022-06-24 05:48:45.925292
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('git status')


# Generated at 2022-06-24 05:48:48.250434
# Unit test for function already_configured
def test_already_configured():
    settings.DEBUG = True
    show(already_configured({'reload':'shell'}))
    settings.DEBUG = False
    show(already_configured({'reload': 'shell'}))

# Generated at 2022-06-24 05:48:50.106809
# Unit test for function color
def test_color():
    assert color(colorama.Fore.YELLOW) == colorama.Fore.YELLOW

# Generated at 2022-06-24 05:48:52.680504
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    corrected_command = Mock()
    corrected_command.script = 'pip install thefuck'
    confirm_text(corrected_command)


# Generated at 2022-06-24 05:49:03.513790
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.lisp import match, get_new_command
    from .shells import Bash, Zsh, Fish, Xonsh
    from .types import Command

    for shell in str(Bash), str(Zsh), str(Fish), str(Xonsh):
        print('\n')
        for command in ('cabal-re', 'cabal configure',
                 'cabal'):
            command = Command(script=command,
                        side_effect=False,
                        stdout=None,
                        stderr=None,
                        env={'THEFUCK_SHELL': shell})
            try:
                output = get_new_command(command, 'cabal-repl')
            except Exception:
                rule_failed(match, sys.exc_info())

# Generated at 2022-06-24 05:49:05.387234
# Unit test for function exception
def test_exception():
    try:
        1/0
    except Exception as e:
        exception('test', sys.exc_info())

# Generated at 2022-06-24 05:49:07.547906
# Unit test for function exception
def test_exception():
    def die():
        1 / 0

    try:
        die()
    except:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:49:08.476857
# Unit test for function color
def test_color():
    assert color('red') == 'red'



# Generated at 2022-06-24 05:49:13.906391
# Unit test for function debug_time
def test_debug_time():
    from thefuck import debug_time
    import time
    from datetime import timedelta
    started = datetime.now()
    with debug_time('foo'):
        time.sleep(1)
    assert sys.stderr.getvalue() == 'foo took: {}\n'.format(timedelta(0, 1, 0))

# Generated at 2022-06-24 05:49:15.473939
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('echo "Fuck"')



# Generated at 2022-06-24 05:49:17.175479
# Unit test for function debug
def test_debug():
    assert debug_time(u'''aaa''') == u'''{blue}{bold}DEBUG:{reset} {msg}\n'''

# Generated at 2022-06-24 05:49:23.140252
# Unit test for function failed
def test_failed():
    f = Failed('test')
    f.write_to_stdout = mock.Mock()
    f.write_to_stderr = mock.Mock()
    assert not f.is_valid()
    f.write_to_stderr.assert_called_once_with(
        u'\x1b[31mtest\x1b[0m\n')



# Generated at 2022-06-24 05:49:24.557606
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule_failed_func', 'exc_info_func')

# Generated at 2022-06-24 05:49:25.554283
# Unit test for function failed
def test_failed():
    failed(u'msg')



# Generated at 2022-06-24 05:49:29.589213
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('sys_stderr_test.log', 'w')
    show_corrected_command('ls')
    with open('sys_stderr_test.log') as f:
        text = f.read()
    assert text == '$ ls\n'
    sys.stderr.close()



# Generated at 2022-06-24 05:49:35.159472
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    old_stderr = sys.stderr
    my_stderr = StringIO()
    sys.stderr = my_stderr
    failed(u"foo")
    assert sys.stderr is my_stderr
    sys.stderr = old_stderr

# Generated at 2022-06-24 05:49:36.753308
# Unit test for function warn
def test_warn():
    warn('test_warn')



# Generated at 2022-06-24 05:49:38.940324
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test exception')
    except Exception:
        exception('test exception', sys.exc_info())

# Generated at 2022-06-24 05:49:41.748619
# Unit test for function failed
def test_failed():
    failed('mock')
    assert sys.stderr.getvalue() == u'\x1b[31mmock\x1b[0m\n'



# Generated at 2022-06-24 05:49:52.927720
# Unit test for function already_configured
def test_already_configured():
    import mock
    import thefuck.shells
    import thefuck.output
    reload_alias = thefuck.shells.get_aliases()['reload']
    expected_output = (u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=thefuck.output.color(const.BOLD),
            reset=thefuck.output.color(const.RESET),
            reload=reload_alias))
    with mock.patch('__builtin__.print') as mock_print:
        thefuck.output.already_configured(thefuck.shells.get_aliases())
        mock_print.assert_called_with(expected_output)


# Generated at 2022-06-24 05:49:56.439495
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'corrected_command'
    corrected_command = corrected_command + ' side_effect'
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:49:58.456468
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'red') == '\033[31mred'



# Generated at 2022-06-24 05:50:02.032939
# Unit test for function configured_successfully
def test_configured_successfully():
    from mock import Mock
    from thefuck.shells import Shell
    config = Mock()
    config.reload = ''
    shell = Mock(Shell)
    shell.get_configuration.return_value = config
    configured_successfully(shell)

# Generated at 2022-06-24 05:50:02.932961
# Unit test for function warn
def test_warn():
    warn('Test title')



# Generated at 2022-06-24 05:50:05.913082
# Unit test for function already_configured
def test_already_configured():
    configuration_details = Const.configuration_details
    expected_output = u'Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1m. ~/.bashrc\x1b[21m or restart your shell.'
    assert already_configured(configuration_details) == expected_output

# Generated at 2022-06-24 05:50:11.256195
# Unit test for function debug_time
def test_debug_time():
    from time import time
    from time import sleep
    from thefuck.utils import debug_time
    t = time()
    with debug_time("for a while"):
        sleep(0.2)
    return time() - t >= 0.2


import unittest

# Generated at 2022-06-24 05:50:17.040371
# Unit test for function confirm_text
def test_confirm_text():
    # create a class to ensure type checking
    class CorrectedCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect
    corrected_command = CorrectedCommand('test', True)
    assert confirm_text(corrected_command) == '>test (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:50:28.437724
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    import sys
    mock_stdout = StringIO()
    sys.stderr = mock_stdout
    cmd_script = 'git push'
    cmd_has_side_effect = False
    prompt = color(colorama.Style.RESET_ALL) + \
        color(colorama.Fore.BLUE) + \
        color(colorama.Style.DIM) + \
        color(colorama.Style.BRIGHT) + \
        color(colorama.Fore.GREEN) + \
        color(colorama.Fore.RED) + \
        color(colorama.Back.RED) + \
        color(colorama.Back.YELLOW) + \
        color(colorama.Back.GREEN) + \
        color(colorama.Fore.WHITE)

# Generated at 2022-06-24 05:50:30.997665
# Unit test for function warn
def test_warn():
    warn('test_warn')



# Generated at 2022-06-24 05:50:40.769261
# Unit test for function failed
def test_failed():
    from .utils import ELLIPSIS

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        failed(u'Шаблон не найден')

# Generated at 2022-06-24 05:50:43.513618
# Unit test for function show_corrected_command
def test_show_corrected_command():
    executable = u'$(brew --prefix nginx)/sbin/nginx'
    script = u'nginx'
    corrected_command = const.Command(executable, script)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:50:46.274099
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        def __str__(self):
            return 'Some test exception'


# Generated at 2022-06-24 05:50:50.669429
# Unit test for function already_configured
def test_already_configured():
    from thefuck.types import ConfigurationDetails
    conf_det = ConfigurationDetails(path='test_path',
                                    can_configure_automatically='test_automatically',
                                    reload='test_reload')
    already_configured(conf_det)

# Generated at 2022-06-24 05:50:52.103062
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('null')


# Generated at 2022-06-24 05:50:54.571358
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully({'reload': 'source $HOME/.bash_profile'}) == None



# Generated at 2022-06-24 05:51:01.939430
# Unit test for function configured_successfully
def test_configured_successfully():
    out = u''
    for i in range(100):
        sys.stderr = FakeOutput()
        configured_successfully(None)
        out += sys.stderr.out
        sys.stderr = sys.__stderr__
    assert out == u'\x1b[32m\x1b[1mfuck\x1b[21m\x1b[39m alias configured successfully!\n' \
                  u'For applying changes run \x1b[32m\x1b[1mreload\x1b[21m\x1b[39m or restart your shell.\n' * 100



# Generated at 2022-06-24 05:51:07.650366
# Unit test for function failed
def test_failed():
    from io import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO()
    failed('test')
    assert sys.stderr.getvalue() == u'\x1b[31mtest\x1b[0m\n'
    sys.stderr = stderr



# Generated at 2022-06-24 05:51:12.184027
# Unit test for function failed
def test_failed():
    import StringIO
    stream = StringIO.StringIO()
    sys.stderr = stream
    failed(u"message")
    sys.stderr = sys.__stderr__
    assert stream.getvalue() == u'\x1b[31mmessage\x1b[0m\n'



# Generated at 2022-06-24 05:51:14.440224
# Unit test for function exception
def test_exception():
    def test():
        raise ValueError('Test')

    try:
        test()
    except Exception:
        exception(u'Test', sys.exc_info())



# Generated at 2022-06-24 05:51:15.940853
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None



# Generated at 2022-06-24 05:51:24.129018
# Unit test for function rule_failed
def test_rule_failed():
    '''
    Test to check if the function rule_failed is working correctly
    '''
    class temp_class(object):
        '''
        Temp class to test rule_failed function
        '''
        def __init__(self):
            self.name = 'rule name'
            self.exc_info = sys.exc_info()

    ex = Exception()
    try:
        raise ex
    except Exception:
        temp_obj = temp_class()
        try:
            rule_failed(temp_obj, sys.exc_info())
        except Exception:
            assert True

# Generated at 2022-06-24 05:51:27.528224
# Unit test for function failed
def test_failed():
    const.user_home = '/tmp/'
    failed("error")
    assert open("/tmp/thefuck.log", "r").read() == "error\n"
    open("/tmp/thefuck.log", "w").close()


# Generated at 2022-06-24 05:51:31.633810
# Unit test for function warn
def test_warn():
    warn("title")
    assert sys.stderr.getvalue() == u'\x1b[41m\x1b[97m\x1b[1m[WARN] '\
        u'title\x1b[0m\n'



# Generated at 2022-06-24 05:51:33.881103
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(object())


# Generated at 2022-06-24 05:51:39.531038
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand(u'git pu', True))
    show_corrected_command(CorrectedCommand(u'git pu', False))

# Generated at 2022-06-24 05:51:43.401924
# Unit test for function version
def test_version():
    thefuck_version = "v1"
    python_version = "3.6"
    shell_info = "Linux"
    version(thefuck_version, python_version, shell_info)



# Generated at 2022-06-24 05:51:52.931478
# Unit test for function rule_failed
def test_rule_failed():
    import mock
    import pytest
    from thefuck.rules.git_branch import get_new_command
    from thefuck.rules.git_branch import match
    from thefuck.rules.git_branch import rule
    from thefuck.types import Command
    from thefuck.main import confirm

    with pytest.raises(SystemExit):
        with mock.patch('thefuck.main.sys') as mock_sys:
            confirm(get_new_command, Command('git branch test', 'fatal: no'
                                             '-such-branch'), [])

# Generated at 2022-06-24 05:51:55.741177
# Unit test for function debug_time
def test_debug_time():
    import time
    for i in range(10):
        with debug_time('test'):
            time.sleep(0.2)

# Generated at 2022-06-24 05:52:03.261179
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys
    import unittest

    import mock

    class TestShowCorrectedCommand(unittest.TestCase):
        def setUp(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr

        def testShowCorrectedCommand(self):
            sys.stdout = io.BytesIO()
            sys.stderr = io.BytesIO()

            with mock.patch('sys.stdout', sys.stdout), \
                    mock.patch('sys.stderr', sys.stderr):
                show_corrected_command(
                    mock.Mock(script='cd /tmp', side_effect=True))
                self.assertEqual(sys.stderr.getvalue(),
                                 '$ cd /tmp (+side effect)\n')

            sys

# Generated at 2022-06-24 05:52:04.504014
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test-debug-time"):
        pass


# Generated at 2022-06-24 05:52:06.333005
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("ls -a")


# Generated at 2022-06-24 05:52:07.907283
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('test'):
        time.sleep(0.05)

# Generated at 2022-06-24 05:52:08.820490
# Unit test for function already_configured
def test_already_configured():
    already_configured('source ~/.bash_profile')

# Generated at 2022-06-24 05:52:11.082554
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('Hello, world!') == 'FUCK>Hello, world! [enter/↑/↓/ctrl+c]'


# mock this function to make tests run faster

# Generated at 2022-06-24 05:52:12.045882
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(False)

# Generated at 2022-06-24 05:52:13.334866
# Unit test for function configured_successfully
def test_configured_successfully():
    class configuration_details():
        reload = 'reload'
    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:52:16.496138
# Unit test for function color
def test_color():
    with settings:
        settings.no_colors = False
        assert color(colorama.Fore.RED)
        settings.no_colors = True
        assert not color(colorama.Fore.RED)

# Generated at 2022-06-24 05:52:21.711470
# Unit test for function already_configured
def test_already_configured():
    import tempfile, sys
    old_stderr = sys.stderr
    tmp = tempfile.mkstemp()
    sys.stderr = open(tmp[1], 'w')
    already_configured('')
    sys.stderr.close()
    sys.stderr = old_stderr
    assert open(tmp[1], 'r').read() == 'Seems like fuck alias already configured!\nFor applying changes run or restart your shell.\n'

# Generated at 2022-06-24 05:52:26.630034
# Unit test for function rule_failed
def test_rule_failed():
    from . import rulegraph
    from .exceptions import FailedCommand, CommandNotFound
    rule = rulegraph.Rule()
    exc_info = CommandNotFound.__name__, CommandNotFound('cmd'), None
    rule_failed(rule, exc_info)
    exc_info = FailedCommand.__name__, FailedCommand('cmd'), None
    rule_failed(rule, exc_info)

# Generated at 2022-06-24 05:52:27.239189
# Unit test for function failed
def test_failed():
    failed(u'Something went wrong')



# Generated at 2022-06-24 05:52:29.875320
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.conf import NoRuleMatched
    rule_failed('NoRuleMatched', exc_info=[NoRuleMatched('hello')])

# Generated at 2022-06-24 05:52:31.474246
# Unit test for function exception
def test_exception():
    try:
        raise Exception
    except Exception:
        exception(u"test", sys.exc_info())

# Generated at 2022-06-24 05:52:32.962206
# Unit test for function version
def test_version():
    assert(version(
            "3.6",
            "3.4",
            "sh") == None)

# Generated at 2022-06-24 05:52:33.630487
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully()

# Generated at 2022-06-24 05:52:36.621459
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.sed import sed

    rule_failed(sed.rule, (sed.rule.execute, sed.rule.execute(''), ''))

# Generated at 2022-06-24 05:52:41.634420
# Unit test for function debug
def test_debug():
    import StringIO
    with open('/dev/tty', 'w') as sys.stderr:
        debug('hello world')
    captured_output = StringIO.StringIO()
    sys.stderr = captured_output
    debug('hello world')
    sys.stderr.close()
    output = captured_output.getvalue()
    return output == ''
