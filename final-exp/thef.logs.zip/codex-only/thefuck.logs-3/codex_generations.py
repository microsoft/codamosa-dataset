

# Generated at 2022-06-24 05:42:51.019625
# Unit test for function already_configured
def test_already_configured():
    # Test 1
    configuration_details_1 = {
        'reload': "Just execute 'source ~/.bashrc'"
    }
    # Test 2
    configuration_details_2 = {
        'reload': "Just execute 'source ~/.bashrc'"
    }
    # Test 3
    configuration_details_3 = {
        'reload': "Just execute 'source ~/.bashrc'"
    }
    # Test 4
    configuration_details_4 = {
        'reload': "Just execute 'source ~/.bashrc'"
    }
    # Test 5
    configuration_details_5 = {
        'reload': "Just execute 'source ~/.bashrc'"
    }
    assert already_configured(configuration_details_1) == None
    assert already_configured(configuration_details_2) == None
    assert already_config

# Generated at 2022-06-24 05:42:54.285931
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type(u'', (), dict(reload=u'reload'))
    # ensure that no exception is raised
    already_configured(configuration_details)

# Generated at 2022-06-24 05:42:57.743213
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import Command
    from . import main
    command = Command('ls', 'ls -la', '')
    show_corrected_command(command)
    main.confirm_command(command)

# Generated at 2022-06-24 05:43:03.370532
# Unit test for function exception
def test_exception():
    with_traceback = lambda *args: (args, sys.exc_info())
    try:
        1 / 0
    except ZeroDivisionError:
        sys.stderr.write(
            u'{prefix}[{date}] {msg}\n'.format(
                prefix=color(colorama.Fore.MAGENTA),
                date=datetime.utcnow(),
                msg=with_traceback(*sys.exc_info())[1]))

# Generated at 2022-06-24 05:43:12.604740
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import StringIO
    import datetime as dt

    with unittest.mock.patch('thefuck.shells.get_temporary_text_editor') as ed:
        ed.return_value = 'vim'
        io = StringIO.StringIO()
        with unittest.mock.patch('thefuck.shells.get_all_executables') as all_ex:
            all_ex.return_value = ['vim']
            ed_cmd = get_temporary_text_editor_command('mocked')
            assert ed_cmd == 'vim'
            io.write('something')
            io.seek(0)
            assert io.read() == 'something'
            io.close()

# Generated at 2022-06-24 05:43:15.583581
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''
    assert color(colorama.Style.RESET_ALL) == ''

# Generated at 2022-06-24 05:43:16.897461
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:43:19.609733
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'rule'
    exc_info = 'exc_info'
    assert rule_failed(rule, exc_info) == None



# Generated at 2022-06-24 05:43:23.308084
# Unit test for function already_configured
def test_already_configured():
    already_configured('/home/user/.bashrc')
    already_configured('/home/user/.config/fish/config.fish')
    already_configured('/home/user/.zshrc')


# Generated at 2022-06-24 05:43:24.799407
# Unit test for function debug
def test_debug():
    debug(u'no colors')
    debug(u'with colors')

# Generated at 2022-06-24 05:43:26.419148
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command({'script': 'cd ..'})


# Generated at 2022-06-24 05:43:33.532790
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            can_configure_automatically=True,
            path=u'/tmp/test',
            content=u'content',
            reload=u'reload'))
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails(
            can_configure_automatically=False,
            path=u'/tmp/test',
            content=u'content',
            reload=u'reload'))



# Generated at 2022-06-24 05:43:37.062767
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple('configuration_details', 'path content reload can_configure_automatically')
    configuration_details.path = "path"
    configuration_details.content = "content"
    configuration_details.reload = "reload"
    configuration_details.can_configure_automatically = True
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-24 05:43:43.117488
# Unit test for function version
def test_version():
    thefuck_version = '1.0'
    python_version = '3.5.1'
    shell_info = 'sh'
    result = u'The Fuck 1.0 using Python 3.5.1 and sh\n'
    version(thefuck_version, python_version, shell_info) == result

if __name__ == '__main__':
    test_version()

# Generated at 2022-06-24 05:43:53.382488
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import memoize
    from .shells import Shell
    from .correctors import Corrector
    from .rules.docker import match, get_new_command
    from . import const
    from .settings import Settings

    class Docker(Shell):
        @property
        def name(self):
            return 'docker'

        @property
        def conf(self):
            return const.DEFAULT_ALIASES[self.name]

        @property
        def python(self):
            return 'python'

        @memoize
        def get_aliases(self):
            return {'docker': 'fuck docker'}

        @classmethod
        def get_current_shell(cls):
            return cls()


# Generated at 2022-06-24 05:43:58.561023
# Unit test for function rule_failed
def test_rule_failed():
    with open('/tmp/output', 'w') as output:
        sys.stderr = output
        rule_failed('example', 'exc_info')
    with open('/tmp/output', 'r') as output:
        assert output.read() == '[WARN] Rule example:\n'



# Generated at 2022-06-24 05:44:00.495069
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test_exception')
    except:
        exception('test', sys.exc_info())

# Generated at 2022-06-24 05:44:01.716715
# Unit test for function debug
def test_debug():
    with debug_time(u'test_debug') as timer:
        pass

# Generated at 2022-06-24 05:44:06.656612
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    stdout = StringIO()
    stderr = StringIO()
    sys.stdout = stdout
    sys.stderr = stderr
    warn('title')
    assert stderr.getvalue() == '\x1b[41m\x1b[37;1m[WARN] title\x1b[0m\n'
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:44:11.759048
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("alias fuck='thefuck' # by the fuck")

    how_to_configure_alias("alias fuck='thefuck' # by the fuck")

    how_to_configure_alias("alias fuck='thefuck' # by the fuck")

# Generated at 2022-06-24 05:44:14.769195
# Unit test for function already_configured
def test_already_configured():
    already_configured = already_configured("something")
    assert already_configured == 'Seems like fuck alias already configured!\nFor applying changes run something or restart your shell.'



# Generated at 2022-06-24 05:44:24.880832
# Unit test for function debug_time
def test_debug_time():
    from contextlib import closing
    from tempfile import NamedTemporaryFile

    with closing(NamedTemporaryFile()) as debug_file:
        old_debug = settings.debug
        old_debug_file = settings.debug_file

        settings.debug = True
        settings.debug_file = debug_file.name

        started = datetime.now()

        with debug_time('1'):
            with debug_time('2'):
                pass

        assert datetime.now() - started > datetime.strptime(
            u'0:00:00.20', '%H:%M:%S.%f')

        debug_file.seek(0)
        debug_file_content = debug_file.read()

        assert u'2 took: ' in debug_file_content
        assert u'1 took: ' in debug

# Generated at 2022-06-24 05:44:30.300230
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck import types
    corrected_command = types.CorrectedCommand(u'git branch fix', True)
    dump = open(u'/dev/null', u'w')
    _stdout = sys.stdout
    sys.stdout = dump
    show_corrected_command(corrected_command)
    sys.stdout = _stdout
    dump.close()

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-24 05:44:32.041119
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command(u'vim', True))
    assert True


# Generated at 2022-06-24 05:44:33.294896
# Unit test for function debug
def test_debug():
    with debug_time(u'test_message'):
        pass

# Generated at 2022-06-24 05:44:35.183219
# Unit test for function exception
def test_exception():
    try:
        raise TypeError('test')
    except Exception:
        exception('Exception test', sys.exc_info())
        assert True


# Generated at 2022-06-24 05:44:38.567688
# Unit test for function failed
def test_failed():
    import StringIO

    with settings(no_colors=True):
        caught = StringIO.StringIO()
        sys.stderr = caught
        failed('message')
        assert caught.getvalue() == 'message\n'

    with settings(no_colors=False):
        caught = StringIO.StringIO()
        sys.stderr = caught
        failed('message')
        assert caught.getvalue() == '\x1b[91mmessage\x1b[0m\n'
        assert caught.getvalue()



# Generated at 2022-06-24 05:44:44.354896
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand

    assert (
        '\n'.join(show_corrected_command(CorrectedCommand('ls', '')))
        .encode('utf-8') ==
        '{}ls{}'.format(const.USER_COMMAND_MARK,
                        colorama.Style.RESET_ALL))

    assert (
        '\n'.join(show_corrected_command(CorrectedCommand('ls', True)))
        .encode('utf-8') ==
        '{}ls{} (+side effect)'.format(const.USER_COMMAND_MARK,
                                       colorama.Style.RESET_ALL))


# Generated at 2022-06-24 05:44:54.778044
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("ls") == (u'➜ ls [+] [enter/↑/↓/ctrl+c]')
    assert confirm_text("pwd") == (u'➜ pwd [+] [enter/↑/↓/ctrl+c]')
    assert confirm_text("cat") == (u'➜ cat [+] [enter/↑/↓/ctrl+c]')
    assert confirm_text("df") == (u'➜ df [+] [enter/↑/↓/ctrl+c]')
    assert confirm_text("ping") == (u'➜ ping [+] [enter/↑/↓/ctrl+c]')
    assert confirm_text("git") == (u'➜ git [+] [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-24 05:44:57.781885
# Unit test for function failed
def test_failed():
    failed('failed')



# Generated at 2022-06-24 05:45:02.964708
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    with mock.patch('sys.stderr') as stderr:
        with debug_time('test_message'):
            time.sleep(0.1)
            pass

    assert stderr.write.call_args[0][0].startswith('DEBUG: test_message took: ')

# Generated at 2022-06-24 05:45:06.721868
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import thefuck.shells.bash as bash
    corrected_command = bash.CorrectedCommand('git status', True)
    show_corrected_command(corrected_command)


# Generated at 2022-06-24 05:45:10.296916
# Unit test for function failed
def test_failed():
    import StringIO
    import sys
    sys.stderr = StringIO.StringIO()
    message = 'Something went wrong'
    failed(message)
    assert 'Something went wrong' in sys.stderr.getvalue()



# Generated at 2022-06-24 05:45:18.968193
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import re
    import colorama
    from .conf import settings
    from .utils import get_all_executables
    from .replacer import split_command

    settings.no_colors = True
    settings.hist_size = 0
    corrected_commands = [
        corrected_command
        for command in ('fuck', 'git add .')
        for corrected_command in get_all_executables(
            *split_command(command))]
    sys.stderr.write('>>>\n')
    show_corrected_command(corrected_commands[0])
    show_corrected_command(corrected_commands[1])
    sys.stderr.write('<<<\n')

# Generated at 2022-06-24 05:45:22.233445
# Unit test for function already_configured
def test_already_configured():
    from thefuck.utils import NamedTuple
    configuration_details = NamedTuple(path='', content='', reload='')
    already_configured(configuration_details)


# Generated at 2022-06-24 05:45:33.010021
# Unit test for function debug_time
def test_debug_time():
    import unittest

    class DebugTimeTest(unittest.TestCase):
        def setUp(self):
            # Save original value of debug_time
            self.orig_debug_time = sys.modules['builtins'].debug_time
            sys.modules['builtins'].debug_time = lambda x: None

        def tearDown(self):
            # Restore original value of debug_time
            sys.modules['builtins'].debug_time = self.orig_debug_time

        def test_debug_time(self):
            """ We have to use core's debug_time function to avoid
            nested context managers
            """
            with debug_time('Test'):
                pass

    unittest.main()

# Generated at 2022-06-24 05:45:35.988383
# Unit test for function rule_failed
def test_rule_failed():
    """
    >>> import sys
    >>> sys.stderr = sys.stdout
    >>> rule_failed('fuck', ('hello', 'there'))
    [WARN] Rule fuck:
    Traceback (most recent call last):
    hello
    there

    """


# Generated at 2022-06-24 05:45:41.370933
# Unit test for function version
def test_version():
    def fake_stderr_write(msg):
        assert msg == (u'The Fuck {} using Python {} and {}\n'.format(
            '0.0', '0.0', 'shell'))

    sys.stderr.write = fake_stderr_write
    version('0.0', '0.0', 'shell')



# Generated at 2022-06-24 05:45:46.754765
# Unit test for function debug
def test_debug():
    from . import utils
    from .utils import _session

    monkey = utils.monkeypatch_module(_session)
    monkey.setattr(_session, 'isatty', lambda: True)
    monkey.setattr(_session, '__getitem__', lambda key: True)

    debug_msg = 'foo'
    debug(debug_msg)

    monkey.undo()

# Generated at 2022-06-24 05:45:55.225598
# Unit test for function confirm_text
def test_confirm_text():
    settings.load()
    settings.no_colors = True
    assert confirm_text(
        mock_corrected_command('fuck')) == \
           '{prefix}fuck [enter/↑/↓/ctrl+c]'.format(prefix=const.USER_COMMAND_MARK)
    settings.load()
    settings.no_colors = False
    assert confirm_text(mock_corrected_command('fuck')) == \
           '{prefix}fuck [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'.format(prefix=const.USER_COMMAND_MARK)


# Generated at 2022-06-24 05:46:03.130834
# Unit test for function failed
def test_failed():
    import tempfile
    import os
    with tempfile.TemporaryFile(mode="w+", encoding="utf-8") as tmp:
        sys.stderr = tmp
        failed(u'foo')
        sys.stderr.seek(0)
        assert sys.stderr.read() == u'{red}foo{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL))
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:46:04.528061
# Unit test for function debug_time
def test_debug_time():
    def foo():
        with debug_time('msg'):
            pass

    foo()

# Generated at 2022-06-24 05:46:08.784030
# Unit test for function warn
def test_warn():
    import StringIO
    old_stderr = sys.stderr
    sys.stderr = stderr = StringIO.StringIO()
    warn('title')
    out = stderr.getvalue()
    sys.stderr = old_stderr
    assert out == u'\x1b[41m[WARN] title\x1b[0m\n'


# Generated at 2022-06-24 05:46:11.832184
# Unit test for function exception
def test_exception():
    def test():
        asd = 1
        asd()

    try:
        test()
    except:
        exception(u'title', sys.exc_info())

# Generated at 2022-06-24 05:46:14.474773
# Unit test for function already_configured
def test_already_configured():
    configuration_details = type('', (), {})()
    configuration_details.reload = 'source ~/.bash_profile'
    already_configured(configuration_details)

# Generated at 2022-06-24 05:46:21.473925
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    settings.no_colors = True
    settings.side_effect = False
    command = 'alias fuck="fuck command"'
    message = '{}\n'.format(command)
    stderr = StringIO()
    sys.stderr = stderr
    confirm_text(command)
    sys.stderr = sys.__stderr__
    assert stderr.getvalue() == message
    settings.no_colors = False

    settings.no_colors = False
    settings.side_effect = True
    command = 'alias fuck="fuck command"'

# Generated at 2022-06-24 05:46:23.686145
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import time
    with debug_time('test'):
        time.sleep(1)



# Generated at 2022-06-24 05:46:27.654920
# Unit test for function already_configured
def test_already_configured():
    assert u'Seems like \x1b[1mfuck\x1b[0m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[0m or restart your shell.'==already_configured(configuration_details='reload')

# Generated at 2022-06-24 05:46:34.757021
# Unit test for function configured_successfully
def test_configured_successfully():
    assert u"The Fuck 3.4" in version("3.4", "3.4", "bash")
    assert u"The Fuck 3.4.0" in version("3.4.0", "3.4", "bash")
    assert u"The Fuck 3.4.0" in version("3.4.0", "3.4.0", "bash")
    assert u"The Fuck 3.4.0" in version("3.4.0", "3.4.0", "ba")

# Generated at 2022-06-24 05:46:36.922318
# Unit test for function warn
def test_warn():
    sys.stderr = open('test_warn.txt', 'w')
    warn('title')
    sys.stderr.close()
    assert open('test_warn.txt').read() == '[WARN] title\n'



# Generated at 2022-06-24 05:46:42.080997
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({'content': 'content', 'path': 'path', 'reload': 'reload'})
    how_to_configure_alias({'content': 'content', 'path': 'path', 'reload': 'reload', 'can_configure_automatically': True})
    how_to_configure_alias(None)


# Generated at 2022-06-24 05:46:43.997517
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule','exc_info')
    assert 1
test_rule_failed()


# Generated at 2022-06-24 05:46:45.371857
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully() == 'fuck alias configured successfully!\nFor applying changes run source ~/.bash_profile or restart your shell'

# Generated at 2022-06-24 05:46:49.890619
# Unit test for function debug
def test_debug():
    import StringIO
    stream = StringIO.StringIO()
    save_stream = sys.stderr
    try:
        sys.stderr = stream
        debug(u'Dummy debug message')
        assert stream.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Dummy debug message\n'
    finally:
        sys.stderr = save_stream

# Generated at 2022-06-24 05:46:59.049718
# Unit test for function failed
def test_failed():
    from io import StringIO
    from textwrap import dedent

    with StringIO() as buf, StringIO() as err:
        old_stdout, old_stderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = buf, err

        msg = u'Test msg'
        failed(msg)

        sys.stdout, sys.stderr = old_stdout, old_stderr

        assert err.getvalue().strip() == dedent('''\
            {red}{msg}{reset}
            '''.format(
                msg=msg,
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-24 05:47:01.114479
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        exception('test', sys.exc_info())


# Generated at 2022-06-24 05:47:07.076843
# Unit test for function version
def test_version():
    test_version = '3.0'
    python_version = '3.4.6'
    shell_info = 'ShellNotSupportedError'
    sys.stderr = open('/dev/null', 'w')
    version(test_version, python_version, shell_info)
    sys.stderr = open('/dev/null', 'r')

# Generated at 2022-06-24 05:47:14.460297
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    from .command import Command
    from .conf import settings
    settings.no_colors = False
    mocked_stderr = mock.MagicMock()
    with mock.patch('sys.stderr', mocked_stderr):
        show_corrected_command(Command(script='ls', side_effect=True))
    assert mocked_stderr.write.call_args[0][0] == \
        u'[0m>[1m[39mls[0m (+side effect)\n'

# Generated at 2022-06-24 05:47:19.447778
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except Exception as e:
        exc_info = sys.exc_info()
        result = ''.join(format_exception(*exc_info))
        assert 'ZeroDivisionError: integer division or modulo by zero' in result
        assert 'File "thefuck/ui.py", line 57, in test_exception' in result



# Generated at 2022-06-24 05:47:26.443590
# Unit test for function debug_time
def test_debug_time():
    """
    start: 14:00:00.000
    end: 14:00:00.001
    elapsed: 1 ms

    debug_time should return 1ms because of default time.sleep(0.001)
    """
    import time
    # Measure elapsed time
    start = datetime.now()
    time.sleep(0.001)
    end = datetime.now()
    elapsed = end - start
    assert test_debug_time_inner(elapsed) == 1

# Generated at 2022-06-24 05:47:29.567922
# Unit test for function failed
def test_failed():
    failed(u'failed')
    sys.stderr.write(u'\n')



# Generated at 2022-06-24 05:47:33.121843
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('/usr/local/bin/fuck',
                           '~/.bashrc',
                           'source ~/.bashrc')


if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-24 05:47:34.742463
# Unit test for function rule_failed
def test_rule_failed():
    rule = "Rule"
    exc_info = ("value1", "value2", "value3")
    expected_result = "Rule failed: "
    assert(rule_failed(rule, exc_info) == expected_result)


# Generated at 2022-06-24 05:47:37.760386
# Unit test for function debug
def test_debug():
    from .application import Application
    debug(u'debug')
    assert settings.debug == True

# Generated at 2022-06-24 05:47:38.665668
# Unit test for function failed
def test_failed():
    failed(u'Hello, World!')

# Generated at 2022-06-24 05:47:42.685372
# Unit test for function exception
def test_exception():
    exit_code = 0

    def test_function():
        1/0

    try:
        test_function()
    except Exception as e:
        exception('name', sys.exc_info())
        exit_code = 1

    assert exit_code is 1

# Generated at 2022-06-24 05:47:50.140818
# Unit test for function exception
def test_exception():
    # temp_buffer is stdout
    from StringIO import StringIO
    from .mdl import Rule
    import sys

    temp_buffer = StringIO()
    sys.stderr = temp_buffer
    exception('Rule TestRule', ([1, 2, 3], 1, "test"))
    sys.stderr = sys.__stderr__

    # check that exception message is printed to stderr

# Generated at 2022-06-24 05:47:51.586258
# Unit test for function color
def test_color():
    assert color('') == ''



# Generated at 2022-06-24 05:47:58.844688
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Case command with side effect
    corrected_command = const.CorrectedCommand(
        script='git push git@heroku.com:my-app.git',
        is_side_effect=True)
    show_corrected_command(corrected_command)
    # Case normal command
    corrected_command = const.CorrectedCommand(
        script='git push git@heroku.com:my-app.git',
        is_side_effect=False)
    show_corrected_command(corrected_command)


# Generated at 2022-06-24 05:48:09.222217
# Unit test for function exception
def test_exception():
    def fake_format_exception(*args):
        return ['{}\n'.format(args)]

    original_format_exception = format_exception
    format_exception = fake_format_exception
    try:
        exception('', ('', '', ''))
        return ''.join(sys.stderr.getvalue()) == \
            u'{warn}[WARN] {}:{reset}\n{trace}' \
            u'{warn}----------------------------{reset}\n\n'.format(
                warn=color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                trace=''.join(format_exception(('', '', ''))))
    finally:
        format_exception = original_

# Generated at 2022-06-24 05:48:15.975091
# Unit test for function failed
def test_failed():
    import StringIO
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        failed(u'failed')
        assert u'\u001b[31mfailed\u001b[39m\n' == out.getvalue()
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:48:19.795995
# Unit test for function debug
def test_debug():
    from mock import patch, Mock

    with patch('sys.stderr') as mock_stderr:
        debug(u'foo')
        mock_stderr.write.assert_called_with(u'foo\n')

# Generated at 2022-06-24 05:48:22.246938
# Unit test for function configured_successfully
def test_configured_successfully():
    test_config_settings = {'reload': u'exec -l $SHELL'}
    configured_successfully(test_config_settings)

# Generated at 2022-06-24 05:48:27.874970
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from . import debug_time as _debug_time
    from .conf import settings
    settings.debug = True
    try:
        with _debug_time(u'time me'):
            assert datetime.now() + timedelta(seconds=1)
    finally:
        settings.debug = False
        del settings.debug

# Generated at 2022-06-24 05:48:32.835179
# Unit test for function color
def test_color():
    assert color(u'foo') == u''
    assert color(u'foo' + colorama.Style.RESET_ALL) == u''

    settings.no_colors = False
    assert color(u'foo') == u'foo'
    assert color(u'foo' + colorama.Style.RESET_ALL) == u'foo'

# Generated at 2022-06-24 05:48:35.474479
# Unit test for function color
def test_color():
    assert u'\x1b[0m' == color(u'\x1b[0m')
    assert u'' == color('\x1b[0m')



# Generated at 2022-06-24 05:48:36.431155
# Unit test for function debug_time
def test_debug_time():
    with debug_time('func'):
        pass

# Generated at 2022-06-24 05:48:39.886920
# Unit test for function version
def test_version():
    thefuck_version = '1'
    python_version = '2'
    shell_info = '3'
    version(thefuck_version, python_version, shell_info)



# Generated at 2022-06-24 05:48:45.245513
# Unit test for function version
def test_version():
    import io

    sys.stderr = io.StringIO()
    version('3.1', '2.7.6', 'Bash 3.2.57(1)-release (x86_64-apple-darwin13)')
    assert sys.stderr.getvalue() == \
        'The Fuck 3.1 using Python 2.7.6 and Bash 3.2.57(1)-release (x86_64-apple-darwin13)\n'

# Generated at 2022-06-24 05:48:57.024023
# Unit test for function confirm_text
def test_confirm_text():
    # Opening the file that contains the content of the file
    f = open('/home/abhishek/Desktop/Project/fuck_test.py', 'a+')
    # Writing the user input line into the file
    f.write('fuck_test\n')
    # Closing the file
    f.close()
    # Opening the file that contains the content of the file
    f1 = open('/home/abhishek/Desktop/Project/fuck_test.py', 'r+')
    # Reading the user input line from the file
    for line in f1:
        if line:
            # Calling the confirm_text function
            confirm_text(line)
            # Closing the file
            f1.close()
            # Removing the line from the file
            f1.remove(line)
            break

# Generated at 2022-06-24 05:48:57.747419
# Unit test for function version
def test_version():
    pass

# Generated at 2022-06-24 05:49:07.589582
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text('clear') ==
            u'{prefix}clear [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]')
    assert (confirm_text('clear\n') ==
            u'{prefix}clear [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]')
    assert (confirm_text('clear\n') ==
            u'{prefix}clear [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]')


# Generated at 2022-06-24 05:49:08.401170
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(show_corrected_command('git push origin master'))


# Generated at 2022-06-24 05:49:16.389251
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from .conf import Settings
    settings = Settings()
    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        warn('test warn')
        output = out.getvalue().strip()
        assert output == '\x1b[41m\x1b[37m\x1b[1m[WARN] test warn\x1b[0m'
    finally:
        sys.stderr = saved_stderr



# Generated at 2022-06-24 05:49:23.187319
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(const.CorrectedCommand('cmd', False)) == u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-24 05:49:28.226326
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell, types
    from mock import patch
    from StringIO import StringIO

    out = StringIO()
    corrected_command = types.CorrectedCommand('echo "spam"', '!')
    # If a line is printed, then it is True.

# Generated at 2022-06-24 05:49:29.429272
# Unit test for function version
def test_version():
    version("version 1","python version 2","shell version 3")
    assert(1)

# Generated at 2022-06-24 05:49:41.372409
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    import mock
    import six

    class TestRule(object):
        def __init__(self, name):
            self.name = name

    class TestLog(unittest.TestCase):
        @mock.patch('sys.stderr.write')
        def test_rule_failed(self, write):
            exc_info = (None, Exception('test exception'), None)
            rule_failed(TestRule('test_rule'), exc_info)

# Generated at 2022-06-24 05:49:45.065029
# Unit test for function color
def test_color():
    with settings(no_colors=True):
        assert color(colorama.Fore.RED) == ''
    with settings(no_colors=False):
        assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-24 05:49:51.284498
# Unit test for function warn
def test_warn():
    onscreen = []

    def f(v):
        onscreen.append(v)

    sys.stderr.write = f
    warn(u'Some Title')
    assert onscreen == [u'\x1b[41m\x1b[37m\x1b[1m[WARN] Some Title\x1b[0m\n']



# Generated at 2022-06-24 05:49:52.164143
# Unit test for function failed
def test_failed():
    failed(u'fuck is not configured')

# Generated at 2022-06-24 05:49:53.448421
# Unit test for function debug
def test_debug():
    assert debug('my message')

# Generated at 2022-06-24 05:49:56.878042
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except BaseException:
        exc_info = sys.exc_info()
        exception('test', exc_info)

# Generated at 2022-06-24 05:50:04.342551
# Unit test for function debug_time
def test_debug_time():
    from .conf import settings
    from . import debug
    from datetime import datetime

    settings.debug = True
    settings.no_colors = True

    called = [False]

    def run(msg):
        with debug_time(msg):
            called[0] = True

    started = datetime.now()

    with debug.capture_output() as output:
        run('test')

    assert called[0]
    assert output.getvalue().strip() == u'DEBUG: test took: {}'.format(
        datetime.now() - started)

# Generated at 2022-06-24 05:50:07.820815
# Unit test for function color
def test_color():
    assert '\x1b[1m' == color(colorama.Style.BRIGHT)
    assert '' == color(colorama.Style.BRIGHT, colors=False)

# Generated at 2022-06-24 05:50:10.179930
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import fuck_alias
    how_to_configure_alias(fuck_alias())



# Generated at 2022-06-24 05:50:13.698004
# Unit test for function failed
def test_failed():
    from thefuck.utils import get_all_stderr
    failed(u'Hi')
    assert get_all_stderr() == 'Hi\n'

# Generated at 2022-06-24 05:50:17.717389
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    from .types import Command
    import sys

    import os
    saved_stderr = sys.stderr
    try:
        out = open(os.devnull, 'w')
        sys.stderr = out
        rule_failed(rules.Rule(
            name='Test',
            match=lambda c: True,
            get_new_command=lambda c: c,
            enabled_by_default=True),
            sys.exc_info())
    finally:
        sys.stderr = saved_stderr



# Generated at 2022-06-24 05:50:29.070852
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys
    import unittest
    import unittest.mock

    conf = unittest.mock.Mock(spec=['can_configure_automatically',
                                    'path',
                                    'reload',
                                    'content'])

    conf.can_configure_automatically = False
    conf.path = 'some_file'
    conf.reload = 'some_command'
    conf.content = 'alias fuck=...'

    old_stdout = sys.stdout
    old_stderr = sys.stderr

# Generated at 2022-06-24 05:50:31.890115
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    sys.stderr = StringIO.StringIO()
    configured_successfully({'reload': 'test'})
    assert sys.stderr.getvalue().endswith(u'For applying changes run test or restart your shell.\n')



# Generated at 2022-06-24 05:50:41.518224
# Unit test for function failed
def test_failed():
    from . import utils
    from .utils import wrap
    from .compat import unicode

    func = utils.get_wrapped_function(failed)
    results = []

    def capture_stdout(string):
        results.extend(wrap(string))

    with utils.mock.patch('sys.stdout', utils.mock.MagicMock()):
        with utils.mock.patch('sys.stdout.isatty', lambda: False):
            with utils.mock.patch('sys.stdout.write', capture_stdout):
                func('msg')
                assert results == ['msg']

    results = []


# Generated at 2022-06-24 05:50:43.302015
# Unit test for function already_configured
def test_already_configured():
    config = type('ConfigDetails', (object,), {
        'reload': '. ~/.bashrc'
    })
    already_configured(config)

# Generated at 2022-06-24 05:50:47.770230
# Unit test for function version
def test_version():
    thefuck_version = '3.9'
    python_version = '2.7.5'
    shell_info = 'bash'
    version(thefuck_version, python_version, shell_info)


test_version()

# Generated at 2022-06-24 05:50:49.201510
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('')
    assert configured_successfully(None)


# Generated at 2022-06-24 05:50:51.949706
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception as e:
        exception('Test exception', sys.exc_info())
        return sys.stderr.getvalue()



# Generated at 2022-06-24 05:50:55.642413
# Unit test for function version
def test_version():
    assert '2.4.8 using Python 2.7.5 and' in version('2.4.8',
                                                     '2.7.5',
                                                     'shell')



# Generated at 2022-06-24 05:50:58.216473
# Unit test for function failed
def test_failed():
    import sys
    sys.stderr = sys.stdout
    failed(u'foo\x1b[R\x1b[K')

# Generated at 2022-06-24 05:51:03.693467
# Unit test for function confirm_text
def test_confirm_text():
    from colorama import init
    init()

    corrected_command = type('', (), {
        'script': 'ls -lah',
        'side_effect': False,
        'stderr': None
    })

    # Example of the right string
    assert confirm_text(corrected_command) == u'\033[1K\rls -lah [\x1b[32menter\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[31mctrl+c\x1b[0m] '



# Generated at 2022-06-24 05:51:09.362181
# Unit test for function already_configured
def test_already_configured():
    from thefuck.utils import read_input
    with read_input(u'', 'y') as input_mock:
        already_configured(u"test relaod")
        assert u'Seems like fuck alias already configured' in input_mock.output
        assert 'For applying changes run test reload or restart your shell' in input_mock.output



# Generated at 2022-06-24 05:51:10.997560
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-24 05:51:12.390368
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("null") == u'Seems like '


# Generated at 2022-06-24 05:51:13.490702
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        assert True



# Generated at 2022-06-24 05:51:17.286367
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails
    how_to_configure_alias(
        ConfigurationDetails('source $HOME/fuck.sh', '/tmp/fuck.sh', '.', True))
    assert True


# Generated at 2022-06-24 05:51:20.557593
# Unit test for function configured_successfully
def test_configured_successfully():
    test_string = u"fuck alias configured successfully!\n"
    test_string += u"For applying changes run reload or restart your shell."
    assert configured_successfully(None) == print(test_string)

# Generated at 2022-06-24 05:51:22.597753
# Unit test for function exception
def test_exception():
    def f():
        raise ValueError
    try:
        f()
    except ValueError:
        exception('Test except', sys.exc_info())

# Generated at 2022-06-24 05:51:24.417489
# Unit test for function warn
def test_warn():
    assert u'[WARN] title' == warn(u'title')



# Generated at 2022-06-24 05:51:28.713963
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command_mock:
        def __init__(self, name, side_effect):
            self.script = name
            self.side_effect = side_effect
    show_corrected_command(corrected_command_mock('ls', False))
    show_corrected_command(corrected_command_mock('ls', True))

# Generated at 2022-06-24 05:51:32.136059
# Unit test for function color
def test_color():
    assert color(colorama.Back.BLACK + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) \
        == colorama.Back.BLACK + colorama.Fore.WHITE + colorama.Style.BRIGHT
    settings.no_colors = True
    assert color(colorama.Back.BLACK + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-24 05:51:38.430976
# Unit test for function debug_time
def test_debug_time():
    settings.debug = True
    msg = "Time test"

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.now() - started))

    with debug_time(msg):
        debug("debug")

# Generated at 2022-06-24 05:51:45.463066
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    from .types import CorrectedCommand

    with mock.patch.object(sys.stderr, 'write') as sys_stderr:
        corrected_command = CorrectedCommand('git push'
                                             ' origin master',
                                             side_effect=True)
        show_corrected_command(corrected_command)
        sys_stderr.assert_called_once_with(u'\033[33m\033[1m\033[2m'
                                           u'$ git push'
                                           u' origin master'
                                           u' \033[1m(+side effect)\033[22m\033[0m\n')

        corrected_command = CorrectedCommand('git push'
                                             ' origin master')

        sys_stderr.reset_mock()
       

# Generated at 2022-06-24 05:51:53.202726
# Unit test for function exception
def test_exception():
    e = Exception('foo')
    exc_info = sys.exc_info()
    exception('bar', exc_info)
    with open('{}.log'.format(__name__)) as f:
        lines = f.readlines()
    assert lines == [
        u'{warn}[WARN] bar:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            trace=''.join(format_exception(*exc_info)))]



# Generated at 2022-06-24 05:51:55.794554
# Unit test for function debug
def test_debug():
    settings.debug = True
    sys.stderr = Exception
    debug('Test debug')
    settings.debug = False
    debug('Test debug')

# Generated at 2022-06-24 05:51:58.977307
# Unit test for function debug_time
def test_debug_time():
    from mock import patch

    def debug(msg):
        print(msg)

    with patch('thefuck.shells.base.debug', debug):
        with debug_time('test'):
            pass
        with debug_time('test2'):
            pass

# Generated at 2022-06-24 05:52:02.239492
# Unit test for function failed
def test_failed():
    failed('foo')
    sys.stderr.seek(0)
    assert sys.stderr.read() == '\x1b[31mfoo\x1b[0m\n'
    sys.stderr.truncate(0)


# Generated at 2022-06-24 05:52:05.794830
# Unit test for function version
def test_version():
    # Prints to stdout, not stderr
    sys.stdout = sys.__stdout__
    import platform
    version(
        '0.0.0',
        platform.python_version(),
        'PS1=\'{}\''.format(const.PS1))
    sys.stdout = sys.stderr

# Generated at 2022-06-24 05:52:10.544137
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys
    capture = io.BytesIO()
    sys.stderr = capture
    test_corrected_command = ['git push origin master']
    show_corrected_command(test_corrected_command)
    sys.stderr = sys.__stderr__
    assert capture.getvalue() == "git push origin master \n"



# Generated at 2022-06-24 05:52:12.893108
# Unit test for function debug_time
def test_debug_time():
    global settings
    settings = settings.clear().load()
    settings.debug = True

    called = False

    with debug_time('test'):
        called = True

    assert called == True

# Generated at 2022-06-24 05:52:13.695255
# Unit test for function failed
def test_failed():
    failed('blah')



# Generated at 2022-06-24 05:52:16.113576
# Unit test for function failed
def test_failed():
    with settings(no_colors=True):
        assert failed('Some error') == 'Some error\n'
    assert failed('Some error') == '\x1b[31mSome error\x1b[0m\n'



# Generated at 2022-06-24 05:52:19.750015
# Unit test for function version
def test_version():
    class ShellInfo(object):
        def __init__(self, name, version):
            self.name = name
            self.version = version

    version('3.14', '2.7', ShellInfo('bash', '4.1'))



# Generated at 2022-06-24 05:52:23.405166
# Unit test for function debug
def test_debug():
    from tempfile import mkstemp
    from os import remove

    _, path = mkstemp()
    debug('test {}', path)
    remove(path)
    with open(path) as f:
        assert f.read() == 'test {}\n' % path

# Generated at 2022-06-24 05:52:25.956834
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'git branch'
    corrected_command = 'git branch -a'
    show_corrected_command(corrected_command)
    assert corrected_command in command



# Generated at 2022-06-24 05:52:31.184419
# Unit test for function confirm_text
def test_confirm_text():
    u"""
        >>> confirm_text(['echo "hi"', True])
        'Выходной поток: [enter/↑/↓/ctrl+c] '
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-24 05:52:38.064938
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import shell
    from .shells import Bash, Fish, Zsh
    original_shells = shell.shells


# Generated at 2022-06-24 05:52:39.312169
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(name="test")



# Generated at 2022-06-24 05:52:40.230337
# Unit test for function debug_time
def test_debug_time():
    import mock
    print(mock)

# Generated at 2022-06-24 05:52:42.486665
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand(u'ls'))


# Generated at 2022-06-24 05:52:46.494928
# Unit test for function color
def test_color():
    assert '\x1b[40m\x1b[37m\x1b[1m' == color(colorama.Back.BLACK
                                               + colorama.Fore.WHITE
                                               + colorama.Style.BRIGHT)
    assert u'' == color(colorama.Back.BLACK
                        + colorama.Fore.WHITE
                        + colorama.Style.BRIGHT)