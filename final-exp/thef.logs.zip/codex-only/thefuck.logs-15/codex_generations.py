

# Generated at 2022-06-24 05:42:40.817131
# Unit test for function debug
def test_debug():
    debug('test debug')



# Generated at 2022-06-24 05:42:43.286721
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except ZeroDivisionError:
        exception('is not zero', sys.exc_info())

if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-24 05:42:43.861792
# Unit test for function failed
def test_failed():
    failed('foo')

# Generated at 2022-06-24 05:42:46.139879
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('sys.stderr') as stderr:
        debug('foo')
        assert stderr.write.call_count == 1

# Generated at 2022-06-24 05:42:46.720737
# Unit test for function debug
def test_debug():
    debug('Hello world!')

# Generated at 2022-06-24 05:42:48.260146
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls'
    assert show_corrected_command(corrected_command) == True

# Generated at 2022-06-24 05:42:58.932265
# Unit test for function exception
def test_exception():
    title = 'Rule `rm`'
    exc_info = (Exception,
                Exception('Test'),
                sys.exc_info()[2])
    expected = (
        u'{warn}[WARN] {title}:{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n')
    expected = expected.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title=title,
        trace=''.join(format_exception(*exc_info)))
    sys.stderr.write = lambda x: expected == x
    exception(title, exc_info)



# Generated at 2022-06-24 05:43:05.265489
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self):
            self.content = "content"
            self.path = "path"
            self.reload = "reload"
            self.can_configure_automatically = True

        def _asdict(self):
            return {'content': self.content, 'path': self.path, 'reload': self.reload}

    configuration_details = ConfigurationDetails()

    how_to_configure_alias(configuration_details)

# Generated at 2022-06-24 05:43:07.777958
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    correct_script = corrected_command('ls', 'dir')
    show_corrected_command(correct_script)
    correct_script_2 = corrected_command('git commit', None)
    show_corrected_command(correct_script_2)

# Generated at 2022-06-24 05:43:13.843111
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = type('', (), {'reload': 'command1'})
    sys.stdout = sys.__stdout__
    configured_successfully(configuration_details)
    assert sys.stdout.getvalue() == \
    u"{bold}fuck{reset} alias configured successfully!\n" \
    u"For applying changes run {bold}command1{reset}" \
    u" or restart your shell.\n".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:43:24.109853
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.const import EMOJI

# Generated at 2022-06-24 05:43:27.796091
# Unit test for function debug
def test_debug():
    from .conf import settings_for_testing
    from .utils import wrap_settings

    with wrap_settings(settings_for_testing):
        msg = u'käse\n'  # make sure unicode works
        debug(msg)

# Generated at 2022-06-24 05:43:32.648025
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """
    Test function "how_to_configure_alias"
    """
    from .conf import ConfigurationDetails

    configuration_details = ConfigurationDetails(
        True,
        '',
        '',
        '',
        '')
    how_to_configure_alias(configuration_details)
    how_to_configure_alias(None)



# Generated at 2022-06-24 05:43:34.464063
# Unit test for function warn
def test_warn():
    with patch('sys.stderr') as stderr:
        warn(u'title')
        assert stderr.write.called



# Generated at 2022-06-24 05:43:41.293669
# Unit test for function configured_successfully
def test_configured_successfully():
    assert (const.CONFIGURED_SUCCESSFULLY
            == u"{bold}fuck{reset} alias configured successfully!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell.".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload=u"{}")
            )

# Generated at 2022-06-24 05:43:42.525679
# Unit test for function failed
def test_failed():
    sys.stderr = StringIO()
    failed("Test")
    return sys.stderr.getvalue()


# Generated at 2022-06-24 05:43:52.935756
# Unit test for function exception
def test_exception():
    from StringIO import StringIO
    from tempfile import NamedTemporaryFile
    from datetime import datetime

    with NamedTemporaryFile() as f:
        try:
            raise Exception("dummy exception")
        except:
            original_stderr = sys.stderr
            sys.stderr = StringIO()
            exception("Test exception", sys.exc_info())

            output = sys.stderr.getvalue()

# Generated at 2022-06-24 05:43:58.441504
# Unit test for function failed
def test_failed():
    sys.stderr = StringIO()
    failed('Hello world!')
    assert sys.stderr.getvalue() == u'\x1b[91mHello world!\x1b[0m\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:44:01.051629
# Unit test for function exception
def test_exception():
    title = 'Title'
    try:
        1/0
    except:
        exc_info = sys.exc_info()
        exception(title, exc_info)

# Generated at 2022-06-24 05:44:05.066590
# Unit test for function debug
def test_debug():
    import io
    import mock

    stdout = io.StringIO()
    stderr = io.StringIO()

    with mock.patch('sys.stdout', stdout):
        with mock.patch('sys.stderr', stderr):
            debug('hello')

    assert not stdout.getvalue()
    assert 'hello' in stderr.getvalue()



# Generated at 2022-06-24 05:44:06.801317
# Unit test for function version
def test_version():
    sys.stderr = io.StringIO()
    version('1.2.3', 'some_python', 'some_shell')
    assert sys.stderr.getvalue() == u'The Fuck 1.2.3 using Python some_python and some_shell\n'

# Generated at 2022-06-24 05:44:12.325234
# Unit test for function version
def test_version():
    import StringIO
    out = StringIO.StringIO()
    sys.stderr = out
    version('1.1.1', '2.7.12', 'sh')
    assert out.getvalue() == 'The Fuck 1.1.1 using Python 2.7.12 and sh\n'

# Generated at 2022-06-24 05:44:16.372276
# Unit test for function debug
def test_debug():
    try:
        open('/dev/null', 'r')
    except Exception as e:
        exc_info = sys.exc_info()
        debug(u'Error: {}'.format(e))
        debug(u'Stacktrace: {}'.format(''.join(
            format_exception(*exc_info))))

# Generated at 2022-06-24 05:44:17.845914
# Unit test for function color
def test_color():
    settings.no_colors = False
    assert color('bold') == colorama.Style.BRIGHT
    settings.no_colors = True
    assert color('bold') == ''

# Generated at 2022-06-24 05:44:19.161236
# Unit test for function warn
def test_warn():
    warn(u'Test')



# Generated at 2022-06-24 05:44:22.094696
# Unit test for function already_configured
def test_already_configured():
    already_configured(
        ConfigurationDetails(
            path='~/.bashrc',
            reload='source ~/.bashrc',
            content='eval $(thefuck --alias -)',
        )
    )



# Generated at 2022-06-24 05:44:30.659929
# Unit test for function show_corrected_command
def test_show_corrected_command():
    for test in range(1, 5):
        corrected_command = ' '
        if (test == 1):
            corrected_command = "git pull --rebase"
            expected_output = "[COMMAND] git pull --rebase\n"
        elif (test == 2):
            corrected_command = "git pull --rebase"
            expected_output = "[COMMAND] git pull --rebase (+side effect)\n"
        elif (test == 3):
            corrected_command = "git pull --rebase"
            expected_output = "[COMMAND] git pull --rebase (+side effect)\n"
        elif (test == 4):
            corrected_command = "git pull --rebase"
            expected_output = "[COMMAND] git pull --rebase\n"
        assert expected_output == show_corrected_

# Generated at 2022-06-24 05:44:36.968163
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('ls', False))
    assert sys.stderr.getvalue() == '› ls\n'
    show_corrected_command(CorrectedCommand('ls', True))
    assert sys.stderr.getvalue() == '› ls\n› ls (+side effect)\n'



# Generated at 2022-06-24 05:44:39.564861
# Unit test for function color
def test_color():
    assert u'\x1b[35;1m[WARN] {title}\x1b[0m' == color(
        colorama.Fore.MAGENTA + colorama.Style.BRIGHT)(
            u'\x1b[35;1m[WARN] {title}\x1b[0m')

    assert u'[WARN] {title}' == color(
        colorama.Fore.MAGENTA + colorama.Style.BRIGHT)(
            '[WARN] {title}')

# Generated at 2022-06-24 05:44:40.968793
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('Test rule', exc_info=sys.exc_info())

# Generated at 2022-06-24 05:44:52.031681
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Test show_corrected_command() function
    """
    import unittest
    import mock

    class ShowCorrectedCommandTest(unittest.TestCase):
        @mock.patch('sys.stderr')
        def test_show_corrected_command_func(self, mock_stderr):
            show_corrected_command('git commit -am "test"')

# Generated at 2022-06-24 05:44:53.791629
# Unit test for function version
def test_version():
    assert version('3.1', '3.6.0', 'Zsh on OSX Sierra') == None

# Generated at 2022-06-24 05:44:55.895727
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git commit -m "as"') == 'git commit "as"'
    assert confirm_text('') == ''


# Generated at 2022-06-24 05:44:59.030007
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except Exception:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-24 05:45:02.836268
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(
        const.ConfigurationDetails(
            reload='reload', path='path',
            content='$ alias fuck=\'eval $(thefuck $(fc -ln -1)); history -r\'',
            can_configure_automatically=True))

# Generated at 2022-06-24 05:45:07.900372
# Unit test for function already_configured
def test_already_configured():
    import io
    import sys
    import contextlib

    test_io = io.StringIO()
    with contextlib.redirect_stdout(test_io):
        already_configured('reload')
    assert u'fuck alias already configured' in test_io.getvalue()


# Generated at 2022-06-24 05:45:09.424351
# Unit test for function warn
def test_warn():
    warn(const.NON_ZERO_RC)



# Generated at 2022-06-24 05:45:18.357750
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .types import ShellConfig
    from .utils import get_closest

# Generated at 2022-06-24 05:45:20.942429
# Unit test for function rule_failed
def test_rule_failed():
    sys.stdout.write("rule_failed() - ")
    rule_failed("Rule Name", "Exception")
    sys.stdout.write("OK\n")



# Generated at 2022-06-24 05:45:26.350872
# Unit test for function exception
def test_exception():
    try:
        raise Exception('The Fuck')
    except Exception:
        sys.stderr = open('/dev/null', 'w')
        exception(u'The Fuck', sys.exc_info())
        sys.stderr = sys.__stderr__
        sys.stderr.write(u'[Test] exception')

# Generated at 2022-06-24 05:45:30.810461
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """
    >>> [how_to_configure_alias(None)]
    [0]
    >>> [how_to_configure_alias(ConfigurationDetails(u'./test', [u'echo OK'], True, u'echo OK'))]
    [0]
    """

# Generated at 2022-06-24 05:45:38.866130
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import sys
    import subprocess
    import tempfile

    def clear():
        os.system('clear')

    def run(script):
        subprocess.call(script, shell=True)

    with tempfile.NamedTemporaryFile() as temp:
        temp.write('sleep 1\nsleep 2\n')
        temp.flush()
        command = u'bash --norc {}'.format(temp.name)
        run(command)
        fd = sys.stderr.fileno()
        sys.stderr = os.fdopen(fd, 'w', 0)
        for _ in range(2):
            confirm_text(command)
            clear()

    clear()
    command = u'fuck this'
    confirm_text(command)
    run(u'fuck this')
    clear()

# Generated at 2022-06-24 05:45:40.432544
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    warn('test')
    assert out.getvalue() == u'[WARN] test\n'



# Generated at 2022-06-24 05:45:41.473129
# Unit test for function warn
def test_warn():
    warn('test_title')


# Generated at 2022-06-24 05:45:42.744408
# Unit test for function debug_time
def test_debug_time():
    debug_time(u'something')

# Generated at 2022-06-24 05:45:46.658134
# Unit test for function show_corrected_command
def test_show_corrected_command():
    correct_command_1 = "ls -al"
    correct_command_2 = "ls -al && echo 'hello'"
    show_corrected_command(correct_command_1)
    show_corrected_command(correct_command_2)



# Generated at 2022-06-24 05:45:47.265413
# Unit test for function already_configured
def test_already_configured():
    assert True == True

# Generated at 2022-06-24 05:45:48.561733
# Unit test for function failed
def test_failed():
    failed('ValueError: x should be > 0')



# Generated at 2022-06-24 05:45:50.169307
# Unit test for function already_configured
def test_already_configured():
    already_configured('source ~/.bashrc')
    sys.stderr.write(u'\n')

# Generated at 2022-06-24 05:46:01.421719
# Unit test for function already_configured
def test_already_configured():
    print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload="bash -c 'source ~/.bashrc'"))



# Generated at 2022-06-24 05:46:02.542819
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN
    assert color(colorama.Fore.GREEN) == ''



# Generated at 2022-06-24 05:46:08.602828
# Unit test for function confirm_text
def test_confirm_text():
    import subprocess
    from thefuck import shells
    from thefuck.rules.git import git_support
    with shells.Factory().from_shell('') as shell:
        corrected_command = git_support.Command(
            'git', 'stasus', 'status')
        confirm_text(corrected_command)
        p = subprocess.Popen(['read', '-n1', '-t1'], stdout=subprocess.PIPE)
        p.wait()
        sys.stderr.write('\n')

# Generated at 2022-06-24 05:46:11.445945
# Unit test for function exception
def test_exception():
    class Exception(object):
        def __init__(self):
            self.args = ['message']
    exception(u'Title', (Exception, Exception(), None))



# Generated at 2022-06-24 05:46:13.374222
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('foo'):
        time.sleep(0.1)

# Generated at 2022-06-24 05:46:20.450852
# Unit test for function failed
def test_failed():
    from mock import patch

    sys.stderr = patch('sys.stderr').start()
    try:
        failed("Test failed")
        assert sys.stderr.write.called_with(u'{red}{msg}{reset}\n'.format(
            msg='Test failed',
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL)))
    except Exception:
        raise
    finally:
        patch.stopall()


# Generated at 2022-06-24 05:46:22.359131
# Unit test for function version
def test_version():
    version('1', '2', {'shell': 'zsh', 'version': '3'})



# Generated at 2022-06-24 05:46:22.861712
# Unit test for function debug_time
def test_debug_time():
    debug_time("Hello")



# Generated at 2022-06-24 05:46:23.872832
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-24 05:46:29.691571
# Unit test for function debug_time
def test_debug_time():
    time_msgs = []

    def mock_debug(msg):
        time_msgs.append(msg)

    global debug
    debug = mock_debug

    with debug_time('foo'):
        pass

    assert len(time_msgs) == 1
    assert 'foo took:' in time_msgs[0]

    with debug_time(u'бар'):
        pass

    assert len(time_msgs) == 2
    assert u'бар took:' in time_msgs[1]

# Generated at 2022-06-24 05:46:33.342853
# Unit test for function rule_failed
def test_rule_failed():
    """
    When rule_failed called
    It should print error
    """
    class MockRule:
        name = "mock_rule"

    rule_failed(MockRule(), ("error_title", "error_message"))

# Generated at 2022-06-24 05:46:37.412387
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .utils import wrap_streams
    output = StringIO()
    with wrap_streams(streams=(sys.stderr, output)):
        debug(u'Hello')
    assert output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello\n'



# Generated at 2022-06-24 05:46:38.755667
# Unit test for function warn
def test_warn():
    warn(u"Fuck")
    exception(u"Fuck", (Exception, Exception, None))

# Generated at 2022-06-24 05:46:41.353443
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('\033[1;33m') == '\033[1;33m'



# Generated at 2022-06-24 05:46:45.324778
# Unit test for function debug_time
def test_debug_time():
    import time
    from datetime import timedelta
    from .log import debug_time

    start = datetime.now()
    with debug_time('stat'):
        time.sleep(1)
    end = datetime.now()

    assert end >= start + timedelta(seconds=1)

# Generated at 2022-06-24 05:46:52.126517
# Unit test for function exception
def test_exception():
    test_log_file = open('./test.log', 'w')
    try:
        raise ValueError(u"ValueError")
    except ValueError as e:
        old_stderr = sys.stderr
        sys.stderr = test_log_file
        exception("ValueError", sys.exc_info())
        exception("ValueError", sys.exc_info())
        sys.stderr = old_stderr
    with open("test.log") as log:
        for line in log:
            if not (line.startswith("[WARN] ") or line.startswith("Traceback") or line.startswith("ValueError")):
                assert(line.startswith("[WARN] ValueError:"))
    test_log_file.close()


# Generated at 2022-06-24 05:46:56.370936
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {
        u'path': '~/.zshrc',
        u'content': 'eval $(thefuck --alias)',
        u'reload': u'reload source ~/.zshrc',
        u'can_configure_automatically': True
    }

    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:46:58.542422
# Unit test for function debug_time
def test_debug_time():
    class dummy(object):
        msg = 'msg'

    with debug_time(dummy().msg) as dt:
        return dt

# Generated at 2022-06-24 05:47:06.912807
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

    assert color(colorama.Fore.GREEN) == ''
    assert color(colorama.Fore.BLUE) == ''
    assert color(colorama.Style.BRIGHT) == ''
    assert color(colorama.Style.RESET_ALL) == ''

# Generated at 2022-06-24 05:47:09.808214
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {"path": "file", "reload": "reload()"}
    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:47:14.929801
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import MagicMock, patch
    from . import utils

    # pylint: disable=E1120
    with patch.object(utils, 'debug') as debug:
        with utils.debug_time('test'):
            pass

        debug.assert_called_once_with('test took: {}'.format(
            timedelta.max))



# Generated at 2022-06-24 05:47:23.603109
# Unit test for function failed
def test_failed():
    def _execute_failed(cmd):
        failed(cmd)
    commands = (
        u'ls',
        u'rm /tmp/file',
        u'rm "/tmp/file/with spaces"',
        u'fuck'
    )
    expected = (
        u'ls\n',
        u'rm /tmp/file\n',
        u'rm "/tmp/file/with spaces"\n',
        u'fuck\n',
    )
    for cmd, exp in zip(commands, expected):
        yield (lambda cmd, exp: _execute_failed(cmd) == exp,
               cmd, exp)

# Generated at 2022-06-24 05:47:25.046771
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed({"name":"name"},("type","value","traceback"))
    assert True

# Generated at 2022-06-24 05:47:26.338461
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-24 05:47:30.346123
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = "fuck"
    show_corrected_command(corrected_command)
    assert const.USER_COMMAND_MARK == "> "


# Generated at 2022-06-24 05:47:31.778196
# Unit test for function exception
def test_exception():
    exception('TITLE', [(Exception(), 'mock_traceback', None)])

# Generated at 2022-06-24 05:47:37.115610
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from collections import namedtuple

    Command = namedtuple('Command', ['script', 'side_effect'])
    corrected_command = Command('echo 666', True)

    bash = Bash()

# Generated at 2022-06-24 05:47:42.091072
# Unit test for function version
def test_version():
    from io import StringIO
    from thefuck import __version__
    capture = StringIO()
    sys.stderr = capture
    version('0.0.0', 'Python 0.0.0', 'Shell 0.0.0')
    sys.stderr = sys.__stderr__
    capture.close()
    assert capture.getvalue() == 'The Fuck 0.0.0 using Python 0.0.0 and Shell 0.0.0\n'

# Generated at 2022-06-24 05:47:47.141411
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug
    with patch('sys.stderr') as stderr:
        # print it if debug is True
        settings.debug = True
        debug('foo')
        assert stderr.write.call_count == 1
        stderr.reset_mock()

        # don't print it if debug is False
        settings.debug = False
        debug('foo')
        assert stderr.write.call_count == 0



# Generated at 2022-06-24 05:47:48.520013
# Unit test for function configured_successfully
def test_configured_successfully():
    class mock_configuration(object):
        reload = u'path'
    configured_successfully(mock_configuration())

# Generated at 2022-06-24 05:47:49.676361
# Unit test for function warn
def test_warn():
    warn("Warning")



# Generated at 2022-06-24 05:47:57.413755
# Unit test for function warn
def test_warn():
    from io import StringIO
    from .conf import Settings
    from . import main
    settings = main.retrieve_settings(
        ['thefuck', '--no-colors', 'ls', 'cd'])
    settings.no_colors = True
    stderr = StringIO()
    sys.stderr = stderr
    warn("some message")
    assert stderr.getvalue() == u'[WARN] some message\n'
    stderr.close()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:47:59.298666
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('Test'):
        time.sleep(0.1)

# Generated at 2022-06-24 05:48:02.068283
# Unit test for function exception
def test_exception():
    try:
        raise TypeError
    except TypeError:
        exception('Exception test', sys.exc_info())



# Generated at 2022-06-24 05:48:04.041246
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None).startswith('Seems like The Fuck')


# Generated at 2022-06-24 05:48:05.533668
# Unit test for function exception
def test_exception():
    exception(u'test', (RuntimeError, RuntimeError("test error"), None))

# Generated at 2022-06-24 05:48:07.215005
# Unit test for function failed
def test_failed():
    sys.stderr.write("\n")
    failed('test')



# Generated at 2022-06-24 05:48:14.516041
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    old_stderr, sys.stderr = sys.stderr, StringIO()
    debug(u'Foo')
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Foo\n'
    sys.stderr = old_stderr

# Generated at 2022-06-24 05:48:15.154786
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('reload')

# Generated at 2022-06-24 05:48:23.024580
# Unit test for function debug_time
def test_debug_time():
    import mock
    import datetime
    from tests.utils import assert_sample_output
    settings.debug = True
    time = datetime.timedelta(seconds=1)
    with mock.patch('datetime.datetime') as datetime_mock:
        mock_datetime = datetime_mock.utcnow.return_value
        mock_datetime.__sub__.return_value = time
        with debug_time('test'):
            pass
    assert_sample_output(u'test took: {}'.format(time))

# Generated at 2022-06-24 05:48:24.845190
# Unit test for function debug_time
def test_debug_time():
    with debug_time('sleep'):
        sleep(5)

# Generated at 2022-06-24 05:48:27.067713
# Unit test for function debug_time
def test_debug_time():
    from .conf import settings
    settings.debug = True
    with debug_time("run"):
        pass



# Generated at 2022-06-24 05:48:29.489849
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''



# Generated at 2022-06-24 05:48:34.064322
# Unit test for function version
def test_version():
    sys.stderr = FakeStd()
    version('1.1.1', '2.7.9', 'sh')
    assert sys.stderr.content == 'The Fuck 1.1.1 using Python 2.7.9 and sh\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:48:39.212116
# Unit test for function warn
def test_warn():
    assert warn('title') == u'\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'
    settings.no_colors = True
    assert warn('title') == u'[WARN] title\n'
    settings.no_colors = False



# Generated at 2022-06-24 05:48:40.213782
# Unit test for function warn
def test_warn():
    warn('msg')


# Generated at 2022-06-24 05:48:42.311880
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('') == 'Seems like fuck alias already configured!\nFor applying changes run  or restart your shell.'

# Generated at 2022-06-24 05:48:44.739746
# Unit test for function exception
def test_exception():
    try:
        raise ValueError(u'Ух ты!')
    except ValueError:
        exception(u'test exception', sys.exc_info())

# Generated at 2022-06-24 05:48:45.652249
# Unit test for function configured_successfully
def test_configured_successfully():
    print(configured_successfully())

# Generated at 2022-06-24 05:48:46.793103
# Unit test for function color
def test_color():
    assert color('bold') == colorama.Style.BRIGHT



# Generated at 2022-06-24 05:48:50.602574
# Unit test for function confirm_text
def test_confirm_text():
    sys.stdout.write(u'\n')
    confirm_text('cmd')
    confirm_text('')
    sys.stdout.write(u'\n')
    confirm_text('cmd')


# Generated at 2022-06-24 05:48:51.676145
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('foo') is None

# Generated at 2022-06-24 05:48:55.461429
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from collections import namedtuple
    CorrectedCommand = namedtuple('CorrectedCommand', 'script side_effect')
    show_corrected_command(CorrectedCommand('git commit -m "fix"', False))



# Generated at 2022-06-24 05:48:57.849884
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'unicode error')
    except Exception:
        exception(u'Test', sys.exc_info())

# Generated at 2022-06-24 05:49:01.517382
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.bash import BashRule
    exc_info = lambda: None
    exc_info.rule = BashRule()
    exc_info.output = u"Test err"
    rule_failed(BashRule(), exc_info)

# Generated at 2022-06-24 05:49:06.773835
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stdout', new_callable=StringIO) as stdout:
        configured_successfully(configuration_details="test_configuration_details")
        assert stdout.getvalue() == "fuck alias configured successfully!\nFor applying changes run test_configuration_details or restart your shell.\n"

# Generated at 2022-06-24 05:49:10.215502
# Unit test for function version
def test_version():
    from thefuck.shells import ShellType
    from . import __version__
    result = version(__version__, '2.7.10', ShellType('', '', '', '', ''))
    assert result == u'The Fuck 3.16 using Python 2.7.10 and shelltype'



# Generated at 2022-06-24 05:49:18.060338
# Unit test for function version
def test_version():
    # Given
    thefuck_version = "3.18"
    python_version = "2.7"
    shell_info = "Windows"
    sys.argv = ['thefuck']
    sys.stderr = open('/tmp/test_log', 'w')

    # When
    version(thefuck_version, python_version, shell_info)

    # Then
    assert u'The Fuck 3.18 using Python 2.7 and Windows\n' \
            in open('/tmp/test_log').read()


# Generated at 2022-06-24 05:49:24.653465
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('sys.stderr') as sys_stderr:
        debug('good')
        sys_stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m good\n')
        sys_stderr.write.reset_mock()
        debug('bad')
        sys_stderr.write.assert_not_called()

# Generated at 2022-06-24 05:49:26.026904
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT

# Generated at 2022-06-24 05:49:29.018914
# Unit test for function version
def test_version():
    from . import version
    from .shells import shell_info

    assert version.thefuck_version == '3.10'
    assert version.python_version == '3.5.3'
    assert version.shell_info == shell_info()

# Generated at 2022-06-24 05:49:30.924414
# Unit test for function already_configured
def test_already_configured():
    assert 'Seems like fuck alias already configured!\n' in already_configured(None)


# Generated at 2022-06-24 05:49:39.901729
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command

    corrected_command = Command('git commit -m "test"', '')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == 'fuck git commit -m "test"\n'

    corrected_command = Command('git commit -m "test"', 'git push')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == 'fuck git commit -m "test"\n' \
                                     'fuck git commit -m "test" (+side effect)\n'



# Generated at 2022-06-24 05:49:44.323109
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('.') == u'Seems like {bold}fuck{reset} alias ' \
                                      u'already configured!\n' \
                                      u'For applying changes run ' \
                                      u'{bold}.{reset} or restart your shell.'.format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload='.')

# Generated at 2022-06-24 05:49:46.493628
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls'
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:49:51.616105
# Unit test for function version
def test_version():
    import io
    import os
    import re
    import shutil
    import tempfile
    from . import version

    output = io.BytesIO()
    version.version('', '', '')
    assert re.match(b'The Fuck \w+ using Python \d+\.\d+\.\d+', output.getvalue())


del colorama

# Generated at 2022-06-24 05:49:57.276999
# Unit test for function failed
def test_failed():
    sys.stderr = open('.thefuck.log', 'w')  # hide output

    failed("Function failed")

    sys.stderr = sys.__stderr__  # show output

    with open('.thefuck.log') as f:
        assert 'Function failed' in f.readline()

# Generated at 2022-06-24 05:49:57.953024
# Unit test for function debug
def test_debug():
    debug("test debug")

# Generated at 2022-06-24 05:50:04.472067
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('', (object,), {'script': 'script',
                                             'side_effect': False})
    assert confirm_text(corrected_command) == '$ script [enter/↑/↓/ctrl+c] '
    corrected_command = type('', (object,), {'script': 'script',
                                             'side_effect': True})
    assert confirm_text(corrected_command) == '$ script (+side effect) [enter/↑/↓/ctrl+c] '

# Generated at 2022-06-24 05:50:07.260095
# Unit test for function exception
def test_exception():
    try:
        raise Exception("TestException")
    except Exception:
        exception("TestException")



# Generated at 2022-06-24 05:50:09.569852
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    failed('msg')
    assert '\x1b[31mmsg\x1b[0m\n' == output.getvalue()

# Generated at 2022-06-24 05:50:11.998445
# Unit test for function exception
def test_exception():
    exception(u'Title', (Exception, Exception(u'Exception'), None))



# Generated at 2022-06-24 05:50:14.496943
# Unit test for function exception
def test_exception():
    try:
        raise Exception('msg')
    except Exception:
        exception('title', sys.exc_info())


# Generated at 2022-06-24 05:50:17.478082
# Unit test for function configured_successfully
def test_configured_successfully():
    print('testing configured_successfully')
    from . import utils
    assert utils.configured_successfully(utils.ConfigurationDetails(
            path='/path',
            reload='/reload')) == None

# Generated at 2022-06-24 05:50:22.030092
# Unit test for function color
def test_color():
    assert color('red')('red') == '\x1b[31mred\x1b[0m'
    settings.no_colors = True
    assert color('red')('red') == 'red'
    settings.no_colors = False

# Generated at 2022-06-24 05:50:24.104973
# Unit test for function color
def test_color():
    assert color('string') == ''
    settings.no_colors = False
    assert color('string') == 'string'

# Generated at 2022-06-24 05:50:25.862144
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('') == ''

# Generated at 2022-06-24 05:50:27.973891
# Unit test for function failed
def test_failed():
    sys.stderr.write(u'{red}Error: test_failed\n'.format(
        red=color(colorama.Fore.RED)))

# Generated at 2022-06-24 05:50:33.537787
# Unit test for function debug
def test_debug():
    def get_output():
        output = []
        old_stderr = sys.stderr

        def store_output(msg):
            output.append(msg)

        sys.stderr = store_output
        debug(u'test')
        sys.stderr = old_stderr
        return output

    settings.debug = True
    assert(get_output() == [u'\u001b[34m\u001b[1mDEBUG:\u001b[0m test\n'])
    settings.debug = False
    assert(get_output() == [])



# Generated at 2022-06-24 05:50:42.826003
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))
    content = u"eval $(thefuck --alias)"
    path = u"~/.config/fish/config.fish"
    reload = u"source ~/.config/fish/config.fish"

# Generated at 2022-06-24 05:50:50.996330
# Unit test for function exception
def test_exception():
    exception(u'Exception title', ['Traceback (most recent call last):',
                                   '  File "/code/tests/test_utils.py", line 55, in test_exception',
                                   '    raise Exception()',
                                   'Exception: '])
    exception(u'Exception title', ['Traceback (most recent call last):',
                                   '  File "/code/tests/test_utils.py", line 55, in test_exception',
                                   '    raise Exception()',
                                   'Exception: foo'])



# Generated at 2022-06-24 05:50:57.527097
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .utils import wrap_in_shell_code
    conf = {'wrap_in_shell_code': wrap_in_shell_code}
    for shell in ['bash', 'zsh', 'fish']:
        conf['shell'] = shell
        show_corrected_command(CorrectedCommand('pwd', '', conf))

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-24 05:51:02.223050
# Unit test for function exception
def test_exception():
    from StringIO import StringIO

    out = StringIO()
    sys.stderr = out
    exception('foo', (None, None, None))
    sys.stderr = sys.__stderr__
    assert out.getvalue() == (u'\x1b[41m\x1b[37m\x1b[1m[WARN] foo:\x1b[0m\n'
                              u'\n')



# Generated at 2022-06-24 05:51:12.390973
# Unit test for function debug_time
def test_debug_time():
    import time
    import unittest

    class TestDebugTime(unittest.TestCase):
        def test_debug_time(self):
            old_stderr = sys.stderr
            sys.stderr = open('/dev/null', 'w')
            from io import StringIO
            try:
                out = StringIO()
                sys.stderr = out
                settings.debug = True
                with debug_time('foo'):
                    time.sleep(1)
                self.assertRegexpMatches(out.getvalue(),
                                         r'foo took:\s+\d+\ssecond\d*')
            finally:
                sys.stderr = old_stderr

# Generated at 2022-06-24 05:51:15.598462
# Unit test for function debug
def test_debug():
    sys.stderr = TestBuffer()
    debug(u'1')
    assert u'DEBUG: 1\n' == sys.stderr.get_value()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:51:22.598458
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    import thefuck.utils as utils
    import thefuck.shells.base as base

    with mock.patch.object(base.Base, 'from_shell', return_value=base.Base()):
        utils.execute_alias = lambda x, y: None
        utils.show_corrected_command("ls")
        utils.show_corrected_command("ls -la")
        utils.show_corrected_command("git rebase -i HEAD~5")

# Generated at 2022-06-24 05:51:27.223826
# Unit test for function failed
def test_failed():
    import StringIO
    from thefuck.main import no_colors
    with no_colors():
        buf = StringIO.StringIO()
        sys.stderr = buf
        failed(u'oops')
        assert buf.getvalue() == u'oops\n'



# Generated at 2022-06-24 05:51:27.875901
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('fuck', (Exception, Exception, None))

# Generated at 2022-06-24 05:51:36.958210
# Unit test for function version
def test_version():
    import sys
    from thefuck.conf import settings
    from thefuck.utils import version
    from thefuck import __version__
    from test.lib import Mock
    _stdout = sys.stdout
    sys.stdout = Mock()
    settings.shell = 'shell'
    version('1.1.1', '2.7.11', 'shell')
    sys.stdout.write.assert_called_once_with('The Fuck 1.1.1 using Python 2.7.11 and shell\n')
    sys.stdout = _stdout



# Generated at 2022-06-24 05:51:38.910976
# Unit test for function version
def test_version():
    version('1.1', '2.7', 'shell')

# Generated at 2022-06-24 05:51:40.566180
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-24 05:51:44.644647
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .models import ConfigurationDetails
    assert how_to_configure_alias(ConfigurationDetails(
        reload='source ~/.bash_profile',
        content='eval $(thefuck --alias)',
        path='~/.bash_profile',
        can_configure_automatically=False)) == None

# Generated at 2022-06-24 05:51:47.780092
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('configuration')
    how_to_configure_alias('configuration_details')



# Generated at 2022-06-24 05:51:55.573127
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import tempfile
    import shutil

    load_conf_file = 'example.bash'
    conf_file = 'example.bash'
    load_conf_command = 'eval $(thefuck --alias)'
    reload_conf_command = 'source ~/.bash_profile'

# Generated at 2022-06-24 05:51:57.771119
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import time

    with debug_time('name') as started:
        time.sleep(0.01)
    assert datetime.now() - started > timedelta(seconds=0.01)



# Generated at 2022-06-24 05:52:01.255325
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details = {
        'content': 'content',
        'path': 'path',
        'reload': 'reload',
        'can_configure_automatically': True
        })

test_how_to_configure_alias()

# Generated at 2022-06-24 05:52:10.783327
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import shell
    from .shells import Bash, zsh
    from .devops import put, run
    from .configuration import ConfigurationDetails
    from .types import Shell
    from .utils import get_closest
    from .devops import temp_dir, temp_file_name
    from .utils import memoize
    from . import conf

    @memoize
    def run_configured_successfully(shell_, target_=None):
        with temp_dir() as tmp_path:
            if target_ is None:
                target_ = temp_file_name(tmp_path)

            with open(target_, 'w') as fd:
                fd.write('')


# Generated at 2022-06-24 05:52:12.467747
# Unit test for function rule_failed
def test_rule_failed():
    rule=u'cd /etc/ssl'
    exception(u'Rule {}'.format(rule), 'test')


# Generated at 2022-06-24 05:52:15.082100
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    settings.no_colors = True
    assert color(colorama.Style.BRIGHT) == ''

# Generated at 2022-06-24 05:52:18.233305
# Unit test for function confirm_text
def test_confirm_text():
    from .app import Application

    app = Application()
    app._corrected_command = "ls"
    app._corrected_command_side_effect = True
    confirm_text(app._corrected_command)

# Generated at 2022-06-24 05:52:21.008517
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print("\nTesting function show_corrected_command ...\n")
    class command:
        def __init__(self):
            self.script = "ls"
            self.side_effect = False

    show_corrected_command(command())

# Generated at 2022-06-24 05:52:21.605715
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-24 05:52:23.056229
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("abc{abc}") == 'abcabc'

# Generated at 2022-06-24 05:52:26.776692
# Unit test for function debug_time
def test_debug_time():
    # that function trigger debug function and we should check
    # if it working as expected
    some_time = datetime.now()
    with debug_time('test_debug_time'):
        some_time = datetime.now() - some_time

    assert(some_time)

# Generated at 2022-06-24 05:52:28.174941
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('configuration')



# Generated at 2022-06-24 05:52:36.648754
# Unit test for function confirm_text
def test_confirm_text():
    expected = (u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
                u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                u'/{red}ctrl+c{reset}]').format(
                    prefix=const.USER_COMMAND_MARK,
                    script='ls',
                    side_effect=' (+side effect)',
                    clear='\033[1K\r',
                    bold=color(colorama.Style.BRIGHT),
                    green=color(colorama.Fore.GREEN),
                    red=color(colorama.Fore.RED),
                    reset=color(colorama.Style.RESET_ALL),
                    blue=color(colorama.Fore.BLUE))


# Generated at 2022-06-24 05:52:40.581198
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    debug(u'Привет, мир!')
    assert sys.stderr.getvalue() == u'Привет, мир!\n'

