

# Generated at 2022-06-24 05:42:45.086500
# Unit test for function rule_failed
def test_rule_failed():
    title = 'title'
    traceback = 'traceback'
    rule = 'rule'
    def dummy(x):
        pass
    try:
        dummy()
    except:
        dummy(1)
        exc_info = sys.exc_info()
        rule_failed(rule, exc_info)
    else:
        dummy()
        assert(False)

# Generated at 2022-06-24 05:42:49.859110
# Unit test for function rule_failed
def test_rule_failed():
    import StringIO
    stream = StringIO.StringIO()
    # Workaround for https://github.com/nvbn/errbot.py/issues/9
    sys.stderr = stream
    rule_failed('failed', ('1', '2', '3'))
    output = stream.getvalue()
    assert "Rule failed" in output
    assert "1" in output
    assert "2" in output
    assert "3" in output

# Generated at 2022-06-24 05:43:01.258963
# Unit test for function already_configured
def test_already_configured():
    from StringIO import StringIO
    from . import conf

    # Redirect stdout to StringIO
    stdout = sys.stdout
    sys.stdout = io = StringIO()

    already_configured(conf.Config.from_name('bash'))

    # Restore stdout
    sys.stdout = stdout

    # Expected output
    expected_output = u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}. ~/.bashrc{reset} or restart your shell.\n".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload=conf.Config.from_name('bash').reload)

    assert io.getvalue() == expected_output



# Generated at 2022-06-24 05:43:03.929119
# Unit test for function version
def test_version():
    ver = version('1.12', '3.5', 'Fish 2.7')
    assert ver == 'The Fuck 1.12 using Python 3.5 and Fish 2.7'

# Generated at 2022-06-24 05:43:12.747495
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
        'content', 'path', 'reload', True)
    expected = """Seems like {bold}fuck{reset} alias isn't configured!
Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.
Or run {bold}fuck{reset} a second time to configure it automatically.
More details - https://github.com/nvbn/thefuck#manual-installation""".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        **configuration_details._asdict())
    assert how_to_configure_alias(configuration_details) == expected


# Generated at 2022-06-24 05:43:14.013177
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:43:17.062559
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''



# Generated at 2022-06-24 05:43:18.172472
# Unit test for function already_configured
def test_already_configured():
    assert already_configured() == None

# Generated at 2022-06-24 05:43:19.558878
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # function not yet defined
    assert False

# Generated at 2022-06-24 05:43:24.306494
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert not u'\x1b' in color(colorama.Fore.RED)
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Fore.RED + 1) == ''
    assert color(colorama.Fore.RED) + color(colorama.Fore.RED) == ''

# Generated at 2022-06-24 05:43:28.743184
# Unit test for function exception
def test_exception():
    """ if can raise exception, will return True
        if raise exception, will return False
        function failed is test function, if exception is work correctly,
        should return True
    """
    try:
        exception(u'', u'')
    except TypeError:
        return True
    else:
        return False

# Generated at 2022-06-24 05:43:34.734443
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write = lambda x: sys.stdout.write(
        (u'{prefix}{bold}{script}{reset}{side_effect}\n').format(
            prefix=const.USER_COMMAND_MARK,
            script=u'git commit',
            side_effect=u' (+side effect)',
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL)))
    show_corrected_command(u'git commit', True)

# Generated at 2022-06-24 05:43:35.801348
# Unit test for function debug
def test_debug():
    assert debug("Test") is None



# Generated at 2022-06-24 05:43:36.842372
# Unit test for function debug_time
def test_debug_time():
    debug_time('test message')

# Generated at 2022-06-24 05:43:40.767992
# Unit test for function version
def test_version():
    version('thefuck version', 'python version', 'shell info')
    assert(sys.stderr.getvalue() ==
           'The Fuck thefuck version using Python python version and shell info\n')


# Generated at 2022-06-24 05:43:51.575737
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = get_corrected_command()

# Generated at 2022-06-24 05:43:59.747191
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from . import utils

    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        failed(u'пошёл на хуй')
        assert sys.stderr.getvalue().endswith(u'пошёл на хуй\n')
    finally:
        sys.stderr = stderr



# Generated at 2022-06-24 05:44:04.843860
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    io = StringIO()
    sys.stderr = io
    sys.stderr.isatty = lambda: True
    confirm_text(const.CorrectedCommand([], '', None))
    output = io.getvalue().replace('\x1b[1K\r', '')
    assert output == '{}ls [enter/↑/↓/ctrl+c]'.format(
        const.USER_COMMAND_MARK)

# Generated at 2022-06-24 05:44:08.658817
# Unit test for function exception
def test_exception():
    import sys
    import io
    from contextlib import redirect_stdout
    from pytest import raises
    from thefuck.shells import Shell
    from thefuck.rules.git_push import match, get_new_command

    with raises(Exception):
        with redirect_stdout(io.StringIO()) as buffer:
            match(Shell('bash', ['git', 'push']), '2 {} git push')
            get_new_command(Shell('bash', ['git', 'push']), '2 {} git push')
            assert buffer.getvalue() == u'[WARN] Rule git_push\n' \
                                       + u'----------------------------\n\n'


# Generated at 2022-06-24 05:44:10.872186
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(const.USER_COMMAND_MARK)



# Generated at 2022-06-24 05:44:20.958281
# Unit test for function failed
def test_failed():
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
    sys.stderr.write("")
   

# Generated at 2022-06-24 05:44:25.849786
# Unit test for function rule_failed
def test_rule_failed():
    pass
warn = warn
exception = exception
rule_failed = rule_failed
failed = failed
show_corrected_command = show_corrected_command
confirm_text = confirm_text
debug = debug
debug_time = debug_time
how_to_configure_alias = how_to_configure_alias
already_configured = already_configured
configured_successfully = configured_successfully
version = version

# Generated at 2022-06-24 05:44:30.540317
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('corrected_command', (object, ),
                             {'script': "some corrected command",
                              'side_effect': False})
    confirm_text(corrected_command)
    corrected_command = type('corrected_command', (object, ),
                             {'script': "some corrected command",
                              'side_effect': True})
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:44:32.117770
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    from thefuck.utils import debug, debug_time
    debug_time("test")
    sleep(1)

# Generated at 2022-06-24 05:44:35.419464
# Unit test for function color
def test_color():
    assert color(const.DATE_FORMAT) == const.DATE_FORMAT
    assert color(const.DATE_FORMAT) != ''
    settings.no_colors = True
    assert color(const.DATE_FORMAT) == ''
    settings.no_colors = False


# Generated at 2022-06-24 05:44:38.820776
# Unit test for function failed
def test_failed():
    import sys
    import StringIO

    out = StringIO.StringIO()
    sys.stderr = out

    failed("Error")
    result = out.getvalue().strip()

    sys.stderr = sys.__stderr__
    out.close()

    assert result == u'\033[31mError\033[0m'

# Generated at 2022-06-24 05:44:41.770998
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = [["","","","","",""], ["","","","","",""]]
    assert how_to_configure_alias(configuration_details)


# Generated at 2022-06-24 05:44:47.092476
# Unit test for function configured_successfully
def test_configured_successfully():
    print(u"{METHOD}".format(METHOD="configured_successfully"))
    configuration_details = namedtuple("configuration_details", "reload")
    configuration_details.reload = "source ~/.config/zsh/zshrc"
    configured_successfully(configuration_details)


# Generated at 2022-06-24 05:44:50.622282
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(u"already configured!",
                           u"/usr/bin/fuck.py",
                           u"source .bashrc",
                           False)



# Generated at 2022-06-24 05:44:54.137503
# Unit test for function failed
def test_failed():
    def get_stderr(msg):
        try:
            failed(msg)
        except SystemExit:
            pass
        return sys.stderr.getvalue().strip()

    assert get_stderr(u'test') == u'\x1b[31mtest\x1b[0m'

# Generated at 2022-06-24 05:44:57.499873
# Unit test for function already_configured
def test_already_configured():
    from .application import Application
    from .shells import FishShell, BashShell, ZshShell
    for shell in [FishShell, BashShell, ZshShell]:
        app = Application(False, '', 'thefuck', {}, shell())
        app._already_configured()



# Generated at 2022-06-24 05:44:59.607556
# Unit test for function confirm_text
def test_confirm_text():
    import os

    os.environ['TERM'] = 'xterm-color'
    confirm_text('ls')

# Generated at 2022-06-24 05:45:03.294710
# Unit test for function version
def test_version():
    from .utils import Version
    from . import shell
    from .shells import shell_command
    version(Version('3.3'), '3.6',
            shell_command(shell.from_name(settings.shell_name)))

# Generated at 2022-06-24 05:45:05.265454
# Unit test for function warn
def test_warn():
    assert warn(u'Foo') == u'[WARN] Foo\n'


# Generated at 2022-06-24 05:45:09.846808
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule
    r = Rule('command_name', 'regex', 'make_correction')
    msg = "test"
    exc_info = ()
    rule_failed(r, exc_info)
    # TODO:


# Generated at 2022-06-24 05:45:14.607433
# Unit test for function failed
def test_failed():
    from mock import patch
    with patch('thefuck.shells.stderr') as stderr:
        failed('msg')
        stderr.write.assert_called_once_with(
            u'{red}msg{reset}\n'.format(
                red=color(colorama.Fore.RED),
                reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-24 05:45:15.832828
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('fuck')


# Generated at 2022-06-24 05:45:21.395508
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        exc_info = sys.exc_info()
        from cStringIO import StringIO
        out = StringIO()
        sys.stderr = out
        exception('Exception message', exc_info)
        assert 'Exception message:' in out.getvalue()
        assert 'RuntimeError' in out.getvalue()

# Generated at 2022-06-24 05:45:33.605583
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script.replace('\\', '\\\\')
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('*1'))
    show_corrected_command(CorrectedCommand('*2', side_effect=True))
    show_corrected_command(CorrectedCommand('ls -al | grep тест',
                                            side_effect=False))
    show_corrected_command(CorrectedCommand('ls -al | grep тест',
                                            side_effect=True))
    show_corrected_command(CorrectedCommand('ls \\\\test'))

# Generated at 2022-06-24 05:45:39.632994
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    configured_successfully('reload')
    sys.stderr = sys.__stderr__
    assert output.getvalue() == '\x1b[1mfuck\x1b[22m alias configured successfully!\nFor applying changes run \x1b[1mreload\x1b[22m or restart your shell.\n'

# Generated at 2022-06-24 05:45:40.743410
# Unit test for function already_configured
def test_already_configured():
    already_configured("The Fuck")


# Generated at 2022-06-24 05:45:43.320860
# Unit test for function already_configured
def test_already_configured():
    configuration_details = Constants(path='/home/', reload='reload')
    already_configured(configuration_details)

# Generated at 2022-06-24 05:45:51.051940
# Unit test for function debug
def test_debug():
    from . import conf
    from .conf import set_settings
    set_settings(conf.Settings(debug=True))
    from . import log
    from .log import debug
    from test.utils import CaptureOutput
    with CaptureOutput() as captured:
        debug(u'test')
    assert captured.stdout == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    with CaptureOutput() as captured:
        log.set_no_colors(True)
        debug(u'test')
    assert captured.stdout == u'DEBUG: test\n'



# Generated at 2022-06-24 05:45:54.084106
# Unit test for function failed
def test_failed():
    from .utils import capture_stderr
    with capture_stderr() as stderr:
        failed('test')
    assert u'\x1b[31mtest\x1b[0m' in stderr.getvalue()



# Generated at 2022-06-24 05:45:57.531665
# Unit test for function failed
def test_failed():
    from StringIO import StringIO

    captured_output = StringIO()
    sys.stderr = captured_output
    failed(u'LOL')
    assert captured_output.getvalue() == '{red}LOL{reset}\n'.format(
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:45:59.019663
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-24 05:46:01.276961
# Unit test for function rule_failed
def test_rule_failed():
    error_string = u" Нет переменной "
    rule_failed(error_string, None)

# Generated at 2022-06-24 05:46:06.610045
# Unit test for function warn
def test_warn():
    from mock import patch
    with patch('sys.stderr') as stderr:
        warn('warning')
        stderr.write.assert_called_with(
            u'{warn}[WARN] warning{reset}\n'.format(
                warn=color(const.BACK_RED + const.FORE_WHITE + const.BRIGHT),
                reset=color(const.RESET_ALL)))


# Generated at 2022-06-24 05:46:08.159248
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('test')

# Generated at 2022-06-24 05:46:13.999385
# Unit test for function configured_successfully
def test_configured_successfully():
    from datetime import datetime
    from .conf import ConfigurationDetails

    # Check a string
    now = datetime.now()
    configuration_details = ConfigurationDetails(
        content='its a test',
        path='/home/usr/',
        reload='/bin/source /home/usr/',
        can_configure_automatically=True)
    assert configured_successfully(configuration_details) == None

# Generated at 2022-06-24 05:46:17.812094
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("fuck") == u'Seems like fuck alias already configured!\n' \
                                            u'For applying changes run fuck\n' \
                                            u'or restart your shell.\n'


# Generated at 2022-06-24 05:46:19.898334
# Unit test for function already_configured
def test_already_configured():
    from thefuck.conf import Configured
    from thefuck.shells import shell
    configured_details = Configured(reload=shell.reload_alias())
    already_configured(configured_details)

# Generated at 2022-06-24 05:46:29.182544
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    import io

    class TestRuleFailed(unittest.TestCase):
        def setUp(self):
            self.saved_stderr = sys.stderr
            sys.stderr = self.stderr = io.StringIO()

        def tearDown(self):
            sys.stderr = self.saved_stderr

        def test_rule_failed(self):
            class Rule(object):
                def __init__(self):
                    self.name = 'test_rule'
            rule_failed(Rule(), ('Error', 'Error', 'Error'))
            self.assertIn('[WARN]', self.stderr.getvalue())

            self.assertIn('Error', self.stderr.getvalue())


# Generated at 2022-06-24 05:46:37.147548
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Command
    
    const.COMMAND_MARK = '%'
    rule_failed(Command('name'), ('exc_type', 'exc_value', 'traceback'))
    assert sys.stderr.getvalue() == u'''\
\x1b[41m\x1b[37m\x1b[1m[WARN] Rule name:\x1b[0m
Traceback (most recent call last):
exc_type: exc_value

\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m


'''


# Generated at 2022-06-24 05:46:39.562363
# Unit test for function failed
def test_failed():
    sys.stderr.write(u'\033[0;31mScript did not match any Fuck rules\033[0m\n')



# Generated at 2022-06-24 05:46:41.780921
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(configuration_details=
            namedtuple('SimpleNamespace', ['reload'])('source ~/.bash'))
    pass

# Generated at 2022-06-24 05:46:43.317598
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-24 05:46:51.270121
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from . import corrector

    def dummy_complete(command):
        return corrector.CorrectedCommand(
            command=command,
            script=command.script + '-fuck' * 5,
            side_effect=command.script.endswith('--'))

    def dummy_wait_for_confirmation(corrected_command, get_command_history):
        return True

    def dummy_get_history(limit):
        return ['fuck', 'rm -rf']

    sys.stderr = f = io.StringIO()
    settings.no_colors = True
    settings.alternatives = False
    settings.wait_command = dummy_wait_for_confirmation


# Generated at 2022-06-24 05:46:52.760476
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("test",("test", "test", "test"))


# Generated at 2022-06-24 05:46:54.582965
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'TEST_RULE'
    exception('TEST EXCEPTION', 'TEST EXCEPTION')

# Generated at 2022-06-24 05:46:57.092984
# Unit test for function exception
def test_exception():
    try:
        raise Exception('eggs')
    except Exception:
        exception(u'title', sys.exc_info())


# Unit tests for function failed

# Generated at 2022-06-24 05:46:58.495133
# Unit test for function debug
def test_debug():
    debug('test debug message')
    assert(settings.debug)



# Generated at 2022-06-24 05:47:00.791257
# Unit test for function version
def test_version():
    from . import __version__, python_version
    from .shells import shell_info

    version(__version__, python_version(), shell_info()[0])

# Generated at 2022-06-24 05:47:01.407033
# Unit test for function failed
def test_failed():
    failed('Message')

# Generated at 2022-06-24 05:47:12.831591
# Unit test for function show_corrected_command
def test_show_corrected_command():
    output = u'fuck'
    corrected_command = u'git branch'
    expected = (output + const.USER_COMMAND_MARK +
                color(colorama.Style.BRIGHT) + corrected_command +
                color(colorama.Style.RESET_ALL) + u'\n')

    sys.stderr.write = lambda s: setattr(sys.modules[__name__], 'test_output', s)

    show_corrected_command(corrected_command)
    assert const.USER_COMMAND_MARK in test_output
    assert color(colorama.Style.BRIGHT) in test_output
    assert corrected_command in test_output
    assert color(colorama.Style.RESET_ALL) in test_output


# Generated at 2022-06-24 05:47:15.287257
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('foo'):
            import time
            time.sleep(1)
    except:
        assert False, 'debug_time failed'
    else:
        assert True

# Generated at 2022-06-24 05:47:21.121532
# Unit test for function failed
def test_failed():
    import sys
    import StringIO
    stdout = sys.stdout
    stderr = sys.stderr
    out = StringIO.StringIO()
    sys.stdout = out
    sys.stderr = out

    failed('msg')
    assert(out.getvalue() == 'msg\n')

    sys.stdout = stdout
    sys.stderr = stderr

# Generated at 2022-06-24 05:47:25.531601
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import sys
    output = io.StringIO()
    sys.stderr = output
    show_corrected_command('ls -la')
    output.seek(0)
    assert output.read() == u'╰─$ ls -la\n'

# Generated at 2022-06-24 05:47:36.306767
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    import subprocess
    import os
    import shutil
    from contextlib import contextmanager

    @contextmanager
    def fake_open(*args, **kwargs):
        yield tempfile.NamedTemporaryFile(mode='w', delete=False)

    @contextmanager
    def fake_subprocess(*args, **kwargs):
        with tempfile.NamedTemporaryFile() as env_hook:
            env_hook.write(u'#!/bin/sh\n')
            env_hook.write(u'echo "export FOO=foo" >> $1\n')
            env_hook.write(u'echo "export BAR=bar" >> $1\n')
            env_hook.flush()
            os.chmod(env_hook.name, 0o755)

# Generated at 2022-06-24 05:47:39.639441
# Unit test for function rule_failed
def test_rule_failed():
    debug(const.USER_COMMAND_MARK + u'echo "hello", {}hello'.format(const.RULE_CHANGE_PROMPT))
    sys.stderr.write(u'\n')
    confirm_text(corrected_command)

# Generated at 2022-06-24 05:47:41.368293
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('git branch', ''))

# Generated at 2022-06-24 05:47:49.706568
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys

    result = io.StringIO()
    sys.stderr = result
    confirm_text(const.CorrectedCommand(
        u'run', const.Script(u'command', u'/home/nvbn'), False))

# Generated at 2022-06-24 05:47:53.280207
# Unit test for function failed
def test_failed():
    sys.stderr = []
    failed(u'Not found')
    assert sys.stderr[0] == u'\x1b[31mNot found\x1b[0m\n'

# Generated at 2022-06-24 05:48:01.755241
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Generic
    from .shells.exceptions import ShellCommandNotFound
    try:
        import blessed
    except:
        return

    confirmed_command = Generic().confirmed_command
    corrected_command = confirmed_command('ls', '')
    assert confirmed_command('ls', 'ls') == corrected_command

    corrected_command = confirmed_command('echo "!"', 'w')
    assert corrected_command.script == 'echo "!"'

    corrected_command = confirmed_command('ls non_existing_dir', '')
    assert corrected_command.script == 'ls non_existing_dir'

# Generated at 2022-06-24 05:48:05.826066
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple(
        'ConfigDetails', ('reload', 'content', 'path', 'can_configure_automatically'))
    reload = u'source ~/.zshrc'
    configuration_details.reload = reload

    already_configured(configuration_details)

# Generated at 2022-06-24 05:48:08.541706
# Unit test for function debug
def test_debug():
    debug('Test debug message')

# Generated at 2022-06-24 05:48:12.959142
# Unit test for function color
def test_color():
    assert (color(colorama.Fore.BLUE)
            == colorama.Fore.BLUE)

    settings.no_colors = True
    assert (color(colorama.Fore.BLUE)
            == u'')

# Generated at 2022-06-24 05:48:19.519425
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from thefuck.utils import CorrectedCommand

    stdout = sys.stdout
    sys.stdout = io.StringIO()
    confirm_text(CorrectedCommand('cd ..', ''))
    result = sys.stdout.getvalue()
    sys.stdout = stdout
    assert result == u'Fuck #cd .. [enter/↑/↓/ctrl+c]', result



# Generated at 2022-06-24 05:48:21.983968
# Unit test for function debug
def test_debug():
    debug('test debug')
    try:
        raise Exception('test exception')
    except:
        exception('test exception', sys.exc_info())

# Generated at 2022-06-24 05:48:23.409997
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("ls -l")
    show_corrected_command("ls -l(+side effect)")


# Generated at 2022-06-24 05:48:26.912439
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        a = 1
        b = 2
    a = 2
    b = 3
    c = 4
    return a, b, c

# Generated at 2022-06-24 05:48:32.970692
# Unit test for function version
def test_version():
    from mock import patch, Mock

    stderr = Mock()
    with patch('sys.stderr', stderr):
        version('1.2.0', '2.7.6', 'bash 3.2.48')
    assert stderr.write.called_once_with(
        'The Fuck 1.2.0 using Python 2.7.6 and bash 3.2.48\n')


# Generated at 2022-06-24 05:48:37.468175
# Unit test for function exception
def test_exception():
    def test_code():
        1 / 0

    exc_info = sys.exc_info()
    try:
        test_code()
    except ZeroDivisionError:
        exc_info = sys.exc_info()

    exception('foo', exc_info)
    assert isinstance(exc_info, tuple)



# Generated at 2022-06-24 05:48:40.214147
# Unit test for function configured_successfully
def test_configured_successfully():
    # Mock configuration details
    class Conf:
        def __init__(self):
            self.reload = "reload"

    configured_successfully(Conf())

# Generated at 2022-06-24 05:48:42.329219
# Unit test for function failed
def test_failed():
    sys.stderr = fake_stderr = FakePopen()
    failed('fail')
    assert fake_stderr.output == u'\x1b[31mfail\x1b[0m\n'



# Generated at 2022-06-24 05:48:45.113578
# Unit test for function debug
def test_debug():
    import io
    import contextlib
    from unittest import TestCase

    with contextlib.redirect_stdout(io.StringIO()):
        from . import logs
        from .conf import settings
        settings.debug = True
        logs.debug('Test')
        settings.debug = False
        logs.debug('Test')



# Generated at 2022-06-24 05:48:46.202135
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("TestRule", sys.exc_info())
    rule_failed("TestRule", sys.exc_info())

# Generated at 2022-06-24 05:48:51.971736
# Unit test for function failed
def test_failed():
    from io import BytesIO
    stderr = sys.stderr
    sys.stderr = BytesIO()
    try:
        failed('foo')
    finally:
        output = sys.stderr.getvalue()
        sys.stderr = stderr
    assert output == b'\x1b[31mfoo\x1b[0m\n'

# Generated at 2022-06-24 05:48:57.012092
# Unit test for function already_configured
def test_already_configured():
    from io import StringIO

    configuration_details = 'notice'

    # store stdout
    output = StringIO()
    sys.stdout = output

    already_configured(configuration_details)
    sys.stdout = sys.__stdout__

    return output.getvalue()



# Generated at 2022-06-24 05:49:00.259684
# Unit test for function exception
def test_exception():
    exc_info = (ValueError, ValueError('value error'), None)
    debug_message = exception('Rule', exc_info)
    assert u'[WARN] Rule: value error\n' in debug_message



# Generated at 2022-06-24 05:49:04.425695
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    sys.stderr = StringIO.StringIO()
    configured_successfully(('env_file', 'reload', 'replace', 'can_configure_automatically'))
    assert 'fuck alias configured successfully!' in sys.stderr.getvalue()



# Generated at 2022-06-24 05:49:07.404282
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(u'\n{}'.format(
        color(colorama.Fore.RED) +
        u'{}git commit'.format(const.USER_COMMAND_MARK)
    ))

# Generated at 2022-06-24 05:49:08.354373
# Unit test for function already_configured
def test_already_configured():
    already_configured(None)

# Generated at 2022-06-24 05:49:11.532898
# Unit test for function color
def test_color():
    assert u'\x1b[1m' == color(colorama.Style.BRIGHT)
    assert u'' == color(colorama.Style.BRIGHT, no_colors=True)

# Generated at 2022-06-24 05:49:22.840451
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from . import utils
    from .shells import Shell
    from .shells.sh import sh, fuck_alias

    correct_io = StringIO()
    correct_io.write(const.USER_COMMAND_MARK + fuck_alias)
    correct_io.write(' ' + color(colorama.Style.BRIGHT))
    corrected_command = sh.from_shell(fuck_alias).correct_command(
        'fuck', '')
    correct_io.write(corrected_command.script)
    correct_io.write(color(colorama.Style.RESET_ALL))
    if corrected_command.side_effect:
        correct_io.write(u' (+side effect)')

# Generated at 2022-06-24 05:49:26.498518
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    from .utils import get_closest, get_alias
    c = Shell('bash', get_alias(), get_closest())
    assert str(c.configuration_details) == 'Shell(shell=bash, cmd=source ~/.bashrc)'



# Generated at 2022-06-24 05:49:27.341449
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(u'run')

# Generated at 2022-06-24 05:49:34.194221
# Unit test for function rule_failed
def test_rule_failed():
    import tempfile
    import os
    import shlex
    import subprocess

    def rule_failed(rule, exc_info):
        sys.stderr.write(u'[WARN] Rule {}'.format(rule.name))

    thefuck_export = '''export THEFUCK_REQUIRE_CONFIRMATION=false
export THEFUCK_RULES='["wrong_script", "correct_script"]'
export THEFUCK_ALIAS='alias fuck="eval $(thefuck $(fc -ln -1))"'
export THEFUCK_RULES_FOLDER='{}'''

    commands = ['wrong_script', 'correct_script']

    with tempfile.TemporaryDirectory() as dir:
        script_file = os.path.join(dir, 'wrong_script.py')

# Generated at 2022-06-24 05:49:37.016170
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Foo'):
        import time; time.sleep(0.1)
    pass


# Generated at 2022-06-24 05:49:37.638154
# Unit test for function debug

# Generated at 2022-06-24 05:49:39.690848
# Unit test for function failed
def test_failed():
    failed(u'Message') == u'\x1b[31mMessage\x1b[0m\n'



# Generated at 2022-06-24 05:49:42.102852
# Unit test for function already_configured
def test_already_configured():
    configuration_details = const.ConfigureDetails('', '', '', '', '', True)
    already_configured(configuration_details)

# Generated at 2022-06-24 05:49:50.855066
# Unit test for function rule_failed
def test_rule_failed():
    fake_rule = object()
    sys.stderr.write(u'{warn}[WARN] {title}{reset}\n{trace}'
        u'{warn}----------------------------{reset}\n\n'.format(
            warn=color(colorama.Back.RED + colorama.Fore.WHITE
                       + colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            title=u'Rule {}'.format(fake_rule.name),
            trace=''.join(format_exception(*fake_rule.exc_info()))))

# Generated at 2022-06-24 05:50:02.670133
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    sys.stderr = sys.stdout
    corrected_command = CorrectedCommand('ls', 'ls -a')
    show_corrected_command(corrected_command)
    assert sys.stdout.getvalue() == '{}ls -a{}\n'.format(
        const.USER_COMMAND_MARK, color(colorama.Style.BRIGHT))
    corrected_command = CorrectedCommand('ls', 'ls -a', side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:50:03.266567
# Unit test for function warn
def test_warn():
    pass

# Generated at 2022-06-24 05:50:05.937101
# Unit test for function warn
def test_warn():
    import StringIO
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        warn('warn message')
        output = out.getvalue().strip()
        assert output == '[WARN] warn message'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:50:07.314748
# Unit test for function already_configured
def test_already_configured():
    already_configured(object)



# Generated at 2022-06-24 05:50:08.055898
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(123)

# Generated at 2022-06-24 05:50:09.381872
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(1)

# Generated at 2022-06-24 05:50:13.698007
# Unit test for function rule_failed
def test_rule_failed():
    class DummyRule(object):
        name = 'dummy'
    e = Exception()
    try:
        raise e
    except:
        rule_failed(DummyRule(), sys.exc_info())


# Generated at 2022-06-24 05:50:15.184925
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed.__globals__['sys'].stderr = sys.stdout

# Generated at 2022-06-24 05:50:22.267462
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from contextlib import contextmanager
    from .mock import patch
    from .time_utils import sleep

    class FakeTime(object):
        def __init__(self):
            self._now = datetime.now()

        @property
        def now(self):
            return self._now

        def __call__(self):
            return self._now

        def __enter__(self):
            return self

        def __exit__(self, *_):
            pass

        def __add__(self, other):
            self._now += other


# Generated at 2022-06-24 05:50:25.861609
# Unit test for function debug_time
def test_debug_time():
    while True:
        a = input('a:')
        if a == 'q':
            break
        with debug_time(a):
            input('b:')
            input('c:')

# Generated at 2022-06-24 05:50:29.027109
# Unit test for function already_configured
def test_already_configured():
    already_configured(
        {
            'bold': color(colorama.Style.BRIGHT),
            'reset': color(colorama.Style.RESET_ALL),
            'reload': 'test'
        }
    )

# Generated at 2022-06-24 05:50:32.746118
# Unit test for function rule_failed
def test_rule_failed():
    try:
        a = 1
        if a == 2:
            b = 'b'
    except Exception:
        rule_failed(a, sys.exc_info())
        return

# Generated at 2022-06-24 05:50:41.604008
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('my title'), None)
    exception('my title', exc_info)
    assert sys.stderr.getvalue() == u'\x1b[45m\x1b[37m\x1b[1m[WARN] ' \
                                    u'my title:\x1b[0m\nTraceback (most recent ' \
                                    u'call last):\n  File "<stdin>", ' \
                                    u'line 1, in <module>\nException: my ' \
                                    u'title\n\x1b[45m\x1b[37m\x1b[1m' \
                                    u'----------------------------\x1b[0m\n\n'

# Generated at 2022-06-24 05:50:46.110763
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('reload') == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}reload{reset} or restart your shell.".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:50:48.894393
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('source ~/.bashrc') == 'Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell.'

# Generated at 2022-06-24 05:50:50.843259
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('rm -rf /app/') == 'Fuck rm -rf /app/'

# Generated at 2022-06-24 05:50:58.546882
# Unit test for function failed
def test_failed():
    from tempfile import NamedTemporaryFile
    from .utils import wrap_streams

    with NamedTemporaryFile(mode='w+') as temp_file:
        with wrap_streams(out=temp_file, err=temp_file):
            failed('test')
            temp_file.seek(0)
            assert temp_file.readline() == color(
                colorama.Fore.RED) + 'test' + color(colorama.Style.RESET_ALL) + '\n'

# Generated at 2022-06-24 05:50:59.768601
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:51:11.252625
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Temporary redirect stdout
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    from collections import namedtuple
    CorrectedCommand = namedtuple('CorrectedCommand', ['script', 'side_effect'])
    for env in ['no-colors', 'colors']:
        colorama.init(strip=False, convert=True)
        settings.no_colors = False
        if env == 'no-colors':
            settings.no_colors = True
        show_corrected_command(CorrectedCommand(script='test', side_effect=True))
        show_corrected_command(CorrectedCommand(script='test2', side_effect=False))

# Generated at 2022-06-24 05:51:11.989311
# Unit test for function already_configured
def test_already_configured():
    from mock import Mock
    already_configured(Mock())



# Generated at 2022-06-24 05:51:13.628599
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(const.ConfigurationDetails(
        reload='source $HOME/.bashrc')) == None

# Generated at 2022-06-24 05:51:17.714320
# Unit test for function warn
def test_warn():
    result = u"\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[39;49;22m\n"
    assert warn('title') == result
    assert warn(u'title') == result



# Generated at 2022-06-24 05:51:20.995425
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'test')
    except Exception as e:
        exc_info = sys.exc_info()
        exception(u'title', exc_info)
        print(output)



# Generated at 2022-06-24 05:51:30.194827
# Unit test for function warn
def test_warn():
    title = 'test'
    title_output = u'{warn}[WARN] {title}{reset}\n'.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title=title)
    output = sys.stderr.getvalue()
    sys.stderr.truncate(0)
    sys.stderr.seek(0)
    warn(title)
    assert(sys.stderr.getvalue() == title_output)
    sys.stderr.truncate(0)
    sys.stderr.seek(0)
    sys.stderr.write(output)

# Generated at 2022-06-24 05:51:33.054321
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color('test') != ''
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:51:43.142120
# Unit test for function version
def test_version():
    """Test case for unit test"""
    class FakeStdErr(object):
        """Fake class for asserting output of version()"""
        def __init__(self):
            self.buffer = []

        def write(self, output):
            self.buffer.append(output)

        def __str__(self):
            return ''.join(self.buffer)

    fake_stderr = FakeStdErr()
    sys.stderr = fake_stderr
    version('7.8.9', '1.2.3', 'Fish Shell')
    assert str(fake_stderr) == (
        u'The Fuck 7.8.9 using Python 1.2.3 and Fish Shell\n')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:51:44.452015
# Unit test for function version
def test_version():
    version('3.5', '3.7.2', 'bash')



# Generated at 2022-06-24 05:51:47.924845
# Unit test for function confirm_text
def test_confirm_text():
    import colorama
    colorama.init()
    const.USER_COMMAND_MARK = '$'
    confirm_text('ls')

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-24 05:51:48.572927
# Unit test for function debug
def test_debug():
    debug('debug message')

# Generated at 2022-06-24 05:51:50.798739
# Unit test for function rule_failed
def test_rule_failed():
    rule = "cd"
    rules = "cd .."
    exc_info = (rules, Exception, Exception("cd"))
    rule_failed(rule, exc_info)



# Generated at 2022-06-24 05:51:52.783887
# Unit test for function warn
def test_warn():
    warn("THE FUCK IS NOT WORKING") == '[WARN] THE FUCK IS NOT WORKING'


# Generated at 2022-06-24 05:52:02.070936
# Unit test for function version
def test_version():
    assert version('0.1.0', '2.7.3', 'bash') == \
        u'The Fuck 0.1.0 using Python 2.7.3 and bash'
    assert version(u'0.1.0', u'2.7.3', u'bash') == \
        u'The Fuck 0.1.0 using Python 2.7.3 and bash'
    assert version(u'0.1.0', u'2.7.3', 'bash') == \
        u'The Fuck 0.1.0 using Python 2.7.3 and bash'
    assert version('0.1.0', u'2.7.3', 'bash') == \
        u'The Fuck 0.1.0 using Python 2.7.3 and bash'

# Generated at 2022-06-24 05:52:03.600405
# Unit test for function exception
def test_exception():
    try:
        raise ValueError()
    except ValueError:
        exception('ValueError', sys.exc_info())

# Generated at 2022-06-24 05:52:04.925671
# Unit test for function warn
def test_warn():
    with settings(no_colors=True):
        assert warn(u'some title') == u'[WARN] some title\n'



# Generated at 2022-06-24 05:52:07.274975
# Unit test for function color
def test_color():
    assert not color('a')
    settings.no_colors = False
    assert color('a') == 'a'
    settings.no_colors = True

# Generated at 2022-06-24 05:52:15.146117
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = None
    how_to_configure_alias(configuration_details)
    configuration_details = type("namespace", (),
                                 {'_asdict': lambda slf:
                                 dict(content='x',
                                      path='y',
                                      reload='z',
                                      can_configure_automatically=False)})
    how_to_configure_alias(configuration_details)
    configuration_details = type("namespace", (),
                                 {'_asdict': lambda slf:
                                 dict(content='x',
                                      path='y',
                                      reload='z',
                                      can_configure_automatically=True)})
    how_to_configure_alias(configuration_details)
    print("Testing how_to_configure_alias is done")

#

# Generated at 2022-06-24 05:52:19.668283
# Unit test for function configured_successfully
def test_configured_successfully():
    class FakeSettings(object):
        pass

    settings = FakeSettings()
    settings.no_colors = False
    from .conf import _settings
    _settings._set_no_color(settings)
    configured_successfully(
        configuration_details=const.ConfigureShell(
            reload='reload',
            shell_type='zsh'))

# Generated at 2022-06-24 05:52:29.921697
# Unit test for function exception
def test_exception():
    from six import StringIO
    from mock import patch

    with patch('sys.stderr', StringIO()) as stderr:
        exception(u'Title', (IndexError, IndexError(), None))

# Generated at 2022-06-24 05:52:33.919872
# Unit test for function failed
def test_failed():
    expected_output = "\x1b[31mtest msg\x1b[0m\n"

# Generated at 2022-06-24 05:52:44.579677
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.settings import settings
    from thefuck.shells import Shell

    settings.no_colors = True
    assert confirm_text(Shell('ls')) == '[enter/↑/↓/ctrl+c]'
    settings.no_colors = False
    assert confirm_text(Shell('ls')) == (
        u'[\033[1K\r\x1b[1m\x1b[92menter\x1b[0m'
        u'/\x1b[1m\x1b[34m↑\x1b[0m/\x1b[1m\x1b[34m↓\x1b[0m'
        u'/\x1b[1m\x1b[31mctrl+c\x1b[0m]')