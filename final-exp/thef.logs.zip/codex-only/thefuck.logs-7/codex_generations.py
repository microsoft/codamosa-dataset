

# Generated at 2022-06-24 05:42:46.847845
# Unit test for function failed
def test_failed():
    from io import StringIO
    output = StringIO()

    failed('bad')
    output.seek(0)
    assert u'{red}bad{reset}\n'.format(
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL)) in output.read()

# Generated at 2022-06-24 05:42:48.525555
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('git brach') == u'[git brach]'


# Generated at 2022-06-24 05:42:49.646961
# Unit test for function version
def test_version():
    version("3.4", "3.4", "3.4")


# Generated at 2022-06-24 05:42:57.657825
# Unit test for function confirm_text
def test_confirm_text():
    # create a StringIO and redirect sys.stderr to it
    import sys
    import os
    import StringIO
    stderr_old = sys.stderr
    sys.stderr = StringIO.StringIO()

    # execute the function
    from thefuck.utils import confirm_text
    confirm_text('test')
    # get the value of sys.stderr and restore the original stderr
    sys.stderr.getvalue()
    sys.stderr = stderr_old

# Generated at 2022-06-24 05:43:01.624897
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime

    class MockStdErr(object):
        def __init__(self):
            self.write = lambda x: None

    with MockStdErr() as mock:
        with debug_time('foo'):
            pass

        def test():
            return datetime.now()

        with debug_time('bar'):
            test()

    assert not any('foo' in l for l in mock.write.calls)
    assert any('bar' in l for l in mock.write.calls)

# Generated at 2022-06-24 05:43:05.727200
# Unit test for function color
def test_color():
    try:
        colorama.init()
        assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
        settings.no_colors = True
        assert color(colorama.Fore.BLUE) == ''
    finally:
        settings.no_colors = False
        colorama.deinit()

# Generated at 2022-06-24 05:43:08.421311
# Unit test for function rule_failed
def test_rule_failed():
    import sys
    try:
        raise Exception()
    except Exception:
        rule = 'This rule'
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:43:08.998447
# Unit test for function configured_successfully
def test_configured_successfully():
    pass

# Generated at 2022-06-24 05:43:10.336475
# Unit test for function already_configured
def test_already_configured():
    assert already_configured((None, '.bashrc', 'source ~/.bashrc')) == None

# Generated at 2022-06-24 05:43:18.063456
# Unit test for function rule_failed
def test_rule_failed():
    logging.warn = mock.MagicMock()
    exc_info = (Exception, Exception('error'), None)
    rule_failed(Rule('name', get_new_command_func=lambda *args: 'new_command'),
                exc_info)
    assert logging.warn.call_count == 1
    assert logging.warn.call_args[0][0].startswith('Rule name:')
    assert exc_info[1].message in logging.warn.call_args[0][0]



# Generated at 2022-06-24 05:43:20.997903
# Unit test for function already_configured
def test_already_configured():
	configuration_details = FakeConfig()
	already_configured(configuration_details)
	assert configuration_details.is_called == True


# Generated at 2022-06-24 05:43:23.407099
# Unit test for function already_configured
def test_already_configured():
    if __name__ == "tests.actions.output":
        reload = 'source ~/.bashrc'
        already_configured(reload)


# Generated at 2022-06-24 05:43:26.298505
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError()
    except RuntimeError:
        test_exc_info = sys.exc_info()
        exception(u'Test Exception', test_exc_info)

# Generated at 2022-06-24 05:43:29.633541
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('forget-it') == u"fuck alias configured successfully!\n" \
                                                  u"For applying changes run forget-it\n" \
                                                  u" or restart your shell."


# Generated at 2022-06-24 05:43:32.219427
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:43:33.149692
# Unit test for function failed
def test_failed():
    failed(u'Test fail')



# Generated at 2022-06-24 05:43:34.313679
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-24 05:43:36.191821
# Unit test for function rule_failed
def test_rule_failed():
    def test():
        raise Exception('test')
    try:
        test()
    except Exception as e:
        rule_failed('rule_name', sys.exc_info())

# Generated at 2022-06-24 05:43:40.988370
# Unit test for function warn
def test_warn():
    from io import StringIO
    out = StringIO()
    sys.stderr = out
    warn('test')
    assert out.getvalue() == u'[WARN] test\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:43:42.533204
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias("configuration_details") == None

# Generated at 2022-06-24 05:43:45.801750
# Unit test for function failed
def test_failed():
    import io
    out = io.StringIO()
    sys.stderr = out
    failed(u'foo')
    assert out.getvalue() == u'foo\n'



# Generated at 2022-06-24 05:43:46.860872
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-24 05:43:49.915094
# Unit test for function already_configured
def test_already_configured():
    
    # The function expect an instance of the ConfigurationDetails class
    class ConfigurationDetails(object):
        def __init__(self, reload):
            self.reload = reload
    
    configuration_details = ConfigurationDetails("My reload command")
    already_configured(configuration_details)
    
    

# Generated at 2022-06-24 05:43:55.573659
# Unit test for function debug_time
def test_debug_time():
    import time

    class TestException(Exception):
        pass

    with debug_time('Foo'):
        for _ in range(4):
            time.sleep(0.1)

    try:
        with debug_time('Bar'):
            time.sleep(0.1)
            raise TestException()
    except TestException:
        pass

# Generated at 2022-06-24 05:44:00.192350
# Unit test for function color
def test_color():
    assert not color('\x1B[31m' + 'foo\x1B[0m')
    colorama.init()
    assert color('\x1B[31m' + 'foo\x1B[0m') == '\x1B[31mfoo\x1B[0m'

# Generated at 2022-06-24 05:44:06.777609
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os

    tmp_file = 'tmp.txt'
    with open(tmp_file, 'w') as f:
        with open(__file__, 'r') as mf:
            f.write(mf.read())
    assert os.path.exists(tmp_file)
    from thefuck.shells import Bash
    from thefuck.correct import Command

    corrected_command = Command('cat tmp', 'cat tmp.txt')
    shell = Bash()
    show_corrected_command(corrected_command)
    confirm_text(corrected_command)
    os.remove(tmp_file)
    assert not os.path.exists(tmp_file)

# Generated at 2022-06-24 05:44:08.553511
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    assert 1 == 1

# Generated at 2022-06-24 05:44:12.777461
# Unit test for function exception
def test_exception():
    etype = RuntimeError
    value = RuntimeError('Something something')
    tb = value.__traceback__

    try:
        raise value
    except etype:
        exc_info = (etype, value, tb)
        exception('Unit test', exc_info)

# Generated at 2022-06-24 05:44:14.675937
# Unit test for function version
def test_version():
    # check for the type of the values:
    version('thefuck_version', 'python_version', 'shell_info')

# Generated at 2022-06-24 05:44:24.801440
# Unit test for function already_configured
def test_already_configured():
    import mock
    import sys
    from .conf import Configuration
    Configuration._instance = None
    with mock.patch('thefuck.shells.get_shell', return_value='shell'):
        with mock.patch.multiple(
            'thefuck.conf.Configuration',
            user_alias='user_alias',
            reload='reload'):
            already_configured(Configuration())
            assert sys.stderr.getvalue() == (
                u"Seems like {bold}fuck{reset} alias already configured!\n"
                u"For applying changes run {bold}reload{reset}"
                u" or restart your shell.\n".format(
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL)))
    Configuration._instance = None



# Generated at 2022-06-24 05:44:26.616565
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test error')
    except Exception as e:
        exception('Test', sys.exc_info())

# Generated at 2022-06-24 05:44:31.844942
# Unit test for function debug
def test_debug():
    import mock
    from mock import patch
    from thefuck.utils import debug
    with mock.patch('sys.stderr', new=mock.Mock()) as mock_stderr:
        with patch.dict('os.environ', {'TF_DEBUG':'1'}):
            debug('test-msg')
            mock_stderr.write.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test-msg\n')

# Generated at 2022-06-24 05:44:33.681141
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise Exception('Expected exception')
    except Exception as e:
        rule_failed(None, sys.exc_info())

# Generated at 2022-06-24 05:44:34.575496
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('test', 'test')

# Generated at 2022-06-24 05:44:36.696570
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        script = 'echo "Fuck"'
        side_effect = False
    show_corrected_command(CorrectedCommand())


# Generated at 2022-06-24 05:44:40.412715
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    from .rules.patterns import regex_match
    from .shells import Shell

    class MyRule(rules.Rule):
        name = 'test'
        pattern = regex_match('test', 'test2', 'test3')

    rule = MyRule()
    try:
        raise Exception('Test')
    except Exception:
        rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:44:44.329815
# Unit test for function already_configured
def test_already_configured():
    import io
    import sys
    output = io.BytesIO()
    sys.stderr = output
    already_configured(lambda: 'test')
    assert output.getvalue().startswith(b'Seems like ')


# Generated at 2022-06-24 05:44:54.778343
# Unit test for function version
def test_version():
    import sys
    import StringIO
    from mock import patch
    from thefuck import version
    from thefuck.main import PYTHON_VERSION
    from thefuck.utils import get_shell_info

    with patch('thefuck.main.__version__', '1.1.1') as version_mock,\
            patch('thefuck.utils.get_shell_info',
                  return_value='ShellInfoMock'):
        s = StringIO.StringIO()
        sys.stderr = s
        version()
        sys.stderr = sys.__stderr__
        assert s.getvalue() == u'The Fuck 1.1.1 using Python {} and ShellInfoMock\n'.format(PYTHON_VERSION)
        version_mock.assert_called_once_with()
        get_shell

# Generated at 2022-06-24 05:44:57.782565
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully()

# Generated at 2022-06-24 05:44:59.029223
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()

# Generated at 2022-06-24 05:45:00.821789
# Unit test for function failed
def test_failed():
    sys.stderr.write = lambda x: None
    failed(u'Boom!')



# Generated at 2022-06-24 05:45:02.342499
# Unit test for function debug
def test_debug():
    debug(u"123")


# Generated at 2022-06-24 05:45:03.382687
# Unit test for function warn
def test_warn():
    warn(u'title')



# Generated at 2022-06-24 05:45:07.175421
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED + 'test') == u'\x1b[41mtest'
    settings.no_colors = True
    assert color('test') == 'test'

# Generated at 2022-06-24 05:45:09.570612
# Unit test for function rule_failed
def test_rule_failed():
    import sys
    rule_failed("rule name ","type")
    assert sys.stderr.getvalue() == u"[ERROR] rule name\n"

# Generated at 2022-06-24 05:45:11.616328
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('ls') == 'Seems like fuck alias already configured!\nFor applying changes run ls or restart your shell.'

# Generated at 2022-06-24 05:45:15.577451
# Unit test for function debug
def test_debug():
    from _pytest.monkeypatch import MonkeyPatch
    monkeypatch = MonkeyPatch()
    monkeypatch.setattr(sys, 'stderr', sys.stdout)
    monkeypatch.setenv('TF_DEBUG', '1', prepend=False)
    debug('test')
    monkeypatch.undo()

# Generated at 2022-06-24 05:45:19.506110
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command
    show_corrected_command(Command('ls', 'ls -lha'))
    show_corrected_command(Command('git', 'git log',
      side_effect=lambda: None))


# Generated at 2022-06-24 05:45:26.240912
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    from StringIO import StringIO

    saved_stdout = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        settings.debug = True
        with debug_time('foo'):
            sleep(1)
        assert out.getvalue().startswith('DEBUG: foo took: 0:00:01.003')
    finally:
        sys.stderr = saved_stdout

# Generated at 2022-06-24 05:45:34.331554
# Unit test for function debug_time
def test_debug_time():
    from contextlib import closing
    from datetime import timedelta
    from mock import Mock
    from .conf import settings
    from . import logs
    settings.debug = True
    with closing(Mock(spec=logs.sys.stderr)) as stderr, logs.debug_time('test'):
        pass
    stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m '
                                                        'test took: 0:00:00.000001\n')

# Generated at 2022-06-24 05:45:45.376852
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import re
    import unittest

    from contextlib import contextmanager
    from io import StringIO

    from .conf import ConfigurationNotFound

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class How_to_configure_alias_test(unittest.TestCase):
        def test_no_configuration_details(self):
            with captured_output() as (out, err):
                how_to_configure_

# Generated at 2022-06-24 05:45:49.602130
# Unit test for function version
def test_version():
    import io
    import sys
    import pytest
    io_stream = io.StringIO()
    sys.stderr = io_stream
    version('The Fuck 3.2', 'Python 3.2', 'Shell 3.2')
    sys.stderr = sys.__stderr__
    assert io_stream.getvalue() == 'The Fuck 3.2 using Python 3.2 and Shell 3.2\n'



# Generated at 2022-06-24 05:45:50.536998
# Unit test for function warn
def test_warn():
    warn('test')


# Generated at 2022-06-24 05:45:55.428733
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Zsh
    from .types import CorrectedCommand

    confirm_text(CorrectedCommand(
        script='ls', side_effect=False))
    confirm_text(CorrectedCommand(
        script='ls', side_effect=True))
    confirm_text(CorrectedCommand(
        script='ls', side_effect=True), shell=Zsh)
    confirm_text(CorrectedCommand(
        script='ls', side_effect=True), color_mode=True)

# Generated at 2022-06-24 05:45:56.942920
# Unit test for function failed
def test_failed():
    failed('msg')

# Generated at 2022-06-24 05:46:00.981620
# Unit test for function confirm_text
def test_confirm_text():
    import os
    class Command():
        def __init__(self):
            self.script = 'ls'
            self.side_effect = True
    command = Command()
    confirm_text(command)
    assert 1 == 1, 'confirm_text - wrong color'

# Generated at 2022-06-24 05:46:04.153275
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(how_to_configure_alias('content', 'path', 'reload', True))

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-24 05:46:05.625931
# Unit test for function exception
def test_exception():
    assert exception(u'hoho', 'exc_info') == ''


# Generated at 2022-06-24 05:46:07.804921
# Unit test for function debug_time
def test_debug_time():
    result = []
    with debug_time('test'):
        result.append('test')
    assert result == ['test']

# Generated at 2022-06-24 05:46:11.016591
# Unit test for function version
def test_version():
    from . import get_version, get_python_info, get_shell_info
    version(
        get_version(),
        get_python_info(),
        get_shell_info())
# END Unit test for function version

# Generated at 2022-06-24 05:46:12.616019
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('reload_command') == None


# Generated at 2022-06-24 05:46:14.102824
# Unit test for function confirm_text
def test_confirm_text():
    result = confirm_text('test-command')
    assert result is None


# Generated at 2022-06-24 05:46:16.778487
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time(u'Test'):
            import time
            time.sleep(1)
    except:
        pass

# Generated at 2022-06-24 05:46:19.740776
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = open('output.txt', 'w')
    test_corrected_command = 'pwd'
    confirm_text(test_corrected_command)
    sys.stderr.close()

# Generated at 2022-06-24 05:46:29.114957
# Unit test for function exception
def test_exception():
    import sys
    import StringIO

    # Test exception that can be formated by unicode
    exc = Exception(u"Привет мир!\n")
    exception('Hello', sys.exc_info())
    assert u"[WARN] Hello:\n  Traceback (most recent call last):\n"\
           u"    File \"\", line 1, in \n"\
           u"  Exception: Привет мир!\n\n"\
           u"[WARN] ----------------------------\n\n"\
           u"" == sys.stderr.getvalue()

    # Test exception that can't be formated by unicode

# Generated at 2022-06-24 05:46:34.500320
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells.bash import Bash
    from .shells.base import get_aliases

    aliases = get_aliases(Bash())
    for alias in aliases:
        if alias.name == 'fuck':
            break
    assert str(alias) == 'alias fuck=\'eval $(thefuck $(fc -ln -1)); history -r\''
    assert alias.name == 'fuck'

# Generated at 2022-06-24 05:46:39.648848
# Unit test for function version
def test_version():
    print('test_version')
    from . import __version__
    from . import __python_version__
    from . import shell

    import mock

    sys.stderr = mock.MagicMock()
    version(__version__, __python_version__, '{} shell'.format(shell))
    sys.stderr.write.assert_called_once_with(
        u'The Fuck {} using Python {} and {} shell\n'.format(__version__,
                                                             __python_version__,
                                                             shell))

# Generated at 2022-06-24 05:46:49.081484
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .repl import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails('~/.bashrc',
                                                'bash',
                                                'source ~/.bashrc',
                                                False))
    how_to_configure_alias(ConfigurationDetails('~/.bash_profile',
                                                'bash',
                                                'source ~/.bash_profile',
                                                False))
    how_to_configure_alias(ConfigurationDetails('~/.zshrc',
                                                'zsh',
                                                'source ~/.zshrc',
                                                False))
    how_to_configure_alias(ConfigurationDetails('~/.bashrc',
                                                'bash',
                                                'source ~/.bashrc',
                                                True))

# Generated at 2022-06-24 05:46:53.790094
# Unit test for function already_configured
def test_already_configured():
    configuration_details = u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell."
    alreadyset = already_configured(configuration_details)
    assert alreadyset == configuration_details


# Generated at 2022-06-24 05:47:02.841522
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from . import conf

    show_corrected_command(CorrectedCommand(script=u'mkdir /usr/loacl/bin',
                                            side_effect=True))
    assert sys.stderr.getvalue() == \
           u'{}mkdir /usr/loacl/bin (+side effect)\n'.format(
               const.USER_COMMAND_MARK)
    sys.stderr.seek(0)
    sys.stderr.truncate(0)

    show_corrected_command(CorrectedCommand(script=u'mkdir /usr/loacl/bin',
                                            side_effect=False))

# Generated at 2022-06-24 05:47:05.075881
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('red') == ''

# Generated at 2022-06-24 05:47:08.730524
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("configuration_details") == 'Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.'


# Generated at 2022-06-24 05:47:09.694318
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-24 05:47:19.572466
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    sys.stdout = output = io.BytesIO()
    how_to_configure_alias(None)
    assert output.getvalue() == ('Seems like \x1b[1mfuck\x1b[21m alias isn\'t '
        'configured!\nMore details - https://github.com/nvbn/thefuck#manual'
        '-installation\n')
    sys.stdout = output = io.BytesIO()
    how_to_configure_alias({'reload': 'test', 'path': 'test', 'content': 'test',
'can_configure_automatically': False})

# Generated at 2022-06-24 05:47:24.702852
# Unit test for function configured_successfully
def test_configured_successfully():
    print(u"{bold}fuck{reset} alias configured successfully!\For applying changes run {bold}{reload}{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload='~/.bashrc'))


# Generated at 2022-06-24 05:47:30.179592
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', StringIO()) as stderr_mocked:
        debug(u'test')
        assert u'DEBUG: test\n' == stderr_mocked.getvalue()

    with patch('sys.stderr', StringIO()) as stderr_mocked:
        settings.debug = False
        debug(u'test')
        assert stderr_mocked.getvalue().count(u'DEBUG: test') == 0
        settings.debug = True

# Generated at 2022-06-24 05:47:39.561605
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """
    Tests for function how_to_configure_alias
    """

# Generated at 2022-06-24 05:47:41.936376
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Run the function with a CorrectedCommand Object
    corrected_command = const.CorrectedCommand(script='uname -a', side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:47:46.855032
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    io = StringIO()
    sys.stderr = io
    failed('message')
    restored, _ = io.getvalue().split('\n')
    return restored == u'{red}message{reset}'.format(
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:47:48.562468
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass



# Generated at 2022-06-24 05:47:49.312836
# Unit test for function confirm_text
def test_confirm_text():
    pass

# Generated at 2022-06-24 05:47:55.857268
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from .utils import debug_time
    err = Mock()

    with debug_time('foo'):
        pass

    err.assert_called_once_with(u'foo took: 0:00:00')

    err.reset_mock()

    with debug_time('bar'):
        pass

    err.assert_called_once_with(u'bar took: 0:00:00')

# Generated at 2022-06-24 05:47:59.708068
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.shells.utils import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        '~/.bashrc',
        '''eval $(thefuck --alias)''',
        'source ~/.bashrc',
        True))


# Generated at 2022-06-24 05:48:03.784852
# Unit test for function configured_successfully
def test_configured_successfully():
    class MockConfigDetails(object):
        def __init__(self):
            self.reload = 'reload'
    configuration_details = MockConfigDetails()
    sys.stderr = sys.stdout
    configured_successfully(configuration_details)

# Generated at 2022-06-24 05:48:06.816790
# Unit test for function version
def test_version():
    from . import __version__
    from . import _get_shell_info

    sys.stderr = sys.stdout
    version(__version__, sys.version, _get_shell_info())



# Generated at 2022-06-24 05:48:13.131295
# Unit test for function version
def test_version():
    assert version('1.2.3', '2.7' or '3.5', 'echo') == \
           u'The Fuck 1.2.3 using Python 2.7 and echo\n' or \
           u'The Fuck 1.2.3 using Python 3.5 and echo\n'

# Generated at 2022-06-24 05:48:17.515753
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    corrected_command = CorrectedCommand(u'ls -la', True)
    show_corrected_command(corrected_command) == (
        u'$ ls -la (+side effect)\n'
    )



# Generated at 2022-06-24 05:48:19.907757
# Unit test for function exception
def test_exception():

    try:
        raise ValueError('new value error')
    except Exception:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:48:26.561115
# Unit test for function rule_failed
def test_rule_failed():
    """test for function rule_failed"""
    import pytest
    from .rules import Command

    @pytest.fixture
    def test_rule():
        rule = Command()
        rule.name = 'test'
        return rule

    @pytest.fixture
    def test_excinfo():
        return [ValueError, ValueError(), ValueError()]

    def test_rule_failed_no_exception():
        try:
            raise ValueError('Test exception')
        except ValueError as e:
            rule_failed(test_rule, e)



# Generated at 2022-06-24 05:48:33.740627
# Unit test for function debug_time
def test_debug_time():
    class Object(object):
        @staticmethod
        def debug(msg):
            Object.msg = msg

    def run(func):
        with debug_time('took'):
            func()

    # Short sleep
    run(lambda: Object.debug('ok'))

    assert(Object.msg == 'took took: 0:00:00.003000')

    # Long sleep
    run(lambda: Object.debug('fail'))

    assert(Object.msg == 'fail took: 0:00:00.030000')

# Generated at 2022-06-24 05:48:41.516544
# Unit test for function version
def test_version():
    from six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO
    import sys
    import platform

    old_stdout = sys.stdout
    sys.stdout = StringIO()
    try:
        version('1.2.3', '2.7.8', 'shell')
        assert sys.stdout.getvalue() == u'The Fuck 1.2.3 using Python 2.7.8 and shell\n'
    finally:
        sys.stdout = old_stdout



# Generated at 2022-06-24 05:48:49.792436
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from tempfile import mkstemp
    from os.path import exists
    from shutil import rmtree
    from os import remove, makedirs, close, stat

    class FakeStatResult(object):
        st_mode = 33261

    def fake_stat(*args, **kwargs):
        return FakeStatResult()

    tempdir = mkstemp()[1]
    close(tempdir)
    close(tempdir)
    file = mkstemp()[1]
    close(file)
    close(file)
    makedirs('{}/.config/fish/functions'.format(tempdir))

    class FakeConfigurationDetails():
        def __init__(self, path, content, reload, can_configure_automatically):
            self.path = path
            self.content = content
            self.reload = reload

# Generated at 2022-06-24 05:48:53.382405
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("cmd", True) == '> cmd (+side effect) [enter/↑/↓/ctrl+c]'
    assert confirm_text("cmd") == '> cmd [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:49:01.469464
# Unit test for function already_configured
def test_already_configured():
    from .shells import Shell
    from .utils import get_closest
    shell_path = get_closest('git')
    print(shell_path)
    a = Shell(shell_path)
    b = Shell(shell_path)
    c = Shell(shell_path)
    assert a.resolve_alias("fuck") == b.resolve_alias("fuck") == c.resolve_alias("fuck") == "eval \"`thefuck $(fc -ln -1)`\""
    already_configured(a)

# Generated at 2022-06-24 05:49:05.139038
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Exceptional!')
    except Exception as e:
        exception(u'Reality check', sys.exc_info())
        assert sys.exc_info()[0] is e.__class__



# Generated at 2022-06-24 05:49:11.003606
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock

    with mock.patch('datetime.datetime') as now:
        now.now.side_effect = [datetime(2013, 4, 3),
                               datetime(2013, 4, 3, 1)]
        with mock.patch('subprocess.Popen') as popen:
            popen.return_value.returncode = 1
            with debug_time('test'):
                time.sleep(3600)
            popen.assert_called_once_with(
                ['bash', '-c', 'test'])

# Generated at 2022-06-24 05:49:12.140525
# Unit test for function warn
def test_warn():
    warn('Test title')



# Generated at 2022-06-24 05:49:23.376162
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import io
    import sys
    # Gather stdout in buffer
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    # Execute function
    confirm_text("test")
    # Get executed function output
    msg = sys.stdout.getvalue()
    # Restore stdout
    sys.stdout = old_stdout

    expected = u"\x1b[1K\r\x1b[1mtest\x1b[21m \x1b[32menter\x1b[39m/\x1b[34m↑\x1b[39m/\x1b[34m↓\x1b[39m/\x1b[31mctrl+c\x1b[39m]"
    # Compare stdout to expected function

# Generated at 2022-06-24 05:49:26.676959
# Unit test for function warn
def test_warn():
    warn('Error')
    assert sys.stderr.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] Error\x1b[0m\n'


# Generated at 2022-06-24 05:49:29.266116
# Unit test for function warn
def test_warn():
    sys.stderr = open('log.txt', 'w')
    warn('test_warn')
    assert open('log.txt', 'r').read() == '[WARN] test_warn\n'


# Generated at 2022-06-24 05:49:30.455595
# Unit test for function warn
def test_warn():
    warn("test")


# Generated at 2022-06-24 05:49:42.026141
# Unit test for function debug_time
def test_debug_time():
    import mock
    with mock.patch('sys.stderr') as stderr, \
            mock.patch('functools.partial') as mock_partial, \
            mock.patch('datetime.datetime') as mock_datetime, \
            mock.patch('thefuck.utils.settings') as settings:
        settings.debug = True
        debug_time('test')
        mock_partial.assert_called_with(mock_datetime.now)
        mock_partial().__enter__.assert_called_once_with()
        mock_partial().__exit__.assert_called_once_with(None, None, None)

# Generated at 2022-06-24 05:49:50.802205
# Unit test for function debug
def test_debug():
    import os
    import mock
    _, path = os.path.splitdrive(__file__)
    path = path.lstrip(os.path.sep)
    _, path = os.path.split(path)
    assert 'test_utils' == path

    with mock.patch('sys.stderr') as stderr:
        debug(u'eggs')
        assert stderr.write.called
        assert u'\x1b[1;34mDEBUG:\x1b[0m eggs\n' == stderr.write.call_args[0][0]

# Generated at 2022-06-24 05:49:59.406804
# Unit test for function version
def test_version():
    from StringIO import StringIO
    from . import version as fuck_version
    from . import __version__ as thefuck_version
    import sys
    import platform

    output = StringIO()
    sys.stderr = output

    version(thefuck_version, platform.python_version(),
            platform.platform())

    output.seek(0)
    assert output.read() == (
        'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                      platform.python_version(),
                                                      platform.platform()))

# Generated at 2022-06-24 05:50:04.798067
# Unit test for function version
def test_version():
    from textwrap import dedent
    from .repository import get_version
    from .shells import get_shell_info
    from .utils import get_python_version
    version(get_version(), get_python_version(), get_shell_info())
    assert sys.stderr.getvalue() == dedent(u'''\
        The Fuck {tf_version} using Python {py_version} and {shell_info}
        '''.format(tf_version=get_version(),
                   py_version=get_python_version(),
                   shell_info=get_shell_info()))



# Generated at 2022-06-24 05:50:11.206367
# Unit test for function already_configured
def test_already_configured():
    assert 'Seems like \033[1mFuck\033[0m alias already configured!\nFor applying changes run \033[1mreload\033[0m or restart your shell.' == already_configured({'path': 'asd','content': 'asd','reload': 'reload','can_configure_automatically': False})


# Generated at 2022-06-24 05:50:12.671906
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == ''



# Generated at 2022-06-24 05:50:17.826048
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        pass
    configuration_details = ConfigurationDetails()
    configuration_details.path = 'path'
    configuration_details.content = 'content'
    configuration_details.can_configure_automatically = True
    configuration_details.reload = 'reload'
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-24 05:50:22.997862
# Unit test for function configured_successfully
def test_configured_successfully():
    class TestConfig(object):
        def __init__(self, reload):
            self.reload = reload

    test_config = TestConfig('test_reload')
    assert configured_successfully(test_config) == 'fuck alias configured successfully!\nFor applying changes run test_reload or restart your shell.'

# Generated at 2022-06-24 05:50:29.317565
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    with redirect_stderr(StringIO()) as stderr:
        warn('fuck')
        assert stderr.getvalue().startswith(
            u'{warn}[WARN] fuck{reset}\n'.format(
                warn=color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)))



# Generated at 2022-06-24 05:50:31.606121
# Unit test for function debug_time
def test_debug_time():
    with debug_time('x'):
        pass



# Generated at 2022-06-24 05:50:41.269098
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .conf import settings
    from .utils import get_closest
    settings.no_colors = True
    assert show_corrected_command(get_closest('fuck', ['ls'], '')) == 'fuck ls\n'
    settings.no_colors = False
    assert show_corrected_command(get_closest('fuck', ['ls'], '')) == u'fuck ls\n'
    settings.no_colors = True
    assert show_corrected_command(get_closest('fuck', ['ls'], '', True)) == 'fuck ls (+side effect)\n'
    settings.no_colors = False
    assert show_corrected_command(get_closest('fuck', ['ls'], '', True)) == u'fuck ls (+side effect)\n'


# Generated at 2022-06-24 05:50:41.816838
# Unit test for function rule_failed
def test_rule_failed():
    pass

# Generated at 2022-06-24 05:50:45.881142
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple('configuration_details',
                                       ['content', 'path', 'reload', 'can_configure_automatically'])
    how_to_configure_alias(configuration_details('ooo', 'bbb', 'ccc', 1))

# Generated at 2022-06-24 05:50:47.411350
# Unit test for function warn
def test_warn():
    warn(title='Title msg')


# Generated at 2022-06-24 05:50:58.881073
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import HOW_TO_CONFIGURE_ALIAS, ALREADY_CONFIGURED, CONFIGURED_SUCCESSFULLY, VERSION
    from .main import Command
    from .git import GitRule
    from .utils import get_git_root
    import sys

    how_to_configure_alias(HOW_TO_CONFIGURE_ALIAS)
    already_configured(ALREADY_CONFIGURED)
    configured_successfully(CONFIGURED_SUCCESSFULLY)
    version(VERSION, '', '')

    class MyGitRule(GitRule):
        command = 'git'

        def get_new_command(self, command):
            return 'git status'

    my_git_rule = MyGitRule()


# Generated at 2022-06-24 05:51:00.426531
# Unit test for function configured_successfully
def test_configured_successfully():
    try:
        configured_successfully(u'python')
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 05:51:02.587697
# Unit test for function warn
def test_warn():
    warn('test')
    assert warn.__doc__ == 'Utility for ability to disabling colored output.'



# Generated at 2022-06-24 05:51:06.779425
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = False
    assert color('') == ''
    settings.no_colors = True
    assert color('') == ''
    settings.no_colors = False



# Generated at 2022-06-24 05:51:08.178693
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-24 05:51:10.367193
# Unit test for function failed
def test_failed():
    assert failed('warn') == u'\x1b[31mwarn\x1b[0m\n'



# Generated at 2022-06-24 05:51:12.587717
# Unit test for function exception
def test_exception():
    try:
        raise Exception('fail')
    except Exception:
        exception('Unit-test', sys.exc_info())



# Generated at 2022-06-24 05:51:16.089974
# Unit test for function confirm_text
def test_confirm_text():
    """Test function confirm_text"""
    import mock
    import sys
    confirm_text(mock.Mock(script="ls"))
    assert sys.stderr.getvalue() == ('>ls [enter/↑/↓/ctrl+c]')



# Generated at 2022-06-24 05:51:26.660429
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from .conf import Config
    from .const import DEFAULT_SETTINGS
    from .main import get_config
    from .main import get_settings
    captured_output = StringIO()
    config = Config(DEFAULT_SETTINGS, {},
                    {'alias': 'fuck', 'require_confirmation': True,
                     'no_colors': True})
    config.to_file()
    try:
        sys.stderr = captured_output
        settings = get_settings(get_config('thefuck/tests/', ''))
        failed('Test failed func')
        assert(captured_output.getvalue() == 'Test failed func\n')
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:51:28.273287
# Unit test for function version
def test_version():
    version('3.12', '3.4.8', 'ShellNotSpecified')



# Generated at 2022-06-24 05:51:33.593263
# Unit test for function failed
def test_failed():
    class Stream:
        def __init__(self):
            self._messages = []

        def write(self, message):
            self._messages.append(message)

        def reset(self):
            self._messages = []

    sys.stderr = Stream()
    failed(u"Something went wrong")

    assert sys.stderr._messages[0].startswith(color(colorama.Fore.RED))
    assert sys.stderr._messages[0].endswith(u'{reset}\n'.format(
        reset=color(colorama.Style.RESET_ALL)))
    assert sys.stderr._messages[0].count(u'Something went wrong') == 1

# Generated at 2022-06-24 05:51:43.683827
# Unit test for function configured_successfully
def test_configured_successfully():
    from .utils import resolve_command
    import tempfile
    import os
    from .conf import load_configuration, get_configuration_details
    from .shells import Shell
    from .utils import get_git_repo_path

    try:
        HOME = os.environ['HOME']
    except KeyError:
        HOME = tempfile.mkdtemp()
        os.environ['HOME'] = HOME

    load_configuration(resolve_command('bash'), get_git_repo_path())
    try:
        shell = Shell.from_shell(resolve_command('bash'),
                                 get_configuration_details())
        configured_successfully(shell.configuration_details)
        assert 1
    finally:
        if HOME == tempfile.gettempdir():
            os.remove(HOME)


# Unit test

# Generated at 2022-06-24 05:51:47.126801
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == '' \
           if settings.no_colors else colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT

# Generated at 2022-06-24 05:51:52.272158
# Unit test for function version
def test_version():
    import io
    import sys
    import version
    import colorama
    colorama.init(atrr=['bold'])
    stdout = sys.stderr
    sys.stderr = io.StringIO()
    version('thefuck', 'python', 'shell')
    assert sys.stderr.read() == u'The Fuck 3.11 using Python 3.5 and shell\n'
    sys.stderr = stdout

# Generated at 2022-06-24 05:51:58.248177
# Unit test for function debug_time
def test_debug_time():
    import datetime
    from contextlib import contextmanager
    import time

    @contextmanager
    def test_context():
        started = datetime.datetime.now()
        try:
            yield
        finally:
            assert datetime.datetime.now() - started >= datetime.timedelta(seconds=0.5)

    with test_context():
        time.sleep(0.6)

# Generated at 2022-06-24 05:52:00.116903
# Unit test for function color
def test_color():
    assert color(u'test') == u'test'

    settings.no_colors = True

    assert color(u'test') == u''

# Generated at 2022-06-24 05:52:04.085458
# Unit test for function version
def test_version():
    from . import get_version
    from . import get_shell_info

    python_version = '.'.join(map(str, sys.version_info[:3]))

    assert version(get_version(), python_version,
                   get_shell_info(None)) == None



# Generated at 2022-06-24 05:52:06.010346
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully("You are good to go") == "You are good to go"

# Generated at 2022-06-24 05:52:08.725042
# Unit test for function warn
def test_warn():
    import StringIO
    original_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    warn('a')
    assert sys.stderr.getvalue().startswith('[WARN] a')



# Generated at 2022-06-24 05:52:10.371298
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'git lol'
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:52:17.316384
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    sys.stderr.write('\x1b[1K')
    sys.stderr.write('\r')
    how_to_configure_alias(color(colorama.Style.RESET_ALL))
    sys.stderr.write('\x1b[1K')
    sys.stderr.write('\r')
    how_to_configure_alias(color(colorama.Fore.BLUE))
    sys.stderr.write('\x1b[1K')
    sys.stderr.write('\r')
    how_to_configure_alias(color(colorama.Style.BRIGHT))
    sys.stderr.write('\x1b[1K')

# Generated at 2022-06-24 05:52:18.688505
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-24 05:52:25.169526
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import fuck_name
    confirm_text(
        corrected_command.CorrectedCommand(
            'git push', 'git push', False))
    assert const.USER_COMMAND_MARK == \
        sys.stderr.getvalue().split(' ')[0]

    confirm_text(
        corrected_command.CorrectedCommand(
            'git push', 'git push', True))
    assert sys.stderr.getvalue().split(' ')[2] == \
        'git push' \
        ' (+side effect)' \
        ' [enter/↑/↓/ctrl+c]'

    confirm_text(
        corrected_command.CorrectedCommand(
            'git push', 'git push', False))

# Generated at 2022-06-24 05:52:34.565680
# Unit test for function confirm_text
def test_confirm_text():
    def confirm_text_test():
        import sys
        import StringIO
        saved_stdout = sys.stdout
        use_string = True
        if use_string:
            sys.stdout = StringIO.StringIO()
        confirm_text(const.CorrectedCommand(script='ls -la', side_effect=True))
        result = sys.stdout.getvalue()
        if use_string:
            sys.stdout.close() # close the stream
        sys.stdout = saved_stdout
        return result

    result = confirm_text_test()

# Generated at 2022-06-24 05:52:35.253774
# Unit test for function version
def test_version():
    pass



# Generated at 2022-06-24 05:52:37.233717
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:52:43.096622
# Unit test for function debug
def test_debug():
    import mock
    import sys

    with mock.patch('sys.stderr') as stderr:
        debug('test')

    stderr.write.assert_called_once_with(u'{blue}{bold}DEBUG:{reset} test\n'.format(
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE),
        bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-24 05:52:44.159598
# Unit test for function debug
def test_debug():
    sys.stderr = sys.stdout
    debug('msg')
    assert sys.stdout.mock_calls != []