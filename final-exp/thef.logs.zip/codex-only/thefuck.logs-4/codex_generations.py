

# Generated at 2022-06-24 05:42:41.255473
# Unit test for function warn
def test_warn():
    sys.stderr = open('warn_test.txt', 'w')
    warn('warn')
    with open('warn_test.txt', 'r') as f:
        assert f.read() == u'[WARN] warn'



# Generated at 2022-06-24 05:42:44.523493
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED + colorama.Style.BRIGHT + 'test') == 'test'
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Style.BRIGHT + 'test') == ''

# Generated at 2022-06-24 05:42:49.048816
# Unit test for function already_configured
def test_already_configured():
    return already_configured({
        'reload': 'source ~/.bash_profile'
    }) == u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}source ~/.bash_profile{reset} or restart your shell.\n".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:42:49.899827
# Unit test for function debug
def test_debug():
    debug('This is debug message')

# Generated at 2022-06-24 05:42:52.373400
# Unit test for function configured_successfully
def test_configured_successfully():
    assert "#!/bin/bash" in configured_successfully(configuration_details)


# Generated at 2022-06-24 05:43:02.032089
# Unit test for function exception
def test_exception():
    class FakeStderr(object):
        def __init__(self, *args, **kwargs):
            pass

        def write(self, text):
            self.text = text

    stderr = FakeStderr()
    sys.stderr = stderr

    exception('Title', ('type', 'value', 'traceback'))

    assert stderr.text == u'{warn}[WARN] Title:{reset}\n{trace}' \
                          '{warn}----------------------------{reset}\n\n'.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        trace='')

# Generated at 2022-06-24 05:43:06.952772
# Unit test for function debug
def test_debug():
    saved = sys.stderr
    try:
        from StringIO import StringIO
        sys.stderr = StringIO()
        debug('message')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n'
    finally:
        sys.stderr = saved

# Generated at 2022-06-24 05:43:14.880810
# Unit test for function warn
def test_warn():
    from .rules.man import ManRule
    from .types import CorrectedCommand
    from .shells import Shell

    rule = ManRule()
    exc_info = (type('exception', (Exception,), {}),
                type('exception', (Exception,), {})('test'),
                None)
    warn('test')
    exception('test', exc_info)
    rule_failed(rule, exc_info)
    failed('test')
    show_corrected_command(
        CorrectedCommand('ls -la', 'ls -al', 'ls -la', Shell()))
    confirm_text(
        CorrectedCommand('ls -la', 'ls -al', 'ls -la', Shell()))
    debug('test')
    how_to_configure_alias(None)
    already_configured(None)
    configured_successfully

# Generated at 2022-06-24 05:43:16.094239
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('corrected_command')

# Generated at 2022-06-24 05:43:25.167233
# Unit test for function version
def test_version():
    from six.moves import cStringIO
    from thefuck.shells import Bash
    from thefuck import __version__ as thefuck_version
    from sys import version_info as python_version
    import __main__
    import thefuck.utils
    __main__.__dict__.update({'__name__': '__main__'})
    thefuck.utils.__name__ = 'thefuck.utils'
    shell = Bash()
    sys.stderr = cStringIO()
    version(thefuck_version, 'Python {}.{}.{}'.format(
            python_version.major, python_version.minor, python_version.micro),
            shell.get_version())

# Generated at 2022-06-24 05:43:28.267520
# Unit test for function color
def test_color():
    assert '\033[0;92m' == color(colorama.Fore.GREEN)
    color._no_colors = True
    assert '' == color(colorama.Fore.GREEN)



# Generated at 2022-06-24 05:43:30.016045
# Unit test for function color
def test_color():
    assert color('hi') == 'hi'
    settings.no_colors = True
    assert color('hi') == ''

# Generated at 2022-06-24 05:43:32.972735
# Unit test for function color
def test_color():
    class accept_unicode(str):
        pass

    assert color('foo') == 'foo'
    assert color(accept_unicode('foo')) == accept_unicode('foo')


# Unit tests for function debug

# Generated at 2022-06-24 05:43:35.611331
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import const

    mock = const(
        RELOAD='reload',
        ALREADY_CONFIGURED='already configured',
        CONFIGURE_AUTOMATICALLY='configure automatically')
    configured_successfully(mock)

# Generated at 2022-06-24 05:43:40.365499
# Unit test for function warn
def test_warn():
    sys.stdout.seek(0)
    warn('test warn')
    assert sys.stdout.read() == '\x1b[41m\x1b[37m\x1b[1m[WARN] test warn\x1b[0m\n'



# Generated at 2022-06-24 05:43:46.278832
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    import time

    with debug_time("Test"):
        time.sleep(0.1)

    before = datetime.now()
    with debug_time("Test2"):
        pass
    after = datetime.now()
    delta = after - before

    assert delta.total_seconds() < 0.1 and delta.total_seconds() > 0.09

# Generated at 2022-06-24 05:43:47.595977
# Unit test for function warn
def test_warn():
    warn('test-title')



# Generated at 2022-06-24 05:43:53.914812
# Unit test for function debug
def test_debug():
    import sys
    import mock
    with mock.patch('sys.stderr', new_callable=mock.PropertyMock) as mock_stderr:
        debug('whatever')
        mock_stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} whatever\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))



# Generated at 2022-06-24 05:44:02.996913
# Unit test for function exception

# Generated at 2022-06-24 05:44:04.185518
# Unit test for function debug_time
def test_debug_time():
    def f():
        pass

    with debug_time('fuck'):
        f()

# Generated at 2022-06-24 05:44:04.779729
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('test')
    confirm_text('test')



# Generated at 2022-06-24 05:44:09.352831
# Unit test for function how_to_configure_alias

# Generated at 2022-06-24 05:44:14.351740
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import ConfigurationDetails

    assert how_to_configure_alias(ConfigurationDetails(
        'alias fuck=\'eval $(thefuck $(fc -ln -1)); history -r\'',
        '/home/nvbn/.zshrc', 'exec zsh',
        '~/.zshrc_with_fuck', ['fc', 'history'])) == None


# Generated at 2022-06-24 05:44:18.914597
# Unit test for function version
def test_version():
    thefuck_version = '2.2' 
    python_version = '3.5.2'
    shell_info = 'Zsh 5.2'
    sys.stderr.write('The Fuck {} using Python {} and {}\n'.format(thefuck_version, python_version,
                                                                   shell_info))

# Generated at 2022-06-24 05:44:20.053495
# Unit test for function debug_time
def test_debug_time():
    debug_time("debug_time")

# Generated at 2022-06-24 05:44:21.437112
# Unit test for function failed
def test_failed():
    assert failed("Text") == sys.stderr.write("Text\n")

# Generated at 2022-06-24 05:44:22.274116
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('already')

# Generated at 2022-06-24 05:44:23.767433
# Unit test for function exception
def test_exception():
    exception(u'Some error', [None, NameError("Unknown variable 'smth'"), None])

# Generated at 2022-06-24 05:44:24.576960
# Unit test for function debug
def test_debug():
    assert debug("msg") == None

# Generated at 2022-06-24 05:44:30.299303
# Unit test for function debug
def test_debug():
    import sys
    import StringIO

    buffer = StringIO.StringIO()

    def warn(*args):
        print >>buffer, ' '.join(map(unicode, args))

    old_stderr = sys.stderr
    sys.stderr = buffer

    try:
        debug(u'привет')
        assert u"DEBUG: привет" in buffer.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-24 05:44:34.989361
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'msg')
        assert stderr.write.called
        stderr.write.assert_called_with(
            color(colorama.Fore.BLUE + colorama.Style.BRIGHT) +
            u'DEBUG:' +
            color(colorama.Style.RESET_ALL) +
            u' ' +
            u'msg\n')



# Generated at 2022-06-24 05:44:42.037770
# Unit test for function configured_successfully
def test_configured_successfully():
    from .version import __version__
    from . import shell
    from . import python_version
    from .conf import ConfigurationDetails

    configuration_details = ConfigurationDetails(
        reload='reload',
        file='file',
        content='content')

    return_code = 0

    def assert_equals(actual, expected):
        global return_code
        if actual != expected:
            return_code = 1
            sys.stderr.write('{} != {}'.format(repr(actual), repr(expected)))

    def tested_output():
        output = []
        with open('/tmp/test_log', 'a') as f:
            sys.stderr = f
            configured_successfully(configuration_details)
            with open('/tmp/test_log') as f:
                output = f.readlines()
       

# Generated at 2022-06-24 05:44:43.391372
# Unit test for function failed
def test_failed():
    failed('msg')

# Generated at 2022-06-24 05:44:50.312940
# Unit test for function configured_successfully
def test_configured_successfully():
    from . import which

    def which_mock(cmd, path=None):
        return which.which('/bin/env')

    which.which = which_mock
    assert """export TF_SHELL_ALIAS=fuck
alias fuck="eval \$(thefuck --alias)"
source ~/.bashrc""" == configured_successfully(
        'The Fuck {} using Python {} and {}\n'.format(thefuck_version,
                                                      python_version,
                                                      shell_info))



# Generated at 2022-06-24 05:44:55.202974
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .utils import MemoryLogger

    logger = MemoryLogger()
    settings.debug = True
    with debug_time(u'hello'):
        logger.write = lambda msg: ''.join(msg)
        try:
            1/0
        except:
            pass
    settings.debug = False
    assert 'hello took' in logger.content

# Generated at 2022-06-24 05:44:57.143541
# Unit test for function exception
def test_exception():
    exc_info = sys.exc_info()
    exception(u'Rule {}'.format(u'test rule'), exc_info)

# Generated at 2022-06-24 05:45:00.334998
# Unit test for function version
def test_version():
    sys.stderr.write(u'The Fuck {} using Python {} and {}\n'.
                     format('0.0.1', '2.7.9', 'zsh'))

# Generated at 2022-06-24 05:45:06.304297
# Unit test for function confirm_text
def test_confirm_text():
    script = 'remove-pyc'
    corrected_command = corrected_commands.CorrectedCommand(script, side_effect=False)
    assert confirm_text(corrected_command) == \
            const.USER_COMMAND_MARK + 'remove-pyc [enter/↑/↓/ctrl+c]'

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-24 05:45:09.281710
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    settings.no_colors = True
    assert color('colorama.Style.BRIGHT') == ''

# Generated at 2022-06-24 05:45:10.645080
# Unit test for function debug_time
def test_debug_time():
    debug_time('a')
    debug_time('b')

# Generated at 2022-06-24 05:45:13.139315
# Unit test for function failed
def test_failed():
    assert 'Text' in "'Text'\n"
    assert 'Text' in "u'Text'\n"
    assert 'Text' not in "u'Tex'\n"

# Generated at 2022-06-24 05:45:17.786878
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    class CorrectedCommandForTesting(CorrectedCommand):

        @property
        def side_effect(self):
            return super(CorrectedCommandForTesting, self).side_effect

    corrected_command = CorrectedCommandForTesting('ls', 'cd', 'ls')
    corrected_command.side_effect = True
    assert show_corrected_command(corrected_command) == '\n'

# Generated at 2022-06-24 05:45:18.676700
# Unit test for function warn
def test_warn():
    warn('Title')


# Generated at 2022-06-24 05:45:29.543962
# Unit test for function already_configured
def test_already_configured():
    """
    Test if the configuration details are printed correctly and
    the text is similar to the text in the README file.
    """
    fake_configuration_details = type(
        'FakeConfigurationDetails',
        ('Reload',),
        {'reload': 'source ~/.bashrc'})
    expected = u'Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell.'

    lines = []

    def append_to_lines(line):
        lines.append(line)

    builtins.print = append_to_lines

    try:
        already_configured(fake_configuration_details())
        assert ' '.join(lines) == expected
    finally:
        builtins.print = print

# Generated at 2022-06-24 05:45:34.174594
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    try:
        with debug_time("test"):
            pass
    finally:
        assert 'test took: {}'.format(datetime.now() - started) == debug('test took: {}'.format(datetime.now() - started))


# Unit tests for function confirm_text

# Generated at 2022-06-24 05:45:36.052424
# Unit test for function failed
def test_failed():
    assert failed(u'Кривая башка!') == None  # noqa



# Generated at 2022-06-24 05:45:39.314991
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(u'fish') == u'Seems like fuck alias already configured!\nFor applying changes run fish_reload or restart your shell.'


# Generated at 2022-06-24 05:45:40.851020
# Unit test for function confirm_text
def test_confirm_text():
    TEXT = "fuck"
    assert confirm_text(TEXT) == ""

# Generated at 2022-06-24 05:45:41.898920
# Unit test for function debug_time
def test_debug_time():
    import time
    debug_time("time.sleep")

# Generated at 2022-06-24 05:45:45.565785
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias({
               'bold': '\x1b[1m',
               'reset': '\x1b[0m'})
test_how_to_configure_alias()



# Generated at 2022-06-24 05:45:48.516554
# Unit test for function warn
def test_warn():
    warn("title")
    assert '\x1b[30m\x1b[41m\x1b[1m[WARN] title\x1b[0m\n'



# Generated at 2022-06-24 05:45:50.456870
# Unit test for function rule_failed
def test_rule_failed():
    exc_info = (None, None, None)
    rule = 'mock'
    rule_failed(rule, exc_info)

# Generated at 2022-06-24 05:45:52.854782
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells.utils import CorrectedCommand
    show_corrected_command(CorrectedCommand('script', False))



# Generated at 2022-06-24 05:46:04.107268
# Unit test for function rule_failed
def test_rule_failed():
    class my_rule(object):
        def name(self):
            return 'my_rule'
    import sys
    import io

    newStderr = io.StringIO()
    sys.stderr = newStderr

    rule_failed(my_rule(), sys.exc_info())

# Generated at 2022-06-24 05:46:05.180248
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-24 05:46:06.729306
# Unit test for function version

# Generated at 2022-06-24 05:46:13.039941
# Unit test for function configured_successfully
def test_configured_successfully():
    config = object()
    config.reload = u'Reload'
    assert configured_successfully(config) == \
        u'{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}Reload{reset} or restart your shell.'.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:46:14.989797
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('test'):
        time.sleep(0.1)


# Generated at 2022-06-24 05:46:17.958393
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.git import get_new_command
    rule = get_new_command
    exc_info = ' this is an exception'

    rule_failed(rule, exc_info)

# Generated at 2022-06-24 05:46:22.152361
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules.git_push import match, get_new_command
    command = 'git push'
    command = match(command)
    command = 'git push -u'
    corrected_command = get_new_command(command)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:46:29.114057
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfDetails(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    for configuration_details in [None,
                                  ConfDetails(path='path',
                                              content='content',
                                              reload='reload',
                                              can_configure_automatically=True),
                                  ConfDetails(path='path',
                                              content='content',
                                              reload='reload',
                                              can_configure_automatically=False)]:
        how_to_configure_alias(configuration_details)
        assert(True)


# Generated at 2022-06-24 05:46:38.519276
# Unit test for function debug
def test_debug():
    import sys
    debug_buffer = sys.stderr
    try:
        from cStringIO import StringIO
        sys.stderr = StringIO()
        settings.debug = True
        debug(u'Test debug message')
        assert sys.stderr.getvalue() == u'{blue}{bold}DEBUG:{reset} Test debug message\n'.format(
            reset=u'', blue=u'', bold='')

        settings.no_colors = True
        sys.stderr = StringIO()
        debug(u'Test debug message')
        assert sys.stderr.getvalue() == u'DEBUG: Test debug message\n'
    finally:
        sys.stderr = debug_buffer
        settings.debug = False
        settings.no_colors = False



# Generated at 2022-06-24 05:46:40.258675
# Unit test for function debug_time
def test_debug_time():
    def func1():
        pass
    debug_time(func1())

# Generated at 2022-06-24 05:46:44.611355
# Unit test for function failed
def test_failed():
    from mock import Mock
    logger = Mock()

    sys.stderr = Mock()
    failed('test failed')
    sys.stderr.write.assert_any_call('\x1b[31mtest failed\x1b[0m\n')

    sys.stderr = logger


# Generated at 2022-06-24 05:46:51.298627
# Unit test for function confirm_text
def test_confirm_text():
    from tests.utils import Mock
    sys.stderr = Mock()
    from thefuck.shells import Bash
    from thefuck.main import Command

    corrected_command = Command('git commit', 'git commit -v', False)
    shell = Bash()
    confirm_text(corrected_command)

    assert len(sys.stderr.write.calls) == 1
    assert u'\r\x1b[1K\x1b[0m\x1b[0m' in sys.stderr.write.calls[0][0][0]
    assert shell.style.from_shell(corrected_command.script) in sys.stderr.write.calls[0][0][0]

# Generated at 2022-06-24 05:46:56.757258
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('source ~/.bashrc\n') == u"Seems like {}fuck{} alias already configured!\nFor applying changes run {}source ~/.bashrc{}\nor restart your shell.".format(color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL), color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL))


# Generated at 2022-06-24 05:46:59.618942
# Unit test for function how_to_configure_alias

# Generated at 2022-06-24 05:47:06.585349
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.python import get_new_command
    from .rules.bash import match
    from .main import fuck
    import pytest
    from thefuck.rules.base import Rule

    class TestRule(Rule):
        def match(self, **kwargs):
            print('match')
            return bool(kwargs.get('script').endswith(u'pytest'))

        def get_new_command(self, **kwargs):
            print('get_new_command')
            return '{} --color=yes'.format(kwargs.get('script'))

    test_rule = TestRule()

    with pytest.raises(Exception) as exc_info:
        test_rule.get_new_command
    rule_failed(test_rule, exc_info)
    print("rule failed test passed")

# Generated at 2022-06-24 05:47:10.298967
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    configuration_details = Shell('sh').get_configuration_details()
    configuration_details._replace(reload='reload')
    assert configured_successfully(configuration_details) == None

# Generated at 2022-06-24 05:47:20.085426
# Unit test for function exception
def test_exception():
    class FakeStream(object):
        def __init__(self):
            self.calls = []

        def write(self, text):
            self.calls.append(text)

    sys.stderr = FakeStream()
    try:
        1 / 0
    except ZeroDivisionError:
        exception(u'test', sys.exc_info())
    sys.stderr = sys.__stderr__
    formatted_exc = ''.join(format_exception(sys.exc_info()[0],
                                             sys.exc_info()[1],
                                             sys.exc_info()[2]))
    assert 'test' in sys.stderr.calls[0]
    assert u'[WARN] test' in sys.stderr.calls[0]

# Generated at 2022-06-24 05:47:24.407707
# Unit test for function version
def test_version():
    version(thefuck_version='the version',
            python_version='2.7.10',
            shell_info=u'ShellInfo') == \
        u'The Fuck the version using Python 2.7.10 and ShellInfo\n'



# Generated at 2022-06-24 05:47:26.912813
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.runner import ConfigurationDetails
    details = ConfigurationDetails(u'content', u'path', u'reload')
    how_to_configure_alias(details)



# Generated at 2022-06-24 05:47:29.517108
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text(None) == None)


# Generated at 2022-06-24 05:47:32.950752
# Unit test for function warn
def test_warn():
    from io import StringIO
    from . import utils
    f = StringIO()
    with utils.mock.patch.object(sys.stderr, 'write') as mock_write:
        mock_write.side_effect = f.write
        warn('test')
    assert f.getvalue() == ('\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n')



# Generated at 2022-06-24 05:47:34.434702
# Unit test for function rule_failed
def test_rule_failed():
    exception_class, exception_instance, traceback = sys.exc_info()
    rule_failed('rule', [exception_instance, exception_class, traceback])



# Generated at 2022-06-24 05:47:39.354417
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = (
        const.ConfigurationDetails(
            can_configure_automatically=False,
            reload='source ~/.zshrc',
            path='~/.zshrc',
            content='eval $(thefuck --alias)'))
    from StringIO import StringIO

    content = StringIO()
    configuration_details = (
        const.ConfigurationDetails(
            can_configure_automatically=False,
            reload='source ~/.zshrc',
            path='~/.zshrc',
            content='eval $(thefuck --alias)'))

    stdout = sys.stdout
    sys.stdout = content
    how_to_configure_alias(configuration_details)
    sys.stdout = stdout

# Generated at 2022-06-24 05:47:42.636613
# Unit test for function version
def test_version():
    assert const.VERSION == '3.0.0'
    assert sys.version.startswith("2.7")
    assert sys.platform == 'linux2'

# Generated at 2022-06-24 05:47:45.876232
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .utils import wrap_result
    corrected_command = Command('git status', 'git commit', '', '', 'cd')

# Generated at 2022-06-24 05:47:46.665861
# Unit test for function already_configured
def test_already_configured():
    already_configured("source ~/.bashrc")


# Generated at 2022-06-24 05:47:56.568831
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command, CorrectedCommand

    corrected_command = CorrectedCommand(
        Command('echo lol'),
        'echo lol',
        side_effect=True)
    assert (show_corrected_command(corrected_command) ==
            '\x1b[93m$ echo lol\x1b[0m (+side effect)\n')

    corrected_command = CorrectedCommand(
        Command('echo lol'),
        'echo lol'
        )
    assert (show_corrected_command(corrected_command) ==
            '\x1b[93m$ echo lol\x1b[0m\n')

# Generated at 2022-06-24 05:47:58.018737
# Unit test for function warn
def test_warn():
    assert warn(u'Test') == u'[WARN] Test\n'



# Generated at 2022-06-24 05:47:59.499762
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details="test")



# Generated at 2022-06-24 05:48:08.177448
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("w") == u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(prefix=const.USER_COMMAND_MARK, script="w", side_effect='', clear='\033[1K\r', bold=color(colorama.Style.BRIGHT), green=color(colorama.Fore.GREEN), red=color(colorama.Fore.RED), reset=color(colorama.Style.RESET_ALL), blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-24 05:48:11.579794
# Unit test for function version
def test_version():
    import sys
    sys.argv = ['thefuck']
    from thefuck.main import main
    assert not main()[0]

# Generated at 2022-06-24 05:48:17.516953
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    buffer = StringIO.StringIO()
    sys.stderr = buffer
    corrected_command = "Corrected command"
    show_corrected_command(corrected_command)
    sys.stderr.seek(0)
    output = sys.stderr.read()
    output = output.strip()
    assert output == 'Fuck ' + corrected_command

# Generated at 2022-06-24 05:48:19.033230
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-24 05:48:21.495390
# Unit test for function debug
def test_debug():
    from .conf import settings
    from . import main

    settings.debug = True
    main._create_logger()

    debug(u'Test debug')

# Generated at 2022-06-24 05:48:22.997209
# Unit test for function version
def test_version():
    assert version('3.0', '3.4', 'sh') == 'The Fuck 3.0 using Python 3.4 and sh\n'


# Generated at 2022-06-24 05:48:26.762511
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    sys.stderr = StringIO()
    command = 'git commit'
    confirm_text(command)
    assert 'git commit' in sys.stderr.getvalue()

# Generated at 2022-06-24 05:48:28.716304
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test time'):
        pass

# Generated at 2022-06-24 05:48:29.745428
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(const.ConfigurationDetails('_'))

# Generated at 2022-06-24 05:48:37.827671
# Unit test for function debug_time
def test_debug_time():
    from .conf import settings
    from . import shell

    settings.debug = True

    # Prepare mocks
    from mock import Mock
    class Time(object):
        def __init__(self):
            self.now = Mock(wraps=datetime.now)
        def __sub__(self, other):
            return u'diff'
        def debug(self, msg):
            assert msg == u'Something took: diff'
    time = Time()
    datetime.now = Mock(return_value=time)
    shell.debug = time.debug

    # Perform actual tests
    with debug_time('Something'):
        pass

# Generated at 2022-06-24 05:48:39.452944
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:48:42.679748
# Unit test for function already_configured
def test_already_configured():
    configuration_details = {
        'path': '~/a.txt',
        'reload': '. ~/.bashrc',
        'can_configure_automatically': False
    }
    already_configured(configuration_details)


# Generated at 2022-06-24 05:48:45.407692
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN

    settings.no_colors = True
    assert color(colorama.Fore.GREEN) == ''

# Generated at 2022-06-24 05:48:51.774592
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    expected_output_no_details = u"Seems like {bold}fuck{reset} alias isn't configured!\n"\
        u"More details - https://github.com/nvbn/thefuck#manual-installation".format(
            bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))
    assert how_to_configure_alias(None) == expected_output_no_details

# Generated at 2022-06-24 05:49:03.357228
# Unit test for function confirm_text
def test_confirm_text():
    import os, tempfile
    with tempfile.TemporaryFile() as temp:
        sys.stderr = temp
        confirm_text(os.getcwd())
        temp.seek(0)

# Generated at 2022-06-24 05:49:07.931429
# Unit test for function failed
def test_failed():
    sys.stdout = buffer = sys.__stdout__
    failed('failed')
    assert buffer.getvalue().startswith(u'\x1b[31m')
    assert buffer.getvalue().endswith(u'\x1b[0m\n')
    assert buffer.getvalue().find('failed') > 0


# Generated at 2022-06-24 05:49:15.578163
# Unit test for function failed
def test_failed():
    from tempfile import NamedTemporaryFile
    from .utils import get_closest, get_closest_dict

    with NamedTemporaryFile() as temp:
        sys.stderr = temp
        failed('fuck')
        sys.stderr = sys.__stderr__

        temp.seek(0)
        assert get_closest_dict(temp.read(), {'msg': 'fuck'})
        temp.close()


# Generated at 2022-06-24 05:49:20.899133
# Unit test for function warn
def test_warn():
    title = 'Title'
    sys.stderr.write(u'{warn}[WARN] {title}{reset}\n'.format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title=title))



# Generated at 2022-06-24 05:49:21.953485
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:49:31.102569
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from thefuck import conf
    from thefuck.types import Command
    from tests.live_tests.utils import colors
    from thefuck.main import USER_COMMAND_MARK

    with conf.override(no_colors=False):
        colors_enabled = colors(USER_COMMAND_MARK, '')
    with conf.override(no_colors=True):
        colors_disabled = colors(USER_COMMAND_MARK, '')

    confirm_text(Command('ls', 'ls'))
    assert sys.stderr.getvalue() == colors_enabled('$ ls [enter/↑/↓/ctrl+c]')

    confirm_text(Command('ls', 'ls', side_effect=True))

# Generated at 2022-06-24 05:49:32.655257
# Unit test for function warn
def test_warn():
    warn(u'Hello')



# Generated at 2022-06-24 05:49:34.905977
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    debug('Start')
    with debug_time('Debug'):
        sleep(2)
    debug('Stop')

# Generated at 2022-06-24 05:49:36.486124
# Unit test for function version
def test_version():
    version(1, 2, 3)



# Generated at 2022-06-24 05:49:44.323445
# Unit test for function debug
def test_debug():
    import io
    import sys

    settings.debug = False
    with io.StringIO() as out:
        sys.stderr = out
        debug('debug(msg) 1')
        sys.stderr = sys.__stderr__
        assert out.getvalue() == ''

    settings.debug = True
    with io.StringIO() as out:
        sys.stderr = out
        debug('debug(msg) 2')
        sys.stderr = sys.__stderr__
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0;0m debug(msg) 2\n'



# Generated at 2022-06-24 05:49:48.175525
# Unit test for function version
def test_version():
    thefuck_version = 1.1
    python_version = '2.7'
    shell_info = 'BASH'
    version(thefuck_version, python_version, shell_info)


# Generated at 2022-06-24 05:49:54.235401
# Unit test for function already_configured
def test_already_configured():
    msg = u"Seems like {}fuck{} alias already configured!\n" \
        u"For applying changes run {}reload{} " \
        u"or restart your shell.".format(color(colorama.Style.BRIGHT),
                                        color(colorama.Style.RESET_ALL),
                                        color(colorama.Style.BRIGHT),
                                        color(colorama.Style.RESET_ALL))
    assert already_configured(color(colorama.Style.BRIGHT), "reload") == msg

# Generated at 2022-06-24 05:49:59.406014
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    config_details = Shell.from_shell('bash').get_config_generator()
    if config_details.reload == None:
        return

    config_details.reload = 'bash'
    configured_successfully(config_details)

# Generated at 2022-06-24 05:50:03.829044
# Unit test for function exception
def test_exception():
    assert exception('Title', ('\xe5\x85\x83\xe5\x86\x8c\xe4\xbc\xa0\xe8\xbe\x93', None, None)) is None
    assert exception('', ('\xe5\x85\x83\xe5\x86\x8c\xe4\xbc\xa0\xe8\xbe\x93', None, None)) is None
    assert exception('', (None, None, None)) is None

# Generated at 2022-06-24 05:50:07.777846
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    c = Command('correct', 'ls -al')
    show_corrected_command(c)

    c.side_effect = True
    show_corrected_command(c)

# Generated at 2022-06-24 05:50:13.857900
# Unit test for function version
def test_version():
    _thefuck_version = '3.3'
    _python_version = '3.4.3'
    _shell_info = 'shell'
    assert u'The Fuck 3.3 using Python 3.4.3 and shell\n' == version(_thefuck_version, _python_version, _shell_info)



# Generated at 2022-06-24 05:50:20.129515
# Unit test for function warn
def test_warn():
    title = 'test_warn'
    reset_color = colorama.Style.RESET_ALL
    warn_color = colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT
    assert warn(title) == '[WARN] test_warn\n'
    colorama.init(autoreset=True)
    assert warn(title) == (
        '{color}[WARN] test_warn{reset_color}\n'.format(
            color=warn_color, reset_color=reset_color))
    colorama.deinit()



# Generated at 2022-06-24 05:50:30.455581
# Unit test for function rule_failed
def test_rule_failed():
    import mock
    mock_rule = mock.Mock()
    mock_rule.name = 'mock_rule'
    mock_exception_info = ('mock_exception', 'mock_exception', 'mock_exception')

    rule_failed(mock_rule, mock_exception_info)

    sys.stderr.write.assert_called_with(u'\x1b[41m\x1b[37m\x1b[1m[WARN]'
                                        u' Rule mock_rule:\x1b[0m\nmock_exception'
                                        u'\x1b[41m\x1b[37m\x1b[1m-------------'
                                        '----------------------------\x1b[0m\n\n')



# Generated at 2022-06-24 05:50:31.556367
# Unit test for function warn
def test_warn():
    warn(u'warning!')


# Generated at 2022-06-24 05:50:36.977166
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(
        ConfigurationDetails(
            path='.bashrc',
            old_content='.bar',
            new_content='.foo',
            can_configure_automatically=False,
            reload='. ~/.bashrc')) == (
            u"Seems like fuck alias already configured!\nFor "
            u"applying changes run . ~/.bashrc or restart your shell.")



# Generated at 2022-06-24 05:50:39.454912
# Unit test for function warn
def test_warn():
    assert warn('some_text') == '\x1b[41;1;97m[WARN] some_text\x1b[0m\n'



# Generated at 2022-06-24 05:50:40.609441
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:50:45.735062
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    configured_successfully(configuration_details=None)
    output = sys.stdout.getvalue()
    sys.stdout = stdout
    assert output == u"\x1b[1mfuck\x1b[22m alias configured successfully!\n" \
                      u"For applying changes run \x1b[1m\x1b[22m or restart your shell.\n"

if __name__ == '__main__':
    test_configured_successfully()

# Generated at 2022-06-24 05:50:57.398341
# Unit test for function version

# Generated at 2022-06-24 05:50:59.805867
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Sho:
        script = "ls -la"
        side_effect = False
    show_corrected_command(Sho())
    assert True

# Generated at 2022-06-24 05:51:03.432827
# Unit test for function rule_failed
def test_rule_failed():
    # rule, exc_info
    rule = lambda x: True
    rule.name = 'test'
    exc_info = [Exception, Exception('Test'), Exception]
    rule_failed(rule, exc_info)


# Generated at 2022-06-24 05:51:14.354402
# Unit test for function already_configured

# Generated at 2022-06-24 05:51:18.558238
# Unit test for function rule_failed
def test_rule_failed():
    try:
        raise ValueError()
    except ValueError:
        exc_info = sys.exc_info()
    class DummyRule(object):
        name = 'dummy_rule'
    rule_failed(DummyRule(), exc_info)

# Generated at 2022-06-24 05:51:22.807004
# Unit test for function failed
def test_failed():
    from StringIO import StringIO

    f = StringIO()
    sys.stderr = f
    failed('error')
    sys.stderr = sys.__stderr__
    assert u'\x1b[31merror\x1b[0m\n' == f.getvalue()

# Generated at 2022-06-24 05:51:25.407032
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'foo')
    except Exception:
        exception(u'test', sys.exc_info())

# Generated at 2022-06-24 05:51:26.829510
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('configuration_details') != None


# Generated at 2022-06-24 05:51:31.609550
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command

    corrected_command = Command('/bin/ls', 'ls')
    show_corrected_command(corrected_command)
    assert Shell.from_shell(None).get_history()[0] == 'fuck ls'

    corrected_command = Command('/bin/ls', 'ls', 'ls')
    show_corrected_command(corrected_command)
    assert Shell.from_shell(None).get_history()[0] == 'ls'

# Generated at 2022-06-24 05:51:42.742848
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from tempfile import NamedTemporaryFile
    from subprocess import Popen, PIPE
    from .utils import get_closest, get_aliases
    import re

    def get_stdout():
        output = p.stdout.read().decode('utf-8')
        return re.sub(r'\s+$', '', output)

    with NamedTemporaryFile() as tf:
        tf.write(b"alias fuck='thefuck'")
        tf.flush()
 
        with open(tf.name, 'r') as f:
            _, _, alias, _ = get_closest(f, 'fuck', get_all=True)[0]

        os.environ['TF_ALIAS'] = alias

# Generated at 2022-06-24 05:51:44.962706
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('test')
    except Exception as e:
        exception(u'Title', sys.exc_info())

# Generated at 2022-06-24 05:51:47.738626
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = type(u'ConfDetails', (object,), {
        'reload': u'reload'})()
    return configured_successfully(configuration_details)

# Generated at 2022-06-24 05:51:52.158128
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from thefuck.utils import get_closing_bracket, replace_argument
    from thefuck.utils import wrap_text, wrap_command

    stream = StringIO()
    failed(u'Test')
    assert stream.getvalue() == u'\x1b[31mTest\x1b[0m\n'

# Generated at 2022-06-24 05:51:58.493191
# Unit test for function failed
def test_failed():
    msg = 'test message'
    expected = u'\x1b[31mtest message\x1b[0m\n'

    from cStringIO import StringIO
    saved_stdout = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        failed(msg)
        assert expected == out.getvalue()
    finally:
        sys.stderr = saved_stdout



# Generated at 2022-06-24 05:51:59.391056
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('vim')


# Generated at 2022-06-24 05:52:04.346872
# Unit test for function version
def test_version():
    from thefuck.utils import get_shell_info
    print('test for version()')
    shell_info = get_shell_info(
        'sh', '/Users/KyeongMin/.zshrc', '/usr/local/bin/zsh')
    version('1.12', '2.7.12', shell_info)

# Generated at 2022-06-24 05:52:10.413463
# Unit test for function debug_time
def test_debug_time():
    import time
    import threading

    settings.debug = True

    # Create a thread to run the function
    def test_target():
        with debug_time('sleep'):
            time.sleep(0.1)  # Sleep 100ms

    # Create the thread
    test_thread = threading.Thread(target=test_target)
    # Start the thread
    test_thread.start()
    # Wait for the thread to finish
    test_thread.join()

# Generated at 2022-06-24 05:52:12.722715
# Unit test for function debug_time
def test_debug_time():
    assert not settings.debug
    with debug_time('cmd'):
        pass

    settings.debug = True
    with debug_time('cmd'):
        pass
    settings.debug = False

# Generated at 2022-06-24 05:52:16.760560
# Unit test for function failed
def test_failed():
    # We need to catch stderr as failed will write to stderr
    # We could also have used a StringIO object as stderr but this is
    # cleaner and leaves stderr unchanged.
    stderr_tmp = sys.stderr
    sys.stderr = open('/dev/null', 'w')
    failed('This is a test')
    sys.stderr.close()
    sys.stderr = stderr_tmp

# Generated at 2022-06-24 05:52:19.302726
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    for configuration_details in [None, 'test_configuration_details']:
        assert how_to_configure_alias(configuration_details)


# Generated at 2022-06-24 05:52:24.389941
# Unit test for function debug
def test_debug():
    from mock import Mock
    sys.stderr = Mock()
    try:
        debug(u'msg')
        sys.stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n')
    finally:
        sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:52:26.935010
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('test')
    except RuntimeError:
        exc_info = sys.exc_info()
    exception('test', exc_info)
    assert True

# Generated at 2022-06-24 05:52:35.820373
# Unit test for function rule_failed
def test_rule_failed():
    import unittest

    class TestRuleFailed(unittest.TestCase):
        def setUp(self):
            self._saved_stderr = sys.stderr
            self._saved_exception = __builtins__.__dict__['Exception']

            class MyException(Exception):
                def __init__(self, msg):
                    self.msg = msg

                def __str__(self):
                    return self.msg

            class MyRule(object):
                def __init__(self, name):
                    self.name = name

            self.my_exception = MyException
            self.my_rule = MyRule


# Generated at 2022-06-24 05:52:38.229636
# Unit test for function version
def test_version():
    version(thefuck_version='1.4',
            python_version='3.4.3', shell_info='zsh-5.1.1')

# Generated at 2022-06-24 05:52:46.815566
# Unit test for function confirm_text
def test_confirm_text():
    from .application import Application
    from .repl import Repl
    from .rule import Rule

    class Command(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    class CorrectedCommand(Command):
        pass

    class Shell(object):
        pass

    class Fuck(Application):
        def __init__(self, rules, shell=None, no_colors=False, debug=False,
                     wait_command=False, require_confirmation=True, alias=None,
                     rules_filename=None, priority=None, history_limit=None,
                     wait_slow_command=None,
                     slow_commands_timeout=None,
                     py3=None):
            self.rules = rules
            self.shell = shell
            self.no