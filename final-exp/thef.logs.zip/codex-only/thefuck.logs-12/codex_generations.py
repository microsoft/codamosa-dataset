

# Generated at 2022-06-24 05:42:44.651201
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.bash import Bash

    class FakeCorrectedCommand(object):
        script = u'whoami'
        side_effect = False

    assert confirm_text(FakeCorrectedCommand()) == \
        u'$whoami [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-24 05:42:47.888331
# Unit test for function failed
def test_failed():
    print >> sys.stderr, 'x'*70
    print >> sys.stderr, 'Test for the function failed'
    print >> sys.stderr, 'x'*70

    failed('Error')
    print >> sys.stderr, 'Test succeeded'

# Generated at 2022-06-24 05:42:50.456841
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    assert show_corrected_command(Command('ls .')) == None
    assert show_corrected_command(Command('ls .', side_effect=True)) == None


# Generated at 2022-06-24 05:42:54.596486
# Unit test for function color
def test_color():
    colorama.init()
    assert color('') == ''
    assert color(colorama.Fore.RED + '1') == '\x1b[31m1'
    assert color(colorama.Fore.RED + '1') == '1'

# Generated at 2022-06-24 05:42:57.534355
# Unit test for function version
def test_version():
    assert u'The Fuck 3.10 using Python 3.4.3 and fish 2.3.0' == version('3.10', '3.4.3','fish 2.3.0')

# Generated at 2022-06-24 05:42:58.602302
# Unit test for function warn
def test_warn():
    warn('Text')


# Generated at 2022-06-24 05:43:02.078387
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output
    failed(u'Some error')
    assert output.getvalue() == (u'\x1b[31mSome error\x1b[0m\n')



# Generated at 2022-06-24 05:43:03.241058
# Unit test for function rule_failed
def test_rule_failed():
    import unittest
    from .rules.python import python_rule
    rule_failed(python_rule, 1)



# Generated at 2022-06-24 05:43:04.556584
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=settings.Configure.details)

# Generated at 2022-06-24 05:43:05.925267
# Unit test for function configured_successfully
def test_configured_successfully():
    """Test for the value of the object configuration_details."""
    configuration_details = u' .bashrc'
    assert configured_successfully(configuration_details) == '.bashrc'

# Generated at 2022-06-24 05:43:13.663427
# Unit test for function already_configured
def test_already_configured():
    from .configurator import ConfigurationDetails
    from .tests.utils import capture_output
    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='eval $(thefuck --alias)',
        reload='exec bash')
    with capture_output() as (stdout, stderr):
        already_configured(configuration_details)
    assert stdout.getvalue() == (
        u'Seems like \x1b[1mfuck\x1b[21m alias already configured!\n'
        u'For applying changes run \x1b[1mexec bash\x1b[21m or restart your shell.' + '\n')
    assert stderr.getvalue() == ''

# Generated at 2022-06-24 05:43:14.855387
# Unit test for function warn
def test_warn():
    warn("Test")


# Generated at 2022-06-24 05:43:16.042573
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(const.ZSH_DETAILS)

# Generated at 2022-06-24 05:43:21.257529
# Unit test for function color

# Generated at 2022-06-24 05:43:22.337333
# Unit test for function configured_successfully
def test_configured_successfully():
    print("Success")

# Generated at 2022-06-24 05:43:23.407080
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(2)

# Generated at 2022-06-24 05:43:26.708420
# Unit test for function version
def test_version():
    assert version('1.1', '2.7.10', 'zsh 4.3.17') == (u'The Fuck 1.1 using Python 2.7.10 and zsh 4.3.17\n')


# Generated at 2022-06-24 05:43:29.215881
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test')
    except Exception:
        return ''.join(format_exception(*sys.exc_info()))



# Generated at 2022-06-24 05:43:32.553853
# Unit test for function color
def test_color():
    assert color('red text') == colorama.Fore.RED + 'red text' + color(colorama.Style.RESET_ALL)
    settings.no_colors = True
    assert color('red text') == 'red text'

# Generated at 2022-06-24 05:43:39.291156
# Unit test for function debug_time
def test_debug_time():
    """
    Calling debug_time function with debug mode on should
    print in stderr something like "DEBUG: <msg> took: <time>".
    """
    # FIXME: not working
    # settings.debug = True
    # try:
    #     with debug_time('msg'):
    #         pass
    # except AssertionError:
    #     pass
    # else:
    #     raise AssertionError('Should not print "took"')
    #
    # with debug_time('msg'):
    #     pass
    #
    # try:
    #     raise AssertionError('Should not raise')
    # except AssertionError:
    #     with debug_time('msg'):
    #         pass
    # else:
    #     raise AssertionError('Should not pass')

# Generated at 2022-06-24 05:43:43.603507
# Unit test for function configured_successfully
def test_configured_successfully():
    class MockConfig:
        def __init__(self):
            self.reload = 'source ~/.bashrc'
    configured_successfully(MockConfig())


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-24 05:43:53.726713
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from datetime import datetime
    settings.no_colors = False
    settings.debug = True
    date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    how_to_configure_alias(None)
    assert sys.stderr.getvalue() == \
        u"{}Seems like {}fuck{} alias isn't configured!\n".format(date, color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL))

    settings.no_colors = True
    how_to_configure_alias(None)
    assert sys.stderr.getvalue() == \
        u"{}Seems like fuck alias isn't configured!\n".format(date)

    from .shells import Shell
    shell_info

# Generated at 2022-06-24 05:43:58.603033
# Unit test for function version
def test_version():
    old_stderr = sys.stderr
    sys.stderr = open("test.txt",'w')
    version("3.20", "2.7.13", "shell")
    sys.stderr.close()
    sys.stderr = old_stderr

test_version()

# Generated at 2022-06-24 05:44:01.552502
# Unit test for function color
def test_color():
    assert color(colorama.Style.RESET_ALL) == ''
    settings.no_colors = False
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

# Generated at 2022-06-24 05:44:03.092096
# Unit test for function debug_time
def test_debug_time():  # pragma: no cover
    import time
    def func():
        time.sleep(1)
    with debug_time('test'):
        func()

# Generated at 2022-06-24 05:44:06.061685
# Unit test for function failed
def test_failed():
    import StringIO

    stream = StringIO.StringIO()
    sys.stderr = stream
    failed(u'Some thing went wrong')
    assert stream.getvalue() == u'\x1b[31mSome thing went wrong\x1b[0m\n'



# Generated at 2022-06-24 05:44:09.443292
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    from .types import Command
    show_corrected_command(CorrectedCommand(Command('ls', ''), ''))

# Generated at 2022-06-24 05:44:11.249066
# Unit test for function color
def test_color():
    assert color(u'{green}').format(green=colorama.Fore.GREEN) == u''

# Generated at 2022-06-24 05:44:12.277489
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:44:13.369852
# Unit test for function debug
def test_debug():
    assert debug('test') == None

# Generated at 2022-06-24 05:44:14.689155
# Unit test for function debug
def test_debug():
    debug('test debug')



# Generated at 2022-06-24 05:44:15.885003
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr.write('-----------------TESTING RULE FAILED--------------------\n')
    rule_failed('yes',('1','2','3'))

# Generated at 2022-06-24 05:44:17.176753
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(configuration_details) == "fuck alias configured successfully"

# Generated at 2022-06-24 05:44:22.669880
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    with mock.patch('sys.stderr') as stderr:
        with debug_time('test'):
            time.sleep(0.001)
        stderr.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:00.001034\n')


# Generated at 2022-06-24 05:44:25.326174
# Unit test for function rule_failed
def test_rule_failed():
    from .rule import Rule

    class MockException(Exception):
        pass

    exc = MockException('test_exception')
    rule = Rule('name', 'inline_regex')
    rule_failed(rule, sys.exc_info())

# Generated at 2022-06-24 05:44:26.191997
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('conf.py')

# Generated at 2022-06-24 05:44:29.439672
# Unit test for function version
def test_version():
    from . import version
    assert version(
        u'4.0', u'2.6.6', u'Fish 2.1.0') == \
        u'The Fuck 4.0 using Python 2.6.6 and Fish 2.1.0\n'

# Generated at 2022-06-24 05:44:30.619825
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details=None) is None

# Generated at 2022-06-24 05:44:33.273070
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'Some exception')
    except Exception:
        exception(u'Rule', sys.exc_info())



# Generated at 2022-06-24 05:44:34.088261
# Unit test for function configured_successfully
def test_configured_successfully():
    return u"Successfully configured"



# Generated at 2022-06-24 05:44:35.988658
# Unit test for function version
def test_version():
    version('1.1.1', '2.7.12', 'sh 3.2.57(1)-release (x86_64-apple-darwin15)')



# Generated at 2022-06-24 05:44:39.605927
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    output = StringIO()
    sys.stderr = output

    warn('title')

    sys.stderr = sys.__stderr__
    assert output.getvalue() == '\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'



# Generated at 2022-06-24 05:44:45.998937
# Unit test for function debug
def test_debug():
    import io
    mock_log = io.StringIO()
    settings.debug = True
    old_stderr = sys.stderr
    sys.stderr = mock_log
    debug('test debug')
    sys.stderr = old_stderr
    assert mock_log.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n'

# Generated at 2022-06-24 05:44:51.812752
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    try:
        out = StringIO()
        sys.stderr = out
        settings.debug = True
        debug(u"The message")
        assert out.getvalue() == u"\x1b[94m\x1b[1mDEBUG:\x1b[0m The message\n"
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:44:52.939167
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-24 05:45:01.051194
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # GIVEN
    from thefuck.utils import configuration_details
    from mock import patch
    from io import StringIO

    configuration_details._replace(path=u'~/.bashrc',
                                   content=u'set $fuck',
                                   can_configure_automatically=False)
    with patch('sys.stdout', new=StringIO()) as fake_out:
        # WHEN
        how_to_configure_alias(configuration_details)
        # THEN

# Generated at 2022-06-24 05:45:05.948890
# Unit test for function debug_time
def test_debug_time():
    from thefuck.utils import debug_time
    from time import time
    from mock import MagicMock

    debug_function = MagicMock()
    with debug_time('message'):
        t1 = time()
        time.sleep(1)
        debug_function()
        t2 = time()

    debug_function.assert_any_call(u'message took: {}'.format(t2 - t1))

# Generated at 2022-06-24 05:45:07.486183
# Unit test for function warn
def test_warn():
    warn(title="Dark Sky")


# Generated at 2022-06-24 05:45:09.846889
# Unit test for function exception
def test_exception():
    try:
        raise Exception('error')
    except Exception as e:
        exception('test exception', sys.exc_info())



# Generated at 2022-06-24 05:45:18.693877
# Unit test for function exception
def test_exception():
    from io import StringIO
    from .test import test_exception_info
    from .test.test_utils import Mock

    assert isinstance(test_exception_info, tuple)

    assert len(test_exception_info) == 3

    stderr = StringIO()

    sys.stderr = stderr

    exception('test', test_exception_info)


# Generated at 2022-06-24 05:45:23.846306
# Unit test for function rule_failed
def test_rule_failed():
    from unittest import TestCase
    from mock import Mock

    class TestRuleFailed(TestCase):
        def test_rule_failed(self):
            rule = Mock(name='TestRule')
            rule_failed(rule, sys.exc_info())

    from .tests.utils import test

    test(TestRuleFailed)

# Generated at 2022-06-24 05:45:25.710817
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert isinstance(how_to_configure_alias(""), type(""))


# Generated at 2022-06-24 05:45:27.859580
# Unit test for function already_configured
def test_already_configured():
    already_configured('your shell')
    return "this is test"

# Generated at 2022-06-24 05:45:34.796683
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    warn("test")
    sys.stderr = sys.__stderr__
    assert out.getvalue() == "{warn}[WARN] {title}{reset}\n".format(
        warn=color(colorama.Back.RED + colorama.Fore.WHITE
                   + colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        title="test")


# Generated at 2022-06-24 05:45:46.037709
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Test')
    except Exception:
        lines = exception('Test', sys.exc_info()).splitlines()

    assert lines[0] == (u'{warn}[WARN] Test:{reset}'
                        .format(warn=color(colorama.Back.RED
                                           + colorama.Fore.WHITE
                                           + colorama.Style.BRIGHT),
                                reset=color(colorama.Style.RESET_ALL)))
    assert lines[1] == (u'{warn}----------------------------{reset}'
                        .format(warn=color(colorama.Back.RED
                                           + colorama.Fore.WHITE
                                           + colorama.Style.BRIGHT),
                                reset=color(colorama.Style.RESET_ALL)))
    assert lines[2] == u''

# Generated at 2022-06-24 05:45:54.801385
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(settings.ConfigurationDetails(
        path=u'~/.config/fish/config.fish',
        content=u'set PATH $PATH /usr/local/bin\n',
        reload=u'fish_reload'))
    how_to_configure_alias(settings.ConfigurationDetails(
        path=u'~/.config/fish/config.fish',
        content=u'set PATH $PATH /usr/local/bin\n',
        reload=u'fish_reload'))

# Generated at 2022-06-24 05:45:59.741462
# Unit test for function warn
def test_warn():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', StringIO()) as fake_err:
        warn('test')
        assert fake_err.getvalue().strip() == u'[WARN] test'



# Generated at 2022-06-24 05:46:02.886412
# Unit test for function color
def test_color():
    assert color(u'hello') == u'hello'
    assert color(u'hello') != u'hell'
    assert color(u'hello') != u'helloa'



# Generated at 2022-06-24 05:46:03.954645
# Unit test for function debug_time
def test_debug_time():
    with debug_time('time'):
        assert True

# Generated at 2022-06-24 05:46:10.793016
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import get_shell
    test_shell = get_shell()
    if test_shell.name == 'zsh':
        # zsh returns a single line
        assert confirm_text(const.Command('git commit', False)) == u'Test\rgit commit ' \
                                                                   u'[enter/↑/↓/ctrl+c]'
        assert confirm_text(const.Command('git commit', True)) == u'Test\rgit commit ' \
                                                                  u'(+side effect) ' \
                                                                  u'[enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:46:13.179604
# Unit test for function debug
def test_debug():
    from .conf import settings

    settings.debug = True
    debug(u'foo')

    settings.debug = False
    debug(u'foo')

# Generated at 2022-06-24 05:46:15.495942
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details)


if __name__ == '__main__':
   test_already_configured()

# Generated at 2022-06-24 05:46:16.872213
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('reload')

# Generated at 2022-06-24 05:46:25.513102
# Unit test for function failed
def test_failed():
    class TestStdErr(object):
        def __init__(self):
            self.value = ''

        def write(self, value):
            self.value += value

    stderr = TestStdErr()
    sys.stderr = stderr
    failed(u'*')
    assert stderr.value.startswith(u'\x1b[31m'), u'Should contain color code'
    assert stderr.value.endswith(u'\x1b[0m*\n'), u'Should contain reset code'
    assert stderr.value != u'*\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:46:31.147568
# Unit test for function debug
def test_debug():
    """Function `test_debug` checks if debug function works properly"""
    try:
        import StringIO
        s = StringIO.StringIO()
        sys.stderr = s
        debug('test')
        assert 'DEBUG' in s.getvalue()
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:46:32.373429
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-24 05:46:35.365458
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .rules.git_dirty_working_directory import _get_corrected_command
    from .rules.git_dirty_working_directory import GitDirtyWorkingDirectory
    command = GitDirtyWorkingDirectory().get_new_command(
        _get_corrected_command('git push |& cat'))
    show_corrected_command(command)

# Generated at 2022-06-24 05:46:36.776948
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except ZeroDivisionError:
        exception('Test exception', sys.exc_info())



# Generated at 2022-06-24 05:46:38.451365
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('cd ~') == 'Seems like fuck alias already configured!\nFor applying changes run cd ~ or restart your shell.'

# Generated at 2022-06-24 05:46:41.410349
# Unit test for function exception
def test_exception():
    try:
        raise Exception('Whoops')
    except Exception as e:
        exception('Exception!', sys.exc_info()) == u'[WARN] Exception!:Whoops'

# Generated at 2022-06-24 05:46:50.262098
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    from mock import patch

    with patch('os.stderr.write') as write_mock:
        with debug_time('foo'):
            sleep(0.1)
        assert 'foo took: 0:00:00.100000' in write_mock.call_args[0][0]

    with patch('os.stderr.write') as write_mock:
        with debug_time('bar'):
            sleep(0.3)
        assert 'bar took: 0:00:00.300000' in write_mock.call_args[0][0]

    with patch('os.stderr.write') as write_mock:
        with debug_time('baz'):
            sleep(1.1)

# Generated at 2022-06-24 05:47:00.357618
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('thefuck.shells.get_all_shells') as get_all_shells, \
            patch('sys.stderr') as stderr:
        get_all_shells.return_value = [{
            'name': 'Shell',
            'version': '2.2',
            'how_to_configure': "Don't know",
            'function_name': 'function_name'}]
        settings.debug = True
        debug(u'Debug message')

        settings.debug = False
        debug(u'Debug message')
        stderr.write.assert_called_once_with(u'\x1b[36m\x1b[1m'
                                             u'DEBUG:\x1b[0m Debug message\n')



# Generated at 2022-06-24 05:47:04.973419
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({
        'can_configure_automatically': True,
        'reload': 'source ~/.bashrc',
        'path': '~/.bashrc',
        'content': 'eval $(thefuck --alias)'
    })

# Generated at 2022-06-24 05:47:07.351229
# Unit test for function debug_time
def test_debug_time():
    """
    This code is used to test the function debug_time
    """
    with debug_time('test'):
        pass



# Generated at 2022-06-24 05:47:10.046260
# Unit test for function version
def test_version():
    assert version('1.0', '2.7', 'bash') == \
        u'The Fuck 1.0 using Python 2.7 and bash'



# Generated at 2022-06-24 05:47:15.766946
# Unit test for function failed
def test_failed():
    import os
    import tempfile
    with tempfile.TemporaryFile(mode='rb') as tmp:
        sys.stderr = tmp
        failed(u'failed test')
        tmp.seek(0)
        assert tmp.read() == u'{red}failed test{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL)).encode(u'utf-8')

# Generated at 2022-06-24 05:47:17.900705
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(u'confirm text')
    sys.stderr.flush()

# Generated at 2022-06-24 05:47:20.624772
# Unit test for function exception
def test_exception():
    try:
        raise SyntaxError('error')
    except Exception:
        exc_info = sys.exc_info()
        exception('My Title', exc_info)

# Generated at 2022-06-24 05:47:24.998316
# Unit test for function color
def test_color():
    class Dummy(object):
        def __str__(self):
            return 'test'

    color_string = color(Dummy())
    if settings.no_colors:
        assert color_string == ''
    else:
        assert color_string == 'test'



# Generated at 2022-06-24 05:47:27.363687
# Unit test for function color
def test_color():
    assert color('\x1b[0m') == ''
    assert color('\x1b[0m') != '\x1b[0m'



# Generated at 2022-06-24 05:47:32.520265
# Unit test for function debug
def test_debug():
    org_stderr = sys.stderr
    mock_stderr = org_stderr
    try:
        sys.stderr = mock_stderr
        debug(u'Real debug!')
    finally:
        sys.stderr = org_stderr

# Generated at 2022-06-24 05:47:34.435710
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('Hello') == {'script': 'Hello'}
    assert show_corrected_command('Hello', 'World') == {'script': 'Hello', 'side_effect': 'World'}



# Generated at 2022-06-24 05:47:37.543390
# Unit test for function debug_time
def test_debug_time():
    import contextlib
    with contextlib.redirect_stdout(None):
        with debug_time('debug'):
            pass


# Generated at 2022-06-24 05:47:40.341794
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(
        script='ls /tmp',
        side_effect=False,
        is_corrected=True)
    confirm_text(corrected_command)



# Generated at 2022-06-24 05:47:42.090277
# Unit test for function already_configured
def test_already_configured():
    from test.lib import Mock
    assert already_configured(Mock(reload='reload')) == None



# Generated at 2022-06-24 05:47:43.934819
# Unit test for function color
def test_color():
    assert color(u'fuck') == u'fuck'
    assert color(u'fuck') != u'fucc'


# Generated at 2022-06-24 05:47:45.465359
# Unit test for function color
def test_color():
    assert color('white') == 'white'
    settings.no_colors = True
    assert color('white') == ''

# Generated at 2022-06-24 05:47:52.663387
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    from thefuck.utils import show_corrected_command
    from thefuck.types import CorrectedCommand

    out = StringIO.StringIO()
    sys.stderr = out
    show_corrected_command(CorrectedCommand('git brnach', 'git branch'))

    assert out.getvalue() == '{prefix}git branch\n'.format(
        prefix=const.USER_COMMAND_MARK)

# Generated at 2022-06-24 05:48:03.735454
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    from .shells import Shell

    print_ = []
    finish_ = []
    open_end = []

    with tempfile.NamedTemporaryFile() as config:
        with tempfile.NamedTemporaryFile() as home:
            with open(home.name, 'w+') as home:
                home.write('echo $HOME')
                home.flush()
                open_end.append(home.name)


# Generated at 2022-06-24 05:48:11.773878
# Unit test for function rule_failed
def test_rule_failed():
    import os
    import tempfile
    try:
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
            pass
        os.remove(f.name)
        with open(f.name):
            pass
    except Exception:
        with open('test_output', 'w') as f:
            with open(sys.stderr):
                sys.stderr = f
                rule_failed(None, sys.exc_info())
        with open('test_output') as f:
            test_res = f.read()
        with open('test_output', 'w') as f:
            f.write(test_res.replace(sys.stderr.name, 'test_output'))

# Generated at 2022-06-24 05:48:18.110209
# Unit test for function failed
def test_failed():
    import StringIO

    temp_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out

        failed('fuuuuuuuuck')

        output = out.getvalue().strip()
        assert output == u'\x1b[31mfuuuuuuuuck\x1b[0m'
    finally:
        sys.stdout = temp_stdout

# Generated at 2022-06-24 05:48:19.626622
# Unit test for function color
def test_color():
    assert not color(colorama.Back.RED + 'foo')

# Generated at 2022-06-24 05:48:20.783466
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(object)

# Generated at 2022-06-24 05:48:23.523586
# Unit test for function warn
def test_warn():
    warn('title')
    assert sys.stderr.getvalue() == u'[WARN] title\n'
    sys.stderr = FakeStderr()



# Generated at 2022-06-24 05:48:28.347709
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = u'pip install ipython'
    expected_output = u'$ {}'.format(corrected_command)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == expected_output

# Generated at 2022-06-24 05:48:33.053783
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .shells.generic import to_shell
    from .command import CorrectedCommand

    shell = Shell(to_shell(settings, const.OSQuery),
                  settings=settings)
    corrected_command = CorrectedCommand('ls', 'ls -lah', shell)

    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:48:35.254497
# Unit test for function already_configured
def test_already_configured():
    configuration_details = const.ConfigurationDetails(
        'asdf', 'asdf', 'asdf', True)
    already_configured(configuration_details)

# Generated at 2022-06-24 05:48:39.449491
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'path': '/path',
                             'content': 'content',
                             'restart_command': 'reload',
                             'can_configure_automatically': True}
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-24 05:48:41.191023
# Unit test for function warn
def test_warn():
    warn('test_warn_title') == '[WARN] test_warn_title{reset}\n'


# Generated at 2022-06-24 05:48:43.635393
# Unit test for function failed
def test_failed():
    try:
        failed('test')
    except UnicodeEncodeError:
        # UnicodeEncodeError should not raised due to 'replace' error handler.
        raise Exception('fail')



# Generated at 2022-06-24 05:48:47.510683
# Unit test for function failed
def test_failed():
    from cStringIO import StringIO
    f = StringIO()
    sys.stderr = f
    failed(u'foo')
    sys.stderr = sys.__stderr__
    assert f.getvalue() == '\x1b[31mfoo\x1b[0m\n'



# Generated at 2022-06-24 05:48:48.601401
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('fuck')

# Generated at 2022-06-24 05:49:00.408673
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stderr.write('Test how_to_configure_alias:\n')
    sys.stderr.write('=============================\n')
    sys.stderr.write('Running the test with all parameters:\n')

    class Dummy:
        def _asdict(self):
            return {'bold': u'*bold*', 'reset': u'*reset*',
                    'path': u'~/.zshrc',
                    'content': u'eval $(thefuck --alias)',
                    'reload': u'source ~/.zshrc',
                    'can_configure_automatically': True}

    configuration_details = Dummy()
    how_to_configure_alias(configuration_details)

    sys.stderr.write('\nRunning the test with no parameters:\n')
    how_

# Generated at 2022-06-24 05:49:06.971740
# Unit test for function version
def test_version():
    from . import version
    from .utils import get_shell_info

    assert u'The Fuck {version} using Python {py_version} ' \
           u'and {shell_info}\n'.format(
        version=version.__version__,
        py_version=sys.version.split()[0],
        shell_info=get_shell_info()) == version(version.__version__,
                                                sys.version.split()[0],
                                                get_shell_info())

# Generated at 2022-06-24 05:49:10.390415
# Unit test for function show_corrected_command
def test_show_corrected_command():
    c = corrected_command(script="ls", side_effect=None)
    assert show_corrected_command(c) == "> ls"
    c = corrected_command(script="ls", side_effect=True)
    assert show_corrected_command(c) == "> ls (+side effect)"



# Generated at 2022-06-24 05:49:12.597205
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells.zsh import Zsh
    configuration_details = Zsh()
    configuration_details.path = "/.zshrc"
    configuration_details.reload = "source ~/.zshrc"
    configured_successfully(configuration_details)



# Generated at 2022-06-24 05:49:13.854455
# Unit test for function already_configured
def test_already_configured():
        already_configured('configuration_details')

# Generated at 2022-06-24 05:49:15.420385
# Unit test for function version
def test_version():
    assert version('The Fuck 1', '2', '3') == None

# Generated at 2022-06-24 05:49:24.315444
# Unit test for function version
def test_version():
    from .app import Application
    from .shells import available_shells
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .utils import get_version
    from .utils import get_python_version

    app = Application(settings, None, None)
    with app.log.patch():
        all_shells = available_shells()
        version(app.version, get_python_version(), all_shells[0].info())
        version(app.version, get_python_version(), all_shells[1].info())
        app.log.version(app.version, get_python_version(), Bash().info())

# Generated at 2022-06-24 05:49:29.808205
# Unit test for function already_configured
def test_already_configured():
	assert already_configured("#!/usr/bin/env bash") ==  "Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}source ~/.bash_profile{reset} or restart your shell."
	assert already_configured("#!/usr/bin/env zsh") == "Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}source ~/.zshrc{reset} or restart your shell."

# Generated at 2022-06-24 05:49:38.805935
# Unit test for function debug
def test_debug():
    with debug_time('test_debug'):
        debug('I have a line break\nright here')

    assert self.old_stderr.getvalue() == (
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m I have a line break\n'
        u'right here\n'
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test_debug took: '
        u'0:00:00.000147\n')



# Generated at 2022-06-24 05:49:41.948204
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'command'
    confirm_text(corrected_command)
    corrected_command = 'command'
    assert confirm_text(corrected_command) == 'command'


# Generated at 2022-06-24 05:49:43.847812
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(1) is None
    assert confirm_text("not ascii") is None


# Generated at 2022-06-24 05:49:47.986181
# Unit test for function color
def test_color():
    assert color('a') == 'a'
    assert color('a') != '💩'
    settings.no_colors = True
    assert color('a') != 'a'
    assert color('a') == '💩'

# Generated at 2022-06-24 05:49:50.711407
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debug_time'):
        pass


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-24 05:49:55.646572
# Unit test for function already_configured
def test_already_configured():
    u'Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1mreload\x1b[21m or restart your shell.' == already_configured({'reload': 'reload'})

# Generated at 2022-06-24 05:50:01.938935
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('rule', 'exc_info')
    assert sys.stderr.getvalue() == '\x1b[41m\x1b[37m\x1b[1m[WARN] Rule rule\x1b[0m\nTraceback (most recent call last):\x1b[41m\x1b[37m\x1b[1m\n----------------------------\x1b[0m\n'



# Generated at 2022-06-24 05:50:09.697213
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import sys

    output = io.StringIO()

# Generated at 2022-06-24 05:50:16.580793
# Unit test for function configured_successfully
def test_configured_successfully():
    import io
    
    class Config(object):
        def __init__(self, reload):
            self.reload = reload
            
    output = io.BytesIO()
    sys.stdout = output
    
    configured_successfully(Config('reload'))
    
    assert len(output.getvalue().strip()) != 0
    assert output.getvalue().find('For applying changes run reload or restart your shell.') != -1

# Generated at 2022-06-24 05:50:21.231819
# Unit test for function already_configured
def test_already_configured():
    result = u'Seems like The Fuck alias already configured!\n' \
             u'For applying changes run source $HOME/.bashrc\n' \
             u'or restart your shell.'
    assert already_configured({'reload': 'source $HOME/.bashrc'}) == result

# Generated at 2022-06-24 05:50:24.159994
# Unit test for function exception
def test_exception():
    try:
        raise Exception('test exception')
    except Exception:
        assert len(list(exception('test', sys.exc_info()))) > 0



# Generated at 2022-06-24 05:50:25.507281
# Unit test for function already_configured
def test_already_configured():
    already_configured(configuration_details=None)

# Generated at 2022-06-24 05:50:26.850935
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("rule", "exc_info")

# Generated at 2022-06-24 05:50:27.835525
# Unit test for function confirm_text
def test_confirm_text():

    assert confirm_text(corrected_command)

# Generated at 2022-06-24 05:50:28.431314
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass

# Generated at 2022-06-24 05:50:31.405023
# Unit test for function version
def test_version():
    version('3.9', '2.7.13', 'Python')



# Generated at 2022-06-24 05:50:35.598376
# Unit test for function failed
def test_failed():
    """Test that line was writed to stderr

    Test use assert_that and stdout_was_called
    """
    from hamcrest import assert_that
    from thefuck.main import stdout_was_called

    failed('wrong')
    assert_that(stdout_was_called())

# Generated at 2022-06-24 05:50:38.986916
# Unit test for function warn
def test_warn():
    warning_title = u'This is a warning title'
    stdout = sys.stdout
    sys.stdout = sys.stderr
    warn(warning_title)
    sys.stdout = stdout


# Generated at 2022-06-24 05:50:44.931760
# Unit test for function warn
def test_warn():
    keys = []
    values = []
    for key, value in colorama.Style.__dict__.items():
        if key.isupper():
            keys.append(key)
            values.append(value)

    import itertools
    import random
    for _ in range(1000):
        random.shuffle(keys)
        for style in itertools.permutations(values, 2):
            warn(u'\033[{}m{}\033[{}m'.format(*style))


if __name__ == '__main__':
    test_warn()
    print('All done')

# Generated at 2022-06-24 05:50:46.323895
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('some command')
    assert sys.stderr.write

# Generated at 2022-06-24 05:50:50.844135
# Unit test for function color
def test_color():
    colorama.init()

    assert color(colorama.Fore.GREEN + 'foo' + colorama.Style.RESET_ALL) == (
        colorama.Fore.GREEN + 'foo' + colorama.Style.RESET_ALL)
    assert color('foo') == ''

# Generated at 2022-06-24 05:50:58.927618
# Unit test for function debug
def test_debug():
    with settings(debug=True):
        debug('test_debug')
        output = sys.stderr.getvalue()
        assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test_debug\n'

    with settings(debug=False):
        debug('test_debug')
        output = sys.stderr.getvalue()
        assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test_debug\n'


# Generated at 2022-06-24 05:51:01.582347
# Unit test for function debug
def test_debug():
    # Check that it won't log anything
    settings._replace(debug=False)
    debug('test')
    # Check that it will log
    settings._replace(debug=True)
    debug('test')

# Generated at 2022-06-24 05:51:03.044962
# Unit test for function failed
def test_failed():
    failed(u'Failed')


# Generated at 2022-06-24 05:51:05.526115
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('Test exception')
    except Exception:
        exception('Title', sys.exc_info())

# Generated at 2022-06-24 05:51:15.362412
# Unit test for function confirm_text
def test_confirm_text():
    result = u'>>> echo "pwd"&\n' \
             u'{}\033[1K\r>>> echo "pwd"& [+side effect] ' \
             u'[enter/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]' \
             u'\n'.format(const.USER_COMMAND_MARK)
    assert confirm_text('echo "pwd"&', True) == result

# Generated at 2022-06-24 05:51:22.087589
# Unit test for function version
def test_version():
    from . import __version__
    from . import shell
    from . import utils
    import sys
    import StringIO
    from distutils.version import StrictVersion
    version(__version__, utils.python_version(), shell.get_shell_info())
    assert StrictVersion(sys.version.split()[0]) >= StrictVersion('2.6.0')
    assert StrictVersion(sys.version.split()[0]) < StrictVersion('2.7.0')

# Generated at 2022-06-24 05:51:24.226332
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK = '$'
    assert confirm_text('git br') == 'git br'

# Generated at 2022-06-24 05:51:28.354420
# Unit test for function failed
def test_failed():
    import sys

    class Stderr(object):
        def __init__(self):
            self.content = ''

        def write(self, string):
            self.content += string

    stderr = Stderr()
    old_stderr = sys.stderr
    sys.stderr = stderr
    try:
        failed(u'Something wrong')
    finally:
        sys.stderr = old_stderr
    assert stderr.content == u'\x1b[31mSomething wrong\x1b[0m\n'



# Generated at 2022-06-24 05:51:29.489153
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('test')



# Generated at 2022-06-24 05:51:38.089104
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.shells import Shell
    from thefuck.rules.man import get_new_command, match, enabled
    import traceback
    try:
        get_new_command('man', Shell())
    except Exception:
        exc_info = sys.exc_info()

    rule_failed(type('Rule', (object,), {'name': 'man', 'match': match,
                                         'get_new_command': get_new_command,
                                         'enabled': enabled}), exc_info)

# Generated at 2022-06-24 05:51:39.913609
# Unit test for function exception
def test_exception():

    try:
        '5' + 5
    except Exception as e:
        exception('Error', e)

# Generated at 2022-06-24 05:51:50.412353
# Unit test for function already_configured
def test_already_configured():
    # without content in file $HOME/.bashrc
    with open('$HOME/.bashrc','w') as f:
        f.write('#export PATH="$HOME/.config/thefuck:$PATH"\n')
        f.write('eval $(thefuck --alias)\n')
    assert already_configured('source ~/.bashrc') == 'Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell.'
    # with content in file $HOME/.bashrc
    with open('$HOME/.bashrc','w') as f:
        f.write('export PATH="$HOME/.config/thefuck:$PATH"\n')
        f.write('eval $(thefuck --alias)\n')

# Generated at 2022-06-24 05:51:57.010840
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    old_stdout = sys.stderr
    captured_stdout = StringIO()
    sys.stderr = captured_stdout
    debug("This is a fake debug")
    sys.stderr = old_stdout
    assert captured_stdout.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m This is a fake debug\n'

# Generated at 2022-06-24 05:51:57.801940
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(None, None)

# Generated at 2022-06-24 05:51:59.996761
# Unit test for function debug_time
def test_debug_time():
    with debug_time("msg"):
        a = 1
        b = 2
        c = 3


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-24 05:52:02.690687
# Unit test for function exception
def test_exception():
    try:
        a = 1
        raise Exception('Test')
    except Exception:
        exception('Test exception', sys.exc_info())

# Generated at 2022-06-24 05:52:05.630566
# Unit test for function already_configured
def test_already_configured():
    mock_stdout = MockOutput()
    with mock_stdout:
        already_configured(None)
        assert mock_stdout.value == "Seems like fuck alias already configured!\nFor applying changes run <reload> or restart your shell."



# Generated at 2022-06-24 05:52:07.612109
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('some time'):
        pass
    assert started - datetime.now()

# Generated at 2022-06-24 05:52:08.171066
# Unit test for function debug
def test_debug():
    debug('test message')

# Generated at 2022-06-24 05:52:11.407897
# Unit test for function rule_failed
def test_rule_failed():
    exit_status, output = rule_failed()
    assert exit_status == 1
    assert output == "[WARN] Rule:failed"

    exit_status, output = rule_failed()
    assert exit_status == 1
    assert output == "[WARN] Rule:failed"


# Generated at 2022-06-24 05:52:20.017874
# Unit test for function failed
def test_failed():
    from pytest import raises
    from pytest import approx

    from thefuck.shells import Shell

    def calc_failed(settings, args, stdout, stderr):
        assert args == ['calc', '1+']
        assert stdout == []
        assert stderr == []
        return 'wrong'
    settings.no_colors = False
    with Shell('/bin/bash', stdout=None, stderr=None) as shell:
        shell.calc_failed = calc_failed
        sys.stdout = sys.stderr = buffer = shell.stderr
        with raises(SystemExit) as exited:
            failed('wrong')
        assert exited.value.code == 100

# Generated at 2022-06-24 05:52:20.899845
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-24 05:52:22.275408
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('configuration_details')



# Generated at 2022-06-24 05:52:24.900490
# Unit test for function version
def test_version():
    version('3.0', '3.5.2', 'Bash 4.0.0')

if __name__ == '__main__':
    test_version()

# Generated at 2022-06-24 05:52:26.629480
# Unit test for function debug_time
def test_debug_time():

    debug(u'Test debug_time')
    with debug_time(u'Test debug_time'):
        pass

# Generated at 2022-06-24 05:52:30.716958
# Unit test for function failed
def test_failed():
    """Tests failed function."""
    assert failed(u'Error!') == sys.stderr.write(u'{red}Error!{reset}\n'.format(
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-24 05:52:31.922531
# Unit test for function configured_successfully
def test_configured_successfully():
    print(configured_successfully('source ~/.bashrc;'))

# Generated at 2022-06-24 05:52:33.978012
# Unit test for function color
def test_color():
    assert color('') is None
    settings.no_colors = True
    assert color('') == ''
    settings.no_colors = False



# Generated at 2022-06-24 05:52:44.616155
# Unit test for function confirm_text
def test_confirm_text():
    # when
    show_confirm_text_called = [False]
    show_corrected_command_called = [False]

    def show_confirm_text(corrected_command):
        assert corrected_command.script == 'fuck'
        show_confirm_text_called[0] = True

    def show_corrected_command(corrected_command):
        assert corrected_command.script == 'fuck'
        show_corrected_command_called[0] = True

    confirm_text.show_confirm_text = show_confirm_text
    confirm_text.show_corrected_command = show_corrected_command

    # then
    confirm_text(CorrectedCommand('fuck', False))
    assert show_confirm_text_called[0]
    assert show_corrected_command_called[0]