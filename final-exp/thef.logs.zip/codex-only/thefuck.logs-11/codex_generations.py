

# Generated at 2022-06-24 05:42:43.992011
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .commands import CorrectedCommand
    show_corrected_command(CorrectedCommand('foo', 'bar', False))
    # Result:
    # #foo bar
    show_corrected_command(CorrectedCommand('foo', 'bar', True))
    # Result:
    # #foo bar (+side effect)


# Generated at 2022-06-24 05:42:44.916293
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:42:51.161765
# Unit test for function failed
def test_failed():
    err = u"Програма зупинена. Застосуйте команду 'FUCK' для перезапуску.\n"
    failed(err)
    assert sys.stderr.getvalue() == u'{red}{msg}{reset}\n'.format(
        msg=err,
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:42:59.229284
# Unit test for function debug_time
def test_debug_time():
    from . import debug_time
    from thefuck.settings import debug
    from mock import patch, Mock
    from datetime import datetime
    from StringIO import StringIO

    with patch('sys.stderr', StringIO()):
        debug = True
        with debug_time('test'):
            wait = datetime.now() + timedelta(seconds=0.4)
            while datetime.now() < wait:
                pass

        captured = sys.stderr.getvalue().strip()
        assert captured.startswith('DEBUG: test took:')

# Generated at 2022-06-24 05:43:00.096203
# Unit test for function exception
def test_exception():
    exception(u'title', sys.exc_info())



# Generated at 2022-06-24 05:43:01.814373
# Unit test for function version
def test_version():
    print(version([1,21,0], '3.5.2', 'bash-4.4'))


# Generated at 2022-06-24 05:43:03.779242
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully({"configuration_details": "configuration_details"}) == None


# Generated at 2022-06-24 05:43:07.344159
# Unit test for function debug_time
def test_debug_time():
    from . import __version__

    version(__version__, '{}'.format(sys.version),
            '{} ({})'.format(sys.platform, sys.executable))

    import time
    with debug_time("Fake"):
        time.sleep(1)



# Generated at 2022-06-24 05:43:13.045011
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    from colorama import Fore

    old = sys.stderr
    try:
        sys.stderr = StringIO()
        warn(u'Test')
        assert sys.stderr.getvalue() == (
            u'{}[WARN] Test{}\n'.format(
                Fore.WHITE + colorama.Back.RED + colorama.Style.BRIGHT,
                colorama.Style.RESET_ALL))
    finally:
        sys.stderr = old



# Generated at 2022-06-24 05:43:21.795232
# Unit test for function version
def test_version():
    from mock import Mock
    thefuck_version = '0.10'
    python_version = (2, 7, 11, 'final', 0)
    shell_info = 'Zsh'
    from StringIO import StringIO
    test_output = StringIO()
    sys.stderr = test_output
    version(thefuck_version, python_version, shell_info)
    sys.stderr = sys.__stderr__
    assert test_output.getvalue() == \
        'The Fuck 0.10 using Python 2.7.11 and Zsh\n'


# Generated at 2022-06-24 05:43:30.257504
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(script='ls -la')
    assert confirm_text(corrected_command) == \
        const.USER_COMMAND_MARK + \
        '\x1b[1K\r' + \
        '\033[1m' + \
        'ls -la' + \
        '\033[0m' + \
        ' ' + \
        '[\033[32menter\033[0m/\033[34m↑\033[0m/\033[34m↓\033[0m' + \
        '/\033[31mctrl+c\033[0m]'

# Generated at 2022-06-24 05:43:33.532269
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('$ git add') == '{prefix}$ git add [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'


# Generated at 2022-06-24 05:43:35.397698
# Unit test for function confirm_text
def test_confirm_text():
    str = confirm_text(None)
    assert str.startswith(const.USER_COMMAND_MARK)

# Generated at 2022-06-24 05:43:39.546520
# Unit test for function warn
def test_warn():
    from . import logs
    logs.warn('test') == u'\x1b[41m\x1b[37m\x1b[1m[WARN] test\x1b[0m\n'


# Generated at 2022-06-24 05:43:50.693351
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.utils import get_alias, ColoredCorrectedCommand
    from thefuck.main import RuleExecutor
    from thefuck.types import Command, CorrectedCommand
    from thefuck.shells import Bash, StrangeShell
    from thefuck.rules import get_rules

    exec_rule = RuleExecutor(get_rules()).rules[0]
    rule_command = Command(script='echo test',
                           exc=None,
                           side_effect=True)
    corrected_command = exec_rule.get_new_command(rule_command)


# Generated at 2022-06-24 05:43:55.674595
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'Проверка: проверка')
    except Exception:
        exception(u'Проверка: проверка', sys.exc_info())

# Generated at 2022-06-24 05:43:59.928955
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == ''
    assert color(colorama.Style.BRIGHT + colorama.Fore.RED
                 + colorama.Back.GREEN) == colorama.Style.BRIGHT \
        + colorama.Fore.RED + colorama.Back.GREEN

# Generated at 2022-06-24 05:44:02.564402
# Unit test for function warn
def test_warn():

    from StringIO import StringIO

    out = StringIO()
    sys.stderr = out

    warn("a")

    sys.stderr = sys.__stderr__

    assert(out.getvalue() == u'[WARN] a\n')



# Generated at 2022-06-24 05:44:08.091175
# Unit test for function warn
def test_warn():
    assert warn(u'Warning') == u'[WARN] Warning\n'
    assert warn(u'Warning'.encode('utf-8')) == u'[WARN] Warning\n'

    assert warn(u'Предупреждение') == u'[WARN] Предупреждение\n'
    assert warn(u'Предупреждение'.encode('utf-8')) == u'[WARN] Предупреждение\n'



# Generated at 2022-06-24 05:44:14.068666
# Unit test for function debug
def test_debug():
    import mock
    from thefuck.utils import debug
    with mock.patch('sys.stderr') as stderr:
        debug(u'say {message}', message=u'Fuck!')
        stderr.write.assert_called_once_with(u"\033[34m\033[1mDEBUG:\033[0m "
                                             u"say Fuck!\n")



# Generated at 2022-06-24 05:44:15.330502
# Unit test for function rule_failed
def test_rule_failed():
    from .conf import Rule
    ex = Exception
    rule = Rule('name')
    rule_failed(rule, sys.exc_info())


# Generated at 2022-06-24 05:44:16.643315
# Unit test for function already_configured
def test_already_configured():
    assert already_configured({'reload': 'echo ""'})



# Generated at 2022-06-24 05:44:22.094906
# Unit test for function configured_successfully
def test_configured_successfully():
    expected_result = u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL),
        reload="source ~/.bashrc")
    assert configured_successfully("source ~/.bashrc") == expected_result

# Generated at 2022-06-24 05:44:23.018993
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully("")
    assert True

# Generated at 2022-06-24 05:44:24.389145
# Unit test for function version
def test_version():
    assert sys.stderr.write('The Fuck 3.18 using Python 2.7 and Bash 4\n')
# END unit test

# Generated at 2022-06-24 05:44:25.574824
# Unit test for function version
def test_version():
    version('3.5', '3.5.3', 'iTerm2')

# Generated at 2022-06-24 05:44:31.162987
# Unit test for function failed
def test_failed():
    out = sys.stderr = StringIO()
    failed(u'Правило {0} не сработало'.format(u'функция'))
    assert u'Правило функция не сработало\n' == out.getvalue()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:44:35.788683
# Unit test for function configured_successfully
def test_configured_successfully():
    import StringIO
    saved_stdout = sys.stdout
    try:
        out = StringIO.StringIO()
        sys.stdout = out
        configured_successfully(None)
        output = out.getvalue().strip()
        assert 'fuck alias configured successfully!' in output
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-24 05:44:37.203775
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except Exception:
        exception(u'', sys.exc_info())

# Generated at 2022-06-24 05:44:37.956406
# Unit test for function exception
def test_exception():
    exception('Rule name', sys.exc_info())

# Generated at 2022-06-24 05:44:39.540194
# Unit test for function exception
def test_exception():
    try:
        raise Exception
    except Exception:
        exception_info = sys.exc_info()

    exception('Exception', exception_info)

# Generated at 2022-06-24 05:44:50.529121
# Unit test for function warn
def test_warn():
    from mock import patch
    stderr = patch('sys.stderr')
    warn('msg')
    stderr.write.assert_called_with(u'[WARN] msg\n')
    stderr.reset_mock()

    settings.no_colors = True
    warn('msg')
    stderr.write.assert_called_with(u'[WARN] msg\n')
    settings.no_colors = False
    stderr.reset_mock()

    colorama.init()
    warn('msg')

# Generated at 2022-06-24 05:44:55.060775
# Unit test for function version
def test_version():
    out = StringIO()
    version(u'3.1415926', u'2.7.6', u'I\'m not a shell, I\'m a shell script')
    assert out.getvalue() == u'The Fuck 3.1415926 using Python 2.7.6 and I\'m not a shell, I\'m a shell script\n'

# Generated at 2022-06-24 05:45:02.020038
# Unit test for function warn
def test_warn():
    from tests.utils import support_stderr
    with support_stderr() as stderr:
        warn('foo')
    assert stderr.getvalue() == u'\x1b[101m\x1b[97m\x1b[1m[WARN] foo\x1b[0m\n'



# Generated at 2022-06-24 05:45:09.526926
# Unit test for function version
def test_version():
    import io
    import version
    import platform
    input_output = io.StringIO()
    sys.stderr = input_output
    version(version='3.11.0',
            python_version=platform.python_version(),
            shell_info='Shell Info')
    sys.stderr = sys.__stderr__
    assert input_output.getvalue() == u'The Fuck 3.11.0 using ' \
                                     u'Python {} and Shell Info\n'.format(platform.python_version())

# Generated at 2022-06-24 05:45:14.649941
# Unit test for function rule_failed
def test_rule_failed():
    from .types import Command
    from .rules import Rule

    with open('/dev/null', 'w') as fd:
        sys.stderr = fd
        rule_failed(Rule(name='fuck',
                         get_new_command=lambda x: x,
                         enabled_by_default=True,
                         priority=1),
                    exc_info=(Exception, Exception('Error'), None))

# Generated at 2022-06-24 05:45:15.169438
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully == print

# Generated at 2022-06-24 05:45:19.414062
# Unit test for function version
def test_version():
    def _redirect_stderr(func):
        def wrapper(*args, **kwargs):
            old_stderr, sys.stderr = sys.stderr, sys.__stderr__
            try:
                return func(*args, **kwargs)
            finally:
                sys.stderr = old_stderr
        return wrapper

    @_redirect_stderr
    def _check_version(t_version, p_version, s_info):
        version(t_version, p_version, s_info)
        assert sys.stderr.getvalue() == \
            u'The Fuck {} using Python {} and {}\n'.format(t_version,
                                                           p_version,
                                                           s_info)
    _check_version('', '', '')
   

# Generated at 2022-06-24 05:45:21.953508
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('test') == "Seems like fuck alias already configured!\nFor applying changes run test or restart your shell."


# Generated at 2022-06-24 05:45:23.219069
# Unit test for function color
def test_color():
    assert color('red') == ''



# Generated at 2022-06-24 05:45:24.252245
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None) == None

# Generated at 2022-06-24 05:45:25.711280
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    with debug_time('a'): sleep(1)

# Generated at 2022-06-24 05:45:28.732820
# Unit test for function color
def test_color():
    assert '\x1b[31m' == color(colorama.Fore.RED)
    assert '' == color(colorama.Fore.GREEN)

# Generated at 2022-06-24 05:45:36.821275
# Unit test for function already_configured
def test_already_configured():
    # test for ubuntu
    configuration_details = const.ConfigureDetails(
        reload_command='source ~/.bashrc',
        can_configure_automatically=False)

    already_configured(configuration_details)

    # test for mac
    configuration_details = const.ConfigureDetails(
        reload_command='source ~/.bash_profile',
        can_configure_automatically=False)

    already_configured(configuration_details)

    # test for zsh
    configuration_details = const.ConfigureDetails(
        reload_command='source ~/.zshrc',
        can_configure_automatically=False)

    already_configured(configuration_details)

# Generated at 2022-06-24 05:45:40.954460
# Unit test for function failed
def test_failed():
    from test.utils import capture_output

    with capture_output() as (out, err):
        failed('test')
        assert err.getvalue() == '\x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-24 05:45:51.011954
# Unit test for function debug_time
def test_debug_time():
    """Check that `debug_time` shows actual time in debug mode"""
    from mock import patch
    from datetime import datetime

    with patch('sys.stderr') as stderr:
        with debug_time('test1'):
            datetime.now()
            datetime.now()
        with debug_time('test2'):
            datetime.now()
            datetime.now()
        with debug_time('test3'):
            datetime.now()
            datetime.now()
        dt1 = datetime.now()
        datetime.now()
        datetime.now()
        dt2 = datetime.now()
        datetime.now()
        datetime.now()
        dt3 = datetime.now()
        datetime.now()
        datetime.now()
        d

# Generated at 2022-06-24 05:45:51.856843
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')

# Generated at 2022-06-24 05:45:58.718834
# Unit test for function exception
def test_exception():
    exc_info = None
    try:
        __tracebackhide__ = True
        raise RuntimeError('test')
    except RuntimeError:
        exc_info = sys.exc_info()

    import StringIO
    buf = StringIO.StringIO()
    exc_stderr = sys.stderr
    sys.stderr = buf
    exception('Title', exc_info)
    sys.stderr = exc_stderr


# Generated at 2022-06-24 05:46:05.477047
# Unit test for function rule_failed
def test_rule_failed():
    rule = object()
    rule.name = 'test'
    try: 1 / 0
    except Exception:
        exc_info = sys.exc_info()
    rule_failed(rule, exc_info)

    # Check exception message
    assert 'Rule test' in sys.stderr.getvalue().decode('utf-8')
    # Check traceback message
    assert 'Traceback (most recent call last)' in sys.stderr.getvalue().decode('utf-8')



# Generated at 2022-06-24 05:46:06.322953
# Unit test for function warn
def test_warn():
    warn('Test warn')


# Generated at 2022-06-24 05:46:17.911082
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.powershell import Powershell
    from .shells.shell import Shell
    import mock
    import sys

    expected_output = (
        u'{bold}fuck{reset} alias configured successfully!\n'
        u'For applying changes run {bold}{reload}{reset}'
        u' or restart your shell.')

    shells = [Bash(), Zsh(), Fish(), Powershell(), Shell()]
    for shell in shells:
        with mock.patch('sys.stderr', new=mock.Mock()) as mocked_sys:
            configured_successfully(shell.get_aliases())
        config = shell.get_aliases()

# Generated at 2022-06-24 05:46:18.890866
# Unit test for function configured_successfully
def test_configured_successfully():
    # There is no way to test stdout.
    pass

# Generated at 2022-06-24 05:46:28.474392
# Unit test for function show_corrected_command

# Generated at 2022-06-24 05:46:32.327578
# Unit test for function failed
def test_failed():
    failed("test")
    sys.stderr.flush()
    assert sys.stderr.getvalue() == '\x1b[31mtest\x1b[0m\n'

# Generated at 2022-06-24 05:46:36.526898
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
        prefix=const.USER_COMMAND_MARK,
        script=u'git push origin master',
        side_effect=u' (+side effect)',
        bold=u'',
        reset=u''))

# Unit tests for the color() function

# Generated at 2022-06-24 05:46:38.484845
# Unit test for function exception
def test_exception():
    try:
        raise Exception('exception_msg')
    except:  # noqa
        pass
        exception(u'Exception', sys.exc_info())



# Generated at 2022-06-24 05:46:48.497817
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import Command
    assert show_corrected_command(Command('ls', '')) == 'ls'
    assert show_corrected_command(Command('ls', '', True)) == 'ls (+side effect)'
    # no output for coverage
    assert confirm_text(Command('ls', '', True)) == ''
    assert warn('test') == '[WARN] test'
    assert exception('test', 'test') == '[WARN] test'
    assert rule_failed('test', 'test') == 'Rule test'
    assert failed(u'Привет') == u'Привет'
    assert how_to_configure_alias('') == ''
    assert already_configured('') == ''
    assert configured_successfully('') == ''
    assert version('test', 'test', 'test')

# Generated at 2022-06-24 05:46:50.231289
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass


# Generated at 2022-06-24 05:46:54.685922
# Unit test for function rule_failed
def test_rule_failed():
    from .utils import wrap_streams
    from .rules import Rule
    from .exceptions import FailedToHandle

    rule = Rule(lambda x: x * 2)
    with wrap_streams(), \
            pytest.raises(FailedToHandle):
        rule_failed(rule, sys.exc_info())


# Generated at 2022-06-24 05:47:00.517876
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    with StringIO() as buffer:
        old_stderr = sys.stderr
        sys.stderr = buffer
        try:
            warn('Test warning')
        finally:
            sys.stderr = old_stderr
        assert buffer.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] Test warning\x1b[0m\n'

# Generated at 2022-06-24 05:47:02.517465
# Unit test for function rule_failed
def test_rule_failed():
    def hello():
        raise ValueError('Hello')
    try:
        hello()
    except Exception:
        rule_failed('func', sys.exc_info())

# Generated at 2022-06-24 05:47:08.828527
# Unit test for function already_configured
def test_already_configured():
    assert already_configured('reload') == print(u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload='reload'))



# Generated at 2022-06-24 05:47:14.156081
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import get_rule
    rule = get_rule('echo', 'file.txt')
    rule.command = 'Fuck'
    try:
        raise Exception('Error')
    except Exception:
        rule_failed(rule, sys.exc_info())
        assert len(sys.stderr.getvalue()) > 0
        sys.stderr.write = sys.stderr.buffer.write

# Generated at 2022-06-24 05:47:16.729426
# Unit test for function color
def test_color():
    colorama.init(True)
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Fore.BLUE) == ''
    colorama.deinit()

# Generated at 2022-06-24 05:47:18.669981
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('Rule', ('1', '2'))



# Generated at 2022-06-24 05:47:22.385247
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text
    with patch('sys.stderr.write') as write:
        confirm_text('It is a test')
        assert write.called

# Generated at 2022-06-24 05:47:26.913695
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    _stdout = sys.stdout
    sys.stdout = StringIO()

    failed(u'error')
    result = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = _stdout

    assert u'[\033[91merror\033[0m]' in result

# Generated at 2022-06-24 05:47:30.885441
# Unit test for function rule_failed
def test_rule_failed():
    print("In test_rule_failed")
    try:
        assert(2 == 3)
    except:
        rule_failed("name", sys.exc_info())


# Generated at 2022-06-24 05:47:31.880689
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully(None)

# Generated at 2022-06-24 05:47:38.728948
# Unit test for function failed
def test_failed():
    from . import exceptions
    from thefuck.utils import wrap_settings, OptionalSettings
    from .tests.utils import captured_output

    with wrap_settings(OptionalSettings(no_colors=True)):
        with captured_output() as (stdout, stderr):
            failed(exceptions.NoRuleMatched)
            failed(exceptions.NoRuleMatched('foo'))

    assert stderr.getvalue() == (
        u'[ERROR] NoRuleMatched\n'
        u'[ERROR] NoRuleMatched: foo\n')



# Generated at 2022-06-24 05:47:40.811629
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = {'reload': 'reload'}
    assert configured_successfully(configuration_details) == None

# Generated at 2022-06-24 05:47:44.604196
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'ls -a'
    corrected_command = 'ls -al'
    assert show_corrected_command(corrected_command) == '\x1b[1K\r' + \
        color(colorama.Style.BRIGHT) + corrected_command + \
        color(colorama.Style.RESET_ALL)

# Generated at 2022-06-24 05:47:48.346556
# Unit test for function rule_failed
def test_rule_failed():
    from .utils import rule_failed
    with open('t.log', 'w') as f:
        old_stderr = sys.stderr
        sys.stderr = f
        try:
            rule_failed('rule', ('type', 'value', 'traceback'))
        except Exception:
            pass
        sys.stderr = old_stderr

# Generated at 2022-06-24 05:47:49.463462
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass

# Generated at 2022-06-24 05:48:00.644053
# Unit test for function warn
def test_warn():
    from . import utils
    from .utils import no_colors, debug
    from .utils import settings
    from .settings import Settings
    utils.colorama = colorama
    utils.colorama.init = True
    utils.colorama.Fore.RED = 'red'
    utils.colorama.Fore.RESET = ''
    utils.colorama.Back.RED = 'red'
    utils.colorama.Back.RESET = ''
    utils.colorama.Style.BRIGHT = 'bright'
    utils.colorama.Style.RESET_ALL = ''

    utils.sys = sys
    utils.sys.stderr = sys.stderr

    _settings = Settings()
    utils.settings = _settings
    _settings.no_colors = False

# Generated at 2022-06-24 05:48:08.823116
# Unit test for function debug
def test_debug():
    from os import environ, devnull
    from tempfile import mkstemp
    from shutil import copyfileobj

    environ['TF_DEBUG'] = '1'

    # Patch stderr
    patch_stderr = mkstemp()
    stderr = sys.stderr
    try:
        sys.stderr = open(patch_stderr[1], 'w')
        debug('Test')
    finally:
        sys.stderr = stderr
        close(patch_stderr[0])

    # Check

# Generated at 2022-06-24 05:48:11.697889
# Unit test for function version
def test_version():
    version('1.2', '2.7.6', 'bash') # pragma: no cover

# Generated at 2022-06-24 05:48:23.285458
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from .conf import set_settings, settings
    import colorama

    set_settings(no_colors=False)
    sys.stderr = StringIO()
    failed('msg')
    assert sys.stderr.getvalue() == (
        u'{red}msg{reset}\n'.format(
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL)))
    sys.stderr = sys.__stderr__

    set_settings(no_colors=True)
    sys.stderr = StringIO()
    failed('msg')
    assert sys.stderr.getvalue() == u'msg\n'
    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:48:25.974750
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'git add .'
    show_corrected_command(corrected_command)


# Generated at 2022-06-24 05:48:30.041643
# Unit test for function failed
def test_failed():
    sys.stderr.write('\n')
    failed('Expected messages')
    sys.stderr.write('\033[1A\033[K')


if __name__ == '__main__':
    test_failed()

# Generated at 2022-06-24 05:48:40.585086
# Unit test for function debug
def test_debug():
    from .application import Application

    app = Application(settings=settings, create_config=False)
    debug_value = app.settings.debug
    app.settings.debug = False

    def fake_stdout(text):
        debug_value = None
        if text == u'\033[34m\033[1mDEBUG:\033[0m \n':
            debug_value = False
        elif text == u'\033[34m\033[1mDEBUG:\033[0m test\n':
            debug_value = True
        return debug_value

    with app.patched_stdout_context():
        debug(u'')
        assert not fake_stdout(sys.stdout.getvalue())
        debug(u'test')
        assert fake_stdout(sys.stdout.getvalue())

# Generated at 2022-06-24 05:48:43.045607
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.GREEN + 'Hello') == colorama.Fore.GREEN + 'Hello'
    assert color('Hello') == ''


# Generated at 2022-06-24 05:48:44.740315
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''

# Generated at 2022-06-24 05:48:46.666917
# Unit test for function debug
def test_debug():
    from capture import capture
    settings.debug = True
    debug('test')
    assert u'DEBUG: test\n' in capture(debug, 'test')
    settings.debug = False
    assert capture(debug, 'test') == u''

# Generated at 2022-06-24 05:48:50.845333
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import contextlib
    debug_string = StringIO()
    with contextlib.redirect_stdout(debug_string):
        debug('Test debug')
        assert debug_string.getvalue() == 'DEBUG: Test debug\n'

# Generated at 2022-06-24 05:48:56.759839
# Unit test for function failed
def test_failed():
    from cStringIO import StringIO

    old_stderr = sys.stderr
    sys.stderr = StringIO()
    failed('test')
    output = sys.stderr.getvalue()
    sys.stderr = old_stderr
    assert output == '\x1b[31mtest\x1b[0m\n'

# Generated at 2022-06-24 05:48:58.310113
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("") == None


# Generated at 2022-06-24 05:49:01.053176
# Unit test for function version
def test_version():
    from .shells import Shell
    assert version(const.VERSION,
                   sys.version[:5],
                   str(Shell('./some/shell'))) == None

# Generated at 2022-06-24 05:49:07.590076
# Unit test for function show_corrected_command
def test_show_corrected_command():
    code = colorama.Fore.RED + colorama.Style.RESET_ALL
    print(u'{prefix}{bold}{script}{reset}{side_effect}'.format(
        prefix=const.USER_COMMAND_MARK,
        script="../fuck_off/fuck_off.py",
        side_effect=u' (+side effect)' if True else u'',
        bold=color(colorama.Style.BRIGHT),
        reset=code))


# Generated at 2022-06-24 05:49:08.516180
# Unit test for function confirm_text
def test_confirm_text():
    # TODO: write it!
    assert(True)

# Generated at 2022-06-24 05:49:20.001328
# Unit test for function confirm_text
def test_confirm_text():
    conf_text = confirm_text('echo "hello world"')

# Generated at 2022-06-24 05:49:20.999518
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls --all')

# Generated at 2022-06-24 05:49:21.762224
# Unit test for function debug
def test_debug():
    with debug_time('ff'):
        pass

# Generated at 2022-06-24 05:49:27.199519
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    err = StringIO()
    sys.stderr = err
    warn('title')
    sys.stderr = sys.__stderr__
    assert err.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'



# Generated at 2022-06-24 05:49:31.780797
# Unit test for function already_configured
def test_already_configured():
    u"""
    >>> class Configuration_details:
    ...     def __init__(self, reload):
    ...         self.reload=reload

    >>> configuration_details = Configuration_details('ls')
    >>> already_configured(configuration_details)
    Seems like fuck alias already configured!
    For applying changes run ls or restart your shell.
    """

# Generated at 2022-06-24 05:49:35.363513
# Unit test for function version
def test_version():
    version('1.1', '2.7.10', 'Powershell')
    version('1.1', '2.7.10', 'bash')
    version('1.1', '2.7.10', 'zsh')

# Generated at 2022-06-24 05:49:38.122857
# Unit test for function already_configured
def test_already_configured():
    try:
        already_configured('test')
    except NameError:
        return 1
    return 0



# Generated at 2022-06-24 05:49:41.020496
# Unit test for function configured_successfully
def test_configured_successfully():
    class ConfigureDetails(object):
        def __init__(self, reload):
            self.reload = reload

    configured_successfully(ConfigureDetails("reload"))



# Generated at 2022-06-24 05:49:42.590372
# Unit test for function rule_failed
def test_rule_failed():
    from ..exceptions import FailedToCorrect
    rule_failed('rule', FailedToCorrect())

# Generated at 2022-06-24 05:49:46.751672
# Unit test for function debug
def test_debug():
    from .conf import settings
    from .utils import reset_settings

    settings._no_colors = True
    settings._debug = True
    debug('test')
    reset_settings()
    settings._debug = False
    debug('test')


# Generated at 2022-06-24 05:49:47.832498
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(('script', True))

# Generated at 2022-06-24 05:49:53.243999
# Unit test for function debug
def test_debug():
    from thefuck import shells
    from thefuck.shells import Bash
    from thefuck.types import ShellInfo

    settings.debug = True

    debug(u'бла-бла')

    # Show that debug works with all shells
    for shell in shells.supported_shells():
        shell = shell()
        debug(u'бла-бла')



# Generated at 2022-06-24 05:50:04.007976
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(['ls'])
    show_corrected_command(['ls', '-alF'])
    show_corrected_command(['ls', '-alF', 'new_file.txt'])
    show_corrected_command(['ls', '-alF', 'new_file.txt', 'new_file2.txt'])
    show_corrected_command(['ls', '-alF', 'new_file.txt', 'new_file2.txt', 'new_file3.txt'])
    show_corrected_command(['ls', '-alF', 'new_file.txt', 'new_file2.txt', 'new_file3.txt', 'new_file4.txt'])

# Generated at 2022-06-24 05:50:09.428696
# Unit test for function rule_failed
def test_rule_failed():
    class Rule(object):
        def __init__(self, name, side_effect=False):
            self.name = name
            self.side_effect = side_effect
    rule_failed(Rule('rule'), (Exception, Exception('foo'), None))



# Generated at 2022-06-24 05:50:19.676188
# Unit test for function configured_successfully
def test_configured_successfully():
    import io
    import sys

    stderr = io.StringIO()
    original_stderr = sys.stderr
    sys.stderr = stderr

    # Correct command
    class ConfDetails:
        reload = 'reload'
    configured_successfully(ConfDetails)
    out = stderr.getvalue()
    assert out == u'\x1b[1mfuck\x1b[21m alias configured successfully!\nFor applying changes run \x1b[1mreload\x1b[21m or restart your shell.\n'
    # Clear buffer
    stderr.close()
    stderr = io.StringIO()
    sys.stderr = stderr

    # Incorrect command
    class IncorrectConfDetails:
        reload = 'reload'
    configured_successfully

# Generated at 2022-06-24 05:50:22.147098
# Unit test for function version
def test_version():
    version('v.0.7', '2.7.9', 'ShellInfo(bash, 4.3.42(1))')

# Generated at 2022-06-24 05:50:27.653099
# Unit test for function exception
def test_exception():
    import pytest
    try:
        raise Exception(u'Бля')
    except BaseException as e:
        exception(u'Тестовый', e.args)
    with pytest.raises(Exception) as exc_info:
        rule_failed(Exception(), exc_info)
        assert False, 'Shoul`t be here'

# Generated at 2022-06-24 05:50:31.908363
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from datetime import datetime
    show_corrected_command(123)

    assert(const.USER_COMMAND_MARK == u'\U0001F41B ')

# Generated at 2022-06-24 05:50:40.522674
# Unit test for function configured_successfully
def test_configured_successfully():
    import os

    def mock_print(*args):
        assert args[0] == u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload='/bin/kill -9 $$')

    original_print = __builtins__['print']
    __builtins__['print'] = mock_print
    try:
        import thefuck.utils

        thefuck.utils.configured_successfully({'reload': '/bin/kill -9 $$'})
    finally:
        __builtins__['print'] = original_print

# Generated at 2022-06-24 05:50:42.706692
# Unit test for function version
def test_version():
    assert 'The Fuck 3.4 using Python 3.4 and Bash 3.2' == version('3.4', '3.4', 'Bash 3.2')


# Generated at 2022-06-24 05:50:45.383664
# Unit test for function debug_time
def test_debug_time():
    from .log import debug_time
    import time
    with debug_time("test_debug_time"):
        time.sleep(3)

# Generated at 2022-06-24 05:50:46.450336
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    raise Exception('Not implemented')



# Generated at 2022-06-24 05:50:52.104199
# Unit test for function version
def test_version():
    from . import __version__
    from platform import python_version
    from .shells import get_shell_info

    assert version(__version__, python_version(), get_shell_info()) == \
        'The Fuck {} using Python {} and {}'.format(__version__,
                                                    python_version(),
                                                    get_shell_info())



# Generated at 2022-06-24 05:50:57.037701
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        def __init__(self, value):
            self.parameter = value

        def __str__(self):
            return repr(self.parameter)

    try:
        raise TestException("test message")
    except:
        exception("Test", sys.exc_info())

# Generated at 2022-06-24 05:51:01.214656
# Unit test for function debug
def test_debug():
    assert debug('test') is None
    assert debug_time('test') is not None
    assert how_to_configure_alias(0) is None
    assert already_configured(0) is None
    assert configured_successfully(0) is None
    assert version('0', '1', '2') is None



# Generated at 2022-06-24 05:51:08.179030
# Unit test for function already_configured
def test_already_configured():
    print("Testing already_configured")
    import io
    import sys
    old_stdout = sys.stdout

    sys.stdout = StringIO = io.StringIO()
    already_configured('test')
    assert sys.stdout.getvalue() == "Seems like fuck alias already configured!\nFor applying changes run test or restart your shell.\n"
    sys.stdout = old_stdout


# Generated at 2022-06-24 05:51:12.777658
# Unit test for function failed
def test_failed():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', StringIO()) as stderr:
        failed('msg')
    assert stderr.getvalue() == u'\x1b[31mmsg\x1b[0m\n'



# Generated at 2022-06-24 05:51:13.513534
# Unit test for function failed
def test_failed():
    failed("abcde")



# Generated at 2022-06-24 05:51:14.543684
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully == 1

# Generated at 2022-06-24 05:51:16.089521
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED) == colorama.Back.RED



# Generated at 2022-06-24 05:51:17.752489
# Unit test for function already_configured
def test_already_configured():
    already_configured(u'. ~/.bashrc')


# Generated at 2022-06-24 05:51:21.395383
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'Red') == \
        colorama.Fore.RED + 'Red'
    settings.no_colors = True
    assert color(colorama.Fore.RED + 'Red') == ''

# Generated at 2022-06-24 05:51:24.429697
# Unit test for function already_configured
def test_already_configured():
    configuration_details = {
        'path': "~/.bashrc",
        'can_configure_automatically': True,
        'reload': 'source ~/.bashrc'
    }

    already_configured(configuration_details)



# Generated at 2022-06-24 05:51:26.351900
# Unit test for function exception
def test_exception():
    try:
        raise Exception
    except:
        exception('title', sys.exc_info())


# Generated at 2022-06-24 05:51:30.129550
# Unit test for function failed
def test_failed():
    from cStringIO import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO()
    failed('msg')
    text = sys.stderr.getvalue()
    sys.stderr = stderr
    assert text == '\x1b[91mmsg\x1b[0m\n'

# Generated at 2022-06-24 05:51:33.442417
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('\x1b[1;31;40m') == ''
    del settings.no_colors

# Generated at 2022-06-24 05:51:34.629247
# Unit test for function warn
def test_warn():
    warn('foo')


# Generated at 2022-06-24 05:51:44.159601
# Unit test for function how_to_configure_alias

# Generated at 2022-06-24 05:51:46.355638
# Unit test for function version
def test_version():
    version('3.12.0', '3.5.3', 'bash 4.3.42(1)-release (x86_64-pc-linux-gnu)')
# End of unit test

# Generated at 2022-06-24 05:51:57.169625
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import tempfile
    from textwrap import dedent
    from .shells import shells


# Generated at 2022-06-24 05:52:00.836215
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Pretend to be the user command
    sys.argv = ['fuck', 'git', 'push origin master']

    class FakeCommand(object):
        def __init__(self):
            self.script = 'git push origin master --force'
            self.side_effect = True

    show_corrected_command(FakeCommand())

# Generated at 2022-06-24 05:52:08.256099
# Unit test for function already_configured
def test_already_configured():
    import os
    import shutil

    cwd = os.path.abspath(os.path.curdir)

# Generated at 2022-06-24 05:52:08.823319
# Unit test for function warn
def test_warn():
    warn('foo')

# Generated at 2022-06-24 05:52:19.094008
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    tmp_config = {
        'bold': color(colorama.Style.BRIGHT),
        'reset': color(colorama.Style.RESET_ALL),
        'content': 'alias fuck = \'. <(thefuck alias)\'',
        'path': '.bashrc',
        'reload': 'source .bashrc'
    }
    tmp_config._asdict()
    a = u'Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.'.format(**tmp_config)

# Generated at 2022-06-24 05:52:21.370687
# Unit test for function failed
def test_failed():
    failed('Test')
    assert sys.stderr.getvalue() == "\x1b[31mTest\x1b[0m\n"



# Generated at 2022-06-24 05:52:23.202803
# Unit test for function rule_failed
def test_rule_failed():
    import thefuck
    rule_failed(thefuck.rules.python.match, [None, None, None])

# Generated at 2022-06-24 05:52:30.762768
# Unit test for function version
def test_version():
    thefuck_version = "1.1"
    python_version = "2.7"
    shell_info = "bash"

    mocked_stderr = sys.stderr
    sys.stderr = mock_stderr = MockStdout()
    version(thefuck_version, python_version, shell_info)
    assert mock_stderr.text == \
        u'The Fuck {} using Python {} and {}\n'.format(thefuck_version, python_version, shell_info)
    sys.stderr = mocked_stderr



# Generated at 2022-06-24 05:52:37.806236
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(settings.get_configuration_details()) == sys.stderr.write(u'Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.'.format(bold=u'\x1b[1m', reset=u'\x1b[0m', reload=u'~/.config/thefuck/thefuck.py'))



# Generated at 2022-06-24 05:52:43.226658
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    fake_stderr = StringIO()
    try:
        old_stderr, sys.stderr = sys.stderr, fake_stderr
        warn(u'Title')
    finally:
        sys.stderr = old_stderr

    assert fake_stderr.getvalue() == u'[WARN] Title\n'

