

# Generated at 2022-06-24 05:42:41.514330
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import get_closest
    from .rules.git import match, get_new_command
    from .shells import ParanoidShell

    command = get_closest('fukc', match, get_new_command,
                          'git brnch', ParanoidShell())
    show_corrected_command(command)
    assert command.script == 'git branch'

# Generated at 2022-06-24 05:42:43.421588
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    shell_info = Shell('', '~')
    show_corrected_command('ls -la')

# Generated at 2022-06-24 05:42:44.337397
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-24 05:42:45.257180
# Unit test for function debug
def test_debug():
    assert debug('test') == None

# Generated at 2022-06-24 05:42:47.804098
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command(const.CorrectedCommand(u'ls -lha', False))
    show_corrected_command(const.CorrectedCommand(u'ls -lha', True))

# Generated at 2022-06-24 05:42:58.651045
# Unit test for function rule_failed
def test_rule_failed():
    import io
    import unittest
    import thefuck
    from thefuck import utils

    class TestCase(unittest.TestCase):
        def setUp(self):
            sys.stdout.close()
            self.stdout = io.StringIO()
            sys.stdout = self.stdout

        def tearDown(self):
            sys.stdout.close()
            sys.stdout = sys.__stdout__

    class TestUtils(TestCase):
        def setUp(self):
            self.rule = thefuck.Rule('a', 'b', 'c', 'd', True)

        def test_rule_failed(self):
            utils.rule_failed(self.rule, ('a', 'b', 'c'))

# Generated at 2022-06-24 05:42:59.926426
# Unit test for function already_configured
def test_already_configured():
    already_configured({"reload": "reload"})



# Generated at 2022-06-24 05:43:03.140963
# Unit test for function already_configured
def test_already_configured():
    already_configured("~/.bashrc")
    already_configured("~/.bash_profile")
    already_configured("~/.zshrc")
    already_configured("~/.profile")
    already_configured("~/.config/fish/config.fish")
    already_configured("~/.config/fish/functions/fuck.fish")
    already_configured("~/.config/fish/fishfile")



# Generated at 2022-06-24 05:43:04.859173
# Unit test for function failed
def test_failed():
    try:
        failed(u'Test')
    except:
        assert False


# Generated at 2022-06-24 05:43:08.170253
# Unit test for function debug_time
def test_debug_time():
    result = "DEBUG: 'time' took: 0:00:00.000001"
    with debug_time('time'):
        pass
    assert result == 'DEBUG: \'time\' took: 0:00:00.000001'



# Generated at 2022-06-24 05:43:15.092946
# Unit test for function version
def test_version():
    version("3.0", "3.4", "cmd")
    print("-------------")
    version("3.0", "3.4", "powershell")
    print("-------------")
    version("3.0", "3.4", "bash")
    print("-------------")
    version("3.0", "3.4", "zsh")
    print("-------------")
    version("3.0", "3.4", "cygwin")
    print("-------------")
    version("3.0", "3.4", "git-bash")
    print("-------------")
    version("3.0", "3.4", "idle")
    print("-------------")
    version("3.0", "3.4", "sh")

# Generated at 2022-06-24 05:43:16.308020
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(None) == None

# Generated at 2022-06-24 05:43:17.550906
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed(None, (None, None, None))

# Generated at 2022-06-24 05:43:20.951034
# Unit test for function version
def test_version():
    version('1.1', '2.8.11', 'shell info')
    assert sys.stderr.getvalue() == 'The Fuck 1.1 using Python 2.8.11 and shell info\n'

# Generated at 2022-06-24 05:43:28.792665
# Unit test for function version
def test_version():
    import mock
    import sys
    import platform
    import thefuck.shells
    shell_info=thefuck.shells.get_shell_info()
    stderr = mock.Mock()
    with mock.patch('thefuck.utils.sys.stderr', stderr):
        version('thefuck_version', 'python_version', shell_info)
    stderr.write.assert_called_once_with("The Fuck thefuck_version using Python python_version and {} ({} {})".format(shell_info.name, platform.machine(), platform.system()))

# Generated at 2022-06-24 05:43:30.873467
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(['fuck', 'reload']) == 'fuck alias configured successfully!\nFor applying changes run reload or restart your shell.'

# Generated at 2022-06-24 05:43:32.693990
# Unit test for function failed
def test_failed():
    """Test function failed"""
    failed('I have a bad feeling about this')



# Generated at 2022-06-24 05:43:34.689836
# Unit test for function version
def test_version():
    assert version("3.4", "3.4.5", "shell") \
           == "The Fuck 3.4 using Python 3.4.5 and shell"

# Generated at 2022-06-24 05:43:35.754858
# Unit test for function failed
def test_failed():
    failed('test msg')
    assert True



# Generated at 2022-06-24 05:43:42.746584
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = settings.ConfigurationDetails('reload', 'path')
    assert u"{bold}fuck{reset} alias configured successfully!\nFor applying changes run {bold}reload{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT),reset=color(colorama.Style.RESET_ALL),reload=configuration_details.reload) == configured_successfully(configuration_details)


# Generated at 2022-06-24 05:43:45.146728
# Unit test for function configured_successfully
def test_configured_successfully():
    class x(object):
        def _asdict(self):
            return {'reload':'test'}

    configured_successfully(x())

# Generated at 2022-06-24 05:43:48.171431
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN + 'green') == '\x1b[32mgreen'
    assert color(colorama.Fore.GREEN + 'green') == ''

# Generated at 2022-06-24 05:43:56.126065
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(
        CorrectedCommand('', None)) == 'The fuck: [] [enter]/[↑]/[↓]/[ctrl+c]'
    assert confirm_text(
        CorrectedCommand('ls', None)) == 'The fuck: [ls] [enter]/[↑]/[↓]/[ctrl+c]'
    assert confirm_text(
        CorrectedCommand('ls -l', None)) == 'The fuck: [ls -l] [enter]/[↑]/[↓]/[ctrl+c]'
    assert confirm_text(
        CorrectedCommand('ls -l', 'rmdir')) == 'The fuck: [ls -l] (+side effect) [enter]/[↑]/[↓]/[ctrl+c]'

# Generated at 2022-06-24 05:43:58.902271
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('/dev/null', 'w')
    import colorama
    colorama.init()
    confirm_text('some_command')

# Generated at 2022-06-24 05:44:00.409430
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-24 05:44:01.635456
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    assert color('color') == ''



# Generated at 2022-06-24 05:44:03.432332
# Unit test for function color
def test_color():
    assert color('red') == '\x1b[0;31m'
    assert color('bold') == '\x1b[1m'



# Generated at 2022-06-24 05:44:04.572451
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command="echo '123'")

# Generated at 2022-06-24 05:44:06.581636
# Unit test for function exception
def test_exception():
    try:
        raise Exception(u'Привет, мир!')
    except:
        exception(u'test', sys.exc_info())

# Generated at 2022-06-24 05:44:11.670826
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    correct_command = mock.Mock()
    correct_command.script = 'correct'
    correct_command.side_effect = False
    assert confirm_text(correct_command) == "fuck correct [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-24 05:44:13.974794
# Unit test for function exception
def test_exception():
    try:
        1/0
    except:
        exception(u'Test', sys.exc_info())


# Generated at 2022-06-24 05:44:15.997382
# Unit test for function warn
def test_warn():
    assert warn('title') == '\x1b[41m[WARN] title\x1b[0m\n'



# Generated at 2022-06-24 05:44:19.155686
# Unit test for function rule_failed
def test_rule_failed():
    class FakeException(Exception):
        pass
    class TestRule(object):
        name = "test"
    rule_failed(TestRule(), (FakeException, FakeException(), []))


# Generated at 2022-06-24 05:44:25.723366
# Unit test for function configured_successfully
def test_configured_successfully():
    from .shells import Shell
    from .utils import wrap_before_colon

    class ConfigurationDetails(object):
        def __init__(self, shell_path, alias, reload_command):
            self.shell_path = shell_path
            self.alias = alias
            self.reload = reload_command

    shell = Shell('bash')
    configuration_details = ConfigurationDetails(shell.path, wrap_before_colon(shell.script), shell.reload_alias())

    configured_successfully(configuration_details)


# Generated at 2022-06-24 05:44:26.495747
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass

# Generated at 2022-06-24 05:44:32.014029
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """Test for function show_corrected_command."""
    from .command import CorrectedCommand

    assert show_corrected_command(
        CorrectedCommand('ls --help', 'ls --help', True)
    ) == const.USER_COMMAND_MARK + 'ls --help (+side effect)\n'
    assert show_corrected_command(
        CorrectedCommand('ls --help', 'ls --help', False)
    ) == const.USER_COMMAND_MARK + 'ls --help\n'



# Generated at 2022-06-24 05:44:34.737461
# Unit test for function failed
def test_failed():
    sys.stderr.write('\n')  # newline
    failed(u'Fail')
    sys.stderr.write('\n\n')

if __name__ == '__main__':
    test_failed()

# Generated at 2022-06-24 05:44:38.956708
# Unit test for function version
def test_version():
    """
    test that our version command prints the correct output
    """
    from io import StringIO
    import sys
    capturedOutput = StringIO()
    sys.stdout = capturedOutput

    version('1.2.3', '2.7', 'bash')

    sys.stdout = sys.__stdout__
    assert capturedOutput.getvalue() == u'The Fuck 1.2.3 using Python 2.7 and bash\n'



# Generated at 2022-06-24 05:44:41.398574
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(u'') == u''



# Generated at 2022-06-24 05:44:48.284608
# Unit test for function exception
def test_exception():
    exc_info = (Exception, Exception('example'), None)
    exception('title', exc_info)
    assert sys.stderr.getvalue() == u'[WARN] title:\nTraceback (most recent call last):\n  File "<stdin>", line 1, in <module>\nException: example\n\n[WARN] ----------------------------\n\n'
    sys.stderr = old_stderr



# Generated at 2022-06-24 05:44:51.981838
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {
        'reload': 'reload',
        'content': 'content',
        'path': 'path',
        'can_configure_automatically': True
    }
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-24 05:44:57.616636
# Unit test for function debug
def test_debug():
    """Unit test for function debug"""
    from thefuck.types import Command
    from StringIO import StringIO
    import sys
    import function_debug

    out = StringIO()
    sys.stderr = out
    function_debug.debug('test')
    sys.stderr.close()
    output = out.getvalue().strip()
    assert(output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test')

# Generated at 2022-06-24 05:45:04.130000
# Unit test for function debug_time
def test_debug_time():
    import time
    import os
    import io
    time.sleep(2)
    with io.open('/tmp/test_shell_log.txt', 'a', encoding='utf-8') as f:
        with debug_time('Message'):
            f.write(u'test message')
    assert 'Message took: 0:00:02' in open('/tmp/test_shell_log.txt').read()
    os.remove('/tmp/test_shell_log.txt')

# Generated at 2022-06-24 05:45:14.829434
# Unit test for function rule_failed
def test_rule_failed():
    import thefuck
    from thefuck.shells import Bash
    from thefuck.rules.fvwm import get_new_command

    def _call(name):
        return lambda *args, **kwargs: (name,)

    class TestRule(thefuck.rules.Rule):
        def match(self, **kwargs):
            return True

        @property
        def name(self):
            return 'TestRule'

    failed_rule = TestRule()

    failed_rule.get_new_command = _call('new_command')
    failed_rule.enabled_by_default = True

# Generated at 2022-06-24 05:45:16.241659
# Unit test for function version
def test_version():
    from .shells import Shell
    assert version('0.0.0', '2.7.8', Shell('fish').info) == \
        'The Fuck 0.0.0 using Python 2.7.8 and fish'

# Generated at 2022-06-24 05:45:19.038835
# Unit test for function exception
def test_exception():
    def _raise():
        raise ValueError('Test')

    try:
        _raise()
    except:
        exception(u'Rule test', sys.exc_info())

# Generated at 2022-06-24 05:45:23.376600
# Unit test for function configured_successfully
def test_configured_successfully():
    from .main import configuration_details
    assert "<class 'thefuck.shells.zsh.Zsh'>" in str(configuration_details).replace(" ", "").replace("'", "")


if __name__ == "__main__":
    test_configured_successfully()

# Generated at 2022-06-24 05:45:25.659582
# Unit test for function failed
def test_failed():
    assert failed('msg') == sys.stderr.write('\x1b[31mmsg\x1b[0m\n')

# Generated at 2022-06-24 05:45:29.074427
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = const.ConfigurationDetails(
        config_path=None,
        reload=None,
        can_configure_automatically=None)



# Generated at 2022-06-24 05:45:30.904463
# Unit test for function exception
def test_exception():
    try:
        int('fuck')
    except:
        exception(u'test', sys.exc_info())

# Generated at 2022-06-24 05:45:32.322169
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-24 05:45:34.085403
# Unit test for function already_configured
def test_already_configured():
    configuration_details = namedtuple('configuration_details',
                                       ['reload'])
    reload = 'test'
    msg = u'Seems like \x1b[1mfuck\x1b[22m alias already configured!'
    assert already_configured(configuration_details(reload)) == msg


# Generated at 2022-06-24 05:45:34.797803
# Unit test for function debug
def test_debug():
    assert debug('msg') == None



# Generated at 2022-06-24 05:45:40.956923
# Unit test for function rule_failed
def test_rule_failed():
    def mock_rule():
        class MockRule:
            name = 'test_rule'
        return MockRule()

    def mock_exc_info():
        return 'mock_exc_info', 'mock_exc_info', 'mock_exc_info'

    rule = mock_rule()
    exc_info = mock_exc_info()
    rule_failed(rule, exc_info)


# Generated at 2022-06-24 05:45:46.210224
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.main import corrected_command
    _execute = corrected_command.execute
    corrected_command.execute = lambda x: u''
    corrected_command = corrected_command(u'git pul', u'git pull', False)
    try:
        show_corrected_command(corrected_command)
    finally:
        corrected_command.execute = _execute

# Generated at 2022-06-24 05:45:48.048129
# Unit test for function version
def test_version():
    thefuck_version = '3.7'
    version(thefuck_version, '3.6', 'bash')

# Generated at 2022-06-24 05:45:49.451484
# Unit test for function configured_successfully
def test_configured_successfully():
    current_conf_dict = {'reload': 'reload'}
    configured_successfully(current_conf_dict)


# Generated at 2022-06-24 05:45:57.256460
# Unit test for function show_corrected_command
def test_show_corrected_command():
    def try_test(test_input, expected_result):
        show_corrected_command(test_input)
        assert open("test.txt", "r").read() == expected_result
    test_input = Command("ls -a", '', True)
    expected_result = "[!] ls -a (+side effect)\n"
    try_test(test_input, expected_result)
    test_input = Command("ls -a", '', False)
    expected_result = "[!] ls -a\n"
    try_test(test_input, expected_result)
    test_input = Command("ls -a", 'ls -a', True)
    expected_result = "[!] ls -a (+side effect)\n"
    try_test(test_input, expected_result)



# Generated at 2022-06-24 05:46:02.978142
# Unit test for function already_configured
def test_already_configured():
    print(
        u"Seems like {bold}fuck{reset} alias already configured!\n"
        u"For applying changes run {bold}{reload}{reset}"
        u" or restart your shell.".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            reload='fuck --reload'))


# Generated at 2022-06-24 05:46:06.610294
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    rule_ = rules.Rule('test123', lambda _: '', '', '', '', '')

# Generated at 2022-06-24 05:46:12.944830
# Unit test for function failed
def test_failed():
    class MockSysStderr(object):
        def __init__(self):
            self.result = None

        def write(self, text):
            self.result = text

    mock_sys_stderr = MockSysStderr()

    failed('some error')

    assert mock_sys_stderr.result == '\x1b[31msome error\x1b[0m\n'

# Generated at 2022-06-24 05:46:14.474764
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully('configuration_details')


# Generated at 2022-06-24 05:46:25.106045
# Unit test for function version
def test_version():
    def _version(argv):
        import sys
        from StringIO import StringIO
        from thefuck._version import __version__
        from thefuck.utils import version
        out = StringIO()
        sys.stderr = out
        sys.argv = argv
        version()
        out.seek(0)
        return out.read()

    # test without argv
    assert (
        _version([])
        == u'The Fuck {} using Python {} and {}\n'.format(
            __version__, sys.version, sys.platform))

    # test with --version as argv
    assert (
        _version(['script', '--version'])
        == u'The Fuck {} using Python {} and {}\n'.format(
            __version__, sys.version, sys.platform))

    # test with -v

# Generated at 2022-06-24 05:46:28.128419
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "ls"
    show_corrected_command(corrected_command)
    # Should return the command
    assert corrected_command == "ls"

# Generated at 2022-06-24 05:46:31.711347
# Unit test for function color
def test_color():
    assert color('Foo') == '\x1b[31mFoo\x1b[0m'
    assert color('Foo') == 'Foo'

# Generated at 2022-06-24 05:46:33.176217
# Unit test for function debug
def test_debug():
    with debug_time('test_debug'):
        print('test_debug')


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-24 05:46:34.896098
# Unit test for function configured_successfully
def test_configured_successfully():
    assert ('fuck alias configured successfully!\n'
            'For applying changes run toonarmy or restart your shell.' ==
            configured_successfully(configuration_details))


# Generated at 2022-06-24 05:46:41.495359
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch, call
    with patch('thefuck.shells.get_settings',
               return_value=settings._replace(debug=True)):
        with debug_time(u'Foo'):
            print('foo')
        calls = [call(u'Foo took: 0:00:00.000999')]
        with patch('thefuck.utils.datetime') as datetime, \
                patch('thefuck.utils.debug') as debug:
            datetime.now.side_effect = [
                datetime(1970, 1, 1),
                datetime(1970, 1, 1, 0, 0, 0, 1000)]
            with debug_time(u'Foo'):
                print('foo')

# Generated at 2022-06-24 05:46:43.422318
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    with debug_time('test'):
        assert True



# Generated at 2022-06-24 05:46:47.618458
# Unit test for function exception
def test_exception():
    def _exception(a):
        def _exception_raise():
            c = 1 / 0
        _exception_raise()
    try:
        _exception(2)
    except Exception:
        exception('test_exception', sys.exc_info())

if __name__ == '__main__':
    test_exception()

# Generated at 2022-06-24 05:46:56.611402
# Unit test for function failed
def test_failed():
    # Assume
    stderr = sys.stderr
    import StringIO
    sys.stderr = StringIO.StringIO()
    msg = u'В подушку рана'

    # When
    failed(msg)

    # Then
    sys.stderr.seek(0)
    assert list(sys.stderr) == ['\x1b[31m\x1b[1mВ подушку рана\x1b[0m\n']

    # Reset
    sys.stderr = stderr

# Generated at 2022-06-24 05:46:57.540705
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as x:
        assert x is None

# Generated at 2022-06-24 05:46:59.798223
# Unit test for function debug_time
def test_debug_time():
    with open("file", "w") as f:
        with debug_time("test_debug_time"):
            f.write("test")



# Generated at 2022-06-24 05:47:11.837053
# Unit test for function warn
def test_warn():
    from io import StringIO
    from textwrap import dedent

    stderr = StringIO()
    settings.no_colors = False
    settings.debug = True

    with stderr_redirector(stderr):
        warn('The world is going to end!')

    assert stderr.getvalue() == dedent("""
        [WARN] The world is going to end!
        """)[1:]

    settings.no_colors = True
    stderr = StringIO()

    with stderr_redirector(stderr):
        warn('The world is going to end!')

    settings.no_colors = False

    assert stderr.getvalue() == dedent("""
        [WARN] The world is going to end!
        """)[1:]



# Generated at 2022-06-24 05:47:15.265043
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime, timedelta

    @contextmanager
    def sleep():
        started = datetime.now()
        yield
        delta = datetime.now() - started

        assert delta > timedelta(seconds=1)

# Generated at 2022-06-24 05:47:17.726212
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    rule_failed(match, get_new_command)



# Generated at 2022-06-24 05:47:18.749228
# Unit test for function warn
def test_warn():
    warn("test")


# Generated at 2022-06-24 05:47:22.893306
# Unit test for function debug
def test_debug():
    from mock import patch, call
    with patch.object(sys.stderr, 'write') as write:
        debug('debug message')
        assert write.call_args_list == [call('debug message\n')]



# Generated at 2022-06-24 05:47:25.579097
# Unit test for function exception
def test_exception():
    class TestException(Exception):
        pass

    try:
        raise TestException()
    except TestException:
        exception(u'Test Exception', sys.exc_info())

# Generated at 2022-06-24 05:47:28.975605
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import CorrectedCommand
    corrected_command = CorrectedCommand(script='ls',
                                         side_effect=True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:47:31.732568
# Unit test for function debug_time
def test_debug_time():
    import pytest
    def my_func():
        import time
        time.sleep(1)
    with debug_time('test'):
        my_func()

# Generated at 2022-06-24 05:47:34.327376
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        configuration_details=const.ConfigurationDetails('', '', '', ''))

# Generated at 2022-06-24 05:47:36.543722
# Unit test for function configured_successfully
def test_configured_successfully():
    config_details = {'reload': 'reload', 'success': 'success'}
    assert configured_successfully(config_details) == config_details['reload']

# Generated at 2022-06-24 05:47:44.362806
# Unit test for function debug
def test_debug():
    from mock import patch, call

    with patch('sys.stderr', autospec=True) as stderr, \
            patch('thefuck.shells.get_shell',
                  autospec=True) as get_shell, \
            patch('thefuck.utils.settings', debug=True):
        with debug_time('test'):
            get_shell.return_value = ('zsh', '5.0.2')
            version('3.8', '2.7.10', 'zsh 5.0.2')

        stderr.write.assert_has_calls(
            [call(u'\u001b[34m\u001b[1mDEBUG:\u001b[0m test took: 0:00:00\n')])

# Generated at 2022-06-24 05:47:46.703812
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("logout") == "Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell."


# Generated at 2022-06-24 05:47:50.969469
# Unit test for function color
def test_color():
    """Test function color"""
    assert colorama.Fore.RED in color('red')
    assert colorama.Fore.RED not in color('red', no_colors=True)



# Generated at 2022-06-24 05:47:54.257645
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import get_new_command

    try:
        raise Exception('Failed')
    except:
        rule_failed(get_new_command, sys.exc_info())



# Generated at 2022-06-24 05:47:58.207209
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from mock import Mock
    from thefuck.types import CorrectedCommand
    mock_settings = Mock()
    settings.no_colors =False
    show_corrected_command(CorrectedCommand('some_command',False))
    assert settings.no_colors == False

# Generated at 2022-06-24 05:48:00.514117
# Unit test for function failed
def test_failed():
    sys.stderr = io.StringIO()
    failed('Test')
    assert sys.stderr.getvalue() == u'\x1b[41mTest\x1b[0m\n'



# Generated at 2022-06-24 05:48:09.145936
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from StringIO import StringIO
    old_stdout, old_stderr = sys.stdout, sys.stderr
    output = StringIO()
    try:
        sys.stdout, sys.stderr = output, output
        how_to_configure_alias(None)
        assert output.getvalue() == 'Seems like \x1b[1mfuck\x1b[0m alias isn\'t configured!\nMore details - https://github.com/nvbn/thefuck#manual-installation\n'
    finally:
        sys.stdout, sys.stderr = old_stdout, old_stderr
        output.close()

# Generated at 2022-06-24 05:48:17.302108
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert 'Seems like fuck alias isn\'t configured!' in how_to_configure_alias(None)
    assert 'Please put in your and apply changes with or restart your shell.' in how_to_configure_alias(None)
    assert 'Or run fuck a second time to configure it automatically.' in how_to_configure_alias(None)
    assert 'More details - https://github.com/nvbn/thefuck#manual-installation' in how_to_configure_alias(None)

# Generated at 2022-06-24 05:48:19.248816
# Unit test for function version
def test_version():
    assert version('test_version', 'test_python_version',
                   'test_shell_info') == None


# Generated at 2022-06-24 05:48:20.837957
# Unit test for function debug
def test_debug():
    assert 'DEBUG: test_msg' == debug('test_msg')

# Generated at 2022-06-24 05:48:23.569913
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    test_case = Command('ls ~', 'ls $HOME', side_effect=True)
    show_corrected_command(test_case)

# Generated at 2022-06-24 05:48:32.062555
# Unit test for function debug
def test_debug():
    from mock import patch
    from .conf import set_settings

    set_settings(verbose=True)
    debug('message')
    with patch('sys.stderr') as stderr_mock:
        reset = color(colorama.Style.RESET_ALL)
        stderr_mock.write.assert_called_once_with(
            u'{}DEBUG:{} message\n'.format(color(colorama.Fore.BLUE), reset))


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-24 05:48:33.100255
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully('2')


# Generated at 2022-06-24 05:48:37.243838
# Unit test for function failed
def test_failed():
    sys.stderr = open('test.log', 'w')
    failed("Lorem ipsum dolor")
    sys.stderr.close()
    assert open('test.log').read() == u'\x1b[31mLorem ipsum dolor\x1b[0m\n'

# Generated at 2022-06-24 05:48:43.322109
# Unit test for function rule_failed
def test_rule_failed():
    rule = type('Rule', (object,), {'name': 'name'})()
    exc_info = Exception, Exception(), None
    result = rule_failed(rule, exc_info)
    assert result == u'[WARN] Rule name:\nTraceback (most recent call last):\n\nTraceback (innermost last):\nNoneType: None\n\n[WARN] ----------------------------\n\n'


# Generated at 2022-06-24 05:48:48.144934
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = object()
    corrected_command.script = 'fuck'
    corrected_command.side_effect = True
    assert confirm_text(corrected_command) ==\
        '>fuck (+side effect) [enter/↑/↓/ctrl+c]'
    corrected_command.side_effect = False
    assert confirm_text(corrected_command) ==\
        '>fuck [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:48:50.004148
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('42') == '42'

# Generated at 2022-06-24 05:48:51.876763
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(u'echo test') == u'(!) echo test\n'

# Generated at 2022-06-24 05:48:55.727397
# Unit test for function exception
def test_exception():
    exc_info = None
    try:
        raise ValueError('test')
    except:
        exc_info = sys.exc_info()
    exception('exception', exc_info)



# Generated at 2022-06-24 05:49:01.517747
# Unit test for function debug_time
def test_debug_time():
    import mock
    with mock.patch('datetime.datetime') as datetime_mock:
        datetime_mock.now.return_value = datetime(2015, 4, 9, 19, 57, 10)
        with debug_time('Something') as timer:
            pass
        timer.assert_called_once_with()
        assert datetime_mock.now.call_count == 2

# Generated at 2022-06-24 05:49:02.513797
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(None)



# Generated at 2022-06-24 05:49:03.774451
# Unit test for function debug
def test_debug():
    # Test normal debug
    debug(u'Test')

# Generated at 2022-06-24 05:49:04.809552
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError(1)
    except RuntimeError as e:
        exception('testcase', sys.exc_info())



# Generated at 2022-06-24 05:49:08.476635
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    corrected_command = Command('ls', 'pwd')
    show_corrected_command(corrected_command)
    corrected_command = Command('ls', 'pwd', True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-24 05:49:09.656570
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('Rule test')


# Generated at 2022-06-24 05:49:15.528160
# Unit test for function failed
def test_failed():
    # Check message display
    failed_msg = "Test failed() function"
    failed(failed_msg)
    assert sys.stderr.getvalue() == u'{red}{msg}{reset}\n'.format(
            msg=failed_msg,
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:49:23.855091
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    sys.stderr = io.StringIO()
    show_corrected_command(const.CorrectedCommand('ls', True))
    output = sys.stderr.getvalue().strip()
    assert output == "> ls (+side effect)"
    sys.stderr.close()

    sys.stderr = io.StringIO()
    show_corrected_command(const.CorrectedCommand('ls', False))
    output = sys.stderr.getvalue().strip()
    assert output == "> ls"
    sys.stderr.close()


# Generated at 2022-06-24 05:49:28.099140
# Unit test for function warn
def test_warn():
    from mock import Mock
    sys.stderr = Mock()
    warn('mock warning')
    sys.stderr.write.assert_called_with(
        u'\x1b[41m\x1b[37m\x1b[1m[WARN] mock warning\x1b[0m\n')


# Generated at 2022-06-24 05:49:37.790932
# Unit test for function warn
def test_warn():
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        warn('hello')
    output = err.getvalue().strip()
    assert output == "[WARN] hello"

# Generated at 2022-06-24 05:49:43.144897
# Unit test for function rule_failed
def test_rule_failed():
    from thefuck.rules.angular import match, get_new_command
    from thefuck.shells import Bash
    rule = type('Rule', (object,), {
        'name': 'angular',
        'priority': 900,
        'match': staticmethod(match),
        'get_new_command': staticmethod(get_new_command)
    })()
    rule_failed(rule, (123, ))



# Generated at 2022-06-24 05:49:49.042396
# Unit test for function warn
def test_warn():
    sys.stderr.write(color(colorama.Back.RED + colorama.Fore.WHITE
                           + colorama.Style.BRIGHT))
    sys.stderr.write(color(colorama.Style.RESET_ALL))
    sys.stderr.write(color(colorama.Style.RESET_ALL) + "\n")
    pass



# Generated at 2022-06-24 05:49:56.600765
# Unit test for function confirm_text
def test_confirm_text():
    class CorrCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    confirm_text(CorrCommand("test", False))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))
    confirm_text(CorrCommand("test", True))

    #class CorrCommands(list):
    #    def __init__(self):
    #        super(CorrCommands

# Generated at 2022-06-24 05:49:59.067670
# Unit test for function color
def test_color():
    assert color('test') == ''
    settings.no_colors = False
    assert color('test') == 'test'



# Generated at 2022-06-24 05:50:02.896396
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time
    with mock.patch('sys.stderr') as stderr:
        with debug_time('TEST'):
            time.sleep(0.2)
        stderr.write.assert_called_with(mock.ANY)

# Generated at 2022-06-24 05:50:05.789532
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class A:
        path = '~/.bashrc'
        reload = 'source ~/.bashrc'
        content = 'thefuck'
        can_configure_automatically = False
    how_to_configure_alias(A)

# Generated at 2022-06-24 05:50:08.210609
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('bar') == ''

# Generated at 2022-06-24 05:50:18.961588
# Unit test for function exception
def test_exception():
    def f():
        raise ValueError('some message')

    try:
        f()
    except ValueError as e:
        exc_info = sys.exc_info()
    assert exception(
        u'Rule some_rule',
        exc_info
    ) == u'\x1b[41;37;1m[WARN] Rule some_rule:\x1b[0m\nTraceback (most recent call last):\n  File "tests/utils/log.py", line 20, in test_exception\n    f()\n  File "tests/utils/log.py", line 18, in f\n    raise ValueError(\'some message\')\nValueError: some message\n\x1b[41;37;1m----------------------------\x1b[0m\n\n'



# Generated at 2022-06-24 05:50:28.513983
# Unit test for function already_configured
def test_already_configured():
    from io import StringIO
    from colorama import init

    init(autoreset=True)
    text = StringIO()
    sys.stderr = text

    already_configured({
        'path': 'path',
        'reload': 'reload'
    })
    sys.stderr = sys.__stderr__
    assert text.getvalue() == (
        u"Seems like \x1b[1mfuck\x1b[0m alias already configured!\n"
        u"For applying changes run \x1b[1mreload\x1b[0m or restart your shell.\n")

# Generated at 2022-06-24 05:50:32.190050
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = command.Command('ls -la ~')
    assert confirm_text(corrected_command) == 'ls -la ~'


# Generated at 2022-06-24 05:50:41.811089
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    global print
    output = ''

    def print_in_test(msg):
        global output
        output += msg

    print = print_in_test
    how_to_configure_alias('alias fuck=\'eval $(thefuck $(fc -ln -1))\'')

    assert 'alias fuck' in output
    assert 'eval $(thefuck $(fc -ln -1))' in output

    output = ''
    debug = True
    how_to_configure_alias('alias fuck=\'eval $(thefuck $(fc -ln -1))\'')

    assert 'alias fuck' in output
    assert 'eval $(thefuck $(fc -ln -1))' in output
    assert 'More details - https://github.com/nvbn/thefuck#manual-installation' in output

    output = ''
    can_configure_aut

# Generated at 2022-06-24 05:50:53.609670
# Unit test for function debug
def test_debug():
    debug_message = 'Debug message'
    correct_result = (u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
        msg=debug_message,
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE),
        bold=color(colorama.Style.BRIGHT)))
    assert debug(debug_message) == correct_result
    assert debug(debug_message) > correct_result
    assert debug(debug_message) != correct_result
    assert debug(debug_message) < correct_result
    assert debug(debug_message) >= correct_result
    assert debug(debug_message) <= correct_result
    assert str(debug(debug_message)) == str(correct_result)

# Generated at 2022-06-24 05:50:56.395172
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'ls'
    confirm_text(corrected_command)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-24 05:50:58.546620
# Unit test for function exception
def test_exception():
    output = []
    exception(u'foo', ([], None, None))
    assert output == [u'foo']

# Generated at 2022-06-24 05:50:59.378101
# Unit test for function rule_failed
def test_rule_failed():
    assert rule_failed(True, (1, 2, 3)) == None

# Generated at 2022-06-24 05:51:00.553744
# Unit test for function debug
def test_debug():
    with debug_time('msg'):
        pass



# Generated at 2022-06-24 05:51:01.908998
# Unit test for function already_configured
def test_already_configured():
    assert already_configured([]) == 1


# Generated at 2022-06-24 05:51:05.179916
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -a'))



# Generated at 2022-06-24 05:51:15.123634
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    result = ''
    settings.side_effect = False
    result = confirm_text(object())
    assert result == ('\r\x1b[1K\x1b[1m\x1b[0m[\x1b[32menter\x1b[0m/'
                      '\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31m'
                      'ctrl+c\x1b[0m]')
    settings.side_effect = True
    result = confirm_text(object())

# Generated at 2022-06-24 05:51:24.226328
# Unit test for function debug
def test_debug():
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(mode='rb', delete=False) as debug_file, \
            settings.override(debug=True):
        debug_file_name = debug_file.name
        debug(u'Test')
        debug(u'')
        debug(u'     ')
        debug(u'string')
        debug_file.close()
        with open(debug_file_name, 'rb') as debug_file:
            debug_file_content = debug_file.read()

    assert u'string\n' == debug_file_content.decode('utf-8')

# Generated at 2022-06-24 05:51:27.265557
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'red') == '\x1b[31mred'
    colorama.init()
    assert color(colorama.Fore.RED + 'red') == 'red'

# Generated at 2022-06-24 05:51:29.993188
# Unit test for function color
def test_color():
    import colorama
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:51:30.825404
# Unit test for function debug
def test_debug():
    debug("test")

# Generated at 2022-06-24 05:51:40.531842
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output

    from .command import CorrectedCommand
    c = CorrectedCommand(u'git status', side_effect=False)
    show_corrected_command(c)
    assert (u"\u274c  git status" == output.getvalue())

    c = CorrectedCommand(u'git add', side_effect=True)
    show_corrected_command(c)
    assert (u"\u274c  git add (+side effect)" == output.getvalue())

    sys.stderr = sys.__stderr__



# Generated at 2022-06-24 05:51:43.849783
# Unit test for function warn
def test_warn():
    from StringIO import StringIO
    with StringIO() as buf:
        sys.stderr = buf
        warn('foo')
        assert 'foo' in buf.getvalue()


# Generated at 2022-06-24 05:51:46.924667
# Unit test for function confirm_text
def test_confirm_text():
    fake_command = type('CorrectedCommand', (object,), {
        'script': 'echo "test"',
        'side_effect': True
    })()
    confirm_text(fake_command)

# Generated at 2022-06-24 05:51:49.418538
# Unit test for function confirm_text
def test_confirm_text():
    from .main import UserAction

    confirm_text(UserAction('ls', '', 'ls'))
    confirm_text(UserAction('ls', '', 'ls'))

# Generated at 2022-06-24 05:51:54.076690
# Unit test for function warn
def test_warn():
    warn(u'Title')
    # AssertionError: u'\x1b[41m\x1b[37m\x1b[1m[WARN] Title\x1b[21m\x1b[0m\n' != u'[WARN] Title\n'



# Generated at 2022-06-24 05:52:02.649913
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    from .types import CorrectedCommand

    class Recording(object):
        def __init__(self):
            self.output = StringIO()

        def __enter__(self):
            self._stdout = sys.stdout
            self._stderr = sys.stderr
            sys.stdout = sys.stderr = self.output
            return self

        def __exit__(self, *args):
            self.output.seek(0)
            sys.stdout = self._stdout
            sys.stderr = self._stderr

    with Recording() as recording:
        failed(u'Test')

    assert '\n'.join([u'\x1b[31mTest\x1b[0m']) == recording.output.getvalue()



# Generated at 2022-06-24 05:52:06.249342
# Unit test for function already_configured
def test_already_configured():
    assertion = "Seems like fuck alias already configured!\nFor applying changes run source ~/.bashrc or restart your shell."
    assert assertion == already_configured(const.ConfigurationDetails(
        'source ~/.bashrc', '', '', True))



# Generated at 2022-06-24 05:52:08.864413
# Unit test for function rule_failed
def test_rule_failed():
    from . import rules
    rule_failed(rules.get_all(None)[0], (None, None, None))

if __name__ == '__main__':
    test_rule_failed()

# Generated at 2022-06-24 05:52:10.821412
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(u'ls') == 'ls'
    assert show_corrected_command(u'ls ') == 'ls'

# Generated at 2022-06-24 05:52:20.503260
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .types import Command

    # The command that was found is not the same as the actual command,
    # so the side effect is True
    corrected_command_1 = CorrectedCommand(Command('echo "foo bar"'),
                                           Command('echo "foo baz"'), True)
    show_corrected_command(corrected_command_1)
    assert sys.stderr.getvalue() == \
        '{prefix}echo "foo baz"{side_effect}\n'.format(
            prefix=const.USER_COMMAND_MARK,
            side_effect=' (+side effect)')

    # The command that was found is the same as the actual command,
    # so the side effect is False

# Generated at 2022-06-24 05:52:22.653244
# Unit test for function version
def test_version():
    version(
        thefuck_version='3.12',
        python_version='3.4',
        shell_info='bash'
    )



# Generated at 2022-06-24 05:52:31.346646
# Unit test for function already_configured
def test_already_configured():
    import tempfile
    import os
    import shutil

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a temporary file in that directory
    path = os.path.join(tmpdir, "tempfile")
    file = open(path, "wb")
    file.close()

    # write a test reload alias
    file = open(path, "wb")
    file.write('alias fuck=reload')
    file.close()

    # Assert we got the correct message
    assert 'Seems like fuck alias already configured!' in already_configured(path)

    # clean up the directory
    shutil.rmtree(tmpdir)

# Generated at 2022-06-24 05:52:38.504676
# Unit test for function version
def test_version():
    from . import __version__
    import sys
    from .shells import from_shell
    from . import python_version
    from mock import Mock
    shell_info = from_shell(Mock(name='proc', executable='shell'))
    version(__version__, python_version(), shell_info)
    assert sys.stderr.getvalue() == u'The Fuck {} using Python {} and {}\n'.format(__version__, python_version(), shell_info)