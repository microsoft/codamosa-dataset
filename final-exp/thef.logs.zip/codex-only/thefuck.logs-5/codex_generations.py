

# Generated at 2022-06-24 05:42:42.359480
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr = open('temp_out.txt', 'w')
    try:
        rule_failed('Test rule', 'Test exc_info')
        with open('temp_out.txt', 'r') as f:
            print(f.read())
    finally:
        sys.stderr.close()
        sys.stderr = sys.__stderr__

# Generated at 2022-06-24 05:42:47.722937
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from time import sleep
    from StringIO import StringIO

    out = StringIO()

    with debug_time('msg'):
        sleep(.5)

    assert '.5 seconds' in out.getvalue()

    with debug_time('msg'):
        sleep(.6)

    assert '.6 seconds' in out.getvalue()

    with debug_time('msg'):
        sleep(.7)

    assert '.7 seconds' in out.getvalue()

# Generated at 2022-06-24 05:42:48.892184
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert True # TODO: implement your test here



# Generated at 2022-06-24 05:42:51.217413
# Unit test for function exception
def test_exception():
    try:
        raise ValueError('test')
    except ValueError:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:42:54.902506
# Unit test for function already_configured
def test_already_configured():
    # Arrange
    details = settings.ConfigurationDetails(
        'source ~/.bashrc', '.bashrc', False)

    # Act
    already_configured(details)

    # Assert
    pass



# Generated at 2022-06-24 05:43:01.301211
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.Command('test', '', False)
    str_output = confirm_text(corrected_command)
    assert str_output ==  u'[!]:test [enter/↑/↓/ctrl+c]'
    corrected_command = const.Command('test', '', True)
    str_output = confirm_text(corrected_command)
    assert str_output == u'[!]:test (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-24 05:43:02.798702
# Unit test for function already_configured
def test_already_configured():
    already_configured({"reload": "reload"})



# Generated at 2022-06-24 05:43:04.195236
# Unit test for function warn
def test_warn():
    warn('Test title')
    warn(u'Test title')

# Generated at 2022-06-24 05:43:10.842614
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    stream = StringIO()
    sys.stderr, old_err = stream, sys.stderr
    try:
        failed(u'Привет')
    finally:
        sys.stderr = old_err
    assert stream.getvalue() == u'\x1b[31mПривет\x1b[0m\n'


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-24 05:43:15.314828
# Unit test for function failed
def test_failed():
    output = sys.stderr
    sys.stderr = StringIO()
    try:
        failed('test')
        assert sys.stderr.getvalue() == '\x1b[91mtest\x1b[0m\n'
    finally:
        sys.stderr = output

# Generated at 2022-06-24 05:43:21.086821
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Set to test without colors
    settings.no_colors = True
    command = 'git log'
    corrected_command = MockCommand(command)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == "%s%s\n" % (const.USER_COMMAND_MARK, command)


# Generated at 2022-06-24 05:43:27.796783
# Unit test for function debug_time
def test_debug_time():
    from contextlib import closing
    from io import StringIO
    from sys import stderr
    from time import sleep
    from . import log

    with closing(StringIO()) as out:
        with settings.save_stderr_into(out):
            with log.debug_time('X'):
                sleep(0.01)
            stderr.write('\n')
        assert out.getvalue() == 'X took: 0:00:00.010000\n\n'

# Generated at 2022-06-24 05:43:29.541604
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as timer:
        pass
    assert isinstance(timer, datetime)



# Generated at 2022-06-24 05:43:37.656246
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    import sys
    from thefuck.types import Command

    # We test sys.stderr.write, so we should save
    # stderr and replace it with StringIO object
    saved_stderr = sys.stderr

# Generated at 2022-06-24 05:43:40.485567
# Unit test for function color
def test_color():
    assert colorama.Fore.RED == color(colorama.Fore.RED)
    assert '' == color(colorama.Fore.RED)



# Generated at 2022-06-24 05:43:45.965068
# Unit test for function version
def test_version():
    import sys
    from StringIO import StringIO
    from thefuck.utils import version

    stream = StringIO()
    sys.stderr = stream
    version('thefuck_version', 'python_version', 'shell_info')
    assert stream.getvalue() == \
           u'The Fuck thefuck_version using Python python_version and shell_info\n'

# Generated at 2022-06-24 05:43:48.118576
# Unit test for function rule_failed
def test_rule_failed():
    global rule_failed
    rule_failed = lambda x, y: print(u"Rule " + x.name + " failed")

# Generated at 2022-06-24 05:43:52.725988
# Unit test for function version
def test_version():
    sys.stderr = StringIO.StringIO()
    version()
    sys.stderr.close()
    assert 'The Fuck' in sys.stderr.closed.getvalue()
    assert 'Python' in sys.stderr.closed.getvalue()
    assert 'SHELL' in sys.stderr.closed.getvalue()


# Generated at 2022-06-24 05:43:55.624203
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:43:56.800981
# Unit test for function exception
def test_exception():
    exception("Exception", sys.exc_info())

# Generated at 2022-06-24 05:44:00.106680
# Unit test for function already_configured
def test_already_configured():
    try:
        sys.stderr.write = lambda x: None
        already_configured(['test'])
    finally:
        sys.stderr.write = sys.__stderr__.write



# Generated at 2022-06-24 05:44:01.351085
# Unit test for function color
def test_color():
    assert color('test') == 'test'



# Generated at 2022-06-24 05:44:02.898256
# Unit test for function exception
def test_exception():
    try:
        int('df')
    except Exception:
        exc_info = sys.exc_info()
        exception(1, exc_info)

# Generated at 2022-06-24 05:44:10.126958
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import settings

    prev_debug = settings.DEBUG
    settings.DEBUG = True

    sys.stderr = StringIO()
    debug("foo bar")
    assert sys.stderr.getvalue() == (u"\x1b[94m\x1b[1mDEBUG:\x1b[0m foo bar\n")

    sys.stderr = StringIO()
    debug("foo %s %s", ("bar", "baz"))
    assert sys.stderr.getvalue() == (u"\x1b[94m\x1b[1mDEBUG:\x1b[0m foo bar baz\n")

    settings.DEBUG = False
    sys.stderr = StringIO()
    debug("foo bar")
    assert sys.stderr.get

# Generated at 2022-06-24 05:44:12.276842
# Unit test for function exception
def test_exception():
    try:
        1/0
    except ZeroDivisionError:
        exception('test1', sys.exc_info())
test_exception()

# Generated at 2022-06-24 05:44:13.370568
# Unit test for function warn
def test_warn():
    warn('test')



# Generated at 2022-06-24 05:44:15.117408
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('Test message')
    settings.debug = False
    debug('Test message')

# Generated at 2022-06-24 05:44:20.149726
# Unit test for function already_configured
def test_already_configured():
    from click.testing import CliRunner
    from .main import main
    from . import __version__

    runner = CliRunner()
    result = runner.invoke(main, ['--version'])

    assert result.exception is None
    assert u'The Fuck {} using Python'.format(__version__) in result.output
    assert result.exit_code == 0



# Generated at 2022-06-24 05:44:26.770637
# Unit test for function failed
def test_failed():
    import io
    sys_stderr = sys.stderr
    sys.stderr = io.StringIO()
    failed_msg = 'foo'
    failed(failed_msg)
    current_msg = sys.stderr.getvalue()
    expected_msg = u'{red}{msg}{reset}\n'.format(
        msg=failed_msg,
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))
    sys.stderr = sys_stderr
    assert current_msg == expected_msg

# Generated at 2022-06-24 05:44:29.461563
# Unit test for function color
def test_color():
    assert color(u'foo') == u''

    settings.no_colors = False
    assert color(u'foo') == u'foo'

# Generated at 2022-06-24 05:44:31.170790
# Unit test for function debug_time
def test_debug_time():
    with debug_time('testing debud_time'):
        print('test')


# Generated at 2022-06-24 05:44:36.775497
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(
            {'path': u'/home/nvbn/.bashrc', 'reload': u'source /home/nvbn/.bashrc'}
    ) == u"Seems like \x1b[1mfuck\x1b[21m alias already configured!\nFor applying changes run \x1b[1msource /home/nvbn/.bashrc\x1b[21m or restart your shell."


# Generated at 2022-06-24 05:44:38.130420
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    with debug_time('test_debug_time'):
        sleep(1)

# Generated at 2022-06-24 05:44:39.939536
# Unit test for function color
def test_color():
    assert color('') == settings.no_colors
    settings.no_colors = True
    assert color('red') == ''
    settings.no_colors = False

# Generated at 2022-06-24 05:44:43.088925
# Unit test for function configured_successfully
def test_configured_successfully():
    config_detail = {'reload': 'reload', 'conf_file': 'conf_file'}
    assert configured_successfully(config_detail) == u'test'


# Generated at 2022-06-24 05:44:46.147292
# Unit test for function exception
def test_exception():
    """Module can be executed"""
    def raise_exception():
        raise Exception('test')
    try:
        raise_exception()
    except Exception:
        exception('Function raise_exception', sys.exc_info())

# Generated at 2022-06-24 05:44:48.017617
# Unit test for function warn
def test_warn():
    assert warn("FAILED.") == "[WARN] FAILED.\n"

# Generated at 2022-06-24 05:44:50.050204
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    configuration_details = Shell.from_shell(
        'bash').get_alias(settings)
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-24 05:44:59.177832
# Unit test for function how_to_configure_alias

# Generated at 2022-06-24 05:45:01.356658
# Unit test for function rule_failed
def test_rule_failed():
    from .rules.echo import match, get_new_command
    rule_failed(match, get_new_command)



# Generated at 2022-06-24 05:45:02.791890
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed('Rule', '')



# Generated at 2022-06-24 05:45:09.571137
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    from .correct import CorrectedCommand

    test_command = CorrectedCommand('ls')

    capturedOutput = io.StringIO()
    sys.stdout = capturedOutput

    show_corrected_command(test_command)
    sys.stdout = sys.__stdout__

    assert capturedOutput.getvalue() == u'{}ls\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-24 05:45:11.916333
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED + colorama.Style.BRIGHT) == \
        colorama.Fore.RED + colorama.Style.BRIGHT

    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    assert color(colorama.Fore.RED + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-24 05:45:15.204895
# Unit test for function failed
def test_failed():
    msg = u'Привет'
    assert failed(msg) == sys.stderr.write(u'\x1b[91mПривет\x1b[0m\n')

# Generated at 2022-06-24 05:45:18.599336
# Unit test for function debug_time
def test_debug_time():
    debug_time('test1')
    debug('test2')
    debug('test3')
    with debug_time('test4'):
        debug('test5')
    debug('test6')

# Generated at 2022-06-24 05:45:22.291678
# Unit test for function configured_successfully
def test_configured_successfully():
    configuration_details = settings.Config('source $ZDOTDIR/.bashrc',
                                            '.zshrc',
                                            'source .zshrc',
                                            True)
    configured_successfully(configuration_details)



# Generated at 2022-06-24 05:45:24.677469
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == '\x1b[31m'
    assert color(colorama.Fore.RED) == ''



# Generated at 2022-06-24 05:45:27.253997
# Unit test for function warn
def test_warn():
    warn('title')

    from .conf import settings
    settings.no_colors = True
    warn('title')

# Generated at 2022-06-24 05:45:29.592744
# Unit test for function exception
def test_exception():
    try:
        raise RuntimeError('foo')
    except RuntimeError:
        exception('test', sys.exc_info())


# Generated at 2022-06-24 05:45:38.267412
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails
    from .utils import unicode_escape
    from .shells import _get_shell_info


# Generated at 2022-06-24 05:45:40.581551
# Unit test for function exception
def test_exception():
    try:
        raise Exception('lol')
    except Exception:
        exception('This is a title', sys.exc_info())

# Generated at 2022-06-24 05:45:47.555119
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    buf = StringIO()
    orig_output = sys.stderr
    sys.stderr = buf

    try:
        debug(u'привет')
        sys.stderr.seek(0)
        assert buf.readlines() == [u'\x1b[34m\x1b[1mDEBUG:\x1b[0m привет\n']
    finally:
        sys.stderr = orig_output

# Generated at 2022-06-24 05:45:57.271727
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command
    current_command = Command('cd ..', './', ['./', '/home/paul/'])
    show_corrected_command(current_command)

    # Unit test for function debug
    def test_debug():
        debug("debug")

    # Unit test for function warn
    def test_warn():
        warn("title")

    # Unit test for function exception
    def test_exception():
        exception("title", [])

    # Unit test for function rule_failed
    def test_rule_failed():
        def called():
            pass
        rule_failed(called, [])

    # Unit test for function failed
    def test_failed():
        failed("msg")

    # Unit test for function confirm_text

# Generated at 2022-06-24 05:46:02.132534
# Unit test for function failed
def test_failed():
    test_msg = "Test message"
    failed(test_msg)
    assert sys.stderr.getvalue() == u'{red}{msg}{reset}\n'.format(
        msg=test_msg,
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-24 05:46:04.848806
# Unit test for function failed
def test_failed():
    failed('test')
    assert sys.stderr.getvalue() == u'\x1b[31mtest\x1b[0m\n'



# Generated at 2022-06-24 05:46:08.989415
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    mock_settings = Mock()
    global settings
    settings = mock_settings
    settings.debug = True
    global debug
    debug = Mock()
    with debug_time('foo'):
        pass
    assert debug.called
    assert debug.call_args[0][0] == u'foo took: {}'.format(timedelta(seconds=0))

# Generated at 2022-06-24 05:46:16.023370
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import sys
    from cStringIO import StringIO

    saved_sys_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out

        @debug_time('Test')
        def test():
            datetime.now()

        test()

        assert 'DEBUG: Test took: 0:00:00.000' in out.getvalue()
    finally:
        sys.stderr = saved_sys_stderr

# Generated at 2022-06-24 05:46:21.331515
# Unit test for function already_configured
def test_already_configured():
    assert already_configured() == u"Seems like {bold}fuck{reset} alias already configured!\nFor applying changes run {bold}{reload}{reset} or restart your shell.".format(bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL), reload=configuration_details.reload).format()


# Generated at 2022-06-24 05:46:22.755440
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(
       None)


# Generated at 2022-06-24 05:46:24.771466
# Unit test for function failed
def test_failed():
    import sys
    sys.stderr = sys.stdout  # Redirect output.
    failed('Test message')
    assert sys.stdout.getvalue() == u'\x1b[31mTest message\x1b[0m\n'

# Generated at 2022-06-24 05:46:26.372630
# Unit test for function warn
def test_warn():
    warn(u'test')



# Generated at 2022-06-24 05:46:28.719106
# Unit test for function version
def test_version():
    assert version('1.2', '3.5', 'bash') ==\
           u'The Fuck 1.2 using Python 3.5 and bash'

# Generated at 2022-06-24 05:46:33.511730
# Unit test for function failed
def test_failed():
    from thefuck import logs
    from thefuck.utils import text_type

    logs.failed(u'Vim is not compatible with readline')
    logs.failed(u'Vim')

    logs.failed(u'Vim is not compatible with readline')
    logs.failed(text_type('no converted'))

# Generated at 2022-06-24 05:46:37.814848
# Unit test for function debug_time
def test_debug_time():
    import datetime
    from time import sleep
    from StringIO import StringIO
    from mock import patch

    with patch('sys.stderr', new=StringIO()) as fake_out:
        with debug_time('test'):
            sleep(0.5)
        assert u'test took: 0:00:00.5' in fake_out.getvalue()

# Generated at 2022-06-24 05:46:41.366383
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from io import BytesIO

    @contextmanager
    def debug_output():
        stderr = sys.stderr
        try:
            sys.stderr = BytesIO()
            yield sys.stderr
        finally:
            sys.stderr = stderr

    with debug_output() as debug_stderr:
        debug('Message')
    assert 'DEBUG: Message\n' == debug_stderr.getvalue()

# Generated at 2022-06-24 05:46:47.064105
# Unit test for function rule_failed
def test_rule_failed():
    class rule:
        pass
    rule.name = 'test_rule'
    assert rule_failed(rule, None).encode('utf-8') == '\x1b[107m\x1b[30m\x1b[1m[WARN] Rule test_rule:\x1b[0m\n\x1b[1m\x1b[107m\x1b[30m----------------------------\x1b[0m\n\n'

# Generated at 2022-06-24 05:46:50.135461
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(
            const.Command(
                script=u'git status', side_effect=True,
                pipe=False, stdin=False))



# Generated at 2022-06-24 05:46:55.372901
# Unit test for function debug
def test_debug():
    debug(u"my debug message")
    assert sys.stderr.getvalue() == (
        u'{blue}{bold}DEBUG:{reset} my debug message\n'.format(
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL)))



# Generated at 2022-06-24 05:47:00.397865
# Unit test for function configured_successfully
def test_configured_successfully():
    with open('test.txt', 'w') as f:
        from .conf.const import RELOAD_COMMAND
        from .utils import ReprObj
        config_details = ReprObj(reload=RELOAD_COMMAND)
        configured_successfully(config_details)
        write_line = f.readline()
        assert write_line == "[WARN] The Fuck 3.14 using Python 2 and fish +\n"

# Generated at 2022-06-24 05:47:01.449755
# Unit test for function already_configured
def test_already_configured():
    assert already_configured({'reload':''})

# Generated at 2022-06-24 05:47:05.640003
# Unit test for function rule_failed
def test_rule_failed():
    rule = "rule"
    exc_info = "exc_info"
    output = rule_failed(rule, exc_info)
    assert "Rule " in output
    assert str(rule) in output
    assert str(exc_info) in output

# Generated at 2022-06-24 05:47:16.106544
# Unit test for function version
def test_version():
    import os
    import platform
    import subprocess
    import uuid
    import tempfile
    import shutil

    def _make_temp_executable(prefix):
        with tempfile.NamedTemporaryFile(prefix='_thefuck_test_' + prefix,
                                         delete=False) as f:
            f.write("#! /bin/sh\necho $0 $1\n")
        os.chmod(f.name, 0o755)
        return f.name

    def _make_temp_config(prefix, content):
        with tempfile.NamedTemporaryFile(prefix='_thefuck_test_' + prefix,
                                         delete=False) as f:
            f.write(content)
        return f.name


# Generated at 2022-06-24 05:47:19.065145
# Unit test for function already_configured
def test_already_configured():
    res = already_configured("test_configuration_details")
    assert res == None

if __name__ == '__main__':
    test_already_configured()

# Generated at 2022-06-24 05:47:27.690101
# Unit test for function exception
def test_exception():
    title = u'Title'
    try:
        raise Exception('msg')
    except:
        expected = (u'\x1b[41m\x1b[37m\x1b[1m[WARN] Title:\x1b[0m\n'
                    u'Traceback (most recent call last):\n'
                    u'  File "test.py", line 1, in <module>\n'
                    u"    raise Exception('msg')\n"
                    u'Exception: msg\n\n')

        exception(title, sys.exc_info())
        assert sys.stderr.getvalue() == expected



# Generated at 2022-06-24 05:47:32.617742
# Unit test for function confirm_text
def test_confirm_text():
    import colorama
    colorama.init()
    try:
        from mock import Mock
        Application = Mock
        corrected_command = Application.CorrectedCommand(
            Mock(script='script'),
            side_effect=False)
        confirm_text(corrected_command)
    finally:
        colorama.deinit()

# Generated at 2022-06-24 05:47:33.686499
# Unit test for function warn
def test_warn():
    warn('abc')

# Generated at 2022-06-24 05:47:34.721318
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'fuck'

# Generated at 2022-06-24 05:47:38.114451
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    with mock.patch('builtins.print') as p:
        with debug_time('msg'):
            time.sleep(.01)
        assert p.call_args[0][0] == 'msg took: 0:00:00.010222'

# Generated at 2022-06-24 05:47:39.820518
# Unit test for function rule_failed
def test_rule_failed():
    rule = 'rule'
    exc_info = 'exc_info'
    rule_failed(rule, exc_info)

# Generated at 2022-06-24 05:47:46.923587
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """Test how_to_configure_alias() function.

    Returns:
        (bool): Return True if message is printed out.
    """
    old_stdout = sys.stdout
    sys.stdout = result = StringIO()
    how_to_configure_alias(None)
    sys.stdout = old_stdout

    assert "Seems like fuck alias isn't configured!" in result.getvalue()
    assert "More details - https://github.com/nvbn/thefuck#manual-installation" in result.getvalue()



# Generated at 2022-06-24 05:47:50.566326
# Unit test for function configured_successfully
def test_configured_successfully():
    assert configured_successfully(
        configuration_details=const.ConfigurationDetails(
            path='foo',
            content='bar',
            reload='baz')) == None


# Generated at 2022-06-24 05:47:54.720854
# Unit test for function rule_failed
def test_rule_failed():
    sys.stderr = open('test_rule_failed', 'w')
    rule_failed('Rule')
    with open('test_rule_failed') as test_rule_file:
        assert 'Rule' in test_rule_file.read()


# Generated at 2022-06-24 05:47:55.804017
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-24 05:47:59.654029
# Unit test for function failed
def test_failed():
    result = sys.stderr.read()
    assert result == '{red}{msg}{reset}\n'.format(
        msg=u'msg',
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL))

# Generated at 2022-06-24 05:48:04.140958
# Unit test for function failed
def test_failed():
    import io
    stream = io.StringIO()
    sys.stderr = stream
    failed(u'test')
    assert u'\x1b[31mtest\x1b[0m\n' == stream.getvalue()



# Generated at 2022-06-24 05:48:07.126335
# Unit test for function warn
def test_warn():
    assert warn('fuck') == u'\x1b[41m\x1b[37m\x1b[1m[WARN] fuck\x1b[0m\n'



# Generated at 2022-06-24 05:48:13.190701
# Unit test for function warn
def test_warn():
    warn("Title")
    assert sys.stderr.getvalue() == u'\x1b[41m\x1b[37m\x1b[1m' \
        '[WARN] Title\x1b[0m\n'


# Generated at 2022-06-24 05:48:15.408754
# Unit test for function failed
def test_failed():
    from cStringIO import StringIO
    out = StringIO()
    err = StringIO()
    sys.stdout = out
    sys.stderr = err
    failed('abc')
    assert u'abc' in err.getvalue()


# Generated at 2022-06-24 05:48:20.017496
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand():
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect
    show_corrected_command(CorrectedCommand("foo"))
    show_corrected_command(CorrectedCommand("foo", True))



# Generated at 2022-06-24 05:48:24.287942
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT not in color(colorama.Style.BRIGHT)

    colorama.init(strip=True)
    settings.no_colors = True
    assert colorama.Style.BRIGHT not in color(colorama.Style.BRIGHT)

# Generated at 2022-06-24 05:48:29.849843
# Unit test for function exception
def test_exception():
    sys.stderr = StringIO()
    try:
        raise Exception('Expected')
    except:
        exception('Title', sys.exc_info())
    output = sys.stderr.getvalue()

    assert '[WARN] Title:' in output
    assert 'Traceback' in output
    assert 'Expected' in output



# Generated at 2022-06-24 05:48:32.109429
# Unit test for function version
def test_version():
    version('3.13.37', '3.3.3', 'bash 4.4.19(1)-release')



# Generated at 2022-06-24 05:48:34.776995
# Unit test for function already_configured
def test_already_configured():
    assert already_configured("") == [u"Seems like {bold}fuck{reset} alias already configured!\n",
                              u"For applying changes run {bold}{reload}{reset}"]

# Generated at 2022-06-24 05:48:36.286968
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    corrected_command = CorrectedCommand('fuck', False)
    show_corrected_command(corrected_command)



# Generated at 2022-06-24 05:48:40.118937
# Unit test for function debug
def test_debug():
    """Test for 'debug' function

    Arguments:
    debug is a function for display debug message

    Returns:
    None

    """

    debug("test_debug")


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-24 05:48:41.470404
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('git branch')



# Generated at 2022-06-24 05:48:49.759418
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    the_fuck_path = ("/home/nvbn/.local/share/thefuck/thefuck")
    configuration_details = const.CONFIGURATION_DETAILS(
        can_configure_automatically=True,
        content="eval $(thefuck --alias)",
        path=the_fuck_path,
        reload="source ~/.bashrc")

# Generated at 2022-06-24 05:48:51.578732
# Unit test for function exception
def test_exception():
    try:
        1 / 0
    except:
        exception('test', sys.exc_info())


# Generated at 2022-06-24 05:48:58.361749
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(
        configuration_details=None
    )
    how_to_configure_alias(
        configuration_details=None
    )
    how_to_configure_alias(
        configuration_details=None
    )
    how_to_configure_alias(
        configuration_details=None
    )
    how_to_configure_alias(
        configuration_details=None
    )

# Generated at 2022-06-24 05:48:58.972588
# Unit test for function version
def test_version():
    pass



# Generated at 2022-06-24 05:49:00.000848
# Unit test for function already_configured
def test_already_configured():
    assert(already_configured(None))

# Generated at 2022-06-24 05:49:06.134316
# Unit test for function debug_time
def test_debug_time():

    def test():
        with debug_time('test started'):
            pass

    if hasattr(test_debug_time, 'assert_called_with'):
        with settings(debug=True):
            with patch('sys.stderr.write') as write:
                test()
                assert_called_with(
                    write,
                    u'test started took: 0:00:00.00000\n'.format(
                        time=datetime.now()))

# Generated at 2022-06-24 05:49:11.405499
# Unit test for function version
def test_version():
    assert version('v1.2.3', 'v2.7.6', 'Shell v3.4.5') == \
        u'The Fuck v1.2.3 using Python v2.7.6 and Shell v3.4.5\n'
    assert version('v1.2.3', 'v2.7.6', 'Shell v3.4.5') != \
        u'The Fuck v1.2.3 using Python v2.7.6 and Shell v3.4.5'


# Generated at 2022-06-24 05:49:13.087806
# Unit test for function debug_time
def test_debug_time():
    assert settings.debug == True
    with debug_time('func name'):
        pass

# Generated at 2022-06-24 05:49:15.947868
# Unit test for function exception
def test_exception():
    try:
        a = 1 / 0
    except Exception:
        exc_info = sys.exc_info()
        exception('Testing', exc_info)
    finally:
        assert True

# Generated at 2022-06-24 05:49:21.393001
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class TestConfigureDetails(object):
        def _asdict(self):
            return {
                'can_configure_automatically': True,
                'content': 'foo',
                'path': 'bar',
                'reload': 'baz'
            }

    assert how_to_configure_alias(TestConfigureDetails()) == None



# Generated at 2022-06-24 05:49:26.122550
# Unit test for function failed
def test_failed():
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    failed(u'failed')
    sys.stderr = sys.__stderr__
    assert out.getvalue() == u'\x1b[31mfailed\x1b[0m\n'



# Generated at 2022-06-24 05:49:27.627177
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command='echo "1"')



# Generated at 2022-06-24 05:49:31.270967
# Unit test for function debug_time
def test_debug_time():
    # TODO: expand testing
    @contextmanager
    def log_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.now() - started))

    with log_time('log_time'):
        pass

# Generated at 2022-06-24 05:49:38.896269
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u'\n')
    sys.stderr.write(u'>>> show_corrected_command\n')
    sys.stderr.write(u'\n')

    from . import types
    import datetime
    corrected_command = types.CorrectedCommand(script='ls',
                                               side_effect=False,
                                               created_at=datetime.datetime.now())
    show_corrected_command(corrected_command)



# Generated at 2022-06-24 05:49:43.614340
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import sys
    import tempfile
    from mock import patch


# Generated at 2022-06-24 05:49:49.041510
# Unit test for function debug
def test_debug():
    import StringIO
    f = StringIO.StringIO()
    sys.stderr = f
    debug(u'Debug message')
    sys.stderr = sys.__stderr__
    assert u'DEBUG: Debug message' in f.getvalue()
    assert u'\033[34m\033[1mDEBUG' in f.getvalue()

# Generated at 2022-06-24 05:49:50.546006
# Unit test for function exception
def test_exception():
    exception('title', (1, 2, 3))

# Generated at 2022-06-24 05:49:59.406433
# Unit test for function confirm_text
def test_confirm_text():

    import sys

    # sys.stdout = open('test.txt', 'w')  # open file in writting mode
    # sys.stderr = open('test.txt', 'w')  # open file in writting mode

    confirm_text('mount')
    # print(u'{red}Testing{reset}'.format(
    #     red=color(colorama.Fore.RED),
    #     reset=color(colorama.Style.RESET_ALL)))
    # print(color(colorama.Fore.RED))

    # sys.stdout.close()  # Close opened file

# Generated at 2022-06-24 05:50:05.205875
# Unit test for function configured_successfully
def test_configured_successfully():
    assert (u"{bold}fuck{reset} alias configured successfully!\n"
            u"For applying changes run {bold}{reload}{reset}"
            u" or restart your shell.").format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                reload='source ~/.zshrc') == configured_successfully(
                    configuration_details=configuration_details('~/.zshrc'))



# Generated at 2022-06-24 05:50:06.012073
# Unit test for function failed
def test_failed():
    assert failed('test') == 'test'

# Generated at 2022-06-24 05:50:14.919045
# Unit test for function rule_failed
def test_rule_failed():
    class Rule(object):
        def __init__(self, name):
            self.name = name
    rule1 = Rule("test rule")
    rule2 = Rule("test rule2")
    exc_info1 = (Exception("test exception"), None, None)
    exc_info2 = (Exception("test exception2"), None, None)
    sys.stderr = open("test_rule_failed", "w")
    rule_failed(rule1, exc_info1)
    rule_failed(rule2, exc_info2)



# Generated at 2022-06-24 05:50:16.792139
# Unit test for function exception
def test_exception():
    try:
        raise Exception()
    except:
        exception('test', sys.exc_info())



# Generated at 2022-06-24 05:50:22.649882
# Unit test for function debug
def test_debug():
    import StringIO
    sys.stderr = StringIO.StringIO()
    debug('debug message')
    assert sys.stderr.getvalue().startswith('\x1b[34m\x1b[1mDEBUG:\x1b[0m debug message\n')
    sys.stderr = sys.__stderr__


# Generated at 2022-06-24 05:50:24.269571
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'TEST'):
        pass

# Generated at 2022-06-24 05:50:32.881186
# Unit test for function configured_successfully
def test_configured_successfully():
    from StringIO import StringIO
    config_out = StringIO()


# Generated at 2022-06-24 05:50:40.683960
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        # Modified sys.stderr for test
        sys.stderr = open('test_show_corrected_command', 'w')
        from .corrector import CorrectedCommand
        show_corrected_command(CorrectedCommand('script',
                                                'side effect'))
        # Checking result with expected
        result = open('test_show_corrected_command', 'r').read()
        expected = u' => script (+side effect)\n'
        assert result == expected
    finally:
        sys.stderr.close()
        import os
        os.remove('test_show_corrected_command')



# Generated at 2022-06-24 05:50:44.231749
# Unit test for function warn
def test_warn():
    from . import tests_utils
    with tests_utils.mock_output() as (stdout, stderr):
        warn('title')

    assert stderr.getvalue() == '\x1b[41m\x1b[37m\x1b[1m[WARN] title\x1b[0m\n'

# Generated at 2022-06-24 05:50:49.406626
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('\x1b[1;31m') != '\x1b[1;31m'
    settings.no_colors = False
    assert color('\x1b[1;31m') == '\x1b[1;31m'
    settings.no_colors = True



# Generated at 2022-06-24 05:51:00.404479
# Unit test for function exception
def test_exception():
    import StringIO

    from .utils import _StderrFilter

    test_exception_text = u'test exception'
    exc_info = (Exception, Exception(test_exception_text), None)

    with _StderrFilter() as stderr:
        exception(u'test', exc_info)

    output = stderr.getvalue().splitlines()

    assert output[0] == u'\x1b[41m\x1b[37m\x1b[1m[WARN] test:\x1b[0m'
    assert output[2] == u'\x1b[41m\x1b[37m\x1b[1m----------------------------\x1b[0m'

# Generated at 2022-06-24 05:51:04.116613
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Bash, Fish

    how_to_configure_alias(Bash)
    how_to_configure_alias(Fish)
    how_to_configure_alias(None)



# Generated at 2022-06-24 05:51:14.464293
# Unit test for function exception

# Generated at 2022-06-24 05:51:16.393751
# Unit test for function rule_failed
def test_rule_failed():
    assert rule_failed('autoflake', (Exception, Exception('boom'), None)) == None


# Generated at 2022-06-24 05:51:20.137905
# Unit test for function rule_failed
def test_rule_failed():

    class Test:
        def __init__(self, name):
            self.name = name
        def __str__(self):
            return str(self.name)

    testRule = Test("rule")

    rule_failed(testRule, "msg")

# Generated at 2022-06-24 05:51:21.731812
# Unit test for function warn
def test_warn():
    warn(u'Hello') == u'[WARN] Hello\n'


# Generated at 2022-06-24 05:51:26.309647
# Unit test for function confirm_text
def test_confirm_text():
    config._get_default_settings()
    confirm_text(ConfirmedCommand('ls | grep', 'ls | grep app'))
    config._get_default_settings()
    config._settings.no_colors = True
    confirm_text(ConfirmedCommand('ls | grep', 'ls | grep app'))


# Generated at 2022-06-24 05:51:26.877716
# Unit test for function configured_successfully
def test_configured_successfully():
    configured_successfully()

# Generated at 2022-06-24 05:51:29.314178
# Unit test for function rule_failed
def test_rule_failed():
    from .rules import Command
    from .rules.correct_cd import match, get_new_command
    rule = Command('cd', 'cd --',
                   match=match,
                   get_new_command=get_new_command,
                   side_effect=False)
    try:
        raise RuntimeError()
    except Exception:
        exc_info = sys.exc_info()
        rule_failed(rule, exc_info)

# Generated at 2022-06-24 05:51:32.709410
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug('Hello world')
        assert False
    except AssertionError:
        assert True
    settings.debug = False



# Generated at 2022-06-24 05:51:41.443018
# Unit test for function debug_time
def test_debug_time():
    """
    If a function called inside debug_time takes longer than 100 microseconds,
    then unit test should pass.
    """
    from datetime import timedelta

    @contextmanager
    def _debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, datetime.now() - started))

    with _debug_time("test_debug_time"):
        pass

    with _debug_time("test_debug_time"):
        time.sleep(0.0001)

    assert True

# Generated at 2022-06-24 05:51:43.806764
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-24 05:51:44.783157
# Unit test for function color
def test_color():
    assert color('some color') == ''



# Generated at 2022-06-24 05:51:45.321723
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-24 05:51:47.689688
# Unit test for function version
def test_version():
    assert version('3.3', '3.3', 'bash') == 'The Fuck 3.3 using Python 3.3 and bash\n'

# Generated at 2022-06-24 05:51:49.085290
# Unit test for function rule_failed
def test_rule_failed():
    rule_failed("rule name", "exc_info")



# Generated at 2022-06-24 05:51:50.369028
# Unit test for function already_configured
def test_already_configured():
    assert already_configured(configuration_details=None) == None


# Generated at 2022-06-24 05:51:52.685355
# Unit test for function already_configured
def test_already_configured():
    output = sys.stderr.write
    assert 'fuck' in already_configured({'reload': 'reload'})



# Generated at 2022-06-24 05:52:02.017352
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from unittest import mock
    from thefuck.utils import ConfigurationDetails
    mock_print = mock.Mock()

# Generated at 2022-06-24 05:52:05.087456
# Unit test for function rule_failed
def test_rule_failed():
    """
    :return: If the function does not show any errors it returns true, else it returns false.
    """
    try:
        rule_failed("rule", (IndexError, IndexError("list index out of range"), None))
    except Exception:
        return False
    return True

# Generated at 2022-06-24 05:52:05.564037
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass

# Generated at 2022-06-24 05:52:06.845586
# Unit test for function exception
def test_exception():
    exception('Test', ('Test', None, None))



# Generated at 2022-06-24 05:52:07.737572
# Unit test for function warn
def test_warn():
    warn('title')



# Generated at 2022-06-24 05:52:10.744387
# Unit test for function debug_time
def test_debug_time():
    old_debug = settings.debug
    try:
        settings.debug = True
        with debug_time('wait'):
            import time
            time.sleep(1.5)
    finally:
        settings.debug = old_debug

# Generated at 2022-06-24 05:52:17.542857
# Unit test for function confirm_text

# Generated at 2022-06-24 05:52:19.261151
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'lsc'
    assert 'lsc' == corrected_command


# Generated at 2022-06-24 05:52:28.941859
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file_name = temp_file.name
    temp_file.file.write(u'import sys\n\nprint "Hello World"\n')
    temp_file.close()

    out, err = execute(u'PYTHONIOENCODING={} python {}'.format(
        sys.stdout.encoding, temp_file_name))

    os.remove(temp_file_name)


# Generated at 2022-06-24 05:52:30.250920
# Unit test for function debug
def test_debug():
    debug('test_debug')
    debug_time('test_debug_time')
    with debug_time('test_debug_time'):
        print('test')

# Generated at 2022-06-24 05:52:32.797714
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    assert color('foo') != ''
    with settings(no_colors=True):
        assert color('foo') == ''



# Generated at 2022-06-24 05:52:34.869674
# Unit test for function version
def test_version():
    version('v0.1', 'Python 2.7.5', 'Shell')



# Generated at 2022-06-24 05:52:39.137990
# Unit test for function debug
def test_debug():
    test_list = []
    debug("test_debug")
    with open("test_log", "r") as f:
        for line in f:
            test_list.append(line)
    assert test_list[-1] == "DEBUG: test_debug\n"