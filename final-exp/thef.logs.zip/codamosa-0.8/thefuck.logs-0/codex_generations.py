

# Generated at 2022-06-12 10:32:15.491769
# Unit test for function debug
def test_debug():
    import cStringIO
    import sys

    stdout = cStringIO.StringIO()
    with debug_time('test1'):
        debug('test debug')

    assert stdout.getvalue() == 'test debug\n'



# Generated at 2022-06-12 10:32:16.545124
# Unit test for function confirm_text
def test_confirm_text():
    assert(confirm_text(None) != 'asd')

# Generated at 2022-06-12 10:32:17.670062
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-12 10:32:20.311377
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command("ls -lah") == 'ls -lah'
    assert show_corrected_command("ls -lah +side effect") == 'ls -lah +side effect'


# Generated at 2022-06-12 10:32:30.489171
# Unit test for function confirm_text

# Generated at 2022-06-12 10:32:31.714774
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug'):
        print('debug_time test')

# Generated at 2022-06-12 10:32:36.403365
# Unit test for function debug_time
def test_debug_time():
    from unittest import TestCase
    from mock import patch

    class Test(TestCase):
        @patch('sys.stderr.write')
        def test_debug_time(self, stderr_write):
            with debug_time('test_msg'):
                pass
            self.assertTrue(stderr_write.called)
    Test().test_debug_time()

# Generated at 2022-06-12 10:32:37.340515
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:32:46.238168
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import Command, CorrectedCommand
    from .rules.base import Rule, CommandExecutor

    shell = Shell()
    shell.from_shell('export SHELL_SESSION_HISTORY=')
    shell.from_shell('export PROMPT_COMMAND=')
    shell.from_shell('export HISTFILE=/dev/null')
    shell.from_shell('export HISTFILESIZE=')
    shell.from_shell('export HISTSIZE=')
    shell.from_shell('export HISTTIMEFORMAT=')
    shell.from_shell('export HISTCONTROL=')

    corrector = Shell()
    corrector.from_shell('export SHELL_SESSION_HISTORY=')
    corrector.from_shell('export PROMPT_COMMAND=')

# Generated at 2022-06-12 10:32:47.746423
# Unit test for function debug_time
def test_debug_time():
    with debug_time("Test"):
        print("test")

# Generated at 2022-06-12 10:33:00.154143
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    from ..conf import ConfigurationDetails
    stdout = io.StringIO()
    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        reload='reload',
        content='content',
        path='path')
    with debug_time('test'):
        with stdout as tmp:
            how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:33:06.915679
# Unit test for function debug
def test_debug():
    # setup
    import StringIO
    o = StringIO.StringIO()
    sys.stderr = o
    settings.debug = True

    # test
    debug('test')
    settings.debug = False
    res = o.getvalue()
    # clean up
    o.close()
    del o
    del sys.stderr
    # assert
    assert res == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-12 10:33:17.434249
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Settings
    from .types import CorrectedCommand
    settings = Settings(_assign=['no_colors'], no_colors=True)
    assert confirm_text(CorrectedCommand('ls', True)) == '  (!) ls (+side effect) [enter/↑/↓/ctrl+c]'
    settings.no_colors = False
    assert confirm_text(CorrectedCommand('ls', False)) == (
        '  (!) ls  [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m'
        '/\x1b[31mctrl+c\x1b[0m]')



# Generated at 2022-06-12 10:33:22.426538
# Unit test for function debug_time
def test_debug_time():
    from . import utils

    def test_func():
        pass

    from time import sleep
    sleep_time = 0.5
    with utils.debug_time('test'):
        sleep(sleep_time)
    assert utils.debug_timings['test'] > sleep_time

# Generated at 2022-06-12 10:33:23.534978
# Unit test for function color
def test_color():
    assert color(True)

    settings.no_colors = True
    assert not color(True)



# Generated at 2022-06-12 10:33:24.513490
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('test')


# Generated at 2022-06-12 10:33:26.306112
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'fuck') == u'fuck'

# Generated at 2022-06-12 10:33:30.914367
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .application import CorrectedCommand
    from .shells import Shell
    fake_shell = Shell('Python', 'test', '', 'reload')
    fake_corrected_command = CorrectedCommand('ls', fake_shell, True)

# Generated at 2022-06-12 10:33:33.844948
# Unit test for function debug
def test_debug():
    debug('Hello, world!')
    settings.debug = False
    debug('Hello, world!')



# Generated at 2022-06-12 10:33:35.285111
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-12 10:33:48.163850
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(settings.ConfigurationDetails._make(
        path=u'/etc/thefuck/thefuck.sh',
        content=u'. ~/.thefuck/venv/bin/activate\n'
                u'thefuck $*',
        reload=u'source ~/.bash_profile',
        can_configure_automatically=True))

# Generated at 2022-06-12 10:33:52.635462
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    assert color(
        colorama.Fore.GREEN +
        const.USER_COMMAND_MARK +
        colorama.Style.BRIGHT) in show_corrected_command(
        CorrectedCommand('echo', side_effect=True))



# Generated at 2022-06-12 10:33:54.276780
# Unit test for function debug
def test_debug():
    assert not settings.debug
    debug('test')


# Unit tests for function how_to_configure_alias

# Generated at 2022-06-12 10:33:57.225299
# Unit test for function debug
def test_debug():
    output = u'debug\n'

    settings.debug = True
    debug(output)

    settings.debug = False
    debug(output)

    settings.debug = True
    debug(output)



# Generated at 2022-06-12 10:34:04.866911
# Unit test for function debug_time
def test_debug_time():
    # This is not a real unit test,
    # look at tests/test_log.py for unit tests of this module.
    # This way for checking debug_time with global settings.debug is
    # a good compromise.
    from datetime import timedelta
    from .conf import settings
    settings.debug = True
    with debug_time('example'):
        pass
    with debug_time('example'):
        pass
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestDebugTime(unittest.TestCase):
        def test_debug_time(self):
            self.assertIn(
                'example took: 0:00:00.' in sys.stderr.getvalue(),
                (True, False))

# Generated at 2022-06-12 10:34:07.690667
# Unit test for function debug_time
def test_debug_time():
    import datetime
    assert ('Default test message took: '+
            str(datetime.timedelta(0, 5, 0))) == debug_time("Default test message", 5)

# Generated at 2022-06-12 10:34:17.468349
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import sys
    import os
    import shutil

    with open('test.txt', 'w') as f:
        f.write('test')
    with open('test2.txt', 'w') as f:
        f.write('test')

    with debug_time('test'):
        with open('test.txt', 'rb') as f:
            datetime.strptime(f.read(), '%Y-%m-%d')

    with debug_time('test2'):
        shutil.copyfile('test.txt', 'test2.txt')

    with open('test.txt', 'rb') as f:
        assert f.read() == 'test'
    with open('test2.txt', 'rb') as f:
        assert f.read() == 'test'

   

# Generated at 2022-06-12 10:34:24.160525
# Unit test for function debug_time
def test_debug_time():
    from . import debug
    from .conf import configuration
    from .utils import wrap_settings
    import mock

    with wrap_settings({'debug': True}):
        with mock.patch.object(debug, 'debug') as debug_mock:
            with debug.debug_time('test_debug'):
                pass

    assert debug_mock.call_args[0][0].startswith('test_debug took: ')


import errno
import socket
import select
import sys
from .utils import wrap_settings



# Generated at 2022-06-12 10:34:34.727753
# Unit test for function debug
def test_debug():
    try:
        tmp_debug = settings.debug
    except AttributeError:
        settings.debug = False
    try:
        import StringIO
        __real_stderr = sys.stderr
        tmp_stderr = sys.stderr = StringIO.StringIO()
        sys.stderr.write = lambda x: tmp_stderr.write(x)
        debug('test')
        tmp_stderr.seek(0)
        assert tmp_stderr.read() == ''
        settings.debug = True
        debug('test')
        tmp_stderr.seek(0)
        assert 'test' in tmp_stderr.read()
    except:
        raise
    finally:
        sys.stderr = __real_stderr

# Generated at 2022-06-12 10:34:41.610888
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import (
        DEFAULT_CONFIGURATION,
        SHELLS, ZSH_CONFIGURATION, FISH_CONFIGURATION, BASH_CONFIGURATION,
        ConfigurationDetails)
    result = how_to_configure_alias(
        ConfigurationDetails(
            can_configure_automatically=False,
            path=SHELLS[0][1],
            reload=SHELLS[0][2],
            content=''))
    assert result == None
    assert how_to_configure_alias(
        ConfigurationDetails(
            can_configure_automatically=True,
            path=SHELLS[0][1],
            reload=SHELLS[0][2],
            content='')) == None
    assert how_to_configure_alias(None) == None

# Generated at 2022-06-12 10:34:49.805908
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock

    corrected_command = mock.MagicMock()
    corrected_command.script = 'echo "Hi"'
    corrected_command.side_effect = False
    show_corrected_command(corrected_command)
    assert True

    corrected_command.script = 'echo "Hi"'
    corrected_command.side_effect = True
    show_corrected_command(corrected_command)
    assert True



# Generated at 2022-06-12 10:34:55.304690
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Test if it does not raise any exception

    how_to_configure_alias(None)

    how_to_configure_alias(
        namedtuple(
            'configuration_details',
            'path content reload can_configure_automatically')(
                path='path',
                content='content',
                reload='reload',
                can_configure_automatically=True))

# Generated at 2022-06-12 10:35:06.175857
# Unit test for function confirm_text
def test_confirm_text():
    # GIVEN
    corrected_command = type('CorrectedCommand', (object,),
                             dict(script=u'script', side_effect=False))

    # WHEN
    confirm_text(corrected_command)
    # THEN

# Generated at 2022-06-12 10:35:07.209840
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(u'string')

# Generated at 2022-06-12 10:35:08.985234
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(u'\033[1K\r\n')


# Generated at 2022-06-12 10:35:14.870988
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .repl import CorrectedCommand
    from io import BytesIO
    sys.stderr = BytesIO()
    show_corrected_command(CorrectedCommand('ls -l', ''))
    assert sys.stderr.getvalue() == \
        '{}ls -l{} {}\n'.format(const.USER_COMMAND_MARK,
                                color(colorama.Style.RESET_ALL),
                                color(colorama.Style.BRIGHT))



# Generated at 2022-06-12 10:35:17.842822
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED) == u'\x1b[41m'
    assert color(colorama.Back.RED) != u'\x1b[41;0m'
    settings.no_colors = True
    assert color(colorama.Back.RED) == u''

# Generated at 2022-06-12 10:35:21.362985
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    conf = namedtuple('conf', 'can_configure_automatically path reload content')
    assert how_to_configure_alias(conf(False, 'path', 'reload', 'content')) == None

# Generated at 2022-06-12 10:35:24.200982
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details='')

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:35:25.326143
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        import time
        time.sleep(1)


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:35:32.751714
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class fake_command(object):

        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    cmd = fake_command('echo aaa', True)
    assert show_corrected_command(cmd) == '  $ echo aaa (+side effect)'

# Generated at 2022-06-12 10:35:42.860845
# Unit test for function confirm_text
def test_confirm_text():
    # TODO: We should use mock or py.test-mock here
    import test.conf
    import test.const

    test.conf.settings.no_colors = False
    test.const.USER_COMMAND_MARK = ''

    confirm_text(test.Command('ls *.py', 'echo "echo"', side_effect=True))
    assert sys.stderr.getvalue() == (
        'ls *.py +side effect [\x1b[32menter\x1b[0m/'
        '\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]')


# Generated at 2022-06-12 10:35:45.086037
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'



# Generated at 2022-06-12 10:35:50.147049
# Unit test for function debug
def test_debug():
    debug_log = []
    old_debug = debug_log.append

    def debug(msg):
        old_debug(msg)

    with debug_time('test'):
        assert debug_log == []
        debug('test_message')
        assert debug_log == ['test_message']

    assert debug_log == ['test_message', u'test took: 0:00:00.000001']

# Generated at 2022-06-12 10:35:56.052067
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == colorama.Back.RED + colorama.Fore.WHITE \
        + colorama.Style.BRIGHT
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-12 10:35:57.062730
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:58.454722
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls -l')


# Generated at 2022-06-12 10:35:59.015377
# Unit test for function debug
def test_debug():
    debug("Debug")

# Generated at 2022-06-12 10:36:02.301630
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from contextlib import closing
    seconds = 1
    import time
    with debug_time("test time") as t:
        time.sleep(seconds)

    assert timedelta(seconds=seconds) < t



# Generated at 2022-06-12 10:36:03.387216
# Unit test for function confirm_text
def test_confirm_text():
    # We are not really testing that value.
    confirm_text('test')

# Generated at 2022-06-12 10:36:13.044628
# Unit test for function debug
def test_debug():
    def test():
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n'

    import mock
    with mock.patch('sys.stderr', wraps=sys.stderr) as stderr, \
            mock.patch('thefuck.shells.colors.settings.debug', True):
        stderr.write = mock.Mock(side_effect=stderr.write)
        stderr.isatty = lambda: True
        debug('msg')
    test()

# Generated at 2022-06-12 10:36:17.707915
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Empty mock for side effects
    class EmptyMock(object):
        def __init__(self, **kwargs):
            for key, value in kwargs.items():
                setattr(self, key, value)
    class Mock(EmptyMock):
        pass
    mock = Mock(script = 'ls')
    show_corrected_command(mock)

# Generated at 2022-06-12 10:36:20.935061
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    settings.no_colors = True
    assert color(colorama.Style.BRIGHT) == ''



# Generated at 2022-06-12 10:36:22.326505
# Unit test for function debug_time
def test_debug_time():
    print(debug_time('hi'));


# Generated at 2022-06-12 10:36:24.493925
# Unit test for function confirm_text
def test_confirm_text():
    write_to_stdout = False
    confirm_text(FakeCommand('ls -la'))
    assert write_to_stdout


# Generated at 2022-06-12 10:36:26.269804
# Unit test for function color
def test_color():
    assert color('green') == colorama.Fore.GREEN
    assert color('green') == ''



# Generated at 2022-06-12 10:36:29.616651
# Unit test for function debug_time
def test_debug_time():
    from mock import patch, MagicMock
    from thefuck import main

    with patch('thefuck.log.debug') as debug_mock:
        with debug_time('test'):
            pass
        assert debug_mock.called

# Generated at 2022-06-12 10:36:30.767337
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('command')


# Generated at 2022-06-12 10:36:36.470065
# Unit test for function debug
def test_debug():
    from mock import patch, Mock
    with patch('sys.stderr') as stderr:
        debug(u'test message')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test message\n')
        stderr.write.reset_mock()

        settings.debug = False
        debug(u'test message')
        assert not stderr.write.called



# Generated at 2022-06-12 10:36:39.530975
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import time

    def debug(msg):
        print(msg)

    time.sleep(1)
    with debug_time(u'Sleeping'):
        time.sleep(1.5)

    assert time.time() - started >= timedelta(seconds=1.5)

# Generated at 2022-06-12 10:36:44.205351
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    for x in range(0, 10):
        how_to_configure_alias("some content")

# Generated at 2022-06-12 10:36:50.733883
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock

    with Mock() as mock:
        with debug_time('test'):
            mock()

    assert mock.called
    assert mock.call_count == 1
    assert mock.call_args[0] == ()
    assert mock.call_args[1] == {}

    from datetime import timedelta

    with Mock() as mock:
        with debug_time('test'):
            mock()
            assert mock.call_count == 1
            assert mock.call_args[0] == ()
            assert mock.call_args[1] == {}

    with Mock() as mock:
        with debug_time('test'):
            mock()
            assert mock.call_count == 1
            assert mock.call_args[0] == ()
            assert mock.call_args[1]

# Generated at 2022-06-12 10:36:52.511163
# Unit test for function color
def test_color():
    assert color(colorama.Fore.WHITE) == colorama.Fore.WHITE
    assert color(colorama.Fore.WHITE) == ''

# Generated at 2022-06-12 10:36:55.860797
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    sys.stderr = open('log.txt', 'w')
    confirm_text('ping -c 1 8.8.8.8')
    sys.stderr.close()
    f = open('log.txt')
    assert f.read() == 'fuck ping -c 1 8.8.8.8 [enter/↑/↓/ctrl+c]\n'

# Generated at 2022-06-12 10:36:59.801597
# Unit test for function debug_time
def test_debug_time():
    from mock import patch, Mock
    with patch('sys.stderr') as stderr:
        with debug_time(Mock(return_value='test-msg')):
            pass

        print(stderr.mock_calls)

# Generated at 2022-06-12 10:37:06.122086
# Unit test for function confirm_text
def test_confirm_text():
    # Test case: 'ne'
    confirm_text("ne")[0] == '"ne" [enter/↑/↓/ctrl+c]'

    # Test case: 'ne -s'
    confirm_text("ne -s")[0] == '"ne -s" [enter/↑/↓/ctrl+c]'

    # Test case: 'ne -s +side effect'
    confirm_text("ne -s +side effect")[0] == '"ne -s +side effect" [enter/↑/↓/ctrl+c]'

    # Test case: 'ne -s +side effect' with colors
    confirm_text("ne -s +side effect")[0] == 'ne -s +side effect'

# Generated at 2022-06-12 10:37:10.125812
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE + '{reset}') == colorama.Fore.BLUE + '{reset}'
    settings.no_colors = True
    assert color(colorama.Fore.BLUE + '{reset}') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:37:17.978937
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write('\033[1K\r{prefix}{script}{side_effect}'
                     ' [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                     '/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        script=u'ls -la',
        side_effect=u'',
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-12 10:37:25.005015
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Bash
    from .shells.bash import BashCorrectedCommand
    bash = Bash()
    corrected_command = BashCorrectedCommand('ls', 'ls -l', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == """{prefix}ls -l{side_effect}
""".format(
        prefix=const.USER_COMMAND_MARK,
        side_effect=u' (+side effect)' if corrected_command.side_effect else u'')

# Generated at 2022-06-12 10:37:27.537244
# Unit test for function color
def test_color():
    assert color('blue')('fuck') == 'fuck'
    assert color('blue', True)('fuck') == ''

# Generated at 2022-06-12 10:37:39.249961
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import StringIO

    sys.stderr = StringIO.StringIO()

    corrected_command = type('CorrectedCommand', (), {
        'script': 'git status',
        'side_effect': False
    })

    confirm_text(corrected_command)
    assert 'git status' in sys.stderr.getvalue()

    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:37:42.767518
# Unit test for function debug_time
def test_debug_time():
    from test.output_collector import OutputCollector
    from datetime import timedelta

    with OutputCollector() as output_collector, debug_time('foo'):
        assert timedelta(0) == datetime.now() - datetime.now()

    assert output_collector.stdout == []
    assert output_collector.stderr == [u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo took: 0:00:00\n']

# Generated at 2022-06-12 10:37:44.437562
# Unit test for function debug
def test_debug():
    content = u'hello'
    debug(content)



# Generated at 2022-06-12 10:37:46.321735
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''

# Generated at 2022-06-12 10:37:50.326712
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time(u'Test'):
        pass
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test took: {}\n'.format(datetime.now() - started)

# Generated at 2022-06-12 10:37:53.322208
# Unit test for function debug
def test_debug():
    debug_text = u'DEBUG: test'
    with settings(debug=True):
        debug(u'test')
    assert sys.stderr.getvalue() == debug_text + '\n'



# Generated at 2022-06-12 10:37:55.085309
# Unit test for function debug
def test_debug():
    try:
        log.debug('blah')
        assert False
    except UnboundLocalError:
        assert True

# Generated at 2022-06-12 10:37:59.687389
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = io.StringIO()
    confirm_text(CorrectedCommand('ls', ''))
    assert sys.stderr.getvalue() == u'{prefix}ls [enter/↑/↓/ctrl+c]'.format(
        prefix=const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:38:07.845696
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, **kwargs):
            self.content = kwargs.get('content')
            self.path = kwargs.get('path')
            self.reload = kwargs.get('reload')
            self.can_configure_automatically = kwargs.get('can_configure_automatically', False)

        def _asdict(self):
            return {'content': self.content,
                    'path': self.path,
                    'reload': self.reload,
                    'can_configure_automatically': self.can_configure_automatically}

# Generated at 2022-06-12 10:38:17.050655
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from thefuck import conf, logs
    from thefuck.conf import setup_logs
    from thefuck.types import CorrectedCommand

    _stdout = sys.stdout
    _stderr = sys.stderr
    _colorama = logs._colorama
    logs._colorama = (True, False)
    conf.settings = conf.Settings()

    setup_logs()


# Generated at 2022-06-12 10:38:29.923380
# Unit test for function confirm_text
def test_confirm_text():
    fout_lines = [u'[~]tfuck.py(+) [enter/↑/↓/ctrl+c]']
    sys.stderr = open('test_confirm_text', 'w')
    confirm_text('tfuck.py', True)
    sys.stderr.close()
    with open('test_confirm_text') as fout:
        fout_lines = fout.read().splitlines()
    assert fout_lines == ['[~]tfuck.py(+) [enter/↑/↓/ctrl+c]']

# Generated at 2022-06-12 10:38:34.541964
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    settings.debug = True
    debug('test')
    assert u'DEBUG: test\n' in sys.stderr.getvalue()
    settings.debug = False
    debug('test')
    assert u'DEBUG: test\n' not in sys.stderr.getvalue()



# Generated at 2022-06-12 10:38:35.412396
# Unit test for function debug
def test_debug():
    assert debug('test message') is None

# Generated at 2022-06-12 10:38:37.512514
# Unit test for function color
def test_color():
    assert '\x1b[0m' == color(colorama.Style.RESET_ALL)
    assert '' == color(colorama.Style.RESET_ALL, True)



# Generated at 2022-06-12 10:38:40.713837
# Unit test for function color
def test_color():
    assert not '\x1b' in color(colorama.Fore.BLACK)
    with colorama.init():
        assert '\x1b' in color(colorama.Fore.BLACK)


# Generated at 2022-06-12 10:38:46.607262
# Unit test for function debug_time
def test_debug_time():
    import mock
    with mock.patch('thefuck.shells.base.datetime') as mock_datetime:
        mock_datetime.now.return_value = datetime(1970, 1, 1, 1, 1, 1, 1)
        with debug_time('test_msg'):
            pass
        debug.assert_called_with(u'test_msg took: 0:00:00.000001')

# Generated at 2022-06-12 10:38:53.267700
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import which
    from .shells import Shell, get_shell_info
    from .conf import Config
    from mock import patch

    shell_info = Shell('sh', 'sh', None)

    def isfile(path):
        return path == '~/.bash_profile'

    with patch.object(which, 'is_executable', return_value=False), \
            patch('os.path.isfile', isfile):
        assert how_to_configure_alias(Config(shell_info, False)) == None

    with patch.object(which, 'is_executable', return_value=True), \
            patch('os.path.isfile', isfile):
        assert how_to_configure_alias(Config(shell_info, True)) == None


# Generated at 2022-06-12 10:38:58.365257
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == '{prefix} {bold}ls{reset}' \
                                 ' [{green}enter{reset}/{blue}↑{reset}/' \
                                 '{blue}↓{reset}/{red}ctrl+c{reset}]'

# Generated at 2022-06-12 10:39:03.232529
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails
    from .shells import Shell
    from .utils import get_closest, get_path

    configuration_details = ConfigurationDetails(
        'fuck', get_closest('fuck', Shell.known()), get_path(), '', False)

    assert how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:39:11.015974
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from datetime import datetime
    from datetime import timedelta
    from thefuck.utils import debug
    from thefuck.utils import debug_time
    with captured_output() as (out, err):
        debug('debug')
    assert len(out.getvalue()) == 0
    assert err.getvalue() == '\n'
    with captured_output() as (out, err):
        with debug_time('test'):
            time.sleep(0.1)

# Generated at 2022-06-12 10:39:20.079611
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    show_corrected_command(Shell('test', 'test', 'test', 'test').from_shell(
        'test', 'test', 'test'))



# Generated at 2022-06-12 10:39:21.435836
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')

# Generated at 2022-06-12 10:39:23.484127
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('test'):
        time.sleep(0.1)

    assert True



# Generated at 2022-06-12 10:39:30.776489
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # To check whether the output of how_to_configure_alias is correct
    from . import conf
    from . import test

    conf.load(False)
    conf.settings.no_colors = True
    configuration_details = test.ConfigurationDetails(
        conf.get_alias(), conf.get_reload_command(),
        conf.get_autoupdate_command(), conf.get_confirm_command(),
        conf.get_confirm_message(), conf.get_slow_command_timeout(),
        conf.get_require_confirmation_to_run(), conf.get_history_limit(),
        conf.get_wait_command(), conf.settings.fuck_alias)
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:39:34.191446
# Unit test for function confirm_text
def test_confirm_text():
    import colorama
    colorama.init()
    confirm_text('python')
    # Reset color
    colorama.deinit()



# Generated at 2022-06-12 10:39:35.094729
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:39:36.825873
# Unit test for function debug
def test_debug():
    assert not sys.stderr.getvalue()
    debug('test')
    assert sys.stderr.getvalue()

# Generated at 2022-06-12 10:39:39.022858
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test_debug_time'):
        assert not datetime.now() - started == 'test_debug_time'

# Generated at 2022-06-12 10:39:40.145517
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('content')


# Generated at 2022-06-12 10:39:44.988380
# Unit test for function debug_time
def test_debug_time():
    from thefuck.shells import shell
    from contextlib import contextmanager
    from mock import patch
    from datetime import datetime

    @contextmanager
    def patch_context(**kwargs):
        with patch.dict(settings.__dict__, kwargs, clear=True):
            yield

    with patch_context(debug=True):
        @debug_time('test_func')
        def test_func():
            pass
        test_func()

    with patch_context(debug=False):
        @debug_time('test_func')
        def test_func():
            pass
        test_func()

# Generated at 2022-06-12 10:39:53.954125
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(
        corrected_command='echo "Fuck"',
        side_effect='rm -rf /') == 'echo "Fuck" (+side effect)'

# Generated at 2022-06-12 10:39:55.860556
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('echo hello') == 'fuck echo hello'



# Generated at 2022-06-12 10:40:01.985811
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):

        def __init__(self, path, content, reload, can_configure_automatically):
            self._asdict = dict(
                path=path, content=content,
                reload=reload,
                can_configure_automatically=can_configure_automatically
            )

    how_to_configure_alias(
        ConfigurationDetails(
            path=u'~/.bashrc',
            content=u"eval $(thefuck --alias)",
            reload=u'source ~/.bashrc',
            can_configure_automatically=True))

# Generated at 2022-06-12 10:40:11.373354
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from thefuck.types import CorrectedCommand

    def get_sys_stderr():
        return io.BytesIO(sys.stderr.getvalue())

    sys.stderr = io.BytesIO()
    settings.no_colors = True
    confirm_text(CorrectedCommand(script='ls'))
    assert 'ls' in get_sys_stderr()

    sys.stderr = io.BytesIO()
    settings.no_colors = False
    confirm_text(CorrectedCommand(script='ls'))
    assert '\x1b[1K\r' in get_sys_stderr()

    sys.stderr = io.BytesIO()
    settings.no_colors = True

# Generated at 2022-06-12 10:40:13.150138
# Unit test for function debug_time
def test_debug_time():
    def test():
        a = 1
        if a:
            a += 1
    with debug_time('test'):
        test()   # noqa

# Generated at 2022-06-12 10:40:19.073311
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .conf import load_settings

    load_settings(debug=True)
    output = StringIO()
    sys.stderr = output
    debug('test')
    sys.stderr = sys.__stderr__
    assert output.getvalue() == \
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'



# Generated at 2022-06-12 10:40:20.940735
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='ls')
    confirm_text(corrected_command='git commit')

# Generated at 2022-06-12 10:40:21.919886
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("test") == None

# Generated at 2022-06-12 10:40:27.440814
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell
    shell = Shell()
    const.USER_COMMAND_MARK = shell.get_command_executed_string()
    show_corrected_command({'script': 'ls', 'side_effect': False})
    const.USER_COMMAND_MARK = shell.get_command_executed_string() + ' '
    show_corrected_command({'script': 'ls', 'side_effect': False})


# Generated at 2022-06-12 10:40:30.694764
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK = u'💩 '
    corrected_command = const.CorrectedCommand(script=u'hello')
    confirm_text(corrected_command)
    expected = constant.USER_COMMAND_MARK + u'💩 hello'
    assert sys.stderr.write == expected

# Generated at 2022-06-12 10:40:45.533970
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print("Testing how_to_configure_alias")
    how_to_configure_alias(configuration_details=None)
    if configuration_details:
        how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:40:46.738934
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(Script(script="fuck", side_effect=False)) == None

# Generated at 2022-06-12 10:40:50.891631
# Unit test for function debug_time
def test_debug_time():
    import contextlib

    @contextlib.contextmanager
    def test_time():
        start = datetime.now()
        yield
        duration = datetime.now() - start

        assert duration > timedelta()
        assert duration < timedelta(seconds=1)

    with test_time():
        with debug_time('debugging'):
            pass

# Generated at 2022-06-12 10:40:52.456281
# Unit test for function debug
def test_debug():
    from .test_utils import NoneOutput

    with NoneOutput():
        debug('test')
        assert False

# Generated at 2022-06-12 10:40:58.968929
# Unit test for function debug_time
def test_debug_time():
    class TestClass(object):
        def __init__(self):
            self.debug_time_count = 0
            self._test_msg = 'test message'
        def debug(self, msg):
            assert msg == self._test_msg
            self.debug_time_count += 1
    settings.debug = True
    tt = TestClass()
    with debug_time(tt._test_msg):
        pass
    assert tt.debug_time_count == 1

# Generated at 2022-06-12 10:41:01.743061
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        try:
            sys.stderr.write('test')
        except Exception:
            pass

# Generated at 2022-06-12 10:41:03.869812
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-12 10:41:06.373097
# Unit test for function debug
def test_debug():
    from io import StringIO
    buf = StringIO()
    sys.stderr = buf
    debug('hello')
    assert buf.getvalue() == "hello\n"
    buf.close()


# Generated at 2022-06-12 10:41:08.185493
# Unit test for function color
def test_color():
    assert color(u'abc') == u'abc'
    settings.no_colors = True
    assert color(u'abc') == u''



# Generated at 2022-06-12 10:41:14.695267
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    from . import shell

    settings.debug = False

    shell.read_key = lambda: 'enter'
    assert shell.get_command('fuck') == 'fuck'

    shell.read_key = lambda: '\x1b[A'
    assert shell.get_command('fuck') == 'fuck'

    shell.read_key = lambda: '\x1b[B'
    assert shell.get_command('fuck') == 'fuck'

    shell.read_key = lambda: '\x03'
    assert shell.get_command('fuck') is None

# Generated at 2022-06-12 10:41:28.898199
# Unit test for function debug
def test_debug():
    assert debug("This is a test") == sys.stderr.write("\x1b[34m\x1b[1mDEBUG:\x1b[0m This is a test\n")


# Generated at 2022-06-12 10:41:32.548487
# Unit test for function confirm_text
def test_confirm_text():
    import six
    import mock
    import thefuck.main
    thefuck.main.get_history = mock.Mock()
    thefuck.main.get_history.return_value = u'git psuh'

    confirm_text([u'git psuh'])
    assert sys.stderr.getvalue() == six.u('>git psuh [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-12 10:41:35.847495
# Unit test for function color
def test_color():
    assert u'\x1b[0m' == color(u'\x1b[0m')
    assert settings.no_colors is True
    settings.no_colors = True
    assert u'' == color(u'\x1b[0m')
    settings.no_colors = False

# Generated at 2022-06-12 10:41:38.364632
# Unit test for function confirm_text
def test_confirm_text():
    expected = ('      fck  [enter/up/down/ctrl+c]')
    assert confirm_text(corrected_command={'script': 'fck'}) == expected

# Generated at 2022-06-12 10:41:39.792651
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text(corrected_command='git commit -m'))==None

# Generated at 2022-06-12 10:41:40.780370
# Unit test for function color
def test_color():
    assert color('red') == ''

# Generated at 2022-06-12 10:41:49.757824
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import conf
    config_details = conf.ConfigurationDetails(
        can_configure_automatically=True,
        reload='source ~/.bashrc',
        path='~/.bashrc',
        content='alias fuck=\'eval $(thefuck $(fc -ln -1 | tail -n 1)); history -r\'')
    details = config_details._asdict()
    how_to_configure_alias(config_details)
    assert (u'Please put {bold}{content}{reset} in your '
            u'{bold}{path}{reset} and apply '
            u'changes with {bold}{reload}{reset} or restart your shell.'.format(**details)) in sys.stdout.getvalue()

# Generated at 2022-06-12 10:41:55.953315
# Unit test for function debug_time
def test_debug_time():
    def _test():
        with debug_time('test'):
            pass
    import mock
    from datetime import datetime, timedelta
    now = datetime.now()
    with mock.patch('datetime.datetime') as mock_datetime:
        mock_datetime.now.side_effect = [now, now + timedelta(seconds=1)]
        with mock.patch('sys.stderr') as mock_stderr:
            _test()
            assert mock_stderr.write.called
            assert 'test took' in mock_stderr.write.call_args[0][0]

# Generated at 2022-06-12 10:41:59.999130
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command

    show_corrected_command(Command('ls', 'ls', None, None))
    assert sys.stderr.getvalue() == '$ ls\n'
    sys.stderr = BytesIO()

    show_corrected_command(Command('ls', 'ls', None, 'cd /'))
    assert sys.stderr.getvalue() == '$ ls (+side effect)\n'

# Generated at 2022-06-12 10:42:06.068047
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import timedelta

    with patch('thefuck.utils.sys.stderr') as stderr:
        with debug_time('foo'):
            pass

        stderr.write.assert_called_with(u'{0}DEBUG:{1} foo took: {2}\n'.format(
            color(colorama.Fore.BLUE), color(colorama.Style.RESET_ALL),
            timedelta()))

