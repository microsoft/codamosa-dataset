

# Generated at 2022-06-12 10:32:11.629127
# Unit test for function color
def test_color():
    assert color('red') == ''
    colorama.init()
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED
    colorama.deinit()

# Generated at 2022-06-12 10:32:15.159782
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(name) == u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'


# Generated at 2022-06-12 10:32:17.124769
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    details = const.ConfigurationDetails('~', 'export', 'fuck', False)
    how_to_configure_alias(details)
    assert True



# Generated at 2022-06-12 10:32:17.938116
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:32:22.374933
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    show_corrected_command(CorrectedCommand(script='ls /usr/lib | grep zip', side_effect=False))
    show_corrected_command(CorrectedCommand(script='git gc', side_effect=True))

# Generated at 2022-06-12 10:32:24.338703
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
        path="/home/user/.config",
        content="eval $(thefuck --alias)",
        can_configure_automatically=True,
        reload=". ~/.config"
    )
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:32:26.540106
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import os

    sys.stderr = sys.__stderr__ = open(os.devnull, 'w')



# Generated at 2022-06-12 10:32:29.766721
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.core import Command
    corrected_command = Command('git commit', '')
    show_corrected_command(corrected_command)
    corrected_command = Command('ls', '', True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:32:32.330638
# Unit test for function confirm_text
def test_confirm_text():
    expected_result = 'fuck (+side effect) [enter/↑/↓/ctrl+c]'
    assert confirm_text(cmd.Command('fuck +side effect', ['arg'], False)) == expected_result

# Generated at 2022-06-12 10:32:35.538066
# Unit test for function debug
def test_debug():
    from test.utils import captured_stderr
    with captured_stderr() as debug_output:
        debug(u'foo')
    assert u'DEBUG: foo' in debug_output.getvalue()



# Generated at 2022-06-12 10:32:41.214686
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'git push origin branchname'
    corrected_command = 'git push origin branch_name'

    sys.stdout.write(''.join(['Success' if command == corrected_command else 'FAil']))
    assert command != corrected_command, "Something went wrong!"

# Generated at 2022-06-12 10:32:42.724309
# Unit test for function debug
def test_debug():
    assert debug('reload-os') == None


# Generated at 2022-06-12 10:32:46.257714
# Unit test for function color
def test_color():
    assert settings.no_colors
    settings.no_colors = False
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-12 10:32:49.063899
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    corrected_command = CorrectedCommand(u'foo', True)
    assert show_corrected_command(corrected_command) == \
        u'> foo\n'

# Generated at 2022-06-12 10:32:50.445210
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("configuration_details")

# Generated at 2022-06-12 10:32:51.912812
# Unit test for function debug
def test_debug():
    debug('debug')


# Generated at 2022-06-12 10:32:53.951610
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    shell = Shell()
    from .command import Command

    confirm_text(Command('ls', 'pwd', False, shell))

# Generated at 2022-06-12 10:32:54.648196
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('corrected_command') == None

# Generated at 2022-06-12 10:33:04.851781
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    _confirm_text = confirm_text
    result = []
    def confirm_text(x):
        result.append(x)
    confirm_text.__name__ = _confirm_text.__name__
    shell = Shell()
    shell.script = ''
    shell.side_effect = ''
    try:
        from types import ModuleType
        thefuck.main.shells = ModuleType('thefuck.main.shells')
        thefuck.main.shells.shell = shell
        thefuck.main.settings.no_colors = True
        thefuck.main.__main__()
        assert(result)
    finally:
        thefuck.main.shells = Shell



# Generated at 2022-06-12 10:33:10.657854
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    input_ = unicode("Seems like {}fuck{} alias isn't configured!\n"
                     "Please put {content} in your {path} and apply changes with {reload} or restart your shell.\n"
                     "Or run {bold}fuck{reset} a second time to configure it automatically.\n"
                     "More details - https://github.com/nvbn/thefuck#manual-installation"
                     .format(colorama.Style.BRIGHT, colorama.Style.RESET_ALL))
    output_ = how_to_configure_alias(configuration_details=None)
    assert input_ == output_



# Generated at 2022-06-12 10:33:14.738160
# Unit test for function color
def test_color():
    assert color('colorama.Foo.BAR') == 'colorama.Foo.BAR'

# Generated at 2022-06-12 10:33:20.407287
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    result = u"Seems like {bold}fuck{reset} alias isn't configured!".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))
    assert result == how_to_configure_alias(None)



# Generated at 2022-06-12 10:33:25.502441
# Unit test for function debug
def test_debug():
    from mock import call
    from thefuck.shells import shell
    stderr = []
    shell.enable_color_when_supported = lambda: False
    for _ in debug(u'{} {}'.format(1, 2)):
        stderr.append(call(u'DEBUG: 1 2\n'))
    assert stderr == [call(u'DEBUG: 1 2\n')]

# Generated at 2022-06-12 10:33:26.171801
# Unit test for function debug
def test_debug():
    debug('Hello world')

# Generated at 2022-06-12 10:33:28.792221
# Unit test for function color
def test_color():
    assert '\x1b[31m' == color(colorama.Fore.RED)
    assert '' == color(colorama.Fore.RED, True)



# Generated at 2022-06-12 10:33:30.105041
# Unit test for function debug
def test_debug():
    debug('hello')

# Generated at 2022-06-12 10:33:31.529468
# Unit test for function debug
def test_debug():
    debug('echo 1')
    debug('echo 2')
    debug('echo 3')

# Generated at 2022-06-12 10:33:37.196328
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO

    sys.stderr = StringIO()
    from thefuck import shells

    fish = shells.Fish()
    confirm_text(fish.CorrectedCommand('ls', ''))
    assert sys.stderr.getvalue() == u'[fuck]ls [enter]/[\u2191]/[\u2193][/ctrl+c]\r'

# Generated at 2022-06-12 10:33:46.822611
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = [True, "bash", "~/.bashrc", "source ~/.bashrc"]
    message_for_terminal_window = ["""Seems like fuck alias isn't configured!""",
                                   """Please put bold ~/.bashrc content reset in your bold ~.bashrc path and apply changes with bold source ~.bashrc reset or restart your shell.""",
                                   """Or run boldfuck reset a second time to configure it automatically.""",
                                   """More details - https://github.com/nvbn/thefuck#manual-installation"""]
    how_to_configure_alias(configuration_details)
    assert len(sys.stdout.write.assert_called_with) == len(message_for_terminal_window)

# Generated at 2022-06-12 10:33:55.475742
# Unit test for function debug
def test_debug():
    # Test under debug
    sys.stderr = BytesIO()
    settings.debug = True
    debug(u'Привет, мир!')
    assert u'Привет, мир!' in sys.stderr.getvalue()

    # Test over debug
    sys.stderr = BytesIO()
    settings.debug = False
    debug(u'Привет, мир!')
    assert u'Привет, мир!' not in sys.stderr.getvalue()



# Generated at 2022-06-12 10:33:59.693724
# Unit test for function color
def test_color():
    assert color('\x1b[91m') == '\x1b[91m'
    assert color('\x1b[91m') == ''



# Generated at 2022-06-12 10:34:00.643856
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('sleeping')



# Generated at 2022-06-12 10:34:04.937917
# Unit test for function debug
def test_debug():
    import sys
    from tests.utils import capture_stderr

    with capture_stderr() as stderr:
        debug('foo')
        assert u'debug' in stderr.getvalue().lower()
        assert u'foo' in stderr.getvalue()

    with capture_stderr() as stderr:
        debug('bar')
        assert 'debug' in stderr.getvalue().lower()
        assert 'bar' in stderr.getvalue()



# Generated at 2022-06-12 10:34:15.504208
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK = ''
    const.USER_COMMAND_STARTING_MARK = ''
    const.SIDE_EFFECT_MARK = ''

    corrected_command = type('', (), {
        'script': '',
        'side_effect': False
    })

# Generated at 2022-06-12 10:34:19.470925
# Unit test for function debug
def test_debug():
    from .debug import LoggedFunctionCall

    def _test_debug(msg):
        assert LoggedFunctionCall('debug', msg) in debug.log_calls

    debug.log_calls = []
    debug('test')
    _test_debug('test')

    settings.debug = False
    debug('test')
    assert LoggedFunctionCall('debug', 'test') not in debug.log_calls
    settings.debug = True

# Generated at 2022-06-12 10:34:24.298757
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'ls'
    corrected_command = 'ls -l'
    failed('Did you mean %s?' % corrected_command)
    show_corrected_command(corrected_command)
    confirm_text(command)
    return 0


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:34:27.361321
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push origin master', ''))


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:34:35.020672
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .types import (ConfigurationDetails,
                        ShellType,
                        ShellConfig,
                        ShellConfigType)
    from .shells import shell

    with shell.create(ShellType('zsh')) as zsh:
        configuration_details = ConfigurationDetails(
            ShellConfig(ShellConfigType.alias,
                        'eval $(thefuck --alias)',
                        '~/.zshrc'),
            'source ~/.zshrc',
            False)
        zsh.put_to_config(configuration_details, '')

        assert zsh.get_config(configuration_details)

# Generated at 2022-06-12 10:34:40.794170
# Unit test for function debug_time
def test_debug_time():
    @contextmanager
    def fake_time():
        yield datetime(2015, 9, 1, 12, 0, 0)

    debug_old = __builtins__['debug']
    try:
        __builtins__['debug'] = lambda x: None
        with debug_time('foo'):
            pass
        __builtins__['debug'] = lambda x: sys.stderr.write(x + '\n')
        with fake_time():
            with debug_time('foo'):
                pass
    finally:
        __builtins__['debug'] = debug_old

if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:34:42.368156
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:34:47.559486
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_closest
    from .config import Config
    from .conf import settings

    for shell in ('fish', 'bash', 'zsh'):
        settings._replace(shell=shell)
        assert how_to_configure_alias(get_closest(Config.get_shells()[shell])) == None



# Generated at 2022-06-12 10:34:49.863516
# Unit test for function debug
def test_debug():
    # TODO:
    # Test the output of this function using a mock
    # We need to be able to set sys.stderr to a mock
    pass

# Generated at 2022-06-12 10:34:57.782654
# Unit test for function confirm_text
def test_confirm_text():
    # A mock object of corrected_command
    class CorrectedCommand:
        script = '''mock_script'''
        side_effect = True

    confirm_text(CorrectedCommand)
    assert sys.stdout.getvalue() == '''mock_script (+side effect) [enter/↑/↓/ctrl+c]'''

    # Disable colors
    with settings:
        settings.no_colors = True
        confirm_text(CorrectedCommand)
        assert sys.stdout.getvalue() == '''mock_script (+side effect) [enter/↑/↓/ctrl+c]'''

# Generated at 2022-06-12 10:35:02.337679
# Unit test for function confirm_text
def test_confirm_text():
    from .repl import confirm_text
    from .utils import get_closest
    from .conf import settings
    from .rule import Command
    settings.no_colors = True
    confirm_text(Command(script='ls'))
    assert get_closest('ls') == [('LANG', 'C')]

# Generated at 2022-06-12 10:35:07.993483
# Unit test for function confirm_text
def test_confirm_text():
    from . import conf
    from .conf import settings
    from .main import reset_settings

    reset_settings()
    settings.no_colors = False
    sys.stderr = open('/dev/null', 'w')
    try:
        confirm_text('true')
    except Exception as e:
        print('confirm_text failed\n' + str(e))
    sys.stderr.close()

# Generated at 2022-06-12 10:35:16.846092
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    output = StringIO.StringIO()
    sys.stdout = output
    confirmed_command = type('confirmed_command', (object,), {
        'script': 'ls', 'side_effect': True})
    confirm_text(confirmed_command)
    output.seek(0)

# Generated at 2022-06-12 10:35:18.542372
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(u'\033[1K\r')


# Generated at 2022-06-12 10:35:19.141305
# Unit test for function debug
def test_debug():
    debug('test message')

# Generated at 2022-06-12 10:35:24.695622
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from . import const
    from .shells import Shell
    how_to_configure_alias(Shell('', 'zsh', '',
                                     '', '',
                                     'echo fuck >> ~/.zshrc && source ~/.zshrc',
                                     'etc/bash_completion.d/thefuck',
                                     const.LOAD_BASH, False))


# Generated at 2022-06-12 10:35:26.091930
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(corrected_command) == True


# Generated at 2022-06-12 10:35:30.156056
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)



# Generated at 2022-06-12 10:35:37.804126
# Unit test for function debug
def test_debug():
    from mock import patch, call

    with patch('sys.stderr') as sys_stderr_mock:
        debug('message')
        assert sys_stderr_mock.method_calls == []

        with patch.dict('thefuck.utils.settings.__dict__', {'debug': True}):
            debug('message')
            assert sys_stderr_mock.method_calls == [
                call.write('\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n')]

# Generated at 2022-06-12 10:35:43.623993
# Unit test for function debug
def test_debug():
    import StringIO
    saved_stdout = sys.stderr
    try:
        out = StringIO.StringIO()
        sys.stderr = out
        settings.debug = True
        debug(u'test')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = saved_stdout


# Generated at 2022-06-12 10:35:47.816800
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {
        'content': 'alias fuck = "$(thefuck $(fc -ln -1))"',
        'path': '~/',
        'reload': 'source ~/.bashrc'
    }

    assert how_to_configure_alias(configuration_details) == None

# Generated at 2022-06-12 10:35:49.776629
# Unit test for function debug_time
def test_debug_time():
    class Test(object):
        pass
    obj = Test()
    obj.debug = True
    with debug_time("test"):
        pass

# Generated at 2022-06-12 10:35:52.267414
# Unit test for function color
def test_color():
    assert color('yellow') == ''
    settings.no_colors = False
    assert color('yellow') == colorama.Fore.YELLOW



# Generated at 2022-06-12 10:35:53.824546
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:36:03.644725
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple(
        'ConfigurationDetails',
        'can_configure_automatically path reload content')

    captured = []

    def fake_print(text):
        captured.append(text)

    old_print = __builtins__['print']
    __builtins__['print'] = fake_print
    try:
        how_to_configure_alias(
            configuration_details(
                can_configure_automatically=True,
                reload='reload',
                path='path',
                content='content'))
    finally:
        __builtins__['print'] = old_print


# Generated at 2022-06-12 10:36:04.803402
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(False)
    how_to_configure_alias(True)

# Generated at 2022-06-12 10:36:05.951299
# Unit test for function debug
def test_debug():
    debug(u'Проверка')



# Generated at 2022-06-12 10:36:09.746018
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass

# Generated at 2022-06-12 10:36:11.288487
# Unit test for function debug_time
def test_debug_time():
    pytest_runner.run_tests([
        'tests/test_debug_time.py::test_debug_time'])

# Generated at 2022-06-12 10:36:16.357127
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import tests.utils
    sys.stdout = tests.utils.UnicodeIO()
    show_corrected_command(tests.utils.FixedCommand('ls', 'ls -a'))
    show_corrected_command(tests.utils.FixedCommand('ls', 'ls -a', True))
    assert sys.stdout.getvalue() == u'=> ls -a\n=> ls -a (+side effect)\n'

# Generated at 2022-06-12 10:36:17.707352
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass



# Generated at 2022-06-12 10:36:20.078807
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand('ls /tmp', False)

    confirm_text(corrected_command)


# Generated at 2022-06-12 10:36:23.485038
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.main import Command
    corrected_command = Command(script='ls -l', side_effect=True)
    show_corrected_command(corrected_command)
    assert const.USER_COMMAND_MARK == '[*]'

# Generated at 2022-06-12 10:36:26.730238
# Unit test for function debug
def test_debug():
    """Unit test for function debug."""

    # call debug with debug disabled
    settings.debug = False
    debug('foo')

    # call debug with debug enabled
    settings.debug = True
    debug('foo')


# Generated at 2022-06-12 10:36:30.055149
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = open('/dev/null', 'w')
    confirm_text(u'echo "Hello"')
    confirm_text(u'echo "Hello" +side effect')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:36:31.215980
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('ls') == "ls"


# Generated at 2022-06-12 10:36:32.030328
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-12 10:36:35.807364
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.5)

# Generated at 2022-06-12 10:36:36.584062
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test string'):
        pass

# Generated at 2022-06-12 10:36:37.348754
# Unit test for function debug
def test_debug():
    assert debug('')
    assert debug('test')

# Generated at 2022-06-12 10:36:39.648320
# Unit test for function color
def test_color():
    assert color('some_string') == 'some_string'

    settings.no_colors = True
    assert color('color_string') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:36:46.294421
# Unit test for function confirm_text
def test_confirm_text():
    from blessed import Terminal
    terminal = Terminal()
    assert confirm_text(('ls -la', True)) == \
           terminal.clear_eos + \
           terminal.bold + 'ls -la' + terminal.normal + ' (+side effect) ' + \
           '[' + terminal.green + 'enter' + terminal.normal + \
           '/' + terminal.blue + '↑' + terminal.normal + \
           '/' + terminal.blue + '↓' + terminal.normal + \
           '/' + terminal.red + 'ctrl+c' + terminal.normal + ']'



# Generated at 2022-06-12 10:36:47.733875
# Unit test for function debug_time
def test_debug_time():
    import datetime
    with debug_time('test'):
        print("test")

# Generated at 2022-06-12 10:36:50.226032
# Unit test for function confirm_text

# Generated at 2022-06-12 10:36:57.443545
# Unit test for function debug
def test_debug():
    import os
    import sys
    import tempfile
    from thefuck.conf import settings
    settings.debug = True
    with tempfile.TemporaryFile() as stream:
        sys.stderr = stream
        debug(u'Test')
        debug(u'Тест')
        stream.seek(0)
        assert stream.read().decode(os.environ.get('LANG')) \
            == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n' \
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Тест\n'

# Generated at 2022-06-12 10:37:05.914251
# Unit test for function debug
def test_debug():
    from _pytest.monkeypatch import MonkeyPatch
    from thefuck.main import Settings

    monkeypatch = MonkeyPatch()

    class Stderr(object):
        def __init__(self):
            self.content = []

        def reset(self):
            self.content = []

        def write(self, msg):
            self.content.append(msg)

        def __str__(self):
            return ''.join(self.content)

    stderr = Stderr()

    monkeypatch.setattr(sys, 'stderr', stderr)
    monkeypatch.setattr(settings, 'debug', True)

    debug(u'Some debug message')

    expected_output = u'\033[34m\033[1mDEBUG:\033[0m Some debug message\n'

# Generated at 2022-06-12 10:37:10.279118
# Unit test for function debug
def test_debug():
    assert not settings.debug
    with open('/dev/tty', 'w') as tty:
        sys.stderr = tty
        debug('msg')
    settings.debug = True
    with open('/dev/tty', 'w') as tty:
        sys.stderr = tty
        debug('msg')
    settings.debug = False

# Generated at 2022-06-12 10:37:18.536539
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.base import Shell
    from .types import CorrectedCommand, Command
    shell = Shell()
    corrected_command = CorrectedCommand(script='ls -l', side_effect=False)
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:37:20.796283
# Unit test for function color
def test_color():
    assert color('foo') == ''
    settings.no_colors = False
    assert color('foo') == 'foo'



# Generated at 2022-06-12 10:37:22.009349
# Unit test for function debug
def test_debug():
    assert debug.__name__ == 'debug'

# Generated at 2022-06-12 10:37:29.187176
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class Temp(object):
        def __init__(self, **entries):
            self.__dict__.update(entries)

    how_to_configure_alias(Temp())
    how_to_configure_alias(Temp(
        path='/home/nvbn/.bashrc',
        content='fuck_alias="eval $(thefuck $(fc -ln -1))"',
        reload='source /home/nvbn/.bashrc',
        can_configure_automatically=True,
    ))

# Generated at 2022-06-12 10:37:36.780190
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta  # pylint: disable=wrong-import-order, wrong-import-position
    from datetime import time  # pylint: disable=wrong-import-order, wrong-import-position

    class Output(object):
        def __init__(self):
            self.content = []

        def write(self, content):
            self.content.append(content)

        def __str__(self):
            return ''.join(self.content)

    timestamps = []

    def mock_datetime_now():
        # pylint: disable=unused-variable
        now = timestamps.pop(0)
        return now

    original_datetime_now = datetime.now
    datetime.now = mock_datetime_now
    output = Output()
    original_debug = debug

# Generated at 2022-06-12 10:37:44.390520
# Unit test for function debug
def test_debug():
    settings.debug = False
    debug('test')
    assert sys.stderr.getvalue() == ''
    sys.stderr.seek(0)
    sys.stderr.truncate()
    settings.debug = True
    debug('test')
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[21m\x1b[39m test\n'
    sys.stderr.seek(0)
    sys.stderr.truncate()
    sys.stderr = open('/dev/null', 'w')


# Generated at 2022-06-12 10:37:48.585440
# Unit test for function debug_time
def test_debug_time():
    try:
        now = datetime.now()
        with debug_time('test_debug_time'):
            sec = (datetime.now() - now).seconds
            if sec < 1:
                raise Exception('It should be show the time that passed')
    except Exception as e:
        raise e

# Generated at 2022-06-12 10:37:51.487135
# Unit test for function confirm_text
def test_confirm_text():
    import inspect

    # We need to access local variable 'confirm_text' from outer scope
    local_variables = inspect.currentframe().f_back.f_locals
    confirm_text(local_variables['corrected_command'])

# Generated at 2022-06-12 10:37:53.801941
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    out = StringIO()
    sys.stderr = out
    debug(u'hello')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:37:56.185299
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time("test_debug_time"):
        time.sleep(0.2)
        return 'asd'


if __name__ == '__main__':
    settings.debug = True
    test_debug_time()

# Generated at 2022-06-12 10:38:01.698206
# Unit test for function debug
def test_debug():
    debug('Hello')



# Generated at 2022-06-12 10:38:06.037624
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command(object):

        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(corrected_command('ls -la')) == 'lfsd -la'
    assert show_corrected_command(corrected_command('ls -la', True)) == 'ls -la (+side effect)'

# Generated at 2022-06-12 10:38:12.766387
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls-l')
    show_corrected_command('ls -l')
    show_corrected_command('ls -l +')
    show_corrected_command('ls -l +1')
    show_corrected_command('ls -l +13')
    show_corrected_command('ls -l +132')
    show_corrected_command('ls -l +1323')


# Generated at 2022-06-12 10:38:16.649989
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    with mock.patch('sys.stderr.write') as mock_write:
        with debug_time(u'TEST'):
            time.sleep(0.005)
    mock_write.assert_called_once_with(
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m TEST took: 0:00:00.005000\n')

# Generated at 2022-06-12 10:38:18.726656
# Unit test for function debug
def test_debug():
    from mock import Mock
    mock = Mock()
    sys.stderr = mock

    debug('string')

    assert mock.write.called

# Generated at 2022-06-12 10:38:19.581326
# Unit test for function confirm_text
def test_confirm_text():
    pass



# Generated at 2022-06-12 10:38:26.136817
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        debug(u"тест сообщения")
        assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m тест сообщения\n'

# Generated at 2022-06-12 10:38:28.051956
# Unit test for function debug
def test_debug():
    assert debug.__wrapped__(u"Hello") is None
    assert debug.__wrapped__(u"Hello") is None

# Generated at 2022-06-12 10:38:28.998337
# Unit test for function debug
def test_debug():
    debug('test')



# Generated at 2022-06-12 10:38:34.789982
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None
    assert how_to_configure_alias(
        AttributeDictionary({
            'path': '~/.bashrc',
            'reload': 'source ~/.bashrc',
            'content': 'eval "$(thefuck --alias)"',
            'can_configure_automatically': True
        })) is None



# Generated at 2022-06-12 10:38:46.889128
# Unit test for function debug_time
def test_debug_time():
    import contextlib
    import StringIO
    from datetime import datetime
    from datetime import timedelta
    from .conf import settings

    settings.debug = True

    with contextlib.closing(StringIO.StringIO()) as stderr:
        sys.stderr = stderr

        with debug_time('test'):
            print(datetime.now() + timedelta(seconds=1))

        sys.stderr = sys.__stderr__
        assert u'test took: 0:00:01' in stderr.getvalue()

# Generated at 2022-06-12 10:38:47.904262
# Unit test for function debug
def test_debug():
    #debug('TEST')
    pass

# Generated at 2022-06-12 10:38:48.777072
# Unit test for function debug_time
def test_debug_time():
    debug_time(u"123")

# Generated at 2022-06-12 10:39:00.814279
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils.appdirs import AppDirs
    from .utils.get_closest_executable_name import get_closest_executable_name
    from .utils.shells import shell_info

    configuration_details = object()

    shit = u"sh " + get_closest_executable_name()
    app_data = AppDirs('thefuck', 'nvbn')
    history = app_data.user_cache_dir + '/history'

    def how_to_configure_alias_test(configuration_details):
        print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-12 10:39:04.331236
# Unit test for function show_corrected_command
def test_show_corrected_command():
    script = u'git push origin master'
    side_effect = True
    corrected_command = script + ' ' + side_effect
    show_corrected_command(corrected_command)
    assert sys.stderr.write == '> git push origin master (+side effect) \n'

# Generated at 2022-06-12 10:39:13.811577
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # check output when configuration_details is None
    restore_sys_stdout = sys.stdout
    try:
        from cStringIO import StringIO
        out = StringIO()
        sys.stdout = out
        how_to_configure_alias(None)
        output = out.getvalue().strip()
        assert output == u"Seems like \x1b[1mfuck\x1b[22m alias isn't configured!\nMore details - https://github.com/nvbn/thefuck#manual-installation", output
    finally:
        sys.stdout = restore_sys_stdout

    # check output when configuration_details is not None
    # check output when configuration_details.can_configure_automatically is True
    restore_sys_stdout = sys.stdout

# Generated at 2022-06-12 10:39:14.958610
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('test')

# Generated at 2022-06-12 10:39:15.801528
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(MockCorrectedCommand())


# Generated at 2022-06-12 10:39:18.308136
# Unit test for function confirm_text
def test_confirm_text():
    # function under test
    show_corrected_command("ls sdfsdf")
    confirm_text("ls sdfsdf")

# Generated at 2022-06-12 10:39:23.400686
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time
    with mock.patch('thefuck.shells.debug') as debug_mock:
        with debug_time('test_debug_time'):
            time.sleep(0.5)
    debug_mock.assert_called_once_with('test_debug_time took: 0:00:00.500000')

# Generated at 2022-06-12 10:39:31.053111
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class TestCommand(object):
        def __init__(self):
            self.script = 'ls'
            self.side_effect = False

        def __str__(self):
            return self.script

    show_corrected_command(TestCommand())

# Generated at 2022-06-12 10:39:36.906092
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    from io import StringIO
    import sys
    f = StringIO()
    sys.stderr = f
    show_corrected_command(CorrectedCommand('', 'vim', False))
    sys.stderr = sys.__stderr__
    assert f.getvalue() == 'TheFuck:vim\n'

# Generated at 2022-06-12 10:39:38.464668
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(how_to_configure_alias(configuration_details=''))


# Generated at 2022-06-12 10:39:43.272438
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = mock.Mock()
    corrected_command.script = "ls rtf-files"
    corrected_command.side_effect = None

    with mock.patch('sys.stderr', new=StringIO()) as mocked_stderr:
        show_corrected_command(corrected_command)
        assert mocked_stderr.getvalue() == ">ls rtf-files\n"

    corrected_command.side_effect = "rm rtf-files"
    with mock.patch('sys.stderr', new=StringIO()) as mocked_stderr:
        show_corrected_command(corrected_command)
        assert mocked_stderr.getvalue() == ">ls rtf-files (+side effect)\n"

# Generated at 2022-06-12 10:39:45.300525
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test') as test:
        pass
    assert test is None


# Generated at 2022-06-12 10:39:46.603204
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = sys.stdout
    show_corrected_command('fuck')
    sys.stderr = None


# Generated at 2022-06-12 10:39:48.924947
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .context import CorrectedCommand
    show_corrected_command(CorrectedCommand(
        script='git log', side_effect=False))
    show_corrected_command(CorrectedCommand(
        script='git log', side_effect=True))


if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:39:50.482003
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-12 10:39:52.161100
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('foo'):
        time.sleep(0.2)

# Generated at 2022-06-12 10:39:53.342092
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:40:03.961991
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import sys
    import tempfile
    from tests.utils import assert_equal
    from thefuck.shells import Shell

    # Test for fish shell
    with tempfile.NamedTemporaryFile() as fish_conf:
        with tempfile.NamedTemporaryFile() as fish_test:
            with tempfile.NamedTemporaryFile() as fish_alias:
                configuration_details = Shell.get_conf_detail(
                    conf_path=fish_conf.name,
                    conf_alias_code='alias fuck="eval (thefuck $(fc -ln -1)); and fish"'
                )
                sys.stderr = fish_test
                how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:40:04.816508
# Unit test for function debug_time
def test_debug_time():
    with debug_time("foo"):
        pass

# Generated at 2022-06-12 10:40:07.802110
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as mock_stderr:
        debug('test')
        assert mock_stderr.write.called

# Generated at 2022-06-12 10:40:14.834700
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import sys
    import six

    if six.PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    class Command(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    output = StringIO()
    old_stdout = sys.stderr
    sys.stderr = output
    try:
        show_corrected_command(Command(u'git'))
        assert output.getvalue() == u'{const.USER_COMMAND_MARK}git\n'.format(**locals())
    finally:
        sys.stderr = old_stdout

# Generated at 2022-06-12 10:40:25.125425
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Чтобы выполнить unit test, нужно запустить тест:
    # python3 -m thefuck.shells.base_shell test_show_corrected_command
    # или
    # python3 -m unittest thefuck.shells.base_shell test_show_corrected_command

    show_corrected_command.__defaults__ = (None,) * len(
        show_corrected_command.__defaults__)
    show_corrected_command.__defaults__ = (False,) * len(
        show_corrected_command.__defaults__)

# Generated at 2022-06-12 10:40:28.889028
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(CorrectedCommand('echo fuck')) == None
    assert show_corrected_command(CorrectedCommand('echo fuck', True)) == None

# Generated at 2022-06-12 10:40:30.654966
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(CorrectedCommand('ls'))
    assert sys.stderr.getvalue().endswith(']')



# Generated at 2022-06-12 10:40:31.814425
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(fuck.shells.Shell()) == None

# Generated at 2022-06-12 10:40:32.306390
# Unit test for function debug
def test_debug():
    debug('message')

# Generated at 2022-06-12 10:40:33.936970
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('This is a test')

# Generated at 2022-06-12 10:40:39.416251
# Unit test for function debug
def test_debug():
    assert debug('current_command') == None

# Generated at 2022-06-12 10:40:41.301329
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        import time
        time.sleep(0.3)

# Generated at 2022-06-12 10:40:49.375309
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = type('', (object, ), {
        'script': [u'git', u'commit'],
        'side_effect': False})
    import StringIO
    output = StringIO.StringIO()
    sys.stderr.flush()
    saved_stdout = sys.stderr
    try:
        sys.stderr = output
        show_corrected_command(corrected_command)
        sys.stderr.flush()
        assert (output == u'\x1b[41m\x1b[37m\x1b[1m> git commit\x1b[0m\n')
    finally:
        sys.stderr = saved_stdout

# Generated at 2022-06-12 10:40:52.497733
# Unit test for function debug_time
def test_debug_time():
    """
    Tests that debug_time returns the correct time.
    """
    with debug_time('Test'):
        return time.sleep(0.5)
    assert debug('Test took: 0:00:00.500000') is True

# Generated at 2022-06-12 10:40:58.438220
# Unit test for function debug
def test_debug():
    try:
        colorama.init()
        import __builtin__
        if hasattr(__builtin__, '__dict__'):
            setattr(__builtin__, '__dict__', {'__name__': '__main__'})
        debug(u'foo')
    finally:
        if hasattr(colorama, 'deinit'):
            colorama.deinit()

# Generated at 2022-06-12 10:41:04.469777
# Unit test for function debug
def test_debug():
    try:
        log = []
        sys.stderr.write = lambda t: log.append(t)
        debug('test')
        assert log == [u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n']
    finally:
        sys.stderr.write = sys.__stderr__.write


# Generated at 2022-06-12 10:41:10.527470
# Unit test for function confirm_text
def test_confirm_text():
    from tempfile import NamedTemporaryFile
    from io import open
    from . import get_closest_match
    from .utils import get_closest_path

    with NamedTemporaryFile(mode='w+t') as script:
        script_name = get_closest_path(script.name)
        script.write(u'fuck this')
        script.flush()

        corrected_command = get_closest_match(script_name)
        confirm_text(corrected_command)
        with open('/dev/tty', 'r+t') as term:
            term.read()

# Generated at 2022-06-12 10:41:13.183388
# Unit test for function confirm_text
def test_confirm_text():
    assert u'The Fuck' in version('3.26', ('3', '5', '2'), 'shell')



# Generated at 2022-06-12 10:41:14.397206
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('wow')


# Generated at 2022-06-12 10:41:18.488519
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    def func():
        with debug_time('test'):
            return

    with mock.patch('sys.stderr', new=StringIO()) as stderr:
        func()
    assert stderr.getvalue().startswith(u'DEBUG: test took: ')



# Generated at 2022-06-12 10:41:24.413060
# Unit test for function debug
def test_debug():
    debug(u'Test debug')



# Generated at 2022-06-12 10:41:26.835742
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    show_corrected_command(
        CorrectedCommand('git add .', True)) == u'git add . (+side effect)'

# Generated at 2022-06-12 10:41:27.650934
# Unit test for function debug
def test_debug():
    assert debug('test') is None



# Generated at 2022-06-12 10:41:31.867969
# Unit test for function debug
def test_debug():
    import StringIO

    with settings(debug=True):
        buf = StringIO.StringIO()
        sys.stderr = buf
        debug(u"foo")
        sys.stderr.seek(0)
        assert buf.read() == u'DEBUG: foo\n'



# Generated at 2022-06-12 10:41:33.358173
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT



# Generated at 2022-06-12 10:41:37.866751
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock

    stderr = mock.Mock()
    sys.stderr = stderr
    show_corrected_command(mock.Mock(script='ls -la'))
    stderr.write.assert_called_once_with(u'\x1b[4m\x1b[36m[{}]\x1b[0m '
                                         u'ls -la\n'.format(const.USER_COMMAND_MARK))

# Generated at 2022-06-12 10:41:48.053204
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    from StringIO import StringIO
    from click.testing import CliRunner
    from .application import fuck
    from .shells import ConfigureFailed
    import sys
    import re

    # Capture output
    string_io = StringIO()
    sys.stdout = string_io

    # Test if alias isn't configured
    runner = CliRunner()
    result = runner.invoke(fuck, ['--alias'])
    assert result.exit_code == 0

    # Test if alias is configured
    fuck()
    ConfigurationDetails = namedtuple(
        'ConfigurationDetails', ['can_configure_automatically', 'path',
                                 'reload', 'content'])
    configuration_details = ConfigurationDetails(True, 'bashrc path',
                                                  'bash reload', 'alias fuck;')
   

# Generated at 2022-06-12 10:41:49.758843
# Unit test for function debug_time
def test_debug_time():
    """
    Make sure debug_time works as expected
    """
    assert debug_time



# Generated at 2022-06-12 10:41:51.057637
# Unit test for function debug
def test_debug():
    assert debug(u'foo') == None



# Generated at 2022-06-12 10:41:54.194978
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        debug(u'foo')
        assert mock_stderr.getvalue() == u'foo\n'



# Generated at 2022-06-12 10:42:07.839969
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    sleep_time = 0.1
    msg = 'time'
    with mock.patch('sys.stderr', new_callable=lambda: mock.Mock()) as stderr_mock,\
            mock.patch('datetime.datetime') as datetime_mock:
        datetime_started = mock.Mock()
        datetime_mock.now.return_value = datetime_started
        datetime_after = mock.Mock()
        datetime_after.__sub__.return_value = '100 ms'
        datetime_mock.now = datetime_after.now
        with debug_time(msg):
            time.sleep(sleep_time)

        assert len(stderr_mock.write.mock_calls) == 0
