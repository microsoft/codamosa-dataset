

# Generated at 2022-06-12 10:32:12.321320
# Unit test for function debug
def test_debug():
    assert not settings.debug
    msg = 'message'
    debug(msg)
    assert sys.stderr.getvalue() == ''
    settings.debug = True
    debug(msg)
    assert sys.stderr.getvalue().endswith('DEBUG: message\n')
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:32:15.894827
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({'path': '~/.bash_profile',
                            'shell': 'bash',
                            'reload': 'reload',
                            'content': 'content',
                            'can_configure_automatically': False})

# Generated at 2022-06-12 10:32:18.566897
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    This test simulate the 'corrected_command' to be replace the user command
    """
    assert show_corrected_command('ls') == 'ls'
    assert show_corrected_command('git push original') == 'git push original'

# Generated at 2022-06-12 10:32:24.676982
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    with settings(debug=True):
        before = datetime.now()
        with debug_time(u'42'):
            pass
        took = datetime.now() - before

    assert (u'42 took: 0:' in sys.stderr.getvalue())
    assert (took > timedelta(0))
    assert (took < timedelta(seconds=2))

# Generated at 2022-06-12 10:32:32.608698
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from . import output
    with patch('sys.stderr') as mocked_stderr:
        with patch('thefuck.conf.settings.no_colors', True):
            output.confirm_text('f')
            mocked_stderr.write.assert_called_with(
                '{prefix}{clear}{script} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                '/{red}ctrl+c{reset}]'.format(
                    prefix='{} '.format(const.USER_COMMAND_MARK),
                    clear='\033[1K\r',
                    script='f',
                    green='[enter/↑/↓/ctrl+c]',
                    reset='',
                    blue=''))

# Generated at 2022-06-12 10:32:41.168648
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug('Works!')
        assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Works!\n'



# Generated at 2022-06-12 10:32:48.513168
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configs = ConfigurationDetails(
        content="fuck=sudo $(fc -ln -1)",
        path="/home/bob/.bashrc",
        reload="source ~/.bashrc",
        can_configure_automatically=True
        )
    configs_no_auto = ConfigurationDetails(
        content="fuck=sudo $(fc -ln -1)",
        path="/home/bob/.bashrc",
        reload="source ~/.bashrc",
        can_configure_automatically=False
        )

    # Test without auto configuration
    how_to_configure_alias(configs_no_auto)
    assert configs_no_auto in how_to_configure_alias(configs_no_auto)

    # Test with auto configuration
    how_to_configure_alias(configs)
    assert configs in how_

# Generated at 2022-06-12 10:32:56.237255
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    from thefuck.shells import Shell
    from thefuck.conf import Settings
    from thefuck.types import Command

    _old_debug_value = Settings.debug
    Settings.debug = True

    shell = Shell()
    curr_time = datetime.now()
    command = Command('ls', '', '/tmp', timedelta(seconds=0))

    try:
        @debug_time('Testing')
        def test_ls_command(shell, command):
            shell.run(command.script)

        test_ls_command(shell, command)
    finally:
        Settings.debug = _old_debug_value

# Generated at 2022-06-12 10:32:58.513209
# Unit test for function debug_time
def test_debug_time():
    with debug_time("debug message"):
        import time
        time.sleep(0.5)
        return "Hello"

# Generated at 2022-06-12 10:33:01.377808
# Unit test for function color
def test_color():
    assert colorama.Style.BRIGHT in color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT not in color('')



# Generated at 2022-06-12 10:33:10.531178
# Unit test for function debug
def test_debug():
    import mock
    from thefuck.shells import Bash
    settings.debug = True
    with mock.patch('sys.stderr') as stderr:
        debug(u'###')
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} ###\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))

    settings.debug = False
    with mock.patch('sys.stderr') as stderr:
        debug(u'###')
        assert not stderr.write.called



# Generated at 2022-06-12 10:33:11.498862
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:33:13.378554
# Unit test for function debug_time
def test_debug_time():
    import time

    seconds = 0.1234
    with debug_time('Sleep'):
        time.sleep(seconds)

# Generated at 2022-06-12 10:33:15.451249
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug(u'foo')
    finally:
        settings.debug = False

# Generated at 2022-06-12 10:33:17.869013
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import tempfile, os
    tmpfile = tempfile.NamedTemporaryFile()
    sys.stderr = tmpfile
    show_corrected_command('corrected_command')
    tmpfile.flush()
    content = open(tmpfile.name, 'r').read()
    tmpfile.close()
    assert content == 'Fuck'

    

# Generated at 2022-06-12 10:33:18.893555
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert not settings.no_colors


# Generated at 2022-06-12 10:33:24.136746
# Unit test for function debug_time
def test_debug_time():
    import time
    from . import shell

    def echo_command(*args):
        with debug_time('test'):
            time.sleep(1)

    shell.run_command = echo_command

    result = shell.and_('echo', 'test')
    assert result.output == '\033[1K\r'

# Generated at 2022-06-12 10:33:28.936473
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class configuration_details_mock:
        def _asdict(self):
            class Config():
                bold = 'bold'
                reset = 'reset'
                reload = 'reload'
            return Config()

        can_configure_automatically = False
    how_to_configure_alias(configuration_details_mock())

# Generated at 2022-06-12 10:33:35.055862
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = type('CorrectedCommand', (), {'script': 'cd ..',
                                                      'side_effect': False})
    show_corrected_command(corrected_command)
    assert colorama.init.called, 'called init of colorama'
    assert colorama.deinit.called, 'called deinit of colorama'

# Generated at 2022-06-12 10:33:43.654781
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from StringIO import StringIO
    from thefuck.conf import settings

    with patch('sys.stderr', new_callable=StringIO) as stderr:
        settings.confirm = True
        confirm_text('ls')
        assert stderr.getvalue() == '$ ls [\x1b[32menter\x1b[39m/\x1b[34m↑\x1b[39m/\x1b[34m↓\x1b[39m/\x1b[31mctrl+c\x1b[39m]'


# Generated at 2022-06-12 10:33:48.639070
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('fuck this', False))
    show_corrected_command(CorrectedCommand('fuck that', True))



# Generated at 2022-06-12 10:33:55.248675
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .settings import debug
    with debug():
        saved_stdout = sys.stderr
        try:
            out = StringIO()
            sys.stderr = out
            debug(u'something')
            output = out.getvalue().strip()
            assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[21m\x1b[39m something'
        finally:
            sys.stderr = saved_stdout

# Generated at 2022-06-12 10:34:00.211345
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    class Args():
        debug = True

    class TestLog(object):
        def __init__(self):
            self.captured = None

        def write(self, value):
            self.captured = value

    import sys
    log = TestLog()
    sys.stderr = log

    settings.debug = True
    with debug_time('test'):
        pass
    assert 'test took: ' in log.captured

    settings.debug = False
    with debug_time('test'):
        pass
    assert log.captured is None

# Generated at 2022-06-12 10:34:05.908592
# Unit test for function color
def test_color():
    class FakeFile(object):
        def __init__(self, name):
            self.name = name

        def write(self, text):
            pass

    colorama.init(wrap=True, strip=False, file=FakeFile('stderr'))

    class FakeSettings(object):
        no_colors = False

    settings.no_colors = False

    warn('test warn')

    settings.no_colors = True
    warn('test warn')

    colorama.deinit()

# Generated at 2022-06-12 10:34:10.580544
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = CorrectedCommand(
        script='echo oops',
        side_effect=False,
        is_multiple=False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == \
        u'{prefix}echo oops\n'.format(prefix=const.USER_COMMAND_MARK)



# Generated at 2022-06-12 10:34:16.124178
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text({
        'script': 'test script',
        'side_effect': True,
    }) == u'[enter/↑/↓/ctrl+c] test script (+side effect) '
    assert confirm_text({
        'script': 'test script',
        'side_effect': False,
    }) == u'[enter/↑/↓/ctrl+c] test script '



# Generated at 2022-06-12 10:34:24.259022
# Unit test for function debug
def test_debug():
    import StringIO
    # Nothing printed when debug is off
    try:
        settings.debug = False
        out = StringIO.StringIO()
        sys.stderr = out
        debug(u'foo')
        assert out.getvalue() == ''
    finally:
        sys.stderr = sys.__stderr__

    # Something printed when debug is on
    try:
        settings.debug = True
        out = StringIO.StringIO()
        sys.stderr = out
        debug(u'foo')
        assert out.getvalue() == u'foo\n'
    finally:
        sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:34:34.778100
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import tempfile
    from . import shells

    # Command ('echo', 'test')
    # expected ('\033[1K\recho test [\033[32menter\033[39m/\033[34m↑\033[39m/\033[34m↓\033[39m/\033[31mctrl+c\033[39m]')
    (handle, temp_path) = tempfile.mkstemp()
    shell = 'fish'
    with open(temp_path, 'w') as f:
        f.write(shell)

# Generated at 2022-06-12 10:34:39.301711
# Unit test for function debug
def test_debug():
    _debug = sys.stderr.write

    calls = []

    def mock_write(txt):
        calls.append(txt)
    sys.stderr.write = mock_write

    settings.debug = False
    debug('msg1')
    assert [] == calls

    settings.debug = True
    debug('msg2')
    assert ['DEBUG: msg2\n'] == calls

    sys.stderr.write = _debug

# Generated at 2022-06-12 10:34:41.769847
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,),
                             dict(script='ls example', side_effect=False))
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:34:46.875549
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from contextlib import closing

    with closing(timedelta) as td:
        delta = timedelta.now() - timedelta.now()
        assert delta == timedelta()
        assert td.now.called



# Generated at 2022-06-12 10:34:49.530426
# Unit test for function color
def test_color():
    disabled_color = u'\033[0m'
    if not disabled_color:
        disabled_color = u''
    assert color(u'\033[0m') == disabled_color

# Generated at 2022-06-12 10:34:58.771480
# Unit test for function debug
def test_debug():

    from StringIO import StringIO
    from colorama import init as colorama_init
    from .conf import settings as default_settings

    original_stderr = sys.stderr
    stderr = StringIO()
    settings.no_colors = False
    colorama_init(autoreset=True)

    try:
        sys.stderr = stderr
        debug('msg')
    finally:
        sys.stderr = original_stderr
        settings.no_colors = default_settings.no_colors

    assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n'



# Generated at 2022-06-12 10:35:01.362787
# Unit test for function color
def test_color():
    assert color('red')('foo') == 'foo'
    settings.no_colors = True
    assert color('red')('foo') == ''



# Generated at 2022-06-12 10:35:02.889652
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == None


# Generated at 2022-06-12 10:35:09.364760
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .command import CorrectedCommand
    shell = Shell()
    shell.prefix = '.'
    shell.suffix = ';'
    shell.set_aliases({"fuck": "echo"})
    corrected_command = CorrectedCommand('fuck',
                                         'git',
                                         'fuck',
                                         'git',
                                         'fuck',
                                         shell,
                                         False,
                                         [])
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:35:17.727146
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import tempfile
    import unittest
    from mock import patch

    from thefuck.shells.default import _get_user_input, BadConfirmation

    os.environ['TF_COLORS'] = 'True'
    confirm_text(CorrectedCommand('ls', 'ls', 'ls'))
    input_ = _get_user_input()

    @patch('sys.stdout.flush')
    def test(char, mocked_stdout_flush, expected=None):
        input_.buffer = ''
        input_.pressed_keys.append(char)
        (actual, side_effect) = input_.send(char)

        mocked_stdout_flush.assert_called_once_with()
        input_.pressed_keys.pop()
        if expected:
            assert actual == expected
        assert side_effect is input

# Generated at 2022-06-12 10:35:20.422401
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time(u'Unit test'):
        assert(datetime.now() - started > datetime.now() - datetime.now())

# Generated at 2022-06-12 10:35:21.455575
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass


# Generated at 2022-06-12 10:35:23.198601
# Unit test for function confirm_text
def test_confirm_text():
    pass


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:35:32.072434
# Unit test for function debug_time
def test_debug_time():
    from unittest.mock import patch

    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('test') as _:
            pass

        debug.assert_called_once_with(u'test took: 0:00:00.000001')

# Generated at 2022-06-12 10:35:34.157305
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u"test_debug_time"):
        pass

# Generated at 2022-06-12 10:35:35.005745
# Unit test for function debug
def test_debug():
    debug('test')



# Generated at 2022-06-12 10:35:44.243674
# Unit test for function confirm_text
def test_confirm_text():
    # We need to avoid the clear sequence
    # to be able to write this text in the unit test.
    assert confirm_text(const.CorrectedCommand('ls')) == \
        u'{prefix}ls [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'\
        .format(
            prefix=const.USER_COMMAND_MARK,
            # clear='\033[1K\r',
            green=color(colorama.Fore.GREEN),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            red=color(colorama.Fore.RED))

# Generated at 2022-06-12 10:35:49.106978
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .correct import CorrectedCommand
    import sys
    import os
    sys.stdout = open(os.devnull, 'w')
    sys.stderr = open(os.devnull, 'w')
    shell = Shell('fish')
    show_corrected_command(CorrectedCommand('echo 123', False, shell))

# Generated at 2022-06-12 10:35:50.305334
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:35:54.016497
# Unit test for function debug_time
def test_debug_time():
    import time
    import StringIO
    out = StringIO.StringIO()

    with debug_time('test'):
        time.sleep(0.1)
    out.seek(0)
    assert 'test took: ' in out.buf

# Generated at 2022-06-12 10:35:55.646278
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color(None) == ''

# Generated at 2022-06-12 10:35:59.010946
# Unit test for function debug
def test_debug():
    """Unit test for function debug"""
    # it shouldn't print anything if debug is off
    with debug_time('test'):
        pass
    # it should print something if debug is on
    settings.debug = True
    debug('test debug')

# Generated at 2022-06-12 10:36:04.744041
# Unit test for function debug
def test_debug():
    import StringIO
    old_std_err = sys.stderr
    fake_std_err = StringIO.StringIO()
    sys.stderr = fake_std_err
    settings.debug = True
    debug('Debug!')
    settings.debug = False
    sys.stderr = old_std_err
    assert(fake_std_err.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Debug!\n')

# Generated at 2022-06-12 10:36:13.078501
# Unit test for function color
def test_color():
    assert not color(colorama.Back.RED)
    assert not color(colorama.Fore.RED)

    settings.no_colors = False
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT)
    settings.no_colors = True

# Generated at 2022-06-12 10:36:23.099829
# Unit test for function confirm_text
def test_confirm_text():
    class Command(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect


# Generated at 2022-06-12 10:36:26.365816
# Unit test for function confirm_text
def test_confirm_text():
    # Function confirm_text should print two lines with given script
    class TestScript():
        def __init__(self):
            self.script = 'ls\ncat'
            self.side_effect = False

    confirm_text(TestScript())

# Generated at 2022-06-12 10:36:31.018722
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    import mock
    mock_debug = mock.Mock()
    with mock.patch('thefuck.shells.get_debug_function',
                    return_value=mock_debug):
        with debug_time('123'):
            mock_debug.assert_called_once_with('123 took: 0:00:00.000000')

# Generated at 2022-06-12 10:36:33.492691
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .utils import _echo
    corrected_command = Command(script='git push origin master')
    assert show_corrected_command(corrected_command) == _echo('git push origin master')

# Generated at 2022-06-12 10:36:35.918862
# Unit test for function debug_time
def test_debug_time():
    # pylint: disable=W0612
    with debug_time(u'some message'):
        pass

    # pylint: enable=W0612

# Generated at 2022-06-12 10:36:36.695319
# Unit test for function debug_time
def test_debug_time():
    debug('test')



# Generated at 2022-06-12 10:36:40.553322
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    for i in range(100000):
        pass
    with debug_time("test_debug_time"):
        for i in range(100000):
            pass
    if (datetime.now() - started).seconds > 0:
        print("Unit test for function debug_time success")
    else:
        print("Unit test for function debug_time failed")


# Generated at 2022-06-12 10:36:41.725884
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass



# Generated at 2022-06-12 10:36:45.564758
# Unit test for function color
def test_color():
    color_enabled = color('bold')
    color_disabled = color('')

    settings.no_colors = False
    assert color_enabled == colorama.Style.BRIGHT
    assert color_disabled == ''

    settings.no_colors = True
    assert color_enabled == ''
    assert color_disabled == ''

# Generated at 2022-06-12 10:36:51.596058
# Unit test for function color
def test_color():
    assert color('green') == 'green'



# Generated at 2022-06-12 10:36:54.629257
# Unit test for function debug
def test_debug():
    import StringIO
    _old_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    try:
        debug('test')
        assert u'test' in sys.stderr.getvalue()
    finally:
        sys.stderr = _old_stderr

# Generated at 2022-06-12 10:36:58.787251
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + colorama.Back.WHITE) == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED + colorama.Back.WHITE) == colorama.Fore.RED + colorama.Back.WHITE

# Generated at 2022-06-12 10:37:01.366424
# Unit test for function confirm_text
def test_confirm_text():
    conf = confirm_text('fuck')
    assert conf == u"[б]fuck [enter]/[↑]/[↓]/[ctrl+c]\n"

# Generated at 2022-06-12 10:37:06.080748
# Unit test for function color
def test_color():
    assert color('')('foo') == 'foo'
    assert color('')("foo") == 'foo'
    assert color('')(u"foo") == 'foo'
    assert color('')(u"fóo") == 'foo'
    assert color('')(u"fóò") == 'foo'
    assert color('')(u"fóò\n") == 'foo\n'



# Generated at 2022-06-12 10:37:10.392010
# Unit test for function confirm_text
def test_confirm_text():
    import io
    output = io.StringIO()
    sys.stderr = output
    from thefuck.types import CorrectedCommand
    confirm_text(CorrectedCommand("ls", side_effect=True))
    sys.stderr = sys.__stderr__
    assert u'ls (+side effect)' in output.getvalue()

# Generated at 2022-06-12 10:37:11.373474
# Unit test for function debug
def test_debug():
    with debug_time(u'test'):
        1+1

# Generated at 2022-06-12 10:37:13.351001
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.posix import PosixShell
    shell = PosixShell()
    assert confirm_text(shell.get_command()) == ''

# Generated at 2022-06-12 10:37:14.922811
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command) == None


# Generated at 2022-06-12 10:37:19.435608
# Unit test for function debug
def test_debug():
    # pylint: disable=line-too-long,C0301
    assert u'\x1b[1mDEBUG:\x1b[0m \x1b[34mbla\x1b[0m' == debug(u'bla')
    assert u'DEBUG: bla' == debug(u'bla')

# Generated at 2022-06-12 10:37:26.922720
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    try:
        how_to_configure_alias(None)
    except ImportError:
        pass



# Generated at 2022-06-12 10:37:30.463818
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('some msg') as f:
        assert f is None
    delta = datetime.now() - started
    assert delta.seconds == 0
    assert delta.microseconds < 10**5 # 10**5 is 0.1 sec.



# Generated at 2022-06-12 10:37:31.057132
# Unit test for function debug_time
def test_debug_time():
    assert True

# Generated at 2022-06-12 10:37:38.060177
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock, patch

    with patch.object(sys.modules[__name__], 'datetime') as mock_datetime:
        mock_datetime.now.return_value = 1
        with debug_time('test'):
            mock_datetime.now.return_value = 11
        mock_datetime.now.return_value = 1

    mock_datetime.now.assert_any_call()
    mock_datetime.now.assert_any_call()
    assert mock_datetime.now.call_count == 4

    with patch.object(sys.modules[__name__], 'debug') as mock_debug:
        with debug_time('test'):
            mock_datetime.now.return_value = 11


# Generated at 2022-06-12 10:37:38.583052
# Unit test for function debug_time
def test_debug_time():
    func()


# Generated at 2022-06-12 10:37:42.757753
# Unit test for function debug
def test_debug():
    from io import StringIO
    import re
    assert re.match(
        r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d{3} DEBUG: hello traceback\n$',
        StringIO()._debug('hello traceback'))



# Generated at 2022-06-12 10:37:49.190455
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells.bash import Bash
    bash = Bash()
    bash.script = 'command'
    bash.side_effect = True

    expected = '\x1b[33m{}\x1b[0m\x1b[1mcommand\x1b[0m (+side effect)\n'.format(const.USER_COMMAND_MARK)

    show_corrected_command(bash)

    assert sys.stderr.getvalue() == expected

# Generated at 2022-06-12 10:37:51.332780
# Unit test for function debug_time
def test_debug_time():
    from . import debug
    from .conf import settings
    settings.debug = True
    @debug_time('test')
    def test():
        pass
    test()

# Generated at 2022-06-12 10:37:52.601879
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('') == False

# Generated at 2022-06-12 10:37:54.348586
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    print(confirm_text(Shell.from_cloned_env().and_(u'ls')))

# Generated at 2022-06-12 10:38:02.851227
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand, Script
    corrected_command = CorrectedCommand(script=Script.from_shell('git status --porcelain'), side_effect=False)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:38:04.036340
# Unit test for function debug_time
def test_debug_time():
    message = "Test debug_time"
    debug_time(message)

# Generated at 2022-06-12 10:38:04.852768
# Unit test for function confirm_text
def test_confirm_text():
	confirm_text("ls")

# Generated at 2022-06-12 10:38:15.525062
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = open('/tmp/test_confirm_text.txt', 'w')
    corrected_command = "example command"
    confirm_text(corrected_command)
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:38:19.944084
# Unit test for function debug
def test_debug():
    sys.stderr.write('\n--- test_debug ---\n')
    settings.debug = True
    debug('debug message')
    settings.debug = False
    debug('debug message')
    sys.stderr.write('--- test_debug passed ---\n\n')


# Generated at 2022-06-12 10:38:21.867476
# Unit test for function debug_time
def test_debug_time():
    debug_time_check = 0
    with debug_time('test'):
        debug_time_check = 1
    assert debug_time_check == 1

# Generated at 2022-06-12 10:38:24.069050
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class FakeCmd(object):
        script = 'git push origin HEAD:master'
        side_effect = False

    show_corrected_command(FakeCmd)

# Generated at 2022-06-12 10:38:26.380152
# Unit test for function debug
def test_debug():
    with settings.debug:
        settings.debug = True
        debug(u"test")
        assert sys.stderr

# Generated at 2022-06-12 10:38:33.074718
# Unit test for function confirm_text
def test_confirm_text():
    clear = u'\033[1K\r'
    script = u'script'
    prefix = const.USER_COMMAND_MARK
    side_effect = u' (+side effect)'

    reset = color(colorama.Style.RESET_ALL)
    green = color(colorama.Fore.GREEN)
    red = color(colorama.Fore.RED)
    blue = color(colorama.Fore.BLUE)
    bold = color(colorama.Style.BRIGHT)

    expected_text_without_colorama = u'{}{}{}{}{} [enter/↑/↓/ctrl+c]'.format(
        prefix, clear, bold, script, reset)

# Generated at 2022-06-12 10:38:40.210605
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from tempfile import NamedTemporaryFile
    from .utils import get_all_executables_in_path
    from .corrector import CorrectedCommand

    temp = NamedTemporaryFile(delete=False)
    temp.close()

    # Just to be sure that we will have some executable
    executables = get_all_executables_in_path()
    assert not executables.isdisjoint(['ls', 'rm'])

    show_corrected_command(CorrectedCommand())
    show_corrected_command(CorrectedCommand(script='ls', side_effect=False))
    show_corrected_command(
        CorrectedCommand(script='rm ' + temp.name, side_effect=True))

    # TODO: check if all outputs were the same as expected
    # (there is no way to do it right now)

# Generated at 2022-06-12 10:38:49.940583
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand(u'git push',
                                            side_effect=True))
    show_corrected_command(CorrectedCommand(u'mv file /tmp',
                                            side_effect=False))

# Generated at 2022-06-12 10:38:53.430333
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # To test if the configuration is already set
    already_configured()
    # To test if the configuration is done successfully
    configured_successfully()
    # To test if the configuration can be done automatically
    how_to_configure_alias_automatically()

# Generated at 2022-06-12 10:38:55.653127
# Unit test for function color
def test_color():
    assert(color(colorama.Fore.GREEN) == colorama.Fore.GREEN)

# Generated at 2022-06-12 10:38:57.017279
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('corrected_command') == 'corrected_command'

# Generated at 2022-06-12 10:38:59.657092
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN)
    settings.no_colors = True
    assert not color(colorama.Fore.GREEN)

# Generated at 2022-06-12 10:39:03.356883
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    content = "alias fuck='eval $(thefuck $(fc -ln -1))'"
    path = ".zshrc"
    reload = "source .zshrc"
    how_to_configure_alias((content, path, reload, True))


# Generated at 2022-06-12 10:39:13.123760
# Unit test for function debug_time
def test_debug_time():
    import os
    import re
    import sys
    import unittest
    import mock
    from datetime import timedelta

    from tests.tools import get_settings

    class TestDebugTime(unittest.TestCase):
        @mock.patch('sys.stderr.write')
        def test_debug_time(self, stderr_write):
            settings = get_settings({'debug': True})
            with settings.debug_time('test'):
                pass
            msg = re.compile(u'test took: .* sec')
            stderr_write.assert_called_with(msg)

        @mock.patch('sys.stderr.write')
        def test_debug_time_disabled(self, stderr_write):
            settings = get_settings({'debug': False})

# Generated at 2022-06-12 10:39:14.696960
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:39:19.705090
# Unit test for function debug_time
def test_debug_time():
    from .contextmanagers import debug_time
    from datetime import timedelta
    duration = timedelta(seconds=4)

    with debug_time('foo') as msg:
        assert msg == 'foo took: 0:00:00'
        from time import sleep
        sleep(duration.total_seconds())

    assert msg == 'foo took: {}'.format(duration)

# Generated at 2022-06-12 10:39:29.575265
# Unit test for function confirm_text
def test_confirm_text():
    import curses
    import textwrap

    curses.setupterm()

    from .shells.posix import get_aliases
    from .shells.bash import Shell

    bash_alias = get_aliases(Shell())

    def test(cmd, expected):
        confirm_text(bash_alias[cmd])
        assert sys.stderr.getvalue() == textwrap.dedent(expected).strip() + '\n'
        sys.stderr.seek(0)
        sys.stderr.truncate()

    test('git log', """\
        git log [enter/↑/↓/ctrl+c]""")
    test('git log ', """\
        git log  [enter/↑/↓/ctrl+c]""")

# Generated at 2022-06-12 10:39:37.418307
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .shells.bash import Bash
    from .shells.fish import Fish
    from .shells.zsh import Zsh
    from .install_config import ConfigurationDetails
    from . import settings
    settings.no_colors = True

    for shell in [Bash(), Fish(), Zsh()]:
        configuration_details = ConfigurationDetails('', '', '', shell, True)
        how_to_configure_alias(configuration_details)
        print('')



# Generated at 2022-06-12 10:39:40.783404
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('pwd') == '\033[1K\r{prefix}pwd [enter/↑/↓/ctrl+c]'
    confirm_text('ls -la') == '\033[1K\r{prefix}ls -la [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:39:45.381892
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({
        'path': '/home/nvbn/.config/thefuck/thefuck.cfg',
        'content': 'alias=fuck',
        'reload': 'exec $SHELL -l',
        'default_profile': 'default',
        'can_configure_automatically': True
        })

# Generated at 2022-06-12 10:39:46.262418
# Unit test for function color
def test_color():
    assert color(u'red') == colorama.Fore.RED

# Generated at 2022-06-12 10:39:56.763576
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from io import StringIO

    from . import config

    (orig_stdout, orig_stderr) = (sys.stdout, sys.stderr)

# Generated at 2022-06-12 10:39:58.513702
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    settings.no_colors = True
    assert color('blue') == ''

# Generated at 2022-06-12 10:40:00.296279
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('sleep'):
        time.sleep(2)

if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:40:02.875850
# Unit test for function debug_time
def test_debug_time():
    import time 
    time.sleep(1)


if __name__ == '__main__':
    with debug_time('sleep'):
        time.sleep(1)

# Generated at 2022-06-12 10:40:04.337726
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('wat'):
        time.sleep(0.2)

# Generated at 2022-06-12 10:40:05.891908
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('foo'):
        time.sleep(0.5)



# Generated at 2022-06-12 10:40:12.582238
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        time.sleep(2)


# Generated at 2022-06-12 10:40:22.157372
# Unit test for function confirm_text
def test_confirm_text():
     with patch('sys.stderr', new=StringIO()) as stderr_mock:
         confirm_text(CorrectedCommand('script', True))
     assert ('{prefix}{"script"} (+side effect) '
             '[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
             '/{red}ctrl+c{reset}]').format(
                 prefix=const.USER_COMMAND_MARK,
                 green=color(colorama.Fore.GREEN),
                 red=color(colorama.Fore.RED),
                 reset=color(colorama.Style.RESET_ALL),
                 blue=color(colorama.Fore.BLUE)) in stderr_mock.getvalue()

# Generated at 2022-06-12 10:40:29.893939
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from thefuck.conf import SETTINGS_TEMPLATE, load_settings, get_settings
    import thefuck.main
    load_settings(SETTINGS_TEMPLATE)
    SETTINGS = get_settings()
    SETTINGS.is_wrong_matched_command = False
    SETTINGS.is_confirm_configured = False
    SETTINGS.is_alias_configured = False

    out = StringIO()
    sys.stdout = out
    thefuck.main.main()
    sys.stdout = sys.__stdout__
    assert out.getvalue().startswith(u'[WARN] Can not find any command') == True


# Generated at 2022-06-12 10:40:36.637590
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
        path='test_path',
        content='test_content',
        reload='test_reload',
        can_configure_automatically=True)


# Generated at 2022-06-12 10:40:41.345145
# Unit test for function debug
def test_debug():
    import pytest
    from mock import patch

    with patch('thefuck.utils.settings', debug=True):
        debug('msg') == u'\033[34m\033[1mDEBUG:\033[21m \033[39mmessage\n'

    with patch('thefuck.utils.settings', debug=False):
        debug('msg') == u''


# Generated at 2022-06-12 10:40:43.541308
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''

# Generated at 2022-06-12 10:40:52.537915
# Unit test for function confirm_text
def test_confirm_text():
    from_ = const.USER_COMMAND_MARK + 'sudo python'
    saved_stdout = sys.stderr
    try:
        from cStringIO import StringIO
        out = StringIO()
        sys.stderr = out

        confirm_text(from_)
        output = out.getvalue().strip()
    finally:
        sys.stderr = saved_stdout
    assert output == (const.USER_COMMAND_MARK + 'sudo python '
                      '[\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/'
                      '\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]')

# Generated at 2022-06-12 10:40:59.851360
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import os

    output = StringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = output

    show_corrected_command('git commit -m "lalonala"')

    sys.stdout = old_stdout

    assert output.getvalue() == os.linesep.join(
        ['{prefix}git commit -m "lalonala"'.format(
             prefix=const.USER_COMMAND_MARK)]) + os.linesep

# Generated at 2022-06-12 10:41:02.367088
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-12 10:41:03.329848
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'Test'):
        pass

# Generated at 2022-06-12 10:41:09.740101
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command("Test", "Test")
    confirm_text("Test", "Test")

# Generated at 2022-06-12 10:41:12.667050
# Unit test for function debug
def test_debug():
    from tests.utils import mock

    with mock.patch.object(sys.stderr, 'write') as write:
        debug('test')

        assert write.called
        write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')


# Generated at 2022-06-12 10:41:14.526933
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrected_command import CorrectedCommand
    show_corrected_command(CorrectedCommand('test', True))



# Generated at 2022-06-12 10:41:23.316879
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(
        CorrectedCommand(script=None, side_effect=False)
    ) == const.USER_COMMAND_MARK
    assert confirm_text(
        CorrectedCommand(script='pwd', side_effect=True)
    ) == const.USER_COMMAND_MARK + 'pwd (+side effect) ' \
        '[\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'

# Generated at 2022-06-12 10:41:24.827029
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert (how_to_configure_alias) is not None

# Generated at 2022-06-12 10:41:32.394523
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.shells import fish, zsh
    configuration_details = fish.ConfigurationDetails(
        '~/.config/fish/config.fish',
        'thefuck --alias > ~/.config/fish/conf.d/thefuck.fish'
        '; source ~/.config/fish/conf.d/thefuck.fish',
        'source ~/.config/fish/config.fish')


# Generated at 2022-06-12 10:41:35.526536
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # If configuration_details is None
    configuration_details = None
    how_to_configure_alias(configuration_details)
    # If configuration_details is not None
    configuration_details = ConfigurationDetails('content', 'path', 'reload', 'second_try')
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:41:37.943911
# Unit test for function debug
def test_debug():
    assert debug('test') == sys.stderr.write('\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-12 10:41:39.704494
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:41:41.992051
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time("Hello"):
            pass
    except:
        pass

# Generated at 2022-06-12 10:41:48.755018
# Unit test for function debug_time
def test_debug_time():
    import datetime
    import time
    with debug_time('test1'):
        time.sleep(0.01)

# Generated at 2022-06-12 10:41:50.165081
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command("echo hello") == "echo hello"

# Generated at 2022-06-12 10:41:51.446589
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # TODO: Unit test for function show_corrected_command
    return True

# Generated at 2022-06-12 10:41:54.823041
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as temp:
        temp_file = temp.name
        os.system("touch " + temp_file)
        how_to_configure_alias(None)
        assert os.path.isfile(temp_file)

# Generated at 2022-06-12 10:41:59.351433
# Unit test for function debug_time
def test_debug_time():
    from sys import stderr
    from datetime import datetime

    with debug_time('Test'):
        assert False

    assert stderr.getvalue().endswith('Test took: 0:00:00\n')

    with debug_time('Test'):
        time = datetime.now()
        while time + const.SECONDS_1 >= datetime.now():
            pass

    assert stderr.getvalue().endswith('Test took: 0:00:01\n')

# Generated at 2022-06-12 10:42:00.065605
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:42:02.189408
# Unit test for function debug_time
def test_debug_time():

    import time

    counter = 0
    with debug_time('test_debug_time'):
        time.sleep(1)

    assert counter == 0

# Generated at 2022-06-12 10:42:02.685692
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('vim file.py')

# Generated at 2022-06-12 10:42:05.974637
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=FakeCorrectedCommand(script=u'test', side_effect=False))
    confirm_text(corrected_command=FakeCorrectedCommand(script=u'test', side_effect=True))

