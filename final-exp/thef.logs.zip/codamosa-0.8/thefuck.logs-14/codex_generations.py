

# Generated at 2022-06-12 10:32:15.817386
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('thedebug')
        stderr.write.assert_called_once_with(
            u'\x1b[36m\x1b[1mDEBUG:\x1b[0m thedebug\n')

# Generated at 2022-06-12 10:32:16.621373
# Unit test for function debug
def test_debug():
    assert debug is not None



# Generated at 2022-06-12 10:32:18.056324
# Unit test for function debug
def test_debug():
    from .conf import set_settings
    set_settings(True)
    debug('DEBUG message')



# Generated at 2022-06-12 10:32:19.208448
# Unit test for function debug_time

# Generated at 2022-06-12 10:32:29.689638
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .const import USER_COMMAND_MARK
    from .types import CorrectedCommand

    corrected_command = CorrectedCommand(
        script=u'test',
        side_effect=GlobalSideEffect())
    stdout_ = sys.__stdout__.write

    def _test(colorama):
        reset_all = colorama.Style.RESET_ALL
        bold = colorama.Style.BRIGHT
        back_red = colorama.Back.RED
        fore_white = colorama.Fore.WHITE


# Generated at 2022-06-12 10:32:32.970992
# Unit test for function how_to_configure_alias

# Generated at 2022-06-12 10:32:34.345672
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass



# Generated at 2022-06-12 10:32:35.324850
# Unit test for function debug
def test_debug():
    assert debug('test') == None


# Generated at 2022-06-12 10:32:36.684318
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None



# Generated at 2022-06-12 10:32:40.257846
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch('thefuck.shells.base.debug') as debug:
        with debug_time('some message'):
            pass
        debug.assert_called_once_with(u'some message took: {}'.format(
            timedelta(seconds=0)))

# Generated at 2022-06-12 10:32:44.204631
# Unit test for function color
def test_color():
    assert color('') == ''



# Generated at 2022-06-12 10:32:45.144776
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(1)

# Generated at 2022-06-12 10:32:48.806287
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    start_time = datetime.now()
    with debug_time("Some debug time"):
        for i in xrange(100000):
            pass
    finish_time = datetime.now()
    assert finish_time > start_time

# Generated at 2022-06-12 10:32:58.908177
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.shells import Bash

    shell = Bash()
    path = shell.config_file.replace('~', '~/home')
    how_to_configure_alias(shell.get_configuration_details({
        'alias': 'fuck',
        'script': path
    })) == u"""Seems like {bold}fuck{reset} alias isn't configured!
Please put {bold}alias fuck='python ~/home/thefuck/thefuck/__main__.py' # Evaluate scripts in the current shell{reset} in your {bold}~/.bashrc{reset} and apply changes with {bold}source ~/.bashrc{reset} or restart your shell.
Or run {bold}fuck{reset} a second time to configure it automatically.
More details - https://github.com/nvbn/thefuck#manual-installation""".format

# Generated at 2022-06-12 10:33:00.359545
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test msg"):
        pass

# Generated at 2022-06-12 10:33:08.797472
# Unit test for function debug_time
def test_debug_time():
    def test():
        import time
        time.sleep(0.0002)

    from mock import patch
    with patch('sys.stderr.write') as sys_stderr_write:
        with debug_time('Test'):
            test()

        sys_stderr_write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} Test took: {}\n'.format(mock.ANY,
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)))


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:33:10.494158
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:33:15.353762
# Unit test for function debug
def test_debug():
    """Test that debug prints"""
    import io
    import mock
    import sys

    with mock.patch('sys.stderr', new=io.StringIO()) as fake_stderr:
        debug('test')
        assert 'test' in fake_stderr.getvalue()

    # Reset mocked object
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:33:22.380352
# Unit test for function debug
def test_debug():
    import mock
    import sys
    sys.stderr = mock.Mock()
    settings.debug = True
    debug(u'instance')

    sys.stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m instance\n')  # noqa

    settings.debug = False



# Generated at 2022-06-12 10:33:23.276953
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None



# Generated at 2022-06-12 10:33:27.575027
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command="ls -al")

# Generated at 2022-06-12 10:33:36.068183
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_output():
        old, sys.stderr = sys.stderr, StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old

    with capture_output() as output:
        debug('test')
    assert 'test' in output.getvalue()

    with capture_output() as output:
        settings.debug = False
        debug('test')
    assert not output.getvalue()

# Generated at 2022-06-12 10:33:38.489739
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(1)


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:33:40.324512
# Unit test for function debug_time
def test_debug_time():
    def sleep():
        import time
        time.sleep(1)
    with debug_time('test'):
        sleep()

# Generated at 2022-06-12 10:33:43.559776
# Unit test for function confirm_text
def test_confirm_text():
    """Should show script and confirm options"""

    corrected_command = 'echo "pew" && echo "pew"'
    confirm_text(corrected_command)



# Generated at 2022-06-12 10:33:47.673010
# Unit test for function debug
def test_debug():
    from io import StringIO
    with mock.patch('sys.stderr') as stderr:
        debug('debug')
        assert stderr.write.called

    settings.debug = False

    with mock.patch('sys.stderr', new_callable=StringIO) as stderr:
        debug('debug')
        assert stderr.write.called is False

# Generated at 2022-06-12 10:33:51.933937
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = MockCommand()
    confirm_text(corrected_command)
    corrected_command.script = 'echo 123'
    confirm_text(corrected_command)
    corrected_command.side_effect = True
    confirm_text(corrected_command)



# Generated at 2022-06-12 10:33:58.709462
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import sys
    class ConfigurationDetails(object):
        def __init__(self, path, content, reload, can_configure_automatically):
            self.path = path
            self.content = content
            self.reload = reload
            self.can_configure_automatically = can_configure_automatically
    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        content='echo "alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        reload='source ~/.bashrc',
        can_configure_automatically=True
    )
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:34:03.034434
# Unit test for function debug
def test_debug():
    """Test for function debug."""
    import StringIO
    from .conf import set_settings
    set_settings({"debug":True})
    content = StringIO.StringIO()
    sys.stderr = content
    debug("debug message")
    assert content.getvalue() == '\x1b[94m\x1b[1mDEBUG:\x1b[0m debug message\n'



# Generated at 2022-06-12 10:34:04.019529
# Unit test for function confirm_text
def test_confirm_text():
    # TODO: test
    pass

# Generated at 2022-06-12 10:34:16.362369
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # If there is no side_effects
    corrected_command = FakeCommand('ls', False)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == ">ls\n"
    # If there are side_effects
    corrected_command = FakeCommand('ls', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == ">ls (+side effect)\n"



# Generated at 2022-06-12 10:34:26.067182
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_sys_output():
        capture_out, capture_err = StringIO(), StringIO()
        current_out, current_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = capture_out, capture_err
            yield capture_out, capture_err
        finally:
            sys.stdout, sys.stderr = current_out, current_err

    with capture_sys_output() as (out, err):
        debug(u'foo')

    assert err.getvalue() == ''
    assert out.getvalue() == u''

    with capture_sys_output() as (out, err):
        debug(u'foo')


# Generated at 2022-06-12 10:34:30.109938
# Unit test for function debug_time
def test_debug_time():
    import time
    import threading
    t=threading.Thread(target=time.sleep, args=(5,))
    t.setDaemon(True)

    with debug_time('Debug time') as d:
        t.start()
        t.join()
    assert d == None

# Generated at 2022-06-12 10:34:32.420315
# Unit test for function debug_time
def test_debug_time():
    for i in range(1, 2):
        with debug_time(u'log {i}'.format(i=i)):
            pass

# Generated at 2022-06-12 10:34:33.412934
# Unit test for function debug_time
def test_debug_time():
    debug_time('mytest')

# Generated at 2022-06-12 10:34:35.348463
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print('\n')
    how_to_configure_alias('')



# Generated at 2022-06-12 10:34:36.558069
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        import time
        time.sleep(0.1)

# Generated at 2022-06-12 10:34:43.817655
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command

    def print_side_effect(cmd):
        """Dummy side_effect function for unit testing."""
        return cmd

    # No-side-effect case
    corrected_command = Command('ls', 'ls --color=auto')
    show_corrected_command(corrected_command)
    # Side-effect case
    corrected_command = Command('ls', print_side_effect, 'ls --color=auto')
    show_corrected_command(corrected_command)

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:34:44.389735
# Unit test for function debug
def test_debug():
    debug("test")

# Generated at 2022-06-12 10:34:47.142095
# Unit test for function color
def test_color():
    assert '\033[0;30;41mtest\033[0m' == color(False, '\033[0;30;41mtest\033[0m')
    assert 'test' == color(True, '\033[0;30;41mtest\033[0m')



# Generated at 2022-06-12 10:35:04.525033
# Unit test for function debug
def test_debug():
    def test_assert(s, expected):
        """Assert to expected output if equals to `s` output."""
        import cStringIO
        old_stdout = sys.stdout
        sys.stdout = cStringIO.StringIO()

        try:
            settings.debug = True
            debug(u'This is a test {"key": "value"}')
            s.assertEqual(sys.stdout.getvalue(), expected)
        finally:
            settings.debug = False
            sys.stdout = old_stdout

    import unittest
    class TestDebug(unittest.TestCase):
        def test_without_colors(self):
            test_assert(self, u'DEBUG: This is a test {u\'key\': u\'value\'}\n')


# Generated at 2022-06-12 10:35:07.739791
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('fuck'))
    show_corrected_command(CorrectedCommand('fuck', side_effect=True))



# Generated at 2022-06-12 10:35:11.790942
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import pytest
    from thefuck.types import CorrectedCommand
    corrected_command = CorrectedCommand('ls', None)
    show_corrected_command(corrected_command)
    corrected_command = CorrectedCommand('ls', True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:35:14.039618
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='ls -al') == (
        u'[f] ls -al [enter]/[↑]/[↓]/[ctrl+c]')

# Generated at 2022-06-12 10:35:16.186042
# Unit test for function color
def test_color():
    assert not color('')
    assert color('') == (colorama.Back.RED + colorama.Fore.WHITE
                         + colorama.Style.BRIGHT)

# Generated at 2022-06-12 10:35:17.792342
# Unit test for function debug
def test_debug():
    try:
        debug('test_debug')
    except Exception:
        raise Exception('test_debug failed')



# Generated at 2022-06-12 10:35:18.773287
# Unit test for function debug_time
def test_debug_time():
    with debug_time('time'):
        pass

# Generated at 2022-06-12 10:35:21.551932
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(script='gut', side_effect=False) == \
           const.USER_COMMAND_MARK + 'gut'

# Generated at 2022-06-12 10:35:25.338782
# Unit test for function debug
def test_debug():
    orig_stderr = sys.stderr
    sys.stderr = sys.stdout

    debug_msg = 'this is debug'
    debug(debug_msg)

    sys.stderr = orig_stderr

# Generated at 2022-06-12 10:35:29.833858
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert (how_to_configure_alias == u"""
        Seems like {bold}fuck{reset} alias isn't configured!
        Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.
        Or run {bold}fuck{reset} a second time to configure it automatically.
        More details - https://github.com/nvbn/thefuck#manual-installation
        """)

# Generated at 2022-06-12 10:35:45.412655
# Unit test for function confirm_text
def test_confirm_text():
    import textwrap
    from contextlib import nested
    from mock import patch
    with nested(
            patch('thefuck.shells.and_', return_value='{}'),
            patch('thefuck.shells.get_shell', return_value=MockShell())) as (
                and_, _):
        with patch('sys.stderr', new_callable=StringIO) as stderr:
            from thefuck.utils import confirm_text
            confirm_text(MockCommand())
            assert stderr.getvalue() == textwrap.dedent('''\
            {}[FIX] f**k you +side effect (enter/↑/↓/ctrl+c)''').format(
                const.USER_COMMAND_MARK)
            stderr.seek(0)

# Generated at 2022-06-12 10:35:45.999044
# Unit test for function debug_time
def test_debug_time():
    pass

# Generated at 2022-06-12 10:35:51.764391
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('thefuck.utils.sys.stderr') as stderr:
        debug('msg')
        assert stderr.write.called
        stderr.write.assert_called_once_with(
            u'{blue}{bold}DEBUG:{reset} msg\n'.format(
                blue=color(colorama.Fore.BLUE),
                reset=color(colorama.Style.RESET_ALL),
                bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-12 10:35:54.060544
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'ls'
    show_corrected_command(corrected_command)
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:35:56.912765
# Unit test for function color
def test_color():
    colorama.init()
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:35:57.938411
# Unit test for function debug_time
def test_debug_time():
    assert timing(1) == 1


# Generated at 2022-06-12 10:36:06.559516
# Unit test for function debug
def test_debug():
    from .utils import get_configuration_details, get_shell_info

    debug_prefix = color(colorama.Fore.BLUE + colorama.Style.BRIGHT)
    debug_reset = color(colorama.Style.RESET_ALL)

    debug(u'unicode')
    debug('unicode'.encode('utf-8'))
    debug(u'{} {}'.format(u'строка', u'со специальными символами'))
    debug(u'{} {} {}'.format(u'строка', 1, debug_prefix))
    debug(u'{} {} {}'.format(u'строка', 1, debug_reset))

# Generated at 2022-06-12 10:36:14.550200
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import ConfigurationDetails
    from . import const

    const.NO_COLORAMA = True
    settings.no_colors = True
    how_to_configure_alias(ConfigurationDetails(
        content=u'eval $(thefuck --alias)',
        path=u'~/.zshrc',
        reload=u'source ~/.zshrc',
        can_configure_automatically=True))
    assert const.STDOUT[0] == u'Seems like fuck alias isn\'t configured!\n'
    assert const.STDOUT[1] == u'Please put eval $(thefuck --alias) in your ~/.zshrc and apply changes with source ~/.zshrc or restart your shell.\n'
    assert const.STDOUT[2] == u"Or run fuck a second time to configure it automatically.\n"
    assert const.STDOUT

# Generated at 2022-06-12 10:36:16.313119
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('y') == u'[enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:36:19.014675
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text("echo 123")
    #confirm_text("echo 123") should equal to
    #echo 123 [enter/↑/↓/ctrl+c]

# Generated at 2022-06-12 10:36:33.876319
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Corrected command
    corrected_command = "ls"
    expected_output = '    {0}ls\n'.format(const.USER_COMMAND_MARK)

    class FakeStdOut(object):
        def __init__(self):
            self.content = []

        def write(self, s):
            self.content.append(s)

        def empty(self):
            self.content = []

        def __str__(self):
            return ''.join(self.content)

    sys.stderr = FakeOut = FakeStdOut()

    show_corrected_command(corrected_command)
    assert FakeStdOut.__str__(FakeOut) == expected_output

    # Corrected command with side effect
    corrected_command = "ls"

# Generated at 2022-06-12 10:36:36.072963
# Unit test for function debug_time
def test_debug_time():
    def test():
        import time
        time.sleep(0.2)
    with debug_time('time'):
        test()

    assert True

# Generated at 2022-06-12 10:36:41.018309
# Unit test for function debug
def test_debug():
    import StringIO
    test_str = 'test_str'
    out = StringIO.StringIO()
    try:
        sys.stderr = out
        debug(test_str)
    finally:
        sys.stderr = sys.__stderr__
    output = out.getvalue().strip()
    assert (output ==
            color(colorama.Fore.BLUE + colorama.Style.BRIGHT) +
            'DEBUG: ' +
            color(colorama.Style.RESET_ALL) + test_str)

# Generated at 2022-06-12 10:36:43.940640
# Unit test for function debug
def test_debug():
    from mock import call, patch
    stderr = patch('sys.stderr')
    with stderr as stderr_mock:
        debug('fuck')
    stderr_mock.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m fuck\n')



# Generated at 2022-06-12 10:36:46.600370
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """Check the show_corrected_command."""
    corrected_command = 'pwd'
    assert show_corrected_command(corrected_command) == show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:36:49.713640
# Unit test for function debug_time
def test_debug_time():
    """
    Test for debug_time
    """
    import time

    with debug_time(u'mytime'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:36:59.143500
# Unit test for function confirm_text
def test_confirm_text():
    class MockCorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    settings.no_colors = False
    confirm_text(MockCorrectedCommand(script='ls', side_effect=False))
    assert u'\x1b[2K\r\x1b[1m\x1b[1m\x1b[1mls\x1b[0m [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]\n' == sys.stderr.getvalue()



# Generated at 2022-06-12 10:37:00.084248
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='ls -h')

# Generated at 2022-06-12 10:37:05.275424
# Unit test for function show_corrected_command
def test_show_corrected_command():
    old_stdout = sys.stdout
    sys.stdout = file = open('test_show_corrected_command', 'w')
    show_corrected_command('corrected_command')
    file.close()
    sys.stdout = old_stdout
    with open('test_show_corrected_command', 'r') as file:
        assert file.readline() == '\x1b[35m😈❯ \x1b[0mcorrected_command\n'
    file.close()


# Generated at 2022-06-12 10:37:06.963166
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == ""


# Generated at 2022-06-12 10:37:21.956656
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from . import utils
    with utils.debug_time('test'):
        datetime.now() + timedelta(seconds=0.0001)


# Generated at 2022-06-12 10:37:23.293296
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:37:24.669057
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:37:28.718363
# Unit test for function debug
def test_debug():
    from tempfile import NamedTemporaryFile
    from .shell import execute

    with NamedTemporaryFile() as out:
        settings.debug = True
        debug('msg')
        settings.debug = False
        debug('msg')



# Generated at 2022-06-12 10:37:30.624630
# Unit test for function debug_time
def test_debug_time():
    from test import main as test_main
    import os
    with debug_time('Test'):
        os.system('echo $PWD')


# Generated at 2022-06-12 10:37:33.934883
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN
    assert color(colorama.Fore.GREEN) == ''
    settings.no_colors = False
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN
    assert color(colorama.Fore.GREEN) != ''

# Generated at 2022-06-12 10:37:43.925524
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = mock.Mock(
        script=u'script', side_effect=True)
    assert (confirm_text(corrected_command) == u'[user command]\033[1K\r'
                                               u'\x1b[1mscript\x1b[0m '
                                               u'(+side effect) '
                                               u'[\x1b[32menter\x1b[0m/'
                                               u'\x1b[34m↑\x1b[0m/'
                                               u'\x1b[34m↓\x1b[0m/'
                                               u'\x1b[31mctrl+c\x1b[0m]')

# Generated at 2022-06-12 10:37:45.598713
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'test_text'
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:37:48.912824
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime, timedelta
    with debug_time('msg'):
        debug.time = datetime.now()
        sleep(1)
    assert debug.time >= datetime.now() + timedelta(secs=1)



# Generated at 2022-06-12 10:37:49.527881
# Unit test for function debug
def test_debug():
    debug('message')

# Generated at 2022-06-12 10:38:02.215998
# Unit test for function debug
def test_debug():
    assert debug(u'foo')



# Generated at 2022-06-12 10:38:03.145627
# Unit test for function debug_time
def test_debug_time():
    f = debug_time("test_debug_time")

# Generated at 2022-06-12 10:38:04.929067
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as dt:
        dt = datetime.now() - dt
    return str(dt)

# Generated at 2022-06-12 10:38:06.864003
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(show_corrected_command("ls -alh"))

# Generated at 2022-06-12 10:38:08.249245
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = 'fuck'
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:38:09.383970
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:38:13.585028
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object, ), {'script': 'ls', 'side_effect': False})
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:38:18.858399
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Given
    bold_color = color(colorama.Style.BRIGHT)
    reset_color = color(colorama.Style.RESET_ALL)
    configuration_details = (
        const.ConfigurationDetails('custom_path',
                                   'custom_content',
                                   'reload_command',
                                   True))

    # When
    how_to_configure_alias(configuration_details)

    # Then

# Generated at 2022-06-12 10:38:23.933057
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    stdout = StringIO.StringIO()
    sys.stdout = stdout
    corrected_command = corrected_command(cmd='ls', side_effect=True)
    confirm_text(corrected_command)
    assert stdout.getvalue() == '{}ls (+side effect) [enter/↑/↓/ctrl+c]'.format(
        const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:38:32.158611
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO

    class MockStdin(object):
        @property
        def isatty(self):
            return False

        def readline(self):
            return ''

    class MockStdout(object):
        def __init__(self):
            self.stringio = StringIO.StringIO()

        @property
        def isatty(self):
            return True

        def write(self, *args):
            self.stringio.write(*args)

    stdout = MockStdout()
    stdin = MockStdin()

    import thefuck.run
    thefuck.run.sys.stdout = stdout
    thefuck.run.sys.stdin = stdin
    import thefuck.main
    thefuck.main.confirm_text('echo "bar"')

# Generated at 2022-06-12 10:38:47.856927
# Unit test for function debug
def test_debug():
    import StringIO
    sys.stderr = StringIO.StringIO()
    debug("test")
    assert sys.stderr.getvalue() == "test\n", "test function debug failed"


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:38:48.737603
# Unit test for function debug_time
def test_debug_time():
    assert debug_time == debug_time

# Generated at 2022-06-12 10:38:51.526800
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=command.Command(u'sudo echo "a"', True))



# Generated at 2022-06-12 10:39:02.709422
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import tempfile

    file_name = None
    os_environ_bak = dict(os.environ)

    from . import app
    from . import shells


# Generated at 2022-06-12 10:39:04.220566
# Unit test for function color
def test_color():
    assert color('test') == colorama.Style.RESET_ALL + 'test'



# Generated at 2022-06-12 10:39:06.821211
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('sys.stderr'):
        debug('test')
        assert sys.stderr.write.called

# Generated at 2022-06-12 10:39:08.012036
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None

# Generated at 2022-06-12 10:39:16.623858
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.bash import Bash
    from .conf.configuration_details import ConfigurationDetails

    bash = Bash('fuck')
    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        can_configure_without_sudo=True,
        content='alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        path='~/.bashrc',
        reload='source ~/.bashrc')

    # print('configuration_details', configuration_details)
    # print('bash', bash)
    # exit(0)

    import tempfile
    temp_file = tempfile.mkstemp()[1]

    import sys
    sys.stdout = open(temp_file, 'w')

    how_to_configure_alias(configuration_details)

    sys.stdout.close

# Generated at 2022-06-12 10:39:21.713788
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO

    saved_stderr = sys.stderr
    message = None
    try:
        out = StringIO()
        sys.stderr = out
        confirm_text(None)
        message = out.getvalue().strip()
    finally:
        sys.stderr = saved_stderr

    return message

# Generated at 2022-06-12 10:39:24.521466
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(const.Command("git status", True))
    assert sys.stderr.getvalue() == (
        ">git status (+side effect)\n")



# Generated at 2022-06-12 10:39:37.484803
# Unit test for function color
def test_color():
    assert color("color_") == "color_"
    settings.no_colors = True
    assert color("color_") == ''

# Generated at 2022-06-12 10:39:38.535298
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from colorama import Fore
    assert how_to_configure_alias(None) == "---------------------------------------------------------------------------"


# Generated at 2022-06-12 10:39:41.467312
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    expected_output = "\x1b[4mHello World\x1b[0m\n"
    show_corrected_command(CorrectedCommand("Hello World"))
    assert sys.stdout.getvalue() == expected_output


# Generated at 2022-06-12 10:39:45.135624
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(const.CorrectedCommand(script='script',
                                                  side_effect=True))
    show_corrected_command(const.CorrectedCommand(script='script',
                                                  side_effect=False))

# Generated at 2022-06-12 10:39:47.722326
# Unit test for function debug
def test_debug():
    import sys
    from mock import Mock

    sys.stderr.write = Mock()
    debug(u'foo')
    sys.stderr.write.assert_called_once_with(
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-12 10:39:49.802854
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debug_time') as _:
        pass

# Generated at 2022-06-12 10:39:51.147360
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)
    assert True == True



# Generated at 2022-06-12 10:39:59.101842
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object, ),
                             {'script': 'ls',
                              'side_effect': True})
    assert (confirm_text(corrected_command)
            == '\033[1K\r\x1b[K\x1b[1m\x1b[95mls\x1b[0m +side effect \x1b[92menter\x1b[0m/\x1b[94m↑\x1b[0m/\x1b[94m↓\x1b[0m/\x1b[91mctrl+c\x1b[0m')

# Generated at 2022-06-12 10:40:02.089826
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    started = datetime.now()
    with debug_time('foo'):
        dummy_operation(3)
    assert started + timedelta(seconds=3) < datetime.now()



# Generated at 2022-06-12 10:40:08.376794
# Unit test for function debug
def test_debug():
    import StringIO
    import sys

    debug_text = "test debug text"
    stderr = sys.stderr

    try:
        sys.stderr = StringIO.StringIO()
        try:
            debug(debug_text)
            assert False
        except AssertionError:
            assert debug_text in sys.stderr.getvalue()
            assert settings.debug is False
        finally:
            sys.stderr.close()
    finally:
        sys.stderr = stderr

# Generated at 2022-06-12 10:40:23.119628
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'ls -la',
        'side_effect': False})
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:40:24.454652
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:40:29.245881
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    from .command import Command
    output = StringIO.StringIO()
    sys.stderr = output
    show_corrected_command(Command("echo 'fuck'", side_effect=True))
    output = output.getvalue()
    sys.stderr = sys.__stderr__
    assert output == const.USER_COMMAND_MARK + "echo 'fuck'" + " (+side effect)" + '\n'

# Generated at 2022-06-12 10:40:30.388670
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias([]) == None


# Generated at 2022-06-12 10:40:33.272963
# Unit test for function confirm_text
def test_confirm_text():
    assert (confirm_text("ls -l") ==
            "➜ ls -l [enter/↑/↓/ctrl+c]" and
            confirm_text("git push") ==
            "➜ git push [enter/↑/↓/ctrl+c]")

# Generated at 2022-06-12 10:40:34.229274
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass



# Generated at 2022-06-12 10:40:34.999914
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-12 10:40:42.753245
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(script=u'git pull',
                                               side_effect=True)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(script=u'git pull',
                                               side_effect=False)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(script=u'',
                                               side_effect=False)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(script=u'',
                                               side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:40:46.451398
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.main import Command
    show_corrected_command(Command('ls foo bar', 'ls bar', 'echo "DANGER!"'))
    sys.stderr.write(u'{}ls bar +side effect\n'.format(const.USER_COMMAND_MARK))

# Generated at 2022-06-12 10:40:56.223916
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, can_configure_automatically, path, content, reload):
            self.can_configure_automatically = can_configure_automatically
            self._asdict = lambda: {
                'path': path, 'content': content, 'reload': reload}
    configuration_details = ConfigurationDetails(
        can_configure_automatically=True,
        path='~/.config/shell',
        content='. ~/.config/shell.conf',
        reload='source ~/.config/shell')

# Generated at 2022-06-12 10:41:09.274615
# Unit test for function debug_time
def test_debug_time():
    debug_time("Test debug time")

if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:41:10.013567
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git push') == 'git push'

# Generated at 2022-06-12 10:41:12.948647
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({'path': '~/.bashrc', 'content': '', 'reload': 'source ~/.bashrc'})



# Generated at 2022-06-12 10:41:13.808310
# Unit test for function debug
def test_debug():
    assert debug('') is None


# Generated at 2022-06-12 10:41:21.444790
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command(corrected_command)

    corrected_command.script = 'ls'
    corrected_command.side_effect = False
    confirm_text(corrected_command)

    corrected_command.script = 'ls'
    corrected_command.side_effect = True
    confirm_text(corrected_command)

    corrected_command.script = 'ls -l'
    corrected_command.side_effect = True
    confirm_text(corrected_command)

    corrected_command.script = 'ls -l'
    corrected_command.side_effect = False
    confirm_text(corrected_command)



# Generated at 2022-06-12 10:41:22.343347
# Unit test for function debug_time
def test_debug_time():
    import time
    import uni

# Generated at 2022-06-12 10:41:29.678169
# Unit test for function debug
def test_debug():
    debug_text = 'any debug text'
    # GIVEN a fake stderr
    import io
    old_stderr = sys.stderr
    new_stderr = io.StringIO()
    sys.stderr = new_stderr

    # WHEN debug text was written to stderr
    debug(debug_text)

    # THEN stderr contains debug text, but without datetime
    assert 'any debug text' in new_stderr.getvalue()
    assert '[DEBUG] any debug text' not in new_stderr.getvalue()

    sys.stderr = old_stderr

# Generated at 2022-06-12 10:41:35.955948
# Unit test for function confirm_text
def test_confirm_text():
    from .application import Application
    from .command import Command
    from .shells import Bash
    app = Application(rules=[], exclude_rules=[], wait_command=False,
                      no_colors=True, debug=False, require_confirmation=True,
                      history_limit=None, alias='fuck',
                      waiting_time=3, script_file=None, slow_commands=None,
                      compat_mode=False, quiet=False, alter_history=False,
                      shell=Bash(), no_wait=False)
    confirm_text(Command("ls", "", "", 0, ""))

# Generated at 2022-06-12 10:41:38.487227
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell

    show_corrected_command(Shell('echo "The Fuck is awesome!"', None).create_command('fuck echo "The Fuck is awesome!"'))

# Generated at 2022-06-12 10:41:43.620381
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class configuration_details:
        def _asdict(self):
            return {'content': 'content',
                    'path': 'path',
                    'reload': 'reload',
                    'can_configure_automatically': 'can_configure_automatically'}
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:41:56.088216
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text("ls dir")


# Generated at 2022-06-12 10:41:57.571780
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand

    show_corrected_command(CorrectedCommand('git push origin', False))

# Generated at 2022-06-12 10:42:05.536806
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import memoize
    from contextlib import nested
    from mock import patch

    with nested(
        patch('sys.stderr', autospec=True),
        patch('thefuck.utils.get_shell', autospec=True),
        patch('thefuck.utils.memoize', new=memoize),
        patch('thefuck.utils.shell_quote', autospec=True)) as (
            stderr, get_shell, *_):
        get_shell.return_value = Shell('bash', '')
        how_to_configure_alias(None)
        assert stderr.write.called
        assert get_shell.called



# Generated at 2022-06-12 10:42:13.475045
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture():
        oldout, olderr = sys.stdout, sys.stderr
        try:
            out = [StringIO(), StringIO()]
            sys.stdout, sys.stderr = out
            yield out
        finally:
            sys.stdout, sys.stderr = oldout, olderr
            out[0] = out[0].getvalue()
            out[1] = out[1].getvalue()

    with capture() as (out, err):
        debug('msg')
    assert not out.strip()
    assert not err.strip()

    settings.debug = True
    with capture() as (out, err):
        debug('msg')
    assert out == 'DEBUG: msg\n'