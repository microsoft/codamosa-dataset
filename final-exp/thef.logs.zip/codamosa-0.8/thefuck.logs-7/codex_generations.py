

# Generated at 2022-06-12 10:32:20.099300
# Unit test for function debug_time
def test_debug_time():
    import mock
    import datetime
    # Python 3
    if sys.version_info.major >= 3:
        with mock.patch('thefuck.utils.debug') as mock_debug:
            with debug_time('test'):
                pass
            assert mock_debug.called
            assert mock_debug.call_args[0][0].startswith('test took: ')
    # Python 2
    else:
        sys.modules['thefuck.utils.datetime'] = mock.Mock()
        # datetime.now and time.time use different types of objects,
        # but they implement the same interface.
        before = object.__new__(datetime.datetime)
        after = object.__new__(datetime.datetime)
        before.__getattribute__ = mock.Mock(return_value=42)


# Generated at 2022-06-12 10:32:23.990784
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('foo') == ''
    settings.no_colors = False
    assert color('foo') == 'foo'

# Generated at 2022-06-12 10:32:26.225052
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correctors.base import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', side_effect=True))



# Generated at 2022-06-12 10:32:28.548030
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "python -m SimpleHTTPServer"
    #corrected_command = "lighter"
    assert show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:32:37.622830
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import StringIO
    import time

    class DebugTimeTest(unittest.TestCase):
        def setUp(self):
            settings.debug = True
            self.stderr = sys.stderr = StringIO.StringIO()

        def tearDown(self):
            sys.stderr = sys.__stderr__
            settings.debug = False

        def test_debug_time(self):
            with debug_time('msg'):
                time.sleep(0.001)
            self.assertTrue('msg took: ' in self.stderr.getvalue())

    suite = unittest.TestLoader().loadTestsFromTestCase(DebugTimeTest)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-12 10:32:39.844331
# Unit test for function color
def test_color():
    assert color('red') == '\033[31m'
    assert color('red') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:32:45.308554
# Unit test for function debug
def test_debug():
    """Verifies if debug() does not output anything if debug is disabled."""
    from thefuck import shell

    with shell.temp_environ():
        import os

        with shell.set_env(THEFUCK_DEBUG=''):
            import sys
            from contextlib import redirect_stdout
            from io import StringIO

            f = StringIO()
            with redirect_stdout(f):
                debug(u'foo')
            out = f.getvalue().strip()
            assert out == u''

# Generated at 2022-06-12 10:32:50.031606
# Unit test for function debug
def test_debug():
    import mock
    import sys
    with mock.patch.object(sys, 'stderr', spec=sys.__stderr__) as mock_stderr:
        debug('msg')
        mock_stderr.write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n')



# Generated at 2022-06-12 10:32:57.300352
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    Tests the output of the show_corrected_command function
    """
    class FakeCommand(object):
        def __init__(self, fake_script, fake_side_effect):
            self.script = fake_script
            self.side_effect = fake_side_effect
    corrected_command = FakeCommand('fake_script', True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == '{0}fake_script (+side effect)\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:32:59.790406
# Unit test for function debug
def test_debug():
    with settings:
        settings.debug = True
        debug(u'foo')
    with settings:
        settings.debug = False
        debug(u'foo')



# Generated at 2022-06-12 10:33:06.607277
# Unit test for function debug
def test_debug():
    from unittest import TestCase
    from . import settings

    class TestDebug(TestCase):

        def setUp(self):
            settings.debug = True

        def tearDown(self):
            settings.debug = False

        def test_debug(self):
            debug('hello')

    TestDebug('test_debug').test_debug()



# Generated at 2022-06-12 10:33:10.275533
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == '\x1b[32m'
    assert color('\x1b[34m') == ''


if __name__ == '__main__':
    test_color()

# Generated at 2022-06-12 10:33:14.784846
# Unit test for function debug_time
def test_debug_time():
    import time
    from StringIO import StringIO

    with debug_time('test'):
        time.sleep(0.005)
    out = StringIO()
    sys.stderr = out
    with debug_time('test'):
        pass
    assert 'test took: 0:00:00.005000' in out.getvalue()

# Generated at 2022-06-12 10:33:20.932437
# Unit test for function confirm_text
def test_confirm_text():  # pragma: no cover
    from collections import namedtuple
    from . import shellutils

    Command = namedtuple('Command', 'script, side_effect')
    corrected_command = Command(script='git fetch upstream',
                                side_effect=False)
    with shellutils.isolated_directory():
        confirm_text(corrected_command)

# Generated at 2022-06-12 10:33:21.430385
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Foo'):
        pass

# Generated at 2022-06-12 10:33:25.361518
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('corrected_command') == (
        u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]')


# Generated at 2022-06-12 10:33:33.956881
# Unit test for function debug
def test_debug():
    # Reset the settings
    reload(settings)

    # No debug
    debug('no debug')
    assert sys.stderr.getvalue() == ''

    # Debug is active
    settings.debug = True
    sys.stderr.truncate(0)
    debug('debug')
    assert ('\x1b[34m\x1b[1mDEBUG:\x1b[0m debug\n' ==
            sys.stderr.getvalue())

    # Debug is disabled again
    settings.debug = False



# Generated at 2022-06-12 10:33:35.005913
# Unit test for function debug_time
def test_debug_time():
    print("test")
    debug("test")

# Generated at 2022-06-12 10:33:39.845844
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import MagicMock, patch

    debug = MagicMock()
    with patch('thefuck.shells.base.debug', debug),\
            debug_time('foo'):
        pass

    debug.assert_called_once_with('foo took: {}'.format(timedelta(0)))

# Generated at 2022-06-12 10:33:42.314082
# Unit test for function debug
def test_debug():
    settings.debug = True
    msg = u"test message"
    debug(msg)



# Generated at 2022-06-12 10:33:51.544609
# Unit test for function debug
def test_debug():
    from thefuck.conf import reload_settings
    from thefuck.utils import save_settings
    from unittest.mock import patch
    from io import StringIO
    from sys import stderr
    from tempfile import gettempdir

    with patch.object(stderr, 'write', return_value=None) as mock_stderr:
        reload_settings()
        save_settings({'debug': True, 'no_colors': False})
        debug(u'test')
        debug(u'test2')
        save_settings({'debug': False, 'no_colors': False})
        debug(u'test3')
        debug(u'test4')
        reload_settings()
        save_settings({'debug': True, 'no_colors': True})
        debug(u'test5')
        debug

# Generated at 2022-06-12 10:33:52.538684
# Unit test for function debug_time
def test_debug_time():
    debug_time(u'some message')

# Generated at 2022-06-12 10:33:57.291044
# Unit test for function debug_time
def test_debug_time():
    class FakeDatetime(object):
        def __init__(self, delta):
            self._delta = delta

        def __sub__(self, value):
            return self._delta

    with debug_time('test') as value:
        assert value is None
        started = datetime.now()

    with debug_time('test') as value:
        assert value is None
        started = FakeDatetime(0.6)



# Generated at 2022-06-12 10:33:57.825357
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:33:58.864036
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(1)

# Generated at 2022-06-12 10:34:00.486512
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('x') == 'x'



# Generated at 2022-06-12 10:34:06.409513
# Unit test for function confirm_text
def test_confirm_text():
    """Tests confirm_text() function."""
    from .command import Command
    assert confirm_text(Command('pwd')) == '\033[1K\r$ pwd [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'
    from .utils import cached_property
    from .shells import Bash
    class Shell(Bash):
        @cached_property
        def _alias_support(self):
            return False

# Generated at 2022-06-12 10:34:16.403329
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = Command.from_shell('fuck')

# Generated at 2022-06-12 10:34:17.725570
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass
    # should not raise exception

# Generated at 2022-06-12 10:34:24.472496
# Unit test for function debug
def test_debug():
    actual = []
    settings.debug = True
    debug_msg = 'test'

    def fake_print(msg):
        actual.append(msg)

    sys.stderr.write = fake_print
    debug(debug_msg)

    settings.debug = False
    if settings.debug:
        debug(debug_msg)
    assert actual == [u'{}DEBUG:{} {}\n'.format(color(colorama.Fore.BLUE),
                                                color(colorama.Style.RESET_ALL),
                                                debug_msg)]

# Generated at 2022-06-12 10:34:37.082409
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print(u"Seems like {bold}fuck{reset} alias isn't configured!".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))
    # print(u"Please put {bold}source /home/nvbn/.local/share/virtualenvs/thefuck-8WgjKxM1/bin/activate
    # #fuck
    # && set -x FUCK_SHELL /usr/bin/fish
    # && set -x FUCK_ALIAS fuck
    # && set -x FUCK_ALWAYS_TO_FIRST_LINE 1
    # && set -x FUCK_SILENT 1
    # && set -x FUCK_WAIT_COMMAND 1
    # && set -x FUCK_ARGS --no-colors
    # && set -x

# Generated at 2022-06-12 10:34:40.886300
# Unit test for function debug
def test_debug():
        msg = u"Файл {file} содержит {count} строк"
        args = {'file': 'file.txt', 'count': 32}
        debug(msg.format(**args))

# Generated at 2022-06-12 10:34:43.218013
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(const.CorrectedCommand(
        script='cd ~/Downloads', side_effect=[]))


# Generated at 2022-06-12 10:34:48.318239
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import timedelta

    with patch('thefuck.shells.base.datetime') as mock_datetime:
        mock_datetime.now.side_effect = [timedelta(seconds=1),
                                         timedelta(seconds=3)]
        with debug_time(u'some message'):
            pass
        assert mock_datetime.now.call_count == 2

# Generated at 2022-06-12 10:34:53.655255
# Unit test for function debug
def test_debug():
    with DebugTime:
        wait(1)
    # Output is like:
    # DEBUG: wait took: 1.001579 sec.
    # For example, test timeout is 10 sec, but sometimes it takes 11 sec
    # to run all the tests. We need to wait longer, but it's ok to wait
    # 11 sec instead of 10. It's just a unit test, its' not a performance
    # test.
    # So, using assertIn instead of assertEqual here.
    assertIn("wait took", debug_time("wait").getvalue())

# Generated at 2022-06-12 10:35:01.923372
# Unit test for function debug_time
def test_debug_time():
    from mock import Mock
    from contextlib import contextmanager
    from datetime import timedelta

    debug = Mock()
    settings.debug = True

    @contextmanager
    def sleep(sec):
        m = Mock()
        m.then.return_value = datetime.now() + timedelta(seconds=sec)
        yield m

    with sleep(0.5) as time:
        with debug_time('msg'):
            time.sleep(0.1)
            time.then.assert_called_once()
    debug.assert_called_once_with(u'msg took: 0:00:00.500000')

# Generated at 2022-06-12 10:35:05.005930
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('', (), {})
    corrected_command.script = 'fuck'
    corrected_command.side_effect = False
    confirm_text(corrected_command)
    assert True



# Generated at 2022-06-12 10:35:09.078019
# Unit test for function debug
def test_debug():
    def wrap():
        debug("Debug message")
    import mock
    import sys
    with mock.patch.object(sys.__class__, 'stderr', mock.MagicMock()) as stderr:
        wrap()
        assert stderr.write.called



# Generated at 2022-06-12 10:35:09.631071
# Unit test for function debug
def test_debug():
    debug('debug message')

# Generated at 2022-06-12 10:35:11.243491
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    value_return = how_to_configure_alias(None)
    assert value_return == None

# Generated at 2022-06-12 10:35:14.657832
# Unit test for function confirm_text
def test_confirm_text():
    cmd = 'ls'
    confirm_text(cmd)

# Generated at 2022-06-12 10:35:16.440299
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    settings.no_colors = True
    assert color('red') == ''



# Generated at 2022-06-12 10:35:21.743576
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    import sys

    with patch('sys.stderr', new=sys.stdout):
        corrected_command = type('', (object,), {'script': 'ls -DF'})
        assert sys.stdout.getvalue() == ''
        confirm_text(corrected_command)
        assert sys.stdout.getvalue() == 'ls -DF [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:35:23.150384
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'Hello world!'):
        pass


# Generated at 2022-06-12 10:35:26.425098
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = u'git push origin master'
    confirm_text(corrected_command)
    corrected_command = u'git push origin master (+side effect)'
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:35:31.550872
# Unit test for function debug
def test_debug():
    sys.stderr = open('debug.log', 'wb')
    settings.debug = True
    debug('something')
    debug('something else')
    settings.debug = False
    debug('different')
    sys.stderr.close()
    assert open('debug.log', 'rb').read() == b'DEBUG: something\nDEBUG: something else\n'



# Generated at 2022-06-12 10:35:39.169542
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time
    with mock.patch('sys.stderr') as mock_stderr:
        with debug_time('Mock debug time'):
            time.sleep(0.01)
        mock_stderr.write.assert_has_calls([
                mock.call('\033[1K\r'),
                mock.call(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Mock debug time took: 0:00:00.010078\n')])

# Generated at 2022-06-12 10:35:42.381715
# Unit test for function debug
def test_debug():
    import StringIO
    buffer = StringIO.StringIO()
    sys.stderr = buffer
    debug(u'Test message')
    sys.stderr = sys.__stderr__
    assert u'Test message' in buffer.getvalue()

# Generated at 2022-06-12 10:35:44.946563
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({'path': '/home/.bashrc',
                            'content': 'eval $(thefuck --alias)'})



# Generated at 2022-06-12 10:35:48.704954
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(
                    configuration_details=None)
    how_to_configure_alias(configuration_details=
                           'content'
                           'path'
                           'reload'
                           'can_configure_automatically')



# Generated at 2022-06-12 10:35:52.311893
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()


# Generated at 2022-06-12 10:35:53.879714
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    assert True



# Generated at 2022-06-12 10:35:56.298637
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('hello'):
            with debug_time('hello'):
                raise Exception()
    except Exception:
        pass

# Generated at 2022-06-12 10:35:58.550088
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test1') as test1:
        time.sleep(1)
    time.sleep(1)



# Generated at 2022-06-12 10:36:01.135465
# Unit test for function color
def test_color():
    # return unicode string on Python 2 and str on Python 3
    assert isinstance(color(u''), unicode)
    assert isinstance(color(u''), type(''))



# Generated at 2022-06-12 10:36:02.436074
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(u'ls') == u'ls'

# Generated at 2022-06-12 10:36:03.205948
# Unit test for function debug_time
def test_debug_time():
    debug_time()


# Generated at 2022-06-12 10:36:04.439514
# Unit test for function debug
def test_debug():
    def _test_debug(msg):
        debug(msg)
    _test_debug("Test debug")

# Generated at 2022-06-12 10:36:05.912145
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    with debug_time('sleep'):
        sleep(0.1)

# Generated at 2022-06-12 10:36:11.851619
# Unit test for function confirm_text
def test_confirm_text():
    confirmed_command = {
        'script': "cat /dev/random",
        'side_effect': False}
    confirm_text(confirmed_command)

    corrected_command = {
        'script': "ls | sort -n",
        'side_effect': False}
    confirm_text(corrected_command)

    corrected_command = {
        'script': "ls | sort -n",
        'side_effect': True}
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:36:17.757384
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'



# Generated at 2022-06-12 10:36:19.669543
# Unit test for function debug
def test_debug():
    debug('return')
    debug('return')
    debug('return')
    debug('return')
    assert True

# Generated at 2022-06-12 10:36:29.652257
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from .shells import Shell
    from .shells.zsh import Zsh
    from .shells import shell_from_name
    from .shells.base import InvalidSettings
    with pytest.raises(InvalidSettings):
        shell_from_name('wrong')
    with pytest.raises(InvalidSettings):
        shell_from_name('bash', Shell())
    shell = Shell()
    shell.get_history = lambda: []
    shell.set_variable = lambda name, value: None
    shell.get_variables = lambda: dict()
    shell.get_history_generator = lambda: []
    shell.clear_history = lambda: None
    shell_from_name('zsh', shell)
    assert shell_from_name('zsh').get_history() == []
    assert shell_from

# Generated at 2022-06-12 10:36:38.251485
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.utils import LazyString

    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    def assert_stdout(expected):
        assert sys.stdout.getvalue() == expected

    def assert_stderr(expected):
        assert sys.stderr.getvalue() == expected

    show_corrected_command(CorrectedCommand('ls', False))
    assert_stderr(u'{}ls{}\n'.format(
        color(colorama.Style.BRIGHT),
        color(colorama.Style.RESET_ALL)))

    show_corrected_command(CorrectedCommand(LazyString('ls'), False))

# Generated at 2022-06-12 10:36:39.285471
# Unit test for function debug
def test_debug():
    debug_message = "one debug message"
    debug(debug_message)


# Generated at 2022-06-12 10:36:42.904066
# Unit test for function confirm_text
def test_confirm_text():
    """Unit test for `confirm_text` function"""
    from .command import CorrectedCommand
    from .utils import confirm_text

    assert confirm_text(CorrectedCommand('command', 'script')) == \
    u'[F]uck!command script [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:36:45.817387
# Unit test for function debug_time
def test_debug_time():
    from .utils import echo
    from datetime import timedelta
    from time import sleep

    with debug_time('echo'):
        sleep(1)
        echo('666')


# Generated at 2022-06-12 10:36:49.496408
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    command = CorrectedCommand('echo', 'ls -la')
    show_corrected_command(command)
    command = CorrectedCommand('ls', 'ls -la', side_effect=True)
    show_corrected_command(command)



# Generated at 2022-06-12 10:36:56.333953
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    howtoconfigurealias = how_to_configure_alias('what')
    assert howtoconfigurealias == print('Seems like {bold}fuck{reset} alias isn\'t configured!\nPlease put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.\nOr run {bold}fuck{reset} a second time to configure it automatically.\nMore details - https://github.com/nvbn/thefuck#manual-installation'.format(bold=color(colorama.Style.BRIGHT),reset=color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-12 10:37:04.816241
# Unit test for function confirm_text
def test_confirm_text():
    import urwid
    from .shells import pipe

    corrected_command = pipe.AndPipe(
        pipe.Command('echo', ''),
        pipe.Command('echo', ''),
    )

    confirm_text(corrected_command)

    urwid.raw_display.Screen.set_terminal_properties(colors=16)
    assert confirm_text(corrected_command) == (
        u'=> (echo && echo) [\x1b[92menter\x1b[0m/\x1b[94m\x1b[0m/\x1b[94m'
        '\x1b[0m/\x1b[91mctrl+c\x1b[0m]')

# Generated at 2022-06-12 10:37:19.220388
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class Settings(object):
        debug = False
        no_colors = False
        exclusion_rules = None
        require_confirmation = False
        wait_command = 1.0
        wait_slow_commands = 15
        priority = {'python': 1000, 'git': 900, 'man': 800}
        history_limit = None
        slow_commands = ['lein', 'rebase', 'merge']
        env = {}
        alter_history = False
        repeat = False
        shell = 'bash'
        rules = []
        priority = Priority()
        exclude_rules = ExcludeRule()
        alias = Alias()

    settings = Settings()


# Generated at 2022-06-12 10:37:21.663530
# Unit test for function debug
def test_debug():
    original_debug = settings.debug

    settings.debug = True
    try:
        debug("test")
    finally:
        settings.debug = original_debug

# Generated at 2022-06-12 10:37:24.909839
# Unit test for function show_corrected_command
def test_show_corrected_command():
    stderr_old = sys.stderr
    from cStringIO import StringIO
    sys.stderr = StringIO()
    show_corrected_command(object())
    assert sys.stderr.getvalue().endswith('\n')

# Generated at 2022-06-12 10:37:26.671282
# Unit test for function debug_time
def test_debug_time():
    assert debug_time == debug_time

# Generated at 2022-06-12 10:37:27.670686
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:37:28.997871
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-12 10:37:34.861818
# Unit test for function confirm_text
def test_confirm_text():
    doc = 'Seems like fuck alias isn\'t configured!\n'
    doc += 'Please put "\nalias fuck=\'/home/kalbasit/.local/bin/thefuck\'" in your "$HOME/.bashrc" and apply changes with "source $HOME/.bashrc" or restart your shell.\n'
    doc += 'Or run fuck a second time to configure it automatically.\n'
    doc += 'More details - https://github.com/nvbn/thefuck#manual-installation'

    assert how_to_configure_alias(doc) == None

# Generated at 2022-06-12 10:37:37.274510
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("fuck") == 5
    assert confirm_text("fuck --help") == 12


# Generated at 2022-06-12 10:37:40.219509
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck import shell
    how_to_configure_alias(shell.get_shell(['/usr/local/bin/bash']))
    how_to_configure_alias(shell.get_shell(['/usr/bin/zsh']))
    how_to_configure_alias(shell.get_shell(['/usr/bin/bash']))



# Generated at 2022-06-12 10:37:50.326279
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    from .test_utils import set_environ, clear_environ, patches
    from .settings import load_settings

    with set_environ(SHELL='/bin/bash'):
        assert show_corrected_command(
            CorrectedCommand('ls', 'ls -la', 'ls')) == None

    with set_environ(SHELL='/bin/bash'):
        assert sys.stderr.write(
            const.USER_COMMAND_MARK + 'ls -la\n') \
            == None

    with set_environ(SHELL='/bin/bash'):
        assert show_corrected_command(
            CorrectedCommand('ls', 'ls -la', 'ls')) == None


# Generated at 2022-06-12 10:37:57.208159
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_message'):
        pass

# Generated at 2022-06-12 10:37:57.762421
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:38:02.216213
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('thefuck.shells.Terminal') as _:
        with patch('sys.stderr') as mocked:
            debug(u'Foo')
            mocked.write.assert_any_call(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Foo\n')

# Generated at 2022-06-12 10:38:05.899118
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(CorrectedCommand('ls | grep readme', False)) == 'ls | grep readme'
    assert show_corrected_command(CorrectedCommand('ls | grep readme', True)) == 'ls | grep readme (+side effect)'

# Generated at 2022-06-12 10:38:13.279320
# Unit test for function debug
def test_debug():
    settings.debug = True
    s = ""

    def capture_stdout(func, *args, **kwargs):
        sys.stdout = s = StringIO()
        func(*args, **kwargs)
        return s

    sys.stderr = s = test_file = StringIO()
    debug('Foo')
    assert u'DEBUG: Foo\n' == s.getvalue()
    settings.debug = False
    debug('Foo')
    assert u'DEBUG: Foo\n' == s.getvalue()

# Generated at 2022-06-12 10:38:18.721450
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import sys
    from thefuck.shells.bash import Bash
    from thefuck.shells.zsh import Zsh

    with mock.patch.object(sys.stdout, 'write') as out:
        with mock.patch('__builtin__.raw_input', return_value=''):
            confirm_text(Bash('script'))
            assert out.mock_calls[0][1] == (
                u'[{}{}{}]'.format(color(colorama.Style.BRIGHT),
                                   'fuck',
                                   color(colorama.Style.RESET_ALL)),)

# Generated at 2022-06-12 10:38:23.042452
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand:
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('git stash pop'))
    show_corrected_command(
        CorrectedCommand('git stash pop', True))



# Generated at 2022-06-12 10:38:31.668509
# Unit test for function debug
def test_debug():
    # Initialize test class
    class TestColoramaStream(object):
        def __init__(self):
            self.content = ''
        def write(self, content):
            self.content += content
        def __unicode__(self):
            return self.content

    colorama.init()
    test_stream = TestColoramaStream()
    stream = sys.stderr
    sys.stderr = test_stream

    # Test debug function work correctly with different colors
    debug('Test debug function')
    assert test_stream.content.strip() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Test debug function'

    # Restore sys.stderr
    sys.stderr = stream

    # Test debug function works correctly without colors
    settings.no_colors = True


# Generated at 2022-06-12 10:38:39.458587
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    from thefuck.conf.configuration_details import ConfigurationDetails
    with StringIO.StringIO() as buff:
        sys.stdout = buff
        how_to_configure_alias(ConfigurationDetails(
            path='~/.bashrc',
            content='eval "$(thefuck --alias fuck)"',
            can_configure_automatically=True,
            reload='bash'))
        sys.stdout = sys.__stdout__

# Generated at 2022-06-12 10:38:45.535725
# Unit test for function debug_time
def test_debug_time():
    import mock
    with mock.patch('thefuck.utils.settings.debug', True):
        with mock.patch('thefuck.utils.sys.stderr') as mock_stderr:
            with debug_time('function'):
                pass
            assert mock_stderr.write.call_args_list[-1][0][0].startswith(
                'function took: ')

# Generated at 2022-06-12 10:39:00.003120
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(u'vim') == u'{}vim'.format(const.USER_COMMAND_MARK)
    show_corrected_command(u'vim +side effect') == u'{}vim +side effect'.format(const.USER_COMMAND_MARK)
    show_corrected_command(u'vim  +side effect') != u'{}vim +side effect'.format(const.USER_COMMAND_MARK)
    show_corrected_command(u'vim  +side effect') == u'{}vim  +side effect'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:39:03.680711
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class corrected_command:
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(corrected_command(script=u'ls', side_effect=False))


# Generated at 2022-06-12 10:39:06.736890
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    assert color('color') != 'nocolor'
    settings.no_colors = True
    assert color('color') == ''

# Generated at 2022-06-12 10:39:07.971605
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # show_corrected_command(corrected_command)
    return


# Generated at 2022-06-12 10:39:11.655550
# Unit test for function debug
def test_debug():
    assert const.SETTINGS_DEBUG.get_value(settings) is False
    debug('Debug is not enabled')
    const.SETTINGS_DEBUG.set_value(settings, True)
    debug('Debug is enabled')



# Generated at 2022-06-12 10:39:14.380326
# Unit test for function color
def test_color():
    assert '\x1b[30m' == color(colorama.Fore.BLACK)
    assert '' == color(colorama.Fore.BLACK, True)

# Generated at 2022-06-12 10:39:24.909667
# Unit test for function show_corrected_command
def test_show_corrected_command():
    #setup
    from thefuck.utils import CorrectedCommand
    class Mock(object):
        def __init__(self, output):
            self.out = output
            self.out1 = output

        def write(self, s, *args):
            if self.out1 == '':
                self.out1 = s
            else:
                self.out1 = self.out
    saved_stderr = sys.stderr

# Generated at 2022-06-12 10:39:29.090763
# Unit test for function debug
def test_debug():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    try:
        debug('test message')
        assert '\033[34m\033[1mDEBUG:\033[0m test message' in output.getvalue()
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:39:35.259038
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Prepare
    corrected_command = type('', (), {})
    corrected_command.script = 'git push origin master:master'
    corrected_command.side_effect = False
    # Exercise
    show_corrected_command(corrected_command)
    # Verify
    assert sys.stderr.getvalue() == u'Corrected command: git push origin master:master\n'


# Generated at 2022-06-12 10:39:38.626307
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        debug('test')
        assert mock_stderr.getvalue() == 'test\n'

# Generated at 2022-06-12 10:39:48.600533
# Unit test for function debug
def test_debug():
    from StringIO import StringIO

    orig_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        debug('foo')
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    finally:
        sys.stderr = orig_stderr

# Generated at 2022-06-12 10:39:59.145254
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with settings(no_colors=True):
        assert show_corrected_command(const.CorrectedCommand('ls -ltrah', False)) == '$ ls -ltrah\n'
    with settings(no_colors=False):
        assert show_corrected_command(const.CorrectedCommand('ls -ltrah', True)) == u'\x1b[46m\x1b[37m\x1b[1m➜\x1b[0m\x1b[1m ls -ltrah\x1b[0m (+side effect)\n'

# Generated at 2022-06-12 10:40:08.543777
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    from mock import patch
    from . import confirm_text

    with patch.object(sys.stderr, 'write') as mocked_write:
        confirm_text(CorrectedCommand('git push origin master', False))


# Generated at 2022-06-12 10:40:13.928788
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    sys.stderr = StringIO()
    settings.debug = True
    msg = u'Hello debug'
    debug(u'Hello debug')
    printed = sys.stderr.getvalue()
    assert printed.strip() == u'DEBUG: Hello debug'.strip()
    assert printed.count('\n') == 1
    settings.debug = False
    debug(u'Hello debug')
    assert sys.stderr.getvalue() == '\n'

# Generated at 2022-06-12 10:40:22.403616
# Unit test for function debug
def test_debug():
    import re
    import sys
    from mock import patch
    from contextlib import contextmanager

    @contextmanager
    def capture():
        old, sys.stderr = sys.stderr, open('/dev/null', 'w')
        try:
            yield
        finally:
            sys.stderr.close()
            sys.stderr = old

    with patch('sys.stderr', new=open('/dev/null', 'w')):
        with capture():
            debug('foo')
    with open('/dev/null') as f:
        assert re.search('foo', f.read()) is not None



# Generated at 2022-06-12 10:40:24.173125
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.types import Command

    confirm_text(
        Command('ls', '', ''))



# Generated at 2022-06-12 10:40:27.926782
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('This is not debug'):
        time.sleep(0.1)
    with debug_time('This is a debug'):
        time.sleep(0.55)
    with debug_time('This is also a debug'):
        time.sleep(0.2)
    assert True == True

# Generated at 2022-06-12 10:40:29.257397
# Unit test for function debug
def test_debug():
    assert debug(u'Test debug') == None



# Generated at 2022-06-12 10:40:30.121698
# Unit test for function debug
def test_debug():
    debug('abc')
    debug(u'abc')

# Generated at 2022-06-12 10:40:31.586508
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == ''
    assert color('test') == 'test'

# Generated at 2022-06-12 10:40:37.843908
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE)
    assert color('')



# Generated at 2022-06-12 10:40:39.185409
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(1)



# Generated at 2022-06-12 10:40:43.815229
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Example usage:
    # how_to_configure_alias(how_to_configure_alias(
    # ConfigurationDetails(
    # path='~/.bashrc',
    # content='eval $(thefuck --alias)',
    # reload='source ~/.bashrc',
    # can_configure_automatically=False)))
    assert True

# Generated at 2022-06-12 10:40:44.785215
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias([])
    how_to_configure_alias(True)

# Generated at 2022-06-12 10:40:46.327197
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('s')


# Generated at 2022-06-12 10:40:51.179942
# Unit test for function debug
def test_debug():
    from mock import MagicMock
    settings.debug = True
    sys.stderr = MagicMock()
    debug(u'test')
    sys.stderr.write.assert_called_once_with(u'{}DEBUG:{} test\n'.format(
        color(colorama.Fore.BLUE + colorama.Style.BRIGHT),
        color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-12 10:40:52.412092
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-12 10:40:53.877957
# Unit test for function debug
def test_debug():
    debug('test')
    assert settings.debug

# Generated at 2022-06-12 10:40:58.031443
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('git pu', False))
    show_corrected_command(CorrectedCommand('ls', True))



# Generated at 2022-06-12 10:41:00.615708
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    result = how_to_configure_alias()

    assert result is None


# Generated at 2022-06-12 10:41:11.223738
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    """
    print(u"Seems like {}fuck{} alias isn't configured!".format(
        color(colorama.Style.BRIGHT),
        color(colorama.Style.RESET_ALL)))

    print(
        u"Please put {} in your {} and apply "
        u"changes with {} or restart your shell.".format(
            color(colorama.Style.BRIGHT),
            color(colorama.Style.RESET_ALL),
            "test"))
    """



# Generated at 2022-06-12 10:41:12.334153
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from ..correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('my_script', True))

# Generated at 2022-06-12 10:41:18.107720
# Unit test for function confirm_text
def test_confirm_text():
    std = sys.stderr
    std.write("test 1=>")
    confirm_text(const.CorrectedCommand("test", False, None))
    confirm_text(const.CorrectedCommand("test", True, None))
    std.write("\ntest 2=>")
    confirm_text(const.CorrectedCommand("test", False, None))
    confirm_text(const.CorrectedCommand("test", True, None))
    std.write("\n")

# Generated at 2022-06-12 10:41:20.270121
# Unit test for function color
def test_color():
    assert not color(colorama.Back.RED)
    assert color(colorama.Fore.RED + colorama.Style.BRIGHT)

# Generated at 2022-06-12 10:41:22.546998
# Unit test for function debug_time
def test_debug_time():
    import mock
    with debug_time('foo'):
        foo = 1 + 1
    debug.assert_called_once_with('foo took: 0:00:00')

# Generated at 2022-06-12 10:41:31.210221
# Unit test for function confirm_text
def test_confirm_text():
    # from .conf import Settings
    from .utils import memoize
    from .shells import Shell
    from .correct import CorrectedCommand

    orig_get_settings = const.get_settings

    const.get_settings = memoize(lambda: settings)
    settings.no_colors = False
    settings.require_confirmation = True


# Generated at 2022-06-12 10:41:36.068187
# Unit test for function confirm_text
def test_confirm_text():
    expected = u'The Fuck [\x1b[33mf\x1b[0m/\x1b[1m\x1b[34m↑\x1b[0m/\x1b[1m\x1b[34m↓\x1b[0m/\x1b[1m\x1b[31mctrl+c\x1b[0m] '
    actual = confirm_text(None)
    assert actual == expected



# Generated at 2022-06-12 10:41:39.159297
# Unit test for function confirm_text
def test_confirm_text():
    from .config import get_shell_info
    shell_info = get_shell_info('bash')
    confirm_text(settings.corrected_command)
    assert 'foo' in sys.stderr.getvalue()

# Generated at 2022-06-12 10:41:42.909379
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', 'ls -l'))
    show_corrected_command(CorrectedCommand('ls', 'git log -l', True))



# Generated at 2022-06-12 10:41:48.642988
# Unit test for function confirm_text

# Generated at 2022-06-12 10:41:59.631843
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')

# Generated at 2022-06-12 10:42:02.889588
# Unit test for function confirm_text
def test_confirm_text():
    # Print correct command
    corrected_command = 'sudo apt-get install python'
    show_corrected_command(corrected_command)
    # Print confirm text
    confirm_text()
    # Check if the confirm text is loaded on the console


# Generated at 2022-06-12 10:42:08.478465
# Unit test for function debug_time
def test_debug_time():
    from mock import patch, MagicMock
    from cStringIO import StringIO

    with patch('thefuck.shells.get_history',
               return_value=iter(['cd /'])):
        with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
            with debug_time('Test time'):
                pass
    assert mock_stderr.getvalue() == 'DEBUG: Test time took: 0:00:00\n'