

# Generated at 2022-06-12 10:32:12.102223
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:32:14.397137
# Unit test for function debug
def test_debug():
    settings.debug = True

    try:
        debug(u'foo bar')
    finally:
        settings.debug = False



# Generated at 2022-06-12 10:32:17.489906
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(('foo', 'bar', False))
    how_to_configure_alias(('foo', 'bar', True))
    how_to_configure_alias(('foo', 'bar', True))
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:32:27.939799
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf import ConfigurationDetails
    from .utils import captured_output

    with captured_output() as (stdout, _):
        how_to_configure_alias(
            ConfigurationDetails(
                'zsh',
                '~/.zshrc',
                'source ~/.zshrc',
                True))


# Generated at 2022-06-12 10:32:28.765059
# Unit test for function debug
def test_debug():
    debug('foo')



# Generated at 2022-06-12 10:32:29.265115
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:32:31.107488
# Unit test for function debug_time
def test_debug_time():
    out = []
    with debug_time('hello'):
        out.append(1)
    assert out == [1]

# Generated at 2022-06-12 10:32:33.056031
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command=const.CorrectedCommand("python",['/usr/bin/python'],True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:32:37.103561
# Unit test for function debug
def test_debug():
    debug('debug')
    assert sys.stderr.getvalue() == color(colorama.Fore.BLUE) + \
        color(colorama.Style.BRIGHT) + 'DEBUG:' + color(colorama.Style.RESET_ALL) + \
        ' debug\n'



# Generated at 2022-06-12 10:32:39.313605
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time(u'foo'):
        assert started - datetime.now() == 0, 'should not take time'

# Generated at 2022-06-12 10:32:43.972358
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('waiting for one second'):
        time.sleep(1)
# End of unit test for function debug_time

# Generated at 2022-06-12 10:32:48.433077
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time

    with mock.patch('sys.stderr.write') as mock_print:
        with debug_time('testing debug_time'):
            time.sleep(0.1)
        mock_print.assert_called_once_with(
            "DEBUG: testing debug_time took: 0:00:00.100000\n")

# Generated at 2022-06-12 10:32:58.506865
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from ..conf import ConfigurationDetails
    from ..utils import which

    def assert_output(configuration_details, expected_output):
        how_to_configure_alias(ConfigurationDetails(*configuration_details))
        assert sys.stdout.getvalue() == expected_output

    sys.stdout = TestBuffer()
    sys.argv[0] = 'thefuck'


# Generated at 2022-06-12 10:33:01.377638
# Unit test for function debug_time
def test_debug_time():
    from .utils import get_time_mock

    debug = get_time_mock()
    with debug_time('test'):
        pass

    assert debug.called

# Generated at 2022-06-12 10:33:02.606237
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')

# Generated at 2022-06-12 10:33:06.604900
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import guess_type

    assert confirm_text(guess_type('ls', None)) == "> ls [enter/↑/↓/ctrl+c]"
    assert confirm_text(guess_type(None, 'ls')) == "> ls [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-12 10:33:17.716678
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Zsh
    import io
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.out = io.StringIO()
            self.real_stderr = sys.stderr
            sys.stderr = self.out

        def tearDown(self):
            sys.stderr = self.real_stderr

        def test_show_corrected_command(self):
            show_corrected_command(Zsh('ls',
                                       'ls'))

# Generated at 2022-06-12 10:33:25.239066
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    dummy_data = [{}, {'can_configure_automatically': 0},
                  {'can_configure_automatically': 1},
                  {'can_configure_automatically': '', 'path': '', 'reload': '',
                   'content': ''}]
    for data in dummy_data:
        print(dummy_data.index(data) + 1, ':')
        print('\n')
        how_to_configure_alias(data)
        print('\n')

# Generated at 2022-06-12 10:33:31.626234
# Unit test for function show_corrected_command
def test_show_corrected_command():
    #for pty module we need to mock stdout, stderr
    sys.stdout = open('1','w')
    sys.stderr = open('2','w')
    show_corrected_command('/usr/bin/man')
    sys.stdout.close()
    sys.stderr.close()
    with open('1','r') as f:
        text = f.read()
        f.close()
    

# Generated at 2022-06-12 10:33:34.542752
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('pwd')
    pass

#Unit test for function debug

# Generated at 2022-06-12 10:33:42.809048
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command = 'ls') == 'ls [enter/↑/↓/ctrl+c]'


# Generated at 2022-06-12 10:33:44.762308
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('test_debug')
    if not settings.debug:
        return False
    else:
        return True

# Generated at 2022-06-12 10:33:48.163838
# Unit test for function debug
def test_debug():
    import mock
    import tempfile

    with tempfile.TemporaryFile() as f:
        with mock.patch.object(logging, 'stderr', f):
            debug('Test')
            f.seek(0)
            assert f.read() == 'DEBUG: Test\n'


# Generated at 2022-06-12 10:33:49.965672
# Unit test for function color
def test_color():
    assert color('a') == ''
    settings.no_colors = False
    assert color('a') == 'a'
    settings.no_colors = True

# Generated at 2022-06-12 10:33:54.810666
# Unit test for function confirm_text
def test_confirm_text():
    import os
    old_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    confirm_text(corrected_command=('git', [], False))
    sys.stdout.close()
    sys.stdout = old_stdout

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:33:58.230184
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .settings import _get_default_settings
    settings._get_default_settings = _get_default_settings
    setting = {'foo': 'bar'}
    debug(setting)


# Generated at 2022-06-12 10:33:59.039733
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:34:02.202046
# Unit test for function confirm_text
def test_confirm_text():
    result = u'\033[1K\r[The Fuck] git add -p (+side effect) [enter/\u2191/\u2193/ctrl+c]'
    assert confirm_text(
        const.CorrectedCommand('git add -p', True)) == result

# Generated at 2022-06-12 10:34:02.680157
# Unit test for function show_corrected_command
def test_show_corrected_command():
	pass

# Generated at 2022-06-12 10:34:03.701298
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-12 10:34:17.054225
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'git push -u origin master'
    show_corrected_command(corrected_command)
    corrected_command = 'git push -u origin master'
    show_corrected_command(corrected_command)
    corrected_command = 'git push -u origin master'
    show_corrected_command(corrected_command)
    corrected_command = 'git push -u origin master'
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:34:24.382066
# Unit test for function debug_time
def test_debug_time():
    import datetime
    from mock import MagicMock
    msg = 'test'
    settings.debug = True
    test_time = datetime.timedelta(seconds=1)
    started = datetime.datetime.now()
    with debug_time(msg):
        now = datetime.datetime.now()
        delta = now - started
        while delta < test_time:
            now = datetime.datetime.now()
            delta = now - started

    assert sys.stderr.write.called_with(u'test took: 0:00:01\n')
    settings.debug = False

# Generated at 2022-06-12 10:34:31.994853
# Unit test for function debug_time
def test_debug_time():
    warnings = []
    messages = []
    old_warn = warn
    old_debug = debug

    try:
        def warn(msg): warnings.append(msg)
        def debug(msg): messages.append(msg)

        with debug_time('make tea'):
            call_it_long_time()

        assert len(warnings) == 0
        assert len(messages) == 1
        assert messages[0].endswith('DEBUG: make tea took: 0:00:00.000001')
    finally:
        warn = old_warn
        debug = old_debug

# Generated at 2022-06-12 10:34:32.852017
# Unit test for function color
def test_color():
    assert color('green') == colorama.Fore.GREEN
    assert color('') == ''



# Generated at 2022-06-12 10:34:40.789541
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():

    import mock
    import StringIO

    configuration_details = mock.Mock()
    configuration_details.path = '~/.bashrc'
    configuration_details.content = 'content'
    configuration_details.reload = 'reload'
    configuration_details.can_configure_automatically = False

    captured_output = StringIO.StringIO()
    sys.stdout = captured_output

    how_to_configure_alias(configuration_details)

    sys.stdout = sys.__stdout__


# Generated at 2022-06-12 10:34:50.453325
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    corrected_command = type('', (), {
        'script': 'ls /non-existing-path',
        'side_effect': True,
    })
    sys.stderr = StringIO.StringIO()
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:34:51.830476
# Unit test for function color
def test_color():
    assert color('text') == ''
    settings.no_colors = False
    assert color('text') == 'text'

# Generated at 2022-06-12 10:34:55.352348
# Unit test for function debug
def test_debug():
    assert debug(u'test message') == sys.stderr.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test message\n')


# Generated at 2022-06-12 10:35:02.383588
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('sys.txt', 'w')
    show_corrected_command('ls')
    f = open('sys.txt', 'r')
    assert f.read() == '{}ls{}\n'.format(const.USER_COMMAND_MARK,
                                         color(colorama.Style.RESET_ALL))
    f.close()
    sys.stderr.close()
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:35:09.594810
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with open('test_show_corrected_command.out', 'w') as f:
        sys.stdout = f
        show_corrected_command(['python', '-m', 'Pyro4.naming', '-n', 'localhost'])
    with open('test_show_corrected_command.out', 'r') as f:
        assert f.readlines() == ['\x1b[34m\x1b[1m$ python -m Pyro4.naming -n localhost\x1b[0m\n']

# Generated at 2022-06-12 10:35:35.454702
# Unit test for function debug
def test_debug():
    from mock import patch, MagicMock

    stderr = MagicMock()
    with patch('sys.stderr', stderr):
        debug(u'Привет, PyCharm!')

    assert stderr.write.called

# Generated at 2022-06-12 10:35:37.366600
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == u'Corrected command: ls [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:35:38.476913
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:44.385693
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration import ConfigurationDetails
    how_to_configure_alias(None)
    how_to_configure_alias(ConfigurationDetails(None, None, False, None, None))
    how_to_configure_alias(ConfigurationDetails(None, None, True, None, None))
    how_to_configure_alias(ConfigurationDetails(None, None, True, None, None))

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:35:52.978077
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .types import CorrectedCommand
    from .conf import Configuration
    settings.no_colors = False
    settings.debug = False
    settings.wait_command = 0
    settings.repeat = False
    settings.history_limit = None
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.exclude_rules = []
    settings.rules = []
    settings.priority = {}
    if settings.alt_priority is None:
        settings.alt_priority = {}
    settings.no_colors = False
    settings.wait_command = 0
    settings.repeat = False
    settings.history_limit = None
    settings.require_confirmation = True
    settings.wait_command = 0
    settings.exclude_rules = []
    settings.rules = []

# Generated at 2022-06-12 10:35:53.926750
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass



# Generated at 2022-06-12 10:35:56.766461
# Unit test for function debug
def test_debug():
    from . import settings as _settings
    settings = _settings.Settings()
    settings.debug = True
    debug("test message")
    settings.debug = False
    debug("test message")

# Generated at 2022-06-12 10:35:59.295685
# Unit test for function debug_time
def test_debug_time():
    """
    Unit test for function debug_time
    """
    
    import time
    
    with debug_time('test'):
        time.sleep(1)



# Generated at 2022-06-12 10:36:07.392246
# Unit test for function confirm_text
def test_confirm_text():
    from unittest import TestCase
    import sys
    import io
    from .command import Command
    from .corrector import FixedRule
    from .shells import Shell

    class ConfirmTextTest(TestCase):
        def setUp(self):
            self.sut = u'fuck'
            self.shell = Shell()
            self.stdout = io.BytesIO()

        def tearDown(self):
            sys.stdout = sys.__stdout__

        def test_confirm_text(self):
            corrected_command = Command(u'ls', u'ls',
                                        '', self.shell)
            sys.stdout = self.stdout
            confirm_text(corrected_command)
            output = self.stdout.getvalue()

# Generated at 2022-06-12 10:36:09.170438
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(const.CorrectedCommand(script='cd $HOME',
                                        side_effect=False))

# Generated at 2022-06-12 10:36:34.492044
# Unit test for function confirm_text
def test_confirm_text():
    for command in [
            'echo',
            '!echo',
            # https://github.com/nvbn/thefuck/issues/598
            'a command\nwith newline',
            ]:
        corrected_command = type(u'CorrectedCommand', (object,),
                                 {'script': command, 'side_effect': False})
        confirm_text(corrected_command)

# Generated at 2022-06-12 10:36:36.803700
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = {
    '_side_effect': False,
    '_script': 'git push',
    '_debug': False
    }
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:36:42.398018
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .types import CorrectedCommand
    corrected_command = CorrectedCommand('ls /home')
    show_corrected_command_stdout = sys.stdout
    sys.stdout = sys.stderr
    show_corrected_command(corrected_command)
    sys.stdout = show_corrected_command_stdout
    assert sys.stderr.getvalue() == '> ls /home\n'



# Generated at 2022-06-12 10:36:49.417895
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(const.CorrectedCommand(script='ls', side_effect=True)) == \
        '{prefix}{clear}{bold}ls{reset} (+side effect) [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(prefix=const.USER_COMMAND_MARK, clear='\033[1K\r', bold=color(colorama.Style.BRIGHT), script='ls', side_effect=' (+side effect)', green=color(colorama.Fore.GREEN), red=color(colorama.Fore.RED), reset=color(colorama.Style.RESET_ALL), blue=color(colorama.Fore.BLUE))


# Generated at 2022-06-12 10:36:51.946792
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False



# Generated at 2022-06-12 10:36:53.471155
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from time import sleep
    with debug_time('test'):
        sleep(1)

# Generated at 2022-06-12 10:36:55.212563
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert u'[corrected command]' in show_corrected_command(u'[corrected command]')

# Generated at 2022-06-12 10:37:02.365494
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    from thefuck.rules.man import correct_command
    from thefuck.utils import confirm_text
    from tests.utils import Command

    command = Command('fuck', '', '', '')
    corrected_command = correct_command(command)
    out = io.StringIO()
    sys.stdout = out
    confirm_text(corrected_command)
    output = out.getvalue().strip()
    sys.stdout = sys.__stdout__
    assert "fuck " in output
    assert "enter" in output

# Generated at 2022-06-12 10:37:07.529184
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'git log',
        'side_effect': True
    })
    confirm_text(corrected_command)
    corrected_command = type('CorrectedCommand', (object,), {
        'script': 'git log',
        'side_effect': False
    })
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:37:11.240939
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class FakeCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(FakeCommand(u'ls'))
    show_corrected_command(FakeCommand(u'ls -la', side_effect=True))

# Generated at 2022-06-12 10:38:03.398593
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    sys.stderr = StringIO()
    confirm_text('test')
    assert sys.stderr.getvalue() == \
        u'{prefix}test [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/' \
         '{red}ctrl+c{reset}]'.format(
                prefix=const.USER_COMMAND_MARK,
                green=color(colorama.Fore.GREEN),
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                red=color(colorama.Fore.RED))


# Generated at 2022-06-12 10:38:04.970608
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) == ''

# Generated at 2022-06-12 10:38:15.624811
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Set up the environment for testing
    sys.stderr.write = mock_write
    settings.no_colors = False

    # Test that the output is correct
    from .command import Command
    cmd = Command('ls')
    show_corrected_command(cmd)
    assert sys.stderr.buffer[-1] == b'{prefix}ls\n'.replace(b'{prefix}',
                                                            bytes(const.USER_COMMAND_MARK, 'UTF-8'))

    # Test that the output is correct when side effect is set to true
    cmd = Command('ls', side_effect=True)
    show_corrected_command(cmd)

# Generated at 2022-06-12 10:38:26.477545
# Unit test for function debug
def test_debug():
    _s = []

    def _f(msg):
        _s.append(msg)

    sys.stderr.write = _f
    settings.debug = True
    debug('msg')
    assert _s == ['\x1b[36m\x1b[1mDEBUG:\x1b[0m msg\n']
    settings.debug = False
    debug('msg')
    assert _s == ['\x1b[36m\x1b[1mDEBUG:\x1b[0m msg\n']

    # Unit test for function warn
    _s = []

    def _f(msg):
        _s.append(msg)

    sys.stderr.write = _f
    warn('msg')

# Generated at 2022-06-12 10:38:30.335091
# Unit test for function debug_time
def test_debug_time():
    output = ""
    started = datetime.now()

    @contextmanager
    def debug_time(msg):
        try:
            yield
        finally:
            output += u'{} took: {}'.format(msg, datetime.now() - started)

    with debug_time("asd"):
        pass
    assert output == "asd took: 0:00:00"

# Generated at 2022-06-12 10:38:35.374466
# Unit test for function debug
def test_debug():
    import StringIO
    log = StringIO.StringIO()
    settings.debug = True
    try:
        with debug_time('Foobar'):
            debug('Foo')
            debug('Bar')
        sys.stderr = log
        debug('Baz')
        assert log.getvalue() == ''
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-12 10:38:37.797878
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls => ls')
    settings.no_colors = True
    show_corrected_command('ls => ls')
    settings.no_colors = False

# Generated at 2022-06-12 10:38:46.405029
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import text_length
    from .shells import Shell
    assert text_length(confirm_text(Shell.from_name('bash')(None).get_history()[0])) == 25
    assert text_length(confirm_text(Shell.from_name('zsh')(None).get_history()[0])) == 24
    assert text_length(confirm_text(Shell.from_name('fish')(None).get_history()[0])) == 24
    assert text_length(confirm_text(Shell.from_name('tcsh')(None).get_history()[0])) == 25

# Generated at 2022-06-12 10:38:48.096623
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test') as e:
        time.sleep(2)
        assert e == True

# Generated at 2022-06-12 10:38:49.568680
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    show_corrected_command(CorrectedCommand('test', True))

# Generated at 2022-06-12 10:40:21.271208
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells.shell import Shell

    corrected_command = Shell().from_raw_script('git branch')
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == u'\u001b[0m$ \u001b[1mgit branch\u001b[0m\n'

# Generated at 2022-06-12 10:40:23.014470
# Unit test for function debug
def test_debug():
    debug("hello")


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:40:24.360992
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text (corrected_command) == '../~/.'

# Generated at 2022-06-12 10:40:27.257482
# Unit test for function confirm_text
def test_confirm_text():
    import os
    if os.name != 'posix':
        pass
    else:
        corrected_command = type('', (), {'script': 'test',
                                          'side_effect': False})()
        confirm_text(corrected_command)

# Generated at 2022-06-12 10:40:29.804343
# Unit test for function debug_time
def test_debug_time():
    called = []

    with debug_time('Test me') as time:
        time.sleep(1)
        called.append(True)

    assert called == [True]

# Unit tests for function show_corrected_command

# Generated at 2022-06-12 10:40:36.593911
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck import conf
    from thefuck.engine import Command
    conf.settings.no_colors = True
    with patch('sys.stderr') as stderr:
        confirm_text(Command('ls', '', 'ls'))
        stderr.write.assert_called_with(
            'git:(master) ✗ ls [enter/↑/↓/ctrl+c]')
    with patch('sys.stderr') as stderr:
        conf.settings.no_colors = False
        confirm_text(Command('ls', '', 'ls'))

# Generated at 2022-06-12 10:40:38.123794
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    assert timedelta(seconds=0.001) < debug_time('test').next().next()

# Generated at 2022-06-12 10:40:47.655602
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import sys
    import io
    import colorama
    import contextlib
    class conf():
        def __init__(self):
            self.bold=color(colorama.Style.BRIGHT)
            self.reset=color(colorama.Style.RESET_ALL)
            self.content=""
            self.path=""
            self.reload=""
            self.can_configure_automatically=1
    configuration_details=conf()

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr

# Generated at 2022-06-12 10:40:50.465435
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('') == ''
    assert color('foo') == ''

# Generated at 2022-06-12 10:40:53.373269
# Unit test for function confirm_text
def test_confirm_text():
    lines = sys.stdin.readline
    lines = list(lines)
    for line in lines:
        print(line)


if __name__ == '__main__':
    test_confirm_text()