

# Generated at 2022-06-12 10:32:15.491806
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck import main
    corrected_command = main.CorrectedCommand('ls', 'ls', 'ls -G')
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:32:18.445490
# Unit test for function color
def test_color():
    assert color(u'Foo') == u'\x1b[0mFoo\x1b[0m\x1b[0m'
    settings.no_colors = True
    assert color(u'Bar') == u''

# Generated at 2022-06-12 10:32:25.634226
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from contextlib import contextmanager

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            sys.stderr.write(u'{} took: {}\n'.format(msg, datetime.now() - started))

    with debug_time(u'test'):
        fake_time = timedelta(seconds=0.01)
        datetime.now = lambda: datetime.now() + fake_time

# Generated at 2022-06-12 10:32:26.929205
# Unit test for function show_corrected_command
def test_show_corrected_command():
    output = show_corrected_command('sdfsdfs')
    assert output == u'#sdfsdfs\n'


# Generated at 2022-06-12 10:32:33.709387
# Unit test for function confirm_text
def test_confirm_text():
    from .types import CorrectedCommand

    class MockStdErr():
        def __init__(self):
            self.text = ""

        def write(self, text):
            self.text = text

    std_err = MockStdErr()
    sys.stderr = std_err
    command = "git commit -m *"
    corrected_command = CorrectedCommand(command, True)
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:32:38.418787
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(u'{prefix}{bold}{script}{reset}{side_effect}'.format(
        prefix=const.USER_COMMAND_MARK,
        script='test_script',
        side_effect=u' (+side effect)',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-12 10:32:42.024889
# Unit test for function color
def test_color():
    def check_colors(no_colors, colors):
        settings.no_colors = bool(no_colors)
        assert color(colors) == '' if no_colors else colors
    yield check_colors, None, '\033[31m'
    yield check_colors, 1, ''

# Generated at 2022-06-12 10:32:46.662836
# Unit test for function debug
def test_debug():
    from tempfile import NamedTemporaryFile
    file = NamedTemporaryFile('w+')
    _stderr = sys.stderr
    try:
        sys.stderr = file
        debug(u'Hello World!')
        file.flush()
        file.seek(0)
        result = file.read()
        assert result == 'DEBUG: Hello World!'
    finally:
        sys.stderr = _stderr
        file.close()

# Generated at 2022-06-12 10:32:48.422401
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls -la\n')
    show_corrected_command('ls\n')

# Generated at 2022-06-12 10:32:54.878392
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import builtins
    builtins.input = lambda _: 'Enter'
    out = io.StringIO()
    sys.stderr = out
    try:
        confirm_text(const.CorrectedCommand(u"ls"))
        out.seek(0)
        result = out.read()
        assert result == '>ls [enter/↑/↓/ctrl+c]', 'fail test'
    finally:
        sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:33:06.723250
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck import conf
    from thefuck.conf import Config
    from thefuck.rules import Rule
    from thefuck.types import CorrectedCommand

    settings.side_effect = False

    corrected_command = CorrectedCommand(
        script='ls -la', side_effect=False)
    confirm_text(corrected_command)

    settings.side_effect = True
    conf.Config = Config(conf._load_config(conf.get_config_path()), [])
    conf.Config.rules = [Rule('fuck', lambda p: 'ls -la')]

    corrected_command = CorrectedCommand(
        script='ls -la', side_effect=True)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:33:08.380822
# Unit test for function debug
def test_debug():
    assert u"FOO" == debug(u"FOO")



# Generated at 2022-06-12 10:33:10.830203
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(script=u'ls -a', side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:33:20.516694
# Unit test for function debug
def test_debug():
    from types import ModuleType
    def mock_debug_function(msg):
        mock_debug_function.last_msg = msg
    mock = ModuleType('mock')
    mock.debug = mock_debug_function
    sys.modules['thefuck.shells.globals'] = mock

    settings.debug = True
    debug('msg_1')
    assert mock_debug_function.last_msg == 'msg_1'

    settings.debug = False
    debug('msg_2')
    assert mock_debug_function.last_msg == 'msg_1'

    del sys.modules['thefuck.shells.globals']

# Generated at 2022-06-12 10:33:25.566890
# Unit test for function debug
def test_debug():
    import StringIO
    test_output = StringIO.StringIO()
    sys.stderr = test_output
    debug('debug')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:33:28.982521
# Unit test for function debug_time
def test_debug_time():
    import datetime
    from time import sleep
    import uuid
    msg = uuid.uuid4().hex
    with debug_time(msg):
        sleep(1)
    assert u'{} took: '.format(msg) in msg

# Generated at 2022-06-12 10:33:31.103731
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = 1
    assert how_to_configure_alias(configuration_details) == None


# Generated at 2022-06-12 10:33:39.375551
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import io
    import textwrap
    from thefuck.utils import how_to_configure_alias
    from thefuck.shells import ConfigurationDetails, shell

    def _stdout():
        return sys.stdout.getvalue()

    configuration_details = ConfigurationDetails('/home/user/.bashrc',
                                                 'fuck = $(thefuck $(fc -ln -1))',
                                                 'source ~/.bashrc')

    sys.stdout = io.StringIO()
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:33:41.862513
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "ls -la"
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:33:47.155405
# Unit test for function confirm_text
def test_confirm_text():
    from .command import Command
    from .shells import Shell
    shell = Shell()
    shell.from_shell('test_alias', 'alias test_alias=test')
    shell.aliases['test_alias']['command'] = Command('test_alias', 'test_alias', 'test')
    sys.stderr.write = sys.stdout.write
    settings.no_colors = False
    confirm_text(shell.aliases['test_alias']['command'])

# Generated at 2022-06-12 10:33:51.840528
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('Test msg'):
        time.sleep(0.1)
    assert True

# Generated at 2022-06-12 10:33:54.964759
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Config
    from .utils import extract_command

    config = Config(settings)
    extract_command(config, False, False, False)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:33:56.825421
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('test'):
            raise Exception
    except Exception:
        pass

# Generated at 2022-06-12 10:33:58.229850
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None



# Generated at 2022-06-12 10:34:04.117805
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == colorama.Back.RED + colorama.Fore.WHITE \
            + colorama.Style.BRIGHT
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == ''
    assert color(colorama.Style.RESET_ALL) == ''



# Generated at 2022-06-12 10:34:07.084901
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:34:09.221942
# Unit test for function debug_time
def test_debug_time():
    print('Running debug_time test')
    import time
    with debug_time('foo'):
        time.sleep(1)

# Generated at 2022-06-12 10:34:13.771546
# Unit test for function confirm_text
def test_confirm_text():
    # Just to make side effects
    sys.stderr.write("\033[1K\r")
    # Hardcoded for testing for python2.6 (no unicode_literals)
    assert confirm_text("Command") == u'\u200b[enter/\u2191/\u2193/ctrl+c]'

# Generated at 2022-06-12 10:34:16.165677
# Unit test for function confirm_text
def test_confirm_text():
    confirmed_text = "ls -l"
    show_corrected_command(confirmed_text)
    assert confirmed_text == "ls -l"



# Generated at 2022-06-12 10:34:18.495357
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.conf import settings
    __builtins__ = settings._replace(no_colors=False).__dict__

    assert confirm_text('sudo echo 42') == 'sudo echo 42'

# Generated at 2022-06-12 10:34:24.111319
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    for configuration_details in [None, ConfigurationDetails(None, None)]:
        how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:34:25.717094
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git commit') == u'git commit [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:34:26.941315
# Unit test for function debug
def test_debug():
    debug('Hello world')



# Generated at 2022-06-12 10:34:29.619915
# Unit test for function confirm_text
def test_confirm_text():
    import shlex
    corrected_command = const.CorrectedCommand(shlex.split(u'pwd'), ['ls'])
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:34:38.909611
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    debug_stream = StringIO()
    handler = sys.stderr
    try:
        sys.stderr = debug_stream
        debug(u'unicode text')
        debug(42)
        debug({u'unicode': 'text'})

        assert(debug_stream.getvalue() ==
               u'\x1b[34m\x1b[1mDEBUG:\x1b[0m unicode text\n'
               u'\x1b[34m\x1b[1mDEBUG:\x1b[0m 42\n'
               u'\x1b[34m\x1b[1mDEBUG:\x1b[0m {u\'unicode\': \'text\'}\n')
    finally:
        sys.stderr = handler

# Generated at 2022-06-12 10:34:43.127310
# Unit test for function debug_time
def test_debug_time():
    from nose.tools import assert_greater
    from datetime import timedelta

    with debug_time('somestring'):
        import time
        time.sleep(0.02)

    assert_greater(timedelta(0, 0, 20000), timedelta(0, 0, 10000))

# Generated at 2022-06-12 10:34:43.775248
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass



# Generated at 2022-06-12 10:34:45.763426
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = "ls -la"
    corrected_command.side_effect = False
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:34:47.419432
# Unit test for function color
def test_color():
    assert color('---') == '---'
    settings.no_colors = True
    assert color('') == ''

# Generated at 2022-06-12 10:34:50.627167
# Unit test for function show_corrected_command
def test_show_corrected_command():
    const.USER_COMMAND_MARK = '>'
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('vcs', 'git prune',
                                            side_effect=True))



# Generated at 2022-06-12 10:34:57.036469
# Unit test for function debug_time
def test_debug_time():
    import datetime
    t = datetime.datetime.now()
    f = debug_time('test debug')

    assert f

    with f as func:
        func

    assert datetime.datetime.now() - t

# Generated at 2022-06-12 10:35:00.932130
# Unit test for function debug
def test_debug():
    from testing.capture import CapturedIO
    from . import utils

    with CapturedIO() as (stdout, stderr):
        utils.debug('msg')
        assert not stdout.getvalue()
        assert 'DEBUG: msg\n' == stderr.getvalue()

# Generated at 2022-06-12 10:35:01.922797
# Unit test for function debug
def test_debug():
    debug('TEST')



# Generated at 2022-06-12 10:35:03.942516
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as t:
        import time     
        time.sleep(0.1)

    assert True

# Generated at 2022-06-12 10:35:07.507783
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch

    with patch('sys.stderr') as mock_stderr:
        confirm_text(FakeCommand('fake_script', True))
        assert mock_stderr.write.called



# Generated at 2022-06-12 10:35:11.916801
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'git status'
    from .shells.base import BaseShell # in order to make 'shells.base' importable
    corrected_command = BaseShell(command, None, None)
    corrected_command.script = 'git commit'
    corrected_command.side_effect = True
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:35:16.109720
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT) == colorama.Back.RED + colorama.Fore.WHITE + \
                                           colorama.Style.BRIGHT
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL



# Generated at 2022-06-12 10:35:26.343528
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import six
    import thefuck.shells.zsh as zsh

    with mock.patch('sys.stderr', new_callable=six.StringIO) as mock_stderr:
        confirm_text(zsh.CorrectedCommand(u'cmd', u'echo test'))

# Generated at 2022-06-12 10:35:26.819260
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:35:29.457422
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    with debug_time('test_debug_time'):
        # Just wait until debug_time() call is printed.
        pass

# Generated at 2022-06-12 10:35:35.839731
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('git push', 'git push'))
    show_corrected_command(Command('git push', 'git push', True))



# Generated at 2022-06-12 10:35:40.681486
# Unit test for function debug_time
def test_debug_time():
    import mock
    import time
    import datetime
    with mock.patch('sys.stderr') as stderr:
        with debug_time('test_message'):
            time.sleep(1)
        stderr.write.assert_any_call(
            u'test_message took: {}\n'.format(datetime.timedelta(seconds=1)))

# Generated at 2022-06-12 10:35:50.267738
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .const import ALIAS, REMOVE_OLD_ALIAS, RELOAD, CONFIGURATION
    alias = ALIAS
    remove_old_alias = REMOVE_OLD_ALIAS
    reload_ = RELOAD
    configuration = CONFIGURATION

    assert (
        how_to_configure_alias(ConfigurationDetails(None, None,
                                                    None, None, None, None))
        == ('Seems like \x1b[1mfuck\x1b[0m alias isn\'t configured!\n'
            '\n'
            'More details - https://github.com/nvbn/thefuck#manual-installation'))


# Generated at 2022-06-12 10:35:55.241275
# Unit test for function debug_time
def test_debug_time():
    def func():
        import time
        with debug_time('test'):
            time.sleep(1)
            print('Tested')
    import cStringIO
    import sys
    out = cStringIO.StringIO()
    sys.stdout = out
    func()
    assert 'Tested' in out.getvalue()


# Generated at 2022-06-12 10:35:57.592423
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class C:
        script = "Some correct command"
        side_effect = False
    show_corrected_command(C)



# Generated at 2022-06-12 10:36:03.370874
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stderr():
        stderr = sys.stderr
        sys.stderr = StringIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = stderr

    with capture_stderr() as stderr:
        debug('hello')

    assert stderr.getvalue() == u'DEBUG: hello\n'

# Generated at 2022-06-12 10:36:05.471072
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        script = 'ls'
        side_effect = True

    show_corrected_command(CorrectedCommand())

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:36:11.703797
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log
    from .log import debug

    with patch('sys.stderr.write') as write_mock:
        with log.debug_time('Test'):
            pass

        assert write_mock.call_count == 1
        assert write_mock.call_args[0][0] ==\
            u'{} took: {}'.format(u'Test', timedelta())



# Generated at 2022-06-12 10:36:13.281061
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("test1") == "\rtest1 [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-12 10:36:13.791671
# Unit test for function debug
def test_debug():
    debug('msg')

# Generated at 2022-06-12 10:36:24.301773
# Unit test for function debug
def test_debug():
    class Shell(object):
        def __init__(self):
            self.called_command = ''

        def get_key(self):
            return 'test_debug'

        def get_history(self):
            return []

        def _call_and_wait(self, command, **kwargs):
            self.called_command = command

        def get_history_ruby_fish(self):
            return []

        def get_everything_before_last_command(self):
            return ''

    shell = Shell()
    debug(u'test debug')
    assert shell.called_command == 'test debug'

# Generated at 2022-06-12 10:36:26.778172
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = 'ls'
    corrected_command = thefuck.corrected_command.CorrectedCommand(command)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:36:28.766835
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    s = Shell()
    text = confirm_text(s)

# Generated at 2022-06-12 10:36:33.394843
# Unit test for function confirm_text
def test_confirm_text():
    class Command(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    assert confirm_text(Command('ls')) == 'fuck ls [enter/↑/↓/ctrl+c]'
    assert confirm_text(Command('ls', side_effect=True)) == 'fuck ls (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:36:35.918874
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git branch\n') == 'git branch\n'
    assert confirm_text('git branch ') == 'git branch [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:36:38.771980
# Unit test for function debug_time
def test_debug_time():
    """
    In order to run this test, you should have debug mode on
    """
    with debug_time('unit test for function debug_time'):
        import time
        time.sleep(1)

# Generated at 2022-06-12 10:36:47.343895
# Unit test for function debug
def test_debug():
    class FakeStdErr(object):
        def __init__(self):
            self.messages = []

        def write(self, msg):
            self.messages.append(msg)

        @property
        def message(self):
            return ''.join(self.messages)

    fake_err = FakeStdErr()
    orig_stderr, sys.stderr = sys.stderr, fake_err

    debug(u'Test message')
    assert fake_err.message == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test message\n'

    settings.debug = False
    debug(u'Test message 2')
    assert not fake_err.message

    settings.debug = True
    settings.no_colors = True

# Generated at 2022-06-12 10:36:56.464135
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import datetime, timedelta

    with patch('sys.stderr.write') as mock_write:
        with debug_time('test'):
            datetime.now = lambda: datetime(2015, 7, 22, 19, 29, 0, 0)
        mock_write.assert_called_once_with(
            'test took: 0:00:00\n')

    with patch('sys.stderr.write') as mock_write:
        with debug_time('test'):
            datetime.now = lambda: datetime(2015, 7, 22, 19, 29, 5, 0)
        mock_write.assert_called_once_with(
            'test took: 0:00:05\n')


# Generated at 2022-06-12 10:37:01.605432
# Unit test for function debug
def test_debug():
    import sys
    import mock

    debugger = mock.Mock()
    with mock.patch.object(sys, 'stderr', debugger):
        debug('test-message')
    debugger.write.assert_called_once_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test-message\n')

# Generated at 2022-06-12 10:37:10.793365
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import mock
    from functools import partial
    from ..how_to_configure import debug_time

    class DebugTimeTest(unittest.TestCase):
        def setUp(self):
            patcher = mock.patch('datetime.datetime',
                                 spec_set=partial(mock.PropertyMock))
            self.addCleanup(patcher.stop)
            self.datetime = patcher.start()
            self.datetime.now.return_value = 1

        @mock.patch('sys.stderr.write')
        @mock.patch('datetime.datetime',
                    spec_set=partial(mock.PropertyMock))
        def test_debug(self, datetime, stderr_write):
            datetime.now.return_value = 5


# Generated at 2022-06-12 10:37:15.808455
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = {'script': '/bin/ls', 'side_effect': False}
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:37:26.721786
# Unit test for function confirm_text
def test_confirm_text():
    import mock

    correct_command = mock.Mock()
    correct_command.script = u'sudo fuck'
    correct_command.side_effect = True

    prompt = u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'

    confirm_text(correct_command)

    sys.stderr.write.assert_called_with(prompt.format(
            prefix='$ ',
            script=u'sudo fuck',
            side_effect=' (+side effect)',
            clear='\033[1K\r',
            bold=u'',
            green=u'',
            red=u'',
            reset=u'',
            blue=u''))

# Generated at 2022-06-12 10:37:33.151187
# Unit test for function color
def test_color():
    reset = color(colorama.Style.RESET_ALL)
    assert color(
        colorama.Back.LIGHTYELLOW_EX + colorama.Style.BRIGHT
        + 'test_string') == reset + 'test_string' + reset

    settings.no_colors = True
    reset = color(colorama.Style.RESET_ALL)
    assert color(
        colorama.Back.LIGHTYELLOW_EX + colorama.Style.BRIGHT
        + 'test_string') == 'test_string'

    settings.no_colors = False

# Generated at 2022-06-12 10:37:34.510541
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='')
    confirm_text(corrected_command='')

# Generated at 2022-06-12 10:37:36.908274
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('Hi'):
            pass
    except StopIteration:
        pass



# Generated at 2022-06-12 10:37:38.422782
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text({'script': 'PWD', 'side_effect': False})


# Generated at 2022-06-12 10:37:48.034952
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    stderr = mock.Mock()
    with mock.patch('sys.stderr', stderr):
        confirm_text(mock.Mock(script='git commit -m "test"',
                               side_effect=False))
        stderr.write.assert_called_once_with(u'fuck git commit -m "test" [enter/↑/↓/ctrl+c]')
        stderr.reset_mock()
        confirm_text(mock.Mock(script='git commit -m "test"',
                               side_effect=True))
        stderr.write.assert_called_once_with(u'fuck git commit -m "test" (+side effect) [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-12 10:37:52.452839
# Unit test for function debug
def test_debug():
    from mock import patch
    from six import StringIO
    from . import log

    output = StringIO()
    with patch('sys.stderr', output):
        log.debug('test')
        assert output.getvalue() == ''

        settings.debug = True
        log.debug('test')
        assert 'DEBUG' in output.getvalue()
        assert 'test' in output.getvalue()

# Generated at 2022-06-12 10:38:02.133602
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    stdout = StringIO.StringIO()
    old_stdout = sys.stdout
    sys.stdout = stdout
    from .conf import ConfigurationDetails
    configuration_details = ConfigurationDetails(
        path=u'~/.bashrc', path_type='file', reload='source ~/.bashrc',
        command_line='eval $(thefuck --alias)',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    sys.stdout = old_stdout

# Generated at 2022-06-12 10:38:03.398194
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as result:
        assert result is None

# Generated at 2022-06-12 10:38:16.113336
# Unit test for function show_corrected_command
def test_show_corrected_command():
    settings.no_colors = False
    show_corrected_command(verbose_commands.VerboseCommand('test', False))
    settings.no_colors = True
    show_corrected_command(verbose_commands.VerboseCommand('test', False))
    settings.no_colors = False
    show_corrected_command(verbose_commands.VerboseCommand('test', True))
    settings.no_colors = True
    show_corrected_command(verbose_commands.VerboseCommand('test', True))



# Generated at 2022-06-12 10:38:21.337981
# Unit test for function debug
def test_debug():
    # Initialize settings
    settings.debug = True
    # Call function
    debug('test')
    # Check result
    assert sys.stderr.getvalue() ==\
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    # Clear stdout
    sys.stderr.seek(0)
    sys.stderr.truncate()

# Generated at 2022-06-12 10:38:23.978620
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = type('',(object,),{'script':'fuck'})
    show_corrected_command(corrected_command)

test_show_corrected_command()

# Generated at 2022-06-12 10:38:25.360064
# Unit test for function debug_time
def test_debug_time():
    """test_debug_time"""
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:38:31.640535
# Unit test for function confirm_text
def test_confirm_text():
    from io import BytesIO
    from .shells.bash import Bash
    from .shells.zsh import Zsh

    for shell_class in (Bash, Zsh):
        with BytesIO() as out:
            with shell_class(stdin=BytesIO(), stdout=out) as shell:
                shell.confirm_text(shell.CorrectedCommand(
                    shell.from_shell('test'), 'corrected', False))
                assert shell.from_pipe(out) == u'$ test [enter/↑/↓/ctrl+c]'


# Unit tests for function exception

# Generated at 2022-06-12 10:38:32.944262
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass
    debug('test')

# Generated at 2022-06-12 10:38:40.142980
# Unit test for function debug
def test_debug():
    import pytest
    from contextlib import contextmanager, nested
    from mock import patch

    from thefuck.utils import debug, debug_time

    @contextmanager
    def capture():
        with nested(patch('sys.stderr'), patch('thefuck.utils.datetime')) as \
                (stderr, datetime):
            datetime.now.return_value = datetime
            datetime.strftime.return_value = '00:00:00'
            yield stderr.write

    @pytest.mark.parametrize('msg', ['msg', u'msg'])
    def test_debug_with_color(msg):
        with capture() as mock_write:
            debug(msg)

# Generated at 2022-06-12 10:38:41.724361
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u"command") == u'[enter/↑/↓/ctrl+c]'



# Generated at 2022-06-12 10:38:44.752541
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-12 10:38:46.106346
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'ls'
    print(confirm_text(corrected_command))

# Generated at 2022-06-12 10:38:53.430412
# Unit test for function color
def test_color():
    assert color(u'foo') == 'foo'
    settings.no_colors = True
    assert color(u'foo') == ''

# Generated at 2022-06-12 10:38:58.507323
# Unit test for function color
def test_color():
    # color(something) should be something always
    assert color(u'1') == u'1'
    assert color(u'') == u''
    assert color(u'12') == u'12'
    assert color(u'123') == u'123'


# Generated at 2022-06-12 10:38:59.080108
# Unit test for function debug
def test_debug():
    debug('debug')

# Generated at 2022-06-12 10:39:04.184579
# Unit test for function debug_time
def test_debug_time():
    import os
    import thefuck.shells.bash as bash

    with debug_time('test'):
        print(bash.and_(('echo test', 'echo test2')))

    os.environ['TF_DEBUG'] = 'true'

    with debug_time('test'):
        print(bash.and_(('echo test', 'echo test2')))

    del os.environ['TF_DEBUG']

# Generated at 2022-06-12 10:39:12.753871
# Unit test for function confirm_text
def test_confirm_text():
    """Unit test for function confirm_text"""
    from .core import Command
    text = const.USER_COMMAND_MARK + "I'm a command"
    result = (u'\u262aI\'m a command [\x1b[32menter\x1b[39m/\x1b[34m\u2191'
              u'\x1b[39m/\x1b[34m\u2193\x1b[39m/\x1b[31mctrl+c\x1b[39m]\x1b[0m')
    assert confirm_text(Command('I\'m a command', 'I\'m a command')) == result

# Generated at 2022-06-12 10:39:16.518401
# Unit test for function debug
def test_debug():
    from mock import Mock
    from .debug import sys  # noqa
    sys = Mock()
    debug(u'test debug')
    sys.assert_called_once_with(u'\x1b[94m\x1b[1mDEBUG:\x1b[0m test debug\n')

# Generated at 2022-06-12 10:39:18.520096
# Unit test for function debug_time
def test_debug_time():
    settings.debug = True
    with debug_time('some msg') as m:
        pass
    assert m

# Generated at 2022-06-12 10:39:20.315501
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Show help message when alias hasn't been configured.
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:39:24.241929
# Unit test for function debug
def test_debug():
    from mock import Mock

    mock_stderr = Mock()

    with debug_time('test'):
        debug('test', stderr=mock_stderr)

    assert mock_stderr.called



# Generated at 2022-06-12 10:39:25.617920
# Unit test for function debug
def test_debug():
    with debug_time(u'lol'):
        pass



# Generated at 2022-06-12 10:39:32.706407
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:39:37.478573
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from contextlib import contextmanager

    @contextmanager
    def debug_time(msg):
        started = datetime.now()

# Generated at 2022-06-12 10:39:42.208704
# Unit test for function debug_time
def test_debug_time():
    "test_debug_time"
    import mock
    with mock.patch('datetime.datetime') as datetime_:
        datetime_.now.return_value = mock.Mock(microsecond=100)
        with debug_time('test') as result:
            datetime_.now.return_value = mock.Mock(microsecond=200)
            assert result == datetime_.now.return_value.microsecond - 100

# Test for function version

# Generated at 2022-06-12 10:39:52.757740
# Unit test for function debug
def test_debug():
    from . import shell
    from .shells import get_shell
    from .utils import get_closest
    from .fuckers import InMemoryRuleFucker
    from .main import main
    from .rules import get_rules
    from . import conf

    def assert_debug(output, input_):
        with shell.debug_time('Debug'):
            get_closest(input_, ['test'])
        assert output in shell.debug_output

    assert_debug('Fuzzy matched: {}'.format(['test']), 'tes')
    assert_debug('Ambiguous command: {}'.format(['test']), 'test')

    shell.debug_output = []
    conf.debug = False
    assert_debug('', 'tes')

    shell.debug_output = []
    conf.debug = True
    shell.usage

# Generated at 2022-06-12 10:39:55.900190
# Unit test for function debug_time
def test_debug_time():
    from os import getenv
    from .main import main

    kwargs = {
        'env': { 'THEFUCK_DEBUG': 'true'},
        'input': 'fuck'
    }

    main(**kwargs)


# Generated at 2022-06-12 10:39:58.147780
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = ''
    confirm_text(corrected_command)

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:40:01.825790
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert (
        show_corrected_command(dict(script='git sutatus', side_effect=False))
        == 'git sutatus'
    )
    assert (
        show_corrected_command(dict(script='git sutatus', side_effect=True))
        == 'git sutatus (+side effect)'
    )

# Generated at 2022-06-12 10:40:02.984833
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        x = datetime.now()
    assert x

# Generated at 2022-06-12 10:40:03.819926
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('cd ..')


# Generated at 2022-06-12 10:40:11.249754
# Unit test for function debug
def test_debug():
    from .testutils import create_settings
    from .testutils import create_os_patches
    from .testutils import create_shell_patches
    with create_settings(debug=True), create_os_patches(), create_shell_patches():
        debug(u'foo')
        assert sys.stderr.getvalue() == \
            u'{blue}{bold}DEBUG:{reset} foo\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT))

# Generated at 2022-06-12 10:40:23.827457
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from os import environ
    old_stdout, sys.stderr = sys.stderr, StringIO()
    environ['TF_DEBUG'] = '1'
    debug(u'Сообщение')
    assert u'\033[34mDEBUG:\033[0m Сообщение\n' in sys.stderr.getvalue()
    del environ['TF_DEBUG']
    sys.stderr = old_stdout



# Generated at 2022-06-12 10:40:29.060312
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import mock
    from . import debug


# Generated at 2022-06-12 10:40:36.141531
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .rule import ConfigurationDeatils
    import os
    import random

    with open('Test_configuration_deatils_how_to_configure_alias.txt', 'w') as f:
        pass
    sys.stdout = open('Test_configuration_deatils_how_to_configure_alias.txt', 'a')

    for i in range(100):
        configuration_details = ConfigurationDeatils(
            path=random.choice(os.listdir('/usr/local')),
            content=random.choice(os.listdir('/usr/local')),
            reload='reload',
            can_configure_automatically=False)
        how_to_configure_alias(configuration_details)
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 10:40:43.457515
# Unit test for function confirm_text
def test_confirm_text():
    from . import corrector
    from .types import CorrectedCommand
    from .shells import Shell

    corrected_command = CorrectedCommand(Shell(), 'echo', '')

    sys.stderr = open('/dev/null', 'w')

    confirm_text(corrected_command)

    with open('/dev/null') as fd:
        assert fd.read() == (u'{}echo [] [enter/↑/↓/ctrl+c]'.format(
            const.USER_COMMAND_MARK))

    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:40:45.784911
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    class MockCommand(object):
        script = u'ls'
        side_effect = True

    confirm_text(MockCommand())

# Generated at 2022-06-12 10:40:50.301145
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules.git import match, get_new_command
    assert match(u'git branch')
    assert not match(u'git branchs')
    assert not match(u'fuck branchs')
    assert not match(u'fuck branch')
    assert get_new_command(u'git branch', u'git branchs') == u'git branch'

# Generated at 2022-06-12 10:40:56.779742
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.corrector import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', False))
    show_corrected_command(CorrectedCommand('ls -al', False))
    show_corrected_command(CorrectedCommand('ls --help', False))
    show_corrected_command(CorrectedCommand('ls', True))
    show_corrected_command(CorrectedCommand('ls -al', True))
    show_corrected_command(CorrectedCommand('ls --help', True))



# Generated at 2022-06-12 10:40:57.952485
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias() == None


# Generated at 2022-06-12 10:41:03.143791
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell
    from .corrector import Correction
    from .rule import Command

    corrected_command = Correction(Command(script='gco master',
                                           side_effect=False), '  git commit -m "-"', shell)

    confirm_text(corrected_command)



# Generated at 2022-06-12 10:41:05.147799
# Unit test for function color
def test_color():
    assert color(u'foo') == u''
    settings.no_colors = False
    assert color(u'foo') == u'foo'

# Generated at 2022-06-12 10:41:19.358140
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test') as t:
        import time
        time.sleep(0.1)
        assert t.time() < 0.1 # it means that assertion will fail if time > 0.1 sec


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:41:26.226298
# Unit test for function confirm_text
def test_confirm_text():
    import io
    output = io.StringIO()
    sys.stderr = output
    from .rules.python import match, get_new_command
    corrected_command = get_new_command('python', 'python')
    confirm_text(corrected_command)
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:41:27.067405
# Unit test for function color
def test_color():
    assert color('test') == 'test'



# Generated at 2022-06-12 10:41:31.300527
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = u'echo hello'
    const.USER_COMMAND_MARK = 'fuck: '
    result = const.USER_COMMAND_MARK + corrected_command
    show_corrected_command(corrected_command)
    assert result == corrected_command



# Generated at 2022-06-12 10:41:33.725793
# Unit test for function debug_time
def test_debug_time():
    import datetime
    debug_time('test')(datetime.datetime.now())
    #stdout.getvalue()
    #b'DEBUG: test took: 0:00:00.000003\n'

# Generated at 2022-06-12 10:41:40.456538
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    from contextlib import contextmanager

    @contextmanager
    def patch_stream():
        old = sys.stderr
        sys.stderr = StringIO()
        try:
            yield
        finally:
            sys.stderr = old

    with patch_stream():
        debug('msg')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n'

    with patch_stream():
        settings.debug = False
        debug('msg')
        assert sys.stderr.getvalue() == u''

# Generated at 2022-06-12 10:41:45.452486
# Unit test for function show_corrected_command
def test_show_corrected_command():
    const.USER_COMMAND_MARK = '$'
    settings.no_colors = False
    show_corrected_command(corrected_command='ls')
    assert sys.stderr.getvalue() == '$ls\n'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 10:41:52.146826
# Unit test for function debug_time
def test_debug_time():
    import thefuck.shells.base
    global debug, settings
    @contextmanager
    def debug_time(msg):
        yield
    global_settings = settings
    class Settings:
        debug = True

    settings = Settings()
    try:
        global_debug = debug
        debug = False
        def debug(msg):
            global debug
            return msg
        with debug_time('msg') as result:
            assert debug('msg took: 0:00:00.000001') == result
    finally:
        debug = global_debug
        settings = global_settings

# Generated at 2022-06-12 10:41:58.395256
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import os
    import sys
    import re
    
    stdout = sys.stdout
    stderr = sys.stderr
    sys.stdout = StringIO.StringIO()
    sys.stderr = StringIO.StringIO()
    
    show_corrected_command(u'fuck')
    result = sys.stderr.getvalue().split(os.linesep)[0]
    sys.stdout = stdout
    sys.stderr = stderr
    assert result == const.USER_COMMAND_MARK + u'fuck'
    
    # red test
    assert re.match(u'^\s+', result) == None
    

# Generated at 2022-06-12 10:41:59.362155
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(None)

