

# Generated at 2022-06-12 10:32:13.670596
# Unit test for function debug_time
def test_debug_time():
    time = datetime.now()
    with debug_time('message'):
        pass
    assert sys.stderr.getvalue() == u'message took: {}\n'.format(datetime.now() - time)

# Generated at 2022-06-12 10:32:16.152182
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('bold') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:32:19.166195
# Unit test for function debug_time
def test_debug_time():
    from mock import patch

    with patch('thefuck.utils.sys.stderr', create=True) as stderr:
        with debug_time(u'Test'):
            pass
        debug(u'Test')
        assert stderr.write.call_count == 2



# Generated at 2022-06-12 10:32:28.070141
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import time
    from datetime import datetime
    from colorama import init, Fore
    init()

    sys.stderr.write(datetime.now().strftime("%d-%m-%Y %I:%M:%S") + "\n")

    confirm_text("Hello, world!")
    time.sleep(2)

    confirm_text("Hello, world!")
    time.sleep(2)

    confirm_text("Hello, world!")
    time.sleep(2)

    sys.stderr.write(Fore.RED + "Hello, World!" + Fore.RESET + "\n")

# Generated at 2022-06-12 10:32:31.894245
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with open('test-command-output', 'w') as output:
        sys.stderr = output
        show_corrected_command(object())
    output.close()
    with open('test-command-output', 'r') as input:
        assert input.readline() == u'$ fuck\n'

# Generated at 2022-06-12 10:32:36.594111
# Unit test for function debug
def test_debug():
    # If this test fails, you should change all the print functions
    # to the sys.stderr.write
    sys.stderr = StringIO()
    debug('foo')
    expected = '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    assert sys.stderr.getvalue() == expected

# Generated at 2022-06-12 10:32:40.787318
# Unit test for function debug
def test_debug():
    from mock import patch
    from . import debug
    with patch('sys.stderr.write') as sys_stderr_write:
        debug(u"test debug")
        sys_stderr_write.assert_called_once_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug\n')



# Generated at 2022-06-12 10:32:43.283544
# Unit test for function color
def test_color():
    assert color('abc') == ''
    settings.no_colors = False
    assert color('abc') == 'abc'
    settings.no_colors = True

# Generated at 2022-06-12 10:32:46.507842
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.get_conf.return_value.no_colors = True
    assert color('test') == ''
    settings.get_conf.return_value.no_colors = False

# Generated at 2022-06-12 10:32:53.466412
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Bash, PromptCommand
    import sys
    import StringIO
    
    # Redirect output
    old_stdout = sys.stdout
    my_stdout = StringIO.StringIO()
    sys.stdout = my_stdout
    
    command = PromptCommand(['pwd', '-P'], 'ls', 'ls', Bash())
    # Test output
    show_corrected_command(command)
    my_stdout.seek(0)
    assert my_stdout.read() == "> " + "ls\n"
    
    command = PromptCommand(['pwd', '-P'], 'ls', 'ls +side effect', Bash())
    show_corrected_command(command)
    my_stdout.seek(0)

# Generated at 2022-06-12 10:32:59.230904
# Unit test for function color
def test_color():
    assert color(123) == ''
    assert color(colorama.Fore.BLUE + '123') == colorama.Fore.BLUE + '123'



# Generated at 2022-06-12 10:33:02.797975
# Unit test for function debug
def test_debug():
    settings.debug = False
    _debug = lambda msg: sys.stderr.write(u'{}\n'.format(msg))
    assert debug('message') == _debug('message')



# Generated at 2022-06-12 10:33:07.066149
# Unit test for function debug
def test_debug():
    from StringIO import StringIO

    output = StringIO()
    with debug_time('test'):
        pass
    debug('test')

    # Print statment need to be removed from source
    assert output.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-12 10:33:14.739146
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK = '$'
    show_corrected_command = 'fuck python'
    expected = u'$\033[1K\rfuck python [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'
    actual = confirm_text(show_corrected_command)
    assert actual == expected



# Generated at 2022-06-12 10:33:25.071924
# Unit test for function debug
def test_debug():
    import sys
    import io
    temp_stdout = sys.stderr
    temp_stderr = sys.stderr
    try:
        out = io.StringIO()
        sys.stdout = out
        sys.stderr = out
        debug('foo')
        out.seek(0)
        assert out.read().endswith('DEBUG: foo\n')
        debug(u'бар')
        out.seek(0)
        assert out.read().endswith(u'DEBUG: бар\n')
        out.close()
    finally:
        sys.stdout = temp_stdout
        sys.stderr = temp_stderr

# Generated at 2022-06-12 10:33:26.477127
# Unit test for function debug
def test_debug():
    debug('Hello World')



# Generated at 2022-06-12 10:33:29.772015
# Unit test for function color
def test_color():
    colorama.init(autoreset=True)
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED) != ''

# Generated at 2022-06-12 10:33:30.821159
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:33:36.350665
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(const.CorrectedCommand(u"ls", False)) == "u' ls [\ue0b0enter\ue0b0/\ue0b0\ue0b2\ue0b0/\ue0b0\ue0b3\ue0b0/\ue0b0ctrl+c\ue0b0]' "

# Generated at 2022-06-12 10:33:37.621336
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("echo 'a'")


# Generated at 2022-06-12 10:33:42.366602
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command)


# Generated at 2022-06-12 10:33:50.157962
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import as_bash
    from .rule import Rule
    from .command import Command
    from .shells import Shell

    script = u'git commit'
    new_script = u'git add --all && git commit'
    corrected_command = Command(new_script,
                                script,
                                u'Corrected git commit',
                                Rule(u'git',
                                     [u'git {0}'],
                                     u'git {0}',
                                     'Corrected git commit'),
                                None)
    confirm_text(corrected_command)

    assert as_bash('export PROMPT_COMMAND') == \
        u"PROMPT_COMMAND='echo -ne \"\\033]0;⚡ ${PWD/#$HOME/~}\\007\"'"

    assert as_bash

# Generated at 2022-06-12 10:33:52.027790
# Unit test for function debug_time
def test_debug_time():
    import time

    assert debug_time(r'foo') is not None
    time.sleep(1)



# Generated at 2022-06-12 10:33:55.246382
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile

    with tempfile.NamedTemporaryFile() as temp:
        fake_details = const.ConfigurationDetails('', temp.name, '', True)

        how_to_configure_alias(fake_details)



# Generated at 2022-06-12 10:33:57.105577
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .main import CorrectedCommand
    show_corrected_command(CorrectedCommand(u'script'))



# Generated at 2022-06-12 10:33:58.537015
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command="git push origin master")



# Generated at 2022-06-12 10:34:03.416082
# Unit test for function confirm_text
def test_confirm_text():
    import os
    import tempfile
    original_stderr = sys.stderr
    temp_file = tempfile.TemporaryFile()
    sys.stderr = temp_file
    confirm_text('foo')
    temp_file.seek(0)
    assert temp_file.read() == 'tf::foo [enter/↑/↓/ctrl+c]\n'
    temp_file.close()
    sys.stderr = original_stderr

# Generated at 2022-06-12 10:34:06.035559
# Unit test for function show_corrected_command
def test_show_corrected_command():
    cmd = 'git commit'
    corrected = 'git add . && git commit'
    show_corrected_command(corrected) == cmd

# Generated at 2022-06-12 10:34:14.234353
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_input_command = "fuck test_input"
    test_corrected_command = "fuck test"
    test_command = Command(test_input_command, "test_input", "test",
                           False)
    sys.stderr.write("\n")
    show_corrected_command(test_command)
    sys.stderr.write("\n")
    test_input = sys.stdin.readline()
    assert test_input == test_corrected_command
    sys.stderr.write("\n")
    sys.stderr.write("correct command tested.\n")



# Generated at 2022-06-12 10:34:14.716017
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-12 10:34:23.160668
# Unit test for function color
def test_color():
    assert color('') == ''
    colorama.init()
    assert color('blue') == '\033[34mblue\033[39m'



# Generated at 2022-06-12 10:34:28.242208
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):

        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand(u'cd /usr/bin', False))
    show_corrected_command(CorrectedCommand(u'cd /usr/bin', True))

# Generated at 2022-06-12 10:34:28.870856
# Unit test for function show_corrected_command
def test_show_corrected_command():
  pass

# Generated at 2022-06-12 10:34:30.584705
# Unit test for function color
def test_color():
    assert color('test') == 'test'



# Generated at 2022-06-12 10:34:35.722136
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys

    out = StringIO.StringIO()
    sys.stderr = out

    show_corrected_command(corrected_command="correct_command")
    output = out.getvalue().strip()
    assert output == 'fuck correct_command'

    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 10:34:45.211558
# Unit test for function debug_time
def test_debug_time():
    import time
    import os

    settings.debug = True
    initial_stderr = sys.stderr
    initial_time = time.time


# Generated at 2022-06-12 10:34:47.503489
# Unit test for function debug
def test_debug():
    debug(u'unicode string')
    debug(b'bytes string')
    debug(u'проверка')


# Generated at 2022-06-12 10:34:48.867109
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('ls --all')

# Generated at 2022-06-12 10:34:55.350680
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import time
    import mock

    with mock.patch('datetime.datetime') as mocked_datetime:
        mocked_datetime.now = mock.Mock(
            side_effect=lambda: datetime.fromtimestamp(100))
        with debug_time(u'fake message'):
            mocked_datetime.now = mock.Mock(
                side_effect=lambda: datetime.fromtimestamp(101))
            time.sleep(0.1)

    assert mocked_datetime.now.call_count == 4

# Generated at 2022-06-12 10:34:56.585090
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:35:12.296842
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from os import devnull
    from StringIO import StringIO
    from tempfile import TemporaryFile
    from thefuck.utils import strip_quotes

    @contextmanager
    def mocked_open(output):
        with TemporaryFile() as f:
            with contextmanager() as original_stderr:
                original_stderr.write = sys.stderr.write
                sys.stderr = f
                settings.debug = True
                yield
                settings.debug = False
                sys.stderr = original_stderr
                settings.no_colors = False
                f.seek(0)
                output.write(f.read())

    @contextmanager
    def string_io():
        output = StringIO()
        yield output
        output.seek(0)
        assert strip_qu

# Generated at 2022-06-12 10:35:15.528896
# Unit test for function confirm_text
def test_confirm_text():
    with open('test.txt', 'w+') as f:
        f.write(u'\033[1K\r')
    with open('test.txt', 'r') as f:
        assert confirm_text('test') == f.read()



# Generated at 2022-06-12 10:35:16.651187
# Unit test for function debug_time
def test_debug_time():
    with debug_time('message'):
        pass

# Generated at 2022-06-12 10:35:17.587057
# Unit test for function debug
def test_debug():
    debug(msg)


# Generated at 2022-06-12 10:35:23.710279
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    _out = StringIO.StringIO()
    sys.stderr = _out
    from .utils import show_corrected_command
    show_corrected_command('corrected_command', 'side_effect')
    sys.stderr.flush()
    assert _out.getvalue() == u'{}corrected_command (+side effect)\n'.format(const.USER_COMMAND_MARK)



# Generated at 2022-06-12 10:35:27.894734
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    stream = StringIO.StringIO()
    sys.stderr = stream
    confirm_text('vim')
    sys.stderr = sys.__stderr__
    assert stream.getvalue() == '>vim [enter/↑/↓/ctrl+c]', 'Confirm text is wrong'



# Generated at 2022-06-12 10:35:34.764280
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails(object):
        def __init__(self, can_configure_automatically=True):
            self.content = 'content'
            self.path = 'path'
            self.reload = 'reload'
            self.can_configure_automatically = can_configure_automatically

    how_to_configure_alias(ConfigurationDetails(False))
    how_to_configure_alias(None)
    how_to_configure_alias(ConfigurationDetails())



# Generated at 2022-06-12 10:35:36.020472
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLACK) == ''

# Generated at 2022-06-12 10:35:37.005509
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:39.169565
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -la'))
    assert(True)



# Generated at 2022-06-12 10:35:54.953486
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_with_prefix_and_suffix, CheckedScript
    from .shells import Shell
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    
    def get_prefix(shell):
        if isinstance(shell, Bash):
            return '$'
        if isinstance(shell, Zsh):
            return '%'
        return ''

    def test(shell, prefix, command, result):
        corrected_command = CheckedScript(command, shell.script_from_shell, prefix)
        show_corrected_command(corrected_command)
        assert sys.stderr.getvalue() == result
        sys.stderr = StringIO()

    shell = Shell()
    sys.stderr = StringIO()


# Generated at 2022-06-12 10:36:00.408900
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLACK + colorama.Back.YELLOW
                 + colorama.Style.BRIGHT) == (
        colorama.Fore.BLACK + colorama.Back.YELLOW
        + colorama.Style.BRIGHT)
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL
    assert color('') == ''

# Generated at 2022-06-12 10:36:06.402914
# Unit test for function debug_time
def test_debug_time():
    import time
    import unittest

    class TestDebugTime(unittest.TestCase):

        def setUp(self):
            self.called = False

        def show_message(self, msg):
            self.called = True

        def test_not_called_without_debug(self):
            with debug_time('test'):
                time.sleep(1)

            self.assertTrue(self.called)

    debug = debug_time
    debug_time = show_message

    try:
        unittest.main()
    finally:
        debug_time = debug

# Generated at 2022-06-12 10:36:07.437073
# Unit test for function debug
def test_debug():
    debug('XD')


# Generated at 2022-06-12 10:36:12.742590
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import get_all_executables
    for executable in get_all_executables():
        # NOTE: In case you need to test certain execuatble,
        # uncomment line below and comment all other ones
        # if not executable.script.startswith("/bin/zfs"):
        #     continue
        confirm_text(executable)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:36:13.959534
# Unit test for function debug_time
def test_debug_time():
    with debug_time("something"):
        pass



# Generated at 2022-06-12 10:36:19.015028
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple(
        'configuration_details', 'content path reload can_configure_automatically')
    how_to_configure_alias(configuration_details(content='content',
                                                 path='path',
                                                 reload='reload',
                                                 can_configure_automatically=True))


# Generated at 2022-06-12 10:36:28.122448
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    from .application import Application
    from .execute import ExecutionResult

    application = Application(magic=lambda: '{}', rules=[],
                              require_confirmation=False,
                              no_colors=True, debug=True)

    with debug_time('test'):
        application.maybe_applicable_rule = lambda *args, **kwargs: ExecutionResult(None, timedelta(seconds=1))
        application.run_rule = lambda *args, **kwargs: ExecutionResult(None, timedelta(seconds=1))
        application.run('ls', 'ls')
    expected_result = u'test took: 0:00:02'
    assert expected_result in sys.stderr.getvalue()

# Generated at 2022-06-12 10:36:36.214482
# Unit test for function confirm_text
def test_confirm_text():
    # Valid input:
    # 1. script = 'fuck', side_effect=True
    # 2. script = 'ls', side_effect=False
    # 3. script = '', side_effect=False
    # 4. script = '', side_effect=True
    for script in ('ls', 'fuck', ''):
        for side_effect in (True, False):
            corrected_command = 'fuck'

# Generated at 2022-06-12 10:36:37.863596
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    show_corrected_command(Command('ls'))
    show_corrected_command(Command('ps aux'))


# Generated at 2022-06-12 10:36:54.839323
# Unit test for function color
def test_color():
    """
    Test color() function
    """
    assert color(colorama.Back.RED) == colorama.Back.RED
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.RESET_ALL+'') == ''


if __name__ == '__main__':
    test_color()

# Generated at 2022-06-12 10:36:56.517794
# Unit test for function debug_time
def test_debug_time():
    seconds = 3
    with debug_time('test'):
        import time
        time.sleep(seconds)

# Generated at 2022-06-12 10:37:04.456385
# Unit test for function debug_time
def test_debug_time():
    import cStringIO
    import time
    import unittest
    from . import log

    class DebugTimeTest(unittest.TestCase):
        def setUp(self):
            self.stderr = sys.stderr
            self.log = cStringIO.StringIO()
            sys.stderr = self.log

        def tearDown(self):
            sys.stderr = self.stderr

        def test_debug_time(self):
            with log.debug_time('test'):
                time.sleep(0.1)
            self.assertIn('test took: ', self.log.getvalue())

    unittest.main(module=__name__)

# Generated at 2022-06-12 10:37:05.519074
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'

# Generated at 2022-06-12 10:37:08.353646
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red' + '/' + 'blue') == colorama.Fore.RED + colorama.Fore.BLUE

# Generated at 2022-06-12 10:37:14.090323
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.conf import settings
    from sys import __stdout__
    from StringIO import StringIO
    from . import const

    stdout = StringIO()
    conf = settings._replace(side_effect=False, alias='fuck')
    settings._replace(conf)

    confirm_text('git commit -m "Hello"', stdout)
    assert stdout.getvalue() == const.USER_COMMAND_MARK + 'git commit -m "Hello" [enter/↑/↓/ctrl+c]\n'



# Generated at 2022-06-12 10:37:19.807567
# Unit test for function debug_time
def test_debug_time():
    import time
    import StringIO

    stream = StringIO.StringIO()
    with settings.in_debug_mode(True):
        with debug_time('test') as _:
            time.sleep(1)
        debug('test2')
        sys.stderr = stream
        time.sleep(1)
    sys.stderr = sys.__stderr__
    assert stream.getvalue() == u'test2\n'



# Generated at 2022-06-12 10:37:30.458425
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import mock
    from . import debug

    class DebugTimeUnitTest(unittest.TestCase):
        @mock.patch('datetime.datetime')
        def test_debug_time(self, datetime_mock):
            datetime_mock.now.side_effect = [
                datetime(2015, 1, 1, 1, 1, 1),
                datetime(2015, 1, 1, 1, 1, 2)
            ]
            with mock.patch('fuckit.debug.debug') as debug_mock:
                with debug.debug_time('test'):
                    pass
            self.assertEqual(debug_mock.call_args,
                             mock.call('test took: 0:00:01.000001'))
    unittest.main()


# Generated at 2022-06-12 10:37:32.270853
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stdout.write(u'\n')
    how_to_configure_alias(None)
    how_to_configure_alias("")

# Generated at 2022-06-12 10:37:32.967064
# Unit test for function debug_time
def test_debug_time():
    with debug_time('testing'):
        pass

# Generated at 2022-06-12 10:37:52.574714
# Unit test for function debug
def test_debug():  # pragma: no cover
    import sys
    import io
    from thefuck.utils import debug

    with (io.BytesIO() if sys.version_info[0] > 2 else io.StringIO()) as stderr:
        sys.stderr = stderr
        debug('foo')
        assert stderr.getvalue() == ''
        settings.debug = True
        debug('foo')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
        settings.debug = False
        debug('foo')
        assert stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-12 10:37:56.647499
# Unit test for function show_corrected_command
def test_show_corrected_command():
    shell = Shell('python')
    rule = Rule('python', 'python', lambda x: x.script.replace('fuck', 'true', 1), None)
    script = 'fuck'
    assert(show_corrected_command(rule.get_corrected_command_script(shell, script)) == None)


# Generated at 2022-06-12 10:38:05.652535
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    import thefuck.conf
    import thefuck.shells.zsh as zsh
    import thefuck.shells.bash as bash
    import thefuck.utils as utils
    from thefuck.rules.git import match, get_new_command
    from thefuck.types import CorrectedCommand
    thefuck.conf.settings.no_colors = True
    shell_obj = zsh.get_shell()
    show_corrected_command(CorrectedCommand('ls', 'ls', False))
    assert output.getvalue() == '>ls \n'
    output.truncate(0)
    show_corrected_command(CorrectedCommand('ls', 'ls -l', True))

# Generated at 2022-06-12 10:38:07.056539
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('sleep'):
        time.sleep(1)

# Generated at 2022-06-12 10:38:08.088618
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'Debug'):
        pass



# Generated at 2022-06-12 10:38:13.547190
# Unit test for function debug
def test_debug():
    from tempfile import NamedTemporaryFile
    with NamedTemporaryFile() as error_file:
        debug('Error message', error_file=error_file.name)
        error_file.seek(0)
        assert error_file.read().decode('utf-8') == 'Error message'



# Generated at 2022-06-12 10:38:14.310516
# Unit test for function debug
def test_debug():
    assert debug('Test') == None


# Generated at 2022-06-12 10:38:22.634157
# Unit test for function debug_time
def test_debug_time():
    from .utils import debug_time
    from .conf import settings
    from . import conf
    from contextlib import contextmanager
    from datetime import datetime

    @contextmanager
    def debug_time(msg):
        try:
            yield
        finally:
            # sys.stderr.write(u'{msg} took: {duration}\n'.format(
            print(u'{msg} took: {duration}\n'.format(
                msg=msg,
                duration=datetime.now() - started))
    with debug_time('foo'):
        with debug_time('bar'):
            with debug_time('bar1'):
                with debug_time('bar2'):
                    pass

# Generated at 2022-06-12 10:38:24.876837
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Foo(object):
        script = 'git fuck'
        side_effect = True

    show_corrected_command(Foo())



# Generated at 2022-06-12 10:38:32.592500
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert (
        how_to_configure_alias(
            configuration_details=None) ==
        "Seems like \x1b[1mfuck\x1b[21m alias isn't configured!\n"
        "More details - https://github.com/nvbn/thefuck#manual-installation")

# Generated at 2022-06-12 10:38:48.451353
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_with_prefix
    from .rule import Command
    corrected_command = Command(
        'ls /home', u'ls /home/\U0001F4A9', '', '', False)
    assert show_corrected_command(corrected_command) == wrap_with_prefix(
            'ls /home/\U0001F4A9')

# Generated at 2022-06-12 10:38:54.742013
# Unit test for function confirm_text
def test_confirm_text():
    # This function uses sys.stdout and change the output, so it's impossible to
    # test it functionally.
    # This function should return correct string with correct `corrected_command`
    # And should not raise exception with incorrect command
    from ..correct import CorrectedCommand
    confirm_text(CorrectedCommand('echo test'))



# Generated at 2022-06-12 10:38:55.842960
# Unit test for function debug
def test_debug():
    debug(u'Unit test for function debug')

# Generated at 2022-06-12 10:38:57.238225
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug(u'Test debug')

# Generated at 2022-06-12 10:39:02.333499
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = open('test.txt', 'w')
    confirm_text([1, 2])
    sys.stderr.close()
    with open('test.txt') as f:
        a = f.readline()
    assert a == '>' + str([1, 2]) + ' [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:39:08.767010
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .utils import get_closest
    from .rule import Rule
    from .types import Commands, CorrectedCommand

    def _test_output(script, output, side_effect=False):
        shell = Shell("", "", "")
        command = get_closest("ls", [
            Rule("ls", "ls",
                 "ls", lambda _: "ls -G")], shell)

        def new_corrected_command(command, script, side_effect=False):
            return CorrectedCommand(script, side_effect)

        with shell.patch(new_corrected_command=new_corrected_command):
            show_corrected_command(command.get_new_command(Commands([script])))
        assert sys.stderr.getvalue() == output

    _test_

# Generated at 2022-06-12 10:39:10.335191
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text("some_script")

# Generated at 2022-06-12 10:39:17.863237
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    import sys
    import io
    show_corrected_command(CorrectedCommand(script='mv file.abc file.cba',
                                            side_effect=False))
    captured_output = io.StringIO()  # Create StringIO object
    sys.stderr = captured_output     # and redirect stdout.
    show_corrected_command(CorrectedCommand(script='mv file.xyz file.cba',
                                            side_effect=True))
    captured_output.getvalue()
    assert captured_output.getvalue() == \
        "Corrected command: mv file.abc file.cba\n" \
        "Corrected command: mv file.xyz file.cba (+side effect)\n"

# Generated at 2022-06-12 10:39:20.173423
# Unit test for function confirm_text
def test_confirm_text():
    # import pdb;pdb.set_trace()
    correct_command = 'ls'
    confirm_text(correct_command)

# Generated at 2022-06-12 10:39:22.552813
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = "ls"
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:39:38.784093
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager, redirect_stderr
    from io import StringIO

    @contextmanager
    def capture():
        """Redirect standard output to `sys.stderr` and capture it."""
        with redirect_stderr(StringIO()) as stderr:
            yield stderr

    with capture() as stderr:
        debug("test")
    assert u'DEBUG: test' in stderr.getvalue()



# Generated at 2022-06-12 10:39:39.464110
# Unit test for function debug
def test_debug():
    with debug_time('Debugging...'):
        debug('Debug message')

# Generated at 2022-06-12 10:39:43.211675
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('', (), {
        'script': 'echo "fuck"',
        'side_effect': True
    })
    assert confirm_text(corrected_command) == const.USER_COMMAND_MARK + 'echo "fuck" (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:39:45.584414
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-12 10:39:48.559210
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = (u'git push --force', True)

    def fake_input():
        return corrected_command

    confirm_text(fake_input)

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:39:54.628038
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert (
        colorama.Style.BRIGHT + '$'
        + colorama.Style.RESET_ALL
        + colorama.Style.BRIGHT
        + 'echo "Fuck" | grep fuck' + colorama.Style.RESET_ALL
        + ' (+side effect)' == show_corrected_command(
            mock_CorrectedCommand(
                '$echo "Fuck" | grep fuck', True)))



# Generated at 2022-06-12 10:40:02.304543
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    import sys
    from .utils import get_old_corrected_command
    from .const import USER_COMMAND_MARK
    from .conf import Settings

    saved_stdout = sys.stdout
    s = StringIO.StringIO()
    sys.stdout = s
    settings = Settings()
    settings.no_colors = False
    corrected_command = get_old_corrected_command(
        USER_COMMAND_MARK + 'echo "foo"\n', [], lambda x: x, settings)
    show_corrected_command(corrected_command)
    assert s.getvalue() == \
        USER_COMMAND_MARK + 'echo "foo"\n'
    sys.stdout = saved_stdout

# Generated at 2022-06-12 10:40:07.536514
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand:
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('ls -l', True))
    show_corrected_command(CorrectedCommand('ls -l', False))
    show_corrected_command(CorrectedCommand('ls -l'))

# Generated at 2022-06-12 10:40:09.786025
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'Red') == colorama.Fore.RED + 'Red'
    assert color('No color') == 'No color'



# Generated at 2022-06-12 10:40:10.997308
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass



# Generated at 2022-06-12 10:40:24.609713
# Unit test for function debug
def test_debug():
    import mock
    import io
    buffer = io.StringIO()
    with mock.patch('sys.stderr', buffer):
        debug('Debug msg')
    assert u'DEBUG: Debug msg' in buffer.getvalue()

# Generated at 2022-06-12 10:40:30.960574
# Unit test for function debug
def test_debug():
    import StringIO

    cached_stderr = sys.stderr
    sys.stderr = StringIO.StringIO()

    try:
        debug("Hello, World")
        output = sys.stderr.getvalue()
        assert output in ["\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello, World\n",
                          "\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello, World\r\n"]

    finally:
        sys.stderr.close()
        sys.stderr = cached_stderr

# Generated at 2022-06-12 10:40:32.108740
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test debug_time'):
        pass

# Generated at 2022-06-12 10:40:34.370012
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls -l')
    show_corrected_command('ls -l')
    show_corrected_command('ls -l')


# Generated at 2022-06-12 10:40:35.734790
# Unit test for function color
def test_color():
    assert color('text') == 'text'
    settings.no_colors = True
    assert color('text') == ''

# Generated at 2022-06-12 10:40:40.951235
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    confirm_text('command')
    sys.stderr = sys.__stderr__
    assert output.getvalue().split(' ')[0] == '┌────\r└───┤'
    assert output.getvalue().split(' ')[-2] == '↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:40:50.261707
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import colorama
    from thefuck.conf import settings
    settings.no_colors = False
    stdout = io.BytesIO()
    sys.stdout = stdout
    confirm_text(u'ls')
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 10:40:52.497388
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .shells import Shell
    show_corrected_command(CorrectedCommand(Shell(), 'ls', 'ls -al'))
    assert True

# Generated at 2022-06-12 10:40:53.963715
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:41:04.555295
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # When there is no configuration details
    how_to_configure_alias(None)
    # Then how to configure alias message should be shown
    # And there is no instruction how to apply changes
    # And there is no instruction how to auto configure alias

    # When there is configuration details
    class ConfigurationDetails(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def _asdict(self):
            return self.__dict__

    how_to_configure_alias(ConfigurationDetails(
        path='~/.aliases',
        content='alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        reload='source ~/.aliases',
        can_configure_automatically=True))
    # Then how to configure alias message should be shown
    # And

# Generated at 2022-06-12 10:41:17.942674
# Unit test for function debug_time
def test_debug_time():
    def run():
        with debug_time('Test'):
            pass
    debug('asdf')
    run()
    assert False

# Generated at 2022-06-12 10:41:20.104287
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr') as stderr:
        debug('unit test')



# Generated at 2022-06-12 10:41:22.240062
# Unit test for function confirm_text
def test_confirm_text():
    # First we have to initialize colorama to be able to run this test on
    # Windows
    colorama.init()
    confirm_text(MagicMock())



# Generated at 2022-06-12 10:41:30.680480
# Unit test for function debug
def test_debug():
    DEBUG_ENABLED = True
    DEBUG_DISABLED = False

    # With debug
    with debug_time('With debug'):
        sys.modules['thefuck'].settings.debug = DEBUG_ENABLED
        debug('Hello world')
    assert sys.stderr.getvalue() == "\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello world\n"
    sys.stderr = sys.__stderr__

    # Without debug
    with debug_time('Without debug'):
        sys.modules['thefuck'].settings.debug = DEBUG_DISABLED
        debug('Hello world')
    assert sys.stderr.getvalue() == ""
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:41:32.216995
# Unit test for function color
def test_color():
    """Test function color()."""
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-12 10:41:33.078198
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:41:39.446667
# Unit test for function debug
def test_debug():
    class Stream:
        def __init__(self):
            self.content = ''

        def write(self, value):
            self.content += value

        def flush(self):
            pass
    stream = Stream()
    sys.stderr = stream
    settings.debug = True
    debug('test')
    test_content = stream.content
    sys.stderr = sys.__stderr__
    settings.debug = False
    return test_content == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'


# Generated at 2022-06-12 10:41:42.485723
# Unit test for function debug
def test_debug():
    """
    test_debug() check that debug function adds prefix DEBUG: to the message
    """
    msg = 'This is a test message'
    debug(msg)



# Generated at 2022-06-12 10:41:49.810278
# Unit test for function confirm_text
def test_confirm_text():
    # confirm_text(corrected_command)
    sys.stderr.write(u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
                     u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                     u'/{red}ctrl+c{reset}]'.format(
                         prefix="",
                         clear='\033[1K\r',
                         bold="",
                         reset="",
                         script="",
                         side_effect=u' (+side effect)',
                         green="",
                         red="",
                         blue=""))

# Generated at 2022-06-12 10:41:50.758873
# Unit test for function debug
def test_debug():  # noqa
    debug('test')

# Generated at 2022-06-12 10:42:07.222084
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug('debug')
        assert [x for x in sys.stderr.getvalue().split('\n')] == [
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m debug']
    finally:
        settings.debug = False
        sys.stderr.close()
        sys.stderr = sys.__stderr__

