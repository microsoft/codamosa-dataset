

# Generated at 2022-06-12 10:32:13.429993
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details=None)

    dd = {
        'path': '~/.zshrc',
        'content': 'eval $(thefuck --alias)',
        'reload': 'source ~/.zshrc',
        'can_configure_automatically': True
    }

    how_to_configure_alias(dd)

# Generated at 2022-06-12 10:32:18.486016
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import wrap_colorama_stream
    from .types import CorrectedCommand

    with wrap_colorama_stream('stderr'):
        show_corrected_command(
            CorrectedCommand('git push', side_effect=False))
        show_corrected_command(
            CorrectedCommand('git push --force', side_effect=True))
        show_corrected_command(
            CorrectedCommand('git push\ncd /tmp', side_effect=True))

# Generated at 2022-06-12 10:32:28.981418
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import Command
    from .rules.shells import Bash
    from .shells import UnknownShell

    mock_corrected_command = Command('git log', 'git log --oneline', True)
    mock_corrected_command2 = Command('git status', 'git branch', False)

    sys_stderr = sys.stderr
    buffer = []
    try:
        sys.stderr = buffer.append
        show_corrected_command(mock_corrected_command)
        show_corrected_command(mock_corrected_command2)
        assert buffer == ['\033[1K\r\x1b[31m$ git log --oneline (+side effect)\n', '\033[1K\r\x1b[31m$ git branch\n']
    finally:
        sys.st

# Generated at 2022-06-12 10:32:31.150489
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('r') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:32:40.257610
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import subprocess
    from contextlib import contextmanager
    from tempfile import NamedTemporaryFile

    @contextmanager
    def redirected_sys_output():
        new_out, new_err = NamedTemporaryFile(), NamedTemporaryFile()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class FakeCommand(object):
        def __init__(self, script):
            self.script = script
            self.side_effect = False

    with redirected_sys_output() as (sys_out, sys_err):
        confirm_

# Generated at 2022-06-12 10:32:42.354417
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    if settings.how_to_configure_alias(None):
        return True
    else:
        return False



# Generated at 2022-06-12 10:32:46.165199
# Unit test for function debug_time
def test_debug_time():
    from .tests.utils import dummy_subprocess

    with debug_time('test'):
        dummy_subprocess.call([sys.executable, '-c', 'import time; time.sleep(1)'],
                              stdout=dummy_subprocess.DEVNULL,
                              stderr=dummy_subprocess.DEVNULL)


# Function unit test

# Generated at 2022-06-12 10:32:48.383480
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()
if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:32:50.443665
# Unit test for function debug_time
def test_debug_time():
    time = datetime.now()

    with debug_time('test_debug_time'):
        assert time < datetime.now()

# Generated at 2022-06-12 10:32:56.900716
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import settings
    settings.debug = True

    from . import output
    from contextlib import contextmanager

    @contextmanager
    def debug_time(msg):
        output.debug(msg)
        yield
        output.debug(msg)

    output.debug_time = debug_time

    @output.debug_time
    def test():
        import time
        time.sleep(1)

    test()
    assert u'test took: ' in output.debug.call_args[0][0]

# Generated at 2022-06-12 10:33:04.897566
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from .const import USER_COMMAND_MARK
    show_corrected_command(CorrectedCommand(
        u'git push origin HEAD',
        side_effect=True)) == (
            USER_COMMAND_MARK + u'git push origin HEAD (+side effect)\n')

# Generated at 2022-06-12 10:33:08.928543
# Unit test for function debug_time
def test_debug_time():
    # This test requires coverage
    import coverage

    tracer = coverage.Coverage()

    tracer.start()
    import this
    tracer.stop()
    tracer.save()

    cov = tracer.analysis(this)
    assert cov == 100
    assert this.d.get('beautiful') == 'ugly'
    assert this.c == 'ugly'

# Generated at 2022-06-12 10:33:20.666145
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from mock import Mock
    from . import conf

    old_term = conf.settings.configured_shell

    conf.settings.configured_shell = Mock(
        name='shell-name',
        can_configure_automatically=True,
        reload_command='reload-command',
        execute_command='exec-command',
        get_aliases='get-aliases-command',
        how_to_configure_aliases_in_config='how-to-manual-config',
        get_command_from_alias='get-command-from-alias',
        create_alias='create-alias',
        configure_automatically='configure-automatically-command',
        run_command='run-command')
    conf.settings.no_colors = False
    conf.settings.alias = None

    how_

# Generated at 2022-06-12 10:33:23.260873
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color(colorama.Fore.RED) != colorama.Fore.GREEN



# Generated at 2022-06-12 10:33:27.310036
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    ConfigurationDetails = namedtuple('ConfigurationDetails',
                                      ['path', 'content',
                                       'reload', 'can_configure_automatically'])

    configuration_details = ConfigurationDetails('.bashrc', 'alias', 'source .bashrc', True)
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:33:28.259211
# Unit test for function confirm_text
def test_confirm_text():
    sys.stdin.write('\ns')

# Generated at 2022-06-12 10:33:32.121271
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class FakeCorrectedCommand:
        script = 'git push'
        side_effect = False
    assert (str(show_corrected_command(FakeCorrectedCommand()))
            == 'Corrected command: git push\n')



# Generated at 2022-06-12 10:33:32.459673
# Unit test for function show_corrected_command
def test_show_corrected_command():
    return True

# Generated at 2022-06-12 10:33:33.297519
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        import time
        time.sleep(0.1)



# Generated at 2022-06-12 10:33:34.802982
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-12 10:33:39.084987
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command='') == None

# Generated at 2022-06-12 10:33:40.857422
# Unit test for function confirm_text
def test_confirm_text():
    assert(confirm_text(const.ShellCommand('ls', 'ls -a')) == None)



# Generated at 2022-06-12 10:33:47.192851
# Unit test for function debug_time
def test_debug_time():
    import time
    import StringIO

    def sleep(seconds):
        time.sleep(seconds)

    def print_to_stderr(*args, **kwargs):
        print(*args, file=sys.stderr, **kwargs)

    out = StringIO.StringIO()
    sys.stderr = out

    with debug_time('msg'):
        sleep(0.1)

    assert '[DEBUG] msg took: 0:00:00.100000\n' in out.getvalue()

# Generated at 2022-06-12 10:33:48.405359
# Unit test for function debug
def test_debug():
    assert debug('msg') == None



# Generated at 2022-06-12 10:33:57.603755
# Unit test for function debug
def test_debug():
    from textwrap import dedent
    from StringIO import StringIO

    # override sys.stderr
    _stderr = sys.stderr
    sys.stderr = StringIO()

    # enable debug mode
    settings.debug = True

    debug(u'Hello World!')

    debug_output = sys.stderr.getvalue()
    sys.stderr.close()
    assert dedent(u"""\
        {blue}{bold}DEBUG:{reset} Hello World!
        """.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT))) == debug_output

    # disable debug mode
    settings.debug = False

    debug(u'Hello World!')

    debug_

# Generated at 2022-06-12 10:33:59.072698
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test') as debug_time_:
        pass

# Generated at 2022-06-12 10:34:01.003842
# Unit test for function color
def test_color():
    assert color('colored')
    settings.no_colors = True
    assert not color('colored')
    settings.no_colors = False

# Generated at 2022-06-12 10:34:03.232169
# Unit test for function confirm_text
def test_confirm_text():
    # According to the configuration in settings.py
    # we have to get this output:
    #   rea config[enter/↑/↓/ctrl+c]
    confirm_text('rea config')

# Generated at 2022-06-12 10:34:04.448377
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    assert True



# Generated at 2022-06-12 10:34:05.723683
# Unit test for function debug
def test_debug():
    debug('foo')

# Generated at 2022-06-12 10:34:13.724553
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime,timedelta

    with debug_time('test'):
        time.sleep(1)

    start = datetime.now()
    with debug_time('test'):
        time.sleep(5)
    end = datetime.now()

    delta = end - start
    assert delta > timedelta(seconds=1)

# Generated at 2022-06-12 10:34:19.801652
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr', autospec=True) as stderr:
        debug(u'hello')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hello\n')

        settings.debug = False
        debug(u'hello')
        assert stderr.write.call_count == 1

        settings.debug = True
        settings.no_colors = True
        debug(u'hello')
        stderr.write.assert_called_with(u'DEBUG: hello\n')

# Generated at 2022-06-12 10:34:23.445208
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # the function is just sys.stderr write, so no real test possible.
    # just check if code coverage is > 0
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', False))

# Generated at 2022-06-12 10:34:33.822553
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from .utils import sys
    from .conf import *

    # Base case
    settings.no_colors = False
    test_object = CorrectedCommand(script='test command',
                                   side_effect=False)
    # save sys.stderr to restore after test
    std_error = sys.stderr
    try:
        sys.stderr = StringIO()
        show_corrected_command(test_object)
        output = sys.stderr.getvalue().strip()
        assert output == (u'{prefix}test command'
                          .format(prefix=const.USER_COMMAND_MARK))

    # Side Effect case
    finally:
        sys.stderr = std_error

# Generated at 2022-06-12 10:34:34.962147
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('test')

# Generated at 2022-06-12 10:34:36.240926
# Unit test for function debug_time
def test_debug_time():
    with debug_time('hello'):
        pass

# Generated at 2022-06-12 10:34:38.575505
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('ls -l') == 'ls -l'
    assert show_corrected_command('cat app.py') == 'cat app.py'

# Generated at 2022-06-12 10:34:43.585367
# Unit test for function debug
def test_debug():
    import StringIO
    _stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    debug('test')

    assert sys.stderr.getvalue() == '\x1b[36m\x1b[1mDEBUG:\x1b[0m test\n'
    sys.stderr = _stderr


# Generated at 2022-06-12 10:34:46.990109
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf.configuration_details import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        can_configure_automatically=False,
        path='~/.bashrc',
        content='eval $(thefuck --alias)')
    )



# Generated at 2022-06-12 10:34:54.785257
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime, timedelta
    import sys
    from mock import patch

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            sys.stderr.write(u'{} took: {}\n'.format(msg, datetime.now() - started))

    with patch('thefuck.shells.base.debug_time', debug_time):
        with patch('sys.stderr') as stderr:
            with debug_time('test_debug_time'):
                time.sleep(1)
            assert 'test_debug_time took' in stderr.write.call_args[0][0]

# Generated at 2022-06-12 10:35:04.784235
# Unit test for function color
def test_color():
    assert color(u'') == u''
    assert color(u'a') == u'a'
    assert color(u'a\nb') == u'a\nb'
    assert color(u'\x1b[1m') == colorama.Style.BRIGHT

# Generated at 2022-06-12 10:35:06.076053
# Unit test for function color
def test_color():
    assert color('red') == 'red'



# Generated at 2022-06-12 10:35:09.781216
# Unit test for function debug_time
def test_debug_time():
    import time
    from itertools import count
    from .utils import cache

    cache.reset_cache()
    for sleep in count(2):
        with debug_time('Cache lookup'):
            time.sleep(sleep)
            cache.get_cache_file()

# Generated at 2022-06-12 10:35:10.380356
# Unit test for function debug_time
def test_debug_time():
    pass



# Generated at 2022-06-12 10:35:12.812869
# Unit test for function color
def test_color():
    assert color(u'\x1b[31mred\x1b[0m') == u'\x1b[31mred\x1b[0m'



# Generated at 2022-06-12 10:35:14.080067
# Unit test for function debug_time
def test_debug_time():
    "test for debug_time"
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:20.154402
# Unit test for function confirm_text
def test_confirm_text():
    def assert_confirm_text(command, expect):
        assert confirm_text(command) == expect


# Generated at 2022-06-12 10:35:25.181466
# Unit test for function debug
def test_debug():
    old_stdout = sys.stderr
    sys.stderr = output = StringIO.StringIO()
    settings.debug = True
    try:
        debug('debug debug debug')
        assert 'DEBUG: debug debug debug' in output.getvalue()
    finally:
        sys.stderr = old_stdout
        settings.debug = False

# Generated at 2022-06-12 10:35:30.175820
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import nested
    from . import utils

# Generated at 2022-06-12 10:35:34.762798
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = SimpleNamespace(
        script='git commit -v',
        side_effect=True)
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == "Corrected command: git commit -v (+side effect)\n"



# Generated at 2022-06-12 10:35:42.424955
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time(u'current time'):
        time.sleep(0.002)

# Generated at 2022-06-12 10:35:44.990529
# Unit test for function debug
def test_debug():
    try:
        with settings.using({'debug': True}):
            debug('x')
            assert (True)
    except AssertionError:
        assert (False)

# Generated at 2022-06-12 10:35:52.416298
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell

    assert how_to_configure_alias(None) is None
    assert how_to_configure_alias(Shell(
        name='shell',
        reload_command='~/.reload',
        history_file_option='-H',
        history_file='~/.fake_history',
        where_am_i='$(pwd)',
        how_to_configure='cat >> ~/.config << EOF\n'
                         'alias fuck=\'eval $(thefuck $(fc -ln -1))\'\n'
                         'EOF\n',
        can_configure_automatically=True,
        config_file=None)) is None

# Generated at 2022-06-12 10:35:53.564265
# Unit test for function debug_time
def test_debug_time():
    debug_time("Debug command")


# Generated at 2022-06-12 10:35:59.522674
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(corrected_command='') == ''
    assert confirm_text(corrected_command='fuck') == 'fuck '
    assert confirm_text(corrected_command='echo') == 'echo '
    assert confirm_text(corrected_command='git') == 'git '
    assert confirm_text(corrected_command='fuck django') == 'fuck django '
    assert confirm_text(corrected_command='fuck') == 'fuck '

# Generated at 2022-06-12 10:36:06.333349
# Unit test for function debug
def test_debug():
    from .conf import settings
    from .utils import prepare_debug_log
    from contextlib import contextmanager
    import sys
    import os
    import tempfile
    from .const import DEBUG_LOG_FILENAME
    prepare_debug_log()
    settings.debug = True
    with closed_temp_file() as (path, mode):
        settings.debug_log = path
        debug('this is debug')
        assert os.path.exists(path)
        assert os.path.isfile(path)
        with open(path, mode) as f:
            assert '[DEBUG] this is debug' in f.read()



# Generated at 2022-06-12 10:36:12.258895
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import shell
    class FakeShell(object):
        @property
        def name(self):
            return 'Shell'

    class FakeCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    shell.get_shell = lambda: FakeShell()
    confirm_text(FakeCommand('ls -la'))
    confirm_text(FakeCommand('ls -la', side_effect=True))

# Generated at 2022-06-12 10:36:16.171149
# Unit test for function debug
def test_debug():
    output = []
    def mock_debug(msg):
        output.append(msg)

    original_debug = debug
    debug = mock_debug
    try:
        testee('message')
        assert u'message' == ''.join(output)
    finally:
        debug = original_debug

# Generated at 2022-06-12 10:36:21.667241
# Unit test for function color
def test_color():
    assert u'\x1b[41m\x1b[37m\x1b[1m[WARN] \x1b[0m' == color(colorama.Back.RED + colorama.Fore.WHITE
                                                               + colorama.Style.BRIGHT)

    assert u'\x1b[0m' == color(colorama.Style.RESET_ALL)



# Generated at 2022-06-12 10:36:28.981693
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    stderr = mock.mock_open()
    with mock.patch('sys.stderr', stderr):
        from thefuck.main import Command
        show_corrected_command(Command('ls', ''))
        stderr.write.assert_called_once_with(u'\x1bc[1K\r'
            u'\x1b[1m{prefix}\x1b[0mls\x1b[0m (+side effect)\n'.format(
            prefix=const.USER_COMMAND_MARK))

# Generated at 2022-06-12 10:36:37.343293
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "cd /etc/bin/"
    show_corrected_command(corrected_command)
    assert sys.stderr.getvalue() == 'cd /etc/bin/\n'

# Generated at 2022-06-12 10:36:39.071509
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    debug_time('Sleeping for one second')(lambda: sleep(1))()

# Generated at 2022-06-12 10:36:39.806053
# Unit test for function debug
def test_debug():
    debug('123')



# Generated at 2022-06-12 10:36:42.082309
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    for command in ('ls', '  ls  ', 'ls\t'):
        confirm_text(command)



# Generated at 2022-06-12 10:36:43.658925
# Unit test for function debug_time
def test_debug_time():
    time = "0:00:00.000001"
    assert debug_time("test") is time

# Generated at 2022-06-12 10:36:50.502276
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from io import StringIO
    output = StringIO()
    print = output.write
    configuration_details = namedtuple('configuration_details',
                                       'can_configure_automatically')
    configuration_details.path = '~/.zshrc'
    configuration_details.reload = 'source ~/.zshrc'
    configuration_details.content = 'eval $(thefuck --alias)'
    configuration_details.can_configure_automatically = False
    how_to_configure_alias(configuration_details)
    output.seek(0)

# Generated at 2022-06-12 10:36:53.983133
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell

    corrected_command = Shell.from_shell('').from_shell(
        'git commit foo -m "message"').get_history()[0]

    output = u"""\
> git commit foo -m "message"
"""
    assert show_corrected_command(corrected_command) == output



# Generated at 2022-06-12 10:36:55.794130
# Unit test for function debug_time
def test_debug_time():
    'test 1'
    with debug_time('test 1'):
        pass



# Generated at 2022-06-12 10:36:57.443563
# Unit test for function debug
def test_debug():
    with debug_time('test_debug'):
        #assert statements
        assert True


# Generated at 2022-06-12 10:37:00.273060
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('this is a line')
    assert sys.stderr.read() == 'this is a line'


# Generated at 2022-06-12 10:37:13.350396
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from datetime import date, time, datetime
    import sys

    def _helper_debug(func, *args):
        # Code adapted from http://stackoverflow.com/a/5139628/73573
        out = StringIO()
        sys.stderr = out
        func(*args)
        sys.stderr = sys.__stderr__
        return out.getvalue()

    assert not _helper_debug(debug, 'Example')
    settings.debug = True
    assert _helper_debug(debug, 'Example') == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Example\n'



# Generated at 2022-06-12 10:37:15.334233
# Unit test for function debug_time
def test_debug_time():
    def print_str():
        with debug_time("printing"):
            print("string")

    print_str()

# Generated at 2022-06-12 10:37:16.622080
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test message'):
        pass



# Generated at 2022-06-12 10:37:19.669269
# Unit test for function debug
def test_debug():
    debug('Test!')
    assert sys.stderr.getvalue().strip() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test!'


# Generated at 2022-06-12 10:37:22.101769
# Unit test for function debug_time
def test_debug_time():
    @debug_time('test')
    def func():
        import time
        time.sleep(0.1)
test_debug_time.test = True

# Generated at 2022-06-12 10:37:28.812280
# Unit test for function debug
def test_debug():
    msg = 'test_debug'
    debug_output = 'DEBUG: test_debug\n'
    test_output = sys.stderr.write
    sys.stderr.write = lambda str: None

    try:
        debug(msg)
        assert test_output.call_args[0][0] == debug_output

    finally:
        sys.stderr.write = test_output


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:37:29.740376
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:37:31.920075
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = "fuck --help"
    confirm_text(corrected_command)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:37:38.654417
# Unit test for function confirm_text
def test_confirm_text():
    from . import rule, command

    corrected_command = command.Command('ls', 'l', '', True)
    assert confirm_text(corrected_command) == \
        u'{prefix}{clear}{bold}ls{reset} (+side effect) [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]' \
        .format(
            prefix=const.USER_COMMAND_MARK,
            clear='\033[1K\r',
            bold=color(colorama.Style.BRIGHT),
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-12 10:37:45.964895
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Add a temporary variable 'sys' to builtin, in order to mock the function
    builtins = __import__('__builtin__')
    builtins.sys = sys

    import os
    import mock
    with mock.patch('sys.stderr', mock.Mock()) as stderr_mock:
        from thefuck import ui
        ui.show_corrected_command('test_command')
        stderr_mock.write.assert_called_with('>test_command')

    # Remove the mock for sys
    del builtins.sys
    reload(sys)

# Generated at 2022-06-12 10:37:52.491999
# Unit test for function confirm_text
def test_confirm_text():
    pass

# Generated at 2022-06-12 10:37:53.563102
# Unit test for function confirm_text
def test_confirm_text():
    result = confirm_text('test_confirm_text')
    assert result == None

# Generated at 2022-06-12 10:37:55.515447
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('thefuck.utils.settings', debug=True) as settings:
        debug('foo bar')
        settings.debug.assert_called_once_with()

# Generated at 2022-06-12 10:38:00.624156
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class FakeShellInfo(object):
        def reload_settings(self):
            return 'fake_reload'

    fake_configuration_details = FakeConfigurations(
        False,
        'fake_path',
        'fake_content',
        FakeShellInfo())

    how_to_configure_alias(fake_configuration_details)

# Generated at 2022-06-12 10:38:01.604267
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:38:06.765383
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    sys.stdout = output = StringIO.StringIO()
    how_to_configure_alias(None)
    result = output.getvalue()

# Generated at 2022-06-12 10:38:16.350794
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .shells.posix import PosixShell, Zsh, Bash
    from .utils import get_closest

    # def get_configuration_details(shell):
    #     return ConfigurationDetails(
    #         name=shell.name,
    #         can_configure_automatically=shell.can_configure_automatically,
    #         path=shell.get_alias(),
    #         content=shell.get_alias_string('python -m thefuck'),
    #         reload=shell.reload(),
    #         python_alias=shell.python_alias(),
    #         history_length=shell.history_length())
    #
    #
    # def get_shell(shell_name):
    #     for shell_cls in (Zsh, Bash):
    #

# Generated at 2022-06-12 10:38:17.743291
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('sleep'):
        time.sleep(1)

# Generated at 2022-06-12 10:38:19.783455
# Unit test for function debug_time
def test_debug_time():
    def func():
        time.sleep(0.1)

    with debug_time('Test debug_time'):
        func()

# Generated at 2022-06-12 10:38:21.104300
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:38:30.960691
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells.bash import Bash
    from thefuck.types import CorrectedCommand
    bash = Bash()
    assert show_corrected_command(
        CorrectedCommand(bash, 'echo "test"', 'echo "test"')) == None



# Generated at 2022-06-12 10:38:32.585083
# Unit test for function color
def test_color():
    assert color('Test') == 'Test'

    settings.no_colors = True
    assert color('Test') == ''

# Generated at 2022-06-12 10:38:33.499787
# Unit test for function debug
def test_debug():
    debug(u'testing debug')


# Generated at 2022-06-12 10:38:35.561517
# Unit test for function debug_time
def test_debug_time():
    result = None
    with debug_time('foo'):
        result = True

    assert result is True

# vim: ts=4 sw=4 et:

# Generated at 2022-06-12 10:38:44.953649
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('thefuck.log.sys') as mock_sys:
        with patch('thefuck.log.settings') as mock_settings:
            mock_settings.debug = True
            debug('x')
            mock_sys.stderr.write.assert_called_once_with(
                    u'\x1b[34m\x1b[1mDEBUG:\x1b[0m x\n')

    with patch('thefuck.log.sys') as mock_sys:
        with patch('thefuck.log.settings') as mock_settings:
            mock_settings.debug = False
            debug('x')
            assert mock_sys.stderr.write.call_count == 0

# Generated at 2022-06-12 10:38:49.357368
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationInfo(object):
        can_configure_automatically = True

    configuration_details = ConfigurationInfo()
    configuration_details.configuration_file = '.bashrc'
    configuration_details.reload = 'source ~/.bashrc'
    configuration_details.content = "eval $(thefuck --alias)"
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:38:59.027772
# Unit test for function debug_time
def test_debug_time():
    import time

    class FileLike(object):
        def __init__(self, on_write=None):
            self._on_write = on_write or (lambda: None)

        def write(self, data):
            self._on_write(data)

    def assert_write_called(data):
        assert data.startswith(
            u'{} took: '.format('spam')), data

    after_write_assert = lambda: assert_write_called(sys.stderr.getvalue())
    with debug_time('spam'):
        time.sleep(0.01)
    after_write_assert()

# Generated at 2022-06-12 10:39:00.049589
# Unit test for function debug_time
def test_debug_time():
    with debug_time('testing'):
        pass

# Generated at 2022-06-12 10:39:02.862645
# Unit test for function debug_time
def test_debug_time():
    from time import sleep
    from textwrap import dedent

    from thefuck.utils import debug_time

    with debug_time('debug_time'):
        sleep(1)

    expected = dedent('''
        \x1b[34m\x1b[1mDEBUG:\x1b[0m debug_time took: 0:00:01
    ''').strip()
    assert debug.__globals__[
               'sys'].stderr.getvalue() == expected

# Generated at 2022-06-12 10:39:04.034777
# Unit test for function show_corrected_command
def test_show_corrected_command():
    #show_corrected_command(corrected_command)
    return

# Generated at 2022-06-12 10:39:15.188368
# Unit test for function show_corrected_command
def test_show_corrected_command():
    try:
        colorama.init(strip=True)
        show_corrected_command(('apt-get install', ''))
        show_corrected_command(('apt-get install', ' +side effect'))
        show_corrected_command(('apt-get install', '+side effect'))
    finally:
        colorama.deinit()

if __name__ == '__main__':
    test_show_corrected_command()

# Generated at 2022-06-12 10:39:22.463428
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        const.ConfigurationDetails('$HOME/.bashrc',
                                   'echo "eval $(thefuck --alias)"',
                                   'source $HOME/.bashrc',
                                   None))
    how_to_configure_alias(
        const.ConfigurationDetails('$HOME/.zshrc',
                                   'echo "eval $(thefuck --alias)"',
                                   'source $HOME/.zshrc',
                                   None))

# Generated at 2022-06-12 10:39:29.190150
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple('configuration_details',
                                       ['content', 'path',
                                        'can_configure_automatically', 'reload'])
    content = ''
    path = ''
    can_configure_automatically = ''
    reload = ''
    configuration_details.content = content
    configuration_details.path = path
    configuration_details.can_configure_automatically = can_configure_automatically
    configuration_details.reload = reload
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:39:34.678219
# Unit test for function debug
def test_debug():
    def test(msg):
        sys.stderr = sys.stdout
        try:
            debug(msg)
        except Exception as e:
            assert False, e

        sys.stderr = sys.__stderr__

    test('Hello world!')
    settings.debug = False
    test('Hello world!')

# Generated at 2022-06-12 10:39:39.648611
# Unit test for function debug
def test_debug():
    import sys
    import StringIO

    try:
       saved_stderr = sys.stderr
       try:
           out = StringIO.StringIO()
           sys.stderr = out
           debug('foo')
           output = out.getvalue().strip()
           assert output == 'DEBUG: foo', output
       finally:
           sys.stderr = saved_stderr
    finally:
        reload(sys)

# Generated at 2022-06-12 10:39:40.791875
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(.5)

# Generated at 2022-06-12 10:39:51.066689
# Unit test for function confirm_text

# Generated at 2022-06-12 10:39:52.987441
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'git push origin master'
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:39:55.407285
# Unit test for function debug
def test_debug():
    try:
        debug(u'hello')
        assert True
    except:
        assert False


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:39:58.745498
# Unit test for function debug
def test_debug():
    sys.stderr = FakeStdErr()
    debug('foo')
    assert sys.stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-12 10:40:13.999575
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def debug_disabled():
        original_debug = settings.debug
        settings.debug = False
        yield
        settings.debug = original_debug

    @contextmanager
    def catch_output():
        output = StringIO()
        original = sys.stderr
        sys.stderr = output
        yield output
        sys.stderr = original

    with catch_output() as output:
        debug(u'msg')
    assert output.getvalue() == u''

    with debug_disabled(), catch_output() as output:
        debug(u'msg')
    assert output.getvalue() == u''

    with catch_output() as output:
        settings.debug = True
        debug(u'msg')
   

# Generated at 2022-06-12 10:40:15.189935
# Unit test for function debug
def test_debug():
    debug('testm')
test_debug()

# Generated at 2022-06-12 10:40:20.845795
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    config_details = const.ConfigurationDetails('PROMPT', '', '', '', '.bashrc')
    how_to_configure_alias(config_details)
    config_details = const.ConfigurationDetails('PROMPT', '', '', '', '.bashrc', True)
    how_to_configure_alias(config_details)



# Generated at 2022-06-12 10:40:21.774599
# Unit test for function debug
def test_debug():
    debug("test debug")
    debug("test debug 2")

# Generated at 2022-06-12 10:40:30.542975
# Unit test for function confirm_text
def test_confirm_text():
    from .shells.base import Shell

    """
    def __init__(self, *args, **kwargs):
        super(Shell, self).__init__(*args, **kwargs)
        self._script = ''
        self.side_effect = ''
        self.get_command = lambda: self._script
        self.put_to_history = lambda *args, **kwargs: None
    """


# Generated at 2022-06-12 10:40:34.231542
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.utils import debug, settings
    settings.debug = True
    with patch('sys.stderr') as stderr:
        debug(u'command')
    stderr.write.assert_called_with(
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m command\n')



# Generated at 2022-06-12 10:40:38.123679
# Unit test for function debug_time
def test_debug_time():
    def assert_equals(one, two, msg=''):
        assert one == two, u'{one} != {two}, {msg}'.format(
            one=one, two=two, msg=msg)

    with debug_time('foo'):
        for i in range(1000):
            pass
        assert_equals(settings.debug, True)

# Generated at 2022-06-12 10:40:42.794008
# Unit test for function debug_time
def test_debug_time(): # FIXME: do not use `test` prefix for unit-tests
    """
    >>> @debug_time('do_something')
    ... def do_something(*args):
    ...     pass
    >>> settings.debug = True
    >>> do_something(1, 2, 3)
    DEBUG: do_something took: 0:00:00
    """
    pass

# Generated at 2022-06-12 10:40:47.535168
# Unit test for function debug
def test_debug():
    import sys
    import os
    import io
    from .conf import settings

    settings.debug = True

    buffer = io.StringIO()
    sys.stderr = buffer
    debug('message')
    sys.stderr = sys.__stderr__

    assert buffer.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n'

# Generated at 2022-06-12 10:40:52.365555
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    configuration_details = Shell('bash', ['$(brew --prefix)/bin/bash'],
                                  None, '~/.bashrc',
                                  'source ~/.bashrc',
                                  'You should reload your shell by command'
                                  ' "source ~/.bashrc"', None, True)
    how_to_configure_alias(configuration_details)
    assert True



# Generated at 2022-06-12 10:41:08.371478
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules.git_push_force import match, get_new_command
    from thefuck.shells import bash
    from mock import Mock
    from StringIO import StringIO
    import sys

    command = Mock(script='git push -f')
    new_command = get_new_command(command, '--force')
    assert match(command, new_command)

    # Using io module
    io = StringIO()
    sys.stderr = io
    show_corrected_command(new_command)
    sys.stderr = sys.__stderr__

    # Using @contextmanager
    with bash.prefix('fuck: ', False):
        pass
    print('git push --force')
    new_command = get_new_command(command, '--force')

# Generated at 2022-06-12 10:41:09.943213
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.main import Command

    cmd = Command('ls non-existent-directory', 'ls ~/', None)
    confirm_text(cmd)

# Generated at 2022-06-12 10:41:11.223597
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        import time
        time.sleep(0.1)

# Generated at 2022-06-12 10:41:14.485650
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    stream = StringIO.StringIO()
    sys.stderr = stream
    show_corrected_command("gco master")
    assert stream.getvalue() == ">gco master\n"

# Generated at 2022-06-12 10:41:23.287957
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    from .command import Command
    import mock
    import sys

    def assert_output(corrected_command, expected):
        try:
            sys.stderr = mock.Mock()
            show_corrected_command(corrected_command)
            sys.stderr.write.assert_called_once_with(expected)
        finally:
            sys.stderr = sys.__stderr__

    assert_output(Command('ls'),
                  u'{}{}ls{}\n'.format(const.USER_COMMAND_MARK,
                                       color(colorama.Style.BRIGHT),
                                       color(colorama.Style.RESET_ALL)))

# Generated at 2022-06-12 10:41:25.832805
# Unit test for function debug
def test_debug():
    sys.argv = ['thefuck', '--debug', 'ls']
    from . import main
    main.main()
    import pdb;pdb.set_trace()



# Generated at 2022-06-12 10:41:28.094558
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    """when the configuration_details is not None.
    when the configuration_details is None.
    """
    how_to_configure_alias(None)


# Generated at 2022-06-12 10:41:30.444924
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr', new=None):
        debug('test')

# Generated at 2022-06-12 10:41:31.044556
# Unit test for function debug
def test_debug():
    debug('Test debug')

# Generated at 2022-06-12 10:41:38.478812
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(
        CorrectedCommand('ls')) == '-> ls [enter/↑/↓/ctrl+c]\x1b[1K\r\x1b[1m\x1b[1mls\x1b[0m [\x1b[32menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]'

# Generated at 2022-06-12 10:41:48.260819
# Unit test for function confirm_text
def test_confirm_text():
    class FakeCommand(object):
        def __init__(self, script, side_effect=True):
            self.script = script
            self.side_effect = side_effect

    confirm_text(FakeCommand('echo "foo"'))
    confirm_text(FakeCommand('echo "foo"', False))

# Generated at 2022-06-12 10:41:50.036805
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('command') == '>command [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:41:57.687063
# Unit test for function debug
def test_debug():
    from mock import patch, call
    from . import output

    with patch('sys.stderr') as stderr:
        output.debug('foo')
        output.debug('bar')
        assert stderr.write.mock_calls == [
            call(u'{blue}{bold}DEBUG:{reset} foo\n'.format(
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL))),
            call(u'{blue}{bold}DEBUG:{reset} bar\n'.format(
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL)))]



# Generated at 2022-06-12 10:41:58.998684
# Unit test for function debug_time
def test_debug_time():
    import time
    # TODO: test
    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:42:05.068940
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf import Configuration

    assert how_to_configure_alias('configuration_details') == \
           """Seems like {bold}fuck{reset} alias isn't configured!
Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.
Or run {bold}fuck{reset} a second time to configure it automatically.
More details - https://github.com/nvbn/thefuck#manual-installation"""
