

# Generated at 2022-06-12 10:32:13.095779
# Unit test for function debug
def test_debug():
    assert debug(u'test') == None


# Generated at 2022-06-12 10:32:16.067894
# Unit test for function color
def test_color():
    assert color(u'\n') == u'\n'
    assert color(u'') == u''
    settings.no_colors = True
    assert color(u'') == u''
    assert color(u'\n') == u''
    settings.no_colors = False

# Generated at 2022-06-12 10:32:16.855296
# Unit test for function debug_time
def test_debug_time():
    debug_time(u'foo')

# Generated at 2022-06-12 10:32:17.362282
# Unit test for function debug_time
def test_debug_time():
    time = 2

# Generated at 2022-06-12 10:32:20.689636
# Unit test for function confirm_text
def test_confirm_text():
    class Command(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    confirm_text(Command('ls'))
    confirm_text(Command('ls', side_effect=True))

# Generated at 2022-06-12 10:32:23.752400
# Unit test for function debug_time
def test_debug_time():
    import time
    from . import debug_time
    with debug_time('asd'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:32:29.364820
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # given
    from thefuck.shells.bash import Bash
    from thefuck.shells.shell import CorrectedCommand
    corrected_command = CorrectedCommand('ls -la', 'ls -al',
                                         'Run ls -al instead of ls -la',
                                         False, 'ls -la', Bash())
    # when
    show_corrected_command(corrected_command)
    # then
    #call(['tput', 'el'])



# Generated at 2022-06-12 10:32:38.743303
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .conf import ConfigurationDetails

    with Shell('/bin/bash', ['bash'],
               ConfigurationDetails('test', 'test', 'test', 'test', True)) as shell:
        shell.get_aliases_output = lambda x: ''
        how_to_configure_alias(shell.get_configuration_details())

# Generated at 2022-06-12 10:32:44.636983
# Unit test for function debug_time
def test_debug_time():
    from StringIO import StringIO
    from .app import debug_time
    import sys

    temp_stdout = StringIO()
    real_stdout, sys.stdout = sys.stdout, temp_stdout

    with debug_time('Привет, мир!'):
        pass

    assert temp_stdout.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Привет, мир! took: 0:00:00\n'

# Generated at 2022-06-12 10:32:45.697190
# Unit test for function debug
def test_debug():
    debug("test_str")

# Generated at 2022-06-12 10:32:48.833265
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:32:51.068761
# Unit test for function color
def test_color():
    assert color('some colored string') == 'some colored string'
    settings.no_colors = True
    assert color('some colored string') == ''



# Generated at 2022-06-12 10:33:00.203821
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    from . import rules
    from .shells import Bash
    from .types import CorrectedCommand
    from .utils import get_closest, get_closest_correction

    settings.DEBUG = True

    @rules.build(match=match_command_re(r'ls', r'lssssssssssss'))
    def match(command):
        return CorrectedCommand('ls', '', '')

    @rules.build(match=match_command_re(r'ls'))
    def match(command):
        return CorrectedCommand('ls', '', '')


# Generated at 2022-06-12 10:33:09.432617
# Unit test for function confirm_text
def test_confirm_text():
    from mock import Mock
    from functools import partial

    sys.stderr = Mock()
    corrected_command = Mock(script=u'echo "Hello"', side_effect=False)

    confirm_text(corrected_command)


# Generated at 2022-06-12 10:33:10.492967
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:33:22.183878
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from collections import namedtuple

    def assert_output(configuration_details, expected):
        print(u'')  # To have a line break before assert message
        assert ("\n".join(sys.stderr.getvalue().split('\n')[-2:])) == expected

    shell = Shell(u'/bin/bash', u'fuck')
    configuration_details = shell.get_autodetected_details()
    configuration_details.path = u'/home/user/.bashrc'
    configuration_details.content = (u'function fuck() {\n'
                                     u'    eval $(thefuck $(fc -ln -1));\n'
                                     u'}')
    configuration_details.reload = u'source ~/.bashrc'

    sys.stderr = sys.__stder

# Generated at 2022-06-12 10:33:23.060255
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:33:24.636599
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """This function will test show_corrected_command function."""
    from .core import Command
    show_corrected_command(Command('ls', '', '', False))

# Generated at 2022-06-12 10:33:36.429159
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.utils import ConfigurationDetails
    from cStringIO import StringIO
    old_stdout = sys.stdout

# Generated at 2022-06-12 10:33:43.841615
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    from .shells import Bash
    from .shells import Fish
    from .shells import Zsh
    from .shells import Tcsh
    from .shells import Xonsh
    from .shells import Unknown

    choices = [
        Bash,
        Fish,
        Zsh,
        Tcsh,
        Xonsh,
        Unknown
    ]

    for shell in choices:
        assert '/bin/ls' in confirm_text(shell('/bin/ls', None))

# Generated at 2022-06-12 10:33:51.277482
# Unit test for function confirm_text
def test_confirm_text():
    # test to confirm the confirm_text function
    class FakeCorrectedCommand(object):
        def __init__(self):
            self.script = ""
            self.side_effect = False

    corrected_command = FakeCorrectedCommand()
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:33:58.494853
# Unit test for function debug
def test_debug():
    import unittest
    import mock
    from thefuck.utils import debug as debug_function

    class DebugTest(unittest.TestCase):
        @mock.patch('sys.stderr')
        def test_it_shows_debug_message(self, stderr):
            debug_function('some-message')
            stderr.write.assert_called_once_with(
                u'{blue}{bold}DEBUG:{reset} some-message\n'.format(
                    blue=color(colorama.Fore.BLUE),
                    bold=color(colorama.Style.BRIGHT),
                    reset=color(colorama.Style.RESET_ALL)))

    unittest.main()

# Generated at 2022-06-12 10:33:59.753084
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.corrector import Command
    confirm_text(Command('pwd', 'pwd'))



# Generated at 2022-06-12 10:34:00.890436
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test [+] [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:34:05.335612
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import six
    import sys
    class Mock(object):
        pass
    corrected_command = Mock()
    corrected_command.script = 'git push'
    corrected_command.side_effect = None
    debug_stdout = sys.stdout
    try:
        sys.stdout = six.StringIO()
        show_corrected_command(corrected_command)
        output = sys.stdout.getvalue().strip()
        assert output == '{}\x1b[1m\x1b[32mgit push\x1b[0m'.format(const.USER_COMMAND_MARK)
    finally:
        sys.stdout = debug_stdout


# Generated at 2022-06-12 10:34:15.545508
# Unit test for function debug
def test_debug():
    # NB: all required libraries should be imported here
    import sys
    import pytest
    from mock import patch, Mock
    from thefuck.shells import Shell

    def run_debug():
        debug(u'foo')

    # with debug=False
    with patch.object(sys, 'stderr', Mock()) as out:
        with patch.object(Shell, 'debug', False):
            run_debug()
    out.write.assert_not_called()

    # with debug=True
    expected_output = (u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')
    with patch.object(sys, 'stderr', Mock()) as out:
        with patch.object(Shell, 'debug', True):
            run_debug()

# Generated at 2022-06-12 10:34:19.250452
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias( 
        configuration_details=configuration_details( 
            path=u'/root/.bashrc',
            reload=u'source /root/.bashrc',
            content=u'source ~/.python3.6/bin/virtualenvwrapper.sh',
            can_configure_automatically=False
            )
        )


# Generated at 2022-06-12 10:34:29.675341
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import WhichOS

    if WhichOS() == 'macosx':
        assert how_to_configure_alias({'path': '~/.bash_profile',
                                       'content':'eval "$(thefuck --alias)"',
                                       'reload':'source ~/.bash_profile',
                                       'can_configure_automatically': True}) == None
    elif WhichOS() == 'linux':
        assert how_to_configure_alias({'path': '~/.bashrc',
                                       'content':'eval "$(thefuck --alias)"',
                                       'reload':'source ~/.bashrc',
                                       'can_configure_automatically': True}) == None

# Generated at 2022-06-12 10:34:31.071331
# Unit test for function debug
def test_debug():
    # Test debug
    debug('Some debug message')



# Generated at 2022-06-12 10:34:32.516134
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("test_command") == "test_command"


# Generated at 2022-06-12 10:34:41.837726
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . import correct
    import sys
    from StringIO import StringIO
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    
    with captured_output() as (out, err):
        show_corrected_command(correct.CorrectedCommand('test', True))
    output = out.getvalue().strip()

# Generated at 2022-06-12 10:34:42.841535
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'



# Generated at 2022-06-12 10:34:50.417869
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    with patch.object(log, 'debug') as patched_debug:
        with log.debug_time('test'):
            assert patched_debug.call_count == 0
        debug_calls = patched_debug.call_args_list
        assert debug_calls[0][0][0].startswith('test took: ')
        assert abs(timedelta(*[int(num) for num in debug_calls[0][0][0].split()[3].split(':')])
                    - timedelta(seconds=101)) < timedelta(seconds=1)


# Generated at 2022-06-12 10:35:00.504431
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    import sys

    mock_stdout = StringIO.StringIO()
    mock_stderr = StringIO.StringIO()
    with open('conf.py', 'w') as f:
        f.write('print("test_alias")')

    sys.stdout = mock_stdout
    sys.stderr = mock_stderr
    how_to_configure_alias()
    mock_stderr.seek(0)
    s = mock_stderr.read()
    assert('Seems like fuck alias isn\'t configured!' in s)
    assert('test_alias' in s)
    sys.stdout = sys.__stdout__
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:35:01.537241
# Unit test for function debug_time
def test_debug_time():
    with debug_time('debug_time'):
        pass

# Generated at 2022-06-12 10:35:05.088842
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import ShellInfo
    from .shells.generic import Generic

    how_to_configure_alias(None)
    configuration_details = Generic().get_configuration_details()
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:35:06.365721
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:07.354656
# Unit test for function confirm_text
def test_confirm_text():
    #TODO
    pass


# Generated at 2022-06-12 10:35:16.406049
# Unit test for function how_to_configure_alias

# Generated at 2022-06-12 10:35:26.008968
# Unit test for function confirm_text
def test_confirm_text():
    from .types import CorrectedCommand
    from mock import patch

    with patch('sys.stderr') as mocked_stderr:
        confirm_text(CorrectedCommand(script='echo "Hello, World!"',
                                      side_effect=False))
        mocked_stderr.write.assert_called_once_with(
            u'{prefix}[1K\r'
            u'[1mecho "Hello, World!"[21m '
            u'[[32menter[39m/[34m↑[39m/[34m↓[39m/[31mctrl+c[39m]'.format(
                prefix=const.USER_COMMAND_MARK))

# Generated at 2022-06-12 10:35:34.763545
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """Test function show_corrected_command
    """
    show_corrected_command.__globals__['sys'].stderr = sys.__stdout__
    show_corrected_command(corrected_command = CorrectedCommand("ls",
                                                                side_effect = False))
    show_corrected_command(corrected_command = CorrectedCommand("ls",
                                                                side_effect = True))



# Generated at 2022-06-12 10:35:36.390620
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('some_corrected_command')



# Generated at 2022-06-12 10:35:36.963315
# Unit test for function show_corrected_command
def test_show_corrected_command():
    asse

# Generated at 2022-06-12 10:35:43.158341
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .. import conf
    stderr = sys.stderr
    sys.stderr = StringIO()
    try:
        conf.settings.debug = False
        debug('test')
        assert sys.stderr.getvalue() is ''
        conf.settings.debug = True
        debug('test')
        assert sys.stderr.getvalue() == u'DEBUG: test\n'
    finally:
        sys.stderr = stderr

# Generated at 2022-06-12 10:35:46.580073
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('', (), {'script': 'ls',
                                      'side_effect': False})()
    assert confirm_text(corrected_command) == 'ls [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-12 10:35:49.393274
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock

    time.sleep = mock.Mock()

    with debug_time(u'foo'):
        time.sleep(0.1)

    assert time.sleep.called



# Generated at 2022-06-12 10:35:50.266145
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'msg'):
        1

# Generated at 2022-06-12 10:35:54.289611
# Unit test for function debug
def test_debug():
    debug('test')
    assert 'test' in sys.stderr.getvalue()
    sys.stderr.seek(0) # reset sys.stderr.getvalue()
    assert 'test' not in sys.stderr.getvalue()

# Generated at 2022-06-12 10:36:01.847915
# Unit test for function debug
def test_debug():
    msg = 'Some debug message'
    save_debug = settings.debug
    settings.debug = False
    debug(msg)
    debug_output = sys.stderr.getvalue()
    sys.stderr = temp_stderr = StringIO()
    assert debug_output == ''
    settings.debug = True
    debug(msg)
    debug_output = sys.stderr.getvalue()
    assert 'DEBUG' in debug_output
    assert msg in debug_output
    settings.debug = save_debug
    sys.stderr = temp_stderr

# Generated at 2022-06-12 10:36:08.640668
# Unit test for function confirm_text
def test_confirm_text():
    from pytest import raises
    from mock import patch
    from thefuck.utils import memoize

    correct_command = 'correct command'
    correct_command_with_side_effect = 'correct command with side effect'
    prefix = u'>>>'
    clear = '\033[1K\r'
    bold = color(colorama.Style.BRIGHT)
    reset = color(colorama.Style.RESET_ALL)
    green = color(colorama.Fore.GREEN)
    red = color(colorama.Fore.RED)
    blue = color(colorama.Fore.BLUE)

    @memoize
    def settings():
        return type('', (), {})

    @patch('sys.stderr')
    def test(sys_stderr, command, expected):
        confirm_text(command)
        sys

# Generated at 2022-06-12 10:36:13.441034
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text([1,2,3])

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:36:15.142043
# Unit test for function debug_time
def test_debug_time():
    # pylint: disable=unused-argument
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:36:17.661436
# Unit test for function debug
def test_debug():
    orig_debug = settings.debug
    try:
        settings.debug = True
        debug(u'foo')
    finally:
        settings.debug = orig_debug


# Generated at 2022-06-12 10:36:22.463276
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells.base import Command
    command = Command('git commit', 'git commit -v')
    sys.stderr = sys.__stderr__
    show_corrected_command(command)
    assert sys.stderr.getvalue().endswith(u'Fuck >> git commit -v\n')



# Generated at 2022-06-12 10:36:24.633352
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command=create_corrected_command_side_effect())
    assert True, u'message'



# Generated at 2022-06-12 10:36:25.668183
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:36:28.083160
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    test_command = CorrectedCommand('vim', True)
    show_corrected_command(test_command)


# Generated at 2022-06-12 10:36:31.255685
# Unit test for function debug
def test_debug():
    from tests.utils import capture_output
    with capture_output() as (stdout, stderr):
        debug(u'Test message')
    assert stdout == ''
    assert stderr == u'DEBUG: Test message\n'


# Generated at 2022-06-12 10:36:32.984927
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = "git adc"
    assert show_corrected_command(corrected_command) == "git adc"

# Generated at 2022-06-12 10:36:40.252054
# Unit test for function debug
def test_debug():
    from mock import patch, Mock
    from thefuck.shells import Bash, Zsh
    from thefuck.utils import wrap_settings, debug, no_colors
    import sys
    import tempfile
    import contextlib
    import colorama

    @contextmanager
    def no_stderr():
        from cStringIO import StringIO
        old = sys.stderr
        sys.stderr = StringIO()
        try:
            yield
        finally:
            sys.stderr = old

    with wrap_settings(require_confirmation=True,
                       exclude_rules=[],
                       wait_command=0,
                       no_colors=True,
                       debug=False):
        assert debug('Hello!') is None
        with wrap_settings(debug=True):
            assert debug('Hello!') is not None


# Generated at 2022-06-12 10:36:44.746914
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == None
    assert confirm_text('') == ''



# Generated at 2022-06-12 10:36:46.399001
# Unit test for function debug_time
def test_debug_time():
    a = ''
    with debug_time(a):
        a = 'test'


# Generated at 2022-06-12 10:36:52.059769
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from io import StringIO
    import sys

    @contextmanager
    def patch_stdout():
        old_stdout = sys.stdout
        stdout = StringIO()
        sys.stdout = stdout
        yield stdout
        sys.stdout = old_stdout

    with patch_stdout() as stdout:
        debug(u'msg')
        assert stdout.getvalue() == u'msg'

# Generated at 2022-06-12 10:36:54.123375
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(make_command_from_script(u'git push')) == u'git push     [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-12 10:37:00.821808
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Settings
    settings = Settings({u'no_colors': True}, {}, {}, {}, {}, '', '')
    from .shells import Shell
    from .command import Command
    shell = Shell('', '')
    shell.get_history = lambda: [
        Command('ls', ''),
        Command('echo "123"', ''),
        Command('ls', '')]
    confirm_text(shell.correct_history(Command('ls', '')))

# Generated at 2022-06-12 10:37:02.105732
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'fuck test [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:37:03.558576
# Unit test for function debug_time
def test_debug_time():
    with debug_time('mytest'):
        1+1



# Generated at 2022-06-12 10:37:04.322528
# Unit test for function debug
def test_debug():
    assert debug('test_debug')



# Generated at 2022-06-12 10:37:07.154095
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = type('CorrectedCommand', (), {
        'script': 'corrected command',
        'side_effect': False,
    })
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:37:09.504368
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    assert not settings.no_colors
    settings.no_colors = True
    assert color(u'foo') == u''

# Generated at 2022-06-12 10:37:15.234478
# Unit test for function confirm_text
def test_confirm_text():
    # terminal has width 80
    corrected_command = type('', (), {'script': u'1\u2192 1', 'side_effect': False})
    confirm_text(corrected_command)
    assert True



# Generated at 2022-06-12 10:37:16.542099
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('git') == 'git'



# Generated at 2022-06-12 10:37:22.535459
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock

    with mock.patch('datetime.datetime') as mocked_datetime:
        mocked_datetime.now.return_value = 7
        with debug_time('foo'):
            time.sleep(0.1)
        mocked_datetime.now.assert_called_with()
        mocked_datetime.now().return_value = 9
        mocked_datetime.now.assert_called_with()

# Generated at 2022-06-12 10:37:28.537601
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from mock import patch
    settings.debug = True
    with patch('sys.stderr', new=StringIO()) as mock_stderr:
        debug('debug text')
        assert mock_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m debug text\n'



# Generated at 2022-06-12 10:37:29.486375
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:37:30.376066
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('') == "test"

# Generated at 2022-06-12 10:37:31.880695
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    show_corrected_command(CorrectedCommand('ls', False))

# Generated at 2022-06-12 10:37:35.854711
# Unit test for function confirm_text
def test_confirm_text():
    from mock import MagicMock
    sys.stderr = MagicMock()
    settings.debug = False
    confirm_text('123')
    try:
        assert sys.stderr.write_called_with(
            u'$fuck 123 [enter/↑/↓/ctrl+c]')
    except AssertionError as e:
        print('test_confirm_text failed: ' + str(e))

# Generated at 2022-06-12 10:37:41.339294
# Unit test for function color
def test_color():
    """
    >>> color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    True

    >>> color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    True

    >>> color(colorama.Fore.BLUE) == ''
    False
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 10:37:51.142357
# Unit test for function confirm_text
def test_confirm_text():
    # Unicode characters:
    #   |'\xe2\x86\x92' (U+2192 RIGHTWARDS ARROW)
    #   |'\xe2\x86\x93' (U+2193 DOWNWARDS ARROW)
    #   |'\xe2\x86\x91' (U+2191 UPWARDS ARROW)
    class Command:
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    confirm_text(Command('git commit --amend'))
    confirm_text(Command('git commit --amend', side_effect=True))
    confirm_text(Command('git commit\xe2\x86\x92'))

# Generated at 2022-06-12 10:37:55.349398
# Unit test for function color
def test_color():
    assert color('a') == 'a'
    settings.no_colors = True
    assert color('a') == ''

# Generated at 2022-06-12 10:37:57.381666
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-12 10:37:58.139594
# Unit test for function color
def test_color():
    assert color('norm') == 'norm'
    assert color('') == ''

# Generated at 2022-06-12 10:38:06.583850
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from collections import namedtuple
    ConfigurationDetails = namedtuple('ConfigurationDetails', 'path content can_configure_automatically reload')

    how_to_configure_alias(ConfigurationDetails(
        path=u'~/.bashrc',
        content=u'"eval $(thefuck --alias)',
        can_configure_automatically=True,
        reload=u'. ~/.bashrc',
    ))

    """
    Output should be like this:

    Seems like The Fuck isn't configured!
    Please put "eval $(thefuck --alias)" in your ~/.bashrc and apply
    changes with . ~/.bashrc or restart your shell.
    Or run thefuck a second time to configure it automatically.
    More details - https://github.com/nvbn/thefuck#manual-installation

    """

# Generated at 2022-06-12 10:38:08.326123
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    show_corrected_command(CorrectedCommand('vim', 'ls'))


# Generated at 2022-06-12 10:38:13.769226
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand

    sys.stderr = open('/dev/null', 'w')
    show_corrected_command(CorrectedCommand('ls', False))
    sys.stderr.close()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:38:19.216067
# Unit test for function debug
def test_debug():
    from test.utils import assert_equal
    from test.utils import FakeStdIO

    debug(u'test')

    assert_equal(FakeStdIO.stderr.getvalue(),
                 u'{blue}{bold}DEBUG:{reset} test\n'.format(
                    reset=color(colorama.Style.RESET_ALL),
                    blue=color(colorama.Fore.BLUE),
                    bold=color(colorama.Style.BRIGHT)))



# Generated at 2022-06-12 10:38:20.096701
# Unit test for function debug
def test_debug():
    assert debug('hello') is None

# Generated at 2022-06-12 10:38:25.079803
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import mock
    from themylog.reader import Dummy
    from .log import now

    with mock.patch('thefuck.script.now', Dummy(now() + timedelta(seconds=1))):
        with debug_time('foo'):
            pass

    assert settings.log.contains('foo took: 1:00:00')

# Generated at 2022-06-12 10:38:32.711927
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(
        (u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
         u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
         u'/{red}ctrl+c{reset}]').format(
            prefix=const.USER_COMMAND_MARK,
            script='git',
            side_effect=' (+side effect)' if True else '',
            clear='\033[1K\r',
            bold=color(colorama.Style.BRIGHT),
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE)))


# Unit

# Generated at 2022-06-12 10:38:40.879785
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('thefuck.ui.sys') as mock_sys:
        debug('foo')

    mock_sys.stderr.write.assert_called_with(
        u'{blue}{bold}DEBUG:{reset} foo\n'.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT)))

# Generated at 2022-06-12 10:38:44.595186
# Unit test for function color
def test_color():
    assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL
    settings.no_colors = True
    assert color(colorama.Style.RESET_ALL) == ''

# Generated at 2022-06-12 10:38:52.196875
# Unit test for function debug
def test_debug():
    from thefuck.shells import shell
    from thefuck.utils import get_all_subclasses
    from tempfile import NamedTemporaryFile
    from io import BytesIO

    old_stderr = sys.stderr
    old_shell = shell.__class__


# Generated at 2022-06-12 10:38:53.387554
# Unit test for function debug
def test_debug():
    with debug_time('foo'):
        pass
        debug('bar')



# Generated at 2022-06-12 10:39:01.185467
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck import configure, settings
    from thefuck.utils import ConfigurationDetails

    configuration_details = ConfigurationDetails('~/.bashrc', 'source ~/.bashrc',
                                                 True)
    how_to_configure_alias(configuration_details)
    how_to_configure_alias(None)
    settings.no_colors = True
    how_to_configure_alias(None)


if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:39:04.295210
# Unit test for function debug
def test_debug():
    from thefuck.utils import capture_stderr
    with capture_stderr() as stderr:
        debug(u'Hi!')
    assert u'DEBUG: Hi!' in stderr.getvalue()



# Generated at 2022-06-12 10:39:13.814938
# Unit test for function confirm_text
def test_confirm_text():
    import re
    import os
    import sys
    import colorama
    from contextlib import contextmanager

    # Colorama init
    colorama.init()

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    test = {
        'script': 'ls -l',
        'side_effect': False
    }

    with captured_output() as (out, err):
        confirm_text(test)

# Generated at 2022-06-12 10:39:23.993291
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    from . import const
    from .utils import confirm_text
    settings.no_colors = False
    corrected_command = const.Command(u'sudo ls /', False)
    assert confirm_text(corrected_command) == (u'\x1b[1K\r\x1b[1m\x1b[1mfuck\x1b[21m\x1b[0m\x1b[32m\x1b[1msudo ls /\x1b[0m  [enter/\x1b[34m\x1b[1m↑\x1b[0m/\x1b[34m\x1b[1m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]')
   

# Generated at 2022-06-12 10:39:31.287862
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO
    import mock
    from tempfile import NamedTemporaryFile

    from thefuck.shells import shell
    from thefuck.shells.bash import Bash
    from thefuck.shells.fish import Fish
    from thefuck.shells.zsh import Zsh
    from thefuck import types
    from tests.utils import Rule, Command

    @Rule
    def match(command):
        return Command(script='ls ~/')

    bash_alias = NamedTemporaryFile(delete=False).name
    with open(bash_alias, 'w') as bash_alias:
        bash_alias.write('#!/bin/bash\nthefuck $1')

    fish_alias = NamedTemporaryFile(delete=False).name

# Generated at 2022-06-12 10:39:32.812917
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from . import log
    log.settings.debug = True
    with log.debug_time('msg'):
        assert timedelta() == timedelta()
    log.settings.debug = False

# Generated at 2022-06-12 10:39:39.956505
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''

# Generated at 2022-06-12 10:39:42.279261
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Config
    from .app import Command

    settings = Config()
    settings.no_colors = False
    command = Command(script='echo test', side_effect=False)
    confirm_text(command)

# Generated at 2022-06-12 10:39:44.099845
# Unit test for function color
def test_color():
    assert color('yellow') == colorama.Fore.YELLOW



# Generated at 2022-06-12 10:39:45.983112
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(
        script='git log', side_effect=False)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:39:49.754149
# Unit test for function debug
def test_debug():
    from .tests.utils import capture_stderr
    with capture_stderr() as stderr:
        debug('Test')
        stderr = stderr.getvalue()

    assert u'DEBUG: Test\n' in stderr

# Generated at 2022-06-12 10:39:51.790067
# Unit test for function confirm_text
def test_confirm_text():
    # no_colors()
    confirm_text(object)
    # settings.no_colors = True
    # confirm_text(object)
    return

# Generated at 2022-06-12 10:39:59.587696
# Unit test for function show_corrected_command
def test_show_corrected_command():
    _old_stderr = sys.stderr
    _old_stdout = sys.stdout
    import io
    out = io.StringIO()
    sys.stderr = out
    sys.stdout = out
    try:
        from thefuck import shell
        show_corrected_command(shell.And('ls', 'cd'))
        assert out.getvalue() == '\x1b[1K\r' + const.USER_COMMAND_MARK + 'ls && cd\n'
    finally:
        sys.stderr = _old_stderr
        sys.stdout = _old_stdout

# Generated at 2022-06-12 10:40:07.667406
# Unit test for function debug
def test_debug():
    from unittest.mock import Mock
    settings.debug = True
    sys.stderr = Mock()
    debug('foo')
    sys.stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')
    settings.debug = False
    debug('bar')
    sys.stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m bar\n')
    settings.debug = True
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:40:11.372980
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import mock
    import time

    with mock.patch.object(time, 'sleep') as mock_sleep:
        with debug_time('test'):
            mock_sleep.assert_not_called()

        mock_sleep.assert_called_once_with(0.1)



# Generated at 2022-06-12 10:40:12.851712
# Unit test for function confirm_text
def test_confirm_text():
    command = u'$ echo "1"\n'
    confirm_text(command)


# Generated at 2022-06-12 10:40:22.682932
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    corrected_command = Command('ls', 'ls -GF')
    show_corrected_command(corrected_command)
    corrected_command = Command('ls', 'ls -GF', True)
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:40:26.544497
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class TestCommand():
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    test_command = TestCommand(script='git push', side_effect=True)
    show_corrected_command(test_command)

# Generated at 2022-06-12 10:40:33.608744
# Unit test for function debug
def test_debug():
    import os
    import sys
    import mock

    with mock.patch('sys.stderr') as stderr:
        debug('Some text')
    stderr.write.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m Some text\n')

    with mock.patch('thefuck.shells.get_shell') as shell, \
            mock.patch.dict(os.environ, {}):
        shell.return_value.get_alias.return_value = 'alias fuck=\'eval $(thefuck $(fc -ln -1))\''
        shell.return_value.app_alias.return_value = 'eval $(thefuck $(fc -ln -1))'
        shell.return_value.app_exists.return_value = True

# Generated at 2022-06-12 10:40:34.746009
# Unit test for function confirm_text
def test_confirm_text():
    test_command = 'thefuck'
    confirm_text(test_command)

# Generated at 2022-06-12 10:40:35.807782
# Unit test for function debug
def test_debug():
    debug('test')
    # TODO: check if really is written to stderr

# Generated at 2022-06-12 10:40:37.527264
# Unit test for function color
def test_color():
    assert color('foo') == ''
    settings.no_colors = False
    assert color('foo') == 'foo'

# Generated at 2022-06-12 10:40:38.378135
# Unit test for function debug_time
def test_debug_time():
    assert debug_time('')

# Generated at 2022-06-12 10:40:43.770051
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from contextlib import contextmanager
    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        yield
        debug(u'{} took: {}'.format(msg, datetime.now() - started))
    def debug(msg):
        print(msg)
    with debug_time('test'):
        a = 1+1

# Generated at 2022-06-12 10:40:45.408739
# Unit test for function debug
def test_debug():
    debug(u"Йа, братан")
    assert True



# Generated at 2022-06-12 10:40:50.260584
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch
    from . import log

    msg = u'foo'
    expected = u'foo took: {0}'.format(timedelta(seconds=0))

    with patch.object(log, 'debug') as mock_debug:
        with log.debug_time(msg):
            pass
        mock_debug.assert_called_with(expected)



# Generated at 2022-06-12 10:40:58.586661
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''
    settings.no_colors = False



# Generated at 2022-06-12 10:41:00.118602
# Unit test for function debug
def test_debug():
    assert debug('msg') is None

# Generated at 2022-06-12 10:41:02.919795
# Unit test for function color
def test_color():
    assert color('blah') == ''
    with settings(no_colors=False):
        assert color('blah') == 'blah'



# Generated at 2022-06-12 10:41:05.267458
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .corrected_command import CorrectedCommand

    show_corrected_command(CorrectedCommand('ls', Command('ls')))


# Generated at 2022-06-12 10:41:07.736985
# Unit test for function confirm_text
def test_confirm_text():
    from .procs import CORRECTED_COMMAND_THAT_DID_NOTHING
    confirm_text(CORRECTED_COMMAND_THAT_DID_NOTHING)

    from .procs import CORRECTED_COMMAND_THAT_DID_SOMETHING
    confirm_text(CORRECTED_COMMAND_THAT_DID_SOMETHING)

# Generated at 2022-06-12 10:41:10.500807
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.shells.base import BaseShell
    with patch.object(BaseShell, 'make_alias') as mock_alias:
        mock_alias.return_value = u'fuck! alias'
        confirm_text(u'ls -la')
        sys.stderr.se

# Generated at 2022-06-12 10:41:12.827624
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', '', ''))



# Generated at 2022-06-12 10:41:22.022486
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    saved_stderr = sys.stderr
    try:
        out = StringIO()
        sys.stderr = out
        debug(u'Hello')
        assert False, u"debug didn't print anything"
    except AssertionError:
        assert out.getvalue() == ''
    finally:
        sys.stderr = saved_stderr

    try:
        out = StringIO()
        sys.stderr = out
        settings.debug = True
        debug(u'Hello')
        assert False, u"debug didn't print anything"
    except AssertionError:
        assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello\n'

# Generated at 2022-06-12 10:41:25.226271
# Unit test for function color
def test_color():
    assert "col" == color("col"), "Text isn't colored"
    settings.no_colors = True
    assert "" == color("col"), "Text is colored"
    settings.no_colors = False

# Generated at 2022-06-12 10:41:26.951874
# Unit test for function confirm_text
def test_confirm_text():
    res = confirm_text(corrected_command='''fuck (?)''')


# Generated at 2022-06-12 10:41:34.412874
# Unit test for function color
def test_color():
    assert color('black') == ''
    assert color('\033[0;30m') == '\033[0;30m'



# Generated at 2022-06-12 10:41:35.808502
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("This is a test")
    print("Output is NOT None")



# Generated at 2022-06-12 10:41:36.614749
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)

# Generated at 2022-06-12 10:41:37.820866
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('') == ''

# Generated at 2022-06-12 10:41:40.367192
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = {
        'script': 'ls /etc',
        'side effect': False
    }
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:41:45.357555
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
        content='eval $(thefuck --alias)',
        path='/home/test/.bash_aliases',
        reload='source /home/test/.bash_aliases',
        can_configure_automatically=False)
    assert how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:41:49.417102
# Unit test for function debug_time
def test_debug_time():
    from mock import Mock
    settings.debug = True
    stderr = Mock()
    msg = 'debug_time_msg'
    with debug_time(msg):
        assert True
    stderr.write.assert_called_with(u'debug_time_msg took: 0:00:00.000000\n')



# Generated at 2022-06-12 10:41:50.844154
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass



# Generated at 2022-06-12 10:41:54.603163
# Unit test for function debug
def test_debug():
    from io import BytesIO
    out = BytesIO()
    sys.stderr = out

    debug(u'Привет!')
    sys.stderr = sys.__stderr__

    assert out.getvalue().decode('utf-8') == u'DEBUG: Привет!\n'

# Generated at 2022-06-12 10:42:00.295737
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('/dev/null', 'w')
    show_corrected_command(const.CorrectedCommand('ls -al', True))
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    if not settings.no_colors:
        assert open('/dev/null').read() == u'{}{}{}'.format(
                const.USER_COMMAND_MARK, 'ls -al', u' (+side effect)\n')
    else:
        assert open('/dev/null').read() == u'{}ls -al\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:42:07.608961
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
         time.sleep(0.1)

# Generated at 2022-06-12 10:42:09.332309
# Unit test for function debug_time
def test_debug_time():
    def test_function(t):
        with debug_time('test'):
            pass
    test_function(0)