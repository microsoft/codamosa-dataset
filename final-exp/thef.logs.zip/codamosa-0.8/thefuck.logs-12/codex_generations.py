

# Generated at 2022-06-12 10:32:15.491818
# Unit test for function debug
def test_debug():
    assert sys.stderr.write.called
    sys.stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test')



# Generated at 2022-06-12 10:32:25.038682
# Unit test for function debug
def test_debug():
    # Update globals, cause we modified the STDOUT
    import __main__
    __main__.sys.stderr = sys.stderr

    # start testing
    msg = "message"
    debug(msg)
    assert sys.stderr.getvalue() == u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
        msg=msg,
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE),
        bold=color(colorama.Style.BRIGHT))
    sys.stderr.truncate(0)

    # clean
    sys.stderr.close()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:32:30.453817
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    with debug_time('foo'):
        from time import sleep
        sleep(0.001)
    out = StringIO()
    sys.stderr = out
    debug('foo')
    assert out.getvalue() == ''
    settings.debug = True
    debug('foo')
    assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'



# Generated at 2022-06-12 10:32:34.987402
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    sys.stderr = io.StringIO()
    show_corrected_command('corrected_command')
    result = sys.stderr.getvalue()
    sys.stderr = sys.__stderr__
    assert result == '{}corrected_command\n'.format(const.USER_COMMAND_MARK)


# Generated at 2022-06-12 10:32:38.126377
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from .scripts import fuck
    corrected_command = CorrectedCommand(
        script=fuck, side_effect=False)
    show_corrected_command(corrected_command)


# Generated at 2022-06-12 10:32:40.574935
# Unit test for function debug_time
def test_debug_time():
    """
    >>> import time
    >>> with debug_time('test'):
    ...     time.sleep(0.2)
    DEBUG: test took: 0:00:00.200012
    """

# Generated at 2022-06-12 10:32:41.972161
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN) == colorama.Fore.GREEN

# Generated at 2022-06-12 10:32:43.244050
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(1)
    assert 1 == 1

# Generated at 2022-06-12 10:32:45.278076
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time("Test"):
        time.sleep(0.1)
        assert 1 == 1
        return True


# Generated at 2022-06-12 10:32:46.257695
# Unit test for function debug
def test_debug():
    debug('debug')



# Generated at 2022-06-12 10:32:58.386146
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells.base import Shell
    from thefuck.types import CorrectedCommand
    from thefuck import conf
    from thefuck.types import Settings

    class TestShell(Shell):
        @staticmethod
        def recommend_history_limit():
            return 42

    conf.settings._set_value(Settings(history_limit=42,
                                      require_confirmation=True,
                                      wait_command=3,
                                      no_colors=True,
                                      slow_commands=['ls', 'rm'],
                                      priority=[1, 2, 3],
                                      debug=True))
    show_corrected_command(CorrectedCommand('ls'))
    show_corrected_command(CorrectedCommand('ls', side_effect=True))

# Generated at 2022-06-12 10:33:00.565431
# Unit test for function color
def test_color():
    assert color('bold') == colorama.Style.BRIGHT
    assert color('red') == colorama.Fore.RED
    assert color('black') == ''

# Generated at 2022-06-12 10:33:04.427961
# Unit test for function debug_time
def test_debug_time():
    from functools import partial

    for c in [partial(datetime.now), datetime.fromtimestamp]:
        now = c()
        with debug_time('testing'):
            assert (datetime.now() - now).microseconds > 0

# Generated at 2022-06-12 10:33:05.506586
# Unit test for function debug
def test_debug():
    assert '1' == '1'

# Generated at 2022-06-12 10:33:07.672697
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . import corrector
    from .types import Command

    c_command = Command("ls -l", "ls -la")
    show_corrected_command(c_command)

# Generated at 2022-06-12 10:33:11.226974
# Unit test for function debug
def test_debug():
    text = 'test'
    settings.debug = True
    std = sys.__stderr__
    sys.stderr = sys.stdout
    debug(text)
    sys.stderr = std
    settings.debug = False

# Generated at 2022-06-12 10:33:14.641378
# Unit test for function color
def test_color():
    assert color(colorama.Fore.GREEN + 'a' + colorama.Style.RESET_ALL) == 'a'
    assert color(colorama.Fore.GREEN + 'a' + colorama.Style.RESET_ALL) != 'b'

# Generated at 2022-06-12 10:33:17.291707
# Unit test for function color
def test_color():
    assert color(u'yellow') == u''
    assert color(u'\033[33m') == u'\033[33m'

# Generated at 2022-06-12 10:33:24.513879
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Command:

        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    from .compat import mock_streams, mock_open

    with mock_streams() as (stdout, stderr):
        show_corrected_command(Command('ls', True))
        stderr.seek(0)
        assert stderr.read() == '> ls (+side effect)\n\n'

# Generated at 2022-06-12 10:33:26.305636
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:33:30.397583
# Unit test for function debug_time
def test_debug_time():
    import time
    time.sleep(1)
    debug_time('test')



# Generated at 2022-06-12 10:33:33.660575
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        assert debug(u'XXX') == None
    finally:
        settings.debug = False



# Generated at 2022-06-12 10:33:36.191713
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'red') == colorama.Fore.RED + 'red'
    assert not color(colorama.Fore.RED + 'red')

# Generated at 2022-06-12 10:33:42.115751
# Unit test for function debug
def test_debug():
    sys.stderr = StringIO()
    debug(u'test')
    debug_text = sys.stderr.getvalue()
    assert debug_text == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    sys.stderr = sys.__stderr__


# Generated at 2022-06-12 10:33:48.330094
# Unit test for function color
def test_color():
    colorama.init()

    def assert_color(no_colors, color_, colored, uncolored):
        settings.no_colors = no_colors
        assert color(color_) == colored if not no_colors else uncolored

    assert_color(True, colorama.Fore.BLUE + 'Hello', 'Hello', 'Hello')
    assert_color(False, colorama.Fore.BLUE + 'Hello',
                 '\x1b[34mHello\x1b[0m', '\x1b[34mHello\x1b[0m')

# Generated at 2022-06-12 10:33:50.459257
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('message') == u'message[enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:33:55.512696
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    conf = configuration_details.ConfigurationDetails(
        'path',
        'content',
        'reload',
        True)

    # can_configure_automatically is True
    how_to_configure_alias(conf)

    # can_configure_automatically is False
    conf.can_configure_automatically = False
    how_to_configure_alias(conf)

# Generated at 2022-06-12 10:34:02.165788
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from contextlib import contextmanager
    from .conf import settings
    from . import const

    settings.debug = True

    example = StringIO()
    settings._original_stderr = sys.stderr
    sys.stderr = example
    debug('Test message')
    sys.stderr = settings._original_stderr

    assert example.getvalue() == (
        const.USER_COMMAND_MARK +
        u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test message\n')

# Generated at 2022-06-12 10:34:06.876757
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import subprocess
    cmd = "some_command param HERE"
    corrected_command = subprocess.Popen(cmd, shell=True,
                                         stdout=subprocess.PIPE,
                                         stderr=subprocess.PIPE)
    show_corrected_command(corrected_command)
    assert corrected_command.poll()

# Generated at 2022-06-12 10:34:16.791920
# Unit test for function debug
def test_debug():
    from mock import patch
    from io import BytesIO

    with patch('sys.stderr', BytesIO()) as mock_stderr:
        settings.no_colors = False
        debug(u'Test debug')
        settings.debug = False
        debug_time(u'Test debug_time')
        assert mock_stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test debug\n'
        mock_stderr.truncate(0)
        settings.no_colors = True
        debug(u'Test debug')
        assert mock_stderr.getvalue() == ''
        settings.debug = True
        debug_time(u'Test debug_time')
        assert 'Test debug_time took' in mock_stderr

# Generated at 2022-06-12 10:34:22.968816
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    m = mock.mock_open()
    with mock.patch('__builtin__.raw_input', return_value=''), \
            mock.patch('__builtin__.open', m, create=True):
        show_corrected_command('corrected')

# Generated at 2022-06-12 10:34:23.633699
# Unit test for function confirm_text
def test_confirm_text():
    pass

# Generated at 2022-06-12 10:34:24.993402
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('configuration_details')



# Generated at 2022-06-12 10:34:29.826455
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls -la', False))
    sys.stderr.write('\033[F')
    show_corrected_command(CorrectedCommand('ls -la', True))
    sys.stderr.write('\033[F')



# Generated at 2022-06-12 10:34:39.429885
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    import colorama

    # Test case: name and path are empty
    configuration_details = Shell(name="", path="")
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:34:49.329471
# Unit test for function debug
def test_debug():
    def assert_msg_written(msg):
        class FakeStdErr(object):
            def __init__(self):
                self.content = None

            def write(self, content):
                self.content = content
        fake_stderr = FakeStdErr()
        old_stderr = sys.stderr
        try:
            sys.stderr = fake_stderr
            debug(msg)
        finally:
            sys.stderr = old_stderr
        assert u'DEBUG: ' + msg == fake_stderr.content.decode('utf-8')

    settings.debug = True

# Generated at 2022-06-12 10:34:53.019074
# Unit test for function debug_time
def test_debug_time():
    import time
    lst = []
    with debug_time("Time"):
        time.sleep(0.1)
        lst.append("asd")
        time.sleep(0.1)
    # debug("Time")
    if len(lst) != 1:
        raise Exception("TEST_DEBUG_TIME_FAILED")

# Generated at 2022-06-12 10:34:56.169385
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import CorrectedCommand
    show_corrected_command(CorrectedCommand("echo 'hello world!'", True))



# Generated at 2022-06-12 10:35:00.766113
# Unit test for function color
def test_color():

    # Test for color
    assert color(colorama.Fore.GREEN + colorama.Style.BRIGHT) == (
        colorama.Fore.GREEN + colorama.Style.BRIGHT)

    # Test for color with disabled color
    settings.no_colors = True
    assert color(colorama.Fore.GREEN + colorama.Style.BRIGHT) == ''

# Generated at 2022-06-12 10:35:04.784603
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        assert debug('test') == sys.stderr.write(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')
    finally:
        settings.debug = False

# Generated at 2022-06-12 10:35:10.502954
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.conf import DEFAULT_EXECUTOR_CWD
    confirm_text(const.CorrectedCommand(u'script',
                                        cwd=DEFAULT_EXECUTOR_CWD,
                                        side_effect=False))



# Generated at 2022-06-12 10:35:16.223712
# Unit test for function debug_time
def test_debug_time():
    """Unit test for debug_time()"""
    import time
    from datetime import datetime
    from datetime import timedelta
    with debug_time('dummy code'):
        time.sleep(1)
    started = datetime.now()
    with debug_time('dummy code'):
        time.sleep(1)
    ended = datetime.now()
    delta = ended - started
    if delta > timedelta(seconds=1):
        return True
    else:
        return False

# Generated at 2022-06-12 10:35:19.775679
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    with patch('sys.stderr.write') as write:
        from .log import debug_time
        with debug_time('test'):
            pass
        assert 'test took:' in write.call_args[0][0]

# Generated at 2022-06-12 10:35:21.598081
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = ('fuck', ' corrected_command')
    confirm_text(corrected_command)


# Generated at 2022-06-12 10:35:27.683335
# Unit test for function debug_time
def test_debug_time():
    import StringIO
    import time

    buf = StringIO.StringIO()
    sys.stderr = buf

    settings.debug = True

    with debug_time('adding'):
        time.sleep(0.1)
        assert 'adding took: 0.1' in buf.getvalue()

    settings.debug = False

    with debug_time('adding'):
        time.sleep(0.1)
        assert 'adding took: 0.1' not in buf.getvalue()

# Generated at 2022-06-12 10:35:36.643607
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    show_corrected_command(CorrectedCommand('ls -l', False))
    assert sys.stderr.getvalue() == '{}ls -l\n'.format(const.USER_COMMAND_MARK)
    sys.stderr.truncate(0)
    show_corrected_command(CorrectedCommand('ls -l', True))
    assert sys.stderr.getvalue() == '{}ls -l (+side effect)\n'.format(const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:35:39.504367
# Unit test for function confirm_text
def test_confirm_text():
    commands = [
        'git push',
        'git push origin master',
        'rm -rf /'
        ]
    for command in commands:
        confirm_text(CorrectedCommand(command))  # noqa

# Generated at 2022-06-12 10:35:44.718579
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import call, patch
    from . import log

    with patch('thefuck.log.debug') as mock_debug:
        with log.debug_time('msg'):
            pass

        mock_debug.assert_has_calls([
            call(u'msg took: 0:00:00'),
            call('Executed in 0.000s')])



# Generated at 2022-06-12 10:35:53.154932
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    from contextlib import contextmanager
    from thefuck.conf import settings
    from thefuck.rules import Command

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO.StringIO(), StringIO.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    settings.no_colors = True
    command = Command('ls', '', '')
    with captured_output() as (out, err):
        show_corrected_command(command)
    output = out.getvalue

# Generated at 2022-06-12 10:35:55.378103
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from mock import Mock
    corrected_command = Mock(script='ls')
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:36:02.133238
# Unit test for function debug_time
def test_debug_time():
    import time
    for i in range(4):
        with debug_time('test'):
            time.sleep(0.001)

# Generated at 2022-06-12 10:36:05.052255
# Unit test for function color
def test_color():
    colorama.init(strip=True)
    assert color(u'XXX') == u'XXX'
    settings.no_colors = True
    assert color(u'XXX') == u''
    delattr(settings, 'no_colors')
    colorama.deinit()



# Generated at 2022-06-12 10:36:06.706276
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test'):
        pass
    assert datetime.now() - started

# Generated at 2022-06-12 10:36:13.751181
# Unit test for function debug
def test_debug():
    import io
    import sys

    def _set_stderr(stderr):
        sys.stderr = stderr

    def _get_stderr():
        return sys.stderr

    out = io.StringIO()
    with debug_time('test'):
        pass
    _set_stderr(None)
    _set_stderr(out)
    debug('foo')
    stderr = _get_stderr()
    _set_stderr(None)
    _set_stderr(stderr)
    assert 'test took' in out.getvalue()
    assert 'foo' in out.getvalue()

# Generated at 2022-06-12 10:36:21.620307
# Unit test for function confirm_text
def test_confirm_text():
    test_result = (u'fuck shit.py (+side effect) [enter/↑/↓/ctrl+c]'
                   == confirm_text(const.CorrectedCommand(
                    u'fuck shit.py', side_effect=True)))

# Generated at 2022-06-12 10:36:26.826832
# Unit test for function confirm_text
def test_confirm_text():
    from . import fuck
    from .shells import generic

    rule = fuck.Rule('test match', '/bin/echo',
                     lambda c: fuck.FuckResult(changed=True), 'test')
    corrected_command = fuck.FuckResult(
        u'sudo echo oops',
        True,
        generic.And('echo oops', 'sudo echo oops'),
        rule)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:36:28.122237
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'ls /'
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:36:28.516473
# Unit test for function debug
def test_debug():
    debug('test debug')

# Generated at 2022-06-12 10:36:36.289870
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    from .shells.fish import Fish
    from .shells.tcsh import Tcsh
    from .shells.xonsh import Xonsh
    from .shells.powershell import Powershell
    from .shells.auto import Auto
    from .shells.cmd import Cmd

    import shutil
    import os

    def test(shell_cls, confirm_path=True):
        shell = shell_cls(settings)
        assert shell.can_autocorrect
        before = shell.conf

        # Test that autocorrect works
        how_to_configure_alias(before)
        after = shell.conf

        if confirm_path:
            assert os.path.exists(after.path)

# Generated at 2022-06-12 10:36:43.615522
# Unit test for function debug_time
def test_debug_time():
    from mock import patch, MagicMock
    from datetime import timedelta

    with patch('datetime.datetime') as dt, \
            patch('sys.stderr') as stderr:

        settings.debug = True
        dt.now.return_value = MagicMock(spec_set=datetime)

        with debug_time('debugging'):
            dt.now.return_value.__sub__.return_value = timedelta(seconds=3.14)
            pass

        stderr.write.assert_called_once_with(
            u'debugging took: 3.140000 seconds\n')

# Generated at 2022-06-12 10:36:50.433008
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'

# Generated at 2022-06-12 10:36:52.509404
# Unit test for function color
def test_color():
    assert color('red')('foo') == 'foo'
    settings.no_colors = True
    assert color('red')('foo') == ''



# Generated at 2022-06-12 10:36:56.253529
# Unit test for function color
def test_color():
    result = '{prefix}{script}{side_effect}{reset}'.format(
        prefix=const.USER_COMMAND_MARK,
        script='pip instal django',
        side_effect=u' (+side effect)' if True else u'',
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))
    assert result == '>pip instal django (+side effect)'

# Generated at 2022-06-12 10:37:02.619317
# Unit test for function debug
def test_debug():
    from unittest.mock import patch
    from thefuck.shells.bash import Bash, And
    with patch('sys.stderr', new_callable=lambda: And()) as stderr:
        debug(u'Test')
        assert stderr.append.called
        assert u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n' in stderr.append.call_args[0][0]



# Generated at 2022-06-12 10:37:04.577780
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    dummy_cd = {'path': 'file', 'content': 'content', 'reload': 'reload'}
    how_to_configure_alias(dummy_cd)

# Generated at 2022-06-12 10:37:05.138893
# Unit test for function confirm_text
def test_confirm_text():
    pass

# Generated at 2022-06-12 10:37:09.097767
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand

    show_corrected_command(CorrectedCommand(script=u"git push", side_effect=True))
    show_corrected_command(CorrectedCommand(script=u"git push", side_effect=False))



# Generated at 2022-06-12 10:37:12.242425
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO

    stderr = sys.stderr
    sys.stderr = StringIO.StringIO()
    show_corrected_command(object())
    assert '>' in sys.stderr.getvalue()
    sys.stderr = stderr


# Generated at 2022-06-12 10:37:13.276574
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-12 10:37:15.992766
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:37:27.188819
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    import colorama
    colorama.init()

# Generated at 2022-06-12 10:37:28.139476
# Unit test for function debug_time
def test_debug_time():
    with debug_time(__name__):
        pass

# Generated at 2022-06-12 10:37:36.111241
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import timedelta
    from unittest import TestCase

    from . import log
    from .conf import load_settings

    def debug_time_decorator(debug_time):
        def wrapped(msg):
            @contextmanager
            def inner():
                started = datetime.now()
                try:
                    yield
                finally:
                    debug_time(u'{} took: {}'.format(msg, datetime.now() - started))
            return inner()
        return wrapped

    log.debug = debug_time_decorator(log.debug)

    class MockedSettings(object):
        def __init__(self, debug):
            self.debug = debug


# Generated at 2022-06-12 10:37:39.364427
# Unit test for function confirm_text
def test_confirm_text():
    confirmed_command = type('Mock', (object, ), {
        'script': u'$ # echo "foobar"\n$ echo "foobar"',
        'side_effect': False})()
    confirm_text(confirmed_command)

# Generated at 2022-06-12 10:37:40.692279
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)
    confirm_text(1)

# Generated at 2022-06-12 10:37:50.718232
# Unit test for function confirm_text
def test_confirm_text():
    try:
        import StringIO
        out = StringIO.StringIO()
        sys.stdout, sys.stderr = out, out
    except ImportError:
        import io
        out = io.StringIO()
        sys.stdout, sys.stderr = out, out

    import colorama
    colorama.init()
    from thefuck.shells.bash import Bash
    from thefuck import types

    corrected_command = types.CorrectedCommand('ls', True)
    confirm_text(corrected_command)

    Bash.alias = ('fuck',)

# Generated at 2022-06-12 10:37:52.209585
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass


# Generated at 2022-06-12 10:37:57.969929
# Unit test for function color
def test_color():
    assert(color(u'\033[01;31m' + u'Warning!!!' + u'\033[00m')
           == u'\033[01;31m' + u'Warning!!!' + u'\033[00m')
    settings.no_colors = True
    assert(color(u'\033[01;31m' + u'Warning!!!' + u'\033[00m') == '')
    settings.no_colors = False



# Generated at 2022-06-12 10:38:00.261363
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import Config
    from .shells import shell_escape, ZshShell

    assert confirm_text(Config('ls', 'pwd', side_effect=True, shell=ZshShell(),)) == None
    assert confirm_text(Config('ls --help', 'ls -h', False, ZshShell(),)) == None

# Generated at 2022-06-12 10:38:04.037691
# Unit test for function debug_time
def test_debug_time():
    intercepted_debug_output = None

    def debug(msg):
        global intercepted_debug_output
        intercepted_debug_output = msg

    with debug_time('call'):
        pass

    assert intercepted_debug_output == 'call took: 0:00:00.000001'


# Generated at 2022-06-12 10:38:14.704814
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from io import StringIO

    try:
        old_stdout = sys.stdout
        sys.stdout = mystdout = StringIO()
        how_to_configure_alias(None)
        sys.stdout = old_stdout
        return mystdout.getvalue()
    finally:
        sys.stdout = old_stdout



# Generated at 2022-06-12 10:38:16.997110
# Unit test for function color
def test_color():
    assert color('hello') == ''
    settings.no_colors = False
    assert color('hello') == 'hello'


# Generated at 2022-06-12 10:38:19.051004
# Unit test for function color
def test_color():
    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert color(colorama.Style.BRIGHT) == ''

# Generated at 2022-06-12 10:38:22.163758
# Unit test for function debug
def test_debug():
    from tests.utils import support_adapted_configs

    with support_adapted_configs():
        settings.reset(False)
        settings.debug = True
        debug('test')
        settings.debug = False
        debug('test')

# Generated at 2022-06-12 10:38:31.217527
# Unit test for function confirm_text
def test_confirm_text():
    from mock import call
    from unittest import TestCase, mock

    from thefuck.utils import confirm_text

    global sys
    with mock.patch.object(sys, 'stderr', mock.Mock()) as mock_stderr:
        confirm_text(CorrectedCommand(script='ls', side_effect=False))
        confirm_text(CorrectedCommand(script='ls', side_effect=True))


# Generated at 2022-06-12 10:38:36.869081
# Unit test for function debug
def test_debug():
    import sys
    from contextlib import contextmanager
    from io import BytesIO

    @contextmanager
    def capture():
        old, sys.stderr = sys.stderr, BytesIO()
        try:
            yield sys.stderr
        finally:
            sys.stderr = old

    with capture() as stream:
        debug(u'Foo bar')
    assert u'DEBUG: Foo bar\n' == stream.getvalue().decode('utf-8')



# Generated at 2022-06-12 10:38:38.434910
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from contextlib import contextmanager
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:38:49.210876
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(delete=False) as fp:
        content = fp.name

    configuration_details = type(
        'ConfigurationDetails',
        (object,),
        {'content': content,
         'path': '/this/path',
         'reload': 'zsh-reload',
         'can_configure_automatically': True})

    how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:39:00.906989
# Unit test for function debug_time
def test_debug_time():
    import re
    import mock
    import datetime

    with mock.patch('sys.stderr') as stderr:
        with debug_time(u'Hello'):
            pass
        assert re.match(r'DEBUG: Hello took: \d+:\d+:\d+\.\d+',
                        stderr.write.call_args[0][0])

    from contextlib import nested
    with nested(mock.patch('datetime.datetime'),
                mock.patch('sys.stderr')) as (datetime, stderr):
        datetime.now.return_value = datetime.datetime(
                                                2014, 4, 1, 0, 0, 0, 0)
        with debug_time(u'Hello'):
            pass
            datetime.now.return_value = datetime.dat

# Generated at 2022-06-12 10:39:03.103254
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    confirm_text(Shell.from_shell_command(Shell, u'ls').get_script_from_history(1))

# Generated at 2022-06-12 10:39:11.655777
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr = StringIO()
    confirm_text('test command')
    assert sys.stderr.getvalue() == '> test command [enter/↑/↓/ctrl+c]\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:39:17.243426
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from .utils import escape_unsafe_symbols
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    for shell in (Bash(), Zsh()):
        show_corrected_command(CorrectedCommand(
            'ls -al',
            shell.get_history()[0]))
        show_corrected_command(CorrectedCommand(
            'ls -al',
            shell.get_history()[0],
            side_effect=True))



# Generated at 2022-06-12 10:39:20.688988
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(script='ls', side_effect=False) == u'ls [enter/↑/↓/ctrl+c]'
    assert confirm_text(script='ls', side_effect=True) == u'ls +side effect'


# Generated at 2022-06-12 10:39:22.369484
# Unit test for function color
def test_color():
    assert color(u'a') == u''

# Generated at 2022-06-12 10:39:27.388802
# Unit test for function color
def test_color():
    colorama.init(autoreset=True)
    assert color('\x1b[31mtest\x1b[39m') == '\x1b[31mtest\x1b[39m'
    settings.no_colors = True
    assert color('\x1b[31mtest\x1b[39m') == ''

# Generated at 2022-06-12 10:39:30.673963
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # test when alias not configured and can_configure_automatically is False
    how_to_configure_alias(None)
    # # test when alias not configured and can_configure_automatically is True
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:39:34.414809
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    settings.no_colors = True
    settings.emulate_tty = True
    confirm_text(CorrectedCommand(script='ls'))



# Generated at 2022-06-12 10:39:39.102825
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == ''
    settings.no_colors = False
    assert color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT) == '\x1b[41m\x1b[37m\x1b[1m'

# Generated at 2022-06-12 10:39:40.310068
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_time'):
        pass



# Generated at 2022-06-12 10:39:46.019470
# Unit test for function debug
def test_debug():
    class TestStdErr(object):
        def __init__(self):
            self.errors = []

        def write(self, text):
            self.errors.append(text)

    settings.debug = True
    sys.stderr = TestStdErr()
    debug('debug')
    sys.stderr.write('test')
    assert len(sys.stderr.errors) == 2
    settings.debug = False



# Generated at 2022-06-12 10:39:52.023633
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(command.Command('t', '')) == 'Corrected command: t'

# Generated at 2022-06-12 10:39:54.751696
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import os
    sys.stdout = open(os.devnull, 'w')
    confirm_text('')
    sys.stdout = sys.__stdout__

# Generated at 2022-06-12 10:39:56.015353
# Unit test for function color
def test_color():
    assert len(color(colorama.Style.BRIGHT)) > 0

# Generated at 2022-06-12 10:39:57.532530
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = ['corrected command']
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:40:00.586192
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = const.ConfigurationDetails(
        path='.zshrc',
        content='fuck = python',
        can_configure_automatically=False,
        reload='')
    assert how_to_configure_alias(configuration_details) == None


# Generated at 2022-06-12 10:40:03.520420
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    import time

    with debug_time('test'):
        time.sleep(0.2)
    assert (datetime.now() - started).total_seconds() >= 0.2

# Generated at 2022-06-12 10:40:04.696960
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:40:08.419097
# Unit test for function color
def test_color():
    assert color(u'foo') == u'foo'
    assert color('') == ''
    settings.no_colors = True
    assert color(u'foo') == ''
    assert color('') == ''

# Generated at 2022-06-12 10:40:14.365961
# Unit test for function debug
def test_debug():
    from tests.utils import support_encoding, temp_dir

    with support_encoding():
        with temp_dir() as temp_dir_path:
            settings.config_path = temp_dir_path
            settings.debug = True
            debug(u'функция работает')
            assert open(settings.debug_log_file).read().startswith(
                u'DEBUG: функция работает\n')
            settings.debug = False

# Generated at 2022-06-12 10:40:18.158870
# Unit test for function debug
def test_debug():
    from tests.utils import capture_stderr
    with capture_stderr() as stderr:
        debug(4)
        assert '4' in stderr.getvalue()
        debug('hi')
        assert 'hi' in stderr.getvalue()



# Generated at 2022-06-12 10:40:32.939886
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from six import StringIO
    from .conf import get_settings

    settings = get_settings()
    settings.debug = True

    stderr = StringIO()
    with contextmanager(lambda: (yield stderr)) as fake_stderr:
        debug(u'foo')
    assert u'DEBUG: foo\n' == fake_stderr.getvalue()

    stderr = StringIO()
    with contextmanager(lambda: (yield stderr)) as fake_stderr:
        settings.debug = False
        debug(u'foo')
    assert u'' == fake_stderr.getvalue()

# Generated at 2022-06-12 10:40:35.406053
# Unit test for function confirm_text
def test_confirm_text():
    # User choose confirm
    confirmed = confirm_text('ls -l')
    assert confirmed == True

    # User choose cancel
    confirmed = confirm_text('ls -l')
    assert confirmed == False

# Generated at 2022-06-12 10:40:35.966789
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert True

# Generated at 2022-06-12 10:40:37.881710
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import CorrectedCommand
    show_corrected_command(CorrectedCommand(u"ls", u"ls", True))

# Generated at 2022-06-12 10:40:39.555705
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls'
    show_corrected_command(corrected_command)


# Generated at 2022-06-12 10:40:43.084300
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    const.USER_CONFIGURATION_DETAILS = None
    how_to_configure_alias(None)
    assert const.USER_CONFIGURATION_DETAILS


# Unit tests for function already_configured

# Generated at 2022-06-12 10:40:46.834831
# Unit test for function debug_time
def test_debug_time():
    import time

    def long_function(time_to_sleep):
        time.sleep(time_to_sleep)
    t = time.time()
    with debug_time(u'long function'):
        long_function(0.2)
    assert time.time() - t >= 0.2


# Generated at 2022-06-12 10:40:52.326239
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import Mock
    from .utils import _debug_time

    sys.stderr = Mock()

    _debug_time('Hi', timedelta(minutes=2, seconds=1))
    sys.stderr.write.assert_called_with(
        '\x1b[34m\x1b[1mDEBUG:\x1b[0m Hi took: 2:01:00\n')



# Generated at 2022-06-12 10:41:02.320542
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect

    import StringIO
    stderr = sys.stderr
    sys.stderr = StringIO.StringIO()

    show_corrected_command(CorrectedCommand('ls'))
    assert sys.stderr.getvalue() == u'$ ls\n'

    show_corrected_command(CorrectedCommand('ls -la', side_effect=True))
    assert sys.stderr.getvalue() == u'$ ls\n$ ls -la (+side effect)\n'

    sys.stderr = stderr

# Generated at 2022-06-12 10:41:04.376089
# Unit test for function debug_time
def test_debug_time():
    debug_state = settings.debug
    settings.debug = True
    debug_time('foooo')
    settings.debug = debug_state


# Generated at 2022-06-12 10:41:15.235167
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'clean'
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:41:23.757742
# Unit test for function confirm_text
def test_confirm_text():
    settings.side_effect = True
    settings.no_colors = False
    sys.stderr = open('test_confirm_text', 'w')
    confirm_text(u'git push')
    settings.side_effect = False
    confirm_text(u'git push')
    settings.no_colors = True
    confirm_text(u'git push')

# Generated at 2022-06-12 10:41:25.022328
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    global settings
    settings.no_colors = False

# Generated at 2022-06-12 10:41:27.367285
# Unit test for function debug_time
def test_debug_time():
    with debug_time('some debug msg'):
        import time
        import random
        time.sleep(random.randint(0, 20) / 100)



# Generated at 2022-06-12 10:41:28.441117
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('some operation'):
        time.sleep(2)

# Generated at 2022-06-12 10:41:30.207186
# Unit test for function debug
def test_debug():
    debug('foo')



# Generated at 2022-06-12 10:41:34.264727
# Unit test for function debug_time
def test_debug_time():
    import time

# Generated at 2022-06-12 10:41:37.382304
# Unit test for function debug
def test_debug():
    from mock import patch

    with patch('sys.stderr', autospec=True) as stderr:
        debug('foo')
        stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

# Generated at 2022-06-12 10:41:47.582928
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # There are cases when we need to configure manually
    x = u'Please put {bold}{content}{reset} in your {bold}{path}{reset} and apply changes with {bold}{reload}{reset} or restart your shell.'

# Generated at 2022-06-12 10:41:49.986343
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    assert settings.no_colors
    settings.no_colors = False
    assert color('foo') == 'foo'

# Generated at 2022-06-12 10:42:03.538676
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from mock import Mock
    corrected_command = Mock()
    corrected_command.script = "script"
    corrected_command.side_effect = None
    show_corrected_command(corrected_command)
    corrected_command.side_effect = "side effect"
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:42:09.642521
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import mock
    show_corrected_command(mock.Mock(
        script='git stash',
        side_effect=False)) == u'fuck git stash'
    show_corrected_command(mock.Mock(
        script='git stash',
        side_effect=True)) == u'fuck git stash +side effect'
    show_corrected_command(mock.Mock(
        script='git stash',
        side_effect=True)) == u'fuck git stash +side effect'