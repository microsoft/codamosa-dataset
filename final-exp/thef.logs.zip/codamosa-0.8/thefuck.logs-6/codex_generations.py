

# Generated at 2022-06-12 10:32:16.372496
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import Config
    from .configurer import ConfigurationDetails
    config = Config(reload_command='reload command',
                    rules_dir='rules_dir',
                    filename='filename',
                    can_configure_automatically=True,
                    home_dir='home_dir')
    configuration_details = ConfigurationDetails('content',
                                                 'path',
                                                 'reload',
                                                 config.can_configure_automatically)
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:32:23.492814
# Unit test for function debug
def test_debug():
    import mock
    import sys
    from contextlib import contextmanager

    @contextmanager
    def styled(style, *values):
        yield values

    with mock.patch('sys.stderr.write') as f:
        with mock.patch('thefuck.shells.get_all_executables',
                        return_value=['sh']):
            debug('helloworld')
    sys.stderr.write.assert_called_with(u'\033[34m\033[1mDEBUG:\033[0m helloworld\n')

# Generated at 2022-06-12 10:32:24.815142
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test') as time:
        time.sleep(0.1)

# Generated at 2022-06-12 10:32:27.033226
# Unit test for function color
def test_color():
    assert color('text') == ''
    settings.no_colors = False
    assert color('text') == 'text'



# Generated at 2022-06-12 10:32:29.955148
# Unit test for function debug_time
def test_debug_time():
    from mock import call
    from .debug import debug
    from .debug import debug_time
    with debug_time('msg'):
        pass
    assert debug.mock_calls[0] == call('msg took: 0:00:00.000000')

# Generated at 2022-06-12 10:32:37.435076
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    result = u"""Seems like \x1b[1mfuck\x1b[22m alias isn't configured!
Please put \x1b[1mwrite to ~/.fuck\x1b[22m in your \x1b[1m~/.bashrc\x1b[22m and apply changes with \x1b[1msource ~/.bashrc\x1b[22m or restart your shell.
Or run \x1b[1mfuck\x1b[22m a second time to configure it automatically.
More details - https://github.com/nvbn/thefuck#manual-installation"""
    how_to_configure_alias(result)

# Generated at 2022-06-12 10:32:39.236651
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command('hello hello')
    confirm_text('hello hello')

# Generated at 2022-06-12 10:32:41.821688
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git pull') == '''\
git pull [enter/↑/↓/ctrl+c]'''
    assert confirm_text('ls') == '''\
ls [enter/↑/↓/ctrl+c]'''



# Generated at 2022-06-12 10:32:47.461207
# Unit test for function debug_time
def test_debug_time():
    from thefuck.shells.bash import get_history
    import mock
    def get_history():
        return [{u'command': u'ls -l /tmp/',
                 u'_id': u'1418364043500'},
                {u'command': u'grep -i tmp',
                 u'_id': u'1418364204307'}]

    with debug_time('test'), mock.patch('sys.stderr') as stderr:
        get_history()
        assert u'get_history took' in stderr.write.call_args[0][0]

# Generated at 2022-06-12 10:32:48.422708
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text("This is a test")

# Generated at 2022-06-12 10:33:00.397319
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Shell
    assert show_corrected_command(Shell('', '', '')('', '')
                                  .from_shell('', '')('foo', '')) == u'[sudo] password for user: ➜ foo\n'
    assert show_corrected_command(Shell('', '', '')('', '')
                                  .from_shell('', '')('foo --bar=baz', '')) == u'[sudo] password for user: ➜ foo --bar=baz\n'
    assert show_corrected_command(Shell('', '', '')('', '')
                                  .from_shell('', '')('foo --bar=baz', '').side_effect(True)) == u'[sudo] password for user: ➜ foo --bar=baz (+side effect)\n'

# Generated at 2022-06-12 10:33:02.283211
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == 'test'

# Generated at 2022-06-12 10:33:04.047543
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('best command', ''))



# Generated at 2022-06-12 10:33:11.226089
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class MockConfigurationDetails():
        def __init__(self, **kwargs):
            self.reload = kwargs['reload']
            self.content = kwargs['content']
            self.path = kwargs['path']
            self.can_configure_automatically = kwargs['can_configure_automatically']

    mock_configuration_details_1 = MockConfigurationDetails(
        reload='bashrc',
        content='eval $(thefuck --alias)',
        path='~/.bashrc',
        can_configure_automatically=True)
    mock_configuration_details_2 = MockConfigurationDetails(
        reload='bashrc',
        content='eval $(thefuck --alias)',
        path='~/.bashrc',
        can_configure_automatically=False)
    mock_

# Generated at 2022-06-12 10:33:15.354607
# Unit test for function color
def test_color():
    assert color('red' + 'bold') == '\x1b[31m\x1b[1m'
    assert color('red' + 'bold') != 'redbold'
    settings.no_colors = True
    assert color('red' + 'bold') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:33:16.850119
# Unit test for function debug_time
def test_debug_time():
    debug_time(lambda: None)

# Generated at 2022-06-12 10:33:22.617953
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'error') == color(colorama.Fore.RED + 'error')
    assert color(colorama.Fore.RED + 'error') != color(colorama.Fore.RED + 'error1')
    assert color(colorama.Fore.RED + 'error') != color(colorama.Fore.RED)

# Generated at 2022-06-12 10:33:26.257616
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import ConfigurationDetails
    print(how_to_configure_alias(ConfigurationDetails('', None, False)))
    print(how_to_configure_alias(ConfigurationDetails('', None, True)))
    print(how_to_configure_alias(ConfigurationDetails('', '', True)))
    print(how_to_configure_alias(None))

# Generated at 2022-06-12 10:33:30.869381
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    output = StringIO()
    sys.stderr = output
    debug('test_debug')
    assert output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test_debug\n'

# Generated at 2022-06-12 10:33:33.768423
# Unit test for function debug_time
def test_debug_time():
    from .utils import debug_time
    from .conf import settings
    settings.debug = True
    debug_time('test')

# Generated at 2022-06-12 10:33:37.433281
# Unit test for function debug_time
def test_debug_time():
    pass

# Generated at 2022-06-12 10:33:42.668601
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Command():
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(Command('ls -al', True))
    show_corrected_command(Command('ls -al', False))



# Generated at 2022-06-12 10:33:50.326087
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = corrected_command_class(script='ls -lah --color=auto')(
        script='ls -lah --color=always')

# Generated at 2022-06-12 10:33:52.863358
# Unit test for function color
def test_color():
    assert color(u'красный') == u''
    assert color(u'красный') != u'красный'

# Generated at 2022-06-12 10:33:54.865303
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = corrected_command.CorrectedCommand(
        'echo "Hello, World!"', False)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:34:00.730398
# Unit test for function confirm_text
def test_confirm_text():
    from mock import patch
    from thefuck.utils import confirm_text, UserQuitException

    with patch('thefuck.utils.raw_input') as raw_input:
        raw_input.side_effect = [
            '\n', '\x1b[A', '', '\x1b[B', '\x03']

        for _ in range(5):
            try:
                confirm_text('some command')
            except UserQuitException:
                pass

# Generated at 2022-06-12 10:34:06.581317
# Unit test for function debug
def test_debug():
    import mock
    import thefuck
    settings.debug = True
    with mock.patch('thefuck.utils.sys.stderr') as stderr:
        thefuck.utils.debug('test')
        stderr.write.assert_called_with(color(colorama.Fore.BLUE +
                                              colorama.Style.BRIGHT) +
                                        'DEBUG:' +
                                        color(colorama.Style.RESET_ALL) +
                                        ' test\n')



# Generated at 2022-06-12 10:34:12.214247
# Unit test for function debug
def test_debug():
    from io import StringIO
    from unittest.mock import patch
    from thefuck.settings import Config
    Config.load(None)
    Config.no_colors = True
    Config.debug = True

    with StringIO() as buf, patch('sys.stderr', buf):
        debug('message')
    output = buf.getvalue()

    assert output.strip() == 'DEBUG: message'



# Generated at 2022-06-12 10:34:16.084807
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_shell_info

    configuration_details = {
        "can_configure_automatically": False,
        "path": "~/.bashrc",
        "content": "alias = fuck",
    }
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:34:17.085329
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(None)

# Generated at 2022-06-12 10:34:27.966874
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('sys.stderr') as stderr_mock:
        debug('test')
        expected_format = color(colorama.Fore.BLUE) \
                          + color(colorama.Style.BRIGHT) \
                          + 'DEBUG:' \
                          + color(colorama.Style.RESET_ALL) \
                          + ' test\n'
        stderr_mock.write.assert_called_with(expected_format)

## Init colorama
colorama.init()

# Generated at 2022-06-12 10:34:33.583003
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.shells import get_shell
    from thefuck.shells.bash import Bash
    get_shell().get_alias = lambda: 'fuck'
    assert confirm_text(Bash().CorrectedCommand(
        script='ls', side_effect=True)) == const.USER_COMMAND_MARK + \
        'ls (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:34:36.852148
# Unit test for function color
def test_color():
    # Tests that color() just returns what's given to it when settings.no_colors is True.
    settings.no_colors = True
    assert color("foobar") == "foobar"
    settings.no_colors = False


# Generated at 2022-06-12 10:34:42.270730
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import Settings
    from . import utils
    from .utils import TEST_TYPE

    settings = Settings(debug=True, no_colors=True)
    with utils.debug_time('test'):
        utils.sleep(timedelta(seconds=1))
    assert TEST_TYPE == 'test took: 0:00:01.002000\n'

# Generated at 2022-06-12 10:34:43.994783
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:34:45.831100
# Unit test for function color
def test_color():
    assert colorama.Style.BRIGHT in color(colorama.Style.BRIGHT)
    assert colorama.Style.BRIGHT not in color('')



# Generated at 2022-06-12 10:34:49.530798
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import unittest
    class TestShowCorrectedCommand(unittest.TestCase):
        def test_show_corrected_command(self):
            show_corrected_command('SYSTEM')
            show_corrected_command('SYSTEM', True)
    unittest.main()

# Generated at 2022-06-12 10:34:56.266133
# Unit test for function debug
def test_debug():
    old_stderr = sys.stderr
    sys.stderr = fake_stderr = []
    try:
        debug(u'Привет, мир!')
        assert fake_stderr == [
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Привет, мир!\n']
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-12 10:34:58.609444
# Unit test for function color
def test_color():
    assert color('red text') == '\x1b[31mred text\x1b[0m'
    assert color('') == ''



# Generated at 2022-06-12 10:34:59.570054
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-12 10:35:07.694223
# Unit test for function color
def test_color():
    class Test:
        no_colors = True

    settings.no_colors = Test.no_colors
    assert color(u'{test}'.format(test=u'Test')) == u''
    settings.no_colors = False
    assert color(u'{test}'.format(test=u'Test')) == u'Test'

# Generated at 2022-06-12 10:35:15.450944
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    conf_details = [const.ConfigurationDetails(
        u'~/.bashrc', u'. ~/.bashrc', True, False)]
    correct_output = [u'Seems like fuck alias isn\'t configured!',
                      u'Please put . ~/.bashrc in your ~/.bashrc and apply\
                       changes with . ~/.bashrc or restart your shell.',
                      u'Or run fuck a second time to configure it automatically.',
                      u'More details - https://github.com/nvbn/thefuck#manual-installation']
    for num, line in enumerate(conf_details):
        assert how_to_configure_alias(line) == correct_output[num]



# Generated at 2022-06-12 10:35:17.784988
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stdin = open('/dev/tty')
    sys.stdout = open('/dev/tty')
    sys.stderr = open('/dev/tty')
    how_to_configure_alias(None)


# Generated at 2022-06-12 10:35:18.813951
# Unit test for function debug

# Generated at 2022-06-12 10:35:24.201365
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import Shell

    shell = Shell(None)

    class Command(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    corrected_command = Command('ls', False)
    show_corrected_command(corrected_command)



# Generated at 2022-06-12 10:35:31.411985
# Unit test for function confirm_text
def test_confirm_text():
    '''
        If confirm_text() works, it should give the output:
        'fuck simple-command (+side effect) [enter/↑/↓/ctrl+c]'
    '''
    from thefuck.types import CorrectedCommand
    corrected_command = CorrectedCommand('simple-command', True)
    import sys
    current_stdout = sys.stdout
    sys.stderr = open('stdout_test.txt', 'w')
    confirm_text(corrected_command)
    sys.stdout = current_stdout
    with open('stdout_test.txt') as f:
        out = f.read()
        assert out == 'fuck simple-command (+side effect) [enter/↑/↓/ctrl+c]', 'confirm_text() failed to give stdout'

# Generated at 2022-06-12 10:35:32.342971
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('') == ''

# Generated at 2022-06-12 10:35:35.753449
# Unit test for function confirm_text
def test_confirm_text():
    init_locale = 'fr_FR.UTF-8'
    test_command = u'git push -f origin dev'
    confirm_text(test_command)



# Generated at 2022-06-12 10:35:36.351544
# Unit test for function debug_time
def test_debug_time():
    debug("test")

# Generated at 2022-06-12 10:35:37.319774
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()

# Generated at 2022-06-12 10:35:43.030820
# Unit test for function debug
def test_debug():
    sys.stderr = open('/dev/null', 'w')
    debug(u'Тест')
    sys.stderr.close()

# Generated at 2022-06-12 10:35:52.197397
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from . import const
    from .shells import Shell

    def get_configuration_details(**kwargs):
        return ConfigurationDetails(const.SETTINGS_PATH,
                                    const.GIT_REPO,
                                    Shell('bash'),
                                    **kwargs)

    # Expected result for unknown shell
    how_to_configure_alias(get_configuration_details(can_configure_automatically=False))

# Generated at 2022-06-12 10:35:55.906156
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .conf import settings
    from . import const

    const.USER_COMMAND_MARK = '>'
    settings.debug = True
    with debug_time('msg'):
        pass



# Generated at 2022-06-12 10:35:59.245606
# Unit test for function color
def test_color():
    assert color('\033[1;37;41m') == '\033[1;37;41m'
    with settings(no_colors=True):
        assert color('\033[1;37;41m') == ''

# Generated at 2022-06-12 10:36:07.338128
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .rules import get_new_command
    from .shells import Bash

    before = StringIO()
    after = StringIO()

    @contextmanager
    def mock_open_files():
        try:
            sys.stderr = before
            yield
        finally:
            sys.stderr = after

    def test_execution(mocker):
        with mock_open_files():
            settings.debug = True
            debug('foo')
            assert before.getvalue() == u''
            assert after.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[22m\x1b[0m foo\n'

        with mock_open_files():
            settings.debug = True
            debug('foo\nbar')

# Generated at 2022-06-12 10:36:11.472665
# Unit test for function debug_time
def test_debug_time():
    from mock import Mock
    from datetime import timedelta
    mock_stderr = Mock()
    sys.stderr = mock_stderr

    with debug_time('msg'):
        pass
    mock_stderr.write.assert_called_with(u'msg took: {}\n'.format(timedelta()))

# Generated at 2022-06-12 10:36:12.801255
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(show_corrected_command("ls"))


# Generated at 2022-06-12 10:36:14.438165
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'

# Generated at 2022-06-12 10:36:16.217667
# Unit test for function confirm_text
def test_confirm_text():
    assert '\033[1K\r' in confirm_text('sudo ')



# Generated at 2022-06-12 10:36:18.318767
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # Test if alias is not configured
    configuration_details = None

    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:36:24.866807
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'ls'
    show_corrected_command(corrected_command)
    assert const.USER_COMMAND_MARK + 'ls' in sys.stderr.getvalue()

# Generated at 2022-06-12 10:36:33.803343
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import confirm_text
    from .conf import settings
    from . import const
    import colorama

    from mock import patch, Mock
    settings.no_colors = False

    with patch('os.getenv', Mock(return_value='80')):
        confirm_text(Mock(script='ls', side_effect=False)) ==\
            (const.USER_COMMAND_MARK + 'ls [enter/↑/↓/ctrl+c]')

    with patch('os.getenv', Mock(return_value='140')):
        confirm_text(Mock(script='ls', side_effect=False)) ==\
            (const.USER_COMMAND_MARK + 'ls [enter/↑/↓/ctrl+c]')


# Generated at 2022-06-12 10:36:35.398414
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('bar') == ''

# Generated at 2022-06-12 10:36:36.508967
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command('ls') == 'ls'

# Generated at 2022-06-12 10:36:37.570119
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    assert True

# Generated at 2022-06-12 10:36:44.013101
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .conf import Configuration
    from .rules.python import match, get_new_command
    import re
    import mock
    import sys

    class FakeCorrectedCommand(object):
        script = 'echo "Hello world!"'
        side_effect = False

    with mock.patch('sys.stdout', new_callable=StringIO) as mock_stdout:
        sys.stdout = mock_stdout
        confirm_text(FakeCorrectedCommand)
        sys.stdout = sys.__stdout__
        assert u'\x1b[1K\r' in mock_stdout.getvalue()
        assert u'\x1b[31m' in mock_stdout.getvalue()
        assert u'\x1b[0m' in mock_stdout.getvalue()


# Generated at 2022-06-12 10:36:46.364125
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(u'ls') == const.USER_COMMAND_MARK + u'ls' + u' ' + u'[enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:36:48.144203
# Unit test for function debug
def test_debug():
    assert u'\033[1K\r' not in debug_time(u'test').next()

# Generated at 2022-06-12 10:36:50.956979
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    a=CorrectedCommand(script="pwd", side_effect=False)
    show_corrected_command(a)


# Generated at 2022-06-12 10:36:54.219168
# Unit test for function debug
def test_debug():
    output = []
    original_stderr = sys.stderr
    sys.stderr = type('FakeStderr', (), {'write': lambda x: output.append(x)})
    debug('foo')
    assert u'DEBUG: foo\n' in output
    sys.stderr = original_stderr

# Generated at 2022-06-12 10:37:05.937251
# Unit test for function debug
def test_debug():
    from mock import patch
    from thefuck.shells.get_aliases import Which

    with patch('thefuck.utils.settings._get_shell') as shell, \
            patch('os.path.expanduser') as expanduser, \
            patch('subprocess.check_output') as check_output:
        shell.return_value = Which(alias_path='/foo/.bash_aliases',
                                   which_path='/bar/which')
        expanduser.return_value = '~'
        check_output.return_value = 'python 2.7.10'

        version('3.3', '2.7.10', 'bash 3.2')
        shell.assert_called_once_with()
        expanduser.assert_called_once_with('~/.bash_aliases')
        check_output.assert_called

# Generated at 2022-06-12 10:37:11.137701
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class FakeConfigurationDetails(object):
        def __init__(self, can_configure_automatically):
            self.can_configure_automatically = can_configure_automatically

    assert how_to_configure_alias(None) == None
    assert how_to_configure_alias(FakeConfigurationDetails(False)) == None
    assert how_to_configure_alias(FakeConfigurationDetails(True)) == None

# Generated at 2022-06-12 10:37:21.010208
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    import sys
    saved_stdout = sys.stdout

# Generated at 2022-06-12 10:37:21.814190
# Unit test for function debug
def test_debug():
    debug('debug message')

# Generated at 2022-06-12 10:37:24.668850
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    user_config_details = ("~/.config/fish/config.fish", "~/.config/fish/")
    how_to_configure_alias(user_config_details)


# Generated at 2022-06-12 10:37:27.952966
# Unit test for function show_corrected_command
def test_show_corrected_command():
    const.USER_COMMAND_MARK = u'$'
    show_corrected_command('git checkout master')
    show_corrected_command('git checkout master', '')

# Generated at 2022-06-12 10:37:30.335493
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)


if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:37:37.545882
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import io
    import mock

    mock_stdout = io.StringIO()
    mock_stderr = io.StringIO()

    sys.stdout = mock_stdout
    sys.stderr = mock_stderr

    with mock.patch('thefuck.utils.conf.settings.no_colors', True):
        show_corrected_command(mock.Mock())

    assert mock_stdout.getvalue() == ''
    assert mock_stderr.getvalue() == u'$ echo "fsck"\n'

    with mock.patch('thefuck.utils.conf.settings.no_colors', False):
        show_corrected_command(mock.Mock())

    assert mock_stdout.getvalue() == ''

# Generated at 2022-06-12 10:37:38.399242
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)


# Generated at 2022-06-12 10:37:42.496474
# Unit test for function debug
def test_debug():
    class Stderr(object):
        def __init__(self):
            self.stderr = ''

        def write(self, value):
            self.stderr += value

    stderr = Stderr()
    old_debug = settings.debug

    settings.debug = True
    try:
        debug('hello debug!')
        assert stderr.stderr == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hello debug!\n'
    finally:
        settings.debug = old_debug


# Generated at 2022-06-12 10:37:48.075202
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert (show_corrected_command(command) ==
            u'[command] git lestart master\n')



# Generated at 2022-06-12 10:37:49.426576
# Unit test for function debug_time
def test_debug_time():
    with debug_time('TEST'):
        print('TEST')



# Generated at 2022-06-12 10:37:53.288645
# Unit test for function debug
def test_debug():
    from thefuck.shells import Shell
    from thefuck.shells.bash import Bash
    from thefuck.shells.fish import Fish
    shell = Shell(Bash(), Fish())
    settings.no_colors = False
    settings.debug = True
    debug("This is debug")



# Generated at 2022-06-12 10:37:57.891559
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Print command
    show_corrected_command(const.CorrectedCommand('ls'))
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'ls' + '\n'

    # Print command with side effect
    show_corrected_command(const.CorrectedCommand('ls', 'ls -l'))
    assert sys.stderr.getvalue() == const.USER_COMMAND_MARK + 'ls' + ' (+side effect)' + '\n'

    # Clear the buffer
    sys.stderr = StringIO()

# Generated at 2022-06-12 10:37:59.314330
# Unit test for function debug
def test_debug():
    assert repr(debug('test text')) == '<function debug at 0x....>'

# Generated at 2022-06-12 10:38:00.290538
# Unit test for function debug
def test_debug():
    assert debug(u'hudolej') == None

# Generated at 2022-06-12 10:38:04.249702
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import pytest
    details = namedtuple('HowTo', ('path', 'content',
                                   'reload', 'can_configure_automatically'))
    assert pytest.raises(SystemExit, how_to_configure_alias(details('', '', '', False)))



# Generated at 2022-06-12 10:38:05.933530
# Unit test for function color
def test_color():
    # color is just a wrapper of ansi escape codes, so we should just check
    # that this codes appear in output
    assert color('something') != 'something'

# Generated at 2022-06-12 10:38:10.884955
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.utils import CorrectedCommand
    import mock

    with mock.patch('sys.stderr.write') as write:
        show_corrected_command(
            CorrectedCommand('git push origin foo', ''))
    write.assert_called_with(
        u'{}git push origin foo\n'.format(const.USER_COMMAND_MARK))



# Generated at 2022-06-12 10:38:11.944004
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(.8)

test_debug_time()

# Generated at 2022-06-12 10:38:25.074394
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells.base import Command

    show_corrected_command(Command('ls', '', ''))
    sys.stderr.seek(0)
    assert sys.stderr.read() == u'{0}ls{1}\n'.format(
        color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL))

    sys.stderr.truncate(0)
    show_corrected_command(Command('ls', '', '', True))
    sys.stderr.seek(0)
    assert sys.stderr.read() == u'{0}ls{1} (+side effect)\n'.format(
        color(colorama.Style.BRIGHT), color(colorama.Style.RESET_ALL))



# Generated at 2022-06-12 10:38:29.107518
# Unit test for function debug
def test_debug():
    import StringIO
    result = StringIO.StringIO()
    sys.stderr = result
    debug('test debug message')

# Generated at 2022-06-12 10:38:30.961129
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('ls')

# Generated at 2022-06-12 10:38:38.995660
# Unit test for function debug_time
def test_debug_time():
    from collections import Counter
    from datetime import timedelta
    from os.path import join, dirname, pardir
    import random
    import string
    from tempfile import mkdtemp

    from .utils import wrap_settings
    from .main import main

    possibilities = string.ascii_letters + string.digits
    str_ = ''.join(random.choice(possibilities)
                   for _ in range(random.randint(1, 20)))
    debug_log = join(mkdtemp(), 'thefuck.log')

# Generated at 2022-06-12 10:38:40.509577
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')


# Generated at 2022-06-12 10:38:42.140204
# Unit test for function debug
def test_debug():
    fake_stderr = []
    with debug_time('message'):
        pass



# Generated at 2022-06-12 10:38:47.302109
# Unit test for function confirm_text
def test_confirm_text():
    import unittest, os
    class TestConfirmText(unittest.TestCase):
        def test_confirm(self):
            os.system("clear")
            print("User Command:")
            confirm_text("fuck")
            print("User Options:")
            show_corrected_command("fuck")
    unittest.main()

# Generated at 2022-06-12 10:38:51.676562
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    from io import StringIO

    old_stderr = sys.stderr
    sys.stderr = StringIO()

    show_corrected_command(CorrectedCommand(script='ls',
                                            side_effect=False))
    output = sys.stderr.getvalue()

    sys.stderr = old_stderr

    assert output == const.USER_COMMAND_MARK + 'ls\n'

# Generated at 2022-06-12 10:38:54.325722
# Unit test for function debug
def test_debug():
    debug(u'Тест работает')
    debug(u'Test is working')

# Generated at 2022-06-12 10:39:02.287731
# Unit test for function debug
def test_debug(): # pylint: disable=unused-variable
    from mock import patch, call

    with patch('sys.stderr') as stderr:
        debug('test')
        stderr.write.assert_called_once_with(
                '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

    with patch.object(settings, 'debug', False), \
            patch('sys.stderr') as stderr:
        debug('debug is disabled')
        assert stderr.write.call_count == 0

# Generated at 2022-06-12 10:39:10.699087
# Unit test for function debug_time
def test_debug_time():
    # This function should not raise any exception
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:39:16.699736
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class Test(object):
        script = "echo 'sometxt'"
        side_effect = False
    test = Test()
    show_corrected_command(test)
    assert open('test.txt', 'r').readlines() == ["echo 'sometxt'\n"]
    test1 = Test()
    test1.side_effect = True
    show_corrected_command(test1)
    assert open('test.txt', 'r').readlines() == ["echo 'sometxt' (+side effect)\n"]
test_show_corrected_command()


# Generated at 2022-06-12 10:39:21.761316
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT + u'warn') == 'warn'
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT + u'warn') == ''

# Generated at 2022-06-12 10:39:30.465516
# Unit test for function confirm_text
def test_confirm_text():
    class TestCommand(object):
        def __init__(self, script, side_effect=False):
            self.script = script
            self.side_effect = side_effect


# Generated at 2022-06-12 10:39:31.017242
# Unit test for function debug_time
def test_debug_time():
    assert debug_time

# Generated at 2022-06-12 10:39:40.449117
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    import fuck
    import fuck.rules.git_dirty
    import fuck.rules.git_clean
    command = fuck.Command('git status')
    show_corrected_command(
        fuck.CorrectedCommand(command,'git pull',fuck.rules.git_dirty))
    assert u'> git pull' in sys.stdout.getvalue()
    command = fuck.Command('git status')
    show_corrected_command(
        fuck.CorrectedCommand(command,'git fetch',fuck.rules.git_clean))
    assert u'> git fetch' in sys.stdout.getvalue()
    sys.stdout = stdout

# Generated at 2022-06-12 10:39:42.702415
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls'))
    show_corrected_command(CorrectedCommand('ls', True))


# Generated at 2022-06-12 10:39:53.177586
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from .rule import Rule

    def test_rule(command):
        raise AssertionError('test')

    rule = Rule(test_rule, 'test rule')

    settings.debug = False
    sys.stderr = StringIO()
    try:
        rule.match('test command')
    except:
        pass
    assert(sys.stderr.getvalue() == '')

    settings.debug = True
    sys.stderr = StringIO()
    try:
        rule.match('test command')
    except:
        pass
    assert(sys.stderr.getvalue().startswith(
        '\x1b[34m\x1b[1mDEBUG\x1b[0m: Rule test rule match failed\n'))

# Generated at 2022-06-12 10:39:54.254069
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('Test_command')


# Generated at 2022-06-12 10:39:59.836476
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager

    def dummy_context_manager():
        from datetime import datetime
        from time import sleep
        started = datetime.now()
        try:
            sleep(0.01)
        finally:
            return datetime.now() - started

    with debug_time('test_debug_time'):
        with dummy_context_manager() as x:
            assert 0 < int(x.seconds)
            assert 0 < int(x.microseconds)

# Generated at 2022-06-12 10:40:08.014595
# Unit test for function debug
def test_debug():
    debug('Test')



# Generated at 2022-06-12 10:40:14.551857
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import subprocess
    import tempfile
    import os

    env = dict(os.environ)
    env['LANG'] = 'en_US.UTF-8'

    with tempfile.TemporaryFile(mode='w+') as f:
        p = subprocess.Popen('./thefuck --alias', shell=True,
                             stdout=f, stderr=f, env=env)
        p.communicate()
        f.seek(0)
        command = f.read()
        f.close()

        assert '[enter]' in command
        assert '[up]' in command
        assert '[down]' in command

# Generated at 2022-06-12 10:40:17.103418
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.1)
# End of Unit test for function debug_time


# Generated at 2022-06-12 10:40:22.589078
# Unit test for function debug
def test_debug():
    import mock
    with mock.patch('sys.stderr.write') as write_mock:
        debug('Some debug message')
    assert write_mock.call_count == 1
    assert write_mock.call_args[0][0] == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Some debug message\n'

# Generated at 2022-06-12 10:40:25.079596
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Bash

    configuration_details = Bash().get_alias()
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:40:33.139888
# Unit test for function confirm_text
def test_confirm_text():
    expected = (
        u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
        u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
        u'/{red}ctrl+c{reset}]').format(
            prefix=const.USER_COMMAND_MARK,
            script='ls',
            side_effect=' (+side effect)',
            clear='\033[1K\r',
            bold=color(colorama.Style.BRIGHT),
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

    assert confirm_text("ls") == expected

# Generated at 2022-06-12 10:40:34.964000
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.ui import confirm_text

    confirm_text(
        const.CorrectedCommand(script='ls', side_effect=False))

# Generated at 2022-06-12 10:40:35.735467
# Unit test for function debug_time
def test_debug_time():
    assert False, "No test implemented"

# Generated at 2022-06-12 10:40:37.486309
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command('ls -al')
    show_corrected_command('ls -la')


# Generated at 2022-06-12 10:40:39.093176
# Unit test for function debug_time
def test_debug_time():
    for i in range(10):
        with debug_time('test'):
            pass

# Generated at 2022-06-12 10:40:51.591918
# Unit test for function debug_time
def test_debug_time():
    from unittest import main, TestCase
    from mock import patch
    from .conf import settings
    from .log import debug, debug_time

    settings.debug = True

    class DebugTimeTest(TestCase):
        @patch('fuck.log.debug')
        def test_debug_time_should_call_debug_with_time_taken(self, debug):
            with debug_time('msg'):
                pass
            debug.assert_called_with(u'msg took: 0:00:00')

    main()

# Generated at 2022-06-12 10:40:52.169808
# Unit test for function debug
def test_debug():
    debug('hello')

# Generated at 2022-06-12 10:41:03.239337
# Unit test for function confirm_text
def test_confirm_text():
    old_sys_stdout = sys.stdout
    sys.stdout = None

# Generated at 2022-06-12 10:41:11.224809
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    import pytest
    colorama.init()
    old_stderr = sys.stderr

# Generated at 2022-06-12 10:41:14.141307
# Unit test for function confirm_text
def test_confirm_text():
    """
    >>> confirm_text(CorrectedCommand('ls abc', False))
    ls abc [enter/↑/↓/ctrl+c]
    """
    pass

# Generated at 2022-06-12 10:41:23.059965
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .utils import get_closest

    configuration_details = ConfigurationDetails('test_histfile',
                                                 'test_config_file',
                                                 'test_reload',
                                                 can_configure_automatically=True)

    how_to_configure_alias(configuration_details)

    assert get_closest(
        "Seems like fuck alias isn't configured!\n"
        "Please put test_histfile in your test_config_file and apply "
        "changes with test_reload or restart your shell.\n"
        "Or run fuck a second time to configure it automatically."
    )
    assert get_closest('More details - https://github.com/nvbn/thefuck#manual-installation')



# Generated at 2022-06-12 10:41:25.477938
# Unit test for function confirm_text
def test_confirm_text():
    correct_output = (u'>>> ')
    command = {'script': u'ls'}
    assert correct_output == confirm_text(command)

# Generated at 2022-06-12 10:41:26.557678
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-12 10:41:31.981051
# Unit test for function confirm_text
def test_confirm_text():
    from . import confirm_text
    from .const import USER_COMMAND_MARK
    corrected_command = Command('cmd', 'cd ..', True)
    confirm_text(corrected_command)
#     input_str = raw_input()
    assert input_str == '\033[1K\r' + USER_COMMAND_MARK + 'cd .. +side effect [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:41:34.112428
# Unit test for function color
def test_color():
    assert color(u'b') == u'b'
    assert color(u'b', False) == u'b'
    assert color(u'b', True) == u''

# Generated at 2022-06-12 10:41:50.801112
# Unit test for function debug
def test_debug():
    import mock
    import __builtin__

    debug("hello world")

    sys.stderr.write = mock.Mock()
    sys.stderr.flush = mock.Mock()
    with mock.patch('sys.stderr', sys.stderr):
        debug("hello world")
        sys.stderr.write.assert_called_with("DEBUG: hello world\n")
        sys.stderr.flush.assert_called_with()

    print = mock.Mock()
    with mock.patch('__builtin__.print', print):
        with mock.patch('thefuck.shells.get_settings',
                        lambda: {'debug': False}):
            debug("hello world")
            assert not print.called


# Generated at 2022-06-12 10:41:52.065416
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('ls -st')


# Generated at 2022-06-12 10:41:56.347285
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    s = StringIO()
    sys.stderr = s
    try:
        debug('test')
        assert s.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stderr = sys.__stderr__


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:41:57.049390
# Unit test for function debug
def test_debug():
    debug('msg')



# Generated at 2022-06-12 10:42:01.538357
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .utils import get_closest
    from .types import Command
    from .rules import get_rules
    from .shells.bash import Bash
    from .shells.zsh import Zsh
    bash = Bash()
    zsh = Zsh


# Generated at 2022-06-12 10:42:03.728989
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('some corrected command')
    show_corrected_command('some corrected command + side effect')


# Generated at 2022-06-12 10:42:06.580544
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(
        corrected_command = 'ls -la') == 'ls -la'
    #assert show_corrected_command(corrected_command) == 'ls -la'