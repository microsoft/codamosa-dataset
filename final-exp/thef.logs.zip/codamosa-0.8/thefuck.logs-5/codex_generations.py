

# Generated at 2022-06-12 10:32:14.596321
# Unit test for function debug_time
def test_debug_time():
    from thefuck.tests.utils import capture_stderr

    with capture_stderr() as captured:
        with debug_time('test_msg'):
            pass

    assert u'test_msg took' in captured.read()

# Generated at 2022-06-12 10:32:16.647515
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell
    from .corrector import CorrectedCommand
    from .application import Application

    confirm_text(CorrectedCommand(Shell(Application('fuck')), 'ls', ''))

# Generated at 2022-06-12 10:32:26.990023
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    import sys

    save_stdout = sys.stdout                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   

# Generated at 2022-06-12 10:32:30.416852
# Unit test for function debug_time
def test_debug_time():
    import mock
    from datetime import timedelta

    with mock.patch('thefuck.shells.base.debug') as debug_mock:
        with debug_time(msg='foo'):
            pass
        assert debug_mock.call_args[0][0].startswith('foo took')

# Generated at 2022-06-12 10:32:32.034248
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED  # nosec
    assert color('') == ''

# Generated at 2022-06-12 10:32:32.928449
# Unit test for function color
def test_color():
    assert not color(u'\033[31m')

# Generated at 2022-06-12 10:32:34.709426
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('foo'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:32:37.198715
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias({})
    how_to_configure_alias([])

# Generated at 2022-06-12 10:32:39.068858
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert color('') == ''
    settings.no_colors = True
    assert color(colorama.Fore.RED) == ''
    assert color('') == ''

# Generated at 2022-06-12 10:32:46.572452
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from mock import patch
    from thefuck.conf import set_settings

    set_settings(no_colors=True, debug=True)
    stdout = StringIO()
    with patch('sys.stderr', stdout):
        debug('error')
    assert stdout.getvalue() == 'DEBUG: error\n'

    set_settings(no_colors=False, debug=True)
    stdout = StringIO()
    with patch('sys.stderr', stdout):
        debug('error')
    assert stdout.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[39m\x1b[49m error\n'

# Generated at 2022-06-12 10:32:59.178209
# Unit test for function confirm_text
def test_confirm_text():
    from .utils import _get_output
    from .types import CorrectedCommand
    command = CorrectedCommand('echo "a & b"', 'echo "a \& b"')
    confirm_text(command)
    assert _get_output() == u'{prefix}echo "a \& b" [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'.format(
            prefix=const.USER_COMMAND_MARK,
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE))

# Generated at 2022-06-12 10:33:08.558231
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
                     u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                     u'/{red}ctrl+c{reset}]'.format(
        prefix=const.USER_COMMAND_MARK,
        script='foo -v',
        side_effect='',
        clear='\033[1K\r',
        bold=color(colorama.Style.BRIGHT),
        green=color(colorama.Fore.GREEN),
        red=color(colorama.Fore.RED),
        reset=color(colorama.Style.RESET_ALL),
        blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-12 10:33:09.831735
# Unit test for function color
def test_color():
    assert color('color') == 'color'

# Generated at 2022-06-12 10:33:10.457756
# Unit test for function debug_time
def test_debug_time():
    assert debug_time

# Generated at 2022-06-12 10:33:20.931078
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # Setup
    from .corrector import CorrectedCommand
    from .shells import Shell
    shell = Shell()
    script = 'git log'
    side_effect = False
    corrected_command = CorrectedCommand(script, side_effect)

    # Execute
    show_corrected_command(corrected_command)

    # Verify
    from cStringIO import StringIO
    sys.stderr = StringIO()
    assert "The Fuck {} using Python {} and {}\n".format(
        shell.get_version(),
        'Unknown Python version',
        shell.name) == sys.stderr.getvalue()
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:33:23.856532
# Unit test for function debug
def test_debug():
    debug('Test-message')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test-message\n'

# Generated at 2022-06-12 10:33:26.405116
# Unit test for function color
def test_color():
    settings.no_colors = True
    assert color(colorama.Back.BLUE) == ''
    settings.no_colors = False
    assert color(colorama.Back.BLUE) == colorama.Back.BLUE

# Generated at 2022-06-12 10:33:34.548074
# Unit test for function confirm_text
def test_confirm_text():
    assert u'\x1B[1K\r\x1B[0m\x1B[1mcd /\x1B[0m [\x1B[32menter\x1B[0m/\x1B[34m↑\x1B[0m/\x1B[34m↓\x1B[0m/\x1B[31mctrl+c\x1B[0m]' == confirm_text(const.Command('cd /'))



# Generated at 2022-06-12 10:33:37.664547
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls -la') == u'{prefix}{clear}{bold}{script}{reset} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'

# Generated at 2022-06-12 10:33:39.467577
# Unit test for function color
def test_color():
    assert color('a') == 'a'
    assert color('a') != ''

# Generated at 2022-06-12 10:33:49.754202
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .utils import get_time
    foo_time = timedelta(seconds=0.03)
    bar_time = timedelta(seconds=0.05)

    def foo():
        with debug_time('foo'):
            get_time(foo_time)

    def bar():
        with debug_time('bar'):
            get_time(bar_time)

    with debug_time('call'):
        foo()
        bar()

    assert sys.stderr.getvalue() == """\
DEBUG: call took: 0:00:00.100018
DEBUG: foo took: 0:00:00.030016
DEBUG: bar took: 0:00:00.049989
"""

# Generated at 2022-06-12 10:33:51.790572
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias('fuck') == u"Seems like fuck alias isn't configured!"

# Generated at 2022-06-12 10:33:52.727939
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:33:57.144832
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import sys
    import mock
    sys.stderr = mock.Mock()
    how_to_configure_alias(None)
    sys.stderr.write.assert_called_once_with(u"Seems like \x1b[1mfuck\x1b[22m alias isn't configured!\n")

# Generated at 2022-06-12 10:34:01.283761
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration import ConfigurationDetails
    how_to_configure_alias(ConfigurationDetails(
        path=u'/home/nvbn/.bashrc',
        reload=u'source ./bashrc',
        content=u'eval $(thefuck --alias)',
        can_configure_automatically=True))



# Generated at 2022-06-12 10:34:04.176342
# Unit test for function color
def test_color():
    from tests.utils import assert_equals

    assert_equals(
        color(colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT),
        colorama.Back.RED + colorama.Fore.WHITE + colorama.Style.BRIGHT)

# Generated at 2022-06-12 10:34:08.089073
# Unit test for function debug_time
def test_debug_time():
    import time
    from . import test

    with test.mock.patch('sys.stderr') as stderr:
        with debug_time('test_debug'):
            time.sleep(0.1)
        assert stderr.write.called



# Generated at 2022-06-12 10:34:09.789932
# Unit test for function debug
def test_debug():
    debug(u'Привет, мир!')



# Generated at 2022-06-12 10:34:11.006209
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'test'
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:34:12.523284
# Unit test for function debug_time
def test_debug_time():
    assert debug_time() == None

# Generated at 2022-06-12 10:34:23.972027
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys

    original_stderr = sys.stderr
    try:
        sys.stderr = StringIO()
        debug(u'msg')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n'
        sys.stderr = StringIO()
        settings.debug = True
        debug(u'msg2')
        assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg2\n'
    finally:
        sys.stderr = original_stderr

# Generated at 2022-06-12 10:34:34.537473
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    output = StringIO.StringIO()
    sys.stdout = output
    configuration_details = "You are wrong!"
    how_to_configure_alias(configuration_details)
    sys.stdout = sys.__stdout__
    output_string = output.getvalue()
    assert output_string.find(u'Seems like ') >= 0
    assert output_string.find(u'isn\'t configured!') >= 0
    assert output_string.find(u'Please put ') >= 0
    assert output_string.find(u'in your ') >= 0
    assert output_string.find(u'and apply') >= 0
    assert output_string.find(u'changes with ') >= 0
    assert output_string.find(u'Or run ') >= 0
    assert output

# Generated at 2022-06-12 10:34:36.571521
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    # with debug_time('test_debug_time'):
    #     sleep(1)
    #     assert True

# Generated at 2022-06-12 10:34:40.515687
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    with StringIO() as stream:
        sys.stderr = stream
        debug(u'Test')
        stream.seek(0)
        assert stream.read() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n'

# Generated at 2022-06-12 10:34:42.841520
# Unit test for function debug
def test_debug():
    from .conf import DEBUG
    DEBUG = False
    try:
        assert debug("debug") == None
    finally:
        DEBUG = True

# Generated at 2022-06-12 10:34:44.547701
# Unit test for function debug_time
def test_debug_time():
    try:
        with debug_time('test'):
            pass
    except Exception:
        pass



# Generated at 2022-06-12 10:34:53.181913
# Unit test for function confirm_text
def test_confirm_text():
    import mock
    import sys
    import os

    # Setup mock objects
    check_output = mock.MagicMock()
    check_output.return_value = "truelove"
    call = mock.MagicMock()
    call.return_value = None
    from thefuck import utils
    orig_check_output = utils.check_output
    utils.check_output = check_output
    from thefuck.rules import correction
    orig_call = correction.call
    correction.call = call

    # Mock raw_input for testing on python 2
    old_raw_input = input

    def mock_raw_input(prompt, **kwargs):
        return 'some_input'

    input = mock_raw_input


# Generated at 2022-06-12 10:34:55.646034
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('Test'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:34:57.206764
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

# Generated at 2022-06-12 10:34:58.865764
# Unit test for function color
def test_color():
    assert color('color') == u'color'
    assert color('color') == ''

# Generated at 2022-06-12 10:35:12.297444
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from mock import patch, call

    def test_context():
        pass

    with patch('sys.stderr') as stderr_mock:
        with debug_time('test_context'):
            pass
        assert stderr_mock.write.call_args_list == \
            [call('\033[1K\r\x1b[34m\x1b[1mDEBUG:\x1b[0m test_context took: {}\n'.format(timedelta()))]

# Generated at 2022-06-12 10:35:16.710267
# Unit test for function confirm_text
def test_confirm_text():
    from io import StringIO
    import sys
    stderr = sys.stderr
    sys.stderr = StringIO()
    confirm_text('ls')
    sys.stderr.seek(0)
    assert sys.stderr.read() == '🔥ls [enter/↑/↓/ctrl+c]'
    sys.stderr = stderr



# Generated at 2022-06-12 10:35:26.983510
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Bash
    from .command import Command
    import os

    def to_unicode(s):
        if sys.version_info[0] < 3:
            return s.decode('utf-8')
        else:
            return s

    corrected_command = Command('ls bad_directory', 'ls')
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:35:30.658649
# Unit test for function debug_time
def test_debug_time():
    import os
    import time
    from mock import patch
    with patch.object(os, 'environ', {const.DEBUG: 'True'}):
        with debug_time('bla'):
            time.sleep(1)

# Generated at 2022-06-12 10:35:33.764395
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    cmd = Command('git commut', 'git commit', side_effect=True)
    show_corrected_command(cmd)


# Generated at 2022-06-12 10:35:43.716382
# Unit test for function show_corrected_command
def test_show_corrected_command():
    # *actual_output_wrapper.getvalue()* to get value of sys.stderr.write
    #  sys.sertr.write return None
    class actual_output_wrapper(object):
        """Helper class to provide ability to getvalue of sys.stderr.write"""
        def __init__(self):
            self.value = None

        def getvalue(self):
            return self.value

        def write(self, value):
            self.value = value

    actual_output = actual_output_wrapper()
    sys.stderr.write = actual_output.write
    # expected output after "show_corrected_command" call

# Generated at 2022-06-12 10:35:45.077949
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(u'ls-l') == 'ls-l'

# Generated at 2022-06-12 10:35:53.377134
# Unit test for function confirm_text
def test_confirm_text():
    # TODO: Make test better
    from io import StringIO
    import sys

    saved_stdout = sys.stdout

# Generated at 2022-06-12 10:35:55.241134
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(0.2)

# Generated at 2022-06-12 10:35:57.211409
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('test1')
    settings.debug = False
    debug('test2')

# Generated at 2022-06-12 10:36:15.824549
# Unit test for function color
def test_color():
    assert color('\033[1;33m') == ''
    assert color(u'\033[1;33m') == ''
    assert color(u'\033[1;33m') == ''
    assert color(u'\033[1;33m') == ''
    assert color(u'\033[1;33m') == ''
    assert color('') == ''
    assert color(u'') == ''
    assert color(u'\033[1;41m\033[1;37m\033[1;5m') == '\033[1;41m\033[1;37m\033[1;5m'

# Generated at 2022-06-12 10:36:17.146106
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("Fuck")


# Generated at 2022-06-12 10:36:24.252952
# Unit test for function debug
def test_debug():
    from mock import patch
    import sys

    settings.debug = True
    with patch('sys.stderr') as stderr:
        debug(u'foo bar')
        stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo bar\n')

    settings.debug = False
    with patch('sys.stderr') as stderr:
        debug(u'foo bar')
        assert not stderr.write.called

# Generated at 2022-06-12 10:36:25.169579
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:36:26.961373
# Unit test for function debug_time
def test_debug_time():
    import time

    with debug_time('test'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:36:35.304996
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stderr.write(u"Seems like {bold}fuck{reset} alias isn't configured!\n".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

    if configuration_details:
        sys.stderr.write(
            u"Please put {bold}{content}{reset} in your "
            u"{bold}{path}{reset} and apply "
            u"changes with {bold}{reload}{reset} or restart your shell.\n".format(
                bold=color(colorama.Style.BRIGHT),
                reset=color(colorama.Style.RESET_ALL),
                **configuration_details._asdict()))

        if configuration_details.can_configure_automatically:
            sys.stderr.write

# Generated at 2022-06-12 10:36:38.432470
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    import sys

    capturedOutput = StringIO()
    sys.stderr = capturedOutput

    debug('test')
    output = capturedOutput.getvalue().strip()
    assert output == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-12 10:36:40.584673
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    config = ConfigurationDetails(Shell('fish', '~/.bashrc', 'source ~/.bashrc'),
                                  False)
    how_to_configure_alias(config)
    debug('Test')



# Generated at 2022-06-12 10:36:42.521603
# Unit test for function color
def test_color():
    assert color('red') == ''
    assert color('black') == ''
    colorama.init()
    assert color('red') == colorama.Fore.RED
    assert color('black') == colorama.Fore.BLACK

# Generated at 2022-06-12 10:36:49.279099
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    command = CorrectedCommand(script=u'pwd', side_effect=False)
    assert show_corrected_command(command) == u'$ pwd'
    assert show_corrected_command(command) == u'$ pwd'
    assert show_corrected_command(command) == u'$ pwd'
    command = CorrectedCommand(script=u'pwd', side_effect=True)
    assert show_corrected_command(command) == u'$ pwd (+side effect)'
    assert show_corrected_command(command) == u'$ pwd (+side effect)'
    assert show_corrected_command(command) == u'$ pwd (+side effect)'

# Generated at 2022-06-12 10:37:03.379342
# Unit test for function debug_time

# Generated at 2022-06-12 10:37:04.181367
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('bashrc')

# Generated at 2022-06-12 10:37:11.511566
# Unit test for function debug
def test_debug():
    import StringIO

    out = StringIO.StringIO()
    settings._debug = True
    settings._no_colors = False
    try:
        with debug_time('test'):
            debug('message')
            print >> out, 'test', out.getvalue()
    finally:
        settings._debug = False
        settings._no_colors = True

    assert out.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n\x1b[34m\x1b[1mDEBUG:\x1b[0m test took: 0:00:00\n'



# Generated at 2022-06-12 10:37:14.091397
# Unit test for function confirm_text
def test_confirm_text():
    from . import corrector
    assert confirm_text(corrector.Command('ls', True)) == None
    assert confirm_text(corrector.Command('ls', False)) == None

# Generated at 2022-06-12 10:37:24.288153
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager
    from io import StringIO
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        debug(u'foo')
    output = out.getvalue().strip()
    assert output == u'foo'

    with captured_output() as (out, err):
        debug(u'foo\nbar')
    output = out.get

# Generated at 2022-06-12 10:37:26.822737
# Unit test for function color
def test_color():
    assert color('text') == 'text'
    settings.no_colors = True
    assert color('text') == ''

# Generated at 2022-06-12 10:37:27.810831
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:37:30.224627
# Unit test for function debug_time
def test_debug_time():
    name_list = ['a', 'b', 'c']
    for name in name_list:
        with debug_time('test {}'.format(name)):
            pass

# Generated at 2022-06-12 10:37:37.461927
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():

    # Note: this test was not written to test colorama, but rather to make
    # sure that this function works as intented even with colorama disabled
    colorama.init(False)

    from .shells import Shell
    from .utils import ConfigurationDetails

    configuration_details = ConfigurationDetails(
        path='~/.bashrc',
        reload='source ~/.bashrc',
        content='eval "$(thefuck --alias)"',
        can_configure_automatically=True)


# Generated at 2022-06-12 10:37:41.223994
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/test',
        content=u'content',
        can_configure_automatically=False,
        reload=u'reload'))
    how_to_configure_alias(const.ConfigurationDetails(
        path=u'/test',
        content=u'content',
        can_configure_automatically=True,
        reload=u'reload'))



# Generated at 2022-06-12 10:38:01.603655
# Unit test for function debug_time
def test_debug_time():
    import time
    import unittest
    from .utils import debug_time

    class TestDebugTime(unittest.TestCase):

        def test_debug_time(self):
            class A(object):
                res = ''
                def write(self, str):
                    self.res += str

            a = A()
            sys.stderr = a
            with debug_time('hi'):
                time.sleep(0.1)
            self.assertTrue('hi took' in a.res)

    return unittest.defaultTestLoader.loadTestsFromTestCase(TestDebugTime)

# Generated at 2022-06-12 10:38:05.290735
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    fake_configuration_details = "\n\tPlease put {bold}{content}{reset} in your " \
    "\n\t{bold}{path}{reset} and apply changes with {bold}{reload}{reset}".format(bold='',
                                                                                  reset='')
    assert fake_configuration_details in how_to_configure_alias(fake_configuration_details)


# Generated at 2022-06-12 10:38:15.722858
# Unit test for function confirm_text
def test_confirm_text():
    from .shells import Shell

    from .shells import Bash

# Generated at 2022-06-12 10:38:24.130840
# Unit test for function debug
def test_debug():
    import os
    import thefuck.shells.bash as bash

    def _test_side_effect(script, *args, **kwargs):
        assert script == u'fuck'

    shell = bash.get_shell()
    shell.putenv = _test_side_effect
    shell.unsetenv = _test_side_effect
    shell.set_alias = _test_side_effect

    try:
        os.environ['TF_DEBUG'] = '1'
        settings.load_configuration()
        debug(u'test')
        debug_time(u'test')
    finally:
        del os.environ['TF_DEBUG']

# Generated at 2022-06-12 10:38:28.090980
# Unit test for function debug_time
def test_debug_time():
    from io import StringIO

    log = StringIO()

    with debug_time('test in debug_timer', log):
        assert log.getvalue() == ''
    assert log.getvalue() == 'test in debug_timer took: 0:00:00.000000\n'



# Generated at 2022-06-12 10:38:34.192685
# Unit test for function debug
def test_debug():
    class DummyStdErr(list):
        def write(self, item):
            self.append(item)

    settings.debug = True
    sys.stderr = DummyStdErr()
    debug('foo')
    assert sys.stderr ==\
        ['\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n']
    settings.debug = False



# Generated at 2022-06-12 10:38:35.486411
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED
    assert color('red') == ''

# Generated at 2022-06-12 10:38:36.216778
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:38:38.144787
# Unit test for function debug_time
def test_debug_time():
    i = 0
    with debug_time('test_debug'):
        for i in range(0, 1000000):
            i += 1

# Generated at 2022-06-12 10:38:43.418836
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import timedelta
    from contextlib import contextmanager

    with patch('thefuck.shells.base.debug') as mock_debug:
        with debug_time(msg='test'):
            pass
        mock_debug.assert_called_once_with('test took: {}'.format(
            timedelta(0)))



# Generated at 2022-06-12 10:38:57.186381
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from StringIO import StringIO
    output_buffer = StringIO()
    sys.stderr = ou

# Generated at 2022-06-12 10:38:58.648045
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:39:04.680013
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    about_configuration = ('fuck', 'alias fuck="eval $(thefuck $(fc -ln -1))"')
    expected_output = 'Seems like {bold}fuck{reset} alias isn\'t configured!'.format(
        bold=color(colorama.Style.BRIGHT), reset=color(colorama.Style.RESET_ALL))
    how_to_configure_alias(about_configuration)
    output = sys.stderr.getvalue().strip()
    assert output == expected_output

# Generated at 2022-06-12 10:39:06.233910
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_func'):
        pass

# Generated at 2022-06-12 10:39:07.762246
# Unit test for function show_corrected_command
def test_show_corrected_command():
    print(color(colorama.Style.BRIGHT))
    show_corrected_command('command')

# Generated at 2022-06-12 10:39:10.503551
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    how_to_configure_alias(Shell._get_shell_info('fish'))



# Generated at 2022-06-12 10:39:11.843904
# Unit test for function debug_time
def test_debug_time():
    """Checks that debug_time can be used in a context manager."""

# Generated at 2022-06-12 10:39:14.581171
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    settings.no_colors = True
    assert color('test') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:39:15.487787
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('debug message')

# Generated at 2022-06-12 10:39:17.800774
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(CorrectedCommand('echo', True)) == 'echo (+side effect) [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:39:33.082765
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(const.CorrectedCommand(script='ls', side_effect=False))

if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:39:34.556634
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from . import application

    app = application.Application()
    correction = app.get_command_correction('aiadm')
    show_corrected_command(correction)
    assert correction.script == 'ls -l'

# Generated at 2022-06-12 10:39:35.757823
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(const.CorrectedCommand('', False))



# Generated at 2022-06-12 10:39:36.734529
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Testing debug_time'):
        assert debug('Test debug') is None


# Generated at 2022-06-12 10:39:37.275842
# Unit test for function debug
def test_debug():
    debug('test')

# Generated at 2022-06-12 10:39:38.144316
# Unit test for function debug
def test_debug():
    debug('test debug')



# Generated at 2022-06-12 10:39:41.381024
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .const import USER_COMMAND_MARK
    from .command import Command
    cmd = Command('git commmit')
    show_corrected_command(cmd)
    assert sys.stderr.getvalue() == USER_COMMAND_MARK + 'git commmit\n'



# Generated at 2022-06-12 10:39:45.053203
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = CorrectedCommand('echo 1', 'echo 2')
    expected = const.USER_COMMAND_MARK + 'echo 2' + '\n'

    assert(show_corrected_command(corrected_command) == expected)

# Generated at 2022-06-12 10:39:45.897013
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=const.CorrectedCommand('ls -a'))

# Generated at 2022-06-12 10:39:46.777611
# Unit test for function color
def test_color():
    assert color('1') == '1'
    assert color('') == ''

# Generated at 2022-06-12 10:40:08.823417
# Unit test for function debug
def test_debug():
    u'Test for function debug'
    settings.debug = True
    from six import StringIO
    from contextlib import contextmanager
    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    with captured_output() as (out, err):
        debug('test')
    assert out.getvalue().strip() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test'

# Generated at 2022-06-12 10:40:10.672358
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(corrected_command=const.CorrectedCommand('echo "ofd"', side_effect=True))



# Generated at 2022-06-12 10:40:11.671291
# Unit test for function color
def test_color():
    assert color('red') == colorama.Fore.RED

# Generated at 2022-06-12 10:40:12.505244
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:40:20.421585
# Unit test for function debug_time
def test_debug_time():
    # Test for setup
    def func():
        a = 5
        for i in range(100000):
            a *= 5

    # Test for teardown
    def func2():
        a = 5
        for i in range(100000):
            a *= 5

    # Test without setup and teardown
    def func3():
        a = 5
        for i in range(100000):
            a *= 5

    with debug_time('func'):
        func()
    with debug_time('func2'):
        func2()
    with debug_time('func3'):
        func3()

# Generated at 2022-06-12 10:40:22.543071
# Unit test for function confirm_text
def test_confirm_text():
    """Test confirm_text function with red color"""
    msg = confirm_text(corrected_command='pwd')
    assert msg


# Generated at 2022-06-12 10:40:25.392784
# Unit test for function debug
def test_debug():
    with open('debug_test.txt', 'w') as f:
        sys.stderr = f
        debug('test')
    assert open('debug_test.txt').read() == 'test\n'

# Generated at 2022-06-12 10:40:26.025093
# Unit test for function debug
def test_debug():
    debug(u'Debug')

# Generated at 2022-06-12 10:40:32.907055
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    sys.stderr.write(u'Seems like {bold}fuck{reset} alias isn\'t configured!\n'.format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))

    sys.stderr.write(
        u'Please put {bold}{content}{reset} in your '
        u'{bold}{path}{reset} and apply '
        u'changes with {bold}{reload}{reset} or restart your shell.\n'.format(
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL),
            content='content',
            path='path',
            reload='reload'))


# Generated at 2022-06-12 10:40:42.014125
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .utils import test

    def reset_conf():
        settings.no_colors = False
        settings.enable_experimental_instant_mode = False

    def init(test_func):
        def wrapper():
            reset_conf()
            test_func()

        return wrapper

    @test
    @init
    def no_configuration_details():
        how_to_configure_alias(None)

    @test
    @init
    def no_advices():
        how_to_configure_alias(ConfigurationDetails(
            path=None, content=None, reload=None))


# Generated at 2022-06-12 10:40:56.636312
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + 'RED') == 'RED'
    assert color(colorama.Fore.RED + 'RED') == ''

# Generated at 2022-06-12 10:40:59.554796
# Unit test for function confirm_text
def test_confirm_text():
    """
    check if the user will be ask to correct the command he entered
    """

# Generated at 2022-06-12 10:41:07.918593
# Unit test for function debug
def test_debug():
    from tempfile import TemporaryFile
    from io import TextIOWrapper
    tmp_stderr = sys.stderr
    tmp_debug = settings.debug

    try:
        from unittest.mock import patch
        sys.stderr = TemporaryFile()
        with patch.object(settings, 'debug', True):
            debug('test debug message')
            sys.stderr.seek(0)
            result = sys.stderr.read()
    finally:
        sys.stderr = tmp_stderr
        settings.debug = tmp_debug
    assert result == b'\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug message\n'

# Generated at 2022-06-12 10:41:11.226067
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class TestCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect

    assert show_corrected_command(TestCommand('git', False)) is None
    assert show_corrected_command(TestCommand('git', True)) is None



# Generated at 2022-06-12 10:41:12.828450
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(1) == '{prefix}'

# Generated at 2022-06-12 10:41:18.231971
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    from .utils import test_stream
    from .utils import capture
    from .rules.python import match, get_new_command
    with test_stream() as stream:
        show_corrected_command(CorrectedCommand(
            script='echo $fuck',
            side_effect=True))
        assert stream.getvalue() == \
            '> echo $fuck (+side effect)\n'



# Generated at 2022-06-12 10:41:21.019387
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    started = datetime.now()
    with debug_time('test'):
        delta = datetime.now() - started
    assert delta > timedelta(microseconds=500000), delta

# Generated at 2022-06-12 10:41:22.896766
# Unit test for function confirm_text
def test_confirm_text():
    from thefuck.utils import confirm_text
    confirm_text('test_command')

# Generated at 2022-06-12 10:41:26.637423
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    def magick(delta):
        with debug_time('Magick'):
            import time
            time.sleep(delta.total_seconds())

    magick(timedelta(seconds=0.156))

# Generated at 2022-06-12 10:41:28.345275
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('Test'):
        pass
    assert (datetime.now() - started > 0)

# Generated at 2022-06-12 10:42:00.353514
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta

    from . import util
    from . import conf
    from contextlib import contextmanager

    import mock

    @contextmanager
    def mocked_debug_time(msg):
        with mock.patch.object(util, 'debug') as debug:
            yield debug

    with mocked_debug_time(u'Mocked debug') as debug:
        with util.debug_time(u'Mocked debug'):
            pass

        debug.assert_called_once_with(u'Mocked debug took: 0:00:00.000000')
        with util.debug_time(u'Mocked debug'):
            pass

        debug.assert_called_with(u'Mocked debug took: {}'.format(
            timedelta(microseconds=conf.settings.slow_threshold_ms)))



# Generated at 2022-06-12 10:42:01.455467
# Unit test for function debug_time
def test_debug_time():
    from mock import Mock
    assert Mock() == Mock()

# Generated at 2022-06-12 10:42:08.287953
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch.object(sys.stderr, 'write') as stderr:
        with patch.object(settings, 'debug', True):
            debug(u'test')
            assert any('DEBUG: test' in line for line in stderr.write.call_args_list)

        with patch.object(settings, 'debug', False):
            debug(u'test')
            assert not any('DEBUG: test' in line for line in stderr.write.call_args_list)
