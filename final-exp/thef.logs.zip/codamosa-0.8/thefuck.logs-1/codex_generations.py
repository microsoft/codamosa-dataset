

# Generated at 2022-06-12 10:32:15.858919
# Unit test for function debug_time
def test_debug_time():
    result = []

    def debug(msg):
        result.append(msg)

    with debug_time('foo'):
        pass

    assert result
    assert 'foo took' in result[0]

# Generated at 2022-06-12 10:32:16.662246
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('123') == '123\n'

# Generated at 2022-06-12 10:32:24.265622
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.shells import History
    from thefuck.utils import CorrectedCommand
    cmd = CorrectedCommand('ls', 'ls -a', History())
    assert show_corrected_command(cmd) == '{}ls -a\n'.format(
        const.USER_COMMAND_MARK)
    cmd = CorrectedCommand('ls', 'ls -a', History(), side_effect=True)
    assert show_corrected_command(cmd) == '{}ls -a (+side effect)\n'.format(
        const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:32:26.852711
# Unit test for function debug_time
def test_debug_time():

    def foo():
        raise NotImplementedError()

    try:
        with debug_time('foo'):
            foo()
    except NotImplementedError:
        pass

# Generated at 2022-06-12 10:32:30.859404
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager, closing
    from io import StringIO

    @contextmanager
    def _debug():
        stream = StringIO()
        with closing(stream):
            def _debug(msg):
                stream.write(msg)
            yield _debug
        assert stream.getvalue() == u'DEBUG: Test\n'

    with _debug():
        debug(u'Test')

# Generated at 2022-06-12 10:32:31.761730
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('fuck')


# Generated at 2022-06-12 10:32:37.579756
# Unit test for function debug_time
def test_debug_time():
    import os
    import time
    import StringIO
    from mock import patch
    from .main import debug_time
    from .settings import set_debug
    set_debug(True)
    with patch.object(sys.stdout, 'write') as mock_stdout:
        with debug_time('test_time'):
            time.sleep(1)
    assert 'DEBUG: test_time took: 1' in mock_stdout.call_args[0][0]

# Generated at 2022-06-12 10:32:44.636376
# Unit test for function debug
def test_debug():
    import io
    buffer = io.StringIO()
    settings.debug = True

    with saved_stderr(buffer):
        debug(u'unicode message')
        assert buffer.getvalue().endswith('unicode message\n')

    with saved_stderr(buffer):
        debug('string message')
        assert buffer.getvalue().endswith('string message\n')

    assert u'string message' == 'string message'

    settings.debug = False

    with saved_stderr(buffer):
        debug('string message')
        assert buffer.getvalue() == ''



# Generated at 2022-06-12 10:32:46.013898
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Debug'):
        pass



# Generated at 2022-06-12 10:32:53.196774
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    # given
    import io
    import sys
    output = io.StringIO()
    saved_stdout = sys.stdout
    sys.stdout = output

    # when
    how_to_configure_alias(None)

    # then
    assert output.getvalue() == u"""\
Seems like \x1b[1mfuck\x1b[22m alias isn't configured!
More details - https://github.com/nvbn/thefuck#manual-installation\n"""

    # when

# Generated at 2022-06-12 10:32:58.468035
# Unit test for function debug_time
def test_debug_time():
    time = datetime.now()
    debug_time('test')(time)
    return time

# Generated at 2022-06-12 10:33:02.335249
# Unit test for function debug_time
def test_debug_time():
    import StringIO
    file_ = StringIO.StringIO()
    def k():
        import time
        time.sleep(0.05)
    with debug_time('test'):
        k()
    assert 'test took' in file_.getvalue()

# Generated at 2022-06-12 10:33:03.704349
# Unit test for function debug
def test_debug():
    print('test_debug')
    debug('test')


# Generated at 2022-06-12 10:33:05.889665
# Unit test for function confirm_text
def test_confirm_text():
    # No side effect
    corrected_command = 'hello --fix'
    assert confirm_text(corrected_command) == 'hello --fix'



# Generated at 2022-06-12 10:33:06.447471
# Unit test for function debug
def test_debug():
    debug('hi')

# Generated at 2022-06-12 10:33:07.928263
# Unit test for function debug
def test_debug():
    assert debug('test') == None


# Generated at 2022-06-12 10:33:10.030297
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('hello world')
    settings.debug = False
    debug('good bye world')

# Generated at 2022-06-12 10:33:16.073729
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand():
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    corrected_command = CorrectedCommand("ls --la", False)
    assert(show_corrected_command(corrected_command) == None)
    corrected_command = CorrectedCommand("ls --la", True)
    assert(show_corrected_command(corrected_command) == None)


# Generated at 2022-06-12 10:33:17.861435
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass

# Generated at 2022-06-12 10:33:25.363264
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from .conf import settings
    from . import utils

    settings.debug = True

    with patch.object(utils.sys.stderr, 'write') as write_mock:
        with utils.debug_time('test_debug_time'):
            pass

    assert write_mock.called
    assert 'test_debug_time' in write_mock.call_args.args[0]
    assert ' took:' in write_mock.call_args.args[0]



# Generated at 2022-06-12 10:33:36.233698
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .utils import get_closest, get_aliases_path, get_shell_info
    import os
    import pathlib

    shell_info = get_shell_info()
    config_details = os.path.join(
        get_closest(pathlib.Path(os.path.expanduser('~')).parts,
                    get_aliases_path()),
        'thefuck_alias')
    f = open(config_details, "w")

    how_to_configure_alias(config_details)

# Generated at 2022-06-12 10:33:46.595126
# Unit test for function confirm_text
def test_confirm_text():
    user_command_mark = const.USER_COMMAND_MARK
    correct = 'Correct'
    side_effect = ' +side effect'
    confirm = confirm_text(correct, side_effect)
    assert confirm == (u'{prefix}{clear}{bold}{correct}{reset}{side_effect} '
                       u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
                       u'/{red}ctrl+c{reset}]'.format(
                           prefix=user_command_mark,
                           clear='\033[1K\r',
                           bold='',
                           correct=correct,
                           reset='',
                           side_effect=side_effect,
                           green='',
                           red='',
                           blue=''))

# Generated at 2022-06-12 10:33:50.130612
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('foo') == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:33:57.027116
# Unit test for function debug
def test_debug():
    from cStringIO import StringIO
    stdout = sys.stderr
    sys.stderr = StringIO()
    try:
        std = 'hello world!'
        debug(std)
        assert sys.stderr.getvalue() == \
               '\x1b[34m\x1b[1mDEBUG:\x1b[0m hello world!\n'

        sys.stderr.truncate(0)
        settings.debug = False
        debug(std)
        assert sys.stderr.getvalue() == ''

    finally:
        sys.stderr = stdout

# Generated at 2022-06-12 10:34:01.785838
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .types import ConfigurationDetails
    details = ConfigurationDetails(Shell.from_shell_name('bash'),
                                   'bash',
                                   '~/.bashrc',
                                   'source ~/.bashrc',
                                   '~/.bashrc',
                                   False,
                                   'haha',
                                   True)
    how_to_configure_alias(details)

# Generated at 2022-06-12 10:34:04.461817
# Unit test for function debug_time
def test_debug_time():
    def debug_time_in_func():
        with debug_time('test_debug_time'):
            pass

    if 'test_debug_time' not in globals():
        print('bad function debug_time')

if __name__ == '__main__':
    test_debug_time()

# Generated at 2022-06-12 10:34:07.086031
# Unit test for function color
def test_color():
    assert not color('')
    assert color(colorama.Fore.RED) == colorama.init() + colorama.Fore.RED

# Generated at 2022-06-12 10:34:07.929896
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:34:15.319485
# Unit test for function confirm_text
def test_confirm_text():
    _original_stdout = sys.stdout
    try:
        from cStringIO import StringIO
        sys.stdout = mystdout = StringIO()
        conf_text = 'command'
        sys.stderr.write('\033[1K\r')
        confirm_text(conf_text)
        assert ('\033[1K\r' + conf_text + ' [enter/↑/↓/ctrl+c]') in mystdout.getvalue()
    finally:
        sys.stdout = _original_stdout

# Generated at 2022-06-12 10:34:18.059894
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write('\x1b[1K\rtest')
    assert sys.stderr.getvalue() == 'test'
    sys.stderr.write(' test')
    assert sys.stderr.getvalue() == 'test test'

# Generated at 2022-06-12 10:34:21.524167
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:34:24.065694
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command=u'ls ~')



# Generated at 2022-06-12 10:34:26.530792
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    show_corrected_command(CorrectedCommand('test', False))
    show_corrected_command(CorrectedCommand('test', True))

# Generated at 2022-06-12 10:34:29.199966
# Unit test for function color
def test_color():
    assert color('') == ''
    settings.no_colors = True
    assert color('.') == ''
    settings.no_colors = False



# Generated at 2022-06-12 10:34:31.070806
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .repl import CorrectedCommand
    show_corrected_command(CorrectedCommand('ls', ''))



# Generated at 2022-06-12 10:34:35.442802
# Unit test for function debug
def test_debug():
    import sys
    from mock import Mock
    from thefuck.utils import debug
    settings.debug = True
    sys.stderr = Mock()
    debug(u'Foo')
    sys.stderr.write.assert_called_once_with(u'{blue}{bold}DEBUG:{reset} Foo\n')

# Generated at 2022-06-12 10:34:36.424154
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) != None


# Generated at 2022-06-12 10:34:46.131147
# Unit test for function confirm_text
def test_confirm_text():
    import tempfile
    import os

    tmp_file = tempfile.NamedTemporaryFile(delete=False)
    tmp_file.close()

    os.environ['FUCK_ALIAS'] = 'fuck'
    os.environ['FUCK_RULE'] = 'echo'
    os.environ['FUCK_HISTORY'] = tmp_file.name

    confirm_text(corrected_command='echo "foo"')
    with open(tmp_file.name, 'r') as tmp_reader:
        assert tmp_reader.read().endswith('fuck echo "foo"\n')

    confirm_text(corrected_command='echo bar')
    with open(tmp_file.name, 'r') as tmp_reader:
        assert tmp_reader.read().endswith('fuck echo bar\n')

    os

# Generated at 2022-06-12 10:34:47.710433
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == '\x1b[34m'



# Generated at 2022-06-12 10:34:48.661649
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert (show_corrected_command("corrected_command")) is None

# Generated at 2022-06-12 10:34:53.183321
# Unit test for function color
def test_color():
    settings.no_colors = False
    assert color(u'foo') == u'foo'
    settings.no_colors = True
    assert color(u'foo') == u''

# Generated at 2022-06-12 10:35:04.527541
# Unit test for function debug
def test_debug():
    import StringIO
    from thefuck import settings

    settings.debug = True
    debug('foo')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'
    sys.stderr = StringIO.StringIO()

    settings.debug = True
    debug(u'бар')
    assert sys.stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m \u0431\u0430\u0440\n'
    sys.stderr = StringIO.StringIO()

    settings.debug = False
    debug('foo')
    assert sys.stderr.getvalue() == ''
    sys.stderr = String

# Generated at 2022-06-12 10:35:10.769291
# Unit test for function debug
def test_debug():
    from mock import patch
    with patch('sys.stderr') as stderr:
        debug(u'Hello')
        stderr.write.assert_called_with(
            u'{blue}{bold}DEBUG:{reset} Hello\n'.format(
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))



# Generated at 2022-06-12 10:35:18.129116
# Unit test for function debug
def test_debug():
    from mock import patch, mock_open
    with patch('thefuck.utils.sys.stderr') as stderr_mock:
        open_mock = mock_open()
        with patch('thefuck.utils.open', open_mock, create=True):
            debug('foo')
    open_mock.assert_called_with('.thefuck.log', 'a')
    stderr_mock.write.assert_called_once_with(u'{blue}{bold}DEBUG:{reset} foo\n'.format(
        blue=color(colorama.Fore.BLUE),
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)
    ))

# Generated at 2022-06-12 10:35:20.010657
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(const.CorrectedCommand('vim test.py', False)) == None


# Generated at 2022-06-12 10:35:24.159745
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from thefuck.utils import debug_time

    with patch('sys.stderr.write') as stderr_write:
        with debug_time('some_msg'):
            pass
        stderr_write.assert_called()

# Generated at 2022-06-12 10:35:25.657440
# Unit test for function color
def test_color():
    assert '\033[32mHello\033[0m' == color('Hello')

# Generated at 2022-06-12 10:35:27.792557
# Unit test for function color
def test_color():
    assert not color('test')
    settings.no_colors = False
    assert color('test') == 'test'
    settings.no_colors = True


# Generated at 2022-06-12 10:35:28.375066
# Unit test for function debug
def test_debug():
    debug('hello')

# Generated at 2022-06-12 10:35:30.113269
# Unit test for function color
def test_color():
    assert color('red') == 'red'
    assert color('green') == 'green'
    assert color('blue') == ''

# Generated at 2022-06-12 10:35:36.117625
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    command = CorrectedCommand(script='ls -la', side_effect=True)
    assert show_corrected_command(command) is None

# Generated at 2022-06-12 10:35:41.006220
# Unit test for function confirm_text
def test_confirm_text():
    import sys
    colorama.init(autoreset=True)
    from thefuck.utils import CorrectedCommand, Command
    command = Command('fuck', '', 'fuck this')
    corrected_command = CorrectedCommand(command, 'ls', False)
    confirm_text(corrected_command)


if __name__ == '__main__':
    test_confirm_text()

# Generated at 2022-06-12 10:35:42.945140
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(
        corrected_command.CorrectedCommand(
            script=u'git add tests.py',
            side_effect=False))

# Generated at 2022-06-12 10:35:44.813023
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('ls') == 'fuck: ls [enter/↑/↓/ctrl+c]'



# Generated at 2022-06-12 10:35:47.861176
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell

    for configuration_details in [None, Shell('bash').get_configuration_details()]:
        how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:35:49.480278
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import Command
    show_corrected_command(Command('ls', 'cd'))



# Generated at 2022-06-12 10:35:50.947255
# Unit test for function color
def test_color():
    assert color('color') == 'color'
    settings.no_colors = True
    assert color('color') == ''

# Generated at 2022-06-12 10:35:55.906176
# Unit test for function debug
def test_debug():
    import logging
    import mock
    logging.debug = mock.Mock()
    debug('foobar')
    assert logging.debug.called
    assert logging.debug.call_args[0][0] == 'foobar'
    assert logging.debug.mock_calls == \
        [mock.call('foobar')]

# Generated at 2022-06-12 10:35:56.912607
# Unit test for function debug
def test_debug():
    assert debug('test debug') is None

# Generated at 2022-06-12 10:36:04.008387
# Unit test for function debug
def test_debug():
    from mock import patch
    from . import debug

    debug_value = 'test debug value'
    with patch('thefuck.log.sys.stderr.write') as _debug:
        settings.debug = True
        debug(debug_value)
        _debug.assert_called_with('\x1b[34m\x1b[1mDEBUG:\x1b[0m test debug value\n')

    with patch('thefuck.log.sys.stderr.write') as _debug:
        settings.debug = False
        debug(debug_value)
        _debug.assert_not_called()

# Generated at 2022-06-12 10:36:11.117225
# Unit test for function debug
def test_debug():
    from StringIO import StringIO

    out = StringIO()
    settings.debug = True

    with debug_time('foo'):
        sys.stderr = out
        debug('foo bar')

    assert out.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo bar\n\n'

# Generated at 2022-06-12 10:36:12.101104
# Unit test for function debug_time
def test_debug_time():
    with debug_time('qqq'):
        pass

# Generated at 2022-06-12 10:36:14.796380
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    start = datetime.now()
    with debug_time('test'):
        pass
    stop = datetime.now()
    assert start < stop


# Generated at 2022-06-12 10:36:16.217445
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('test') == u'$test [test]'

# Generated at 2022-06-12 10:36:17.194497
# Unit test for function debug
def test_debug():
    assert debug('foo') is None

# Generated at 2022-06-12 10:36:23.918888
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import mock
    import StringIO
    how_to_configure_alias(None)

    configuration_details = mock.Mock()
    configuration_details.bold = "BOLD"
    configuration_details.reset = "RESET"
    configuration_details.content = "CONTENT"
    configuration_details.path = "PATH"
    configuration_details.reload = "RELOAD"
    configuration_details.can_configure_automatically = True
    how_to_configure_alias(configuration_details)

# Generated at 2022-06-12 10:36:27.868477
# Unit test for function debug_time
def test_debug_time():
    from cStringIO import StringIO
    from mock import patch

    result = StringIO()
    with patch('sys.stderr', result):
        with debug_time('test'):
            pass
    result.seek(0)
    output = result.read()
    assert 'DEBUG: test took' in output

# Generated at 2022-06-12 10:36:29.443697
# Unit test for function debug
def test_debug():
    """It should print debug message"""
    debug(u'test')

# Generated at 2022-06-12 10:36:29.978601
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert True

# Generated at 2022-06-12 10:36:34.150250
# Unit test for function debug
def test_debug():
    import mock
    import io
    import os
    os.environ['THEFUCK_DEBUG'] = 'True'

    with mock.patch('sys.stderr', new=io.StringIO()) as mock_stderr:
        debug('foo')

    assert u'\nDEBUG: foo\n' in mock_stderr.getvalue()
    del os.environ['THEFUCK_DEBUG']

# Generated at 2022-06-12 10:36:45.773203
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO

    def confirm(command=''):
        output = StringIO.StringIO()
        sys.stderr = output
        confirm_text(command)

    confirm('')
    assert output.getvalue() == u"""➜  [\x1b[1m\x1b[92menter\x1b[0m/\x1b[34m↑\x1b[0m/\x1b[34m↓\x1b[0m/\x1b[31mctrl+c\x1b[0m]"""

    confirm(corrected_command='')

# Generated at 2022-06-12 10:36:54.569060
# Unit test for function confirm_text
def test_confirm_text():
    def check_both(string, expected_string):
        assert confirm_text(string) == expected_string
        assert confirm_text(string[::-1]) == expected_string[::-1]

    check_both(
        u'echo "Yes, fuck it"',
        u'$ echo "Yes, fuck it" [enter/↑/↓/ctrl+c]')
    check_both(
        u'echo "Yes, fuck it"',
        u'$ echo "Yes, fuck it" [enter/↑/↓/ctrl+c]')
    check_both(
        u'echo "Yes, fuck it"',
        u'$ echo "Yes, fuck it" [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-12 10:37:01.193981
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    try:
        import colorama
        colorama.init()
    except ImportError:
        colorama = None

    from .conf import ConfigurationNotFound
    configuration_details = (ConfigurationNotFound('bash', '~/.bashrc',
        'echo \'eval $(thefuck --alias)\' >> ~/.bashrc && source ~/.bashrc',
        True, 'source ~/.bashrc'))
    how_to_configure_alias(configuration_details)
    # assert False # for visual testing

# Generated at 2022-06-12 10:37:03.814999
# Unit test for function debug
def test_debug():
    assert debug('test_debug') == sys.stderr.write('\x1b[34m\x1b[1mDEBUG:\x1b[0m\x1b[0m test_debug\n')

# Generated at 2022-06-12 10:37:06.176122
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    with debug_time('test'):
        pass
    return (datetime.now() - started).total_seconds() > 0

# Generated at 2022-06-12 10:37:10.999034
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr = open('temp', 'w')
    show_corrected_command(
        const.CorrectedCommand(u'script', u'script + side effect', True))
    output = open('temp').read()
    sys.stderr = sys.__stderr__
    assert output == const.USER_COMMAND_MARK + u'script + side effect (+side effect)\n'



# Generated at 2022-06-12 10:37:11.444342
# Unit test for function debug_time
def test_debug_time():
    assert debug_time

# Generated at 2022-06-12 10:37:12.322234
# Unit test for function debug_time
def test_debug_time():
    with debug_time('some operation'):
        pass

# Generated at 2022-06-12 10:37:13.307124
# Unit test for function debug
def test_debug():
    debug('some debug something')

# Generated at 2022-06-12 10:37:19.981199
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    try:
        import shlex
        shlex.quote('echo')
    except AttributeError:
        print("1. OK!")
    else:
        print("1. ERROR!")
        
    try:
        import shutil
        shutil.which('echo')
    except AttributeError:
        print("2. OK!")
    else:
        print("2. ERROR!")
        

if __name__ == '__main__':
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:37:27.143876
# Unit test for function debug
def test_debug():
    from io import BytesIO
    from contextlib import redirect_stdout
    from . import log

    with redirect_stdout(BytesIO()) as stdout:
        log.debug('test')
    assert stdout.getvalue() == b'fuck-as-a-service daemon: DEBUG: test\n'

# Generated at 2022-06-12 10:37:30.919124
# Unit test for function show_corrected_command
def test_show_corrected_command():
    fake_corrected_command = FakeCorrectedCommand()
    show_corrected_command(fake_corrected_command)
    assert 'fuck-test-command' in sys.stderr.getvalue()
    assert '+side effect' in sys.stderr.getvalue()


# Generated at 2022-06-12 10:37:32.218434
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    show_corrected_command(CorrectedCommand('cat u.txt'))



# Generated at 2022-06-12 10:37:35.889565
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import Command
    from .shells import SimpleAndPythonShell

    script = 'git push'
    side_effect = True
    command = Command(script, side_effect)

    # The result must be showed in stdout
    assert sys.stderr.stream.write(u'{}\n'.format(script)) == len(script) + 1



# Generated at 2022-06-12 10:37:42.718934
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git push origin master') == \
           '{0}^Cgit push origin master {1}[{2}enter{1}/{3}↑{1}/{3}↓{1}/{4}ctrl+c{1}]'\
           .format(const.USER_COMMAND_MARK,
                   color(colorama.Style.RESET_ALL),
                   color(colorama.Fore.GREEN),
                   color(colorama.Fore.BLUE),
                   color(colorama.Fore.RED))

# Generated at 2022-06-12 10:37:51.746340
# Unit test for function confirm_text
def test_confirm_text():
    def run_confirm_text(command, side_effect):
        class CorrectedCommand(object):
            def __init__(self):
                self.script = command
                self.side_effect = side_effect

        sys.stderr = sys.__stderr__
        sys.__stderr__.write("")
        confirm_text(CorrectedCommand())
        assert sys.__stderr__.getvalue().rstrip() == '{}[sudo] password for thomas: {}[enter]/[↑]/[↓]/[ctrl+c]'.format(const.USER_COMMAND_MARK, '')

    run_confirm_text("sudo ls", True)
    run_confirm_text("sudo ls", False)

# Generated at 2022-06-12 10:38:00.237246
# Unit test for function debug
def test_debug():
    def assert_write(msg):
        with patch('sys.stderr') as stderr:
            debug(msg)
            stderr.write.assert_called_once_with(u'{}{}{} {}\n'.format(
                color(colorama.Fore.BLUE),
                color(colorama.Style.BRIGHT),
                'DEBUG:',
                msg))

    with patch('thefuck.utils.settings', debug=True):
        assert_write('any message')

    with patch('thefuck.utils.settings', debug=False):
        with patch('sys.stderr') as stderr:
            debug('any message')
            assert not stderr.write.called

# Generated at 2022-06-12 10:38:01.203543
# Unit test for function debug
def test_debug():
    debug('I\'am a test')

# Generated at 2022-06-12 10:38:02.644521
# Unit test for function debug
def test_debug():
    settings.debug = True
    try:
        debug('abc')
    finally:
        settings.debug = False

# Generated at 2022-06-12 10:38:05.678157
# Unit test for function debug
def test_debug():
    import sys
    import mock
    from thefuck.utils import debug
    debug('test', settings)
    written_value = sys.stderr.write.call_args[0][0]

    assert written_value == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-12 10:38:09.379814
# Unit test for function confirm_text
def test_confirm_text():
    return confirm_text(corrected_command="ls --all")



# Generated at 2022-06-12 10:38:10.235770
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-12 10:38:15.085415
# Unit test for function debug
def test_debug():
    import pytest
    with pytest.raises(AttributeError):
        settings.debug = 'hi'

    settings.debug = True
    debug('hi')
    settings.debug = False
    with pytest.raises(TypeError):
        debug(1)
    settings.debug = True
    debug(1)

# Generated at 2022-06-12 10:38:20.737059
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import timedelta

    @contextmanager
    def time(value):
        yield value

    def func():
        for i in range(1):
            with debug_time('main'):
                with time(timedelta(seconds=1)):
                    pass
                with debug_time('sub'):
                    with time(timedelta(seconds=2)):
                        pass

    func()

# Generated at 2022-06-12 10:38:22.490987
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    time = datetime.now()
    assert debug_time('foo')

# Generated at 2022-06-12 10:38:23.600283
# Unit test for function debug
def test_debug():
    assert debug('message') == None


# Generated at 2022-06-12 10:38:24.971862
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command("mkdir hello") == None

# Generated at 2022-06-12 10:38:26.839026
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        import time
        time.sleep(1)

# Generated at 2022-06-12 10:38:27.686762
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text("test") == None

# Generated at 2022-06-12 10:38:28.182132
# Unit test for function debug
def test_debug():
    debug('debug message')

# Generated at 2022-06-12 10:38:38.792372
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    with_details = StringIO.StringIO()
    how_to_configure_alias(const.ConfigurationDetails(
        '~/.bashrc',
        'eval $(thefuck --alias)',
        '~/.config/fish/config.fish',
        'eval (thefuck --alias fish)',
        'source $HOME/.config/fish/config.fish'))

# Generated at 2022-06-12 10:38:41.770985
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .utils import time

    @time
    def f():
        pass

    with debug_time('msg'):
        f()

# Generated at 2022-06-12 10:38:45.945538
# Unit test for function confirm_text
def test_confirm_text():
    from StringIO import StringIO
    from .main import confirm_text
    captured_output = StringIO()
    sys.stderr = captured_output
    confirm_text("test")
    assert captured_output.getvalue().strip()=='test\n'

# Generated at 2022-06-12 10:38:52.900917
# Unit test for function debug
def test_debug():
    import mock
    import tempfile
    import os

    with mock.patch('thefuck.shells.get_all_shells', return_value=[]):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            with mock.patch('sys.stderr', f):
                with mock.patch('sys.version_info', (2, 7, 5, 'final', 0)):
                    from thefuck import utils
                    utils.debug(u'привет!')
                    debug(u'привет!')
            with open(f.name) as _f:
                content = _f.read()
            os.unlink(f.name)

# Generated at 2022-06-12 10:38:59.429428
# Unit test for function debug_time
def test_debug_time():
    import time

    class Timer(object):
        def __enter__(self):
            self._started = time.time()

        def __exit__(self, *args, **kwargs):
            self.elapsed = time.time() - self._started

    with Timer() as timer:
        with debug_time('foobar'):
            time.sleep(1)

    assert timer.elapsed > 1

# Generated at 2022-06-12 10:39:01.185421
# Unit test for function debug_time
def test_debug_time():
    import datetime
    with debug_time('test'):
      assert datetime.datetime.now()

# Generated at 2022-06-12 10:39:03.996701
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells import Generic
    show_corrected_command(Generic())
    Generic().script = "git branch"
    Generic().side_effect = True
    show_corrected_command(Generic())

# Generated at 2022-06-12 10:39:12.299437
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = mystdout = StringIO.StringIO()
    how_to_configure_alias(None)
    sys.stdout = old_stdout
    assert (mystdout.getvalue() == u"Seems like {bold}fuck{reset} alias isn't configured!\nMore details - https://github.com/nvbn/thefuck#manual-installation\n".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL)))


# Generated at 2022-06-12 10:39:13.422778
# Unit test for function debug_time
def test_debug_time():
    with debug_time("This took"):
        time.sleep(0.1)

# Generated at 2022-06-12 10:39:17.693495
# Unit test for function debug
def test_debug():
    from .entrypoints import _debug
    from .conf import load_settings
    from .rules.any_command import fuck
    load_settings()
    settings.debug = True
    try:
        with _debug('test_fuck'):
            fuck()
    except Exception as e:
        # The debug level doesn't matter, we should just get the exception
        assert True
    else:
        assert False



# Generated at 2022-06-12 10:39:25.027332
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias({'path': 'test.txt', 'reload': 'reload'})

# Generated at 2022-06-12 10:39:30.074241
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect=None):
            self.script = script
            self.side_effect = side_effect

    show_corrected_command(CorrectedCommand('git branch'))
    show_corrected_command(CorrectedCommand(
        'git branch', side_effect='git branch'))
    show_corrected_command(CorrectedCommand(
        'git branch', side_effect=None))


# Generated at 2022-06-12 10:39:37.326057
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import tempfile
    import os
    corrected_command = 'fuck cd'
    with tempfile.NamedTemporaryFile(suffix='.py') as test_file:
        execfile(test_file.name, {'__file__': test_file.name})
        fd = os.dup(sys.stderr.fileno())
        stderr = os.fdopen(fd)
        show_corrected_command(corrected_command)
        assert corrected_command in stderr.read()



# Generated at 2022-06-12 10:39:44.435724
# Unit test for function confirm_text
def test_confirm_text():
    from .conf import settings
    from . import const

    settings.side_effect = True
    assert (
        confirm_text('') == const.USER_COMMAND_MARK + '' + ' (+side effect) '
        + '[\033[32menter\033[0m/\033[34m↑\033[0m/\033[34m↓\033[0m/\033[31mctrl+c'
        + '\033[0m]')
    settings.side_effect = False

# Generated at 2022-06-12 10:39:50.656447
# Unit test for function debug
def test_debug():
    import StringIO
    sio = StringIO.StringIO()
    settings.debug = True
    _stdout = sys.stderr
    sys.stderr = sio
    try:
        debug(u'msg')
        assert sio.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m msg\n'
    finally:
        settings.debug = False
        sys.stderr = _stdout

# Generated at 2022-06-12 10:39:53.774016
# Unit test for function debug_time
def test_debug_time():
    # before using debug_time
    debug("hello world")
    # using debug_time
    with debug_time("test"):
        assert True
    # after using debug_time
    debug("hello world")

# Generated at 2022-06-12 10:40:01.986250
# Unit test for function confirm_text
def test_confirm_text():
    """
    Test confirm text

    :return:
    """
    from thefuck.shells.sh import FindExternalCommand
    from thefuck.shells.bash import Bash

    # correct text
    corrected_command = FindExternalCommand('test.sh', 'test.sh', u'/tmp/', u'testshell')
    assert confirm_text(corrected_command) == 'fuck>test.sh   [enter/↑/↓/ctrl+c]'

    # side effect text
    corrected_command = FindExternalCommand('test.sh', 'test.sh', u'/tmp/', u'testshell', side_effect=True)
    assert confirm_text(corrected_command) == 'fuck>test.sh   (+side effect) [enter/↑/↓/ctrl+c]'

    # wrong text

# Generated at 2022-06-12 10:40:03.530006
# Unit test for function color
def test_color():
    assert color('test_color') == color('test_color')
    assert color(colorama.Back.RED) == ''

# Generated at 2022-06-12 10:40:05.011559
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time(u'test'):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-12 10:40:06.255471
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('pwd') == '[enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:40:12.966048
# Unit test for function color
def test_color():
    assert color('red') == ''
    settings.no_colors = False
    assert color('red') == 'red'



# Generated at 2022-06-12 10:40:17.397141
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    with patch('sys.stderr', new=StringIO()) as fake_stderr:
        debug('test')
        assert fake_stderr.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-12 10:40:27.441497
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from . import conf
    from .types import ConfigurationDetails
    from .utils import get_closest

    def get_path_type(shell):
        return get_closest(shell, (conf.bash_path, conf.zsh_path, conf.fish_path),
                           default=conf.bash_path)

    path = get_path_type(Shell.from_shell_name('bash'))
    configuration_details = ConfigurationDetails(
        path=path,
        content='eval $(thefuck --alias)',
        reload='exec fish',
        can_configure_automatically=True)
    how_to_configure_alias(configuration_details)
    assert True


if __name__ == "__main__":
    test_how_to_configure_alias()

# Generated at 2022-06-12 10:40:28.680692
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test_debug_time'):
        pass

# Generated at 2022-06-12 10:40:30.198130
# Unit test for function debug_time

# Generated at 2022-06-12 10:40:33.399463
# Unit test for function debug
def test_debug():
    class Dummy(object):
        def __init__(self):
            self.debug = False

    settings = Dummy()

    print("========== debug output ==========")
    debug("Test")
    settings.debug = True
    debug("Test")
    print("==================================")

# Generated at 2022-06-12 10:40:39.463938
# Unit test for function color
def test_color():
    from unittest import mock
    from . import formatting
    formatting.settings.no_colors = False
    assert '\x1b[1;37;41m' == formatting.color('\x1b[1;37;41m')
    formatting.settings.no_colors = True
    with mock.patch('sys.stderr') as stderr_:
        assert '' == formatting.color('\x1b[1;37;41m')
        assert 0 == stderr_.write.call_count



# Generated at 2022-06-12 10:40:40.258077
# Unit test for function debug
def test_debug():
    debug('Hello World')

# Generated at 2022-06-12 10:40:41.554661
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    assert started.day == 1



# Generated at 2022-06-12 10:40:43.045291
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('pip install abc')
    assert True, 'hi'

# Generated at 2022-06-12 10:40:49.303042
# Unit test for function debug
def test_debug():
    assert not debug.__name__.startswith('_')

# Generated at 2022-06-12 10:40:50.720531
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:40:52.613330
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert u"" == how_to_configure_alias(None)
    assert u"" != how_to_configure_alias('configuration_details')

# Generated at 2022-06-12 10:40:54.097413
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(None) is None

# Generated at 2022-06-12 10:41:03.236896
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime
    from .conf import settings
    settings.debug = True
    message = "unit test debug msg"

    @contextmanager
    def debug_time(msg):
        started = datetime.now()
        try:
            yield
        finally:
            sys.stderr.write(u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
                msg=msg,
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)))
    with debug_time(message):
        pass

# Generated at 2022-06-12 10:41:10.387446
# Unit test for function debug
def test_debug():
    import io
    import sys
    sys.stderr = io.StringIO()
    sys.stderr.isatty = lambda: True
    debug('message')
    sys.stderr.seek(0)
    assert sys.stderr.read() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m message\n'

    sys.stderr = io.StringIO()
    sys.stderr.isatty = lambda: True
    settings.no_colors = True
    debug('message')
    sys.stderr.seek(0)
    assert sys.stderr.read() == 'DEBUG: message\n'

# Generated at 2022-06-12 10:41:14.783890
# Unit test for function confirm_text
def test_confirm_text():
    class Command:
        def __init__(self, script, side_effect=None):
            self.script = script
            self.side_effect = side_effect

    confirm_text(Command('ls', True))
    confirm_text(Command('pip install lxml', False))
    confirm_text(Command('ls'))

# Generated at 2022-06-12 10:41:15.776312
# Unit test for function debug_time
def test_debug_time():
    debug_time(0)

# Generated at 2022-06-12 10:41:19.071069
# Unit test for function debug
def test_debug():
    from .conf import Settings
    settings = Settings()
    settings.debug = True
    debug(u'Hallo')
    #sys.stdout.flush()


if __name__ == '__main__':
    test_debug()

# Generated at 2022-06-12 10:41:26.028772
# Unit test for function confirm_text
def test_confirm_text():
    import StringIO

    sys.stdout = StringIO.StringIO()
    confirm_text('')

# Generated at 2022-06-12 10:41:32.797031
# Unit test for function color
def test_color():
    assert color(u'test') == u'test'
    settings.no_colors = True
    assert color(u'test') == u''

# Generated at 2022-06-12 10:41:34.561298
# Unit test for function color
def test_color():
    assert color('fucked') == 'fucked'
    settings.no_colors = True
    assert color('fucked') == ''

# Generated at 2022-06-12 10:41:36.281156
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write('\n')
    show_corrected_command(const.CorrectedCommand('git comit', False))
    sys.stderr.write('\n')

# Generated at 2022-06-12 10:41:37.157955
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias is not None

# Generated at 2022-06-12 10:41:47.584008
# Unit test for function debug_time
def test_debug_time():
    import time
    from datetime import timedelta
    from io import StringIO
    time.sleep(0.3)
    debug_out = StringIO()
    with debug_time(u'Test'):
        time.sleep(0.5)

    sys.stderr = debug_out
    time.sleep(0.2)
    with debug_time(u'Test'):
        time.sleep(0.1)
    assert abs(
        timedelta(seconds=0.6) -
        timedelta(seconds=float(debug_out.getvalue()
                                .split(u' took: ')[1].split()[0]))) < timedelta(seconds=0.2)

# Generated at 2022-06-12 10:41:49.985918
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .conf.corrected_command import CorrectedCommand
    x = CorrectedCommand('test script', False)
    show_corrected_command(x)



# Generated at 2022-06-12 10:41:54.786723
# Unit test for function debug
def test_debug():
    from .tests.utils import capture_stdout
    with capture_stdout() as stdout:
        debug('foo')
    assert stdout.getvalue() == '\n'

    settings.debug = True
    with capture_stdout() as stdout:
        debug('foo')
    assert stdout.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n'

# Generated at 2022-06-12 10:41:55.792907
# Unit test for function debug
def test_debug():
    """
    testing debug function
    :return:
    """
    debug('1')

# Generated at 2022-06-12 10:41:59.830757
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from mock import patch
    from datetime import datetime 
    from . import rules
    from . import corrector
    from .corrector import Command


    corrected_command = Command('cd ../../../fuckyou', True)
    with patch.object(sys.stderr, 'write') as mocked_print:
        show_corrected_command(corrected_command)
        assert mocked_print.called



# Generated at 2022-06-12 10:42:06.903236
# Unit test for function debug
def test_debug():
    from unittest import mock
    from thefuck.utils import settings

    settings.debug = True
    with mock.patch('sys.stderr') as stderr:
        debug(u'foo')
        stderr.write.assert_called_once_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n')

    settings.debug = False
    with mock.patch('sys.stderr') as stderr:
        debug(u'bar')
        assert not stderr.write.called