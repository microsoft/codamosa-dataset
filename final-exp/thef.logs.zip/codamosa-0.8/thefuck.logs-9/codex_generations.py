

# Generated at 2022-06-12 10:32:14.476481
# Unit test for function debug_time
def test_debug_time():
    from mock import call
    from mock import MagicMock
    import __builtin__
    __builtin__.__dict__.update({'debug': MagicMock(), 'datetime': MagicMock()})
    with debug_time('foo'):
        debug.assert_called_once_with('foo took: None')
    debug.reset_mock()
    with debug_time('foo'):
        datetime.now.return_value.__sub__.return_value = 'foo'
        debug.assert_called_once_with('foo took: foo')

# Generated at 2022-06-12 10:32:15.113558
# Unit test for function debug
def test_debug():
    assert debug('test_msg') == None

# Generated at 2022-06-12 10:32:21.747935
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == colorama.Fore.RED
    assert colorama.Fore.RED not in color(colorama.Fore.RED)

    assert color(colorama.Back.RED) == colorama.Back.RED
    assert colorama.Back.RED not in color(colorama.Back.RED)

    assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
    assert colorama.Style.BRIGHT not in color(colorama.Style.BRIGHT)

# Generated at 2022-06-12 10:32:25.496398
# Unit test for function debug
def test_debug():
    stdout = sys.stdout  # reassign stdout to variable
    try:
        sys.stdout = sys.stderr  # reassign stdout
        debug('Debug message')
    finally:
        sys.stdout = stdout  # restore stdout to original value

# Generated at 2022-06-12 10:32:27.351250
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert (show_corrected_command('git push origin master') ==
            'git push origin master')

# Generated at 2022-06-12 10:32:28.269199
# Unit test for function debug_time
def test_debug_time():
    with debug_time('something'):
        pass

# Generated at 2022-06-12 10:32:29.146639
# Unit test for function color
def test_color():
    assert color('test') == 'test'



# Generated at 2022-06-12 10:32:32.373430
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell

    s = Shell('zsh')

    how_to_configure_alias(s)

    s.configuration_details.can_configure_automatically = False
    how_to_configure_alias(s)

# Generated at 2022-06-12 10:32:37.485105
# Unit test for function debug_time
def test_debug_time():
    def testee():
        with debug_time('Function'):
            pass

    # Make sure there is no side-effect in the unit test
    debug_buffer = sys.stderr
    sys.stderr = _MockWritable()

    try:
        testee()
        assert False
    except AssertionError:
        pass

    sys.stderr = debug_buffer



# Generated at 2022-06-12 10:32:41.755975
# Unit test for function debug_time
def test_debug_time():
    from StringIO import StringIO
    old_stderr, sys.stderr = sys.stderr, StringIO()
    settings.debug = True
    try:
        with debug_time('i am too lazy to mock time'):
            pass
        assert 'i am too lazy to mock time took: ' in sys.stderr.getvalue()
    finally:
        sys.stderr = old_stderr

# Generated at 2022-06-12 10:32:46.921307
# Unit test for function debug
def test_debug():

    new_setting = settings.debug
    settings.debug = True
    debug('debug')

    settings.debug = False
    debug('debug')
    assert settings.debug == new_setting

# Generated at 2022-06-12 10:32:49.137028
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert show_corrected_command(const.CorrectedCommand(script="ls", side_effect=True)) == "git add README.md"



# Generated at 2022-06-12 10:32:54.242383
# Unit test for function debug
def test_debug():
    import StringIO
    captured_output = StringIO.StringIO()
    sys.stderr = captured_output
    debug("test")
    sys.stderr = sys.__stderr__
    assert captured_output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

# Generated at 2022-06-12 10:33:00.257529
# Unit test for function debug_time
def test_debug_time():
    from mock import Mock
    from datetime import datetime, timedelta

    mock_time = datetime(year=2015, month=1, day=1)

    def mock_now():
        mock_time.replace(mock_time + timedelta(seconds=1))
        return mock_time

    datetime.now = Mock(wraps=mock_now)

    with debug_time('test'):
        pass

    assert datetime.now.called

# Generated at 2022-06-12 10:33:03.326357
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import pytest
    colorama.init()
    with pytest.raises(SystemExit):
        how_to_configure_alias(None)



# Generated at 2022-06-12 10:33:05.847914
# Unit test for function debug
def test_debug():
    try:
        raise RuntimeError('test')
    except Exception as e:
        debug(u'{}'.format(e.message))

test_debug()

# Generated at 2022-06-12 10:33:07.672405
# Unit test for function debug
def test_debug():
    try:
        settings.debug = True
        debug('Test debug')
    finally:
        settings.debug = False


# Generated at 2022-06-12 10:33:09.664002
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import colorama
    colorama.init()
    assert how_to_configure_alias() == None

# Generated at 2022-06-12 10:33:21.341563
# Unit test for function confirm_text
def test_confirm_text():
    import re
    import sys
    import tempfile
    import contextlib

    result = []
    def _mocked_stderr(msg):
        result.append(msg)

    with contextlib.redirect_stderr(tempfile.TemporaryFile(mode='w+')):
        sys.stderr.write = _mocked_stderr
        with contextlib.redirect_stdout(_mocked_stderr):
            with contextlib.redirect_stdin(tempfile.TemporaryFile(mode='w+')):
                from .output import confirm_text, CorrectedCommand
                confirm_text(CorrectedCommand(
                    script='a',
                    side_effect=True))


# Generated at 2022-06-12 10:33:26.711526
# Unit test for function debug
def test_debug():
    def test_logger(msg):
        test_logger.messages.append(msg)
    test_logger.messages = []
    sentinel = object()

    old_logger = sys.stderr.write
    try:
        sys.stderr.write = test_logger
        debug(sentinel)
    finally:
        sys.stderr.write = old_logger

    assert test_logger.messages == [u'DEBUG: {}\n'.format(sentinel)]

# Generated at 2022-06-12 10:33:35.941401
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from . import const
    from .types import Command
    from .utils import replace_argument
    show_corrected_command(CorrectedCommand(
        Command(script='git add file.py', stdout='On branch master',
                script_parts=('git', 'add', 'file.py')),
        replace_argument('git add', 'git push', 'file.py')))

# Generated at 2022-06-12 10:33:44.803050
# Unit test for function debug
def test_debug():
    class FakeOutput(object):
        def __init__(self):
            self.data = ''

        def write(self, data):
            self.data = data

        def clear(self):
            self.data = ''

    debug_out = FakeOutput()
    debug('lol')  # Will write to stderr if debug() is enabled
    assert debug_out.data == ''

    settings.debug = True

    debug('lol')  # Will write to stderr if debug() is enabled
    assert debug_out.data == '\x1b[34m\x1b[1mDEBUG:\x1b[0m lol\n'

# Generated at 2022-06-12 10:33:51.483949
# Unit test for function debug
def test_debug():
    from .tests.utils import Spy

    with Spy() as spy:
        debug('foo bar')
        assert not spy.called
        debug('baz')
        assert not spy.called

    with Spy() as spy:
        settings.debug = True
        debug('foo bar')
        assert spy.called
        assert spy.stdout == u'{blue}{bold}DEBUG:{reset} foo bar\n'.format(
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))
        debug('baz')

# Generated at 2022-06-12 10:33:53.954972
# Unit test for function debug_time
def test_debug_time():
    started = datetime.now()
    try:
        yield
    finally:
        debug(u'{} took: {}'.format("Hello", datetime.now() - started))

# Generated at 2022-06-12 10:34:02.872199
# Unit test for function confirm_text
def test_confirm_text():
    import io
    import sys
    import colorama
    colorama.init()
    fake_stderr = io.StringIO()
    sys.stderr = fake_stderr
    const.USER_COMMAND_MARK = '# '
    corrected_command = CorrectedCommand('ls', False)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:34:04.250675
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(False)



# Generated at 2022-06-12 10:34:05.860005
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass

# Generated at 2022-06-12 10:34:14.420572
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import _get_corrected_command
    from .main import Command
    correct_command = Command(script='echo', side_effect=True)
    assert show_corrected_command(correct_command) == \
        u'{prefix}{bold}{script}{reset}{side_effect}'.format(
            prefix=const.USER_COMMAND_MARK,
            script=_get_corrected_command(correct_command),
            side_effect=u' (+side effect)' if correct_command.side_effect else u'',
            bold=color(colorama.Style.BRIGHT),
            reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-12 10:34:15.365491
# Unit test for function debug
def test_debug():
    assert debug('hello') == None



# Generated at 2022-06-12 10:34:19.826263
# Unit test for function debug
def test_debug():
    with settings(debug=False):
        debug('foo')
        assert sys.stderr.getvalue() == ''
    with settings(debug=True):
        debug('foo')
        assert sys.stderr.getvalue() == '\x1b[36m\x1b[1mDEBUG:\x1b[0m foo\n'
    with settings(debug=True):
        with settings(no_colors=False):
            debug('foo')
            assert sys.stderr.getvalue() == '\x1b[36m\x1b[1mDEBUG:\x1b[0m foo\n'
    with settings(debug=True):
        with settings(no_colors=True):
            debug('foo')
            assert sys.stderr.getvalue() == 'DEBUG: foo\n'




# Generated at 2022-06-12 10:34:32.925437
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .shells import Shell
    from .utils import get_record_as_string

    commands = [
        ('git push origin master', 'git push origin && git push github master'),
        ('sudo !!', 'sudo fuck'),
        ('git push orrigin master', 'git push origin && git push github master'),
        ('git tag --a "test"', 'git tag --a test'),
        ('git branch test -m "message"', 'git branch test -m message'),
        ('git config --global user.email "me@mail.com"',
            'git config --global user.email me@mail.com'),
        ('git config --global user.name "My name"',
            'git config --global user.name My name')]

    messages = []

# Generated at 2022-06-12 10:34:38.157222
# Unit test for function debug
def test_debug():
    from mock import patch
    from StringIO import StringIO

    msg = u'привет'
    with patch('sys.stderr', new=StringIO()) as stderr,\
            patch.dict('fuck.utils.settings.__dict__', {'debug': True}):
        debug(msg)

    assert stderr.getvalue().endswith(u'DEBUG: привет\n')



# Generated at 2022-06-12 10:34:47.707896
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .configuration_details import ConfigurationDetails
    from .configuration_details import (
        ConfigurationDetails as CD,
        ConfigurationDetailsResult as CDR)

    # if the cases failed it will rase an error.
    cd = CD(CDR.AUTOMATIC, '/home', '', 'source /home/.zshrc')
    how_to_configure_alias(cd)

    cd = CD(CDR.AUTOMATIC, '/home', '', '')
    how_to_configure_alias(cd)

    cd = CD(CDR.NOT_AUTOMATIC, '/home', '.zshrc', 'source /home/.zshrc')
    how_to_configure_alias(cd)


# Generated at 2022-06-12 10:34:49.368349
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        pass

# Generated at 2022-06-12 10:34:54.244669
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .conf import ConfigurationDetails
    from .utils import b

    how_to_configure_alias(
        ConfigurationDetails(
            path='/home/nvbn/.config/fish/config.fish',
            content=b('eval (thefuck --alias)'),
            reload='source /home/nvbn/.config/fish/config.fish',
            can_configure_automatically=True))

# Generated at 2022-06-12 10:34:59.107702
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .shells.posix import Bash
    bash = Bash()
    command = bash.get_command('ls --al', '', '', 0, False)
    assert command == 'ls --al'
    show_corrected_command(command)
    assert command != 'ls -al'
    show_corrected_command(command)

# Generated at 2022-06-12 10:35:00.505070
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    assert color('bar') == ''



# Generated at 2022-06-12 10:35:04.871357
# Unit test for function confirm_text
def test_confirm_text():
    stdout = sys.stdout
    sys.stdout = sys.__stdout__
    from .conf import settings
    settings.no_colors = False
    confirm_text(const.CorrectedCommand(script='git add -p', side_effect=True))
    sys.stdout = stdout

# Generated at 2022-06-12 10:35:06.175286
# Unit test for function debug
def test_debug():
    assert debug('test') is None



# Generated at 2022-06-12 10:35:09.177251
# Unit test for function color
def test_color():
    """Check that colors are disabled when needed."""
    settings.no_colors = True
    assert color('foo') == ''
    settings.no_colors = False
    assert color('foo') == 'foo'

# Generated at 2022-06-12 10:35:14.552604
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:35:17.375410
# Unit test for function confirm_text
def test_confirm_text():
    # GIVEN correct command
    corrected_command = 'correct_command'
    # WHEN show text to confirm
    confirm_text(corrected_command)
    # THEN this text should be 'correct_command'
    assert confirm_text(corrected_command) == corrected_command

# Generated at 2022-06-12 10:35:22.765340
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    class configuration_details(object):
        def __init__(self):
            self.config_file = 'fake_config_file'
            self.reload = 'fake_reload'
            self.can_configure_automatically = True
    data = configuration_details()
    how_to_configure_alias(data)


# Generated at 2022-06-12 10:35:30.610970
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write(
        (u'{prefix}{clear}{bold}{script}{reset}{side_effect} '
         u'[{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}'
         u'/{red}ctrl+c{reset}]').format(
            prefix=const.USER_COMMAND_MARK,
            script=' ',
            side_effect=' ',
            clear='\033[1K\r',
            bold=color(colorama.Style.BRIGHT),
            green=color(colorama.Fore.GREEN),
            red=color(colorama.Fore.RED),
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE)))

# Generated at 2022-06-12 10:35:32.247979
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('time'):
        time.sleep(0.1)

# Generated at 2022-06-12 10:35:33.966312
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Some msg'):
        pass

# Generated at 2022-06-12 10:35:43.934284
# Unit test for function debug_time
def test_debug_time():
    import unittest
    import mock

    def test_time(count):
        for i in range(count):
            pass

    class DebugTimeTest(unittest.TestCase):
        @mock.patch('sys.stderr.write')
        def test_pass(self, mock_stderr):
            with debug_time('test'):
                test_time(10000)
            mock_stderr.assert_called_with(
                u'test took: {0}\n'.format(mock.ANY))

        @mock.patch('sys.stderr.write')
        def test_exception(self, mock_stderr):
            try:
                with debug_time('test'):
                    test_time(10000)
                    raise Exception()
            except:
                pass
            mock_stderr

# Generated at 2022-06-12 10:35:46.911420
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = {'path': '/some/path', 'can_configure_automatically': False}
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:35:49.046620
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED) == ''
    assert colorama.Fore.RED in color(colorama.Fore.RED)



# Generated at 2022-06-12 10:35:50.278139
# Unit test for function confirm_text
def test_confirm_text():
    from . import output
    output.confirm_text('shit')

# Generated at 2022-06-12 10:35:58.504115
# Unit test for function debug
def test_debug():
    from mock import patch, Mock
    from thefuck.utils import debug
    with patch('sys.stderr', Mock()) as mocked_stderr:
        debug('test')
        assert mocked_stderr.write.called



# Generated at 2022-06-12 10:36:01.418619
# Unit test for function show_corrected_command
def test_show_corrected_command():
    sys.stderr.write(const.USER_COMMAND_MARK)
    sys.stderr.write('foo bar')
    sys.stderr.write('\n')


# Generated at 2022-06-12 10:36:05.427749
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import datetime

    with patch('sys.stderr') as sys_stderr:
        with debug_time('test'):
            now = datetime.now()
            assert sys_stderr.write.call_args_list[0][0][0] == 'DEBUG: test took: {}\n'.format(now - now)



# Generated at 2022-06-12 10:36:07.092913
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass


# Generated at 2022-06-12 10:36:13.535598
# Unit test for function debug
def test_debug():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    captured_output = StringIO()

    sys.stderr = captured_output
    settings.debug = False
    debug('MyTest')
    assert captured_output.getvalue() == ""
    settings.debug = True
    debug('MyTest')
    assert captured_output.getvalue() == ("\x1b[34m\x1b[1mDEBUG:\x1b[0m MyTest\n")
    sys.stderr = sys.__stderr__
    settings.debug = False



# Generated at 2022-06-12 10:36:22.087327
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(
        const.ConfigurationDetails(
            path=u'~/.bashrc',
            can_configure_automatically=False,
            content=u'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
            reload=u'source ~/.bashrc'))
    how_to_configure_alias(
        const.ConfigurationDetails(
            path=u'~/.bashrc',
            can_configure_automatically=True,
            content=u'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
            reload=u'source ~/.bashrc'))

# Generated at 2022-06-12 10:36:23.866109
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias('')
    how_to_configure_alias('details')


# Generated at 2022-06-12 10:36:24.817188
# Unit test for function debug_time
def test_debug_time():
    with debug_time(u'Message'):
        pass

# Generated at 2022-06-12 10:36:33.767064
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.utils import Configuration, ConfigurationDetails
    from thefuck.shells import Shell
    from thefuck.shells.fish import Fish
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.bash import Bash
    from thefuck.shells.sh import Sh
    from thefuck.shells.tcsh import Tcsh

    assert how_to_configure_alias(None) == None


    configuration = Configuration(
        'function fuck() {',
        'eval $(thefuck $(fc -ln -1));',
        '}',
        'alias fuck'
    )
    configuration_details = ConfigurationDetails('fuck',
                                                 '/home/nvbn/.bashrc',
                                                 'source ~/.bashrc',
                                                 True)

# Generated at 2022-06-12 10:36:40.353113
# Unit test for function debug
def test_debug():
    import StringIO
    from mock import patch

    with patch.object(sys.modules['thefuck.shells.bash'], 'is_running',
                      return_value=True):
        from thefuck import cli
        settings.debug = True
        io = StringIO.StringIO()
        with patch('sys.stdout', io):
            cli.main()
            assert io.getvalue() == '\x1b[34m\x1b[1mDEBUG:\x1b[0m thefuck 0.31 using Python 2.7.10 and Bash 4.4\n'



# Generated at 2022-06-12 10:36:48.467389
# Unit test for function confirm_text
def test_confirm_text():
    from tests.utils import Mock

    corrected_command = Mock(script=u'echo "Hey!"')
    confirm_text(corrected_command)

    corrected_command.script = u'echo "Hey!"'
    confirm_text(corrected_command)

    corrected_command.side_effect = True
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:36:58.043292
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import os
    import tempfile
    from .utils import get_closest

    def _debug(s):
        assert s == u"Seems like \x1b[1mfuck\x1b[21m alias isn't configured!"


# Generated at 2022-06-12 10:36:59.034790
# Unit test for function debug_time
def test_debug_time():
    import time
    try:
        with debug_time('Test debug time'):
            time.sleep(0.2)
    except:
        pass

# Generated at 2022-06-12 10:36:59.618334
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass

# Generated at 2022-06-12 10:37:01.446514
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias('')



# Generated at 2022-06-12 10:37:10.649861
# Unit test for function debug
def test_debug():
    def debug_test():
        settings.debug = True
        debug("test")

    def debug_test_2():
        settings.debug = False
        debug("test")

    def debug_test_3():
        settings.debug = True
        from contextlib import contextmanager
        from datetime import datetime
        import sys
        from traceback import format_exception
        import colorama
        from .conf import settings
        from . import const

        @contextmanager
        def debug_time(msg):
            started = datetime.now()

# Generated at 2022-06-12 10:37:12.321833
# Unit test for function show_corrected_command
def test_show_corrected_command():
    assert sys.stdout.getvalue() == ''
    show_corrected_command('')
    assert sys.stdout.getvalue() == ''

# Generated at 2022-06-12 10:37:17.273184
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    sys.stderr = stderr_test = StringIO.StringIO()
    show_corrected_command(const.CorrectedCommand('echo "123"', False))
    sys.stderr = sys.__stderr__
    assert stderr_test.getvalue() == u'→ echo "123"\n'



# Generated at 2022-06-12 10:37:22.528413
# Unit test for function confirm_text
def test_confirm_text():
    expected = u'{prefix}{clear}{bold}{script}{reset}{side_effect} [{green}enter{reset}/{blue}↑{reset}/{blue}↓{reset}/{red}ctrl+c{reset}]'
    confirmation = confirm_text(const.CorrectedCommand(script=u'ls',
                                                       side_effect=True))
    assert expected == confirmation

# Generated at 2022-06-12 10:37:27.765125
# Unit test for function debug_time
def test_debug_time():
    import time
    import mock
    with debug_time('test'):
        time.sleep(0.1)
    # debug() is mocked to check who calls it
    with mock.patch('thefuck.shells.util.debug') as debug:
        with debug_time('test'):
            time.sleep(0.1)
            assert debug.called

# Generated at 2022-06-12 10:37:36.860630
# Unit test for function color
def test_color():
    colorama.init()
    assert color(colorama.Fore.RED) == ''
    settings.no_colors = False
    colorama.init()
    assert color(colorama.Fore.RED) == colorama.Fore.RED

# Generated at 2022-06-12 10:37:38.980571
# Unit test for function debug_time
def test_debug_time():
    msg = 'Hello'
    from datetime import timedelta

    with debug_time(msg):
        assert datetime.now() - started < timedelta(seconds=1)

# Generated at 2022-06-12 10:37:40.327166
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    show_corrected_command(CorrectedCommand('git push'))


colorama.init()

# Generated at 2022-06-12 10:37:50.446373
# Unit test for function debug_time
def test_debug_time():
    from . import __version__
    from .utils import get_shell_info
    from .main import no_colors
    from .settings import set_no_colors
    from .application import Application, NoRuleMatched
    from .shells import Shell
    from .replacer import Replacer

    set_no_colors(True)

# Generated at 2022-06-12 10:37:53.732855
# Unit test for function debug
def test_debug():
    from .conf import settings
    settings.debug = True

    stderr = sys.stderr
    sys.stderr = sys.stdout
    try:
        debug('test')
    finally:
        sys.stderr = stderr

# Generated at 2022-06-12 10:37:57.373499
# Unit test for function color
def test_color():
    with settings.using({'no_colors': True}):
        assert color(colorama.Style.BRIGHT) == ''
        assert color(colorama.Style.RESET_ALL) == ''

    with settings.using({'no_colors': False}):
        assert color(colorama.Style.BRIGHT) == colorama.Style.BRIGHT
        assert color(colorama.Style.RESET_ALL) == colorama.Style.RESET_ALL

# Generated at 2022-06-12 10:37:58.227579
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('ls') == 'ls'

# Generated at 2022-06-12 10:38:02.006687
# Unit test for function show_corrected_command
def test_show_corrected_command():
    message = 'Added parentheses for PyCharm'
    command = 'git diff'
    show_corrected_command(command, message)
    assert sys.stdout.getvalue() == '{} (Added parentheses for PyCharm)\n'.format(command)



# Generated at 2022-06-12 10:38:02.934957
# Unit test for function debug_time
def test_debug_time():
    assert debug_time is not None

# Generated at 2022-06-12 10:38:04.589488
# Unit test for function debug_time
def test_debug_time():
    import mock
    with debug_time('message'):
        pass
    mock.MagicMock.assert_called_once_with('message took: ')

# Generated at 2022-06-12 10:38:12.571339
# Unit test for function debug
def test_debug():
    log = []
    settings.debug = True
    try:
        def other_debug(msg):
            log.append(u'debug: {}'.format(msg))
        sys.stderr.write = other_debug
        debug(u'How are you?')
    finally:
        settings.debug = False
    assert log == [u'debug: How are you?\n']



# Generated at 2022-06-12 10:38:15.204324
# Unit test for function confirm_text
def test_confirm_text():
    constant_test_string = 'confirm_text test'
    confirm_text(constant_test_string)
    # We don't get a perfect match because the 'clear' string includes
    # a non-printing character, so we check for the presence of the
    # first part of the string
    assert sys.stderr.getvalue().find(constant_test_string) != -1

# Generated at 2022-06-12 10:38:17.091862
# Unit test for function confirm_text
def test_confirm_text():
    from collections import namedtuple
    from os import linesep
    from .rules import Command
    Command = namedtuple('Command', 'script side_effect')
    for case in [(Command('ls', True), 'ls (+side effect)')]:
        assert(next(confirm_text(case[0])) == case[1])

# Generated at 2022-06-12 10:38:17.940877
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:38:19.938129
# Unit test for function debug
def test_debug():
    from tests.utils import PatchedStdInOut

    settings.debug = True
    with PatchedStdInOut() as (stdin, stdout):
        debug(u'Foo')
    assert stdout.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Foo\n'

# Generated at 2022-06-12 10:38:21.615304
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('test'):
        time.sleep(1)

test_debug_time()

# Generated at 2022-06-12 10:38:22.215536
# Unit test for function how_to_configure_alias

# Generated at 2022-06-12 10:38:24.447839
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = 'sdfsdfsdfsdfsdfsdf'
    assert show_corrected_command(corrected_command) is None

# Generated at 2022-06-12 10:38:27.379453
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(["sadfsadfsafsad", True])
    show_corrected_command(["ls", False])


# Generated at 2022-06-12 10:38:28.895927
# Unit test for function confirm_text
def test_confirm_text():
    text = "Hello world"
    confirm_text(text)

test_confirm_text()

# Generated at 2022-06-12 10:38:39.408251
# Unit test for function debug
def test_debug():
    """Unit tests for function debug."""
    import mock
    # pylint: disable=W0612

    def mock_write(msg):
        assert msg == u'{blue}{bold}DEBUG:{reset} test\n'.format(
            reset=color(colorama.Style.RESET_ALL),
            blue=color(colorama.Fore.BLUE),
            bold=color(colorama.Style.BRIGHT))

    with mock.patch.object(sys.stderr, 'write', mock_write):
        settings.debug = True
        debug('test')
        settings.debug = False
        debug('test')

# Generated at 2022-06-12 10:38:45.904984
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(('ls', False))
    confirm_text(('ls', True))
    confirm_text(('ls -la', False))
    confirm_text(('ls -la', True))
    confirm_text(('ls asd', False))
    confirm_text(('ls asd', True))
    confirm_text(('ls asd -la', False))
    confirm_text(('ls asd -la', True))

# Generated at 2022-06-12 10:38:46.770795
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED) == ''

# Generated at 2022-06-12 10:38:47.763313
# Unit test for function debug_time
def test_debug_time():
    with debug_time('message'):
        pass

# Generated at 2022-06-12 10:38:53.767552
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import get_closest, get_correction
    from .rules.git import git_rule
    from .shells import Shell
    from .main import Command, NoRuleMatched, RulesNotFound
    from .rules.python_module import (
        python_rule, python3_rule, pip2_rule, pip3_rule)
    from .rules.python_script import (
        python_script_rule, python3_script_rule)
    from .rules.npm import npm_rule
    from .rules.gem import gem_rule
    from .rules.man import man_rule
    from .rules.ssh import ssh_rule
    from .rules.system import (
        apt_get_rule, yum_rule, emerge_rule)
    from .rules.system import system_rule

# Generated at 2022-06-12 10:38:59.656601
# Unit test for function color
def test_color():
    assert color('\033[0m') == ''
    assert color('\033[0m') != '\033[0m'
    assert color('\033[0m') != '\033[1m'
    assert color('\033[1m') != '\033[0m'
    assert color('\033[1m') == '\033[1m'

# Generated at 2022-06-12 10:39:03.213274
# Unit test for function confirm_text
def test_confirm_text():
    from . import const
    from . import conf
    from . import log
    from .conf import settings
    from . import __version__
    import sys
    import colorama
    settings.no_colors = False
    log.show_corrected_command('ls')
    log.confirm_text('ls')
    from .shells import Bash
    from .shells import Zsh
    from .shells import Shell
    from .shells import shell
    settings.no_colors = False
    const.USER_COMMAND_MARK = u'test'
    Bash().and_('ls').should.be.confirmed

# Generated at 2022-06-12 10:39:03.999043
# Unit test for function debug_time
def test_debug_time():
    debug_time("debug time test")

# Generated at 2022-06-12 10:39:05.825155
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test"):
        pass

# Generated at 2022-06-12 10:39:07.721494
# Unit test for function debug_time
def test_debug_time():
    from .main import Command

    with debug_time('test') as t:
        Command('ls', '').run()

    assert t is None

# Generated at 2022-06-12 10:39:13.278095
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:39:14.898264
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias()



# Generated at 2022-06-12 10:39:25.450130
# Unit test for function confirm_text

# Generated at 2022-06-12 10:39:31.794277
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .types import CorrectedCommand
    from . import commands as c
    from . import rules as r

    warn('test')
    exception('test', (None, None, None))
    rule_failed(r.Rule('', '', ''), (None, None, None))
    failed('test')
    show_corrected_command(CorrectedCommand('test', False))
    confirm_text(CorrectedCommand('test', False))
    debug('test')
    with debug_time('test'):
        pass
    how_to_configure_alias(c.ConfigurationDetail(
        path='test',
        content='test',
        reload='test',
        can_configure_automatically=True))

# Generated at 2022-06-12 10:39:41.071458
# Unit test for function debug_time
def test_debug_time():
    import unittest

    class TestDebugTime(unittest.TestCase):
        def setUp(self):
            self.orig_debug_stream = sys.stderr

            class Stream:
                def __init__(self):
                    self.content = []

                def write(self, text):
                    self.content.append(text)

            self.stream = Stream()
            sys.stderr = self.stream

        def tearDown(self):
            sys.stderr = self.orig_debug_stream

        def test_debug_time(self):
            with debug_time('msg'):
                pass

        def test_debug_time_debugging(self):
            settings.debug = True
            self.test_debug_time()

# Generated at 2022-06-12 10:39:43.075273
# Unit test for function show_corrected_command
def test_show_corrected_command():
    with patch('sys.stderr.write') as stderr:
        show_corrected_command(Command('ls /', 'ls /mnt/', False))
        assert stderr.called



# Generated at 2022-06-12 10:39:50.393334
# Unit test for function debug
def test_debug():
    from mock import Mock
    from thefuck.main import debug

    settings = Mock(debug=False)
    stderr = Mock()

    def reset_called():
        assert stderr.write.called
        stderr.write.called = False

    debug(u"Some debug message", settings=settings, stderr=stderr)
    reset_called()

    settings.debug = True
    debug(u"Some debug message", settings=settings, stderr=stderr)
    assert stderr.write.called

# Generated at 2022-06-12 10:39:53.387035
# Unit test for function debug_time
def test_debug_time():
    const.settings.debug = True
    try:
        with debug_time('test'):
            assert True
    except AssertionError:
        assert False
    finally:
        const.settings.debug = False

# Generated at 2022-06-12 10:39:59.253247
# Unit test for function debug_time
def test_debug_time():
    import sys
    import mock
    import thefuck.main
    from datetime import datetime

    sys.stderr = mock.Mock()
    thefuck.main.settings.debug = True
    thefuck.main.debug_time('msg')(
        lambda: datetime.now().replace(microsecond=0))()
    sys.stderr.write.assert_called_once_with(u'msg took: 0:00:00\n')

# Generated at 2022-06-12 10:39:59.988437
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass


# Generated at 2022-06-12 10:40:06.174529
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:40:14.303469
# Unit test for function debug_time
def test_debug_time():
    from tempfile import NamedTemporaryFile
    from . import debug
    old_debug = debug
    debug_file = NamedTemporaryFile(delete=False)
    try:
        def test_debug(msg):
            debug_file.write('{}\n'.format(msg).encode('utf-8'))

        debug = test_debug
        with debug_time('Message'):
            pass

        debug_file.close()
        with open(debug_file.name, 'r') as debug_file:
            assert ('Message took: 0:00:00'
                    in debug_file.read().decode('utf-8'))
    finally:
        debug = old_debug
        debug_file.close()

# Generated at 2022-06-12 10:40:15.521256
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('you command')

# Generated at 2022-06-12 10:40:16.764591
# Unit test for function color
def test_color():
    assert color('test') == 'test'
    assert color('test') != 'ansi'

# Generated at 2022-06-12 10:40:26.887567
# Unit test for function debug_time
def test_debug_time():
    import unittest

    class TestDebugTimeCase(unittest.TestCase):
        def test_debug_time(self):
            output = []

            def debug(msg):
                output.append(msg)

            def assert_output_cleared():
                self.assertEqual(output, [])

            def assert_output_equal(expected):
                self.assertEqual(output, expected)

            settings.debug = True
            try:
                from thefuck.utils import debug, debug_time
                global debug, debug_time
                assert_output_cleared()

                with debug_time('some_action'):
                    assert_output_cleared()

                with debug_time('another_action'):
                    assert_output_cleared()

                assert_output_cleared()

            finally:
                settings.debug = False

# Generated at 2022-06-12 10:40:29.193848
# Unit test for function debug_time
def test_debug_time():
    import time
    start = int(time.time())
    with debug_time('test'):
        time.sleep(1)
    end = int(time.time())
    assert (end - start) == 1

# Generated at 2022-06-12 10:40:31.624877
# Unit test for function color
def test_color():
    assert color('\x1b[1m') == '\x1b[1m'
    settings.no_colors = True
    colorama.init()
    assert color('\x1b[1m') == ''

# Generated at 2022-06-12 10:40:39.231421
# Unit test for function color
def test_color():
    assert color(colorama.Fore.RED + colorama.Fore.BLUE + 'foo') == '\x1b[31m\x1b[34mfoo\x1b[39m\x1b[34m\x1b[39m'
    settings.no_colors = True
    assert color(colorama.Fore.RED + colorama.Fore.BLUE + 'foo') == ''
    settings.no_colors = False
    assert color(colorama.Fore.RED + colorama.Fore.BLUE + 'foo') == '\x1b[31m\x1b[34mfoo\x1b[39m\x1b[34m\x1b[39m'

# Generated at 2022-06-12 10:40:41.513363
# Unit test for function confirm_text
def test_confirm_text():
    # there is no easy way to test this, so just call this function
    import thefuck.main
    thefuck.main.confirm_text('cd ..')

# Generated at 2022-06-12 10:40:47.533853
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias({"content": "content",
                            "path": "path",
                            "reload": "reload",
                            "can_configure_automatically": True})
    how_to_configure_alias({"content": "content",
                            "path": "path",
                            "reload": "reload",
                            "can_configure_automatically": False})



# Generated at 2022-06-12 10:40:54.632491
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = 'git push origin'
    assert confirm_text(corrected_command) == True



# Generated at 2022-06-12 10:40:55.496755
# Unit test for function debug
def test_debug():
    settings.debug = True
    debug('Test')

# Generated at 2022-06-12 10:40:57.275327
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command("ls -la")
    show_corrected_command("ls -la +1")

# Generated at 2022-06-12 10:41:07.490940
# Unit test for function debug
def test_debug():
    import StringIO
    from . import conf
    from .utils import get_closest

    # Get closest 'fuck' binary
    fuck_dirname = get_closest('fuck')

    # Get directory for module
    test_dirname = os.path.dirname(os.path.abspath(__file__))

    # Get original settings
    original_settings = conf.settings

    # Create and set new settings

# Generated at 2022-06-12 10:41:08.296973
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command()



# Generated at 2022-06-12 10:41:09.130803
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:41:10.666149
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .corrector import Command
    c = Command('ls', 'ls -l')
    show_corrected_command(c)



# Generated at 2022-06-12 10:41:14.752775
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    import mock
    import os
    from thefuck.conf import ConfigurationDetails
    from thefuck.utils import get_shell_info

    with mock.patch('thefuck.utils.samefile', return_value=False):
        assert how_to_configure_alias(ConfigurationDetails(
            path=os.path.expanduser('~/.kshrc'),
            reload=get_shell_info(os.environ['SHELL']),
            can_configure_automatically=True,
            content='''eval $(thefuck --alias)''')) == None



# Generated at 2022-06-12 10:41:20.104351
# Unit test for function confirm_text
def test_confirm_text():
    from . import shell

    assert confirm_text(shell.CorrectedCommand(script="ls", side_effect=False)) == "\033[1K\rls [enter/↑/↓/ctrl+c]"
    assert confirm_text(shell.CorrectedCommand(script="ls", side_effect=True)) == "\033[1K\rls (+side effect) [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-12 10:41:21.662918
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    with debug_time('test message'):
        pass



# Generated at 2022-06-12 10:41:28.749477
# Unit test for function confirm_text
def test_confirm_text():
    import pytest
    with pytest.raises(SystemExit):
        show_corrected_command(u'sudo echo "fuck"')
        confirm_text(u'sudo echo "fuck"')

# Generated at 2022-06-12 10:41:30.688605
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias(None) is None


# Generated at 2022-06-12 10:41:34.547845
# Unit test for function debug
def test_debug():
    import StringIO
    old_stdout = sys.stderr
    try:
        mystdout = StringIO.StringIO()
        sys.stderr = mystdout
        debug('Test')
        output = mystdout.getvalue().strip()
        assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Test'
    finally:
        sys.stderr = old_stdout

# Generated at 2022-06-12 10:41:38.534871
# Unit test for function debug_time
def test_debug_time():

    from .main import send_to_stderr

    send_to_stderr('x')
    send_to_stderr('x')
    with debug_time('foo'):
        send_to_stderr('x')
        with debug_time('bar'):
            send_to_stderr('x')
    with debug_time('foo 2'):
        send_to_stderr('x')

# Generated at 2022-06-12 10:41:39.576222
# Unit test for function debug
def test_debug():
    assert debug('test') is None

# Generated at 2022-06-12 10:41:45.356732
# Unit test for function debug_time
def test_debug_time():
    t = datetime.now()
    with debug_time('execution of command'):
        pass
    assert(color(colorama.Style.RESET_ALL) in sys.stderr.getvalue())
    assert('DEBUG: execution of command took' in sys.stderr.getvalue())
    assert(str(datetime.now() - t) in sys.stderr.getvalue())

# Generated at 2022-06-12 10:41:46.022962
# Unit test for function debug
def test_debug():
    debug('message')

# Generated at 2022-06-12 10:41:51.228934
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert how_to_configure_alias('') == 'Seems like {bold}fuck{reset} alias is not configured!Please put {bold}content{reset} in your {bold}path{reset} and apply changes with {bold}reload{reset} or restart your shell.Or run {bold}fuck{reset} a second time to configure it automatically.More details - https://github.com/nvbn/thefuck#manual-installation'


# Generated at 2022-06-12 10:41:52.470431
# Unit test for function color
def test_color():
    assert '\x1b[0m' == color('')

# Generated at 2022-06-12 10:41:56.908822
# Unit test for function debug
def test_debug():
    import StringIO
    import mock
    from thefuck import settings

    debug_output = StringIO.StringIO()

    with mock.patch('sys.stderr', debug_output):
        settings.debug = True
        debug(u'test')
        assert debug_output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'

    

# Generated at 2022-06-12 10:42:04.700632
# Unit test for function debug_time
def test_debug_time():
    # Simply runs debug_time(msg) and checks output for
    # the message.
    with debug_time('test_debug_time'):
        pass