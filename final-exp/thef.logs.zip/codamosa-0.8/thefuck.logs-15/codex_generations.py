

# Generated at 2022-06-12 10:32:12.263628
# Unit test for function show_corrected_command
def test_show_corrected_command():
    expected = const.USER_COMMAND_MARK + 'pwd {}\n'.format(color(colorama.Style.BRIGHT))
    actual = show_corrected_command('pwd ')
    assert actual == expected

# Generated at 2022-06-12 10:32:16.440047
# Unit test for function debug_time
def test_debug_time():
    import time
    import unittest

    class DebugTimeTest(unittest.TestCase):
        def test_debug_time(self):
            with debug_time('test message'):
                print('Some action')
                time.sleep(1)

    unittest.main(module='test_debug_time', exit=False)

# Generated at 2022-06-12 10:32:18.173845
# Unit test for function color
def test_color():
    assert color(colorama.Fore.BLUE) == colorama.Fore.BLUE
    assert color(u'') == u''



# Generated at 2022-06-12 10:32:19.005937
# Unit test for function color
def test_color():
    assert u'' == color(u'')



# Generated at 2022-06-12 10:32:21.148976
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text(u'ls -la') == u'>>> ls -la [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:32:30.726681
# Unit test for function confirm_text
def test_confirm_text():
    """Test the confirm_text function with a mocked stdout"""
    from cStringIO import StringIO
    from contextlib import contextmanager
    from .rules import Command
    from .utils import confirm_text
    import sys

    @contextmanager
    def mock_stdout():
        """Monkey patch stdout"""
        orig_stdout = sys.stdout
        sys.stdout = StringIO()
        yield sys.stdout
        sys.stdout = orig_stdout

    with mock_stdout() as mock:
        confirm_text(Command('ls'))

# Generated at 2022-06-12 10:32:33.710013
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .repl import CorrectedCommand
    import sys

    sys.stderr = open('/dev/null', 'w')
    show_corrected_command(CorrectedCommand('ls', False))
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:32:35.127859
# Unit test for function confirm_text
def test_confirm_text():
    show_corrected_command('ls -la')


# Generated at 2022-06-12 10:32:36.070810
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text(None) == None

# Generated at 2022-06-12 10:32:41.474256
# Unit test for function confirm_text
def test_confirm_text():
    """
    Test the correct printing of the most common output of confirm_text
    """
    import colorama
    colorama.init()
    corrected_command = "ls -a"
    confirm_text(corrected_command)
    print(const.USER_COMMAND_MARK + colorama.Style.BRIGHT +
          colorama.Fore.GREEN + corrected_command + colorama.Style.RESET_ALL +
          " [enter/↑/↓/ctrl+c]" + colorama.Style.RESET_ALL)

# Generated at 2022-06-12 10:32:52.367427
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import tempfile
    import subprocess
    import os
    import time

    test_factual_corrected_command = "git push"
    tst = tempfile.NamedTemporaryFile()
    tst.write('#!/bin/bash\n')
    tst.write('echo "got:" $*\n')
    tst.write('sleep 1\n')
    tst.write('echo "{}"\n'.format(test_factual_corrected_command))
    tst.flush()
    time.sleep(1)

    subprocess.call(['chmod', 'u+x', tst.name])
    subprocess.call(['which', 'fuck'] + [tst.name] * 2)
    time.sleep(1)

# Generated at 2022-06-12 10:32:54.037113
# Unit test for function confirm_text
def test_confirm_text():
    with colorama.Style.RESET_ALL:
        assert confirm_text(None) == ""

# Generated at 2022-06-12 10:32:54.987823
# Unit test for function show_corrected_command
def test_show_corrected_command():
    corrected_command = ''
    show_corrected_command(corrected_command)

# Generated at 2022-06-12 10:32:57.062750
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:33:07.270633
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    import mock
    with mock.patch('datetime.datetime') as datetime_mock:
        with debug_time('msg'):
            pass
        datetime_mock.now.side_effect = [timedelta(seconds=10),
                                         timedelta(seconds=20)]
        with mock.patch('sys.stderr') as stderr_mock:
            settings.debug = True
            debug_time('msg')
            stderr_mock.write.assert_called_once_with(
                color(colorama.Fore.BLUE)
                + color(colorama.Style.BRIGHT) + u'DEBUG:'
                + color(colorama.Style.RESET_ALL) + u' msg took: 0:00:10\n')

# Generated at 2022-06-12 10:33:08.429004
# Unit test for function debug_time
def test_debug_time():
    with debug_time('Test'):
        pass

# Generated at 2022-06-12 10:33:11.635003
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    global shell

    shell = Shell(env={'SHELL': 'bash'})
    how_to_configure_alias(shell.how_to_configure_alias())

# Generated at 2022-06-12 10:33:12.237584
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass



# Generated at 2022-06-12 10:33:12.900791
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    pass

# Generated at 2022-06-12 10:33:14.738085
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time(u'Test'):
        time.sleep(0.5)

# Generated at 2022-06-12 10:33:21.656161
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .command import CorrectedCommand
    command = CorrectedCommand('command', 'fuck command', False)
    show_corrected_command(command)



# Generated at 2022-06-12 10:33:23.242415
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('ls')
    confirm_text('ls')
    confirm_text('ls')
    confirm_text('ls')
    confirm_text('ls')

# Generated at 2022-06-12 10:33:34.386141
# Unit test for function confirm_text
def test_confirm_text():
    def t(*args):
        return ' '.join(args)

    import sys
    saved_stderr = sys.stderr

    try:
        import tempfile
        sys.stderr = open(tempfile.mkstemp()[1], 'w+')

        settings.no_colors = True
        confirm_text(const.CorrectedCommand('lol', False))
        settings.no_colors = False
        confirm_text(const.CorrectedCommand('lol', False))

        settings.no_colors = True
        confirm_text(const.CorrectedCommand('lol', True))
        settings.no_colors = False
        confirm_text(const.CorrectedCommand('lol', True))
    finally:
        sys.stderr.close()
        sys.stderr = saved_stderr

# Generated at 2022-06-12 10:33:37.268302
# Unit test for function color
def test_color():
    assert(color(colorama.Fore.BLUE) == colorama.Fore.BLUE)
    settings.no_colors = True
    assert(color(colorama.Fore.BLUE) == '')
    settings.no_colors = False

# Generated at 2022-06-12 10:33:42.128127
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias({
        "content": "some_content",
        "path": "some_path",
        "reload": "some_reload",
        "can_configure_automatically": False
    })


# Generated at 2022-06-12 10:33:43.888562
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text('ls') == const.USER_COMMAND_MARK + 'ls'



# Generated at 2022-06-12 10:33:45.087729
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    assert len(how_to_configure_alias(None))


# Generated at 2022-06-12 10:33:49.359796
# Unit test for function debug_time
def test_debug_time():
    """
    Create empty file named debug_time.trace,
    run command with debug_time context manager and assert
    that it contains expected string
    """
    with open('debug_time.trace', 'w'):
        pass
    with debug_time('test_debug_time'):
        pass
    with open('debug_time.trace', 'r') as f:
        assert 'test_debug_time took' in f.read()

# Generated at 2022-06-12 10:33:54.730760
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import StringIO
    output = StringIO.StringIO()
    sys.stderr = output
    corrected_command = 'ls /some/path'
    show_corrected_command(corrected_command)
    output.seek(0)
    assert output.read() == u'{}ls /some/path\n'.format(const.USER_COMMAND_MARK)



# Generated at 2022-06-12 10:33:55.365615
# Unit test for function debug
def test_debug():
    debug('message')

# Generated at 2022-06-12 10:33:59.364607
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:34:01.900654
# Unit test for function debug
def test_debug():
    # https://github.com/nvbn/thefuck/issues/1294
    debug(u'ÑÒÀËËÀËÈÇÀŒ')

# Generated at 2022-06-12 10:34:07.489158
# Unit test for function debug_time
def test_debug_time():
    from mock import patch
    from datetime import datetime

    ret = 3
    with patch('thefuck.shells.base.debug') as mock_debug:
        with debug_time('msg'):
            return ret
        assert mock_debug.call_count == 1
        assert mock_debug.call_args[0][0] == \
            u'msg took: {0}'.format(datetime.now() - datetime.now())

# Generated at 2022-06-12 10:34:16.472692
# Unit test for function debug
def test_debug():
    import io

    class Buffer(object):
        def __init__(self):
            self._buffer = io.StringIO()

        @property
        def value(self):
            return self._buffer.getvalue()

        def write(self, value):
            self._buffer.write(value)

    buffer = Buffer()
    settings.debug = True
    try:
        sys.stderr = buffer
        debug(u'hello world')
        assert buffer.value == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m hello world\n'
    finally:
        sys.stderr = sys.__stderr__
        settings.debug = False

# Generated at 2022-06-12 10:34:20.957644
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == u'\x1b[101m\x1b[97m\x1b[1m'
    settings.no_colors = True
    assert color(colorama.Back.RED + colorama.Fore.WHITE
                 + colorama.Style.BRIGHT) == u''

# Generated at 2022-06-12 10:34:31.949612
# Unit test for function debug
def test_debug():
    import sys
    # setup
    real_std = sys.stderr
    sys.stderr = fake_stderr = (
        open('/tmp/thefuck-fake-stderr.txt', 'w', buffering=0))
    # do
    debug('Fake message')
    debug('Another fake message')
    # cleanup
    sys.stderr = real_std
    fake_stderr.close()
    # test
    assert (
        open('/tmp/thefuck-fake-stderr.txt').read() ==
        '\x1b[34m\x1b[1mDEBUG:\x1b[0m Fake message\n'
        '\x1b[34m\x1b[1mDEBUG:\x1b[0m Another fake message\n')

# Generated at 2022-06-12 10:34:40.272346
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    from .shells import Shell


    class FakeTime(object):
        def __init__(self):
            self.offset = 0

        def __call__(self):
            return started + timedelta(seconds=self.offset)

        def __iter__(self):
            return self

        def next(self):
            self.offset += 1
            return self.__call__()


    class MockCommand(object):
        def __init__(self, *args, **kwargs):
            self.side_effect = kwargs.pop('side_effect', False)

        def script(self):
            return u'fuck git push'

    started = datetime.now()
    with FakeTime() as current_time, \
            settings:
        settings.debug = True
        shell = Shell()


# Generated at 2022-06-12 10:34:50.061396
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write = lambda x: x

# Generated at 2022-06-12 10:35:00.505324
# Unit test for function debug_time
def test_debug_time():
    from contextlib import contextmanager
    from datetime import datetime
    from datetime import timedelta
    from mock import Mock

    @contextmanager
    def fake_time():
        m = Mock()
        m.now.return_value = datetime(1, 1, 1)
        yield m.now
        m.now.return_value = datetime(1, 1, 1, 0, 0, 1)

    @contextmanager
    def debug_time(msg):
        now = fake_time()
        started = now()
        try:
            yield
        finally:
            print('{} took: {}'.format(msg, now() - started))

    with Mock() as print_mock:
        with debug_time('hi'):
            pass

# Generated at 2022-06-12 10:35:01.536638
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-12 10:35:06.682206
# Unit test for function debug_time
def test_debug_time():
    with debug_time('foo'):
        from time import sleep
        sleep(3)



# Generated at 2022-06-12 10:35:11.916598
# Unit test for function debug
def test_debug():
    from thefuck.utils import test

    settings.debug = True

    with test.mock.patch('thefuck.utils.log.sys') as mock_sys:
        debug(u'foo')

    mock_sys.stderr.write.assert_called_once_with(
        u"\x1b[34m\x1b[1mDEBUG:\x1b[0m foo\n")



# Generated at 2022-06-12 10:35:19.081284
# Unit test for function debug
def test_debug():

    from mock import patch
    from .version import __version__ as thefuck_version
    from .python_version import PYTHON_VERSION
    from .shells import get_shell_info
    import sys
    with patch.object(sys, 'stderr') as mock_stderr:
        debug("test_debug")
        mock_stderr.write.assert_called_with(
            u'{blue}{bold}DEBUG:{reset} {msg}\n'.format(
                msg="test_debug",
                reset=color(colorama.Style.RESET_ALL),
                blue=color(colorama.Fore.BLUE),
                bold=color(colorama.Style.BRIGHT)
            ))
        mock_stderr.reset_mock()


# Generated at 2022-06-12 10:35:25.128393
# Unit test for function confirm_text
def test_confirm_text():
    confirm_text([]) == '>\r> \x1b[1m\x1b[32menter\x1b[0m/\x1b[34m\x1b[A\x1b[0m/\x1b[34m\x1b[B\x1b[0m/\x1b[31mctrl+c\x1b[0m]'

# Generated at 2022-06-12 10:35:28.966342
# Unit test for function debug
def test_debug():
    from .conf import settings as current_settings
    from tests.utils import reset_settings, restore_settings
    
    old_settings = dict(current_settings)
    reset_settings()
    current_settings.debug = False
    debug('debug')
    current_settings.debug = True
    debug('debug')
    reset_settings()
    restore_settings(old_settings)

# Generated at 2022-06-12 10:35:31.723670
# Unit test for function confirm_text
def test_confirm_text():
    script = "cd /"
    assert confirm_text(script) == \
    const.USER_COMMAND_MARK + \
    "cd / [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-12 10:35:35.271582
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .correct import CorrectedCommand
    from .shells import Shell

    shell = Shell()
    script = 'cd /usr/local/'
    show_corrected_command(CorrectedCommand(script, shell, ''))

# Generated at 2022-06-12 10:35:41.518976
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    cd = ConfigurationDetails('', '', '')
    cd1 = ConfigurationDetails('1.txt', '2.sh', '3.sh --reload')
    cd2 = ConfigurationDetails('1.txt', '2.sh', '', False, False)
    assert how_to_configure_alias(cd) is None
    assert how_to_configure_alias(cd1) is None
    assert how_to_configure_alias(cd2) is None


# Generated at 2022-06-12 10:35:48.296029
# Unit test for function debug
def test_debug():
    sys.stderr = FakeStd()
    settings.debug = True
    debug('foo')
    assert sys.stderr.std == ['DEBUG: foo\n']
    debug('bar')
    assert sys.stderr.std == ['DEBUG: foo\n', 'DEBUG: bar\n']
    settings.debug = False
    debug('foo')
    assert sys.stderr.std == ['DEBUG: foo\n', 'DEBUG: bar\n']
    sys.stderr = sys.__stderr__



# Generated at 2022-06-12 10:35:49.236368
# Unit test for function color
def test_color():
    assert color('') == ''

# Generated at 2022-06-12 10:35:54.378683
# Unit test for function confirm_text
def test_confirm_text():
    assert confirm_text('git banch') == 'git banch [enter/↑/↓/ctrl+c]'

# Generated at 2022-06-12 10:35:56.052586
# Unit test for function show_corrected_command
def test_show_corrected_command():
    """
    show_corrected_command(corrected_command):
    """



# Generated at 2022-06-12 10:35:57.889521
# Unit test for function debug_time
def test_debug_time():
    sys.stderr.write("test_debug_time:\n")
    debug_time("test_debug_time")

# Generated at 2022-06-12 10:36:03.830745
# Unit test for function debug
def test_debug():
    from .utils import EOL
    from mock import patch
    with patch('thefuck.shells.get_alias', return_value='thefuck'):
        debug('foo')
        assert sys.stderr.getvalue() == color(colorama.Fore.BLUE)\
                                      + color(colorama.Style.BRIGHT)\
                                      + u'DEBUG:'\
                                      + color(colorama.Style.RESET_ALL)\
                                      + u' foo' + EOL


# Generated at 2022-06-12 10:36:06.401953
# Unit test for function color
def test_color():
    assert color('') == ''
    assert color('\033[0m') == ''
    settings.no_colors = True
    assert color('') == ''
    assert color('\033[0m') == ''

test_color()

# Generated at 2022-06-12 10:36:11.394477
# Unit test for function debug_time
def test_debug_time():
    class Recorder(object):
        def __init__(self):
            self._calls = []

        def __call__(self, *args):
            self._calls.append(args)

    recorder = Recorder()
    with debug_time(u'foo'):
        recorder(u'bar')

    assert recorder._calls == [(u'foo took: 0:00:00', )]

# Generated at 2022-06-12 10:36:13.158129
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(None)
    how_to_configure_alias(None)

# Generated at 2022-06-12 10:36:13.682153
# Unit test for function debug
def test_debug():
    debug('Test message')

# Generated at 2022-06-12 10:36:16.218129
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    assert show_corrected_command(
        CorrectedCommand(u'cat xxx.py', u'cat xxx.py', False)) == None

# Generated at 2022-06-12 10:36:17.891734
# Unit test for function debug_time
def test_debug_time():
    placeholder = 0
    with debug_time('placeholder'):
        placeholder += 1
    assert placeholder == 1



# Generated at 2022-06-12 10:36:28.939318
# Unit test for function debug_time
def test_debug_time():
    from .main import DEBUG
    import mock
    import time

    @debug_time(u'test')
    def test_function(sleep_time):
        time.sleep(sleep_time)

    with mock.patch('sys.stderr', new=mock.MagicMock()) as mocked_stderr:
        with mock.patch.object(DEBUG, 'debug', new=mock.MagicMock()):
            test_function(sleep_time=0.2)
            mocked_stderr.assert_any_call(u'DEBUG: test took: {0}\n'.format(str(mock.ANY)[:5]))

# Generated at 2022-06-12 10:36:30.767551
# Unit test for function confirm_text
def test_confirm_text():
    # python3.3
    assert confirm_text(None) == None
    # python3.4
    assert confirm_text(None) is None

# Generated at 2022-06-12 10:36:31.612315
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test time"):
        pass

# Generated at 2022-06-12 10:36:32.294832
# Unit test for function debug
def test_debug():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:36:36.179484
# Unit test for function debug
def test_debug():
    import StringIO
    import sys
    settings.debug = True
    out = StringIO.StringIO()
    sys.stderr = out
    debug('123')
    result = out.getvalue()
    assert result == '\x1b[94m\x1b[1mDEBUG:\x1b[0m 123\n'
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:36:38.111682
# Unit test for function color
def test_color():
    assert not color('')

    settings.no_colors = True
    assert not color('Hello')
    settings.no_colors = False

    assert color('Hello') == 'Hello'

# Generated at 2022-06-12 10:36:39.425629
# Unit test for function debug
def test_debug():
    assert(debug('test_debug') == None)
    assert(debug('test_debug') == None)

# Generated at 2022-06-12 10:36:41.530073
# Unit test for function show_corrected_command
def test_show_corrected_command():
    class CorrectedCommand(object):
        def __init__(self):
            self.script = "script"
            self.side_effect = True

    show_corrected_command(CorrectedCommand())

# Generated at 2022-06-12 10:36:42.360432
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:36:46.187206
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.rules.git import match, get_new_command
    from thefuck.types import Command

    corrected_command = get_new_command(Command('git pussh', 'git'), 'push')
    show_corrected_command(corrected_command)
    assert True


# Generated at 2022-06-12 10:36:51.557803
# Unit test for function debug_time
def test_debug_time():
    """
    >>> from datetime import datetime
    >>> debug_time('message'):
    >>>     datetime(1999, 12, 12)
    >>>
    """


# Generated at 2022-06-12 10:36:55.025528
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    class ConfigurationDetails:

        def __init__(self, can_configure_automatically):
            self.can_configure_automatically = can_configure_automatically

        def _asdict():
            return {}

    how_to_configure_alias(ConfigurationDetails(False))
    how_to_configure_alias(ConfigurationDetails(True))

# Generated at 2022-06-12 10:37:03.364137
# Unit test for function debug
def test_debug():
    class Capture(object):
        def __init__(self):
            self.lines = []

        def write(self, line):
            self.lines.append(line)

    settings.debug = True
    output = Capture()
    old_stderr = sys.stderr
    try:
        sys.stderr = output
        debug('Debug message')
        assert len(output.lines) == 1
        assert output.lines[0] == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Debug message\n'
    finally:
        sys.stderr = old_stderr
        settings.debug = False



# Generated at 2022-06-12 10:37:05.985079
# Unit test for function debug_time
def test_debug_time():
    from datetime import datetime
    from time import sleep
    debug_time('default')
    debug_time('my debug text')
    with debug_time('my context manager'):
        sleep(1)
    assert True

# Generated at 2022-06-12 10:37:09.382811
# Unit test for function show_corrected_command
def test_show_corrected_command():
    command = corrected_command('ls')
    assert show_corrected_command(command) == ''
    assert show_corrected_command(command, False) == ''
    assert show_corrected_command(command, True) == 'ls'

# Generated at 2022-06-12 10:37:16.226548
# Unit test for function debug
def test_debug():
    from mock import patch
    from .utils import is_python2

    debug('test')

    with patch('sys.stderr') as stderr:
        debug('test')
        if is_python2:
            stderr.write.assert_called_once_with(
                u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')
        else:
            stderr.write.assert_called_once_with(
                u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n')

# Generated at 2022-06-12 10:37:24.478141
# Unit test for function color
def test_color():
    from contextlib import contextmanager
    from StringIO import StringIO

    @contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    with capture(color, 'color') as color_output:
        assert color_output == 'color'

    settings.no_colors = True
    with capture(color, 'color') as color_output:
        assert color_output == ''
    settings.no_colors = False

# Generated at 2022-06-12 10:37:25.057350
# Unit test for function show_corrected_command
def test_show_corrected_command():
    pass


# Generated at 2022-06-12 10:37:26.994122
# Unit test for function confirm_text
def test_confirm_text():
    corrected_command = const.CorrectedCommand(['ls', '-l'], 'ls -l', False)
    confirm_text(corrected_command)
    corrected_command = const.CorrectedCommand(['ls', '-l'], 'ls -l', True)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:37:27.632008
# Unit test for function debug_time
def test_debug_time():
    debug_time('test')

# Generated at 2022-06-12 10:37:34.671864
# Unit test for function debug
def test_debug():
    from mock import Mock
    from . import log

    settings.debug = True
    log.debug('Test debug')
    sys.stderr.write = Mock()
    log.debug('Test debug 2')
    sys.stderr.write.assert_called_with(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test debug 2\n')



# Generated at 2022-06-12 10:37:40.738111
# Unit test for function debug
def test_debug():
    from tests.utils import capture_stderr

    with capture_stderr() as stderr:
        debug(u'foo')

    assert stderr.read() == ''

    settings.debug = True
    with capture_stderr() as stderr:
        debug(u'bar')

    assert stderr.read() == u'\x1b[34m\x1b[1mDEBUG:\x1b[21m bar\n'

# Generated at 2022-06-12 10:37:45.598229
# Unit test for function debug_time
def test_debug_time():
    import re
    import time
    import mock
    with mock.patch('thefuck.output.debug'):
        with debug_time('foo'):
            time.sleep(0.1)

    output = sys.stderr.getvalue()
    assert re.match(r'foo took: \d+\.\d+ seconds', output)

# Generated at 2022-06-12 10:37:47.798396
# Unit test for function color
def test_color():
    assert color(u'RED') == u''
    settings.no_colors = False
    assert color(u'RED') == u'RED'



# Generated at 2022-06-12 10:37:55.248680
# Unit test for function debug
def test_debug():
    """
    Check debug(), is it display a message
    """

    from contextlib import contextmanager
    from StringIO import StringIO
    from sys import stderr

    @contextmanager
    def captured_output(stream_name):
        """
        Check a message shows in the correct stream
        """
        orig_stdout = getattr(sys, stream_name)
        setattr(sys, stream_name, StringIO())
        try:
            yield getattr(sys, stream_name)
        finally:
            setattr(sys, stream_name, orig_stdout)

    with captured_output('stderr') as result:
        debug('my debug message')
    assert result.getvalue() == 'DEBUG: my debug message\n'


# Generated at 2022-06-12 10:38:05.115369
# Unit test for function confirm_text
def test_confirm_text():
    const.USER_COMMAND_MARK = '>>> '

    class FakeCorrectedCommand(object):
        def __init__(self, script):
            self.script = script
            self.side_effect = False


# Generated at 2022-06-12 10:38:09.777324
# Unit test for function color
def test_color():
    assert '\033' in color(colorama.Style.RESET_ALL)
    assert '\033' not in color('')

    assert color(colorama.Style.RESET_ALL) == color(
        colorama.Style.RESET_ALL)
    assert color(colorama.Style.RESET_ALL) != color(
        colorama.Style.BRIGHT)

# Generated at 2022-06-12 10:38:12.643596
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias("")

# Generated at 2022-06-12 10:38:13.466894
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:38:18.209047
# Unit test for function show_corrected_command
def test_show_corrected_command():
    test_string = 'git sta'
    test_side_effect = False

    show_corrected_command(test_string, test_side_effect)

    assert show_corrected_command(test_string, test_side_effect) == \
           u'{prefix}{bold}{script}{reset}{side_effect}\n'.format(
               prefix=const.USER_COMMAND_MARK,
               script=test_string,
               side_effect=u' (+side effect)' if test_side_effect else u'',
               bold=color(colorama.Style.BRIGHT),
               reset=color(colorama.Style.RESET_ALL))



# Generated at 2022-06-12 10:38:25.075827
# Unit test for function confirm_text
def test_confirm_text():
    class CorrectedCommand(object):
        def __init__(self, script, side_effect):
            self.script = script
            self.side_effect = side_effect
    corrected_command = CorrectedCommand('echo lulz', True)
    confirm_text(corrected_command)

# Generated at 2022-06-12 10:38:26.564143
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass

# Generated at 2022-06-12 10:38:31.838534
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from .shells import Shell
    from .utils import get_closest
    shell = 'bash'
    expected_shell = get_closest(shell, Shell)
    system = sys.platform
    if system == 'darwin':
        system = 'macos'
        expected_shell = get_closest('bash', Shell)
    expected_reload = expected_shell.reload_cmd
    configuration_details = settings.get_configuration_details(System(shell=shell, system=system))
    how_to_configure_alias(configuration_details)


# Generated at 2022-06-12 10:38:33.107272
# Unit test for function debug_time
def test_debug_time():
    with debug_time('some message'):
        pass



# Generated at 2022-06-12 10:38:40.231089
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    with open('output.txt', 'w') as output:
        sys.stdout = output
        how_to_configure_alias(const.ConfigurationDetails(
            shell_name=const.SHELL_NAME,
            shell_config_path=const.SHELL_CONFIG_PATH,
            script=const.ADD_TO_BASH,
            reload_command=const.RELOAD_BASH))

    with open('output.txt', 'r') as output:
        output_lines = output.readlines()

    output_lines[0] == u"Seems like {bold}fuck{reset} alias isn't configured!\n".format(
        bold=color(colorama.Style.BRIGHT),
        reset=color(colorama.Style.RESET_ALL))


# Generated at 2022-06-12 10:38:43.045249
# Unit test for function confirm_text
def test_confirm_text():
    def test():
        show_corrected_command(CorrectedCommand('test_scrip_2', True))
        confirm_text(CorrectedCommand('test_scrip_2', True))
    test()



# Generated at 2022-06-12 10:38:44.852511
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test case'):
        pass

# Generated at 2022-06-12 10:38:45.819936
# Unit test for function color
def test_color():
    assert color('') == ''



# Generated at 2022-06-12 10:38:52.245407
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    how_to_configure_alias(configuration_details=None)
    how_to_configure_alias(configuration_details=const.ConfigurationDetails(
        path=u'~/bash',
        content=u'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        reload=u'source ~/bash',
        can_configure_automatically=False))
    how_to_configure_alias(configuration_details=const.ConfigurationDetails(
        path=u'~/bash',
        content=u'alias fuck=\'eval $(thefuck $(fc -ln -1))\'',
        reload=u'source ~/bash',
        can_configure_automatically=True))

# Generated at 2022-06-12 10:39:03.356838
# Unit test for function confirm_text
def test_confirm_text():
    from . import conf
    from . import const
    import sys
    import tempfile
    import unittest

    class TestConfirmText(unittest.TestCase):
        def setUp(self):
            self.test_fd, self.test_filename = tempfile.mkstemp()
            self.test_file = open(self.test_filename, 'w+')
            sys.stderr = self.test_file

        def tearDown(self):
            sys.stderr = sys.__stderr__
            self.test_file.close()
            os.remove(self.test_filename)

        def test_confirm_text(self):
            confirm_text("test_command")

# Generated at 2022-06-12 10:39:14.939936
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from .utils import _get_corrected_commands
    from . import conf

    def test_config(**kwargs):
        new_conf = conf.Config(**kwargs)
        from thefuck.shells import known_shells
        for _, shell in known_shells.items():
            shell._set_config(new_conf)
        return new_conf

    conf_default = test_config()

    conf_no_colors = test_config(no_colors=True)

    conf_no_split = test_config(no_split=True)

    conf_no_colors_no_split = test_config(no_colors=True, no_split=True)

    assert not conf_default.no_colors
    assert not conf_no_colors.no_colors
    assert not conf

# Generated at 2022-06-12 10:39:16.074762
# Unit test for function debug_time
def test_debug_time():
    with debug_time('test'):
        pass


# Generated at 2022-06-12 10:39:17.374757
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command('corrected_command')

# Generated at 2022-06-12 10:39:18.529075
# Unit test for function debug_time
def test_debug_time():
    with debug_time('msg'):
        pass

# Generated at 2022-06-12 10:39:27.306573
# Unit test for function debug_time
def test_debug_time():
    # FIXME: this should be in separate file,but now I afraid that Travis CI
    # will break.
    import time
    import contextlib
    class MockErr(object):
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

    stderr = sys.stderr
    sys.stderr = MockErr()
    try:
        with debug_time('Fake task'):
            time.sleep(0.2)
        assert 'Fake task took:' in sys.stderr.text
    finally:
        sys.stderr = stderr

# Generated at 2022-06-12 10:39:36.217505
# Unit test for function confirm_text
def test_confirm_text():
    sys.stderr.write = lambda x: None
    confirm_text(
        const.CorrectedCommand(
            script='ls -la',
            side_effect=False)) == \
        u'{prefix}ls -la [enter/↑/↓/ctrl+c]'.format(prefix=const.USER_COMMAND_MARK)

    confirm_text(
        const.CorrectedCommand(
            script='ls -la',
            side_effect=True)) == \
        u'{prefix}ls -la (+side effect) [enter/↑/↓/ctrl+c]'.format(
            prefix=const.USER_COMMAND_MARK)

# Generated at 2022-06-12 10:39:41.659218
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    from thefuck.conf import ConfigurationDetails
    from mock import patch
    from .utils import assert_equal, encode
    from thefuck.shells import Shell
    from thefuck.types import Command
    from thefuck.compat import unicode

    patch('sys.stderr', 'str').start()

# Generated at 2022-06-12 10:39:42.332178
# Unit test for function debug
def test_debug():
    debug('debug test')

# Generated at 2022-06-12 10:39:47.614006
# Unit test for function debug
def test_debug():
    assert debug(u'1') == sys.__stderr__.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m 1\n')
    assert debug(u'2') == sys.__stderr__.write(u'\x1b[34m\x1b[1mDEBUG:\x1b[0m 2\n')



# Generated at 2022-06-12 10:39:50.393539
# Unit test for function color
def test_color():
    assert color('foo') == 'foo'
    settings.no_colors = True
    assert color('bar') == ''



# Generated at 2022-06-12 10:39:56.174785
# Unit test for function confirm_text
def test_confirm_text():
    # there is no function for testing so I placed it here.
    fuck_command = 'fuck'
    corrected_command = 'git push'
    confirm_text(corrected_command)



# Generated at 2022-06-12 10:39:59.062268
# Unit test for function confirm_text
def test_confirm_text():
    if isinstance(confirm_text, str):
        assert confirm_text.__name__ == "confirm_text"
    else:
        assert confirm_text.__class__.__name__ == "function"

# Generated at 2022-06-12 10:40:00.645597
# Unit test for function color
def test_color():
    assert color('red')('text') == 'text'
    settings.no_colors = True
    assert color('red')('text') == ''

# Generated at 2022-06-12 10:40:07.268546
# Unit test for function debug_time
def test_debug_time():
    from .time import Time
    from .time import sleep
    import time

    start_time = Time()

    @contextmanager
    def debug_time(msg):
        started = Time()
        try:
            yield
        finally:
            debug(u'{} took: {}'.format(msg, Time() - started))

    with debug_time('Time') as t:
        # time.sleep(0.01)
        print(time.time() - start_time.time)


# Generated at 2022-06-12 10:40:09.227565
# Unit test for function debug_time
def test_debug_time():
    from datetime import timedelta
    with debug_time('query'):
        import time
        time.sleep(0.1)

# Generated at 2022-06-12 10:40:11.578859
# Unit test for function debug_time
def test_debug_time():
    from thefuck.utils import debug_time
    from datetime import datetime

    debug_time('test')
    assert datetime.now().second == 1



# Generated at 2022-06-12 10:40:15.642531
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    from . import conf
    import sys

    out = StringIO()
    sys.stderr = out
    settings.debug = True
    debug('Test debug message')
    assert out.getvalue().endswith('Test debug message\n')
    settings.debug = False
    debug('Test debug message')
    assert out.getvalue().endswith('Test debug message\n')
    sys.stderr = sys.__stderr__

# Generated at 2022-06-12 10:40:19.706872
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    configuration_details = namedtuple(
        'ConfigurationDetails', 'can_configure_automatically'
    )
    configuration_details.can_configure_automatically = True
    how_to_configure_alias(configuration_details)



# Generated at 2022-06-12 10:40:28.889662
# Unit test for function debug_time
def test_debug_time():
    """Testing debug_time function"""
    import time
    import unittest
    from StringIO import StringIO

    class DebugTimeTest(unittest.TestCase):
        def test_debug_time(self):
            """testing with output"""
            saved_stdout = sys.stdout
            try:
                out = StringIO()
                sys.stdout = out
                start = time.time()
                with debug_time('test'):
                    time.sleep(0.2)
                sys.stdout = saved_stdout
                result = out.getvalue()
                self.assertTrue('DEBUG: test took: 0:00:00.200' in result,
                                'incorrect result')
            finally:
                sys.stdout = saved_stdout


# Generated at 2022-06-12 10:40:34.904531
# Unit test for function color
def test_color():
    assert color(colorama.Back.RED + 'a') == '\x1b[41ma'
    assert color(colorama.Fore.RED + 'a') == '\x1b[31ma'
    assert color(colorama.Style.BRIGHT + 'a') == '\x1b[1ma'
    assert color(colorama.Back.RED + colorama.Fore.WHITE +
                 colorama.Style.BRIGHT + 'a') == '\x1b[41;37;1ma'
    assert color(colorama.Style.RESET_ALL + 'a') == '\x1b[0ma'



# Generated at 2022-06-12 10:40:44.001617
# Unit test for function debug
def test_debug():
    from io import StringIO
    import sys

    captured_output = StringIO()

    saved_stdout = sys.stdout
    sys.stdout = captured_output

    try:
        debug(u'test')
        assert captured_output.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m test\n'
    finally:
        sys.stdout = saved_stdout

# Generated at 2022-06-12 10:40:52.287912
# Unit test for function debug
def test_debug():
    from contextlib import contextmanager

    @contextmanager
    def capture(command, *args, **kwargs):
        import StringIO
        out, sys.stderr = sys.stderr, StringIO.StringIO()
        command(*args, **kwargs)
        sys.stderr.seek(0)
        yield sys.stderr.read()
        sys.stderr = out

    settings.debug = True
    with capture(debug, 'Hello world!') as output:
        assert output == '\x1b[34m\x1b[1mDEBUG:\x1b[0m Hello world!\n'

    settings.debug = False
    with capture(debug, 'Hello world!') as output:
        assert output == ''

# Generated at 2022-06-12 10:40:54.097625
# Unit test for function debug_time
def test_debug_time():
    with debug_time("test_debug_time"):
        pass

# Generated at 2022-06-12 10:41:04.683854
# Unit test for function debug
def test_debug():
    from _io import StringIO
    import sys
    import re
    import datetime

    old_stdout = sys.stdout
    old_stderr = sys.stderr
    try:
        out = sys.stdout = StringIO()
        debug(u'test text')
        result = out.getvalue()
        timestamp = re.search(u'^.\d{2}:\d{2}:\d{2}', result).group(0)
        assert timestamp
        assert datetime.datetime.strptime(timestamp, u'%H:%M:%S')
        assert u'DEBUG: test text' in result
    finally:
        sys.stdout.close()
        sys.stdout = old_stdout
        sys.stderr = old_stderr

# Generated at 2022-06-12 10:41:10.709552
# Unit test for function debug
def test_debug():
    import mock
    import io
    from thefuck import color

    stderr = io.StringIO()
    with mock.patch('sys.stderr', stderr):
        debug(u'Test')
        assert stderr.getvalue() == u'\x1b[34m\x1b[1mDEBUG:\x1b[0m Test\n'

    settings.debug = False
    stderr = io.StringIO()
    with mock.patch('sys.stderr', stderr):
        debug(u'Test')
        assert stderr.getvalue() == ''

# Generated at 2022-06-12 10:41:13.436684
# Unit test for function how_to_configure_alias
def test_how_to_configure_alias():
    print('test_how_to_configure_alias')
    how_to_configure_alias(None)



# Generated at 2022-06-12 10:41:20.146905
# Unit test for function debug
def test_debug():
    import mock
    import os
    command = 'ls'
    with mock.patch.object(os, 'environ') as mock_environ,\
            mock.patch.object(sys, 'stderr') as mock_stderr:
        mock_environ.__getitem__.return_value = 'true'
        debug(command)
        mock_stderr.write.assert_called_with(
            u'\x1b[34m\x1b[1mDEBUG:\x1b[0m {}\n'.format(command))

# Generated at 2022-06-12 10:41:28.055031
# Unit test for function show_corrected_command
def test_show_corrected_command():
    from thefuck.types import CorrectedCommand
    def check_output(script, side_effect):
        from io import StringIO
        import sys
        out = StringIO()
        saved_stdout = sys.stdout
        try:
            sys.stdout = out
            show_corrected_command(CorrectedCommand(script=script,side_effect=side_effect))
            output = out.getvalue().strip()
        finally:
            sys.stdout = saved_stdout
        return output

    assert check_output("ls","") == "> ls "
    assert check_output("ls","") == "> ls "
    assert check_output("ls"," +") == "> ls +"

# Generated at 2022-06-12 10:41:29.694495
# Unit test for function debug
def test_debug():
    debug(u'some message')



# Generated at 2022-06-12 10:41:31.752736
# Unit test for function confirm_text
def test_confirm_text():
    # All possible cases
    corrected_command = "command"
    assert confirm_text(corrected_command) == \
    "[user_command]command [enter/↑/↓/ctrl+c]"

# Generated at 2022-06-12 10:41:43.227185
# Unit test for function debug
def test_debug():
    from mock import patch, Mock
    with patch.object(settings, 'debug', True):
        msg = 'test'
        with patch('sys.stderr') as debug:
            debug(msg)
            debug.write.assert_called_with(colorama.Style.BRIGHT +
                                           colorama.Fore.BLUE +
                                           'DEBUG:' +
                                           colorama.Style.RESET_ALL +
                                           ' test\n')

    with patch.object(settings, 'debug', False):
        msg = 'test'
        with patch('sys.stderr') as debug:
            debug(msg)
            assert not debug.write.called

# Generated at 2022-06-12 10:41:52.187041
# Unit test for function show_corrected_command
def test_show_corrected_command():
    import os
    import filecmp
    args = [
        {"corrected_command": {'script': "", "side_effect": True}},
        {"corrected_command": {'script': "ls", "side_effect": True}},
        {"corrected_command": {'script': "echo", "side_effect": False}},
    ]
    for i in args:
        filename = "test_show_corrected_command_%s" % i
        f = open(filename, "w")
        show_corrected_command(i["corrected_command"])
        f.close()
        assert filecmp.cmp(filename, "tests/%s" % filename)
        if os.path.exists(filename):
            os.remove(filename)



# Generated at 2022-06-12 10:41:53.691580
# Unit test for function debug_time
def test_debug_time():
    settings.debug = True
    import time
    with debug_time('A'):
        time.sleep(0.05)
    with debug_time('B'):
        time.sleep(0.1)
    settings.debug = False

# Generated at 2022-06-12 10:41:58.803524
# Unit test for function confirm_text
def test_confirm_text():
    def check_confirm_text(cmd, expected):
        sys.stderr = StringIO()
        confirm_text(cmd)
        assert sys.stderr.getvalue() == expected
        sys.stderr = sys.__stderr__

    check_confirm_text(CorrectedCommand('ls', ''),
                       u'fuck!ls [enter/↑/↓/ctrl+c]')
    check_confirm_text(CorrectedCommand('ls', '', True),
                       u'fuck!ls (+side effect) [enter/↑/↓/ctrl+c]')

# Generated at 2022-06-12 10:42:00.389516
# Unit test for function show_corrected_command
def test_show_corrected_command():
    show_corrected_command(corrected_command(script='git push', side_effect=False))
    assert True


# Generated at 2022-06-12 10:42:02.187589
# Unit test for function debug_time
def test_debug_time():
    import time
    with debug_time('msg'):
        time.sleep(0.5)

# Generated at 2022-06-12 10:42:10.138331
# Unit test for function debug
def test_debug():
    from StringIO import StringIO
    old_err = sys.stderr
    sys.stderr = StringIO()
    debug(u'foo')
    captured = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = old_err
    assert 'DEBUG: foo\n' == captured
    settings.debug = False
    old_err = sys.stderr
    sys.stderr = StringIO()
    debug(u'foo')
    captured = sys.stderr.getvalue()
    sys.stderr.close()
    sys.stderr = old_err
    assert '' == captured

