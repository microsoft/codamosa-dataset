

# Generated at 2022-06-11 06:39:38.549218
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    mock_module = MagicMock()
    mock_module.__class__.__name__ = 'Module'
    mock_module.check_mode = True
    cb = get_add_ppa_signing_key_callback(mock_module)

    assert cb is None

    mock_module.check_mode = False
    a = 'aaa'
    cb = get_add_ppa_signing_key_callback(mock_module)
    cb(a)

    mock_module.run_command.assert_called_with(a, check_rc=True)



# Generated at 2022-06-11 06:39:43.904704
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = object
    module.check_mode = False
    def module_run_command(command, check_rc=False):
        return command
    module.run_command = module_run_command
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None


# Generated at 2022-06-11 06:39:56.047133
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sl = UbuntuSourcesList(module=None)

    # add_source() function is used to add the repo line in the actual file
    sl.add_source(line='deb http://deb.debian.org/debian stretch main', file='one_repo_one_line.list')
    assert 'one_repo_one_line.list' in sl.files
    assert sl.files['one_repo_one_line.list'] == [(0, True, True, 'deb http://deb.debian.org/debian stretch main', '')]

    sl.add_source(line='deb http://deb.debian.org/debian stretch main', file='one_repo_two_lines.list')
    assert 'one_repo_two_lines.list' in sl.files

# Generated at 2022-06-11 06:40:00.204180
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = FakeModule()
    module.params = {
        "filename": None,
        "mode": None,
        "codename": 'xenial'
    }

    sl = UbuntuSourcesList(module)
    if sl.codename != 'xenial':
        return False
    return True


# Generated at 2022-06-11 06:40:12.319486
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    test_dict = {}
    test_dir = os.path.dirname(os.path.realpath(__file__))
    for filename in [os.path.join(test_dir, 'sourceslist', 'sourceslist_1.list'),
                     os.path.join(test_dir, 'sourceslist', 'sourceslist_2.list')]:
        f = open(filename, 'r')
        group = []
        for n, line in enumerate(f):
            valid, enabled, source, comment = SourcesList._parse(line)
            group.append((n, valid, enabled, source, comment))
        test_dict[filename] = group
    test_sl = SourcesList.load(test_dir)
    assert test_dict == test_sl.files



# Generated at 2022-06-11 06:40:23.221087
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-11 06:40:35.485539
# Unit test for method load of class SourcesList

# Generated at 2022-06-11 06:40:45.356130
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    u = UbuntuSourcesList()
    u.add_source('deb http://ftp.debian.org/debian/ jessie-backports main')
    u.add_source('ppa:foo/bar')
    u.add_source('ppa:foobar')
    u.add_source('ppa:foobar/')

    assert len(u.files.keys()) == 3
    assert u.files[u._expand_path('_debian.list')] == [(0, True, True, 'deb http://ftp.debian.org/debian/ jessie-backports main', '')]
    assert u.files[u._expand_path('_ppa_foo_bar.list')] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu jessie main', '')]
    assert u

# Generated at 2022-06-11 06:40:54.513821
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.files = {
        'file_1': [
            (0, True, False, 'deb-src http://archive.canonical.com/ubuntu hardy partner', 'comment1'),
            (1, False, True, 'source', 'comment2'),
            (2, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'comment3'),
        ],
        # Empty file:
        'file_2': [],
    }
    sources.modify('file_1', 2, enabled='yes')
    sources.modify('file_1', 2, source='deb http://deb.example.com/ubuntu hardy')
    sources.modify('file_1', 2, comment='comment4')

# Generated at 2022-06-11 06:41:05.582056
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-11 06:42:08.122981
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    class Module(object):
        def __init__(self, fail_json_msg=None):
            self.params = {}
            self.fail_json_msg = fail_json_msg
            self.changed = False
            self.results = {'before': [], 'after': []}
            self.paths = {}

        def fail_json(self, **kwargs):
            if self.fail_json_msg:
                raise AssertionError(self.fail_json_msg)
            raise AssertionError("The module should not have failed")

        def exit_json(self, **kwargs):
            raise AssertionError("The module should not have succeeded")

        def set_changed(self):
            self.changed = True
            raise AssertionError("The module should not have succeeded")


# Generated at 2022-06-11 06:42:19.396335
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = MagicMock()
    module.params = {}
    module.params['filename'] = None
    module.params['codename'] = None
    module.params['mode'] = 644
    module.set_mode_if_different = MagicMock()
    module.atomic_move = MagicMock()
    module.fail_json = MagicMock()
    module.run_command = MagicMock()
    module.run_command.return_value = 0, "", ""
    sl = UbuntuSourcesList(module)
    sl.files = {
        '/etc/apt/sources.list': [
            (
                0,
                True,
                True,
                'deb http://ppa.launchpad.net/fkrull/deadsnakes/ubuntu xenial main',
                ''
            )
        ]
    }

# Generated at 2022-06-11 06:42:30.690028
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class ModuleMock(object):
        def __init__(self):
            self.params = dict(name="test")

    module = ModuleMock()
    sources = SourcesList(module)
    sources.load('/tmp/test_1')
    sources.modify('/tmp/test_1', 0, enabled=True, source="foo", comment="bar")
    assert sources.files['/tmp/test_1'][0][1:] == (True, True, "foo", "bar")
    sources.modify('/tmp/test_1', 0, enabled=False, source="foo", comment="bar")
    assert sources.files['/tmp/test_1'][0][1:] == (True, False, "foo", "bar")

# Generated at 2022-06-11 06:42:32.781646
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec=dict())
    u = UbuntuSourcesList(module)



# Generated at 2022-06-11 06:42:44.387941
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils._text import to_native
    m = MagicMock()
    s = UbuntuSourcesList(m)
    s.files = {'test_file': [(0, True, True, 'deb http://ppa.launchpad.net/test_ppa/test_ppa/ubuntu artful main', ''),
                             (1, True, True, 'deb http://ppa.launchpad.net/test_ppa/test_ppa/ubuntu bionic main', ''),
                             (2, True, True, 'deb http://ppa.launchpad.net/test_ppa/test_ppa/ubuntu xenial main', ''),
                             (3, True, False, 'deb http://ppa.launchpad.net/test_ppa/test_ppa/ubuntu xenial main', '')]}

# Generated at 2022-06-11 06:42:56.237343
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    module = AnsibleModule({})
    # Load imaginary sources.list file
    with tempfile.NamedTemporaryFile(mode='w') as tmp:
        tmp.write('''deb http://cdn.debian.net/debian/ squeeze main non-free contrib
deb http://security.debian.org/ squeeze/updates main non-free contrib
deb http://cdn.debian.net/debian/ squeeze-proposed-updates main non-free contrib
''')
        tmp.flush()
        sl = SourcesList(module)
        sl.load(tmp.name)
        assert len(sl.files) == 1
        assert len(sl.files[tmp.name]) == 3
        # File's content is correctly parsed
        valid, enabled, source, comment = sl.files[tmp.name][1]
        assert enabled

# Generated at 2022-06-11 06:43:06.256066
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files['foo.list'] = [(0, True, True, 'deb http://foo.com/debian/ jessie main', '')]
    sl.files['bar.list'] = [(0, True, True, 'deb http://bar.com/debian/ stretch main', ''),
                            (1, True, True, 'deb http://baz.com/debian/ stretch main', '')]

# Generated at 2022-06-11 06:43:16.317234
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import os
    from .mock import patch
    from .mock import Mock

    class Args(object):
        def __init__(self, params):
            self.__dict__ = params

    def do_test(params, expected_result):
        module = Mock()
        module.params = Args(params)
        module.run_command.return_value = (0, '', '')
        module.atomic_move.return_value = None
        module.set_mode_if_different.return_value = None

        sources = UbuntuSourcesList(module)

        sources.add_source(module.params.line, comment=module.params.comment, file=module.params.filename)


# Generated at 2022-06-11 06:43:25.423747
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    content = '''deb [ arch=amd64 ] http://deb.debian.org/debian jessie main contrib
deb-src http://deb.debian.org/debian jessie main contrib
deb http://deb.debian.org/debian jessie-updates main contrib
deb-src http://deb.debian.org/debian jessie-updates main contrib

deb http://security.debian.org/debian-security jessie/updates main contrib
deb-src http://security.debian.org/debian-security jessie/updates main contrib
'''
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sources = SourcesList(m)

# Generated at 2022-06-11 06:43:33.499400
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-11 06:44:44.237853
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class Module(object):
        def __init__(self):
            self.params = {}

    module = Module()
    sl = UbuntuSourcesList(module)
    assert('/etc/apt/sources.list' in sl.files)
    assert(len(sl.files['/etc/apt/sources.list']) == 1)

# Generated at 2022-06-11 06:44:54.677534
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class FakeModule(object):
        def __init__(self):
            self.params = {}

    module = FakeModule()

    sources = SourcesList(module)

# Generated at 2022-06-11 06:45:04.988427
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test for the case that repository already exists
    class MyModule(object):
        pass

    my_module = MyModule()
    my_module.params = {"mode": None, "filename": None, "codename": "xenial"}
    def my_add_ppa_signing_keys_callback(command):
        pass
    ubuntu_sources_list = UbuntuSourcesList(my_module, add_ppa_signing_keys_callback=my_add_ppa_signing_keys_callback)
    ubuntu_sources_list.repos_urls = ['deb http://ppa.launchpad.net/some_owner/some_ppa/ubuntu xenial main']

# Generated at 2022-06-11 06:45:15.187967
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class TestSourcesList(SourcesList):
        def __init__(self, module, files):
            self.module = module
            self.files = {}
            self.new_repos = set()
            self.default_file = 'sources.list'
            for file, lines in files.items():
                group = []
                for n, line in enumerate(lines):
                    valid, enabled, source, comment = self._parse(line)
                    group.append((n, valid, enabled, source, comment))
                self.files[file] = group

    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda **kwargs: None  # do nothing

    def assertEqual(a, b):
        assert a == b, "%r != %r" % (a, b)


# Generated at 2022-06-11 06:45:25.143701
# Unit test for function install_python_apt
def test_install_python_apt():
    from mock import MagicMock, patch
    from ansible.modules.packaging.os import apt_repository
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})

    # Create a mock fail_json, which is called to fail when check mode is enabled and python-apt is not installed
    module.fail_json = MagicMock()

    # Create a mock apt-get command, which is invoked when python-apt is installed automatically
    apt_get_path = MagicMock(return_value='/usr/bin/apt-get')
    module.get_bin_path = MagicMock(return_value=apt_get_path)

    # Create mocks for each apt-get command, which is invoked when python-apt is installed automatically

# Generated at 2022-06-11 06:45:32.338885
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={'demo': dict(type='bool', default=False)})
    sourceslist = SourcesList(module)
    sourceslist.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='This repo is used to test SourcesList __iter__ function')
    sourceslist.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main', comment='This repo is used to test SourcesList __iter__ function')
    sourceslist.add_source('deb http://us.archive.ubuntu.com/ubuntu/ bionic main universe', comment='This repo is used to test SourcesList __iter__ function')

# Generated at 2022-06-11 06:45:39.130520
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    tempdir = tempfile.mkdtemp(prefix='aptrepository-')
    foo_fn = os.path.join(tempdir, 'foo.list')

# Generated at 2022-06-11 06:45:47.955467
# Unit test for function install_python_apt
def test_install_python_apt():
    import os
    import uuid
    import tempfile
    import shutil

    # Set up temporary directory to mimic a Debian environment
    # with a working package manager and a package we can install
    temp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(temp_dir, 'bin'))
    os.mkdir(os.path.join(temp_dir, 'usr', 'lib', 'python2.7', 'dist-packages'))

    # Create a fake apt-get which will print "Successfully installed"
    # to stdout if it is given the arguments "install" and a package name
    fake_apt_get_path = os.path.join(temp_dir, 'bin', 'apt-get')

# Generated at 2022-06-11 06:45:56.725857
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class DummyModule:
        class DummyFailJson:
            def __call__(self, msg):
                raise Exception(msg)
        fail_json = DummyFailJson()

        class DummyYaml:
            def __call__(self, msg):
                return {'default_file': './sources.list', 'files': [{'./sources.list': 'deb file:///mnt/cdrom/ /\n'}]}
        params = DummyYaml()

        class DummyAtomicMove:
            def __call__(self, tmp_path, filename):
                return True
        atomic_move = DummyAtomicMove()

        class DummySetModeIfDifferent:
            def __call__(self, filename, mode, follow):
                return True
        set_mode_if_different = Dummy

# Generated at 2022-06-11 06:46:05.825718
# Unit test for function main