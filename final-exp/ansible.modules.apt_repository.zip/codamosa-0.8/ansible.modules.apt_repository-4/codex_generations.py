

# Generated at 2022-06-11 06:39:29.152226
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert all(isinstance(line, tuple) and len(line) == 5 for line in SourcesList(None))



# Generated at 2022-06-11 06:39:37.525555
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # noinspection PyUnusedLocal
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main universe restricted')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main universe restricted multiverse')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main universe restricted multiverse # pairs')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main universe restricted multiverse # pairs')

   

# Generated at 2022-06-11 06:39:46.491762
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Create a temporary directory and change to it
    #   Create two files and add a source to each file
    #   Save the state of the new sourceslist files for future comparison
    #   Change our current sources list with a new source in a new file
    #   Exit the directory
    #   Change back to the original directory
    #   Revert the sources list with the revert_sources_list function
    #   Assert that the sources list files match the originals
    tmp_dir = tempfile.mkdtemp()
    orig_dir = os.getcwd()
    os.chdir(tmp_dir)
    filename = "test_revert_sources_list"
    for num in range(1, 3):
        open(filename + str(num), 'a').close()
        apt_sources = SourcesList(module=None)
       

# Generated at 2022-06-11 06:39:57.426405
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    filename = 'sources.list'
    state = 'present'
    exists = os.path.exists(filename)
    if exists:
        with open(filename, 'r') as f:
            original = f.read()

    sl = SourcesList()
    comment = 'my comment'
    sources = [
        'deb http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse',
        'deb http://archive.ubuntu.com/ubuntu xenial-updates main restricted universe multiverse',
        '# deb http://archive.ubuntu.com/ubuntu xenial-backports main restricted universe multiverse',
        '# deb http://archive.ubuntu.com/ubuntu xenial-security main restricted universe multiverse'
    ]
    for source in sources:
        sl.add_source(source, comment)


# Generated at 2022-06-11 06:39:58.080253
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    pass

# Generated at 2022-06-11 06:40:09.840460
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(required=True, choices=['present', 'absent']),
            source=dict(required=True),
            update_cache=dict(required=False, default=False, type='bool'),
            filename=dict(required=False, default=None),
            codename=dict(required=False, default=None),
            mode=dict(choices=['0644'], required=False, default=None),
        )
    )

    sources_before = sourceslist_before = SourcesList(module)
    sources_after = SourcesList(module)

    sources_after.add_source(os.path.abspath(__file__))
    sources_after.save()


# Generated at 2022-06-11 06:40:12.447340
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    m = MagicMock()
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(m)
    add_ppa_signing_key_callback(['ls', '-la'])
    m.run_command.assert_called_with(['ls', '-la'], check_rc=True)



# Generated at 2022-06-11 06:40:23.285156
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sources = SourcesList()

    assert sources
    assert len(sources) == 0

    sources.add_source('deb http://mirror.de.leaseweb.net/debian/ jessie main')
    sources.add_source('deb http://mirror.de.leaseweb.net/ubuntu/ trusty main')

    assert len(sources) == 2

    for src in sources:
        assert src[1] in ('deb http://mirror.de.leaseweb.net/debian/ jessie main',
                          'deb http://mirror.de.leaseweb.net/ubuntu/ trusty main')

    sources.add_source('deb http://mirror.de.leaseweb.net/ubuntu/ trusty main')
    assert len(sources) == 2


# Generated at 2022-06-11 06:40:35.577246
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec=dict())

    sources_list = SourcesList(module)

# Generated at 2022-06-11 06:40:45.446933
# Unit test for function main
def test_main():
    import aptsources
    filename = aptsources.__file__
    sourceslist = "deb http://arch_mirrors/ubuntu precise main universe"
    state = "absent"
    repo = "http://arch_mirrors/ubuntu precise main universe"

    # Test: name not found

# Generated at 2022-06-11 06:41:26.382565
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.six import StringIO
    module = AnsibleModule(argument_spec={})
    content = StringIO(to_bytes("""# Comment
deb http://localhost/deb/ precise main
deb http://localhost/deb/ precise universe
deb-src http://localhost/src precise main
"""))
    content.name = 'sources.list'
    sl = SourcesList(module)
    sl.files['sources.list'] = []
    n = 0
    for line in content:
        valid, enabled, source, comment = sl._parse(line)
        if valid:
            sl.files[content.name].append((n, valid, enabled, source, comment))
        n += 1

# Generated at 2022-06-11 06:41:27.529686
# Unit test for function install_python_apt
def test_install_python_apt():
    assert False


# Generated at 2022-06-11 06:41:33.899939
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule.fake_module()
    sl = SourcesList(module)
    repo_url = 'deb http://deb.debian.org/debian/ stable main'
    sl.add_source(repo_url)
    filename = sl._suggest_filename(repo_url)
    assert file in sl.files
    assert sl.files[filename][0][3] == repo_url
    assert sl.files[filename][0][4] == ''


# Generated at 2022-06-11 06:41:40.618619
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sources = UbuntuSourcesList(module)
    assert sources.codename == 'xenial'
    assert sources.add_ppa_signing_keys_callback is None

    module = AnsibleModule(argument_spec={'codename': {'default': 'yakkety'}})
    sources = UbuntuSourcesList(module)
    assert sources.codename == 'yakkety'
    assert sources.add_ppa_signing_keys_callback is None



# Generated at 2022-06-11 06:41:50.077907
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # input args for the function
    dummy_sources_before = {}
    dummy_sources_after = {}
    dummy_sourceslist_before = {}
    # execute the function
    # assert the result
    # Although the function has been tested in the main body, the following test covers the error logging in the function.
    with pytest.raises(Exception) as excinfo:
        revert_sources_list(dummy_sources_before, dummy_sources_after, dummy_sourceslist_before)
    expected_error = 'revert_sources_list errored: %s' % dummy_sources_before
    assert str(excinfo.value) == expected_error



# Generated at 2022-06-11 06:42:00.471680
# Unit test for function main

# Generated at 2022-06-11 06:42:12.531432
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class FakeModule:
        # In order to test, we need to mock atomic_move (file.atomic_move)
        def atomic_move(self, src, dst):
            pass
        def set_mode_if_different(self, path, mode, changed):
            pass
    class FakeAnsibleModule:
        def __init__(self, src, dst):
            self.params = {'filename': dst}
        def fail_json(self, msg):
            raise Exception("%s" % msg)
    fm = FakeModule()
    l = SourcesList(fm)
    am = FakeAnsibleModule("", "")
    l.module = am
    l.new_repos = set()
    l.add_source("deb http://archive.ubuntu.com/ubuntu precise main universe", "test")
    l.add

# Generated at 2022-06-11 06:42:20.920918
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule({}, {}, {}, [])
    # pass empty callable as add_ppa_signing_keys_callback
    ubuntu_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=lambda command: None)

    ubuntu_sources_list_deep_copy = copy.deepcopy(ubuntu_sources_list)
    ubuntu_sources_list_deep_copy.add_ppa_signing_keys_callback = lambda command: None

    assert isinstance(ubuntu_sources_list_deep_copy, UbuntuSourcesList)
    assert ubuntu_sources_list_deep_copy.add_ppa_signing_keys_callback == ubuntu_sources_list.add_ppa_signing_keys_callback


# Generated at 2022-06-11 06:42:32.005305
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    # The return value of the function will be a function object
    # This is what we will test
    return_value = get_add_ppa_signing_key_callback(module)
    assert return_value and callable(return_value)
    # If check_mode is set, then the callable should return None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None
    # Now, for the check_mode being False case - we don't have a better way
    # to test this other than to test if there's a calling exception
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None


# Generated at 2022-06-11 06:42:41.129756
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    valid, enabled, source, comment = sl._parse('# deb cdrom:[Debian GNU/Linux 9.1.0 _Stretch_ - Official amd64 DVD Binary-1 20170523-12:10]/ stretch contrib', raise_if_invalid_or_disabled=True)
    sl.add_source(source)
    source_found = False
    for filename, n, enabled, source, comment in sl:
        if source == source:
            source_found = True
            break
    assert source_found

# Generated at 2022-06-11 06:43:24.692299
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Set up the module and its parameters.
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params['state'] = 'present'
    module.params['repo'] = 'deb http://archive.canonical.com/ubuntu hardy partner'
    module.params['filename'] = None

    # We have to mock the resources.
    module._apt_cfg_file = staticmethod(lambda x: x.replace('Dir::Etc::', 'test/'))
    module._apt_cfg_dir = staticmethod(lambda x: x.replace('Dir::Etc::', 'test/'))
    module.atomic_move = lambda src, dest: None
    module.makedirs = lambda x: None

# Generated at 2022-06-11 06:43:34.632566
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    for sample_file in (
        'sources.list',
        'sources.list.d.sample',
        'sources.list.d.disabled.sample',
    ):
        f = open(os.path.join(os.path.dirname(__file__), sample_file))
        module_args = {
            'repo': f.read(),
            'state': 'present',
        }
        m = AnsibleModule(argument_spec={})
        m.params = module_args
        sl = SourcesList(m)
        dumpstruct = sl.dump()
        if not dumpstruct:
            m.fail_json(msg="Dump results are empty for %s" % sample_file)

# Generated at 2022-06-11 06:43:37.067508
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.exit_json(changed=False)



# Generated at 2022-06-11 06:43:47.074781
# Unit test for method load of class SourcesList

# Generated at 2022-06-11 06:43:56.290061
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class Module(object):
        def __init__(self, argv):
            self.tmpdir = argv[-1]
            del argv[-1]
            self.argv = argv

        def fail_json(self, msg):
            raise Exception(msg)

        def debug(self, msg):
            print(msg)

    def _choice(new, old):
        if new is None:
            return old
        return new

    def modify(file, n, enabled=None, source=None, comment=None):
        '''
        This function to be used with iterator, so we don't care of invalid sources.
        If source, enabled, or comment is None, original value from line ``n`` will be preserved.
        '''

# Generated at 2022-06-11 06:44:06.953444
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os

    tmp = tempfile.mkdtemp()


# Generated at 2022-06-11 06:44:16.785753
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    f = get_add_ppa_signing_key_callback(None)
    assert f is None
    class ModuleMock:
        def __init__(self, check_mode=True):
            self.check_mode = check_mode
        def run_command(self, cmd, check_rc=True):
            pass
    f = get_add_ppa_signing_key_callback(ModuleMock())
    assert f is None
    cmd_run = []
    def run_command(self, cmd, check_rc=True):
        cmd_run.append(cmd)

    module = ModuleMock(check_mode=False)
    module.run_command = run_command
    f = get_add_ppa_signing_key_callback(module)
    f(['foo', 'bar', 'baz'])
   

# Generated at 2022-06-11 06:44:21.140382
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sources = SourcesList(None)
    cloned = deepcopy(sources)

    assert cloned == sources
    assert cloned.module == sources.module
    assert cloned.add_ppa_signing_keys_callback == sources.add_ppa_signing_keys_callback
    assert cloned.codename == sources.codename
    assert cloned.files == sources.files



# Generated at 2022-06-11 06:44:31.267488
# Unit test for method load of class SourcesList

# Generated at 2022-06-11 06:44:32.800931
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test without filename
    # Test with filename
    pass


# Generated at 2022-06-11 06:45:50.800242
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test method add_source with line like:  'ppa:<ppa_name>/<ppa_owner>'
    line = 'ppa:ansible/ansible2'
    module = Mock()
    module.params = {'codename': 'trusty'}
    ppa_owner = 'ansible'
    ppa_name = 'ansible2'
    module.run_command = MagicMock(return_value=(0, '', ''))
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)

    # Execute method
    usl.add_source(line)

    # Tests

# Generated at 2022-06-11 06:45:53.233699
# Unit test for function main
def test_main():
    # TODO: add unit tests for proper code coverage and
    #       to make sure the unit tests themselves are correct
    assert False

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:46:02.261399
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    amended_source1 = "deb http://archive.canonical.com/ubuntu hardy partner"
    amended_source2 = "deb-src http://archive.canonical.com/ubuntu hardy partner"
    amended_comment1 = ""
    amended_comment2 = "# test comment"
    amended_file = "/tmp/test_SourcesList_add_source.list"
    def check_result(file_name, source, comment):
        if added_sources.get(file_name) == None:
            return False
        lines = added_sources[file_name]
        for n, valid, enabled, src, comm in lines:
            if src == source and comm == comment:
                return True
        return False
    ###############################################################################
    ### Test case 1: Add new line to existing file.
    ### Expectation: Line with

# Generated at 2022-06-11 06:46:11.445798
# Unit test for function revert_sources_list
def test_revert_sources_list():
    class Module(object):
        def __init__(self):
            self.params = dict()
        def fail_json(self, **kwargs):
            pass
        def atomic_move(self, src, dest):
            pass

# Generated at 2022-06-11 06:46:14.556191
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({})
    got = get_add_ppa_signing_key_callback(module)
    expected = None
    assert got == expected, "Expected '%s' but got '%s'" % (expected, got)



# Generated at 2022-06-11 06:46:22.998273
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Unit test for method remove_source of class SourcesList
    """
    module = AnsibleModule({})
    class Test:
        def fail_json(self, msg):
            print(msg)
    module.fail_json = Test().fail_json
    sl = SourcesList(module)
    sl._add_valid_source("deb http://repo_host/repo_path repo_component", "commented")
    assert len(sl.files["/etc/apt/sources.list"]) == 1
    sl.remove_source("deb http://repo_host/repo_path repo_component")
    assert len(sl.files["/etc/apt/sources.list"]) == 0


# Generated at 2022-06-11 06:46:32.394213
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = DummyModule()
    sources_list = SourcesList(module)
    assert sources_list.module is module
    assert sources_list.new_repos == set()
    assert sources_list.default_file == '/etc/apt/sources.list'

# Generated at 2022-06-11 06:46:39.205789
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={'state': dict(default='present', choices=['present', 'absent']), 'repo': dict(required=True), 'filename': dict(), 'update_cache': dict(default=True, type='bool'), 'validate_certs': dict(required=True, type='bool')})
    module.update_cache = True
    module.success_keywords = [('changed','true')]
    module.fail_json = lambda msg: sys.exit(msg)
    module.params = {'repo': 'ppa:nginx/stable',
                     'state': 'present',
                     'update_cache': False}

# Generated at 2022-06-11 06:46:48.133990
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    Test to check if all algoritms in ``SourcesList.dump`` function is working
    '''
    # Let's create a new module object, this is required for running method
    # load and dump.
    module = type('', (), dict(atomic_move=True, set_mode_if_different=True))()

    # Create a file, in which new data will be stored
    filename = 'sources.list'
    fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % filename, dir='/tmp')
    f = os.fdopen(fd, 'w')
    f.write('\n')

# Generated at 2022-06-11 06:46:51.413813
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = DummyModule()
    assert get_add_ppa_signing_key_callback(module) is None

    module = DummyModule(check_mode=False)
    assert type(get_add_ppa_signing_key_callback(module)) == FunctionType

