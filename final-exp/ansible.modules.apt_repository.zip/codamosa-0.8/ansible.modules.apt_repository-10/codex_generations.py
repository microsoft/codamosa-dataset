

# Generated at 2022-06-11 06:39:42.534596
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda: None

    sources = SourcesList(module)

    assert os.path.isfile(sources.default_file)

    for file_name in sources.files:
        assert os.path.isfile(file_name)

    for file, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            assert sources[n][0] == n



# Generated at 2022-06-11 06:39:54.811128
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-11 06:40:06.135945
# Unit test for function install_python_apt
def test_install_python_apt():

    apt_pkg_name = "python3-apt"

    # Check if python3-apt is installed
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    global apt
    try:
        import apt
        HAVE_PYTHON_APT = True
    except ImportError:
        HAVE_PYTHON_APT = False
    if not HAVE_PYTHON_APT:
        install_python_apt(module, apt_pkg_name)

    # Check if installed package is the one we want
    if HAVE_PYTHON_APT:
        import apt
        import apt_pkg
        import aptsources.distro as aptsources_distro
        apt_pkg_module = apt_pkg.__name__

# Generated at 2022-06-11 06:40:17.146342
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module_helper = AnsibleModule(argument_spec={})
    module_helper.params = {}
    module_helper.params['codename'] = 'bionic'
    sl = UbuntuSourcesList(module_helper)
    sl._add_valid_source("deb http://ppa.launchpad.net/example/example1/ubuntu bionic main", "example_file")
    assert len(sl.files) == 1
    for filename, sources in sl.files.items():
        assert filename == "example_file"
        assert sources == [(0, True, True, "deb http://ppa.launchpad.net/example/example1/ubuntu bionic main", "example_file")]

# Generated at 2022-06-11 06:40:25.395478
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json_called = False

        def fail_json(self, **kwargs):
            self.fail_json_called = True

    sources = [
        "# Comment",
        "deb cdrom:[Debian GNU/Linux 8.2.0 _Jessie_ - Official amd64 DVD Binary-1 20170225-11:01]/ jessie contrib main",
        "deb http://deb.debian.org/debian/ stretch main",
        "deb http://deb.debian.org/debian/ stretch-updates main",
        "deb http://security.debian.org/ stretch/updates main",
    ]

# Generated at 2022-06-11 06:40:26.196115
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass



# Generated at 2022-06-11 06:40:35.340881
# Unit test for function main
def test_main():
    '''
    Test cases with Source as parameter

    Test cases with mode as parameter

    Test cases with codename as parameter

    Test cases with update_cache as parameter

    Test cases with update_cache_retries as parameter

    Test cases with update_cache_retry_max_delay as parameter

    Test cases with filename as parameter

    Test cases with install_python_apt as parameter

    Test cases with validate_certs as parameter

    Test cases with repo as parameter

    Test cases with state as parameter

    '''
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:40:42.137908
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sources = SourcesList(None)
    sources.load('/etc/apt/sources.list')

    assert len(sources.files) == 1
    assert '/etc/apt/sources.list' in sources.files
    assert len(sources.files['/etc/apt/sources.list']) == 4
    assert sources.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://us.archive.ubuntu.com/ubuntu/ xenial main restricted', '')



# Generated at 2022-06-11 06:40:50.379885
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-11 06:41:00.921346
# Unit test for function main
def test_main():
    import copy
    import random
    import time
    import apt.cache
    import aptsources.sourceslist
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.common.dict_transformations import recursive_diff
    from ansible.module_utils.pycompat24 import to_unicode
    import ansible.module_utils.apt_pkg
    import ansible.module_utils.apts

# Generated at 2022-06-11 06:41:40.040252
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert list(SourcesList('# deb http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse\n# deb-src http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse\n').__iter__()) == [('', 0, True, 'deb http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse', ''), ('', 1, True, 'deb-src http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse', '')]


# Generated at 2022-06-11 06:41:50.818231
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    """
    Test the `UbuntuSourcesList` class.

    """
    import tempfile
    import os

    temp_sources_list_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
    temp_sources_list_file.write('deb http://ppa.launchpad.net/test/test1/ubuntu/ xenial main\n')
    temp_sources_list_file.write('deb http://ppa.launchpad.net/test/test2/ubuntu/ xenial main\n')
    temp_sources_list_file.write('deb http://ppa.launchpad.net/test/test1/ubuntu/ trusty main\n')
    temp_sources_list_file.write('deb http://ppa.launchpad.net/test/test2/ubuntu/ trusty main\n')


# Generated at 2022-06-11 06:42:00.889394
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec=dict(
        check_mode=dict(required=False, choices=BOOLEANS, type='bool', default=False)
    ))
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None, "Function must return None in check_mode"

    module = AnsibleModule(argument_spec=dict(
        check_mode=dict(required=False, choices=BOOLEANS, type='bool', default=False)
    ))
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None, "Function must return not None when not in check_mode"
    callback(['dummy'])

# Generated at 2022-06-11 06:42:13.072122
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # file is missing
    module = AnsibleModule(argument_spec=dict(repo='', state='absent'))
    apm = SourcesList(module)
    assert not apm.files

    # create a file in /etc/apt/sources.list.d/
    with tempfile.NamedTemporaryFile(mode='w+', prefix='ansible', suffix='.list', dir='/etc/apt/sources.list.d') as f:
        filename = f.name

    # create a valid source entry
    source_new = "deb http://archive.ubuntu.com/ubuntu xenial main"
    enabled_new = True
    valid_new = True
    comment_new = " Added by ansible"

    # create a invalid source entry

# Generated at 2022-06-11 06:42:21.347533
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    '''
    Test the add_source method of the UbuntuSourcesList class
    '''
    # Create a mock module
    module = AnsibleModule(argument_spec={
        'state': dict(type='str', default='present', choices=['absent', 'present']),
        'update_cache': dict(type='bool', default=False),
        'repo': dict(type='str', required=True),
        'mode': dict(type='raw'),
        'filename': dict(type='str'),
        'dist': dict(type='str'),
        'key_url': dict(type='str'),
        'validate_certs': dict(type='bool', default=True),
        'key_id': dict(type='str'),
    })

# Generated at 2022-06-11 06:42:32.995119
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Test iterating over one source in one file.
    sources = SourcesList(None)
    sources.files = {'file': [(-1, True, True, 'source', '')]}
    file, n, enabled, source, comment = next(iter(sources))
    assert file == 'file'
    assert n == 0
    assert enabled
    assert source == 'source'
    assert comment == ''

    # Test iterating over multiple sources in multiple files.
    sources = SourcesList(None)
    sources.files = {'file': [(-1, True, True, 'source', ''), (-1, True, False, 'disabled_source', ''), (-1, True, True, 'enabled_source', '')]}
    source_count = 0

# Generated at 2022-06-11 06:42:38.857064
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """
    Unit test for method save of class SourcesList.
    """
    import tempfile
    def create_sourceslist():
        """
        Create sourceslist with two files:
        a file with two entries that are both valid, one enabled and anothe disabled.
        a file with one entry that is valid and enabled
        """
        f = SourcesList(None)

# Generated at 2022-06-11 06:42:50.195416
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule(object):
        def __init__(self):
            self.params = {'codename': 'trusty'}
            self.run_command = lambda command, check_rc: ('', '', '')
        def fail_json(self, msg):
            raise Exception(msg)
        def atomic_move(self, tmp, dest):
            pass

    with TemporaryDirectory() as tmpdir:
        module = MockModule()
        sources_list = UbuntuSourcesList(module)
        file = os.path.join(tmpdir, 'foo.list')
        sources_list.add_source('ppa:foo/bar', file=file)
        sources_list.add_source('http://example.org', file=file)

# Generated at 2022-06-11 06:42:55.286108
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={'state': {'type': 'str'}})
    sources_before = dict()
    sources_after = dict()
    sourceslist_before = SourcesList(module)

    revert_sources_list(sources_before, sources_after, sourceslist_before)



# Generated at 2022-06-11 06:43:05.479123
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # Create directory for testing
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-11 06:44:30.341423
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list = SourcesList()
    assert sources_list.dump() == {}

    # add sources.list file
    sources_list.files['/etc/apt/sources.list'] = [(1, True, True, 'deb http://archive.canonical.com/ubuntu trusty partner', '')]
    # add other file
    sources_list.files['/etc/apt/sources.list.d/other.list'] = [(1, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty multiverse', '')]


# Generated at 2022-06-11 06:44:42.036816
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    from ansible.module_utils.common.collections import ImmutableDict
    test_list = SourcesList(AnsibleModule(argument_spec=dict(test=dict(type='bool', default=True)),
                                          bypass_checks=True, no_log=True))
    test_list.files = {'/tmp/test.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial main', '# a comment'),
                                          (1, True, False, 'deb http://archive.ubuntu.com/ubuntu xenial-updates main', '# a comment'),
                                          (2, False, False, 'deb http://archive.ubuntu.com/ubuntu xenial-security main', '# a comment'),]}
    test_list.modify('/tmp/test.list', 0, enabled=False)

# Generated at 2022-06-11 06:44:53.084046
# Unit test for constructor of class SourcesList

# Generated at 2022-06-11 06:45:00.402667
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest
    import inspect
    import sys
    class TestUbuntuSourcesList(unittest.TestCase):
        global _UbuntuSourcesList
        _Usl = _UbuntuSourcesList()
        def test_add_source(self):
            param = {"key": "value"}
            result = self._Usl.add_source(param)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestUbuntuSourcesList)
    unittest.TextTestRunner(testRunner=unittest.TextTestRunner(stream=sys.stdout)).run(suite)



# Generated at 2022-06-11 06:45:11.035955
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.params = {}
            self.failed = False
            self.changed = False

        def fail_json(self, *params):
            self.failed = True

        def atomic_move(self, src, dst):
            pass

        def set_mode_if_different(self, path, mode, not_a_directory):
            pass
    sl = SourcesList(Module())
    sl.load('tests/sourceslist')
    sl.remove_source('deb-src http://deb.debian.org/debian/ jessie main')

# Generated at 2022-06-11 06:45:19.183438
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    params = dict(
        repo='ppa:nginx/stable',
        state='present',
    )
    sl = SourcesList(params)
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 1
    assert sl.files['/etc/apt/sources.list'][0][2] == True
    assert sl.files['/etc/apt/sources.list'][0][3] == 'ppa:nginx/stable'
    sl.modify('/etc/apt/sources.list', 0, 'ppa:nginx/development', comment='some comment')
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 1

# Generated at 2022-06-11 06:45:24.984829
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import tempfile

    test_sources = """### THIS FILE IS AUTOMATICALLY CONFIGURED ###
# You may comment out this entry, but any other modifications may be lost.
deb http://archive.ubuntu.com/ubuntu/ bionic-updates main restricted

# deb-src http://archive.ubuntu.com/ubuntu/ bionic-updates main restricted
deb http://archive.ubuntu.com/ubuntu/ bionic-updates main restricted"""


# Generated at 2022-06-11 06:45:32.232634
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    def assert_result(lines, result):
        sources_list = SourcesList(None)
        for line in lines:
            sources_list.add_source(line)
        for line, output in result:
            valid, enabled, source, comment = sources_list._parse(line)
            for i, (valid_i, enabled_i, source_i, comment_i) in enumerate(sources_list.files.values()[0]):
                if valid_i == valid and enabled_i == enabled and source_i == source and comment_i == comment:
                    sources_list.modify(sources_list.files.keys()[0], i, enabled=output[0], source=output[1], comment=output[2])
        return sources_list


# Generated at 2022-06-11 06:45:41.491530
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    m = AnsibleModule(argument_spec={})
    sl = SourcesList(m)
    sl.save()

    sl_new = SourcesList(m)
    assert len(sl.files) == len(sl_new.files)

    for filename, sl_l in sl.files.items():
        assert filename in sl_new.files
        sl_l_new = sl_new.files[filename]
        assert len(sl_l) == len(sl_l_new)
        for i in range(len(sl_l)):
            assert sl_l[i][0] == sl_l_new[i][0]
            assert sl_l[i][1] == sl_l_new[i][1]
            assert sl_l[i][2] == sl_l_new[i][2]
            assert sl

# Generated at 2022-06-11 06:45:50.450483
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module_args = {}
    module = AnsibleModule(argument_spec=module_args)
    sources = SourcesList(module)
    module.fail_json = lambda msg: print(msg)
    # setup test sources