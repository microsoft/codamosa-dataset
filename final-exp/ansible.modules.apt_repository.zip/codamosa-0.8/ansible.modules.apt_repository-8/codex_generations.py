

# Generated at 2022-06-11 06:39:34.333726
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    f = tempfile.NamedTemporaryFile()
    list = SourcesList(module, f.name)
    list.add_source("deb http://foo foo main", "test")
    list.add_source("deb-src http://foo foo main", "test")
    list.add_source("# deb-src http://foo foo main", "test")
    list.save()

    f.seek(0)
    assert "# deb-src http://foo foo main # test\n" == f.readline()
    assert "deb http://foo foo main # test\n" == f.readline()
    assert "deb-src http://foo foo main # test\n" == f.readline()
    f.close()


# Generated at 2022-06-11 06:39:44.687025
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import os.path
    from tempfile import mkdtemp

    class DummyModule(object):
        params = {
            'filename': None,
        }

        def atomic_move(self, tmp_path, filename):
            os.rename(tmp_path, filename)

        def set_mode_if_different(self, filename, mode, recursive):
            pass

    class DummyAptModule(object):
        def __init__(self, tmpdir):
            self.module = DummyModule()
            self.tmpdir = tmpdir

        def _apt_cfg_file(self, var):
            if var == 'Dir::Etc::sourcelist':
                return os.path.join(self.tmpdir, 'etc', 'apt', 'sources.list')

# Generated at 2022-06-11 06:39:56.182103
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():

    class MockModule(object):
        def __init__(self):
            self.params = {'codename': 'xenial'}

        def fail_json(self, message):
            raise Exception(message)

        def atomic_move(self, tmp_path, filename):
            pass

        def set_mode_if_different(self, filename, this_mode, recursive):
            pass

    # Test with ppa:
    sources_list = UbuntuSourcesList(MockModule())
    source_line = "deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main"
    sources_list.add_source('ppa:ansible/ansible')
    result = sources_list.dump()

# Generated at 2022-06-11 06:40:07.533196
# Unit test for constructor of class SourcesList
def test_SourcesList():
    tmp_dirname = tempfile.mkdtemp(prefix="apt-repository-")
    tmp_filename = os.path.join(tmp_dirname, 'sources.list')
    tmp_file_fd, tmp_file_pathname = tempfile.mkstemp(prefix='source-', dir=tmp_dirname)
    tmp_file = os.fdopen(tmp_file_fd, 'w')


# Generated at 2022-06-11 06:40:20.099818
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    s = UbuntuSourcesList(None)
    for i in range(0, 10):
        s.add_source('deb http://SOMESOURCE')
        s.add_source('deb https://SOMESOURCE')
        s.add_source('deb [arch=amd64] http://SOMESOURCE')
        s.add_source('deb [arch=amd64] https://SOMESOURCE')
        s.add_source('deb [arch=amd64, i386] http://SOMESOURCE')
        s.add_source('deb [arch=amd64, i386] https://SOMESOURCE')
        s.add_source('deb [arch=amd64, i386] http://SOMESOURCE main')
        s.add_source('deb [arch=amd64, i386] https://SOMESOURCE main')


# Generated at 2022-06-11 06:40:32.088850
# Unit test for function install_python_apt
def test_install_python_apt():
    import apt_repository

    module = AnsibleModule(argument_spec={})
    m_module = copy.copy(module)

    class RunCommandMock(object):
        def __init__(self, rc, so, se):
            self.rc = rc
            self.so = so
            self.se = se


# Generated at 2022-06-11 06:40:42.182752
# Unit test for function revert_sources_list
def test_revert_sources_list():
    class mock_module(object):
        def __init__(self):
            self.check_mode = False
            self.exception = None
            self.params = {
                'codename': 'xenial'
            }
            self.exit_args = None
            self.exit_kwargs = None

        def fail_json(self, msg=None, **kwargs):
            self.exit_args = msg
            self.exit_kwargs = kwargs

    # Setup
    m = mock_module()
    sources_before = {'/etc/apt/sources.list': 'deb [arch=amd64] http://packages.dotdeb.org jessie all\n'}

# Generated at 2022-06-11 06:40:49.427789
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = object()
    sources = SourcesList(module)
    sources.files = {'a.list': [
        (0, True, False, '# deb foo'),
        (1, True, True, 'deb foo'),
        (2, True, False, '# deb foo'),
        (3, True, True, 'deb foo'),
        (4, True, False, '# deb foo'),
    ]}
    sources.remove_source('# deb foo')
    assert sources.dump() == {'a.list': '# deb foo\n# deb foo\n# deb foo\n'}
    sources.remove_source('deb foo')
    assert sources.dump() == {}



# Generated at 2022-06-11 06:40:54.416913
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():

    import doctest
    import ansible.module_utils.apt_repository
    results = doctest.testmod(ansible.module_utils.apt_repository)
    if results.failed == 0:
        return True
    else:
        raise Exception("Failed doctest for SourcesList.modify: %s" % results.failed)


# Generated at 2022-06-11 06:41:05.437516
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    test_file = '/opt/ansible_test/sources.list'
    test_file_content = ''' deb [arch=amd64] http://apt.example.com/debian trusty main non-free
# deb [arch=i386] http://apt.example.com/debian trusty main non-free
# deb-src http://apt.example.com/debian trusty main
deb [arch=amd64] http://apt.example.com/debian trusty-updates main
# deb-src http://apt.example.com/debian trusty-updates main
deb [arch=amd64] http://apt.example.com/debian trusty-backports main
# deb-src http://apt.example.com/debian trusty-backports main
'''

# Generated at 2022-06-11 06:42:05.521722
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    assert Globals.SourcesList(None).dump() == {}




# Generated at 2022-06-11 06:42:11.381077
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'check_mode': True, 'install_python_apt':True}, check_invalid_arguments=False)
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')
    install_python_apt(module, 'not-a-real-package-name')



# Generated at 2022-06-11 06:42:20.663280
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule({})

    sourceslist_before = UbuntuSourcesList(module)
    sourceslist_before.load(os.path.join(os.path.dirname(__file__), 'test_apt_sources_list_before.txt'))

    sourceslist_after = UbuntuSourcesList(module)
    sourceslist_after.load(os.path.join(os.path.dirname(__file__), 'test_apt_sources_list_after.txt'))

    sources_before = sourceslist_before.dump()
    sources_after = sourceslist_after.dump()

    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.dump() == sources_before



# Generated at 2022-06-11 06:42:31.654649
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    pass

    module = AnsibleModule(argument_spec=dict())
    def_file = module.get_bin_path("sources.list")
    os.remove(def_file)
    s = SourcesList(module)
    f = os.open(def_file,os.O_RDWR|os.O_CREAT)
    os.write(f,'deb http://archive.ubuntu.com/ubuntu trusty main multiverse restricted universe\n'.encode('utf-8'))
    os.close(f)
    s.remove_source("deb http://archive.ubuntu.com/ubuntu trusty main multiverse restricted universe")
    assert len(s.files[def_file]) == 0
    print("unit test passed!")

test_SourcesList_remove_source()



# Generated at 2022-06-11 06:42:36.207072
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    try:
        install_python_apt(module, 'python-apt')
    except Exception:
        print ('Failed to install python-apt')

# main()

# Generated at 2022-06-11 06:42:47.347001
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec=dict())
    module.params = {
        'filename': None,
        'mode': None,
    }
    module.check_mode = False

    def _run_command(command):
        pass

    def _add_ppa_signing_keys(command):
        pass

    sources_list = UbuntuSourcesList(module, _add_ppa_signing_keys)

    # Case 1: invalid repository
    try:
        sources_list.add_source('invalid_repo')
        assert False
    except SystemExit:
        pass

    # Case 2: add ppa
    sources_list.add_source('ppa:webupd8team/atom')
    assert sources_list.files

    # Case 3: add existing repository

# Generated at 2022-06-11 06:42:58.927785
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''Unit test for method __iter__ of class SourcesList
    '''
    _module = AnsibleModule({})
    _module.exit_json = lambda x: x
    _sources_list = SourcesList(_module, '')

# Generated at 2022-06-11 06:43:08.027115
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    fail_lines = []
    failed = False

    # We have a known working sources file, so we'll use it to test against
    sl = SourcesList({'_ansible_check_mode': True})
    sl.load("test-sources.list")

    # We don't care about comments, so let's filter that out
    test_sl = open("test-sources.list", "r").read()
    test_sl = re.sub("#.*\n", "\n", test_sl)
    test_sl = test_sl.split("\n")

    test_iter_sl = []

    for line in sl:
        test_iter_sl.append(line[3])

    for line in test_sl:
        if line not in test_iter_sl:
            failed = True

# Generated at 2022-06-11 06:43:13.988774
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Initialize test environment
    module = AnsibleModule(argument_spec=dict(
        filename=dict(default=None, type='str'),
        codename=dict(default=None, type='str'),
    ))

    # Setup test data
    obj = UbuntuSourcesList(module)

    # Execute tested code
    result = obj.__deepcopy__()

    # Verify results
    assert isinstance(result, UbuntuSourcesList)
    assert result.module == module



# Generated at 2022-06-11 06:43:23.681470
# Unit test for function install_python_apt
def test_install_python_apt():
    try:
        import apt
        import apt_pkg
    except ImportError:
        pass
    else:
        # Not needed, should skip
        return

    class MockedAptModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.ran_command = []

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def run_command(self, command):
            self.ran_command.append(command)
            return (0, '', '')

        def get_bin_path(self, binary):
            self.ran_command.append(binary)
            if binary == 'apt-get':
                return 'apt-get'

    # Fake this for test purposes
    class MockException(Exception):
        pass



# Generated at 2022-06-11 06:44:37.878077
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """test remove_source"""
    module = AnsibleModule({})
    my_sources_list = SourcesList(module)

# Generated at 2022-06-11 06:44:45.351157
# Unit test for function install_python_apt
def test_install_python_apt():
    assert not HAVE_PYTHON_APT
    apt_pkg_name = 'python-apt' if sys.version_info.major == 2 else 'python3-apt'
    module = AnsibleModule(argument_spec={
        'install_python_apt': {'type': 'bool', 'default': True},
    })
    with pytest.raises(AnsibleError):
        install_python_apt(module, apt_pkg_name)


# ===========================================
# SourceFile manipulation
#

# Generated at 2022-06-11 06:44:46.026737
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-11 06:44:51.963898
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class MockModule(object):
        def run_command(self, command, check_rc=True):
            pass

    mock_module = MockModule()
    result = get_add_ppa_signing_key_callback(mock_module)
    assert result is not None
    result = get_add_ppa_signing_key_callback(mock_module)
    assert result is None



# Generated at 2022-06-11 06:44:57.752367
# Unit test for function install_python_apt
def test_install_python_apt():
    mod = AnsibleModule({})
    if PY3:
        mod.run_command = run_command_py3
    else:
        mod.run_command = run_command_py2
    mod.fail_json = fail_json
    mod.get_bin_path = get_bin_path
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        install_python_apt(mod, 'python3-apt')
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.args[0] == 0


# Generated at 2022-06-11 06:45:07.901659
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    distro_name_mock = 'Ubuntu'
    version_mock = '18.04'
    codename_mock = 'bionic'
    system_mock = 'linux'
    machine_mock = 'x86_64'

    # Mock the distro module to get specific distribution info
    with patch.object(distro, 'name', return_value=distro_name_mock), \
         patch.object(distro, 'version', return_value=version_mock), \
         patch.object(distro, 'codename', return_value=codename_mock), \
         patch.object(distro, 'system', return_value=system_mock), \
         patch.object(distro, 'machine', return_value=machine_mock):
        # Mock the ansible module
        module

# Generated at 2022-06-11 06:45:17.272432
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import module_utils.basic
    mock_module = module_utils.basic.AnsibleModule(arg_spec={})
    sl = UbuntuSourcesList(mock_module)
    for line in [
        'deb http://key.com/ sa',
        'deb https://key.com/ sa',
        'deb ftp://key.com/ sa',
        'deb [opt] http://key.com/ sa',
        '# deb http://commented.com/ sa',
        'deb http://key.com/ [opt1] [opt2] sa',
    ]:
        sl.add_source(line)

    for filename, n, enabled, source, comment in sl:
        assert enabled
        assert not source.startswith('#')

    assert len(sl.files) == 1



# Generated at 2022-06-11 06:45:27.144446
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={
        'repo': {'type': 'str', 'required': True},
        'comment': {'type': 'str'},
        'filename': {'type': 'str'},
    },
        supports_check_mode=True
    )

    def _apt_cfg(key):
        return {
            'Dir::Etc': '/dev/null',
            'Dir::Etc::sourceparts': '/dev/null',
            'Dir::Etc::sourcelist': '/dev/null',
        }[key]

    def _apt_cfg_file(filespec):
        return {
            'Dir::Etc::sourcelist': '/dev/null',
        }[filespec]


# Generated at 2022-06-11 06:45:34.277790
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    default_source='deb http://archive.ubuntu.com/ubuntu xenial main restricted universe multiverse'
    ppa_source='deb http://ppa.launchpad.net/patrick-dessalle/ppa/ubuntu xenial main'
    comment_source='deb http://archive.ubuntu.com/ubuntu xenial main # comment'
    module = None
    s = UbuntuSourcesList(module)

    s.files['sources.list']= [(1, True, True, default_source, ''),
                              (2, True, True, ppa_source, ''),
                              (3, True, True, comment_source, '')]
    s.remove_source(default_source)
    assert len(s.files['sources.list'])==2

# Generated at 2022-06-11 06:45:42.246055
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from unittest import mock, TestCase
    from ansible.module_utils.basic import AnsibleModule

    # this is just a placeholder
    class AnsibleModuleFake(object):
        def __init__(self, **kwargs):
            self.params = kwargs


# Generated at 2022-06-11 06:48:32.418368
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    from ansible.module_utils.apt.sourceslist import SourcesList

    sources = SourcesList(None)
    sources.add_source('deb http://archive.canonical.com/ubuntu trusty partner')
    sources.add_source('deb-src http://archive.ubuntu.com/ubuntu trusty partner')
    sources.add_source('deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main')

    dump = sources.dump()
    assert dump == {'/etc/apt/sources.list': 'deb http://archive.canonical.com/ubuntu trusty partner\n'}



# Generated at 2022-06-11 06:48:37.947316
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    temp_dir = tempfile.TemporaryDirectory()

# Generated at 2022-06-11 06:48:41.951547
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(
        argument_spec = dict(
            state = dict(default='present', choices=['absent', 'present']),
        )
    )
    source_list = SourcesList(module)
    source_list.add_source("# deb [arch=amd64] https://download.virtualbox.org/virtualbox/debian bionic contrib non-free")
    source_list.remove_source("# deb [arch=amd64] https://download.virtualbox.org/virtualbox/debian bionic contrib non-free")
    assert len(source_list.dump()) == 0

# test SourceList's dump function

# Generated at 2022-06-11 06:48:48.428558
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    Test for `SourcesList.add_source`
    '''
    # Create a dummy module
    module = AnsibleModule({}, check_invalid_arguments=False)
    # Create a dummy sources list
    apt_sources = SourcesList(module)

    # Add some source and then compare results with expected
    apt_sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    apt_sources.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main')

    # Push this sources list into a temp file
    temp_file = tempfile.NamedTemporaryFile()
    apt_sources.save_to_file(temp_file.name)

    # Read back original sources list from the temp file and compare it with expected
    original_s