

# Generated at 2022-06-11 06:39:28.144410
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    sources_list = SourcesList(module)
    sources_list.add_source("deb https://apt.postgresql.org/pub/repos/apt/ stretch-pgdg main")
    assert any("deb https://apt.postgresql.org/pub/repos/apt/ stretch-pgdg main" == s[3] for s in sources_list.files[sources_list.default_file])



# Generated at 2022-06-11 06:39:39.886079
# Unit test for function main
def test_main():
    def spawn_process(args):
        return None

    def call_command(args, check_rc=True):
        return (0, 'stdout', 'stderr')

    def command_error(args, check_rc, rc=None, out=None, err=None, msg=None):
        return (rc, out, err)

    def remove_file(path):
        return False

    def load_file(filename):
        return ''

    def write_file(filename, contents, mode=None):
        return True

    def probe_interpreters_for_module(interpreters, module_name):
        return None

    class SourcesList(object):

        def __init__(self, module):
            self.module = module


# Generated at 2022-06-11 06:39:52.376215
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fd, tmp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('# deb cdrom:[Debian GNU/Linux 8.0.0 _Jessie_ - Official amd64 DVD Binary-1 20150930-12:16]/ jessie contrib main\n')
    f.write('deb-src http://archive.canonical.com/ubuntu bionic partner\n')
    f.write('# commented deb http://foo.com ubuntu main\n')
    f.write('deb http://bar.com ubuntu main\n')
    f.write('deb https://baz.com ubuntu main\n')

# Generated at 2022-06-11 06:40:00.632258
# Unit test for function install_python_apt
def test_install_python_apt():
    '''Unit test for function install_python_apt.'''
    # check if install_python_apt fails in check mode
    module = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': True}})
    try:
        del sys.modules['apt']
        del sys.modules['apt_pkg']
        del sys.modules['aptsources.distro']
    except KeyError:
        pass
    module.get_bin_path = lambda x: '/usr/bin/apt-get'
    module.run_command = lambda x: (0, '', '')
    install_python_apt(module, 'python-apt')
    module.fail_json = lambda x: sys.exit(1)
    with pytest.raises(SystemExit) as excinfo:
        install_

# Generated at 2022-06-11 06:40:02.226311
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    assert False, "No test for method remove_source"


# Generated at 2022-06-11 06:40:05.128483
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    SourcesList(module)



# Generated at 2022-06-11 06:40:17.995291
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import unittest
    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = Mock(side_effect=AnsibleExitJson)
            self.fail_json = Mock(side_effect=AnsibleFailJson)
            self.run_command = Mock(return_value=(0, '', ''))
            self.set_mode_if_different = Mock()
            self.atomic_move = Mock()
            self.check_mode = False
    #
    # begin test case
    #

# Generated at 2022-06-11 06:40:18.682605
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-11 06:40:19.929513
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    raise NotImplementedError()

# Generated at 2022-06-11 06:40:31.900868
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec=dict(repo=dict(type='str'), state=dict(type='str', default='present', choices=['absent', 'present']), mode=dict(type='raw'), update_cache=dict(type='bool', default='yes', aliases=['update-cache']), filename=dict(type='str'), install_python_apt=dict(type='bool', default='yes')))
    sourceslist = UbuntuSourcesList(module, add_ppa_signing_keys_callback=get_add_ppa_signing_key_callback(module))
    sourceslist_before = copy.deepcopy(sourceslist)
    sources_before = sourceslist.dump()

    sourceslist.add_source("ppa:ansible/ansible")

    sources_after = sourceslist.dump()
    diff = []

# Generated at 2022-06-11 06:41:07.259895
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import os

    test_file = os.path.join(os.path.dirname(__file__), 'test_data/apt_repo.json')
    test_data = json.load(open(test_file))
    test_values = test_data['inputs']

    # mock sys.argv
    sys.argv = test_values
    module = AnsibleModule(argument_spec={})

    main(module)


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:09.531994
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    m = MagicMock()
    cmd_callback = get_add_ppa_signing_key_callback(m)

    # Check in noop mode
    m.check_mode = False
    m.run_command.return_value = 0, '', ''
    assert cmd_callback is not None

    # Check in check mode
    m.check_mode = True
    assert cmd_callback is None



# Generated at 2022-06-11 06:41:16.567545
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    """
    This method tests whether the SourcesList.modify() function
    modifies an entry in the sources.list files in a given directory

    Modifies the file entry of self.files at position n

    """
    for line in ["deb http://archive.ubuntu.com/ubuntu precise main universe", "deb-src http://archive.ubuntu.com/ubuntu precise main universe"]:
        sources_list = SourcesList(AnsibleModule({}))

        # Check if the sources_list is empty
        if sources_list.files:
            sources_list.remove_source(line)

        sources_list.add_source(line, comment='This is a random comment')
        for filename, sources in sources_list.files.items():
            if sources:
                n = len(sources) - 1

# Generated at 2022-06-11 06:41:18.681802
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Test case 1
    test_SourcesList = SourcesList()
    try:
        test_SourcesList.remove_source(None)
    except TypeError:
        pass
    except Exception as e:
        assert False, "unexpected exception found: " + str(e)



# Generated at 2022-06-11 06:41:31.390456
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    u = UbuntuSourcesList(module=None)
    file = 'test.txt'
    u.files[file] = [(0, True, True, "deb http://ppa.launchpad.net/baculadb/ppa/ubuntu wily main", ""),
   (1, True, True, "deb http://ppa.launchpad.net/baculadb/bacula/ubuntu wily main", ""),
   (2, True, True, "deb http://ppa.launchpad.net/baculadb/bacula/ubuntu trusty main", ""),
   (3, True, True, "deb http://ppa.launchpad.net/baculadb/bacula/ubuntu wily main", "")]

# Generated at 2022-06-11 06:41:39.648844
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class FakeModule():
        def fail_json(self, msg):
            raise AssertionError(msg)
        @staticmethod
        def atomic_move(path1, path2):
            print("atomic_move(%s, %s)" % (path1, path2))
            with open(path2, 'w') as f:
                f.write(open(path1).read())
            os.remove(path1)
    m = FakeModule()
    d = SourcesList(m)

# Generated at 2022-06-11 06:41:50.389362
# Unit test for function install_python_apt
def test_install_python_apt():

    class DummyModule:

        def __init__(self):
            self.fail_json_called = False
            self.fail_json_msg = None
            self.run_command_called = []
            self.run_command_rc = [ 0, 0 ]
            self.run_command_output = [ "", "" ]

        def get_bin_path(self, arg):
            return '/usr/bin/apt-get'

        def fail_json(self, msg):
            self.fail_json_called = True
            self.fail_json_msg = msg

        def run_command(self, arg):
            self.run_command_called.append(arg)
            rc = self.run_command_rc.pop(0)
            output = self.run_command_output.pop(0)

# Generated at 2022-06-11 06:42:00.670413
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Test default values
    src = SourcesList(None)

# Generated at 2022-06-11 06:42:12.806135
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    """
    This test aims to ensure that __deepcopy__
    Generates a deep copy of a new object of the same type and with the same attributes
    :return:
    """
    module = AnsibleModuleMock()
    ubuntu_source_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback="foo")
    ubuntu_source_list.add_source(line="foo", comment='', file=None)
    copy_ubuntu_source_list = copy.deepcopy(ubuntu_source_list)
    assert ubuntu_source_list is not copy_ubuntu_source_list
    assert type(ubuntu_source_list) is type(copy_ubuntu_source_list)
    assert ubuntu_source_list.files == copy_ubuntu_source_list.files
    assert ubuntu_source_list.module == copy

# Generated at 2022-06-11 06:42:19.842281
# Unit test for function main

# Generated at 2022-06-11 06:43:23.639233
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = MagicMock()
    module.params = {}
    ubuntuSourcesList = UbuntuSourcesList(module)
    ubuntuSourcesList.files = {
        'test.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', ''),
            (1, True, True, 'deb http://ppa.launchpad.net/ansible/foo/ubuntu bionic main', ''),
            (2, True, True, 'deb http://ppa.launchpad.net/ansible/bar/ubuntu bionic main', '')
        ]
    }
    if ubuntuSourcesList.repos_urls:
        ubuntuSourcesList.remove_source('ppa:ansible/foo')

# Generated at 2022-06-11 06:43:24.225633
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-11 06:43:25.194713
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert True



# Generated at 2022-06-11 06:43:26.946715
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    return True


# Generated at 2022-06-11 06:43:36.796041
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sl = SourcesList()
    sl.add_source('deb http://repo.example.org/ubuntu bionic main')
    sl.add_source('deb-src http://repo.example.org/ubuntu bionic main')
    sl.add_source('deb http://repo.example.org/ubuntu bionic main restricted')
    sl.add_source('deb-src http://repo.example.org/ubuntu bionic main restricted')
    assert len(sl.files) == 1

# Generated at 2022-06-11 06:43:38.199427
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    object = SourcesList('module')
    object.load('file')


# Generated at 2022-06-11 06:43:48.363703
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class TestModule(object):
        def __init__(self, param_path):
            self.params = {'mode': 0o644}
            self.path = param_path

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'apt-get':
                return '/usr/bin/apt-get'

        def fail_json(self, msg):
            print("ERROR: %s" % msg)

        def run_command(self, argv):
            if argv[0] == '/usr/bin/apt-get' and argv[-1] == '-q':
                print("simulate apt-get install")
                return (0, '', '')
            return (1, '', '')


# Generated at 2022-06-11 06:43:56.967051
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import tempfile
    file = tempfile.NamedTemporaryFile(mode='w+', delete=False)
    sources_list = SourcesList(AnsibleModule(argument_spec={}))

    sources_list.files[file.name] = [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'comment')]
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner # comment')
    sources_list.add_source('deb http://test.test/test  # test')
    sources_list.add_source('deb-src http://test.test/test  # test')
    sources_list.add_source('deb http://test.test/test # test', file='test.list')

# Generated at 2022-06-11 06:44:07.481863
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils._text import to_text
    from ansible.modules.packaging.os import apt_key
    from ansible.compat.tests.mock import patch, MagicMock
    module = MagicMock(name='module', check_mode=False)
    callback = get_add_ppa_signing_key_callback(module)
    callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'ABCD1234'])
    assert module.run_command.call_count == 1

# Generated at 2022-06-11 06:44:17.357313
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import tempfile
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    tmp = tempfile.NamedTemporaryFile()
    tmp.write('# deb cdrom:[Ubuntu-Server 14.04.2 LTS _Trusty Tahr_ - Release amd64 (20150218.1)]/ trusty main restricted\n')
    tmp.write('deb http://mirrors.aliyun.com/ubuntu/ trusty main restricted universe multiverse\n')
    tmp.write('deb http://mirrors.aliyun.com/ubuntu/ trusty-security main restricted universe multiverse\n')

# Generated at 2022-06-11 06:45:48.109874
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Used to compare expected to actual
    class SlModule(object):
        def __init__(self):
            self.params = dict(
                codename='tuscany',
            )

    # Create a list of valid sources to add to UbuntuSourcesList
    sources = [
        u'deb http://ppa.launchpad.net/ubuntu-cloud-archive/tuscany-proposed/ubuntu tuscany main',
        u'deb-src http://ppa.launchpad.net/ubuntu-cloud-archive/tuscany-proposed/ubuntu tuscany main',
        u'deb-src http://example.com/repo stable main',
        u'deb http://example.com/repo stable main',
    ]

    # Create an instance of UbuntuSourcesList
    usl = UbuntuSourcesList(SlModule())

    # Add all the sources

# Generated at 2022-06-11 06:45:51.179674
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sl = SourcesList()

    # Print out for debugging purposes
    for filename, n, enabled, source, comment in sl:
        print(filename, n, enabled, source, comment)

# SourcesList test, executed at runtime

# Generated at 2022-06-11 06:46:00.241504
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule({})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    assert sl.repos_urls[0] == 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main'

    sl.add_source('ppa:foo/baz')
    assert sl.repos_urls[1] == 'deb http://ppa.launchpad.net/foo/baz/ubuntu xenial main'

    sl.add_source('http://repo.example.org/ubuntu xenial main', file='example.org_xenial.list')
    assert sl.repos_urls[2] == 'deb http://repo.example.org/ubuntu xenial main'


# Generated at 2022-06-11 06:46:09.246708
# Unit test for function main
def test_main():
    params = {
        'repo': 'ppa:ansible/ansible',
        'state': 'present',
        'mode': '0644',
        'update_cache': True,
        'update_cache_retries': 10,
        'update_cache_retry_max_delay': 12,
        'filename': '/etc/apt/sources.list.d/ansible.list',
        'install_python_apt': True,
        'validate_certs': True,
        'codename': 'bionic',
    }

    class DummyModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, command, check_rc=True):
            raise NotImplemented

# Generated at 2022-06-11 06:46:13.831934
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    a = UbuntuSourcesList(None)
    a.load('tests/unit/modules/test_apt/test_ubuntu_sources')
    a.remove_source('ppa:ohpc/stable')
    assert a.repos_urls == ['deb http://downloads-distro.mongodb.org/repo/ubuntu-upstart dist 10gen']


# Generated at 2022-06-11 06:46:23.394718
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec=dict(state=dict(default='present', choices=['absent', 'present', 'comment'])))
    sl = SourcesList(module)
    sl._add_valid_source('source1', 'comment1', None)
    sl._add_valid_source('source1', 'comment1', None)
    sl._add_valid_source('source2', 'comment2', None)
    sl.modify(sl.default_file, 0, enabled=False)
    sl.modify(sl.default_file, 1, enabled=False)
    sl.modify(sl.default_file, 2, enabled=True)
    sl.modify(sl.default_file, 2, comment='comment3')
    sl.save()

# Generated at 2022-06-11 06:46:32.776141
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class M:
        params = {}

        def fail_json(self, msg):
            print(msg)

    m = M()
    sl = SourcesList(m)
    sl.load('test_apt_repository.txt')

# Generated at 2022-06-11 06:46:39.075486
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sl = SourcesList()
    assert(sl.files == {})
    assert(sl.default_file == '/etc/apt/sources.list')
    assert(os.path.exists(sl.default_file))
    sl.load(sl.default_file)
    for file, sources in sl.files.items():
        for n, valid, enabled, source, comment in sources:
            assert(file == sl.default_file)
            assert(sl.parse(line)[1] == enabled)
            assert(sl.parse(line)[2] == source)
            assert(sl.parse(line)[3] == comment)



# Generated at 2022-06-11 06:46:43.609057
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_string = 'deb http://archive.canonical.com/ubuntu hardy partner\n'
    sl = SourcesList(None)
    sl.load('/var/tmp/test_deb.list')
    sl._remove_valid_source(test_string[4:])
    assert not sl.files['/var/tmp/test_deb.list']

# Unit tests for class SourcesList

# Generated at 2022-06-11 06:46:48.632376
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    global apt
    apt = None

    assert install_python_apt(module, 'python-apt')
    import apt
    assert apt is not None

    global apt_pkg
    apt_pkg = None

    assert install_python_apt(module, 'python3-apt')
    import apt_pkg
    assert apt_pkg is not None

