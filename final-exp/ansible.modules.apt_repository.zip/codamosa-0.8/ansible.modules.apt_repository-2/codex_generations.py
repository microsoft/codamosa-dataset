

# Generated at 2022-06-11 06:39:28.780164
# Unit test for function install_python_apt
def test_install_python_apt():
    pass


# Generated at 2022-06-11 06:39:29.925706
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
        pass

# Generated at 2022-06-11 06:39:30.538942
# Unit test for function install_python_apt
def test_install_python_apt():
    return True


# Generated at 2022-06-11 06:39:41.629118
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    """
    Unit test for method modify of class SourcesList
    :return: Nothing
    """

# Generated at 2022-06-11 06:39:48.174921
# Unit test for function main
def test_main():
    assert HAVE_PYTHON_APT is True, "Incorrect value for HAVE_PYTHON_APT"
    assert PY3 is True, "Incorrect value for PY3"
    assert distro is not None, "Incorrect value for distro"


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:39:58.303106
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params=kwargs.get('params')

        # noinspection PyUnusedLocal
        def atomic_move(self, src, dst):
            pass

        # noinspection PyUnusedLocal
        def set_mode_if_different(self, path, mode, changed):
            pass

    class FakeFailJson(object):
        def __init__(self):
            self.error = ''
            self.errors = []

        def __call__(self, msg):
            self.errors.append(msg)

        def __str__(self):
            self.error = '\n'.join(self.errors)
            return self.error

    # Since this is test, we don't care of default directory,
    # but

# Generated at 2022-06-11 06:40:05.802862
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    if apt_pkg:
        apt_pkg.config.clear()
        apt_pkg.init_config()
        apt_pkg.init_system()

    sources_list = UbuntuSourcesList(module)
    for filename in sources_list.files:
        module.debug("file: %s" % filename)
        for source in sources_list.files[filename]:
            module.debug("source: %s" % source)



# Generated at 2022-06-11 06:40:15.260560
# Unit test for function install_python_apt
def test_install_python_apt():
    # Mocked module
    module = AnsibleModule(argument_spec=dict())
    module.get_bin_path = lambda x: '/usr/bin/apt'

    # Mock module.run_command
    def run_command_mock(command, args):
        assert command == ['/usr/bin/apt', 'update']
        return 0, 'stdout', 'stderr'
    module.run_command = lambda x, y: run_command_mock(x, y)

    # Test run
    install_python_apt(module, 'python-apt')



# Generated at 2022-06-11 06:40:23.080074
# Unit test for function revert_sources_list
def test_revert_sources_list():
    mock_module = MagicMock()
    mock_sources_before = {}
    mock_sources_after = {'a': '123', 'b': '456'}
    mock_sourceslist_before = MagicMock()
    # first remove any new files that were created:
    for filename in set(mock_sources_after.keys()).difference(mock_sources_before.keys()):
        if os.path.exists(filename):
            os.remove(filename)
    # now revert the existing files to their former state:
    mock_sourceslist_before.save()



# Generated at 2022-06-11 06:40:28.181594
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class ModuleMock:
        def __init__(self):
            self.check_mode = False
            self.run_command = lambda x, y: None
            self.run_command = lambda command: None

    assert callable(get_add_ppa_signing_key_callback(ModuleMock()))



# Generated at 2022-06-11 06:41:22.232075
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import ansible.module_utils.basic
    import glob
    import os
    import shutil
    # Create temporary directory
    tmpdir = tempfile.mkdtemp(prefix="apt_repository")
    apt_pkg_dir = os.path.join(tmpdir, "apt")
    apt_pkg_etc_dir = os.path.join(apt_pkg_dir, "etc")
    apt_pkg_etc_source_dir = os.path.join(apt_pkg_etc_dir, "sources.list.d")
    apt_pkg_d_dir = os.path.join(apt_pkg_dir, "d")
    apt_pkg_d_etc_dir = os.path.join(apt_pkg_d_dir, "etc")
    apt_pkg_d_etc_source_dir = os.path

# Generated at 2022-06-11 06:41:34.482212
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class FakeModule(object):
        @staticmethod
        def run_command(*args, **kwargs):
            return 0, '', ''

        @staticmethod
        def fail_json(*args, **kwargs):
            return

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/bin'

    class FakeModule2(object):
        @staticmethod
        def run_command(*args, **kwargs):
            return 0, '', ''

        @staticmethod
        def fail_json(*args, **kwargs):
            return

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/bin'

        @staticmethod
        def atomic_move(src, dst):
            return


# Generated at 2022-06-11 06:41:41.468124
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import os
    import tempfile
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    from ansible.module_utils.basic import AnsibleModule

    content = {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu xenial main\n',
               '/etc/apt/sources.list.d/ansible-test.list': 'deb [ arch=amd64 ] https://download.docker.com/linux/ubuntu xenial stable\n'}

    if PY2:
        content = {k: to_bytes(v) for k, v in content.items()}

    m = AnsibleModule(argument_spec={})

    m.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-11 06:41:53.027951
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    test_data = [
        "deb http://deb.debian.org/debian/ buster main contrib non-free",
        "deb-src http://deb.debian.org/debian/ buster main contrib non-free",
        "#deb http://deb.debian.org/debian/ buster main contrib non-free",
        "# deb-src http://deb.debian.org/debian/ buster main contrib non-free"
    ]
    print("################## test_SourcesList_modify #################")
    print("Test data:")
    print("\n".join(test_data))
    sources_list = SourcesList("")
    sources_list._add_valid_source(test_data[0], "", "")
    sources_list._add_valid_source(test_data[1], "", "")
    sources

# Generated at 2022-06-11 06:42:01.725245
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    codename = "some"

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            raise AssertionError(msg)

        def set_mode_if_different(self, filename, this_mode, follow):
            pass

        def atomic_move(self, tmp_path, filename):
            pass

    class MockDistro(object):
        codename = codename

    module = MockModule({})
    add_ppa_signing_keys_callback = None

    apt_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    apt_sources_list.codename = codename

    assert apt_sources_list.__deepcopy__() == apt_sources_list

# Generated at 2022-06-11 06:42:02.926584
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    #FIXME: implement
    pass


# Generated at 2022-06-11 06:42:06.983882
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    command = ['apt-key', 'list']
    key_list = module.run_command(command, check_rc=True)
    assert len(key_list) == 2

    callback = get_add_ppa_signing_key_callback(module)
    callback(command)
    key_list = module.run_command(command, check_rc=True)
    assert len(key_list) == 2

    new_module = AnsibleModule(argument_spec={}, check_mode=True)
    new_callback = get_add_ppa_signing_key_callback(new_module)
    assert new_callback is None



# Generated at 2022-06-11 06:42:17.831813
# Unit test for function install_python_apt
def test_install_python_apt():
    module = type('module', (object,), {})
    module.check_mode = False
    module.fail_json = lambda **kwargs: sys.exit(1)
    module.run_command = lambda *args: (0, '', '')
    module.get_bin_path = lambda *args: '/usr/bin/apt-get'
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')
    module.get_bin_path = lambda *args: None
    module.fail_json = lambda **kwargs: None
    module.check_mode = True
    install_python_apt(module, 'python3-apt')
    sys.exit(0)



# Generated at 2022-06-11 06:42:28.822952
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # test with file
    m = DummyModule()
    s = SourcesList(m)
    s.add_source('deb http://test.com/ test main # test repo', file='test.list')
    assert s.files['/etc/apt/sources.list.d/test.list'][0][3] == 'deb http://test.com/ test main'
    # test with comment
    s.add_source('deb http://test2.com/ test2 main', comment='test comment')
    assert s.files['/etc/apt/sources.list.d/test2.list'][0][3] == 'deb http://test2.com/ test2 main'
    assert s.files['/etc/apt/sources.list.d/test2.list'][0][4] == 'test comment'



# Generated at 2022-06-11 06:42:30.799733
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    This should be a non-empty docstring!
    '''
    pass

# Generated at 2022-06-11 06:43:33.577404
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # pylint: disable=too-many-locals,consider-iterating-dictionary
    def get_test_data(data):
        for file, sources in data.items():
            for n, valid, enabled, source, comment in sources:
                yield file, n, enabled, source, comment

    output = '''
# deb cdrom:[Debian GNU/Linux 8.6.0 _Jessie_ - Official amd64 DVD Binary-1 20170217-13:03]/ jessie contrib main #disabled line
deb https://deb.debian.org/debian jessie contrib #comment
deb http://security.debian.org/ jessie/updates main contrib
deb http://security.debian.org/ jessie/updates main contrib #multiline
      #comment'''

    expected_result = get_test_

# Generated at 2022-06-11 06:43:43.413204
# Unit test for function main
def test_main():
    args = dict(
        repo=dict(type='str', required=True),
        state=dict(type='str', default='present', choices=['absent', 'present']),
        mode=dict(type='raw'),
        update_cache=dict(type='bool', default=True, aliases=['update-cache']),
        update_cache_retries=dict(type='int', default=5),
        update_cache_retry_max_delay=dict(type='int', default=12),
        filename=dict(type='str'),
        # This should not be needed, but exists as a failsafe
        install_python_apt=dict(type='bool', default=True),
        validate_certs=dict(type='bool', default=True),
        codename=dict(type='str'),
    )

    module = Ansible

# Generated at 2022-06-11 06:43:47.206987
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'state': 'present', 'update_cache': 'yes', 'repo': 'test'}, check_invalid_arguments=False)
    install_python_apt(module, 'test')
    assert 'test' in module.run_command


# Generated at 2022-06-11 06:43:56.376994
# Unit test for function main
def test_main():
    module = AnsibleModule({
        'repo': 'deb http://packages.dotdeb.org jessie all',
        'state': 'present',
        'mode': dict(type='raw'),
        'update_cache': True,
        'update_cache_retries': 5,
        'update_cache_retry_max_delay': 5,
        'filename': 'dotdeb.list',
        # This should not be needed, but exists as a failsafe
        'install_python_apt': True,
        'validate_certs': True,
        'codename': 'jessie'
    }, check_invalid_arguments=False)

    # Try setting an invalid apt module path to simulate missing dependencies
    # It will cause the module to fail.

# Generated at 2022-06-11 06:44:06.999315
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    d = tempfile.mkdtemp()

# Generated at 2022-06-11 06:44:11.501220
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Nested method that's used inside test_SourcesList_save
    def sources_list_save(sources, expected_output, comment=''):
        module = MagicMock()
        module.atomic_move = MagicMock()
        module.set_mode_if_different = MagicMock()
        s = SourcesList(module)
        s.files = {'file': sources}
        fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % 'file', dir='')
        os.close(fd)
        module.atomic_move.side_effect = lambda a, b: shutil.copyfile(a, b)
        s.save()
        with open('file') as f:
            assert f.read() == expected_output
        # no exception raised

# Generated at 2022-06-11 06:44:20.744189
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)
    assert s.dump() == {}
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)

# Generated at 2022-06-11 06:44:30.824671
# Unit test for function main
def test_main():
    test_arguments = dict(
        repo='puppetlabs-pc1',
        state='present',
        mode=dict(type='raw'),
        update_cache=dict(type='bool', default=True, aliases=['update-cache']),
        update_cache_retries=dict(type='int', default=5),
        update_cache_retry_max_delay=dict(type='int', default=12),
        filename=dict(type='str'),
        install_python_apt=dict(type='bool', default=True),
        validate_certs=dict(type='bool', default=True),
        codename=dict(type='str'),
    )

# Generated at 2022-06-11 06:44:42.726063
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    def load_file(filename):
        f = open(filename)
        lines = f.readlines()
        f.close()
        return lines

    # Test with default file /etc/apt/sources.list
    apt_sl = SourcesList(AnsibleModule(argument_spec=dict()))
    filename = apt_sl.default_file
    test_source = 'deb http://test.test/test/ test main'
    test_comment = 'Test comment'
    apt_sl.add_source(test_source, test_comment)
    apt_sl.save()
    assert load_file(filename) == (['%s #%s\n' % (test_source, test_comment)]), "Unable to write to file '%s'" % filename
    os.remove(filename)

    # Test with custom file
   

# Generated at 2022-06-11 06:44:53.560163
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import pytest

# Generated at 2022-06-11 06:45:56.092314
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['present', 'absent']),
        repo=dict(required=True),
        filename=dict(),
    ))

    sources_list = SourcesList(module)
    raw_dict = sources_list.dump()

    if raw_dict['/etc/apt/sources.list'] == '''\
### You might want to change deb-src to deb if the package does not exist for the source distributions.
deb http://deb.debian.org/debian/ testing main contrib non-free
#deb-src http://deb.debian.org/debian/ testing main contrib non-free
''':
        module.exit_json(msg='Class SourcesList works as expected')

# Generated at 2022-06-11 06:45:58.152176
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sl = SourcesList(module)
    assert sl.default_file
    assert sl.files



# Generated at 2022-06-11 06:46:07.116585
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class Module(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise RuntimeError(kwargs)

    test_params = [('filename', 'test.list'),
                   ('codename', 'bionic'),
                   ('name', 'test repo'),
                   ('description', 'test description'),
                   ('components', ['main']),
                   ('architectures', ['amd64']),
                   ('ppa', 'ppa:test/testppa')]
    expected = {'filename': 'test.list',
                'state': 'present',
                'update_cache': False}
    for p in test_params:
        expected[p[0]] = p[1]
        mod = Module()
        mod.params[p[0]] = p[1]
        sl

# Generated at 2022-06-11 06:46:16.678301
# Unit test for function main

# Generated at 2022-06-11 06:46:26.261187
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """
        Test the save method of class SourcesList
    """
    # Create a temporary file

    fd, tmp_path = tempfile.mkstemp(prefix=".testSourcesList-", dir=".")
    os.close(fd)
    # Create a SourcesList object
    module = AnsibleModule({})
    source_list = SourcesList(module)
    # Add file to SourcesList
    source_list.files[tmp_path] = ['test','test2','test3','test4','test5','test6','test7','test8','test9']
    # Test save method
    source_list.save()
    with open(tmp_path, 'r') as file:
        read_file = file.read()
    os.remove(tmp_path)

# Generated at 2022-06-11 06:46:28.052491
# Unit test for function main
def test_main():
    # for testing
    return main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:46:36.721382
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    import contextlib

    class FakeModule(object):
        def __init__(self):
            self.params = {'mode': '0755'}
            self.check_mode = False

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, src, dst):
            pass

        def set_mode_if_different(self, *args, **kwargs):
            pass

        @contextlib.contextmanager
        def tempfile(self, *args, **kwargs):
            yield None, None

        def run_command(self, *args, **kwargs):
            return 1, '', 'error'


# Generated at 2022-06-11 06:46:43.192939
# Unit test for function install_python_apt
def test_install_python_apt():
    # create a test module to call install_python_apt
    module = AnsibleModule({}, supports_check_mode=True)
    module.get_bin_path = lambda x: '/usr/bin/%s' % x
    # test apt-get fails
    module.run_command = lambda x: (1, '', '')
    # fail without check_mode
    try:
        install_python_apt(module, 'apt-pkg')
    except SystemExit:
        pass
    else:
        raise Exception("apt-get failed to install and module didn't exit")
    # fail with check_mode
    try:
        install_python_apt(module, 'apt-pkg')
    except SystemExit:
        pass
    else:
        raise Exception("apt-get failed to install and module didn't exit")
    # test apt-

# Generated at 2022-06-11 06:46:47.518124
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    """Unit test for method :func:`~ansible.module_utils.apt.SourcesList.__iter__` of class :class:`apt.SourcesList`

    This method is tested by all other (unit) tests in this module.
    """
    sources = SourcesList(object())
    assert not any(sources.__iter__())

# Generated at 2022-06-11 06:46:48.547453
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # @todo: implement test
    pass



# Generated at 2022-06-11 06:48:48.573539
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)
    assert not isinstance(s.files, list)
    assert isinstance(s.files, dict)
    assert isinstance(s.new_repos, set)
    assert not isinstance(s.new_repos, list)
    assert isinstance(s.default_file, str)
    assert len(s.default_file) > 0

