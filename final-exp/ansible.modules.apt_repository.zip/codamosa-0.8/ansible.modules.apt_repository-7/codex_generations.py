

# Generated at 2022-06-11 06:39:28.170096
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sl = SourcesList(module)

    # Adding into existing file
    file = '/tmp/foo.list'
    old = [
        (42, False, False, 'foo', 'comment'),
        (43, True, True, 'bar', 'comment'),
    ]
    sl.files[file] = old
    sl.modify(file, 0, enabled=True)
    sl.modify(file, 1, comment='foo')
    assert sl.files[file] == [
        (42, False, True, 'foo', 'comment'),
        (43, True, True, 'bar', 'foo'),
    ]

    # Adding into new file
    file = '/tmp/bar.list'
    assert file not in sl.files
    sl.modify(file, 0, enabled=True)

# Generated at 2022-06-11 06:39:35.900337
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.add_source('deb http://nginx.org/packages/mainline/debian/ jessie nginx')
    for filename, n, enabled, source, comment in sourceslist:
        assert filename == '/etc/apt/sources.list.d/nginx_org_packages_mainline_debian_.list'
        assert enabled
        assert source == 'deb http://nginx.org/packages/mainline/debian/ jessie nginx'
        assert comment == ''
        break


# Generated at 2022-06-11 06:39:38.305374
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList(None)
    assert os.path.isfile(sl.default_file)
    sl.load(sl.default_file)
    assert sl.default_file in sl.files
    assert len(sl.files[sl.default_file]) > 0



# Generated at 2022-06-11 06:39:46.660816
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    """
    Test class that "mocks" the AnsibleModule class.
    """
    class AnsibleModuleArguments(object):
        """
        Class that "mocks" the AnsibleModule class.
        """
        def __init__(self, params={}):
            self.params = params

    def __exec_module():
        """
        Exec the module.
        """
        params = dict(add_ppa_signing_keys_callback='bar')

        module = AnsibleModuleArguments(params=params)
        sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback='foo')

        sources_list_copy = copy.deepcopy(sources_list)

        assert sources_list_copy.module is None

# Generated at 2022-06-11 06:39:57.549269
# Unit test for constructor of class SourcesList
def test_SourcesList():
    tmp_dir = tempfile.mkdtemp()
    example_content = '''
# file 1
deb http://example.com/debian/ unstable main
deb-src http://example.com/debian/ stable main
deb http://example.com/debian/ stable main
     deb-src http://example.com/debian/  stable main
# deb http://example.com/debian/ stable main
deb http://example.com/debian/ stable main # not valid source spec
'''
    example_content = example_content.strip().split('\n')
    package_dir = tmp_dir + '/etc/apt/sources.list.d'
    os.makedirs(tmp_dir + '/etc/apt')
    with open(tmp_dir + '/etc/apt/sources.list', 'w') as sources_list:
        sources_list

# Generated at 2022-06-11 06:40:08.972855
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import StringIO

    # Create a fake module object we can use to mock the system
    class FakeModule:
        def __init__(self):
            self.params = {"mode": "?", "filename": "?"}
            self.fail_json = lambda msg: msg
            self.atomic_move = lambda a, b: "atomic_move_not_real"
            self.set_mode_if_different = lambda a, b, c: "set_mode_not_real"

    # Create a fake apt_pkg module we can use to mock the system
    class FakeAptPkg:
        class FakeConfig:
            def find_file(self, filespec):
                return filespec
            def find_dir(self, dirspec):
                return dirspec

        config = FakeConfig()

    module = FakeModule()
    my_apt_

# Generated at 2022-06-11 06:40:21.137592
# Unit test for method remove_source of class UbuntuSourcesList

# Generated at 2022-06-11 06:40:33.312855
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    class ExitJsonModule(AnsibleModule):
        def __init__(self):
            # Suppress the module logging by default.
            arguments = dict(suppress_logging=True)
            super(ExitJsonModule, self).__init__(argument_spec=dict(), supports_check_mode=True, **arguments)

        def exit_json(self, **kwargs):
            global TEST_RESULT
            TEST_RESULT = dict(changed=kwargs.get('changed', False), msg=kwargs.get('msg'))

    # Mock the UbuntuSourcesList.save() method to skip the actual file modification.
    def mock_save(self):
        pass

    module = ExitJsonModule()
    sourceslist

# Generated at 2022-06-11 06:40:43.399657
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict())
    sl = UbuntuSourcesList(module)
    sl.files = {
        '/etc/apt/sources.list.d/file.list': [
            (1, True, True, "deb http://ppa.launchpad.net/ppa/ubuntu xenial main", ""),
            (2, True, True, "deb http://ppa.launchpad.net/ppa/ubuntu bionic main", ""),
            (3, True, True, "deb http://ppa.launchpad.net/ppa/ubuntu bionic main", ""),
        ],
    }
    sl.remove_source("ppa:ppa")

# Generated at 2022-06-11 06:40:51.080252
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class File:
        def __init__(self):
            self.data = []
            self.f = None
            self.idx = 0

        def __iter__(self):
            return self

        def __next__(self):
            return self.next()

        def write(self, string):
            self.data.append(string)

        def next(self):
            if self.idx >= len(self.data):
                raise StopIteration
            out = self.data[self.idx]
            self.idx += 1
            return out

        def remove(self):
            pass

    class Module:
        def __init__(self):
            self.params = {}

        def fail_json(self, **kw):
            raise Exception


# Generated at 2022-06-11 06:41:30.976790
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    usl = UbuntuSourcesList(module=module)

    # testing file loading
    assert os.path.isfile(usl.default_file), 'file %s is not readable' % (usl.default_file)
    assert len(usl.files) >= 1, 'sources.list file should contain at least one valid repository'

    # testing iterator
    for file, n, enabled, source, comment in usl:
        assert len(source) > 0, 'source should not be empty string'

    # testing dump
    dumpstruct = usl.dump()
    assert isinstance(dumpstruct, dict), 'dump should be a dict'

    return True



# Generated at 2022-06-11 06:41:37.792251
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    module.exit_json({})

    sl = SourcesList(module)

    sl._add_valid_source('deb http://localhost/foo', 'Test')
    sl._add_valid_source('deb http://localhost/baz', 'Test')
    sl._add_valid_source('deb-src http://localhost/foo', 'Test')
    sl._add_valid_source('deb-src http://localhost/baz', 'Test')

    sl._remove_valid_source('deb-src http://localhost/baz')
    sl._remove_valid_source('deb http://localhost/baz')

    assert len(sl.files) == 2
    assert len(sl.files[sl.default_file]) == 2

    # Test modify

# Generated at 2022-06-11 06:41:43.144970
# Unit test for function main
def test_main():
    pass

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.six.moves import shlex_quote
from ansible.module_utils._text import to_bytes, to_native
from ansible.module_utils.six import ensure_str, ensure_text

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 06:41:54.546607
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)

    def test_cases():

        def throw(msg):
            raise AssertionError(msg)

        def assert_no_source(source):
            for file, sources in sl.files.items():
                for n, valid, enabled, src, comment in sources:
                    if src == source:
                        throw("Source '%s' exists in file %s" % (source, file))

        sl.add_source('deb http://example.com/myrepo/ stable unstable')
        sl.add_source('# deb http://example.com/disabledrepo/ stable unstable')
        sl.add_source('  deb http://user:pass@example.com/authrepo/ stable unstable # Comment')
        sl.add

# Generated at 2022-06-11 06:42:02.468168
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class TestModule(object):
        def __init__(self, sources):
            self.files = sources

        def fail_json(self, msg):
            raise AssertionError(msg)

    module = TestModule({
        '/tmp/sources.list': [
            (0, True, True, 'deb http://test apt test', 'This is comment'),
            (1, False, False, '# deb http://test apt test', 'This is comment'),
            (2, False, True, '# deb http://test apt test', 'This is comment'),
            (3, False, True, 'deb http://test apt test', 'This is comment'),
            (4, True, False, 'deb http://test apt test', 'This is comment')
        ]
    })
    sources = SourcesList(module)

# Generated at 2022-06-11 06:42:10.906521
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    """ Test __deepcopy__ method of class UbuntuSourcesList. """
    module = AnsibleModule(argument_spec={})
    # initial value
    x = UbuntuSourcesList(module)
    x.codename = 'test_value'
    # call the method
    y = x.__deepcopy__()
    assert isinstance(y, UbuntuSourcesList)
    # check result
    assert x is not y
    assert y.codename == x.codename
    assert y.module == x.module
    assert y.add_ppa_signing_keys_callback is None



# Generated at 2022-06-11 06:42:20.664306
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({}, check_invalid_arguments=False)
    sources = SourcesList(module)

    sources._add_valid_source('deb http://archive.canonical.com/ubuntu hardy partner', 'canonical')

    sources.save()

    sources2 = SourcesList(module)
    sources2.load('%s/%s.list' % (sources._apt_cfg_dir('Dir::Etc::sourceparts'), 'archive_canonical_com_ubuntu_hardy_partner'))

    source, comment = sources2.files['%s/%s.list' % (sources._apt_cfg_dir(
        'Dir::Etc::sourceparts'), 'archive_canonical_com_ubuntu_hardy_partner')][0][3:]


# Generated at 2022-06-11 06:42:32.174871
# Unit test for method add_source of class UbuntuSourcesList

# Generated at 2022-06-11 06:42:43.740744
# Unit test for function install_python_apt
def test_install_python_apt():
    # test apt-get install python3-apt
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    if PY3:
        module.run_command.return_value = [0, '', '']
        install_python_apt(module, 'python3-apt')
        assert module.run_command.call_count == 2
        assert module.run_command.call_args[0][0] == [module.get_bin_path('apt-get'), 'install', 'python3-apt', '-y', '-q']
        module.run_command.return_value = [1, '', 'Unexpected error']
        with pytest.raises(AnsibleFailJson) as execinfo:
            install_python_apt(module, 'python3-apt')


# Generated at 2022-06-11 06:42:55.615151
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class Module(object):
        pass

    module = Module()

    sourceslist = SourcesList(module)


# Generated at 2022-06-11 06:44:07.119289
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={
        'codename': {'type': 'str'},
        'filename': {'type': 'str'},
        'mode': {'type': 'str'},
    })

    sources = UbuntuSourcesList(module)
    p = module.params
    for file, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            if valid:
                assert source.strip()
    if not sources.codename:
        assert sources.codename == distro.codename
    if not sources.default_file:
        assert sources.default_file == '/etc/apt/sources.list'
    if not sources.files:
        assert sources.files == {}
    if not sources.module:
        assert sources.module == module

# Generated at 2022-06-11 06:44:16.966262
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = MagicMock()
    module.params = {'codename': distro.codename}
    module.check_mode = False
    module.set_mode_if_different = MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.fail_json = MagicMock()
    module.atomic_move = MagicMock()

    def add_ppa_signing_keys_callback(command):
        module.run_command(command, check_rc=True)

    s = UbuntuSourcesList(
        module,
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback
    )

# Generated at 2022-06-11 06:44:22.637714
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class Module:
        def __init__(self):
            self.params = dict(
                repo='deb http://archive.canonical.com/ubuntu hardy partner',
                state='absent',
                filename=None,
                mode=None,
                update_cache='no',
                validate_certs='yes',
                codename='',
                distro='',
            )

# Generated at 2022-06-11 06:44:23.627263
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    assert False, "Test not implemented"



# Generated at 2022-06-11 06:44:34.232353
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # We're going to mock this module, as some of its functionality is platform specific.
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files = {
        '/tmp/something.list': [
            (0, True, True, 'deb some-repo-somewhere', 'some comment'),
        ],
        '/tmp/new-source.list': [
            (0, True, True, 'deb some-new-repo', 'some comment'),
            (1, True, True, 'deb existing-repo', 'some comment'),
            (2, False, False, '# deb old-source', 'some comment')
        ],
    }

    # Uncomment this to see if the mocked methods have been called.
    # def p(key):
    #     print "CALLED",

# Generated at 2022-06-11 06:44:46.112002
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins
    builtins.__dict__['HAVE_PYTHON_APT'] = False


# Generated at 2022-06-11 06:44:55.963842
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():

    testdata = [
        " # deb http://archive.canonical.com/ubuntu hardy partner",
        "   deb http://archive.canonical.com/ubuntu hardy partner",
        "deb http://archive.canonical.com/ubuntu hardy partner",
        '   # deb http://archive.canonical.com/ubuntu hardy partner',
        "# deb http://archive.canonical.com/ubuntu hardy partner",
        "deb http://dl.google.com/linux/chrome/deb/ stable main",
        "deb-src http://archive.canonical.com/ubuntu hardy partner",
    ]


# Generated at 2022-06-11 06:44:58.895192
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = DummyModule()
    u_sl = UbuntuSourcesList(module)
    assert not u_sl.files
    assert u_sl.new_repos == set()


# Generated at 2022-06-11 06:45:09.314625
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    filename = 'sources.list'
    sources = [('deb http://archive.canonical.com/ubuntu hardy partner',),
               ('deb http://archive.ubuntu.com/ubuntu hardy main restricted universe multiverse',),
               ('deb http://security.ubuntu.com/ubuntu hardy-security main restricted universe multiverse',)
               ]
    #
    # Test that _expand_path works right.
    #
    module.params['filename'] = filename

    sourcesList = SourcesList(module)

# Generated at 2022-06-11 06:45:15.373683
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    module.run_command = lambda x: (x, '', '')
    install_python_apt(module, 'python3-apt')
    assert module._check_mode is False
    assert module.check_mode is True
    assert module._diff is False
    assert module.diff is True
    assert module._insistent is False
    assert module.insistent is True
    assert module._warnings is False
    assert module.warnings is True



# Generated at 2022-06-11 06:47:05.620093
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class Module():
        def __init__(self):
            self.params = {}
            self.params['filename'] = None

        def fail_json(self, msg):
            print(msg)
        def set_mode_if_different(self, file, mode, diff=True):
            pass
        def atomic_move(self, tmp, final):
            pass
        def get_bin_path(self, apt_get_path):
            return apt_get_path

        def run_command(self, arg):
            return 0, 'stdout', 'stderr'

    module = Module()
    '''
    Test logic for method add_source() in class SourcesList
    '''

    sources_list = SourcesList(module)
    source_new = 'source_new'
    comment_new = 'comment_new'


# Generated at 2022-06-11 06:47:13.959236
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''SourcesList modify unit tests'''

    class test_module(object):
        params = {'mode': False}

        @staticmethod
        def fail_json(msg):
            raise Exception(msg)

        @staticmethod
        def atomic_move(src, dst):
            pass

        @staticmethod
        def get_bin_path(path):
            return None

        @staticmethod
        def set_mode_if_different(dst, this_mode, False_):
            pass

    sourceslist = SourcesList(test_module)

# Generated at 2022-06-11 06:47:17.550070
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({})
    assert module.check_mode is False
    assert get_add_ppa_signing_key_callback(module) is not None

    module = AnsibleModule({}, check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-11 06:47:25.513920
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    class AnsibleModuleMock(AnsibleModule):
        """AnsibleModuleMock

        Mock of AnsibleModule.

        See https://github.com/ansible/ansible/pull/27309
        """
        def __init__(self, *args, **kwargs):
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)
            self._tmpdir = None
            self._tmpdir = tempfile.mkdtemp(prefix=self.aliases[0] + '_ansible_modlib.module_utils.basic.')


# Generated at 2022-06-11 06:47:31.291796
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    ubuntuSourcesList = UbuntuSourcesList(object)
    ubuntuSourcesList._remove_valid_source = MagicMock()
    ubuntuSourcesList.remove_source('ppa:myppa')
    ubuntuSourcesList._remove_valid_source.assert_called_once_with('deb http://ppa.launchpad.net/myppa/ppa/ubuntu {} main'.format(distro.codename))
    ubuntuSourcesList._remove_valid_source.reset_mock()
    ubuntuSourcesList.remove_source('myppa')
    ubuntuSourcesList._remove_valid_source.assert_called_once_with('myppa')


# Generated at 2022-06-11 06:47:31.784091
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-11 06:47:39.715921
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    a = SourcesList()
    a.files = {
        'c': [(0, False, False, 'deb http://deb', ' comment'),
              (1, True, True, 'deb http://deb', ' comment'),
              (2, True, False, 'deb http://deb', ' comment'),
              (3, False, False, 'deb http://deb', ' comment')],
        'b': [(0, True, True, 'deb http://deb', ' comment'),
              (1, True, False, 'deb http://deb', ' comment'),
              (2, True, True, 'deb http://deb', ' comment')]
    }
    a.default_file = 'a'

# Generated at 2022-06-11 06:47:47.961213
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    '''
    Test UbuntuSourcesList class
    '''

    # Create fake directory
    d = tempfile.mkdtemp()

    # Create mock module
    module = AnsibleModule(argument_spec={})
    module.params.update({'_ansible_tmpdir': d})

    # Create fake .list file
    f = open(os.path.join(d, 'apt.list'), 'w')
    f.write('# Example of ppa\n')
    f.write('deb http://ppa.launchpad.net/my-fake-ppa/my-fake-ppa/ubuntu xenial main\n')
    f.write('# Example of non-ppa\n')
    f.write('deb http://deb.debian.org/debian jessie main contrib non-free\n')
    f.close()

    #

# Generated at 2022-06-11 06:47:58.007503
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    test_sources = {
        'test.list': '''
            deb http://archive.ubuntu.com/ubuntu precise main restricted
            # deb-src http://archive.ubuntu.com/ubuntu precise main restricted
            \t # deb http://archive.ubuntu.com/ubuntu precise-updates main restricted
            '''
        }
    module = FakeModule(params={})
    sources = SourcesList(module)
    sources._apt_cfg_dir = lambda _: ''
    sources._apt_cfg_file = lambda _: ''
    sources.files = {'test.list': []}

# Generated at 2022-06-11 06:48:06.014938
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class ModuleMock(object):
        def __init__(self):
            self.params = dict(codename='codename')

    def add_ppa_signing_keys_callback(command):
        pass

    ubuntu_sources_list = UbuntuSourcesList(ModuleMock(), add_ppa_signing_keys_callback)

    new_ubuntu_sources_list = copy.deepcopy(ubuntu_sources_list)
    assert ubuntu_sources_list.codename == new_ubuntu_sources_list.codename
    assert ubuntu_sources_list.add_ppa_signing_keys_callback == new_ubuntu_sources_list.add_ppa_signing_keys_callback