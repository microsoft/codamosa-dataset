

# Generated at 2022-06-11 06:39:32.661916
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import shutil
    import tempfile
    import unittest

    class TestModule(object):
        def __init__(self):
            self.params = dict(
                filename='test_filename',
                comment='test comment',
                state='present',
            )
            self._error_messages = []

        def fail_json(self, msg):
            self._error_messages.append(msg)

        def atomic_move(self, src, dest):
            shutil.move(src, dest)

    class TestRevertSourcesList(unittest.TestCase):

        def setUp(self):
            self.in_dir = tempfile.mkdtemp()
            self.out_dir = tempfile.mkdtemp()
            self.module = TestModule()


# Generated at 2022-06-11 06:39:43.601538
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.misc.plugins.module_utils.pycompat24 import get_exception

    tmp = os.path.realpath(tempfile.mkdtemp())
    m = AnsibleModule({
        'filename': os.path.join(tmp, 'test.list'),
        'codename': 'xenial',
        'state': 'present',
        'key': 'https://ansible.github.io/ansible/gpg-ok.key',
        'key_src': None,
        'update_cache': False,
        'mode': None
    },
        check_invalid_arguments=False)
    sl = UbuntuSourcesList(m)

    # Test common use case: a new ppa

# Generated at 2022-06-11 06:39:55.702305
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources = SourcesList(None)

    # No sources
    sources.load('test/sources.list')
    assert list(sources) == []

    # Simple case: one source
    sources.load('test/sources.list1')
    srcs = list(sources)
    assert len(srcs) == 1
    filename, n, enabled, source, comment = srcs[0]
    assert filename == 'test/sources.list1'
    assert n == 0
    assert enabled
    assert source == 'deb http://archive.canonical.com/ubuntu hardy partner'
    assert not comment

    # multicomment
    sources.load('test/sources.list2')
    srcs = list(sources)
    assert len(srcs) == 1
    filename, n, enabled, source, comment = srcs

# Generated at 2022-06-11 06:40:07.044691
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os.path
    import unittest
    from shutil import rmtree
    import ansible.module_utils.common.respawn


    class TestCase(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp(prefix='apt_repository_test_')
            self.addCleanup(rmtree, self.tmpdir, ignore_errors=True)

            # Override apt_pkg.Config
            self.orig_config_init = apt_pkg.Config.__init__
            self.orig_config_find_file = apt_pkg.Config.FindFile
            self.orig_config_find_dir = apt_pkg.Config.FindDir
            self.orig_config_merge = apt_pkg.Config.Merge

            apt_pkg.Config

# Generated at 2022-06-11 06:40:19.679501
# Unit test for function install_python_apt
def test_install_python_apt():
    # In this test, we are mocking module.run_command
    # since we are just testing the function install_python_apt()
    # which calls module.run_command.
    import sys
    python_apt = 'python-apt'
    if PY3:
        python_apt = 'python3-apt'
    module = sys.modules["ansible.module_utils.basic"]
    module.run_command = lambda x: (1, '', '')
    module.get_bin_path = lambda x: '/usr/bin/apt-get'

    try:
        import apt
        del apt
    except ImportError:
        install_python_apt(module, python_apt)
        try:
            import apt
        except ImportError:
            raise AssertionError("Failed to install python-apt")



# Generated at 2022-06-11 06:40:29.182651
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    """
    Removes a repository source by line.
    """

    # Set up a mock module
    line = "deb http://ppa.launchpad.net/someone/ppa/ubuntu xenial main"
    file = '/etc/apt/sources.list.d/test_ppa.list'
    comment = '# Hello, world!'

    # Add the repository to the test object
    sl = UbuntuSourcesList(module)
    sl.add_source(line, comment, file)
    assert line in sl.repos_urls

    # Remove the repository from the test object
    sl.remove_source(line)
    assert line not in sl.repos_urls


# Generated at 2022-06-11 06:40:40.214398
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile

    from ansible.module_utils.apt_repository import SourcesList
    from ansible.module_utils import basic

    temp_dir = tempfile.mkdtemp(prefix='ansible_test_SourcesList_save')
    temp_conf = tempfile.mkdtemp(prefix='ansible_test_SourcesList_save_conf', dir=temp_dir)
    temp_conf_sourceparts = tempfile.mkdtemp(prefix='ansible_test_SourcesList_save_conf_sourceparts', dir=temp_dir)

    module = basic.AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    module.params['filename'] = 'file3.list'

    old_config_find_file = SourcesList._apt_cfg_file


# Generated at 2022-06-11 06:40:45.832368
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    source_list = UbuntuSourcesList(None)
    source_list.add_source("ppa:ansible/ansible")

    assert source_list.files["/etc/apt/sources.list.d/ansible-ansible-ubuntu-bionic.list"] == [
        (0, True, True, "deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main", "")
    ]



# Generated at 2022-06-11 06:40:46.383914
# Unit test for function install_python_apt
def test_install_python_apt():
    assert False



# Generated at 2022-06-11 06:40:47.266747
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    assert False



# Generated at 2022-06-11 06:41:21.391058
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import tempfile
    import shutil
    import os
    t = SourcesList(AnsibleModule(argument_spec={}))
    tf = tempfile.mkdtemp()

# Generated at 2022-06-11 06:41:26.338959
# Unit test for constructor of class SourcesList

# Generated at 2022-06-11 06:41:36.715610
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources = UbuntuSourcesList()
    sources.codename = 'wily'
    sources.files = {
        '/etc/apt/sources.list.d/remi-php56.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/ondrej/php/ubuntu wily main', ''),
            (1, True, False, 'deb http://ppa.launchpad.net/ondrej/php/ubuntu wily main', ''),
        ]
    }
    sources.remove_source('ppa:ondrej/php')  # should work (see https://github.com/ansible/ansible/pull/21985)
    sources.remove_source('ppa:ondrej/php:wily')  # should work (see https://github.com/ansible/ansible/pull/218

# Generated at 2022-06-11 06:41:46.583059
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()
    ubuntu_sources_list = UbuntuSourcesList(
        module,
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback
    )
    ubuntu_sources_list.codename = 'codename'

    actual = ubuntu_sources_list.__deepcopy__()

    assert ubuntu_sources_list.module == actual.module
    assert ubuntu_sources_list.add_ppa_signing_keys_callback == actual.add_ppa_signing_keys_callback
    assert ubuntu_sources_list.codename == actual.codename


# Generated at 2022-06-11 06:41:57.616504
# Unit test for function main
def test_main():
    import os
    import sys
    import pytest
    import re

    m_path=os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
    print(m_path)
    if m_path not in sys.path:
        sys.path.insert(0, m_path)

# Generated at 2022-06-11 06:42:07.701476
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Create dummy file system structure
    temp_dir = tempfile.mkdtemp()
    sources_list_dirs = [
        os.path.join(temp_dir, "sources.list.d"),
        os.path.join(temp_dir, "dir::etc::sourceparts")
    ]
    sources_list_dirs_dict = {
        'Dir::Etc::sourcelist': os.path.join(temp_dir, "sources.list"),
        'Dir::Etc::sourceparts': os.path.join(temp_dir, "dir::etc::sourceparts"),
    }

    for d in sources_list_dirs:
        os.makedirs(d)


# Generated at 2022-06-11 06:42:12.030384
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3'
    }
    sources_after = {
        'test1': 'test1',
        'test2': 'test2',
        'test3': 'test3',
        'test4': 'test4'
    }
    sources_after2 = {
        'test1': 'test1',
        'test2': 'test2'
    }
    mock_module = Mock()
    mock_module.check_mode = False
    mock_module.atomic_move = lambda a, b: mock_module.tmp_paths.append(a)
    mock_module.tmp_paths = []

    sl_before = Mock()
    sl_before.files = sources_before


# Generated at 2022-06-11 06:42:15.454184
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('test_apt_repository_modify')
    for file, sources in sl.files.items():
        for n, valid, enabled, source, comment in sources:
            if 'ppa:nginx/stable' in source:
                sl.modify(file, n, comment='test_apt_repository_modify_comment')
    sl.save()
    module.exit_json(changed=True)


# Generated at 2022-06-11 06:42:25.416242
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # This test does not actually run apt module code, it just tests the
    # new SourcesList object.
    module = AnsibleModule(argument_spec={})

    sources = SourcesList(module)

    # Add one new source and ensure it was added
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ wily main')
    assert len(sources.files) == 1  # Should be 1 source
    filename, line, enabled, source, comment = next(iter(sources))
    assert enabled
    assert source == 'deb http://archive.ubuntu.com/ubuntu/ wily main'
    assert not comment

    # Now add the same source again, and ensure that the previous one was
    # modified, and not duplicated.
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ wily main')


# Generated at 2022-06-11 06:42:28.655950
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = None
    sources_list = SourcesList(module)
    assert sources_list.__iter__ == sources_list.__iter__()


# Generated at 2022-06-11 06:43:31.760963
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    list = SourcesList()
    list.files = {
        'file1': [
            (0, True, True, 'deb 1001', ''),
            (1, True, False, 'deb-src 1002', ''),
        ],
        'file2': [
            (0, True, True, 'deb 1003', 'comment3'),
            (1, True, True, 'deb 1004', 'comment4'),
        ],
    }
    print(list.dump())


# Generated at 2022-06-11 06:43:41.477813
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Create test
    test = SourcesList(None)
    # Test normal string
    sources = dict()
    sources[0] = ["deb http://archive.canonical.com/ubuntu hardy partner", "http://archive.canonical.com/ubuntu hardy partner", False, False, False]
    sources[1] = ["deb http://dl.google.com/linux/chrome/deb/ stable main", "http://dl.google.com/linux/chrome/deb/ stable main", False, True, True]
    sources[2] = ["deb-src http://archive.canonical.com/ubuntu hardy partner", "http://archive.canonical.com/ubuntu hardy partner", True, False, False]
    for i in range(len(sources)):
        test._add_valid_source(sources[i][1], "", None)

# Generated at 2022-06-11 06:43:47.339026
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None
    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None


# Generated at 2022-06-11 06:43:56.461050
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class MyModule:
        def __init__(self):
            self._dict = dict(
                file1=['# source1\n', 'source2'],
                file2=[]
            )

        def atomic_move(self, tmp_path, filename):
            self._dict[filename] = self._dict[tmp_path]

        def fail_json(self, msg):
            raise Exception(msg)

        def get_bin_path(self, bin_path):
            return bin_path

        def run_command(self, cmd):
            return 1, '', ''

    mymod = MyModule()
    sl = SourcesList(mymod)
    sl.load('file1')
    sl.load('file2')
    sl.add_source('source3')
    sl.add_source('source4')
    sl

# Generated at 2022-06-11 06:44:06.997629
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class TestClass(object):
        def __init__(self):
            self.files = {}
            self.default_file = "/etc/apt/sources.list"
            self.files[self.default_file] = [
                (0, True, True, "deb http://archive.ubuntu.com/ubuntu xenial main", ""),
                (1, False, False, "deb http://archive.ubuntu.com/ubuntu xenial main", ""),
                (2, False, False, "deb http://archive.ubuntu.com/ubuntu xenial main", ""),
                (3, True, True, "deb http://archive.ubuntu.com/ubuntu xenial main", ""),
                (4, True, True, "deb http://archive.ubuntu.com/ubuntu xenial main", ""),
            ]
            self.module = TestClass()
           

# Generated at 2022-06-11 06:44:16.829778
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Is called to mock the behaviour of apt-key
    def apt_key_callback_add(command):
        assert command[-1] == key_fingerprint
    # Create test data set
    test_src_url = 'https://src'
    test_comment = 'SomeComment'
    test_file = 'MySourceFile'
    test_ppa_url = 'ppa:ppaowner/ppaname'
    test_ppa_owner = 'ppaowner'
    test_ppa_name = 'ppaname'
    test_codename = 'codename'
    test_key_fingerprint = 'fingerprint'
    test_sources_list_dump = {
        'MySourceFile': 'deb https://src SomeComment\n',
    }
    # Perform the test.
    module = MagicMock()
    module.params = {}


# Generated at 2022-06-11 06:44:26.058521
# Unit test for function main
def test_main():
    test_arguments = {
        'repo': 'ansible',
        'state': 'present',
        'mode': '0440',
        'update_cache': 'True',
        'update_cache_retries': '5',
        'update_cache_retry_max_delay': '12',
        'filename': 'ansible',
        'install_python_apt': 'True',
        'validate_certs': 'True',
        'codename': 'ansible',
        'self': 'ansible'
    }


# Generated at 2022-06-11 06:44:37.493761
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    """
    Correctly remove the source for the archive for a repository
    """
    import sys

    # load the module
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../..', 'lib'))

    module = AnsibleModule({
        'state': 'absent',
        'name': 'ppa:ansible/ansible'
    }, check_invalid_arguments=False)

    sources_list = UbuntuSourcesList(module)

    # Create the default sources list
    default_file = sources_list._apt_cfg_file('Dir::Etc::sourcelist')
    open(default_file, 'w').close()

    sources_list.load(default_file)


# Generated at 2022-06-11 06:44:49.009161
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Test SourcesList.remove_source method
    """
    class AnsibleModuleFake:
        def __init__(self, argv, **kwargs):
            self.params = kwargs
            self.argv = argv
        def fail_json(self, msg):
            self.exit_args = sys.exc_info()
        def check_mode(self):
            return False
    class FakeSourcesList(SourcesList):
        def __init__(self, module):
            self.module = module
            self.files = {}  # group sources by file
            self.default_file = self.module.params['file']
    params = dict(
        file='/tmp/sources.list',
        mode='0644'
    )

# Generated at 2022-06-11 06:44:56.780462
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict())
    s = UbuntuSourcesList(module)
    s.add_source('deb http://ppa.launchpad.net/webupd8team/y-ppa-manager/ubuntu trusty main')
    assert len(s.files) == 1
    assert len(s.files[s.default_file]) == 1
    s.remove_source('ppa:webupd8team/y-ppa-manager')
    assert len(s.files) == 1
    assert len(s.files[s.default_file]) == 0
    res = s.remove_source('ppa:webupd8team/y-ppa-manager')
    assert res is None

