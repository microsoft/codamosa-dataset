

# Generated at 2022-06-11 06:39:50.725430
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sl = SourcesList(None)
    sl.load('apt_repository/tests/data/sources.list.d/disabled-and-enabled-sources.list')

# Generated at 2022-06-11 06:39:51.638197
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass


# Generated at 2022-06-11 06:39:58.616474
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={'codename': {'default': 'xenial', 'type': 'str'}})
    ubuntu_sources = UbuntuSourcesList(module)

    # add ppa:ondrej/php
    ubuntu_sources.add_source('ppa:ondrej/php')
    assert 'ppa:ondrej/php' in ubuntu_sources.repos_urls
    # add another ppa:ondrej/php
    ubuntu_sources.add_source('ppa:ondrej/php')
    assert 'ppa:ondrej/php' in ubuntu_sources.repos_urls

# Generated at 2022-06-11 06:40:03.057367
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Test in check_mode
    module = MagicMock()
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None
    # Test in normal mode
    module = MagicMock()
    module.check_mode = False
    f = get_add_ppa_signing_key_callback(module)
    assert f is not None
    f(['a', 'b'])
    module.run_command.assert_called_with(['a', 'b'], check_rc=True)



# Generated at 2022-06-11 06:40:15.986414
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    m = AnsibleModule(argument_spec={})
    # m.object is a SourcesList object
    m.object.add_source('deb http://repository.example.com//ubuntu trusty main')
    tmp_path = tempfile.mkdtemp()
    m.object.default_file = os.path.join(tmp_path, 'sources.list')
    m.object.save()
    m.object.load(m.object.default_file)
    assert len(m.object.files) == 1
    m.object.save()
    m.object.remove_source('deb http://repository.example.com//ubuntu trusty main')
    assert len(m.object.files) == 1
    m.object.save()
    m.object.load(m.object.default_file)


# Generated at 2022-06-11 06:40:18.214576
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    assert UbuntuSourcesList(None).remove_source('ppa:foo/bar') == None



# Generated at 2022-06-11 06:40:20.359638
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Testing with the default value for argument memo
    # Input arguments:
    #   (no arguments)

    pass



# Generated at 2022-06-11 06:40:32.430519
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from io import StringIO
    from tempfile import NamedTemporaryFile

    m = MagicMock(spec_set=Module, check_mode=True)
    module = m.module

    apt_pkg.init()
    sources_before = AptSourcesListModify(m)
    sources_after = AptSourcesListModify(m)
    sources_after._add_valid_source('deb http://ppa.launchpad.net/foo_bar_test/test-ppa/ubuntu test main', '')

    # Create the temp file
    temp_file = NamedTemporaryFile(mode='w+t', delete=False, prefix='ansible')
    temp_file.write(to_bytes('deb http://fake.com/\n'))
    temp_file.close()

    # Create an apt_sources_list_before mock
   

# Generated at 2022-06-11 06:40:42.502236
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(
        argument_spec=dict(
            codename='',
        )
    )
    u = UbuntuSourcesList(module)
    u.files = dict()

# Generated at 2022-06-11 06:40:46.596728
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import pprint
    s = UbuntuSourcesList(None, None)
    sl = 'deb http://ppa.launchpad.net/ansible/ansible-2.4/ubuntu trusty main'

    s.load('/tmp/tt')
    s.add_source(sl)
    pp = pprint.PrettyPrinter(indent=4)
    pp.pprint(s.dump())
    s.remove_source('ppa:ansible/ansible-2.4')
    pp.pprint(s.dump())


# Generated at 2022-06-11 06:41:24.498272
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self, fail_json, atomic_move, set_mode_if_different, run_command, check_mode, params):
            self.fail_json = fail_json
            self.atomic_move = atomic_move
            self.set_mode_if_different = set_mode_if_different
            self.run_command = run_command
            self.check_mode = check_mode
            self.params = params

    class Distro(object):
        codename = 'trusty'

    global distro
    distro = Distro()

    global SourcesList
    SourcesList = UbuntuSourcesList

    # Uncomment for debugging
    # import pdb
    # pdb.set_trace()

    class FAIL_JSON(Exception):
        pass

# Generated at 2022-06-11 06:41:35.347637
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    assert SourcesList({}).dump() == {}
    assert SourcesList({'a': []}).dump() == {}
    assert SourcesList({'a': [('0', False, True, '', '')]}).dump() == {}
    assert SourcesList({'a': [('0', True, True, 'a b c', 'd')]}).dump() == {'a': 'a b c\n'}
    assert SourcesList({'a': [('0', True, False, 'a b c', 'd')]}).dump() == {'a': '# a b c\n'}

# Generated at 2022-06-11 06:41:46.150046
# Unit test for constructor of class SourcesList
def test_SourcesList():
    if not HAVE_PYTHON_APT:
        return

    # Make test-specific copy of apt config file, so we don't alter system's one
    TMP_DIR = tempfile.mkdtemp(prefix='ansible-apt-repo')
    CUSTOM_ETC_DIR = os.path.join(TMP_DIR, 'etc')
    CUSTOM_ETC_APT_DIR = os.path.join(CUSTOM_ETC_DIR, 'apt')
    CUSTOM_ETC_APT_SOURCESLISTD_DIR = os.path.join(CUSTOM_ETC_APT_DIR, 'sources.list.d')

    apt_pkg.Config.Set('Dir::Etc', CUSTOM_ETC_DIR)

# Generated at 2022-06-11 06:41:57.255510
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import os.path

    class Module(object):
        """
        Module mock for class `SourcesList`.
        """
        def __init__(self, path, content):
            self._path = path
            self._content = content

        def get_bin_path(self, arg, *args, **kwargs):
            """
            Mock method to avoid import of module apt.
            """
            return '/bin/apt-get'

        def run_command(self, cmd, *args, **kwargs):
            if '/bin/apt-get' == cmd[0] and 'update' == cmd[1]:
                return 0, '', ''
            if '/bin/apt-get' == cmd[0] and 'install' == cmd[1]:
                return 0, '', ''


# Generated at 2022-06-11 06:42:07.134145
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModuleStub()
    u = UbuntuSourcesList(module)


# Generated at 2022-06-11 06:42:18.617120
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    apt = module.apt = apt_pkg = aptsources_distro = distro = None
    try:
        import apt
        import apt_pkg
        import aptsources.distro as aptsources_distro

        distro = aptsources_distro.get_distro()

        HAVE_PYTHON_APT = True
    except ImportError:
        HAVE_PYTHON_APT = False

    DEFAULT_SOURCES_PERM = 0o0644

    VALID_SOURCE_TYPES = ('deb', 'deb-src')

    sources_list = SourcesList(module)
    assert len(sources_list.files) == 0
    sources_list.load('/home/test/test.list')

# Generated at 2022-06-11 06:42:22.587829
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule('', '')
    module.get_bin_path = MagicMock(return_value="/usr/bin/apt-get")
    module.run_command = MagicMock(return_value=(0, '', ''))
    install_python_apt(module, 'python-apt')



# Generated at 2022-06-11 06:42:26.061124
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = UbuntuSourcesList(module)
    module.assertIsInstance(deepcopy(sl), UbuntuSourcesList)


# Generated at 2022-06-11 06:42:38.114020
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'filename': None,
                'codename': None
            }

    mock_module = MockModule()
    usl = UbuntuSourcesList(mock_module)
    usl.add_source('ppa:smoser/bup')
    assert len(usl.repos_urls) == 1
    usl.remove_source('ppa:smoser/bup')
    assert len(usl.repos_urls) == 0

    usl.add_source('ppa:smoser/bup')
    assert len(usl.repos_urls) == 1
    usl.remove_source('deb http://ppa.launchpad.net/smoser/bup/ubuntu xenial main')

# Generated at 2022-06-11 06:42:49.570582
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})

    apt_repository = SourcesList(module)
    apt_repository._remove_valid_source = MagicMock()

    # test without filename
    apt_repository.files = {}
    apt_repository.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    expected_files = {
        '/etc/apt/sources.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]
    }
    if not sys.version_info >= (3,):
        for key, value in expected_files.items():
            expected_files[key] = sorted(expected_files[key])
    assert expected_files == apt_repository.files

    # test with filename
    apt_re

# Generated at 2022-06-11 06:44:08.984337
# Unit test for method load of class SourcesList

# Generated at 2022-06-11 06:44:18.877699
# Unit test for constructor of class SourcesList
def test_SourcesList():
    '''
    :return:
    '''
    module = AnsibleModule(argument_spec=dict())

    # Ensure that keys dir is nonexistent.
    keys_dir = apt_pkg.config.find_dir('Dir::Etc::sourceparts')
    if os.path.isdir(keys_dir):
        module.fail_json(msg="Can't run unit test: %s exists" % keys_dir)

    # Create sources.list with few lines.
    default_file = apt_pkg.config.find_file('Dir::Etc::sourcelist')
    if os.path.isfile(default_file):
        module.fail_json(msg="Can't run unit test: %s exists" % default_file)


# Generated at 2022-06-11 06:44:24.790747
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    s = SourcesList('')
    s.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    s.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    assert s._expand_path('canonical_com.list') == '/etc/apt/sources.list.d/canonical_com.list'
    assert s._expand_path('/etc/apt/sources.list.d/canonical_com.list') == '/etc/apt/sources.list.d/canonical_com.list'

    s = SourcesList('')
    s.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical_com.list')
    assert s

# Generated at 2022-06-11 06:44:26.911602
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, apt_pkg_name='python-apt')



# Generated at 2022-06-11 06:44:38.436545
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile

    module = AnsibleModule(argument_spec={})
    result = dict(changed=False, result='')

    tmp_dir = tempfile.mkdtemp()
    assert(tmp_dir.startswith('/tmp'))
    data = '''\
    # foo
    deb http://example.com/beef/ cow master
    # comment
    deb-src http://example.com/beef/ cow master # comment
    deb [arch=i386] http://example.com/beef/ cow master
    deb [arch=amd64] http://example.com/beef/ cow master
    '''
    with open('/tmp/sources.list', 'w') as f:
        f.write(data)

    sl = SourcesList(module)

    # Simple iterator

# Generated at 2022-06-11 06:44:49.993419
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    data = '''
deb http://archive.canonical.com/ubuntu hardy partner
deb-src http://archive.canonical.com/ubuntu hardy partner

# deb http://archive.canonical.com/ubuntu hardy partner
# deb-src http://archive.canonical.com/ubuntu hardy partner
'''
    tmpdir = tempfile.mkdtemp()
    f = open("/%s/sources.list" % tmpdir, "w")
    f.write(data)
    f.close()
    sources_list = SourcesList("/%s" % tmpdir)
    sources_list.load("%s/sources.list" % tmpdir)
    assert len(sources_list.files) == 1
    sources_list.load("%s/sources.list" % tmpdir)

# Generated at 2022-06-11 06:44:55.705748
# Unit test for function main
def test_main():
    """ Unit Test for function main """


# Generated at 2022-06-11 06:45:04.190838
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.apt import get_add_ppa_signing_key_callback
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests.mock import Mock

    module = Mock()
    module.check_mode = False

    with patch('ansible.module_utils.apt.run_command', new=Mock()) as run_command_mock:
        get_add_ppa_signing_key_callback(module)()
        run_command_mock.assert_called_once()

    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-11 06:45:06.632161
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    module.exit_json(changed=True)



# Generated at 2022-06-11 06:45:13.514731
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    def _test(line_old, line_new, comment=''):
        sl = SourcesList(AnsibleModule(os=OsMock()))
        assert len(list(sl)) == 0

        sl.add_source(line_old)
        assert len(list(sl)) == 1
        filename, n, enabled, source, comment_ = list(sl)[0]
        assert enabled
        assert source == line_new
        assert comment_ == comment
