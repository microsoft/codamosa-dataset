

# Generated at 2022-06-11 06:39:40.062956
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = FakeModule()
    sourceslist = SourcesList(module)

    def load_file(filename, lines):
        sourceslist.files[filename] = []

        for n, line in enumerate(lines):
            valid, enabled, source, comment = sourceslist._parse(line)
            sourceslist.files[filename].append((n, valid, enabled, source, comment))

    load_file(
        'sources.list',
        [
            'deb http://archive.canonical.com/ubuntu maverick partner\n',
            '# deb-src http://archive.canonical.com/ubuntu maverick partner\n',
        ]
    )

# Generated at 2022-06-11 06:39:52.656038
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    m = AnsibleModule({})
    m.fail_json = lambda **kwargs: None
    with tempfile.NamedTemporaryFile() as sl:
        with tempfile.NamedTemporaryFile() as sl_d:
            sl.write('\ndeb http://archive.ubuntu.com/ubuntu/ hardy main\n'.encode('utf-8'))
            sl.flush()
            sl_d.write('\ndeb-src http://archive.ubuntu.com/ubuntu/ hardy main\n'.encode('utf-8'))
            sl_d.flush()
            mock_apt_cfg_file = lambda filespec: sl.name
            mock_apt_cfg_dir = lambda dirspec: sl_d.name

# Generated at 2022-06-11 06:40:00.810112
# Unit test for method save of class SourcesList

# Generated at 2022-06-11 06:40:13.621590
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    duplicated_repo = 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse'
    sl = UbuntuSourcesList(mod)
    sl.add_source(duplicated_repo)
    sl.add_source(duplicated_repo)
    assert len(sl.files['/etc/apt/sources.list']) == 2
    sl.add_source('ppa:ansible/ansible')
    assert '/etc/apt/sources.list' in sl.files
    assert len(sl.files['/etc/apt/sources.list']) == 2

# Generated at 2022-06-11 06:40:21.358304
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:ansible/ansible')
    assert sl.files[sl.default_file][0][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    sl.add_source('ppa:somethingelse')
    assert sl.files[sl.default_file][1][3] == 'deb http://ppa.launchpad.net/somethingelse/ubuntu xenial main'



# Generated at 2022-06-11 06:40:33.627675
# Unit test for function revert_sources_list

# Generated at 2022-06-11 06:40:43.724036
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    filename = "test_SourcesList_save.list"
    ansible_module = AnsibleModule(argument_spec={})
    ansible_module.params = {}
    ansible_module.check_mode = True
    test_source_list = SourcesList(ansible_module)

# Generated at 2022-06-11 06:40:51.159752
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sl = UbuntuSourcesList(None)
    # ppa
    sl.add_source("ppa:loganmzz/qemu")
    assert sl._suggest_filename("loganmzz_qemu_bionic") == "loganmzz_qemu_bionic.list"
    assert sl.files["/etc/apt/sources.list.d/loganmzz_qemu_bionic.list"][0][1:] == (True, True, "ppa:loganmzz/qemu", "")
    sl.add_source("ppa:loganmzz/qemu")
    assert len(sl.files["/etc/apt/sources.list.d/loganmzz_qemu_bionic.list"]) == 1

# Generated at 2022-06-11 06:40:56.719815
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sourcesList = SourcesList(module)
    # Check that we parsed all sources, including disabled and commented.
    assertEqual(len(list(sourcesList)), len(sourcesList.files['/etc/apt/sources.list']) + len(sourcesList.files['/etc/apt/sources.list.d/google-chrome.list']))


# Generated at 2022-06-11 06:41:07.498415
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sources_list = UbuntuSourcesList(AnsibleModule(
            argument_spec=dict(
                update_cache=dict(default=False, type='bool'),
                cache_valid_time=dict(default=0, type='int'),
                state=dict(default='present', type='str', choices=['absent', 'present']),
                codename=dict(default=None, type='str'),
                filename=dict(default=None, type='str'),
                mode=dict(default=DEFAULT_SOURCES_PERM, type='raw'),
                source=dict(default=None, type='str', required=True),
                comment=dict(default='', type='str'),
            )
        ))

    assert sources_list.codename == 'xenial'
    assert sources_list.add_ppa_signing_keys

# Generated at 2022-06-11 06:42:19.897799
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    auth_ret_val = None
    def _add_ppa_signing_keys_callback(command):
        # Verify that the command to add the key is correct
        assert 'apt-key adv --recv-keys --no-tty --keyserver hkp://keyserver.ubuntu.com:80' in command
        assert command[-1] == '1234567890ABCDEF'

    def _auth_callback(url, fetch_headers, data):
        return auth_ret_val

    def _url_callback(url, data, headers, request_type='POST'):
        if url == 'http://ppa.launchpad.net/user/ppa-name/ubuntu/dists/xenial/Release':
            raise Exception('No such file or directory')


# Generated at 2022-06-11 06:42:31.158405
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = Mock()
    module.params = dict()
    apt_module = UbuntuSourcesList(module)

    apt_module.add_source('deb http://archive.canonical.com/ubuntu precise partner', file='/etc/apt/sources.list.d/partner.list')
    assert '/etc/apt/sources.list.d/partner.list' in apt_module.files
    assert 'deb http://archive.canonical.com/ubuntu precise partner' in apt_module.files['/etc/apt/sources.list.d/partner.list'][0][3]
    assert 'partner' in apt_module.files['/etc/apt/sources.list.d/partner.list'][0][4]


# Generated at 2022-06-11 06:42:42.920142
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule(AnsibleModule):
        def __init__(self):
            self.params = dict()
            self.fail_json = lambda msg: msg
            self.atomic_move = lambda src, dest: None

# Generated at 2022-06-11 06:42:51.208636
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(
        argument_spec={
            'apt_pkg_name': {'required': True},
            'check_mode': {'required': False, 'type': 'bool', 'default': False}
        },
        supports_check_mode=True
    )
    apt_pkg_name = module.params['apt_pkg_name']
    check_mode = module.params['check_mode']
    install_python_apt(module, apt_pkg_name)
    module.exit_json(msg="%s has been automatically installed" % apt_pkg_name)



# Generated at 2022-06-11 06:42:59.165757
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    m = MagicMock(name='module')
    m.params = dict()
    m.params['codename'] = 'foo_codename'
    m.atomic_move = MagicMock(name='atomic_move')
    m.set_mode_if_different = MagicMock(name='set_mode_if_different')
    m.params['filename'] = None
    # TODO: fix
    # m.params['mode'] = None
    m.params = {}

    s = UbuntuSourcesList(m)



# Generated at 2022-06-11 06:43:00.434646
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass



# Generated at 2022-06-11 06:43:08.906052
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import tempfile

    # Two sources with comments in two different .list files
    # in /etc/apt/sources.list.d/
    tmpdir = tempfile.mkdtemp()
    test_f1 = os.path.join(tmpdir, 'test-1.list')
    test_f2 = os.path.join(tmpdir, 'test-2.list')
    f1 = open(test_f1, 'w')
    f1.write('deb http://archive.ubuntu.com/ubuntu/ wily main restricted\n')
    f1.write('deb http://archive.ubuntu.com/ubuntu/ wily-updates main restricted # Security updates\n')
    f1.close()
    f2 = open(test_f2, 'w')

# Generated at 2022-06-11 06:43:19.138034
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    line = 'deb http://ppa.launchpad.net/testppa/testppa/ubuntu xenial main'
    comment = 'testppa testppa'
    module = MagicMock()
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.files = {'/etc/apt/sources.list.d/testppa-testppa_ubuntu.list': [(0, True, True, line, comment)]}
    ubuntu_sources_list.remove_source(line)
    assert not ubuntu_sources_list.files
    ppa_line = 'ppa:testppa/testppa'
    ubuntu_sources_list.files = {'/etc/apt/sources.list.d/testppa-testppa_ubuntu.list': [(0, True, True, line, comment)]}


# Generated at 2022-06-11 06:43:28.313163
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.builtin.plugins.module_utils.apt.sources_list import SourcesList

    def _mock_atomic_move(src, dest):
        assert(len(src) == 1)
        with open(dest, 'r') as file:
            assert(len(''.join(file)) == 1)

    def _mock_set_mode_if_different(path, mode, chown):
        assert(path == 'bar.list')
        assert(mode == 0o644)
        assert(chown == False)

    def _mock_run_command(args):
        assert(args[0] == 'bar.list')
        assert(args[3] == 'w')
        return (0, 1)

    module

# Generated at 2022-06-11 06:43:38.200010
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class module_mock(object):
        def __init__(self, module):
            self.params = module.params
            self.debug = module.debug
            self.atomic_move = module.atomic_move
            self.set_mode_if_different = module.set_mode_if_different
            self.run_command = module.run_command
            self.fail_json = module.fail_json
        def __call__(self, *args, **kwargs):
            self.params = kwargs

    class distro_mock(object):
        def __init__(self, module):
            self.codename = module.codename

    class fetch_url_mock(object):
        def __init__(self, module):
            self.module = module
            self.request = Request(module)

# Generated at 2022-06-11 06:44:46.065341
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(None)
    sl.files = {'a': [('0', True, True, 'q', 'w'),
                      ('1', True, True, 'q', 'w')]}
    sl.remove_source('q')
    assert sl.files == {'a': [('1', True, True, 'q', 'w')]}
    sl.files = {'a': [('0', True, True, 'q', 'w'),
                      ('1', True, True, 'q', 'w')]}
    sl.remove_source('q w')
    assert sl.files == {'a': [('1', True, True, 'q', 'w')]}

# Generated at 2022-06-11 06:44:49.055350
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    assert isinstance(SourcesList(module), SourcesList)
    assert SourcesList(module).files


# Generated at 2022-06-11 06:44:57.535357
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class DummyModule(object):
        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, command, check_rc=True):
            rc, output, err = 0, "", ""
            if isinstance(command, (list, tuple)):
                command = ' '.join(command)
            if command.startswith("apt-key export"):
                key_fingerprint = command.split()[-1]
                rc = int(key_fingerprint[-1])

            return rc, output, err

    sl = UbuntuSourcesList(DummyModule(), add_ppa_signing_keys_callback=None)

    sl.add_source("deb http://ppa.launchpad.net/omega8cc/firefox-ublock-origin/ubuntu bionic main", "comment")
    sl

# Generated at 2022-06-11 06:45:07.717763
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    _parameters_ = dict(
        add_ppa_signing_keys_callback=None,
        codename=None,
        ppa='ppa:~debconf-users/ubuntu/ppa')
    _result_ = dict(
        repos_urls=[])
    _exception_ = None
    _module_ = None
    _func_name_ = 'add_ppa'
    _cls_name_ = 'UbuntuSourcesList'
    _module_name_ = 'ansible_collections.ansible.community.plugins.module_utils.apt.repositories'

# Generated at 2022-06-11 06:45:17.096371
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    with patch.object(os.path, 'join') as mock_join:
        # Setup
        mock_join.return_value = '/etc/apt/sources.list.d/some_file.list'

        module = Mock()
        module.atomic_move = Mock()
        module.set_mode_if_different = Mock()
        module.params = {'filename':None, 'mode':None}

        # Test
        apt = UbuntuSourcesList(module, lambda x:True)
        apt.files = {}

        # Test1:
        # - input: a PPA
        # - expected result:
        #   - file name: will be suggested
        #   - sources added: PPA and its signing key
        #   - file mode: default
        ppa_url = 'ppa:some-ppa'
        ppa_key

# Generated at 2022-06-11 06:45:23.507345
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class FakeModule(object):
        params = {'codename': 'codename'}
        fail_json = ModuleHelper.fail_json
    module = FakeModule()
    usl = UbuntuSourcesList(module)
    copy_usl = copy.deepcopy(usl)
    assert copy_usl.module is module
    assert copy_usl.codename == 'codename'
    assert copy_usl.add_ppa_signing_keys_callback is None


# Generated at 2022-06-11 06:45:31.305566
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources = SourcesList(None)
    sources.files['/etc/apt/sources.list'] = [
        (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ bionic main', ''),
        (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ bionic-security main', ''),
        (2, True, True, 'deb http://archive.ubuntu.com/ubuntu/ bionic-updates main', ''),
        (3, True, True, 'deb http://archive.ubuntu.com/ubuntu/ bionic universe', ''),
        (4, True, True, 'deb http://archive.ubuntu.com/ubuntu/ bionic-updates universe', ''),
        (5, True, True, '# deb http://example.com/repo/ bionic examples', ''),
    ]

# Generated at 2022-06-11 06:45:41.399311
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    def _mock_atomic_move(path1, path2):
        '''Mock atomic_move method of AnsibleModule

        This method should copy contents of file and not it's attributes
        '''
        with open(path2, "w+") as new_file:
            with open(path1) as old_file:
                new_file.write(old_file.read())

    def _mock_set_mode_if_different(path, mode, follow):
        '''Mock AnsibleModule.set_mode_if_different for testing purposes'''
        assert os.path.isfile(path)
        assert follow is False

        if path in mock_set_mode_if_different_expected:
            assert mock_set_mode_if_different_expected[path] == mode
            del mock_set_mode_if

# Generated at 2022-06-11 06:45:49.576624
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()

    sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    sources_list_new = copy.deepcopy(sources_list)

    assert sources_list is not sources_list_new
    assert isinstance(sources_list_new, UbuntuSourcesList)
    assert sources_list.module is sources_list_new.module
    assert sources_list.add_ppa_signing_keys_callback is sources_list_new.add_ppa_signing_keys_callback
    assert sources_list.codename is sources_list_new.codename
    assert sources_list.files is sources_list_new.files



# Generated at 2022-06-11 06:45:54.412151
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # By default distro.codename is used
    sources_list = UbuntuSourcesList({})

    # Check the default codename is the same as distro.codename
    assert sources_list.codename == distro.codename

    # check the codename can be overridden
    sources_list = UbuntuSourcesList({}, codename='other')
    assert sources_list.codename == 'other'

