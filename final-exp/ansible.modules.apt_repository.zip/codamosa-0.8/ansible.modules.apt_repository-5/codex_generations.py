

# Generated at 2022-06-11 06:39:41.674451
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six import b
    from ansible.module_utils.six import text_type
    import sys

    # reload module
    reload(sys)
    if PY2:
        try:
            sys.setdefaultencoding('utf8')
        except AttributeError:
            pass

    # mock module input parameters

# Generated at 2022-06-11 06:39:54.471109
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Unit test for function revert_sources_list'''
    sources_before = {'/etc/apt/sources.list.d/foo.list': 'bar', '/etc/apt/sources.list': 'baz'}
    set_module_args({'sources': sources_before})
    module = AnsibleModule(argument_spec={'sources': {'type': 'dict'}})
    sourceslist = UbuntuSourcesList(module)

    # Function to test:
    sourceslist.save()
    sources_after = sourceslist.dump()
    revert_sources_list(sources_before, sources_after, sourceslist)

    # Check that the revert succeeded:
    for filename, _ in sources_before.items():
        with open(filename, 'r') as f:
            contents = f.read()
       

# Generated at 2022-06-11 06:39:58.523420
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    '''
    Class UbuntuSourcesList should be able to construct properly
    '''
    module = AnsibleModule(argument_spec={})
    ubuntu_sources_list = UbuntuSourcesList(module)

    assert ubuntu_sources_list.files == {}



# Generated at 2022-06-11 06:40:10.473290
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-11 06:40:22.179221
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})

    src = SourcesList(module)

    SRC = [
        ('deb http://archive.canonical.com/ubuntu hardy partner', ''),
        ('deb http://dl.google.com/linux/chrome/deb/ stable main', ''),
        ('deb-src http://archive.canonical.com/ubuntu hardy partner', ''),
        ('# deb http://archive.canonical.com/ubuntu hardy partner', ''),
        ('# deb http://dl.google.com/linux/chrome/deb/ stable main', ''),
        ('# deb-src http://archive.canonical.com/ubuntu hardy partner', ''),
    ]


# Generated at 2022-06-11 06:40:34.381446
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockFilesystem(object):
        def __init__(self):
            self.files = {
                '/etc/apt/sources.list': (
                    ('# deb cdrom:[Debian GNU/Linux 7 _Wheezy_ - Official Snapshot amd64 LIVE/INSTALL Binary 20130920-04:14]/ wheezy main',),
                    ('deb http://security.debian.org/ wheezy/updates main contrib non-free',),
                ),
            }

        def open(self, filename, mode):
            self.filename = filename
            self.mode = mode
            return iter(self.files.get(filename, ()))

        def exists(self, filename):
            return filename in self.files


# Generated at 2022-06-11 06:40:38.713019
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    filename = '/tmp/ansible-testfile-%d' % random.randrange(0, 1000000)
    assert filename not in [f for f, _, _, _, _ in SourcesList.add_source(filename, 'deb http://example.com/debian jessie main')]



# Generated at 2022-06-11 06:40:48.011359
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    print("Unit test Started")

# Generated at 2022-06-11 06:40:49.966697
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    assert list(sources_list) == []

# Generated at 2022-06-11 06:41:00.450396
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import tempfile
    import shutil
    import os

    # Test file with one repo
    apt_file_one = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    apt_file_one.write(b'deb http://archive.ubuntu.com/ubuntu/ raring main restricted\n')
    apt_file_one.close()
    # Test file with multiple repo
    apt_file_two = tempfile.NamedTemporaryFile(mode='w+b', delete=False)
    apt_file_two.write(b'deb http://archive.ubuntu.com/ubuntu/ raring main restricted\n')
    apt_file_two.write(b'deb http://archive.ubuntu.com/ubuntu/ raring universe\n')

# Generated at 2022-06-11 06:41:35.540578
# Unit test for constructor of class SourcesList

# Generated at 2022-06-11 06:41:46.298296
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sourceslist = SourcesList(None)

# Generated at 2022-06-11 06:41:57.347734
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Check that adding source to existing file works.
    valid, enabled, source, comment = 'deb http://archive.canonical.com/ubuntu trusty partner'.split()
    sourceslist = SourcesList('module')
    assert sourceslist.add_source(line) == (valid, enabled, source, comment)

    # Check that adding source with comment works.
    comment = 'comment'
    assert sourceslist.add_source(line, comment=comment) == (valid, enabled, source, comment)

    # Check that adding source with filename works.
    filename = 'new-file.list'
    assert sourceslist.add_source(line, file=filename) == (valid, enabled, source, comment)

    # Check that adding disabled source works.
    # We'll remove comment to simplify testing.

# Generated at 2022-06-11 06:42:00.830150
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    line = 'deb http://deb.debian.org/debian buster main'
    file = 'test.list'
    sl = SourcesList(dict())
    sl.add_source(line, file=file)
    assert line in sl.dump()[sl._expand_path(file)]



# Generated at 2022-06-11 06:42:12.966819
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-11 06:42:17.188625
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None

    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None



# Generated at 2022-06-11 06:42:28.272994
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    import shutil
    import os
    import random
    # The following tests are very basic - they just check that data are
    # read and stored in the right format. These tests are not meant to
    # check that the underlying aptsources.sourceslist module works
    # properly. They rather check that we've written the wrapper correctly.

    temp_dir = tempfile.mkdtemp()
    src = os.path.abspath(os.path.dirname(__file__))

# Generated at 2022-06-11 06:42:37.356738
# Unit test for function install_python_apt
def test_install_python_apt():
    # pylint: disable=unused-argument
    def run_command(self, cmd, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False):
        return 0, '', ''
    AnsibleModule.run_command = run_command
    apt_pkg_name = 'python3-apt' if PY3 else 'python-apt'
    #local module creation
    m = AnsibleModule(
        argument_spec={},
    )
    if apt:
        install_python_apt(m, apt_pkg_name)
        assert apt



# Generated at 2022-06-11 06:42:45.866280
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sl = UbuntuSourcesList('module', 'add_ppa_signing_keys_callback')
    sl.add_ppa_signing_keys_callback = 'add_ppa_signing_keys_callback'
    sl.codename = 'codename'

    sldc = sl.__deepcopy__()

    assert sldc.module == 'module'
    assert sldc.add_ppa_signing_keys_callback == 'add_ppa_signing_keys_callback'
    assert sldc.codename == 'codename'
    assert not hasattr(sldc, 'files')


# Generated at 2022-06-11 06:42:57.581960
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    apt_pkg_name = 'python-apt'

    if PY3:
        apt_pkg_name = 'python3-apt'

    # Install python apt - needed for this module
    install_python_apt(module, apt_pkg_name)

    # Install python-apt - needed for this module
    # module.get_bin_path('apt-get')

    sourceslist = SourcesList(module)
    # Add new souces
    sourceslist.add_source('deb http://archive.canonical.com/ubuntu precise partner')

    # Create temp file
    fd, tmp_path = tempfile.mkstemp()
    files = sourceslist.files
    print (tmp_path)
    print (fd)
    files[tmp_path] = []

    # now test save
    sourceslist.save()

    # Check if

# Generated at 2022-06-11 06:44:41.762291
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import apt
    import module_utils.debops.apt
    obj = UbuntuSourcesList(module_utils.debops.apt.AnsibleModule({}))
    obj._add_valid_source = lambda l, c, f: obj.sources_list.append(l)
    obj.sources_list = []
    obj.add_source('ppa:foo/bar')
    assert obj.sources_list == ['deb http://ppa.launchpad.net/foo/bar/ubuntu ' + apt.distro.codename(True) + ' main']
    obj.add_source('deb http://ppa.launchpad.net/foo/bar/ubuntu ' + apt.distro.codename(True) + ' main')

# Generated at 2022-06-11 06:44:52.870766
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    apt_src = 'deb http://ppa.launchpad.net/chris-lea/redis-server/ubuntu trusty main'
    escaped_src = 'deb http://ppa.launchpad.net/chris-lea%2fredis-server/ubuntu trusty main'
    # create instance of class UbuntuSourcesList
    usl = UbuntuSourcesList({"params" : {"codename" : "trusty"}})
    # check that escaped ppa src is correct
    assert usl._expand_ppa('ppa:chris-lea%2fredis-server')[0] == escaped_src
    assert usl._expand_ppa('ppa:chris-lea/redis-server')[0] == escaped_src
    # check that ppa source has been found

# Generated at 2022-06-11 06:45:02.397523
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec=dict())

    # Create test sources.list
    fd, filename = tempfile.mkstemp(prefix=".test_SourcesList___iter__.sources_list.", text=True)
    f = os.fdopen(fd, 'w')
    f.write("""# source 1
deb http://domain.invalid/ubuntu bionic main restricted universe multiverse
deb http://domain.invalid/ubuntu bionic-updates main restricted universe multiverse
deb http://domain.invalid/ubuntu bionic-security main restricted universe multiverse

deb [arch=amd64] http://domain.invalid/ubuntu bionic stable # comment
# source 3
#source 4
deb-src http://domain.invalid/ubuntu bionic-updates main restricted universe multiverse

""")
    f.close()
   

# Generated at 2022-06-11 06:45:07.947027
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    '''
    Tests that the get_add_ppa_signing_key_callback function performs as expected
    '''
    class MockModule(object):
        def __init__(self):
            self.check_mode = False

        def run_command(self, command, check_rc=True):
            pass
    assert get_add_ppa_signing_key_callback(MockModule()) is not None



# Generated at 2022-06-11 06:45:10.894728
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    assert len(UbuntuSourcesList(object()).remove_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu  main")) is 0


# Generated at 2022-06-11 06:45:15.870618
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    for file in glob.iglob('%s/*.list' % sources._apt_cfg_dir('Dir::Etc::sourceparts')):
        assert os.path.isfile(file)
        sources.load(file)
    assert sources.files

# TODO: Add some unit tests for other methods of class SourcesList.



# Generated at 2022-06-11 06:45:25.056716
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Testing if method __deepcopy__ calls __init__ method with passed parameters
    class TestModule(object):  # pylint: disable=too-few-public-methods
        def __init__(self, params):
            self.params = params

    module = TestModule(params={'codename': 'precise'})
    sl = UbuntuSourcesList(module)

    # pylint: disable=protected-access
    assert sl.__deepcopy__() is not sl
    assert sl.__deepcopy__().module is not module
    assert sl.__deepcopy__().module.params is not module.params
    assert sl.__deepcopy__().module.params == module.params
    # pylint: enable=protected-access


# -----------------------------


# Generated at 2022-06-11 06:45:32.286332
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict())
    sl = UbuntuSourcesList(module)
    # Prepare sources.list

# Generated at 2022-06-11 06:45:41.521675
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class FakeModule():
        class FakeAnsibleModule():
            def atomic_move(self, tmp_path, filename):
                pass
            def _execute_module(self):
                pass
        FAKE_ANSIBLED_MODULE = FakeAnsibleModule()
        def __init__(self, files):
            self.files = files
    # Empty dict
    sl = SourcesList(FakeModule({}))
    assert sl.dump() == {}
    # One file

# Generated at 2022-06-11 06:45:42.145398
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass

# Generated at 2022-06-11 06:47:57.715038
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    """
    Run unit tests for SourcesList.dump()
    """
    import tempfile
    import uuid
    import copy
    import shutil
    # generate a temporary directory
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-11 06:48:06.668216
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import StringIO
    obj = SourcesList(AnsibleModuleMock())
    # Check that empty files will not be added to sources.
    obj.load('/etc/apt/sources.list')
    assert 'sources.list' not in obj.files
    # Check that disabled sources will be added to sources.
    with open('/etc/apt/sources.list.d/sources.list', 'w') as f:
        f.write('# deb http://archive.canonical.com/ubuntu hardy partner\n')

# Generated at 2022-06-11 06:48:13.934639
# Unit test for function main
def test_main():
    repo = {'repo': 'http://example.repo', 'state': 'present'}
    state = 'present'
    update_cache = True
    update_cache_retries = 5
    update_cache_retry_max_delay = 12
    changed = True
    diff = []

    # Create an instance of the AnsibleModule mock

# Generated at 2022-06-11 06:48:23.143306
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    testee = SourcesList(module)
    # Initialize test sources

# Generated at 2022-06-11 06:48:27.378280
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert UbuntuSourcesList(
        ansible_module,
        add_ppa_signing_keys_callback=lambda *args, **kwargs: None
    ).add_ppa_signing_keys_callback == ansible_module



# Generated at 2022-06-11 06:48:32.450983
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    source_list = UbuntuSourcesList(module)
    source_list.files = {'file.list': [(0, True, True, 'deb http://ppa.launchpad.net/mitch-seymour/saltstack/ubuntu bionic main', '')]}
    source_list.remove_source(' deb http://ppa.launchpad.net/mitch-seymour/saltstack/ubuntu bionic main')
    assert len(source_list.files['file.list']) == 0, "source list has not been removed"



# Generated at 2022-06-11 06:48:37.947522
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-11 06:48:42.933297
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    mod = AnsibleModule(argument_spec={})
    sl = SourcesList(mod)

    test_path = 'test_sources_list'
    test_data = '''
# sl_1
sl_1_1
sl_1_2
sl_1_3
# sl_1_4
'''

    # can't use mod.tmpdir, module is not running
    test_dir = tempfile.mkdtemp()
    test_file = os.path.join(test_dir, test_path)
    f = open(test_file, 'w')
    f.write(test_data)
    f.close()

    sl.load(test_file)

    for file, sources in sl.files.items():
        assert file == test_file
        assert len(sources) == 5

        # n,

# Generated at 2022-06-11 06:48:48.065202
# Unit test for function install_python_apt
def test_install_python_apt():
    use_check_mode = True
    py_apt_name = 'python-apt'
    apt_pkg_name = 'apt-get'
    rc, so, se = install_python_apt(mock_module, apt_pkg_name)
    assert rc == 255
    assert so == ''
    assert apt_pkg_name in se

    use_check_mode = False
    rc, so, se = install_python_apt(mock_module, apt_pkg_name)
    assert rc == 0
    assert so == ''
    assert se == ''
    assert py_apt_name in sys.modules


# Generated at 2022-06-11 06:48:51.002394
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    repo = UbuntuSourcesList(module)
    repo.add_source("deb http://example.com/repo some_source")
    assert repo.repos_urls == ["deb http://example.com/repo some_source"]