

# Generated at 2022-06-11 06:39:35.798430
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class FakeModule:
        def __init__(self):
            self.params = {'filename': 'filename'}
            self.atomic_move = None
            self.fail_json = None


    class FakeLine:
        def __init__(self):
            self.n = 0
            self.enabled = True
            self.source = 'deb http://apt.puppetlabs.com trusty puppet5'
            self.comment = None

    src = SourcesList(FakeModule())
    src.files = {'file': [FakeLine()]}
    src.files['file'][0].enabled = False
    src.files['file'][0].comment = 'comment'
    src.modify('file', 0, enabled=True)
    assert src.files['file'][0].enabled is True

# Generated at 2022-06-11 06:39:45.733434
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    from random import random, seed
    from pprint import pformat

    seed(42)


# Generated at 2022-06-11 06:39:56.829653
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Test valid sources
    test_list = SourcesList(AnsibleModule(argument_spec={}))
    test_list.load('/tmp/source_test')
    line_number = 0
    filename = '/tmp/source_test'
    test_list.modify(filename, line_number, enabled=True, source='deb http://archive.ubuntu.com/ubuntu trusty universe restricted', comment='test comment')
    assert test_list.dump() == {'/tmp/source_test': 'deb http://archive.ubuntu.com/ubuntu trusty universe restricted # test comment\n'}
    line_number = 1
    test_list.modify(filename, line_number, enabled=True)

# Generated at 2022-06-11 06:40:02.949649
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Test case: no changes required
    module = Mock()
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None

    # Test case: changes required and not in check mode
    module = Mock()
    module.check_mode = False
    add_ppa_signing_keys_callback = get_add_ppa_signing_key_callback(module)
    assert add_ppa_signing_keys_callback is not None
    assert call(command=['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '017ED316EFD06EAB']) == module.run_command.call_args


# Generated at 2022-06-11 06:40:15.874258
# Unit test for method dump of class SourcesList

# Generated at 2022-06-11 06:40:24.905332
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    modules = []
    param_names = []
    param_values = []
    if module.params:
        argspec = module.params
        args = argspec.keys()
        modules = {a: None for a in args}
        param_names = [a for a in args]
        param_values = [argspec[a] for a in args]
        logging.debug('param_names: %s', param_names)
        logging.debug('param_values: %s', param_values)
    module.fail_json = MagicMock(name='fail_json', side_effect=AnsibleFailJson)
    module.run_command = MagicMock(name='run_command', side_effect=AnsibleRunCommand)

# Generated at 2022-06-11 06:40:36.931593
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import sys
    import pdb
    class AnsibleModule_mock(object):
        class exit_json_mock(object):
            def __init__(self, params):
                self.params = params
            def __call__(self, failed=False, changed=False, msg='', **kwargs):
                print(repr(kwargs))
                if failed:
                    sys.exit(1)
                else:
                    sys.exit(0)
        class fail_json_mock(object):
            def __init__(self, params):
                self.params = params
            def __call__(self, failed=False, changed=False, msg='', **kwargs):
                print(repr(kwargs))
                if failed:
                    sys.exit(1)
                else:
                    sys.exit(0)



# Generated at 2022-06-11 06:40:46.712983
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # mock module
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.files = {}
    sl.files[os.path.realpath(__file__)] = [
        (0, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'comment'),
        (1, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', None),
        (2, True, True, 'deb http://archive.canonical.com/ubuntu hardy main', 'comment'),
        (3, True, False, 'deb http://archive.canonical.com/ubuntu hardy main', None),
    ]

    # enable, disable and preserve comments
    sl.modify(os.path.realpath(__file__), 0, enabled=True, comment='new comment')

# Generated at 2022-06-11 06:40:56.352983
# Unit test for function main
def test_main():
    from tempfile import mkstemp
    from ansible.module_utils.six import b
    from ansible.utils.hashing import checksum
    from ansible.modules.packaging.os import apt_repository
    from ansible.module_utils.aptsources import SourcesList
    import os
    import subprocess
    import tempfile

    apt_repository_path = None
    for path in os.environ['PATH'].split(':'):
        if os.path.exists(os.path.join(path, 'apt-repository')):
            apt_repository_path = os.path.join(path, 'apt-repository')
            break
    if apt_repository_path is None:
        raise Exception("Unable to find apt-repository in $PATH")

    temp

# Generated at 2022-06-11 06:41:07.087212
# Unit test for function main

# Generated at 2022-06-11 06:41:58.142494
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-11 06:41:59.396716
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(None) is None



# Generated at 2022-06-11 06:42:05.082990
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec=dict())
    module.params['filename'] = 'testfilename.list'
    module.params['source_list'] = 'deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted'
    sl = SourcesList(module)
    sl.add_source(module.params['source_list'])
    sl.save()


# Generated at 2022-06-11 06:42:09.664995
# Unit test for function main

# Generated at 2022-06-11 06:42:20.043233
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    lines = [
        'deb http://archive.canonical.com/ubuntu precise partner',
        '# deb-src http://archive.canonical.com/ubuntu precise partner',
        '',
        '### ppa:nginx/stable',
        'deb http://ppa.launchpad.net/nginx/stable/ubuntu precise main'
    ]

    sl = SourcesList(module)
    for line in lines:
        sl.load('/tmp/test.list')
        sl.files['/tmp/test.list'].append((len(sl.files['/tmp/test.list']), True, True, line, ''))

    # Check that valid source will be returned.

# Generated at 2022-06-11 06:42:20.993408
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    UbuntuSourcesList({},lambda x: None)



# Generated at 2022-06-11 06:42:32.563102
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class Module(object):
        def fail_json(self, msg=None, **kwargs):
            print(kwargs)
            raise Exception(msg)


# Generated at 2022-06-11 06:42:35.760865
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule('apt_repository')
    install_python_apt(module, 'python-apt')



# Generated at 2022-06-11 06:42:39.654808
# Unit test for function install_python_apt
def test_install_python_apt():
    import sys
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-11 06:42:51.100108
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    """
    Test __iter__ method of class SourcesList
    """
    # read sources.list.d
    sources_list_d_files = glob.iglob('%s/*.list' % SourcesList._apt_cfg_dir('Dir::Etc::sourceparts'))
    # read sources.list if it exists
    sources_list_file_path = SourcesList._apt_cfg_file('Dir::Etc::sourcelist')
    if os.path.isfile(sources_list_file_path):
        sources_list_d_files.append(sources_list_file_path)
    sources_list = SourcesList(None)
    for file in sources_list_d_files:
        sources_list.load(file)
    assert isinstance(sources_list, SourcesList)

# Generated at 2022-06-11 06:43:32.223694
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    source_lines = [
        "deb http://ppa.launchpad.net/test1/ppa/ubuntu xenial main",
        "deb http://ppa.launchpad.net/test2/ppa2/ubuntu precise main",
        "deb http://ppa.launchpad.net/test3/ppa3/ubuntu trusty main",
        "deb http://ppa.launchpad.net/test4/ppa4/ubuntu Yakkety main",
        "deb http://ppa.launchpad.net/test5/ppa5/ubuntu Yakkety main"
    ]
    module = AnsibleModule(argument_spec={
        'codename': dict(type='str', default='xenial'),
        'mode': dict(type='str', default='0644')
    })
    module.params['mode'] = '0600'
    ppa_to_re

# Generated at 2022-06-11 06:43:42.005427
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})

    # Create test file
    d = tempfile.mkdtemp()
    filename = os.path.join(d, 'sources.list')
    with open(filename, 'w') as f:
        f.write('deb http://example.com/ubuntu/ xenial main\n')
        f.write('deb http://example.com/ubuntu/ xenial universe\n')
        f.write('# deb http://example.com/ubuntu/ xenial multiverse\n')
        f.write('invalid line\n')
        f.write('deb http://example.com/ubuntu/ xenial restricted\n')

    sl = SourcesList(module)
    enabled_count = 0

# Generated at 2022-06-11 06:43:52.069347
# Unit test for function main
def test_main():
    argv = ['/foo/bar', 'repository', 'state']

# Generated at 2022-06-11 06:43:59.821460
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible_collections.ansible.debian.tests.unit.compat import unittest
    from ansible_collections.ansible.debian.tests.unit.compat.mock import create_autospec, patch
    from ansible_collections.ansible.debian.plugins.modules import apt_sources_list

    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass

    module = create_autospec(apt_sources_list)
    module.exit_json = create_autospec(module.exit_json, side_effect=AnsibleExitJson)
    module.fail_json = create_autospec(module.fail_json, side_effect=AnsibleFailJson)

    sources_before = {}
    sources_after = {}

# Generated at 2022-06-11 06:44:04.820643
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock(check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None

    module = Mock(check_mode=False)
    callback = get_add_ppa_signing_key_callback(module)
    command = Mock()
    callback(command)
    module.run_command.assert_called_with(command, check_rc=True)



# Generated at 2022-06-11 06:44:09.238406
# Unit test for function main
def test_main():
    if HAVE_PYTHON_APT:
        sourceslist = UbuntuSourcesList(module, add_ppa_signing_keys_callback=get_add_ppa_signing_key_callback(module))
        assert sourceslist.dump()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-11 06:44:17.761978
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Create UbuntuSourcesList object
    module = AnsibleModule(argument_spec={})
    ubuntusourceslist = UbuntuSourcesList(module)

    # default filename
    ubuntusourceslist.add_source('ppa:foo/ppa')
    assert ubuntusourceslist.suggested_file == None

    # specified filename
    ubuntusourceslist.add_source('ppa:foo/bar', '', 'foo.bar.list')
    assert ubuntusourceslist.suggested_file == 'foo.bar.list'

    # invalid ppa
    with pytest.raises(InvalidSource):
        ubuntusourceslist.add_source('ppa:foo/')

# Generated at 2022-06-11 06:44:23.207291
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    file = "/tmp/testapt"
    sl = SourcesList(None)
    sl.files = {file: [(1, True, True, "source", ""), (2, True, True, "source2", ""), (3, True, True, "source", "")]}
    sl.save()
    # Check that the file has been saved
    f = open(file, 'r')
    assert(len(f.readlines()) == 3)
    f.close()



# Generated at 2022-06-11 06:44:33.746852
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # test that the callback is None when check_mode is True
    module = MagicMock()
    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None
    # test that the callback added a key to apt
    module.check_mode = False
    module.run_command = MagicMock()
    callback = get_add_ppa_signing_key_callback(module)
    expected_command = ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'FAKE_KEY']
    callback(expected_command)
    module.run_command.assert_called_once_with(expected_command, check_rc=True)


# Generated at 2022-06-11 06:44:45.664325
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList()
    sl.files = {'file_a': [(0, True, True, 's1', 'comment1'), (1, False, False, 's2', 'comment2'), (2, True, True, 's3', 'comment3')]}
    sl.modify('file_a', 2, source='new_source')
    assert sl.files['file_a'] == [(0, True, True, 's1', 'comment1'), (1, False, False, 's2', 'comment2'), (2, True, True, 'new_source', 'comment3')]

    sl.modify('file_a', 2, source=None)

# Generated at 2022-06-11 06:45:25.940077
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    result = SourcesList._parse('# #Comment for unit tests', raise_if_invalid_or_disabled=True)
    assert result == (False, False, '', '#Comment for unit tests')

    result = SourcesList._parse('deb http://example.com/debian stable contrib', raise_if_invalid_or_disabled=True)
    assert result == (True, True, 'deb http://example.com/debian stable contrib', '')

    result = SourcesList._parse('# deb http://example.com/debian unstable', raise_if_invalid_or_disabled=True)
    assert result == (False, False, '', 'deb http://example.com/debian unstable')


# Generated at 2022-06-11 06:45:32.921949
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import tempfile
    tmpfile = tempfile.NamedTemporaryFile(mode='w+')


# Generated at 2022-06-11 06:45:39.739360
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import distribution
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.urls import fetch_url

    def _fetch_url(module, url, headers=None):
        return "works", {}

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-11 06:45:41.932212
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    assert UbuntuSourcesList(MagicMock()).add_source("deb http://ppa.launchpad.net/foo/bar/ubuntu baz main") == None


# Generated at 2022-06-11 06:45:50.836532
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    m = AnsibleModule(argument_spec={})
    s = SourcesList(m)
    with open('testfile', 'w') as f:
        f.write("# This is an interesting comment\n")
        f.write("deb http://archive.canonical.com/ubuntu lucid partner\n")
        f.write("deb http://archive.canonical.com/ubuntu karmic partner\n")
        f.write("deb http://archive.canonical.com/ubuntu hardy partner\n")
        f.write("# this is not\n")
    s.load('testfile')
    s.remove_source("# This is an interesting comment")
    s.remove_source("deb http://archive.canonical.com/ubuntu hardy partner")
    s.remove_source("# this is not")
    s.save()


# Generated at 2022-06-11 06:45:59.991123
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    m = AnsibleModule(
        argument_spec={}
    )
    sl = SourcesList(m)
    os.mkdir("/tmp/sl")
    os.mkdir("/tmp/sl/d")

# Generated at 2022-06-11 06:46:08.784904
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(None)
    sl.load('tests/test_sources.list')
    sl.remove_source('deb http://www.test.domain/test/test1 precise main')
    assert len(sl.files['tests/test_sources.list']) == 2
    assert sl.files['tests/test_sources.list'][0][3] == 'deb http://www.test.domain/test/test2 precise main'
    assert sl.files['tests/test_sources.list'][1][3] == 'deb http://www.test.domain/test/test3 precise main'
    sl = SourcesList(None)
    sl.load('tests/test_sources.list')
    sl.remove_source('deb http://www.test.domain/test/test4 precise main')

# Generated at 2022-06-11 06:46:18.269676
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    import mock
    import pytest

    class MockModule(object):
        class ModuleFailException(Exception):
            pass

        class AtomicMoveException(Exception):
            pass

        class MockAptPkg(object):
            class Config(object):
                @staticmethod
                def FindFile(file):
                    return '/'

            @staticmethod
            def Config(file):
                return MockModule.MockAptPkg.Config()

            @staticmethod
            def ConfigDump():
                return {
                    'Dir::Etc::SourceList': '/'
                }

        @staticmethod
        def fail_json(msg, **kwargs):
            raise MockModule.ModuleFailException(msg)

        @staticmethod
        def atomic_move(tmp_path, filename):
            raise MockModule.AtomicMoveException()


# Generated at 2022-06-11 06:46:27.828920
# Unit test for function main

# Generated at 2022-06-11 06:46:36.550383
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import io
    import unittest
    from unittest.mock import patch

    class TestSourcesListRemoveSource(unittest.TestCase):
        """ Test SourcesList.remove_source with following content:
            deb http://archive.canonical.com/ubuntu hardy partner
            deb-src http://archive.canonical.com/ubuntu hardy partner
            # deb http://archive.canonical.com/ubuntu hardy partner
            # deb-src http://archive.canonical.com/ubuntu hardy partner
        """
        def setUp(self):
            self.sourceslist = SourcesList(None)

# Generated at 2022-06-11 06:48:43.518901
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert callable(get_add_ppa_signing_key_callback(AnsibleModule(dict())))
    assert get_add_ppa_signing_key_callback(AnsibleModule(dict())).__self__ is None
    assert get_add_ppa_signing_key_callback(AnsibleModule(dict())).__closure__ is None

# Generated at 2022-06-11 06:48:50.602937
# Unit test for function main
def test_main():
    # Create a mock module to pass into modules.apt_repository.main
    mock_module = MagicMock(exit_json=lambda x: True, exit_json=lambda x, y: True, fail_json=lambda x: False, debug=lambda x: True)
    # Set up the parameters
    mock_module.params = {'repo': 'test repo', 'filename': 'test filename', 'state': 'test state', 'update_cache': True, 'codename': 'test codename'}
    mock_module._diff = True

    # set up the temp dir
    temp_dir = tempfile.mkdtemp()
    mock_sources_list_path = os.path.join(temp_dir, 'sources.list')

    # set up the sources list

# Generated at 2022-06-11 06:48:52.573233
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    import copy
    module = Mock()
    sl = UbuntuSourcesList(module)
    assert sl is not copy.deepcopy(sl)
