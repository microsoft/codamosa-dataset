

# Generated at 2022-06-11 06:39:30.976246
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({'check_mode': False})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None

    module = AnsibleModule({'check_mode': True})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None



# Generated at 2022-06-11 06:39:42.194174
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Test data for yaml file
    yamlfile = '''# Test file
# This file is a comment
deb [ arch=amd64 ] http://download.virtualbox.org/virtualbox/debian xenial contrib
deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu precise main
ppa:ansible/ansible
ppa:webupd8team/java
'''
    # Test data for parsed yaml file
    parsed_yaml = {'deb [ arch=amd64 ] http://download.virtualbox.org/virtualbox/debian xenial contrib': '', 'deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu precise main': '', 'ppa:ansible/ansible': '', 'ppa:webupd8team/java': ''}

    # Test data for sources to be

# Generated at 2022-06-11 06:39:54.572607
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import os
    import shutil
    import sys

    class Module(object):
        def fail_json(self, msg):
            sys.stderr.write(msg + '\n')

        @staticmethod
        def atomic_move(old, new):
            shutil.move(old, new)

        def set_mode_if_different(self, name, mode, changed):
            pass

    path = tempfile.mkdtemp()

# Generated at 2022-06-11 06:40:01.778679
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Create dummy source file
    source_file = tempfile.NamedTemporaryFile(prefix="ansible-apt_repository-", mode='w', delete=False).name

# Generated at 2022-06-11 06:40:14.878892
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    os.makedirs(os.path.join(test_dir, 'sourceparts'))
    os.makedirs(os.path.join(test_dir, 'sourced.list.d'))

    apt_pkg.Config.Set('Dir::Etc::sourcelist', os.path.join(test_dir, 'sources.list'))
    apt_pkg.Config.Set('Dir::Etc::sourceparts', os.path.join(test_dir, 'sourceparts'))

    module_mock = MagicMock()
    sl = SourcesList(module_mock)


# Generated at 2022-06-11 06:40:15.271532
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-11 06:40:21.542744
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = Mock()
    module.params = {}
    module.params['codename'] = 'codename'
    module.params['key_id'] = 'key_id'
    module.params['key_server'] = 'key_server'
    module.run_command.return_value = (0, '', '')
    module.check_mode = False
    module.no_log = False
    module.warn = Mock()
    module.fail_json = Mock()

    add_ppa_signing_keys_callback = Mock()

    a = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)

    assert(a.__deepcopy__().module.params == a.module.params)

# Generated at 2022-06-11 06:40:22.665651
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt() is None



# Generated at 2022-06-11 06:40:34.839483
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec=dict())
    module.params['codename'] = "xenial"
    sl = UbuntuSourcesList(module)
    assert [] == sl.repos_urls
    sl.add_source("deb http://mirror.test.com/ubuntu xenial main universe multiverse")
    assert ["deb http://mirror.test.com/ubuntu xenial main universe multiverse"] == sl.repos_urls
    sl.add_source("ppa:webupd8team/java")
    assert ["deb http://mirror.test.com/ubuntu xenial main universe multiverse", "deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main"] == sl.repos_urls
    # when a deb line is in the sources it will still be present
    sl.add

# Generated at 2022-06-11 06:40:44.766285
# Unit test for function main
def test_main():
    import os
    import tempfile

    # Test for function aptsources_distro.Distribution
    def test_Distribution():
        from ansible.module_utils.aptlib.distro import Distribution
        from ansible.module_utils.aptlib.distro import CodenameError
        from ansible.module_utils.aptlib.distro import CodenameUriFormatError
        from ansible.module_utils.aptlib.distro import CodenameUriError
        from ansible.module_utils.aptlib.distro import MirrorError

        dist = Distribution()

        assert dist.id == 'debian'
        assert dist.version == 'stretch'
        assert dist.codename == 'stretch'
        assert dist.release == 'debian'

# Generated at 2022-06-11 06:41:16.127627
# Unit test for function main
def test_main():
    sourceslist = UbuntuSourcesList(module, add_ppa_signing_keys_callback=get_add_ppa_signing_key_callback(module))
    test_repo = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'
    sourceslist.add_source(test_repo)

# Generated at 2022-06-11 06:41:21.414828
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})

    sl = SourcesList(module)

    default_file = sl._apt_cfg_file('Dir::Etc::sourcelist')
    fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % os.path.basename(default_file),
                                    dir=os.path.dirname(default_file))

    f = os.fdopen(fd, 'w')
    f.write("""\
deb-src http://archive.canonical.com/ubuntu hardy partner
deb http://archive.canonical.com/ubuntu hardy partner
# deb http://archive.canonical.com/ubuntu hardy partner
deb-src http://archive.canonical.com/ubuntu hardy partner
""")
    f.close()

    sl.load(tmp_path)

# Generated at 2022-06-11 06:41:33.944874
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import unittest

    class _Module(object):
        def fail_json(self, msg):
            raise Exception(msg)

    class _SourcesList(UbuntuSourcesList):
        def add_ppa_signing_keys_callback(self, command):
            pass

    class TestUbuntuSourcesList(unittest.TestCase):
        def setUp(self):
            self.module = _Module()
            self.sources_list = _SourcesList(self.module)

# Generated at 2022-06-11 06:41:35.263017
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(MockModule()) is None
    assert get_add_ppa_signing_key_callback(MockModule(check_mode=False)) is not None



# Generated at 2022-06-11 06:41:46.051866
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    lines = ['# deb http://debian.mirror.iweb.ca/debian/ jessie main',
             'deb http://debian.mirror.iweb.ca/debian/ jessie main',
             '# deb-src http://mirrors.kernel.org/debian/ jessie main',
             '''# deb http://debian.mirror.iweb.ca/debian/ jessie main # This is a comment''',
             '''deb http://debian.mirror.iweb.ca/debian/ jessie main # This is a comment''',
             '',
             '# Something totally different',
             'Something totally different',
             'deb http://debian.mirror.iweb.ca/debian/ jessie main # This is a comment']

    filename = tempfile.mktemp()

# Generated at 2022-06-11 06:41:57.120405
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    ''' Unit test for method dump of class SourcesList'''
    module = AnsibleModule({'debug': False})
    filename = os.path.join(tempfile.gettempdir(), 'apt-repository-test.list')
    try:
        os.remove(filename)
    except OSError:
        pass

    with open(filename, 'w') as f:
        f.write("""#hello world
deb http://test.test/test
deb-src http://test.test/test
# not a valid source
#deb http://test.test/test2
""")
    sourceslist = SourcesList(module)
    sourceslist.load(filename)

# Generated at 2022-06-11 06:42:06.990609
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    module.params['filename'] = 'test.list'
    module.params['state'] = 'present'
    module.params['repo'] = 'deb http://example.com/repo distro component'
    sources_list = SourcesList(module)
    sources_list.add_source(module.params['repo'], '')
    sources_list.save()
    sources_list2 = SourcesList(module)
    sources_list2.load('/etc/apt/sources.list.d/test.list')
    assert sources_list.dump() == sources_list2.dump()
    os.remove('/etc/apt/sources.list.d/test.list')
    # Raises ValueError if not initialized yet

# Generated at 2022-06-11 06:42:18.498827
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    from collections import namedtuple
    # Create dummy temporary directory
    tmpdir = tempfile.mkdtemp()
    SourcesList = namedtuple('SourcesList', ['default_file', 'files', '_apt_cfg_dir'])
    apt_cfg_dir = {'Dir::Etc::sourcelist': tmpdir + '/sourcelist',
                   'Dir::Etc::sourceparts': tmpdir + '/sourceparts'}
    module = namedtuple('Module', ['atomic_move', 'fail_json', 'params', 'set_mode_if_different'])
    apt_repo_file = '%s/test.list' % (tmpdir + '/sourceparts')

# Generated at 2022-06-11 06:42:20.944475
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec=dict())
    x=SourcesList(module)
    x.load('/etc/apt/sources.list')

# Generated at 2022-06-11 06:42:32.509668
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    """
    Test add_source() of class SourcesList
    """
    import tempfile
    import os.path
    import shutil
    class FakeModule(object):
        def __init__(self):
            self.params = {
                'filename': None,
                'from_archive': True,
                'from_dist': False,
                'from_trusted': False,
                'from_ppa': False,
                'from_src': False,
                'key_id': '',
                'key_server': '',
                'mode': '644',
                'repo': 'deb http://archive.ubuntu.com/ubuntu trusty main',
                'state': 'present',
                'update_cache': False,
            }
            self.fail_json = lambda *args, **kwargs: None

# Generated at 2022-06-11 06:43:38.812947
# Unit test for function install_python_apt
def test_install_python_apt():
    # TODO: Write unit tests
    return True



# Generated at 2022-06-11 06:43:48.857729
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sources_list = SourcesList(module)

    test_file = os.path.join('/tmp/', 'test.list')
    with open(test_file, 'w') as f:
        f.write('#deb [option] http://test.org/test /\ndeb-src [option] http://test.org/test /\nnot-valid-line')

    sources_list.load(test_file)

    expected = {
        test_file: [
            (0, False, True, 'deb [option] http://test.org/test /', ''),
            (1, True, True, 'deb-src [option] http://test.org/test /', ''),
            (2, False, True, 'not-valid-line', '')
        ]
    }


# Generated at 2022-06-11 06:43:57.190182
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    class KodiakModule():

        def __init__(self):
            self.params = {}

    ppa_count = 0
    for line in open("/etc/apt/sources.list"):
        if line.startswith('ppa:'):
            ppa = line.split('#')[0].strip()

            kodiak_module = KodiakModule()
            sources_list = UbuntuSourcesList(kodiak_module)

            sources_list.add_source(ppa)
            sources_list.remove_source(ppa)

            ppa_count += 1

    assert UbuntuSourcesList.LP_API
    ppa_count_2 = 0
    for line in open("/etc/apt/sources.list"):
        if line.startswith('ppa:'):
            ppa_count_2 += 1


# Generated at 2022-06-11 06:44:00.034705
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_get_path = module.get_bin_path('apt-get')
    rc, so, se = module.run_command([apt_get_path, 'update'])


# Generated at 2022-06-11 06:44:10.003999
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    fake_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    usl = UbuntuSourcesList(fake_module)
    assert len(usl.dump()) == 0
    usl.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foobar.list')
    assert len(usl.dump()) == 1
    assert len(usl.dump()['/etc/apt/sources.list.d/foobar.list'].splitlines()) == 1
    usl.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foobar.list')
    assert len(usl.dump()) == 1

# Generated at 2022-06-11 06:44:19.691972
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Test 1: Src files before and after are the same, no new files were added,
    #         sourceslist_before should be empty and neither before nor after
    #         should be modified.
    sources_before = {
        '/etc/apt/sources.list': '# comment\n# comment\n\n',
        '/etc/apt/sources.list.d/unattended-upgrades.list': '# comment\n# comment\n\n'
    }
    sources_after = {
        '/etc/apt/sources.list': '# comment\n# comment\n\n',
        '/etc/apt/sources.list.d/unattended-upgrades.list': '# comment\n# comment\n\n'
    }
    sourceslist_before = SourcesList(module)
    revert_

# Generated at 2022-06-11 06:44:29.582073
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Need a mock from module 'apt'
    # Check if the method `remove_source` works as expected
    sources_list = UbuntuSourcesList(module)
    line = 'deb http://ppa.launchpad.net/saltstack/salt/ubuntu trusty main'
    # One case that the source is not in a new file
    sources_list._add_valid_source(source=line, comment="ppa for saltstack", file=None)
    # One case that the source is in a new file
    file_name = '/etc/apt/sources.list.d/saltstack.list'
    sources_list._add_valid_source(source=line, comment="ppa for saltstack", file=file_name)
    sources_list.remove_source(line=line)

# Generated at 2022-06-11 06:44:41.219902
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import sys

    # Mock the load method to make it return a list of sources

# Generated at 2022-06-11 06:44:52.414849
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(AnsibleModule(argument_spec={}, bypass_checks=True))
    # normal case
    line = 'deb-src http://archive.canonical.com/ubuntu hardy partner'
    sl.add_source(line)
    sl.remove_source(line)
    assert not [s for s in sl]
    # ignore disabled sources
    line = '# deb http://archive.example.com/ubuntu trusty-unstable universe'
    sl.add_source(line)
    sl.remove_source(line)
    assert not [s for s in sl]
    # disable source
    line = 'deb http://archive.example.com/ubuntu trusty-unstable universe'
    sl.add_source(line)
    sl.remove_source('# %s' % line)

# Generated at 2022-06-11 06:45:01.530583
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    '''
    This test should be run with molecule
    1. run "sudo pip install -r test-requirements.txt"
    2. run "molecule test --scenario-name sources_list"
    '''
    import pytest
