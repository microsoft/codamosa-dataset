

# Generated at 2022-06-11 06:39:32.752791
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Import module and create object
    module = AnsibleModule(argument_spec={})
    repository_list = SourcesList(module)

    # Prepare sources to test
    sources = ('deb http://example.com/ubuntu/dists/trusty/main', 'deb http://example.com/ubuntu/dists/trusty/not-main', 'deb http://example.com/ubuntu/dists/xenial/main')
    file = '/tmp/test.list'

    # Test with empty file
    repository_list.modify(file, 0)

    # Add sources and test
    for i, line in enumerate(sources):
        repository_list._add_valid_source(line, '', file)
        repository_list.modify(file, i, False, sources[i]+"_modified")
    repository_list.save()

# Generated at 2022-06-11 06:39:43.681444
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.six import StringIO
    import ansible.module_utils.apt_pkg

    # suppress warning messages
    ansible.module_utils.apt_pkg.config['quiet'] = '1'
    ansible.module_utils.apt_pkg.config.clear()
    ansible.module_utils.apt_pkg.init_config()

    class FakeModule(object):
        def fail_json(self, msg):
            raise AssertionError(msg)

        atomic_move = staticmethod(os.rename)

        def set_mode_if_different(self, filename, mode, changed):
            assert mode == DEFAULT_SOURCES_PERM
            assert changed is False

    class FakeDistro(object):
        def __init__(self):
            self.codename = 'focal'

# Generated at 2022-06-11 06:39:55.824952
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec=dict(
        test=dict(type='bool', required=True),
    ))
    if module.params['test']:
        # Construct object for testing
        sources = SourcesList(module)
        sources.files = {
            '/etc/apt/sources.list': [
                (0, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic main', ''),
                (1, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic-security main', ''),
                (2, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic-updates main', ''),
            ],
        }

        # Test method
        result = [i for i in sources]

# Generated at 2022-06-11 06:40:02.504333
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule

    # Note: This test is not marked as 'test_add_ppa_signing_key_callback' because of the
    # potential for a collision with a future function of that name
    def test_callback(command):
        print('Running command: %s' % command)

    module = AnsibleModule(
        argument_spec=dict(
            ppa="string"
        )
    )

    # the callback should be None in check mode
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None

    module.check_mode = False
    assert test_callback == get_add_ppa_signing_key_callback(module)


# - - - - - - - - - - - - - - - - - -

# Generated at 2022-06-11 06:40:15.540560
# Unit test for constructor of class SourcesList
def test_SourcesList():
    '''
    Test SourcesList class - constructor.
    '''
    class TestAnsibleModule(object):
        '''
        Test class for AnsibleModule.
        '''
        def fail_json(self, **kwargs):
            '''
            Fail with supplied arguments.
            '''
            raise ValueError(kwargs.get('msg', 'Test Failed'))

        def get_bin_path(self, _):
            '''
            Return empty path.
            '''
            return ''

        def run_command(self, args):
            '''
            Return success for apt-get update.
            '''
            if args[0].endswith('apt-get') and args[1] == 'update':
                return 0, '', ''
            return 1, '', ''


# Generated at 2022-06-11 06:40:24.712430
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    # Create temporary file
    (fd, filename) = tempfile.mkstemp()
    # Write to file
    f = os.fdopen(fd, 'w')
    f.write('deb http://example.com/debian stable main')
    f.flush()
    f.close()
    # Create SourcesList
    sl = SourcesList(module)
    # Add file to SourcesList object
    sl.load(filename)
    # Check file is loaded
    assert sl.files[filename] == [(0, True, True, 'deb http://example.com/debian stable main', '')]
    # Modify file
    sl.modify(filename, 0, comment=sl.files[filename][0][4] + ' (modified by ansible)')
    # Check file is modified
    assert sl.files

# Generated at 2022-06-11 06:40:32.728113
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = FakeModule()
    module.params = {'filename': 'ppa_source.list'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    assert sources_list.files['/etc/apt/sources.list.d/ppa_source.list'][0][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'



# Generated at 2022-06-11 06:40:42.048671
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={
        'mode': {
            'default': None,
            'type': 'int',
        },
    })
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu trusty partner')
    for filename, n, enabled, source, comment in sources_list:
        assert source == 'deb http://archive.canonical.com/ubuntu trusty partner', \
            'Failed to add valid source'
        assert not enabled, 'Failed to add disabled source'
        return

    raise AssertionError('Failed to find valid source %s in %s' % (source, sources_list.files.keys()))



# Generated at 2022-06-11 06:40:50.320392
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    mocked_module = MagicMock()
    mocked_module.params = dict(codename=None)
    mocked_apt_pkg = MagicMock()
    mocked_apt_pkg.config.find_file = MagicMock(return_value='/etc/apt/sources.list')
    mocked_apt_pkg.config.find_dir = MagicMock(return_value='/etc/apt/sources.list.d')
    mocked_sources_list = UbuntuSourcesList(mocked_module)
    mocked_sources_list._suggest_filename = MagicMock(return_value='other.list')
    mocked_sources_list._parse = MagicMock(side_effect=lambda x, y: (True, True, x, ''))


# Generated at 2022-06-11 06:41:00.824285
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    fake_module = type('Module', (object,), {
        'fail_json': lambda msg: 'module failed'
    })()

    sources_list = SourcesList(fake_module)
    sources_list.add_source(line='deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source(line='deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source(line='deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source(line='deb http://archive.canonical.com/ubuntu hardy partner')

    for filename, sources in sources_list.files.items():
        if sources:
            print(filename)

# Generated at 2022-06-11 06:41:37.601735
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class TestModule(object):
        param1 = None
        _params = None
        def __init__(self, filename=None, dir=None):
            self.param1 = filename
            self._params = { 'filename': filename, 'dir': dir}

        def params(self):
            return self._params

        def fail_json(self, msg):
            print(msg)

        def atomic_move(self, src, dest):
            print("%s -> %s " % (src, dest))

        def set_mode_if_different(self, path, mode, follow):
            print("%s %s %s" % (path, mode, follow))

    import io
    import json
    import sys


# Generated at 2022-06-11 06:41:48.315768
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    test_module = AnsibleModule(argument_spec=dict(
        codename=dict(default='xenial')
    ))

    sl = UbuntuSourcesList(test_module)

    # Add comment only
    sl.add_source('# this is a comment', comment='test comment')
    assert len(sl.files) == 1
    for filename, sources in sl.files.items():
        assert len(sources) == 1
        parsed_comment = sources[0]
        assert parsed_comment == (0, False, False, '# this is a comment', 'test comment')
        break

    # Add simple source
    sl.add_source('deb http://ppa.launchpad.net/testppa/testppa2/ubuntu xenial main', comment='test comment')
    assert len(sl.files) == 2

# Generated at 2022-06-11 06:41:59.151765
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, msg):
            self.fail_json_called = True
            self.fail_json_msg = msg

    class MockSourcesList(UbuntuSourcesList):
        def _get_ppa_info(self, owner_name, ppa_name):
            return {
                'signing_key_fingerprint': '0x00FAKEFINGERPRINT0x00'
            }

        def run_command(self, cmd, check_rc=True):
            if cmd == 'apt-key export 0x00FAKEFINGERPRINT0x00':
                return 0, '', "gpg: no key with ID '0x00FAKEFINGERPRINT0x00'"

# Generated at 2022-06-11 06:42:04.806473
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({"repo": "repo-not-in-sourceslist",
        "state": "present",
        "update_cache": True })
    # Setup variables used in the main method
    # Each of these variables is assigned a value
    # prior to calling the main method
    try:
        tmp_fd, tmp_path = tempfile.mkstemp()
        with open(tmp_path, 'w') as f:
            f.write("#")
    except (IOError, AttributeError) as e:
        module.fail_json(msg=to_native(e))
    old_path = os.environ.get("PATH", "")
    curr_exe = os.path.realpath(sys.executable)

# Generated at 2022-06-11 06:42:16.755109
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Create test instance
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

    # Create temporary file
    fd, tmp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    # Write sources to temporary file
    f.write('deb https://foobar.baz main\n')
    f.write('# deb https://foobar.baz main\n')
    f.write('\n')
    f.write('\n')
    f.write('deb https://foobar.baz main')
    f.close()

    # Add temporary file to instance
    sources_list.load(tmp_path)
    dump = sources_list.dump()

    # Remove temporary file
    os.remove(tmp_path)

    #

# Generated at 2022-06-11 06:42:19.667732
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line = "deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main"
    source = SourcesList(line)
    source.remove_source(line)

# Generated at 2022-06-11 06:42:30.990981
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import sys
    import pytest
    class MockModule(object):
        class Params(object):
            state= 'present'
        def __init__(self):
            self.params = MockModule.Params()
        def fail_json(self, msg):
            print(msg)
            sys.exit(-1)
        def get_bin_path(self, program):
            pass
        def atomic_move(self, src, dest):
            pass

# Generated at 2022-06-11 06:42:42.775000
# Unit test for function main

# Generated at 2022-06-11 06:42:54.597596
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    results = []
    curpath = os.path.dirname(os.path.abspath(__file__))
    apt_config_orig = SourcesList._apt_cfg_file
    os.chmod = results.append

# Generated at 2022-06-11 06:43:04.925409
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sourcelist = SourcesList(module)

    sourcelist.add_source('deb http://deb.debian.org/debian jessie-backports main', comment='Backports')
    sourcelist.add_source('deb-src http://deb.debian.org/debian jessie-backports main', comment='Debian')

    file = 'http___deb.debian.org_debian.list'
    assert file in sourcelist.files
    assert len(sourcelist.files[file]) == 2
    assert sourcelist.files[file][0][:4] == (0, True, True, 'deb http://deb.debian.org/debian jessie-backports main')
    assert sourcelist.files[file][0][4] == 'Backports'

# Generated at 2022-06-11 06:43:38.630245
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # TODO: Add appropriate unit tests. This will probably involve working
    # out how to mock the apt_pkg and apt modules.
    assert True == False



# Generated at 2022-06-11 06:43:48.724805
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sl = UbuntuSourcesList(None)
    sl._get_ppa_info = lambda x, y: {'signing_key_fingerprint': 'fingerprint'}

    def _key_already_exists(key_fingerprint):
        if key_fingerprint == 'fingerprint':
            return False
        return True

    sl._key_already_exists = _key_already_exists

    sl.add_source('ppa:mahmoh/ppa', 'mahmoh/ppa', 'mahmoh')
    sl.add_source('ppa:', 'ppa')

    assert len(sl.files) == 1
    assert list(sl.files.keys())[0] == '/etc/apt/sources.list.d/mahmoh.list'

# Generated at 2022-06-11 06:43:57.140204
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    obj = SourcesList(AnsibleModule)
    obj.module.params = {'filename': 'aptly-repo-publish'}
    obj.files = {'/etc/apt/sources.list.d/aptly-repo-publish.list': [(0, True, True, 'deb [arch=amd64] http://aptly.zafar.se/public/ trusty main', ''), (1, True, True, 'deb-src [arch=amd64] http://aptly.zafar.se/public/ trusty main', '')]}
    obj.remove_source('deb [arch=amd64] http://aptly.zafar.se/public/ trusty main')

# Generated at 2022-06-11 06:43:58.610411
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # TODO: unit test
    pass


# Generated at 2022-06-11 06:44:08.492673
# Unit test for method save of class SourcesList

# Generated at 2022-06-11 06:44:18.428658
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Test if SourcesList.remove_source() works properly.
    """
    # The first test is a line to remove that exists in a file that already has sources
    test1_line = 'deb http://archive.ubuntu.com/ubuntu xenial-backports main restricted universe multiverse'
    test1_file = open('test1_file.list', 'w')

# Generated at 2022-06-11 06:44:23.771785
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_list = ['deb http://archive.canonical.com/ubuntu saucy partner',
                 'deb-src http://archive.canonical.com/ubuntu saucy partner',
                 'deb http://archive.canonical.com/ubuntu saucy partner',
                 'deb http://archive.canonical.com/ubuntu saucy partner',
                 'deb http://archive.canonical.com/ubuntu saucy partner']
    sources_list = SourcesList()
    for line in test_list:
        sources_list.add_source(line)
    sources_list.remove_source(test_list[0])
    assert(len(sources_list.files[sources_list.default_file]) == 4)



# Generated at 2022-06-11 06:44:34.502955
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import unittest
    import tempfile

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp(prefix='ansible-test-aptrepository-sourceslist-dump')

        def tearDown(self):
            import shutil
            shutil.rmtree(self.test_dir)

        def _create_file(self, filename, content):
            with open(os.path.join(self.test_dir, filename), 'w') as f:
                f.write(content)


# Generated at 2022-06-11 06:44:41.005180
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    callback = get_add_ppa_signing_key_callback(module)
    assert callable(callback)


# Generated at 2022-06-11 06:44:52.195756
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    try:
        # Ensure __deepcopy__ is a member of class UbuntuSourcesList
        assert callable(getattr(UbuntuSourcesList, '__deepcopy__'))
    except AssertionError as e:
        print('Failed to ensure that __deepcopy__ is a member of class UbuntuSourcesList: %s' % str(e))
    try:
        # Ensure __deepcopy__ accepts exactly one arguments
        assert getargspec(UbuntuSourcesList.__deepcopy__) == getargspec(lambda self, memo=None: None)
    except AssertionError as e:
        print('Failed to ensure that __deepcopy__ accepts exactly one arguments: %s' % str(e))

# Generated at 2022-06-11 06:46:56.467307
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible.module_utils.facts.virtual.openvz import OpenvzFactModule
    from ansible.module_utils.facts.virtual.vserver import VserverFactModule
    from ansible.module_utils.facts.virtual.xen import XenFactModule
    from ansible.module_utils.facts.virtual.zone import ZoneFactModule

    distro = aptsources_distro.get_distro()
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        add_file_common_args=True)

    distro.install_python_apt(module)
    sources = SourcesList(module)

    dspl_path = module.get_bin_path('dpkg-scanpackages')

# Generated at 2022-06-11 06:47:05.857001
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from copy import deepcopy
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url

    class ModuleStub(object):

        def __init__(self):
            self.params = {
                'codename': 'xenial',
                'state': 'present',
                'filename': None,
                'mode': None
            }
            self.fail_json = basic.fail_json
            self.changed = True
            self.atomic_move = os.rename
            self.set_mode_if_different = os.chmod

    class MockResponse(object):
        def __init__(self, text, url):
            self.read = lambda: to_bytes(text)


# Generated at 2022-06-11 06:47:10.686914
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    unit_test_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    temp_obj = SourcesList(unit_test_module)
    file_name = '/etc/apt/sources.list'
    temp_obj.load(file_name)
    assert(file_name in temp_obj.files)
    assert(len(temp_obj.files) == 1)


# Generated at 2022-06-11 06:47:14.860071
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Test in check mode
    module = AnsibleModule({'check_mode': True})
    assert get_add_ppa_signing_key_callback(module) is None

    # Test not in check mode
    module = AnsibleModule({'check_mode': False})
    assert get_add_ppa_signing_key_callback(module) is not None

# Generated at 2022-06-11 06:47:22.838185
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    SourcesList.__iter__()
    '''
    mod = AnsibleModule({'src': 'test.list'}, check_mode=False)
    src = SourcesList(mod)

    src.files = {
        'file1': [
            (0, False, True, 'source1', 'comment1'),
            (1, True, True, 'source2', 'comment2'),
        ],
        'file2': [
            (0, True, True, 'source3', 'comment3'),
            (1, True, False, 'source4', 'comment4'),
        ]
    }

    assert list(src) == [
        ('file2', 0, True, 'source3', 'comment3'),
        ('file1', 1, True, 'source2', 'comment2'),
    ]


# Generated at 2022-06-11 06:47:30.271137
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    def test(subtest):
        file = '/path/to/file'

        class Module(object):
            def __init__(self, params):
                self.params = params
            def fail_json(self, msg, **kwargs):
                raise AssertionError(msg)
            def atomic_move(self, src, dest):
                pass
            def set_mode_if_different(self, path, mode, changed):
                pass
            def run_command(self, command, check_rc=False):
                pass
        class FetchResult(object):
            def __init__(self, read_res, info):
                self.read = read_res
                self.info = info
        module = Module({'filename': None, 'mode': None})

# Generated at 2022-06-11 06:47:35.305643
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    file = '/tmp/sources.list'
    sourceslist.files[file] = [('1', True, True, 'source', 'comment')]
    sourceslist.modify(file, 0, enabled=False, source='source2', comment='comment2')
    modified_item = sourceslist.files[file][0]
    assert modified_item == ('1', True, False, 'source2', 'comment2')


# Generated at 2022-06-11 06:47:43.609589
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    test_module = AnsibleModule(argument_spec={})
    test_SourcesList = SourcesList(test_module)

# Generated at 2022-06-11 06:47:52.078713
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.add_source('deb http://packages.cloud.google.com/apt google-cloud-packages-archive-keyring-stretch main', comment='# Comment')
    sl.add_source('deb [arch=amd64] http://packages.cloud.google.com/apt google-cloud-packages-archive-keyring-stretch main', comment='# Comment')

    assert sl.files is not None
    assert sl.files['/etc/apt/sources.list'][0][2] == 'deb http://packages.cloud.google.com/apt google-cloud-packages-archive-keyring-stretch main # Comment\n'

# Generated at 2022-06-11 06:48:02.452318
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    import mock
    import tempfile
    import shutil
    import os

