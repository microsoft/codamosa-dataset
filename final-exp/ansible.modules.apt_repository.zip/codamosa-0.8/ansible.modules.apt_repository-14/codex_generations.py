

# Generated at 2022-06-11 06:39:34.128072
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os import apt_key
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    assert get_add_ppa_signing_key_callback(module) == apt_key.run_command

# Generated at 2022-06-11 06:39:44.455239
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import shutil
    import io

    src_file = '''
    deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main
    deb http://archive.ubuntu.com/ubuntu trusty main universe
    '''

    dst_file = '''
    # deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main
    deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main
    deb http://archive.ubuntu.com/ubuntu trusty main universe
    '''

    src_dir = tempfile.mkdtemp()
    dst_dir = tempfile.mkdtemp()

    src_path = os.path.join(src_dir, 'sources.list')

# Generated at 2022-06-11 06:39:53.329316
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Setup
    module = AnsibleModule({})
    line = 'deb https://archive.canonical.com/ubuntu bionic partner'
    file = '/etc/apt/sources.list.d/test.list'

    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list._add_valid_source(line, comment='')

    # Test
    ubuntu_sources_list.remove_source(line)

    # Assert
    assert file not in ubuntu_sources_list.files


# Generated at 2022-06-11 06:40:01.157393
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # initialise a dummy module for testing
    module = AnsibleModule(argument_spec={})
    module.params['filename'] = 'foo.list'
    module.params['state'] = 'present'
    tempdir = tempfile.mkdtemp()
    module.params['file'] = tempdir + '/sources.list'
    module.params['repo'] = 'deb-src http://archive.canonical.com/ubuntu trusty partner'
    module.params['comment'] = 'added by ansible'
    module.run_command = run_command
    module.atomic_move = atomic_move
    module.get_bin_path = get_bin_path
    module.exit_json = exit_json
    module.fail_json = fail_json
    # create sources.list file

# Generated at 2022-06-11 06:40:14.049628
# Unit test for function main

# Generated at 2022-06-11 06:40:24.009849
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({}, supports_check_mode=True)
    src = SourcesList(module)

    # Create a file with no content
    src.new_repos.add("test_file")
    src.save()
    assert os.path.isfile("test_file") is True
    os.remove("test_file")

    # Create a file with content
    src.add_source("deb http://example.com/xenial main")
    src.add_source("deb-src http://example.com/xenial main")
    src.new_repos.add("test_file")
    src.save()

    # Verify contents of file
    f = open("test_file", "r")

# Generated at 2022-06-11 06:40:33.321449
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.add_source('deb http://ppa.launchpad.net/user/ppa/ubuntu bionic main')
    deep_copy = copy.deepcopy(ubuntu_sources_list)
    assert len(deep_copy.repos_urls) == 1
    assert deep_copy.repos_urls[0] == 'deb http://ppa.launchpad.net/user/ppa/ubuntu bionic main'


# Generated at 2022-06-11 06:40:43.398628
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.common.respawn import respawn_python

    # Required for running test with Python 2.5
    if sys.version_info[0] == 2 and sys.version_info[1] < 6:
        import ansible.utils.unicode as util_unicode
        util_unicode.write_unicode = util_unicode.write_bytes

    def _mock_fetch_url(url, *args, **kwargs):
        return open_url(url, *args, **kwargs)


# Generated at 2022-06-11 06:40:51.018350
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.load(os.path.join(os.path.dirname(__file__), "test_data", "sources.list"))
    dumpstruct = sl.dump()
    assert dumpstruct.keys() == ['/etc/apt/sources.list', '/etc/apt/sources.list.d/google-chrome.list', '/etc/apt/sources.list.d/nginx-stable.list']
    assert dumpstruct['/etc/apt/sources.list.d/google-chrome.list'] == '''\
deb http://dl.google.com/linux/chrome/deb/ stable main
# Later comment
# # start with #

# deb-src http://dl.google.com/linux/chrome/deb/ stable main
'''


# Generated at 2022-06-11 06:41:01.709484
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule:
        '''Minimalistic mock object for AnsibleModule.'''
        def __init__(self, params):
            self.params = params

    class MockCallback:
        '''Minimalistic mock object for callback.'''
        def __call__(self, command):
            self.command = command

    # 1. Create a mock object for AnsibleModule.
    params = dict(
        codename='xenial'
    )
    mock_module = MockModule(params)

    # 2. Create a mock object for callback.
    mock_callback = MockCallback()

    # 3. Create an instance of UbuntuSourcesList class.
    sources = UbuntuSourcesList(mock_module, mock_callback)

    # 4. Add some repositories.

# Generated at 2022-06-11 06:42:02.373417
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    """Unit test for method add_source of class UbuntuSourcesList"""
    """
    This unit test is testing two method add_source of class UbuntuSourcesList if ppa source added and if source is 
    already added than ensure that it will not add again.
    """
    class ModuleFake(object):
        def __init__(self):
            self.params = dict(
                codename='trusty'
            )

    class SudoFake(object):
        def run_command(self, command_name, **args):
            if command_name == 'apt-get update':
                return 0, '', ''
            elif command_name == 'apt-key export 7EBC211F04F9BE72':
                return 0, '', ''

# Generated at 2022-06-11 06:42:07.157934
# Unit test for function main

# Generated at 2022-06-11 06:42:18.654399
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 06:42:29.738359
# Unit test for method save of class SourcesList
def test_SourcesList_save():
  class SourceLine(object):
    def __init__(self, filename, line_number, valid, enabled, source, comment):
      self.filename = filename
      self.line_number = line_number
      self.valid = valid
      self.enabled = enabled
      self.source = source
      self.comment = comment
    def __getitem__(self, key):
      if key == 0:
        return self.line_number
      elif key == 1:
        return self.valid
      elif key == 2:
        return self.enabled
      elif key == 3:
        return self.source
      elif key == 4:
        return self.comment
      else:
        raise IndexError


# Generated at 2022-06-11 06:42:41.507254
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(
        argument_spec=dict(
            filename=dict(default=None, type='str'),
            mode=dict(default=DEFAULT_SOURCES_PERM, type='int'),
        ),
    )
    source_list = SourcesList(module)
    source_list.add_source('deb http://archive.ubuntu.com/ubuntu bionic main restricted')
    source_list.add_source('deb-src http://archive.ubuntu.com/ubuntu bionic main restricted')
    source_list.add_source('deb http://archive.ubuntu.com/ubuntu bionic universe')
    source_list.add_source('deb-src http://archive.ubuntu.com/ubuntu bionic universe')
    source_list.add_source('deb http://archive.ubuntu.com/ubuntu bionic multiverse')
    source

# Generated at 2022-06-11 06:42:48.073103
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():

    module = MagicMock()
    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    callback(['command'])
    module.run_command.assert_called_once_with(['command'], check_rc=True)



# Generated at 2022-06-11 06:42:49.624741
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt == install_python_apt



# Generated at 2022-06-11 06:43:01.132395
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt import aptsources_distro
    from ansible.module_utils.apt import apt
    from ansible.module_utils.six import string_types
    import pythonapt
    import time
    import random
    import apt
    apt_pkg_name = 'python3-apt' if PY3 else 'python-apt'
    sys.path.insert(0, '../')
    from ansible.module_utils.apt import apt_pkg
    class apt_pkg_init():
        def __init__(self, module, apt_pkg_name):
            self.m_module = module
            self.m_apt_pkg_name = apt_pkg_name
        def init_system(self):
            return 0
    apt_pkg

# Generated at 2022-06-11 06:43:09.266091
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.plugins.module_utils.common.text.converters import to_bytes
    from ansible_collections.ansible.community.plugins.module_utils.urls import fetch_url
    import tempfile
    import os
    import json

    def fake_fetch_url(module, url, headers=None):
        response = tempfile.NamedTemporaryFile(mode='wb', delete=False)

# Generated at 2022-06-11 06:43:19.478580
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class DummyModule(object):
        class DummyModuleFailJson(object):
            def __init__(self, module):
                self.module = module
            def fail_json(self, msg):
                raise Exception(msg)
        module_fail_json = DummyModuleFailJson(None)
        class DummyModuleAtomicMove(object):
            def __init__(self, module):
                self.module = module
            def atomic_move(self, tmp_path, filename):
                pass
        module_atomic_move = DummyModuleAtomicMove(None)
        class DummyModuleSetModeIfDifferent(object):
            def __init__(self, module):
                self.module = module

# Generated at 2022-06-11 06:44:30.435693
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    _apt_pkg_config = apt_pkg.config.__dict__
    _apt_pkg_Config = apt_pkg.Config.__dict__
    global apt_pkg_config
    apt_pkg_config = apt_pkg.config.__dict__.copy()

    class MockApt:
        def __init__(self):
            self.config_values = {
                'Dir::Etc::sourcelist': './tests/apt_repository/sources.list',
                'Dir::Etc::sourceparts': './tests/apt_repository',
            }

# Generated at 2022-06-11 06:44:42.147096
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class DummyModule(object):
        def __init__(self, params):
            self.params = params

        @staticmethod
        def fail_json(msg, **kwargs):
            raise Exception(msg)

        @staticmethod
        def atomic_move(path1, path2):
            pass

        @staticmethod
        def run_command(cmd, **kwargs):
            return(0, '', '')

    class DummyAddPpaSigningKeysCallback(object):
        def __init__(self, k=None):
            self.k = k

        def __call__(self, *args, **kwargs):
            pass

    module = DummyModule({})
    add_ppa_signing_keys_callback = DummyAddPpaSigningKeysCallback()
    source_list = UbuntuSourcesList(module)


# Generated at 2022-06-11 06:44:53.173061
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import ConnectionError

    m = MockModule()
    add_ppa_signing_key_callback = MagicMock()

    s = UbuntuSourcesList(m, add_ppa_signing_key_callback)

    """
    KeyError raises if fetch_url returns non-200 code
    """
    m.run_command.return_value = (1, None, None)
    try:
        s.add_source('ppa:test_owner/test_name')
        assert False
    except KeyError:
        pass

    """
    ConnectionError raises if there is no internet connection
    """
    m.run_command.side_effect = ConnectionError()

# Generated at 2022-06-11 06:45:02.883103
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

    # Check that sources.list is parsed
    assert 'sources.list' in sources_list.files
    assert len(sources_list.files['sources.list']) > 0
    sources_list.load('/etc/apt/sources.list')
    assert len(sources_list.files['/etc/apt/sources.list']) > 0

    # Check that sources.list.d/* is parsed
    assert len(sources_list.files) > 1
    for file in glob.iglob('/etc/apt/sources.list.d/*.list'):
        assert file in sources_list.files
        assert len(sources_list.files[file]) > 0


# Generated at 2022-06-11 06:45:13.560696
# Unit test for function install_python_apt
def test_install_python_apt():
    class FakeModule(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: sys.exit(1)

        @staticmethod
        def get_bin_path(binary):
            return '/usr/bin/' + binary

        @staticmethod
        def run_command(args, **kwargs):
            return None, '', ''

    orig_run_command = FakeModule.run_command

    def run_command(args, **kwargs):
        if args[1] == 'install':
            return 0, '', ''
        else:
            return orig_run_command(args, **kwargs)

    FakeModule.run_command = run_command

    if PY3:
        apt_pkg_name = 'python3-apt'

# Generated at 2022-06-11 06:45:20.797273
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class ModuleMock(object):
        def fail_json(self, msg):
            pass

        @staticmethod
        def atomic_move(src, dst):
            pass

        def set_mode_if_different(self, src, mode, changed):
            pass

        @staticmethod
        def run_command(cmd, check_rc=True):
            return os.EX_OK, to_bytes(""), to_bytes("")

    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    module.params['mode'] = None
    module.params['filename'] = None

    test_instance = UbuntuSourcesList(module)
    assert test_instance

# Generated at 2022-06-11 06:45:29.461569
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Testing with empty sources.list file
    tmpdir = tempfile.mkdtemp()
    os.environ['APT_CONFIG'] = os.path.join(tmpdir, "apt.conf")
    l = SourcesList(None)
    d = l.dump()
    assert d == {}, "Got %s instead of empty dict" % (d)

    # Testing with custom sources.list
    os.makedirs(os.path.join(tmpdir, "sources.list.d"))
    f = open(os.path.join(tmpdir, "sources.list"), 'wb')
    f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.close()


# Generated at 2022-06-11 06:45:36.196434
# Unit test for function install_python_apt
def test_install_python_apt():
    import os
    import sys
    import shutil
    import tempfile
    import apt
    import apt_pkg
    import aptsources.distro as aptsources_distro

    TESTHOME = tempfile.mkdtemp()

    # Make sure the temp file is deleted
    @atexit.register
    def tmpfile_stop():
        if os.path.exists(TESTHOME):
            shutil.rmtree(TESTHOME)

    # Set environment variables
    os.environ['HOME'] = TESTHOME
    os.environ['LANG'] = 'C'
    os.environ['LC_ALL'] = 'C'

    # Create directories we need
    os.makedirs('%s/etc/apt/apt.conf.d' % TESTHOME)
    os.m

# Generated at 2022-06-11 06:45:44.299511
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule():
        def __init__(self, params=None):
            self.params = params
        def fail_json(self, *args, **kwargs):
            return
        def run_command(self, *args, **kwargs):
            return
        def atomic_move(self, *args, **kwargs):
            return
        def set_mode_if_different(self, *args, **kwargs):
            return
    def test_callback(*args, **kwargs):
        return
    module = MockModule()
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=test_callback)
    copy = copy.deepcopy(usl)
    assert copy.add_ppa_signing_keys_callback == test_callback
    assert copy.module == module
    assert copy.cod

# Generated at 2022-06-11 06:45:45.993563
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sources_list = UbuntuSourcesList(module=None)
    assert sources_list is not None
