

# Generated at 2022-06-11 06:39:53.951631
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    def check_source_file(sources, content):
        captured = sources.load(filename)
        assert captured == content

    sources = SourcesList(None)
    filename = '/path/to/source.list'

# Generated at 2022-06-11 06:40:04.821206
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(
    argument_spec = dict(
        mode = dict(default=None, type='raw'),
        filename = dict(default=None, type='raw'),
        repo = dict(default=None, type='raw'),
        comment = dict(default=None, type='raw'),
        state = dict(default='present', type='str')
    )
    )
    module.exit_json = lambda: None

# Generated at 2022-06-11 06:40:17.706638
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    # modify() tries to preserve original value, so we will modify "enabled"
    # property and check that "source" and "comment" were preserved
    expected_source = 'deb http://dl.google.com/linux/chrome/deb/ stable main'
    expected_comment = 'temp'
    sl.add_source(expected_source, expected_comment, file='/tmp/invalid.list')
    for filename, n, enabled, source, comment in sl:
        assert source == expected_source
        assert comment == expected_comment
        # We have only one source, so filename is fixed
        assert filename == '/tmp/invalid.list'
        sl.modify(filename, n, enabled=False)
        assert not enabled


# Generated at 2022-06-11 06:40:25.632441
# Unit test for method remove_source of class UbuntuSourcesList

# Generated at 2022-06-11 06:40:26.364827
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert True



# Generated at 2022-06-11 06:40:38.200344
# Unit test for function main
def test_main():
    mode = None
    repo = "deb [arch=amd64] https://download.docker.com/linux/ubuntu xenial stable"
    state = "present"
    update_cache = True
    update_cache_retries=5
    update_cache_retry_max_delay=12
    filename = None
    install_python_apt=True
    validate_certs=True
    codename=None
    check_mode=True
    diff=False

    p = patch('ansible_collections.ansible.community.plugins.module_utils.common.apt.SourcesList.distro')
    mock_distro = p.start()
    mock_distro.return_value = aptsources_distro.DebianDistribution(codename='debian')


# Generated at 2022-06-11 06:40:47.645474
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import types
    import unittest
    from .sourceslist import UbuntuSourcesList, sources_list_for_codename

    class TestUbuntuSourcesList(unittest.TestCase):

        def setUp(self):
            self.sources_list = sources_list_for_codename("bionic")

        def test_remove_ppa_source(self):
            self.sources_list.add_source("ppa:ansible/ansible", file="ansible")
            self.sources_list.save()

            self.sources_list = sources_list_for_codename("bionic")
            self.sources_list.remove_source("ppa:ansible/ansible")
            self.sources_list.save()

            self.sources_list = sources_list_for_codename("bionic")


# Generated at 2022-06-11 06:40:55.034115
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class Module(object):
        def __init__(self, codename):
            self.codename = codename
            self.params = dict(codename=self.codename)

        def fail_json(self, msg):
            raise Exception(msg)

    sources_list = UbuntuSourcesList(Module('trusty'))
    assert sources_list.codename == 'trusty'
    assert sources_list.LP_API == 'https://launchpad.net/api/1.0/~%s/+archive/%s'
    assert sources_list.add_ppa_signing_keys_callback == None


# Generated at 2022-06-11 06:41:06.047931
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the following structure:
    # tmpdir/
    # |-opt/
    #   |-foo/
    #     |-bar.list
    # |-foo.list
    # |-baz.list
    os.makedirs(os.path.join(tmpdir, 'opt', 'foo'))
    # Write sources to list files

# Generated at 2022-06-11 06:41:06.699052
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass

# Generated at 2022-06-11 06:41:43.638159
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-11 06:41:49.296482
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import pdb; pdb.set_trace()
    _SL = SourcesList('')
    _SL.load('test_fixtures/sources.list')
    print(_SL)
    _SL.remove_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    print(_SL)
    # _SL.dump()
    return _SL


# Generated at 2022-06-11 06:41:59.920650
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})

    distro_name = 'Debian'
    distro_release = 'jessie'
    distro_codename = 'jessie'

    class FakeDistro:
        @staticmethod
        def get_distro_codename(distro_name, distro_release):
            return distro_codename

    aptsources_distro.get_distro = lambda: FakeDistro()
    aptsources_distro.get_distro_name = lambda: distro_name
    aptsources_distro.get_distro_release = lambda: distro_release


# Generated at 2022-06-11 06:42:11.273266
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({},check_invalid_arguments=False)
    # Create temporary directory
    tmp_path = tempfile.mkdtemp()
    fd, apt_sources_list_file = tempfile.mkstemp(prefix="sources.list", dir=tmp_path)
    fd, apt_sources_listd_file = tempfile.mkstemp(prefix="test.list", dir=tmp_path + "/sources.list.d")
    f = os.fdopen(fd, 'w')

# Generated at 2022-06-11 06:42:20.822080
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    repo_file = """\
        deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main # another comment
        deb [arch=amd64] http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted # comment # another comment
    """
    fd, tmp_path = tempfile.mkstemp(prefix=".sources-list-", dir=tempfile.gettempdir())
    os.write(fd, repo_file.encode())
    os.close(fd)

    repo_file = tmp_path
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.load(repo_file)

    # Testing the removal of a PPA
    # The PPA is not removed because it

# Generated at 2022-06-11 06:42:32.343712
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    result = UbuntuSourcesList(None)

    result.add_source("http://linux.dropbox.com/ubuntu wily main")
    result.add_source("ppa:ansible/ansible")
    result.add_source("#ppa:ansible/ansible")

    assert len(result.repos_urls) == 2
    assert result.repos_urls[0] == "http://linux.dropbox.com/ubuntu wily main"
    assert result.repos_urls[1] == "deb http://ppa.launchpad.net/ansible/ansible/ubuntu wily main"

    result.remove_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu wily main")

    assert len(result.repos_urls) == 1

# Generated at 2022-06-11 06:42:43.927424
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import re
    import shutil
    import tempfile
    import os
    import stat
    import sys
    # init module names to keep pylint happy
    apt = apt_pkg = aptsources_distro = distro = None
    HAVE_PYTHON_APT = True
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.common.respawn import has_respawned, probe_interpreters_for_module, respawn_module
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.respawn import has_respawned, probe_interpreters_for_module, respawn_module


# Generated at 2022-06-11 06:42:47.906188
# Unit test for function install_python_apt
def test_install_python_apt():

    result = '{"changed": true, "msg": "Failed to auto-install python3-apt. Error was: ''", "output": ""}'
    assert result == install_python_apt("python3-apt")


# Generated at 2022-06-11 06:42:59.394932
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class APTModule(object):

        def __init__(self):
            self.check_mode = False
            self.params = {'filename': 'proftpd.list'}

        def get_bin_path(self, prog):
            return prog

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='strict', expand_user_and_vars=False, cat_stderr=True):
            return (0, '', '')

        def fail_json(self, msg):
            print(msg)


# Generated at 2022-06-11 06:43:08.376914
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    module.atomic_move = lambda _, __: None
    def _add_ppa_signing_keys_callback(_):
        pass
    file_list = [
        '/etc/apt/sources.list',
        '/etc/apt/sources.list.d/elastic-7.x.list',
        '/etc/apt/sources.list.d/mongodb-org-3.6.list',
        '/etc/apt/sources.list.d/mongodb-org-3.6.list',
        '/etc/apt/sources.list.d/virtualbox.list',
    ]
    sl = UbuntuSourcesList(module, _add_ppa_signing_keys_callback)

# Generated at 2022-06-11 06:44:23.497272
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(
        argument_spec=dict(
            filename=dict(),
        ),
    )
    sl = SourcesList(module)
    sl._add_valid_source('deb-src http://archive.ubuntu.com/ubuntu xenial main restricted', comment='')
    sl.modify('/etc/apt/sources.list', 0, source='deb http://archive.ubuntu.com/ubuntu xenial main restricted')
    assert sl.files['/etc/apt/sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu xenial main restricted'
    assert sl.files['/etc/apt/sources.list'][0][4] == ''



# Generated at 2022-06-11 06:44:29.488297
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class FakeModule(object):
        pass
    module = FakeModule()
    sl = SourcesList(module)
    assert not sl.files
    sl.load('/etc/apt/sources.list')
    assert sl.files
    for filename in list(sl.files.keys()):
        assert filename in (sl.default_file, '/etc/apt/sources.list.d/ansible.list')


# Generated at 2022-06-11 06:44:41.170900
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule:
        class TestParams:
            codename = 'hoge'

        def __init__(self):
            self.params = self.__class__.TestParams()
            self.fail_json = lambda *args, **kwargs: None

        def atomic_move(self, src, dest):
            pass

        def set_mode_if_different(self, path, mode, changed):
            pass

    class TestAddPpaSigningKeysCallback:
        def __init__(self):
            pass

        def __call__(self, command):
            pass

    arg1 = TestModule()

    obj = UbuntuSourcesList(
        arg1,
        add_ppa_signing_keys_callback=TestAddPpaSigningKeysCallback()
    )

    obj2 = copy.deepcopy(obj)
   

# Generated at 2022-06-11 06:44:52.416165
# Unit test for function revert_sources_list
def test_revert_sources_list():
    try:
        import apt_pkg
    except ImportError:
        # This is not a fatal error, just means testing of some functions is not possible
        return
    # Create a temporary directory to work in, and change to it:
    tmpdir = tempfile.mkdtemp()
    os.chdir(tmpdir)

    # Create a temporary sources.list file and save it as the "before" state:
    f = open('sources.list', 'w')
    f.write("deb http://old.org/ubuntu/\n")
    f.close()
    s = SourcesList(None)
    s.load('sources.list')
    sources_before = s.dump()

    # Modify the sources list to include a new entry:
    s2 = SourcesList(None)
    s2.load('sources.list')

# Generated at 2022-06-11 06:45:01.497391
# Unit test for function install_python_apt
def test_install_python_apt():
    # Testing on python2.7 and python3
    for python_version in (2.7, 3.6):
        python_string = "python%d" % python_version
        python_executable = python_string
        if python_version == 2.7:
            python_executable = "python"
        python_apt_package_name = "%s-apt" % python_string
        module_params = {'install_python_apt': True}
        with tempfile.NamedTemporaryFile() as manifest:
            manifest.write(REAL_SYNTAX_FOR_PYTHON_VERSION_MANIFEST.format(python_version).encode('utf-8'))
            manifest.flush()

# Generated at 2022-06-11 06:45:12.158520
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sources_list_module = {
        'atomic_move':lambda *args, **kwargs: True,
        'set_mode_if_different':lambda *args, **kwargs: True,
        'run_command':lambda *args, **kwargs: (0, '', ''),
        'fail_json':lambda *args, **kwargs: True,
        'params':{},
    }
    usl = UbuntuSourcesList(sources_list_module)
    usl.files['/etc/apt/sources.list.d/ansible_ppa-ubuntu-ansible-test_test-ansible-stable-trusty.list'] = []
    usl.add_source('ppa:ansible/ansible-test')


# Generated at 2022-06-11 06:45:20.004656
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class ModuleFake:
        def __init__(self, params):
            self.params = params
            self.codename = params['codename']

        def fail_json(self, msg):
            raise Exception(msg)

    module = ModuleFake(dict(codename='trusty'))
    add_ppa_signing_keys_callback = lambda command: None
    srcs = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)
    srcs.add_source('ppa:foo/bar')
    srcs.add_source('http://mirror.canonical.com')

    clone = copy.deepcopy(srcs)

    # original and clone can be different objects or not
    if srcs is clone:
        return

    # the original class should be the same


# Generated at 2022-06-11 06:45:21.407789
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(None) is None



# Generated at 2022-06-11 06:45:29.922698
# Unit test for constructor of class SourcesList
def test_SourcesList():
    from ansible.module_utils.six import StringIO

    original = sys.stderr
    sys.stderr = StringIO()

    module = AnsibleModule({})

    sources_list = SourcesList(module)

    assert sources_list.files == {}

    sources_list.load('/etc/apt/sources.list')
    sources_list.load('/etc/apt/sources.list.d/somesource.list')

    sources_list.files = {}
    assert sources_list.files == {}

    sources_list.load('/etc/apt/sources.list')
    sources_list.load('/etc/apt/sources.list.d/somesource.list')

    sys.stderr.close()
    sys.stderr = original


# Generated at 2022-06-11 06:45:36.662523
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic

    m_sources_before = {'/tmp/apt/sources.list': 'dummy text'}
    m_sources_after = {'/tmp/apt/sources.list': 'dummy text'}
    m_sourceslist_before = type('obj', (object,), {'save': lambda self: setattr(self, '_is_saved', True)})
    sources_before = m_sources_before
    sources_after = m_sources_after
    sourceslist_before = m_sourceslist_before()
