

# Generated at 2022-06-25 02:02:13.140100
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Use case
    var_1 = SourcesList()
    var_2 = var_1.modify()

    return


# Generated at 2022-06-25 02:02:17.651421
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():

    class MockSourcesList(SourcesList):
        def __init__(self, module):
            self.module = module
            self.files = {"filename": [("n", "valid", "enabled", "source", "comment")]}

    class MockModule:
        def __init__(self):
            self.params = {"enabled": True, "comment": "comment", "source": "source"}
        def fail_json(self, msg):
            return {"msg": msg}

    source_list = MockSourcesList(MockModule())
    source_list.modify("filename", "n")


# Generated at 2022-06-25 02:02:19.550803
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_1 = SourcesList({})
    var_1.load("/etc/apt/sources.list")
    var_1.dump()


# Generated at 2022-06-25 02:02:22.903134
# Unit test for constructor of class SourcesList
def test_SourcesList():
    apt
    apt_pkg
    aptsources_distro
    distro


# Generated at 2022-06-25 02:02:32.750314
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Test 1
    try:
        test_case_0()
    except TypeError as e:
        print(e)
    else:
        print('Success!')
    # Test 2
    try:
        test_case_0()
    except TypeError as e:
        print(e)
    else:
        print('Success!')
    # Test 3
    try:
        test_case_0()
    except TypeError as e:
        print(e)
    else:
        print('Success!')
    # Test 4
    try:
        test_case_0()
    except TypeError as e:
        print(e)
    else:
        print('Success!')
    # Test 5
    try:
        test_case_0()
    except TypeError as e:
        print(e)


# Generated at 2022-06-25 02:02:36.514985
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_0 = SourcesList()
    var_1 = ...
    assert var_0.remove_source(var_1, '0', var_1, '0')


# Generated at 2022-06-25 02:02:38.480363
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """ Function to test method remove_source of class SourcesList """
    var_0 = SourcesList('test')
    var_0._remove_valid_source('test')


# Generated at 2022-06-25 02:02:40.715246
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source(): 
    var_0 = UbuntuSourcesList(module)
    var_1 = 'ppa:marutter/rrutter'
    var_0.remove_source(var_1)
    var_1 = 'ppa:marutter/rrutter'


# Generated at 2022-06-25 02:02:47.604122
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_0 = SourcesList()
    var_1 = 'deb http://archive.ubuntu.com/ubuntu bionic main '
    var_0.remove_source(var_1)
    var_2 = set()
    var_3 = (var_2, var_1)
    var_4 = var_0.remove_source(var_3)


# Generated at 2022-06-25 02:02:58.280983
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    test_case_0()

if __name__ == '__main__':
    import doctest
    # do initial run of the doctest to get the version string
    doctest.testmod()

# Generated at 2022-06-25 02:03:58.547975
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Tests that in check mode callback is None
    module = AnsibleModule(check_mode=True)
    result = get_add_ppa_signing_key_callback(module)
    assert result is None

    # Tests that in normal mode callback is function that runs specified command
    module = AnsibleModule(check_mode=False)
    result = get_add_ppa_signing_key_callback(module)
    assert callable(result)


# Generated at 2022-06-25 02:03:59.935585
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sut = SourcesList(var_0)
    assert isinstance(sut, SourcesList)


# Generated at 2022-06-25 02:04:01.772734
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sources_list = SourcesList()
    sources_list.modify(line, n, enabled, source, comment)


# Generated at 2022-06-25 02:04:11.326490
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Test that content of sources.list is dumped correctly.
    sources_list = SourcesList(None)
    tmp_path = tempfile.mktemp()

    fd, tmp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('''\
# deb-src http://some.domain.tld/debian stable main

deb http://some.domain.tld/debian stable main


#deb-src http://some.domain.tld/debian stable main
''')
    f.close()
    sources_list.load(tmp_path)
    dump = sources_list.dump()

# Generated at 2022-06-25 02:04:14.238535
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList(main())
    var_0.dump()


# Generated at 2022-06-25 02:04:17.728220
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    var = UbuntuSourcesList()
    assert isinstance(var, UbuntuSourcesList)
    assert var.module == None
    assert var.add_ppa_signing_keys_callback == None


# Generated at 2022-06-25 02:04:19.956199
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = SourcesList()
    var_1 = UbuntuSourcesList(var_0)

if __name__ == '__main__':
    test_case_0()
    test_UbuntuSourcesList___deepcopy__()

# Generated at 2022-06-25 02:04:29.482531
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():

    sl = UbuntuSourcesList(None)

    assert sl._suggest_filename('deb http://ppa.launchpad.net/ghetto-sky/fish-shell/ubuntu trusty main') == 'ghetto-sky_fish-shell.list'

    assert 'ghetto-sky_fish-shell.list' not in sl.files


    sl.add_source('ppa:ghetto-sky/fish-shell')

    assert sl._suggest_filename('deb http://ppa.launchpad.net/ghetto-sky/fish-shell/ubuntu trusty main') == 'ghetto-sky_fish-shell.list'

    assert 'ghetto-sky_fish-shell.list' in sl.files

    sl.remove_source('ppa:ghetto-sky/fish-shell')



# Generated at 2022-06-25 02:04:37.157138
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from AnsibleModuleMock import AnsibleModule
    module = AnsibleModule
    main = UbuntuSourcesList
    with mock.patch.object(main, '__init__') as func:
        func.return_value = None
        func.side_effect = Exception('raise')
        var_1 = main(module)
        assert var_1 == None

# speed up test
if __name__ == '__main__':
    test_UbuntuSourcesList___deepcopy__()
    test_case_0()

# Generated at 2022-06-25 02:04:38.146392
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    global module
    var_1 = SourcesList(module)


# Generated at 2022-06-25 02:05:46.484489
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Create a dummy module
    class AviTestModule():
        def __init__(self):
            self.params = {}

        def check_mode(self):
            return 'true'

        def run_command(self, command, check_rc):
            return None, "sdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdfsdf", None


    # Create a dummy class
    class AviTestClass():
        def __init__(self):
            self.module = AviTestModule()

    sut = AviTestClass()
    expected_output = None
    var_output = get_add_ppa_signing_key_callback(sut)
    assert var_output == expected_output



# Generated at 2022-06-25 02:05:47.748624
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = main(['test', '--test_case=test_save'])


# Generated at 2022-06-25 02:05:48.921126
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    source_list = SourcesList('ansible_module')
    source_list.save()


# Generated at 2022-06-25 02:05:58.782648
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    #
    # Create a mock module
    #
    test_module = AnsibleModuleMock()

    #
    # Create a mock params
    #
	
    #
    # Create a mock class
    #
    add_ppa_signing_keys_callback = self.add_ppa_signing_keys_callback()

    #
    # Create a UbuntuSourcesList class with kept module, params and mocked classes
    # as arguments
    #
    test_class = UbuntuSourcesList(test_module, add_ppa_signing_keys_callback)

    #
    # Create a mock line
    #

# Generated at 2022-06-25 02:06:01.023290
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    test_get_add_ppa_signing_key_callback = None
    assert test_get_add_ppa_signing_key_callback == None


# Generated at 2022-06-25 02:06:03.222671
# Unit test for function main
def test_main():
    args = {
        "repo": "http://archive.ubuntu.com/ubuntu precise main universe",
        "state": "present",
    }
    main(args)


# Generated at 2022-06-25 02:06:04.843923
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList(module)
    var_0.save()


# Generated at 2022-06-25 02:06:05.882455
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    pass


# Generated at 2022-06-25 02:06:06.989183
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert test_SourcesList___iter__()


# Generated at 2022-06-25 02:06:09.059446
# Unit test for constructor of class SourcesList
def test_SourcesList():
    list = SourcesList('module')
    # assert that instance is created.
    assert list != None

# class SourcesList
# constructor
# test case for argument module

# Generated at 2022-06-25 02:08:23.355600
# Unit test for function revert_sources_list
def test_revert_sources_list():
    var_0 = main()

if __name__ == '__main__':
    test_case_0()
    test_revert_sources_list()

# Generated at 2022-06-25 02:08:24.101479
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = main()


# Generated at 2022-06-25 02:08:25.019716
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_1 = SourcesList()
    var_1.save()


# Generated at 2022-06-25 02:08:26.857091
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList()
    var_1 = SourcesList.save(var_0)
    assert var_1 == 0



# Generated at 2022-06-25 02:08:32.687379
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_1 = SourcesList(module)
    var_2 = var_1._parse('# deb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse')
    var_3 = var_1._parse('deb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse')
    var_1.add_source('deb http://us.archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse', 'comment', 'file')

# Constructor for class SourcesList

# Generated at 2022-06-25 02:08:34.701272
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    if PY3:
        units = [
            (test_case_0, 'default'),
        ]
        for unit, expected in units:
            unit()
            assert var_0 == expected


# Generated at 2022-06-25 02:08:35.670327
# Unit test for constructor of class SourcesList
def test_SourcesList():
    obj = SourcesList(test_case_0())



# Generated at 2022-06-25 02:08:36.172037
# Unit test for method load of class SourcesList
def test_SourcesList_load():

    pass


# Generated at 2022-06-25 02:08:38.592875
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_1 = UbuntuSourcesList('var_1')
    var_2 = 'var_2'
    var_1.remove_source('var_2')


# Generated at 2022-06-25 02:08:41.067033
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_0 = SourcesList(x='')
    var_0.add_source('', '')
