

# Generated at 2022-06-25 02:02:44.932106
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Create temporary source file to write to
    fd, temp_path = tempfile.mkstemp()

    # Create dummy source file to write to
    f = open(temp_path, 'w')
    f.write('deb xyz://some-source.com/something something main\n')
    f.close()

    # Create a SourcesList object, load the dummy source file, add valid source to it and save it
    sl = SourcesList(AnsibleModule(argument_spec={'filename': {'type': 'str', 'required': False},
                                                  'mode': {'type': 'int', 'required': False}}))
    sl.load(temp_path)
    sl.add_source('deb http://some-new-source.com/something something main')

# Generated at 2022-06-25 02:02:53.924327
# Unit test for function install_python_apt
def test_install_python_apt():
    import unittest

    # Try to import apt, apt_pkg and aptsources.distro after installation.
    class TestInstallPythonApt(unittest.TestCase):
        def setUp(self):
            self.apt_pkg_name = 'python3-apt' if PY3 else 'python-apt'
            self.module = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': True}})


# Generated at 2022-06-25 02:03:04.065097
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module_args = {'name': 'deb http://archive.canonical.com/ubuntu hardy partner', 'state': 'present'}

# Generated at 2022-06-25 02:03:06.891196
# Unit test for constructor of class SourcesList
def test_SourcesList():
    try:
        SourcesList(None)
    except TypeError:
        pass


# Generated at 2022-06-25 02:03:13.244344
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(
        argument_spec=dict()
    )
    callback = get_add_ppa_signing_key_callback(module)
    assert None == callback
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    assert None != callback


# Generated at 2022-06-25 02:03:22.999558
# Unit test for function install_python_apt
def test_install_python_apt():
    pass
    # Seems to be hard to test this, we need to be able to
    # install and uninstall something
    #
    # module = AnsibleModule(argument_spec={
    #     "repo": {"required": True},
    #     "state": {"default": "present", "type": "str"},
    #     "update_cache": {"default": True, "type": "bool"},
    #     "codename": {"type": "str"},
    #     "validate_certs": {"default": True, "type": "bool"},
    #     "filename": {"type": "str"},
    # })
    #
    # install_python_apt(module, "python-apt")
    # install_python_apt(module, "python3-apt")


# Generated at 2022-06-25 02:03:31.786662
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = Mock()
    add_ppa_signing_keys_callback = Mock()
    codename = 'zesty'
    repo_owner = 'gnome3-team'
    repo_name = 'gnome3'

    # Test when basic source is added
    s = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    source = 'deb http://ppa.launchpad.net/gnome3-team/gnome3/ubuntu zesty main'

    s.add_source(source)
    assert(s.repos_urls[0] == source)

    # Test when a PPA is added
    s = UbuntuSourcesList(module)
    ppa = 'ppa:%s/%s' % (repo_owner, repo_name)

# Generated at 2022-06-25 02:03:39.573420
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sources_list = SourcesList(AnsibleModule(argument_spec={}))
    res = sources_list._parse("deb http://ftp.us.debian.org/debian/ squeeze main contrib non-free")
    assert res == (True, True, 'deb http://ftp.us.debian.org/debian/ squeeze main contrib non-free', '')
    res = sources_list._parse("#deb http://ftp.us.debian.org/debian/ squeeze main contrib non-free")
    assert res == (True, False, 'deb http://ftp.us.debian.org/debian/ squeeze main contrib non-free', '')


# Generated at 2022-06-25 02:03:45.892132
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={'filename': {'aliases': ['list_filename']}})
    sources = SourcesList(module)
    sources.add_source('deb http://us.archive.ubuntu.com/ubuntu/ precise universe', comment='# deb-src http://us.archive.ubuntu.com/ubuntu/ precise universe #Uncomment to get updates')
    sources.add_source('deb http://us.archive.ubuntu.com/ubuntu/ precise multiverse', file='extra.list')
    sources.remove_source('deb http://us.archive.ubuntu.com/ubuntu/ precise universe')

    # dump sources to stdout
    module.exit_json(changed=True, result=sources.dump())


# Generated at 2022-06-25 02:03:52.229452
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():

    # Simple test with config existing file and dir sources.list.d
    module = AnsibleModule(argument_spec=dict(
        repo='deb-src http://archive.canonical.com/ubuntu hardy partner',
        state='present',
        filename='canonical-partner-sources',
        update_cache=False,
        validate_certs=True,
        install_python_apt=True,
        mode=DEFAULT_SOURCES_PERM,
    ))
    module.exit_json = lambda **kw: sys.exit(json.dumps(kw))
    sourceslist = SourcesList(module)
    sourceslist.dump()


# Generated at 2022-06-25 02:04:27.672875
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    #
    # Evaluate and verify method remove_source
    #
    
    #
    # Evaluate and verify method remove_source
    #
    
    #
    # Evaluate and verify method remove_source
    #
    pass


# Generated at 2022-06-25 02:04:36.215431
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO

    import apt
    import aptsources.distro
    import copy
    import json
    import os.path
    import re
    import requests
    import shutil
    import subprocess
    import sys
    import tempfile
    import xmlrpc.client

    # Mocks

    class MockAnsibleModule():

        def __init__(self, argument_spec, supports_check_mode):
            pass

        def fail_json(self, msg):
            self.result = msg

        def exit_json(self, changed, repo, state, diff):
            self.result = (changed, repo, state, diff)


# Generated at 2022-06-25 02:04:37.548656
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert var_0.__iter__() == var_0.__iter__()


# Generated at 2022-06-25 02:04:41.431331
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Initialize test variables
    sources = []
    # Call test method
    for file, n, enabled, source, comment in sources:
        pass
    pass # Return assertion


# Generated at 2022-06-25 02:04:43.891306
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_0 = SourcesList()
    var_1 = ('deb http://deb.debian.org/debian oldstable main')
    var_0.remove_source(var_1)


# Generated at 2022-06-25 02:04:50.038313
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_1 = SourcesList()
    # Test attribute self.files
    var_1.files = {'/etc/apt/sources.list.d/google-chrome.list': (1, True, True, 'deb http://dl.google.com/linux/chrome/deb/ stable main', '')}
    # Test attribute self.default_file
    var_1.default_file = '/etc/apt/sources.list'
    # Test attribute self.new_repos
    var_1.new_repos = {'/etc/apt/sources.list.d/google-chrome.list'}
    var_1 = iter(var_1)
    assert var_1
    assert isinstance(var_1, Iterator)
    assert var_1.__name__ == 'SourcesList'


# Generated at 2022-06-25 02:04:55.570915
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    print("Testing SourceList.remove_source...")

    sourceList = SourcesList()
    sourceList.load()
    sourceList.remove_source("deb https://some-repo.com/repo_name/ /")
    sourceList.save()


# Generated at 2022-06-25 02:04:59.614639
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    try:
        UbuntuSourcesList.add_source()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 02:05:07.895121
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_1 = SourcesList()
    var_2 = SourcesList()
    var_3 = SourcesList()
    var_4 = SourcesList()
    var_5 = SourcesList()
    var_6 = SourcesList()
    var_7 = SourcesList()
    var_8 = SourcesList()
    var_9 = SourcesList()
    var_10 = SourcesList()
    var_11 = SourcesList()
    var_12 = SourcesList()
    var_13 = SourcesList()
    var_14 = SourcesList()
    var_15 = SourcesList()
    var_16 = SourcesList()
    var_17 = SourcesList()
    var_18 = SourcesList()
    var_19 = SourcesList()
    var_20 = SourcesList()
    var_21 = SourcesList()
    var_22 = SourcesList()
   

# Generated at 2022-06-25 02:05:11.823241
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = UbuntuSourcesList(None)
    source_line = "deb http://ppa.launchpad.net/chris-lea/redis-server/ubuntu precise main"
    comment = ""
    file = "~/chris-lea/redis-server"
    var_0.add_source(source_line, comment, file)


# Generated at 2022-06-25 02:06:08.002507
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    apt_repo = SourcesList.save()


# Generated at 2022-06-25 02:06:10.119491
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    repo_list = SourcesList()
    repo_list.modify(1,1)

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 02:06:12.196723
# Unit test for function install_python_apt
def test_install_python_apt():
    try:
        import apt
        import apt_pkg
        import aptsources.distro as aptsources_distro

        distro = aptsources_distro.get_distro()
    except ImportError:
        print("yes")


# Generated at 2022-06-25 02:06:13.472816
# Unit test for function install_python_apt
def test_install_python_apt():
    assert True, "Not implemented yet"


# Generated at 2022-06-25 02:06:17.536742
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule({'codename': 'introspection_data'}, {'url': 'introspection_data', 'deb': 'introspection_data'})
    ubuntu_sources_list = UbuntuSourcesList(module, lambda x: None)
    ubuntu_sources_list.__deepcopy__()


# Generated at 2022-06-25 02:06:19.344248
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_0 = main()
    line_0 = ""
    var_0.remove_source(line_0)


# Generated at 2022-06-25 02:06:22.421374
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(
        argument_spec = dict(
            codename = dict(required=True),
            filename = dict(required=False)
        )
    )
    pkg = UbuntuSourcesList(module)
    sources = copy.deepcopy(pkg)


# Generated at 2022-06-25 02:06:26.570040
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    def _run_command(command):
        return(command)
    check_mode = True
    command = _run_command(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'info_signing_key_fingerprint'])
    if check_mode == True:
        assert command == None
    else:
        assert command == ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'info_signing_key_fingerprint']
        print('\x1b[6;30;42m' + 'TEST_PASSED' + '\x1b[0m')


# Generated at 2022-06-25 02:06:35.067876
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Check number of arguments
    if len(sys.argv) != 2:
        print('Error: expected 1 argument, got %d' % len(sys.argv))
        print('Usage: <test-name>.py <test-number>')
        sys.exit(1)

    # Check if test number is valid
    test_number = sys.argv[1]
    if test_number == '0':
        sys.exit(0)
    elif test_number == '1':
        test_case_1()
        sys.exit(0)
    else:
        print('Error: unknown test case "%s"' % test_number)
        print('Usage: <test-name>.py <test-number>')
        sys.exit(1)


# Generated at 2022-06-25 02:06:36.889371
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    test_case_0()

if __name__ == '__main__':
    test_get_add_ppa_signing_key_callback()

# Generated at 2022-06-25 02:08:55.967397
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    test_object = UbuntuSourcesList()
    line = 'ppa:ppa_name'
    comment = '#comment'
    file = '~/python_script/test_script.py'
    expected_return = None
    test_object.add_source(line, comment, file)
    actual_return = expected_return
    assert actual_return == expected_return


# Generated at 2022-06-25 02:09:00.651601
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_1 = tempfile.gettempdir()
    var_2 = os.path.join(var_1, "apt_temp_sources.list_%s" % str(random.randint(1,1000000)))
    m_stdin = io.StringIO('deb http://archive.canonical.com/ubuntu hardy partner\n# deb-src http://archive.canonical.com/ubuntu hardy partner')
    m_stdout = io.StringIO()
    m_stdout.write('deb http://archive.canonical.com/ubuntu hardy partner')
    m_stdout.seek(0)
    m_stderr = io.StringIO()
    m = mock_module.AnsibleModule(
      argument_spec=m_args,
      supports_check_mode=True
    )

# Generated at 2022-06-25 02:09:01.996173
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    print("Testing method save of class SourcesList")
    test_0_SourcesList_save()
    print("Testing method save of class SourcesList:passed")


# Generated at 2022-06-25 02:09:02.920585
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_1 = SourcesList("module")
    var_1.dump()


# Generated at 2022-06-25 02:09:05.633077
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_0 = UbuntuSourcesList(None)
    var_2 = None
    var_3 = var_0.remove_source(var_2)


# Generated at 2022-06-25 02:09:11.142354
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList

    params = {
        'codename' : 'precise',
    }

    # Do not create a module instance as it takes too much time
    var_0 = UbuntuSourcesList(params, None)
    var_0._expand_path = lambda path: path
    var_1 = deepcopy(var_0)

    assert var_0.__class__ is var_1.__class__
    assert var_0.repos_urls == var_1.repos_urls



# Generated at 2022-06-25 02:09:17.346163
# Unit test for function install_python_apt

# Generated at 2022-06-25 02:09:21.867269
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(choices=REPO_STATES, default='present'),
            filename=dict(),
            update_cache=dict(type='bool', default=False),
            cache_valid_time=dict(type='int', default=0),
            sources=dict(type='list'),
            distro=dict(default='Ubuntu'),
            codename=dict(),
            mode=dict(choices=['insert', 'remove'], default='insert'),
        ),
        supports_check_mode=True
    )

    testvar = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)


# Generated at 2022-06-25 02:09:22.855355
# Unit test for function revert_sources_list
def test_revert_sources_list():
    try:
        var_0 = main()
        assert True
    except:
        assert False


# Generated at 2022-06-25 02:09:27.110739
# Unit test for constructor of class SourcesList
def test_SourcesList():
    parameters = {'repo': 'deb http://archive.canonical.com/ubuntu hardy partner', 'key_url': None, 'key_server': 'hkp://keyserver.ubuntu.com:80', 'key_content': None, 'codename': 'hardy', 'update_cache': False, 'filename': None, 'state': 'present'}