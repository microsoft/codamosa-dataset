

# Generated at 2022-06-25 02:02:20.209079
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Test case data
    line_0_new = "deb http://archive.ubuntu.com/ubuntu trusty restricted main multiverse"
    line_0_old = "deb http://archive.ubuntu.com/ubuntu trusty restricted main multiverse"
    # Test code
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)
    sources_list_0.modify("sources.list.d/test_0.list", 0, enabled=True, source=line_0_new, comment="")
    # Post-test assertions
    assert sources_list_0.files["sources.list.d/test_0.list"][0][2] == True
    assert sources_list_0.files["sources.list.d/test_0.list"][0][3] == line_0_new


# Generated at 2022-06-25 02:02:22.968285
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources_list = UbuntuSourcesList({'foo': 'bar'})

    source = 'deb-src http://archive.ubuntu.com/ubuntu eoan main universe'
    sources_list.add_source(source)
    sources_list.dump()
    sources_list.remove_source(source)
    sources_list.dump()


# Generated at 2022-06-25 02:02:25.886801
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    dict_0 = {}
    str_0 = 'ppa:dtcooper/rpi-ppa'
    sources_list_0 = UbuntuSourcesList(dict_0)
    sources_list_0.remove_source(str_0)


# Generated at 2022-06-25 02:02:36.084706
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    # Test input data set 1
    dict_1 = {}
    line_1 = 'ppa:ansible/ansible'
    sources_list_1 = SourcesList(dict_1)
    
    # Test expected result 1
    expected_result_1 = NotImplementedError
    
    # Perform the test for data set 1
    try:
        sources_list_1.remove_source(line_1)
    except Exception as e:
        actual_result_1 = type(e)
    else:
        actual_result_1 = None
    
    # Check if the test result was as expected
    assert actual_result_1 == expected_result_1, 'Test fail: remove_source() method failed for input data set 1.'


# Generated at 2022-06-25 02:02:38.302476
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # create an empty module
    module = spawn_module()
    sources_list_0 = SourcesList(module)
    call_result_0 = sources_list_0.default_file
    assert isinstance(call_result_0, str)


# Generated at 2022-06-25 02:02:40.184538
# Unit test for function main
def test_main():
    print('----- Test of the Main Function:')
    print('----- No parameter set. Expected: Fail. Result: No Fail.')
    print('')
    print('----- Test of function main() completed.')



# Generated at 2022-06-25 02:02:49.995948
# Unit test for function install_python_apt
def test_install_python_apt():

    from ansible.modules.packaging.os import apt_repository

    # Load parameters used by install_python_apt
    params = {'install_python_apt': True}

    # Load module_utils needed by install_python_apt
    module_utils = {'apt': apt, 'apt_pkg': apt_pkg, 'aptsources_distro': aptsources_distro}

    # Load ansible.module_utils needed by install_python_apt
    ansible_module_utils = {'fetch_url': fetch_url, 'get_bin_path': get_bin_path, 'run_command': run_command}

    # Mock module
    mock_module = MagicMock(params=params,
                            module_utils=module_utils,
                            ansible_module_utils=ansible_module_utils)

# Generated at 2022-06-25 02:02:51.445405
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)
    # method dump of class SourcesList must exist
    assert hasattr(sources_list_0, 'dump')


# Generated at 2022-06-25 02:02:53.093443
# Unit test for function main
def test_main():
    # test case 1
    # from sources_list_test import test_case_1
    # test_case_1()

    # test case 2
    from sources_list_test import test_case_2
    test_case_2()


# Generated at 2022-06-25 02:02:56.687780
# Unit test for function install_python_apt
def test_install_python_apt():
    m = AnsibleModule(
        argument_spec=dict(
            apt_pkg_name=dict(required=True, type='str'),
        )
    )
    install_python_apt(m, 'python3-apt')



# Generated at 2022-06-25 02:03:54.393106
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = {}
    sources_list = SourcesList(module)
    sources_list.load("tests/test_aptrepository_1.sources.list")
    # Try to dump
    dump_1 = sources_list.dump()
    if not dump_1:
        raise Exception("SourcesList dump() returned an empty dict.")
    print("Dump: %s" % dump_1)



# Generated at 2022-06-25 02:03:59.463190
# Unit test for constructor of class SourcesList
def test_SourcesList():
    if HAVE_PYTHON_APT:
        test_case_0()

# end of unit tests for SourcesList


# Generated at 2022-06-25 02:04:03.390906
# Unit test for constructor of class SourcesList
def test_SourcesList():
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)

########################################
#
# list Module Executions
#
# 1. list_repository()
# 2. add_repository()
# 3. remove_repository()
#
########################################


# Generated at 2022-06-25 02:04:11.557366
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    sources_list_0 = UbuntuSourcesList(dict_0)
    sources_list_0.add_source('foo', 'bar')
    sources_list_0.add_source('foo', 'bar')
    expected = sources_list_0.dump()
    # The result should be equal to sources_list_0
    assert expected == dict_1
    # The result should be equal to sources_list_0
    assert expected == dict_2
    # The result should be equal to sources_list_0
    assert expected == dict_3


# Generated at 2022-06-25 02:04:15.133250
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)
    sources_list_0.load("system")


# Generated at 2022-06-25 02:04:19.327767
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    line = 'deb http://ppa.launchpad.net/ansible/ansible-2.9/ubuntu xenial main'
    comment = ' ansible '
    file = 'ansible'
    dict_0 = {}
    UbuntuSourcesList_0 = UbuntuSourcesList(dict_0)
    UbuntuSourcesList_0.add_source(line, comment, file)


# Generated at 2022-06-25 02:04:29.627357
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)
    assert_raises(InvalidSource, sources_list_0._parse, "m", True)

# Generated at 2022-06-25 02:04:35.263094
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    import json

    # Python3 migrated to unicode type and python2 to str
    # Let's make sure we have native strings
    to_native = lambda x: x.encode('utf-8') if isinstance(x, unicode) else x

# Generated at 2022-06-25 02:04:38.519068
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    dict_0 = {}
    sources_list_0 = SourcesList(dict_0)
    sources_list_0.save()
    dict_1 = {'./temp.list': 'deb [arch=amd64] https://download.docker.com/linux/centos/7/x86_64/stable/ fc30\n'}
    sources_list_1 = SourcesList(dict_1)
    sources_list_1.save()


# Generated at 2022-06-25 02:04:43.074136
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    dict_0 = {
        'codename': 'xenial',
        'filename': 'ubuntu-xenial.list',
        'state': 'present',
        'update_cache': False,
        'url': 'ppa:ondrej/php'
    }
    UbuntuSourcesList_0 = UbuntuSourcesList(dict_0)
    UbuntuSourcesList_0.add_source('ppa:ondrej/php')
    print(UbuntuSourcesList_0.dump())


# Generated at 2022-06-25 02:05:40.758801
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(
        argument_spec=dict()
    )
    # We will just test the constructor here
    obj = UbuntuSourcesList(module)


# Generated at 2022-06-25 02:05:42.020484
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    str_0 = 'utf-8'
    instance_0 = UbuntuSourcesList(None)

test_case_0()
test_UbuntuSourcesList()

# Generated at 2022-06-25 02:05:44.221016
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    for _ in range(10):
        t_0 = SourcesList(str_0)
        t_0.load((str_0 + str_0))
        t_0.load(str_0)
        t_0.load(str_0)


# Generated at 2022-06-25 02:05:49.749773
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    str_0 = test_case_0()

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True),
            mode = dict(default="prompt"),
            password = dict(no_log=True),
        ),
        supports_check_mode = True
    )

    if not HAS_PYTHON26_CRYPTO:
        module.fail_json(msg="Crypto is required for this module (python 2.6 or greater)")

    try:
        crypt = CryptedValue(module.params["password"])
    except ValueError:
        module.fail_json(msg="Error while decoding password parameter: ValueError")
    except TypeError:
        module.fail_json(msg="Error while decoding password parameter: TypeError")


# Generated at 2022-06-25 02:05:51.726288
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():

    # Run the function get_add_ppa_signing_key_callback with arguments
    # and test its output.

    # Assertion object reference
    assert hasattr(str_0, 'isnumeric') == 1
    # Assertion function call
    get_add_ppa_signing_key_callback()


# Generated at 2022-06-25 02:05:52.584104
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    str_0 = 'utf-8'
    # no return type
    # no return type
    return None

# Generated at 2022-06-25 02:05:53.723685
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    args0 = SourcesList(None)
    assert not SourcesList.dump(args0)


# Generated at 2022-06-25 02:06:00.703151
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    test_module_0 = SourcesList(module)
    assert test_module_0._apt_cfg_file('Dir::Etc::sourcelist') == '/etc/apt/sources.list'
    assert test_module_0._apt_cfg_dir('Dir::Etc::sourceparts') == '/etc/apt/sources.list.d'



# Generated at 2022-06-25 02:06:08.936966
# Unit test for function install_python_apt
def test_install_python_apt():
    # We need to mock up the module for test cases
    apt = apt_pkg = aptsources_distro = distro = None
    class MockModuleObject(object):
        def __init__(self):
            self.fail_json = lambda msg: msg

        def run_command(self, cmd, check_rc=True):
            return (0, '', '')

        def get_bin_path(self, bin_name):
            if bin_name == 'apt-get':
                return '/usr/bin/apt-get'
            else:
                return ''

    # Define a test case
    class TestCase0(object):
        def __init__(self):
            self.module = MockModuleObject()
            self.module.check_mode = False
            self.apt_pkg_name = 'python-apt'
           

# Generated at 2022-06-25 02:06:16.192566
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    s = SourcesList(AnsibleModule(argument_spec={}))
    s.add_source('deb http://example.com')
    assert 'http://example.com' in str(s)
    s.remove_source('deb http://example.com')
    assert 'http://example.com' not in str(s)
    s.add_source('#deb http://example.com')
    assert 'http://example.com' in str(s)
    s.remove_source('#deb http://example.com')
    assert 'http://example.com' not in str(s)

test_SourcesList_remove_source()
# end unit test SourcesList.remove_source



# Generated at 2022-06-25 02:08:38.674705
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert callable(get_add_ppa_signing_key_callback)
    

# Generated at 2022-06-25 02:08:46.920789
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    str_0 = 'utf-8'
    shlex_0 = shlex.shlex
    d = {'no_log': False, 'stdout_callback': str_0}
    tmp = shlex_0('')
    setattr(tmp, 'encoding', str_0)
    tmp_0 = shlex_0('')
    setattr(tmp_0, 'encoding', str_0)
    tmp_1 = shlex_0('')
    setattr(tmp_1, 'encoding', str_0)
    tmp_2 = shlex_0('')
    setattr(tmp_2, 'encoding', str_0)
    tmp_3 = shlex_0('')
    setattr(tmp_3, 'encoding', str_0)
    sources_list_0 = Ubuntu

# Generated at 2022-06-25 02:08:50.137070
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    if __name__ == '__main__':
        # Create an object
        # The try block is used to catch and print the exception
        try:
            file_0 = test_SourcesList___iter__.test_case_0()
        except Exception as e:
            print("Exception caught: ", e)



# Generated at 2022-06-25 02:08:51.643675
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as excinfo:
        main()
    assert excinfo.value.args[0]['changed']
    
    


# Generated at 2022-06-25 02:08:58.292139
# Unit test for function main

# Generated at 2022-06-25 02:09:02.153091
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Test for method remove_source
    kwargs = dict()
    kwargs['module'] = 'module'
    obj = UbuntuSourcesList(**kwargs)
    obj.remove_source(**{'line': 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main\n'})


# Generated at 2022-06-25 02:09:06.850879
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sl = SourcesList(AnsibleModule({}))

# Generated at 2022-06-25 02:09:10.188777
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.modules.core.packaging.os import apt_repository
    from ansible.module_utils.six import PY3
    a = { 'check_mode': False, 'run_command': [], 'get_bin_path': [], 'fail_json': [], }
    apt_repository.install_python_apt(a)


# Generated at 2022-06-25 02:09:12.228725
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    arg_0 = "\\\\xam9ha5"
    arg_1 = test_case_0
    UbuntuSourcesList___deepcopy__(arg_0, arg_1)


# Generated at 2022-06-25 02:09:13.143568
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    global sources_list
    sources_list.save()
