

# Generated at 2022-06-25 02:02:12.543231
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    sources_list_0.add_source('deb http://archive.canonical.com/ubuntu hardy partner', '', 'google-chrome')


# Generated at 2022-06-25 02:02:15.731401
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    bool_0 = False
    ubuntu_sources_list_0 = UbuntuSourcesList(bool_0)
    assert isinstance(ubuntu_sources_list_0.__deepcopy__(), UbuntuSourcesList)


# Generated at 2022-06-25 02:02:25.870849
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list_0 = SourcesList(AnsibleModule(argument_spec={}))
    sources_list_0._add_valid_source("deb http://archive.canonical.com/ubuntu hardy partner", "", sources_list_0.default_file)
    sources_list_0._add_valid_source("deb-src http://archive.canonical.com/ubuntu hardy partner", "", sources_list_0.default_file)

    sources_list_0._add_valid_source("deb http://archive.canonical.com/ubuntu hardy partner", "", "old-sources.list")
    sources_list_0._add_valid_source("deb-src http://archive.canonical.com/ubuntu hardy partner", "", "old-sources.list")


# Generated at 2022-06-25 02:02:28.794187
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    sources_list_0.dump()


# Generated at 2022-06-25 02:02:37.889810
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    bool_0 = False
    string_0 = "fIw5.S$?&[{5"
    string_1 = "X!k)n>C'Y^?t"
    string_2 = "On$g{bQ+:*Wn"
    string_3 = "Z`&FV8W#j'Hy"
    function_0 = bool_0.add_source
    ubuntu_sources_list_0 = UbuntuSourcesList(bool_0, function_0)
    ubuntu_sources_list_0.remove_source(string_0)
    ubuntu_sources_list_0.add_source(string_1, string_2, string_3)
    ubuntu_sources_list_0.remove_source(string_0)
    ubuntu_sources_list_

# Generated at 2022-06-25 02:02:39.622671
# Unit test for function install_python_apt
def test_install_python_apt():
    bool_0 = True
    apt_pkg_name_0 = 'python-apt'
    module_0 = AnsibleModule(argument_spec={})
    install_python_apt(module_0, apt_pkg_name_0)


# Generated at 2022-06-25 02:02:44.605703
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    string_0 = "deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main"
    string_1 = ""
    sources_list_0.add_source(string_0, string_1)


# Generated at 2022-06-25 02:02:51.663107
# Unit test for function main
def test_main():
    test_repo = True
    test_cache = True
    test_install_python_apt = True
    test_filename = True
    test_repo_to_add = True
    test_repo_to_add_comment = True
    test_repo_to_remove = True
    test_codename = True
    test_codename_wrong = True
    test_repo_to_add_ppa = True
    test_repo_to_add_ppa_wrong = True
    test_repo_to_add_ppa_comment = True
    test_repo_to_add_ppa_comment_wrong = True
    test_repo_to_add_line_disable = True
    test_repo_to_add_line_disable_comment = True


# Generated at 2022-06-25 02:02:54.118904
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    line_0 = "deb http://archive.canonical.com/ubuntu hardy partner"
    sources_list_0.remove_source(line_0)


# Generated at 2022-06-25 02:03:04.348369
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    testcase0_input_entry_0 = ("""
# deb http://example.org/repo testing main""")
    testcase0_input_entry_1 = """deb http://example.org/repo_new testing main"""
    testcase0_input_entry_2 = """deb http://example.org/repo testing main # added by ansible"""
    testcase0_input_entry_3 = """deb http://example.org/repo testing main"""
    testcase0_expected_entry_0 = """
# deb http://example.org/repo testing main"""
    testcase0_expected_entry_1 = """deb http://example.org/repo_new testing main"""
    testcase0_expected_entry_2 = """deb http://example.org/repo testing main # added by ansible"""
    testcase0

# Generated at 2022-06-25 02:03:33.693515
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sources_list = SourcesList()


# Generated at 2022-06-25 02:03:34.444830
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    UbuntuSourcesList()


# Generated at 2022-06-25 02:03:35.796741
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    args = {}
    sourceslist.save(**args)


# Generated at 2022-06-25 02:03:40.987427
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = main()
    var_1 = main()
    var_2 = main()
    var_3 = main()
    var_4 = main()
    var_5 = main()
    var_6 = main()
    var_7 = main()
    var_8 = main()
    var_9 = main()
    var_10 = main()
    var_11 = main()
    var_12 = main()
    var_13 = main()
    var_14 = main()
    var_15 = main()
    var_16 = main()
    var_17 = main()
    var_18 = main()
    var_19 = main()
    var_20 = main()
    var_21 = main()
    var_22 = main()
    var_23 = main()
    var_24 = main()

# Generated at 2022-06-25 02:03:47.101627
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sourcesList = SourcesList(module)
    testSourcesList = SourcesList(module)

    # Check parameter files
    assert sourcesList.files == testSourcesList.files

    # Check parameter module
    assert sourcesList.module == testSourcesList.module

    # Check parameter new_repos
    assert sourcesList.new_repos == testSourcesList.new_repos


# Generated at 2022-06-25 02:03:54.843249
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    try:
        global apt, apt_pkg, aptsources_distro, distro, HAVE_PYTHON_APT, DEFAULT_SOURCES_PERM, VALID_SOURCE_TYPES
        import apt
        import apt_pkg
        import aptsources.distro as aptsources_distro

        distro = aptsources_distro.get_distro()

        HAVE_PYTHON_APT = True
    except ImportError:
        HAVE_PYTHON_APT = False

    DEFAULT_SOURCES_PERM = 420
    VALID_SOURCE_TYPES = ['DEB', 'DEB-SRC']

    global apt, apt_pkg, aptsources_distro, distro, HAVE_PYTHON_APT, DEFAULT_SOURCES_

# Generated at 2022-06-25 02:03:55.748093
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Run revert_sources_list with correct parameters
    assert True ==True



# Generated at 2022-06-25 02:04:04.132710
# Unit test for function install_python_apt
def test_install_python_apt():
    var_1 = AnsibleModule(argument_spec=dict(repo=dict(type='str', required=True), state='str', mode='raw', update_cache='bool', update_cache_retries='int', update_cache_retry_max_delay='int', validate_certs='bool', filename='str', codename='str', install_python_apt='bool'))
    var_1.params['install_python_apt'] = True
    var_1.params['repo'] = 'ppa:nginx/stable'
    install_python_apt(var_1, 'python-apt')


# Generated at 2022-06-25 02:04:04.914613
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList()



# Generated at 2022-06-25 02:04:06.472362
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = main()


# Generated at 2022-06-25 02:04:42.858896
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sources_list = UbuntuSourcesList(module=None)

    # Test with line='ppa:x/y' and comment='', file=None
    sources_list.add_source(line='ppa:x/y', comment='', file=None)

    # Test with line='ppa:x/y' and comment='', file='hello'
    sources_list.add_source(line='ppa:x/y', comment='', file='hello')

    # Test with line='ppa:x/y' and comment='', file='/tmp/hello.list'
    sources_list.add_source(line='ppa:x/y', comment='', file='/tmp/hello.list')


# Generated at 2022-06-25 02:04:44.958700
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 'Inclusion of this unit test is in progress. Please ignore the error. '


# Generated at 2022-06-25 02:04:46.819111
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = UbuntuSourcesList()
    var_1 = var_0.__deepcopy__()


# Generated at 2022-06-25 02:04:54.542844
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    s = SourcesList('')
    s.files = {'testfile': [(0, True, True, 'deb http://example.com/ubuntu hardy main', 'some comment'),
                            (1, True, False, 'deb http://example.com/ubuntu hardy main', 'some comment'),
                            (2, False, False, 'source http://example.com/ubuntu hardy main', 'some comment'),
                            (3, False, False, '', ''),
                            ]}
    s.modify('testfile', 0, comment='new comment')
    s.modify('testfile', 2, enabled=True)

# Generated at 2022-06-25 02:04:56.996221
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = main()
    assert var_0


# Generated at 2022-06-25 02:04:59.174575
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda arg: arg
    module.run_command = lambda arg_a, arg_b, arg_c: (0, "", "")

    install_python_apt(module, "test")



# Generated at 2022-06-25 02:05:04.381991
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_0 = SourcesList(None)
    var_1 = None
    var_2 = 'deb http://archive.canonical.com/ubuntu hardy partner'
    var_0.add_source(var_2, var_1)
    var_0.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    var_0.add_source(var_2, var_1)


# Generated at 2022-06-25 02:05:10.557200
# Unit test for function install_python_apt
def test_install_python_apt():
    var_0 = AnsibleModule({'name': 'echo'})
    var_1 = load_platform_subclass({'name': 'echo'},var_0)
    var_2 = install_python_apt(var_0,'python-apt')
    assert var_2 == None
    var_3 = AnsibleModule({'name': 'echo'})
    var_4 = load_platform_subclass({'name': 'echo'},var_3)
    var_5 = has_respawned(var_3,var_4)
    assert var_5 == False
    var_6 = test_case_0()
    # Test succeed
    assert var_6 == None


# Generated at 2022-06-25 02:05:14.668487
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test if the function works correctly'''

    test_result = revert_sources_list()
    assert test_result == None, 'Test Failed'


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 02:05:16.342962
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    list = SourcesList("")
    #TODO: Add test case body here


# Generated at 2022-06-25 02:08:42.008196
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_0 = UbuntuSourcesList(1)
    var_0.remove_source(1)
    var_1 = UbuntuSourcesList(1)
    var_1.remove_source(1)


# Generated at 2022-06-25 02:08:44.194920
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = UbuntuSourcesList(
        var_1,
        var_2
    )
    var_3 = var_0.__deepcopy__(
        var_4
    )


# Generated at 2022-06-25 02:08:48.181827
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = main()
    var_1 = main()
    var_2 = main()
    var_3 = main()
    var_4 = main()
    var_5 = main()
    var_6 = main()

# Generated at 2022-06-25 02:08:55.396406
# Unit test for function install_python_apt
def test_install_python_apt():
    var_3 = apt_pkg.Configuration()

    var_3.set("Dir", "/")  # set a fake server directory

    var_3.set("Dir::State::status", "/var/lib/dpkg/status")  # set a fake status file

    var_3.set("APT::Architecture", "amd64")
    apt_pkg.init_config()
    apt_pkg.config.clear("APT::Architecture")
    var_4 = apt_pkg.VersionList()

    var_5 = apt_pkg.VersionList()

    var_6 = apt_pkg.Cache()

    var_7 = apt_pkg.Cache()

    var_8 = apt_pkg.Cache()

    var_9 = apt_pkg.Configuration()

    var_9.set("Dir", "/")


# Generated at 2022-06-25 02:09:01.886063
# Unit test for function main
def test_main():
    var_1 = {'params': {'filename': '/etc/apt/sources.list.d/ansible-test.list', 'repo': 'deb http://apt-repo.example.com/ubuntu xenial main', 'install_python_apt': False, 'update_cache_retries': 5, 'update_cache': True, 'state': 'present', 'mode': None, 'update_cache_retry_max_delay': 12, 'codename': None}}
    var_2 = ['/etc/apt/sources.list.d/ansible-test.list']
    var_3 = [('/etc/apt/sources.list.d/ansible-test.list', ['deb http://apt-repo.example.com/ubuntu xenial main\n'])]
    var_4 = False

# Generated at 2022-06-25 02:09:05.843405
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():

    var_0 = UbuntuSourcesList(module)
    var_1 = 'ppa:zope/zope'
    var_2 = ''
    var_3 = None

    var_0.add_source(var_1, var_2, var_3)
    print(var_0.dump())


# Generated at 2022-06-25 02:09:13.143526
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # Declare test inputs
    filename = 'sources.list'
    if os.path.isfile(filename):
        os.remove(filename)
    f = open(filename, 'w')
    f.write("deb http://archive.canonical.com/ubuntu hardy partner")
    f.close()
    module = type('module', (object,), {'run_command': run_command, 'get_bin_path': get_bin_path, 'fail_json': fail_json, 'atomic_move': atomic_move, 'set_mode_if_different': set_mode_if_different})
    sl = SourcesList(module)
    sl.load(filename)
    assert(len(sl.files) == 1)
    if os.path.isfile(filename):
        os.remove(filename)

# Unit test

# Generated at 2022-06-25 02:09:18.675988
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = main()
    sl.files["/etc/apt/sources.list.d/google.list"] = [
        (0, True, True, "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main", "")
    ]
    sl.modify("/etc/apt/sources.list.d/google.list", 0, enabled=False, source="deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main")
    assert sl.files["/etc/apt/sources.list.d/google.list"] == [
        (0, True, False, "deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main", "")
    ]


# Generated at 2022-06-25 02:09:26.425462
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    test_cases = [
        (
            'ppa:ubuntu-x-swat/updates',
            UbuntuSourcesList(AnsibleModuleMock())
        ),
        (
            'ppa:ubuntu-x-swat/updates',
            UbuntuSourcesList(AnsibleModuleMock(), add_ppa_signing_keys_callback=lambda command: sudo_command(command))
        ),
        (
            'deb http://ppa.launchpad.net/ubuntu-x-swat/updates/ubuntu xenial main',
            UbuntuSourcesList(AnsibleModuleMock())
        )
    ]
    for test_case in test_cases:
        line, obj = test_case
        obj.add_source(line)
        assert type(obj) == UbuntuSourcesList


# Generated at 2022-06-25 02:09:27.353292
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    var_1 = UbuntuSourcesList()
