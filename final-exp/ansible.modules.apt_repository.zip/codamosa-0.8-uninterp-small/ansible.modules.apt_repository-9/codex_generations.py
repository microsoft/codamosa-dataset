

# Generated at 2022-06-25 02:02:14.038805
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    list_0 = SourcesList()
    try:
        for file, sources in list(list_0.files.items()):
            for n, valid, enabled, source, comment in sources:
                if valid:
                    yield file, n, enabled, source, comment
    except:
        assert False


# Generated at 2022-06-25 02:02:21.426767
# Unit test for function install_python_apt
def test_install_python_apt():
    global apt_pkg
    import apt_pkg

    py2_apt_pkgs = ('python-apt', 'python-apt-common')
    py3_apt_pkgs = ('python3-apt', 'python3-apt-common')

    apt_pkg_name = apt_pkg.__name__

    if apt_pkg_name.startswith('apt_pkg'):
        module = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': True}})
        module.params['install_python_apt'] = True

        if sys.version_info < (3, 0):
            apt_pkgs = py2_apt_pkgs
            apt_pkg_name = 'python-apt'
        else:
            apt_pkgs = py3_apt_pkgs
            apt_

# Generated at 2022-06-25 02:02:29.085326
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Test with a valid SourcesList object with files that return a value when read
    try:
        list_1 = SourcesList('abc')
        ubuntu_sources_list_1 = UbuntuSourcesList(list_1)
        list_1_iter = list_1.__iter__()
        assert True
    except:
        assert False

    # Test with an invalid SourcesList object with files that throw errors when read
    try:
        list_2 = SourcesList('abc')
        ubuntu_sources_list_2 = UbuntuSourcesList(list_2)
        list_2_iter = list_2.__iter__()
        assert False
    except:
        assert True


# Generated at 2022-06-25 02:02:32.003969
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    list_1 = None
    ubuntu_sources_list_1 = SourcesList(list_1)
    res_1 = ubuntu_sources_list_1.dump()

    assert(type(res_1) == dict)



# Generated at 2022-06-25 02:02:36.000254
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    list_save = None
    list_save = SourcesList(list_save)
    list_save.save()


# Generated at 2022-06-25 02:02:45.384029
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    apt_pkg.config.set('APT::Architecture', 'amd64')
    apt_pkg.config.set('APT::Architectures::', 'amd64')
    apt_pkg.config.set('Dir::Etc::sourcelist', '/home/ubuntu/workspace/ansible-modules-extras.ansible.com/system/apt_repository/tests/sources.list.0')

    list_0 = SourcesList(None)
    list_0.remove_source('   deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main')
    assert len(list_0.files) == 1

# Generated at 2022-06-25 02:02:49.524673
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Create test objects
    list_0 = None
    ubuntu_sources_list_0 = UbuntuSourcesList(list_0)

    # Call method
    line = 'deb http://example.com ubuntu1 main'
    assert ubuntu_sources_list_0.remove_source(line) is None


# Generated at 2022-06-25 02:02:54.466102
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Create test instance
    d = '/t/sources.list'
    f = '/t/sources.list.d/t.list'
    list_1 = SourcesList()
    list_1.files[d] = [0, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty universe', '']
    list_1.files[f] = [1, False, True, 'deb http://archive.ubuntu.com/ubuntu trusty universe', '# test']

    # Assert it matches the expected output
    assert list_1.dump() == {
        d: 'deb http://archive.ubuntu.com/ubuntu trusty universe \n', 
        f: '# deb http://archive.ubuntu.com/ubuntu trusty universe # test\n'
    }


# Generated at 2022-06-25 02:02:55.055385
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:03:04.643291
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = "python3-apt"
    temp = tempfile.NamedTemporaryFile(suffix=".py")
    temp_path = temp.name
    temp.close()
    if PY3:
        temp_path_escaped = "python3 \"%s\"" % temp_path
    else:
        temp_path_escaped = "python \"%s\"" % temp_path
    rc, so, se = module.run_command([temp_path_escaped, '-c', 'import sys; print(sys.version_info[0])'])
    if int(so.strip()) == 3:
        apt_pkg_name = "python3-apt"
    else:
        apt_pkg_name = "python-apt"


# Generated at 2022-06-25 02:03:36.806505
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sources_list_0 = SourcesList()


# Generated at 2022-06-25 02:03:39.994130
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    test_case_0()
    # Declaring 'sources_list_0' variable
    sources_list_0 = SourcesList()
    # Calling method 'add_source()' and verifying whether 'sources_list_0' is None.
    assert sources_list_0.add_source('deb http://archive.canonical.com/ubuntu hardy partner') is not None


# Generated at 2022-06-25 02:03:45.905406
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    ppa_id = 'ubuntu-audio-dev/ppa'
    sl = UbuntuSourcesList(None)
    sl.add_source('ppa:%s' % ppa_id)

    # get the current list of urls
    previous_urls = []
    for url in sl.repos_urls:
        previous_urls.append(url)

    # check the ppa was correctly added
    assert len(previous_urls) == 1
    assert previous_urls[0] == "deb http://ppa.launchpad.net/%s/ubuntu xenial main" % (ppa_id)

    # get the copy of the sources list and check urls are the same
    new_sl = copy.deepcopy(sl)

    for url in new_sl.repos_urls:
        assert url in previous_urls

# Generated at 2022-06-25 02:03:54.343069
# Unit test for function install_python_apt
def test_install_python_apt():
    # Set up a test module
    mod_params = {
        'install_python_apt': True,
        'repo': 'deb http://archive.canonical.com/ubuntu hardy partner',
        'state': 'present',
    }

    mod = AnsibleModule(
        argument_spec=dict(
            install_python_apt=dict(required=False, type='bool', default=False),
            repo=dict(required=True, type='str'),
            state=dict(required=False, choices=['present', 'absent'], default='present'))
    )

    def run_module():
        # This will continue to re-execute the ansible module until it has been auto-reinstalled
        global apt
        global apt_pkg
        global aptsources_distro
        global distro
        global HAVE_PYTH

# Generated at 2022-06-25 02:03:55.144238
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    pass


# Generated at 2022-06-25 02:03:59.664988
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # First create a test case
    test_case_0()


# Generated at 2022-06-25 02:04:01.264908
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    result = True
    try:
        SourcesList.save()
    except Exception as e:
        result = False
    assert result == True


# Generated at 2022-06-25 02:04:05.458675
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sources_list_1 = UbuntuSourcesList(AnsibleModule(argument_spec={
        'filename': dict(required=False, type='str'),
        'mode': dict(required=False, default='None'),
        'codename': dict(required=False, default='None')
    }))

    sources_list_1.add_source('ppa:marian.schubert/mariadb')

    # Test for Debian sources.list
    debian_sources = """
    deb http://security.debian.org/ jessie/updates main
    deb-src http://security.debian.org/ jessie/updates main"""


# Generated at 2022-06-25 02:04:13.791522
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    '''
    Test function get_add_ppa_signing_key_callback to see if callback returned is None or a function
    '''
    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['absent', 'present']),
            sources=dict(type='list', required=True),
            filename=dict(type='path', aliases=['dest']),
            mode=dict(type='raw'),
            update_cache=dict(default='yes', type='bool')
        ),
    )

    test_function = get_add_ppa_signing_key_callback(module)
    assert type(test_function) in (type(None), types.FunctionType), "get_add_ppa_signing_key_callback did not return None or a function"


# Generated at 2022-06-25 02:04:19.865663
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Test 1: add_source a non-valid line
    sources_list_0 = SourcesList()
    source_line = 'deb http://dl.google.com/linux/chrome/deb/ stable main'
    try:
        sources_list_0.add_source(source_line)
    except InvalidSource as exc:
        pass
    else:
        raise Exception('Non-valid line was added')

    try:
        sources_list_0.add_source(source_line, raise_if_invalid_or_disabled=True)
    except InvalidSource as exc:
        pass
    else:
        raise Exception('Non-valid line was added')

    # Test 2: add_source a non-enabled line
    sources_list_1 = SourcesList()

# Generated at 2022-06-25 02:05:21.811474
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    var_0 = SourcesList(None)
    var_1 = ''
    var_2 = ''
    var_3 = ''
    var_4 = ''


# Generated at 2022-06-25 02:05:28.192723
# Unit test for method load of class SourcesList
def test_SourcesList_load():

    tmp_list = list()
    for source in source_list_file.split('\n'):
        tmp_list.append(source)
    source_list =  dict(tmp_list)

    apt_repository = SourcesList()
    apt_repository.load(source_list_file)

    for filename, sources in list(apt_repository.files.items()):
        assert filename == source_list_file

        for source in source_list:
            for n, valid, enabled, source, comment in sources:
                assert source in source_list[source]
                assert str(len(source)) == source[0:len(source)]


if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:05:35.152668
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # If a test fails, you could get the actual code with:
    #     import pdb
    #     pdb.set_trace()
    # and then you can interactively experiment with the code.

    # But first, here is a trivial example test:
    assert 1 == 1, "unit test failing, 1 == 2"

    # a better test:
    test_case_0()
    assert 1 == 1, "unit test failing for revert_sources_list"


# Generated at 2022-06-25 02:05:39.456398
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Test against the base case.
    list_0 = SourcesList()
    if SourcesList.dump(list_0) != {}:
        return False
    return True


# Generated at 2022-06-25 02:05:42.454491
# Unit test for function install_python_apt
def test_install_python_apt():
    try:
        var_1 = AnsibleModule(
            argument_spec={}
        )
        x = main()
    except SystemExit:
        pass
    except: # noqa: E722
        var_1 = AnsibleModule(
            argument_spec={}
        )
        x = main()



# Generated at 2022-06-25 02:05:48.029078
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(dict())

    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError: unsupported operand type(s) for -: 'NoneType' and 'int'
    # bug: TypeError:

# Generated at 2022-06-25 02:05:50.478274
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    mod = AnsibleModule({ 'state': 'present'})
    # mod = AnsibleModule({ 'comment': 'deb http://localhost/repo/ test main'})
    sl = SourcesList(mod)
    sl.load('test_data/test_0.txt')
    # sl.save()
    sl.dump()


# Generated at 2022-06-25 02:05:53.023955
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_2 = SourcesList(apt_pkg, aptsources_distro, distro, apt)
    var_2.load(var_0)
    return var_2.dump()

if __name__ == '__main__':
    test_case_0()
    test_SourcesList_dump()

# Generated at 2022-06-25 02:05:56.030404
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    test_case_0()


# Generated at 2022-06-25 02:06:04.879061
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'

# Generated at 2022-06-25 02:07:00.209759
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    sources_list = SourcesList(module)

    dumpstruct = sources_list.dump()

    # Check for file permissions if we have a default file
    if 'Dir::Etc::sourcelist' in dumpstruct:
        status, output, dummy = module.run_command('stat -c %a ' + dumpstruct['Dir::Etc::sourcelist'], check_rc=False)
        if status != 0:
            module.fail_json(msg='error getting permissions on %s: %s' % (dumpstruct['Dir::Etc::sourcelist'], output))
        # If we're returning the current file, make sure the mode matches
        if os.path.exists(sources_list.default_file):
            file_perm

# Generated at 2022-06-25 02:07:05.556560
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    file_0 = 'test-file.list'
    dirname_0 = 'test-dir'
    if os.path.exists(dirname_0):
        shutil.rmtree(dirname_0)
    os.makedirs(dirname_0)
    lines_0 = ['# example sources.list', '  deb http://localhost:4567/ubuntu precise main', '  deb http://localhost:4567/ubuntu precise-updates main restricted', '   deb http://localhost:4567/ubuntu precise universe', '', '# comment for precise-security', 'deb http://localhost:4567/ubuntu precise-security main restricted', '', '# This file is empty', ' ', '# Disabled source', '# deb http://localhost:4567/ubuntu precise multiverse']

# Generated at 2022-06-25 02:07:06.576662
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = main()
    SourcesList.save(var_0)


# Generated at 2022-06-25 02:07:09.154917
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():

    # Testing with all default inputs
    args = {}
    retval = SourcesList.modify(args)
    assert retval == False

    # Testing with some inputs
    args = {}
    retval = SourcesList.modify(args)
    assert retval == False


# Generated at 2022-06-25 02:07:10.790607
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    UbuntuSourcesList = UbuntuSourcesList()
    UbuntuSourcesList.remove_source('ppa:gotte/test')


# Generated at 2022-06-25 02:07:20.070331
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={
                                            'codename':{
                                                            'type': 'str',
                                                            'default': 'ubuntu'
                                                        },
                                            'filename': {
                                                            'type': 'str',
                                                            'default': 'sources.list.d'
                                                        },
                                            'update_cache': {
                                                                'type': 'bool',
                                                                'default': True
                                                            }
                                            },
                            supports_check_mode=True)
    var_0 = module.params['filename']
    var_1 = UbuntuSourcesList(var_0)
    # Main test:
    var_2 = module.params['filename']
    var_1.remove_source(var_2)
   

# Generated at 2022-06-25 02:07:21.805457
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = main()
    var_0.add_source('ppa:kivy-team/kivy-daily')


# Generated at 2022-06-25 02:07:23.386060
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList()
    var_1 = var_0.save()


# Generated at 2022-06-25 02:07:24.755021
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        var_1 = SourcesList()
        var_1.__iter__()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 02:07:25.853861
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert revert_sources_list() == main()


# Generated at 2022-06-25 02:09:44.736374
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    try:
        var_0 = UbuntuSourcesList()
        var_1 = 'ppa:kubuntu-ppa/backports'
        var_0.remove_source(var_1)
    except Exception as inst:
        var_2 = str(inst)
        print(var_2)


# Generated at 2022-06-25 02:09:45.492471
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    assert True


# Generated at 2022-06-25 02:09:48.605569
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_1 = {'repos_urls': [], 'codename': ''}
    var_2 = UbuntuSourcesList(module=var_1, add_ppa_signing_keys_callback=None)
    var_3 = 'deb http://ppa.launchpad.net/vslavik/test/ubuntu intrepid main'
    var_2.remove_source(line=var_3)


# Generated at 2022-06-25 02:09:54.606038
# Unit test for method add_source of class UbuntuSourcesList

# Generated at 2022-06-25 02:10:02.826030
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Test with two .list files
    #
    # file1:
    #   deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main
    #   # deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main
    #
    # file2:
    #   deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main
    #
    # should become:
    #   file2:
    #     # deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main
    #
    _tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-25 02:10:10.587512
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # Create mock object and assign it as a global for module
    module = AnsibleModule(argument_spec=dict())
    module.params['state'] = 'present'
    module.params['repo'] = 'deb http://archive.canonical.com/ubuntu hardy partner'

    # Create a test file (will be subject to removal automatically by AnsibleModule
    # test infrastructure)
    import tempfile
    global_test_path = tempfile.gettempdir()
    test_file = os.path.join(global_test_path, 'test_SourcesList_save_file')


# Generated at 2022-06-25 02:10:12.060647
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_1 = SourcesList()
    var_2 = var_1.__iter__()
    assert var_2


# Generated at 2022-06-25 02:10:18.467000
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # Init the module arguments
    args = dict(
        repo='deb http://archive.canonical.com/ubuntu hardy partner',
        state='present',
    )

    # Using ansible module as a template

# Generated at 2022-06-25 02:10:19.526832
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_1 = SourcesList()
    var_2 = main()


# Generated at 2022-06-25 02:10:20.778298
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_0 = SourcesList()
    var_1 = None
    return var_0.load(var_1)
