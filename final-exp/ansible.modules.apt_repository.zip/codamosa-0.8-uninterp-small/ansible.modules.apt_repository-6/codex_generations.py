

# Generated at 2022-06-25 02:02:21.738485
# Unit test for function install_python_apt
def test_install_python_apt():
    # Mock the required module instances
    module = AnsibleModule(argument_spec={})

    # Mock the core required modules
    apt_pkg = AnsibleModule(argument_spec={})
    sys.modules["apt_pkg"] = apt_pkg

    # Mock the core required modules
    apt = AnsibleModule(argument_spec={})
    sys.modules["apt"] = apt

    # Mock the core required modules
    aptsources_distro = AnsibleModule(argument_spec={})
    sys.modules["aptsources.distro"] = aptsources_distro

    # Mock the core required modules
    distro = AnsibleModule(argument_spec={})
    sys.modules["aptsources.distro.get_distro"] = distro

    # Mock the core required modules
    apt = AnsibleModule(argument_spec={})


# Generated at 2022-06-25 02:02:30.002661
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    # Create a test object of type SourcesList
    test_obj = SourcesList(AnsibleModule(
        argument_spec = dict(
            repo = dict(required=True),
            state = dict(required=True, choices=['present', 'absent']),
            filename = dict(required=False, default=None),
            update_cache = dict(required=False, type='bool', default=True),
            cache_valid_time = dict(required=False, type='int', default=None),
            validate_certs = dict(required=False, type='bool', default=True),
            mode = dict(required=False, type='int', default=None),
            install_python_apt = dict(required=False, type='bool', default=True),
        ),
        supports_check_mode=True
    ))

    # Define

# Generated at 2022-06-25 02:02:38.546423
# Unit test for function revert_sources_list

# Generated at 2022-06-25 02:02:44.368568
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Create a module for testing.
    test_mod = AnsibleModule(argument_spec=dict())

    temp_dir1 = tempfile.mkdtemp()
    temp_dir2 = tempfile.mkdtemp()


# Generated at 2022-06-25 02:02:47.907299
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({'state': 'present'}, check_invalid_arguments=False)
    try:
        SourcesList(module)
    except Exception as e:
        module.fail_json(msg="Failed to initialize class SourcesList: %s" % to_native(e))


# Generated at 2022-06-25 02:02:50.721660
# Unit test for constructor of class SourcesList
def test_SourcesList():
    try:
        test_case_0()
    except InvalidSource as err:
        raise InvalidSource(err)


# Generated at 2022-06-25 02:02:53.795850
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Arrange
    test_module = AnsibleModule(argument_spec={})

    # Act
    callback = get_add_ppa_signing_key_callback(test_module)

    # Assert
    assert(callback is None)


# Generated at 2022-06-25 02:02:56.205169
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({})
    assert get_add_ppa_signing_key_callback(module) is None


# Generated at 2022-06-25 02:02:56.976181
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    test_SourcesList_load_0()


# Generated at 2022-06-25 02:03:05.186491
# Unit test for function install_python_apt
def test_install_python_apt():

    # Patch module and get module arguments
    module = AnsibleModule(argument_spec=dict())

    # Call with Python 2 apt package name
    install_python_apt(module, 'python-apt')

    # Call with Python 3 apt package name
    install_python_apt(module, 'python3-apt')

_TEST_CASES = [test_case_0]

# Use the system's python3 instead of a python3 interpreter in a virtualenv
# because that can't use apt
if PY3:
    _TEST_CASES.append(test_install_python_apt)


# Generated at 2022-06-25 02:04:03.003800
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_case_0()


# Generated at 2022-06-25 02:04:05.464329
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # init SourcesList
    test_module = AnsibleModule(argument_spec={'file': {'type': 'path'}})
    sources_list = SourcesList(test_module)

    sources_list.save()


# Generated at 2022-06-25 02:04:12.870976
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({}, {}, {})
    sl = SourcesList(module)
    sl.add_source('deb [arch=amd64] https://apt.dockerproject.org/repo ubuntu-trusty main')
    for f, s in list(sl.files.items()):
        for n, valid, enabled, source, comment in s:
            assert source == 'deb [arch=amd64] https://apt.dockerproject.org/repo ubuntu-trusty main', \
                'Expected source \'deb [arch=amd64] https://apt.dockerproject.org/repo ubuntu-trusty main\', got ' + str(source)
    del sl


# Generated at 2022-06-25 02:04:21.425873
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    import os

    # Create a directory in which to work
    t = tempfile.mkdtemp()

    # Create a sourcelist to manipulate
    s = SourcesList(t)
    test_file_path = os.path.join(t, 'test.list')
    test_data = "deb http://example.com/ubuntu bionic main universe\n"
    s.add_source(line=test_data.strip(), comment='fun')

    # Save the original sources-list contents for later
    sources_before = s.dump()
    sourceslist_before = s

    src_data = "deb http://example.com/ubuntu bionic main universe\n"
    s.add_source(line=src_data.strip(), comment='fun')
    s.save()

    # Get the updated sources-list contents


# Generated at 2022-06-25 02:04:30.319260
# Unit test for function install_python_apt
def test_install_python_apt():
    """
    This is a test for the module's function 'install_python_apt'
    """
    # Initialize test variables
    apt_pkg_name = "python3-apt"
    apt_get_path = "/usr/bin/apt-get"

    # Initialize test class
    module = AnsibleModule(argument_spec={})
    module.params = {
        'check_mode': False,
        'update_cache': False,
    }

    # Test failure mode
    if not HAVE_PYTHON_APT:
        install_python_apt(module, apt_pkg_name)

    test_case_0()
    test_case_1()



# Generated at 2022-06-25 02:04:40.926506
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={
        'codename': dict()
    })

    repos = UbuntuSourcesList(module)
    repos._add_valid_source('ppa:joe/cqrs', '', 'a-joe-cqrs.list')
    repos._add_valid_source('deb http://example.com', '', 'b-example-com.list')

    assert len(repos.files) == 2

    # Remove deb source from list
    repos.remove_source('deb http://example.com')
    assert len(repos.files) == 1

    # Remove ppa source from list
    repos.remove_source('ppa:joe/cqrs')
    assert len(repos.files) == 0


# Generated at 2022-06-25 02:04:45.518027
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList(None)
    sl.files['sources.list'] = [('line_0', True, True, 'source_0', 'comment_0')]
    sl.modify('sources.list', 0, enabled=False, source='source_1', comment='comment_1')
    assert(sl.files['sources.list'] == [('line_0', True, False, 'source_1', 'comment_1')])


# Generated at 2022-06-25 02:04:52.111340
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'
    # Test that when there is no system python-apt installed and module's
    # install_python_apt=true it works
    module_0 = AnsibleModule({'install_python_apt':True}, False, ['install_python_apt'], '', '', None, '')
    install_python_apt(module_0, apt_pkg_name)
    assert not module_0.fail_json.called
    assert module_0.exited
    assert module_0.exit_args == {'changed': True}

    # When there is no system python-apt installed and module's
    # install_python_apt=false returns an error

# Generated at 2022-06-25 02:05:01.502595
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    invalid_source_0 = test_case_0()
    # Testing __iter__ method with invalid sources
    sources_list_0 = SourcesList(module=None)

# Generated at 2022-06-25 02:05:05.668870
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # get instance of SourcesList
    sl = SourcesList(None)
    # load some sources
    sl.load('tests/fixtures/testcase_0/sources.list')
    # check that the iterator returns always a tuple of 5 elements
    for line in sl:
        assert len(line) == 5


# Generated at 2022-06-25 02:06:19.146616
# Unit test for function install_python_apt
def test_install_python_apt():

    # Test needs to be run in a virtual environment, with the Python apt
    # module not already installed to succeed

    # Save the environment
    old_python_modules = copy.deepcopy(sys.modules)

    # Install the Python apt module
    install_python_apt(AnsibleModule(argument_spec={}), 'python3-apt')

    # Restore the environment
    sys.modules = old_python_modules


# Generated at 2022-06-25 02:06:27.145989
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Initialize a dummy module
    test_module = AnsibleModule({})

    # Create a dummy SourcesList
    sl = SourcesList(test_module)

    # Populate the SourcesList with some dummy data
    for filename in ('/etc/apt/sources.list', '/etc/apt/sources.list.d/foo.list', '/etc/apt/sources.list.d/bar.list'):
        sl.files[filename] = []
        for n in range(0, 10):
            sl.files[filename].append((n, True, True, "deb http://archive.ubuntu.com/ubuntu bionic main restricted universe multiverse", ""))
            sl.files[filename].append((n, True, False, "deb http://archive.ubuntu.com/ubuntu bionic-updates main restricted universe multiverse", ""))
            sl

# Generated at 2022-06-25 02:06:30.268209
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    try:
        # Init SourcesList object with no argument
        sources = SourcesList(module)
    except Exception as e:
        # Expected exception, do nothing
        pass



# Generated at 2022-06-25 02:06:37.244136
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    m = AnsibleModule({'debug': True})
    sources = SourcesList(m)

    # Testing dump when sources.list is not empty
    src_list = sources.dump()
    assert len(src_list) > 0

    # Delete all the sources from sources.list and sources.list.d
    for filename in src_list:
        for n, valid, enabled, source, comment in sources:
            if not enabled:
                sources.files[filename].pop(n)
                assert len(sources.dump()) == 0
            else:
                sources.files[filename].pop(n)


# Generated at 2022-06-25 02:06:45.517504
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import ansible.constants as C

    # Create empty AnsibleModule object
    module = AnsibleModule(argument_spec=dict())
    module.fail_json = exit_json_fail
    module.exit_json = exit_json_pass
    module.atomic_move = ansible_atomic_move
    module.set_mode_if_different = ansible_set_mode_if_different

    # Create empty SourcesList object
    sources_list = SourcesList(module)

    # Create list of sources

# Generated at 2022-06-25 02:06:50.404294
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        '/etc/apt/sources.list.d/new_repo_0.list': '# deb [arch=amd64] http://us.archive.ubuntu.com/ubuntu/ xenial main restricted',
        '/etc/apt/sources.list.d/repo_0.list': '# deb [arch=amd64] http://us.archive.ubuntu.com/ubuntu/ xenial main restricted',
        '/etc/apt/sources.list.d/repo_1.list': '# deb [arch=amd64] http://us.archive.ubuntu.com/ubuntu/ xenial main restricted',
        '/etc/apt/sources.list.d/repo_2.list': '# deb [arch=amd64] http://us.archive.ubuntu.com/ubuntu/ xenial main restricted',
    }

# Generated at 2022-06-25 02:06:59.153061
# Unit test for function install_python_apt
def test_install_python_apt():
    global apt, apt_pkg, aptsources_distro, distro


# Generated at 2022-06-25 02:07:02.633361
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        invalid_source_0 = InvalidSource()
    except Exception as e:
        if type(e) is not InvalidSource:
            raise Exception('Got unexpected exception "%s"' % e)
    try:
        invalid_source_1 = InvalidSource()
    except Exception as e:
        if type(e) is not InvalidSource:
            raise Exception('Got unexpected exception "%s"' % e)


# Generated at 2022-06-25 02:07:09.683123
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    params = dict(
        repo='ppa:james-page/docker',
        state='present',
        update_cache=False
    )

    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True),
            state=dict(default='present', choices=['absent', 'present']),
            mode=dict(type='raw'),
            update_cache=dict(default=False, type='bool'),
            filename=dict(),
            codename=dict(),
        ),
        supports_check_mode=True
    )

    module.exit_json(msg=UbuntuSourcesList(module).__deepcopy__())


# Generated at 2022-06-25 02:07:11.146387
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    ubuntu_sources_list = UbuntuSourcesList()
    deepcopy(ubuntu_sources_list)


# Generated at 2022-06-25 02:09:27.419865
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sl = UbuntuSourcesList(None)
    print(sl)


# Generated at 2022-06-25 02:09:35.300916
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # init vars
    srcs = SourcesList(AnsibleModule({}))
    filename =  "sources.list"
    srcs.files[filename] = [(0, True, True, "repo1", "comment1"), (1, True, True, "repo2", "comment2"), (2, True, True, "repo3", "comment3")]
    n = 0
    repos = srcs._choice(None, "repo1")
    comments = srcs._choice(None, "comment1")
    srcs.modify(filename, n, repos, comments)
    if srcs.files[filename][n] != (0, True, True, "repo1", "comment1"):
        test_result = 1
        raise Exception("Test failed: %s" % test_result)




# Generated at 2022-06-25 02:09:40.870082
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True),
            state=dict(default='present', choices=['absent', 'present']),
            update_cache=dict(default=False, type='bool'),
            validate_certs=dict(required=False, type='bool', default=True),
            filename=dict(required=False, type='str'),
            install_python_apt=dict(default=True, type='bool'),
            mode=dict(required=False, type='str'),
            update_after_add=dict(default=True, type='bool'),
            cache_valid_time=dict(required=False, type='int', default=3600),
        ),
    )

# Generated at 2022-06-25 02:09:45.021771
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={'codename': {'type': 'str'}, 'file': {'type': 'str'}, 'key_id': {'type': 'str'}}, supports_check_mode=False, bypass_checks=False)
    os.chmod('/etc/apt/sources.list.d', 0o755)
    x = UbuntuSourcesList(module)
    x.add_source('deb https://download.01.org/intel-sgx/sgx_repo/ubuntu xenial main')
    x.save()


# Generated at 2022-06-25 02:09:46.529965
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Setup
    m = Generic()

    # Exercise
    results = main(m)

    # Verify
    assert (results == 0)


# Generated at 2022-06-25 02:09:47.256660
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    assert True


# Generated at 2022-06-25 02:09:53.036279
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-25 02:09:58.964858
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    # Mock of SourcesList class
    class SourcesListMock:
        def __init__(self):
            self.new_repos = []

        def modify(self, filename, line, enabled=None, source=None, comment=None):
            self.new_repos.append((filename, line, enabled, source, comment))

    # Call of the method
    sources = SourcesListMock()
    sources.add_source('deb http://us.archive.ubuntu.com/ubuntu/ bionic multiverse')

    assert(sources.new_repos[0] == (sources._apt_cfg_file('Dir::Etc::sourcelist'), len(sources.new_repos), True, 'deb http://us.archive.ubuntu.com/ubuntu/ bionic multiverse', ''))


# Generated at 2022-06-25 02:10:02.068857
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_1 = SourcesList()
    var_2 = 'deb http://archive.ubuntu.com/ubuntu xenial main'
    var_1.remove_source(var_2)


# Generated at 2022-06-25 02:10:05.492820
# Unit test for function install_python_apt
def test_install_python_apt():
    var_0 = AnsibleModule()
    var_1 = apt_pkg_name = "python-apt"
    var_2 = install_python_apt(var_0, var_1)
