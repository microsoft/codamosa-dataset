

# Generated at 2022-06-25 02:02:15.738135
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    for bool_1, bool_2, bool_3 in sources_list_0:
        if bool_1:
            return bool_2
        else:
            return bool_3


# Generated at 2022-06-25 02:02:19.856554
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module_0 = AnsibleModule({})
    test_case_0(module_0)


# Generated at 2022-06-25 02:02:29.261084
# Unit test for function main

# Generated at 2022-06-25 02:02:33.036944
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # Create an instance of the class SourcesList
    sources_list_0 = SourcesList(None)
    # Create the appropriate inputs
    file_0 = ""
    file_1 = "SourcesList/test_0.list"
    # Invoke the function
    sources_list_0.load(file_0)
    sources_list_0.load(file_1)


# Generated at 2022-06-25 02:02:35.407583
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Instantiate a SourcesList object to use
    try:
        sources_list_0 = SourcesList()
    except NameError:
        sources_list_0 = SourcesList(False)

    # Call modify from SourcesList, no return type
    sources_list_0.modify("deb")


# Generated at 2022-06-25 02:02:36.854354
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sources_list_0 = SourcesList(object())
    sources_list_0.save()


# Generated at 2022-06-25 02:02:38.894733
# Unit test for function install_python_apt
def test_install_python_apt():
    # Run module to install python apt
    # Should not throw exceptions
    install_python_apt('python3-apt', 'python3-apt')



# Generated at 2022-06-25 02:02:41.614848
# Unit test for function revert_sources_list
def test_revert_sources_list():
    bool_0 = False
    sources_list_0 = SourcesList(bool_0)
    sources_list_1 = SourcesList(bool_0)
    sources_list_2 = SourcesList(bool_0)
    revert_sources_list(sources_list_0, sources_list_1, sources_list_2)


# Generated at 2022-06-25 02:02:45.423418
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = ansible_module_create()
    sources_list_0 = SourcesList(module)
    assert sources_list_0


# Generated at 2022-06-25 02:02:48.028932
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sources_list_0 = SourcesList(None)
    sources_list_0.add_source("deb http://mysite.com/debian distribution component1 component2", "comment")

    return


# Generated at 2022-06-25 02:03:21.951782
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    src_list = SourcesList(module)
    file_list = [ ('/etc/apt/sources.list.d/sources.list', 'deb http://archive.canonical.com/ubuntu precise partner\n'),
                  ('/etc/apt/sources.list.d/cdimage.list', 'deb http://cdimage.ubuntu.com/releases precise-updates/main restricted multiverse\n'),
                  ('/etc/apt/sources.list.d/repo.list', 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main\n'),
                ]

    for file, src in file_list:
        src_list.files[file] = [(0, True, True, src, '')]



# Generated at 2022-06-25 02:03:29.385003
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class ModuleFailJson(object):
        def fail_json(self, msg):
            return msg

    # adding valid source to remove later
    source_line = "deb http://ppa.launchpad.net/name/stable/ubuntu xenial main"
    sources_list = UbuntuSourcesList(ModuleFailJson())
    sources_list.add_source(source_line, comment='')

    sources_list.remove_source(source_line)

    repos_urls = sources_list.repos_urls
    if source_line in repos_urls:
        raise Exception('Wrong implementation of remove_source function. Source %s should not be in the list.' % (source_line))

# Generated at 2022-06-25 02:03:34.441368
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict())
    src_list = SourcesList(module)

    if module.check_mode:
        # Running in check mode, we need to test at least one method
        src_list.dump()


# Generated at 2022-06-25 02:03:38.533181
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'/etc/apt/sources.list': 'contents'}
    sources_after = {'/etc/apt/sources.list': 'contents',
                     '/etc/apt/sources.list.d/ansible1.list': 'contents',
                     '/etc/apt/sources.list.d/ansible2.list': 'contents'
                    }
    sourceslist_before = UbuntuSourcesList(sources_before)
    revert_sources_list(sources_before, sources_after, sourceslist_before)


# Generated at 2022-06-25 02:03:44.126594
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.exit_args = {}
            self.exit_code = None
            fd, self.tmpfile = tempfile.mkstemp()
            os.close(fd)

            def _run_command(command, check_rc=False):
                if check_rc:
                    self.check_rc = check_rc
                    raise SystemExit(self.exit_code, self.exit_args)
                return self.exit_code, '', ''

            self.run_command = _run_command

            def fail_json(msg):
                self.msg = msg
                raise SystemExit()

            self.fail_json = fail_json


# Generated at 2022-06-25 02:03:44.727373
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-25 02:03:50.420603
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(
        argument_spec=dict(
            file=dict(type='str', required=True),
            state=dict(type='str', required=True, choices=['present', 'absent'])
        )
    )
    file = module.params['file']
    state = module.params['state']
    sources_list = SourcesList(module)
    if state == 'present':
        sources_list.load(file)
    module.exit_json(changed=state == 'absent', dumps=sources_list.dump())


# Generated at 2022-06-25 02:03:53.705493
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    upl = UbuntuSourcesList(module)
    upl.load('/dev/null')

    # For each line, we try to remove a source,
    # then we test that the file has been removed
    lines = [source[3] for source in upl]
    for line in lines:
        upl.remove_source(line)

    assert len(upl.files) == 0


# Generated at 2022-06-25 02:04:04.162147
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # selected cases
    invalid_source_1 = InvalidSource("# comment")
    invalid_source_2 = InvalidSource("# comment\n")
    invalid_source_3 = InvalidSource("# comment\n# comment")
    invalid_source_4 = InvalidSource("# comment\n# comment\n")
    invalid_source_5 = InvalidSource("# comment\n# comment\n# comment")
    invalid_source_6 = InvalidSource("# comment\n# comment\n# comment\n")
    invalid_source_7 = InvalidSource(" # comment")
    invalid_source_8 = InvalidSource(" # comment\n")
    invalid_source_9 = InvalidSource(" # comment\n# comment")
    invalid_source_10 = InvalidSource(" # comment\n# comment\n")

# Generated at 2022-06-25 02:04:12.650007
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    distro = UbuntuDistro(name=None, version=None, id=None, codename=None,
        release=None, info=None, major_release=None, supported=False,
        like=None, init=None, init_system_command=None, type=None)

    module = AnsibleModule(argument_spec={'codename': {'type': 'str'}})
    module.params['codename'] = 'trusty'
    module.distribution = distro
    module.params['state'] = 'present'
    module.params['name'] = 'ppa:ansible/ansible'

    test_obj = UbuntuSourcesList(module)

    # verify if the test object is instance of UbuntuSourcesList
    assert isinstance(test_obj, UbuntuSourcesList)

    # verify if the __deepcopy__ method return an instance

# Generated at 2022-06-25 02:05:05.740813
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # Initialize the class
    obj = SourcesList("file_param")

    # Invoke method load with argument 'file_param'
    obj.load("file_param")


# Generated at 2022-06-25 02:05:07.551704
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # test case 0
    _var_0 = UbuntuSourcesList(module);
    _var_1 = 'ppa:ubuntu-sdk-team/ppa'
    _var_0.remove_source(_var_1);



# Generated at 2022-06-25 02:05:13.809156
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import ansible.modules.extras.cloud.do.apt_repository as apt_repository
    test_arg_0 = None
    test_arg_1 = None
    test_arg_2 = None
    test_arg_3 = None
    expected_0 = None
    expected_1 = None
    expected_2 = None
    expected_3 = None
    expected_4 = None
    expected_5 = None
    expected_6 = None
    expected_7 = None
    expected_8 = None
    expected_9 = None
    expected_10 = None
    expected_11 = None
    expected_12 = None
    expected_13 = None
    expected_14 = None
    expected_15 = None
    expected_16 = None
    expected_17 = None
    expected_18 = None
    expected_19

# Generated at 2022-06-25 02:05:23.618039
# Unit test for method load of class SourcesList

# Generated at 2022-06-25 02:05:25.901256
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    print("Start the test of add_source()")

    print("Test case 0")
    var_0 = main()


# Generated at 2022-06-25 02:05:30.472483
# Unit test for function revert_sources_list
def test_revert_sources_list():
    try:
        main()
    except SystemExit:
        revert_sources_list()



# Generated at 2022-06-25 02:05:33.065756
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList(AnsibleModule())
    var_0.save()


# Generated at 2022-06-25 02:05:33.985822
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = UbuntuSourcesList()
    var_1 = var_0.__deepcopy__()


# Generated at 2022-06-25 02:05:36.139697
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    print('Test case: modify')

    apt_repository = main()
    apt_repository.modify('deb-src http://archive.canonical.com/ubuntu hardy partner', 'deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-25 02:05:45.676551
# Unit test for function revert_sources_list
def test_revert_sources_list():
    var_0 = SourcesList(None, default_file='/etc/apt/sources.list.d/test.list')
    var_0.add_source('test')
    var_1 = SourcesList(None)
    var_0.save()
    var_1.save()
    '''Revert the sourcelist files to their previous state.'''

    # First remove any new files that were created:
    for filename in set(var_1.keys()).difference(var_0.keys()):
        if os.path.exists(filename):
            os.remove(filename)
    # Now revert the existing files to their former state:
    var_0.save()
    return not os.path.exists('/etc/apt/sources.list.d/test.list')


# Generated at 2022-06-25 02:08:58.072564
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_SourcesList = SourcesList()
    test_SourcesList.add_source("deb http://archive.ubuntu.com/ubuntu trusty-security main")
    test_SourcesList.add_source("deb http://archive.ubuntu.com/ubuntu precise-updates main")
    test_SourcesList.add_source("deb http://archive.ubuntu.com/ubuntu precise main")
    test_SourcesList.add_source("deb http://archive.ubuntu.com/ubuntu precise-security main")
    test_SourcesList.remove_source("deb http://archive.ubuntu.com/ubuntu precise-updates main")

# Generated at 2022-06-25 02:09:00.941392
# Unit test for constructor of class SourcesList
def test_SourcesList():
    assert SourcesList
    assert SourcesList is not None
    assert callable(SourcesList)
    assert SourcesList.__name__ == 'SourcesList'
    assert SourcesList.__doc__ == 'Simple version of aptsources.sourceslist.SourcesList.\\n    No advanced logic and no backups inside.\\n    '


# Generated at 2022-06-25 02:09:04.031429
# Unit test for function main
def test_main():
    assert isinstance(main(),  (type(None), dict)), \
        "Function returns incorrect type"
    
if __name__ == '__main__':
    #test_case_0()
    import sys
    sys.path.append('/home/ssv/PycharmProjects/ansible-modules-core/lib/ansible/modules/packaging/os/apt_repository.py')
    main()

# Generated at 2022-06-25 02:09:04.661837
# Unit test for constructor of class SourcesList
def test_SourcesList():
    var_0 = SourcesList()


# Generated at 2022-06-25 02:09:10.598695
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    global SOURCESLIST__ITER__CALLED
    SOURCESLIST__ITER__CALLED = False

    def mock_SOURCESLIST__ITER__():
        global SOURCESLIST__ITER__CALLED
        SOURCESLIST__ITER__CALLED = True

    orig_SOURCESLIST__ITER__ = SourcesList.__iter__
    SourcesList.__iter__ = mock_SOURCESLIST__ITER__

    var_0 = SourcesList()
    var_0.__iter__()

    assert SOURCESLIST__ITER__CALLED

    SourcesList.__iter__ = orig_SOURCESLIST__ITER__


# Generated at 2022-06-25 02:09:11.524399
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class_SourcesList = var_0.SourcesList()



# Generated at 2022-06-25 02:09:13.540121
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    instance = SourcesList(module)
    assert instance is not None
    return True


# Generated at 2022-06-25 02:09:14.834859
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_1 = SourcesList()
    var_1.add_source(line="deb", file=arg_1)


# Generated at 2022-06-25 02:09:19.877561
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    src = SourcesList(AnsibleModule(argument_spec={}))
    src.add_source('deb http://ubuntu.cs.utah.edu/ubuntu/ hardy main restricted')
    assert src.dump() == {'/etc/apt/sources.list': 'deb http://ubuntu.cs.utah.edu/ubuntu/ hardy main restricted\n'}
    assert src._suggest_filename('deb http://ubuntu.cs.utah.edu/ubuntu/ hardy main restricted') == 'ubuntu_cs_utah_edu_ubuntu_.list'
    assert src._suggest_filename('deb http://user:pass@ubuntu.cs.utah.edu/ubuntu/ hardy main restricted') == 'ubuntu_cs_utah_edu_ubuntu_.list'



# Generated at 2022-06-25 02:09:26.578640
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import subprocess
    p = subprocess.Popen(["/bin/bash"], stdout=subprocess.PIPE)
    import sys
    import os

    cwd = os.path.abspath('/etc/apt/sources.list')
    os.chdir(cwd)

    import apt
    apt_pkg = apt
    module = apt
    module.params = dict(
        source='ppa:ansible/ansible',
    )
    module.run_command = lambda args, **kwargs: (0, p.communicate(), '')
    module.atomic_move = lambda tmp_path, filename: None
    module.fail_json = lambda **kwargs: None