

# Generated at 2022-06-25 02:02:18.541817
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    content = open('tests/test_sources.list', 'r').read()
    class new_module(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
    module = new_module()
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    assert (content == sources.dump()['tests/test_sources.list'])


# Generated at 2022-06-25 02:02:31.555093
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    test_data = {}
    test_data['Dir::Etc::sourcelist'] = '/etc/apt/sources.list'
    test_data['Dir::Etc::sourceparts'] = '/etc/apt/sources.list.d'
    module = AnsibleModule(argument_spec={'test_mode': {'type': 'bool', 'default': True, 'required': False}})
    sl = SourcesList(module)
    dump_output = sl.dump()

# Generated at 2022-06-25 02:02:41.144217
# Unit test for method dump of class SourcesList

# Generated at 2022-06-25 02:02:52.921986
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModuleStub()
    add_ppa_signing_keys_callback = []
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    # make sure that __deepcopy__ function exists
    assert hasattr(usl, '__deepcopy__'), 'UbuntuSourcesList lacks __deepcopy__ function'

    # make sure that the callback function is passed through the copy
    copy = copy.deepcopy(usl)
    assert copy.add_ppa_signing_keys_callback == usl.add_ppa_signing_keys_callback

    # make sure that the callback is preserved when called from the copy
    copy.add_source('ppa:test')
    assert len(add_ppa_signing_keys_callback) == 1

    # make sure that the callback is not called if add_ppa

# Generated at 2022-06-25 02:03:03.489390
# Unit test for function install_python_apt
def test_install_python_apt():
    # This function is used in unit tests that may not have a module object.
    # Create a mock module object to test the functionality that is allowed
    class FakeModule:
        def fail_json(self, msg):
            print(msg)

        def get_bin_path(self, _):
            return "mock_apt_get_path"

        def run_command(self, args):
            command = ' '.join(args)
            if command == "mock_apt_get_path update":
                return 0, "", ""
            elif command == "mock_apt_get_path install python-apt -y -q" or command == "mock_apt_get_path install python3-apt -y -q":
                return 0, "", ""
            else:
                return 1, "", ""

    install_python_apt

# Generated at 2022-06-25 02:03:11.483410
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    apt_pkg_mock = Mock()
    apt_pkg.config.mock_class = apt_pkg_mock
    apt_pkg.Config.mock_class = apt_pkg_mock
    apt_pkg_mock.FindDir.return_value = "/etc/apt/sources.list.d/"
    apt_pkg_mock.FindFile.return_value = "/etc/apt/sources.list"

    list_0 = SourcesList(module)

# Generated at 2022-06-25 02:03:17.713840
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module_obj = AnsibleModule(argument_spec={})
    add_ppa_signing_keys_callback = None
    obj = UbuntuSourcesList(module_obj, add_ppa_signing_keys_callback)
    obj.codename = 'codename'
    # Test method
    deepcopy_obj = deepcopy(obj)
    # Check result
    assert type(deepcopy_obj) == type(obj)
    assert deepcopy_obj.module == obj.module
    assert deepcopy_obj.add_ppa_signing_keys_callback == obj.add_ppa_signing_keys_callback
    assert deepcopy_obj.codename == obj.codename


# Generated at 2022-06-25 02:03:19.136360
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sourcesList = SourcesList(None)
    for i, valid, enabled, source, comment in sourcesList:
        assert(True)


# Generated at 2022-06-25 02:03:24.836075
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # the following lines are for testing purposes only
    module = AnsibleModule({
        'repo': 'deb http://archive.ubuntu.com/ubuntu precise main universe'
    })

    module.exit_json = lambda **kwargs: sys.exit(0)
    module.fail_json = lambda **kwargs: sys.exit(1)

    fd, tmp_path = tempfile.mkstemp(prefix='ansible-test-sources', suffix='list')

# Generated at 2022-06-25 02:03:28.732852
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    items = ['foo', 'bar', 'baz']
    sources = SourcesList()
    source = "deb http://localhost:5000/debian/ unstable main"
    comment = "#This is a comment"
    f = tempfile.mktemp()
    sources = SourcesList()
    sources.add_source(source, comment, f)
    sources.save()
    assert os.path.exists(f)
    f_handle = open(f, 'r')
    actual = f_handle.read()
    expected = source+' '+comment+'\n'
    assert actual == expected
    f_handle.close()


# Generated at 2022-06-25 02:04:05.338529
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    list = SourcesList(None)
    assert(list.dump() == {})
    list.load('/tmp/test_SourcesList_modify')

    # modify file
    list.modify('/tmp/test_SourcesList_modify', 0, enabled=True, source='test_0', comment='')
    list.modify('/tmp/test_SourcesList_modify', 1, enabled=False, source='test_1', comment='test_1')

    # modify source
    list.modify('/tmp/test_SourcesList_modify', 2, source='test_2', comment=None)
    list.modify('/tmp/test_SourcesList_modify', 3, source='test_3', comment='test_3')

    # modify comment

# Generated at 2022-06-25 02:04:08.140852
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    SourcesList(module)


# Generated at 2022-06-25 02:04:18.570944
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    sl = UbuntuSourcesList(module)
    # init source list
    source_list = [
        'deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main',
        'deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main',
        'deb http://ppa.launchpad.net/git-core/ppa/ubuntu bionic main',
        'deb-src http://ppa.launchpad.net/git-core/ppa/ubuntu bionic main',
    ]

    # add source list
    for line in source_list:
        sl.add_source(line)

    # remove source list
    for line in source_list:
        sl.remove_source(line)

    assert(len(list(sl)) == 0)



# Generated at 2022-06-25 02:04:28.296724
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={'codename': {'type': 'str'}, 'mode': {'type': 'raw'}})
    ansible_sl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=simulate_add_ppa_signing_key())
    ansible_sl.add_source('ppa:lxc-docker/lxc-docker')
    ansible_sl.save()
    ansible_sl.load(ansible_sl.default_file)
    ansible_sl.remove_source('ppa:lxc-docker/lxc-docker')
    ansible_sl.save()



# Generated at 2022-06-25 02:04:38.650492
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    src_list = SourcesList(None)

    src_list.add_source("deb http://example.com/devel trusty main contrib")
    assert(src_list.dump() == {'/etc/apt/sources.list': 'deb http://example.com/devel trusty main contrib\n'})

    src_list.add_source("deb http://example.com/devel trusty main contrib", "testing")
    assert(src_list.dump() == {'/etc/apt/sources.list': 'deb http://example.com/devel trusty main contrib # testing\n'})

    src_list.add_source("deb http://example.com/devel trusty main contrib", "testing2")

# Generated at 2022-06-25 02:04:39.673338
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule({}, {})
    obj = UbuntuSourcesList(module)
    assert obj == deepcopy(obj)


# Generated at 2022-06-25 02:04:45.096025
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    #testing invalid file path
    sources_list = SourcesList('')
    sources_list.files = {'/a/b/c/d/e':[{'source':'123'}]}
    sources_list.save()
    assert sources_list.files == {}
    assert sources_list._apt_cfg_dir('') == ''



# Generated at 2022-06-25 02:04:51.998849
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    test_module = AnsibleModule({}, False)
    test_UbuntuSourcesList = UbuntuSourcesList(test_module)
    test_UbuntuSourcesList._add_valid_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '# test_repo_0')
    test_UbuntuSourcesList._add_valid_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '# test_repo_0')
    test_UbuntuSourcesList._remove_valid_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    assert 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main' not in test_UbuntuSourcesList.repos_urls

# Unit test

# Generated at 2022-06-25 02:04:57.045761
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = MagicMock()
    sources = UbuntuSourcesList(module)
    sources.repos_urls = ['deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main',
                          'deb http://apt.postgresql.org/pub/repos/apt/ trusty-pgdg main']
    sources.remove_source('ppa:ansible/ansible')
    assert len(sources.repos_urls) == 1



# Generated at 2022-06-25 02:05:02.374827
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    file = '/some/file'
    sources = [(1, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
               (3, False, False, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
               (4, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
               (5, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]

    modules_mock = {'os': types.ModuleType('os'),
                    'apt_pkg': types.ModuleType('apt_pkg'),
                    'aptsources_distro': types.ModuleType('aptsources_distro')}

# Generated at 2022-06-25 02:06:18.608538
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    source_list = SourcesList()
    source_list.load('/etc/apt/sources.list')
    assert source_list.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial main restricted', '# See http://help.ubuntu.com/community/UpgradeNotes for how to upgrade to')


# Generated at 2022-06-25 02:06:22.176990
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Get text
    test_string = 'deb http://archive.canonical.com/ubuntu hardy partner'
    # Get SourcesList object
    test_SourcesList_add_source_object = SourcesList(None)
    # Test add_source function
    test_SourcesList_add_source_object.add_source(test_string)
    # Check integrity
    assert test_SourcesList_add_source_object.files[SourcesList._apt_cfg_file('Dir::Etc::sourcelist')][0][3] == test_string


# Generated at 2022-06-25 02:06:29.427557
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})

    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/ppa')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo')
    sources_list.add_source('ppa:foo/buzz')
    sources_list.add_source('ppa:foo/buzz')
    sources_list.save()

    repos_urls = ['deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main',
                  'deb http://ppa.launchpad.net/foo/buzz/ubuntu xenial main',
                  'deb http://ppa.launchpad.net/foo/ppa/ubuntu xenial main']


# Generated at 2022-06-25 02:06:38.109754
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.params['filename'] = None
            self.params['codename'] = None
            self.params['mode'] = None
            self.params['update_cache'] = None
        class FailJson:
            def __init__(self, module, msg):
                self.module = module
                self.msg = msg
            def __call__(self):
                raise Exception('[FAKE] %s' % self.msg)
        def fail_json(self, msg):
            raise self.FailJson(self, msg)
        class AtomicMove:
            def __init__(self, module, source, dest):
                self.module = module
                self.source = source
                self.dest = dest

# Generated at 2022-06-25 02:06:40.875978
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = Mock()
    module.params = {'codename': 'xenial'}
    UbuntuSourcesList(module)



# Generated at 2022-06-25 02:06:45.284870
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    test_SourcesList = SourcesList(None)
    test_SourcesList.add_source("deb http://archive.ubuntu.com/ubuntu/ trusty universe")
    assert("/etc/apt/sources.list.d/trusty.list" in test_SourcesList.files)
    assert("deb http://archive.ubuntu.com/ubuntu/ trusty universe" in test_SourcesList.files["/etc/apt/sources.list.d/trusty.list"])


# Generated at 2022-06-25 02:06:49.545274
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True, aliases=['name']),
            state=dict(required=False, default='present', choices=['present', 'absent']),
            update_cache=dict(default='no', type='bool'),
            filename=dict(required=False, default=None),
            mode=dict(required=False, default=None),
            update_cache_valid_age=dict(default=3600, type='int'),
            codename=dict(default=distro.codename, type='str'),
            dist=dict(default=distro.id, type='str'),
        ))
    module.params=dict(module.params.items())
    if module.params['state'] == 'present':
        module.params['update_cache'] = True


# Generated at 2022-06-25 02:06:51.338565
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    module.check_mode = True
    module.no_log = True
    sources_list = SourcesList(module)
    module.exit_json(changed=False, result=sources_list.dump())


# Generated at 2022-06-25 02:06:59.647542
# Unit test for function install_python_apt
def test_install_python_apt():

    for apt_pkg_name in ('python-apt', 'python3-apt'):
        module = AnsibleModule({'install_python_apt': True})
        with tempfile.NamedTemporaryFile('w', delete=False) as output:
            module.exit_json = lambda x: output.write(json.dumps(x))
            if getattr(apt_pkg, '__version__', None) is None:
                install_python_apt(module, apt_pkg_name)
                output.flush()
                module_output = json.loads(open(output.name).read())
                assert module_output == {'msg': '%s must be installed to use check mode' % apt_pkg_name}

# Generated at 2022-06-25 02:07:01.209818
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Test case-0
    sources_list_0 = SourcesList(None)
    test_case_0()



# Generated at 2022-06-25 02:08:44.163387
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line = '''\
# deb http://download.proxmox.com/debian/pve stretch pve-no-subscription
'''
    sl = SourcesList(line)
    sl.remove_source(line)
    assert not sl.contains_source(line)


# Generated at 2022-06-25 02:08:47.739329
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    if __name__ == "__main__":
        """
        Test if read sources are the same when saving the file.
        
        When saving the file, it creates a temporary file and re-reads it afterwards. If they are equal, it is because
        all the sources are preserved.
        
        """
        #test_case_1
        SourcesList.save()


# Generated at 2022-06-25 02:08:52.063401
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList()
    var_0.files = {
      '/etc/apt/sources.list.d/google-cloud-sdk.list': [
        (0, True, True, 'deb [arch=amd64] http://packages.cloud.google.com/apt cloud-sdk main', ''),
      ],
    }
    var_0.dump()
    var_0.save()


# Generated at 2022-06-25 02:08:57.120308
# Unit test for constructor of class SourcesList
def test_SourcesList():
    src_list = SourcesList(AnsibleModule)

    # Test for case when sources.list file does not exist
    assert src_list.default_file == '/etc/apt/sources.list'
    assert len(src_list.files) == 0
    assert len(list(src_list)) == 0
    assert src_list.dump() == {}

    # Test for case when sources.list file exists
    test_file_name = 'sources.list.example'
    test_file_path = '/tmp/sources.list.example'

# Generated at 2022-06-25 02:08:59.614028
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Create class instance
    src = SourcesList(10)

    # Create mock object so that function calls return a value
    f = Mock()
    f.return_value = 10

    # Now call the function with mock object as argument
    f.remove_source("test")


# Generated at 2022-06-25 02:09:00.900010
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    lineup = "deb http://archive.canonical.com/ubuntu hardy partner"
    comment = ""
    file = None
    test_case_0()



# Generated at 2022-06-25 02:09:02.680002
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    var_0 = get_add_ppa_signing_key_callback(module=None)
    assert isinstance(var_0, types.FunctionType) == True


# Generated at 2022-06-25 02:09:04.408418
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    line = 'deb http://packages.linuxmint.com rosa main import backport'
    comment = '# Nice mirror'
    file = None
    instance = SourcesList()
    instance.add_source(line, comment, file)



# Generated at 2022-06-25 02:09:05.250799
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_0 = SourcesList()
    var_0.load()


# Generated at 2022-06-25 02:09:06.086626
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sl = SourcesList()
    sl.save()
