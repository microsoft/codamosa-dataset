

# Generated at 2022-06-25 02:02:14.538765
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    var_1 = UbuntuSourcesList()


# Generated at 2022-06-25 02:02:21.749833
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # Create instance of class SourcesList
    test_instance = SourcesList(None)

    # Create temporary file

# Generated at 2022-06-25 02:02:25.672110
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    src = SourcesList(AnsibleModule(argument_spec={}))
    src.save()


# Generated at 2022-06-25 02:02:29.028266
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    var_0 = SourcesList(module = object())
    var_0.modify(file = object(), n = object(), enabled = None, source = None, comment = None)


# Generated at 2022-06-25 02:02:33.450471
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    temp_sourcesList = SourcesList()
    temp_file = ""
    temp_n = 0
    temp_enabled = None
    temp_source = None
    temp_comment = None
    temp_sourcesList.modify(temp_file, temp_n, temp_enabled, temp_source, temp_comment)


# Generated at 2022-06-25 02:02:40.894958
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Local variable(s) initialization
    str_0 ="   deb http://archive.ubuntu.com/ubuntu xenial-backports main universe restricted multiverse   #   "
    str_1 ="deb https://apt.dockerproject.org/repo ubuntu-xenial main"
    str_2 ="deb http://archive.ubuntu.com/ubuntu xenial-backports main universe restricted multiverse   #   "
    str_3 ="deb http://archive.ubuntu.com/ubuntu xenial-backports main universe restricted multiverse   #   "
    str_4 ="deb https://apt.dockerproject.org/repo ubuntu-xenial main"
    str_5 ="deb https://apt.dockerproject.org/repo ubuntu-xenial main"

# Generated at 2022-06-25 02:02:52.860256
# Unit test for function install_python_apt
def test_install_python_apt():
    class AnsibleModule():
        def __init__(self):
            self.params = {}
            self.check_mode = True
            self.fail_json = print
            self.run_command = self.do_mock_run_command
            self.get_bin_path = self.do_mock_get_bin_path

        def do_mock_get_bin_path(self, cmd):
            return cmd

        def do_mock_run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return 0, "", ""

    #Test correct comand
    module = AnsibleModule()
    install_python_apt(module, 'python-apt')

# Generated at 2022-06-25 02:02:56.692944
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    var_0 = SourcesList(module)
    var_1 = arg_0
    var_2 = arg_1
    var_3 = arg_2
    var_4 = arg_3
    var_5 = arg_4
    var_0.modify(var_1, var_2, var_3, var_4, var_5)
    pass


# Generated at 2022-06-25 02:02:59.549494
# Unit test for function revert_sources_list
def test_revert_sources_list():
    var_0 = 'source_before'
    var_1 = 'source_after'
    var_2 = 'sources_list'
    revert_sources_list(var_0, var_1, var_2)



# Generated at 2022-06-25 02:03:01.787298
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    inst = SourcesList()
    inst.modify(file, n, enabled=None, source=None, comment=None)


# Generated at 2022-06-25 02:03:34.379410
# Unit test for constructor of class SourcesList
def test_SourcesList():

    # try to create a sourceslist object with a module.
    module = AnsibleModule(argument_spec=dict())
    sources_list = SourcesList(module)
    assert isinstance(sources_list, SourcesList)



# Generated at 2022-06-25 02:03:34.969982
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    return


# Generated at 2022-06-25 02:03:40.209742
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({'repo': 'deb http://archive.canonical.com/ubuntu hardy partner', 'state': 'present'}, "test_SourcesList_dump")
    apt_repository = apt_repository(module)
    _sources_list = SourcesList(module)

    SourcesList.dump()
    return

if __name__ == '__main__':
    # Run test_case_0
    test_case_0()
    # Run test_SourcesList_dump
    test_SourcesList_dump()

# Generated at 2022-06-25 02:03:44.853380
# Unit test for function install_python_apt
def test_install_python_apt():
    print("test_install_python_apt")
    # TODO: add a real test

    return test_case_0()


# Generated at 2022-06-25 02:03:48.763710
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    main()


# Generated at 2022-06-25 02:03:51.570415
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Parameters
    module = None

    # Class instance
    UbuntuSourcesList_class = UbuntuSourcesList(module)

    # Deep copy of an instance
    deep_copy = UbuntuSourcesList_class.__deepcopy__()

    # Assert
    assert deep_copy is not None


# Generated at 2022-06-25 02:03:55.121241
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList()
    var_0 = var_0.save()


# Generated at 2022-06-25 02:04:00.294986
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sources_list_obj = SourcesList()
    sources_list_obj.modify("test_file", "test_n")


# Generated at 2022-06-25 02:04:01.329933
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    object0 = SourcesList()
    object0.save()


# Generated at 2022-06-25 02:04:04.214941
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={
    })

    obj_SourcesList = SourcesList(module)
    obj_SourcesList.modify("", "")


# Generated at 2022-06-25 02:04:35.580641
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-25 02:04:36.238212
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    assert True


# Generated at 2022-06-25 02:04:38.262061
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    my_dict = main()
    my_dump = json.dumps(my_dict)
    print(my_dump)
    assert my_dump is not None


# Generated at 2022-06-25 02:04:41.675789
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList(main())
    var_0.dump()


# Generated at 2022-06-25 02:04:43.484758
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList()
    var_0.dump()


# Generated at 2022-06-25 02:04:49.832461
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = dict()
    sources_after = dict()
    sourceslist_before = SourcesList(module)

    try:
        revert_sources_list(sources_before, sources_after, sourceslist_before)
    except:
        raise AssertionError

    sources_before = dict()
    sources_after = dict()
    sourceslist_before = SourcesList(module)

    try:
        revert_sources_list(sources_before, sources_after, sourceslist_before)
    except:
        raise AssertionError

    sources_before = dict()
    sources_after = dict()
    sourceslist_before = SourcesList(module)

    try:
        revert_sources_list(sources_before, sources_after, sourceslist_before)
    except:
        raise AssertionError

   

# Generated at 2022-06-25 02:04:50.552767
# Unit test for function install_python_apt
def test_install_python_apt():
    pass

# Generated at 2022-06-25 02:04:55.104415
# Unit test for function install_python_apt
def test_install_python_apt():
    args = get_test_install_python_apt_default_args()
    rc = install_python_apt(args['module'], args['apt_pkg_name'])
    # Assertion
    assert rc


# Generated at 2022-06-25 02:04:59.259688
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    var_0 = SourcesList(module)
    return var_0


# Generated at 2022-06-25 02:05:02.583978
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        main()
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            raise

if __name__ == '__main__':
    try:
        main()
    except SystemExit as inst:
        if inst.args[0] is True:
            raise



# Generated at 2022-06-25 02:06:00.633627
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():

    src = SourcesList()



# Generated at 2022-06-25 02:06:06.571872
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    with tempfile.NamedTemporaryFile(mode='w', delete=False) as f:
        var_1 = SourcesList(None)
        var_1.files = {f.name: [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]}
        var_1.save()
        f.close()
        assert open(f.name).read() == 'deb http://archive.canonical.com/ubuntu hardy partner\n'
    os.remove(f.name)


# Generated at 2022-06-25 02:06:07.537344
# Unit test for function main
def test_main():
    pass
    #main()



# Generated at 2022-06-25 02:06:09.927094
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    ub_sources_list0 = UbuntuSourcesList(module)
    ub_sources_list0.remove_source('')



# Generated at 2022-06-25 02:06:10.670645
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    UbuntuSourcesList(module)


# Generated at 2022-06-25 02:06:12.611764
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_0 = SourcesList('self')
    var_1 = dump()
    var_1 = dump()
    assert var_1 == 0
    assert var_1 == 0


# Generated at 2022-06-25 02:06:13.777150
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_0 = _expand_path()


# Generated at 2022-06-25 02:06:14.545529
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    assert False


# Generated at 2022-06-25 02:06:16.050849
# Unit test for function main
def test_main():
    main()


if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:06:18.967436
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sources_path = None
    sources_path = '/etc/apt/sources.list'
    var_1 = SourcesList(arg_0)
    var_1.save(sources_path)


# Generated at 2022-06-25 02:07:29.535214
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    base = UbuntuSourcesList({"module": {"params": {"codename": "trusty"}}})
    print("base =", base)
    

# Generated at 2022-06-25 02:07:30.277813
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-25 02:07:30.949557
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = main()


# Generated at 2022-06-25 02:07:32.484490
# Unit test for function main
def test_main():
    # Test case 0
    try:
        test_case_0()
    except:
        print("Caught exception")
        print_exc()
        return 1


# Generated at 2022-06-25 02:07:36.987147
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = "python3-apt"
    if HAVE_PYTHON_APT:
        try:
            # Install the package if it is not already installed
            import apt
            import apt_pkg
            import aptsources.distro as aptsources_distro
            distro = aptsources_distro.get_distro()
        except ImportError:
            install_python_apt(module, apt_pkg_name)
    else:
        install_python_apt(module, apt_pkg_name)



# Generated at 2022-06-25 02:07:41.094048
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'test.list')
    f = open(tmp_file, 'w')
    f.write('deb foo bar\n')
    f.close()
    sl = SourcesList(None)
    sl.load(tmp_file)
    expected_result = {tmp_file: [(0, True, True, 'deb foo bar', '')]}
    assert sl.files == expected_result


# Generated at 2022-06-25 02:07:42.630143
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_0 = UbuntuSourcesList()
    var_1 = 'test_value_2'
    var_0.remove_source(var_1)


# Generated at 2022-06-25 02:07:43.288276
# Unit test for constructor of class SourcesList
def test_SourcesList():
    test_var = SourcesList()


# Generated at 2022-06-25 02:07:47.497933
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    # Create a new object of class SourcesList
    # Test with a valid source string
    try:
      source = SourcesList
      source.add_source('deb http://archive.ubuntu.com/ubuntu hardy-updates universe', 'ubuntu universe')
    except InvalidSource:
      print("Failed Test Case 0")


# Generated at 2022-06-25 02:07:48.572053
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == 0, var_0

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:10:25.826880
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(
        argument_spec=dict(state=dict(default='present', choices=['present', 'absent'], type='str'),
        repo=dict(required=True, type='str'),
        filename=dict(default=None, type='str'),
        codename=dict(default=None, type='str'),
        mode=dict(default=DEFAULT_SOURCES_PERM, type='str')),
        supports_check_mode=True)

    assert get_add_ppa_signing_key_callback(module) == None


# Generated at 2022-06-25 02:10:35.632906
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    var_SourcesList = SourcesList()
    var_file = random.sample([str(x) for x in range(0, 256)], random.randint(0, 256))
    var_n = random.sample([str(x) for x in range(0, 256)], random.randint(0, 256))
    var_enabled = False
    var_source = random.sample([str(x) for x in range(0, 256)], random.randint(0, 256))
    var_comment = random.sample([str(x) for x in range(0, 256)], random.randint(0, 256))
    var_return = var_SourcesList.modify(var_file, var_n, var_enabled, var_source, var_comment)
    assert_equal(var_return, None)

# Unit test

# Generated at 2022-06-25 02:10:36.369991
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass


# Generated at 2022-06-25 02:10:42.097128
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    if len(var_0.files) == 1:
        var_0.modify(filename='/etc/apt/sources.list', n=0, enabled=True, source='src', comment='comment')
    else:
        var_0.modify(filename='/etc/apt/sources.list.d/test-repo_test.list', n=0, enabled=True, source='src', comment='comment')


# Generated at 2022-06-25 02:10:44.403709
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.common.removed import removed
    removed("This test is removed after Ansible 2.10, as the module util class has been removed")


# Generated at 2022-06-25 02:10:48.484906
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    args = dict(line='deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    uut = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)
    uut.remove_source(**args)
    var_0 = uut.LP_API
    assert not isinstance(var_0, Exception)
    result = uut.dump()
    var_1 = result[result.keys()[0]]
    assert not isinstance(var_1, BaseException)
    assert not isinstance(result, BaseException)
    assert 1 == len(result)


# Generated at 2022-06-25 02:10:49.157512
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    assert True


# Generated at 2022-06-25 02:10:50.882280
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    arg = "nonexistent"
    var_1 = SourcesList(arg)
    var_1.save()

if __name__ == "__main__":
    test_case_0()


# Generated at 2022-06-25 02:10:54.904536
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():

    module_0 = AnsibleModule({}, {}, False)
    param_0 = module_0.params
    param_0["codename"] = "codename_0"
    param_0["filename"] = "filename_0"

    target_0 = UbuntuSourcesList(module_0, add_ppa_signing_keys_callback={})
    ret_0 = target_0.__deepcopy__()

    assert ret_0.module is not None
    assert ret_0.add_ppa_signing_keys_callback is not None



# Generated at 2022-06-25 02:10:56.804680
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_0 = SourcesList()
    var_1 = 'deb http://archive.canonical.com/ubuntu trusty partner'
    var_0.remove_source(var_1)
