

# Generated at 2022-06-25 02:02:16.061262
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    test_case_index = 0
    print('----------- Starting test for SourcesList.load() method -----------')
    module_specific_arguments = dict(
        debug=dict(type='bool', default=False),
    )
    #build a dummy module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    #test load method with default file
    test_case_0()
    #test load method with non-default file
    test_case_1()
    print('----------- Finished testing for SourcesList.load() method -----------')
    #build a dummy module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    #test modigy method with default file
    test_SourcesList_modify()

# Generated at 2022-06-25 02:02:25.073626
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.common.respawn

    # Create a fake ansible module
    class FakeAnsibleModule(object):
        PARAM_NAME = "repo"  # Parameter name declared in the metadata
        PARAM_VALUE = "Test"  # Parameter value to be passed

        def __init__(self):
            self.name = "apt_repository"
            self.params = {"params": "params"}
            self.params[self.PARAM_NAME] = self.PARAM_VALUE
            self.paused = False
            self.changed = False
            self.called_exit_json = False
            self.called_fail_json = False

# Generated at 2022-06-25 02:02:30.265814
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({'codename': 'trusty'})
    # Testing that codename is passed correctly to superclass
    assert UbuntuSourcesList(module, add_ppa_signing_keys_callback=None).codename == 'trusty'



# Generated at 2022-06-25 02:02:39.764883
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    add_ppa_signing_keys_callback = lambda cmd: None

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['present', 'absent']),
            repo=dict(default='universe'),
            comment=dict(default=''),
            update_cache=dict(default=False, type='bool'),
            validate_certs=dict(default=True, type='bool'),
        ),
        supports_check_mode=True
    )
    sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)

    line = 'deb http://archive.ubuntu.com/ubuntu/ bionic-security universe'

# Generated at 2022-06-25 02:02:47.531722
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    test_module = AnsibleModule({'codename': 'bionic'})
    test_UbuntuSourcesList = UbuntuSourcesList(test_module)
    test_UbuntuSourcesList.add_source("deb [arch=amd64] http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main")
    result = test_UbuntuSourcesList.dump()
    values = result.values()
    test_module.assertEqual(values, list(values))



# Generated at 2022-06-25 02:02:51.617093
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = dict()
    module['fail_json'] = lambda *args, **kwargs: os.abort()
    module['atomic_move'] = lambda *args, **kwargs: None
    SourcesList.save(SourcesList(module))


# Generated at 2022-06-25 02:02:59.586011
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # with default codename
    usl1 = UbuntuSourcesList(object())
    assert usl1.codename == distro.codename

    # with specified codename
    codename = 'xenial'
    usl2 = UbuntuSourcesList(object(), codename=codename)
    assert usl2.codename == codename

    # updated codename
    codename = 'yakkety'
    usl2.codename = codename
    assert usl2.codename == codename

    # __deepcopy__
    usl3 = copy.deepcopy(usl2)
    assert usl3.codename == usl2.codename


# Generated at 2022-06-25 02:03:06.470522
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # Build up a mock module object.
    module_args = {}
    module_args['codename'] = 'xenial'
    module_args['state'] = 'present'
    module_args['update_cache'] = False
    module_args['src'] = 'test_src'

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    sourcelist = UbuntuSourcesList(module=module)
    assert sourcelist.codename == 'xenial'


# Generated at 2022-06-25 02:03:07.659671
# Unit test for constructor of class SourcesList
def test_SourcesList():
    test_SourcesList_0 = SourcesList()


# Generated at 2022-06-25 02:03:11.364469
# Unit test for constructor of class SourcesList
def test_SourcesList():
    """Tests constructor of SourcesList class."""
    module = AnsibleModule(argument_spec={})

    # pylint: disable=unused-argument
    sl = SourcesList(module)

    test_SourcesList()



# Generated at 2022-06-25 02:03:46.026465
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from mock import patch
    import requests

    module_args = dict(
        state='present',
        repo='ppa:graphics-drivers/ppa',
        update_cache=False,
        skip_validate=False,
    )

    with patch.object(AnsibleModule, 'run_command') as run_command:
        run_command.return_value = (0, '', '')

        # Run deepcopy
        with patch.object(requests, 'request') as request:
            request.return_value = 0, dict(status=200, url=''), ''
            module = AnsibleModule(module_args)
            deepcopy(UbuntuSourcesList(module))


# Generated at 2022-06-25 02:03:50.261896
# Unit test for function revert_sources_list
def test_revert_sources_list():

    # Setup:
    # New temp directory
    tempdir = tempfile.mkdtemp()
    sourceslist_dir = os.path.join(tempdir, 'sourceslist')
    os.mkdir(sourceslist_dir)

    # Make a list of files with content to be put into the new temp directory
    files_to_create = {
        'file1': '\n'.join(['line0']),
        'file2': '\n'.join(['line0', 'line1']),
        'file3': '\n'.join(['line0', 'line1', 'line2']),
    }

    # Write out the files with content

# Generated at 2022-06-25 02:04:01.394543
# Unit test for function main

# Generated at 2022-06-25 02:04:11.102883
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    mod = AnsibleModule({})

    sl = SourcesList(mod)

    # create dummy sources files
    fd, path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.write('# deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.close()
    sl.load(path)
    os.remove(path)

    # load sources.list
    os.environ['APT_CONFIG'] = os.path.abspath('./apt.conf')
    sl = SourcesList(mod)

    for file, n, enabled, source, comment in sl:
        print(file, n, enabled, source, comment)



# Generated at 2022-06-25 02:04:13.946296
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_case_0()


# Generated at 2022-06-25 02:04:15.839467
# Unit test for constructor of class SourcesList
def test_SourcesList():
    """Unit test for SourcesList"""
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    assert sourceslist is not None



# Generated at 2022-06-25 02:04:20.385426
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = FakeModule()
    add_ppa_signing_keys_callback = lambda command: None
    ubuntu_sources_list = UbuntuSourcesList(
        module,
        add_ppa_signing_keys_callback=None,
    )
    copy = copy.deepcopy(ubuntu_sources_list)
    assert isinstance(copy, UbuntuSourcesList)
    assert copy.module is module
    assert copy.add_ppa_signing_keys_callback is None


# Generated at 2022-06-25 02:04:26.076153
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = FakeModule()
    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module)


# Generated at 2022-06-25 02:04:31.831690
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """
    Test for method save of class SourcesList
    """
    """
    1. Create a temporary directory
    2. Create dummy file in temp directory
    3. Create dummy filename
    4. Add dummy file to self.files as key and dummy filename as a value
    
    5. Save file
    6. If no exception is raised, then the test passes.
    """
    m = AnsibleModule(argument_spec={})
    
    #Create a temporary directory
    tempdir = tempfile.mkdtemp()
    
    #Create dummy filename
    filename = 'test1.list'
    
    #Create dummy file in temp directory
    open(os.path.join(tempdir, filename), 'w').close()
    
    #Create SourcesList object
    sources_list = SourcesList(m)
    #Add dummy file to self

# Generated at 2022-06-25 02:04:42.565321
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources = SourcesList(AnsibleModule(argument_spec={}))
    sources.files = {'file1': [(0, False, False, '', ''),
                               (1, True, True, 'deb http://somerepo.org somerepo main', ''),
                               (2, False, False, '#deb http://somerepo.org somerepo main', 'not a valid deb source')],
                     'file2': [(0, True, True, 'deb http://somerepo.org somerepo main', ''),
                               (1, True, True, 'deb http://someotherrepo.org someotherrepo main', '')]}
    iterator = iter(sources)
    assert next(iterator) == ('file1', 1, True, 'deb http://somerepo.org somerepo main', '')
   

# Generated at 2022-06-25 02:05:51.724751
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({}, check_invalid_arguments=False)
    s = SourcesList(module)
    # This is a simple test that this method not raise exceptions
    s.add_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    s.remove_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    s.remove_source('# deb http://archive.ubuntu.com/ubuntu xenial main')
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    s.add_source('# deb http://archive.ubuntu.com/ubuntu trusty main')
    s.remove_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    s.remove_source('# deb http://archive.ubuntu.com/ubuntu trusty main')


# Generated at 2022-06-25 02:06:00.561605
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    apt_pkg_name_2 = "python2-apt"
    apt_pkg_name_3 = "python-apt"
    # test for python2
    if PY3:
        install_python_apt(module, apt_pkg_name_2)
        # test for python3
        install_python_apt(module, apt_pkg_name_3)
    else:
        install_python_apt(module, apt_pkg_name_3)

# convert of the source.list format to the format used by aptsources.distro.add_source_from_line

# Generated at 2022-06-25 02:06:02.022873
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    global sources_list
    sources_list = SourcesList('../test/sources.list')



# Generated at 2022-06-25 02:06:06.176382
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    try:
        # Test raised InvalidSource exception.
        # Python 3 syntax.
        with open(os.devnull, 'r') as f:
            f = SourcesList(module)._parse('deb http://example.com', raise_if_invalid_or_disabled=True)
    except InvalidSource:
        pass



# Generated at 2022-06-25 02:06:10.821318
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    test_file = "test_ansible_apt_repository"
    if os.path.exists(test_file):
        os.remove(test_file)
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list._add_valid_source('deb http://localhost:9999/ubuntu xenial extra', '', file=test_file)
    sources_list.save()
    assert os.path.exists(test_file)


# Generated at 2022-06-25 02:06:11.841224
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # UbuntuSourcesList()
    UbuntuSourcesList({}, {})



# Generated at 2022-06-25 02:06:13.719217
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    SourcesList(module).dump()


# Generated at 2022-06-25 02:06:22.222974
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    file_0 = '%s/%s' % (tempfile.gettempdir(), 'apt-repository-file-0.list')
    file_1 = '%s/%s' % (tempfile.gettempdir(), 'apt-repository-file-1.list')
    with open(file_0, 'w') as f:
        f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
    with open(file_1, 'w') as f:
        f.write('deb http://dl.google.com/linux/chrome/deb/ stable main\n')
    with open(file_1, 'a') as f:
        f.write('\n')
    sources_list = SourcesList(TestAnsibleModule())
    sources_list.load(file_0)

# Generated at 2022-06-25 02:06:29.452934
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    class SourcesList:
        def add_source(self, line, comment='', file=None):
    '''
    # Note: we are testing here only subclassing and input validation,
    #       not writing to files.

    # class SourcesListTest(SourcesList):
    #     def _expand_path(self, filename):
    #         return filename
    #     def _choice(self, new, old):
    #         return new
    #     def _apt_cfg_file(filespec):
    #         return 'sources'
    #     def _apt_cfg_dir(filespec):
    #         return '.'
    #     def _parse(self, line, raise_if_invalid_or_disabled=True):
    #         return True, True, line, 'test comment'
    #     def

# Generated at 2022-06-25 02:06:38.074958
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule({
        'codename': 'xenial'
    })

    ubuntu_sources = UbuntuSourcesList(module)

    source = 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main'
    ubuntu_sources.add_source(source)
    assert(ubuntu_sources.files['/etc/apt/sources.list.d/foo_bar.list'][0] == (0, True, True, source, ''))

    source = 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main'
    ubuntu_sources.add_source(source, comment='baz')

# Generated at 2022-06-25 02:09:00.303065
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    sourcesList = SourcesList(module)
    sourcesList.save()


# Generated at 2022-06-25 02:09:09.302445
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # test set up
    class mock_sources_list(object):
        def __init__(self):
            self.files = {}

        def modify(self, *args, **kwargs):
            filename = args[0]
            if filename in self.files:
                self.files[filename].append(args)
            else:
                self.files[filename] = [args]

        def __getitem__(self, key):
            return self.files[key]

        def __setitem__(self, key, value):
            self.files[key] = value

        def keys(self):
            return list(self.files.keys())

    sources_before = mock_sources_list()
    sources_after = mock_sources_list()


# Generated at 2022-06-25 02:09:14.626577
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={'filename': dict(required=False, type='str')})
    filename = module.params.get('filename')

    sources = SourcesList(module)

    valid_sources = 0
    for file, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            if valid:
                valid_sources += 1
                assert(file in filename)
                assert(n == valid_sources - 1)
                assert(enabled)
                assert(source.startswith('deb ') or source.startswith('deb-src '))

    return valid_sources


# Generated at 2022-06-25 02:09:20.119811
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModuleMock()
    m = UbuntuSourcesList(module)

    # test case 0
    m.load("sample.list")
    m.remove_source("deb https://download.sublimetext.com/ apt/stable/")

    expected = {"sample.list": "#deb https://download.sublimetext.com/ apt/stable/\n"}
    if m.dump() != expected:
        raise Exception("remove_source of class UbuntuSourcesList failed! expected: %s" % expected)
    # test case 1
    m.load("sample1.list")
    m.remove_source("ppa:ubuntu-wine/ppa")


# Generated at 2022-06-25 02:09:24.388549
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({}, {'ANSIBLE_MODULE_ARGS': {}})
    sources_list = SourcesList(module)
    file = 'test/file'
    source_valid = "deb http://pack.repository.com/ /"
    source_valid_disabled = "#" + source_valid
    source_invalid = "invalid source"
    sources_list.files[file].extend([
        (0, True, True, source_valid, "comment 0"),
        (1, True, False, source_valid, "comment 1"),
        (2, False, True, source_invalid, "comment 2")
        ])
    sources_list.save()
    sources_list_new = SourcesList(module)
    sources_list_new.load(file)
    sources_list_new.save()

# Generated at 2022-06-25 02:09:32.291433
# Unit test for constructor of class SourcesList
def test_SourcesList():
    assert sys.version_info[:2] == (2, 7)      # this test can run only with Python 2.7
    module = AnsibleModule(argument_spec={})
    lst = SourcesList(module)


# Generated at 2022-06-25 02:09:38.809645
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['present', 'absent']),
        repo=dict(required=True),
        update_cache=dict(default=False, type='bool'),
        filename=dict(default=None),
        validate_certs=dict(default=True, type='bool'),
        mode=dict(default=None, type='raw'),
        keyserver=dict(default='keyserver.ubuntu.com', type='str')))

    result = dict(
        changed=0,
        stdout_lines=[],
        msg=''
    )

    sources_list = SourcesList(module=module)


# Generated at 2022-06-25 02:09:43.781445
# Unit test for function main

# Generated at 2022-06-25 02:09:48.084795
# Unit test for function main
def test_main():
    in_output = ('''
        {
            "changed": false,
            "diff": {
                "before": "",
                "after": "deb http://ppa.launchpad.net/dans-couch/nimbus/ubuntu precise main"
            },
            "repo": "ppa:dans-couch/nimbus",
            "state": "present"
        }
    ''')

    in_output = json.loads(in_output)


# Generated at 2022-06-25 02:09:52.998384
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.files['/etc/apt/sources.list'] = [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main', None)]
    ubuntu_sources_list.remove_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    assert None == ubuntu_sources_list.files.get('/etc/apt/sources.list', None)
