

# Generated at 2022-06-25 02:02:21.399760
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    complex_1 = None
    ubuntu_sources_list_1 = UbuntuSourcesList(complex_1)

    line = "deb [arch=amd64] http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main"
    ubuntu_sources_list_1.remove_source(line)

    line = "ppa:mozillateam/ppa"
    ubuntu_sources_list_1.remove_source(line)

    line = "deb [arch=amd64] http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main"
    ubuntu_sources_list_1.remove_source(line)

    line = "ppa:mozillateam/ppa"
    ubuntu_sources_list_1.remove_source

# Generated at 2022-06-25 02:02:31.716745
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    test_SourcesList_save.test_file0 = '/tmp/ansible_apt_repository_sources_list_tests.test_SourcesList_save.tmp0'
    test_SourcesList_save.test_file1 = '/tmp/ansible_apt_repository_sources_list_tests.test_SourcesList_save.tmp1'
    test_SourcesList_save.test_file2 = '/tmp/ansible_apt_repository_sources_list_tests.test_SourcesList_save.tmp2'
    test_SourcesList_save.test_file3 = '/tmp/ansible_apt_repository_sources_list_tests.test_SourcesList_save.tmp3'

# Generated at 2022-06-25 02:02:34.615600
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    complex_0 = None
    sources_list_0 = SourcesList(complex_0)
    test_SourcesList___iter__.io_buf = ""
    sources_list_0.__iter__()

test_SourcesList___iter__.io_buf = ""


# Generated at 2022-06-25 02:02:41.861468
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Create a simple SourcesListConfig object
    aSourcesListConfig = SourcesListConfig()
    aSourcesListConfig.deb_src = [
        {
            'country': 'United States',
            'mirror_url': 'http://mirrors.kernel.org/ubuntu',
            'suite': 'xenial',
            'repos': ['main', 'restricted'],
            'components': ['main']
        }
    ]
    aSourcesListConfig.deb = [
        {
            'country': 'United States',
            'mirror_url': 'http://mirrors.kernel.org/ubuntu',
            'suite': 'xenial',
            'repos': ['main', 'restricted'],
            'components': ['main']
        }
    ]

# Generated at 2022-06-25 02:02:52.921295
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    complex_0 = None
    sources_list_0 = SourcesList(complex_0)
    sources_list_0.modify('', 0, True, 'deb http://packages.dotdeb.org jessie all', '# Added by Ansible')
    sources_list_0.modify('.', 1, True, 'deb-src http://packages.dotdeb.org jessie all', '# Added by Ansible')
    sources_list_0.modify('..', 2, True, 'deb http://repo.percona.com/apt jessie main', '')
    sources_list_0.modify('...', 3, True, 'deb-src http://repo.percona.com/apt jessie main', '')

# Generated at 2022-06-25 02:02:57.705596
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    complex_1 = None
    ubuntu_sources_list_0 = UbuntuSourcesList(complex_1)
    line_0 = '''deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'''
    ubuntu_sources_list_0.remove_source(line_0)


# Generated at 2022-06-25 02:03:01.874725
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    complex_0 = None
    ubuntu_sources_list_0 = UbuntuSourcesList(complex_0)
    assert isinstance(ubuntu_sources_list_0.__deepcopy__(), UbuntuSourcesList)


# Generated at 2022-06-25 02:03:04.579101
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    if test_case_0() == True:
        print("Unit test for function test_case_0")
else:
    main()

# Generated at 2022-06-25 02:03:07.622395
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    complex_0 = None
    dumpstruct = {}
    ubuntu_sources_list_0 = UbuntuSourcesList(complex_0)
    dumpstruct = ubuntu_sources_list_0.dump()
    return dumpstruct



# Generated at 2022-06-25 02:03:09.625805
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    assert ubuntu_sources_list_0.remove_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main') == None


# Generated at 2022-06-25 02:03:51.047715
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    test_0 = SourcesList(None)

    str_0 = 'deb cdrom:[Debian GNU/Linux 7.0.0 _Wheezy_ - Official amd64 DVD Binary-1 20130528-10:51]/ wheezy contrib main'
    test_0.add_source(str_0)

    str_1 = 'deb cdrom:[Debian GNU/Linux 7.0.0 _Wheezy_ - Official amd64 DVD Binary-1 20130528-10:51]/ wheezy contrib main '
    test_0.add_source(str_1)

    str_2 = '  deb cdrom:[Debian GNU/Linux 7.0.0 _Wheezy_ - Official amd64 DVD Binary-1 20130528-10:51]/ wheezy contrib main'

# Generated at 2022-06-25 02:04:01.424899
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    str_1 = 'deb cdrom:[Ubuntu-Server 14.04 LTS _Trusty Tahr_ - Release amd64 (20150423)]/ trusty main restricted'
    str_2 = '#deb cdrom:[Ubuntu-Server 14.04 LTS _Trusty Tahr_ - Release amd64 (20150423)]/ trusty main restricted'
    str_3 = 'deb http://mirror.rackspace.com/ubuntu trusty main restricted'
    str_4 = 'deb http://mirror.rackspace.com/ubuntu trusty-updates main restricted'
    str_5 = 'deb http://mirror.rackspace.com/ubuntu trusty universe'
    str_6 = 'deb http://mirror.rackspace.com/ubuntu trusty-updates universe'

# Generated at 2022-06-25 02:04:07.830901
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    str_1 = '..'
    sources_list_1 = SourcesList(str_1)

    str_2 = '...'
    sources_list_0 = SourcesList(str_2)

    str_3 = '....'
    sources_list_3 = SourcesList(str_3)

    str_4 = '.....'
    sources_list_2 = SourcesList(str_4)


# Generated at 2022-06-25 02:04:08.938552
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    assert callable(SourcesList.save)


# Generated at 2022-06-25 02:04:16.234616
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list_1 = SourcesList("bruv")
    sources_list_1.add_source("repo1")
    sources_list_1.add_source("repo2")
    expected_res_1 = "{'bruv': 'deb repo1\ndeb repo2\n'}"
    assert str(sources_list_1.dump()) == expected_res_1



# Generated at 2022-06-25 02:04:25.274861
# Unit test for function install_python_apt

# Generated at 2022-06-25 02:04:31.205714
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # SourcesList.dump() returns dict, so we deserialize it to compare with original later
    original_str = repr(SourcesList('.').dump())
    test_sources_list = SourcesList('.')

    # modify with passing all params
    test_sources_list.modify('/etc/apt/sources.list', 0, enabled=True, source='deb http://archive.canonical.com/ubuntu hardy partner', comment='')

    # modify with passing just one param
    test_sources_list.modify('/etc/apt/sources.list', 0, source='deb http://archive.canonical.com/ubuntu hardy partner')

    # modify with passing nothing
    test_sources_list.modify('/etc/apt/sources.list', 0)

    # assert if dicts are equal
   

# Generated at 2022-06-25 02:04:33.024655
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
  str_0 = '.'
  sources_list_0 = SourcesList(str_0)
  r = sources_list_0.dump()


# Generated at 2022-06-25 02:04:39.372634
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sources_list_0 = UbuntuSourcesList(None, None)
    sources_list_0.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')


# Generated at 2022-06-25 02:04:47.358873
# Unit test for function install_python_apt
def test_install_python_apt():
    global apt
    global apt_pkg
    global aptsources_distro
    global distro
    global HAVE_PYTHON_APT
    global DEFAULT_SOURCES_PERM

    apt = apt_pkg = aptsources_distro = distro = None
    DEFAULT_SOURCES_PERM = 0o644
    HAVE_PYTHON_APT = False
    apt_pkg_name = 'python-apt'
    module = AnsibleModule(argument_spec=dict(
        name=dict(required=True),
    ))

    lines = [
        'Failed to auto-install %s. Error was: \'%s\'' % (apt_pkg_name, 'Could not install package %s' % apt_pkg_name)
    ]

# Generated at 2022-06-25 02:06:03.933682
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    str_0 = '.'
    UbuntuSourcesList(str_0)



# Generated at 2022-06-25 02:06:06.181632
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 02:06:15.335734
# Unit test for function revert_sources_list
def test_revert_sources_list():
    str_0 = '.'
    str_1 = '.'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()

# Generated at 2022-06-25 02:06:18.568447
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    str_0 = '.'
    ubuntu_sources_list_2 = UbuntuSourcesList(str_0)
    ubuntu_sources_list_3 = ubuntu_sources_list_2.__deepcopy__()


# Generated at 2022-06-25 02:06:21.627097
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    str_0 = '.'
    sources_list_0 = UbuntuSourcesList(str_0)
    str_1 = 'ubuntu'
    str_2 = 'ppa'
    sources_list_0.add_source(str_1, str_2)


# Generated at 2022-06-25 02:06:27.115883
# Unit test for function install_python_apt
def test_install_python_apt():
    class AnsModule:
        def __init__(self):
            self.fail_json = lambda msg, **kwargs: sys.exit(1)
            self.check_mode = False

        def get_bin_path(self, apt_get, required=False):
            return '/usr/bin/apt-get'

        def run_command(self, *args, **kwargs):
            return (0, '', '')

    ans_mod = AnsModule()

    install_python_apt(ans_mod, 'python-apt')



# Generated at 2022-06-25 02:06:36.262135
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    str_0 = 'd.e.b'
    list_0 = ['', '_', '#']
    list_1 = ['', '', '']
    boolean_0 = all(list_0)
    boolean_1 = all([list_0[i_0] == list_1[i_0] for i_0 in range(len(list_0))])
    if boolean_0 == boolean_1:
        pass

# Generated at 2022-06-25 02:06:38.265537
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    apt_pkg_name = 'python3-apt'
    install_python_apt(module, apt_pkg_name)


# Generated at 2022-06-25 02:06:46.405833
# Unit test for function main
def test_main():
    test_sources_list = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/packaging/os/apt_repository.py'
    test_sources_list_before = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/packaging/os/apt_repository.py'
    test_sources_list_after = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/modules/packaging/os/apt_repository.py'


# Generated at 2022-06-25 02:06:49.208816
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sources_list_0 = UbuntuSourcesList('.')
    str_0 = 'ppa:maarten-fonville/android-studio'
    str_1 = 'ppa:maarten-fonville/android-studio'
    sources_list_0.add_source(str_0, str_1)
    str_0 = 'ppa:maarten-fonville/android-studio'
    sources_list_0.add_source(str_0)
