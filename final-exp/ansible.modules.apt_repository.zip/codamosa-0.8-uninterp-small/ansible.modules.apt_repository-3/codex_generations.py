

# Generated at 2022-06-25 02:02:19.859243
# Unit test for function main
def test_main():
    main()
    assert True


# Generated at 2022-06-25 02:02:25.097505
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sourceslist = UbuntuSourcesList(module)
    line = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'
    comment = '# Ansible PPA'
    sourceslist.add_source(line, comment)
    f = open('/etc/apt/sources.list.d/ansible_ansible_ubuntu.list', 'r')
    lines = f.readlines()
    f.close()
    if not '# Ansible PPA\n' in lines:
        print('Failed assert')
        return False
    os.remove('/etc/apt/sources.list.d/ansible_ansible_ubuntu.list')
    return True



# Generated at 2022-06-25 02:02:30.505720
# Unit test for function main

# Generated at 2022-06-25 02:02:38.611579
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    var_0 = SourcesList()
    var_1 = SourcesList()
    var_2 = SourcesList()
    var_3 = SourcesList()
    var_4 = SourcesList()
    var_5 = SourcesList()
    var_6 = SourcesList()
    var_7 = SourcesList()
    var_8 = SourcesList()
    var_9 = SourcesList()
    var_10 = SourcesList()
    var_11 = SourcesList()
    var_12 = SourcesList()
    var_13 = SourcesList()
    var_14 = SourcesList()
    var_15 = SourcesList()
    var_16 = SourcesList()
    var_17 = SourcesList()
    var_18 = SourcesList()
    var_19 = SourcesList()
    var_20 = SourcesList()
    var_21 = SourcesList()
   

# Generated at 2022-06-25 02:02:39.799350
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_sources_list = SourcesList(module)
    var_sources_list.save()


# Generated at 2022-06-25 02:02:46.248395
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    list0 = SourcesList(AnsibleModule)
    list0.load(list0._apt_cfg_file('Dir::Etc::sourcelist'))

if __name__ == '__main__':
    try:
        test_case_0()
    except:
        raise


# Generated at 2022-06-25 02:02:50.760355
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    input_buffer = io.StringIO()
    sys.stdout = input_buffer
    var_0 = SourcesList()
    var_0.__iter__()
    sys.stdout = sys.__stdout__
    assert input_buffer.getvalue() == ""


# Generated at 2022-06-25 02:02:52.706024
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_src = SourcesList(module)
    test_src.remove_source('http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')


# Generated at 2022-06-25 02:03:01.787085
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sourceslist = SourcesList(AnsibleModule(argument_spec={}, supports_check_mode=True))

# Generated at 2022-06-25 02:03:03.347108
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList.__iter__()


# Generated at 2022-06-25 02:03:37.514180
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_1 = SourcesList(None)
    var_2 = UbuntuSourcesList(None)
    var_2.__deepcopy__()


# Generated at 2022-06-25 02:03:38.744353
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList()
    assert None == var_0.__iter__()


# Generated at 2022-06-25 02:03:45.750845
# Unit test for function install_python_apt

# Generated at 2022-06-25 02:03:46.716391
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sl = UbuntuSourcesList(module)
    copy = copy.deepcopy(sl)
    assert copy is not None


# Generated at 2022-06-25 02:03:50.336562
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = ''
    sources_after = ''
    sourceslist_before = SourcesList('')
    test_case_0()

# Function run_command()

# Generated at 2022-06-25 02:03:58.429139
# Unit test for constructor of class SourcesList
def test_SourcesList():

    # print the constructor of the class SourcesList.
    m = AnsibleModule(argument_spec=dict(key=dict(required=False, type='str'), repo=dict(required=True, type='str'), state=dict(required=False, type='bool', default=False)))
    SourcesList = SourcesList(m)
    print(SourcesList)

reload(sys)
sys.setdefaultencoding('utf8')

s = SourcesList()

# Generated at 2022-06-25 02:04:08.283871
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    path = os.path.join(sys.path[0], '../../../test/runner/lib/ansible/module_utils/apt_repository.py')
    sys.path.append(path)
    import apt_repository

    # Initialization
    module = AnsibleModule(argument_spec=dict())
    sl = apt_repository.SourcesList(module)

    # Execution
    dumpstruct = sl.dump()

    # Verification
    assert len(dumpstruct) == 2
    assert '/etc/apt/sources.list' in dumpstruct
    assert '/etc/apt/sources.list.d/ansible_test.list' in dumpstruct

# Generated at 2022-06-25 02:04:09.580004
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sourcesList = SourcesList(1)
    output = sourcesList.load
    assert output == 0


# Generated at 2022-06-25 02:04:14.181972
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    obj_UbuntuSourcesList = UbuntuSourcesList(module)

    param_1 = ''
    UbuntuSourcesList.remove_source(obj_UbuntuSourcesList, param_1)

if __name__ == "__main__":
    main()

# Generated at 2022-06-25 02:04:15.469770
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_5 = main()
    var_5.save()


# Generated at 2022-06-25 02:05:07.314204
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sources_list = SourcesList("")
    file_path = sources_list._apt_cfg_file("Dir::Etc::sourcelist")
    try:
        os.makedirs("/etc")
    except OSError as err:
        if not os.path.isdir("/etc"):
            raise err
    fo = open(file_path, "w")

# Generated at 2022-06-25 02:05:08.132484
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    fake_module = AnsibleModule()


# Generated at 2022-06-25 02:05:09.152213
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    print('Test for add_source')
    main()


# Generated at 2022-06-25 02:05:14.480373
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    temp_srcs = SourcesList(None, '', [])
    temp_srcs.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    temp_srcs.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert(len(temp_srcs.lines) == 0)


# Generated at 2022-06-25 02:05:22.291225
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList()
    for tup_0 in var_0:
        assert isinstance(tup_0, tuple)
        assert len(tup_0) == 5
        var_1, var_2, var_3, var_4, var_5 = tup_0
        assert isinstance(var_1, str)
        assert isinstance(var_2, int)
        assert isinstance(var_3, bool)
        assert isinstance(var_4, str)
        assert isinstance(var_5, str)


# Generated at 2022-06-25 02:05:25.675154
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModuleMock()
    sl = UbuntuSourcesList(module)
    copy_sl = copy.deepcopy(sl)
    assert sl.module == copy_sl.module
    assert sl.new_repos == copy_sl.new_repos
    assert sl.files == copy_sl.files
    assert sl.codename == copy_sl.codename
    assert sl.default_file == copy_sl.default_file
    assert sl.add_ppa_signing_keys_callback == copy_sl.add_ppa_signing_keys_callback



# Generated at 2022-06-25 02:05:26.614020
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    print("Running test case 0")
    s = SouresList()


# Generated at 2022-06-25 02:05:33.672234
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    module.check_mode = False
    var_0 = SourcesList(module)
    var_1 = var_0.save()


# Generated at 2022-06-25 02:05:39.256350
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    global apt
    global apt_pkg
    sys.path.insert(0, './ansible_collections/ansible')

    try:
        from ansible.modules.packaging.os import apt_repository
    except:
        from ansible.modules.packaging.os import apt_repository

    apt = apt_pkg
    apt_pkg = apt_pkg
    apt_pkg.init_system()

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.tmpdir = tempfile.mkdtemp()
            self.fail_json = lambda **kwargs: exit(1)
            self.log = lambda _: None

        def mkdtemp(self):
            return self.tmpdir


# Generated at 2022-06-25 02:05:40.482097
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    a = UbuntuSourcesList('')
    b = copy.deepcopy(a)
    assert b is not None
    assert a is not b



# Generated at 2022-06-25 02:06:50.217779
# Unit test for function main
def test_main():
    # Stub out
    def test_case_0():
        pass

    test_case_0()

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 02:06:53.022396
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    var_0 = SourcesList(None)
    var_1 = None
    var_0.modify(var_1)
    var_2 = var_0.modify(var_1)


# Generated at 2022-06-25 02:07:01.086639
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Init object
    sl = UbuntuSourcesList(None, None)

    # Add your test cases

# Generated at 2022-06-25 02:07:09.488646
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Main test
    sources_before = {'/etc/apt/sources.list': ''}
    sources_after = {'/etc/apt/sources.list': ''}
    sourceslist_before = 'sourceslist_before'
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    expected = 'expected'
    assert var_0 == expected
    # Edge cases
    sources_before = {'/etc/apt/sources.list': ''}
    sources_after = {'/etc/apt/sources.list': ''}
    sourceslist_before = 'sourceslist_before'
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    expected = 'expected'
    assert var_0 == expected


# Generated at 2022-06-25 02:07:18.894866
# Unit test for function main
def test_main():
    ansible_module_0 = AnsibleModule(argument_spec=dict(repo=dict(required=True, type='str'), state=dict(default='present', choices=['absent', 'present'], type='str'), mode=dict(type='raw'), update_cache=dict(type='bool', aliases=['update-cache'], default=True), update_cache_retries=dict(type='int', default=5), update_cache_retry_max_delay=dict(type='int', default=12), filename=dict(type='str'), install_python_apt=dict(type='bool', default=True), validate_certs=dict(type='bool', default=True), codename=dict(type='str')), supports_check_mode=True)
    with pytest.raises(AnsibleFailJson):
        main()


# Generated at 2022-06-25 02:07:20.731417
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = UbuntuSourcesList({}, {})
    var_1 = []
    var_0.add_source(var_1)


# Generated at 2022-06-25 02:07:27.379279
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    def test_case_1():
        module = AnsibleModule({})
        sources = SourcesList(module)
        sources.files['/etc/apt/sources.list'] = [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ hardy main universe', 'comment'), (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ hardy-security main universe', 'comment'), (2, True, True, 'deb http://archive.ubuntu.com/ubuntu/ hardy-updates main universe', 'comment'), (3, True, True, 'deb http://archive.ubuntu.com/ubuntu/ hardy-backports main universe', 'comment'), (4, True, True, 'deb http://archive.ubuntu.com/ubuntu/ hardy partner', 'comment')]

# Generated at 2022-06-25 02:07:29.117627
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    srcs = SourcesList
    lines = ''
    for line in lines:
        srcs.append(srcs._parse(line))

    assert srcs


# Generated at 2022-06-25 02:07:30.829676
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList()
    var_1 = iter(var_0)
    var_2 = run_example(var_1, "SourcesList.__iter__")
    return var_2


# Generated at 2022-06-25 02:07:37.426625
# Unit test for function install_python_apt
def test_install_python_apt():
    inst = AnsibleModule(argument_spec=dict(
        repo=dict(required=True, type='str'),
        state=dict(default='present', choices=['absent', 'present']),
        mode=dict(),
        update_cache=dict(default=True, type='bool', aliases=['update-cache']),
        update_cache_retries=dict(default=5, type='int'),
        update_cache_retry_max_delay=dict(default=12, type='int'),
        validate_certs=dict(default=True, type='bool'),
        filename=dict(),
        codename=dict(),
        install_python_apt=dict(default=True, type='bool')
        )
    )
    var_0 = install_python_apt(inst, 'python-apt')



# Generated at 2022-06-25 02:08:51.766263
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class_0 = UbuntuSourcesList()
    assert class_0.remove_source("ppa:ubuntu-wine/ppa") == None


# Generated at 2022-06-25 02:08:53.123772
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    global apt_pkg
    var_0 = main()
    var_0.dump()


# Generated at 2022-06-25 02:08:58.812637
# Unit test for function install_python_apt
def test_install_python_apt():
    global HAVE_PYTHON_APT
    if PY3:
        HAVE_PYTHON_APT = False
    else:
        try:
            import apt
            import apt_pkg
            import aptsources.distro as aptsources_distro
            HAVE_PYTHON_APT = True
        except ImportError:
            HAVE_PYTHON_APT = False


    class AnsibleModuleFake():
        def __init__(self):
            self.params = {}
            self.check_mode = False

        @staticmethod
        def get_bin_path(command):
            return '/usr/bin/apt-get'

        @staticmethod
        def run_command(command):
            return (0, '', '')


# Generated at 2022-06-25 02:09:01.753287
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module_0 = AnsibleModule(
        argument_spec={
            'codename': {'type': 'str'},
        },
        supports_check_mode=True)
    assert type(UbuntuSourcesList(module_0)) == UbuntuSourcesList


# Generated at 2022-06-25 02:09:05.960897
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = 'apt_repository'
    expected = 'https://launchpad.net/api/1.0/~%s/+archive/%s'
    actual = get_add_ppa_signing_key_callback(module)
    assert expected == actual, 'Expected : %s, Actual : %s' % (expected, actual)


# Generated at 2022-06-25 02:09:09.404457
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # test case 0
    UbuntuSourcesList_remove_source_instance = UbuntuSourcesList()
    # test case 1
    test_case_1 = UbuntuSourcesList()
    test_case_1.remove_source('# deb https://packages.grafana.com/oss/deb stable main')


# Generated at 2022-06-25 02:09:15.570834
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():

    global module, state, mode, apt_update, install_python_apt
    global HAVE_PYTHON_APT, DEFAULT_SOURCES_PERM, apt, apt_pkg, aptsources_distro, distro, VALID_SOURCE_TYPES
    global InvalidSource, __name__
    global SourcesList, _expand_path, _suggest_filename, _parse, _apt_cfg_file, _apt_cfg_dir, load, save, dump
    global _choice, _add_valid_source, add_source, _remove_valid_source, remove_source, _test_case_0, test_case_0

    def _expand_path(filename):
        if '/' in filename:
            return filename

# Generated at 2022-06-25 02:09:16.970590
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    obj = UbuntuSourcesList()
    var_0 = obj.__deepcopy__()
    assert var_0 


# Generated at 2022-06-25 02:09:17.994376
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList()
    sl.modify(file, n, enabled=None, source=None, comment=None)


# Generated at 2022-06-25 02:09:19.197924
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sources_list = SourcesList(AnsibleModule)
    sources_list.load(real_dir + '/sources.list')
    sources_list.save()
