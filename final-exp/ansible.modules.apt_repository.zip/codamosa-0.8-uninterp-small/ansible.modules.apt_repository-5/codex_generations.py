

# Generated at 2022-06-25 02:02:16.232318
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # case: check that we are able to add valid deb source
    tmp_file = '/tmp/ansible.test.apt_repository.add_source.tmp'
    if os.path.isfile(tmp_file):
        os.remove(tmp_file)

    tmp_sources_list = SourcesList(AnsibleModule(
        argument_spec={},
    ))
    tmp_sources_list.add_source('deb http://archive.canonical.com/ubuntu trusty partner', file=tmp_file)
    tmp_sources_list.save()
    tmp_sources_list.load(tmp_file)
    assert next(tmp_sources_list) == (tmp_file, 0, True, 'deb http://archive.canonical.com/ubuntu trusty partner', '')

    # case: check that we

# Generated at 2022-06-25 02:02:20.568770
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList(AnsibleModule(
        argument_spec={},
    ))
    sl.load('/usr/share/doc/pulseaudio-module-gconf/examples/default.pa')


# Generated at 2022-06-25 02:02:26.023658
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    ppa = 'ppa:foo/bar'
    module = AnsibleModule(argument_spec=dict(codename='xenial'), supports_check_mode=True)
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source(ppa)
    sources_list.add_source(ppa, file='/etc/apt/sources.list.d/foo.list')
    sources_list.add_source('deb http://example.com testing main', comment='test')
    sources_list.add_source('invalid line', file='/etc/apt/sources.list.d/example.list')
    assert 'foo.list' in sources_list.files
    assert 'example.list' in sources_list.files

# Generated at 2022-06-25 02:02:34.291436
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-25 02:02:41.299945
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    samplestr = '''
# comment
deb http://ftp.us.debian.org/debian stable main non-free contrib
    # comment
    deb-src http://ftp.us.debian.org/debian stable main non-free contrib
    deb http://ftp.debian.org/debian stable main non-free contrib
deb http://ftp.debian.org/debian stable main non-free contrib
'''
    module = AnsibleModule({})
    sl = SourcesList(module)
    fd, temp_file = tempfile.mkstemp(prefix="test_SourcesList_modify_")
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.file.write(samplestr.encode("utf-8"))
    temp_file.file.flush()
    # test to

# Generated at 2022-06-25 02:02:51.168178
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Given
    module = AnsibleModule(argument_spec={})
    ubuntu_sources_list = UbuntuSourcesList(module)

    # When
    deepcopied_ubuntu_sources_list = copy.deepcopy(ubuntu_sources_list)

    # Then
    assert ubuntu_sources_list != deepcopied_ubuntu_sources_list
    assert ubuntu_sources_list.module == deepcopied_ubuntu_sources_list.module
    assert ubuntu_sources_list.add_ppa_signing_keys_callback == deepcopied_ubuntu_sources_list.add_ppa_signing_keys_callback
    assert ubuntu_sources_list.codename == deepcopied_ubuntu_sources_list.codename
    assert ubuntu_sources_list.files == deepcopied_ubuntu

# Generated at 2022-06-25 02:02:59.633343
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    tmp_dir = tempfile.mkdtemp()
    file_path_1 = os.path.join(tmp_dir, 'sources.list')
    file_path_2 = os.path.join(tmp_dir, 'sources.list.d/sourcefile.list')

    new_file_path = os.path.join(tmp_dir, 'sources.list.d/new_sourcefile.list')
    
    # Create a SourcesList object
    sl = SourcesList(None)

    # Load sources from a default file
    sl.load(file_path_1)
    assert sl.files == {file_path_1:[]}

    # Load sources from a file in sources.list.d
    sl.load(file_path_2)

# Generated at 2022-06-25 02:03:08.982459
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Test case when the source is in the sources list
    test_sources_list = UbuntuSourcesList(object)
    test_sources_list.files = { os.path.abspath('test_file'): [
                                (0, True, True, 'deb http://ppa.launchpad.net/owner/ppa/ubuntu bionic main', '')
                            ],
                                os.path.abspath('test_file2'): [
                                (0, True, True, 'deb http://ppa.launchpad.net/owner/ppa2/ubuntu bionic main', '')
                            ]}
    test_sources_list.remove_source('ppa:owner/ppa')
    assert os.path.abspath('test_file') not in test_sources_list.files
    assert os.path.abspath

# Generated at 2022-06-25 02:03:15.630030
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    instance = SourcesList()
    for i in range(10):
        try:
            instance.modify(i)
        except InvalidSource:
            pass


# Generated at 2022-06-25 02:03:22.028496
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    with tempfile.TemporaryDirectory() as tmpdirname:
        os.chdir(tmpdirname)
        tmp_modules = dict()
        tmp_module = namedtuple('module', 'debug fail_json exit_json check_mode set_mode_if_different atomic_move nonexistent nonexistent')
        tmp_module.debug = False
        tmp_module.fail_json = lambda **kwargs:  (print('fail_json called'))
        tmp_module.exit_json = lambda **kwargs:  (print('exit_json called'))
        tmp_module.check_mode = False
        tmp_module.set_mode_if_different = lambda filename, mode, follow:  None
        tmp_module.atomic_move = lambda source, dest:  None
        tmp_module.nonexistent = False

# Generated at 2022-06-25 02:03:59.891744
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    tmp_path = None
    tmp_dir = None

# Generated at 2022-06-25 02:04:03.275253
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    m = AnsibleModule(argument_spec={})
    test_slist = SourcesList(m)
    test_slist.remove_source("deb http://httpredir.debian.org/debian/ jessie main")


# Generated at 2022-06-25 02:04:08.317821
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sources_list = SourcesList(None)
    sources_list.files = {'test_file': [('0', True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
                                        ('1', False, False, '# deb http://archive.canonical.com/ubuntu hardy partner', '')]}


# Generated at 2022-06-25 02:04:16.079291
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    s = SourcesList()
    try:
        s.load("tests/data/sources.list")
        d = s.dump()
        assert d == {
            'tests/data/sources.list':
            '# deb http://archive.canonical.com/ubuntu precise partner #comment\n'
            'deb-src http://source.ubuntu.com/ precise partner\n',
        }
    finally:
        s.save()


# Generated at 2022-06-25 02:04:25.190488
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sourceslist = SourcesList(0)

    file = '/test/sources.list'
    line1 = ' # deb-src http://archive.ubuntu.com/ubuntu bionic main '
    line2 = '# deb [option1=val1 option2=val2] http://repo.example.com/ubuntu bionic main'
    line3 = 'deb [option1=val1 option2=val2] http://repo.example.com/ubuntu bionic main'
    line4 = ' # deb-src [option1=val1 option2=val2] http://repo.example.com/ubuntu bionic main'
    line5 = '# deb-src [option1=val1 option2=val2] http://repo.example.com/ubuntu bionic main'

    sourceslist.files[file] = []

# Generated at 2022-06-25 02:04:32.156672
# Unit test for function install_python_apt
def test_install_python_apt():

    class FakeModule:
        class TestException(Exception):
            pass

        def __init__(self, update_rc = 0, update_so = '', update_se = ''):
            self.update_rc = update_rc
            self.update_so = update_so
            self.update_se = update_se
            self.check_mode = False
            self.params = {'install_python_apt': True}
            self.apt_get_path = None
            self.rc = None
            self.so = None
            self.se = None

        def get_bin_path(self, apt_get_name, opts = None):
            return self.apt_get_path


# Generated at 2022-06-25 02:04:42.563715
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = random.choice(['python-apt', 'python3-apt'])
    module = AnsibleModule(
        argument_spec = dict(
            install_python_apt = dict(type='bool', default=True)
        ),
        required_one_of = (('install_python_apt', True),),
        supports_check_mode = True,
        bypass_checks = True
    )

    if not distro:
        if module.params['install_python_apt']:
            install_python_apt(module, apt_pkg_name)
        else:
            module.fail_json(msg="%s must be installed to use this module" % apt_pkg_name)

    module.exit_json(changed=False)


# Generated at 2022-06-25 02:04:50.612800
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    UbuntuSourcesList(module)

    # Test add_source with a valid ppa.
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')

    # Test add_source with a valid ppa but with a wrong destination file.
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible', file='wrong')

    # Test add_source with a valid ppa but with a destination file that already exists.
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible', file='ansible_ansible.list')

# Generated at 2022-06-25 02:04:56.666117
# Unit test for function main
def test_main():
    #
    # Mock result of method 'dump' in class SourcesList
    #
    class sourceslist_mock():
        def __init__(self):
            self.dump_result = [{'test':'test'}]

        def dump(self):
            return self.dump_result

    if sys.version_info[0] < 3:
        #
        # Mock result of method 'respawn' in class AnsibleModule
        #
        class ansible_module_mock():
            def __init__(self):
                self.respawn_result = [{'test':'test'}]
                self.check_mode = True
                self._diff = True

            def respawn(self):
                return self.respawn_result
        ansible_module_mock = ansible_module_mock()
        #


# Generated at 2022-06-25 02:04:59.259669
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(None) is None


# Generated at 2022-06-25 02:05:35.546770
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    str_0 = 'ppa:mmstick76/alsa'
    str_1 = 'ppa:~mmstick76/'
    str_2 = 'ppa:~mmstick76'
    str_3 = '~mmstick76'
    str_4 = 'ppa:mmstick76'
    str_5 = 'ppa'
    str_6 = 'ppa:'
    str_7 = ''
    str_8 = 'ppa::'
    str_9 = 'ppa:~~mmstick76'
    str_10 = 'ppa:mmstick76/~'

# Generated at 2022-06-25 02:05:40.062795
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    str_0 = '6U5!1-!N1\x0f'
    sources_list_0 = SourcesList(str_0)
    test = sources_list_0.__iter__()
    assert test is not None


# Generated at 2022-06-25 02:05:41.859260
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sources_list_1 = SourcesList('d')
    str_1 = 'repo-scm'
    sources_list_1.remove_source(str_1)


# Generated at 2022-06-25 02:05:43.401565
# Unit test for function revert_sources_list
def test_revert_sources_list():
    str_0 = '\x1c'
    # Test passed
    pass


# Generated at 2022-06-25 02:05:44.454085
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    str_0 = '`'
    sources_list_0 = SourcesList(str_0)
    test_case_0()


# Generated at 2022-06-25 02:05:45.941078
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    file_1, n_1, enable_1, source_1, comment_1 = SourcesList.modify()


# Generated at 2022-06-25 02:05:51.919816
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    try:
        global _test_SourcesList_save_count
        try:
            _test_SourcesList_save_count += 1
        except:
            _test_SourcesList_save_count = 0

        test_method_name = 'save'
        test_method = getattr(SourcesList, test_method_name)
        test_case = '0'
        expected_result = None
        result = test_method()

        if result != expected_result:
            test_case_status = 'failed'
            test_case_failure_reason = 'Wrong result, expected: ' + str(expected_result) + ', got: ' + str(result)
        else:
            test_case_status = 'passed'
            test_case_failure_reason = ''

    except Exception as e:
        test_case_

# Generated at 2022-06-25 02:05:53.945601
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    str_0 = '`'
    sources_list_0 = SourcesList(str_0)

    # test for case 1
    str_0 = 'C'
    sources_list_0.save(str_0)


# Generated at 2022-06-25 02:05:56.289328
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    str_0 = '_'
    UbuntuSourcesList_0 = UbuntuSourcesList(str_0)
    str_1 = '`'
    str_2 = '4n4w+'
    str_3 = 'a(1'
    str_4 = '*'
    UbuntuSourcesList_0.add_source(str_1, str_2, str_3)



# Generated at 2022-06-25 02:06:00.270621
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    str_0 = '+'
    ubuntu_sources_list_0 = UbuntuSourcesList(str_0)
    int_0 = 0
    assert UbuntuSourcesList(str_0) is not ubuntu_sources_list_0.__deepcopy__(int_0)


# Generated at 2022-06-25 02:08:23.072764
# Unit test for function main
def test_main():
    # Create the class to pass to the method
    module_params = {}
    module_params['repo'] = ''
    module_params['state'] = 'present'
    module_params['mode'] = 'None'
    module_params['update_cache'] = True
    module_params['update_cache_retries'] = 5
    module_params['update_cache_retry_max_delay'] = 12
    module_params['filename'] = ''
    # This should not be needed, but exists as a failsafe
    module_params['install_python_apt'] = True
    module_params['validate_certs'] = True
    module_params['codename'] = ''
    # Create the AnsibleModule object
    module = AnsibleModule(argument_spec=module_params)
    # Run the main function

# Generated at 2022-06-25 02:08:24.060308
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    str_0 = '`'
    UbuntuSourcesList(str_0)


# Generated at 2022-06-25 02:08:25.930305
# Unit test for constructor of class SourcesList
def test_SourcesList():
    global HAVE_PYTHON_APT
    HAVE_PYTHON_APT = True
    sources_list_0 = SourcesList()
    assert isinstance(sources_list_0, SourcesList)


# Generated at 2022-06-25 02:08:28.597599
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    str_0 = '{s@'
    sources_list_0 = SourcesList(str_0)
    sources_list_0.modify('x(Z<$', 0, str_0, str_0, str_0)


# Generated at 2022-06-25 02:08:31.369145
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    obj = SourcesList("str_0")
    itr = obj.__iter__()
    try:
        str_0 = next(itr)
    except StopIteration:
        pass


# Generated at 2022-06-25 02:08:35.561817
# Unit test for function revert_sources_list
def test_revert_sources_list():
    str_0 = ':|F6qq^>'
    str_1 = '6G5Od'
    str_2 = 'fYw'
    str_3 = 'iX9'
    str_4 = '^dz'
    str_5 = 'qw'
    str_6 = '?t9'
    str_7 = 'E{7f'
    str_8 = 'F#'
    str_9 = '{'
    str_10 = '}'
    str_11 = '['
    str_12 = ']'
    str_13 = '^'
    str_14 = '`'
    str_15 = '<>'
    str_16 = 'dW-'
    str_17 = 'g#v,'
    str_18 = '4'
    str_

# Generated at 2022-06-25 02:08:37.411401
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sources_list_0 = SourcesList(str)
    sources_list_0.add_source('deb http://deb.debian.org/debian stretch main')
    sources_list_0.save()


# Generated at 2022-06-25 02:08:45.959226
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    if not HAVE_PYTHON_APT:
        module = AnsibleModule({})
        pkg = 'python-apt'
        if PY3:
            pkg = 'python3-apt'
        install_python_apt(module, pkg)
        global apt, apt_pkg, aptsources_distro, distro
        import apt
        import apt_pkg
        import aptsources.distro as aptsources_distro
        distro = aptsources_distro.get_distro()
    sources_list_1 = SourcesList(AnsibleModule({}))
    str_1 = '`'
    sources_list_1.load(str_1)
    sources_list_1._add_valid_source(str_1, '*', None)

# Generated at 2022-06-25 02:08:47.396634
# Unit test for function main
def test_main():
  try:
      test_case_0()
  except SystemExit:
      pass


# Generated at 2022-06-25 02:08:49.059308
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list_test = SourcesList()
    dumpstruct = sources_list_test.dump
    assert type(dumpstruct) == dict
