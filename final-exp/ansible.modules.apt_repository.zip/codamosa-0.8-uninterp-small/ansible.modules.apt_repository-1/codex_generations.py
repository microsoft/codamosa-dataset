

# Generated at 2022-06-25 02:02:31.587267
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(
        argument_spec = dict(
            state=dict(default='present', choices=['present', 'absent']),
            repo=dict(default=None, required=True),
            filename=dict(default=None),
            update_cache=dict(default=False, type='bool'),
            validate_certs=dict(default=True, type='bool'),
            mode=dict(default=None, type='raw'),
            install_python_apt=dict(default=True, type='bool'),
            codename=dict(default=None),
            dist=dict(default=None),
            components=dict(default=None),
        ),
        supports_check_mode=True,
    )
    # TODO: Test code here
    result = SourcesList.save(module)

# Generated at 2022-06-25 02:02:33.832118
# Unit test for function install_python_apt
def test_install_python_apt():
    x = install_python_apt(apt_pkg_name)

# Generated at 2022-06-25 02:02:34.650518
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass



# Generated at 2022-06-25 02:02:37.855534
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_1 = SourcesList()
    var_2 = iter(var_1)
    var_3 = next(var_2)
    var_4 = SourcesList()
    var_5 = iter(var_4)
    var_6 = next(var_5)
    assert var_3 != var_6


# Generated at 2022-06-25 02:02:48.189545
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_1 = os.path
    var_1.isfile = MagicMock(return_value='True')
    var_2 = SourcesList()
    var_1.isfile = MagicMock(return_value='True')
    var_3 = var_2._apt_cfg_file
    var_4 = apt_pkg
    var_4.config = MagicMock()
    var_4.config.find_file = MagicMock(return_value='0')
    var_3 = var_2._apt_cfg_file('Dir::Etc::sourcelist')
    var_2.default_file = var_3
    var_1 = glob
    var_1.iglob = MagicMock(return_value='0')
    var_3 = var_2._apt_cfg_dir
    var_3 = var_

# Generated at 2022-06-25 02:02:57.038370
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_1 = UbuntuSourcesList()
    var_2 = 'deb http://foo.bar baz'
    try:
        var_1.add_source(var_2)
    except:
        pass
    var_3 = 'https://foo.bar baz'
    try:
        var_1.add_source(var_3)
    except:
        pass
    var_4 = 'ppa:foo.bar'
    try:
        var_1.add_source(var_4)
    except:
        pass
    var_5 = 'ppa:foo.bar/baz'
    try:
        var_1.add_source(var_5)
    except:
        pass
    var_6 = 'deb'

# Generated at 2022-06-25 02:03:00.058909
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        var_0 = test_case_0()
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-25 02:03:09.155549
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Case 1
    # Test of __iter__
    var_4 = 'SourcesList'
    var_5 = SourcesList(var_4)
    var_2 = var_5.__iter__()
    var_7 = []
    var_5 = var_2.__next__()
    var_7.append(var_5)
    var_7 = var_7[0]
    assert var_7[0]==var_7[0]

    # Case 2
    # Test of __iter__
    var_4 = 'SourcesList'
    var_5 = SourcesList(var_4)
    var_2 = var_5.__iter__()
    var_7 = []
    var_5 = var_2.__next__()
    var_7.append(var_5)

# Generated at 2022-06-25 02:03:18.863702
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestClass:
        def __init__(self):
            pass

        def __deepcopy__(self, memo=None):
            return TestClass()

    if __name__ == '__main__':
        module = AnsibleModule(
            argument_spec = dict()
        )
    else:
        module = AnsibleModule(
            argument_spec = dict()
        )

    setattr(module, 'params', dict())

    object_to_test = UbuntuSourcesList(module)
    copy_of_object = copy.deepcopy(object_to_test)

    assert isinstance(object_to_test, UbuntuSourcesList)
    assert isinstance(copy_of_object, UbuntuSourcesList)


# Generated at 2022-06-25 02:03:24.623253
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    f_0 = SourcesList(None)
    f_0._parse = None
    f_0._parse = 'hb8X'
    f_0._apt_cfg_file = None
    f_0._apt_cfg_file = 'Prms'
    f_0._apt_cfg_dir = None
    f_0._apt_cfg_dir = 'cVZB'
    f_0.files = {}
    f_0.files['H4'] = ['qY', 'fVc', 'pN', 'S7L', 'vQe']
    f_0.files['b'] = ['m', 'd', 'DmI', 'L', 'C']
    f_0.files['g'] = ['50', 'Y', 'Zd', 'Z', 'X']
    f_0.files

# Generated at 2022-06-25 02:04:19.391122
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = MockModule()
    assert isinstance(UbuntuSourcesList(module), UbuntuSourcesList)
    del module

    module = MockModule()
    module.params = dict(
        codename='trusty'
    )
    assert isinstance(UbuntuSourcesList(module, add_ppa_signing_keys_callback=None), UbuntuSourcesList)
    del module


# Generated at 2022-06-25 02:04:25.515982
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    var_0 = UbuntuSourcesList()
    var_source = 'deb http://ppa.launchpad.net/ppa_owner/ppa/ubuntu xenial main'
    var_file = 'ppa.list'
    var_1 = var_0.add_source(var_source, file=var_file)


# Generated at 2022-06-25 02:04:26.479814
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_0 = main()


# Generated at 2022-06-25 02:04:27.758258
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    var_1 = SourcesList()
    var_2 = var_1.dump()
    print(var_2)



# Generated at 2022-06-25 02:04:31.823596
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    var_sources_list = SourcesList(AnsibleModule(argument_spec=dict()))
    var_sources_list.files = {'/etc/apt/sources.list.d/google-chrome.list': [(0, True, True, 'deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main', None)]}
    line = 'deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main'
    var_sources_list.remove_source(line)
    assert not var_sources_list.files


# Generated at 2022-06-25 02:04:32.844677
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # Code to test method save
    pass


# Generated at 2022-06-25 02:04:37.933366
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # Setup
    var_0 = os.path.isfile(self.default_file)

    var_1 = "Failed to create directory %s: %s"

    var_2 = os.path.exists(filename)


    # Test 1
    if var_0 == True:
        self.load(self.default_file)
    else:
        self.load(None)

    # Test 2
    for file in glob.iglob('%s/*.list' % self._apt_cfg_dir('Dir::Etc::sourceparts')):
        self.load(file)

    # Test 3
    d, fn = os.path.split(filename)

# Generated at 2022-06-25 02:04:48.344802
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    global main
    #create a dummy module
    class DummyModule():
        def fail_json(self, *args, **kwargs):
            return fail_json(*args, **kwargs)

        def atomic_move(self, *args, **kwargs):
            return atomic_move(*args, **kwargs)

        def get_bin_path(self, *args, **kwargs):
            return get_bin_path(*args, **kwargs)

        def set_mode_if_different(self, *args, **kwargs):
            return set_mode_if_different(*args, **kwargs)

        def run_command(self, *args, **kwargs):
            return run_command(*args, **kwargs)
    global module
    module = DummyModule()
    #create a dummy sources list

# Generated at 2022-06-25 02:04:49.629953
# Unit test for function main
def test_main():
    var_0 = main()
    assert not var_0


# Generated at 2022-06-25 02:04:52.213373
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    r = UbuntuSourcesList(module)
    assert(isinstance(r, UbuntuSourcesList))
    assert(r.module==module)


# Generated at 2022-06-25 02:06:35.626458
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_0 = SourcesList()
    var_0.save()


# Generated at 2022-06-25 02:06:41.630861
# Unit test for function main
def test_main():
    global sys
    global aptsources_distro
    global aptsources_distro_ubuntu

    class sys:
        @staticmethod
        def executable():
            return '/usr/bin/python'

    class aptsources_distro:
        @staticmethod
        def get_distro(*args):
            return aptsources_distro_ubuntu

    class aptsources_distro_ubuntu:
        @staticmethod
        def codename():
            return 'bionic'

    test_case_0()

# Generated at 2022-06-25 02:06:44.150911
# Unit test for function main
def test_main():
    # Execute function main with use case 0
    test_case_0()

if __name__ == "__main__":
    p0 = multiprocessing.Process(target=test_main)
    p0.start()
    p0.join()

# Generated at 2022-06-25 02:06:45.669654
# Unit test for function install_python_apt
def test_install_python_apt():
    try:
        assert install_python_apt(module, apt_pkg_name) == None
    except Exception as e:
        print(e)

# Generated at 2022-06-25 02:06:52.563759
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert 'SourcesList' in globals() or 'SourcesList' in locals() or 'SourcesList' in vars()
    assert '__iter__' in globals() or '__iter__' in locals() or '__iter__' in vars()
    assert 'main' in globals() or 'main' in locals() or 'main' in vars()
    assert 'apt' in globals() or 'apt' in locals() or 'apt' in vars()
    assert 'apt_pkg' in globals() or 'apt_pkg' in locals() or 'apt_pkg' in vars()
    assert 'aptsources_distro' in globals() or 'aptsources_distro' in locals() or 'aptsources_distro' in vars()

# Generated at 2022-06-25 02:06:58.304992
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Unit test for: get_add_ppa_signing_key_callback

    # Check that get_add_ppa_signing_key_callback returns None when request is in check mode
    module = AnsibleModule({
        'state': 'present',
        'name': 'ppa:ansible/ansible',
        'update_cache': True,
        'check_mode': True,
    })
    assert get_add_ppa_signing_key_callback(module) is None


# Generated at 2022-06-25 02:06:59.342746
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    _module = SourcesList()
    _module.load()


# Generated at 2022-06-25 02:07:02.936975
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Arrange
    var_0 = SourcesList(None)

    # Act
    var_0.add_source("deb http://example.com/debian wheezy-backports main", "", "test")

    # Assert
    assert var_0.files["test.list"][0][1:] == (True, True, "deb http://example.com/debian wheezy-backports main", "")


# Generated at 2022-06-25 02:07:04.957433
# Unit test for function install_python_apt
def test_install_python_apt():
    assert callable(install_python_apt)


# Generated at 2022-06-25 02:07:05.915985
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources = SourcesList({'a':1})
    assert sources.__iter__()
