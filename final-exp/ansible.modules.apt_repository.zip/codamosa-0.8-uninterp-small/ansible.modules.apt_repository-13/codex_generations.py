

# Generated at 2022-06-25 02:02:14.671957
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_list_0 = SourcesList(None)
    sources_list_1 = SourcesList(None)
    sources_list_2 = SourcesList(None)
    sources_list_3 = SourcesList(None)
    sources_list_0.load(None)
    sources_list_1.load(None)
    sources_list_3.load(None)
    revert_sources_list(sources_list_0, sources_list_1, sources_list_2)


# Generated at 2022-06-25 02:02:17.299259
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    bool_0 = True
    sources_list_0 = SourcesList(bool_0)
    sources_list_0.remove_source(bool_0)


# Generated at 2022-06-25 02:02:19.256367
# Unit test for function revert_sources_list
def test_revert_sources_list():
    bool_0 = True
    sources_list_0 = SourcesList(bool_0)
    revert_sources_list(bool_0, sources_list_0, bool_0)


# Generated at 2022-06-25 02:02:21.611006
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert True


# Generated at 2022-06-25 02:02:26.994712
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    bool_0 = True
    module_0 = AnsibleModule(bool_0, "AnsibleModule for test_get_add_ppa_signing_key_callback")
    result = get_add_ppa_signing_key_callback(module_0)
    assert result is None


# Generated at 2022-06-25 02:02:32.037757
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    bool_1 = True
    sources_list_1 = SourcesList(bool_1)
    # Insert test code here
    bool_2 = True
    sources_list_1.load(bool_2)


# Generated at 2022-06-25 02:02:35.979832
# Unit test for function main
def test_main():
    try:
        print('test function:', sys._getframe().f_code.co_name)
        test_case_0()
    except SystemExit:
        pass
    except Exception as e:
        print('FAILED:', e)

if __name__ == '__main__':
    test_main()

main()

# Generated at 2022-06-25 02:02:42.303021
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    bool_0 = True
    sources_list_0 = UbuntuSourcesList(bool_0)
    sources_list_0.add_source('deb http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu', 'deb-src http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu')
    sources_list_0.add_source('deb http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu', 'deb-src http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu', 'deb-src http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu')


# Generated at 2022-06-25 02:02:44.654857
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    bool_0 = False
    if bool_0:
        test_case_0()
    else:
        bool_1 = True
        sources_list_0 = SourcesList(bool_1)
        dict_2 = sources_list_0.dump()
        dumpstruct_0 = dict_2


# Generated at 2022-06-25 02:02:48.927766
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    bool_0 = True
    sources_list_0 = SourcesList(bool_0)
    line_0 = 'deb http://archive.canonical.com/ubuntu hardy partner'
    file_0 = None
    comment_0 = ''
    sources_list_0.add_source(line_0, comment_0, file_0)


# Generated at 2022-06-25 02:03:29.245390
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    bool_1 = True
    sources_list_1 = UbuntuSourcesList(bool_1)
    line_0 = 'deb-src http://ppa.launchpad.net/webupd8team/java/ubuntu trusty main'
    sources_list_1.remove_source(line_0)
    line_1 = 'deb http://ppa.launchpad.net/webupd8team/java/ubuntu trusty main'
    sources_list_1.remove_source(line_1)
    line_2 = 'deb http://www.example.com/debian stable main extra'
    sources_list_1.remove_source(line_2)
    line_3 = 'deb http://www.example.com/debian stable main extra'
    sources_list_1.remove_source(line_3)


# Generated at 2022-06-25 02:03:37.073628
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    arg0 = {'mode': 'present', 'codename': 'artful', 'update_cache': False, 'state': 'present', 'password': None, 'autoremove': False, 'key_content': None, 'key_url': None, 'cache_valid_time': 0, 'deb': None, 'src': None, 'filename': None, 'state_desc': None, 'update_cache_skip_packages': [], 'key_id': None, 'pre_depend': False, 'install_recommends': True, 'allow_unauthenticated': False, 'purge': False}
    bool_0 = True
    str_0 = 'foo'
    # SourcesList is not implemented yet
    # uut = UbuntuSourcesList(bool_0, None)
    # uut.remove_source(str_0)


# Generated at 2022-06-25 02:03:40.233874
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    try:
        obj = UbuntuSourcesList(None)
        result = obj.__deepcopy__()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 02:03:45.758470
# Unit test for constructor of class SourcesList
def test_SourcesList():
    test_case_0()

########################################################################
#
# Function: apt_keys
#
# Description:
#   Retrieve a key from a keyserver and store it in apt-key's database.
#
########################################################################

# Generated at 2022-06-25 02:03:47.949694
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module_0 = ModuleMock(check_mode=False, debug=False)
    arg_0 = module_0
    arg_1 = None
    obj_0 = UbuntuSourcesList(arg_0, arg_1)
    test_case_0()

if __name__ == '__main__':
    test_UbuntuSourcesList()

# Generated at 2022-06-25 02:03:49.425429
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt(bool_0, "apt-pkg-name") == "apt-pkg-name"


# Generated at 2022-06-25 02:03:53.336568
# Unit test for constructor of class SourcesList
def test_SourcesList():
    try:
        module = AnsibleModule(argument_spec={}, supports_check_mode=True)
        test_case_0()
        module.exit_json(msg="SourcesList tests are successful", changed=False)
    except Exception as e:
        module.fail_json(msg="SourcesList tests are failed", failed=True, details="%s" % e.message)


# Generated at 2022-06-25 02:04:01.900648
# Unit test for function main
def test_main():
    with mock.patch.object(sys, 'argv', ['ansible-test', 'apt_repository', '--connection', 'local', '--inventory', '/etc/ansible/hosts', '--module-path', '/Users/djozan/git/ansible/lib/ansible/modules/packaging/os/', '--extra-vars', '{"repo": "deb http://ftp.br.debian.org/debian testing main", "state": "absent", "mode": "0444"}']):
        # FIXME(djozan): mock call of class UbuntuSourcesList
        # FIXME(djozan): mock call of function get_add_ppa_signing_key_callback
        try:
            main()
        finally:
            module.exit_json.restore_stderr()


# Generated at 2022-06-25 02:04:10.610122
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    bool_0 = True
    sources_list_0 = SourcesList(bool_0)
    str_0 = 'deb http://archive.canonical.com/ubuntu hardy partner'
    str_1 = 'deb http://archive.canonical.com/ubuntu artful partner'
    str_2 = 'deb http://archive.canonical.com/ubuntu bionic partner'
    str_3 = 'deb http://archive.canonical.com/ubuntu bionic partner'
    str_4 = 'deb http://archive.canonical.com/ubuntu bionic partner'
    sources_list_0.modify(str_0,str_1,str_2,str_3,str_4)


# Generated at 2022-06-25 02:04:14.522069
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = None
    get_add_ppa_signing_key_callback(module)


# Generated at 2022-06-25 02:05:35.625394
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sources_list = SourcesList(AnsibleModule)
    file = "file"
    n = 10
    sources_list.files = {file: [sources_list._parse("#line", raise_if_invalid_or_disabled=True) for i in range(3)]}
    sources_list.modify(file, n, True, "test", "test")
    sources_list.modify(file, n, True, None, "test")
    sources_list.modify(file, n, None, None, "test")


# Generated at 2022-06-25 02:05:45.436241
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources_list = SourcesList(AnsibleModule(argument_spec={}))
    module_valid = {'choices': ['absent', 'present'], 'required': False, 'default': None, 'aliases': ['state'], 'type': 'str', 'no_log': False}
    module_filename = {'choices': [None], 'required': False, 'default': None, 'aliases': [], 'type': 'str', 'no_log': False}
    module_repo = {'choices': [None], 'required': True, 'default': None, 'aliases': [], 'type': 'str', 'no_log': False}
    module_comment = {'choices': [None], 'required': False, 'default': '', 'aliases': [], 'type': 'str', 'no_log': False}

# Generated at 2022-06-25 02:05:47.287844
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    boolean = True
    ubuntu_sources_list_0 = SourcesList(boolean)
    ubuntu_sources_list_0.add_source("test_value")


# Generated at 2022-06-25 02:05:49.171323
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list_0 = SourcesList(apt, apt_pkg, aptsources_distro, distro, HAVE_PYTHON_APT)
    assert sources_list_0.dump() == {}


# Generated at 2022-06-25 02:05:50.533615
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    bool_1 = True
    sources_list_1 = SourcesList(bool_1)
    sources_list_1.dump()


# Generated at 2022-06-25 02:05:56.077695
# Unit test for method __iter__ of class SourcesList

# Generated at 2022-06-25 02:05:58.982403
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    string_0 = 'o'
    sources_list_0 = SourcesList(string_0)
    string_1 = 'k'
    sources_list_0.load(string_1)


# Generated at 2022-06-25 02:06:03.194561
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Remove sourceslist file if it exists
    try:
        if os.path.exists(sourceslist_file):
            os.remove(sourceslist_file)
    except IOError:
    # don't care if it's already gone
        pass

    # Save the state of sources.list
    sources_before = dict()
    sourceslist_before = UbuntuSourcesList(None)
    sources_before[sourceslist_file] = sourceslist_before.dump()[sourceslist_file]

    # Add a source to the list
    sourceslist = UbuntuSourcesList(None)
    sourceslist.add_source(new_source_line)

    # Now revert the changes
    sources_after = sourceslist.dump()
    revert_sources_list(sources_before, sources_after, sourceslist_before)

    # Check

# Generated at 2022-06-25 02:06:05.637548
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    install_python_apt(module, 'python-apt')


# Generated at 2022-06-25 02:06:14.201492
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {u'/etc/apt/sources.list.d/adobe-flashplugin.list': u'\ndeb http://archive.canonical.com/ lucid partner\n\n'}
    sources_after = {u'/etc/apt/sources.list.d/adobe-flashplugin.list': u'\ndeb http://archive.canonical.com/ lucid partner\n\n',
                     u'/etc/apt/sources.list.d/sources.list': u'\ndeb http://archive.canonical.com/ lucid partner\n\n'}
    sourceslist_before = SourcesList(bool_0)
    revert_sources_list(sources_before, sources_after, sourceslist_before)

test_case_0()
test_revert_sources_list()