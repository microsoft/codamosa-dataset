

# Generated at 2022-06-25 02:02:11.599168
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_1 = SourcesList()
    var_2 = test_case_0()
    return var_2


# Generated at 2022-06-25 02:02:22.144461
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'a': 'A'
    }

    obj = UbuntuSourcesList(module)
    obj.sources_list = {
        1: 'B'
    }

    cloned_obj = copy.deepcopy(obj)

    if not isinstance(cloned_obj, UbuntuSourcesList):
        raise Exception("Failure in type comparison")

    if cloned_obj.sources_list != {1: 'B'}:
        raise Exception("Failure in value comparison")

    if cloned_obj.module != module:
        raise Exception("Failure in value comparison")

    if cloned_obj.add_ppa_signing_keys_callback != obj.add_ppa_signing_keys_callback:
        raise Exception("Failure in value comparison")


# Generated at 2022-06-25 02:02:23.976760
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    var_1 = SourcesList()
    var_1.filename = "SourcesList.txt"
    var_1.save()


# Generated at 2022-06-25 02:02:29.857754
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import os
    from tempfile import mkstemp
    from shutil import copy2
    from os.path import exists

    fd, temp = mkstemp()
    copy2('./test_SourcesList', temp)

    s = SourcesList()
    s.load(temp)

    os.remove(temp)
    assert(exists(temp) == False)


# Generated at 2022-06-25 02:02:33.338381
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList(AnsibleModule)
    if not os.path.isfile(sl.default_file):
        return
    sl.load(sl.default_file)
    if not os.path.isfile(sl.default_file):
        return


# Generated at 2022-06-25 02:02:35.591491
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None


# Generated at 2022-06-25 02:02:40.806208
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    global var_0
    # assume test_case_0() has been run before
    sources = var_0
    file = "./ansible-temp-201612161542338953"
    n = 0
    enabled=True
    source="deb http://mirrors.163.com/ubuntu/ trusty main restricted universe multiverse"
    comment=""
    if not sources.files[file][n][1]:
        sources.modify(file,n,enabled)
        assert enabled

# Generated at 2022-06-25 02:02:46.786485
# Unit test for function revert_sources_list
def test_revert_sources_list():
    var_0 = ''
    var_1 = ''
    var_2 = ''
    var_3 = ''
    var_4 = ''
    var_5 = ''
    var_6 = ''
    var_7 = ''
    var_8 = ''
    var_9 = ''
    var_10 = ''
    var_11 = ''
    var_12 = ''
    var_13 = ''
    var_14 = ''
    var_15 = ''
    var_16 = ''
    var_17 = ''
    var_18 = ''
    var_19 = ''
    var_20 = ''
    var_21 = ''
    var_22 = ''
    var_23 = ''
    var_24 = ''
    var_25 = ''
    var_26 = ''
    var_27 = ''
    var_

# Generated at 2022-06-25 02:02:48.586316
# Unit test for function main
def test_main():
    with patch('aptsources.sourceslist.SourcesList') as mock_SourcesList:
        pass
        main()
    assert mock_SourcesList.called


# Generated at 2022-06-25 02:02:50.385088
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList(global_var_0.ansible_0)
    for var_1, var_2 in var_0:
        var_1 = var_1
        var_2 = var_2


# Generated at 2022-06-25 02:03:18.235356
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = UbuntuSourcesList()
    result = var_0.__deepcopy__()


# Generated at 2022-06-25 02:03:22.465610
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    #Source to be removed
    #parameters for SourcesList.remove_source
    line = 'deb http://archive.canonical.com/ubuntu hardy partner'
    #Expected result
    remove_source_expected_result = None
    try:
        remove_source_return = SourcesList.remove_source(line)
        if remove_source_return == remove_source_expected_result:
            test_case_0()
        else:
            raise Exception('Test case failed')
    except Exception:
        print('Test case failed')


# Generated at 2022-06-25 02:03:23.532517
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    var_0 = SourcesList()
    var_1 = var_0.__iter__()


# Generated at 2022-06-25 02:03:28.350040
# Unit test for function install_python_apt
def test_install_python_apt():
    import unittest
    import ansible.module_utils.ansible_release as ansible_release

    class TestInstallPythonApt(unittest.TestCase):

        def setUp(self):
            self.module = AnsibleModule
            self.module.check_mode = False
            self.module.run_command = mock_run_command
            self.module.fail_json = mock_fail_json

        def test_install_python_apt_should_fail_on_error_code_0(self):
            self.module.check_mode = True
            self.assertRaises(SystemExit, install_python_apt, self.module, 'python-apt')

    return TestInstallPythonApt

if __name__ == '__main__':
    import unittest
    t = test_install_python_apt()


# Generated at 2022-06-25 02:03:29.528231
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sourceslist = SourcesList(None)
    sourceslist.load("sources.list")
    assert len(sourceslist.files) > 0


# Generated at 2022-06-25 02:03:37.611087
# Unit test for function main

# Generated at 2022-06-25 02:03:44.877899
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(None)
    sl.files = {}
    sl.files['/etc/apt/sources.list'] = [
        (0,True, True, '#deb cdrom',''),
        (1,True, True, 'deb http://ppa.launchpad.net/nicolas-bouchard/debian42/ubuntu quantal main',''),
        (2,True, True, 'deb http://ppa.launchpad.net/nicolas-bouchard/debian42/ubuntu quantal main',''),
        (3,True, True, 'deb http://ppa.launchpad.net/nicolas-bouchard/debian42/ubuntu quantal main',''),
        (4,True, True, 'deb http://ppa.launchpad.net/nicolas-bouchard/debian42/ubuntu quantal main','')]



# Generated at 2022-06-25 02:03:46.198531
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Initialize SourcesList obj
    class_inst_0 = SourcesList(None)
    assert True



# Generated at 2022-06-25 02:03:53.970155
# Unit test for function install_python_apt
def test_install_python_apt():
    class ModuleMock(object):
        class FailJson(object):
            def __init__(self, message=''):
                self.message = message
        def __init__(self):
            self.called_msg = ''
        def fail_json(self, msg='', **kwargs):
            raise self.FailJson(msg)
        
        def get_bin_path(self, str):
            print(str)
            return var_0
        
        def run_command(self, cmd_list):
            if var_0:
                raise self.FailJson(var_0.strip())
        
    var_0 = ModuleMock()

# Generated at 2022-06-25 02:03:55.079354
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    repository = SourcesList()
    repository.remove_source()


# Generated at 2022-06-25 02:04:22.960487
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_0 = SourcesList()
    var_1 = var_0.load()


# Generated at 2022-06-25 02:04:24.591951
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class_0 = UbuntuSourcesList( var_0)
    var_1 = None
    var_2 = class_0.__deepcopy__(var_1)


# Generated at 2022-06-25 02:04:26.323759
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = ansible.builtin.apt_repository.AnsibleModule
    sourcesList = ansible.builtin.apt_repository.SourcesList(module)
    sourcesList.save()


# Generated at 2022-06-25 02:04:31.099992
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    from random import choice
    from string import printable
    from itertools import product
    for (f1, f2) in product(printable, printable):
        if f1 != '#' and f2 != '#':
            t = '# ' + f1 + f2 * 10
            var_0 = Types(t)
            var_1 = SourcesList(var_0)
            var_1.add_source(t)
            assert var_1.dump()[var_0.params['filename']] == '# ' + f1 + f2 * 10 + '\n'

if __name__ == '__main__':
    test_SourcesList_add_source()

# Generated at 2022-06-25 02:04:32.014163
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    obj = SourcesList()
    obj.modify()


# Generated at 2022-06-25 02:04:38.397352
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    if PY3:
        exec('''def do_exec(co, loc): exec(co, loc)\n''', globals())
        eval('''def do_eval(co, loc): return eval(co, loc)\n''', globals())

# Generated at 2022-06-25 02:04:43.971874
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    '''
    Load a sources list from <file>.
    :param file:
    :return:
    '''
    test_object = SourcesList()
    if isinstance(test_object, SourcesList):
        assert True
    else:
        assert False


# Generated at 2022-06-25 02:04:45.090177
# Unit test for constructor of class SourcesList
def test_SourcesList():
    var_0 = SourcesList(module)


# Generated at 2022-06-25 02:04:46.468477
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    var_1 = main()


# Generated at 2022-06-25 02:04:48.185537
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    var_0 = UbuntuSourcesList()
    var_1 = 'ppa:'
    var_2 = "ppa:foo/bar"
    var_0.remove_source(var_2)
    

# Generated at 2022-06-25 02:05:53.051698
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    print('Testing dump')
    module = AnsibleModule(argument_spec={'src': {'required': True, 'type': 'str'}})
    file = module.params['src']
    sources_list = SourcesList(module)
    sources_list.load(file)
    print(SourcesList.dump(sources_list))


# Generated at 2022-06-25 02:06:04.080544
# Unit test for method remove_source of class UbuntuSourcesList

# Generated at 2022-06-25 02:06:05.991937
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Test of modify with sources.list containing 1 line
    assert False

    # Test of modify with sources.list containing more than 1 line
    assert False


# Generated at 2022-06-25 02:06:08.872943
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_0 = SourcesList()
    var_0.load("C:\\Users\\Vexati0n\\Documents\\GitHub\\ansible-modules-extras\\distro\\apt_repository.py")
    return var_0.files


# Generated at 2022-06-25 02:06:10.211340
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    # globals()['test_case_0']()
    test_main()
    # test_case_0()

# Generated at 2022-06-25 02:06:16.042382
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    if not HAVE_PYTHON_APT:
        return

    var_0 = SourcesList(None)
    
    # Byte code for test_0
    # Python 3.5

# Generated at 2022-06-25 02:06:19.266141
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    global var_0
    if (var_0 == 0):
        srcs = SourcesList(var_0)
        srcs.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')


# Generated at 2022-06-25 02:06:20.686798
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({})
    assert callable(get_add_ppa_signing_key_callback(module))


# Generated at 2022-06-25 02:06:26.708769
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    var_1 = distro.codename
    var_2 = os.path.abspath(os.path.join('/etc/apt/sources.list.d', '*.list'))
    var_3 = os.path.abspath('/etc/apt/sources.list.d')
    var_4 = module.params
    var_5 = apt_pkg.Config.FindFile('Dir::Etc::sourceparts')
    var_6 = module
    var_7 = UbuntuSourcesList(var_6, var_4)


# Generated at 2022-06-25 02:06:28.161655
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    var_0 = UbuntuSourcesList(var_0)
    var_1 = var_0.__deepcopy__()


# Generated at 2022-06-25 02:07:41.541597
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    sl = UbuntuSourcesList(module)
    sl.load('/tmp/testfiles/sources.list')
    sl.remove_source('deb http://ppa.launchpad.net/nilarimogard/webupd8/ubuntu quantal main')
    bk = sl.dump()

# Generated at 2022-06-25 02:07:46.906412
# Unit test for function revert_sources_list
def test_revert_sources_list():
    var_sources_before = {}
    var_sources_after = {'/etc/apt/sources.list.d/test1.list': '# This is a dummy test file to check the revert_sources_list feature\n\n# with a change\n\n# This is a dummy test file to check the revert_sources_list feature\n\n# with a change\n'}
    var_sourceslist_before = {}
    var_sourceslist_before['/etc/apt/sources.list'] = '# This is a dummy test file to check the revert_sources_list feature\n\n# with a change\n'

# Generated at 2022-06-25 02:07:53.859754
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # TODO: FIXME: WIP: remove this line to start testing
    return

    # TODO: FIXME: WIP: remove this line to start testing
    assert False

    # Create an instance of SourcesList
    # TODO: FIXME: WIP: change the line below to construct test arguments

# Generated at 2022-06-25 02:07:55.629711
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    var_2 = apt_pkg.config.find_file('Dir::Etc::sourcelist')
    var_3 = SourcesList()
    var_3.load(var_2)


# Generated at 2022-06-25 02:08:03.073257
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(
        argument_spec = dict(
            state = dict(default="present", choices=["absent", "present"], type="str"),
            repo = dict(required=True, type="str"),
            codename = dict(required=False, type="str")
        )
    )
    UbuntuSourcesList_instance = UbuntuSourcesList(module)
    # Set args.
    args = dict(
        repo = "http://repo1.maven.org/maven2"
    )
    # Set up parameter values
    line = args['repo']

    # Invoke method
    UbuntuSourcesList_instance.add_source(line)


# Generated at 2022-06-25 02:08:04.829697
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Create an instance
    sources_list = SourcesList(mock_module)
    # Call method save without parameters
    sources_list.save()



# Generated at 2022-06-25 02:08:06.547564
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Arrange
    sources = SourcesList(module)

    # Act
    sources.dump()

    # Assert
    assertEquals(sources, None)


# Generated at 2022-06-25 02:08:12.960228
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line = 'deb http://archive.canonical.com/ubuntu trusty partner'
    sources = SourcesList(AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True, type='str'),
            state=dict(default='present', choices=['absent', 'present']),
            filename=dict(required=False, type='str'),
            update_cache=dict(default=False, required=False),
            validate_certs=dict(default=True, type='bool'),
            mode=dict(default=None, required=False, type='raw'),
            update_period=dict(default=3600, required=False, type='int'),
            install_python_apt=dict(default=True, required=False, type='bool')
        ),
    ))
    sources.remove_source(line)



# Generated at 2022-06-25 02:08:16.692557
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    print("\n>>> test method __deepcopy__ of class UbuntuSourcesList")
    test_case_0()

if __name__ == '__main__':
    if len(sys.argv) == 1:
        print("usage: %s <test_name>" % sys.argv[0])
        exit(1)
    print("\n>>> Running test '%s'" % sys.argv[1])
    exec(sys.argv[1] + "()")

# Generated at 2022-06-25 02:08:23.017048
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sources_list = SourcesList()
    def _apt_cfg_dir(dirspec):
        return "/etc/apt"
    sources_list._apt_cfg_dir = _apt_cfg_dir
    sources_list.add_source("deb http://archive.canonical.com/ubuntu hardy partner")
    sources_list.add_source("deb http://dl.google.com/linux/chrome/deb/ stable main", file="chrome")
    sources_list.add_source("deb-src http://archive.canonical.com/ubuntu hardy partner")
    sources_list.add_source("deb http://archive.canonical.com/ubuntu hardy partner")
    sources_list.remove_source("deb http://archive.canonical.com/ubuntu hardy partner")
    sources_list.file = "/etc/apt/sources.list"

# Generated at 2022-06-25 02:11:10.428067
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule({'key': 'value'})
    obj = UbuntuSourcesList(module)
    obj.add_source('key')


# Generated at 2022-06-25 02:11:15.055853
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModuleStub()
    def add_ppa_signing_keys_callback(command):
        return None
    var_1 = UbuntuSourcesList(module, add_ppa_signing_keys_callback)


# Generated at 2022-06-25 02:11:16.012232
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    subprocess.call(['python3', 'test_SourcesList_modify.py'])


# Generated at 2022-06-25 02:11:18.656933
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert isinstance(get_add_ppa_signing_key_callback({})() , FunctionType)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 02:11:27.211749
# Unit test for function install_python_apt
def test_install_python_apt():
    # Test 1: apt-get fails to update (update fails)
    mod = AnsibleModule({}, {}, True)
    sudoL = mod.get_bin_path('sudo', True)
    apt_get_path = mod.get_bin_path('apt-get')
    if sudoL:
        apt_get_path = sudoL + [apt_get_path]

    class MockRunCommand:
        def __init__(self, mod):
            self.mod = mod


# Generated at 2022-06-25 02:11:28.906206
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    mysourceslist = SourcesList(module)
    remove_source_out = mysourceslist.remove_source('line')
    remove_source_out = mysourceslist.remove_source('line')


# Generated at 2022-06-25 02:11:35.300295
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {"/etc/apt/sources.list.d/deactivate-gpgcheck.list": "# GPG check disabled by Ansible\ndeb http://extras.ubuntu.com/ubuntu precise main\ndeb-src http://extras.ubuntu.com/ubuntu precise main\n"}
    sources_after = {"/etc/apt/sources.list.d/deactivate-gpgcheck.list": "# GPG check disabled by Ansible\ndeb http://extras.ubuntu.com/ubuntu precise main\ndeb-src http://extras.ubuntu.com/ubuntu precise main\n"}
    sourceslist_before = {'test': 'test'}
    revert_sources_list(sources_before, sources_after, sourceslist_before)


# Generated at 2022-06-25 02:11:36.828779
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    assert True # TODO: implement your test here
