

# Generated at 2022-06-23 03:06:08.004468
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert False


# Generated at 2022-06-23 03:06:20.029649
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    def mock_module_run_command(command, **kwargs):
        assert command[1] == 'adv'
        assert command[3] == '--recv-keys'
        assert command[5] == '--keyserver'
        assert command[7] == 'hkp://keyserver.ubuntu.com:80'
        assert command[8] == '9D6D8F6BC857C906'

    module = Mock()
    module.check_mode = False
    module.run_command = mock_module_run_command
    callback = get_add_ppa_signing_key_callback(module)

# Generated at 2022-06-23 03:06:29.310672
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(None)
    sl.files = {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty main', '# this is some comment')]}
    sl.remove_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    assert(sl.files.get('/etc/apt/sources.list', None) is None)
    sl.files = {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty main', '# this is some comment'), (1, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty main', '')]}
    sl.remove_source('deb http://archive.ubuntu.com/ubuntu trusty main')

# Generated at 2022-06-23 03:06:38.132362
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    mod = distro = get_distribution()

    sources_list = UbuntuSourcesList(module=mod)

    assert sources_list.codename == distro.codename

    assert sources_list.add_ppa_signing_keys_callback is None
    assert sources_list.repos_urls == []

    for filename, sources in sources_list.files.items():
        assert isinstance(filename, str)
        for source in sources:
            assert isinstance(source, list)
            assert isinstance(source[0], int)
            assert isinstance(source[1], bool)
            assert isinstance(source[2], bool)
            assert isinstance(source[3], str)
            assert isinstance(source[4], str)


# Test for run_command function

# Generated at 2022-06-23 03:06:49.157539
# Unit test for function revert_sources_list
def test_revert_sources_list():
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.add_sources = []
            self.remove_sources = []
            self.atomic_move = lambda source, destination: open(destination, 'w').write(open(source).read())
            self.set_mode_if_different = lambda path, mode, retry: None

    module = MockModule()
    sourceslist_before = UbuntuSourcesList(module)
    sources_before = dict()
    sources_after = dict()
    sourceslist_after = dict()
    revert_sources_list(sources_before, sources_after, sourceslist_before)

    module = MockModule()

# Generated at 2022-06-23 03:06:51.464827
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, '')
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-23 03:06:52.251594
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert True



# Generated at 2022-06-23 03:06:58.603289
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources = SourcesList(None)
    assert sources.__iter__() == []


# Generated at 2022-06-23 03:07:09.853407
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    ubuntu_sources_list = UbuntuSourcesList(None)

    # Test with PPA
    line = 'ppa:openstack-ubuntu-testing/train'
    file = ubuntu_sources_list._suggest_filename(line)
    assert isinstance(file, str)
    ppa_line, ppa_owner, ppa_name = ubuntu_sources_list._expand_ppa(line)
    assert isinstance(ppa_line, str)
    assert isinstance(ppa_owner, str)

    # Test with repository list
    line = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main' % (ppa_owner, ppa_name, ubuntu_sources_list.codename)
    file = ubuntu_sources_list._suggest_filename(line)

# Generated at 2022-06-23 03:07:20.156163
# Unit test for method modify of class SourcesList

# Generated at 2022-06-23 03:07:33.358109
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={'state': {'required': True, 'choices': ['present', 'absent']}})
    source = UbuntuSourcesList(module)
    source.add_source('ppa:fred/ppa')
    source.add_source('ppa:barney/ppa')
    source.add_source('ppa:wilma/ppa')

    source.remove_source('ppa:barney/ppa')
    repositories = source.repos_urls

    assert ('ppa:fred/ppa' in repositories)
    assert ('ppa:barney/ppa' not in repositories)
    assert ('ppa:wilma/ppa' in repositories)



# Generated at 2022-06-23 03:07:43.678305
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    print('''
+--------------------+---------+--------+---------+---------+
| source             | enabled | valid  | file    | comment |
+--------------------+---------+--------+---------+---------+
| deb-src http://deb | True    | True   |         |         |
| deb-src http://deb | False   | True   |         |         |
| deb-src http://deb | False   | False  |         |         |
| deb-src http://deb | True    | True   | foo.list|         |
| deb-src http://deb | True    | True   |         | bar     |
| deb-src http://deb | True    | True   | foo.list| bar     |
+--------------------+---------+--------+---------+---------+
''')
    sl = SourcesList(None)

# Generated at 2022-06-23 03:07:45.682627
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    e = InvalidSource()
    assert e.args == ("No valid sources given",)



# Generated at 2022-06-23 03:07:54.867906
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    def test_SourcesList___iter__(test_data):
        fd, tmp_path = tempfile.mkstemp(prefix="test_", suffix='.list')

        f = os.fdopen(fd, 'w')
        f.write(test_data['file'])
        f.close()

        sl = SourcesList(AnsibleModule(argument_spec=dict()))
        sl.load(tmp_path)

        if len(sl.files) != 1:
            return False

        if len(sl.files[tmp_path]) != len(test_data['result']):
            return False

        os.remove(tmp_path)


# Generated at 2022-06-23 03:08:04.904079
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({
        'comment': '',
        'file': '',
        'state': 'present',
        'repo': 'deb [ trusted=yes ] http://example.org/',
    }, 'testdata')

    sl = SourcesList(module)
    sl.add_source(module.params['repo'], comment=module.params['comment'], file=module.params['file'])
    assert sl.files.popitem() == ('/etc/apt/sources.list.d/example.org.list',
                                  [(0, True, True, 'deb [ trusted=yes ] http://example.org/', '')])

# Generated at 2022-06-23 03:08:07.002430
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('test')
    assert 'test' in to_native(exc)
    assert 'InvalidSource' in to_native(exc)



# Generated at 2022-06-23 03:08:12.183434
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files["/tmp/foo"] = [
        [0, True, True, "some-source", "some-comment"],
        [1, True, True, "source-to-modify", "old-comment"]
    ]

    sl.modify("/tmp/foo", 1, source="new-source", comment="new-comment")
    assert sl.files == {
        "/tmp/foo": [
            [0, True, True, "some-source", "some-comment"],
            [1, True, True, "new-source", "new-comment"]
        ]
    }

# Generated at 2022-06-23 03:08:20.273673
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('input.txt')
    sources._remove_valid_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.save()
    for filename, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            print(valid, enabled, source, comment)


# Generated at 2022-06-23 03:08:33.767046
# Unit test for function main

# Generated at 2022-06-23 03:08:44.192283
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class Module(object):
        class AnsibleModule(object):
            def __init__(self):
                self.params = {'state': 'present'}
                self.fail_json = self.fail_json_real
                self.run_command = self.run_command_real
                self.check_mode = False

            def fail_json_real(self, *args, **kwargs):
                print(json.dumps({'msg': 'FAILED: %s, %s' % (args, kwargs)}))

            @staticmethod
            def run_command_real(*args, **kwargs):
                return 0, '', ''

        def __init__(self):
            self.AnsibleModule = self.AnsibleModule()
            self.run_command = self.run_command_real


# Generated at 2022-06-23 03:08:57.632552
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import types
    import sys
    from ansible.module_utils.basic import AnsibleModule

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class FakeModule(object):
        run_command_rcs = []

        def __init__(self):
            self.check_mode = False

        def run_command(self, *args, **kwargs):
            return self.run_command_rcs.pop(0)

    class TestGetAddPpaSigningKeyCallback(unittest.TestCase):
        def testCallbackRunsProperly(self):
            module = FakeModule()
            module.run_command_rcs = [0, 0]
            add_ppa_signing_keys_callback = get_add_ppa

# Generated at 2022-06-23 03:09:01.072206
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file.endswith("sources.list")
    assert len(sources.files) == 0



# Generated at 2022-06-23 03:09:10.084859
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Create a mock module and SourcesList object
    filename = tempfile.mktemp()
    f = open(filename, 'w')
    f.write('''deb http://archive.canonical.com/ubuntu hardy partner
deb http://archive.canonical.com/ubuntu hardy partner # Comment
deb-src http://archive.canonical.com/ubuntu hardy partner
# deb http://archive.canonical.com/ubuntu hardy partner
Lorem ipsum dolor sit amet, consectetur
''')
    f.close()
    module = AnsibleModule({})
    s = SourcesList(module)
    s.load(filename)
    # Modify first (enabled) source
    s.modify(filename, 0, comment=' Modified comment')

# Generated at 2022-06-23 03:09:23.568047
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    '''
    Unit test for method load of class SourcesList
    '''
    # Testing if file is loaded properly
    # if the file is not present function should raise an exception
    test_sourcelist = SourcesList()
    try:
        test_sourcelist.load('tests/sources.list')
    except Exception:
        test_sourcelist.fail_json(msg="Failed to open a file")
    # Testing whether the number of enabled and disabled lines
    # are correct in the file
    enabled_lines = 0
    disabled_lines = 0
    for filename, n, enabled, source, comment in test_sourcelist:
        if enabled:
            enabled_lines += 1
        else:
            disabled_lines += 1
    assert enabled_lines == 4
    assert disabled_lines == 4


# Generated at 2022-06-23 03:09:26.587829
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    module = AnsibleModule(argument_spec=dict())
    e = InvalidSource('test_msg')
    module.fail_json(msg=e)



# Generated at 2022-06-23 03:09:39.171314
# Unit test for function main
def test_main():
    class MockModule(object):
        def __init__(self):
            self.params = {'repo': 'deb [arch=amd64] http://download.docker.com/linux/ubuntu bionic stable',
                           'state': 'present',
                           'mode': '644',
                           'update_cache': True,
                           'update_cache_retries': 5,
                           'update_cache_retry_max_delay': 12,
                           'filename': None,
                           'install_python_apt': True,
                           'validate_certs': True,
                           'codename': None,
                           }
            self.check_mode = False
            self._diff = True
        def fail_json(self, msg=''):
            return {'msg': msg}

# Generated at 2022-06-23 03:09:51.046460
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Tests for SourcesList.remove_source()
    """
    import sys
    import tempfile
    import textwrap

    class MockModule(object):
        def __init__(self):
            pass

        def fail_json(self, **kwargs):
            pass

        def run_command(self, cmd):
            return False, '', ''

    class MockAptPkg(object):
        @staticmethod
        def Config(filespec):
            return os.path.join(os.getcwd(), filespec)

        @staticmethod
        def FindFile(path):
            return path

        @staticmethod
        def FindDir(path):
            return path

    mocked_apt_pkg = MockAptPkg()
    mocked_module = MockModule()

    # Prepare a temp file to be read by SourcesList
   

# Generated at 2022-06-23 03:10:03.552847
# Unit test for function install_python_apt
def test_install_python_apt():
    # Expected init_module() call
    # pylint: disable=unused-argument
    def init_module(module_name, args, kwargs):
        assert module_name == 'ansible.builtin.apt_repository'
        assert args == {}
        assert kwargs['check_mode'] is False

    # Expected module.run_command() calls
    # pylint: disable=unused-argument
    def run_command(cmd, check_rc=True):
        assert cmd == ['apt-get', 'update']
        return 0, b'', b''
    def run_command(cmd, check_rc=True):
        assert cmd == ['apt-get', 'install', 'python-apt', '-y', '-q']
        return 0, b'', b''

    # Expected has_

# Generated at 2022-06-23 03:10:14.665938
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    module = AnsibleModule({})
    apt_pkg.init()
    sources_before = {tempfile.mkstemp()[1]: True}
    sources_after = dict(sources_before, **{tempfile.mkstemp()[1]: True})
    sourceslist_before = SourcesList(module)


# Generated at 2022-06-23 03:10:24.584722
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from . import lib_apt_repo_mock
    with lib_apt_repo_mock.mock():
        # prepare object
        module = mock.Mock()
        module.params = {'codename': mock.Mock()}
        module.params['codename'].return_value = 'test_codename'
        add_ppa_signing_keys_callback = mock.Mock()
        obj = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
        obj.codename = 'test_codename'
        obj.module = module
        obj.add_ppa_signing_keys_callback = add_ppa_signing_keys_callback
        obj.files = {}
        # call deepcopy
        result = obj.__deepcopy__()
        # tests

# Generated at 2022-06-23 03:10:34.964612
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sources = SourcesList()
    sources.add_source('deb http://archive.ubuntu.com/ubuntu artful main')
    assert sources.files['/etc/apt/sources.list'][0][3] == "deb http://archive.ubuntu.com/ubuntu artful main"
    sources.add_source('# deb http://archive.ubuntu.com/ubuntu artful main')
    assert sources.files['/etc/apt/sources.list'][1][3] == "deb http://archive.ubuntu.com/ubuntu artful main"
    assert sources.files['/etc/apt/sources.list'][1][2] == False
    sources.add_source('deb http://archive.ubuntu.com/ubuntu artful main # comment',
                       comment='# comment')

# Generated at 2022-06-23 03:10:44.144671
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModuleMock()
    module.params = dict(
        filename='test.list')
    usl = UbuntuSourcesList(module)
    sources_to_test = [
        'deb https://download.sublimetext.com/ apt/stable/',
        'ppa:ansible/ansible'
    ]

    for source in sources_to_test:
        usl.add_source(source, comment='SublimeText editor')

    expected_files = [
        ('apt/sublimetext.list', 'deb https://download.sublimetext.com/ apt/stable/ # SublimeText editor\n'),
        ('ppa_ansible_ansible.list', 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main # SublimeText editor\n')
    ]

   

# Generated at 2022-06-23 03:10:51.415113
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    TEST_DATA = {
        'file': 'testfile',
        'line': 'deb http://example.com squeeze main\n',
        'ls': [(0, True, True, "deb http://example.com squeeze main", "")]
    }
    sl = SourcesList(None)
    sl.files[TEST_DATA['file']] = TEST_DATA['ls']
    sl.modify('testfile', 0, comment='test comment')
    assert sl.files == {'testfile': [(0, True, True, "deb http://example.com squeeze main", 'test comment')]}


# Generated at 2022-06-23 03:11:02.840295
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import tempfile
    import shutil

    dir = tempfile.mkdtemp()

    testpath = os.path.join(dir, "testfile.list")
    f = open(testpath, "w")
    f.write("\n#comment\n\n")
    f.write("deb\t\tfoo\n")
    f.write("deb-src http://foo   \n")
    f.write("deb-src [arch=amd64] https://foo   \n")
    f.close()

    sl = SourcesList(None)

    sl.load(testpath)

    sources = [(n, valid, enabled, source, comment) for n, valid, enabled, source, comment in sl]


# Generated at 2022-06-23 03:11:05.440610
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sl = SourcesList(None)
    sl.load('sources.list')
    assert len(list(sl)) == 2

# Generated at 2022-06-23 03:11:13.963776
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, check_invalid_arguments=False)
    sources_list = SourcesList(module)

    assert os.path.isfile(sources_list.default_file)

    # parse() tests
    def check_valid(line, expected):
        valid, enabled, source, comment = sources_list._parse(line)
        assert enabled == expected[0], 'enabled: %s expected: %s' % (enabled, expected[0])
        assert source == expected[1], 'source: %s expected: %s' % (source, expected[1])
        assert comment == expected[2], 'comment: %s expected: %s' % (comment, expected[2])

# Generated at 2022-06-23 03:11:20.236486
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    fail = False
    try:
        raise InvalidSource()
    except InvalidSource:
        fail = True
        assert fail



# Generated at 2022-06-23 03:11:31.215476
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import io
    import os
    import tempfile
    from ansible.module_utils.apt_repository import SourcesList

    def _run_iterator(content, expected_num_of_valid_sources):
        f = tempfile.NamedTemporaryFile(mode='w+t', encoding='utf-8', delete=False, suffix='.list')
        f.write(content)
        f.close()
        sources = SourcesList(None)
        sources.load(f.name)
        i = 0
        for it in sources:
            i += 1
        os.unlink(f.name)
        return i == expected_num_of_valid_sources

    # 1. Test that iterator over empty file return zero iterators.
    assert _run_iterator("", 0)

    # 2. Test that iterator over file with

# Generated at 2022-06-23 03:11:36.670113
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule
    s = SourcesList(module)
    s.load(apt_pkg.Config.FindFile('Dir::Etc::sourcelist'))
    s.remove_source('deb http://http.debian.net/debian sid main')
    assert not any([True for t, enabled, src, comment in s if src == 'deb http://http.debian.net/debian sid main'])



# Generated at 2022-06-23 03:11:46.608196
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.apt.revert_sources_list import revert_sources_list
    from ansible.module_utils.apt.revert_sources_list import SourcesList
    from ansible.module_utils.apt.revert_sources_list import UbuntuSourcesList
    for os_family in ['Debian', 'Suse']:
        for Repos in [SourcesList, UbuntuSourcesList]:
            module = AnsibleModule({})
            sourceslist_before = Repos(module)
            # Make sure sources list is empty
            sources_before = sourceslist_before.dump()
            assert len(sources_before) == 0
            sourceslist_after = sourceslist_before
            sources_after = sourceslist_after.dump()
            # Add a new file to the sources list

# Generated at 2022-06-23 03:11:47.615189
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    assert False, "No unit tests implemented"

# Generated at 2022-06-23 03:11:56.622032
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # some test data
    sources_list_dict = {
        'afile.list': [
            (0, True, False, 'deb http://archive.ubuntu.com/ubuntu bionic universe', 'test comment'),
            (1, True, True, 'deb-src http://archive.ubuntu.com/ubuntu bionic multiverse', ''),
            (0, False, False, 'deb http://archive.ubuntu.com/ubuntu bionic multiverse', ''),
        ],
        'another_file.list': [
            (0, True, True, 'deb-src http://archive.ubuntu.com/ubuntu bionic multiverse', ''),
            (1, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic main', 'test comment'),
        ],
    }
    # create a SourcesList class object and set the sources loaded in it

# Generated at 2022-06-23 03:12:04.529036
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    source_list = UbuntuSourcesList(module)
    source_list.add_source('deb http://ppa.launchpad.net/mahshad/ppa/ubuntu precise main')
    assert source_list.files['/etc/apt/sources.list.d/mahshad_ppa_ubuntu_precise.list'][0][3] == 'deb http://ppa.launchpad.net/mahshad/ppa/ubuntu precise main'

# Generated at 2022-06-23 03:12:13.349232
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test case 1:
    # Input:
    # ppa:ubuntu-toolchain-r/ppa
    #
    # Expected result:
    # deb http://ppa.launchpad.net/ubuntu-toolchain-r/ppa/ubuntu trusty main
    # Actual result:
    # deb http://ppa.launchpad.net/ubuntu-toolchain-r/ppa/ubuntu trusty main
    def mock_add_ppa_signing_keys_callback():
        pass

    ppa_source = 'ppa:ubuntu-toolchain-r/ppa'
    mock_module = MagicMock()
    ppa_cls = UbuntuSourcesList(mock_module, add_ppa_signing_keys_callback=mock_add_ppa_signing_keys_callback)
    ppa_cls.codename = 'trusty'


# Generated at 2022-06-23 03:12:15.095824
# Unit test for function install_python_apt
def test_install_python_apt():
    # This function can't be unit tested, since it calls apt-get
    pass



# Generated at 2022-06-23 03:12:25.776731
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.modules.packaging.os import apt_repository


# Generated at 2022-06-23 03:12:36.912632
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModuleMock()
    sources = UbuntuSourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Unit test of _expand_ppa method
    source_line, ppa_owner, ppa_name = sources._expand_ppa('ppa:ansible/ansible')
    assert source_line == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    assert ppa_owner == 'ansible'
    assert ppa_name == 'ansible'

    # Unit test of _get_ppa_info method
    info = sources._get_ppa_info(ppa_owner, ppa_name)

# Generated at 2022-06-23 03:12:47.089628
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    source_list=SourcesList()
    source_list.files['/etc/apt/sources.list.d/nginx-stable-trusty.list'] = [(0, True, True, 'deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main', ''),
                                                                             (1, True, True, 'deb-src http://ppa.launchpad.net/nginx/stable/ubuntu trusty main', '')]
    source_list.remove_source('deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main')

# Generated at 2022-06-23 03:12:55.727814
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class Module_add_source():
        def __init__(self):
            self.params = {
                'filename': None,
                'codename': 'trusty',
            }

        def fail_json(self, msg):
            raise AssertionError(msg)

    module = Module_add_source()

    class UbuntuSourcesList_add_source():
        def __init__(self):
            self.files = {}

        def _suggest_filename(self, line):
            return 'test_sugest_filename.sources.list'

        def _add_valid_source(self, source, comment, file=None):
            return True

    sl = UbuntuSourcesList_add_source()
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)
    usl.files = sl

# Generated at 2022-06-23 03:13:07.486563
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.files = {
        'file1': [
            (0, True, True, "deb http://foo main", 'comment'),
            (1, True, False, "deb http://foo main", 'comment'),
            (2, False, True, "deb http://foo main", 'comment'),
            (3, True, True, "deb http://foo main", ''),
            (4, True, True, "deb http://foo main", None),
            (5, True, True, "deb http://foo main", 'comment'),
        ],
        'file2': [],
    }
    assert sl.dump() == {
        'file1': 'deb http://foo main\n',
        'file2': '',
    }


# Generated at 2022-06-23 03:13:13.005757
# Unit test for constructor of class SourcesList
def test_SourcesList():
    mod = AnsibleModule({'_ansible_check_mode': True})
    sources = SourcesList(mod)
    assert sources.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-23 03:13:22.741340
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = MockModule()
    sourceslist = SourcesList(module)


# Generated at 2022-06-23 03:13:30.038564
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(dict())
    module.params = {'filename': 'ansible_test.list'}
    sources_list = UbuntuSourcesList(module)

    def _add_ppa_signing_keys_callback(command):
        pass

    module.params = {'filename': 'ansible_test.list', 'codename': 'xenial'}
    sources_list2 = UbuntuSourcesList(module, _add_ppa_signing_keys_callback)



# Generated at 2022-06-23 03:13:32.016419
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None



# Generated at 2022-06-23 03:13:43.734983
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:13:56.363848
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class SourcesList(object):
        def __init__(self, module):
            self.module = module
            self.files = {}  # group sources by file
            # Repositories that we're adding -- used to implement mode param
            self.new_repos = set()
            self.default_file = self._apt_cfg_file('Dir::Etc::sourcelist')

        @staticmethod
        def _apt_cfg_file(filespec):
            return "/etc/apt/sources.list"

        @staticmethod
        def _apt_cfg_dir(dirspec):
            return "/etc/apt/sources.list.d"

        def _parse(self, line, raise_if_invalid_or_disabled=False):
            valid = False
            enabled = True
            source = ''
            comment = ''


# Generated at 2022-06-23 03:14:06.938547
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import ast

    class MockModule(object):
        def __init__(self):
            self.exit_args = None
            self.exit_kwargs = None

        def fail_json(self, msg, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    m = MockModule()
    s = SourcesList(m)
    s.files = {
        'file1': [
            (0, False, True, 'deb foo', 'bar'),  # invalid source
            (1, True, True, 'deb foo baz', 'bar'),  # old values
        ],
        'file2': [
            (0, True, False, 'deb foo baz', 'bar'),  # disabled source
        ],
        'file3': []  # empty list
    }

# Generated at 2022-06-23 03:14:16.351199
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    for line in ('deb http://archive.canonical.com/ubuntu hardy partner',
                 'deb http://archive.canonical.com/ubuntu hardy partner',
                 '# deb http://archive.canonical.com/ubuntu hardy partner',
                 '    deb http://archive.canonical.com/ubuntu hardy partner'):
        sources = SourcesList()
        sources._add_valid_source('deb http://archive.canonical.com/ubuntu hardy partner', '', 'sources.list')
        sources._add_valid_source('deb http://archive.canonical.com/ubuntu hardy partner', '', 'sources.list')
        sources._add_valid_source('# deb http://archive.canonical.com/ubuntu hardy partner', '', 'sources.list')

# Generated at 2022-06-23 03:14:23.024791
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist._suggest_filename = lambda x: os.path.abspath(os.path.join(tempfile.gettempdir(), x))
    sourceslist.files.clear()
    sourceslist.load('test_sourceslist.txt')

# Generated at 2022-06-23 03:14:26.267381
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec=dict(
        install_python_apt=dict(type='bool', default='true'),
    ))
    assert install_python_apt(module, "python-apt") == None, "Failed to install python-apt"



# Generated at 2022-06-23 03:14:33.733606
# Unit test for function install_python_apt
def test_install_python_apt():
    import tempfile
    import ansible.module_utils.basic
    import ansible.module_utils.common.sys_info
    import ansible.module_utils.six
    import sys
    import os
    import json

    d = tempfile.temp_dir
    if 'ANSIBLE_LIBRARY' in os.environ:
        d = os.environ.get('ANSIBLE_LIBRARY')

    m = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    m_copy = copy.deepcopy(m)
    m_copy.fail_json = lambda x: sys.exit(1)

    install_python_apt(m_copy, 'python3-apt')

    # We're installing on a Python2 system, so

# Generated at 2022-06-23 03:14:44.243938
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # test empty sources list
    module = AnsibleModule(
        argument_spec = dict()
    )
    sl = SourcesList(module)
    assert not sl.files

    # test non-existent sources list
    none_sources_list = '/etc/apt/sources.list_not_exists'
    module = AnsibleModule(
        argument_spec = dict(
            filename = dict(type='path', required=False),
            repo = dict(type='str', required=False),
        )
    )
    sl = SourcesList(module)
    assert sl.files == { none_sources_list: [] }

    # test sources list

# Generated at 2022-06-23 03:14:55.677645
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    src = SourcesList(None)
    src._add_valid_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main",
                         "comment", 'ansible.list')
    src._add_valid_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main",
                         "comment", 'ansible.list')
    src._add_valid_source("deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main",
                         "comment", 'ansible.list')
    src._add_valid_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main",
                         "comment2", 'ansible.list')

# Generated at 2022-06-23 03:14:56.687532
# Unit test for function install_python_apt
def test_install_python_apt():
    pass


# Generated at 2022-06-23 03:15:06.936116
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """Test SourcesList.save()
    """
    import os
    import shutil
    import tempfile


# Generated at 2022-06-23 03:15:19.146956
# Unit test for method add_source of class UbuntuSourcesList

# Generated at 2022-06-23 03:15:29.295257
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(
        argument_spec=dict(
            filename=dict(type='str', required=False),
            state=dict(type='str', required=False, default='present'),
            sources=dict(type='list', required=False),
            mode=dict(type='str', required=False, default=DEFAULT_SOURCES_PERM),
            codename=dict(type='str', required=False, default=None)
        )
    )
    sources_before = dict()
    sources_after = dict()
    sourceslist_before = dict()
    sourceslist_before.save = lambda: None
    result = revert_sources_list(sources_before, sources_after, sourceslist_before)
    module.exit_json(changed=False)


# Generated at 2022-06-23 03:15:37.577492
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    def my_run_command(command, check_rc=None):
        print(command)

    module = FakeModule()
    module.run_command = my_run_command
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    callback([])
    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None



# Generated at 2022-06-23 03:15:41.278016
# Unit test for function revert_sources_list
def test_revert_sources_list():
    m = AnsibleModule()
    s = SourcesList(m)
    s1 = list(s)
    s.add_source('s1', 's1')
    s.add_source('s2', 's2')
    s2 = list(s)
    s3 = list(s)
    s.add_source('s3', 's3')
    s4 = list(s)
    revert_sources_list(s2, s3, s)
    assert(list(s) == s2)
    revert_sources_list(s1, s2, s)
    assert(list(s) == s1)


# ==============================================================================
# main control flow


# Generated at 2022-06-23 03:15:50.565924
# Unit test for function main
def test_main():
    mo = MagicMock()
    mo.params = {}
    mo.params['repo'] = 'fake_repo'
    mo.params['state'] = 'fake_state'

    mo.module = ''
    mo.check_mode = False
    mo._diff = True
    mo.fail_json.side_effect = Exception('fail')
    mo.fail_json.return_value = None

    mo.exit_json.return_value = None

    main(mo)

    mo.fail_json.assert_called_once_with(msg='apt_repository is not supported on target.')


# Generated at 2022-06-23 03:15:52.723846
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)



# Generated at 2022-06-23 03:16:02.785502
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    try:
        a = UbuntuSourcesList(None)
        b = deepcopy(a)
        assert a.__dict__.keys() == b.__dict__.keys()
        assert a.__dict__['module'] == b.__dict__['module']
        assert a.__dict__['add_ppa_signing_keys_callback'] == b.__dict__['add_ppa_signing_keys_callback']
        assert a.__dict__['codename'] == b.__dict__['codename']
        assert a.__dict__['files'] == b.__dict__['files']
    except AssertionError as e:
        raise AssertionError(to_native(e))
    except Exception as e:
        if IS_PY2:
            raise Exception(to_native(e))