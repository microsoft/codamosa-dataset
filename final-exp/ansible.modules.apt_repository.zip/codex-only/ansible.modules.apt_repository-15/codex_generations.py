

# Generated at 2022-06-23 03:06:16.431212
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import pprint
    import os
    # init vars and constants
    line='deb http://us.archive.ubuntu.com/ubuntu/ precise main restricted universe multiverse'
    filename="/tmp/sources.list.disabled"
    comment="a disabled line"
    sl=SourcesList(None)

    # populate the sources
    f = open(filename,'w')
    f.write("#%s #%s \n" % (line,comment))
    f.close()
    # read the sources
    sl.load(filename)
    # test the iterator
    for key,value in sl.files.items():
        for index in value:
            assert(index[4]==comment)
    os.remove(filename)



# Generated at 2022-06-23 03:06:21.053510
# Unit test for function revert_sources_list
def test_revert_sources_list():
    global SourcesList, file
    SourcesList = FakeSourcesListClass
    sl = SourcesList()
    file = {}
    # Create a modification to a file then test the revert
    def _create_mod(file):
        sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main')
        sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main',file='file1')
        sl.add_source('deb http://archive.ubuntu.com/ubuntu precise main',file='file2')
        file['file1'] = 'deb http://archive.ubuntu.com/ubuntu precise main'
        file['file2'] = 'deb http://archive.ubuntu.com/ubuntu precise main'
        return sl
    sl_before = _create_mod(file)
    sl_after = _create_mod(file)
   

# Generated at 2022-06-23 03:06:29.633859
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class ModuleStub(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def atomic_move(self, tmp, dest):
            with open(dest, 'w') as f:
                with open(tmp, 'r') as fh:
                    for line in fh:
                        f.write(line)

        def set_mode_if_different(self, filename, this_mode, DEFAULT_SOURCES_PERM):
            pass

    class ResponseStub(object):
        def __init__(self, status, content=""):
            self.status = status
            self.content = content.encode('utf-8')

        def getcode(self):
            return self.status


# Generated at 2022-06-23 03:06:34.473883
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = DummyModule()
    sl = SourcesList(module)
    assert list(sl) == []
    sl.load('/etc/somewhere/sources.list')
    assert list(sl) == ['/etc/somewhere/sources.list', 0, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '']
    sl.load('/etc/somewhere/sources.list.d/file.list')

# Generated at 2022-06-23 03:06:39.375918
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = Mock()
    src = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)
    assert type(deepcopy(src)) == UbuntuSourcesList


# Generated at 2022-06-23 03:06:50.215773
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})


# Generated at 2022-06-23 03:06:55.560191
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    src = "deb http://archive.ubuntu.com/ubuntu/ precise universe\n"
    src1 = "deb-src http://archive.ubuntu.com/ubuntu/ precise universe\n"
    with open("sources.list", 'w') as f:
        f.write(src)
        f.write(src1)
    S = SourcesList("sources.list")
    check = {
        "sources.list": src+src1
    }
    result = S.dump()
    assert result == check


# Generated at 2022-06-23 03:07:04.505640
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources_list = UbuntuSourcesList(None)

    sources_list.add_source('deb http://ppa.launchpad.net/git-core/ppa/ubuntu xenial main')
    sources_list.add_source('ppa:git-core/ppa')
    sources_list.add_source('deb http://linux.dropbox.com/ubuntu xenial main')
    sources_list.add_source('deb [arch=amd64] https://repo.mongodb.org/apt/ubuntu xenial/mongodb-org/3.4 multiverse')
    sources_list.add_source('deb http://ppa.launchpad.net/webupd8team/java/ubuntu xenial main', file='/etc/apt/sources.list.d/webupd8team-java.list')


# Generated at 2022-06-23 03:07:05.486170
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    assert SourcesList(None).modify(None, None) == None

# Generated at 2022-06-23 03:07:16.309909
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({'_ansible_check_mode': True})
    source_list = SourcesList(module)
    test_sources_list_file = '/tmp/ansible_test_sources_list'

# Generated at 2022-06-23 03:07:25.373836
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest

    class TestUbuntuSourcesCase(unittest.TestCase):
        def setUp(self):
            class Module(object):
                def __init__(self, codename):
                    self.params = {
                        'filename': None,
                        'codename': codename
                    }
                def fail_json(self, msg):
                    raise Exception(msg)
                def atomic_move(self, src, dst):
                    pass
                def set_mode_if_different(self, path, mode, changed=True):
                    pass
                def run_command(self, cmd, check_rc=True):
                    pass
            self._module = Module('xenial')
            self._module.params['filename'] = ''
            self._module.params['codename'] = 'xenial'


# Generated at 2022-06-23 03:07:36.972356
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # Create temp file with sample repository information
    # (can't reuse default sources since it is already loaded)
    sample_file_path = os.path.join(tempfile.gettempdir(), 'ansible_apt_module_test')
    with open(sample_file_path, 'w') as sample_file:
        sample_file.write('deb http://ftp.us.debian.org/debian testing main\n')

    sources_list = SourcesList(dict(module=None))
    sources_list.load(sample_file_path)

    for file, n, enabled, source, comment in sources_list:
        assert file == sample_file_path, "File name is incorrect"
        assert n == 0, "Source line number is incorrect"
        assert enabled, "Source is not enabled"

# Generated at 2022-06-23 03:07:46.170244
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import os
    import tempfile
    import shutil
    import random
    import string
    import json

    tmpdir = tempfile.mkdtemp(prefix='ansible_apt_repository_')
    conf_file = os.path.join(tmpdir, 'sources.list')


# Generated at 2022-06-23 03:07:55.186998
# Unit test for function main
def test_main():
    repo = 'http://test.example.com/'
    state = 'present'
    update_cache = True
    mode = None
    install_python_apt = True
    interpreter = '/usr/bin/python'
    # Note: mode is referenced in SourcesList class via the passed in module (self here)

    sourceslist = None


# Generated at 2022-06-23 03:08:03.260193
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)
    source_file = '/tmp/ansible-test-source-%x' % random.randint(1001, 2 ** 64)
    test_source = 'deb http://archive.ubuntu.com/ubuntu trusty main'
    s.files[source_file] = [(0, True, True, test_source, '')]
    assert s.dump() == {source_file: test_source + '\n'}



# Generated at 2022-06-23 03:08:05.277622
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    message = "bla"
    error = InvalidSource(message)
    assert error.args[0] == message



# Generated at 2022-06-23 03:08:14.135570
# Unit test for function revert_sources_list
def test_revert_sources_list():
    paths = [
        '/etc/apt/sources.list',
        '/etc/apt/sources.list.d/ansible-repository.list',
    ]
    sources_before = {}
    sources_after = {}
    for path in paths:
        f = open(path, 'r')
        lines = []
        for line in f:
            lines.append(line)
        f.close()
        sources_before[path] = lines

    # Modify 1 file
    add_source_line(paths[0], '### ANSIBLE MANAGED BLOCK ###')
    # Modify 2 file
    add_source_line(paths[1], '### ANSIBLE MANAGED BLOCK ###')
    # Check all modifications
    for path in paths:
        f = open(path, 'r')


# Generated at 2022-06-23 03:08:24.880628
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    def test_module(**kwargs):
        name = 'test'
        module = MagicMock(
            name=name,
            check_mode=False,
            run_command=MagicMock(
                side_effect=lambda command, check_rc:
                    [0, None, None] if command[3] == 'FAKE_KEY' else
                    [1, None, 'ImportError: ']
            )
        )
        return module

    module = test_module()
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None

    module = test_module(check_mode=True)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module = test_module(check_mode=False)
    callback = get

# Generated at 2022-06-23 03:08:36.430922
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    NEED_ACCEPT = True

    def accept(msg):
        if NEED_ACCEPT:
            print(msg)
            return True
        else:
            return False

    module = AnsibleModule({})
    class _SourcesList(SourcesList):

        def __init__(self, module):
            super(_SourcesList, self).__init__(module)

        @staticmethod
        def _apt_cfg_file(filespec):
            if filespec.endswith('Dir::Etc::sourcelist'):
                return '/etc/apt/sources.list'
            if filespec.endswith('Dir::Etc::sourceparts'):
                return '/etc/apt/sources.list.d'
            return '/etc/apt/%s' % filespec

# Generated at 2022-06-23 03:08:43.015529
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = Mock()
    module.params = {}
    module.params['codename'] = None
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['update_cache'] = None
    module.params['use_proxy'] = None
    retval = UbuntuSourcesList(module)

    res = retval.__deepcopy__()

    assert not res.module
    assert res.codename == UbuntuSourcesList.codename



# Generated at 2022-06-23 03:08:50.966443
# Unit test for function main
def test_main():
    repo = 'deb http://http.kali.org/kali kali-rolling main non-free contrib'
    state = 'present'
    result = main()
    assert result is not None
test_main()

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.urls import *
from ansible.module_utils._text import to_native, to_text

main()

# Generated at 2022-06-23 03:08:57.009993
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # create a module for testing
    module = AnsibleModule(
        argument_spec=dict(
            codename=dict(required=False, type='str'),
        ),
    )
    # test check_mode
    module.check_mode = True

    # test UbuntuSourcesList class
    sources_list = UbuntuSourcesList(module)



# Generated at 2022-06-23 03:09:07.377647
# Unit test for method __iter__ of class SourcesList

# Generated at 2022-06-23 03:09:12.277491
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = MagicMock(return_value={
        'name': 'ubuntu',
        'module_utils': 'ansible.module_utils',
        'codename': 'xenial',
    })
    u = UbuntuSourcesList(module())
    assert u.codename == 'xenial'



# Generated at 2022-06-23 03:09:23.873015
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = None
    sources = SourcesList(module)
    a='deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'
    sources._add_valid_source(a,'')
    b=('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main', '#')
    sources.modify(sources.files.keys()[0],0,comment=b[1])
    if sources.files.values()[0][0][4] != b[1]:
        print('test_SourcesList_modify: FAIL')
        return
    if not b[0] in [s for s in sources]:
        print('test_SourcesList_modify: FAIL')
        return
    print('test_SourcesList_modify: PASS')


# Generated at 2022-06-23 03:09:28.168301
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load("/etc/apt/sources.list")
    sourceslist.load("/etc/apt/sources.list.d/ansible-2017.01.02-01_unstable.list")
    assert len(sourceslist.files) == 2

    lines = sourceslist.files["/etc/apt/sources.list"]
    assert len(lines) > 1
    assert lines[0] == (0, True, True, 'deb http://example.org/debian jessie main', '')
    assert lines[1] == (1, True, True, 'deb http://example.org/debian unstable main', '')


# Generated at 2022-06-23 03:09:39.418215
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {"/etc/apt/sources.list": "deb [arch=amd64,arm64,armhf,i386,ppc64el,ppc64le64el] http://archive.raspbian.org/raspbian/ jessie main contrib non-free rpi"
        }
    sources_after = {"/etc/apt/sources.list": "deb [arch=amd64,arm64,armhf,i386,ppc64el,ppc64le64el] http://archive.raspbian.org/raspbian/ jessie main contrib non-free rpi"
        }
    # First remove any new files that were created:

# Generated at 2022-06-23 03:09:50.697658
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    import sys
    import StringIO
    module = StringIO.StringIO()

    try:
        # Detect Python version
        if sys.version_info < (2, 6):
            import unittest2 as unittest
        else:
            import unittest

        class UbuntuSourcesListTestCase(unittest.TestCase):
            def setUp(self):
                self.module = module
                self.ubuntu_sources_list = UbuntuSourcesList(self.module)

            def test_constructor(self):
                self.assertIsInstance(self.ubuntu_sources_list, UbuntuSourcesList)

        unittest.main()
    except ImportError:
        print("Error: you need to install the unittest2 or unittest modules for this test")


# Generated at 2022-06-23 03:10:00.469637
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    try:
        os.makedirs('/tmp/ansible_test')
    except OSError:
        pass

# Generated at 2022-06-23 03:10:11.447043
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    lines = ['deb http://archive.ubuntu.com/ubuntu trusty main',
             'deb http://archive.canonical.com/ubuntu trusty partner',
             '#deb http://dl.google.com/linux/chrome/deb/ stable main']

    basedir = os.path.dirname(os.path.realpath(__file__))

    # First, create a temporary file with arbitrary sources
    temp = tempfile.NamedTemporaryFile(suffix='.list', prefix='test-', mode='w+')
    temp.write('\n'.join(lines))
    temp.write('\n')
    temp.flush()

    # Second, create an instance of SourcesList with this file

# Generated at 2022-06-23 03:10:16.238906
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    u = UbuntuSourcesList(AnsibleModule({}), add_ppa_signing_keys_callback=None)
    u.load('/etc/apt/sources.list')
    assert len(list(u)) == 1
    u.remove_source('# deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    assert len(list(u)) == 0



# Generated at 2022-06-23 03:10:27.128009
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not PY3:
        reload(sys)
        sys.setdefaultencoding('utf8')
    empty_file_name = tempfile.mktemp()
    sources_file_name = tempfile.mktemp()
    f = open(empty_file_name, "w")
    f.close()
    f = open(sources_file_name, "w")
    f.write("# This is a comment\n")
    f.write("deb http://archive.canonical.com/ubuntu hardy partner\n")
    f.write("deb-src http://archive.canonical.com/ubuntu hardy partner\n")
    f.write("\n")
    f.write("   \n")

# Generated at 2022-06-23 03:10:40.720083
# Unit test for function main
def test_main():
    github_repo_name = 'ansible/ansible'
    github_repo_url = 'https://github.com/%s' % github_repo_name
    github_repo_key = 'https://github.com/%s.keys' % github_repo_name


# Generated at 2022-06-23 03:10:51.974462
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''revert_sources_list unit test'''

    invalid_sources_list_dir = '/etc/apt/sources.list.d'
    if not os.path.isdir(invalid_sources_list_dir):
        os.makedirs(invalid_sources_list_dir)

    module = AnsibleModule({
        'state': 'absent',
        'update': 'no',
        'filename': 'test.list',
        'mode': '0444',
    }, check_invalid_arguments=False)

    # Add a file in the sources.list.d directory:
    filename = os.path.join(invalid_sources_list_dir, module.params['filename'])

# Generated at 2022-06-23 03:11:03.182114
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile
    import shutil
    import os
    import re

    module = AnsibleModule(
        argument_spec=dict(
            mode=dict(default=None),
            state=dict(default=None),
            sources=dict(default=None),
            filename=dict(default=None),
            update_cache=dict(default=None),
            validate_certs=dict(default=None),
            keyserver=dict(default=None),
            key=dict(default=None),
            repo=dict(default=None),
            codename=dict(default=None),
            distro=dict(default=None),
        ),
        supports_check_mode=True,
    )

    tmp = tempfile.mkdtemp()

# Generated at 2022-06-23 03:11:13.282826
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sources = SourcesList(module)
    sources_before = sources.dump()
    sources_list_file = os.path.join(tempfile.gettempdir(), 'sources.list')
    sources.add_source('deb http://example.com/ubuntu xenial main', None)
    sources.save()
    module.atomic_move(sources_list_file, '{}.save'.format(sources_list_file))

# Generated at 2022-06-23 03:11:29.109280
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import sys

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    sources = SourcesList(module)
    module.fail_json = lambda msg: sys.exit(msg)

    if not os.path.isdir('/etc/apt/sources.list.d'):
        os.makedirs('/etc/apt/sources.list.d')


# Generated at 2022-06-23 03:11:37.322234
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    filename_tmp = tempfile.mkstemp(prefix="._tmp_sources_")

# Generated at 2022-06-23 03:11:43.366312
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.ansible_release import __version__ as ansible_version

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    module.exit_json(changed=False)
    __version__ = ansible_version



# Generated at 2022-06-23 03:11:45.900844
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("InvalidSource test")
    except InvalidSource as e:
        assert str(e) == "InvalidSource test"


# Generated at 2022-06-23 03:11:54.523131
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({'name': 'testdata'})
    sources_list=SourcesList(module)
    sources_list.files={"testdata.list":[{"1",True,"deb http://testdata data1",""},{"2",True,"deb http://testdata data2",""},{"3",True,"deb http://testdata data3",""}]}
    sources_list.remove_source("deb http://testdata data2")
    assert sources_list.files=={"testdata.list":[{"1",True,"deb http://testdata data1",""},{"2",True,"deb http://testdata data3",""}]}
    

# Generated at 2022-06-23 03:12:07.221939
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class Module(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            raise AssertionError(to_native(msg))

        def get_bin_path(self, name):
            if name == 'apt-get':
                return '/usr/bin/apt-get'
            raise NotImplementedError()

        def run_command(self, name):
            raise NotImplementedError()

        def atomic_move(self, source, dest):
            raise NotImplementedError()

        def set_mode_if_different(self, filename, mode, changed):
            raise NotImplementedError()

    params = {}
    module = Module(params)
    s = SourcesList(module)

    # add new source

# Generated at 2022-06-23 03:12:14.960095
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import sys
    import io
    from contextlib import contextmanager
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.repository import UbuntuSourcesList

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    class StdoutMock():
            def __init__(self):
                self.buffer = []

            def write(self, string):
                self.buffer.append(string)

            def __getattr__(self, attr):
                return getattr(sys.stdout, attr)

    @contextmanager
    def stdout_as_stringio():
        old_stdout = sys.stdout
        sys.stdout = StdoutMock()
        try:
            yield sys.stdout
        finally:
            sys

# Generated at 2022-06-23 03:12:24.942394
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import io
    import tempfile

    # write sources.list to temporary file
    f = io.StringIO()
    f.write(u'''
# disabled (comment)
deb file:/var/cache/apt/archives ./
    ''')
    f.seek(0)
    tmp = tempfile.NamedTemporaryFile()
    tmp.write(f.read().encode('ascii'))
    tmp.flush()

    # load temporary file in sources.list
    sl = SourcesList(None)
    sl.load(tmp.name)

# Generated at 2022-06-23 03:12:36.274335
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule({
        'codename': 'xenial',
        'state': 'present',
        'comment': 'foo',
        'update_cache': False
    })
    file1 = '/etc/apt/sources.list.d/bob_foo.list'
    file2 = '/etc/apt/sources.list.d/bob_bar.list'
    lines1 = [
        'deb http://example.com/ubuntu/ xenial main # bob foo',
        'deb http://example.com/ubuntu/ xenial main # bob foo2'
    ]
    lines2 = [
        'deb http://example.com/ubuntu/ xenial main # bar foo',
        'deb http://example.com/ubuntu/ xenial main # bar foo2'
    ]
    # Ensure the files exist

# Generated at 2022-06-23 03:12:46.749595
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class _Module(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, command, check_rc=False):
            return 0, '', ''

        def atomic_move(self, tmp_path, filename):
            pass


# Generated at 2022-06-23 03:12:58.340218
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    uri_to_add = ["deb-src http://ppa.launchpad.net/ubuntu-toolchain-r/test/ubuntu eoan main"]
    uri_to_remove = ["http://ppa.launchpad.net/ubuntu-toolchain-r/test/ubuntu eoan main"]
    module = AnsibleModule(
            argument_spec = dict(
                    filename = dict(required=False, default=None)
            )
    )
    sources_list = UbuntuSourcesList(module)
    for uri in uri_to_add:
        sources_list.add_source(uri, comment="")

    sources_list.remove_source(uri_to_remove[0])
    repos_urls = sources_list.repos_urls
    assert repos_urls == uri_to_add


# Generated at 2022-06-23 03:13:03.335739
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList(None)
    sl.files['sources.list'] = [(0, True, True, 'deb http://example.org/', 'Some comment')]

    # No change
    sl.modify('sources.list', 0)
    assert sl.files['sources.list'] == [(0, True, True, 'deb http://example.org/', 'Some comment')]

    # Only source change
    sl.modify('sources.list', 0, source='deb http://example.com/')
    assert sl.files['sources.list'] == [(0, True, True, 'deb http://example.com/', 'Some comment')]

    # Only enabled change
    sl.modify('sources.list', 0, enabled=False)

# Generated at 2022-06-23 03:13:13.202215
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})

    sl = SourcesList(module)

    # Unit test #1 - make sure the constructor loads files and parses the data
    file = sl._apt_cfg_file('Dir::Etc::sourcelist')
    assert file in sl.files
    assert len(sl.files[file]) == 0

    file = sl._apt_cfg_file('Dir::Etc::sourceparts') + '/ansible.list'
    assert file in sl.files
    assert len(sl.files[file]) == 1

    file = sl._apt_cfg_file('Dir::Etc::sourceparts') + '/ansible-disabled.list'
    assert file in sl.files
    assert len(sl.files[file]) == 1

    file = sl._apt_cfg_file('Dir::Etc::sourceparts')

# Generated at 2022-06-23 03:13:17.411306
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import doctest
    from ansible.module_utils.six.moves import StringIO
    doctest.testmod(optionflags=doctest.ELLIPSIS, extraglobs={
        'sources': SourcesList(None),
        'StringIO': StringIO,
    })



# Generated at 2022-06-23 03:13:30.699969
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = dict(
        apt = dict(
            main = dict(
                source = 'deb http://ftp.us.debian.org/debian/ testing main',
            ),
        ),
        apt2 = dict(
            contrib = dict(
                source = 'deb http://ftp.us.debian.org/debian/ testing contrib',
            ),
        ),
        apt3 = dict(
            non_free = dict(
                source = 'deb http://ftp.us.debian.org/debian/ testing non-free',
            ),
        ),
    )

# Generated at 2022-06-23 03:13:42.525072
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import ConnectionError
    # Mock the module first
    module = mock.MagicMock()
    module.params = {'codename': 'trusty'}
    module.fail_json.side_effect = SystemExit
    # Mock up the apt_pkg module to run on Python 2.5
    apt_pkg = mock.MagicMock()
    apt_pkg.Config.FindFile.side_effect = ['/etc/apt/sources.list', '/etc/apt/sources.list.d/', '/etc/apt/trusted.gpg.d']
    sys.modules['apt_pkg'] = apt_pkg
    # Mock the tempfile module too, so that we don't create actual temp files
    tempfile = mock.MagicM

# Generated at 2022-06-23 03:13:51.655458
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    f = tempfile.NamedTemporaryFile(delete=False, mode='w+')
    f.write('#deb http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse\n')
    f.write('deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse\n')
    f.close()
    repos = SourcesList(module)
    repos.load(f.name)
    assert len(repos.files) == 1
    f.close()
    os.remove(f.name)


# Generated at 2022-06-23 03:14:00.313091
# Unit test for function main
def test_main():
  global __salt__
  __opts__ = {}
  __salt__ = {}
  def __grains__(param):
    if param=='os_family':
      return 'Debian'
    if param=='os_name':
      return 'Debian'
    if param=='os':
      return 'Debian'
    if param=='osrelease':
      return 'Debian'
    if param=='osarch':
      return 'amd64'
  class AnsibleModuleFake:
    def __init__(self):
      self.params = {
        'state': 'present',
        'repo': 'ppa:ubuntu-wine/ppa',
      }
      self.check_mode = False
      self._diff = False
    def fail_json(self, msg):
      raise Exception(msg)
   

# Generated at 2022-06-23 03:14:06.097779
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class Module(object):
        def __init__(self):
            self.atomic_move = False
            self.set_mode_if_different = False
        def fail_json(self, msg):
            pass

    class SourcesList(SourcesList):
        def __init__(self, module):
            self.module = module
            self.files = {}
            self.files['test.list'] = [(0, True, True, 'deb http://test.list.file', 'Comment'),
                                       (1, True, True, 'deb http://test.list.file/something.else', 'Comment')]

    sourcesList = SourcesList(Module())

# Generated at 2022-06-23 03:14:15.778601
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    s = '''deb http://archive.ubuntu.com/ubuntu trusty-security main restricted
deb-src http://archive.ubuntu.com/ubuntu trusty-security restricted main universe multiverse # comment
# deb-src http://archive.ubuntu.com/ubuntu trusty-security restricted main universe multiverse
deb http://archive.ubuntu.com/ubuntu trusty-security restricted universe multiverse
'''
    sl = SourcesList(None)
    file = '/tmp/filename'
    sl.files[file] = []
    for n, line in enumerate(s.split('\n')):
        valid, enabled, source, comment = sl._parse(line)
        sl.files[file].append((n, valid, enabled, source, comment))

    # Modify comment
    sl.modify(file, 0, comment='test')
    assert sl.files

# Generated at 2022-06-23 03:14:25.453186
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    s = SourcesList(None)
    # Test 1
    s.files = {
        'somefile': [
            (0, False, False, 'deb http://www.example.com/ someapp', 'comment'),
            None,
            (2, True, True, 'deb http://www.example.com/ someapp', '')
        ]
    }
    it = iter(s)
    result = [('somefile', 2, True, 'deb http://www.example.com/ someapp', '')]
    assert list(it) == result



# Generated at 2022-06-23 03:14:33.377768
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    lines = []
    for filename, n, enabled, source, comment in sl:
        contents = {}
        contents['filename'] = filename
        contents['number'] = n
        contents['enabled'] = enabled
        contents['source'] = source
        contents['comment'] = comment
        lines.append(contents)
    print(lines)
    module.exit_json(changed=False)


# Generated at 2022-06-23 03:14:43.990870
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    _module = MagicMock()
    _module.params = dict()
    _module.params['codename'] = 'codename'
    _module.params['filename'] = 'filename'

    s = UbuntuSourcesList(_module)

# Generated at 2022-06-23 03:14:45.278901
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    assert 0


# Generated at 2022-06-23 03:14:57.457196
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    path = __file__
    dirname = os.path.dirname(path)
    filename = os.path.join(dirname, '..', 'files', 'aptsources.list')
    sourceslist = SourcesList(AnsibleModule(argument_spec={}))
    sourceslist.load(filename)

# Generated at 2022-06-23 03:15:04.639176
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import unittest
    import os
    import tempfile

    class TestSourcesListLoad(unittest.TestCase):
        def setUp(self):
            self.tmp_path = tempfile.mkdtemp()
            apt_pkg_dir_etc = os.path.join(self.tmp_path, 'etc')
            os.makedirs(apt_pkg_dir_etc)
            os.makedirs(os.path.join(apt_pkg_dir_etc, 'apt'))
            os.makedirs(os.path.join(apt_pkg_dir_etc, 'apt', 'sources.list.d'))
            apt_pkg_dir_etc_apt = os.path.join(apt_pkg_dir_etc, 'apt')

# Generated at 2022-06-23 03:15:09.395911
# Unit test for function main
def test_main():
    from ansible.module_utils.apt.sources_list import main
    # We either succeed or fail, but nothing else
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:10.690711
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert True



# Generated at 2022-06-23 03:15:22.923059
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    mod = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['absent', 'present']),
        repo=dict(required=True),
        filename=dict(default=None),
        update_cache=dict(default=False, type='bool'),
        cache_valid_time=dict(default=0, type='int'),
        validate_certs=dict(default=True, type='bool'),
        keyserver=dict(default='keyserver.ubuntu.com', aliases=['key_server']),
        key_id=dict(default=None, aliases=['key']),
        mode=dict(default=None, type='raw'),
        install_python_apt=dict(default=True, type='bool')))
    fd, temppath = tempfile.mkstemp()

# Generated at 2022-06-23 03:15:28.049416
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList(AnsibleModule(argument_spec={}))
    sl.load(os.path.join(os.path.dirname(__file__), 'files', 'sources.list'))
    return (data for filename, data in sl.files.items() if filename == '/etc/apt/sources.list')



# Generated at 2022-06-23 03:15:36.988469
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    fake_module = object()
    sl = SourcesList(fake_module)
    lines = ['deb http://deb.debian.org/debian wheezy main', '# deb http://deb.debian.org/debian wheezy-updates main']

    for l in lines:
        sl.add_source(l)
    assert len(sl.files) == 1
    assert len(sl.files[sl.default_file]) == 2
    assert sl.files[sl.default_file][0] == (0, True, True, 'deb http://deb.debian.org/debian wheezy main', '')
    assert sl.files[sl.default_file][1] == (1, True, True, 'deb http://deb.debian.org/debian wheezy-updates main', '')



# Generated at 2022-06-23 03:15:39.367235
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except InvalidSource:
        e = sys.exc_info()[1]
        assert isinstance(e, InvalidSource)



# Generated at 2022-06-23 03:15:49.022845
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module_args = dict(
        repo='deb http://http.debian.net/debian jessie-backports main contrib non-free',
        filename='debian-backports.list',
        state='present',
    )

    old = copy.deepcopy(sys.argv)
    sys.argv = [sys.argv[0]]
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)
    sys.argv = old

    apt_sources = SourcesList(module)
    apt_sources.add_source(module.params['repo'], file=module.params['filename'])

    dump = apt_sources.dump()
    assert(module_args['filename'] in dump)

# Generated at 2022-06-23 03:15:59.684599
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sl = SourcesList(module)
    sl.files = {'dir1/dir11/dir111.list':[(0, True, True, 'deb http://user:password@host:port/path distro component1', '# Comment')],
                'dir1/dir12.list':[(0, True, True, 'deb http://user:password@host:port/path distro component2', '# Comment')],
                'dir1/dir13.list':[(0, True, True, 'deb http://user:password@host:port/path distro component3', '# Comment')],
                'dir2.list':[(0, True, True, 'deb http://user:password@host:port/path distro component4', '# Comment')]}
    sl.save()

# Generated at 2022-06-23 03:16:02.778549
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = Mock(params={}, name="module")
    s = UbuntuSourcesList(module)
    assert isinstance(deepcopy(s), UbuntuSourcesList)



# Generated at 2022-06-23 03:16:14.164597
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    import tempfile

    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **arguments: None
    file = tempfile.NamedTemporaryFile(delete=False)