

# Generated at 2022-06-23 03:06:10.766477
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {}
    sources_after = {'a': 'b', 'd': 'e'}
    sourceslist_before = {}
    assert revert_sources_list(sources_before, sources_after, sourceslist_before) is None



# Generated at 2022-06-23 03:06:13.119712
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert len(sources.files) >= 1



# Generated at 2022-06-23 03:06:19.622439
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module_args = dict(
        repo='deb http://archive.canonical.com/ubuntu hardy partner',
        state='present')

    module = AnsibleModule(argument_spec={})
    module.params.update(module_args)

    sources_list = SourcesList(module)
    assert sources_list.dump() == {}



# Generated at 2022-06-23 03:06:22.988082
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({"setup": {"apt-get update"}})
    sl = SourcesList(module)
    assert sl.files
    assert not sl.new_repos



# Generated at 2022-06-23 03:06:31.028941
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import copy
    import tempfile

    module = AnsibleModule(argument_spec=dict(
        mode=dict(default=0o644, type='raw'),
    ))

    class SourcesList(object):
        def __init__(self):
            self.files = {}

        def load(self, file):
            pass

    class Module(object):
        def __init__(self):
            self.check_mode = False
            self.params = dict()

        def fail_json(self, **kwargs):
            raise RuntimeError('Call to fail_json!')

        def atomic_move(self, src, dst):
            pass

        def set_mode_if_different(self, path, mode, changed):
            pass

        def get_bin_path(self, binary):
            pass


# Generated at 2022-06-23 03:06:34.990819
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)



# Generated at 2022-06-23 03:06:40.214209
# Unit test for function main

# Generated at 2022-06-23 03:06:50.837910
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    def _remove_source(sources, source_line, expected):
        sl = SourcesList()
        sl.files = copy.deepcopy(sources)
        sl.remove_source(source_line)
        assert sl.dump() == expected


# Generated at 2022-06-23 03:06:58.006016
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class DummyModule(object):
        class DummyParams(object):
            codename = 'precise'
        params = DummyParams()

    class DummyParams(object):
        codename = 'precise'
    dummy_module = UbuntuSourcesList(DummyModule())
    assert id(dummy_module.codename) == id(dummy_module.__deepcopy__().codename)


# Generated at 2022-06-23 03:07:07.697210
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    import copy
    # Create instance of class with arguments that we need for testing
    UbuntuSourcesList_instance = UbuntuSourcesList(None, None)
    # Store instance class name for testing if it gets deepcopied
    class_name = UbuntuSourcesList_instance.__class__.__name__
    # Create deepcopy of instance
    UbuntuSourcesList_instance_copy = copy.deepcopy(UbuntuSourcesList_instance)
    # Test if the class names are equal - should be equal
    class_names_equal = (UbuntuSourcesList_instance.__class__.__name__ == UbuntuSourcesList_instance_copy.__class__.__name__)
    # Test if the instances are not the same - should be not the same
    instances_not_equal = (UbuntuSourcesList_instance != UbuntuSourcesList_instance_copy)
    # Test if the instances

# Generated at 2022-06-23 03:07:14.061295
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})

    apt_pkg_name = 'python-apt'
    apt_get_path = module.get_bin_path('apt-get')
    rc, so, se = module.run_command([apt_get_path, 'update'])

    assert rc == 0
    rc, so, se = module.run_command([apt_get_path, 'install', apt_pkg_name, '-y', '-q'])
    assert rc == 0

# Unit tests for function apt_pkg_name

# Generated at 2022-06-23 03:07:18.262735
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    assert len(sl.files) == 0

    sl.add_source('deb http://example.com/debian wheezy main', 'Example')
    assert len(sl.files) == 1
    assert os.path.basename(list(sl.files)[0]) == 'example.com_debian.list'
    assert len(sl.files['example.com_debian.list']) == 1
    assert sl.files['example.com_debian.list'][0][1:] == (True, True, 'deb http://example.com/debian wheezy main', 'Example')

    sl.add_source('deb http://example.com/debian wheezy main', 'Example', file='test.list')
    assert len(sl.files) == 2

# Generated at 2022-06-23 03:07:27.539802
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.ansible.community.plugins.module_utils.tests.test_module_utils.test_distro.mocks_ansible_module import MockAnsibleModule

    def _add_ppa_signing_keys_callback(command):
        pass

    module = MockAnsibleModule()
    sources_list = UbuntuSourcesList(module, _add_ppa_signing_keys_callback)

# Generated at 2022-06-23 03:07:39.179327
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    lines = [
        '# deb http://http.kali.org/kali kali-rolling main contrib non-free',
        'deb http://repo.mysql.com/apt/debian/ stretch mysql-5.7',
        'deb [arch=amd64] http://packages.microsoft.com/repos/vscode stable main',
    ]

    sl = SourcesList(None)

    sl.load(None)

    for line in lines:
        valid, enabled, source, comment = sl._parse(line)
        sl.files[None].append((len(sl.files[None]), valid, enabled, source, comment))

    assert sl.dump() == {None: ''.join(lines)}

    # try to modify valid string
    sl.modify(None, 1, False, None, 'This string was modified')


# Generated at 2022-06-23 03:07:47.455096
# Unit test for method __iter__ of class SourcesList

# Generated at 2022-06-23 03:07:51.495221
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    pass


# Generated at 2022-06-23 03:08:03.781303
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)

    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files
    assert '/etc/apt/sources.list' in sources.files
    assert '/etc/apt/sources.list.d/ansible-test.list' in sources.files
    assert '/etc/apt/sources.list.d/ansible-test.disabled.list' in sources.files
    assert 'not_existing.list' in sources.files


# Generated at 2022-06-23 03:08:13.037689
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    from ansible.module_utils.six import StringIO

    class FakeModule:
        class FakeParams:
            def __init__(self):
                self.atomic_move = 'a'
                self.set_mode_if_different = 'b'
        def __init__(self):
            self.params = self.FakeParams()
        def fail_json(self, msg):
            print(msg)

    module = FakeModule()

    file = 'somefile'
    n = 0
    sl = SourcesList(module)
    sl.files[file] = [(n, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main', '')]

    # set parameter source to None (we will use original source)
    source = None
    sl.modify(file, n, source=source)
   

# Generated at 2022-06-23 03:08:19.940821
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import json
    from .mock.mock_module import MockModule
    from .mock.mock_ansible_module import MockAnsibleModule

    mock_module = MockModule()

    def get_ansible_module():
        return MockAnsibleModule(sources_path='tests/unit/fixtures/sources/',
                                 sources_content='tests/unit/fixtures/sources/content/',
                                 sources_expected_content='tests/unit/fixtures/sources/expected_content/')


# Generated at 2022-06-23 03:08:33.488196
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={'repo': {'required': True, 'type': 'str'},
                                           'filename': {'type': 'str'}})
    sl = SourcesList(module)

    sl._add_valid_source('deb http://archive.canonical.com/ubuntu hardy partner',
                         'comment',
                         file='/tmp/sources.list.d/file.list')
    assert sl.dump() == {'/tmp/sources.list.d/file.list': 'deb http://archive.canonical.com/ubuntu hardy partner # comment\n'}

    sl = SourcesList(module)


# Generated at 2022-06-23 03:08:41.533722
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Dummy object for testing
    module = type('DummyModule', (object,), {'fail_json': lambda self, msg: None})
    # Stubbing __init__ to avoid calling 'apt_pkg.init_system()' from real __init__
    # which is not compatible with Python 2.5
    old___init__ = UbuntuSourcesList.__init__
    UbuntuSourcesList.__init__ = lambda self: None
    try:
        obj = UbuntuSourcesList(module)
    finally:
        # Clean up
        UbuntuSourcesList.__init__ = old___init__

    copy = copy.deepcopy(obj)
    assert type(obj) == type(copy)
    assert obj.codename == copy.codename


# Generated at 2022-06-23 03:08:51.685756
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    #Setup
    module = AnsibleModule('test')
    sources = SourcesList(module)
    sources.load('/tmp/test_SourcesList')
    sources._add_valid_source("deb example.com test", '', None)

    #Run
    line = ["deb example.com test\n"]
    line_input = ["deb example.com test\n"]
    for i in range(len(line)):
        return_value = sources.remove_source(line_input[i])

    #Assert
    assert not return_value


# Generated at 2022-06-23 03:09:04.681088
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.files['test_file'] = [(1, True, True, 'source1', 'comment1'),
                             (2, True, True, 'source1', 'comment2'),
                             (3, True, True, 'source2', 'comment3'),
                             (4, True, True, 'source3', 'comment4'),
                             (5, True, True, 'source4', 'comment5'),
                             ]
    source = 'modified source'
    comment = 'modified comment'
    for n, enabled, source_old, comment_old in sl.files['test_file']:
        sl.modify('test_file', n, source=source, comment=comment)

# Generated at 2022-06-23 03:09:15.372238
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Test for unit method remove_source of class SourcesList.
    """
    x = SourcesList(12)
    x.files = {'test': [(0, True, True, 'deb http://test.com/test xenial main', 'testcomment'),
                        (1, True, True, 'deb-src http://test.com/test xenial main', ''),
                        (2, True, False, 'deb-src http://test.com/test xenial main', '')]
                }
    x._remove_valid_source('deb http://test.com/test xenial main')

# Generated at 2022-06-23 03:09:18.635462
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    assert_equal(UbuntuSourcesList(module).remove_source('ppa:foo'), None)
    assert_equal(UbuntuSourcesList(module).remove_source('ppa:foo/bar'), None)


# Generated at 2022-06-23 03:09:27.698602
# Unit test for function main
def test_main():
    delete_file = True

# Generated at 2022-06-23 03:09:35.110471
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    (sourceslist, module, add_ppa_signing_keys_callback) = init_unit_test()
    ubuntu_sourceslist = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    ubuntu_sourceslist.__deepcopy__()
    assert ubuntu_sourceslist.module is not None
    assert ubuntu_sourceslist.add_ppa_signing_keys_callback is not None


# Generated at 2022-06-23 03:09:43.347102
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    test_module = AnsibleModule({})
    test_module.add_argument_spec({})
    test_module.params = {}
    test_list = SourcesList(test_module)
    test_list._apt_cfg_dir = lambda x: '.'
    test_list._apt_cfg_file = lambda x: 'test_file'
    test_list.default_file = 'test_file'
    test_list.load('test_file')
    test_list.modify('test_file', 0, enabled=False, source='test_source', comment='test_comment')
    assert test_list.files['test_file'][0] == (0, True, False, 'test_source', 'test_comment'), 'test_SourcesList_modify() failed.'


# Generated at 2022-06-23 03:09:49.644740
# Unit test for function main

# Generated at 2022-06-23 03:09:56.656213
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'file_before': 'content_in_before'}
    sources_after = {'file_after': 'content_in_after'}
    class sourceslist_before:
        def save(self):
            pass
    try:
        revert_sources_list(sources_before, sources_after, sourceslist_before)
    except Exception as e:
        raise AssertionError('Unexpected exception raised: %s' % e)



# Generated at 2022-06-23 03:10:01.997657
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        system(
            '{0} -m ansible_collections.ansible.community.plugins.modules.testing.misc.apt_repository '
            '-a "repo=ppa:ansible/ansible state=present"'.format(sys.executable))

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:13.888514
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec=dict())
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'

    def _add_ppa_signing_keys_callback(command):
        assert command == ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '65FFB764143522BE8C4FBFAFA20CF5F3B30F6B3D']

    sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=_add_ppa_signing_keys_callback)

# Generated at 2022-06-23 03:10:23.852878
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    Test SourcesList.add_source()
    '''
    module = AnsibleModule(argument_spec={})
    # Set sources to some default value as default_file is empty by default
    sl = SourcesList(module)

# Generated at 2022-06-23 03:10:34.325654
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class AddPPAKeyCallback(object):
        def __init__(self):
            self.keys = []

        def __call__(self, command):
            self.keys.append(command)

    class FetchUrlCallback(object):
        def __init__(self):
            self.urls = []
            self.responses = []

        def __call__(self, module, url, headers=None):
            self.urls.append(url)
            status = 200
            response = {
                'content-type': 'application/json'
            }
            if self.responses:
                status = self.responses[0]['status']
                response = self.responses[0]['response']
                self.responses = self.responses[1:]

# Generated at 2022-06-23 03:10:36.631729
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    obj = UbuntuSourcesList(None)
    copy.copy(obj)
    copy.deepcopy(obj)

# Generated at 2022-06-23 03:10:46.274851
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = Mock()
    sources_before = {'/etc/apt/sources.list.d/filename1.list': 'src1\nsrc2'}
    sources_after = {'/etc/apt/sources.list.d/filename1.list': 'src1\nsrc2\nsrc3'}
    class sources_list:
        def save(self):
            pass
    sourceslist_before = sources_list()
    srcs = SourcesList(module)
    srcs.sources_list_files = sourceslist_before
    assert len(module._method_calls) == 0
    revert_sources_list(sources_before, sources_after, srcs)

# Generated at 2022-06-23 03:10:48.907446
# Unit test for function install_python_apt
def test_install_python_apt():
    module_meta = dict(
        check_mode=False,
        get_bin_path=lambda x: '/usr/bin/apt-get'
    )
    module = AnsibleModule(**module_meta)
    for what in ('apt', 'apt_pkg'):
        module.run_command = MagicMock(name='run_command')
        install_python_apt(module, what)



# Generated at 2022-06-23 03:10:59.550489
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Test the remove_source method of the SourcesList class
    """

    # Test line contains comment as # at end
    line = "deb http://archive.ubuntu.com/ubuntu xenial main # Some Remark"
    sources_list = SourcesList(AnsibleModule(argument_spec={}))
    sources_list.load('test_1')
    sources_list.add_source(line)
    sources_list.remove_source(line)
    assert not [x for x in sources_list]

    # Test line contains comment as # in begining
    line = "#deb http://archive.ubuntu.com/ubuntu xenial main"
    sources_list = SourcesList(AnsibleModule(argument_spec={}))
    sources_list.load('test_2')
    sources_list.add_source(line)
    sources

# Generated at 2022-06-23 03:11:08.538388
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    from ansible.module_utils.six.moves import StringIO

    module = AnsibleModule(argument_spec={})
    apt_src = SourcesList(module)
    output_1 = """
deb [arch=i386] http://archive.ubuntu.com/ubuntu/ xenial main restricted
deb-src http://archive.ubuntu.com/ubuntu/ xenial universe
deb-src http://archive.ubuntu.com/ubuntu/ xenial multiverse
deb http://old-releases.ubuntu.com/ubuntu/ raring main restricted universe multiverse
deb-src http://old-releases.ubuntu.com/ubuntu/ raring-security main restricted universe multiverse
"""

# Generated at 2022-06-23 03:11:21.161393
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Initialize and define test object
    module_obj = None
    ubuntu_sources_list_obj = UbuntuSourcesList(module_obj)

    # Copy existing class method
    def _remove_valid_source_bak(source):
        return UbuntuSourcesList._remove_valid_source(ubuntu_sources_list_obj, source)

    # Monkey patch the class method
    def _remove_valid_source_fake_s(s, _remove_valid_source_bak=_remove_valid_source_bak, ubuntu_sources_list_obj=ubuntu_sources_list_obj):
        for filename, n, enabled, src, comment in ubuntu_sources_list_obj:
            if source == src and enabled:
                ubuntu_sources_list_obj.files[filename].pop(n)

    Ubuntu

# Generated at 2022-06-23 03:11:28.992460
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import tempfile

    def _create_file(filename):
        fd, tmp_path = tempfile.mkstemp(prefix='.%s' % filename, dir=d)
        f = os.fdopen(fd, 'w')

# Generated at 2022-06-23 03:11:34.541154
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    install_python_apt(module, 'python3-apt')
    assert module.run_command.call_count == 2
# end of unit test



# Generated at 2022-06-23 03:11:44.056192
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sourceslist_size_before = os.stat(UBUNTU_SOURCES_LIST_FILE).st_size
    sources_before = UbuntuSourcesList(dict()).dump()
    sources_after = dict()
    for i in range(1, 41):
        sources_after[UBUNTU_SOURCES_LIST_FILE] = ('deb http://fakesite.com/ubuntu %s main' % i)
        sourceslist_size_after = os.stat(UBUNTU_SOURCES_LIST_FILE).st_size
        assert sourceslist_size_before != sourceslist_size_after
        sourceslist_before = UbuntuSourcesList(dict())
        revert_sources_list(sources_before, sources_after, sourceslist_before)

# Generated at 2022-06-23 03:11:50.242167
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    old_instance = UbuntuSourcesList(None)
    new_instance1 = deepcopy(old_instance)
    new_instance2 = deepcopy(new_instance1)
    new_instance3 = deepcopy(old_instance)

    assert new_instance1 == new_instance2
    assert new_instance1 != new_instance3
    assert new_instance2 != new_instance3


# Generated at 2022-06-23 03:11:52.569305
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Invalid source string")
    except InvalidSource as err:
        assert str(err) == "Invalid source string"


# Generated at 2022-06-23 03:12:01.704064
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from .mock import MagicMock

    module = MagicMock(check_mode=False)
    module.atomic_move = None
    module.set_mode_if_different = None

    sources_before = {
        '/etc/apt/sources.list.d/puppet_puppetlabs-pc1.list': 'deb http://apt.puppetlabs.com pc1 main',
        '/etc/apt/sources.list.d/puppet_puppetlabs-pc2.list': 'deb http://apt.puppetlabs.com pc2 main',
    }


# Generated at 2022-06-23 03:12:11.757463
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={
        'filename': dict(required=False, type='str'),
    })
    # Test that new files are deleted and existing files are reverted
    UbuntuSourcesList(module, add_ppa_signing_keys_callback=None).load('/etc/apt/sources.list.d/ansible_test_revert.list')
    sources_before = {'file1': 'source1'}
    sources_after = sources_before.copy()
    sources_after['file1'] = 'source1'
    sources_after['file2'] = 'source2'
    sourceslist_before = SourcesList(module)
    sourceslist_before.files['file1'] = ['source1']
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    #

# Generated at 2022-06-23 03:12:13.133422
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    assert True


# Generated at 2022-06-23 03:12:23.637876
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class MockModule(object):
        def __init__(self):
            self.params = {'filename': 'test-filename.list'}
            self.fail_json = self._fail_json
            self.check_mode = False
            self.called = False

        def _fail_json(self, **kwargs):
            self.called = True
            raise Exception(kwargs)

        def set_mode_if_different(self, name, mode, changed):
            pass

    class MockFilesystem:
        def __init__(self):
            self.files = {}
            self.fail_json = False

        def atomic_move(self, source, destination):
            self.files[destination] = self.files[source]

        def isdir(self, path):
            return path in self.files


# Generated at 2022-06-23 03:12:27.107454
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # There is no way to unit-test this method properly.
    # We don't know what content _apt_cfg_file() and _apt_cfg_dir() return.
    # So we just try to use them to check that they don't raise exceptions
    # and change behaviour during a test run.
    SourcesList(None).save()



# Generated at 2022-06-23 03:12:37.751433
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    def test_fixture(filename):
        module = DummyModule()
        sources = SourcesList(module)
        sources.load(filename)
        return sources, module


# Generated at 2022-06-23 03:12:40.647844
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    resources = SourcesList(module)
    assert resources.default_file == '/etc/apt/sources.list'


# Generated at 2022-06-23 03:12:49.182841
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    sourcelist = UbuntuSourcesList(module)
    line_exists = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    line_not_exists = 'deb http://ppa.launchpad.net/elliptic-curve/elliptic-curve/ubuntu xenial main'
    sourcelist.add_source('ppa:elliptic-curve/elliptic-curve')
    sourcelist.remove_source('ppa:elliptic-curve/elliptic-curve')
    assert line_exists in sourcelist.repos_urls
    assert line_not_exists not in sourcelist.repos_urls


# Generated at 2022-06-23 03:12:53.091923
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
  sourcesList = SourcesList(module)
  for i in sourcesList.__iter__():
    print(i)


# Generated at 2022-06-23 03:12:58.739858
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('msg', 'data')
    assert exc.msg == 'msg'
    assert exc.data == 'data'
    assert str(exc) == 'msg: data'



# Generated at 2022-06-23 03:13:09.951793
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # add_source() of UbuntuSourcesList is called as a method of an instance of UbuntuSourcesList.
    # The instance of UbuntuSourcesList is created when a new UbuntuSourcesList object is created.
    # Here is a stub for UbuntuSourcesList.__init__().
    # It only works because the code after UbuntuSourcesList.__init__() does not call the UbuntuSourcesList constructor
    # before calling UbuntuSourcesList.add_source().
    method_add_source_is_called = False
    class StubUbuntuSourcesList:
        # This method is called as a method of an instance of StubUbuntuSourcesList.
        def add_source(self, line, comment='', file=None):
            # Check some of the arguments.
            # Check that line is "ppa:user/ppa-name".
            assert 'ppa:' in line
            assert '/' in line

# Generated at 2022-06-23 03:13:13.077744
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    """Unit test for class InvalidSource. Raises InvalidSource with a message, and
    checks that the message is accessible"""
    try:
        raise InvalidSource("Invalid source string")
        assert False
    except InvalidSource as e:
        assert e.message == "Invalid source string"


# Generated at 2022-06-23 03:13:22.773930
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources = [
        "deb-src http://archive.canonical.com/ubuntu trusty partner",
        "deb http://archive.canonical.com/ubuntu trusty partner",
        "deb http://archive.canonical.com/ubuntu trusty partner",
        "deb http://archive.ubuntu.com/ubuntu/ artful main restricted universe multiverse",
    ]
    for source in sources:
        sources_list.add_source(source)
    dumpstruct = sources_list.dump()
    for filename, sources in dumpstruct.items():
        assert filename in ["/etc/apt/sources.list", "/etc/apt/sources.list.d/trusty.list"]

# Generated at 2022-06-23 03:13:35.702340
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-23 03:13:39.512676
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("invalid source")
    except InvalidSource as exc:
        assert str(exc) == "invalid source"



# Generated at 2022-06-23 03:13:47.505574
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils import apt_pkg
    apt_pkg.parse_config = parse_config

    from collections import Mapping
    from copy import deepcopy

    # create a module object
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # create a UbuntuSourcesList object
    expected_result = UbuntuSourcesList(module)

    # deepcopy this object
    result = deepcopy(expected_result)

    # compare the expected and actual UbuntuSourcesList objects
    assert type(result) == type(expected_result)
    assert isinstance(result, UbuntuSourcesList)
    assert isinstance(result, SourcesList)
    assert isinstance(result, Mapping)



# Generated at 2022-06-23 03:13:56.870884
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:14:07.402271
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    global module
    module = AnsibleModule({'update_cache': False}, bypass_checks=True)
    sl = UbuntuSourcesList(module)
    assert ('/etc/apt/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu xenial main restricted', '') in sl
    assert ('/etc/apt/sources.list', 1, True, 'deb http://archive.ubuntu.com/ubuntu xenial-updates main restricted', '') in sl
    assert ('/etc/apt/sources.list', 2, True, 'deb http://archive.ubuntu.com/ubuntu xenial universe', '') in sl
    assert ('/etc/apt/sources.list', 3, True, 'deb http://archive.ubuntu.com/ubuntu xenial-updates universe', '') in sl

# Generated at 2022-06-23 03:14:17.626791
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)


# Generated at 2022-06-23 03:14:29.558866
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class DummyModule(object):
        def __init__(self):
            self._fetched_urls = []
            self.params = {'filename': None, 'codename': None}

        def fail_json(self, msg):
            raise AssertionError(msg)

        def run_command(self, cmd, check_rc=False):
            # mock
            return 0, cmd, ''

        def atomic_move(self, tmp, path):
            pass

        def set_mode_if_different(self, path, mode, changed=False):
            # mock
            pass

    def fetch_url(*args, **kwargs):
        # mock
        return None, None

    UbuntuSourcesList.fetch_url = fetch_url
    module = DummyModule()
    sources_list = UbuntuSourcesList(module)

    #

# Generated at 2022-06-23 03:14:32.667948
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('foo')
    except Exception as e:
        assert e.args[0] == 'foo'



# Generated at 2022-06-23 03:14:33.579695
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert 'sourceslist'



# Generated at 2022-06-23 03:14:40.828923
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = type("module", (),  {})
    object_under_test = SourcesList(module)
    line = 'deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic test'
    object_under_test.add_source(line, file='test.list')
    object_under_test.remove_source(line)
    # assert
    import json
    assert json.loads("""{"/root/test.list": ""}""") == object_under_test.dump()



# Generated at 2022-06-23 03:14:53.371142
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    obj = SourcesList(AnsibleModule(argument_spec={}))
    obj.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    obj.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    obj.add_source('deb http://packages.dotdeb.org jessie all')
    obj.add_source('deb-src http://packages.dotdeb.org jessie all')
    obj.add_source('deb http://packages.dotdeb.org jessie all')
    obj.add_source('deb http://packages.dotdeb.org jessie all deb')
    obj.add_source('deb-src http://packages.dotdeb.org jessie all deb')

    obj.dump()
    equal(len(obj.files), 3)

# Generated at 2022-06-23 03:15:06.011635
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({'_ansible_check_mode': False})
    sources = SourcesList(module)
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from io import BytesIO as StringIO

    sources._parse = lambda x, y: x
    f = StringIO("deb http://ubuntu.com/debian-stable stable\ndeb-src http://ubuntu.com/debian-stable stable\ndeb http://ubuntu.com/debian-stable-old stable-old")
    sources.files = {None: f.readlines()}
    sources.modify(None, 0, comment="Modified comment")
    # We're comparing to original line, because we don't want to pull Python3 migration hacks for tests

# Generated at 2022-06-23 03:15:10.252838
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    a = SourcesList()
    a.files = {'/etc/apt/sources.list': [('/etc/apt/sources.list', 0, False, 'deb http://ftp.debian.org/debian/ jessie main', ' # comment')]}
    a.save()



# Generated at 2022-06-23 03:15:21.307937
# Unit test for function main
def test_main():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, Mock
    from ansible_collections.community.general.plugins.modules import apt_repository

    class TestAptRepository(unittest.TestCase):

        def setUp(self):
            self.module = apt_repository.AnsibleModule({'repo': 'ansible/ansible'})
            self.module.check_mode = True
            self.module._diff = True
            self.module.run_command = Mock(return_value=(0, '', ''))

        # Repository already exists

# Generated at 2022-06-23 03:15:32.117036
# Unit test for function install_python_apt
def test_install_python_apt():
    class FakeModule(object):
        def __init__(self):
            self.params = {'install_python_apt': True}

        def fail_json(self, msg):
            raise ValueError(msg)

        def get_bin_path(self, executable):
            if executable == 'apt-get':
                return '/bin/apt-get'
            else:
                return None

        def run_command(self, cmd):
            return (1, 'stdout', 'stderr')
    try:
        install_python_apt(FakeModule(), 'python3-apt')
        assert False, 'should fail'
    except ValueError as e:
        assert e.args[0] == "python3-apt must be installed to use check mode"


# Generated at 2022-06-23 03:15:34.323530
# Unit test for function install_python_apt
def test_install_python_apt():
    '''
    Mock the test above by not running it
    '''
    pass



# Generated at 2022-06-23 03:15:44.980373
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest
    import tempfile

    class testUbuntuSourcesListClass(unittest.TestCase):
        def setUp(self):
            self.filename = tempfile.mktemp()
            with open(self.filename, 'w') as f:
                f.write(SOURCES_LIST_AFTER_REMOVE_FOO)

        def tearDown(self):
            os.remove(self.filename)

        def test_add_source(self):
            from ansible.module_utils.six import PY2
            from ansible.module_utils.basic import AnsibleModule
            if PY2:
                from StringIO import StringIO
            else:
                from io import StringIO


# Generated at 2022-06-23 03:15:56.669088
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    s = apt_get.UbuntuSourcesList()
    with open('/tmp/sources.list', 'w') as f:
        f.write('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main\n')
        f.write('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main\n')
        f.write('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main\n')
    s.load('/tmp/sources.list')
    assert len(s.files['/tmp/sources.list']) == 3
    assert len(s.repos_urls) == 3
    s.remove_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')

# Generated at 2022-06-23 03:16:06.227070
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import mock
    import shutil
    import tempfile

    class _SourcesList(SourcesList):
        def __init__(self):
            class _Module(object):
                def __init__(self):
                    self.params = {
                        'state': 'present',
                        'repo': 'ppa:nginx/stable',
                        'filename': None,
                        'update_cache': True,
                        'cache_valid_time': 0,
                        'mode': DEFAULT_SOURCES_PERM,
                    }

                def get_bin_path(self, arg):
                    pass

                def fail_json(self, msg):
                    raise Exception(msg)

                def get_bin_path(self, arg, *args, **kwargs):
                    return None

                def atomic_move(self, src, dst):
                    shutil