

# Generated at 2022-06-23 03:06:06.691324
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    UbuntuSourcesList(AddonModule(argument_spec={}, check_invalid_arguments=False, bypass_checks=True))


# Generated at 2022-06-23 03:06:17.625378
# Unit test for function install_python_apt
def test_install_python_apt():

    # get the current apt version
    apt_apt_version = apt_pkg.__version__

    # initiate the module with check_mode set to true
    module = AnsibleModule(
        check_mode=True,
        argument_spec=dict(
            install_python_apt=dict(
                type='bool',
                default=True
            )
        )
    )

    # save the current state of HAVE_PYTHON_APT
    have_python_apt_before = HAVE_PYTHON_APT

    # Call the function with ansible python packages
    # The function should not raise an exception
    install_python_apt(module, 'python-apt')
    HAVE_PYTHON_APT = True
    install_python_apt(module, 'python3-apt')

    # Set HAVE_PYTH

# Generated at 2022-06-23 03:06:26.301617
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = Mock()
    ubuntusourceslist = UbuntuSourcesList(module)
    ubuntusourceslist.files = {'sources.list.d/debian.list': [
        (0, True, False, 'deb http://deb.debian.org/debian/ buster main', '# main\n'),
        (1, True, False, '# deb http://deb.debian.org/debian/ buster main', '# main\n'),
        (2, True, False, '# deb http://deb.debian.org/debian/ buster main', '# main\n'),
        (3, True, True, 'deb http://deb.debian.org/debian/ buster main', '# main\n'),
    ]}

# Generated at 2022-06-23 03:06:32.765770
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sources = SourcesList([])
    sources.add_source("""#deb http://ubuntu.mirror.cambrium.nl/ubuntu/ bionic main restricted universe multiverse""")
    sources.add_source("deb http://security.ubuntu.com/ubuntu bionic-security main restricted universe multiverse")
    assert sources.dump() == {'/etc/apt/sources.list': '\n'.join([
        '# deb http://ubuntu.mirror.cambrium.nl/ubuntu/ bionic main restricted universe multiverse\n',
        'deb http://security.ubuntu.com/ubuntu bionic-security main restricted universe multiverse\n'])}
    sources.add_source("deb http://ubuntu.mirror.cambrium.nl/ubuntu/ bionic-updates main restricted universe multiverse")

# Generated at 2022-06-23 03:06:45.390738
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # clean up test run files
    try:
        os.remove("/tmp/sources.list.d/test.list")
    except:
        pass

    try:
        os.remove("/tmp/test_fixture_sources.list")
    except:
        pass

    s = UbuntuSourcesList(
        dict(
            _ansible_remote_tmp="/tmp/",
            _ansible_tmp="/tmp/",
            _ansible_check_mode=False,
        )
    )

    s.add_source("deb http://example.com/ubuntu trusty main")
    s.add_source("deb http://example.com/ubuntu-updates trusty-updates main")
    s.add_source("deb http://example.com/ubuntu-backports trusty-backports main")
    s.add

# Generated at 2022-06-23 03:06:46.792281
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sl = SourcesList(module)


# Generated at 2022-06-23 03:06:53.056090
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    VALID_SOURCE_TYPES = ('deb', 'deb-src')
    for source in VALID_SOURCE_TYPES:
        sourceslist = SourcesList(AnsibleModule)
        source_line = '# %s %s %s' % (source, 'dummy_url', 'dummy_section')
        sourceslist.add_source(source_line)
        assert len(sourceslist.files) == 1
        sourceslist.remove_source(source_line)
        assert len(sourceslist.files) == 0



# Generated at 2022-06-23 03:07:02.540968
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    from shutil import rmtree
    from tempfile import mkdtemp
    from ansible.module_utils import basic

    class MockModule:
        def fail_json(*args, **kwargs):
            raise Exception('FAILURE: %s %s' % (args, kwargs))

        def atomic_move(self, src, dest):
            self.last_moved_file = src

    module = MockModule()
    tmpdir = mkdtemp()
    module.params = {'path': os.path.join(tmpdir, 'main.list')}
    src = SourcesList(module)

# Generated at 2022-06-23 03:07:02.963474
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    pass

# Generated at 2022-06-23 03:07:08.771083
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        '/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/test.list': 'deb http://test.test.test/test.deb trusty main\n'
    }

    sources_after = {
        '/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/test.list': 'deb http://test.test.test/test.deb trusty main\n',
        '/etc/apt/sources.list.d/test2.list': 'deb http://test2.test2.test/test.deb trusty main\n'
    }


# Generated at 2022-06-23 03:07:13.374724
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import copy

    module = Mock()
    module.params = dict(
        codename='xenial',
    )
    module.run_command.return_value = (0, '', '')

    sl = UbuntuSourcesList(module).__deepcopy__()
    sl.add_source('deb [arch=amd64] http://archive.ubuntu.com/ubuntu xenial main')
    assert sl.files['/etc/apt/sources.list.d/archive.ubuntu.com_ubuntu_xenial.list'] == [
        (0, True, True, 'deb [arch=amd64] http://archive.ubuntu.com/ubuntu xenial main', '')
    ]

    sl = UbuntuSourcesList(module).__deepcopy__()
    sl.add_source('ppa:ansible/ansible')

# Generated at 2022-06-23 03:07:24.204306
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from unittest import mock
    # check if not in check mode, call module.run_command
    module = mock.MagicMock()
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)
    assert callable(add_ppa_signing_key_callback), '_run_command should be callable'
    add_ppa_signing_key_callback(['echo,1'])
    module.run_command.assert_called_once_with(['echo,1'], check_rc=True)

    # check if in check mode, no callback
    module.check_mode = True
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)

# Generated at 2022-06-23 03:07:30.563748
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})

    file = '/non/existent/path/file.list'
    sl = SourcesList(module)
    sl._add_valid_source('deb http://archive.ubuntu.com/ubuntu xenial main', '# a comment', file=file)

    assert file in sl.files
    assert len(sl.files[file]) == 1
    assert sl.files[file][0][1:] == (True, True, 'deb http://archive.ubuntu.com/ubuntu xenial main', '# a comment')

# Generated at 2022-06-23 03:07:41.748605
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Instance of class SourcesList
    sl = SourcesList(AnsibleModule({}))

    # Valid sources

# Generated at 2022-06-23 03:07:45.298581
# Unit test for function main
def test_main():
    pass

# no unit tests for module import

# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:07:45.891457
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    assert True



# Generated at 2022-06-23 03:07:54.974934
# Unit test for function main

# Generated at 2022-06-23 03:08:06.614405
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    filename = '/tmp/sources.list'
    line_to_remove = 'deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted'
    existing_line = 'deb http://us.archive.ubuntu.com/ubuntu/ trusty-backports main restricted'

# Generated at 2022-06-23 03:08:14.990381
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = MagicMock()
    module.params.get.return_value = 'trusty'
    module.params.get.return_value = 'trusty'
    module.run_command.return_value = (0, '', '')
    module.check_mode.return_value = True
    module.fail_json.side_effect = FailJsonException('message')
    module.atomic_move.return_value = True
    module.set_mode_if_different.return_value = True
    module.fail_json.side_effect = FailJsonException('message')

    sources_list = UbuntuSourcesList(module)
    sources_list._add_valid_source = MagicMock()
    sources_list._suggest_filename = MagicMock()
    sources_list._parse = MagicMock()
    sources_list._

# Generated at 2022-06-23 03:08:28.043473
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    def make_configuration_for_test_with_modules(modules_list):
        class MockAptModule:
            def __init__(self):
                self.params = {'mode': DEFAULT_SOURCES_PERM}
                self.fail_json_called = False

            def fail_json(self, **kwargs):
                self.fail_json_called = True

            def set_mode_if_different(self, filename, mode, adjust_recursive):
                if not os.path.exists(filename):
                    assert False

            def atomic_move(self, tmp_path, filename):
                if not os.path.exists(tmp_path):
                    assert False
                if not os.path.exists(filename):
                    assert False


# Generated at 2022-06-23 03:08:32.234913
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockAddPpaSigningKeys:
        def __call__(self, command):
            pass
    m = UbuntuSourcesList(module, add_ppa_signing_keys_callback=MockAddPpaSigningKeys())
    x = copy.deepcopy(m)
    assert x == m


# Generated at 2022-06-23 03:08:42.005701
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import io

    class MockModule(object):
        class CheckModeFailure(Exception):
            pass

        def __init__(self, result):
            self._result = result

        def run_command(self, cmd, *args, **kwargs):
            if kwargs.get('check_rc'):
                if not self._result['command_rc']:
                    raise Exception("Fake error")
            return self._result['command_rc'], '\n'.join(self._result['command_stdout']), '\n'.join(self._result['command_stderr'])

        def fail_json(self, msg):
            raise Exception("Failed: %s" % msg)

        def atomic_move(self, src, dest):
            pass


# Generated at 2022-06-23 03:08:46.794754
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    list_ = SourcesList(module)
    list_.add_source('deb http://archive.ubuntu.com/ubuntu xenial main', 'ubuntu main')
    list_.save()


# Generated at 2022-06-23 03:08:59.373215
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import zipfile
    import tempfile
    import shutil
    module = AnsibleModule('apt_repository', 'url=http://apt.postgresql.org/pub/repos/apt/')
    sources_temp_dir = tempfile.mkdtemp()
    apt_sources_temp_dir = sources_temp_dir + '/etc/apt'
    apt_sources_parts_temp_dir = sources_temp_dir + '/etc/apt/sources.list.d'
    os.makedirs(apt_sources_parts_temp_dir)
    os.makedirs(apt_sources_temp_dir)
    module.params['filename'] = 'pgdg.list'
    module.params['state'] = 'present'
    SourcesList.apt_cfg_dir_old = SourcesList._apt_

# Generated at 2022-06-23 03:09:07.851882
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({}, check_invalid_arguments=False)

    sl = SourcesList(module)
    sl.add_source("deb http://archive.canonical.com/ubuntu trusty partner")
    sl.add_source("deb http://security.ubuntu.com/ubuntu precise-security main universe")

    dump = sl.dump()
    assert isinstance(dump, dict)
    assert len(dump) == 1
    assert dump['/etc/apt/sources.list'] == ("deb http://archive.canonical.com/ubuntu trusty partner\n"
                                             "deb http://security.ubuntu.com/ubuntu precise-security main universe\n")


# Generated at 2022-06-23 03:09:17.841066
# Unit test for constructor of class SourcesList
def test_SourcesList():
    passed = True

    # create temporary file
    f = open('/tmp/test-SourcesList.list', 'w+')
    f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.close()

    test = SourcesList(None)
    if test.files != {}:
        passed = False
    else:
        test.load('/tmp/test-SourcesList.list')
        if test.files != {'/tmp/test-SourcesList.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]}:
            passed = False

    # remove temporary file
    os.remove('/tmp/test-SourcesList.list')

    return passed



# Generated at 2022-06-23 03:09:27.149265
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sources_list = SourcesList()

    def test_set_source(new_source=None, new_comment=None, new_enabled=None,
                        old_source='deb http://archive.canonical.com/ubuntu hardy partner',
                        old_comment='#Comment', old_enabled=False):

        sources_list.files['test.list'] = [(1, True, old_enabled, old_source, old_comment)]
        sources_list.modify('test.list', 1, new_enabled, new_source, new_comment)

        assert sources_list.files['test.list'][0][3] == new_source or old_source
        assert sources_list.files['test.list'][0][4] == new_comment or old_comment

# Generated at 2022-06-23 03:09:30.063910
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    assert SourcesList(None)._remove_valid_source("") is None


# Generated at 2022-06-23 03:09:38.730726
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModuleFc25()
    module.params['filename'] = None
    module.params['mode'] = None
    sl = UbuntuSourcesList(module)
    line = 'deb http://deb.debian.org/debian stretch main'
    sl.add_source(line)
    assert sl.repos_urls == [line]
    sl.remove_source(line)
    assert sl.repos_urls == []
    sl.add_source(line)
    assert sl.repos_urls == [line]
    sl.remove_source(line)
    assert sl.repos_urls == []


# Generated at 2022-06-23 03:09:50.645750
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    assert len(sl.files) == 0
    module.fail_json = lambda **fail_args: fail_args
    sl.load('test_data/test_data.list')
    assert len(sl.files) == 2

# Generated at 2022-06-23 03:10:00.146104
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule('apt_repository')
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://www.onlyfortest/repo trusty main')
    sources_list.save()
    assert os.path.isfile('/etc/apt/sources.list.d/www.onlyfortest_repo.list')
    with open('/etc/apt/sources.list.d/www.onlyfortest_repo.list', 'r') as f:
        lines = f.readlines()
        assert lines == ['deb http://www.onlyfortest/repo trusty main\n']
    os.remove('/etc/apt/sources.list.d/www.onlyfortest_repo.list')

# Generated at 2022-06-23 03:10:02.600624
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("mymsg")
    except InvalidSource as e:
        return str(e) == "mymsg"



# Generated at 2022-06-23 03:10:06.716907
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    result = None
    try:
        raise InvalidSource("Could not parse source given: {0}".format("deb http://ftp.debian.org/debian/ unstable main non-free"))
    except InvalidSource as exc:
        result = 'Could not parse source given: deb http://ftp.debian.org/debian/ unstable main non-free'

    assert result == str(exc)



# Generated at 2022-06-23 03:10:16.012699
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sources = SourcesList(None)
    import tempfile
    outf = tempfile.mkstemp()
    fd = os.fdopen(outf[0], 'w')
    fd.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    fd.write('# deb-src http://archive.ubuntu.com/ubuntu/ xenial restricted main\n')
    fd.write('\n')
    fd.write('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted\n')
    fd.write('deb-src http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted\n')
    fd.write('\n')
    fd.close()
    sources.load(outf[1])

# Generated at 2022-06-23 03:10:21.714746
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    assert module.check_mode is True
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={})
    assert module.check_mode is False
    assert get_add_ppa_signing_key_callback(module)



# Generated at 2022-06-23 03:10:26.363608
# Unit test for function main

# Generated at 2022-06-23 03:10:29.117930
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec=dict(install_python_apt=dict(type='bool', default=False)))
    module.params['install_python_apt'] = True
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-23 03:10:30.093664
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # NotImplemented :/
    pass



# Generated at 2022-06-23 03:10:33.331120
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({})
    ubuntu_sources_list = UbuntuSourcesList(module)
    assert ubuntu_sources_list.codename == 'xenial'


# Generated at 2022-06-23 03:10:42.913603
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec=dict())
    source_list = SourcesList(module)
    source_list.files = dict(test_file=[(0, True, True, 'test_source', 'test_comment')])
    source_list.modify('test_file', 0, enabled=False)
    assert source_list.files['test_file'][0][1] is False
    source_list.modify('test_file', 0, source='test_source_new')
    assert source_list.files['test_file'][0][3] == 'test_source_new'
    source_list.modify('test_file', 0, comment='test_comment_new')
    assert source_list.files['test_file'][0][4] == 'test_comment_new'

# Generated at 2022-06-23 03:10:52.297400
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({'_ansible_check_mode': True})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://example.com/ubuntu trusty main')
    sources_list.add_source('deb http://example.com/ubuntu trusty-updates main', comment='test')
    sources_list.add_source('deb-src http://example.com/ubuntu trusty main')

    assert sources_list.dump() == {'/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n# deb http://example.com/ubuntu trusty-updates main # test\ndeb-src http://example.com/ubuntu trusty main\n'}


# Generated at 2022-06-23 03:10:59.339179
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.files['test_file'] = [(0, True, True, 'deb http://ubuntu.com', 'comment')]
    sources.modify('test_file', 0, source='deb-src http://ubuntu.com')
    assert sources.files['test_file'] == [(0, True, True, 'deb-src http://ubuntu.com', 'comment')]
test_SourcesList_modify()


# Generated at 2022-06-23 03:11:13.003300
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    d, fn = os.path.split(module.tmpdir)
    test_file = os.path.join(d, 'test.list')
    f = open(test_file, 'w')
    f.write('deb http://netgen.unfuddle.com/svn/netgen_erp/trunk/dev apt/\n')
    f.close()

    sources_list = SourcesList(module)
    sources_list.load(test_file)
    assert sources_list.files[test_file] == [(0, True, True, 'deb http://netgen.unfuddle.com/svn/netgen_erp/trunk/dev apt/', '')]
    os.remove(test_file)

# Generated at 2022-06-23 03:11:23.763370
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={
        'codename': dict(default='trusty')
    })

    contents = '''
# deb cdrom:[Ubuntu-Server 12.04 LTS _Precise Pangolin_ - Release amd64 (20120425)]/ dists/precise/main/binary-i386/
# deb cdrom:[Ubuntu-Server 12.04 LTS _Precise Pangolin_ - Release amd64 (20120425)]/ dists/precise/restricted/binary-i386/
deb http://mirror.netinch.com/pub/ubuntu/archive/ precise main restricted
# deb-src http://mirror.netinch.com/pub/ubuntu/archive/ precise main restricted

'''

    module.atomic_move = lambda path, path2: True
    apt_package_manager.get_package_

# Generated at 2022-06-23 03:11:35.661715
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class Module(object):
        def __init__(self, check_mode=False):
            self.check_mode = check_mode
            self.rc = []
            self.out = []
            self.err = []

        def run_command(self, command, check_rc=True):
            self.rc.append(0)
            self.out.append('')
            self.err.append('')

    module = Module()
    callback = get_add_ppa_signing_key_callback(module)
    callback(None)
    assert module.rc == []

    module = Module(True)
    callback = get_add_ppa_signing_key_callback(module)
    callback(None)



# Generated at 2022-06-23 03:11:46.009173
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    result = {}
    sources_list = get_sources_list(module)
    sources_before = deepcopy(sources_list.files)
    sourceslist_before = deepcopy(sources_list)
    module._diff = False
    module.params['state'] = 'present'
    module.params['filename'] = None
    module.params['repo'] = 'deb http://old.debian/testing main'
    module.params['dist'] = 'xenial'
    module.params['mode'] = 0o644
    result['changed'] = manage_repo(module, sources_list)
    revert_sources_list(sources_before, sources_list.files, sourceslist_before)
    assert "deb http://old.debian/testing main" not in get

# Generated at 2022-06-23 03:11:57.237302
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    try:
        import lxml.etree as ET
    except ImportError:
        import xml.etree.ElementTree as ET

    test_dir = os.path.dirname(os.path.realpath(__file__))
    module = AnsibleModule(argument_spec={})

    class ModuleFailException(Exception):
        pass

    class TestModule(object):
        def __init__(self, module):
            self.params = module.params

        def fail_json(self, *args, **kwargs):
            raise ModuleFailException(kwargs['msg'])

        def run_command(self, cmd):
            return 1, '', 'command failed'

        def atomic_move(self, src, dst):
            os.rename(src, dst)


# Generated at 2022-06-23 03:12:08.733445
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    import shutil

    sourcesfile = tempfile.NamedTemporaryFile()
    tempdir = tempfile.mkdtemp()
    tempfile.tempdir = tempdir

    # First lets create a sources.list file and populate it with two sources so we can perform comparisons.
    sourcesfile.write(b'deb http://debian.org/debian wheezy main\n')
    sourcesfile.write(b'deb http://debian.org/debian wheezy contrib\n')
    sourcesfile.flush()

    # Now lets duplicate that file and modify it a bit.
    sourcesfile_before = tempfile.NamedTemporaryFile()
    shutil.copyfile(sourcesfile.name, sourcesfile_before.name)

    sourcesfile_after = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 03:12:18.049507
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()
    defaults = dict(
        module=module,
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback
    )
    sl = UbuntuSourcesList(**defaults)
    deep_copy = deepcopy(sl)
    assert deep_copy.add_ppa_signing_keys_callback == add_ppa_signing_keys_callback



# Generated at 2022-06-23 03:12:27.298808
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 03:12:37.866147
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock(check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None

    module = Mock(check_mode=False)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None
    assert callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'ABCD1234']) is True

    module = Mock(check_mode=False)
    module.run_command = Mock(side_effect=Exception("Error"))
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None

# Generated at 2022-06-23 03:12:47.911330
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    src = SourcesList(module)

    # Test 1: do nothing
    src.files = {'/etc/apt/sources.list': [
        (0, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'First line'),
        (1, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'Second line'),
    ]}
    src.modify('/etc/apt/sources.list', 0)

# Generated at 2022-06-23 03:12:56.595460
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={}, check_invalid_arguments=False)
    sources = SourcesList(module)
    content = '''\
# deb https://dl.yarnpkg.com/debian/ stable main
deb-src http://archive.canonical.com/ubuntu hardy partner
# deb http://archive.ubuntu.com/ubuntu artful main universe
# deb http://archive.ubuntu.com/ubuntu artful-updates main universe
'''
    fd, tmp_path = tempfile.mkstemp(prefix=".sourceslist-", dir=os.path.dirname(sources.default_file))
    sources.files[tmp_path] = []
    for n, line in enumerate(content.splitlines()):
        sources.files[tmp_path].append(sources._parse(line))

   

# Generated at 2022-06-23 03:13:08.656158
# Unit test for function main

# Generated at 2022-06-23 03:13:14.914337
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Check that deepcopy returns a new instance
    um = unittest.mock.Mock()
    usl = UbuntuSourcesList(um)
    assert usl is not usl.__deepcopy__()

    # Check that the add_ppa_signing_keys_callback attribute is copied
    um = unittest.mock.Mock()
    usl = UbuntuSourcesList(um, add_ppa_signing_keys_callback=um)
    assert isinstance(usl.__deepcopy__(), UbuntuSourcesList)
    assert usl.add_ppa_signing_keys_callback == usl.__deepcopy__().add_ppa_signing_keys_callback



# Generated at 2022-06-23 03:13:21.973582
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(side_effect=[(0, '', ''), (0, '', '')])
    install_python_apt(module, 'python-apt')
    # The first call is apt-get update, the second is apt-get install python-apt
    assert module.run_command.call_args_list[1][0][0][3] == 'python-apt'
    # We should not have actually executed anything, as we are in check mode
    assert module.fail_json.called is False



# Generated at 2022-06-23 03:13:29.370730
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    apt_pkg.init()
    apt_pkg.config.set('Dir::Etc::sourceparts', '/etc/apt/sources.list.d')
    apt_pkg.config.set('Dir::Etc::sourcelist', '/etc/apt/sources.list')
    sources_list = SourcesList(AnsibleModule(argument_spec={}))
    assert sources_list.dump() == {}

# ==============================================================================
# SourcesList module class
# ==============================================================================

# Generated at 2022-06-23 03:13:37.660402
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    '''
    Tests SourcesList.save() by creating a temporary directory and
    writing a file to that directory, then comparing it with the
    original file.
    '''
    import shutil
    import tempfile
    from tempfile import mkdtemp

    from textwrap import dedent


# Generated at 2022-06-23 03:13:45.781241
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class Module(object):
        def __init__(self):
            self.params = {}
            self.debug = True
            self.fail_json = lambda msg, **kwargs: self.fail(msg, **kwargs)

            # We need a tmpdir to write files to when checking sources.
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(os.rmdir, self.tmpdir)

        def fail(self, msg, **kwargs):
            raise AssertionError(msg)

        def atomic_move(self, source, dest):
            shutil.move(source, dest)

        def set_mode_if_different(self, path, mode, changed):
            pass

    module = Module()
    sources_list = SourcesList(module)

# Generated at 2022-06-23 03:13:47.935531
# Unit test for function install_python_apt
def test_install_python_apt():
    return module.check_mode



# Generated at 2022-06-23 03:13:55.502709
# Unit test for constructor of class SourcesList
def test_SourcesList():
    params = {}
    module = AnsibleModule(argument_spec=params, supports_check_mode=True)
    sl = SourcesList(module)
    dump = sl.dump()

    assert dump
    assert '/etc/apt/sources.list' in dump
    assert '/etc/apt/sources.list.d' in dump
    assert '/etc/apt/sources.list.d/ansible.list' in dump


# Generated at 2022-06-23 03:14:06.252109
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class File(object):
        def __init__(self, contents):
            self.contents = contents
        def write(self, contents):
            self.contents += contents
        def close(self):
            pass

    sources = SourcesList(None)
    sources.files = {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]}

    sources.modify('/etc/apt/sources.list', 0, enabled=False, comment='test')

    res = SourcesList(None)
    res.files = {'/etc/apt/sources.list': [(0, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'test')]}

    assert sources == res

# Generated at 2022-06-23 03:14:15.886393
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # create a sample apt_repository argument
    mock_module = AnsibleModule(
        argument_spec=dict(
            repo=dict(required=True),
            state=dict(default='present', choices=['absent', 'present'])
        ),
        supports_check_mode=False,
        required_if=[('state', 'absent', ['repo'])],
        mutually_exclusive=[],
        required_together=[]
    )
    repo_arg = mock_module.params.get('repo')
    state_arg = str(mock_module.params.get('state'))
    filename_arg = mock_module.params.get('filename')
    sourceslist = SourcesList(mock_module)
    # Create a source file

# Generated at 2022-06-23 03:14:22.086789
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is not None
    module = AnsibleModule(argument_spec={}, check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-23 03:14:32.951156
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import sys
    import os
    import shutil
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        name='test',
        state='present',
        repo='deb http://archive.canonical.com/ubuntu hardy partner'
    )
    sl = SourcesList(module)
    sl.add_source(module.params['repo'])
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 03:14:35.344886
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})

    sl = SourcesList(module)

    assert len(sl.files) == 0



# Generated at 2022-06-23 03:14:45.295944
# Unit test for function install_python_apt
def test_install_python_apt():
    import tempfile
    import shutil
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six.moves import urllib

    # Build fake apt-get
    tmpdir = tempfile.mkdtemp()
    test_python_apt_name = 'python3-apt'
    apt_get_path = os.path.join(tmpdir, 'apt-get')
    with open(apt_get_path, 'w') as apt_get_file:
        apt_get_file.write('#!/bin/bash')

    os.chmod(apt_get_path, 0o755)

    # Build fake python-apt

# Generated at 2022-06-23 03:14:54.542269
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Test adding sources
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)
    test_sources = ['deb http://archive.ubuntu.com/ubuntu xenial main',
                    'deb http://archive.ubuntu.com/ubuntu xenial-updates main',
                    'deb http://archive.ubuntu.com/ubuntu xenial-security main']
    for source in test_sources:
        sl._add_valid_source(source, '')
    for source in test_sources:
        for file, n, enabled, source_in, comment in sl:
            assert source == source_in



# Generated at 2022-06-23 03:14:57.939283
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    instance = UbuntuSourcesList(None)
    result = instance.__deepcopy__()
    assert isinstance(result, UbuntuSourcesList)

# Generated at 2022-06-23 03:14:58.762999
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # TODO
    pass

# Generated at 2022-06-23 03:15:02.819843
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():

    class FakeModule(object):
        def __init__(self, check_mode=False):
            self.check_mode = check_mode
            self.params = {}
            self.fail_json = None
            self.files = {}

        def fail_json(self, msg):
            raise InvalidSource(msg)

    # Case with default sources.list
    src_list = SourcesList(FakeModule())
    assert len(src_list.files) == 1
    assert len(src_list.files[src_list.default_file]) > 0



# Generated at 2022-06-23 03:15:07.822172
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # check_mode = True
    module = MagicMock(check_mode=True)
    assert get_add_ppa_signing_key_callback(module) is None
    # check_mode = False
    module = MagicMock(check_mode=False)
    assert get_add_ppa_signing_key_callback(module) == module.run_command



# Generated at 2022-06-23 03:15:19.846751
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({
        'filename': 'myrepo',
        'comment': 'myrepo comment',
        'state': 'present',
        'mode': '0600',
        'repo': 'deb http://repo.example.com/ some-repo main',
    }, is_new_style=True)

    sl = SourcesList(module)
    assert sl.default_file == '/etc/apt/sources.list'

# Generated at 2022-06-23 03:15:29.783883
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    assert [] == SourcesList(None).remove_source('')
    assert [] == SourcesList(None).remove_source('#')
    assert [] == SourcesList(None).remove_source('##')
    assert [] == SourcesList(None).remove_source('###')
    assert [] == SourcesList(None).remove_source('####')

# Generated at 2022-06-23 03:15:32.719668
# Unit test for constructor of class SourcesList
def test_SourcesList():
    assert len(SourcesList(None)) > 0
    assert len(SourcesList(None).dump()) > 0



# Generated at 2022-06-23 03:15:39.898242
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = MagicMock()
    module.params = {}
    sl = UbuntuSourcesList(module)
    sl._parse = MagicMock(return_value=(True, True, 'source', 'comment'))
    sl._remove_valid_source = MagicMock()

    sl.remove_source('line')
    sl._parse.assert_called_with('line', raise_if_invalid_or_disabled=True)
    sl._remove_valid_source.assert_called_with('source')



# Generated at 2022-06-23 03:15:52.078304
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # source = 'deb http://ppa.launchpad.net/ddaa/foo/ubuntu quantal main'
    # file = _suggest_filename('%s_%s' % (source, self.codename))
    # file = _suggest_filename('ppa:ddaa/foo_quantal')
    # file = 'ddaa_foo.list'
    owner_name = 'ddaa'
    ppa_name = 'foo'
    codename = 'quantal'

    lp_api = 'https://launchpad.net/api/1.0/~%s/+archive/%s'
    lp_api = lp_api % (owner_name, ppa_name)


# Generated at 2022-06-23 03:16:02.331227
# Unit test for function install_python_apt
def test_install_python_apt():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.respawn import probe_interpreters_for_module, has_respawned, respawn_module
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.check_mode = False
        def run_command(self, command, *args, **kwargs):
            return 0, '', ''
        def get_bin_path(self, command, *args, **kwargs):
            return None
        def fail_json(self, *args, **kwargs):
            raise Exception()

   