

# Generated at 2022-06-23 03:06:11.603479
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    line = "deb http://dl.google.com/linux/chrome/deb/ stable main"
    comment = "added by ansible"
    file = "/tmp/test-sources.list"
    sourceslist = SourcesList(object())
    sourceslist.add_source(line, comment, file=file)
    assert sourceslist.dump()[file] == line + ' # ' + comment + '\n'


# Generated at 2022-06-23 03:06:17.153890
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # create two files
    fd, filename = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.example.com/ trusty main multiverse\n')
    f.write('deb-src http://archive.example.com/ trusty main multiverse\n')
    f.write('# deb-src http://archive.example.com/ trusty main multiverse\n')
    f.close()

    fd, filename2 = tempfile.mkstemp()
    f2 = os.fdopen(fd, 'w')
    f2.write('deb-src http://download.example.com/ trusty main multiverse\n')
    f2.write('# deb http://download.example.com/ trusty main multiverse\n')

# Generated at 2022-06-23 03:06:20.974499
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    obj = UbuntuSourcesList(module)
    obj_copy = copy.deepcopy(obj)
    assert obj_copy.module is not obj.module
    assert obj_copy.add_ppa_signing_keys_callback is obj.add_ppa_signing_keys_callback
    assert obj_copy.codename == obj.codename



# Generated at 2022-06-23 03:06:26.005119
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.common.respawn import respawn_test
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    test = respawn_test(SourcesList)

    def _init_module(self, tmpdir, files):
        self.module = _AnsibleModule(tmpdir, files)

    def _init_tmpdir(self):
        self.tmpdir = mkdtemp(prefix='ansible_test_')

    def _cleanup(self):
        rmtree(self.tmpdir)

    def _AnsibleModule(tmpdir, files):
        def _fail_json(msg):
            raise Exception(msg)


# Generated at 2022-06-23 03:06:37.064931
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    m = AnsibleModule(name='test')
    s = UbuntuSourcesList(m)
    s.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', '# ansible')
    assert s.files['/etc/apt/sources.list.d/ansible_ansible_bionic.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', '# ansible')]
    s.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', '# ansible')

# Generated at 2022-06-23 03:06:42.871616
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class Module(object):
        def __init__():
            self.files = {
                'filename': [
                    (
                        0,  # n
                        True,  # valid
                        False,  # enabled
                        'deb http://archive.ubuntu.com/ubuntu/ precise multiverse',  # source
                        'comment',  # comment
                    ),
                ]
            }

    m = Module()
    sl = SourcesList(m)
    sl.modify("filename", 0, enabled=True)
    assert sl.files['filename'][0][1] == (0, True, True, "deb http://archive.ubuntu.com/ubuntu/ precise multiverse",
                                          "comment")
    sl.modify("filename", 0, source="deb http://archive.ubuntu.com/ubuntu/ quantal multiverse")

# Generated at 2022-06-23 03:06:43.698946
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-23 03:06:53.342426
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    src_list = SourcesList()
    # Test file doesn't exist and empty list
    assert src_list._files == {}
    # Test empty file
    src_list.load('/dev/null')
    assert src_list._files == {}
    # Test file with simple line
    src_list.load(os.path.join(os.path.dirname(__file__), 'input_sources_list_load.txt'))
    assert set(src_list._files.keys()) == set([os.path.join(os.path.dirname(__file__), 'input_sources_list_load.txt')])
    assert len(src_list._files[os.path.join(os.path.dirname(__file__), 'input_sources_list_load.txt')]) == 1
    assert src_list

# Generated at 2022-06-23 03:07:03.353542
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from mock import patch, MagicMock
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.apt.sources import UbuntuSourcesList

# Generated at 2022-06-23 03:07:08.533992
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # Instantiating class InvalidSource should raise an exception with a specific error message
    exception_text = "Source format is not valid"
    try:
        raise InvalidSource(exception_text)
    except InvalidSource as e:
        test_text = str(e)
        assert test_text == exception_text, \
            "Source exception text is not correct. Expected %s and got: %s" % (exception_text, test_text)



# Generated at 2022-06-23 03:07:20.086488
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    path = tempfile.mkstemp()


# Generated at 2022-06-23 03:07:26.139933
# Unit test for constructor of class SourcesList
def test_SourcesList():

    # Force read from sources.list and sources.list.d
    apt_pkg.init_system()
    apt_pkg.config.set("Dir::Etc::sourcelist", "/dev/null")
    apt_pkg.config.set("Dir::Etc::sourceparts", "/dev/null")

    # SourcesList constructor reads sources.list and sources.list.d,
    # so it's safe to check lookup methods without sources.list and sources.list.d
    sl = SourcesList(None)
    assert len(sl.files) == 0

    # But constructor can read files, so let's do it
    sl = SourcesList(None)
    assert len(sl.files) != 0



# Generated at 2022-06-23 03:07:27.746780
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('testing')
    except InvalidSource as e:
        assert(e.args == ('testing',))



# Generated at 2022-06-23 03:07:39.333650
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_data = [
        ['# deb http://archive.canonical.com/ubuntu hardy partner', 'deb http://archive.canonical.com/ubuntu hardy partner'],
        ['deb http://archive.canonical.com/ubuntu hardy partner', 'deb http://archive.canonical.com/ubuntu hardy partner'],
        ['deb-src http://archive.canonical.com/ubuntu hardy partner', 'deb-src http://archive.canonical.com/ubuntu hardy partner']
    ]
    sl = SourcesList({})
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-23 03:07:48.591532
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    '''
    test add_source method of class UbuntuSourcesList:
    is the method add a new source?
    '''
    # Create a module for the unit test and a UbuntuSourcesList object
    mod = AnsibleModuleMock()
    sources = UbuntuSourcesList(mod)
    # Create a test source and add it.
    source_test = 'deb http://ppa.launchpad.net/danielrichter2007/grub-customizer/ubuntu xenial main'
    comment_test = '# This is a test source'
    fn = sources._suggest_filename('grub-customizer')
    sources.add_source(source_test, comment_test, fn)
    # If the source has been added, the code returns 0

# Generated at 2022-06-23 03:07:54.177368
# Unit test for constructor of class SourcesList

# Generated at 2022-06-23 03:08:05.910157
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import pytest
    from .ansible_module_apt_repository import SourcesList

    class FakeModule(object):
        def __init__(self, args, files, debug=False):
            self.params = {}
            self.debug = debug
            self.args = args
            self.files = files
            self.fail_json = self.exit_json = self.run_command = self.get_bin_path = self.atomic_move = None

        def _format_args(self):
            return ", ".join("%s=%s" % (arg, repr(self.params[arg])) for arg in self.args)


# Generated at 2022-06-23 03:08:14.616245
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class ModuleFailJson(object):
        def __init__(self):
            self.params = {'filename': None}

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, tmp_path, filename):
            os.rename(tmp_path, filename)


# Generated at 2022-06-23 03:08:20.966535
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''test_sources_list'''
    source_list = '''\
## THIS FILE IS AUTOMATICALLY CONFIGURED BY THE PACKAGE 'apt-add-repository'
#
# The entries below are either automatically added by other
# installation/configuration tools or manually added by the user.
#
deb     http://tahoe.thinki.st/debian      jessie           main
#
# deb-src http://tahoe.thinki.st/debian jessie main
'''.splitlines()

    sourceslist = UbuntuSourcesList(None)
    sourceslist.load(source_file)
    sourceslist_before = copy.deepcopy(sourceslist)

    sourceslist.add_source("deb http://tahoe.thinki.st/debian jessie main", comment="#")


# Generated at 2022-06-23 03:08:34.371047
# Unit test for function main
def test_main():
    from ansible.utils.path import unfrackpath

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import StringIO

    from ansible_collections.jctanner.system_py_apt.plugins.module_utils.apt import distro

    # Make sure we don't do any actual work.
    fetch_url.side_effect = lambda params, url, **kwargs: '{}'
    distro.codename = 'trusty'
    apt.cache.open.side_effect = lambda:  ''

    # Make sure we don't try to run apt-get update in check mode.

# Generated at 2022-06-23 03:08:41.363348
# Unit test for function install_python_apt
def test_install_python_apt():
    m = AnsibleModule({})
    m.fail_json = MagicMock(side_effect=stop_iteration)
    m.get_bin_path = MagicMock(return_value='/usr/bin/apt-get')
    m.run_command = MagicMock(return_value=(0, '', ''))
    install_python_apt(m, 'python-apt')
    assert m.fail_json.call_count == 1
    assert m.get_bin_path.call_count == 1
    assert m.get_bin_count.call_count == 2



# Generated at 2022-06-23 03:08:54.985018
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    src_list = SourcesList(AnsibleModule(argument_spec=dict()))
    src_list.load('test/data/valid.list')

# Generated at 2022-06-23 03:09:06.091685
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Exercise code in SourcesList.remove_source() method
    # mock the module, since we don't have it when running unit tests
    mock_module = type('AnsibleModule', (object,), {'run_command': None, 'check_mode': False, 'params': None})
    mock_module.run_command = lambda args: (0, '', '')
    mock_module.check_mode = False
    mock_module.params = dict(repo='deb http://archive.canonical.com/ubuntu hardy partner')
    mock_module.fail_json = lambda **kwargs: ("fail_json was called: %s" % kwargs)
    mock_module.atomic_move = lambda *args: (0, '', '')

    sl = SourcesList(mock_module)

# Generated at 2022-06-23 03:09:17.033297
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class Module:
        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, tmp_path, filename):
            os.rename(tmp_path, filename)

        def set_mode_if_different(self, filename, mode, follow_links):
            if follow_links:
                os.chmod(filename, mode)

    sl = UbuntuSourcesList(Module())
    sl.add_source('ppa:foo/bar')
    assert len(sl.files) == 1
    assert sl.files.keys() == ['/etc/apt/sources.list.d/foo_bar.list']
    sl.add_source('ppa:foo/bar', file='/tmp/foo.list')
    assert len(sl.files) == 2

# Generated at 2022-06-23 03:09:20.439688
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    source = 'deb http://archive.canonical.com/ubuntu xenial partner'
    file = '/etc/apt/sources.list.d/canonical_partner.list'
    sl = SourcesList(None)
    sl.files = {file: [(0, True, True, source, '')]}
    assert sl.dump()[file] == '%s\n' % source



# Generated at 2022-06-23 03:09:24.714378
# Unit test for function install_python_apt
def test_install_python_apt():
    import platform
    import contextlib
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils import apt_pkg as apt_pkg_utils
    try:
        import apt
    except ImportError:
        pass
    else:
        return  # python-apt is already installed, no need to test this function

    apt_pkg_name = 'python-apt' if PY3 else 'python3-apt'

    # Create a module object and initialize apt_pkg just enough to not fail on import
    module = AnsibleModule(name='apt_pkg', argument_spec={'install_python_apt': {'type': 'bool', 'default': False}})

# Generated at 2022-06-23 03:09:28.607960
# Unit test for constructor of class SourcesList
def test_SourcesList():
    return SourcesList(None)


#
# The following are our public functions for the 'apt_repository' module.
#


# Generated at 2022-06-23 03:09:39.531584
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

    import sys, os
    my_dir = os.path.dirname(os.path.abspath(__file__))
    _ansible_module_name = os.path.basename(__file__)[:-3]
    _module = os.path.join(my_dir, '../library/%s.py' % _ansible_module_name)
    _fake_module = os.path.join(my_dir, 'fake_module.py')
    _resource_defination_module = os.path.join(my_dir, 'fake_resource.py')

# Generated at 2022-06-23 03:09:47.417101
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(m) is None

    m.check_mode = False
    f = get_add_ppa_signing_key_callback(m)
    import sys
    if sys.version_info >= (3, 0):
        assert f.__self__ is m
    else:
        assert f.im_self == m



# Generated at 2022-06-23 03:09:59.128992
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    with tempfile.TemporaryDirectory() as tempdir:
        # Create fake apt config and sources lists
        apt_cfg_dir = os.path.join(tempdir, 'etc/apt')
        sourceparts_dir = os.path.join(apt_cfg_dir, 'sources.list.d')
        os.makedirs(sourceparts_dir)


# Generated at 2022-06-23 03:10:11.291091
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    def test_iter_method():
        # Tests are inside module because of import dependencies
        import pytest
        from ansible.module_utils.apt_repository import SourcesList, InvalidSource, VALID_SOURCE_TYPES

        random.seed(0)  # timed tests
        for _ in range(50):
            # Create random sources list
            expected_lines = []
            for _ in range(random.randrange(30)):
                valid_source_type = random.choice(VALID_SOURCE_TYPES)
                source_enabled = bool(random.getrandbits(1))
                source = '%s http://some.random.domain/random/path' % valid_source_type
                if source_enabled:
                    expected_lines.append(source)

# Generated at 2022-06-23 03:10:12.009862
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    pass


# Generated at 2022-06-23 03:10:19.868867
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible_collections.community.general.plugins.module_utils.distribution.debian.sources_list import SourcesList, UbuntuSourcesList
    module = AnsibleModule(argument_spec={})
    sources_before = SourcesList(module)
    sources_after = SourcesList(module)
    sources_after.add_source('http://example.com/repo')
    sourceslist_before = SourcesList(module)
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert len(sources_after) == len(sources_before)
    sources_before = UbuntuSourcesList(module)
    sources_after = UbuntuSourcesList(module)

# Generated at 2022-06-23 03:10:28.927322
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible.module_utils.facts.system.distribution import Distribution
    distro = Distribution(dict(
        name='Ubuntu',
        id='ubuntu',
        codename='precise',
        major_version='12'
    ))

    module_mock = MagicMock()
    module_mock.params = dict(
        codename=None
    )

    module_mock.atomic_move.return_value = None
    module_mock.set_mode_if_different.return_value = None
    module_mock.run_command.return_value = (0, '', '')
    module_mock.run_command.return_value = (0, '{"signing_key_fingerprint": "1"}', '')

    sl = UbuntuSourcesList(module_mock)

    # Test file

# Generated at 2022-06-23 03:10:35.475452
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module_args = dict(
        state='present'
    )

    existing_source = 'deb http://archive.canonical.com/ubuntu hardy partner'
    sources = [(0, True, True, existing_source, 'test comment'),
               (0, True, True, existing_source, 'test comment 2')]
    sources_list = dict(sources_list=[
            dict(
                filename='/etc/apt/sources.list',
                sources=sources,
                new_repos=set(['/etc/apt/sources.list'])
            )])
    return sources_list


# Generated at 2022-06-23 03:10:44.593239
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

    sources_list = [
        'deb-src http://archive.canonical.com/ubuntu hardy partner',
        '# deb http://archive.canonical.com/ubuntu hardy partner',
        '',
        '# commented line',
        '# commented line with extra info',
        'deb http://archive.canonical.com/ubuntu hardy partner',
        '# deb-src http://archive.canonical.com/ubuntu hardy partner',
        '# invalid line',
        '# another invalid line'
    ]

    def has_file(filename):
        assert os.path.exists(filename)
        assert os.path.isfile(filename)

        content = open(filename, 'r').readlines()

# Generated at 2022-06-23 03:10:53.446071
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # run ansible module without parameters
    import ansible.module_utils.basic as basic
    argument_spec = dict(filename=dict(aliases=['name']),
                         state=dict(default='present', choices=['absent', 'present']),
                         update_cache=dict(default=False, type='bool'),
                         validate_certs=dict(default=True, type='bool'),
                         source=dict(required=True),
                         comment=dict(default=''),
                         mode=dict(required=False, type='raw'),
                         )

    module = basic.AnsibleModule(argument_spec=argument_spec, supports_check_mode=True)
    module.exit_json = Mock()
    module.run_command = Mock()
    module.run_command.return_value = 0, "", ""
    module.check

# Generated at 2022-06-23 03:10:54.579986
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    InvalidSource()



# Generated at 2022-06-23 03:11:02.003165
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    repo_manager = UbuntuSourcesList(None)
    repo_manager.files = {
        '/etc/apt/sources.list' : [
            (1, True, False, 'deb http://ppa.launchpad.net/tom/ppa/ubuntu bionic main', '')
        ]
    }

    repo_manager.remove_source('deb http://ppa.launchpad.net/tom/ppa/ubuntu bionic main')

    assert repo_manager.files['/etc/apt/sources.list'] == []


# Generated at 2022-06-23 03:11:13.458043
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self.params = params

    def add_ppa_signing_keys_callback(command):
        pass

    module = Module()
    ubuntu_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)

    actual = ubuntu_sources_list._parse('deb   http://ppa.launchpad.net/chris-lea/redis-server/ubuntu trusty main', True)
    assert actual == (True, True, 'deb http://ppa.launchpad.net/chris-lea/redis-server/ubuntu trusty main')


# Generated at 2022-06-23 03:11:29.194220
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.common.process import get_bin_path
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

    # On Debian GNU/Linux, the default APT keyring directory is
    #  - /etc/apt/trusted.gpg
    #  - /etc/apt/trusted.gpg.d/*.gpg
    # and the default APT keyring is /etc/apt/trusted.gpg.
    keyring = '/tmp/test_apt_keyring'
    gpg = get_bin_path('gpg')

# Generated at 2022-06-23 03:11:38.334615
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    First, let's make sure that we can add new sources.
    '''
    testlib = __import__('ansible_collections.ansible.community.tests.unit.modules.backports.test_ansible_module_apt_repository_SourcesList_add_source', globals(), locals(), ['*'])
    test_cases = testlib.test_cases
    for test_case in test_cases:
        test = SourcesList(test_case['module'])
        for entry in test_case['initial']:
            test._add_valid_source(*entry)
        for entry in test_case['final']:
            test._remove_valid_source(*entry)
        assert test.dump() == test_case['expected']



# Generated at 2022-06-23 03:11:46.668178
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    # https://github.com/ansible/ansible/issues/23721
    source1 = 'deb [arch=amd64] https://apt.dockerproject.org/repo ubuntu-xenial main'
    comment1 = ' Docker repo'
    sourceslist.add_source(source1, comment=comment1, file='testfile.list')
    # https://github.com/ansible/ansible/issues/23721
    source2 = 'deb [arch=amd64] https://apt.dockerproject.org/repo ubuntu-xenial main'
    comment2 = ' Docker repo'
    sourceslist.add_source(source2, comment=comment2, file='testfile.list')


# Generated at 2022-06-23 03:11:57.478257
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from tempfile import mkdtemp
    from shutil import rmtree

    apt_pkg.init_system()
    test_dir = mkdtemp()
    module = AnsibleModule({'src': '/tmp/repo.list',
                            'filename': '%s/%s' % (test_dir, 'repo_list')})

# Generated at 2022-06-23 03:12:01.031277
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(0) is None
    assert get_add_ppa_signing_key_callback(1)('a') == None

apt_pkg.init()


# Generated at 2022-06-23 03:12:06.052827
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import tempfile, textwrap, os
    m = AnsibleModule(argument_spec={})
    tmp_f = tempfile.NamedTemporaryFile(delete=False)
    tmp_f.write(textwrap.dedent('''\
        deb http://archive.canonical.com/ubuntu hardy partner
        deb-src http://archive.ubuntu.com/ubuntu hardy main restricted
        # deb http://archive.canonical.com/ hardy partner

        deb http://archive.canonical.com/ubuntu hardy partner
        <-- invalid line ///
        ''').encode('utf-8'))
    tmp_f.close()
    sl = SourcesList(m)
    sl.load(tmp_f.name)

# Generated at 2022-06-23 03:12:12.015438
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    mock_module = MagicMock(spec=AnsibleModule)
    mock_add_ppa_signing_keys_callback = MagicMock(spec=None)
    sl = UbuntuSourcesList(mock_module, add_ppa_signing_keys_callback=mock_add_ppa_signing_keys_callback)
    assert sl == sl.__deepcopy__()



# Generated at 2022-06-23 03:12:22.619067
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec=dict())
    sources_list = SourcesList(module)
    sources_list.files['/etc/apt/sources.list'] = [(0, True, True, 'deb http://www.example.com wheezy', 'comment')]
    sources_list.files['/etc/apt/sources.list.d/test.list'] = [(0, True, True, 'deb http://www.example.com testing', 'comment')]
    expected_output = {
        '/etc/apt/sources.list': 'deb http://www.example.com wheezy\n',
        '/etc/apt/sources.list.d/test.list': 'deb http://www.example.com testing\n',
    }
    assert sources_list.dump() == expected_output

# Unit

# Generated at 2022-06-23 03:12:35.676137
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:12:46.661453
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    a = {
        'b': 'c',
        'g': 'e',
    }
    b = {
        'b': 'c',
        'g': 'e',
        'd': 'f',
    }
    c = {
        'b': 'c',
        'g': 'e',
    }

    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            raise Exception('Fail')
        def atomic_move(self, *args, **kwargs):
            pass
        def set_mode_if_different(self, *args, **kwargs):
            pass

    m = MockModule()

    with tempfile.TemporaryDirectory() as tempdir:
        s

# Generated at 2022-06-23 03:12:58.338160
# Unit test for function main
def test_main():
    module_name="repo_facts"

# Generated at 2022-06-23 03:13:09.386460
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:13:17.007673
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # TODO: mock is not a good choice for testing of constructor.
    #       But I'm too lazy to write testing framework and to compare dumps ;)
    src = SourcesList(AnsibleModule(argument_spec={}))
    assert src is not None
    for key in src.files:
        assert key is not None


# Generated at 2022-06-23 03:13:21.185349
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleExitJson) as result:
        main()
    assert result.value.args[0]['changed']


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:34.254493
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule()

    # Test adding PPAs
    test_list = UbuntuSourcesList(module)
    test_list.new_repos = {}

    ppa = 'ppa:abc/123'
    test_list.add_source(ppa)
    assert ppa in test_list.new_repos

    ppa = 'ppa:abc'
    test_list.add_source(ppa)
    assert ppa in test_list.new_repos

    # Test adding a general source
    general_source = 'deb http://ftp.debian.org/debian squeeze main'
    general_file = 'my_file.list'

    test_list.add_source(general_source, file=general_file)
    assert general_file in test_list.files

# Generated at 2022-06-23 03:13:44.541313
# Unit test for constructor of class UbuntuSourcesList

# Generated at 2022-06-23 03:13:48.107861
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:13:50.430649
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except Exception:
        pass



# Generated at 2022-06-23 03:14:01.918077
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict())

    sourceslist = SourcesList(module)
    assert len(sourceslist.files) == 0
    assert len(sourceslist.new_repos) == 0

    sourceslist.load('tests/testdata/add_remove_apt_repo/sources.conf')
    assert len(sourceslist.files) == 1
    assert len(sourceslist.new_repos) == 0


# Generated at 2022-06-23 03:14:14.267041
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec=dict(
        mode=dict(type='str', default='present', choices=['present', 'absent']),
        state=dict(type='str', default='present', choices=['present', 'absent']),
        filename=dict(type='str'),
        update_cache=dict(type='bool', default=False),
        source=dict(type='str'),
        source_list=dict(type='str'),
        comment=dict(type='str'),
        codename=dict(type='str'),
        cache_valid_time=dict(type='int', default=0),
    ))
    sl = UbuntuSourcesList(module)
    assert isinstance(sl, UbuntuSourcesList)
    assert isinstance(sl, SourcesList)


# Generated at 2022-06-23 03:14:17.003985
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    assert len(sourceslist.files) > 0



# Generated at 2022-06-23 03:14:23.677760
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    '''Test for github issue #44987: remove_source method does not do anything if the PPA already exists as a disabled repo'''
    import tempfile
    import os

    line = 'ppa:foo/bar'
    module_name = 'apt'
    filename = os.path.join('/etc/apt/sources.list.d', '%s.list' % module_name)
    comment = '# comment'
    new_comment = '# new_comment'

    with tempfile.NamedTemporaryFile('w', delete=False) as f:
        f.write('%s %s\n' % (line, comment))
        f.write('%s %s\n' % ('#'+line, new_comment))

    f.close()

    module = AnsibleModule(argument_spec={})
    repositories

# Generated at 2022-06-23 03:14:31.199367
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class Module:
        def __init__(self):
            self.params = dict()

    # test empty apt sources
    module = Module()
    usl = UbuntuSourcesList(module)
    assert usl.codename == 'trusty'

    # test non-empty apt sources
    module = Module()
    module.params["codename"] = "xenial"
    usl = UbuntuSourcesList(module)
    assert usl.codename == 'xenial'
    assert len(usl.files) == 0


# Generated at 2022-06-23 03:14:39.613268
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.changed = False
    module = FakeModule()
    sources = SourcesList(module)
    sources.load(os.path.join(os.path.dirname(__file__), 'inputs', 'sources.list'))
    sources.save()
    output_file = os.path.join(os.path.dirname(__file__), 'outputs', 'sources.list')
    with open(output_file) as f:
        assert f.read() == str(sources)


# Generated at 2022-06-23 03:14:47.380870
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    test_file = '/tmp/test_apt.list'
    sl = UbuntuSourcesList(module=dict(params=dict(codename='vivid')))
    f = open(test_file, 'w')
    f.write('deb http://ppa.launchpad.net/pi-rho/security/ubuntu vivid main\n')
    f.write('deb-src http://ppa.launchpad.net/pi-rho/security/ubuntu vivid main\n')
    f.write('deb http://ppa.launchpad.net/pi-rho/security/ubuntu trusty main\n')
    f.write('deb-src http://ppa.launchpad.net/pi-rho/security/ubuntu trusty main\n')
    f.close()
    sl.load(test_file)

# Generated at 2022-06-23 03:14:57.097367
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class AnsibleModule(object):
        def __init__(self):
            self.params = {
                'filename': None
            }

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def set_mode_if_different(self, src, mode, follow):
            pass

    module = AnsibleModule()
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo.list')
    assert len(sources_list.files) == 1
    assert len(sources_list.files['/etc/apt/sources.list.d/foo.list']) == 1
    sources_list.remove_source('ppa:foo/bar')

# Generated at 2022-06-23 03:15:07.108378
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    # check if ppa gets removed
    sl = UbuntuSourcesList(ModuleStub())
    sl.add_source('ppa:marutter/rdev')
    sl.remove_source('ppa:marutter/rdev')
    assert len(sl.files) == 0

    # check if non-ppa gets removed
    sl = UbuntuSourcesList(ModuleStub())
    sl.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sl.remove_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    assert len(sl.files) == 0

    # check if ppa with codename gets removed
    sl = UbuntuSourcesList(ModuleStub(dict(codename='quantal')))
    sl.add_source('ppa:marutter/rdev')

# Generated at 2022-06-23 03:15:16.223213
# Unit test for function main
def test_main():
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self._diff = False

        def fail_json(self, msg):
            raise Exception(msg)

        def exit_json(self, changed=False, repo=None, state=None, diff=dict()):
            print((changed, repo, state, diff))

    a = AnsibleModule()
    main(a)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:15:27.156423
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class MockModule():
        def fail_json(self, **msg):
            print(msg)
            return False

    m = MockModule()
    sl = SourcesList(m)
    filename = tempfile.mkdtemp(prefix='ansible-tmp-')

# Generated at 2022-06-23 03:15:27.898955
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    pass



# Generated at 2022-06-23 03:15:36.882907
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class Module(object):
        def __init__(self, *args):
            self.args = args
            self.fail_json_called = False
            self.params = None
            self.set_mode_if_different_called = False
            self.atomic_move_called = False

        def fail_json(self, msg):
            self.fail_json_called = True
            self.msg = msg

        def set_mode_if_different(self, filename, mode, changed):
            self.set_mode_if_different_called = True
            self.set_mode_if_different_filename = filename
            self.set_mode_if_different_mode = mode
            self.set_mode_if_different_changed = changed

        def atomic_move(self, tmp_path, filename):
            self.atomic_move

# Generated at 2022-06-23 03:15:47.839805
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_cases = (
        # test_case                               # expected_result
        ('deb http://example.com/xenial main\n',  # True
            (True, 'deb http://example.com/xenial main')),
        ('http://example.com/xenial main\n',      # True
            (True, 'deb http://example.com/xenial main')),
        ('http://example.com/xenial main\n',      # False
            (False, 'deb http://example.com/xenial main')),
        ('# http://example.com/xenial main\n',    # False
            (False, 'deb http://example.com/xenial main')),
    )

# Generated at 2022-06-23 03:15:57.338848
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # This is a testing function. Not part of actual code.
    module = Mock()
    module.run_command = Mock(return_value=0)
    module.check_mode = True
    module.debug = Mock()
    module.fail_json = Mock(return_value=0)
    module.atomic_move = Mock(return_value=0)
    module.set_mode_if_different = Mock(return_value=0)
    module.params = {'file': 'mockfile'}
    sl = SourcesList(module)
    sl.load_sourceslist()
    assert sl.default_file == 'mockfile'



# Generated at 2022-06-23 03:16:01.791695
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    line = 'deb [arch=amd64] http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted'
    source = 'deb [arch=amd64] http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted'
    assert source == UbuntuSourcesList.remove_source(line)

# Generated at 2022-06-23 03:16:06.583271
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = MagicMock()

    # check mode
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    # normal mode
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    callback([])
