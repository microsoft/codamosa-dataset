

# Generated at 2022-06-23 03:06:12.937105
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    check_mode = False
    dummy_module = type('DummyModule', (object,), {'check_mode': check_mode})
    function = get_add_ppa_signing_key_callback(dummy_module)
    assert function is not None

    check_mode = True
    dummy_module = type('DummyModule', (object,), {'check_mode': check_mode})
    function = get_add_ppa_signing_key_callback(dummy_module)
    assert function is None
# End unit test


# Generated at 2022-06-23 03:06:21.204247
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.modify('/a/path', 0, source='0')
    sources_list.save()
    assert os.path.isfile('/a/path')
    with open('/a/path') as f:
        contents = f.read()
    assert contents == '0\n'
    os.remove('/a/path')


# Generated at 2022-06-23 03:06:30.125404
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_module_class, test_failing_class, test_case_class = _get_test_classes()
    suite = test_module_class(teardown_mock=False)
    def create_mock_file(filename, sources, module):
        if not os.path.exists(os.path.dirname(filename)):
            os.makedirs(os.path.dirname(filename))
        with open(filename, 'w') as f:
            for s in sources:
                f.write(s.strip() + '\n')
    # Definition of tests
    class TestSourcesList(test_case_class):
        def setUp(self):
            self.sl = SourcesList(self.module)


# Generated at 2022-06-23 03:06:33.296923
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("test")
    except InvalidSource as e:
        if "test" != str(e):
            raise Exception("test_InvalidSource failed")


# gets and parses any lsb-release info available

# Generated at 2022-06-23 03:06:36.561211
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    my_invalid_source = InvalidSource('an exception message')
    assert my_invalid_source.args[0] == 'an exception message'


# Generated at 2022-06-23 03:06:40.317620
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(MagicMock()) is not None
    assert get_add_ppa_signing_key_callback(MagicMock(check_mode=True)) is None


# Generated at 2022-06-23 03:06:50.918955
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import pytest

    source_list_files = [
        ('', True, 'deb http://example.com/ubuntu xenial main', ''),
        ('', True, 'deb http://example.com/ubuntu xenial main', 'comment'),
        ('', False, 'deb http://example.com/ubuntu xenial main', ''),
        ('', False, 'deb http://example.com/ubuntu xenial main', 'comment'),
    ]

    my_module = DummyModule(params={'filename': 'filename'})
    my_sources_list = SourcesList(my_module)

    for source_list_file in source_list_files:
        my_sources_list.files = {'file': [source_list_file]}

# Generated at 2022-06-23 03:06:57.463517
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    test_base_dir = os.path.join(os.path.dirname(__file__), 'test_data')
    sl = SourcesList(AnsibleModule(argument_spec={}))
    sl.load(os.path.join(test_base_dir, 'sources.list'))
    assert sl.dump() == json.load(open(os.path.join(test_base_dir, 'sources.list.dump.json')))



# Generated at 2022-06-23 03:07:07.145153
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module:
        class args: pass

        class params:
            pass

    obj = UbuntuSourcesList(Module)
    obj.files = {
        '/etc/apt/sources.list.d/ansible-ubuntu-ansible-bionic.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', ''),
            (1, False, False, '# deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main', ''),
        ],
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic main restricted', ''),
        ],
    }
    obj.remove_source('ppa:ansible/ansible')
   

# Generated at 2022-06-23 03:07:15.199050
# Unit test for function install_python_apt
def test_install_python_apt():
    class Module:
        def __init__(self):
            self.fail_json = print
            self.run_command = lambda x: (0, 'ran command', '')
            self.check_mode = False
            self.get_bin_path = lambda x: True

    module = Module()
    try:
        import apt
        HAVE_PYTHON_APT = True
    except ImportError:
        HAVE_PYTHON_APT = False
    install_python_apt(module, 'apt')
    assert HAVE_PYTHON_APT

    module.check_mode = True
    install_python_apt(module, 'apt')
    assert not HAVE_PYTHON_APT



# Generated at 2022-06-23 03:07:24.414858
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():

    class Module(object):
        pass

    # create a fake module
    module = Module()
    module.params = {
        'filename': 'a.list'  # should be ignored
    }

    # create a fake file
    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.write(b'###testing###')
    test_file.close()

    # create a fake dir
    temp_dir = tempfile.mkdtemp()

    # create a fake apt path
    fake_apt = ''.join([temp_dir, '/apt/', '\n'])

    # monkey patch UbuntuSourcesList._apt_cfg_file

# Generated at 2022-06-23 03:07:35.853337
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # create temp directory
    temp_dir = tempfile.mkdtemp()
    # create temp files

# Generated at 2022-06-23 03:07:45.483423
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils import basic
    from ansible.module_utils import common
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import string_types
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = common.run_command
    module.debug = basic._debug
    module.log = basic._log
    module.get_bin_path = common.get_bin_path

# Generated at 2022-06-23 03:07:53.354512
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_list = [
        'deb http://example.com/ubuntu /',
        'deb-src http://example.com/ubuntu /',
    ]
    sourceslist_before = SourcesList(None)
    for line in sources_list:
        sourceslist_before.add_source(line)
    sourceslist_before.save()

    sources_before = sourceslist_before.dump()
    sourceslist = SourcesList(None)
    sourceslist.load_all()
    sources_after = sourceslist.dump()
    revert_sources_list(sources_before, sources_after, sourceslist_before)

    sourceslist_after = SourcesList(None)
    sourceslist_after.load_all()
    sources_reverted = sourceslist_after.dump()
    assert sources_before == sources_reverted

    sources_list

# Generated at 2022-06-23 03:08:05.814982
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # set up
    module = AnsibleModule(argument_spec={})
    tmp_dir = tempfile.mkdtemp()
    default_file = os.path.join(tmp_dir, 'sources.list')
    with open(default_file, 'w') as f:
        f.write('''
            deb http://ftp.debian.org/debian/ jessie main
            deb http://ftp.debian.org/debian/ jessie-updates main
            deb http://security.debian.org/ jessie/updates main
            deb http://scopes.registry.ubuntu.com/overlay.ubuntu.com/prod trusty main
        ''')
    sources = SourcesList(module)
    # test removing a source

# Generated at 2022-06-23 03:08:11.436919
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    assert os.path.exists(sources_list.default_file)



# Generated at 2022-06-23 03:08:18.361467
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    '''
    >>> sl = UbuntuSourcesList(module=None)  # doctest: +ELLIPSIS
    >>> sl.__deepcopy__()  # doctest: +ELLIPSIS
    <ansible_collections.ansible.community.plugins.module_utils.apt.UbuntuSourcesList object at ...>
    '''


# Generated at 2022-06-23 03:08:31.699873
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # test case
    result = {
        '/usr/share/doc/foo/examples/bar/baz.list': 'deb http://example.com/debian stable main\n',
        '/etc/apt/sources.list': 'deb http://example.net/debian unstable main\n',
        '/etc/apt/sources.list.d/test.list': 'deb http://test.test/debian stable main\n',
        '/etc/apt/sources.list.d/test2.list': 'deb https://test2.test/debian stable main\n'
    }
    # test code
    sl = SourcesList(None)

# Generated at 2022-06-23 03:08:40.589105
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    m = ModuleStub()
    sl = SourcesList(m)
    sl.files = {'sl.list': [(0, True, True, 'line1', 'comment1'),
                            (1, False, False, 'line2', 'comment2')]}
    sl.modify('sl.list', 0, enabled=False)
    sl.modify('sl.list', 0, source='line1 new')
    sl.modify('sl.list', 0, comment='comment1 new')
    assert sl.files == {'sl.list': [(0, True, False, 'line1 new', 'comment1 new'),
                                    (1, False, False, 'line2', 'comment2')]}

# Generated at 2022-06-23 03:08:51.373694
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {"sources-before/filename1.list":"deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n"}
    sources_after = {"sources-after/filename1.list":"deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n","sources-after/filename2.list":"deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n"}

    all_sources_list = apt.SourcesList()
    all_sources_list.add("sources-after/filename1.list","deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n")

# Generated at 2022-06-23 03:08:55.611694
# Unit test for function main
def test_main():
    module = AnsibleModule({'repo': 'http://joomla.org', 'install_python_apt': False, 'check_mode': False})
    main()
    assert module.fail_json.called


# Generated at 2022-06-23 03:08:58.335686
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('oops')
    except InvalidSource as exception:
        assert str(exception) == 'oops'



# Generated at 2022-06-23 03:09:10.383340
# Unit test for constructor of class SourcesList
def test_SourcesList():
    m = AnsibleModule(argument_spec=dict(state=dict(default='present', choices=['present', 'absent'])))
    sources = SourcesList(m)
    assert len(sources.files) == 0

    # Create two files with sources
    temp_path = tempfile.mktemp()
    open(temp_path, 'wt').write('''\
# deb http://archive.canonical.com/ubuntu hardy partner
deb http://archive.canonical.com/ubuntu hardy partner
deb-src http://archive.canonical.com/ubuntu hardy partner
''')
    sources.files[temp_path] = []
    sources.load(temp_path)

    temp_path = tempfile.mktemp()

# Generated at 2022-06-23 03:09:23.568484
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import pytest
    from ansible.module_utils.pycompat24 import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.urls import fetch_url

    Content = b"""deb http://linux.mirrors.es.net/ubuntu/ precise main restricted universe multiverse
deb-src http://linux.mirrors.es.net/ubuntu/ precise main restricted universe multiverse
# deb http://linux.mirrors.es.net/ubuntu/ precise-updates main restricted universe multiverse
# deb-src http://linux.mirrors.es.net/ubuntu/ precise-updates main restricted universe multiverse
deb http://linux.mirrors.es.net/ubuntu/ precise-security main restricted universe multiverse
deb-src http://linux.mirrors.es.net/ubuntu/ precise-security main restricted universe multiverse
"""

# Generated at 2022-06-23 03:09:37.036629
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sources = '''
# deb http://some-repo/ubuntu_version main restricted
# deb-src http://some-repo/ubuntu_version main restricted
deb http://some-repo/ubuntu_version main restricted
deb http://some-repo/ubuntu_version main
deb-src http://some-repo/ubuntu_version main
deb http://some-repo/ubuntu_version main
'''

    expected_sources = '''
# deb http://some-repo/ubuntu_version main restricted
# deb-src http://some-repo/ubuntu_version main restricted
deb http://some-repo/ubuntu_version main
deb http://some-repo/ubuntu_version main
'''

    expected_sources_list = dict([('test_sources_list', expected_sources)])


# Generated at 2022-06-23 03:09:49.976718
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # create temporary source file
    source_file = tempfile.NamedTemporaryFile()
    # add data to the source file
    source_file.write(b'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse\n')
    source_file.write(b'#deb http://archive.ubuntu.com/ubuntu/ xenial restricted\n')
    source_file.write(b'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted universe multiverse\n')
    source_file.write(b'#deb http://archive.ubuntu.com/ubuntu/ xenial-security main restricted universe multiverse\n')
    source_file.write(b'\n')

# Generated at 2022-06-23 03:09:52.496179
# Unit test for function main
def test_main():
    from ansible.module_utils import basic

    with pytest.raises(SystemExit):
        main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:10:05.615514
# Unit test for function main
def test_main():
    import inspect
    import sys

    # From Ansible
    class ModuleStub(object):
        def __init__(self):
            self.params = {
                'repo': None,
                'state': None,
                'codename': None,
            }
            self.id = ''
            self.fail_json = print
            self.exit_json = lambda **kwargs: None

        def _diff(self):
            self._diff_value = True
            return True

        def check_mode(self):
            return self._check_mode

    mod = ModuleStub()
    mod._check_mode = False
    sys.modules['ansible.module_utils.six'] = six
    sys.modules['ansible.module_utils.aptsources_list'] = mock_aptsources_list


# Generated at 2022-06-23 03:10:15.288010
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import subprocess
    import pprint

    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {}

        def get_bin_path(self, cmd):
            return '/usr/bin/%s' % cmd

        def run_command(self, args):
            return subprocess.Popen(args, stdout=subprocess.PIPE).communicate()

        def fail_json(self, msg, **kwargs):
            print(msg)
            return {'failed': True, 'msg': msg}

        def exit_json(self, **kwargs):
            return kwargs

        def atomic_move(self, src, dest):
            os.rename(src, dest)


# Generated at 2022-06-23 03:10:19.238668
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    for filename, sources in s.files.items():
        for n, valid, enabled, source, comment in sources:
            assert source == 'deb http://archive.ubuntu.com/ubuntu/ xenial universe'
            assert comment == ''
            assert not enabled
            assert valid
            assert n == 0
            assert filename == '/etc/apt/sources.list.d/mytest.list'

# Generated at 2022-06-23 03:10:23.299057
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load("tests/test_apt_repository.py")
    test_results = sources.dump()
    assert "@" not in test_results['tests/test_apt_repository.py']



# Generated at 2022-06-23 03:10:29.283916
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(
        argument_spec=dict(
            codename=dict(required=False, default=None, type='str'),
        ),
        supports_check_mode=True,
    )
    sources = UbuntuSourcesList(module)
    assert sources.codename
    assert sources.add_ppa_signing_keys_callback is None


# Generated at 2022-06-23 03:10:37.573248
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    usl = UbuntuSourcesList(module)
    usl.files = {
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible-2.5/ubuntu xenial main', '')
        ],
        '/etc/apt/sources.list.d/custom_1.list': [
            (0, True, True, 'deb [arch=amd64] http://ppa.launchpad.net/ansible/ansible-2.5-2.6/ubuntu xenial main', '')
        ]
    }
    usl.remove_source('ppa:ansible/ansible-2.5/ubuntu')

# Generated at 2022-06-23 03:10:50.737262
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    inputs = ["deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted",
              "# deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted",
              "deb [optical] http://us.archive.ubuntu.com/ubuntu/ trusty main restricted",
              "deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted # test comment",
              "# deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted # test comment",
              "deb [optical] http://us.archive.ubuntu.com/ubuntu/ trusty main restricted # test comment",
              ]


# Generated at 2022-06-23 03:10:54.875066
# Unit test for function main

# Generated at 2022-06-23 03:10:58.948205
# Unit test for function main
def test_main():
    arg = dict( repo='', state='present', mode='', update_cache=False, update_cache_retries=1, update_cache_retry_max_delay=2, filename='', install_python_apt=False, validate_certs=True, codename='')
    out = {}
    err = {}
    ret = {'msg': '',
           'updates': {}}
    result = main()

    out['u']['e'] = {'changed': False,
                     'codename': '',
                     'repo': '',
                     'state': 'present',
                     'update_cache': False,
                     'update_cache_retries': 1,
                     'update_cache_retry_max_delay': 2,
                     'validate_certs': True,
                     'filename': ''}
    ret

# Generated at 2022-06-23 03:11:13.348380
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    # Source without comment, should suggest "deb_http_archive_ubuntu_com_ubuntu_dists_xenial_main_binary_amd64_Packages gz".
    sl = SourcesList(None)
    sl.add_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    sl.save()
    assert os.path.isfile('/etc/apt/sources.list.d/deb_http_archive_ubuntu_com_ubuntu_dists_xenial_main_binary_amd64_Packages.list')

    # Source without comment and filename is passed, should be added to that file.
    sl = SourcesList(None)
    sl.add_source('deb http://archive.ubuntu.com/ubuntu xenial main', file='test')
    sl.save()

# Generated at 2022-06-23 03:11:14.499504
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    testobj = UbuntuSourcesList()
    assert id(testobj) != id(testobj.__deepcopy__())


# Generated at 2022-06-23 03:11:29.692675
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import apt
    import unittest
    import tempfile
    import shutil

    tmp_directory = tempfile.mkdtemp()
    apt_pkg_config = apt.config.AptConfig(rootdir=tmp_directory)

    class TestRevertSourcesList(unittest.TestCase):
        def test_revert_sources_list_revert_nothing(self):
            '''Test revert_sources_list does nothing if sources lists are the same.'''

            sources_before = {'/etc/apt/sources.list': 'foo\nbar\nbaz'}
            sources_after = sources_before.copy()
            sourceslist_before = UbuntuSourcesList(module=Mock(config=apt_pkg_config), add_ppa_signing_keys_callback=None)


# Generated at 2022-06-23 03:11:39.271277
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    l = UbuntuSourcesList(None)
    l.files = {'file1': [(0, True, True, 'deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian xenial contrib',
                          '# line')]}

    l.remove_source('deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian xenial contrib')
    assert l.files[list(l.files.keys())[0]][0][3] == 'deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian xenial contrib # line'

    l.remove_source('# deb [arch=amd64] http://download.virtualbox.org/virtualbox/debian xenial contrib')
    assert 'file1' not in l.files


# Generated at 2022-06-23 03:11:46.906616
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule

    class test_module(AnsibleModule):
        def run_command(command, check_rc=True):
            _temp_run_command.command = command
    _temp_run_command = test_module
    _temp_run_command.command = None
    test_module.check_mode = True
    assert get_add_ppa_signing_key_callback(test_module) is None
    test_module.check_mode = False
    assert get_add_ppa_signing_key_callback(test_module) is not None
    get_add_ppa_signing_key_callback(test_module)(['apt-key', 'adv'])

# Generated at 2022-06-23 03:11:57.675803
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    import tempfile
    import shutil

    # Define a callback function
    def run_command(*args, **kwargs):
        print(args)
        print(kwargs)
        return (0, 'out', 'err')

    test_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 03:12:09.098230
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class FauxModule(object):
        def __init__(self, fail_json_msg=None, fail=False, params=None):
            self.fail_json_msg = fail_json_msg
            self.fail = fail
            self.params = params or {}
            self.files = {}
            self.atomic_move_src = None
            self.atomic_move_dest = None
            self.atomic_move_mode = None
            self.atomic_move_orig_mode = None

        def fail_json(self, msg=None, **kwargs):
            self.fail_json_msg = msg
            self.fail = True

        def set_mode_if_different(self, dest, mode, changed):
            self.atomic_move_mode = mode


# Generated at 2022-06-23 03:12:17.047065
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic.AnsibleModule', Mock(check_mode=True)):
        assert get_add_ppa_signing_key_callback(Mock()) is None
    with patch('ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.basic.AnsibleModule', Mock(check_mode=False)):
        assert get_add_ppa_signing_key_callback(Mock()) is not None



# Generated at 2022-06-23 03:12:18.127044
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert InvalidSource('test')



# Generated at 2022-06-23 03:12:25.404339
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Test that we return None in check mode.
    module = Mock(check_mode=True)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    # Test that the callback runs the command.
    module = Mock(check_mode=False, run_command=MagicMock(return_value=(0, '', '')))
    callback = get_add_ppa_signing_key_callback(module)
    callback(['command'])
    module.run_command.assert_called_once_with(['command'], check_rc=True)



# Generated at 2022-06-23 03:12:36.578084
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    class TestModule:
        FAIL_JSON_ARGS = ['msg']

        def __init__(self):
            self.params = {
                'filename': None,
                'mode': DEFAULT_SOURCES_PERM,
            }
            self.atomic_move_successful = True


# Generated at 2022-06-23 03:12:46.964204
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})

    lines = [
        '# a comment',
        '# another comment',
        '# ppa:someuser/ppa',
        '# ppa:other/ppa',
        '',
        'deb http://ppa.launchpad.net/someuser/ppa/ubuntu xenial main',
        'deb http://ppa.launchpad.net/other/ppa/ubuntu xenial main',
        'deb file:file:/dir/dir xenial main',
        'deb http://deb.debian.org/debian wheezy main'
    ]

    obj = UbuntuSourcesList(module)
    fd, tmp_path = tempfile.mkstemp(prefix=".somefile-")

    f = os.fdopen(fd, 'w')
    f.write('\n'.join(lines))

# Generated at 2022-06-23 03:12:52.998655
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(
        argument_spec={}
    )
    sl = SourcesList(module)
    sl.add_source('deb http://hehe.ru/path/to/deb/ hehe main')
    assert len(sl.files) == 1
    line = list(sl)[0]
    assert line[2] == True
    sl.remove_source('deb http://hehe.ru/path/to/deb/ hehe main')
    assert len(sl.files) == 0


# Generated at 2022-06-23 03:12:56.257816
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    assert False


# Generated at 2022-06-23 03:12:58.186582
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert False

# Generated at 2022-06-23 03:13:03.547276
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(dict())

    def _run_command(command):
        print(' '.join(command))

    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) == _run_command


# Generated at 2022-06-23 03:13:13.304801
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources = SourcesList(module)

    # make an empty sources.list with a parsed source
    data = '''
# comment 1
deb http://archive.canonical.com/ubuntu hardy partner
# comment 2
deb-src [arch=amd64] http://archive.debian.org/debian/ sid main contrib non-free
# comment 3
'''
    fd, fname = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write(data)
    sources.load(fname)
    os.remove(fname)

    # we keep line numbers from sources.list intact

# Generated at 2022-06-23 03:13:18.692408
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sources_list_file = '''deb http://deb.debian.org/debian stretch main
deb http://deb.debian.org/debian stretch-updates main
deb http://security.debian.org stretch/updates main
# deb http://deb.debian.org/debian stretch-backports main
# deb-src http://deb.debian.org/debian stretch main
# deb-src http://deb.debian.org/debian stretch-updates main
# deb-src http://security.debian.org stretch/updates main
# deb-src http://deb.debian.org/debian stretch-backports main
'''
    sources_list_test_file = None

# Generated at 2022-06-23 03:13:30.589636
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''
    Test that a line in the sources list can be modified by passing the index
    of the line.
    '''
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    file = '/tmp/test_sources.list'
    line = 'deb http://archive.ubuntu.com/ubuntu xenial main'
    comment = 'test'
    with open(file, 'w') as f:
        f.write(line + '\n')
    sl.load(file)
    sl.modify(file, 0, comment=comment)
    sl.save()
    with open(file, 'r') as f:
        assert f.read() == line + ' # ' + comment + '\n'
    os.remove(file)



# Generated at 2022-06-23 03:13:42.436606
# Unit test for function install_python_apt
def test_install_python_apt():
    def run_module(module_args, check_mode=False):
        module_args['_ansible_check_mode'] = check_mode
        module_args['_ansible_diff'] = False

        module_name = 'apt_repository'
        module_path = 'ansible.builtin.apt_repository'
        module_class = getattr(__import__(module_path, fromlist=[module_name]), module_name)


# Generated at 2022-06-23 03:13:52.263508
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sources = SourcesList(module)

    # Test with both dos and unix line endings
    sources.load("../test/apt_repository_tests/input/dos_line_endings.list")

# Generated at 2022-06-23 03:14:03.094107
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # build a simple mock module with given parameters
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def fail_json(self, *args, **kwargs):
            assert False, "fail_json called with %s %s" % (args, kwargs)

        def get_bin_path(self, arg):
            return None

        @staticmethod
        def atomic_move(src, dst):
            os.rename(src, dst)

        @staticmethod
        def set_mode_if_different(src, dst, b):
            pass

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # build a default sources.list file
    default_file = os.path.join(tmpdir, 'sources.list')

# Generated at 2022-06-23 03:14:14.739687
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class AnsibleModule():
        def __init__(self):
            self.params = {
                'state': 'present',
                'repo': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted',
                'filename': None,
                'update_cache': None,
                'cache_valid_time': None,
                'valid_certs_only': None,
                'validate_certs': None,
                'enforce_tools': None,
                'autoclean': None,
                'mode': None
            }
            self.fail_json = fail_json
        def atomic_move(self, tmp_path, filename):
            pass
        def get_bin_path(self, bin_path):
            pass
        def run_command(self, cmd):
            pass

# Generated at 2022-06-23 03:14:27.282094
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # In order to test this class, we'll actually invoke the module directly.
    # This is much easier than trying to mock AnsibleModule (and its attendant
    # params and fails json methods, etc)
    argument_spec = dict(
        name=dict(type='list', required=True),
        state=dict(default='present', choices=['absent', 'present']),
        mode=dict(type='raw'),
        filename=dict(type='str'),
        update_cache=dict(type='bool', default=False),
        validate_certs=dict(type='bool', default=True),
        codename=dict(type='str'),
        dist=dict(type='str'),
    )

# Generated at 2022-06-23 03:14:37.113614
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    module.fail_json = lambda **kwargs: exit(1)

    def mock_Config_FindDir(dirspec):
        return '/tmp'

    apt_pkg.Config.FindDir = mock_Config_FindDir

    content = '''#comment
deb http://mirror.yandex.ru/ubuntu/ precise main restricted
[arch=amd64,i386] deb http://archive.canonical.com/ubuntu/ natty partner
deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main
# deb http://mirror.yandex.ru/ubuntu/ precise main restricted # removed
        '''
    with open(os.path.join('/tmp', 'sources.list'), 'w') as f:
        f.write(content)

    # SourcesList

# Generated at 2022-06-23 03:14:38.195166
# Unit test for function install_python_apt
def test_install_python_apt():
    assert 0 == 0



# Generated at 2022-06-23 03:14:47.265660
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'/etc/apt/sources.list.d/abc.list': 'abc\ndef\n'}
    sources_after = {'/etc/apt/sources.list.d/abc.list': 'abc\n'}

    os.makedirs('/etc/apt/sources.list.d')
    open('/etc/apt/sources.list.d/abc.list', 'w').write('abc\ndef\n')
    sourceslist_before = SourcesList(None)
    sourceslist_before.load('/etc/apt/sources.list.d/abc.list')

    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert os.path.exists('/etc/apt/sources.list.d/abc.list')


# Generated at 2022-06-23 03:14:59.442482
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.params = {}

    sources = SourcesList(module)
    sources.load("tests/unittest/ansible_test_sources.list")

    assert len(sources.files) == 1
    assert sources.files["tests/unittest/ansible_test_sources.list"]

    assert len(sources.files["tests/unittest/ansible_test_sources.list"]) == 5

    assert sources.files["tests/unittest/ansible_test_sources.list"][0][1] == True
    assert sources.files["tests/unittest/ansible_test_sources.list"][0][2] == True

# Generated at 2022-06-23 03:15:09.778408
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({}, {}, [])
    sourceslist = SourcesList(module)
    sourceslist.load('tests/apt_repository.sourceslist')

# Generated at 2022-06-23 03:15:22.716345
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class AnsibleModuleFake(object):
        def __init__(self):
            self.params = dict()
        def fail_json(self, msg):
            raise AssertionError(msg)
        def atomic_move(self, src, dst):
            pass
        def get_bin_path(self, binary):
            return '/usr/bin/'+binary
        def set_mode_if_different(self, path, mode, changed):
            pass

    am = AnsibleModuleFake()

    sl = SourcesList(am)

    sl.modify('/etc/apt/sources.list', 0, source='# deb http://download.virtualbox.org/virtualbox/debian trusty contrib')

# Generated at 2022-06-23 03:15:31.171279
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sl = UbuntuSourcesList(module)
    assert(module == sl.module)
    assert(apt_pkg.upstream_version(distro.codename) == sl.codename)
    del sl

    module = AnsibleModule(argument_spec={'codename': {'type': 'str'}})
    module.params['codename'] = 'precise'
    sl = UbuntuSourcesList(module)
    assert(module == sl.module)
    assert(apt_pkg.upstream_version('precise') == sl.codename)
    del sl


# Generated at 2022-06-23 03:15:42.609558
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.utils.path import unfrackpath

    class TestAptModule(object):
        class AnsibleModule(object):
            def __init__(self, *args):
                self.args = args

        def __init__(self):
            self.called = False

        def fail_json(self, msg):
            self.called = True
            self.msg = msg

        def atomic_move(self, src, dst):
            pass

        def check_mode(self):
            return False

        def get_bin_path(self, bin):
            return '/usr/bin/%s' % bin

        def run_command(self, cmd):
            return 0,

# Generated at 2022-06-23 03:15:47.036453
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = FakeModule(params={})
    obj = SourcesList(module)
    try:
        obj.save()
    except AttributeError:
        pass
    else:
        assert False, "GOT: %s" % obj.save()


# Generated at 2022-06-23 03:15:48.075042
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass  # Nothing to unit test



# Generated at 2022-06-23 03:15:52.882527
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.common._collections_compat import OrderedDict
    test_obj = SourcesList(None)
    test_obj.load("my_file")
    assert type(test_obj.files) == OrderedDict



# Generated at 2022-06-23 03:16:02.898128
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import ansible.module_utils.basic
    import ansible.module_utils.pycompat24
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.json_utils
    import ansible.module_utils.network.common.utils
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils.six.moves import http_client
    from ansible.module_utils.six.moves import urllib
    from ansible.module_utils.six.moves import xmlrpc_client

# Generated at 2022-06-23 03:16:09.261221
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    test_mod = AnsibleModule(argument_spec={})
    test_mod.exit_json = lambda x: x
    result = test_mod.exit_json({})
    test_sources_list = SourcesList(test_mod)

    test_sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner # canonical partner')
    result['result']['/etc/apt/sources.list'] = {
        'changes_have_been_made': True,
        'dump': 'deb-src http://archive.canonical.com/ubuntu hardy partner # canonical partner\n'
    }

    test_sources_list.add_source('# deb http://archive.canonical.com/ubuntu hardy partner # canonical partner')