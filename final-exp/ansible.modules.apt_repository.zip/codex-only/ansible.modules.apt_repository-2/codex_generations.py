

# Generated at 2022-06-23 03:06:13.284475
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    """Unit test for remove_source method of class UbuntuSourcesList

    The test is done by starting the method remove_source of UbuntuSourcesList
    and checking if the output of the method is correct.

    :param none:
    :return: test passed
    """

    line = "deb http://ppa.launchpad.net/ansible/ansible-2.7/ubuntu trusty"
    a = UbuntuSourcesList(None)
    a.add_source(line)
    a.remove_source(line)
    assert(line not in a.repos_urls)
    return True


# Generated at 2022-06-23 03:06:25.380594
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # Mock imports
    import tempfile
    import os

    import ansible.module_utils.basic
    import ansible.module_utils.six.moves.shutil_ansible_moves as shutil_ansible_moves

    from ansible.module_utils.six import StringIO

    class MockModule:
        def __init__(self):
            self.fail_json_called = False
            self.exit_args = {}
            self.atomic_move_called = False
            self.set_mode_if_different_called = False

        def fail_json(self, msg):
            self.fail_json_called = True
            raise Exception(msg)

        def exit_json(self, **kwargs):
            self.exit_args = kwargs


# Generated at 2022-06-23 03:06:33.108065
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})

    test_object = UbuntuSourcesList(module)

    assert type(test_object) is UbuntuSourcesList
    assert os.path.isfile(test_object.default_file)



# Generated at 2022-06-23 03:06:45.436231
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert not sources._apt_cfg_file('no-such-file')
    assert not sources._apt_cfg_dir('no-such-dir')

    file1 = '/etc/apt/sources.list'
    file2 = '/etc/apt/sources.list.d/file2.list'
    file3 = '/etc/apt/sources.list.d/file3.list'

    for f in (file1, file2, file3):
        open(f, 'w').close()

    sources.load(file1)
    sources.load(file2)
    sources.load(file3)

    # Simple iterator
    lines = []
    for file, n, enabled, source, comment in sources:
        lines.append

# Generated at 2022-06-23 03:06:54.087807
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule({
        'filename': None,
        'update_cache': True,
        'repos': [ 'ppa:kirillshkrogalev/ffmpeg-next', 'ppa:network-manager/ppa' ],
        'mode': None,
        'state': 'present',
    }, {})

    ap = UbuntuSourcesList(module)

    ap.add_source('ppa:kirillshkrogalev/ffmpeg-next')
    assert('ppa:kirillshkrogalev/ffmpeg-next' in ap.repos_urls)
    assert('deb http://ppa.launchpad.net/kirillshkrogalev/ffmpeg-next/ubuntu xenial main' in ap.repos_urls)



# Generated at 2022-06-23 03:07:03.842008
# Unit test for function install_python_apt
def test_install_python_apt():
    # Cannot test on non-debian platform
    if apt_pkg is None:
        pass
    else:
        # Case 1:
        #########
        # Install python-apt from a PPA repository
        ppa_repo_str = "ppa:u/ppa-repo"
        ppa_repo_file = "/etc/apt/sources.list.d/u-ppa-repo-%s.list" % ppa_repo_str.split(':')[1]
        test_module = apt_repo_mock(check_mode=False, repo=ppa_repo_str, state='present')
        install_python_apt(test_module, 'python-apt')
        assert apt_pkg is not None
        # The auto-install succeeded
        # Clean up

# Generated at 2022-06-23 03:07:09.488330
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class TestModule(object):
        pass
    test_module = TestModule()
    test_module.params = {}
    test_module.fail_json = lambda msg, **kwargs: msg
    test_module.atomic_move = lambda src, dst: None
    sls = SourcesList(test_module)
    filename = '/tmp/test-1.list'
    sls.files[filename] = [(0, True, True, 'line0', None), (1, True, True, 'line1', None), (2, False, False, 'line2', None), (3, True, False, 'line3', 'comment'), (4, True, True, 'line4', None)]
    dumpstruct = sls.dump()


# Generated at 2022-06-23 03:07:13.688386
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sources = SourcesList()
    for file in ['/etc/apt/sources.list', '/etc/apt/sources.list.d/test.list']:
        with open(file, 'w') as f:
            f.write('''# Test sources.
''')
    sources.load('/etc/apt/sources.list')
    sources.load('/etc/apt/sources.list.d/test.list')

    assert len(sources.files) == 2

    for filename, sources in sources.files.items():
        assert len(sources) == 1

        n, valid, enabled, source, comment = sources[0]
        assert n == 0
        assert not valid
        assert not enabled
        assert source == ''
        assert comment == 'Test sources.'


# Generated at 2022-06-23 03:07:24.204654
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    """
    Test for method `UbuntuSourcesList.add_source`
    """
    import requests
    import urllib.parse

    # Dummy class for module.params
    class _DummyModule(object):
        params = {
            'filename': None,
            'codename': 'codename'
        }

    # Dummy class for module.run_command
    class _DummyRunCommand(object):
        def run_command(self, command, check_rc=True):
            pass

    # Dummy class for module.atomic_move
    class _DummyAtomicMove(object):
        def atomic_move(self, tmp_path, filename):
            pass

    # Dummy class for module.set_mode_if_different

# Generated at 2022-06-23 03:07:36.297872
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    '''
    Create test dir
    '''
    test_dir = tempfile.mkdtemp()
    test_apt_cfg_dir = os.path.join(test_dir, 'etc', 'apt')
    test_apt_sourceparts_dir = os.path.join(test_apt_cfg_dir, 'sources.list.d')
    test_apt_sourcelist_file = os.path.join(test_apt_cfg_dir, 'sources.list')
    os.makedirs(test_apt_sourceparts_dir)

    # Create some junk in the sources.list.d dir.
    test_junk_1 = os.path.join(test_apt_sourceparts_dir, 'junk1.list')
    f = open(test_junk_1, 'w')
    f.write

# Generated at 2022-06-23 03:07:45.155183
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Prepare test data
    line = "ppa:ansible/ansible"
    comment = "This is a comment"

    # Prepare test inputs
    module = MagicMock()
    module.params = {
        "codename": "xenial",
        "filename": None,
        "mode": None
    }
    module.run_command.return_value = (0, "", "")

    # Prepare tested class
    sources_list = UbuntuSourcesList(module)

    # Execute tested code
    sources_list.add_source(line, comment)

    assert "deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n" == sources_list.dump()[sources_list.default_file]

# Generated at 2022-06-23 03:07:52.266088
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Init
    module = AnsibleModule(dict(file='/tmp/apt_repository'))
    filename = '/tmp/apt_repository'
    comment = 'comment'
    source_types = ['deb', 'deb-src']
    source_1 = source_types[random.randint(0, len(source_types) - 1)]+' http://'+str(random.randint(0, 100))
    source_2 = source_types[random.randint(0, len(source_types) - 1)]+' http://'+str(random.randint(0, 100))
    sources = [source_1, source_2]
    lines = []

    # Setup
    # create sources
    sl = SourcesList(module)

# Generated at 2022-06-23 03:08:04.346219
# Unit test for function main

# Generated at 2022-06-23 03:08:13.442488
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import sys

    # Create simple implementation of ansible module.
    class FakeModule():
        pass

    fake_module = FakeModule()

    # Create simple implementation of atomic_move method.
    def fake_atomic_move(src, dst):
        pass

    setattr(fake_module, 'atomic_move', fake_atomic_move)

    # Create simple implementation of set_mode_if_different method.
    def fake_set_mode_if_different(src, dst):
        pass

    setattr(fake_module, 'set_mode_if_different', fake_set_mode_if_different)

    # Create simple implementation of fail_json method.
    def fake_fail_json(msg):
        sys.exit(1)

    setattr(fake_module, 'fail_json', fake_fail_json)

    # Create

# Generated at 2022-06-23 03:08:26.962200
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    group = [
        (1, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner'),
        (2, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner'),
        (3, False, True, 'deb http://archive.canonical.com/ubuntu hardy partner'),
        (4, True, True, 'deb-src http://archive.canonical.com/ubuntu hardy partner'),
        (5, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner # this is a comment'),
        (6, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner')
    ]
    s = SourcesList(None)
    s.files['./file'] = group

# Generated at 2022-06-23 03:08:38.013465
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    import copy
    import types

    mock = {
        'codename': 'bionic',
        '_repositories': []
    }
    mock_module = types.SimpleNamespace(**mock)
    mock_module.params = {}
    mock_module.params['codename'] = 'bionic'
    mock_module.params['filename'] = None
    mock_module.params['mode'] = None
    mock_module.params['state'] = None
    mock_module.params['update_cache'] = None
    mock_module.params['update_cache_timeout'] = None
    mock_module.params['validate_certs'] = None
    mock_module.params['proxy_host'] = None
    mock_module.params['proxy_port'] = None

# Generated at 2022-06-23 03:08:41.717838
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None


# Generated at 2022-06-23 03:08:53.240481
# Unit test for function install_python_apt
def test_install_python_apt():
    # setup
    m = AnsibleModule(
        argument_spec=dict(
            install_python_apt=dict(type='bool', default=True),
            apt_pkg_name=dict(type='str', default='python-apt'),
        )
    )
    m.run_command = MagicMock(return_value=(0, '', ''))
    m.get_bin_path = MagicMock(return_value='/usr/bin/apt-get')
    # run
    install_python_apt(m, 'python-apt')
    # assert
    assert m.run_command.call_count == 2



# Generated at 2022-06-23 03:09:00.237244
# Unit test for function install_python_apt
def test_install_python_apt():
    class FakeAnsibleModule:
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda command, **kwargs: (0, "", "")
        def get_bin_path(self, binary):
            return binary

    fake_module = FakeAnsibleModule()

    install_python_apt(fake_module, "python3-apt")


# Generated at 2022-06-23 03:09:06.697980
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before  = {'a': 'a\nb\nc\n', 'b': '1\n2\n3\n'}
    sources_after = {'a': 'a\nb\nc\n', 'b': '1\n2\n3\n', 'c': '4\n5\n'}
    sourceslist_before = simple_sourceslist()
    # don't run really
    sourceslist_before.save = lambda: False

    revert_sources_list(sources_before, sources_after, sourceslist_before)
    # NOTE: as we return None, there is no real way to check that file was removed
    # (other than by checking system state).


# Generated at 2022-06-23 03:09:17.594688
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import io
    import sys
    from ansible.module_utils.ansible_release import __version__
    from ansible.module_utils.basic import AnsibleModule

    class TestModule(AnsibleModule):
        def __init__(self):
            pass
        @staticmethod
        def fail_json(msg):
            sys.stderr.write("FAIL: %s\n" % msg)
        @staticmethod
        def _apt_cfg_file(filespec):
            return os.path.join(os.path.dirname(__file__), filespec)
        @staticmethod
        def _apt_cfg_dir(dirspec):
            return os.path.join(os.path.dirname(__file__), dirspec)
        @staticmethod
        def get_bin_path(name):
            return

# Generated at 2022-06-23 03:09:20.345976
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = MagicMock()
    ubuntu_sources_list = UbuntuSourcesList(module)
    assert module is ubuntu_sources_list.module



# Generated at 2022-06-23 03:09:28.797354
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({}, supports_check_mode=True)
    sources = SourcesList(module)
    sources.files = {}
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty multiverse', comment='test comment 1')
    assert len(sources.files) == 1
    assert 'test comment 1' in sources.files.values()[0][-1][-1]
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty multiverse', comment='test comment 2')
    assert len(sources.files) == 1
    assert 'test comment 2' in sources.files.values()[0][-1][-1]

# Generated at 2022-06-23 03:09:35.054066
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Create an object of class UbuntuSourcesList
    class module:
        def fail_json(self, msg):
            print("Failed to remove source: %s" % (msg))
    module = module()

    # Method __init__()
    obj = UbuntuSourcesList(module)
    # Method _expand_ppa()
    obj._expand_ppa('ppa:user/repo')


# Generated at 2022-06-23 03:09:41.015198
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = dict(sources.list_file)
    sourceslist = SourcesList(module)
    sourceslist_before = deepcopy(sourceslist)
    sourceslist.save()
    sources_after = sourceslist.dump()

    sourceslist = SourcesList(module)
    sourceslist.add_source('deb http://us.archive.ubuntu.com/ubuntu/ trusty main')
    sourceslist.save()
    revert_sources_list(sources_before, sources_after, sourceslist_before)



# Generated at 2022-06-23 03:09:50.256321
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module_params = dict(codename='yakkety')
    u = UbuntuSourcesList(module=None, **module_params)
    u._add_valid_source("deb http://ppa.launchpad.net/ansible/ansible-2.6/ubuntu yakkety main", "", "ansible-2.6.list")
    assert len(u.files[u.default_file]) == 1
    u.remove_source("deb http://ppa.launchpad.net/ansible/ansible-2.6/ubuntu yakkety main # Description")
    assert len(u.files[u.default_file]) == 0
    u._add_valid_source("deb http://ppa.launchpad.net/ansible/ansible-2.6/ubuntu yakkety main", "", "ansible-2.6.list")


# Generated at 2022-06-23 03:10:00.182248
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    Test method __iter__ of class SourcesList
    '''

    sl = SourcesList(None)
    sl.load(os.path.join(os.path.dirname(__file__), 'apt_repository_test_data', 'sources.list'))

    result = list(sl)
    assert len(result) == 3

    # Test 1st source
    file, n, enabled, source, comment = result[0]

    assert file.endswith('sources.list')
    assert n == 0
    assert enabled
    assert source == 'deb http://old-releases.ubuntu.com/ubuntu/ raring main restricted universe multiverse'
    assert comment == ''

    # Test 2nd source
    file, n, enabled, source, comment = result[1]


# Generated at 2022-06-23 03:10:10.537238
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sl = SourcesList(AnsibleModule(argument_spec={}))
    sl.files = {
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://archive.ubuntu.com/ubuntu precise main restricted', ''),
            (1, True, False, 'deb http://archive.ubuntu.com/ubuntu precise-proposed restricted main universe multiverse', 'hello'),
        ]
    }
    assert sl.dump() == {
        '/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu precise main restricted\n'
                                 '# deb http://archive.ubuntu.com/ubuntu precise-proposed restricted main universe multiverse # hello\n'
    }



# Generated at 2022-06-23 03:10:21.708375
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class FakeModule:
        def fail_json(self, msg):
            print("FAILED: %s" % msg)

    class FakeFile:
        def __init__(self, content):
            self.content = content

        def write(self, line):
            self.content.append(line.rstrip())

        def close(self):
            pass

    module = FakeModule()
    sources = SourcesList(module)
    filenames = []
    filenames_expand = []
    filenames_expand.append(os.path.abspath('/etc/apt/sources.list.d/fake_line1.list'))
    filenames_expand.append(os.path.abspath('/etc/apt/sources.list.d/fake_line2.list'))
   

# Generated at 2022-06-23 03:10:31.261267
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class TestModule(object):
        """ Fake module class for unit testing """

        def __init__(self, files, fvs=None):
            self.params = {}
            self.repofiles = files
            self.fvs = fvs

        def get_bin_path(self, binary):
            """ Fake get_bin_path for unit testing """

            return '/bin/direct/path'

        @staticmethod
        def run_command(*args, **kwargs):
            """ Fake run_command for unit testing """

            return 0, 'stdout', 'stderr'

        @staticmethod
        def fail_json(*args, **kwargs):
            """ Fake fail_json for unit testing """

            if 'msg' in kwargs:
                raise RuntimeError(kwargs['msg'])
            raise RuntimeError('Unspecified error')

# Generated at 2022-06-23 03:10:39.178077
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sl = SourcesList(None)
    sl.files = {
        '/etc/apt/sources.list': [
            (0, False, True, '# deb-src http://archive.canonical.com/ubuntu precise partner', ''),
            (1, True, True, 'deb http://archive.canonical.com/ubuntu precise partner', ''),
        ],
        '/etc/apt/sources.list.d/nginx.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main', '#Added by PPA'),
            (1, True, True, 'deb-src http://ppa.launchpad.net/nginx/stable/ubuntu trusty main', '#Added by PPA'),
        ]
    }

# Generated at 2022-06-23 03:10:44.764618
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    test_obj = SourcesList(AnsibleModule(argument_spec={}, bypass_checks=True))
    assert test_obj.modify('file/name', 2, source='source', enabled=True, comment='comment')


# Generated at 2022-06-23 03:10:53.645269
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    sl = SourcesList(module)

    d = tempfile.mkdtemp()
    os.chdir(d)

    sl.load('sources.list')

    sources_list_entries = {'line1': 'deb line1', 'source': 'deb [arch=amd64] https://test',
                            'comment': 'deb [arch=amd64] https://test #test', 'disabled': '#deb [arch=amd64] https://test'}
    for name, line in sources_list_entries.items():
        sl.add_source(line)
        sl.save()

# Generated at 2022-06-23 03:11:02.075028
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import apt_repository
    p = apt_repository.AnsibleModule(argument_spec={})
    p.atomic_move = None
    p.set_mode_if_different = None

    s = apt_repository.SourcesList(p)
    s.save()

    assert not os.path.isfile("/etc/apt/sources.list.new")

# Generated at 2022-06-23 03:11:13.494497
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources_list = UbuntuSourcesList(MagicMock())

# Generated at 2022-06-23 03:11:29.196010
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    classes = [
        {
            "name": "Python 2",
            "apt_pkg_module": "apt_pkg",
            "aptsources": "aptsources"
        }
    ]

    if PY3:
        classes.append({
            "name": "Python 3",
            "apt_pkg_module": "apt",
            "aptsources": "apt_pkg"
        })

    for py_class in classes:
        # set up mocks
        sys.modules['apt'] = apt = imp.new_module('apt')
        sys.modules['apt_pkg'] = apt_pkg = imp.new_module('apt_pkg')
        sys.modules['aptsources'] = imp.new_module('aptsources')

# Generated at 2022-06-23 03:11:39.104051
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line_commented= '#deb  http://archive.canonical.com/ubuntu  hardy  partner'
    line_enabled= 'deb-src http://archive.canonical.com/ubuntu hardy partner'
    list=SourcesList('')
    list.files[list.default_file]= []
    list.files[list.default_file].append( (0, True, True, line_enabled, '') )
    list.files[list.default_file].append( (1, True, False, line_commented, '') )
    list.remove_source(line_commented)
    assert len(list.files[list.default_file]) == 1
    assert (0, True, True, line_enabled, '') == list.files[list.default_file][0]


# Generated at 2022-06-23 03:11:52.048145
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    m = AnsibleModule(
        argument_spec=dict(
            state=dict(type='str', choices=['absent', 'present'], default='present'),
            source=dict(type='str', required=True),
            comment=dict(type='str', default=''),
            filename=dict(type='str', default=None),
            update_cache=dict(type='bool', default=False),
            keyserver=dict(type='str', default='hkp://keyserver.ubuntu.com:80'),
            key=dict(type='str', default=None)
        ),
        supports_check_mode=True
    )
    ppa = 'ppa:foo/bar'
    sources_list = UbuntuSourcesList(m)
    sources_list.add_source(ppa, 'added by ansible')
    assert sources_

# Generated at 2022-06-23 03:11:59.672001
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    module = AnsibleModule({
        '_ansible_check_mode': True,
        '_ansible_no_log': False,
        '_ansible_debug': True,
    }, check_invalid_arguments=False)
    a = get_add_ppa_signing_key_callback(module)
    assert a is None

    module = AnsibleModule({
        '_ansible_check_mode': False,
        '_ansible_no_log': False,
        '_ansible_debug': True,
    }, check_invalid_arguments=False)
    a = get_add_ppa_signing_key_callback(module)
    assert a is not None
   

# Generated at 2022-06-23 03:12:03.824191
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    obj = SourcesList(module)
    line = "deb http://www.example.com/debian squeeze main"
    obj.remove_source(line)
    # if the file name is in files, it means that the line exists in files.
    assert obj.files.get('/etc/apt/sources.list') == None


# Generated at 2022-06-23 03:12:12.850816
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    u = UbuntuSourcesList(module)
    u.files['file1'] = [(0, True, True, 'ppa:test', '')]
    u.files['file2'] = [(0, True, True, 'http://test', '')]
    u.files['file3'] = [(0, True, True, 'deb http://ppa.launchpad.net/test/test/ubuntu xenial main', '')]

    u.remove_source('ppa:test')
    assert u.files['file1'] == [(0, True, False, 'ppa:test', '')]
    assert set(u.files.keys()) == set(['file1', 'file2', 'file3'])

    u.remove_source('http://test')

# Generated at 2022-06-23 03:12:18.074163
# Unit test for constructor of class SourcesList
def test_SourcesList():
    params = dict(
        repo='deb http://example.com/ubuntu/ vivid main',
        state='present',
    )
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    module.params = params
    sources_list = SourcesList(module)
    assert sources_list is not None



# Generated at 2022-06-23 03:12:27.364391
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = DummyAnsibleModule()
    lines = [
        'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main',
        'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main',
        'deb http://www.example.com xenial main'
    ]
    expected = [
        'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main',
        'deb http://www.example.com xenial main'
    ]
    sources_list = UbuntuSourcesList(module)

    for line in lines:
        sources_list.add_source(line)

    sources_list.remove_source(lines[0])

    dump = sources_list.dump()
    assert len(dump) == 1

# Generated at 2022-06-23 03:12:39.574045
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    Test case for add_source method of class SourcesList
    '''

    def _assert_sources_list(default_file, sources_list_file, test_case):
        sources_list_file = sources_list_file.splitlines()
        with open(default_file, "r") as sources_list_file:
            for index, line in enumerate(sources_list_file):
                if line.strip() != sources_list_file[index].strip():
                    raise AssertionError("Sources list does not match with test case {0} (line {1}).".format(test_case, index+1))


# Generated at 2022-06-23 03:12:41.386891
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    with pytest.raises(Exception):
        raise InvalidSource("This is an invalid source")


# Generated at 2022-06-23 03:12:50.147339
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Here we have a source that we want to remove and some source
    # that we don't want to remove.  The source that we want to remove
    # is in a file that contains other sources.  The source that we don't
    # want to remove is in a file that contains only that one source.
    # We're checking that when we call remove_source, only the source
    # that we want to remove is removed.
    sl = SourcesList.__new__(SourcesList)

# Generated at 2022-06-23 03:13:00.915986
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({'jump':2})
    module.params = {}
    module.params['codename'] = 'Yakkety'
    module.params['mode'] = '0400'
    distro.codename = 'Yakkety'

    ubuntu_sources_list = UbuntuSourcesList(module)

    module.params['filename'] = 'ansible_test_sourcelist.list'
    ubuntu_sources_list.add_source('deb http://example.com/ubuntu yakkety main', 'Ansible Test')
    ubuntu_sources_list.save()
    ubuntu_sources_list.remove_source('deb http://example.com/ubuntu yakkety main')
    os.remove('/etc/apt/sources.list.d/ansible_test_sourcelist.list')



# Generated at 2022-06-23 03:13:03.196987
# Unit test for constructor of class SourcesList
def test_SourcesList():
    s = SourcesList(None)
    assert len(s.files) == 0


# Generated at 2022-06-23 03:13:13.077097
# Unit test for function main

# Generated at 2022-06-23 03:13:20.559610
# Unit test for function main

# Generated at 2022-06-23 03:13:33.626268
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    src_list = SourcesList(None)
    src_list.files = {'/root/test.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic main', ' '),
                                          (1, True, False, 'deb http://archive.ubuntu.com/ubuntu bionic main universe', ' '),
                                          (2, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic universe', ' ')]}

    # The expected result
    expected_list = copy.deepcopy(src_list.files)
    expected_list['/root/test.list'].remove((0, True, True, 'deb http://archive.ubuntu.com/ubuntu bionic main', ' '))

    src_list.remove_source('deb http://archive.ubuntu.com/ubuntu bionic main')



# Generated at 2022-06-23 03:13:44.083919
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class DummyModule(object):
        def __init__(self, *args, **kwargs):
            self._module = AnsibleModule(*args, **kwargs)

        def module(self):
            return self._module

        def check_mode(self):
            return False

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/apt-get'

        def run_command(self, *args, **kwargs):
            return 0, '', ''

        def fail_json(self, *args, **kwargs):
            self._module.fail_json(*args, **kwargs)

        def atomic_move(self, *args, **kwargs):
            pass

        def set_mode_if_different(self, *args, **kwargs):
            pass

    module = D

# Generated at 2022-06-23 03:13:56.442520
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    s = SourcesList(AnsibleModule(argument_spec={}))
    s.files = {
        '/etc/apt/sources.list': [(1, True, True, 'src1', 'comment1'),
                                  (2, False, False, 'src2', 'comment2'),
                                  (3, True, False, 'src3', 'comment3')],
        '/etc/apt/sources.list.d/some.list': [(4, False, False, 'src4', 'comment4'),
                                              (5, True, True, 'src5', 'comment5')],
        '/etc/apt/sources.list.d/another.list': [(6, True, True, 'src6', 'comment6')]}

# Generated at 2022-06-23 03:14:07.973200
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic

    # first we create a module instance and test the removal of an apt-get source
    module_test = ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic.AnsibleModule(argument_spec={
        'filename': dict(
            type='str',
            required=False,
            default=None,
        ),
        'mode': dict(
            type='str',
            required=False,
            default=None,
        ),
    })
    apt_sources_list = UbuntuSourcesList(module=module_test)
    # we're adding a source to the file test.list
    ## we're creating the file

# Generated at 2022-06-23 03:14:08.690752
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass



# Generated at 2022-06-23 03:14:10.640932
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    with pytest.raises(InvalidSource):
        raise InvalidSource("source is invalid, contains invalid characters")


# Generated at 2022-06-23 03:14:11.962177
# Unit test for function main
def test_main():
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:14:24.229889
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # Execute cmd with user input injection
    def run_with_inject(cmd, data=None):
        if data:
            # Set the input data n the stdin process
            sys.stdin = data
        return run_command(module, cmd, check_rc=True)

    # Disable PYTHONHASHSEED so that the results are consistent
    os.environ['PYTHONHASHSEED'] = '0'

    # Specify Python interpreter location
    # This is needed to avoid AnsibleModule respawning itself when it can't find the interpreter

# Generated at 2022-06-23 03:14:36.409445
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.files == {}

    # Test for loading sources from etc/apt/sources.list
    assert _to_lines(sources.dump()) == [
        None,
        '# deb http://archive.ubuntu.com/ubuntu/ hardy main restricted universe multiverse\n',
        '# deb http://archive.ubuntu.com/ubuntu/ hardy-updates main restricted universe multiverse\n',
        'deb http://archive.ubuntu.com/ubuntu/ hardy-security main restricted universe multiverse\n'
    ]

    # Test for loading sources from etc/apt/sources.list.d

# Generated at 2022-06-23 03:14:46.764654
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class Module:
        def __init__(self):
            self.params = {}

    module = Module()

    # Empty file
    sl = SourcesList(module)
    sl.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/files/empty.list')
    assert sl.files == {
        'tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/files/empty.list':
            [(0, False, False, '', '')]
    }

    # Invalid lines
    sl = SourcesList(module)
    sl.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/files/invalid.list')

# Generated at 2022-06-23 03:14:48.447277
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
  assert True



# Generated at 2022-06-23 03:14:57.426717
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    import requests
    setattr(requests, 'codes', requests.codes)
    setattr(requests.codes, 'ok', requests.codes.ok)
    setattr(requests, 'get', requests.get)
    setattr(requests, 'post', requests.post)

    from ansible.module_utils.six import StringIO

    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['filename'] = 'sources.list'
    module.tmpdir = '/tmp/'
    module.run_command = run_command_mock
    module.set_mode_if_different = set_mode_if_different_mock
    module.fail_json = fail_json_mock
    module.params['codename'] = 'trusty'

    m_open = mock_

# Generated at 2022-06-23 03:15:07.320928
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:15:15.041208
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """Unit test for method remove_source of class SourcesList"""
    module=AnsibleModule(argument_spec={})
    obj = SourcesList(module)
    obj.load(unit_test=True)
    obj.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert({'sources_list_file': None} == obj.dump())
    pass

# Generated at 2022-06-23 03:15:20.903535
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python3-apt'
    module = AnsibleModule({'install_python_apt': True})
    if PY3:
        install_python_apt(module, apt_pkg_name)
    else:
        with pytest.raises(SystemExit):
            install_python_apt(module, apt_pkg_name)

# Check whether Python apt is installed, try to install it if auto_install_python_apt is set to True

# Generated at 2022-06-23 03:15:31.986073
# Unit test for function install_python_apt
def test_install_python_apt():
    module = _get_empty_module_mock()
    module.check_mode = False
    module.get_bin_path.return_value = 'apt-get'
    python_apt_lib = "python3-apt"
    # apt-get update
    module.run_command.return_value = (0, '', '')
    install_python_apt(module, python_apt_lib)
    module.run_command.assert_called_with(['apt-get', 'update'])
    # apt-get install
    module.run_command.side_effect = [
        (0, '', ''),
        (0, '', '')
    ]
    install_python_apt(module, python_apt_lib)

# Generated at 2022-06-23 03:15:41.791021
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = object()
    sl = SourcesList(module)

    sl.files = {'/etc/apt/sources.list': [
        (0, True, True, 'deb http://example.com/debian distribution component1 component2', 'comment1'),
        (1, True, True, 'deb http://example.com/debian distribution component1 component2', 'comment2'),
        (2, True, True, 'deb http://example.com/debian distribution component1 component2', 'comment3')]}

    sl.remove_source('deb http://example.com/debian distribution component1 component2')

    assert sl.files == {'/etc/apt/sources.list': []}



# Generated at 2022-06-23 03:15:43.785647
# Unit test for function main
def test_main():
    unittest.TestCase().assertTrue(callable(main))


# Generated at 2022-06-23 03:15:46.176543
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('Invalid Source Test')
    except InvalidSource as e:
        assert "Invalid Source Test" in str(e)



# Generated at 2022-06-23 03:15:57.760779
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['filename'] = None
    with open('test_SourcesList___iter__.txt', 'r') as f:
        file_contents = f.read()
    file = 'test_SourcesList___iter__.txt'
    sources_list = SourcesList(module)
    sources_list.load(file)
    result = []
    for filename, n, enabled, source, comment in sources_list:
        result.append((filename, n, enabled, source, comment))

# Generated at 2022-06-23 03:16:09.911685
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    To test that removing a source works properly
    :return: None
    """
    mod = {"check_mode": False,
           "debug": False,
           "diff": True,
           "fail_on_missing_handler": True,
           "no_log": False,
           "verbosity": 0,
           "warnings": []}

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True, check_invalid_arguments=False, **mod)
    mod = module.params
    mod['filename'] = "Test_SourcesList_remove_source"
    mod['mode'] = 0o644
    sl = SourcesList(module)
    sl.load(sl.default_file)

    # only a single entry shall be removed