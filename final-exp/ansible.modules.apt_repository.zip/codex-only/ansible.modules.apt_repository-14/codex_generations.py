

# Generated at 2022-06-23 03:06:13.074024
# Unit test for function main
def test_main():
    ret_ok = {'repo': 'deb http://127.0.0.1 buster main', 'state': 'present', 'diff': [
            {'before': '', 'before_header': '/dev/null', 'after': 'deb http://127.0.0.1 buster main\n',
             'after_header': '/etc/apt/sources.list.d/ansible-test.list'}], 'changed': True}
    assert main() == ret_ok
    return True
test_main()


# Generated at 2022-06-23 03:06:15.604404
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('foobar')
    except InvalidSource as e:
        assert e.args[0] == 'foobar'


# Generated at 2022-06-23 03:06:16.758133
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sl = SourcesList()
    assert sl


# Generated at 2022-06-23 03:06:27.574782
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import tempfile
    import shutil
    import os
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sources = SourcesList(mod)
    # Remove all existing sources
    sources.files = {}
    d = tempfile.mkdtemp()
    sources.default_file = os.path.join(d, 'sources.list')

# Generated at 2022-06-23 03:06:31.137763
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sourceslist = SourcesList(None)
    sourceslist._add_valid_source('deb http://example.com', '', None)
    sourceslist.modify(sourceslist.default_file, 0, False, 'deb https://example.com', 'comment')

    dump = sourceslist.dump()
    assert dump[sourceslist.default_file].strip() == 'deb https://example.com # comment'
    assert len(dump) == 1
    assert len(sourceslist.files[sourceslist.default_file]) == 1



# Generated at 2022-06-23 03:06:37.231772
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None
    assert callback(['echo', 'hello', 'world']) is None



# Generated at 2022-06-23 03:06:43.027309
# Unit test for function main
def test_main():

    class TestModule(object):
        def __init__(self, params):
            self.params = params
            self.exit_json = print
            self.fail_json = print
            self._diff = True

    # Test when apt_pkg is installed
    params = {
        'mode': '644',
        'update_cache': True,
        'install_python_apt': False,
    }
    module = TestModule(params)
    class TestAptsourcesDistro(aptsources_distro.Distribution):
        @property
        def source_template(self):
            return '[source]\nType: simple\nuri: %(uri)s\nsuite: %(suite)s\ncomponents: %(comps)s\n'
    distro.__class__ = TestAptsourcesDist

# Generated at 2022-06-23 03:06:53.655338
# Unit test for function install_python_apt
def test_install_python_apt(): # pylint: disable=missing-function-docstring
    module = MockModule(params={'update_cache': False, 'install_python_apt': True})
    python_apt_name = 'python-apt'
    install_python_apt(module, python_apt_name)
    assert(module.run_command_called)
    command_calls = module.run_command_called # pylint: disable=unused-variable
    assert(len(command_calls) == 2)
    first_call = command_calls[0]
    assert(first_call['args'][0] == module.apt_get_path)
    assert(first_call['args'][1] == 'update')
    assert(len(first_call['args']) == 2)
    second_call = command_calls[1]


# Generated at 2022-06-23 03:07:04.575307
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    print("\n\n===TEST: test_SourcesList_dump===")
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    sourceslist = SourcesList(module)
    sourceslist.add_source("deb http://host/ path1/repo/component1")
    sourceslist.add_source("deb-src http://host/ path2/repo/component2")
    sourceslist.add_source("deb http://host/ disabled_path/disabled_repo/disabled_component", enabled=False)
    sourceslist.add_source("deb-src http://host/ path3/repo/component3", comment="some comment")
    sourceslist.add_source("deb http://host/ path4/repo/component4", file="my.list")

# Generated at 2022-06-23 03:07:07.820206
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # pylint: disable=undefined-variable
    module = AnsibleModule({})
    sl = SourcesList(module)

    assert sl.default_file == '/etc/apt/sources.list'
    # I've got "other/non-free" in my own sources.list
    assert 'other/non-free' in set(sl.files['/etc/apt/sources.list'])



# Generated at 2022-06-23 03:07:18.608002
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl1 = SourcesList(None)

# Generated at 2022-06-23 03:07:23.828011
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    ansible_module = AnsibleModule(
        argument_spec={
            'codename': {'type': 'str'}
        }
    )
    test_obj = UbuntuSourcesList(ansible_module)
    # test what happens if there is no params
    assert test_obj.__deepcopy__()
    # test what happens if there is params
    assert test_obj.__deepcopy__(memo='1')


# Generated at 2022-06-23 03:07:24.562619
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass


# Generated at 2022-06-23 03:07:36.085839
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    """
    Check load method of class SourcesList
    :return:
    """
    t_file = '/etc/apt/sources.list'
    fp = open(t_file)
    f_lines = fp.readlines()
    fp.close()

    result_file = []
    for line in f_lines:
        if line.strip().startswith('#'):
            enabled = False
            line = line[1:]
        else:
            enabled = True

        i = line.find('#')
        if i > 0:
            line = line[:i]
            comment = line[i + 1:]
        else:
            comment = ''
        line = line.strip()
        if line:
            chunks = line.split()

# Generated at 2022-06-23 03:07:46.747183
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import StringIO
    os_path_isfile = os.path.isfile
    os_path_split = os.path.split
    os_path_abspath = os.path.abspath
    glob_iglob = glob.iglob
    open = staticmethod(StringIO.StringIO)

    class MockedAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {'filename': None}

        def fail_json(self, msg):
            raise ValueError(msg)

    class MockedSourcesList(SourcesList):
        def __init__(self, module):
            self.module = module
            self.files = {}
            self.default_file = '/path/to/sources.list'


# Generated at 2022-06-23 03:07:49.705800
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # test direct inheritance of SourcesList class member variables
    # without calling __init__() of the parent class
    sl = UbuntuSourcesList(None)
    assert sl.module is None
    assert sl.default_file == '/etc/apt/sources.list'


# Generated at 2022-06-23 03:08:02.160660
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.modules.packaging.language import apt_repository

    import os

    fd, test_path = tempfile.mkstemp()
    os.close(fd)

    # make sure apt exits nonzero on 'err'
    mocker = mocker_factory(apt_repository)
    mocker.patch(
            'ansible.module_utils.basic.AnsibleModule.exit_json',
            side_effect=apt_repository.AnsibleModule.exit_json)
    mocker.patch('ansible.module_utils.basic.AnsibleModule.run_command', side_effect=lambda x, **kw: (1, '', ''))
    result = basic._ANS

# Generated at 2022-06-23 03:08:11.901308
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    '''
    Tests for method add_source of class UbuntuSourcesList
    '''
    module = AnsibleModule(
        argument_spec={
            'filename': {'default': None, 'required': False, 'type': 'str'},
            'mode': {'default': '0644', 'required': False, 'type': 'str'},
            'state': {'default': 'present', 'required': False, 'type': 'str', 'choices': ['absent', 'present']},
            'validate_certs': {'default': True, 'required': False, 'type': 'bool'},
        },
        supports_check_mode=True
    )
    fake_module = FakeModule()
    add_ppa_signing_keys_callback = None

# Generated at 2022-06-23 03:08:24.936557
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = lambda x: None
    sources_list = SourcesList(module)
    file = '/path/to/file'
    n = 0
    sources_list.files[file] = [
        (n, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
        (n, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
        (n, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''),
    ]
    sources_list.modify(file, n, enabled=True)
    assert sources_list.files[file][n][1] is True



# Generated at 2022-06-23 03:08:36.485851
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import pytest
    from ansible.module_utils.six import PY3

    if not PY3:
        pytest.skip("Test file is not PY3 compatible")

    # Test with dummy self.files dict and dummy line
    dummy_self = SourcesList(AnsibleModule(argument_spec={}))
    dummy_self.files = {"test.list": [(1, True, False, "source", "#comment"),
                                      (2, True, False, "source2", ""),
                                      (3, True, True, "source3", "#comment3"),
                                      (4, True, True, "source4", ""),
                                      (5, True, False, "source3", "#"),
                                      (6, True, True, "source3", "")]}

# Generated at 2022-06-23 03:08:48.060818
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import os
    import shutil

    from ansible.module_utils._text import to_bytes, to_native

    module = AnsibleModule(argument_spec={})
    tmpdir = module.mkdtemp()
    filename = os.path.join(tmpdir, 'test.list')

# Generated at 2022-06-23 03:08:55.251790
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            codename=dict(default='trusty', choices=['trusty', 'precise'], type='str'),
        ),
        supports_check_mode=True
    )
    sl = UbuntuSourcesList(module)


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:09:03.297100
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    from ansible_collections.community.debian.tests.unit.compat.mock import MagicMock
    mocker = MagicMock()
    args = dict(comment='', file='/etc/apt/sources.list.d/elastic-7.x.list')
    line = 'deb https://artifacts.elastic.co/packages/7.x/apt stable main'
    result = UbuntuSourcesList._add_valid_source(mocker, line, **args)
    expected = None
    assert result == expected



# Generated at 2022-06-23 03:09:15.046257
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    return_value = {
        'active': True,
        'expand': True,
        'filename': '/etc/apt/sources.list.d/debian-ansible-team-ansible-stable-xenial.list',
        'file': '/etc/apt/sources.list.d/debian-ansible-team-ansible-stable-xenial.list',
        'line': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main #DEB-PPA-MAIN',
        'name': 'debian-ansible-team-ansible-stable-xenial',
        'ppas': [],
        'repo': 'main',
        'state': 'present',
        'update_cache': False}
    sourceslist = UbuntuSourcesList(module=fake_module)


# Generated at 2022-06-23 03:09:22.889392
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    This is an internal unit test to check that SourcesList.dump()
    function can handle all the corner cases.
    '''
    sl = SourcesList(None)

# Generated at 2022-06-23 03:09:36.034025
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    o = SourcesList(module)
    o.files['file.list'] = [(0, True, False, 'deb-src http://archive.canonical.com/ubuntu hardy partner', 'This is comment'),
                            (1, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'This is comment'),
                            (2, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'This is comment'),
                            (3, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'This is comment')]
    o.modify('file.list', 0, enabled=True, comment='New comment')

# Generated at 2022-06-23 03:09:44.191544
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # create temporary file
    fd, tmp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')

    f.write("deb http://example.com/debian stable main\n")
    f.write("deb-src http://example.com/debian stable main\n")
    f.write("deb http://example.com/debian stable main\n")
    f.write("#deb-src http://example.com/debian stable main\n")
    f.write("# \n")
    f.write("cut\n")
    f.close()

    mod = AnsibleModule(argument_spec={})

    sl = SourcesList(mod)

    sl.load(tmp_path)

    # check that we've got everything we expect

# Generated at 2022-06-23 03:09:45.265628
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    with pytest.raises(InvalidSource):
        raise InvalidSource("test")


# Generated at 2022-06-23 03:09:49.230150
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: None
    module.atomic_move = lambda x, y: None
    sourceslist = SourcesList(module)
    sourceslist.save()


# Generated at 2022-06-23 03:09:53.374181
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    o = UbuntuSourcesList(None)
    d = copy.deepcopy(o)
    assert o.LP_API == d.LP_API
    assert o.codename == d.codename
    assert o.add_ppa_signing_keys_callback is None


# Generated at 2022-06-23 03:09:59.040980
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = DummyModule()
    sources = SourcesList(module)
    sources.load('/tmp/test_sources.list')
    sources.modify('/tmp/test_sources.list', 0, comment='test')
    sources.modify('/tmp/test_sources.list', 2, source='deb deb http://archive.debian.org/debian/ squeeze-lts main')
    sources.save()



# Generated at 2022-06-23 03:10:11.239225
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from unittest.mock import Mock
    from ansible.module_utils.basic import AnsibleModule

    ubuntu_sources_list = UbuntuSourcesList(Mock(spec_set=AnsibleModule))
    ubuntu_sources_list.module = 'foo'
    ubuntu_sources_list.add_ppa_signing_keys_callback = lambda a: a
    ubuntu_sources_list.codename = 'bar'

    ubuntu_sources_list_copy = deepcopy(ubuntu_sources_list)

    assert ubuntu_sources_list_copy.module == 'foo'
    assert ubuntu_sources_list_copy.add_ppa_signing_keys_callback is not None
    assert ubuntu_sources_list_copy.codename == 'bar'

# Generated at 2022-06-23 03:10:19.461002
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    """
    test method - dump.
    """
    sl = SourcesList({})
    sl.files['./filename/sources.list'] = {'source': 'deb http://archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse', 'enabled': 'True', 'comment': '#123'}
    sl.files['./filename/sources2.list'] = {'source': 'deb http://archive.ubuntu.com/ubuntu/ xenial-backports main restricted universe multiverse', 'enabled': 'False', 'comment': '#123'}
    sl_dump_result = sl.dump()

# Generated at 2022-06-23 03:10:26.981556
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec=dict(line=dict(required=True), file_mode=dict()))
    sl = SourcesList(module)
    sl.load("/tmp/sources.list.test")
    for line in open("/tmp/sources.list.test"):
        if line.startswith("#"):
            continue
        sl._add_valid_source(line.split(" ", 1)[1], "", None)
    dumpstruct = sl.dump()
    assert dumpstruct["/tmp/sources.list.test"] == open("/tmp/sources.list.test").read()



# Generated at 2022-06-23 03:10:35.438750
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class MockModule:
        def __init__(self):
            self.params = {
                'filename': None,
                'get_signature_keys': False,
                'gpgkey': '1234567890',
                'mode': DEFAULT_SOURCES_PERM
            }

    module = MockModule()

    sourceslist = SourcesList(module)
    # test single source
    sourceslist.files = {
        '/etc/apt/sources.list': [
            (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse', '')
        ]
    }
    assert sourceslist.dump() == {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted universe multiverse\n'}
    # test

# Generated at 2022-06-23 03:10:48.350765
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = None

    def mock_filespec_dir(dirspec):
        return 'testdata/sources/' + dirspec

    def mock_filespec_file(filespec):
        return 'testdata/sources/' + filespec

    module = DummyModule()
    sourceslist = SourcesList(module)

    # Make sure that empty sources.list.d/ isn't a problem

# Generated at 2022-06-23 03:11:00.134148
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files[None] = [(0, True, True, 'deb http://apt.postgresql.org/pub/repos/apt -', 'test repo'),
                      (1, True, True, 'deb http://apt.postgresql.org/pub/repos/apt -', 'test repo'),
                      (2, True, True, 'deb http://apt.postgresql.org/pub/repos/apt -', 'test repo'),
                      (3, True, True, 'deb http://apt.postgresql.org/pub/repos/apt -', 'test repo'),
                      (4, True, True, 'deb http://apt.postgresql.org/pub/repos/apt -', 'test repo')]
    sl.mod

# Generated at 2022-06-23 03:11:13.348369
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    line0 = 'deb http://archive.canonical.com/ubuntu hardy partner'
    line1 = 'deb-src http://archive.canonical.com/ubuntu hardy partner'
    line2 = '# deb http://archive.canonical.com/ubuntu hardy partner'
    line3 = '# deb-src http://archive.canonical.com/ubuntu hardy partner'
    sourceslist.add_source(line0)
    sourceslist.add_source(line1)
    sourceslist.add_source(line2)
    sourceslist.add_source(line3)
    sourceslist.remove_source(line0)
    sourceslist.remove_source(line1)
    sourceslist.remove_source(line2)
    sources

# Generated at 2022-06-23 03:11:21.595735
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import re

    class _Module(object):
        """Simulated AnsibleModule"""
        def fail_json(self, **kwargs):
            raise RuntimeError(json.dumps(kwargs))

        def atomic_move(self, src, dst):
            """Simulated AnsibleModule.atomic_move()"""
            shutil.move(src, dst)

        @property
        def params(self):
            return {}

    class _SourcesList(SourcesList):
        """Override sources list reader to simulate adding apt source by apt module."""
        def __init__(self, *args, **kwargs):
            super(_SourcesList, self).__init__(*args, **kwargs)
            self.files = {}
            apt_source = 'deb [arch=amd64] http://apt.example.com stable main'
            self._add_

# Generated at 2022-06-23 03:11:29.303120
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    def _get_module():
        module = Mock()
        module.params = dict()
        module.params['codename'] = None
        return module

    module = _get_module()

    sl = UbuntuSourcesList(module)

    sl.add_source("deb http://mirror.com/Linux/ubuntu/xenial main restricted universe multiverse")
    assert sl.dump()['/etc/apt/sources.list'] == 'deb http://mirror.com/Linux/ubuntu/xenial main restricted universe multiverse\n'

    sl.add_source("ppa:jdstrand/test")
    assert sl.dump()['/etc/apt/sources.list'].startswith('deb http://mirror.com/Linux/ubuntu/xenial main restricted universe multiverse\n')

# Generated at 2022-06-23 03:11:34.825933
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import mock
    module1 = mock.Mock()
    module1.check_mode = False

    module2 = mock.Mock()
    module2.check_mode = True

    assert get_add_ppa_signing_key_callback(module1) is not None
    assert get_add_ppa_signing_key_callback(module2) is None



# Generated at 2022-06-23 03:11:43.754827
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # Its a kind of magic: we run our unit test inside of __main__.
    # So in the same time we test module inside of module and not just python library.
    if sys.modules['__main__'].__file__.endswith(__file__):
        if not HAVE_PYTHON_APT:
            return (False, 'cannot test %s when python-apt is not installed' % __file__)
        mod = SourcesList(sys.modules['__main__'])
        mod.load('tests/test_apt_repository1.sources')
        mod.load('tests/test_apt_repository2.sources')
        mod.load('tests/test_apt_repository3.sources')
        mod.load('tests/test_apt_repository4.sources')


# Generated at 2022-06-23 03:11:55.222999
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    mod = AnsibleModule(argument_spec={})
    a = SourcesList(mod)

    a._add_valid_source('deb http://archive.ubuntu.com/ubuntu/ xenial main', '# ansible')
    n = a._add_valid_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe', '# ansible')
    a._add_valid_source('deb http://archive.ubuntu.com/ubuntu/ xenial restricted', '# ansible')

    # enable to disabled source (by modifying it)
    a.modify(n, True)

    # remove disabled source from file
    a._remove_valid_source('deb http://archive.ubuntu.com/ubuntu/ xenial restricted')

    # check

# Generated at 2022-06-23 03:12:02.360787
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-23 03:12:07.951785
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule():
        class MockModuleExitActions():
            def run(self):
                pass
        exit_args = {'warnings': MockModuleExitActions()}
        def fail_json(self, **kwargs):
            pass
        def atomic_move(self, *args, **kwargs):
            pass
        def set_mode_if_different(self, *args, **kwargs):
            pass
    class MockDistro():
        codename = 'codename'
    class MockFetchUrl():
        def __init__(self, *args, **kwargs):
            pass
        def read(self):
            return "123"
    class MockRunCommand():
        def __init__(self, *args, **kwargs):
            pass
        def run(self, *args, **kwargs):
            return

# Generated at 2022-06-23 03:12:18.741660
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.files = {}
    sources_list.files['/etc/apt/sources.list'] = [
        (0, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial main', ''),
        (1, True, True, 'deb-src http://archive.ubuntu.com/ubuntu xenial main', ''),
        (2, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial-security main', ''),
    ]
    sources_list.files['/etc/apt/sources.list.d/dummy.list'] = [
        (0, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial-security main', ''),
    ]

    sources

# Generated at 2022-06-23 03:12:27.196579
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # Test basic instantiation of exception object
    try:
        raise InvalidSource('Test')
    except InvalidSource as e:
        if not str(e) == 'Test':
            raise Exception('Test 1 failed')

    # Test 'url' attribute of exception object
    try:
        raise InvalidSource('Test', url='http://example.com')
    except InvalidSource as e:
        if not e.url == 'http://example.com':
            raise Exception('Test 2 failed')

    # Test 'key' attribute of exception object
    try:
        raise InvalidSource('Test', url='http://example.com', key='AAAAAA')
    except InvalidSource as e:
        if not e.key == 'AAAAAA':
            raise Exception('Test 3 failed')



# Generated at 2022-06-23 03:12:37.823692
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class Mod(AnsibleModule):
        def atomic_move(self, tmp_path, filename):
            file1 =  os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'apt_repository_module_test_1', 'sources_list'))
            file2 =  os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data', 'apt_repository_module_test_2', 'sources_list'))
            if tmp_path == file1:
                os.system("cp " + file2 + " " + file1)

# Generated at 2022-06-23 03:12:47.832411
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sources = SourcesList(None)
    sources.load('''\
# deb cdrom:[Ubuntu-Server 18.04.1 LTS _Bionic Beaver_ - Release amd64 (20180725)]/ bionic main restricted
# deb-src http://archive.ubuntu.com/ubuntu bionic main restricted
deb http://security.ubuntu.com/ubuntu bionic-security main restricted
deb-src http://archive.ubuntu.com/ubuntu bionic main restricted
''')
    sources.remove_source('  deb-src http://archive.ubuntu.com/ubuntu bionic main restricted   ')

# Generated at 2022-06-23 03:12:51.591537
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    if not hasattr(apt, 'apt_pkg'):
        raise Exception("apt module is not loaded, test skipped")

    # Test with non-ASCII character in the exception message
    message = u'<\u221e>'
    try:
        raise InvalidSource(message)
    except InvalidSource as e:
        if message != str(e):
            raise Exception("InvalidSource exception is not utf-8 decoded")


# Generated at 2022-06-23 03:12:55.686930
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(None) is None


# Generated at 2022-06-23 03:13:07.438069
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import shutil
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.common.respawn import respawn_module
    from ansible.module_utils.urls import fetch_url

    # Create temporary workspaces
    d = tempfile.mkdtemp(dir='/tmp')
    d_etc = os.path.join(d, 'etc')
    d_apt = os.path.join(d, 'etc/apt')
    d_apt_sourceparts = os.path.join(d_apt, 'sources.list.d')
    shutil.rmtree(d)  # should be absent
    os.makedirs(d_apt_sourceparts)

    # Create temporary environment
    old_

# Generated at 2022-06-23 03:13:10.925616
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    _result = get_add_ppa_signing_key_callback(dict(check_mode=False))
    assert _result(['echo']) == None

    _result = get_add_ppa_signing_key_callback(dict(check_mode=True))
    assert _result(['echo']) == None



# Generated at 2022-06-23 03:13:16.128048
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_src = InvalidSource("Invalid apt source 'deb http://example.com/' (missing version)")
    assert invalid_src.args[0] == "Invalid apt source 'deb http://example.com/' (missing version)"


# Generated at 2022-06-23 03:13:24.548852
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.six import StringIO
    _module = AnsibleModule(argument_spec={})

    sl = SourcesList(_module)

    # Check if empty file is loaded
    _fd, _path = tempfile.mkstemp()
    assert _fd == 3
    assert os.close(_fd) == None
    assert _path
    assert os.path.exists(_path)
    sl.load(_path)
    assert sl.files == {_path: []}
    assert os.path.isfile(_path)
    assert os.remove(_path) == None

    # Check if commented line is loaded
    _fd, _path = tempfile.mkstemp()
    assert _fd == 3
    assert os.close(_fd) == None
    assert _path
    assert os.path.exists(_path)


# Generated at 2022-06-23 03:13:31.464216
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class MyModule(object):
        def __init__(self):
            self.params = {}

    class Distro(object):
        def __init__(self):
            self.codename = 'xenial'

    module = MyModule()
    distro = Distro()
    sl = UbuntuSourcesList(module)
    assert_equal(len(sl.files), 0)
    assert_equal(sl.codename, 'xenial')



# Generated at 2022-06-23 03:13:43.170754
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(
        argument_spec=dict(
            repo=dict(default='deb http://archive.canonical.com/ubuntu hardy partner'),
            filename=dict(default=None),
            install_python_apt=dict(default=True),
            install_python_apt_apt=dict(default=True),
            install_python_apt_apt_pkg=dict(default=True),
            install_python3_apt=dict(default=True),
            install_python3_apt_apt=dict(default=True),
            install_python3_apt_apt_pkg=dict(default=True),
        )
    )
    sl = SourcesList(module)
    module.exit_json(changed=False, sourceslist=sl.dump())

# ===========================================
# Main control flow


# Generated at 2022-06-23 03:13:52.670272
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # file with missing __init__ method
    class MockModule(object):
        pass
    module = MockModule()
    module.params = {
        'codename': 'codename',
    }
    module.run_command = MagicMock()
    instance = UbuntuSourcesList(module)
    clone = deepcopy(instance)
    assert clone.codename == instance.codename
    assert clone.module == instance.module
    assert clone.add_ppa_signing_keys_callback == instance.add_ppa_signing_keys_callback

# Generated at 2022-06-23 03:14:00.962248
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    package_cache = apt.Cache()

# Generated at 2022-06-23 03:14:10.714990
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import tempfile
    fn, fname = tempfile.mkstemp()
    f = open(fname,'w')

# Generated at 2022-06-23 03:14:19.145856
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils import basic
    from ansible.module_utils.common.respawn import respawn_module

    apt = basic.AnsibleModule(argument_spec=dict())

    def mock_fail_json(*args, **kwargs):
        raise Exception('fail_json should not be called')
    apt.fail_json = mock_fail_json
    apt.check_mode = True

    def mock_run_command(*args, **kwargs):
        raise Exception('run_command should not be called when check_mode True')
    apt.run_command = mock_run_command

    def mock_get_bin_path(*args, **kwargs):
        return None
    apt.get_bin_path = mock_get_bin_path


# Generated at 2022-06-23 03:14:23.657254
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # Test that an exception is raised with a specific message.
    raised_exception = None
    try:
        raise InvalidSource('test message')
    except InvalidSource as ex:
        raised_exception = ex
    assert raised_exception.message == 'test message'


# Generated at 2022-06-23 03:14:34.677625
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    orig_config_find_file = apt_pkg.config.find_file

    apt_pkg.config.find_file = lambda x: '/tmp'
    sl = SourcesList(module)
    def revert():
        os.remove('/tmp/test.list')
        apt_pkg.config.find_file = orig_config_find_file
    sl.add_source('deb http://example.com/ some_distro universe',
                  file='test.list')
    sl.save()
    try:
        with open('/tmp/test.list') as f:
            assert 'deb http://example.com/ some_distro universe\n' == f.read()
    except IOError as err:
        raise
    finally:
        revert

# Generated at 2022-06-23 03:14:44.851804
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Test 1: Modify a source in a existing file
    apt_repo_file = '/tmp/.ansible_tmp_Simple_apt_repository-1555869912.169719-9123-1ju2g2t.list'
    apt_repo = 'deb http://archive.canonical.com/ubuntu hardy partner'
    apt_sources_list = SourcesList(None)
    apt_sources_list.files[apt_repo_file] = [(0, True, True, apt_repo, '')]
    file_1 = apt_sources_list.files[apt_repo_file][0]

    # Iterate for the apt_sources_list, then find the source and modify it

# Generated at 2022-06-23 03:14:56.096170
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sourceslist = SourcesList()

# Generated at 2022-06-23 03:14:58.897952
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('oops')
    except InvalidSource as e:
        assert e.message == 'oops'



# Generated at 2022-06-23 03:15:00.488710
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except InvalidSource:
        pass


# Generated at 2022-06-23 03:15:09.656972
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import unittest
    import sys

# Generated at 2022-06-23 03:15:19.099725
# Unit test for function install_python_apt
def test_install_python_apt():
    import json
    import tempfile

    def mock_run_command(args):
        if args[1] == 'update':
            return 0, '', ''
        return 0, '', ''

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = mock_run_command
    module.get_bin_path = lambda x: "/usr/bin/%s" % x

    install_python_apt(module, "python-apt")

    install_python_apt(module, "python3-apt")


# Generated at 2022-06-23 03:15:22.715937
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sourceslist = SourcesList(None)
    sourceslist.load('/etc/apt/sources.list')
    assert sourceslist.files['/etc/apt/sources.list'] is not None


# Generated at 2022-06-23 03:15:28.502660
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    ubuntu_sources_list = UbuntuSourcesList(module=None, add_ppa_signing_keys_callback=None)
    ubuntu_sources_list.add_ppa_signing_keys_callback = None
    ubuntu_sources_list.codename = None
    ubuntu_sources_list.files = None
    ubuntu_sources_list.module = None
    ubuntu_sources_list.new_repos = None


# Generated at 2022-06-23 03:15:34.048699
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():

    module = AnsibleModule(argument_spec={})

    ubuntu_sources_list = UbuntuSourcesList(module)
    assert(isinstance(ubuntu_sources_list, UbuntuSourcesList))


# Generated at 2022-06-23 03:15:44.760215
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import unittest
    import shutil
    import tempfile

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self._test_dir = tempfile.mkdtemp()
            self._cwd = os.getcwd()
            os.chdir(self._test_dir)

        def tearDown(self):
            os.chdir(self._cwd)
            shutil.rmtree(self._test_dir)

        def test_empty(self):
            sources = SourcesList(self.module)
            sources.save()
            self.assertTrue(os.path.exists(sources.default_file))
            with open(sources.default_file) as f:
                data = f.read()
            self.assertEqual(data, '')


# Generated at 2022-06-23 03:15:56.455904
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_source_list = [
        'deb http://archive.canonical.com/ubuntu hardy partner',
        'deb-src http://archive.canonical.com/ubuntu hardy partner',
        '# deb http://archive.canonical.com/ubuntu hardy partner',
        '# deb-src http://archive.canonical.com/ubuntu hardy partner',
    ]

# Generated at 2022-06-23 03:16:00.653645
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # "__deepcopy__" method of "UbuntuSourcesList" class returns instance of "UbuntuSourcesList" class
    assert isinstance(deepcopy(UbuntuSourcesList(module)), UbuntuSourcesList)



# Generated at 2022-06-23 03:16:12.279882
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    # Test with a PPA
    source_list = UbuntuSourcesList(None)
    source_list.files = {
        '/etc/apt/sources.list.d/javierdiaz.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/javier-diaz/ppa/ubuntu trusty main', ''),
            (1, True, True, 'deb http://ppa.launchpad.net/javier-diaz/ppa/ubuntu xenial main', ''),
            (2, True, True, 'deb http://ppa.launchpad.net/javier-diaz/ppa/ubuntu xenial main', ''),
            (3, True, True, 'deb-src http://ppa.launchpad.net/javier-diaz/ppa/ubuntu xenial main', ''),
        ],
    }
