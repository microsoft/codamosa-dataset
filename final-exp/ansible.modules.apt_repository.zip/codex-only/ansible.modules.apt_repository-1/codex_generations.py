

# Generated at 2022-06-23 03:06:14.640718
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class Module(object):
        class FailJson(Exception):
            pass

        class AtomicMove(object):
            pass

        class SetModeIfDifferent(object):
            pass

    the_module = Module()

    class Source:
        def __init__(self, the_module):
            self.__the_module = the_module
            self.__valid = False
            self.__enabled = True
            self.__source = ''
            self.__comment = ''

        def set_enabled(self, enabled):
            self.__enabled = enabled

        def set_source(self, source):
            self.__valid = True
            self.__source = source

        def set_comment(self, comment):
            self.__comment = comment


# Generated at 2022-06-23 03:06:19.191724
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class MockModule(object):
        def __init__(self):
            self.params = {}
    ubuntu_sources_list = UbuntuSourcesList(MockModule())
    ubuntu_sources_list.add_source("deb http://archive.ubuntu.com/ubuntu trusty multiverse")
    assert("deb http://archive.ubuntu.com/ubuntu trusty multiverse" in ubuntu_sources_list.repos_urls)

# Generated at 2022-06-23 03:06:28.819513
# Unit test for function main
def test_main():
    """
    Unit test for main
    """
    # pylint: disable=protected-access

# Generated at 2022-06-23 03:06:38.010918
# Unit test for function main
def test_main():
    try:
        # Python 2.6 fallback
        import unittest2 as unittest
    except ImportError:
        # Python >= 2.7
        import unittest

    import ansible.module_utils.apt_repository as apt_repository
    import ansible.module_utils.apt_pkg as apt_pkg
    import ansible.module_utils.six as six

    class DummyModule(object):
        def __init__(self, fail_json=None, fail_json_on_diff=None, has_changed=None, **kwargs):
            self.fail_json_on_diff = fail_json_on_diff
            self.fail_json = fail_json
            self.has_changed = has_changed
            self.params = kwargs

# Generated at 2022-06-23 03:06:42.833969
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    apt_pkg_name = "python-apt"
    install_python_apt(module, apt_pkg_name)
    assert module.fail_json.called is False, "Failed to install {}".format(apt_pkg_name)


# Generated at 2022-06-23 03:06:49.289014
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    def mock_run_command(_):
        pass

    module = Mock(spec=AnsibleModule)
    module.run_command.side_effect = mock_run_command
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) == mock_run_command

    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-23 03:06:58.529926
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    ''' Test iterating over sources.list '''

    test_lines = '''
deb [trusted=yes] http://archive.canonical.com/ubuntu trusty partner
deb [trusted=yes] http://archive.canonical.com/ubuntu trusty partner disabled # Yes, we have disabled sources.
deb-src http://archive.canonical.com/ubuntu trusty partner
# i.e. this line is a comment:
# deb https://private.com/ubuntu trusty partner

## This is a comment with an empty line before it
deb https://public.com/ubuntu trusty main
'''


# Generated at 2022-06-23 03:07:04.195363
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = DummyModule()
    sl = SourcesList(module)
    # Starting with empty sources list
    assert len(sl.files) == 0
    # Load sources list with content
    sl.load(module.default_file)
    assert len(sl.files) == 1
    assert module.default_file in sl.files
    # Check that dump function works
    assert sl.dump() == {module.default_file: module.default_content}



# Generated at 2022-06-23 03:07:05.488194
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_source = InvalidSource



# Generated at 2022-06-23 03:07:06.456105
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    ex = InvalidSource()



# Generated at 2022-06-23 03:07:11.393166
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

    assert sources.default_file is not None
    assert '/sources.list' in sources.default_file

    for file in sources.files.keys():
        for n, valid, enabled, source, comment in sources.files[file]:
            assert valid == True


# Generated at 2022-06-23 03:07:20.781209
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    :return:
    '''
    module = AnsibleModule(argument_spec={})
    assert module is not None, 'Unit test for apt_repository expected module not to be None'

    sl = SourcesList(module)
    assert sl.files == {}, 'Unit test for apt_repository expected sources list to be empty'

    sl.add_source('deb http://archive.example.com/ubuntu bionic main')
    assert sl.files == {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.example.com/ubuntu bionic main', '')]}, 'Unit test for apt_repository add source did not store source in the default file'


# Generated at 2022-06-23 03:07:28.410384
# Unit test for method modify of class SourcesList

# Generated at 2022-06-23 03:07:30.701747
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt('python-apt') == 0
    assert install_python_apt('python3-apt') == 0


# Generated at 2022-06-23 03:07:41.836665
# Unit test for method modify of class SourcesList

# Generated at 2022-06-23 03:07:51.181435
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec = dict(
        test = dict(required = True, type = 'dict'),
        sources_list = dict(required = True, type = 'dict'),
    ))

    test = module.params['test']
    sources_list = module.params['sources_list']

    # Set up module.files with the same data that was passed in
    module.files = copy.deepcopy(sources_list)

    # Create the object
    sourcesList = SourcesList(module)

    # Save the object
    sourcesList.save()

    # Return the results
    module.exit_json(changed = True, result = sourcesList.files)


# Generated at 2022-06-23 03:07:54.656086
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # isinstance(obj, class) is true if obj is an instance of class, or is an instance of a subclass of class.
    assert isinstance(InvalidSource(), Exception)


# Generated at 2022-06-23 03:08:07.048819
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(name='test_SourcesList_remove_source', argument_spec=dict())
    sources_list = SourcesList(module)

# Generated at 2022-06-23 03:08:10.875418
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class ModuleMock(object):
        class params(object):
            filename = None
            mode = None
    module = ModuleMock()

    ubuntu_sourceslist = UbuntuSourcesList(module)

    assert ubuntu_sourceslist.add_ppa_signing_keys_callback is None
    assert ubuntu_sourceslist.codename is not None
    assert ubuntu_sourceslist.module is module
    assert ubuntu_sourceslist.new_repos == set()



# Generated at 2022-06-23 03:08:15.100389
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Revert the sourcelist files to their previous state.'''
    # First remove any new files that were created:
    for filename in set(sources_after.keys()).difference(sources_before.keys()):
        if os.path.exists(filename):
            os.remove(filename)
    # Now revert the existing files to their former state:
    sourceslist_before.save()

# Generated at 2022-06-23 03:08:19.260962
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('test')
    if hasattr(exc, 'message'):
        # Python 2.x
        assert exc.message == 'test'
    else:
        # Python 3.x
        assert exc.args == ('test',)



# Generated at 2022-06-23 03:08:28.444223
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load("tests/unit/modules/ansible_test/_test_data/test_apt_repository/test.list")

# Generated at 2022-06-23 03:08:29.108982
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass

# Generated at 2022-06-23 03:08:35.247830
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # __deepcopy__(UbuntuSourcesList self, memo=None) -> UbuntuSourcesList
    # Test if deepcopy of UbuntuSourcesList object is UbuntuSourcesList type
    if PY3:
        obj = UbuntuSourcesList(AnsibleModule, 'foo')
        res = obj.__deepcopy__()
        assert isinstance(res, UbuntuSourcesList)
    else:
        # GH-12489 - Python 2.7 gives TypeError: can't pickle instancemethod objects
        pass



# Generated at 2022-06-23 03:08:44.273687
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['absent', 'present', 'latest']),
        repo=dict(type='str', required=True, aliases=['source']),
        filename=dict(type='str'),
        update_cache=dict(type='bool', default=False),
        mode=dict(type='raw'),
        update_apt_cache=dict(type='bool', default=True)
    ),
                           supports_check_mode=True)

    #Borrowed code from the parent module
    def _check_mode(module):
        if not module.check_mode:
            return
        # make a copy of the module params so that we can restore them if we are
        # running in check mode and get interrupted

# Generated at 2022-06-23 03:08:57.734893
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-23 03:09:07.617750
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = FakeModule()
    sl = SourcesList(module)
    sl._parse = lambda x, y: ('', True, x, '')
    sl.files = {
        '1': [(0, '', True, 'first', ''),
               (1, '', True, 'second', '')],
        '2': [(0, '', True, 'third', ''),
              (1, '', False, 'fourth', '')],
        '3': [(0, '', False, '#fifth', '')],
    }
    assert [source for source in sl] == [
        ('1', 0, True, 'first', ''),
        ('1', 1, True, 'second', ''),
        ('2', 0, True, 'third', ''),
    ]


# Generated at 2022-06-23 03:09:18.296547
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://example.com/repo release main')
    sources_list.add_source('deb https://example.com/repo release main')
    sources_list.add_source('deb https://example.com/repo other main')
    sources_list.add_source('deb http://example.com/repo release contrib', comment='some comment')
    sources_list.add_source('deb http://example.com/repo release contrib')
    sources_list.add_source('deb file:/var/repo ./', file='custom.list')
    sources_list.add_source('deb file:/var/repo ./', file='custom.list')
    sources_list.add_source

# Generated at 2022-06-23 03:09:23.161626
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # We can't use mock here because it's not available in Python 2.5
    # and we want to support it.
    class FakeModule(object):
        class FakeFullFileStat(object):
            st_mode = 0o644

        class FakeFileStat(object):
            st_mode = 0o600

        def __init__(self):
            self.params = {}
            self.full_stat = self.FakeFullFileStat
            self.stat = self.FakeFileStat

        def exit_json(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def atomic_move(self, *args, **kwargs):
            pass

        def check_mode(self):
            raise Exception("check_mode() is not implemented")


# Generated at 2022-06-23 03:09:34.669926
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = None
    sources = SourcesList(module)
    assert not sources.files
    assert sources.default_file == '/etc/apt/sources.list'
    if "en_US" in os.listdir('/usr/share/i18n/locales'):
        assert sources._apt_cfg_dir('Dir::Etc::sourceparts') == '/etc/apt/sources.list.d'
    else:
        apt_pkg.Config.Set("Dir::Etc::sourceparts", "/tmp/sources.list.d")
        assert sources._apt_cfg_dir('Dir::Etc::sourceparts') == '/tmp/sources.list.d'



# Generated at 2022-06-23 03:09:43.347076
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from mock import patch


# Generated at 2022-06-23 03:09:53.978501
# Unit test for method dump of class SourcesList

# Generated at 2022-06-23 03:10:03.062501
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    obj = SourcesList(module)
    obj.files['/path/to/file'] = [(0, True, True, 'source', 'comment')]

    assert obj.files['/path/to/file'] == [(0, True, True, 'source', 'comment')]
    assert obj.dump() == {'/path/to/file': 'source # comment\n'}

    obj.modify('/path/to/file', 0, enabled=False)
    assert obj.files['/path/to/file'] == [(0, True, False, 'source', 'comment')]
    assert obj.dump() == {'/path/to/file': '# source # comment\n'}

    obj.modify('/path/to/file', 0, source='source2')
    assert obj.files

# Generated at 2022-06-23 03:10:14.308639
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = OrderedDict([(u'/etc/apt/sources.list', u'deb http://archive.ubuntu.com/ubuntu precise main restricted\ndeb http://archive.ubuntu.com/ubuntu precise-updates  main restricted\ndeb http://archive.ubuntu.com/ubuntu precise universe\ndeb http://archive.ubuntu.com/ubuntu precise-updates universe\ndeb http://archive.ubuntu.com/ubuntu precise multiverse\ndeb http://archive.ubuntu.com/ubuntu precise-updates multiverse\n')])

# Generated at 2022-06-23 03:10:16.549541
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # pylint: disable=unused-variable
    exc = InvalidSource('test')
    assert exc.msg == 'test'


# Generated at 2022-06-23 03:10:23.169449
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()
    obj = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)

    obj_copy = copy.deepcopy(obj)

    assert obj_copy.module == module
    assert obj_copy.add_ppa_signing_keys_callback == add_ppa_signing_keys_callback


# Generated at 2022-06-23 03:10:33.801169
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
  '''
  A test to ensure that the add_source method of the SourcesList class works as expected.
  Test basic case with a single line.
  Test case for sources with several lines.

  :return: True when tests pass, False if a test fails.
  '''
  from ansible.module_utils import basic

  test_ssl = SourcesList(basic)
  test_ssl.files = {}

  test_ssl.add_source("deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable")
  expected_result1 = {'/etc/apt/sources.list': 'deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable\n'}

  if test_ssl.dump() != expected_result1:
    test_ssl.files = {}
    return False

# Generated at 2022-06-23 03:10:35.821290
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    err = InvalidSource('foo')
    assert err.message == 'foo', err.message



# Generated at 2022-06-23 03:10:48.880331
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class FakeModule(object):
        def fail_json(self, msg):
            raise Exception(msg)

    class FakeAptConfig(object):
        def __init__(self, dir_etc_sourcelist, dir_etc_sourceparts):
            self.dir_etc_sourcelist = dir_etc_sourcelist
            self.dir_etc_sourceparts = dir_etc_sourceparts

        def find_file(self, filespec):
            if filespec == "Dir::Etc::sourcelist":
                return self.dir_etc_sourcelist
            return os.path.join(self.dir_etc_sourceparts, filespec)

    class FakeAptPkg(object):
        def __init__(self, apt_config):
            self.config = apt_config

    fake_module = FakeModule()

# Generated at 2022-06-23 03:11:00.684270
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Initialization of the module
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'raring'

    # Initialization of the class
    class UbuntuSourcesList_object(UbuntuSourcesList):
        def __init__(self, module):
            super(UbuntuSourcesList_object, self).__init__(module)
        def add_ppa_signing_keys_callback(self, command):
            self.command = command
    object = UbuntuSourcesList_object(module)

    # Initialization of the test data
    line = 'ppa:sarnold/redshift'

    # Execute the add_source method for the first time

# Generated at 2022-06-23 03:11:13.352754
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    lines = '''\
deb http://www.company.com/repository/ubuntu/upstream distribution component1 component2
deb-src http://www.company.com/repository/ubuntu/upstream distribution component1 component2
deb http://us.archive.ubuntu.com/ubuntu/ lucid main restricted
deb http://us.archive.ubuntu.com/ubuntu/ lucid-updates main restricted
deb http://security.ubuntu.com/ubuntu/ lucid-security main restricted
'''
    lines = lines.split('\n')

    # test for expected results on real data
    sl = make_sources_list(lines)
    results = [(x[3], x[4]) for x in sl]

# Generated at 2022-06-23 03:11:17.509362
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    filename = stub_echo_output(b'', b'', 1)
    module = stub_module(filename)
    sources = UbuntuSourcesList(module)
    sources.remove_source("deb http://ppa.launchpad.net/ppaname/ppa/ubuntu bionic main")
    expected_commands = [
        ['/bin/echo', '/etc/apt/sources.list.d/*.list'],
        ['/bin/rm', '-f', '-v', '/etc/apt/sources.list.d/*.list']
    ]
    assert_commands(module, expected_commands)



# Generated at 2022-06-23 03:11:21.955421
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    sources_before = dict()
    sources_after = dict()
    sl = UbuntuSourcesList(module)
    revert_sources_list(sources_before, sources_after, sl)




# Generated at 2022-06-23 03:11:26.947742
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Setup
    m = AnsibleModule({})

    # Setup test data
    list_of_filename = ['file0', 'file1']
    list_of_comment = ['comment0', 'comment1']
    list_of_source = ['source0', 'source1']
    list_of_enabled = [True, False]
    list_of_valid = [False, True]
    file_mapping = {'file0':[['source0', 'comment0', False, False]], 'file1':[['source1', 'comment1', True, True]]}

    # Setup expected result
    expected_result_file_mapping = {'file0': '#source0 #comment0\n', 'file1': 'source1 #comment1\n'}

    # Exercise
    sources = SourcesList(m)

# Generated at 2022-06-23 03:11:31.335443
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = MockModule({'filename': 'test_filename'})

    ppa_line = 'ppa:test_ppa'
    test_sl = UbuntuSourcesList(module)

    assert test_sl.files is None
    test_sl.add_source(ppa_line)
    assert test_sl.files is not None



# Generated at 2022-06-23 03:11:35.968057
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():

    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True
    )

    check_mode = module.check_mode

    _run_command = get_add_ppa_signing_key_callback(module)

    if check_mode:
        assert _run_command is None
    else:
        assert _run_command is not None
        assert type(_run_command) == types.FunctionType


# Generated at 2022-06-23 03:11:46.002891
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    lines = []
    lines.append('deb http://deb.debian.org/debian jessie-backports main contrib non-free\n')
    lines.append('deb http://deb.debian.org/debian jessie-backports main contrib non-free\n')
    lines.append('# deb http://ftp.debian.org/debian/ jessie-updates main contrib non-free\n')
    lines.append('# deb http://ftp.debian.org/debian/ jessie-updates main contrib non-free\n')
    lines.append('deb bt://openoffice.org/stable/devel ./ wordprocessing\n')
    lines.append('# deb bt://openoffice.org/stable/devel ./ wordprocessing\n')

# Generated at 2022-06-23 03:11:54.826333
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import tempfile
    backup_dir = tempfile.mkdtemp()
    filename = os.path.join(backup_dir, 'test.list')
    with open(filename, 'w') as f:
        f.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    s = SourcesList(None)
    s.load(filename)
    try:
        assert s.dump() == {filename: 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n'}
    finally:
        s.save()
        os.remove(filename)


# Generated at 2022-06-23 03:12:02.010053
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class Test(unittest.TestCase):
        def setUp(self):
            self.sourceslist = SourcesList(None)
            self.sourceslist.add_source('deb http://www.example.com/ubuntu/ wily main restricted universe multiverse')
            self.sourceslist.add_source('deb http://www.example.com/ubuntu/ wily-security main restricted universe multiverse')
            self.sourceslist.add_source('deb http://www.example.com/ubuntu/ wily-updates main restricted universe multiverse')
            self.sourceslist.add_source('deb http://www.example.com/ubuntu/ wily-proposed main restricted universe multiverse')

# Generated at 2022-06-23 03:12:05.579368
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    file = sources_list.default_file
    sources_list.modify(file, 0, comment="new comment")
    pprint(sources_list.dump())
    sources_list.modify(file, 0, comment=None, enabled=False)
    pprint(sources_list.dump())



# Generated at 2022-06-23 03:12:09.191214
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = DummyModule()
    sl = UbuntuSourcesList(module)
    assert sl.codename == distro.codename


# Generated at 2022-06-23 03:12:13.367376
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test cases for function revert_sources_list'''

    # sources_before, sources_after, and sourceslist_before are
    # created in the test_revert_sources_list_file() test case
    # and are passed as arguments so that they can be reused in
    # other test cases.

    # Source was disabled, so it should become enabled
    sourceslist_before.modify('/etc/apt/sources.list.d/python.list', 0, enabled=False)
    msg = "Source should be enabled when it was disabled before the test"
    assert sourceslist_before.files['/etc/apt/sources.list.d/python.list'][0][2], msg

    revert_sources_list(sources_before, sources_after, sourceslist_before)


# Generated at 2022-06-23 03:12:22.029811
# Unit test for function install_python_apt
def test_install_python_apt():
    import ansible.module_utils.ansible_release
    import ansible.module_utils.urls
    import ansible.module_utils.six
    import ansible.module_utils.dict_merge
    from ansible.modules.extras.packaging import apt_repository

    module = apt_repository

    apt_repository.HAVE_PYTHON_APT = False
    call_result = apt_repository.install_python_apt(module, 'some-apt')


# Generated at 2022-06-23 03:12:30.519158
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # create a temp file and some dummy sources
    t = tempfile.NamedTemporaryFile()
    tfn = t.name


# Generated at 2022-06-23 03:12:40.807022
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    # Read sample data from files
    my_in_data = open(os.path.join(os.getcwd(), 'test/in_data.json')).read()
    my_out_data = open(os.path.join(os.getcwd(), 'test/out_data.json')).read()

    # Create the Ansible Module Argument Specification

# Generated at 2022-06-23 03:12:51.808724
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class SourcesList:
        def __init__(self, module):
            self.module = module

# Generated at 2022-06-23 03:13:01.246344
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(dict(), False)
    repo = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)
    copy_repo = copy.deepcopy(repo)
    assert module is copy_repo.module
    assert repo.codename is copy_repo.codename
    assert repo.add_ppa_signing_keys_callback is copy_repo.add_ppa_signing_keys_callback



# Generated at 2022-06-23 03:13:10.966045
# Unit test for function revert_sources_list
def test_revert_sources_list():

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = dict()

        class ReturnData(object):
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

        def fail_json(self, msg):
            raise AssertionError(msg)

        def get_bin_path(self, bin, opt_dirs=[]):
            return 'bin'

        def atomic_move(self, tmp, filename, unsafe_writes=False):
            shutil.copy(tmp, filename)

        def set_mode_if_different(self, path, mode, diff=True):
            if path == 'test/test/test.list':
                raise AssertionError('Permission should not be changed')
            else:
                pass


# Generated at 2022-06-23 03:13:22.450787
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    try:
        import io
        import aptsources.sourceslist
    except ImportError:
        # skip unit test if specific module are not available
        return [1, 1]
    res = 0
    res += 1

# Generated at 2022-06-23 03:13:27.646985
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import tempfile
    import json
    import requests
    from ansible.module_utils.basic import AnsibleModule

    mod = AnsibleModule(add_ppa_signing_keys_callback=get_add_ppa_signing_key_callback)

    def _get_ppa_info(owner_name, ppa_name):
        """
        Hard-code a valid response from launchpad.net so that the test
        can run without a network connection.
        """

        lp_api = UbuntuSourcesList.LP_API % (owner_name, ppa_name)


# Generated at 2022-06-23 03:13:37.108572
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    s = SourcesList(None)

# Generated at 2022-06-23 03:13:42.362022
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile


    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.params['codename'] = 'trusty'

        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, command, check_rc=True):
            self.commands.append(command)
            rc = 0
            out = ''
            err = ''
            if command == 'apt-key export 93741A3D':
                out = ''
                err = 'gpg: no valid OpenPGP data found.'
            elif command == 'apt-key export BFB4FCF2':
                out = 'keydata'
                err = ''

            return rc, out, err



# Generated at 2022-06-23 03:13:52.177895
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    src = """# deb http://test.com/test
# deb http://test.com/test-test1
deb http://test.com/test-test2
deb http://test.com/test-test3
"""

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)
    fd, tmp_path = tempfile.mkstemp(prefix=".test-")

    f = os.fdopen(fd, 'w')
    f.write(src)
    f.close()

    sl.load(tmp_path)

    # Modify the third source
    for filename, n, e, s, c in sl:
        if 'test-test3' in s:
            sl.modify(filename, n, enabled=False, comment='third')

# Generated at 2022-06-23 03:14:02.933425
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://example.com/example example main')
    sources.save()

    # sources.list
    assert sources.files['/etc/apt/sources.list'] == [(0, True, True, 'deb http://example.com/example example main', '')]

    # sources.list.d/example.list
    assert sources.files['/etc/apt/sources.list.d/example.list'] == []

    sources = SourcesList(module)
    sources.add_source('deb http://example.com/example example main', file='example.list')
    sources.save()

    # sources.list
    assert sources.files['/etc/apt/sources.list'] == []

    # sources.list.d/example

# Generated at 2022-06-23 03:14:04.340306
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass # test is not implemented

# Generated at 2022-06-23 03:14:14.542561
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module=AnsibleModule({})
    sl = SourcesList(module)
    file = "/etc/apt/sources.list"

    #Setup the test
    with open("/tmp/sources.list", "w+") as f:
        f.write("deb http://http.debian.net/debian wheezy main\n")
        f.write("deb-src http://http.debian.net/debian wheezy main\n")
        f.write("\n")
        f.write("be-src http://http.debian.net/debian wheezy main\n")
        f.write("deb http://http.debian.net/debian wheezy main\n")
        f.write("deb http://http.debian.net/debian wheezy main\n")

# Generated at 2022-06-23 03:14:19.013090
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sources = SourcesList()

    assert sources.files == {}
    assert sources.new_repos == set()
    assert sources.default_file == '/etc/apt/sources.list'


# Generated at 2022-06-23 03:14:30.379723
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

    sl._add_valid_source('deb http://example.com/debian testing main', 'test entry', file='/test/test')
    sl._add_valid_source('deb http://example.com/debian testing main 2', 'test entry', file='/test/test')
    sl.modify('/test/test', 0, source='deb http://example.com/debian testing main', comment='test entry')
    sl.modify('/test/test', 1, enabled=True, source='deb http://example.com/debian testing main 2', comment='test entry')

    dumpstruct = sl.dump()

    assert '/test/test' in dumpstruct

# Generated at 2022-06-23 03:14:38.898489
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Returns a tuple with the generated sourceslist and the result of the module call'''
    # Create a new module mock to use with the module
    module = AnsibleModule(argument_spec=dict(codename=dict(default=u'xenial'), state=dict(default='present', choices=['present', 'absent']), filename=dict(), update_cache=dict(default=True, type='bool'), source=dict(required=True), key=dict(), key_url=dict(), deb_src=dict(type='bool', default=False), comment=dict()))
    # Create a fake sourceslist with one entry
    sources1 = {'/etc/apt/sources.list.d/ansible.list': '''deb http://ppa.launchpad.net/daniruiz/flat-remix/ubuntu xenial main\n'''}
   

# Generated at 2022-06-23 03:14:39.692311
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # There's no way to unit-test this function, sadly
    return True



# Generated at 2022-06-23 03:14:47.380988
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import pytest
    source1 = 'deb http://archive.canonical.com/ubuntu hardy partner'
    source2 = 'deb http://dl.google.com/linux/chrome/deb/ stable main'
    source3 = 'deb-src http://archive.canonical.com/ubuntu hardy partner'
    sources = '%s\n# %s\n%s\n' % (source1, source2, source3)

    module = {}

    class mock_open(object):
        def __init__(self, sources):
            self.sources = sources
            self.content = self.sources.split('\n')

        def __call__(self, *args, **kwargs):
            return self

        def __iter__(self):
            return self

        def __next__(self):
            line = ''


# Generated at 2022-06-23 03:14:59.542985
# Unit test for function main
def test_main():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 03:15:04.155404
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(
        argument_spec=dict(
            apt_pkg_name='python-apt',
        ),

        supports_check_mode=True,
    )
    if module.check_mode:
        module.exit_json(changed=True)
    else:
        module.exit_json(changed=True)


# Generated at 2022-06-23 03:15:13.327340
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import pytest

    class Module(object):
        class FailJson(BaseException):
            def __init__(self, msg):
                print(msg)
                pass

        @staticmethod
        def atomic_move(tmp_path, filename):
            pass

        @staticmethod
        def set_mode_if_different(filename, this_mode, sudoable):
            pass

    def _apt_cfg_file(filespec):
        return '/etc/apt/sources.list'

    def _apt_cfg_dir(dirspec):
        return '/etc/apt/sources.list.d'

    class ModuleDict(dict):
        def __init__(self, implements=None):
            self.implements = implements or {}

    module = ModuleDict(implements={'apt_repository': Module})


# Generated at 2022-06-23 03:15:16.759283
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    assert UbuntuSourcesList(None) is not None

# =========================================================================
# This is a helper class/module used to test changes in apt-sources with
# 'diff' mode. It is used internally.
# =========================================================================

# Generated at 2022-06-23 03:15:27.568087
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list function'''

# Generated at 2022-06-23 03:15:36.667551
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''
    Test method modify of class SourcesList
    '''

# Generated at 2022-06-23 03:15:47.461930
# Unit test for function install_python_apt
def test_install_python_apt():

    # Create dummy AnsibleModule instance.
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    am = AnsibleModule(argument_spec={}, supports_check_mode=True, check_invalid_arguments=False)
    am.params['install_python_apt'] = True

    # Mock run_command with default return values.
    # See http://www.diveintopython.net/unit_testing/mocking_resources.html
    original_run_command = am.run_command

# Generated at 2022-06-23 03:15:56.564466
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule:
        def __init__(self):
            self.params = {
                'codename': 'xenial',
            }

        def fail_json(self, *args, **kwargs):
            raise ValueError('fail_json: {} {}'.format(args, kwargs))

    # code under test
    module = MockModule()
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.remove_source('ppa:foo/bar')
    assert len(sources_list.files) == 0



# Generated at 2022-06-23 03:16:05.494094
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    lines = [
        'deb http://archive.canonical.com/ubuntu xenial partner',
        '# deb-src [arch=amd64] http://archive.canonical.com/ubuntu xenial partner',
        'deb [arch=armhf] http://archive.canonical.com/ubuntu xenial partner',
        '# deb http://dl.google.com/linux/chrome/deb/ stable main',
        'deb [arch=i386] http://dl.google.com/linux/chrome/deb/ stable main',
    ]