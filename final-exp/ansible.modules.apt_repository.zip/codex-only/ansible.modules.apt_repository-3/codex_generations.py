

# Generated at 2022-06-23 03:06:14.558951
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # simple test to check if dump works as expected
    import tempfile
    import os
    import shutil
    import ansible.module_utils.basic

    line1 = 'deb http://localhost/qemu qemu/debian stretch main'
    line2 = '# deb-src http://localhost/qemu qemu/debian stretch main'
    line3 = 'deb-src http://localhost/qemu qemu/debian stretch main'
    line4 = 'line4'
    line5 = '# line5'
    line6 = 'deb http://localhost/qemu qemu/debian stretch main # line5'


# Generated at 2022-06-23 03:06:25.860526
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class TestModule(object):
        params = {
        }
        fail_json = fail_json
        exit_json = exit_json
        atomic_move = atomic_move

        def __init__(self):
            self.files = {}
        def set_mode_if_different(self, file, mode, changed):
            pass

    class TestDistro(object):
        def __init__(self):
            self.codename = 'xenial'

    class MockedResponse(object):
        class info(object):
            def __init__(self):
                self.status = ''
            def getheader(self, header):
                return ''

        def read(self):
            return ''

    def test_fetch_url(self, module, url, **kwargs):
        return MockedResponse(), MockedResponse()



# Generated at 2022-06-23 03:06:31.523786
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class Module(object):
        def __init__(self):
            self.params = {}
        def atomic_move(self, src, dst):
            pass
        def set_mode_if_different(self, path, mode, changed):
            pass
        def fail_json(self, **kwargs):
            pass
        def get_bin_path(self, name):
            return "apt-get"
        def run_command(self, cmd):
            return 1, '', ''

    sl = SourcesList(Module())

    assert list(sl) == []

# Unit tests for class SourcesList

# Generated at 2022-06-23 03:06:44.958781
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    sl = SourcesList(module)

    # empty
    sl.save()
    assert os.path.isfile(sl.default_file)

    # all in one file
    lines = [
        'deb http://debian.com/debian/ test contrib',
        'deb http://debian.com/ubuntu/ test restricted universe',
    ]
    for line in lines:
        sl.add_source(line)
    sl.save()
    with open(sl.default_file) as f:
        assert f.readlines() == lines

    # add to a new file
    sl.add_source('deb http://debian.com/debian/ test multiverse')
    sl.add_source('deb http://debian.com/debian/ test main', file='debian_main')
    sl.save()


# Generated at 2022-06-23 03:06:54.014280
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    test_module = AnsibleModule(argument_spec={'codename': dict(default='trusty')})
    test_sl = UbuntuSourcesList(test_module)

    # Invalid sources
    line = 'foo://bar'
    test_sl.add_source(line)
    assert test_sl.files == {}

    # Valid sources
    line = 'deb http://example.com/ubuntu trusty main universe'
    test_sl.add_source(line)
    assert test_sl.files == {'/etc/apt/sources.list.d/example.com.list': [(0, True, True, line, '')]}
    test_sl.dump()

    # Correct, but duplicate sources.
    test_sl.add_source(line)

# Generated at 2022-06-23 03:07:03.384740
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)
    f = StringIO('\n'.join([line for line in ['# Comment line', 'Invalid line', '# Disabled source', 'deb http://archive.canonical.com/ubuntu hardy partner', 'deb-src http://archive.canonical.com/ubuntu hardy partner']]))

    file_mock = mock.mock_open()
    with mock.patch('builtins.open', file_mock):
        file_mock.return_value = f
        sl = SourcesList(module)
        assert sl.default_file == 'sources.list'

# Generated at 2022-06-23 03:07:10.789192
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    repo_present = "deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main"
    repo_absent = "deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main"
    repo_present_ppa = "ppa:ansible/ansible"
    repo_absent_ppa = "ppa:ansible/ansible1"
    repo_present_ppa_name = "ppa:ansible"
    repo_absent_ppa_name = "ppa:ansible1"
    add_ppa_callback = None
    file = "ansible"
    comment = ""
    class module:
        def __init__(self):
            self.params={}
            self.params['codename']=""
    list = UbuntuSourcesList(module=module(), )

    list.add_source

# Generated at 2022-06-23 03:07:20.405784
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = type('Module', (), {'check_mode': False, 'atomic_move': None})
    sources = SourcesList(module)

    # Add 3 sources
    sources.add_source('deb http://example.com/debian stable main')
    sources.add_source('deb http://example.com/debian stable main')
    sources.add_source('deb http://example.com/debian stable main')

    # Add 3 disabled sources
    sources.add_source('#deb http://example.com/debian stable main')
    sources.add_source('#deb http://example.com/debian stable main')
    sources.add_source('#deb http://example.com/debian stable main')

    # Add 1 commented source
    sources.add_source('# deb http://example.com/debian stable main')

    # Add 2 source with comments
   

# Generated at 2022-06-23 03:07:25.585169
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    obj = UbuntuSourcesList(module=None)
    obj.files = {
        'foo/bar/baz.list': [
            (
                0,
                True,
                True,
                'deb http://ppa.launchpad.net/ansible/ansible/ubuntu  main',
                ''
            )
        ]
    }
    obj.remove_source(line='ppa:ansible/ansible')
    assert obj.files == {}

# Generated at 2022-06-23 03:07:30.848851
# Unit test for function install_python_apt
def test_install_python_apt():
    '''Unit test for function install_python_apt
    '''
    # Create a mocked module
    test = AnsibleModule(argument_spec={})
    # Create a mocked apt_get command with status 0
    test.run_command = MagicMock(return_value=(0,'','no error'))
    # Try to install
    install_python_apt(test, 'python-apt')
    test.run_command.assert_called_with(['apt-get', 'update'])
    test.run_command.assert_called_with(['apt-get', 'install', 'python-apt', '-y', '-q'])


# Generated at 2022-06-23 03:07:42.507943
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    from ansible.modules.packaging.os import apt_repository
    module = apt_repository._get_module()

    sources_list = apt_repository.SourcesList(module)
    
    # returns the current testdata directory
    currentdir = os.path.dirname(os.path.abspath(__file__))
    test_data_dir = os.path.join(currentdir, 'testdata')
    
    # returns a list of the test files
    test_file_list = os.listdir(test_data_dir)
    for test_file in test_file_list:
        if test_file == 'test_SourcesList_remove_source':
            continue
        file_path = os.path.join(test_data_dir, test_file)
        # loads the content of the test

# Generated at 2022-06-23 03:07:50.886753
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import pytest

# Generated at 2022-06-23 03:08:02.677932
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule('', {'fake': True})
    sl = SourcesList(module)
    sl.files = {'/tmp/sources.list': [
        (0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '# a comment'),
    ]}
    sl.save()
    assert os.path.exists('/tmp/sources.list')
    with open('/tmp/sources.list', 'r') as f:
        assert f.readlines() == ['deb http://archive.canonical.com/ubuntu hardy partner\n']
    sl.files = {'/tmp/sources.list': []}
    sl.save()
    assert not os.path.exists('/tmp/sources.list')


# Generated at 2022-06-23 03:08:12.246464
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Create SourceList instance to work with
    class FakeAnsibleModule(object):
        params = dict()

    fake_module = FakeAnsibleModule()
    sl = SourcesList(fake_module)

    def test_source(source):
        return source.strip() == 'deb http://archive.ubuntu.com/ubuntu natty main restricted universe'

    test_iter = iter(sl)

    # Add source to existing file
    sl.add_source('deb http://archive.ubuntu.com/ubuntu natty main restricted universe')
    assert test_source(next(test_iter)[3]) is True

    # Add source to newly created file
    sl.add_source('deb http://archive.ubuntu.com/ubuntu oneiric main restricted universe', file='test.list')

# Generated at 2022-06-23 03:08:25.628950
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    '''
    We are asserting the properties of object returned by __deepcopy__ against the object
    being passed as an argument. If the argument object is modified, there should not be any change
    to the object returned as it is a clone.
    '''

    module = AnsibleModule(argument_spec={})
    module.params = {}
    modifiable_data = {'module': module, 'codename': ''}
    readonly_data = {'add_ppa_signing_keys_callback': None}
    sl = UbuntuSourcesList(module)
    sl.__dict__.update(modifiable_data)
    sl.__dict__.update(readonly_data)
    sl2 = deepcopy(sl)
    assert_equal(sl2.__dict__, sl.__dict__)


# Generated at 2022-06-23 03:08:37.326113
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class GenericModule(object):
        def __init__(self):
            self.params = dict(filename=None)

    module = GenericModule()
    sources_list = SourcesList(module)
    my_file = '/tmp/my_sources.list'
    file_content = "deb http://archive.canonical.com/ubuntu trusty partner\n" \
                   "# deb http://archive.canonical.com/ubuntu trusty partner\n"
    f = open(my_file, 'w')
    f.write(file_content)
    f.close()
    sources_list.load(my_file)
    try:
        os.remove(my_file)
    except OSError as e:
        print("Error: %s : %s" % (my_file, e.strerror))

# Generated at 2022-06-23 03:08:39.843521
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load("sources.list")
    sources_list.save()


# Generated at 2022-06-23 03:08:53.154274
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sourceslist = SourcesList(module)
    sourceslist.files = {
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', None),
            (1, True, False, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', 'comment'),
            (2, False, False, 'deb http://archive.ubuntu.com/ubuntu/ xenial universe', None),
        ],
        '/etc/apt/sources.list.d/luke-bluewind.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/luke-bluewind/ppa/ubuntu xenial main', None),
        ],
    }

   

# Generated at 2022-06-23 03:08:55.970522
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sm = SourcesList
    pass



# Generated at 2022-06-23 03:08:58.156757
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    x = InvalidSource()
    assert x.args[0] == 'Invalid source specified'



# Generated at 2022-06-23 03:09:10.053266
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sourcesList = SourcesList(module)

    fileName = "tests/ansible_modlib.ansible_modlib_apt_repository.sourcesList"
    file = open(fileName, "r")
    i = 0
    file.readline()
    while True:
        line = file.readline()
        if not line:
            break
        source = sourcesList._parse(line, raise_if_invalid_or_disabled=True)[2]
        comment = sourcesList._parse(line, raise_if_invalid_or_disabled=True)[3]
        sourcesList.add_source(line, comment, fileName)
        sourcesList.modify(fileName, i, commented = " # ")

# Generated at 2022-06-23 03:09:18.790092
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    m = AnsibleModule({ 'state': 'present', 'repo': 'deb http://download.webmin.com/download/repository sarge contrib' })
    s = SourcesList(m)
    s.add_source(m.params['repo'])
    s.save()
    assert os.path.exists('/etc/apt/sources.list')


# Generated at 2022-06-23 03:09:27.809148
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec=dict())
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)
    assert add_ppa_signing_key_callback is None, 'action should not be set in check mode'

    module = AnsibleModule(argument_spec=dict(), check_mode=False)
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)
    assert callable(add_ppa_signing_key_callback), 'action should be set when check_mode is disabled'
    assert add_ppa_signing_key_callback(['true']) is None, 'no error expected from _run_command(), but returned %s' % add_ppa_signing_key_callback(['true'])



# Generated at 2022-06-23 03:09:32.028890
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-23 03:09:33.602340
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except InvalidSource:
        pass


# Generated at 2022-06-23 03:09:34.777557
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # TBD

    assert False


# Generated at 2022-06-23 03:09:45.657460
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, filename):
            self.basic = basic.AnsibleModule(argument_spec={
                'mode': dict(default=None, type='str'),
                'filename': dict(type='str')
            })
            self.params = {'filename': filename}

        def run_command(self, *args, **kwargs):
            return 0, '', ''

        def set_mode_if_different(self, *args, **kwargs):
            pass

        def atomic_move(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            raise Exception(args[0])


# Generated at 2022-06-23 03:09:55.465529
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    dumpstruct = {'/etc/apt/sources.list': '''
deb http://archive.ubuntu.com/ubuntu/ trusty main restricted multiverse universe
deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted multiverse universe

''', '/etc/apt/sources.list.d/ansible-generated.list': '''
deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main
deb-src http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main
'''}
    module.atomic_move = lambda src, dst: None
    module.set_mode_if_different = lambda path, mode, changed=True, follow=True: None
    sources.add_source

# Generated at 2022-06-23 03:10:08.497750
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict(
        repo=dict(type='str'),
        filename=dict(type='str'),
        state=dict(type='str', default='present', choices=['present', 'absent']),
        mode=dict(type='raw'),
    ), )
    module.params['repo'] = 'deb http://archive.canonical.com/ubuntu hardy partner'
    module.params['filename'] = 'arch_repo.list'
    module.params['state'] = 'present'
    module.params['mode'] = None

    # call the method to test
    sl = SourcesList(module)
    sl.add_source(repo, filename='arch_repo.list')
    sl.remove_source(repo)
    sl.save()
    assert sl.dump() == {}

# Generated at 2022-06-23 03:10:15.441576
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    s = SourcesList()
    # when files is empty
    assert list(s) == []
    # when files is not empty
    s.files = {'/etc/apt/sources.list.d/test_SourcesList___iter__.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]}
    assert list(s) == [('/etc/apt/sources.list.d/test_SourcesList___iter__.list', 0, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]


# Generated at 2022-06-23 03:10:25.296713
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    test_sources_list = SourcesList
    test_sources_list.files = {1: [(1, True, False, "deb cdrom:[Debian GNU/Linux 8 _Jessie_ - Official Snapshot amd64 LIVE/INSTALL Binary 20160510-12:45]/ jessie contrib main", "")]}
    test_sources_list.modify(1, 1, enabled=None, source=None, comment="Comment")
    assert test_sources_list.files[1][1][1] == True
    assert test_sources_list.files[1][1][3] == "deb cdrom:[Debian GNU/Linux 8 _Jessie_ - Official Snapshot amd64 LIVE/INSTALL Binary 20160510-12:45]/ jessie contrib main"

# Generated at 2022-06-23 03:10:34.566829
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():

    class DummyModule(object):
        def __init__(self, params):
            self.params = params
            self.check_mode = params['check_mode']
        def run_command(self, args, check_rc=True):
            pass

    params = {
        'check_mode': False
    }
    mock_module = DummyModule(params)
    assert get_add_ppa_signing_key_callback(mock_module) is not None

    params = {
        'check_mode': True
    }
    mock_module = DummyModule(params)
    assert get_add_ppa_signing_key_callback(mock_module) is None



# Generated at 2022-06-23 03:10:43.932442
# Unit test for function main
def test_main():
    sys.modules['apt'] = MagicMock(apt)
    sys.modules['aptsources.distro'] = MagicMock(aptsources_distro)

    sys.modules['aptsources.distro'].Distribution.return_value = aptsources_distro.Distribution()

    module = MagicMock(AnsibleModule)
    module.params = {
        'repo': 'https://repo.com/repo.deb',
        'state': 'present',
        'mode': '0644',
        'update_cache': True,
        'update_cache_retries': 5,
        'update_cache_retry_max_delay': 12,
        'filename': '/etc/apt/sources.list.d/repo.list'
    }
    module.check_mode = False
   

# Generated at 2022-06-23 03:10:53.012964
# Unit test for constructor of class UbuntuSourcesList

# Generated at 2022-06-23 03:11:03.820252
# Unit test for function main
def test_main():
    import sys
    from ansible.module_utils.basic import AnsibleModule
    
    # Read in the XML for the module

# Generated at 2022-06-23 03:11:13.346369
# Unit test for function revert_sources_list
def test_revert_sources_list():
    temp_dir = tempfile.mkdtemp()
    self = dict(sources_before=[],sources_after=[],sourceslist_before=[])
    self['sourceslist_before'] = UbuntuSourcesList(self, add_ppa_signing_keys_callback=None)
    self['sourceslist_before'].files = {os.path.join(temp_dir, 'sources_temp.list'): ['', '']}
    self['sources_before'] = self['sourceslist_before'].dump()
    self['sourceslist_before'].save()
    sourceslist_after = UbuntuSourcesList(self, add_ppa_signing_keys_callback=None)
    sourceslist_after.load(self['sourceslist_before'].files.keys()[0])

# Generated at 2022-06-23 03:11:24.042134
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    module.fail_json = lambda msg: msg

    sl = SourcesList(module)

    filename = tempfile.mktemp()
    content = """
    # deb file:///mirror/ localrepo main

    # deb-src http://archive.ubuntu.com/ubuntu trusty main restricted universe multiverse

    # deb http://puppetlabs.com/debian trusty main
    deb [arch=amd64]  http://archive.canonical.com/ubuntu hardy partner

    # deb http://rabbitmq.com/debian/ testing main
    deb http://ppa.launchpad.net/fkrull/deadsnakes/ubuntu trusty main
    deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main
    """


# Generated at 2022-06-23 03:11:36.360145
# Unit test for function main
def test_main():
    from ansible.module_utils.apt import apt_pkg
    from ansible.module_utils.apt import aptsources_distro
    from ansible.module_utils.apt import aptsources
    sys.modules['apt_pkg'] = apt_pkg
    sys.modules['aptsources.distro'] = aptsources_distro
    sys.modules['aptsources'] = aptsources
    sys.modules['aptsources.distro'].codename = "test"
    sys.modules['aptsources.distro'].series = "test"
    sys.modules['aptsources.distro'].__package__ = "test"
    sys.modules['aptsources.distro'].__name__ = "test"

# Generated at 2022-06-23 03:11:45.020414
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class FakeModule:
        def fail_json(self, **kwargs):
            print(kwargs)
            assert False
        def atomic_move(self, src, dst):
            pass
        def set_mode_if_different(self, src, dst, b):
            pass
    sl = SourcesList(FakeModule())
    sl.add_source('deb http://repo1.com foo1')
    sl.add_source('deb http://repo2.com foo2')
    sl.add_source('deb http://repo1.com foo3')
    sl.add_source('#deb http://repo3.com foo4')
    sl.remove_source('deb http://repo1.com foo1')

# Generated at 2022-06-23 03:11:55.227326
# Unit test for function main
def test_main():
    # Test for absence of parameter sources_path (should default to /etc/apt/sources.list)
    sources_path = None
    sudo = False
    if getattr(sys, 'frozen', None):
        sources_path = 'C:\\Ansible\\ansible-2.3.2.0\\lib\\site-packages\\ansible\\modules\\packaging\\os\\apt_repository.py'
    assert sources_path == '/etc/apt/sources.list', 'sources_path (); expected /etc/apt/sources.list '
    # Test for absence of parameter sudo (should default to False)
    assert sudo == False, 'sudo (); expected False'


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:11:58.562130
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    assert install_python_apt(module, 'python-apt') == None, "Failed to install python-apt"


# Generated at 2022-06-23 03:12:09.743699
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # When check_mode is True return callback which returns None
    module = mock.MagicMock()
    module.check_mode = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    # When check_mode is False return callback which calls run_command function
    module = mock.MagicMock()
    module.check_mode = False
    callback = get_add_ppa_signing_key_callback(module)
    command = ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'XYZ']
    callback(command)
    module.run_command.assert_called_once_with(command, check_rc=True)



# Generated at 2022-06-23 03:12:23.569896
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import os
    import shutil
    import random
    import time
    import errno
    from ansible.module_utils._text import to_bytes

    # Create test directory and files
    old_dir = os.path.join(tempfile.mkdtemp(), 'etc')
    apt_cfg_dir_ = os.path.join(old_dir, 'apt')
    dirs = [
        os.path.join(apt_cfg_dir_, 'apt.conf.d'),
        os.path.join(apt_cfg_dir_, 'preferences.d'),
        os.path.join(old_dir, 'apt', 'lists', 'partial'),
    ]

# Generated at 2022-06-23 03:12:34.059911
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import os
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import contextlib

    @contextlib.contextmanager
    def temp_file(content):
        '''
        Create new temp file with specified content.

        Example:
            with temp_file('test_file.txt', 'Hello World!') as temp:
                print(open(temp).read())
        '''
        fd, filename = tempfile.mkstemp(prefix='apt_')
        open(filename, 'w').write(content)
        os.close(fd)
        yield filename
        os.remove(filename)

    sl = SourcesList(None)

# Generated at 2022-06-23 03:12:39.237780
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: None
    module.fail_json = lambda x: None
    module.run_command = lambda x: (0, '', '')
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-23 03:12:48.665342
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    '''
    Tests the function remove_source
    '''
    class TestModule(object):
        '''
        Fake AnsibleModule class
        '''
        def __init__(self, params, add_ppa_signing_keys_callback):
            self.params = params
            self.add_ppa_signing_keys_callback = add_ppa_signing_keys_callback

    def add_ppa_signing_keys_callback(self, command):
        '''
        Fake add_ppa_signing_keys_callback.
        '''

    ppa_simple = 'ppa:foo/bar'
    ppa_complex = 'ppa:foo/bar/baz'

    test_1 = UbuntuSourcesList(TestModule({}, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback))

# Generated at 2022-06-23 03:12:58.682277
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils._text import to_bytes, to_str
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import (
        HTTPHandler,
        HTTPSHandler,
        HTTPRedirectHandler,
        Request,
        build_opener,
        urlopen
    )

    class MockResponse(object):
        def __init__(self, text):
            self.text = text


# Generated at 2022-06-23 03:13:09.959319
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    import unittest

    class TestUbuntuSourcesList(unittest.TestCase):

        def setUp(self):
            self.ubuntu_sources_list = UbuntuSourcesList(None)

# Generated at 2022-06-23 03:13:22.342232
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class FakeModule(object):
        def __init__(self, result):
            self.result = result

        def fail_json(self, **kwargs):
            print(kwargs)

    class FakeFile(object):
        def __init__(self, contents):
            self.contents = contents
            self.i = 0
            self.closed = False

        def close(self):
            self.closed = True

        def __iter__(self):
            return self

        def __next__(self):
            if self.i >= len(self.contents):
                raise StopIteration()
            else:
                self.i += 1
                return self.contents[self.i - 1]

        next = __next__


# Generated at 2022-06-23 03:13:31.467502
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    src_list = SourcesList(module)
    assert len(src_list.files) > 0

    src_list = SourcesList(module)
    src_list.remove_source("deb http://us.archive.ubuntu.com/ubuntu/ trusty multiverse")
    src_list.save()
    assert len(src_list.files) > 0

    src_list = SourcesList(module)
    assert len(src_list.files) > 0

    count = 0
    for filename, sources in src_list.files.items():
        count += len(sources)
    assert count > 0

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4:

# Generated at 2022-06-23 03:13:42.823532
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    import string
    import random
    module = AnsibleModule(argument_spec={})
    sample_line = 'deb http://ppa.launchpad.net/%s/%s/ubuntu %s main' % (
        ''.join(random.choice(string.ascii_letters) for _ in range(10)),
        ''.join(random.choice(string.ascii_letters) for _ in range(10)),
        ''.join(random.choice(string.ascii_letters) for _ in range(10))
    )
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source(sample_line)

    assert sample_line in sources_list.repos_urls, 'URL "%s" not found' % sample_line



# Generated at 2022-06-23 03:13:48.605794
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    line = "deb http://mirrors.tuna.tsinghua.edu.cn/ubuntu/ xenial main restricted"
    comment = "not comment"
    filename = "testcase.list"
    SourcesList = SourcesList(AnsibleModule({}))
    #SourcesList.add_source(line,comment,filename)
    SourcesList.add_source(line,comment)
# test_SourcesList_add_source()



# Generated at 2022-06-23 03:14:00.676197
# Unit test for function revert_sources_list

# Generated at 2022-06-23 03:14:06.313206
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Testing for old Python versions (such as 2.5) that does not have 'assertIn' and 'assertNotIn'.
    # This will not affect newer Python versions.
    import sys
    if sys.version_info[0] > 2:
        # Python 3
        from unittest.case import TestCase
    else:
        # Python 2.5, 2.6, 2.7
        from unittest2.case import TestCase

    class MyTestCase(TestCase):
        def assertIn(self, member, container, msg=None):
            if not msg:
                msg = "%r not in %r" % (member, container)

            self.assertTrue(member in container, msg)


# Generated at 2022-06-23 03:14:09.903015
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    obj = UbuntuSourcesList(None, add_ppa_signing_keys_callback=None)
    expected = UbuntuSourcesList
    actual = type(copy.deepcopy(obj))
    assert expected == actual



# Generated at 2022-06-23 03:14:17.778453
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils.basic import AnsibleModule
    import testdata.sources_list as sources_list_testdata
    testdata = sources_list_testdata.get_test_data()
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load(testdata.get("file"))
    count = 0
    for file, n, enabled, source, comment in sl:
        assert type(file) is str
        assert type(n) is int
        assert type(enabled) is bool
        assert type(source) is str
        assert type(comment) is str
        count += 1
    assert count == testdata.get("count")



# Generated at 2022-06-23 03:14:22.126570
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    # Enabling the following line would throw exception
    assert not sl.files
    # No exception thrown
    sl.dump()



# Generated at 2022-06-23 03:14:32.630847
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    sources = SourcesList(module)
    sources.load('yum.repositories.txt')

    sources_out = SourcesList(module)
    for filename, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            sources_out.modify(filename, n, enabled=True, comment='comment')
    assert sources_out.files == sources.files

    sources_out = SourcesList(module)
    for filename, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            sources_out.modify(filename, n, source='oops')
    assert sources_out.files == sources.files



# Generated at 2022-06-23 03:14:33.302540
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-23 03:14:41.907217
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = MagicMock()
    sources_list = SourcesList(module)
    sources_list._add_valid_source('deb http://archive.canonical.com/ubuntu raring partner', 'key=value', file='/etc/apt/sources.list.d/raring.list')
    sources_list.save()
    assert os.path.isfile('/etc/apt/sources.list.d/raring.list')
    fd = open('/etc/apt/sources.list.d/raring.list')
    assert fd.read() == 'deb http://archive.canonical.com/ubuntu raring partner'
# Checksum type to use

# Generated at 2022-06-23 03:14:54.448232
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os, shutil, stat
    import tempfile
    from itertools import chain

    def compare_file_content(file, content):
        with open(file, 'r') as f:
            return f.read() == content

    def test_sources_list_save_itself(tmp_path):
        '''
        Check that save works with itself.
        '''
        sources = SourcesList(None)
        sources.add_source('deb http://example.com/debian foo bar')

        sources.save()
        sources.load(os.path.join(tmp_path, 'sources.list'))

        assert len(list(sources)) == 2

# Generated at 2022-06-23 03:15:03.212762
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Set up mocks
    tempfile_mock = mock.MagicMock()
    tempfile_mock.side_effect = [
        ('', 'path/to/file.list'),
        ('', 'path/to/file2.list'),
    ]
    os_mock = mock.MagicMock()
    os_mock.path.abspath.return_value = 'path_to_abspath'
    os_mock.path.exists.return_value = False
    os_mock.path.isdir.return_value = False

    fd_mock = mock.MagicMock()
    open_mock = mock.mock_open()
    fd_mock.__enter__.return_value = open_mock
    module_mock = mock.MagicMock()

   

# Generated at 2022-06-23 03:15:10.658259
# Unit test for function revert_sources_list
def test_revert_sources_list():
    for test_file in os.listdir('./test/unit/modules/test_apt_module/files'):
        with open('./test/unit/modules/test_apt_module/files/'+test_file) as f:
            data = f.read()

        fd, path = tempfile.mkstemp(prefix='.%s-' % test_file)

        with os.fdopen(fd, 'w') as f:
            f.write(data)

        yield test_revert_sources_list_helper, test_file, path

        os.remove(path)



# Generated at 2022-06-23 03:15:22.874740
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # init
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = '/file.list'
    sl = UbuntuSourcesList(
        module,
        add_ppa_signing_keys_callback=lambda command: module.run_command(command),
    )
    # test

# Generated at 2022-06-23 03:15:25.544290
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    "Ensure that the exception is thrown correctly"
    try:
        raise InvalidSource("Test")
    except InvalidSource as e:
        assert "Test" == str(e)



# Generated at 2022-06-23 03:15:35.133434
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/tmp/testfile')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='some comment')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='some comment', file='/tmp/testfile')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='')


# Generated at 2022-06-23 03:15:41.166609
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class FakeModule:
        def __init__(self):
            self.params = {}

    m = FakeModule()
    sources = SourcesList(m)

    for file, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            yield (file, n, enabled, source, comment)



# Generated at 2022-06-23 03:15:47.457280
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import mock
    m = mock.MagicMock()
    cb = get_add_ppa_signing_key_callback(m)
    assert cb is None
    m.check_mode = False
    cb = get_add_ppa_signing_key_callback(m)
    assert cb is not None
    cb(['command'])
    m.run_command.assert_called_with(['command'], check_rc=True)


# Generated at 2022-06-23 03:15:57.396131
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """
    test_SourcesList_save_1
    """
    # create temp dir with sources.list
    tmp_dir = tempfile.mkdtemp()
    os.mkdir(os.path.join(tmp_dir, 'sources.list.d'))
    tmp_file = os.path.join(tmp_dir, 'sources.list')
    tmp_file2 = os.path.join(tmp_dir, 'sources.list.d', 'test.list')

    # create empty sources.list
    with open(tmp_file, 'w') as tmp_file_fh:
        pass

    # call _apt_cfg_dir to override default dir spec -> /etc/apt
    module = AnsibleModule({})
    target_dir = os.path.dirname(tmp_file)
    SourcesList._apt

# Generated at 2022-06-23 03:15:58.813915
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    assert True


# Generated at 2022-06-23 03:16:10.886514
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    def test_case(data, expected):
        class DummyModule(object):
            def __init__(self):
                self.params = { 'filename': None }
                self.atomic_move = lambda source, dest: None
                self.set_mode_if_different = lambda dest, perm, changed: None
                self.get_bin_path = lambda t: None
                self.run_command = lambda argv, **kwargs: (0, "", None)
                self.fail_json = lambda **kwargs: None

        class DummyAptPkgConfig(object):
            def __init__(self):
                self.file_ = lambda filespec: None
                self.dir_ = lambda dirspec: None

        class DummyAptPkg(object):
            def __init__(self):
                self.config = D