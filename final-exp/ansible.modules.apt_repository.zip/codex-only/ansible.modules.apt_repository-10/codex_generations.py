

# Generated at 2022-06-23 03:06:13.608447
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test case #1
    line = 'deb http://ppa.launchpad.net/linuxuprising/apps/ubuntu disco main'
    result = 'deb http://ppa.launchpad.net/linuxuprising/apps/ubuntu disco main # Added by Ansible\n'
    test_class = UbuntuSourcesList(None)
    test_class.add_source(line, comment='Added by Ansible')
    assert list(test_class.files.values())[0][0] == (
        0,
        True,
        True,
        line,
        'Added by Ansible'
    )

    # Test case #2
    file = 'linuxuprising.list'
    result = 'deb http://ppa.launchpad.net/linuxuprising/apps/ubuntu disco main # Added by Ansible\n'
    test_class = UbuntuSources

# Generated at 2022-06-23 03:06:20.197498
# Unit test for function main
def test_main():
    assert install_python_apt(module, apt_pkg_name)
    assert respawn_module(interpreter)
    assert probe_interpreters_for_module(interpreters, 'apt')
    assert get_add_ppa_signing_key_callback(module)


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:06:30.080678
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sl = SourcesList(AnsibleModule(argument_spec={}, check_invalid_arguments=False))
    assert len(list(sl)) == 0


# Generated at 2022-06-23 03:06:42.435149
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.apt import SourcesList

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        @staticmethod
        def fail_json(msg):
            raise Exception(msg)

        @staticmethod
        def atomic_move(src, dst):
            os.rename(src, dst)

        @staticmethod
        def set_mode_if_different(path, mode, changed, diff=None):
            pass

    sources_list = SourcesList(MockModule())

    def check_file(filename):
        # Validate file
        f = open(filename, 'r')
        lines = f.readlines()
        f.close()
        assert len(lines) == 2

# Generated at 2022-06-23 03:06:53.169099
# Unit test for function main
def test_main():
    import xml.dom.minidom
    import sys
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import StringIO

    if not PY3:
        reload(sys)
        sys.setdefaultencoding('utf8')

    # Create a module with given parameter spec and a dictionary of return values.

# Generated at 2022-06-23 03:07:03.420518
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({})
    def run_command(command):
        command.should.be.equal(['/usr/bin/add-apt-repository', '--yes', 'ppa:foo/bar'])
    module.run_command = run_command
    ubuntu_sources = UbuntuSourcesList(module)
    assert ubuntu_sources.add_ppa_signing_keys_callback is None

    ubuntu_sources.add_ppa_signing_keys_callback = get_add_ppa_signing_key_callback(module)
    ubuntu_sources.add_ppa_signing_keys_callback(['/usr/bin/add-apt-repository', '--yes', 'ppa:foo/bar'])



# Generated at 2022-06-23 03:07:07.172672
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sourcelist = SourcesList()
    sourcelist.files = {'/file':[(0, True, True, 'foo', ''), (1, True, False, 'bar', '')]}

    sourcelist.remove_source('foo') # test remove enabled source
    assert sourcelist.files['/file'] == [(0, True, False, 'bar', '')]

    sourcelist.remove_source('bar') # test remove disabled source
    assert sourcelist.files['/file'] == []


# Generated at 2022-06-23 03:07:17.920165
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import argparse
    import ansible.module_utils.basic
    import ansible.module_utils.common.respawn
    import tempfile
    import atexit
    import shutil
    import os.path

    parser = argparse.ArgumentParser()
    ansible.module_utils.basic.add_default_arguments(parser)
    args, unknown = parser.parse_known_args()
    args = vars(args)
    args['respawn_automatically'] = False
    ansible.module_utils.common.respawn.main(args)

    @atexit.register
    def cleanup_test_dir():
        shutil.rmtree(test_dir)

    test_dir = tempfile.mkdtemp()
    default_file = os.path.join(test_dir, "sources.list")

# Generated at 2022-06-23 03:07:18.876730
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert InvalidSource('Some message')



# Generated at 2022-06-23 03:07:28.126568
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    lines = [
        "deb http://debian.org/debian buster main contrib non-free\n",
        "# deb http://debian.org/debian buster main contrib non-free\n",
        "deb http://debian.org/debian buster main contrib non-free # some comment\n",
        "# deb http://debian.org/debian buster main contrib non-free # some comment\n",
        "deb http://debian.org/debian buster main contrib non-free # some comment\n",
    ]
    source_list = []
    for line in lines:
        source_list.append(re.sub("#.*", "", line))

    f = open("/tmp/test_SourcesList_load", "w")
    for line in lines:
        f.write(line)
    f.close()

# Generated at 2022-06-23 03:07:28.702389
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass

# Generated at 2022-06-23 03:07:30.321136
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert [True, True, True, True] == list(SourcesList.__iter__)

# Generated at 2022-06-23 03:07:41.513772
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class Module(object):
        def fail_json(self, msg):
            raise Exception(msg)
    module = Module()

    test_file = tempfile.mktemp()
    with open(test_file, 'w') as f:
        f.write('deb http://host/path\n')
        f.write('#deb http://host2/path2\n')

    sl = SourcesList(module)
    sl.load(test_file)

    sl.modify(test_file, 0, source='deb http://host/path changed')
    sl.modify(test_file, 1, enabled=True, comment='comment')

    with open(test_file) as f:
        changed_source = f.read()
    os.remove(test_file)


# Generated at 2022-06-23 03:07:46.515632
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class Module:
        def run_command(self, command, check_rc=True):
            pass

        def check_mode(self):
            return False

    module = Module()
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-23 03:07:55.873843
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    sourceslist = SourcesList(None)
    sourceslist.files = {'/tmp/a': [(0, True, True, 'deb htt://p/d1/u1 stable partner', ''),],
                          '/tmp/b': [(0, True, True, 'deb htt://p/d1/u1 stable partner', ''),],
                          '/tmp/c': [(0, True, False, 'deb htt://p/d1/u1 stable partner', ''),],
                          '/tmp/d': [],
                          }
    sourceslist.new_repos = set(['/tmp/a', '/tmp/b', '/tmp/c'])
    sourceslist.save()
    assert os.path.isfile('/tmp/a')
    assert os.path.isfile('/tmp/b')

# Generated at 2022-06-23 03:08:07.264642
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Global variable - to be removed by class' destructor
    test_data = tempfile.mkdtemp()
    module = AnsibleModule(argument_spec={'state': {'type': 'str', 'choices': ['present', 'absent']}, 'mode': {'type': 'int'},
                                           'filename': {'type': 'str'}})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.set_mode_if_different = MagicMock()
    module.atomic_move = MagicMock(side_effect=lambda src, dst: shutil.move(src, dst))
    module.params = {'state': 'absent', 'mode': None, 'filename': None}
    sources_list = SourcesList(module)
    sources_list.module.params

# Generated at 2022-06-23 03:08:12.420789
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    m = AnsibleModule(argument_spec={})
    sl = SourcesList(m)
    sl.files = {'test' : ['test', 'example']}
    sl.dump()
    return sl.dump()


# Generated at 2022-06-23 03:08:25.672490
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    for line in ('deb http://example.com/debian/ somerepo main contrib',
                 'deb http://example.com/debian/ somerepo',
                 'deb http://example.com/debian/',
                 'http://example.com/debian/ somerepo main contrib',
                 'http://example.com/debian/ somerepo',
                 'http://example.com/debian/',
                 'deb http://example.com/debian/ source main contrib',
                 'deb http://example.com/debian/ source',
                 'deb http://example.com/debian/'):
        sl = SourcesList(module)
        sl.add_source(line)

# Generated at 2022-06-23 03:08:28.204049
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('Invalid source')
    except InvalidSource as e:
        assert str(e) == 'Invalid source'


# Generated at 2022-06-23 03:08:40.210081
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Test remove_source on this source line
    print("Testing SourcesList.remove_source()")
    sourceLine = 'deb http://us.archive.ubuntu.com/ubuntu/ xenial-updates restricted main multiverse universe'
    defaultFile = SourcesList._apt_cfg_file('Dir::Etc::sourcelist')
    # print("Default sources.list file location: {0}".format(defaultFile))

    # Check for file for default sources.list file and create one if not present
    if not os.path.isfile(defaultFile) :
        print("\tCreating new sources.list file")
        print("\t\t{0}".format(defaultFile))
        open(defaultFile, 'a').close()
    else :
        print("\tDefault sources.list file found:")

# Generated at 2022-06-23 03:08:53.595511
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """
    Unit test for remove_source method
    """
    import os
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.respawn import has_respawned, probe_interpreters_for_module, respawn_module

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    class TestSourcesList_RemoveSource_Method(unittest.TestCase):
        """
        Unit test for remove_source method
        """
        @classmethod
        def setUpClass(cls):
            cls.temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 03:09:00.883261
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    global distro
    distro = aptsources_distro.get_distro()
    sl = SourcesList(None)
    sl.files = {'test_filename': [(1, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'comment')]}
    sl.modify('test_filename', 1, comment='new comment')
    assert sl.files == {'test_filename': [(1, True, False, 'deb http://archive.canonical.com/ubuntu hardy partner', 'new comment')]}



# Generated at 2022-06-23 03:09:09.992203
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({}, {})
    # Test correct parses
    sourceslist = SourcesList(module)
    sourceslist.add_source("deb http://deb.debian.org/debian unstable main", "comment")
    assert sourceslist.files['/etc/apt/sources.list'] == [(0, True, True, "deb http://deb.debian.org/debian unstable main", "comment")]
    sourceslist.add_source("deb http://deb.debian.org/debian stable main", "comment")
    assert sourceslist.files['/etc/apt/sources.list'] == [(0, True, True, "deb http://deb.debian.org/debian unstable main", "comment"), (1, True, True, "deb http://deb.debian.org/debian stable main", "comment")]

# Generated at 2022-06-23 03:09:23.568346
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    
    filename = '/tmp/test-unittest_apt.list'
    if os.path.isfile(filename):
        delimiter = '\n'
        with open(filename) as myfile:
            sources = myfile.read()
        source_list = sources.split(delimiter)
    else:
        source_list = []
    apt_repository_obj = SourcesList(module)
    apt_repository_obj.load(filename)
    for i, line in enumerate(apt_repository_obj.files['/tmp/test-unittest_apt.list']):
        assert line[3] == source_list[i]
        assert line[1] == True
        assert line[2] == True
        assert line[0] == i
       

# Generated at 2022-06-23 03:09:29.950548
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    test_module = AnsibleModule(
        argument_spec=dict(
            codename=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    tested_module = UbuntuSourcesList(test_module)

    return tested_module


# Generated at 2022-06-23 03:09:37.644850
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import ImmutableDict
    from ansible.module_utils.apt_repository import Respawn
    from ansible.module_utils.apt_repository import probe_interpreters_for_module
    from ansible.module_utils.apt_repository import respawn_module
    from ansible.module_utils.apt_repository import install_python_apt


# Standard boilerplate to call the main() function to begin the program.
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 03:09:48.775551
# Unit test for function install_python_apt
def test_install_python_apt():
    # Note that fake_module is not the real AnsibleModule class, it is
    # a mock object with a fixed subset of the AnsibleModule methods.
    from ansible.module_utils import basic
    AttributeDict = basic.AnsibleModule._AttributeDict
    fake_module = AttributeDict()
    fake_module.check_mode = False
    fake_module.get_bin_path = lambda x: '/usr/bin/apt-get'
    fake_module.run_command = lambda x: (0, b'', b'')
    assert install_python_apt(fake_module, 'python-apt') is None


# TODO: Remove when dropped support for Python 2.6

# Generated at 2022-06-23 03:09:59.245736
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():

    module = AnsibleModule(argument_spec={
        'cache_valid_time': dict(type='int', default=0),
        'codename': dict(type='str', default=None),
        'filename': dict(type='str', default=None),
        'key_url': dict(type='str', default=None),
        'keyserver': dict(type='str', default='keyserver.ubuntu.com'),
        'mode': dict(type='raw', default='0644'),
        'repo': dict(type='str', required=True),
        'state': dict(type='str', default='present', choices=['absent', 'present']),
        'update_cache': dict(type='bool', default=False),
    })
    distro = DistroInfo()
    sl = UbuntuSourcesList(module)
    assert sl

# Generated at 2022-06-23 03:10:09.514866
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, {})
    sources_list = SourcesList(module)
    assert(sources_list.default_file.endswith('/sources.list'))

    # Read sources.list and related files
    sources_list.load(sources_list.default_file)
    assert('/etc/apt/sources.list' in sources_list.files)

    # Make sure that there are no duplicated files
    try:
        sources_list.load(sources_list.default_file)
    except AssertionError:
        pass
    else:
        assert(False)


# Generated at 2022-06-23 03:10:10.547556
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass  # nothing to test



# Generated at 2022-06-23 03:10:15.525948
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
  """Verify that SourcesList.remove_source() removes the source line"""
  import pprint
  test_input_data = { "expected_output" : {"test_case" : "test case description"}}
  pprint.pprint(test_input_data)
  for test_case in test_input_data:
    module = DummyGenericModule()
    sources_list = SourcesList()



# Generated at 2022-06-23 03:10:26.558822
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    # Create a file at /tmp/tmpKaVej5
    with tempfile.NamedTemporaryFile(mode='w') as f:
        f.writelines(['deb http://host1/release1 release1\n', 'deb http://host1/release2 release2 # line commment\n', '#deb http://host1/release2 release2\n'])
        f.flush()
        sl = SourcesList(module)
        sl.load(f.name)
        assert sl.dump() == {f.name: 'deb http://host1/release1 release1\n\
deb http://host1/release2 release2 # line commment\n\
#deb http://host1/release2 release2\n'}


# Generated at 2022-06-23 03:10:32.428280
# Unit test for function install_python_apt
def test_install_python_apt():
    # Create a fake module object.
    module = object()
    module.check_mode = False
    module.get_bin_path = lambda bin: '/usr/bin/' + bin
    module.run_command = lambda command: (0, '', '')
    module.fail_json = lambda **kwargs: None

    # Run the function.
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')

    # At this point, no exceptions should have been raised.



# Generated at 2022-06-23 03:10:36.511487
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    line = "deb http://ppa.launchpad.net/datacharmer/mysql-5.7/ubuntu vivid main"
    ppa = UbuntuSourcesList(line, 'datacharmer/mysql-5.7')
    ppa.remove_source(line)
    ppa.save()


# Generated at 2022-06-23 03:10:49.633802
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = DummyModule()
    sources = SourcesList(module)

    class TestException(Exception):
        pass

    class TestFile(object):
        def __init__(self, content):
            self.content = content
            self.cursor = 0

        def readline(self):
            try:
                line = self.content[self.cursor]
                self.cursor += 1
            except IndexError:
                line = ''
            return line


# Generated at 2022-06-23 03:11:01.287740
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = Mock(name='module')
    module.run_command.return_value = (1, '', 'Error Message', None)
    # We should still allow the same file name if present with the same content
    sources_before = {'/etc/apt/sources.list': 'deb http://www.ubuntu.com/ubuntu xenial main\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://www.ubuntu.com/ubuntu xenial main\n'}
    sourceslist_before = Mock(name='sourceslist_before')
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    module.run_command.assert_not_called()
    # We should not get an error if the file exist but with different content

# Generated at 2022-06-23 03:11:13.396704
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(AnsibleModule(argument_spec={}, supports_check_mode=True))
    sl._add_valid_source('deb http://repo1.example.net/debian wheezy main', 'test1')
    sl._add_valid_source('deb http://repo2.example.net/debian wheezy main', 'test2')
    sl._add_valid_source('deb http://repo2.example.net/debian wheezy-backports  main', 'test3')
    sl._add_valid_source('deb http://repo2.example.net/debian wheezy-backports  main', 'test4')
    sl._add_valid_source('deb http://repo3.example.net/debian wheezy main', 'test5')

# Generated at 2022-06-23 03:11:29.145984
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    with tempfile.TemporaryDirectory() as tmp_dir:
        os.mkdir(os.path.join(tmp_dir, "dir"))
        module = FakeModule({})
        sources = SourcesList(module)
        f = open(os.path.join(tmp_dir, 'example'), 'w')

# Generated at 2022-06-23 03:11:38.886120
# Unit test for function install_python_apt
def test_install_python_apt():
    class MockModule(object):
        def __init__(self, resp_dict):
            self.params = dict()
            self.respawn_check = dict()
            self.check_mode = False
            self.respawn_check = resp_dict

        def fail_json(self, **kwargs):
            raise RuntimeError("got exception: %s" % kwargs['msg'])

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/apt-get'

        def run_command(self, *args, **kwargs):
            if self.respawn_check['cmd'] == args[0]:
                return self.respawn_check['ret'], self.respawn_check['stdout'], self.respawn_check['stderr']
            else:
                raise Runtime

# Generated at 2022-06-23 03:11:44.262288
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

    assert sources_list is not None
    assert hasattr(sources_list, 'module')
    assert hasattr(sources_list, 'codename')
    assert hasattr(sources_list, 'files')
    assert sources_list.codename == distro.codename

# Unit test of the method add_source of class UbuntuSourcesList

# Generated at 2022-06-23 03:11:55.597219
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    u = UbuntuSourcesList(module)

    assert u.add_source('deb http://archive.ubuntu.com/ubuntu/ wily main') == None
    assert u.add_source('deb http://archive.ubuntu.com/ubuntu/ wily main', file='my.list') == None
    assert u.add_source('ppa:brightbox/ruby-ng') == None
    assert u.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ wily main', '')
    assert u.files['my.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ wily main', '')

# Generated at 2022-06-23 03:12:07.370288
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    # This is a simple unit test for method _add_valid_source of class SourcesList.
    # It's necessary to run it with pytest.
    # First run the Ansible module to verify that required dependencies are installed.
    # After that run the test with:
    #    pytest unit/module_utils/ansible_test/apt_repo/test_apt_repository.py

    s = SourcesList(None)

    # Test case 1. Add new sources.
    # Check if it adds the specified file in sources.list.d
    s._add_valid_source("deb [arch=amd64] http://example.net/debian/ stable main",
                        "comment for repo",
                        "file_name.list")

    assert len(s.files) == 1, "seems like we didn't add the file"


# Generated at 2022-06-23 03:12:21.128039
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    def _mocked_add_ppa_signing_keys_callback(command):
        pass

    class _MockedModule(object):
        def __init__(self):
            self.params = {'filename':None}

        @staticmethod
        def params():
            raise NotImplementedError

        @staticmethod
        def get_bin_path(command, opt_dirs=None, required=False): # pylint: disable=unused-argument
            return command

        @staticmethod
        def run_command(command, check_rc=True): # pylint: disable=unused-argument
            return (0, '', '')

        @staticmethod
        def fail_json(msg):
            raise Exception(msg)


# Generated at 2022-06-23 03:12:32.778197
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module_args = dict(
        add_ppa_signing_keys_callback=get_add_ppa_signing_key_callback(module)
    )
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    assert module.check_mode is True
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    assert module.check_mode is False
    assert get_add_ppa_signing_key_callback(module)



# Generated at 2022-06-23 03:12:42.558469
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    ''' Unit test for method save of class SourcesList '''
    import shutil
    import tempfile
    import os
    import os.path

    apt_get_path = module.get_bin_path('apt-get')
    if apt_get_path:
        rc, so, se = module.run_command([apt_get_path, 'update'])
        if rc != 0:
            module.fail_json(msg="Failed to auto-install %s. Error was: '%s'" % (apt_pkg_name, se.strip()))
        rc, so, se = module.run_command([apt_get_path, 'install', apt_pkg_name, '-y', '-q'])

# Generated at 2022-06-23 03:12:48.843149
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock()

    _run_command = get_add_ppa_signing_key_callback(module)
    assert _run_command is None

    module.check_mode = False

    _run_command = get_add_ppa_signing_key_callback(module)
    assert _run_command is not None
    _run_command(['apt-key', 'list'])
    module.run_command.assert_called_once_with(['apt-key', 'list'], check_rc=True)
# END OF UNIT TEST



# Generated at 2022-06-23 03:12:57.311139
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({}, check_invalid_arguments=False)
    module.fail_json = lambda *args: False
    module.get_bin_path = lambda *args: False
    sources_list = SourcesList(module)
    line = 'deb http://archive.ubuntu.com/ubuntu/ trusty main multiverse'
    sources_list._add_valid_source(line, comment='')
    for filename, n, enabled, source, comment in sources_list:
        assert filename
        assert n >= 0
        assert enabled is True
        assert source == line
        assert comment == ''

# Generated at 2022-06-23 03:13:08.898435
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    dumpstruct = {}
    srcs = ['deb http://dl.google.com/linux/chrome/deb/ stable main', 'deb http://archive.canonical.com/ubuntu hardy partner', 'deb-src http://archive.canonical.com/ubuntu hardy partner']
    dumpstruct['/etc/apt/sources.list'] = '\n'.join(srcs)
    dumpstruct['/etc/apt/sources.list.d/custom.list'] = 'deb http://example.com/debian stable multiverse'
    dumpstruct['/etc/apt/sources.list.d/zcustom.list'] = 'deb http://example.com/debian stable multiverse'
    dumpstruct['/etc/apt/sources.list.d/acustom.list'] = ''

# Generated at 2022-06-23 03:13:22.099840
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
  # Test with PPA

  # Test with ppa:owner/ppa_name
  assert UbuntuSourcesList._expand_ppa('ppa:owner/ppa_name') == ('deb http://ppa.launchpad.net/owner/ppa_name/ubuntu xenial main', 'owner', 'ppa_name')
  # Test with ppa:owner/ppa_name/subdir
  assert UbuntuSourcesList._expand_ppa('ppa:owner/ppa_name/subdir') == ('deb http://ppa.launchpad.net/owner/ppa_name/ubuntu xenial main', 'owner', 'ppa_name')
  # Test with ppa:owner/ppa_name/subdir/subdir

# Generated at 2022-06-23 03:13:35.047736
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module_test = AnsibleModule({})
    sources_list_test = SourcesList(module_test)
    assert sources_list_test.module == module_test
    file_test = "/etc/apt/sources.list"
    assert sources_list_test.files == {}
    sources_list_test.files[file_test] = []
    file_test2 = "/etc/apt/sources.list.d/1.list"
    sources_list_test.files[file_test2] = []
    assert sources_list_test.files[file_test] == []
    assert sources_list_test.files[file_test2] == []
    sources_list_test.files[file_test].append((0, True, True, "deb http://archive.canonical.com/ubuntu hardy partner", None))


# Generated at 2022-06-23 03:13:39.226362
# Unit test for function revert_sources_list
def test_revert_sources_list():
    try:
        import aptsources.sourceslist
    except ImportError:
        import warnings
        warnings.warn('aptsources not installed')
        return
    import os
    import tempfile

# Generated at 2022-06-23 03:13:50.634836
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source(): # pragma: no cover
    class MockModule:

        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = lambda src, dst: True
            self.set_mode_if_different = lambda src, mode, recursive: True
            self._diff = False
            self._remove = False
            self._backup = False

        def check_mode(self):
            return False

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            return 0, '', ''

    class MockSourcesList(SourcesList):

        def __init__(self, *args, **kwargs):
            super(MockSourcesList, self).__init__(*args, **kwargs)


# Generated at 2022-06-23 03:13:54.889842
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    obj = UbuntuSourcesList(module)
    param = line
    obj.remove_source(param)
    pass_message = "Unit test for function remove_source of class UbuntuSourcesList."
    assert True, pass_message


# Generated at 2022-06-23 03:13:56.064227
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except InvalidSource:
        pass


# Generated at 2022-06-23 03:13:59.373046
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sources = UbuntuSourcesList(None)
    sources_copy = copy.deepcopy(sources)
    assert sources is not sources_copy and type(sources) == type(sources_copy)


# Generated at 2022-06-23 03:14:09.558071
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.failure = False
        def fail_json(self, msg):
            self.failure = True
            self.failure_msg = msg
    #test on case when line is valid
    test_module = TestModule(state='present')
    test_sourceslist = SourcesList(test_module)
    test_module.params['repo'] = 'deb http://archive.canonical.com/ubuntu trusty partner'
    valid, enabled, source, comment = test_sourceslist._parse(test_module.params['repo'], raise_if_invalid_or_disabled=True)

# Generated at 2022-06-23 03:14:16.953155
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(
        argument_spec={
            'check_mode': {'type': 'bool', 'default': False},
        },
        supports_check_mode=True,
    )
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module.params['check_mode'] = True
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module.params['check_mode'] = False
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None



# Generated at 2022-06-23 03:14:23.546835
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class MyModule(object):
        pass

    module = MyModule()

    module.params = {
        'filename': 'my_file.list'
    }

    s = SourcesList(module)

    filename = os.path.abspath(os.path.join('sources_lists', 'sources_list'))
    s.load(filename)


# Generated at 2022-06-23 03:14:29.528209
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {}
    sources_after = {}
    sourceslist_before = {}
    revert_sources_list(sources_before, sources_after, sourceslist_before)

# Generated at 2022-06-23 03:14:40.510574
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={'codename': dict(required=True, type='str')})
    module.params['codename'] = 'xenial'
    module.debug = True
    module.exit_json = Mock()

    ppa_name = 'ppa:ansible/ansible'
    file = 'ansible.list'
    ubuntu_sources_list = UbuntuSourcesList(module)

    ubuntu_sources_list.add_source(ppa_name, file=file)
    assert ubuntu_sources_list.files[file][0][2] is True
    assert ubuntu_sources_list.files[file][0][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'

# Generated at 2022-06-23 03:14:50.164397
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    config = SourcesList(dict())
    config.add_source('ppa:ubuntu-toolchain-r/test')
    config.add_source('http://ppa.launchpad.net/ubuntu-toolchain-r/test/ubuntu natty main')
    assert len(config.repos_urls) == 2

    config.remove_source('ppa:ubuntu-toolchain-r/test')
    assert len(config.repos_urls) == 1
    assert 'http://ppa.launchpad.net/ubuntu-toolchain-r/test/ubuntu natty main' in config.repos_urls



# Generated at 2022-06-23 03:14:52.859550
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'check_mode': True}, {}, {})
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-23 03:15:02.059119
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    def add_keys(command):
        pass
    current_ubuntu_sources_list = UbuntuSourcesList(MagicMock(), add_ppa_signing_keys_callback=add_keys)
    result = copy.deepcopy(current_ubuntu_sources_list)
    assert isinstance(result, UbuntuSourcesList)
    assert result.module is current_ubuntu_sources_list.module
    assert result.codename is current_ubuntu_sources_list.codename
    assert result.add_ppa_signing_keys_callback is current_ubuntu_sources_list.add_ppa_signing_keys_callback


# Generated at 2022-06-23 03:15:04.635543
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    x=SourcesList(None)
    x.load('test_data/sources.list')

# Generated at 2022-06-23 03:15:13.373176
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    Test case for the "__iter__" method of the SourcesList class
    '''
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    source_list = SourcesList(module)
    expected_iter = (('/etc/apt/sources.list', 0, True, 'deb http://archive.canonical.com/ubuntu hardy partner', ''), ('/etc/apt/sources.list', 1, True, 'deb-src http://archive.canonical.com/ubuntu hardy partner', ''), ('/etc/apt/sources.list', 2, False, 'deb http://dl.google.com/linux/chrome/deb/ stable main', ''))

    for expected, result in zip(expected_iter, source_list):
        assert expected == result

# Generated at 2022-06-23 03:15:18.790133
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Create temporary sources lists:
    ## Create an example file.
    sources_before = []
    sources_after = []
    for i in range(10):
        sources_before.append('deb http://example%d.com/ubuntu xenial main' % i)
        sources_after.append('deb http://example%d.com/ubuntu xenial main' % i)
    sources_before.sort()
    sources_after.sort()
    before_path = tempfile.mktemp()
    with open(before_path, 'w') as f:
        f.write('\n'.join(sources_before))
    ## Create an example file.
    after_path = tempfile.mktemp()
    with open(after_path, 'w') as f:
        f.write('\n'.join(sources_after))


# Generated at 2022-06-23 03:15:29.061049
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})

    os.environ['APT_CONFIG'] = module.tmpdir + '/apt.conf'
    apt_cfg = open(os.environ['APT_CONFIG'], 'w')

# Generated at 2022-06-23 03:15:36.684547
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = None

    sources_list = UbuntuSourcesList(module)

    # Test
    assert sources_list.__class__.__name__ == 'UbuntuSourcesList'
    assert sources_list.codename == distro.codename
    assert sources_list.add_ppa_signing_keys_callback == None


# Generated at 2022-06-23 03:15:46.614084
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList(AnsibleModule(argument_spec={}))

    if os.path.isfile("/tmp/test_SourcesList_modify"):
        os.remove("/tmp/test_SourcesList_modify")

# Generated at 2022-06-23 03:15:50.726738
# Unit test for function main
def test_main():
    some_file = "some file"


# Generated at 2022-06-23 03:16:01.388340
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['absent', 'present']),
        repo=dict(required=True),
        file=dict(required=False, default=None),
        mode=dict(required=False, default=None, type='raw'),
        update_cache=dict(required=False, default=False, type='bool'),
        validate_certs=dict(required=False, default=True, type='bool'),
        keyid=dict(required=False),
        keyserver=dict(required=False),
        codename=dict(required=False, default=''),
        dist=dict(required=False, default=''),
        filename=dict(required=False, default=None),
    ), supports_check_mode=True)
    sources_list = Sources

# Generated at 2022-06-23 03:16:12.921072
# Unit test for function main
def test_main():
    import unittest

    import ansible.utils.path as path
    real_get_bin_path = path.get_bin_path

    def reset_paths():
        path.get_bin_path = real_get_bin_path

    def raise_ioerror(exc):
        raise IOError(exc)

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' in kwargs:
            raise AnsibleExitJson(kwargs['changed'])
        else:
            raise AnsibleExitJson(True)

    def fail_json(*args, **kwargs):
        raise AnsibleFailJson(kwargs)
