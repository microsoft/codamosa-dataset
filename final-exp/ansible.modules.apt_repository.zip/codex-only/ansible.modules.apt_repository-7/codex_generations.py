

# Generated at 2022-06-23 03:06:13.277925
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    sourceslist = SourcesList(module)
    sourceslist.add_source()
    sourceslist.remove_source()
    sourceslist.save()
    sourceslist.reload()
    sourceslist = UbuntuSourcesList(module)
    sourceslist.add_source()
    sourceslist.remove_source()
    sourceslist.save()
    sourceslist.reload()
    # No change
    module.exit_json(changed=False)



# Generated at 2022-06-23 03:06:25.588072
# Unit test for function main

# Generated at 2022-06-23 03:06:30.523527
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    """
    Unit tests for InvalidSource
    """
    exc = InvalidSource('test')
    assert(str(exc) == 'test')



# Generated at 2022-06-23 03:06:40.826881
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec=dict(filename=dict(required=False, default=None, type="str")))
    module.params["repo"] = "deb http://archive.canonical.com/ubuntu oneiric partner"
    module.params["state"] = "present"
    sl = SourcesList(module)
    assert sl.dump() == {
        "/etc/apt/sources.list": "",
        "/etc/apt/sources.list.d/oneiric.list": "deb http://archive.canonical.com/ubuntu oneiric partner\n"
    }


# Generated at 2022-06-23 03:06:52.233113
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = MagicMock()
    sources = UbuntuSourcesList(module)

# Generated at 2022-06-23 03:07:01.766155
# Unit test for function main
def test_main():
    import ansible.modules.packaging.language.apt.apt_repository.ansible_module_apt_repository as m

    MOCK_FILE = ['deb http://foo/debian distribution component1 component2',
                 'deb http://foo/debian distribution component1 component2',
                 'deb http://foo/debian distribution component1 component2']

    MOCK_FILE_RESULT = ['deb http://foo/debian distribution component1 component2',
                        'deb http://foo/debian distribution component1 component2',
                        'deb http://foo/debian distribution component1 component2']


# Generated at 2022-06-23 03:07:05.931113
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    fail = False
    try:
        raise InvalidSource('InvalidSource')
    except InvalidSource:
        fail = True
    assert fail is True, 'InvalidSource exception not raised'



# Generated at 2022-06-23 03:07:14.600724
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # If a non-existent file is included, should not fail.
    sources_before = {'/tmp/foo': '', '/tmp/bar': '', '/tmp/baz': ''}
    sources_after = {'/tmp/foo': '', '/tmp/bar': '', '/tmp/baz': '', '/tmp/foobar': ''}
    sourceslist_before = MagicMock(**{'save.return_value': None})
    revert_sources_list(sources_before, sources_after, sourceslist_before)



# Generated at 2022-06-23 03:07:22.527073
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from tempfile import mkstemp

    # Create a temporary file to use for the tests
    # Use the same values as the Ansible testing framework
    fd, apt_sources_list_file = mkstemp()
    os.close(fd) # Don't actually need the open file handle

    # Test with no sources_before, should delete the file

# Generated at 2022-06-23 03:07:31.102484
# Unit test for function install_python_apt
def test_install_python_apt():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.resources.constants as constants

    m = basic.AnsibleModule(
        argument_spec={'test': {'type': 'bool', 'default': True}},
        required_one_of=[['test']],
        supports_check_mode=True
    )

    if PY3:
        apt_pkg_name = 'python3-apt'
    else:
        apt_pkg_name = 'python-apt'

    install_python_apt(m, apt_pkg_name)

    m.exit_json(
        msg="python apt installed fine",
        changed=True,
        adhoc_ansible=constants.ADHOC_ANSIBLE
    )



# Generated at 2022-06-23 03:07:39.984863
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule(object):

        _debug = False

        def __init__(self, **kwargs):
            self.params = kwargs

        @property
        def debug(self):
            return self._debug

        @debug.setter
        def debug(self, value):
            self._debug = value

        def fail_json(self, msg):
            raise AssertionError(msg)

    # Test 0 - simplest test
    m = TestModule(name='unit test for method __deepcopy__ of class UbuntuSourcesList')
    s = UbuntuSourcesList(m)
    s.add_source('deb http://test.domain1 deb1 main')
    s_copy = deepcopy(s)

    assert not m.debug, "when __deepcopy__ is called, _debug should be set to False"

# Generated at 2022-06-23 03:07:51.709747
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    class AnsibleModuleMock(object):
        class params(object):
            filename = u'filename'
            mode = u'mode'
            codename = u'codename'
        def fail_json(self, msg):
            raise Exception(msg)
        def atomic_move(self, a, b):
            pass
    module = AnsibleModuleMock()
    module.run_command = lambda cmd: '', '', ''
    module.set_mode_if_different = lambda x: None
    module.params = AnsibleModuleMock.params()

    class OpenMock(object):
        def __init__(self, path, mode):
            self.path = path
            self.mode = mode

# Generated at 2022-06-23 03:07:54.601729
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('foo')
    except InvalidSource as e:
        assert e.args[0] == 'foo'



# Generated at 2022-06-23 03:08:07.049534
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList(None)

# Generated at 2022-06-23 03:08:12.806094
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({'state': 'present', 'repo': 'deb http://example.com/debian foobar'})
    sourceslist = SourcesList(module)

    assert sourceslist.dump() == {}

    # Prepare case when repo is present in default sources list file
    sourceslist.load('tests/data/sources.list')
    expected_result = {'tests/data/sources.list': 'deb http://example.com/debian foobar\n'}
    assert sourceslist.dump() == expected_result

    # Prepare case when repo isn't present in default sources list file
    sourceslist.load('tests/data/sources.list.empty')
    expected_result = {'tests/data/sources.list.empty': ''}
    assert sourceslist.dump() == expected_result


# Generated at 2022-06-23 03:08:18.150436
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    mymodule = DummyModule()
    s = UbuntuSourcesList(mymodule)
    d = copy.deepcopy(s)
    assert s.module == d.module
    # We could also check if add_ppa_signing_keys_callback is the same object,
    # but that's not needed as we want to use a different instance
    assert s.add_ppa_signing_keys_callback == d.add_ppa_signing_keys_callback

# Generated at 2022-06-23 03:08:28.453576
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    ansible_test_instance = AnsibleModule({})
    ansible_test_instance._debug = False
    ansible_test_instance.exit_json = lambda **args: None
    ansible_test_instance.fail_json = lambda **args: None
    ansible_test_instance.atomic_move = lambda **args: None
    instance_to_test = SourcesList(ansible_test_instance)
    try:
        instance_to_test.save()
    except Exception as exception_raised:
        assert exception_raised
        return
    assert False, "test_SourcesList_save() failed to raise an Exception"


# Generated at 2022-06-23 03:08:39.611375
# Unit test for function main
def test_main():
    repo = 'ppa:ansible/myansible'
    state = 'present'
    mode = '0644'
    update_cache = True
    filename = None

# Generated at 2022-06-23 03:08:45.695589
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    assert get_add_ppa_signing_key_callback(module) is None

    test_args = {}
    module = AnsibleModule(test_args, bypass_checks=True)

    assert callable(get_add_ppa_signing_key_callback(module))


# Generated at 2022-06-23 03:08:58.644220
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import os
    import shutil
    import tempfile

    from ansible.module_utils.apt.sources_list import SourcesList
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList

    tmp = tempfile.mkdtemp()
    sources_filename_1 = os.path.join(tmp, "sources_1.list")
    sources_filename_2 = os.path.join(tmp, "sources_2.list")

    # Create sources list file
    with open(sources_filename_1, 'w') as source_file:
        source_file.write("deb http://ppa.launchpad.net/owner/repo/ubuntu trusty main\n")


# Generated at 2022-06-23 03:09:11.036077
# Unit test for method __iter__ of class SourcesList

# Generated at 2022-06-23 03:09:18.865938
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    module.exit_json = Mock()
    lines = [
        'deb http://ppa.launchpad.net/kivy-team/kivy/ubuntu xenial main',
        '# deb-src http://ppa.launchpad.net/kivy-team/kivy/ubuntu xenial main',
    ]
    sl = UbuntuSourcesList(module)
    for line in lines:
        sl.add_source(line)
    sl.remove_source('ppa:kivy-team/kivy')
    assert len(sl.repos_urls) == 0


# Generated at 2022-06-23 03:09:27.878432
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import unittest

    class TestSourcesList(unittest.TestCase):
        def test_empty_file(self):
            m = AnsibleModule(argument_spec={'state': {'default': 'present'}})
            sl = SourcesList(m)
            self.assertEqual(sl.dump(), {})

        def test_first_line_only(self):
            m = AnsibleModule(argument_spec={'state': {'default': 'present'}})
            sl = SourcesList(m)
            sl.load('test_apt_module/apt.sources.list.d/first_line_only')

# Generated at 2022-06-23 03:09:34.327088
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    test_obj = UbuntuSourcesList('module')
    test_obj.load('')
    test_obj._add_valid_source('')
    test_obj._remove_valid_source('')
    test_obj.modify(0,0,0,0,0)
    test_obj.dump()
    test_obj._expand_path('')
    test_obj._suggest_filename('')
    test_obj._parse('')
    test_obj._apt_cfg_dir('')
    test_obj.save()
    test_obj.__iter__()
    test_obj._add_valid_source(0,0,0)
    test_obj._get_ppa_info(0,0)
    test_obj._expand_ppa('')
    test_obj._key_al

# Generated at 2022-06-23 03:09:45.308292
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    ubuntu_sources = UbuntuSourcesList(module = None)
    source = 'deb [arch=amd64,i386] http://repo.example.com/xenial main'
    ubuntu_sources.add_source(source, comment = '')
    assert source in [line for filename, line in ubuntu_sources.files.items()]
    ubuntu_sources.remove_source(source)
    assert source not in [line for filename, line in ubuntu_sources.files.items()]
    source = 'ppa:user/ppa-name'
    ubuntu_sources.add_source(source, comment = '')
    assert source in [line for filename, line in ubuntu_sources.files.items()]
    ubuntu_sources.remove_source(source)

# Generated at 2022-06-23 03:09:46.749964
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    # TODO: Write unit test for method load of class SourcesList
    pass


# Generated at 2022-06-23 03:09:58.997081
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

    with open('tests/test_apt.sources.list', 'r') as f:
        for n, line in enumerate(f):
            valid, enabled, source, comment = sources_list._parse(line)
            if valid:
                sources_list.files[sources_list.default_file].append((n, valid, enabled, source, comment))


# Generated at 2022-06-23 03:10:11.187143
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Pretend that foo.list did not exist before
    sources_before = { 'bar.list' : "" }
    sources_after = { 'baz.list' : "", 'foo.list' : "" }
    # sources_before is not modified by revert_sources_list
    sourceslist_before = SourcesList(None)
    sourceslist_before.load("bar.list")
    # sourceslist_after should be unchanged (baz.list should still be present)
    sourceslist_after = SourcesList(None)
    sourceslist_after.load("baz.list")
    sourceslist_after.load("foo.list")
    # Now revert it
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    for filename in sources_after:
        assert(filename in sources_before)

# Generated at 2022-06-23 03:10:13.985954
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt('python-apt') == True
    assert install_python_apt('python3-apt') == True


# Generated at 2022-06-23 03:10:24.005704
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Dummy module for testing
    class DummyModule(object):
        class DummyParams(object):
            pass

        def __init__(self):
            self.params = self.DummyParams()

        def fail_json(self, msg, **kwargs):
            raise Exception(msg)

        def atomic_move(self, tmp_path, path):
            with open(path, 'w') as f:
                with open(tmp_path, 'r') as f2:
                    f.write(f2.read())
            os.remove(tmp_path)

        def set_mode_if_different(self, path, mode, force):
            if force:
                mode = 0o644
            os.chmod(path, mode)

    module = DummyModule()
    sourceslist = SourcesList(module)


# Generated at 2022-06-23 03:10:33.788231
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    from ansible.module_utils.common.respawn import respawn, has_respawned
    # Spawn a new process to test, this is necessary for apt_pkg.init_config and apt_pkg.config.set
    # since they are module global.
    if has_respawned():
        if PY3:
            sys.exit(0)
        else:
            os._exit(0)

    respawn(sys.executable, [__file__, json.dumps(dict(
        __testcase__='test_SourcesList_add_source',
    ))],
        setpgrp=True,
        before_exec=lambda: apt_pkg.init_config(),
        logfile=sys.stderr,
    )


# Generated at 2022-06-23 03:10:38.027246
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    module = AnsibleModule(argument_spec={})
    try:
        raise InvalidSource(to_native('Invalid source'))
    except InvalidSource as e:
        module.fail_json(msg="%s" % to_native(e))

# Class to handle apt repository sources

# Generated at 2022-06-23 03:10:51.003610
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModuleMock()
    sourceslist = SourcesList(module)

    # test that we don't touch the file if the content didn't change
    sourceslist.files = {
        '/etc/apt/sources.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu trusty partner', '')],
    }

    with open('/etc/apt/sources.list', 'w') as f:
        f.write('deb http://archive.canonical.com/ubuntu trusty partner')
    sourceslist.save()
    with open('/etc/apt/sources.list', 'r') as f:
        assert f.read() == 'deb http://archive.canonical.com/ubuntu trusty partner'

    # test that we create file if it doesn't exist

# Generated at 2022-06-23 03:11:02.598875
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu/ hardy partner', comment='# asd')
    sl.add_source('deb-src http://archive.canonical.com/ubuntu/ hardy partner', comment='# asd')
    sl.add_source('deb http://archive.canonical.com/ubuntu/ hardy partner', comment='# asd')
    sl.add_source('deb http://archive.canonical.com/ubuntu/ hardy partner', comment='# asd')
    sl.remove_source('deb http://archive.canonical.com/ubuntu/ hardy partner')


# Generated at 2022-06-23 03:11:13.690164
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import inspect
    import os
    import random
    import stat
    import tempfile
    import shutil
    import textwrap

    import sys
    sys.modules['apt'] = None
    sys.modules['apt_pkg'] = None
    sys.modules['aptsources.distro'] = None

    import ansible.module_utils.apt_repository_utils

    class ModuleStub(object):
        def __init__(self, params):
            self.params = params
            self.fail_json_called = False
            self.fail_json_report = {}
            self.atomic_move_called = False
            self.atomic_move_report = {}
            self.set_mode_if_difference_called = False
            self.set_mode_if_difference_report = {}


# Generated at 2022-06-23 03:11:24.274970
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    apt_module_mock = type('Module', (), {
        'atomic_move.return_value': True,
        'set_mode_if_different.return_value': True,
        'params': {
            'filename': None
        }}
    )

    def run_command_mock(argv):
        assert argv == [
            apt_module_mock.get_bin_path.return_value,
            'list',
            'deb-src',
            'deb-src',
            'http://mirror.tld/ubuntu'
        ]
        return (0, '', '')

    def open_mock(path, mode):
        assert path == '/etc/apt/sources.list.d/mirror.tld_ubuntu.list'

# Generated at 2022-06-23 03:11:36.601501
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # create a temporary file
    (fd, tmp_path) = tempfile.mkstemp()

    # write some content to the temporary file
    try:
      f = os.fdopen(fd, 'w')
      f.write("deb http://archive.ubuntu.com/ubuntu bionic main restricted\n")
      f.write("deb http://archive.ubuntu.com/ubuntu bionic-updates main restricted\n")
      f.write("deb http://security.ubuntu.com/ubuntu bionic-security main restricted\n")
    finally:
      f.close()

    # create a SourcesList object
    module = AnsibleModule(argument_spec=dict())

    sl = SourcesList(module=module)

    sl.load(tmp_path)

    # modify the third line of the temporary file

# Generated at 2022-06-23 03:11:41.151950
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule({})
    sources_fn = dict(UbuntuSourcesList(module))
    sources_before = dict(sources_fn)
    sources_after = dict(sources_fn)
    sourceslist_before = UbuntuSourcesList(module)

    sources_after['test_file'] = {'foobar'}

    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sources_fn == sources_before



# Generated at 2022-06-23 03:11:45.075757
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    ppa_callback1 = get_add_ppa_signing_key_callback(module)
    module.check_mode = True
    ppa_callback2 = get_add_ppa_signing_key_callback(module)
    assert ppa_callback1 is not None and ppa_callback2 is None



# Generated at 2022-06-23 03:11:50.822930
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sl = SourcesList()
    assert sl.default_file == '/etc/apt/sources.list'
    assert sorted(sl.files.keys()) == ['/etc/apt/sources.list', '/etc/apt/sources.list.d/scaleway.list', '/etc/apt/sources.list.d/sources.list.save']



# Generated at 2022-06-23 03:11:52.711359
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    e = InvalidSource("Class InvalidSource")
    assert(str(e) == "Class InvalidSource")



# Generated at 2022-06-23 03:11:57.042309
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sources_list = SourcesList()
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert not sources_list.files


# Generated at 2022-06-23 03:12:08.581733
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, '', ''))
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)
    assert add_ppa_signing_key_callback is None, "function get_add_ppa_signing_key_callback, expected None as add_ppa_signing_key_callback, but got: %s" % add_ppa_signing_key_callback
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

# Generated at 2022-06-23 03:12:14.946376
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList()
    line = " # deb http://dl.google.com/linux/chrome/deb/ stable main"
    sl._add_valid_source(line,"")
    sl.remove_source(line)
    assert sl.dump() == {'test.list': ''}



# Generated at 2022-06-23 03:12:24.011415
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible_collections.ansible.builtin.plugins.module_utils.apt import install_python_apt
    from ansible_collections.ansible.builtin.plugins.module_utils.apt_pkg import python_apt_installed
    assert not python_apt_installed()
    # set attrs for module to be able to use run_command
    m = AnsibleModule({})
    m.check_mode = False
    m.get_bin_path = lambda: "/usr/bin/apt-get"
    install_python_apt(m, "python-apt")
    assert python_apt_installed()



# Generated at 2022-06-23 03:12:27.389664
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    data = 'deb http://httpredir.debian.org/debian jessie main'
    sl = SourcesList(None)
    sl.add_source(data)
    assert data in next(iter(sl))[3]
    sl.add_source(data)
    assert len(list(sl)) == 1


# Generated at 2022-06-23 03:12:34.260905
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict(repo=dict()))
    def _fail(msg):
        module.fail_json(msg=msg)
    module.fail_json = _fail
    sources = SourcesList(module)
    assert sources.files
    assert sources.default_file == sources._apt_cfg_file('Dir::Etc::sourcelist')


# Generated at 2022-06-23 03:12:43.500782
# Unit test for constructor of class SourcesList
def test_SourcesList():
    global apt, apt_pkg, distro, HAVE_PYTHON_APT
    apt = apt_pkg = distro = None
    HAVE_PYTHON_APT = True

    class DummyModule:
        def __init__(self):
            self.params = {}
            self.atomic_move = None

        def fail_json(self, msg=''):
            raise Exception(msg)

        def get_bin_path(self, executable):
            return '/bin/' + executable

        def set_mode_if_different(self, path, mode, changed):
            return 0

    class DummyDistro:
        def __init__(self, sourceslist_file):
            self.sourceslist_file = sourceslist_file

        def get_sourceslist(self):
            return self.sourceslist_file

# Generated at 2022-06-23 03:12:53.414619
# Unit test for function main

# Generated at 2022-06-23 03:12:58.255484
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-23 03:13:02.682264
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sourceslist_before = UbuntuSourcesList(module)
    sourceslist_after = UbuntuSourcesList(module)
    revert_sources_list({}, {}, sourceslist_before)



# Generated at 2022-06-23 03:13:10.290359
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    length_files_before = len(SourcesList.files)
    length_files_after = len(SourcesList.files)
    if length_files_before == 0:
        SourcesList.load('/etc/apt/sources.list')
        length_files_after = len(SourcesList.files)

# Generated at 2022-06-23 03:13:17.209481
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = None
    sources_before = {"/etc/apt/sources.list": "deb http://ppa.launchpad.net/test/ubuntu trusty main\ndeb-src http://ppa.launchpad.net/test/ubuntu trusty main\n"}
    sources_after = {"/etc/apt/sources.list": "deb http://ppa.launchpad.net/test/ubuntu trusty main\ndeb-src http://ppa.launchpad.net/test/ubuntu trusty main\ndeb http://ppa.launchpad.net/test/ubuntu trusty main\n"}
    sourceslist_before = aptsources.sourceslist.SourcesList()
    sourceslist_before.add('deb http://ppa.launchpad.net/test/ubuntu trusty main')

# Generated at 2022-06-23 03:13:25.154436
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    test_module = AnsibleModule(argument_spec={})
    test_module._socket_path = '/foo'
    test_module.params = {'codename': 'bionic'}

    test_obj = UbuntuSourcesList(test_module)

# Generated at 2022-06-23 03:13:30.911686
# Unit test for function main
def test_main():
    mod = AnsibleModule({}, {}, check_invalid_arguments=False)
    mod.params['repo'] = ''
    mod.params['state'] = 'present'
    mod.params['filename'] = '';
    mod.params['update_cache'] = True
    mod.params['update_cache_retries'] = 0
    mod.params['update_cache_retry_max_delay'] = 0
    mod.params['install_python_apt'] = True
    mod.params['validate_certs'] = True
    mod.params['codename'] = ''

    aptsources_distro.Distribution = None
    aptsources_sourceslist.SourcesList = None
    apt_pkg.Config = MagicMock()
    apt_pkg.Config.subtree = {}
    apt_pkg.Config.find

# Generated at 2022-06-23 03:13:34.423046
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    m = MagicMock()
    s = UbuntuSourcesList(m)
    assert s != s.__deepcopy__()



# Generated at 2022-06-23 03:13:44.679105
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    file = 'file'
    d = 'd'
    fn = 'fn'
    fd = 'fd'
    tmp_path = 'tmp_path'
    line = 'line'
    lines = 'lines'
    data = {'diff': {}, 'before': '', 'after': ''}
    datadict = {'msg': '', 'rc': 0, 'diff': {'before': '', 'after': ''}, 'invocation': {'module_args': {}}}
    datadict['src'] = tmp_path
    inst = SourcesList(AnsibleModule(argument_spec={'state': {'required': True, 'choices': ['present', 'absent']}, 'filename': {'default': None}, 'repo': {'required': True}}))

# Generated at 2022-06-23 03:13:54.601017
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    Test for AnsibleModule of ansible.module_utils.basic.py - apt_repository
    This test test for `dump` method of class `SourcesList`
    '''
    module = AnsibleModule(argument_spec=dict())

    # test for empty files
    empty_files = {'/a/b': '', '/b/c': ''}
    sources_list = SourcesList(module)
    sources_list.files = empty_files
    assert sources_list.dump() == {}

    # test for one file non-empty file
    non_empty_files = {'/a/b': '', '/c/d': 'deb http://a.b.ru test\n#deb http://a.b.ru test2'}
    sources_list = SourcesList(module)
    sources_list.files = non

# Generated at 2022-06-23 03:14:05.437886
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """Test save method"""
    import os
    import shutil
    import tempfile
    import pytest
    import ansible.module_utils.basic as basic

    class Options(object):
        """Class to simulate module.params"""
        def __init__(self, params):
            self.__dict__ = copy.deepcopy(params)

        def __getitem__(self, key):
            return getattr(self, key)

    file_paths = []
    tmp_dir = tempfile.gettempdir()
    tmp_path = os.path.join(tmp_dir, 'tmp_file.list')
    file_paths.append(tmp_path)
    tmp_path = os.path.join(tmp_dir, 'tmp_file_d', 'tmp_file_d.list')

# Generated at 2022-06-23 03:14:15.299933
# Unit test for function main

# Generated at 2022-06-23 03:14:28.180520
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    result = {
        '/etc/apt/sources.list':
            'deb http://us.archive.ubuntu.com/ubuntu/ xenial main restricted\n'
            'deb-src http://us.archive.ubuntu.com/ubuntu/ xenial main restricted\n'
            '\n'
    }

    fd, tmp_path = tempfile.mkstemp(prefix='.list', dir='/tmp')

    f = os.fdopen(fd, 'w')
    f.write('deb http://us.archive.ubuntu.com/ubuntu/ xenial main restricted\ndeb-src http://us.archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    f.close()

    sl = SourcesList(None)

# Generated at 2022-06-23 03:14:36.307714
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class FakeModule:
        def run_command(self, command, check_rc=True):
            print("%s: check_rc=%s" % (command, bool(check_rc)))

    module = FakeModule()
    f = get_add_ppa_signing_key_callback(module)
    f(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '123'])


# Generated at 2022-06-23 03:14:39.522951
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("This is a test for InvalidSource class.")
    except InvalidSource as e:
        assert e.args[0] == "This is a test for InvalidSource class."


# Generated at 2022-06-23 03:14:48.566388
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line_to_remove = 'deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main'
    filename = 'pgdg.list'
    sl = SourcesList(None)
    sl.load(filename)
    for enabled, line, comment in [(True, line_to_remove, 'added by pgdg installer'),(False, 'deb http://deb.debian.org/debian/ jessie main', '# added by pgdg installer')]:
        line = " ".join([(" # " if not enabled else ""), line, (" # " if comment else ""), comment])
        sl._add_valid_source(line, "", file=filename)
    sl._remove_valid_source(line_to_remove)
    assert len(sl.files[filename]) == 1

# Generated at 2022-06-23 03:14:59.233524
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'install_python_apt': True}, check_invalid_arguments=False)
    apt_pkg_name = 'python-apt'

    try:
        importlib.import_module(apt_pkg_name)
    except ImportError:
        pass
    else:
        module.fail_json(msg="%s was not supposed to be installed" % apt_pkg_name)

    install_python_apt(module, apt_pkg_name)
    try:
        importlib.import_module(apt_pkg_name)
    except ImportError:
        module.fail_json(msg="%s not installed by install_python_apt" % apt_pkg_name)



# Generated at 2022-06-23 03:15:08.541347
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import pytest

    class module_mock():
        def fail_json(self, *args, **kwargs):
            print('fail_json:', args, kwargs)
            raise Exception()

        def atomic_move(self, *args, **kwargs):
            print('atomic_move:', args, kwargs)

        def set_mode_if_different(self, *args, **kwargs):
            print('set_mode_if_different:', args, kwargs)

        def run_command(self, *args, **kwargs):
            print('run_command:', args, kwargs)
            raise Exception()

    sl = UbuntuSourcesList(module_mock(), None)

# Generated at 2022-06-23 03:15:20.050002
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # Initialize the module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Initialize the SourcesList
    sources_list = SourcesList(module)

    # Configure the SourcesList
    # TODO: don't add files in /etc/apt/sources.list.d/ but in /tmp/
    sources_list.add_source("deb http://http.debian.net/debian jessie-backports main", comment="#backports",
                            file="jessie-backports")
    sources_list.add_source("deb http://archive.ubuntu.com/ubuntu xenial main universe", comment="#default")
    sources_list.add_source("deb http://archive.ubuntu.com/ubuntu xenial-security main universe", comment="#security")

# Generated at 2022-06-23 03:15:29.895860
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # create temporary directory with files under /tmp
    tmpPath = tempfile.mkdtemp(prefix="ansible_test_sourceslist_save.", dir="/tmp")
    default_file = os.path.join(tmpPath, "sources.list")
    partsPath = os.path.join(tmpPath, "sources.list.d")

    # create two empty files
    with open(default_file, 'w'):
        pass
    with open(os.path.join(partsPath, "test.list"), 'w'):
        pass

    # generate list

# Generated at 2022-06-23 03:15:38.103598
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils.basic import AnsibleModule
    ansible_module = AnsibleModule({})
    ubuntu_sources_list = UbuntuSourcesList(ansible_module)
    ubuntu_sources_list.files = {
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://example.com/ubuntu/ bionic main', ''),
            (1, True, True, 'deb http://ppa.launchpad.net/test/test/ubuntu bionic main', ''),
            (2, True, True, 'deb-src http://ppa.launchpad.net/test/test/ubuntu bionic main', '')
        ]
    }

    # remove ppa with all lines
    ubuntu_sources_list.remove_source('ppa:test/test')
    assert ub

# Generated at 2022-06-23 03:15:48.709690
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import tempfile
    from ansible_collections.community.general.plugins.module_utils.ubuntu_common import TempDir
    module = AnsibleModule(argument_spec={})
    tmp_dir = TempDir(module)
    with tmp_dir as path:
        command_path = os.path.join(path, 'command')
        with open(command_path, 'w') as f:
            f.write('')
        module.run_command = lambda x, check_rc=None: open(command_path, 'a').write('%s\n' % x)
        cb = get_add_ppa_signing_key_callback(module)

# Generated at 2022-06-23 03:15:59.599837
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common.respawn import probe_interpreters_for_module
    debug = 0
    if 'debug' in os.environ:
        debug = int(os.environ['debug'])

    apt = apt_pkg = aptsources_distro = distro = None
    apthistory = None

    if os.path.exists(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'python3-apt')):
        apt_pkg_name = 'python3-apt'
    else:
        apt_pkg_name = 'python-apt'

# Generated at 2022-06-23 03:16:11.292795
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sources = """\
deb http://ppa.launchpad.net/rquillo/ansible/ubuntu trusty main
deb http://ppa.launchpad.net/rquillo/ansible/ubuntu/ main
deb http://ppa.launchpad.net/rquillo/ansible/ trusty main
deb http://ppa.launchpad.net/rquillo/ansible/ubuntu trusty main
deb file:///cdrom/ trusty main
deb http://host/ trusty main
deb http://host/ubuntu trusty main
"""
