

# Generated at 2022-06-23 03:06:09.508477
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={'codename': {'default': 'xenial'}})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    assert sources_list.repos_urls == ['deb http://archive.ubuntu.com/ubuntu xenial main']


# Generated at 2022-06-23 03:06:17.630996
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = FakeModule()
    u = UbuntuSourcesList(module)
    u.files = {
        '/etc/apt/sources.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/keithw/mosh/ubuntu xenial main', ''),
            (1, True, True, 'deb-src http://ppa.launchpad.net/keithw/mosh/ubuntu xenial main', ''),
            (2, True, True, 'deb http://ppa.launchpad.net/keithw/mosh/ubuntu xenial main', ''),
            (3, True, True, 'deb-src http://ppa.launchpad.net/keithw/mosh/ubuntu xenial main', ''),
        ],
    }
    # test 1

# Generated at 2022-06-23 03:06:28.261754
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    m = AnsibleModule({})
    sl = SourcesList(m)
    assert m.params['mode'] == None
    assert sl.dump() == {}
    try:
        sl.add_source('invalid line')
        assert 0
    except InvalidSource:
        pass
    sl.add_source('deb http://example.com/ubuntu ubuntu main')
    output = sl.dump()
    assert output == {'/etc/apt/sources.list': 'deb http://example.com/ubuntu ubuntu main\n',}
    sl = SourcesList(m)
    sl.add_source('deb http://example.com/ubuntu ubuntu main', comment='comment 1')
    sl.add_source('deb http://example.com/ubuntu ubuntu main', comment='comment 2')
    output = sl.dump()

# Generated at 2022-06-23 03:06:38.464249
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # test_SourcesList_save: Write a sourceslist to file and check if it was written correctly
    # Instantiate sourceslist
    module = AnsibleModule({})
    sourceslist = SourcesList(module)

    # Setup sourceslist
    filename = '/tmp/test_SourcesList_save.list'
    test_contents = """# Disabled entry
# deb-src http://mirror.fuel-infra.org/pkgs/ubuntu/ yakkety main
deb http://mirror.fuel-infra.org/pkgs/ubuntu/ yakkety main

# Disabled
# deb-src http://mirror.fuel-infra.org/pkgs/ubuntu/ trusty main
deb http://mirror.fuel-infra.org/pkgs/ubuntu/ trusty main
"""
    sourceslist.files[filename] = []

# Generated at 2022-06-23 03:06:49.456877
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import ansible.module_utils.ansible_release
    c = SourcesList(ansible.module_utils.ansible_release)

# Generated at 2022-06-23 03:06:53.579095
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource
    except InvalidSource:
        pass
# end of test for the constructor of class InvalidSource



# Generated at 2022-06-23 03:07:04.543794
# Unit test for function revert_sources_list
def test_revert_sources_list():
    """ Return a test suite for the main function.
    """
    import tempfile

    test_suite = unittest.TestSuite()

    ####################################################################################
    class TestRevertSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tmpdir = tempfile.mkdtemp()

            # Create a mock module_helper to pass to the SourcesList
            self.module = Mock()
            self.module.params = dict(
                filename=None,
                codename=None,
            )
            self.module.check_mode = False
            self.module.atomic_move = lambda src, dest: shutil.move(src, dest)
            self.module.set_mode_if_different = lambda x, y, z: True
            self.module.run_command

# Generated at 2022-06-23 03:07:11.146259
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import tempfile
    from ansible.module_utils import six
    from ansible.module_utils.basic import AnsibleModule

    def add_ppa_signing_keys_callback(command):
        return True

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = print
            self.fail_json = print

    class FakeDistro(object):
        def __init__(self):
            self.codename = 'bionic'


# Generated at 2022-06-23 03:07:12.100421
# Unit test for function install_python_apt
def test_install_python_apt():
    install_python_apt(module, apt_pkg_name)



# Generated at 2022-06-23 03:07:15.326522
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line = """deb [ arch=amd64,arm64 ] https://download.docker.com/linux/ubuntu xenial stable"""

    sourcelist = SourcesList(None)
    sourcelist.add_source(line, comment = 'Test Comment')
    print(sourcelist.dump())

    sourcelist.add_source(line, comment = 'Test Comment')
    print(sourcelist.dump())

    sourcelist.add_source(line, comment = 'Test Comment')
    print(sourcelist.dump())

    sourcelist.remove_source(line)
    print(sourcelist.dump())


# Generated at 2022-06-23 03:07:26.229144
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():

    # This test is intended to test a logic for dump method of SourcesList class.
    # We check if the sources.list file is being generated as we expect it to be.

    class FakeModule(object):
        params = {}
        results = {}
        exit_args = {}
        exit_kwargs = {}

        def exit_json(*args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

    # Prepare temp directories and files for the test
    # The result should contain the default sources.list and several files in sources.list.d directory
    tempdir = tempfile.mkdtemp()
    open(os.path.join(tempdir, 'sources.list'), 'a').close()

# Generated at 2022-06-23 03:07:38.476659
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    s = SourcesList(module)
    s.load("tests/resources/apt_repository/sources.list")
    s.save()
    s.load("tests/resources/apt_repository/sources.list")
    assert len(s.files) == 1
    assert len(s.files["tests/resources/apt_repository/sources.list"]) == 3
    assert (0, True, True, "deb http://us.archive.ubuntu.com/ubuntu/ precise universe", "") == s.files["tests/resources/apt_repository/sources.list"][0]

# Generated at 2022-06-23 03:07:41.401358
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'
    install_python_apt(module, apt_pkg_name)
    return



# Generated at 2022-06-23 03:07:45.474718
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    """ check for Exception InvalidSource """
    try:
        raise InvalidSource('invalid source string')
    except InvalidSource as exc:
        assert exc.args[0] == 'invalid source string'



# Generated at 2022-06-23 03:07:54.770861
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module():
        def __init__(self, params = None):
            if params is None:
                params = dict()
                test_name = 'default,error,overwrite'
            else:
                test_name = 'default'
            self.params = params
            self.result = dict(failed=False)
            self.fail_json = self.fail_json_by_raise
        def fail_json_by_raise(self, msg):
            raise Exception('fail_json(%s)'%msg)
        def fail_json_by_return(self, msg):
            self.result['failed'] = True
        def dump_results(self, result):
            if result:
                pass
        def exit_json(self, **kwargs):
            pass

# Generated at 2022-06-23 03:07:57.136330
# Unit test for constructor of class InvalidSource
def test_InvalidSource():  # pylint: disable=missing-docstring
    try:
        raise InvalidSource()
    except InvalidSource:
        pass



# Generated at 2022-06-23 03:08:08.202585
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class Module(object):
        def __init__(self, params):
            self.params = params
            self.failed = False
            self.changed = False
            self.diff = {}
            self.exit_args = {}
            self.checked_in_at_the_source = ''
            self.run_command = self.fake_run_command

        def atomic_move(self, tmp_path, filename):
            if filename == '/etc/apt/sources.list.d/ppa-jeos.list':
                f = open(filename, 'w')
                f.write('deb http://ppa.launchpad.net/jeos/ppa/ubuntu hardy main' + '\n')
                f.close()

# Generated at 2022-06-23 03:08:10.902079
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'
    module = AnsibleModule(argument_spec = {
        'install_python_apt': {'type':'bool', 'default':True},
        'check_mode': {'type':'bool', 'default':False},
    })
    try:
        import apt
        import apt_pkg
    except ImportError:
        install_python_apt(module, apt_pkg_name)
        assert HAVE_PYTHON_APT
    else:
        assert HAVE_PYTHON_APT


# Generated at 2022-06-23 03:08:23.593419
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = Mock()
    module.params = {
        'filename': None,
        'id': None,
        'line': None,
        'mode': None,
        'repo': None,
        'state': 'absent',
        'ppa_auth': None
    }
    sources = UbuntuSourcesList(module)

# Generated at 2022-06-23 03:08:25.854223
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Invalid source exception")
    except InvalidSource as e:
        assert e.message == "Invalid source exception"


# Generated at 2022-06-23 03:08:28.420937
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({'warn': False}, {'warn': False})
    sources_list = SourcesList(module)
    if len(list(sources_list)) < 0:
        module.fail_json(msg="SoucesList is empty")



# Generated at 2022-06-23 03:08:40.341712
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import os.path
    import tempfile
    import unittest
    from ansible.utils import module_docs
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import _thread

    class OS_Path_TestCase(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(OS_Path_TestCase, self).__init__(*args, **kwargs)
            self.tmp_dir = tempfile.mkdtemp()

        def setUp(self):
            self.assertTrue(os.path.exists(self.tmp_dir))


# Generated at 2022-06-23 03:08:46.794734
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule:
        class MockParams:
            codename = 'codename'

        params = MockParams()

    obj = UbuntuSourcesList(MockModule)

    obj2 = copy.deepcopy(obj)
    assert obj2 is not obj
    assert obj2.module is obj.module
    assert obj2.codename == obj.codename



# Generated at 2022-06-23 03:08:58.644135
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    u = UbuntuSourcesList(1)
    u.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main')
    u.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main')
    u.add_source('ppa:unit-test/testing')
    u.add_source('ppa:unit-test/testing')
    u.add_source('ppa:unit-test/testing')
    assert len(u.files['/etc/apt/sources.list.d/unit-test_testing.list']) == 2
    assert len(u.files['/etc/apt/sources.list.d/ansible_ansible.list']) == 2



# Generated at 2022-06-23 03:09:11.036344
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources_list = SourcesList(AnsibleModule({}))
    sources_list.load('tests/aptsources_iterate_sources_list.txt')

    result = list(sources_list)

# Generated at 2022-06-23 03:09:23.655773
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # create an empty sources.list file
    with open('/tmp/sources.list', 'w') as f:
        f.write('')
    assert os.stat('/tmp/sources.list').st_size == 0
    #
    # create an empty sources.list.d directory
    os.makedirs('/tmp/sources.list.d/')
    assert os.path.isdir('/tmp/sources.list.d')
    #
    # have a non-empty sources.list.d/ file
    with open('/tmp/sources.list.d/non-empty.list', 'w') as f:
        f.write('#' * 50)
    assert os.path.isfile('/tmp/sources.list.d/non-empty.list')

# Generated at 2022-06-23 03:09:33.107577
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Unit test for method remove_source of class UbuntuSourcesList

    #
    # Create test data
    #

    #
    # Create test mocks
    #

    #
    # Set up test objects
    #
    usl = UbuntuSourcesList(mock.MagicMock())

    #     def remove_source(self, line):

    # Tests
    #
    assert usl.remove_source("deb http://ppa.launchpad.net/myppa/myppa/ubuntu bionic main") == None


# Generated at 2022-06-23 03:09:40.257074
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sl = UbuntuSourcesList(None)
    sl.files['/tmp/test.list'] = [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main', '')]
    sl.remove_source('ppa:ansible/ansible')
    assert not sl.files
    # Check that original sources.list was not removed
    assert os.path.isfile('/etc/apt/sources.list')



# Generated at 2022-06-23 03:09:47.558611
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Create sample file
    file = tempfile.mktemp()
    with open(file, 'w') as f:
        f.write('''
# comment
deb-src foo main # comment
# deb-src foo universe # comment
# deb-src http X Z ''')
    SourcesList(module).add_source('deb http://bar.com main', comment='bar', file='bar.list')
    SourcesList(module).add_source('deb http://foo.com main', comment='foo')
    SourcesList(module).add_source('deb http://baz.com main')

    assert 'deb-src foo main # comment\n' in open(file).read()
    assert 'deb http://baz.com main\n' in open(file).read()

# Generated at 2022-06-23 03:09:55.673021
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    m = AnsibleModule(
        argument_spec=dict(
            add_source_line=dict(required=True, type='str'),
            comment=dict(type='str'),
            file=dict(type='str'),
            expected_sourceslist=dict(type='list')
        )
    )
    m.run_command = Mock(return_value=(0, '', ''))
    sourceslist = SourcesList(m)

    sourceslist.add_source(m.params['add_source_line'], m.params.get('comment', ''), m.params.get('file', None))
    result = sourceslist.dump()
    assert result == m.params['expected_sourceslist']


# Generated at 2022-06-23 03:10:08.709380
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-23 03:10:12.940099
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = VarsModule()
    sl = UbuntuSourcesList(module)
    assert sl.codename == distro.codename
    assert sl.add_ppa_signing_keys_callback is None
    assert isinstance(sl, UbuntuSourcesList)
    assert isinstance(sl, SourcesList)


# Generated at 2022-06-23 03:10:14.828384
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert callable(get_add_ppa_signing_key_callback('module'))


# Generated at 2022-06-23 03:10:21.509426
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sourcesfile_before = []
    sourcesfile_after = []
    sources_before = {}
    sources_after = {}
    module = Mock()
    sources_before[module.params['filename']] = sourcesfile_before
    sources_after[module.params['filename']] = sourcesfile_after
    with patch.multiple(os.path, remove=DEFAULT, exists=DEFAULT):
        os.path.remove.return_value = True
        os.path.exists.return_value = True
        with patch.multiple(os, remove=DEFAULT, exists=DEFAULT):
            os.remove.return_value = True
            os.exists.return_value = True
            with patch.multiple(sources, files=DEFAULT, new_repos=DEFAULT, save=DEFAULT):
                sources.files = sources_after


# Generated at 2022-06-23 03:10:28.256359
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    '''
    Test for method add_source of class SourcesList.
    '''

    if PY3:
        raise Exception('DocTest does not work for python 3')

    import doctest
    from ansible.module_utils import apt as apt_utils

    m = AnsibleModule(argument_spec=dict())
    m.params['filename'] = 'foo.list'
    sl = apt_utils.SourcesList(m)
    doctest.run_docstring_examples(sl.add_source, globals())


# Generated at 2022-06-23 03:10:34.537745
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sl = SourcesList()
    assert list(sl) == [(u'/etc/apt/sources.list', 0, True, u'deb http://ftp.ru.debian.org/debian/ jessie main', ' comment'), (u'/etc/apt/sources.list', 1, True, u'deb-src http://ftp.ru.debian.org/debian/ jessie main', ''), (u'/etc/apt/sources.list.d/additional.list', 0, True, u'deb http://archive.canonical.com/ubuntu hardy partner', '')]


# Generated at 2022-06-23 03:10:42.191181
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    from io import StringIO
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True,
                           check_invalid_arguments=False)
    sources = ["deb http://archive.ubuntu.com/ubuntu/ focal main restricted universe multiverse",
               "deb http://archive.ubuntu.com/ubuntu/ focal-updates main restricted universe multiverse"]
    default_file = "sources.list"
    f = StringIO(sources[0]+"\n"+sources[1]+"\n")
    source_list = SourcesList(module)
    source_list.load(f)
    assert source_list.default_file == default_file

    assert len(list(source_list)) == 2
    # Remove both sources

# Generated at 2022-06-23 03:10:45.561539
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list with bad keys'''
    ret = revert_sources_list('foo', 'bar', 'baz')
    assert ret is None



# Generated at 2022-06-23 03:10:47.062075
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    UbuntuSourcesList(dict())
    UbuntuSourcesList(dict(), None)



# Generated at 2022-06-23 03:10:49.225981
# Unit test for constructor of class InvalidSource

# Generated at 2022-06-23 03:10:51.842697
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Test message")
    except InvalidSource as e:
        assert "Test message" in str(e)



# Generated at 2022-06-23 03:11:02.366893
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        from unittest import mock
    except ImportError:
        import mock

    filename = 'sources.list'
    sources = [
        (0, True, True, '#foo', ''),
        (1, True, False, 'bar', ''),
        (2, False, False, 'baz', ''),
        (3, True, True, 'qaz', 'qaz')
    ]
    sl = SourcesList(None)
    sl.files = {}
    sl.files[filename] = sources
    i = iter(sl)
    for n, source in enumerate(sources[1:]):
        assert (filename, source[0], True, source[3], source[4]) == next(i)
    assert True



# Generated at 2022-06-23 03:11:13.590488
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import doctest
    from ansible.module_utils.six import StringIO

    m = DummyModule()
    s = SourcesList(m)
    assert s.default_file == '/etc/apt/sources.list'

    f = tempfile.NamedTemporaryFile(mode='w')

# Generated at 2022-06-23 03:11:25.950539
# Unit test for function main
def test_main():
    args = dict(
        repo='repo',
        state='present',
        mode=dict(),
        update_cache='True',
        update_cache_retries=5,
        update_cache_retry_max_delay=12,
        filename='filename',
        # This should not be needed, but exists as a failsafe
        install_python_apt='True',
        validate_certs='True',
        codename='codename',
    )
    p = ModuleArgsParser(args)
    main()


# Generated at 2022-06-23 03:11:27.299216
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass

# Generated at 2022-06-23 03:11:32.136137
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sources_list = SourcesList()
    sources_list.load("/tmp/ansible-test-sources")
    for file, sources in sources_list.files.items():
        for n, valid, enabled, source, comment in sources:
            if valid:
                yield file, n, enabled, source, comment

# Generated at 2022-06-23 03:11:42.976750
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    class SourcesListTestCase(unittest.TestCase):
        def setUp(self):
            self.sources = SourcesList(AnsibleModule(argument_spec={
                "filename": {"required": False, "type": "str"},
                "mode": {"required": False, "type": "int"},
            }))
            self.sources.load('tests/apt_repository/fixtures/sources_list_1')

        def test_atomic_write_empty_source_file(self):
            self.sources.files[self.sources.default_file] = []
            self.sources.save()
            self.assertFalse(os.path.isfile(self.sources.default_file))


# Generated at 2022-06-23 03:11:48.850238
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    ubuntusourceslist = UbuntuSourcesList(module)
    repos_urls = ubuntusourceslist.repos_urls
    assert repos_urls is not None, "failed to get repositories"


# Generated at 2022-06-23 03:11:58.950123
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)

# Generated at 2022-06-23 03:12:10.042577
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class _Module:
        class _FailJson:
            def __call__(self, **kwargs):
                raise Exception(kwargs['msg'])
        fail_json = _FailJson()

    mod = _Module()
    usl = UbuntuSourcesList(mod)
    usl.files = {'file1': [
        (1, False, False, 'abc'),  # dummy line test to ensure that remove_source() will not affect it
        (2, True, True, 'deb http://ppa.launchpad.net/webupd8team/java/ubuntu trusty main'),  # existing entry
    ]}
    usl.remove_source('ppa:webupd8team/java')
    assert len(usl.files['file1']) == 1, 'Length of removed entry should be 0'

# Generated at 2022-06-23 03:12:23.606789
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    """
    Test function __iter__() of SourcesList class.
    """
    from ansible.module_utils.six import StringIO
    class FakeModule():
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()
            self.params = {'mode': 0o600, 'filename': None}
        def fail_json(self, message):
            raise Exception(message)
        def atomic_move(self, path1, path2):
            shutil.move(path1, path2)
        def set_mode_if_different(self, path, mode, changed):
            # do nothing
            pass

# Generated at 2022-06-23 03:12:34.047624
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Fake module for testing
    class ModuleStub(object):
        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

        def __init__(self, check_mode):
            self.check_mode = check_mode

        def run_command(self, command, check_rc):
            if command[3] == '0xEFE21092':
                return self.RunCommandResult(0, '', '')
            else:
                return self.RunCommandResult(1, '', "failed to fetch PPA information, error was: %s" % info['msg'])

    module = ModuleStub(check_mode=False)

# Generated at 2022-06-23 03:12:41.876818
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sl = SourcesList()
    sl.files = {
        'file_one': [(0, True, True, 'source1', 'comment1'),
                     (1, True, True, 'source2', 'comment2'),
                     (2, True, True, 'source3', 'comment3'),
                     (3, True, False, 'source4', 'comment4')],
        'file_two': []
    }
    expected = {
        'file_one': 'source1\nsource2\nsource3\nsource4 # comment4\n',
        'file_two': ''
    }
    assert expected == sl.dump()



# Generated at 2022-06-23 03:12:46.346082
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Initialize
    sl = SourcesList(None)
    sl.load("/sources-list")
    sl.remove_source("deb-src http://deb.debian.org/debian buster main")
    # Verify results
    assert sl.files['/sources-list'][-1][2] is False


# Generated at 2022-06-23 03:12:52.945089
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    m = MagicMock(spec=dict)
    m.params = dict(
        codename='bionic',
        filename='filename',
        mode='mode',
    )
    m.run_command.return_value = (0, '', '')

    # We need to mock fetch_url, because it is called inside the __init__
    # method of UbuntuSourcesList class
    sl = UbuntuSourcesList(m, add_ppa_signing_keys_callback=None)

    def mock_fetch_url(m, url, headers=None):
        assert url == 'https://launchpad.net/api/1.0/~demo/+archive/demo'
        return '', dict(status=200)
    setattr(sl, 'fetch_url', mock_fetch_url)


# Generated at 2022-06-23 03:13:00.446935
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = Mock(params=dict())
    sources_list = UbuntuSourcesList(module)

    sources_list.load('/tmp/sources.list')
    sources_list.remove_source('deb http://deb.debian.org/debian stretch main')

    module.exit_json(changed=False, msg='ruh roh')

# Generated at 2022-06-23 03:13:11.243278
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources_data = {
                '/etc/apt/sources.list': [
                    (
                        0, True, True, 'deb http://ppa.launchpad.net/myppa/myppa/ubuntu bionic main',
                        'This file is my test'
                    )
                ],
                '/etc/apt/sources.list.d/mytest.list': [
                    (
                        0, True, True, 'deb http://ppa.launchpad.net/myppa/myppa/ubuntu bionic main',
                        'This file is my test'
                    ),
                    (
                        1, True, True, 'deb-src http://ppa.launchpad.net/myppa/myppa/ubuntu bionic main',
                        'This file is my test'
                    )
                ]
            }


# Generated at 2022-06-23 03:13:18.955147
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class DummyModule:
        def __init__(self):
            self.params = {}
        def check_mode(self):
            return False
        def fail_json(self, msg):
            raise Exception(msg)
        def warn(self, msg):
            pass

    def fail_with_message(msg):
        raise Exception(msg)

    module = DummyModule()
    sources = SourcesList(module)
    sources.files[sources.default_file] = [
        (0, True, True, 'deb http://example.com/debian example-package main', ''),
        (1, True, False, 'deb http://example.com/debian example-package-2 main', ''),
    ]

    sources.modify(sources.default_file, 0, comment='comment')

# Generated at 2022-06-23 03:13:31.462968
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # test_add_source_change_source_list_and_update_file_contents
    module = AnsibleModule(argument_spec={'state': dict(default='present', choices=['absent', 'present']),
                                          'filename': dict(default=None),
                                          'update_cache': dict(default='no', type='bool'),
                                          'repo': dict(required=True),
                                          'comment': dict(default=''),
                                          'mode': dict(default=None)})
    repo_instance = Repo(module)
    template = UbuntuSourcesList(module)
    template.files[template.default_file] = []

# Generated at 2022-06-23 03:13:42.200352
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock()

    assert get_add_ppa_signing_key_callback(module) is None

    module.check_mode = False

    def _check_run_command(command):
        assert command == ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '123']
    module.run_command.side_effect = _check_run_command
    get_add_ppa_signing_key_callback(module)(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '123'])



# Generated at 2022-06-23 03:13:50.619098
# Unit test for function main

# Generated at 2022-06-23 03:14:02.148944
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    t = tempfile.NamedTemporaryFile()
    fname = t.name
    t.write("""
    # This is a valid comment with no entry.
    # deb http://archive.canonical.com/ubuntu raring partner
    deb http://archive.ubuntu.com/ubuntu/ xenial main restricted
    deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted
    # deb-src http://archive.canonical.com/ubuntu raring partner
    """.encode('utf-8'))
    t.flush()

    # Iterate through SourcesList to make sure that comments skipped, only valid
    # sources will be returned.
    sources = SourcesList(fname)
    results = set()
    for file, n, enabled, source, comment in sources:
        results.add(source)


# Generated at 2022-06-23 03:14:02.755470
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-23 03:14:13.598019
# Unit test for function main

# Generated at 2022-06-23 03:14:24.440412
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # It's necessary to have some valid source in sources.list
    # for fetch_apt_locked to work
    with open('/etc/apt/sources.list.d/ansible-test.list', 'w') as fixture:
        fixture.write('deb http://archive.ubuntu.com/ubuntu xenial main')

    sl = UbuntuSourcesList('ppa:ansible/ansible')
    sl.remove_source("ppa:ansible/ansible")
    assert len(sl.files.keys()) == 1
    assert ('/etc/apt/sources.list.d/ansible-test.list', [
        (0,
         True,
         True,
         'deb http://archive.ubuntu.com/ubuntu xenial main',
         '')]) == list(sl.files.items())[0]



# Generated at 2022-06-23 03:14:36.446584
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    assert SourcesList(None).dump() == {}

    fake_module = type('FakeModule', (object,), {'params': {}, 'atomic_move': None, 'set_mode_if_different': None})

    # We're not testing parsing, so don't care of params
    sources = SourcesList(fake_module)

    # Test empty files
    sources.files = {
        '/etc/apt/file1.list': [],
        '/etc/apt/file2.list': [],
    }
    assert sources.dump() == {}

    # Test one file

# Generated at 2022-06-23 03:14:46.762636
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    obj = UbuntuSourcesList('module')

# Generated at 2022-06-23 03:14:47.982105
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert InvalidSource



# Generated at 2022-06-23 03:14:49.280588
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass



# Generated at 2022-06-23 03:14:54.775489
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = DummyModule()
    sl = UbuntuSourcesList(module)
    want = 'http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    sl.add_source('ppa:ansible/ansible')
    have = sl.files[sl.default_file][0][3]
    assert want == have


# Generated at 2022-06-23 03:15:05.400558
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fake_module = type('FakeModule', (object,), {'params': {}, 'fail_json': module.fail_json, 'run_command': lambda *args, **kw: (0, '', ''), 'atomic_move': lambda a, b: None, 'set_mode_if_different': lambda a, b, c: None})
    sl = SourcesList(fake_module)
    test_cases = [
        ('deb http://myrepo main', 'deb http://myrepo main'),
        ('# deb http://myrepo main', '# deb http://myrepo main'),
        ('# deb http://myrepo main # my comment', '# deb http://myrepo main # my comment'),
    ]

# Generated at 2022-06-23 03:15:13.368727
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    """
    Test case for method add_source of class SourcesList
    """
    # Create a dummy module for testing

# Generated at 2022-06-23 03:15:24.751755
# Unit test for function install_python_apt
def test_install_python_apt():

    class MockModule(object):
        "Mock class for AnsibleModule"
        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda key, value: (key, value)
            self.run_command = lambda command: (0, None, None)
        def get_bin_path(self, apt_pkg_name):
            return 'mock_apt'
    apt_pkg_name = 'python-apt'
    mod = MockModule(install_python_apt=True, check_mode=False)
    install_python_apt(mod, apt_pkg_name)
    assert True
    mod = MockModule(install_python_apt=True, check_mode=True)

# Generated at 2022-06-23 03:15:34.827970
# Unit test for function install_python_apt
def test_install_python_apt():
    # We need to create a class instance that mocks our module
    class FakeModule:
        # We'll add attributes to our instance to reflect what would actually be
        # returned by `ansible.builtin.module_common.AnsibleModule`
        def fail_json(self, msg):
            self.fail_json_msg = msg

        def get_bin_path(self, binary):
            return 'apt-get'

        def run_command(self, command):
            if command[0] == 'apt-get' and command[1] == 'update':
                return (0, '', '')
            else:
                return (0, '', '')

    # We can safely ignore Pylint's complaints about mocking AnsibleModule, because
    # we're not actually calling it here.
    # pylint: disable=unused-

# Generated at 2022-06-23 03:15:41.689246
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})

    orig_apt_cfg_file = SourcesList._apt_cfg_file
    orig_apt_cfg_dir = SourcesList._apt_cfg_dir

    def fake_apt_cfg_file(filespec):
        return to_native(os.path.abspath(os.path.join(os.path.dirname(__file__), '../files', filespec)))

    def fake_apt_cfg_dir(dirspec):
        return to_native(os.path.abspath(os.path.join(os.path.dirname(__file__), '../files', dirspec)))

    SourcesList._apt_cfg_file = fake_apt_cfg_file
    SourcesList._apt_cfg_dir = fake_apt_cfg_dir

    sl = SourcesList(module)

# Generated at 2022-06-23 03:15:53.831715
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-23 03:16:05.755791
# Unit test for method __iter__ of class SourcesList