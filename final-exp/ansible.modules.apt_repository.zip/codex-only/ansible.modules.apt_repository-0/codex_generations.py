

# Generated at 2022-06-23 03:06:14.529095
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    file = '/test/file'
    self = SourcesList

    def _testcase(self, testcase, old, new, expected):
        self.files[file] = [old]
        self.modify(file, 0, enabled=new[0], source=new[1], comment=new[2])
        if self.files[file][0] != expected:
            self.module.fail_json(msg="Test case failed: file=%s old=%s new=%s expected=%s" % (file, old, new, expected))

    module = type('Module', (object,), {})
    self.module = module()
    self.files = {}


# Generated at 2022-06-23 03:06:20.516397
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    msg = 'Repository could not be added: an invalid line was encountered.'
    try:
        raise InvalidSource
    except InvalidSource as exception:
        assert str(exception) == msg


# Generated at 2022-06-23 03:06:21.269020
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass


# Generated at 2022-06-23 03:06:30.019261
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.six import b
    import shutil
    import tempfile

    def test_dir():
        dir = tempfile.mkdtemp()
        yield dir
        shutil.rmtree(dir)

    def file_content(dir, file):
        with open(os.path.join(dir, file)) as f:
            return f.read()

    def check_content(dir, file, content):
        assert content == file_content(dir, file)

    def create_file(dir, file, content):
        with open(os.path.join(dir, file), 'w') as f:
            f.write(content)

    # /Dir/:Etc:sourceparts should be a directory

# Generated at 2022-06-23 03:06:42.343720
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    tempdir = tempfile.mkdtemp('sourceslist')
    sourceslist = SourcesList(module)
    sourceslist_files = {}
    sourceslist_files["%s/sources.list"%tempdir] = ['deb http://archive.ubuntu.com/ubuntu trusty main main-updates restricted universe multiverse\n',
                                                    'deb http://archive.canonical.com/ubuntu hardy partner\n']
    sourceslist_files["%s/1.list"%tempdir] = ['# deb http://archive.canonical.com/ubuntu hardy partner\n',
                                              'deb http://dl.google.com/linux/chrome/deb/ stable main\n']

# Generated at 2022-06-23 03:06:53.122732
# Unit test for function main

# Generated at 2022-06-23 03:07:02.625771
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = self.fail
            self.atomic_move = self.move

        def fail(self, msg):
            self.msg = msg

        def move(self, src, dst):
            self.actual = open(src.name).read()
            self.expected = open(dst).read()

    class MySourcesList(SourcesList):
        def __init__(self, module):
            super(MySourcesList, self).__init__(module)

# Generated at 2022-06-23 03:07:08.449833
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    src = SourcesList()

    src.new_repos = {'src_list': True}

    src.load('test_list')

    # Test is current line modified
    src.modify('test_list', 0)
    assert src.files['test_list'] == [(0, True, True, 'deb http://ubuntu.com/ubuntu bionic main', '')]

    # Test is new line modified
    src.modify('test_list', len(src.files['test_list']), source='deb http://ubuntu.com/ubuntu bionic contrib')
    assert src.files['test_list'] == [(0, True, True, 'deb http://ubuntu.com/ubuntu bionic main', ''),
                                      (1, True, True, 'deb http://ubuntu.com/ubuntu bionic contrib', '')]

    # Test is all

# Generated at 2022-06-23 03:07:20.050056
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():

    module = AnsibleModule({})

    s = SourcesList(module)
    new_s = SourcesList(module)

    s.load('tests/apt_repository/sources.list')
    new_s.load('tests/apt_repository/sources.list')

    for filename, sources in list(new_s.files.items()):
        if sources:
            d = '/tmp'
            fn = os.path.basename(filename)
            fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % fn, dir=d)
            f = os.fdopen(fd, 'w')
            for n, valid, enabled, source, comment in sources:
                chunks = []
                if not enabled:
                    chunks.append('# ')
                chunks.append(source)
               

# Generated at 2022-06-23 03:07:27.558688
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Test method modify of class SourcesList

    class TestSourcesList(SourcesList):
        def __init__(self, module):
            self.files = {}
            self.files['sources.list'] = [(0, True, True, 'deb http://www.example.com trusty', ''),
                                          (1, True, True, 'deb http://www.example.com saucy', 'Comment'),
                                          (2, True, False, 'deb http://www.example.com raring', ''),
                                          (3, True, False, 'deb http://www.example.com precise', ''),
                                          (4, True, False, 'deb http://www.example.com saucy', '')]
            self.loaded_files = dict(self.files)

    source_list = TestSourcesList(None)



# Generated at 2022-06-23 03:07:29.850746
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, supports_check_mode=True)
    sl = SourcesList(module)
    assert (sl.default_file is not None)



# Generated at 2022-06-23 03:07:41.066462
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    targets = [
        'comments',
        'source_file',
        'source_line',
    ]
    module_args = dict(
        filename="filename",
        comment="comment",
        codename="codename",
        state="state",
        update_cache=True,
        update_mode="update_mode",
    )
    instance = UbuntuSourcesList(MagicMock(params=module_args))
    instance.comments = []
    instance.source_file = "source_file"
    instance.source_line = "source_line"
    copy_instance = copy.deepcopy(instance)
    for target in targets:
        assert getattr(copy_instance, target) == getattr(instance, target)
    assert copy_instance.module == instance.module
    assert copy_instance.add_ppa_signing_keys

# Generated at 2022-06-23 03:07:52.125568
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    file = "/tmp/sources.list"
    if os.path.exists(file):
        module.exit_json(changed=False)


# Generated at 2022-06-23 03:08:04.705800
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({
        'state': 'present',
        'repo': 'deb http://archive.canonical.com/ubuntu hardy partner',
    },
    {},
    {})

    # file1
    file1 = '/etc/apt/sources.list.d/archive.canonical.com_ubuntu_dists_trusty_partner_binary-amd64_Packages'
    group1 = []
    group1.append((0, True, True, 'deb http://archive.canonical.com/ubuntu trusty partner', 'Partner archive'))
    group1.append((1, True, True, 'deb http://archive.canonical.com/ubuntu trusty partner', '#Partner archive'))

    # file2
    file2 = '/etc/apt/sources.list'
    group2 = []

# Generated at 2022-06-23 03:08:13.732162
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import io
    import sys
    import unittest

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common._collections_compat import MutableMapping


    class FakeModule(MutableMapping):
        def __init__(self):
            self.run_command_result = None
            self.checks = []
            self.params = {}
            self.tmpdir = None

        class _FailingCommand(Exception):
            pass

        def fail_json(self, *args, **kwargs):
            raise TypeError("unexpected call to fail_json")


# Generated at 2022-06-23 03:08:14.288352
# Unit test for function revert_sources_list
def test_revert_sources_list():
    assert True



# Generated at 2022-06-23 03:08:17.423288
# Unit test for constructor of class SourcesList
def test_SourcesList():
    '''
    Simple test for SourcesList constructor
    '''
    sources = SourcesList(AnsibleModule(argument_spec={}))
    # we're expecting that sources.list and sources.list.d will not be empty for any target system
    assert len(sources.files) > 0



# Generated at 2022-06-23 03:08:22.392949
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')

# This was inspired by what aptsoures.sourceslist does.
# The difference here is that we will add multiple entries to the
# same file, but we also don't need to modify the file if the
# source is already present.

# Generated at 2022-06-23 03:08:32.834595
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    def _no_op(command):
        pass

    module = AnsibleModule(argument_spec={'codename': {'default': 'xenial', 'type': 'str'}})
    sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=_no_op)

    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/baz')
    sources_list.add_source('deb http://packages.example.com/debian/ testing main')
    sources_list.add_source('deb http://packages.example.com/debian/ testing main', '# comment')
    assert len(sources_list.files) == 4, 'We need to have 4 sources: two ppas and two non-ppa sources'

# Generated at 2022-06-23 03:08:42.442099
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    def _parse(line):
        valid, enabled, source, comment = SourcesList._parse(line)
        if enabled:
            return source
        else:
            return '# %s' % source

    def _equal_source_lists(sl1, sl2):
        return _equal_lists(sl1.dump().values(), sl2.dump().values())

    def _equal_lists(list1, list2):
        if len(list1) != len(list2):
            return False

        for v1, v2 in zip(sorted(list1), sorted(list2)):
            if v1 != v2:
                return False
        return True


# Generated at 2022-06-23 03:08:55.717857
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files = {
        '/etc/apt/sources.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main', '')],
        '/etc/apt/sources.list.d/nodesource.list': [(0, True, True, 'deb http://deb.nodesource.com/node_8.x xenial main', '')],
        '/etc/apt/sources.list.d/non-repo.list': [(0, False, True, '', '')],
    }

# Generated at 2022-06-23 03:09:06.585334
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import unittest
    import mock
    from ansible.module_utils.apt import ModuleApt
    from ansible.module_utils._text import to_bytes

    module = mock.MagicMock(spec=ModuleApt)
    module.check_mode = False
    module.run_command.return_value = None

    callback = get_add_ppa_signing_key_callback(module)
    callback(['/usr/bin/apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '12345'])

# Generated at 2022-06-23 03:09:17.512320
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # test
    from ansible.module_utils._text import to_text

    _, tmp_path = tempfile.mkstemp()
    my_sources_list = SourcesList(AnsibleModule(
        argument_spec={},
    ))
    my_sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file=tmp_path)

    # test atomic_move
    import os
    import shutil
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, msg):
            raise RuntimeError(msg)
        @staticmethod
        def atomic_move(src, dst):
            shutil.move(src, dst)

# Generated at 2022-06-23 03:09:23.512964
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'a': 'aaa', 'b': 'bbb'}
    sources_after = {'a': 'aaa', 'b': 'bbb', 'c': 'ccc'}
    sourceslist_before = dict()

    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sources_after != {'a': 'aaa', 'b': 'bbb', 'c': 'ccc'}
    assert sourceslist_before == {'c': 'ccc'}



# Generated at 2022-06-23 03:09:36.942515
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    def mock_fetch_url(module, ppa_api, headers):
        return (StringIO('{"signing_key_fingerprint": "mocked"}'), {'status': 200})

    mocked_module = Mock()
    mocked_module.run_command = Mock(return_value=(0, 'mocked_output', ''))
    mocked_module.params = {}
    mocked_module.params['codename'] = 'mocked_codename'

    mocked_module.fail_json = Mock(side_effect=SystemExit('fail'))
    mocked_module.atomic_move = Mock()
    mocked_module.set_mode_if_different = Mock()

    mocked_module.fail_json.side_effect = SystemExit('fail')
    mocked_module.atomic_move.side_effect = SystemExit('fail')
    mocked_

# Generated at 2022-06-23 03:09:49.079356
# Unit test for function install_python_apt
def test_install_python_apt():
    import mock

    m = mock.MagicMock()
    m.get_bin_path.return_value = '/bin/apt-get'
    m.check_mode = False
    m.run_command.return_value = (0, '/bin/apt-get', None)

    install_python_apt(m, 'python-apt')

    assert m.run_command.call_count == 2
    assert m.run_command.call_args_list[0][0][0] == ['/bin/apt-get', 'update']
    assert m.run_command.call_args_list[1][0][0] == ['/bin/apt-get', 'install', 'python-apt', '-y', '-q']


# Generated at 2022-06-23 03:09:59.931814
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # create a backup of existing sources.list
    if os.path.exists('/etc/apt/sources.list'):
        os.rename('/etc/apt/sources.list', '/etc/apt/sources.list.ansible_test_bak')

    # build a dummy sources.list for testing
    os.makedirs('/etc/apt/sources.list.d')
    source_list = SourcesList(AnsibleModule(argument_spec={}))
    source_list.add_source('deb http://us.archive.ubuntu.com/ubuntu/ trusty multiverse')
    source_list.add_source('deb-src http://us.archive.ubuntu.com/ubuntu/ trusty multiverse')

    source_list.save()

# Generated at 2022-06-23 03:10:04.187841
# Unit test for function main
def test_main():
    module = AnsibleModule(
        supports_check_mode=True
        )
    module.exit_json = exit_json
    module.fail_json = fail_json

# pylint: disable=invalid-name,no-self-use

# Generated at 2022-06-23 03:10:11.183260
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    file = '/tmp/test'
    line = 'deb http://archive.canonical.com/ubuntu hardy partner'
    comment = 'test'
    sources = SourcesList(AnsibleModule({}))
    sources.add_source(line, comment, file=file)
    sources.remove_source(line)
    for filename, n, enabled, src, src_comment in sources:
        if src == line:
            raise Exception('Line "%s" not disabled in file "%s"' % (line, filename))


# Generated at 2022-06-23 03:10:21.800291
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from collections import namedtuple
    from mock import Mock
    import re
    from ansible.module_utils._text import to_bytes, to_text



# Generated at 2022-06-23 03:10:31.292341
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class FakeModule():
        def __init__(self):
            self.params = {
                'verbose': True,
                'filename': None
            }

        def fail_json(self, msg):
            print('Failed: ' + msg)

        def get_bin_path(self, name):
            return None

        def run_command(self, cmd):
            return 0, '', ''

        def atomic_move(self, src, dest):
            pass

        def set_mode_if_different(self, src, dest, changed):
            pass

    mod = FakeModule()
    sources = SourcesList(mod)

# Generated at 2022-06-23 03:10:39.930230
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Create file sources.list
    f = open('sources.list', 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu xenial main\n')
    f.write('deb http://archive.ubuntu.com/ubuntu xenial universe\n')
    f.write('# deb http://archive.ubuntu.com/ubuntu xenial-updates main\n')
    f.close()

    # Load file sources.list
    s = SourcesList(None)
    s.load('sources.list')

    # Modify the status of source http://archive.ubuntu.com/ubuntu xenial-updates main

# Generated at 2022-06-23 03:10:46.093553
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # get_add_ppa_signing_key_callback should return either
    # None if module.check_mode returns True
    # or a function that calls module.run_command with check_rc=True
    module = AnsibleModule(argument_spec=dict())
    module.check_mode = Mock()
    module.run_command = Mock()
    source_list = UbuntuSourcesList(module)
    function = source_list.get_add_ppa_signing_key_callback()
    # assert not None
    assert function is not None
    # call the function
    function(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'string'])
    # make assertTrue that the function was called
    module.run_

# Generated at 2022-06-23 03:10:58.580690
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    default_file = "/etc/apt/sources.list"
    file = "/etc/apt/sources.list.d/test.list"
    line1 = "deb [arch=amd64] http://archive.canonical.com/ubuntu bionic partner"
    line2 = "deb http://archive.canonical.com/ubuntu bionic partner"

    sl = SourcesList(AnsibleModule(argument_spec={}))
    for i in sl:
        sl.modify(i[0], i[1], False, i[3], i[4])

    sl.add_source(line1)
    sl.add_source(line2, file=file)
    sl.add_source(line1, file="test")
    sl.save()
    sl.load(default_file)
    sl.load(file)


# Generated at 2022-06-23 03:11:13.306176
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    test_file = module.tmpdir + '/test_file'
    test_content = '''
deb [ arch=amd64 ] https://download.docker.com/linux/ubuntu artful stable
# deb-src [ arch=amd64 ] https://download.docker.com/linux/ubuntu artful stable
#
# See http://help.github.com for more information on how to create a github
# repo, commit and push.
#
# deb-src http://us.archive.ubuntu.com/ubuntu/ hardy main restricted
deb     http://us.archive.ubuntu.com/ubuntu/ hardy main restricted
'''
    open(test_file, 'w').write(test_content)
    sources = SourcesList(module)
    sources.load(test_file)
    assert sources.files

# Generated at 2022-06-23 03:11:24.002360
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec=dict(filename=dict(required=False, default=None)))
    sources = UbuntuSourcesList(module)

    sources.add_source('ppa:jonathonf/vim')
    assert sources.files == {
        'vim.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/jonathonf/vim/ubuntu xenial main', '')
        ]
    }
    sources.add_source('ppa:jonathonf/vim', comment='comment')
    assert sources.files == {
        'vim.list': [
            (0, True, True, 'deb http://ppa.launchpad.net/jonathonf/vim/ubuntu xenial main', 'comment')
        ]
    }

# Generated at 2022-06-23 03:11:36.355203
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    # Tests:
    #  - Error message when InvalidSource object is instantiated.
    #  - Error message when InvalidSource object is printed.
    #  - Error message when InvalidSource object is converted to string.

    # Setup
    class Foo:
        def __init__(self):
            self.foo = 'bar'
            self.bar = 'foo'

    orig_error_msg = 'Some error message'
    data = {'foo': 'bar', 'bar': 'foo'}

    # Run

# Generated at 2022-06-23 03:11:43.159136
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    '''
    Test cases for function get_add_ppa_signing_key_callback
    '''
    mocked_module = Mock()
    mocked_module.check_mode = False
    cb = get_add_ppa_signing_key_callback(mocked_module)
    command = ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '123A']
    cb(command)
    mocked_module.run_command.assert_called_once_with(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '123A'], check_rc=True)

    mocked_module = Mock()

# Generated at 2022-06-23 03:11:54.525151
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # NOTE: this test is used to test CODE in the apt_repository module, so
    # it should use the apt.repository module itself.
    '''
    test_SourcesList_remove_source
    '''

    module = ansible_module_mock()
    sourceslist = SourcesList(module)

    apt_sources_list_entry1 = "deb http://archive.ubuntu.com/ubuntu xenial main restricted\n"
    apt_sources_list_entry2 = "deb http://archive.ubuntu.com/ubuntu xenial-updates main restricted\n"

    test_data_list = []
    test_data_list.append([sourceslist, apt_sources_list_entry1, True])

# Generated at 2022-06-23 03:12:05.563153
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback(): 
    class AnsibleModule:
        def __init__(self):
            self.ansible_module = Mock()
            self.run_command = Mock()
        def fail_json(self, *args, **kwargs):
            self.ansible_module.fail_json(*args, **kwargs)
        def run_command(self, *args, **kwargs):
            return self.run_command(*args, **kwargs)
        def check_mode(self):
            return False

    module = AnsibleModule()
    result = get_add_ppa_signing_key_callback(module)
    assert result == AnsibleModule.run_command


# Generated at 2022-06-23 03:12:16.435552
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # test data
    test_line = 'deb [arch=amd64] http://some.hostname/repository/ some_repository some_component'
    test_comment = 'some comment'
    test_file = 'test_file.list'

    # test class
    test_class = SourcesList(None)

    # test execution
    test_class.add_source(test_line, test_comment, file=test_file)
    test_class.remove_source(test_line)

    # test results
    assert test_line not in test_class.dump()[test_file]


# Simple version of aptsources.distro.get_sources.
# No advanced logic, no signing keys.

# Generated at 2022-06-23 03:12:19.689385
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)
    assert('/etc/apt/sources.list' in sl.dump().keys())


# Generated at 2022-06-23 03:12:28.622626
# Unit test for function install_python_apt
def test_install_python_apt():
    class AnsibleModuleFake(object):
        def __init__(self):
            self.fail_json = self._fail_json
            self.checked = False
            self.installed = False
        
        def get_bin_path(self, bin_name):
            if bin_name == 'apt-get':
                return '/usr/bin/apt-get'
            else:
                return None
        
        def run_command(self, args):
            if self.checked == False:
                self.checked = True
                return (0, '', '')
            elif self.installed == False:
                self.installed = True
                return (0, '', '')
            elif self.installed == True:
                self.installed = False
                return (1, '', '')


# Generated at 2022-06-23 03:12:31.718451
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Invalid source.")
    except InvalidSource as e:
        assert repr(e) == 'InvalidSource("Invalid source.")'



# Generated at 2022-06-23 03:12:42.148079
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module=module)

    # Add deb-src spec as comment
    def t(source, comment, file=None):
        sl.files = {}
        sl.add_source(source, comment=comment, file=file)
        return sl.files


# Generated at 2022-06-23 03:12:52.114679
# Unit test for function revert_sources_list
def test_revert_sources_list():
    test_module = AnsibleModule(argument_spec=dict(codename=dict(default=None)))
    test_module.params['codename'] = 'trusty'
    test_module.params['state'] = 'present'
    test_module.params['filename'] = 'example_filename.foo'
    test_module.params['repo'] = 'ppa:foo/bar'

    test_sources_before = {}
    test_sources_after = {
        '/etc/apt/sources.list.d/example_filename.foo': 'deb http://ppa.launchpad.net/foo/bar/ubuntu trusty main\n',
    }
    test_sourceslist_before = UbuntuSourcesList(test_module)
    assert test_sourceslist_before.repos_urls == []
    test_sourceslist

# Generated at 2022-06-23 03:12:55.108293
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {}
    sources_after = {}
    sourceslist_before = {}
    assert revert_sources_list(sources_before,sources_after,sourceslist_before) == None

# Generated at 2022-06-23 03:13:01.572304
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **args: None
    sl = UbuntuSourcesList(module)
    sources_list = "/etc/apt/sources.list"
    sl.load(sources_list)
    assert sources_list in sl.files
    assert len(list(sl)) > 0

# Generated at 2022-06-23 03:13:12.133201
# Unit test for function main

# Generated at 2022-06-23 03:13:22.517662
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})

# Generated at 2022-06-23 03:13:35.376434
# Unit test for method load of class SourcesList

# Generated at 2022-06-23 03:13:39.533775
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import ansible.module_utils.basic

    mocked_module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    mocked_command_id = 0

    def mocked_run_command(command, check_rc=True):
        global mocked_command_id
        mocked_command_id += 1
        if mocked_command_id == 1:
            assert command == ['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '1122334455667788']

# Generated at 2022-06-23 03:13:51.082112
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    """
    Unit test for method load of class SourcesList
    """
    import unittest
    from ansible.module_utils.apt_repository import InvalidSource, SourcesList

    class SourcesListTest(unittest.TestCase):
        def test_load_empty_file(self):
            f = tempfile.NamedTemporaryFile()
            sl = SourcesList(None)
            sl.load(f.name)
            self.assertEqual(sl.files, {f.name: []})

        def test_load_multiple_files(self):
            f1 = tempfile.NamedTemporaryFile()
            f2 = tempfile.NamedTemporaryFile()
            sl = SourcesList(None)
            sl.load(f1.name)
            sl.load(f2.name)
            self.assertE

# Generated at 2022-06-23 03:13:55.351359
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = MagicMock()
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-23 03:14:06.163671
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
  module = {
      'atomic_move': lambda a, b: None,
      'check_mode': True,
      'exit_json': lambda **kwargs: None,
      'get_bin_path': lambda bin: bin,
      'fail_json': lambda **kwargs: None,
      'params': {'purge': True}
  }
  sl = SourcesList(module)

# Generated at 2022-06-23 03:14:15.816674
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os import skip_if_no_apt
    from ansible.modules.packaging.os import apt_repository
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six.moves import reload_module

    def setup_test_env():
        '''Setup the test env'''
        # Load the apt module
        sys.path.insert(0, os.path.join(os.getcwd(), 'library/'))

        # Check if the apt module is already loaded
        apt_repository_loaded = 'apt_repository' in sys.modules

# Generated at 2022-06-23 03:14:28.636408
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class Module:
        pass
    module = Module()
    module.params = {'codename': 'bionic'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('itstool/itstool')
    sources_list.add_source('ppa:chris-lea/node.js')
    sources_list.add_source('ppa:chris-lea/node.js', file='node.js.list')
    sources_list.add_source('deb http://ppa.launchpad.net/itstool/itstool/ubuntu bionic main # deb-src http://ppa.launchpad.net/itstool/itstool/ubuntu bionic main')

# Generated at 2022-06-23 03:14:37.629281
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class FakeModule(object):
        params = {}

    src = SourcesList(FakeModule())
    src._parse = lambda x: (True, True, x, '')

# Generated at 2022-06-23 03:14:40.378414
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Fake variables for testing
    sources_before = ['example.list']
    sources_after = ['example.list', 'example2.list']
    # Call function with fake variables
    revert_sources_list(sources_before, sources_after)


# Generated at 2022-06-23 03:14:52.860066
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    _run_command_called = 0
    def mock_run_command(command, check_rc=True):
        global _run_command_called
        _run_command_called = _run_command_called + 1

    m = magic_patch('ansible.module_utils.ubuntu_common.get_add_ppa_signing_key_callback')
    m.run_command = mock_run_command

    class ModuleProxy(object):
        def __init__(self):
            self.check_mode = False

    module = ModuleProxy()

    f = get_add_ppa_signing_key_callback(module)
    assert f is not None

# Generated at 2022-06-23 03:15:03.088340
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {
                     '/etc/apt/sources.list': '',
                     '/etc/apt/sources.list.d/google.list': '',
                     '/etc/apt/sources.list.d/google-cloud-sdk.list': '',
    }
    sources_after = {
        '/etc/apt/sources.list': '',
        '/etc/apt/sources.list.d/google.list': '',
        '/etc/apt/sources.list.d/google-cloud-sdk.list': '',
        '/etc/apt/sources.list.d/test.list': '',
    }

# Generated at 2022-06-23 03:15:12.619089
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    utils.skip_if_not_importable('apt_pkg')

    class MyModule(object):
        def __init__(self, params, add_ppa_signing_keys_callback):
            self.params = params
            self.add_ppa_signing_keys_callback = add_ppa_signing_keys_callback

    module = MyModule({
        'add_ppa_signing_keys': True,
        'mode': '0644',
    }, None)
    instance = UbuntuSourcesList(module)
    copy = copy.deepcopy(instance)

    # assert that the copy is really a copy and not the same instance
    assert instance is not copy
    assert instance._apt_cfg_file is not copy._apt_cfg_file
    assert instance._apt_cfg_dir is not copy._apt_cfg_dir

    #

# Generated at 2022-06-23 03:15:22.428402
# Unit test for function main
def test_main():
    p = dict(
        add = (dict(codename = 'codename', state = 'absent', repo = 'repo', update_cache_retry_max_delay = 12, update_cache = True, update_cache_retries = 5, filename = 'filename', mode = 'mode', install_python_apt = True, validate_certs = True), dict()),
    )
    module = AnsibleModule(
        argument_spec = p['add'][0],
        supports_check_mode = True,
    )

    p['add'][1]['module'] = module
    p['add'][1]['respawn_module'] = respawn_module
    p['add'][1]['err'] = True
    p['add'][1]['sys'] = True

# Generated at 2022-06-23 03:15:31.302240
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    m = AnsibleModule(argument_spec={})
    sl = SourcesList(module=m)

    # Simple case
    sl.add_source('deb http://archive.ubuntu.com/ubuntu xenial universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu xenial universe')
    assert len(sl.files) == 1
    assert len(sl.files[sl.default_file]) == 1
    assert sl.files[sl.default_file][0][2:] == (True, 'deb http://archive.ubuntu.com/ubuntu xenial universe', '')

    # Source with a comment.
    sl.add_source('deb http://archive.ubuntu.com/ubuntu xenial multiverse # Multiverse')
    assert len(sl.files) == 1

# Generated at 2022-06-23 03:15:42.707935
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({'state': 'present'})
    sl = SourcesList(module)
    sl.add_source('deb-src http://archive.ubuntu.com/ubuntu/ hardy multiverse',
                  comment='Ubuntu multiverse sources, until hardy')
    dumpstruct = sl.dump()
    assert dumpstruct == \
           {'/etc/apt/sources.list.d/archive_ubuntu_com_ubuntu.list':
                'deb-src http://archive.ubuntu.com/ubuntu/ hardy multiverse # Ubuntu multiverse sources, until hardy\n'}

    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ hardy multiverse',
                  comment='Ubuntu multiverse sources, until hardy')

    dumpstruct = sl.dump()

# Generated at 2022-06-23 03:15:54.387937
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    testdata = copy.deepcopy(SOURCES)
    testsl = UbuntuSourcesList(mock_module, None)
    for repo in testdata:
        testsl.add_source(repo['sourceline'], repo['comment'], repo['file'])
    for repo in testdata:
        testsl.remove_source(repo['sourceline'])
    # Check that sources are empty
    testsl_dump = testsl.dump()
    assert testsl_dump['/etc/apt/sources.list'] == ''
    assert testsl_dump['/etc/apt/sources.list.d/ansible_ansible.list'] == ''
    assert testsl_dump['/etc/apt/sources.list.d/ansible_nginx.list'] == ''

# Generated at 2022-06-23 03:15:58.844873
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    error = InvalidSource('test_error_message')
    assert error.message == 'test_error_message'



# Generated at 2022-06-23 03:16:07.250241
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import StringIO
    import apt
    old_config = apt.apt_pkg.config.set
    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_stdin = sys.stdin
    old_open = open
    old_exists = os.path.exists