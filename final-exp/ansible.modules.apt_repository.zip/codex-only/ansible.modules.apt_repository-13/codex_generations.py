

# Generated at 2022-06-23 03:06:17.500632
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class DummyModule(object):
        def __init__(self):
            self.params = dict()
            self.params['filename'] = None
        @staticmethod
        def get_bin_path(bin_name):
            return ''
        @staticmethod
        def fail_json(msg):
            print(msg)
            exit(1)

    # Test parsing of sources
    module = DummyModule()
    sourceslist = SourcesList(module)

    # Test parsing of sources
    source1 = 'deb http://archive.ubuntu.com/ubuntu vivid main restricted universe # Vivid'
    source2 = 'deb-src https://archive.ubuntu.com/ubuntu vivid main restricted universe # Vivid'
    source3 = '# deb http://archive.ubuntu.com/ubuntu vivid main restricted universe # Vivid'

# Generated at 2022-06-23 03:06:24.093190
# Unit test for function install_python_apt
def test_install_python_apt():
    class Result(object):
        def __init__(self):
            self.rc = 0
            self.stdout = ""
            self.stderr = ""
    class Module(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.fail_json = lambda x: False
            self.warn = lambda x: False
            self.run_command = lambda x: Result()
    module = Module()
    install_python_apt(module, 'name')



# Generated at 2022-06-23 03:06:33.422697
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # The call to the function or method . . . . . . . . . . . . . . . . . . . . . . . . .
    module = DummyModule()
    ubuntu_sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-23 03:06:45.571471
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils.basic import AnsibleModule

    am = AnsibleModule(argument_spec={})
    orig = UbuntuSourcesList(am)
    orig.module.run_command = Mock(return_value=0, side_effect=lambda *args, **kargs: [0, '', ''])

    copy = copy.deepcopy(orig)

    assert copy is not orig, "A copy of UbuntuSourcesList should not be identical to the original"
    assert copy.__class__ is orig.__class__, "A copy of UbuntuSourcesList should have the same class as the original"
    assert copy.add_ppa_signing_keys_callback is orig.add_ppa_signing_keys_callback, "A copy of UbuntuSourcesList should have the same add_ppa_signing_keys_callback attribute as the original"

# Generated at 2022-06-23 03:06:54.484638
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sl = SourcesList(AnsibleModule(
        argument_spec=dict(
            filename=dict(required=False, type='str'),
            mode=dict(required=False, type='int'),
        ),
        supports_check_mode=True))

    sl.add_source('deb http://example.com/debian testing main', comment='added by test')
    sl.add_source('deb https://example.com/debian testing main', comment='added by test')
    sl.add_source('deb https://user:pass@example.com/debian testing main', comment='added by test')
    sl.add_source('deb https://user:pass@example.com/debian testing main', file='testing.list', comment='added by test')

# Generated at 2022-06-23 03:07:03.707639
# Unit test for function main
def test_main():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.tests.unit.compat.mock import patch, PropertyMock, MagicMock, Mock, call

    class TestModule(unittest.TestCase):

        def setUp(self):
            self.module = MagicMock()

            self.module.params = {
                'repo': 'foo'
            }
            self.module._diff = True

            self.module.check_mode = False

            self.module.run_command = MagicMock()
            self.module.fail_json = MagicMock()

            self.module.exit_json = MagicMock()

        def test_sourceslist_save(self):
            sl = MagicMock()

# Generated at 2022-06-23 03:07:09.390832
# Unit test for constructor of class SourcesList
def test_SourcesList():
    class AnsibleModuleMock(object):
        class ModuleResult(object):
            def __init__(self, changed=False, result=None):
                self.changed = changed
                self.result = result
                self.parsed_results = None

        def __init__(self):
            self.params = {'filename': None}

        def fail_json(self, msg):
            pass

        def exit_json(self, changed=False, result=None):
            raise RuntimeError(self.ModuleResult(changed, result))

        def atomic_move(self, src, dest):
            shutil.move(src, dest)

        def set_mode_if_different(self, path, mode, changed=False):
            pass

        def check_file_absent(self, path):
            return False


# Generated at 2022-06-23 03:07:13.202201
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(None) is None
    assert get_add_ppa_signing_key_callback('abc') is None


# Generated at 2022-06-23 03:07:19.612205
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(
        argument_spec=dict(
            codename=dict(),
        ),
    )

    sl = UbuntuSourcesList(module)
    assert not hasattr(sl, 'module')
    assert not hasattr(sl, 'add_ppa_signing_keys_callback')
    assert not hasattr(sl, 'codename')



# Generated at 2022-06-23 03:07:21.700820
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('Source is invalid.')
    except InvalidSource as e:
        print(e.args)


# Generated at 2022-06-23 03:07:35.820949
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    '''
    Unit test for constructor of class UbuntuSourcesList
    '''
    # Do not modify `example_sources.list`
    module = Mock(params={'filename': 'example_sources.list', 'codename': 'xenial'})
    sources_list = UbuntuSourcesList(module)
    mock_callback = MagicMock()
    sources_list.add_ppa_signing_keys_callback = mock_callback
    sources_list.add_source('ppa:foo/bar')

    repositories = sources_list.repos_urls
    assert 'ppa:foo/bar' in repositories
    assert 'http://ppa.launchpad.net/foo/bar/ubuntu xenial main' in repositories


# Generated at 2022-06-23 03:07:47.249800
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'
    module = better_arg_parser()
    module.return_values['get_bin_path'] = True
    module.return_values['run_command'] = True
    install_python_apt(module, apt_pkg_name)
    expected_result = {'changed': True, 'warnings': []}
    module.exit_json.assert_called_with(**expected_result)
  
    module = better_arg_parser()
    module.return_values['get_bin_path'] = True
    module.return_values['run_command'] = False
    install_python_apt(module, apt_pkg_name)

# Generated at 2022-06-23 03:07:52.400946
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # this should not fail
    UbuntuSourcesList(None).remove_source('ppa:kivy-team/kivy')



# Generated at 2022-06-23 03:08:03.836845
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Test the method without supplying the optional parameter
    m = MagicMock()
    s = UbuntuSourcesList(m)
    c = copy.deepcopy(s)
    assert c.module == s.module
    assert c.add_ppa_signing_keys_callback == s.add_ppa_signing_keys_callback
    assert c.codename == s.codename

    # Test the method supplying the optional parameter
    c = copy.deepcopy(s, dict())
    assert c.module == s.module
    assert c.add_ppa_signing_keys_callback == s.add_ppa_signing_keys_callback
    assert c.codename == s.codename



# Generated at 2022-06-23 03:08:09.275679
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict())
    sources = SourcesList(module)
    sources._add_valid_source('deb http://dl.google.com/linux/chrome/deb/ stable main', '')
    sources._remove_valid_source('deb http://dl.google.com/linux/chrome/deb/ stable main')
    assert list(sources) == []


# Generated at 2022-06-23 03:08:11.814081
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sl = SourcesList(module)

    assert sl.default_file
    assert sl.files



# Generated at 2022-06-23 03:08:25.252340
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    sl = SourcesList(module)

    # add new valid source
    line = "deb     http://archive.canonical.com/ubuntu hardy partner"
    comment = "Comment for this source"
    file = "new.list"
    sl.add_source(line, comment, file)
    assert file in sl.files
    assert len(sl.files[file]) == 1
    assert sl.files[file][0][1]
    assert sl.files[file][0][2]
    assert sl.files[file][0][3] == "deb http://archive.canonical.com/ubuntu hardy partner"
    assert sl.files[file][0][4] == comment

    # add

# Generated at 2022-06-23 03:08:27.183435
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict())
    sources = SourcesList(module)
    assert sources.files



# Generated at 2022-06-23 03:08:28.915927
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    i = InvalidSource("test")
    assert str(i) == "test"



# Generated at 2022-06-23 03:08:40.352840
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class FakeModule(object):
        def fail_json(self, *args, **kwargs):
            raise RuntimeError('fail_json() should not be called')

    sources = SourcesList(FakeModule())
    sources.files = {
        'a': [(1, True, True, 's1', 'c1'), (2, False, False, 's2', 'c2'), (3, True, True, 's3', 'c3'), (4, False, True, 's4', 'c4')],
        'b': [(5, False, False, 's5', 'c5'), (6, True, True, 's6', 'c6')],
        'c': [(7, False, True, 's7', 'c7')]
    }

    all_sources = list(sources)


# Generated at 2022-06-23 03:08:47.675098
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class ModuleMock:
        def __init__(self):
            self.params = {'codename': 'trusty'}

    class SourcesListMock:
        def __init__(self):
            self.module = ModuleMock()

    s = UbuntuSourcesList(SourcesListMock(), add_ppa_signing_keys_callback=None)
    copy_s = copy.deepcopy(s)
    assert copy_s == s



# Generated at 2022-06-23 03:08:59.999372
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    distro.set_codename('xenial')
    sl = UbuntuSourcesList(module=module)

    # empty cache
    assert len(list(sl)) == 0

    # add one source
    sl.add_source('ppa:foo/ppa')
    assert len(list(sl)) == 1

    # add source for testing duplicate source
    sl.add_source('ppa:foo/bar')
    assert len(list(sl)) == 2

    # add source for testing duplicate source, but different line
    sl.add_source('deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main')
    assert len(list(sl)) == 2

    # add source for testing duplicate source, but different codename
    sl.add_source

# Generated at 2022-06-23 03:09:09.495659
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    line1 = "deb [arch=amd64] https://download.docker.com/linux/ubuntu xenial stable"
    line2 = "deb-src https://download.docker.com/linux/ubuntu xenial stable"
    line3 = "deb http://debian.mirror.iweb.ca/debian stretch main contrib non-free"
    line4 = "deb-src http://debian.mirror.iweb.ca/debian stretch main contrib non-free"
    line5 = "# deb-src http://security.debian.org/ stretch/updates main"
    line6 = "# deb http://debian.mirror.iweb.ca/debian stretch main contrib non-free"
    line7 = "deb [arch=amd64] https://download.docker.com/linux/ubuntu bionic stable"

# Generated at 2022-06-23 03:09:23.443211
# Unit test for function install_python_apt
def test_install_python_apt():
    # test_install_python_apt()
    import mock

    #
    # create a Mock Module and patch the run_command() method
    #
    module = mock.Mock()
    module.check_mode = False
    module.get_bin_path.return_value = '/usr/bin/apt-get'
    module.run_command.return_value = (0, '', '')
    #
    # call the function
    #
    install_python_apt(module, 'python-apt')
    #
    # did the expected commands get run?
    #

# Generated at 2022-06-23 03:09:36.904855
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class MockModule:
        class MockFailJson:
            def __init__(self, *args, **kwargs):
                self.args = args
                self.kwargs = kwargs

        def __init__(self, params, run_command_args=None, run_command_return_value=None, atomic_move=None, fetch_url_params=None, fetch_url_return_value=None, set_mode_if_different=None):
            self.params = params
            self.run_command_args = run_command_args
            self.run_command_return_value = run_command_return_value
            self.atomic_move_args = None
            self.atomic_move = atomic_move or self._atomic_move
            self.fetch_url_params = fetch_url_params
            self.f

# Generated at 2022-06-23 03:09:38.740925
# Unit test for function install_python_apt
def test_install_python_apt():
    pass


# Generated at 2022-06-23 03:09:46.278421
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Create config file
    config = "deb http://archive.ubuntu.com/ubuntu precise main restricted universe multiverse\n\
deb http://archive.ubuntu.com/ubuntu precise-security main restricted universe multiverse\n\
deb http://archive.ubuntu.com/ubuntu precise-updates main restricted universe multiverse\n\
# deb http://archive.ubuntu.com/ubuntu precise partner\n"
    fd, tmp_path = tempfile.mkstemp(suffix=".list")
    with open(tmp_path, 'w') as config_file:
        config_file.write(config)

    # Make instance of SourcesList
    sl = SourcesList(AnsibleModule(argument_spec={}))

    # Modify all sources

# Generated at 2022-06-23 03:09:53.919344
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = Mock()
    module.params = dict()
    module.params['filename'] = None
    module.params['codename'] = 'xenial'

    class ReturnCode:
        def __init__(self):
            self.return_code = 0

        def run_command(self, *args, **kwargs):
            return self.return_code, None, None

    return_code = ReturnCode()
    module.run_command = return_code.run_command

    class ModuleFailJson:
        def __init__(self):
            self.fail_json_called = False

        def fail_json(self, *args, **kwargs):
            self.fail_json_called = True

    module_fail_json = ModuleFailJson()
    module.fail_json = module_fail_json.fail_json

# Generated at 2022-06-23 03:10:03.040057
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    # modify lines to get a predictable result
    lines = ['deb http://archive.ubuntu.com/ubuntu xenial main\n',
             '\n',
             '# deb-src http://archive.ubuntu.com/ubuntu xenial main\n',
             'deb http://archive.ubuntu.com/ubuntu xenial-updates main universe\n',
             '# deb-src http://archive.ubuntu.com/ubuntu xenial-updates main universe\n',
             'deb http://archive.ubuntu.com/ubuntu xenial-security main universe\n',
             '# deb-src http://archive.ubuntu.com/ubuntu xenial-security main universe\n',
             '\n',
             '# deb-src http://archive.ubuntu.com/ubuntu xenial-security main universe\n',
             '\n']

# Generated at 2022-06-23 03:10:04.668836
# Unit test for constructor of class SourcesList
def test_SourcesList():
    assert SourcesList("/etc/apt/sources.list")



# Generated at 2022-06-23 03:10:14.189350
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    apt = SourcesList()
    apt.add_source('deb ftp://ftp.debian.org/debian wheezy main')
    apt.add_source('deb ftp://ftp.debian.org/debian wheezy contrib')
    apt.add_source('deb-src ftp://ftp.debian.org/debian wheezy contrib non-free', comment='third party non-free packages')

    assert apt.dump() == {'sources.list':
                            '''deb ftp://ftp.debian.org/debian wheezy main
deb ftp://ftp.debian.org/debian wheezy contrib
deb-src ftp://ftp.debian.org/debian wheezy contrib non-free # third party non-free packages
'''}



# Generated at 2022-06-23 03:10:24.149214
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # unit tests
    class Module():
        def fail_json(self, *args, **kwargs):
            raise AssertionError(json.dumps(args, indent=2, sort_keys=True) + ' ' + json.dumps(kwargs, indent=2, sort_keys=True))

        def get_bin_path(self, *args, **kwargs):
            return None

    sl = SourcesList(Module())

# Generated at 2022-06-23 03:10:26.030677
# Unit test for constructor of class SourcesList
def test_SourcesList():
    list = SourcesList()

    entries = list.dump()
    assert entries[list.default_file] is not None



# Generated at 2022-06-23 03:10:27.576820
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    a = SourcesList()

# Generated at 2022-06-23 03:10:40.895787
# Unit test for function main
def test_main():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    test_utils_path = os.path.join(current_dir, '..', 'test_utils.py')
    args = []
    if PY3:
        args.append('-3')
    args.append(test_utils_path)
    args.append(__file__)
    args.append('--color')
    args.append('no')
    args.append('--truncate')
    args.append('-120')
    if platform.system() == 'Windows':
        args = ['"%s"' % arg for arg in args]
    rc = subprocess.call(' '.join(args), shell=True)
    if rc != 0:
        exit(rc)


# Generated at 2022-06-23 03:10:44.443127
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    """ remove_source
    """
    module = AnsibleModule(argument_spec={})
    mods = set()
    # Arguments: line
    obj = SourcesList(module)
    line = 'dummy_line'
    obj.remove_source(line)

# Generated at 2022-06-23 03:10:50.708998
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = {'params': {'codename': 'trusty'}}
    _sources_list = UbuntuSourcesList(module)
    d_copy_sources_list = copy.deepcopy(_sources_list)
    assert type(_sources_list) == type(d_copy_sources_list)
    assert id(_sources_list) != id(d_copy_sources_list)
    assert _sources_list.codename == d_copy_sources_list.codename


# Generated at 2022-06-23 03:11:02.318995
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module_args = {}
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=False)
    sl = SourcesList(module)
    for filename, n, enabled, source, comment in sl:
        sl.modify(filename, n, enabled=False)

    assert len(sl.dump().values()) == 1

# Generated at 2022-06-23 03:11:13.556802
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils import basic
    from ansible.module.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import configparser

    class FakeModule:
        def __init__(self):
            self.params = {'state': 'absent'}
            self.configparser = configparser
            self.basic = basic
            self.utils = basic.AnsibleModule
            self.StringIO = StringIO
            self.backup_local = ''
            self.atomic_move = ''

    class FakeSourcesListAnsibleModule:
        def __init__(self):
            self.module = FakeModule()
            self.params = {'dist_upgrade': 'dist_upgrade'}


# Generated at 2022-06-23 03:11:24.198928
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils import basic
    import ansible.module_utils.apt_pkg as apt_pkg

    def mocked_apt_pkg_find_file(filespec):
        if filespec == "Dir::Etc::sourceparts":
            return "./test/sources.list.d"
        elif filespec == "Dir::Etc::sourcelist":
            return "./test/sources.list"

    def mocked_apt_pkg_find_dir(dirspec):
        if dirspec == "Dir::Etc::sourceparts":
            return "./test/sources.list.d"
        elif dirspec == "Dir::Etc::sourcelist":
            return "./test/sources.list"


# Generated at 2022-06-23 03:11:32.386118
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    try:
        import distro
    except ImportError:
        return

    # Create an Ubuntu test system
    distro.id() == 'ubuntu'

    module = MagicMock
    module.params = {}
    module.params['filename'] = None
    module.params['codename'] = None

    module.run_command.return_value = 0, 'Sample output\n', ''

    ub_sol = UbuntuSourcesList(module)

    # Verify the test system has the right files
    assert ub_sol.default_file == '/etc/apt/sources.list'
    assert os.path.exists(ub_sol.default_file)



# Generated at 2022-06-23 03:11:38.411022
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = UbuntuSourcesList(module)
    sl.load('test_source.list')
    sl.remove_source('http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    assert len(sl.files['test_source.list']) == 1
    assert sl.files['test_source.list'][0][3] == 'deb http://ppa.launchpad.net/ansible/foo/ubuntu trusty main'

# Generated at 2022-06-23 03:11:39.924956
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert True



# Generated at 2022-06-23 03:11:44.403633
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("This source is invalid.")
    except InvalidSource as e:
        assert(str(e) == "This source is invalid.")


# Generated at 2022-06-23 03:11:55.745638
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    Unit test for method add_source of class SourcesList
     - check if sources are added correctly
     - check if passed sources and comments are correct
     - check if file is created if it doesn't exist
     - check if file is dropped if it is empty after removing all sources
     - check if default filename is used if filename is not specified
    '''
    module = FakeAnsibleModule()
    sources = FakeAnsibleModule()
    # we use tempfile to get a temporary folder
    # this works, because directories are created
    # with the same rights as their parents
    # the temporary directory is removed at the end
    tmpdir = tempfile.tempdir

    # Add 4 valid sources

# Generated at 2022-06-23 03:12:07.462025
# Unit test for function install_python_apt
def test_install_python_apt():
    class TestModule(object):
        def __init__(self):
            self.check_mode = False
            self.run_command_calls = 0
            self.fail_json_calls = 0
        def get_bin_path(self, executable):
            return '/usr/bin/apt-get'
        def run_command(self, executable):
            self.run_command_calls += 1
            return 0, '', ''
        def fail_json(self, msg):
            self.fail_json_calls += 1
            raise Exception(msg)
    module = TestModule()
    install_python_apt(module, 'python3-apt')
    assert module.run_command_calls == 2
    assert module.fail_json_calls == 0


# Generated at 2022-06-23 03:12:12.990090
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(FakeModule(check_mode=False))
    assert add_ppa_signing_key_callback
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(FakeModule(check_mode=True))
    assert add_ppa_signing_key_callback is None



# Generated at 2022-06-23 03:12:23.551433
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():

    sl = UbuntuSourcesList(dict(codename='xenial'))

    assert(sl.files == {})
    assert(sl.codename == 'xenial')

    # Let's add couple of sources.
    sl.add_source('deb http://ftp.ru.debian.org/debian/ jessie main')
    sl.add_source('deb http://security.debian.org/ jessie/updates main')
    sl.add_source('ppa:ubuntu-toolchain-r/test')

    # Make sure that we have correct number of files
    assert(len(sl.files) == 2)

    # Let's check that we have expected sources in each file

# Generated at 2022-06-23 03:12:35.722586
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    module.exit_json = lambda x: None

    sl = SourcesList(module)
    sl.files = dict(file1=[(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', None),
                           (1, True, True, 'deb-src http://archive.canonical.com/ubuntu hardy partner', None)],
                    file2=[(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ vivid main restricted', None),
                           (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ vivid-updates main restricted', None)])

    assert (sl.files['file1'][0][2], sl.files['file1'][1][2]) == (True, True)

# Generated at 2022-06-23 03:12:44.345383
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(name='UbuntuSourcesListTest', version='0.0.0',
                           argument_spec=dict(mode=dict(required=False, type='str')))

# Generated at 2022-06-23 03:12:45.047599
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # TODO: unit tests for function revert_sources_list
    pass



# Generated at 2022-06-23 03:12:52.275972
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import os
    import tempfile
    import shutil
    import sys

    template = '''
deb http://example.com/deb/ stable partner
deb-src http://example.com/deb/ stable partner
deb http://example.com/deb/ other
deb-src http://example.com/deb/ other
'''

    def _write_file(filename, content):
        '''
        Write ``content`` to ``filename``.
        Create parent directories if necessary. Return full path to the file.
        '''
        d, fn = os.path.split(filename)
        if d:
            os.makedirs(d)

        f = open(filename, 'w')
        f.write(content)
        f.close()

        return filename

    # create testing environment
    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-23 03:13:05.935298
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModuleMock(
        dict(
            state='present',
            repository='ppa:foo/bar',
            update_cache=False,
        )
    )

    add_ppa_signing_keys_callback = get_add_ppa_signing_key_callback(module)
    assert add_ppa_signing_keys_callback is not None

    command = ['apt-key', 'adv', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '--recv-keys', '12345']
    add_ppa_signing_keys_callback(command)

    assert module.run_command.called
    assert command == module.run_command.call_args[0][0]


# Generated at 2022-06-23 03:13:09.384852
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = 'any'
    obj = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    assert isinstance(deepcopy(obj), UbuntuSourcesList)


# Generated at 2022-06-23 03:13:17.008339
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)
    dump = sl.dump()
    # There must be at least one file with sources
    assert dump
    # And there must be at least one source in this file
    assert dump.values()[0]


# Generated at 2022-06-23 03:13:25.024367
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.module_utils.basic import AnsibleModule
    apt_pkg_name = 'python-apt'
    module = AnsibleModule({})
    # Force variable to None, since we do not have apt-get
    module.get_bin_path = lambda apt_get_path: None
    module.run_command = lambda cmd, check_rc=True: (1, 'stdout', 'stderr')
    module.check_mode = False
    try:
        install_python_apt(module, apt_pkg_name)
    except SystemExit as e:
        if e.code == 0:
            assert False, 'The module should exit with error'
        elif e.code == 1:
            assert True
        else:
            assert False, 'The module should exit with error'

# Generated at 2022-06-23 03:13:37.520626
# Unit test for function main

# Generated at 2022-06-23 03:13:45.737995
# Unit test for function main

# Generated at 2022-06-23 03:13:55.379702
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    import os
    testdir = '/tmp/ansible_pt_test_dir'
    try:
        os.makedirs(testdir)
    except OSError:
        pass

    tmpprefix = '/tmp/ansible_pt_test_sources_list_source-'
    tmpfile = tempfile.NamedTemporaryFile(prefix=tmpprefix, dir=testdir)
    tmpfilename = tmpfile.name
    tmpfile.close()


# Generated at 2022-06-23 03:14:00.884751
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_after = {'filename1': 'content'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = {'filename1': 'content'}
    revert_sources_list(sources_after, sources_after, sourceslist_before)



# Generated at 2022-06-23 03:14:11.757268
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Mock module
    module = type('FakeModule', (), {})
    module.check_mode = False
    module.params = {'filename': None}
    module.run_command = lambda x, check_rc=False: ('', '', 0)
    module.fail_json = lambda msg: None
    module.atomic_move = lambda x, y: None
    module.set_mode_if_different = lambda x, y, z: None
    # Assign mocked functions to 'apt'

# Generated at 2022-06-23 03:14:18.961899
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=[0, '', ''])
    module.get_bin_path = MagicMock(return_value="/usr/bin/apt-get")
    assert install_python_apt(module, "python-apt") is None



# Generated at 2022-06-23 03:14:21.801926
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('test')
    assert str(exc) == 'test'
    assert repr(exc) == 'test'


# Generated at 2022-06-23 03:14:32.727834
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import tempfile
    import subprocess

    def _run_command(command):
        env = os.environ.copy()
        env['DEBIAN_FRONTEND'] = 'noninteractive'
        subprocess.check_call(command, env=env)

    def _make_module(**kwargs):
        return type('module', (object,), dict(
            run_command=mock.Mock(return_value=(0, '', '')),
            check_mode=kwargs.get('check_mode', False),
        ))

    def _make_tmp_file(content):
        fd, fn = tempfile.mkstemp()
        os.write(fd, content.encode('utf-8'))
        os.close(fd)
        return fn


# Generated at 2022-06-23 03:14:39.280135
# Unit test for function install_python_apt
def test_install_python_apt():
    class mock_module:
        def __init__(self):
            self.fail_json = lambda *args, **kwargs: sys.exit(1)
            self.run_command = lambda *args, **kwargs: (0, "", "")
            self.check_mode = False
            self.get_bin_path = lambda *args, **kwargs: "apt-get"
    install_python_apt(mock_module(), "python-apt")


# Generated at 2022-06-23 03:14:46.506726
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict(state=dict(type='str', default='present', choices=['present', 'absent']),
                                              repo=dict(type='str', required=True),
                                              filename=dict(type='str', default=None),
                                              update_cache=dict(type='bool', default=False)),
                           supports_check_mode=True)
    sources_list = SourcesList(module)
    for file, sources in sources_list.files.items():
        for n, valid, enabled, source, comment in sources:
            if valid:
                assert ' ' in source
                assert len(source.split()) >= 3



# Generated at 2022-06-23 03:14:56.188180
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    data = []
    source = []
    for line in open("sources.list").readlines():
        data.append(line.lstrip("#").strip())
        if line.startswith("#"):
            continue
        source.append(line.split()[0].strip())
    sl = SourcesList()
    for line in data:
        sl._parse(line)
    for s in source:
        sl._remove_valid_source(s)
    for file, sources in list(sl.files.items()):
        for n, valid, enabled, source, comment in sources:
            assert source == s


# Generated at 2022-06-23 03:15:06.596821
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    os.environ['APT_CONFIG'] = os.path.join(os.path.dirname(__file__), 'fixtures', 'apt.conf')
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty multiverse')
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty main restricted', comment='test')
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty universe', file='test-file')
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty multiverse', file='test-file')
    s.add_source('# disabled multiverse', file='test-file')
    s.save()


# Generated at 2022-06-23 03:15:11.483987
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    e = InvalidSource("repo", "deb")
    assert str(e) == "'deb' is not a valid source type. Valid types include ['deb-src']"
    e = InvalidSource("repo", "deb-src")
    assert str(e) == "Source deb-src does not contain required components. String should be of the form: deb [ type [ subtype ] ] uri section"


# Generated at 2022-06-23 03:15:22.388451
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    expect = {}
    test_instance = SourcesList(None)
    test_instance.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner', 'test', '/etc/apt/sources.list.d/test.list')
    expect = {u'/etc/apt/sources.list.d/test.list': u'deb-src http://archive.canonical.com/ubuntu hardy partner test\n'}
    assert test_instance.dump() == expect
    test_instance.add_source('deb http://archive.canonical.com/ubuntu trusty partner', 'test2', '/etc/apt/sources.list.d/test.list')

# Generated at 2022-06-23 03:15:33.007737
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    test_module = AnsibleModule(argument_spec={})
    test_module.exit_json = lambda x: True
    global SourcesList
    SourcesList = type('TestSourcesList', (), {'_apt_cfg_file': lambda x: '/dev/null', '_apt_cfg_dir': lambda x: '/dev/null'})
    sourceslist = SourcesList(test_module)
    sourceslist.load('/dev/null')
    assert sourceslist.dump() == {'/dev/null': ''}
    sourceslist.load('/dev/null')
    assert sourceslist.dump() == {'/dev/null': ''}

# Generated at 2022-06-23 03:15:34.604787
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    with pytest.raises(InvalidSource):
        raise InvalidSource



# Generated at 2022-06-23 03:15:45.195176
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    # Create valid dummy sources.list file

# Generated at 2022-06-23 03:15:50.253785
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    sl = SourcesList(module)
    print(json.dumps(sl.dump(), indent=2))
    assert len(sl.dump()['/etc/apt/sources.list'].split('\n')) > 10


# Generated at 2022-06-23 03:15:50.997763
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass

# Generated at 2022-06-23 03:15:54.040337
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = sys.modules['__builtin__'].AnsibleModule
    source_list = SourcesList(module)
    assert source_list


# Generated at 2022-06-23 03:16:03.119697
# Unit test for function install_python_apt
def test_install_python_apt():
    # Import apt and apt_pkg.
    import apt
    import apt_pkg
    # Get apt object.
    apt = apt_pkg.Cache()
    # Check if cache is still empty, i.e.
    # python-apt not installed.
    if len(apt.keys()) == 0:
        install_python_apt(apt)
        # Check if python-apt is installed.
        if len(apt.keys()) == 0:
            # If not we bail out.
            return False
        else:
            # If it is we are golden.
            return True
    else:
        # Looks like python-apt is already installed.
        # We are golden.
        return True


# ===========================================
# Main control flow


# Generated at 2022-06-23 03:16:15.250992
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'/etc/apt/sources.list': 'some content'}
    sources_after = {'/etc/apt/sources.list': 'some new content', '/etc/apt/sources.list.d/git-core.list': 'some content'}
    sourceslist_before = apt_list(None)
    sourceslist_before.files = {'/etc/apt/sources.list': 'some content'}

    expected_sources_after = {'/etc/apt/sources.list': 'some content'}
    expected_sourceslist_before = apt_list(None)
    expected_sourceslist_before.files = {'/etc/apt/sources.list': 'some content', '/etc/apt/sources.list.d/git-core.list': 'some content'}

    revert_