

# Generated at 2022-06-17 04:02:59.801935
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:03:04.370407
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import aptsources.distro

    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import reload_module

    from ansible.module_utils.apt_repository import (
        get_add_ppa_signing_key_callback,
        respawn_module,
        probe_interpreters_for_module,
        install_python_apt,
        has_respawned,
        SourcesList,
        InvalidSource,
        UbuntuSourcesList,
        revert_sources_list,
        main,
    )

    from ansible.module_utils._text import to_bytes, to_native

    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-17 04:03:19.210166
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import stat
    import sys

    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins

    class FakeModule(object):
        def __init__(self):
            self.params = {'mode': 0o644}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = shutil.move
            self.set_mode_if_different = os.chmod

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

    class FakeFile(object):
        def __init__(self, name):
            self.name = name
            self.content = ''


# Generated at 2022-06-17 04:03:28.347188
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import os
    import shutil
    import stat
    import filecmp
    import sys

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = os.path.join(tmpdir, 'sources.list')
    # Create temporary file
    tmpfile2 = os.path.join(tmpdir, 'sources.list.d', 'test.list')
    # Create temporary file
    tmpfile3 = os.path.join(tmpdir, 'sources.list.d', 'test2.list')

    # Create temporary file
    f = open(tmpfile, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')

# Generated at 2022-06-17 04:03:38.391954
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:03:47.169900
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('tests/test_sources.list')
    dumpstruct = sl.dump()

# Generated at 2022-06-17 04:03:52.869914
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule(object):
        def __init__(self):
            self.params = {'codename': 'trusty'}

    module = MockModule()
    add_ppa_signing_keys_callback = lambda command: None
    sl = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    sl_copy = copy.deepcopy(sl)
    assert sl_copy.codename == 'trusty'
    assert sl_copy.add_ppa_signing_keys_callback == add_ppa_signing_keys_callback



# Generated at 2022-06-17 04:04:00.197699
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    import stat

    def _read_file(filename):
        with open(filename, 'r') as f:
            return f.read()

    def _check_file(filename, expected):
        assert _read_file(filename) == expected

    def _check_file_mode(filename, expected):
        assert stat.S_IMODE(os.stat(filename).st_mode) == expected

    def _check_file_exists(filename, expected):
        assert os.path.exists(filename) == expected

    def _check_file_not_exists(filename):
        _check_file_exists(filename, False)

    def _check_file_is_symlink(filename, expected):
        assert os.path.islink(filename) == expected

   

# Generated at 2022-06-17 04:04:03.899747
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:04:14.618321
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:04:55.607832
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['codename'] = 'xenial'

    class MockAddPpaSigningKeysCallback(object):
        def __init__(self):
            pass

    module = MockModule()
    add_ppa_signing_keys_callback = MockAddPpaSigningKeysCallback()
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    usl_copy = copy.deepcopy(usl)
    assert usl_copy.module == usl.module
    assert usl_copy.codename == usl.codename
    assert usl_copy.add_ppa_signing_keys_callback == usl.add_ppa_signing_keys_callback


# Generated at 2022-06-17 04:05:08.209756
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load(os.path.join(os.path.dirname(__file__), 'test_data', 'sources.list'))
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) == 3
    assert sources.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert sources.files['/etc/apt/sources.list'][1] == (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')

# Generated at 2022-06-17 04:05:19.731596
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.urls import fetch_url
    import json
    import os
    import tempfile
    import glob
    import re
    import apt_pkg
    import distro
    import shutil
    import sys
    import stat
    import subprocess
    import time
    import traceback
    import types
    import warnings
    import yaml
    import zlib
    import zipfile
    import zlib
    import zmq
    from ansible.module_utils.six.moves import shlex_quote
    from ansible.module_utils.six.moves.urllib.parse import urls

# Generated at 2022-06-17 04:05:25.709864
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:05:29.017449
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    assert len(sources_list.files) == 1
    assert len(sources_list.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:05:40.957689
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    dump = sources_list.dump()

# Generated at 2022-06-17 04:05:51.662242
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    assert sl.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]
    sl.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo_bar_xenial.list')

# Generated at 2022-06-17 04:06:03.087749
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # test for ppa
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    assert sources_list.files['/etc/apt/sources.list.d/ansible_ansible_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]

    # test for ppa with owner name
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible/ubuntu')

# Generated at 2022-06-17 04:06:06.715315
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu xenial main restricted')
    assert len(sources.files['tests/test_sources.list']) == 1
    assert sources.files['tests/test_sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu xenial-updates main restricted'


# Generated at 2022-06-17 04:06:13.291177
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'filename': 'test.list'}
    module.check_mode = True
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:07:44.128906
# Unit test for function main

# Generated at 2022-06-17 04:07:55.001062
# Unit test for method remove_source of class UbuntuSourcesList

# Generated at 2022-06-17 04:08:03.853237
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'trusty'}
    sl = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:08:09.165756
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.dump() == {}


# Generated at 2022-06-17 04:08:19.109055
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
   

# Generated at 2022-06-17 04:08:21.050341
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    sources_list.dump()


# Generated at 2022-06-17 04:08:31.559888
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:08:36.773493
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:08:45.922918
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')

# Generated at 2022-06-17 04:08:54.161803
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.files[sources.default_file] == [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.files[sources.default_file] == [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='test')

# Generated at 2022-06-17 04:11:10.510711
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:11:15.187636
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources

# Generated at 2022-06-17 04:11:28.354769
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:11:38.453249
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:11:42.525125
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')

# Generated at 2022-06-17 04:11:52.204100
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:11:54.774491
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:12:03.957851
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/tmp/test.list')
    sl.modify('/tmp/test.list', 0, enabled=False)
    assert sl.files['/tmp/test.list'][0][2] == False
    sl.modify('/tmp/test.list', 0, enabled=True)
    assert sl.files['/tmp/test.list'][0][2] == True
    sl.modify('/tmp/test.list', 0, source='deb http://archive.canonical.com/ubuntu hardy partner')
    assert sl.files['/tmp/test.list'][0][3] == 'deb http://archive.canonical.com/ubuntu hardy partner'

# Generated at 2022-06-17 04:12:05.868074
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:12:19.446398
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    sources.modify('tests/test_sources.list', 0, enabled=False, comment='new comment')
    sources.modify('tests/test_sources.list', 1, source='deb http://example.com/ubuntu trusty main')
    sources.modify('tests/test_sources.list', 2, source='deb http://example.com/ubuntu trusty main', comment='new comment')
    sources.modify('tests/test_sources.list', 3, enabled=False)
    sources.modify('tests/test_sources.list', 4, enabled=False, comment='new comment')