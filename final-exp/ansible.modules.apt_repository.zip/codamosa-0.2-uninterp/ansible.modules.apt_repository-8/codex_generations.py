

# Generated at 2022-06-17 04:03:01.821599
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources_list.dump() == {}


# Generated at 2022-06-17 04:03:06.413318
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:13.030580
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:03:19.344247
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes
    import tempfile

    module = AnsibleModule(argument_spec={})
    sources_before = {
        '/etc/apt/sources.list': 'deb http://example.com/debian jessie main\n',
        '/etc/apt/sources.list.d/example.list': 'deb http://example.com/debian jessie main\n',
    }

# Generated at 2022-06-17 04:03:20.506359
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-17 04:03:27.257388
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:03:37.672129
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:03:44.453594
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    assert sources_list.files['/etc/apt/sources.list.d/ansible_ansible_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-17 04:03:46.956183
# Unit test for function install_python_apt
def test_install_python_apt():
    # TODO: write unit test
    pass



# Generated at 2022-06-17 04:03:55.986139
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list'''
    module = AnsibleModule(argument_spec={})
    sources_before = {'file1': 'line1\nline2\n'}
    sources_after = {'file1': 'line1\nline2\n', 'file2': 'line3\nline4\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = sources_before
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.files == sources_before


# Generated at 2022-06-17 04:04:31.173008
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt import SourcesList

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.module = AnsibleModule(argument_spec={})
            self.module.exit_json = lambda x: x
            self.module.fail_json = lambda x: x
            self.module.atomic_move = lambda x, y: shutil.move(x, y)
            self.module.set_mode_if_different = lambda x, y, z: None
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(shutil.rmtree, self.tmpdir)


# Generated at 2022-06-17 04:04:35.500011
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:04:46.037225
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:04:57.258377
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:05:08.983904
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(None)

# Generated at 2022-06-17 04:05:11.761673
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:05:21.853972
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:05:33.576157
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    sl.load('/etc/apt/sources.list.d/ansible.list')
    sl.load('/etc/apt/sources.list.d/ansible-2.list')
    sl.load('/etc/apt/sources.list.d/ansible-3.list')
    sl.load('/etc/apt/sources.list.d/ansible-4.list')
    sl.load('/etc/apt/sources.list.d/ansible-5.list')
    sl.load('/etc/apt/sources.list.d/ansible-6.list')

# Generated at 2022-06-17 04:05:37.523516
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert sources.files['/etc/apt/sources.list']


# Generated at 2022-06-17 04:05:49.190296
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['repo'] = None
    module.params['comment'] = None
    module.params['mode'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['repo'] = None
    module.params['comment'] = None
    module.params['mode'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
   

# Generated at 2022-06-17 04:07:08.604499
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/example.list': 'deb http://example.com/ubuntu trusty main\n',
    }
    sources_after = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/example.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/new.list': 'deb http://example.com/ubuntu trusty main\n',
    }
    sourceslist_before = UbuntuSourcesList(module)


# Generated at 2022-06-17 04:07:18.699567
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    Test for method dump of class SourcesList
    '''
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    dumpstruct = sources.dump()

# Generated at 2022-06-17 04:07:24.071466
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:07:34.785668
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:07:39.199407
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:07:47.973408
# Unit test for function main

# Generated at 2022-06-17 04:07:52.044486
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    assert len(sources_list.files) == 1
    assert len(sources_list.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:08:00.600514
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = ''
    module.params['distribution'] = 'xenial'
    module.params['key_url'] = None
    module.params['key_id'] = None
    module.params['key_server'] = 'keyserver.ubuntu.com'
    module.params['key_content'] = None

# Generated at 2022-06-17 04:08:07.367443
# Unit test for function main

# Generated at 2022-06-17 04:08:20.769887
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/google-chrome.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/nginx.list')