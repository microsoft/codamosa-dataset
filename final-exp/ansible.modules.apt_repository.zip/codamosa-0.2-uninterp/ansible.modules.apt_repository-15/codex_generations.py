

# Generated at 2022-06-17 04:03:06.282334
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    module.params = {'install_python_apt': True}
    module.check_mode = False
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')
    module.check_mode = True
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:03:11.492731
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    dump = sources.dump()
    assert dump == {'tests/test_sources.list': 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\ndeb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\ndeb http://archive.ubuntu.com/ubuntu/ trusty universe\ndeb http://archive.ubuntu.com/ubuntu/ trusty-updates universe\n'}



# Generated at 2022-06-17 04:03:22.802730
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:03:34.909721
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/baz')
    sources_list.add_source('deb http://example.com/ubuntu xenial main')
    sources_list.add_source('deb http://example.com/ubuntu xenial main')
    sources_list.add_source('deb http://example.com/ubuntu xenial main')
    sources_list.add_source('deb http://example.com/ubuntu xenial main')
    sources_list.add_source('deb http://example.com/ubuntu xenial main')

# Generated at 2022-06-17 04:03:45.070666
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:03:46.463506
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:47.763525
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:03:56.919148
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:04:08.733619
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/test.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/test2.list')

# Generated at 2022-06-17 04:04:17.641991
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils._text import to_bytes

    # Reload the module to make sure that the global variables are reset
    reload_module(apt_repository)

    # Create a temporary directory for the test
    tmpdir = tempfile.mkdtemp()
    os.chmod(tmpdir, 0o755)  # so that Apache can read test files, if using the apt-repository module

    # Create a temporary file for the test
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)

    # Create a temporary file for the test
    fd, tmpfile2

# Generated at 2022-06-17 04:05:22.472748
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import stat
    import sys

    def _create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def _read_file(path):
        with open(path, 'r') as f:
            return f.read()

    def _create_sources_list(content):
        tmp_dir = tempfile.mkdtemp()
        apt_cfg_dir = os.path.join(tmp_dir, 'etc', 'apt')
        os.makedirs(apt_cfg_dir)
        apt_cfg_file = os.path.join(apt_cfg_dir, 'sources.list')
        _create_file(apt_cfg_file, content)
        return apt_cfg_file

   

# Generated at 2022-06-17 04:05:27.389102
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:05:38.702590
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-")
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    f.write('\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted\n')

# Generated at 2022-06-17 04:05:50.144641
# Unit test for function main

# Generated at 2022-06-17 04:05:58.791279
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    dumpstruct = sl.dump()

# Generated at 2022-06-17 04:06:04.196713
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:06:06.499933
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:06:10.076787
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert sources.files['/etc/apt/sources.list']
    assert len(sources.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:06:16.152975
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:06:23.443448
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-17 04:07:37.489087
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:07:47.265524
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical.list')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical.list')

# Generated at 2022-06-17 04:07:55.572553
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main')
    sources.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main', file='google-chrome')
    sources.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main', file='google-chrome')
    sources.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main', file='google-chrome')

# Generated at 2022-06-17 04:08:04.310263
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load('tests/test_sources.list')

# Generated at 2022-06-17 04:08:13.024139
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted universe multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-security main restricted universe multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-backports main restricted universe multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-proposed main restricted universe multiverse')

# Generated at 2022-06-17 04:08:17.250194
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:08:24.169111
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    assert sl.default_file == '/etc/apt/sources.list'
    assert sl.files == {}

    # Create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-", dir='/etc/apt')
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted\n')
    f.write('\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted\n')

# Generated at 2022-06-17 04:08:28.306420
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sources

# Generated at 2022-06-17 04:08:39.798870
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')

# Generated at 2022-06-17 04:08:50.315116
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)