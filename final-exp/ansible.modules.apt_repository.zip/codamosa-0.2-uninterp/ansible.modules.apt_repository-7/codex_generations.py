

# Generated at 2022-06-17 04:03:11.246459
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda msg: sys.exit(msg)
            self.atomic_move = os.rename
            self.set_mode_if_different = lambda filename, mode, follow: None

        def get_bin_path(self, name):
            return '/usr/bin/%s' % name

        def run_command(self, cmd):
            return 0, '', ''

    params = {
        'repo': 'deb http://archive.ubuntu.com/ubuntu trusty main',
        'state': 'present',
        'filename': 'test.list',
    }
    module = FakeModule(params)

    tmpdir = tempfile.mkd

# Generated at 2022-06-17 04:03:22.280375
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'codename': 'xenial'
    }
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    sl.add_source('ppa:foo/bar')
    sl.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo_bar.list')
    sl.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo_bar.list')
    sl.add_source('deb http://example.com/debian xenial main')
    sl.add_source('deb http://example.com/debian xenial main')

# Generated at 2022-06-17 04:03:34.867892
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:03:42.598025
# Unit test for function main

# Generated at 2022-06-17 04:03:53.501101
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['source'] = 'ppa:ansible/ansible'
    module.params['comment'] = '# comment'

    sources_list = UbuntuSourcesList(module)
    sources_list.add_source(module.params['source'], module.params['comment'], module.params['filename'])
    sources_list.save()

    sources_list_copy = copy.deepcopy(sources_list)
    sources_list_copy

# Generated at 2022-06-17 04:04:04.188048
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test for method add_source(self, line, comment='', file=None)
    # of class UbuntuSourcesList
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['keyserver'] = 'hkp://keyserver.ubuntu.com:80'
    module.params['keyid'] = '0xFBB75451'
    module.params['key_url'] = 'https://www.postgresql.org/media/keys/ACCC4CF8.asc'
   

# Generated at 2022-06-17 04:04:14.810263
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')

# Generated at 2022-06-17 04:04:21.113899
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = 'test comment'
    module.params['mode'] = '0644'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['state'] = 'present'
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params

# Generated at 2022-06-17 04:04:27.686544
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load('/tmp/test_sources.list')

# Generated at 2022-06-17 04:04:35.275092
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:56.079396
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.load('tests/sources.list')

# Generated at 2022-06-17 04:05:58.289905
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:06:10.110631
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-17 04:06:14.384135
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    sources_list.dump()


# Generated at 2022-06-17 04:06:22.713831
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/data/sources.list')
    sources_list.load('tests/data/sources.list.d/google-chrome.list')
    assert len(list(sources_list)) == 8
    for file, n, enabled, source, comment in sources_list:
        assert file in ('tests/data/sources.list', 'tests/data/sources.list.d/google-chrome.list')
        assert n in (0, 1, 2, 3, 4, 5, 6, 7)
        assert enabled in (True, False)

# Generated at 2022-06-17 04:06:25.883121
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sl = UbuntuSourcesList(module)
    sl_copy = copy.deepcopy(sl)
    assert sl_copy.codename == 'xenial'
    assert sl_copy.module == module
    assert sl_copy.add_ppa_signing_keys_callback == None


# Generated at 2022-06-17 04:06:30.990037
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:06:33.424403
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.remove_source('ppa:ansible/ansible')
    assert sources_list.repos_urls == []


# Generated at 2022-06-17 04:06:42.999042
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:06:52.296792
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.fail_json = MagicMock()
    module.atomic_move = MagicMock()
    module.set_mode_if_different = MagicMock()
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}

# Generated at 2022-06-17 04:07:47.327528
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict(
        codename=dict(default='trusty'),
        filename=dict(default=None),
        mode=dict(default=None),
    ))

    sources_list = UbuntuSourcesList(module)

    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')

    assert len(sources_list.repos_urls) == 1

    sources_list.remove_source('ppa:ansible/ansible')


# Generated at 2022-06-17 04:07:55.572603
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')

# Generated at 2022-06-17 04:07:59.656097
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    assert sources_list.default_file == '/etc/apt/sources.list'
    assert sources_list.files == {}
    assert sources_list.new_repos == set()


# Generated at 2022-06-17 04:08:03.196552
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources = UbuntuSourcesList(module)
    assert sources.codename == 'xenial'
    assert sources.add_ppa_signing_keys_callback is None


# Generated at 2022-06-17 04:08:12.038660
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load(os.path.join(os.path.dirname(__file__), 'sources.list'))
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse')
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted universe multiverse')
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu/ trusty-security main restricted universe multiverse')
    sources.remove_source('deb http://archive.ubuntu.com/ubuntu/ trusty-backports main restricted universe multiverse')
    sources.remove_source('deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse')
    sources.remove_source

# Generated at 2022-06-17 04:08:22.329629
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('tests/unit/modules/ansible_collections/ansible/builtin/files/test_sources.list')

# Generated at 2022-06-17 04:08:33.504527
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list'''
    # Create a temporary directory for testing
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file for testing
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file for testing
    tmpfile2 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file for testing
    tmpfile3 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file for testing
    tmpfile4 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Create a temporary file for testing
    tmpfile5 = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
   

# Generated at 2022-06-17 04:08:41.010312
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}
    assert list(sources) == []
    assert sources.dump() == {}


# Generated at 2022-06-17 04:08:49.294637
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')

# Generated at 2022-06-17 04:08:56.317497
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(
        argument_spec=dict(
            state=dict(default='present', choices=['absent', 'present']),
            filename=dict(default=None),
            update_cache=dict(default=False, type='bool'),
            cache_valid_time=dict(default=0, type='int'),
            source=dict(required=True),
            comment=dict(default=''),
            mode=dict(default=None),
            codename=dict(default=None),
        ),
        supports_check_mode=True
    )

    # Create a fake sources.list file
    test_file = StringIO()


# Generated at 2022-06-17 04:10:45.629712
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    assert sources_list.files['/etc/apt/sources.list']


# Generated at 2022-06-17 04:10:55.862443
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = False
    module.params['src'] = 'ppa:ansible/ansible'
    module.params['comment'] = '# Ansible PPA'

    sl = UbuntuSourcesList(module)
    sl.add_source(module.params['src'], module.params['comment'], module.params['filename'])
    sl.save()

    assert os.path.isfile(module.params['filename'])

# Generated at 2022-06-17 04:11:08.153371
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:11:15.821671
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:11:28.429407
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(self)

# Generated at 2022-06-17 04:11:30.269713
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:11:31.454130
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:11:40.602484
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    dump = sources.dump()

# Generated at 2022-06-17 04:11:51.276150
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.files['/etc/apt/sources.list'] == [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/test.list')
    assert sources.files['/etc/apt/sources.list.d/test.list'] == [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]

# Generated at 2022-06-17 04:11:54.579952
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Test with None
    obj = UbuntuSourcesList(None)
    obj.__deepcopy__()

    # Test with a value
    obj = UbuntuSourcesList(None)
    obj.__deepcopy__(None)

