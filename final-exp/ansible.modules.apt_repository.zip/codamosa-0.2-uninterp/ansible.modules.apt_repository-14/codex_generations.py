

# Generated at 2022-06-17 04:03:04.456649
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename
    assert sources_list.add_ppa_signing_keys_callback is None


# Generated at 2022-06-17 04:03:12.846071
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:03:23.161475
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.sources_list import SourcesList
    from ansible.module_utils.apt.sources_list import InvalidSource
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.apt.sources_list import get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.sources_list import revert_sources_list
    import os
    import copy
    import random
    import time
    import apt
    import aptsources_distro
    import distro
    import sys
    import json
    import sys
    import os
    import time
    import random
    import copy
    import apt
    import aptsources_distro

# Generated at 2022-06-17 04:03:28.202499
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:03:31.058575
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-17 04:03:35.626505
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:03:37.886189
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:03:42.860497
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert len(sl.files[sl.default_file]) == 0



# Generated at 2022-06-17 04:03:53.527431
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.files = {'test': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '# comment')]}
    sl.modify('test', 0, comment='new comment')
    assert sl.files == {'test': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'new comment')]}
    sl.modify('test', 0, source='deb http://archive.canonical.com/ubuntu hardy partner')
    assert sl.files == {'test': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'new comment')]}
    sl.modify('test', 0, enabled=False)

# Generated at 2022-06-17 04:04:04.231705
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:04:40.822015
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:04:51.986122
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-17 04:04:58.442060
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:10.632553
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    sources.load('/etc/apt/sources.list.d/google-chrome.list')
    sources.load('/etc/apt/sources.list.d/nginx-ubuntu-stable-trusty.list')
    sources.load('/etc/apt/sources.list.d/nginx-ubuntu-stable-xenial.list')
    sources.load('/etc/apt/sources.list.d/nginx-ubuntu-stable-yakkety.list')
    sources.load('/etc/apt/sources.list.d/nginx-ubuntu-stable-zesty.list')

# Generated at 2022-06-17 04:05:20.297994
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')

# Generated at 2022-06-17 04:05:33.568904
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:40.503406
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('test_sources.list')
    sources.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.save()
    assert os.path.isfile('test_sources.list')
    assert os.path.getsize('test_sources.list') == 0
    os.remove('test_sources.list')


# Generated at 2022-06-17 04:05:45.198716
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:05:48.622579
# Unit test for function install_python_apt
def test_install_python_apt():
    import apt
    import apt_pkg
    import aptsources.distro as aptsources_distro

    distro = aptsources_distro.get_distro()

    HAVE_PYTHON_APT = True


# Generated at 2022-06-17 04:05:57.729307
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-17 04:07:11.583712
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    assert len(sources.files) == 1
    assert len(sources.files[sources.default_file]) == 2
    assert sources.files[sources.default_file][0][3] == 'deb http://archive.ubuntu.com/ubuntu trusty main'
    assert sources.files[sources.default_file][1][3] == 'deb http://archive.ubuntu.com/ubuntu trusty main'
    assert sources.files[sources.default_file][0][2] is True

# Generated at 2022-06-17 04:07:20.368096
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:07:24.347948
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    sl.add_source('deb http://example.com/ubuntu xenial main')
    sl_copy = copy.deepcopy(sl)
    assert sl_copy.files == sl.files
    assert sl_copy.codename == sl.codename
    assert sl_copy.add_ppa_signing_keys_callback == sl.add_ppa_signing_keys_callback



# Generated at 2022-06-17 04:07:34.944357
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(self)

# Generated at 2022-06-17 04:07:47.014784
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', file='test.list')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', file='test.list')

# Generated at 2022-06-17 04:07:57.179793
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main', comment='test comment')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-updates main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-security main')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-security universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty multiverse')

# Generated at 2022-06-17 04:08:02.118888
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/sources.list')
    for file, n, enabled, source, comment in sources:
        assert file == '/tmp/sources.list'
        assert n == 0
        assert enabled
        assert source == 'deb http://archive.canonical.com/ubuntu hardy partner'
        assert comment == ''

# Generated at 2022-06-17 04:08:11.365559
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:08:18.412869
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/tmp/test_sources.list')
    dumpstruct = sl.dump()
    assert dumpstruct['/tmp/test_sources.list'] == 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\n'


# Generated at 2022-06-17 04:08:29.314455
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load(os.path.join(os.path.dirname(__file__), 'sources.list'))