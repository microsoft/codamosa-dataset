

# Generated at 2022-06-17 04:03:12.549932
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.fail_json = MagicMock()
    module.atomic_move = MagicMock()
    module.set_mode_if_different = MagicMock()
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}
    module.params = {'codename': 'xenial'}

# Generated at 2022-06-17 04:03:24.001719
# Unit test for function main

# Generated at 2022-06-17 04:03:35.031216
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/tmp/test_SourcesList___iter__')

# Generated at 2022-06-17 04:03:39.840597
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:03:48.385767
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='test_file')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='test_file')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='test_file')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='test_file')

# Generated at 2022-06-17 04:03:53.796390
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:04:04.422037
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = UbuntuSourcesList(module)
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    sources

# Generated at 2022-06-17 04:04:06.298615
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/apt-get'
    module.run_command = lambda x: (0, '', '')
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:04:18.814302
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import shutil
    import os
    import json
    import sys
    import apt_pkg
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.six.moves.urllib.parse import urlencode
    from ansible.module_utils.six.moves.urllib.error import URLError
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils.urls import ConnectionError
    from ansible.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule
   

# Generated at 2022-06-17 04:04:27.552108
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(None)

# Generated at 2022-06-17 04:05:12.438820
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test.list')
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test2.list')

# Generated at 2022-06-17 04:05:20.888794
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-", dir='/etc/apt')
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu trusty main\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu trusty main\n')
    f.write('deb http://archive.ubuntu.com/ubuntu trusty-updates main\n')

# Generated at 2022-06-17 04:05:26.241678
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert sources.files['/etc/apt/sources.list'] == []


# Generated at 2022-06-17 04:05:33.375568
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:05:44.876550
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('test_data/sources.list')
    dumpstruct = sl.dump()

# Generated at 2022-06-17 04:05:51.248329
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:06:03.052380
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Test that the function works as expected
    # Create a temporary directory to work in
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file to work with
    fd, tmpfile = tempfile.mkstemp(dir=tmpdir)
    os.close(fd)
    # Create a SourcesList object for the temporary file
    sourceslist_before = SourcesList(tmpfile)
    # Create a SourcesList object for the temporary directory
    sourceslist_after = SourcesList(tmpdir)
    # Add a source to the temporary file
    sourceslist_after.add_source('deb http://example.com/ubuntu/ xenial main')
    # Save the temporary file
    sourceslist_after.save()
    # Revert the temporary file to its previous state

# Generated at 2022-06-17 04:06:11.062469
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list

# Generated at 2022-06-17 04:06:21.428537
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:06:27.390000
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/test_sources.list')

# Generated at 2022-06-17 04:09:19.285868
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')

# Generated at 2022-06-17 04:09:21.305532
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:09:27.940810
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'trusty'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['source'] = 'ppa:ansible/ansible'

    sl = UbuntuSourcesList(module)
    sl.add_source(module.params['source'])
    sl.save()

    assert os.path.exists(module.params['filename'])
    assert os.path.getsize(module.params['filename']) > 0
    assert os.path.isfile(module.params['filename'])
    assert os.access

# Generated at 2022-06-17 04:09:37.920952
# Unit test for function main

# Generated at 2022-06-17 04:09:40.899313
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:09:47.781654
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:ansible/ansible')
    assert sl.files['/etc/apt/sources.list.d/ansible_ansible_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]
    sl.add_source('ppa:ansible/ansible')
    assert sl.files['/etc/apt/sources.list.d/ansible_ansible_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]

# Generated at 2022-06-17 04:09:53.765007
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:09:56.977792
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:10:05.593221
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create the default sources.list file
    default_file = os.path.join(tmpdir, 'sources.list')
    open(default_file, 'a').close()
    # Create the default sources.list.d directory
    default_dir = os.path.join(tmpdir, 'sources.list.d')
    os.mkdir(default_dir)
    # Create the default sources.list.d/default.list file
    default_list_file = os.path.join(default_dir, 'default.list')
    open(default_list_file, 'a').close()
    # Create the default sources.list.d/default.list.save file

# Generated at 2022-06-17 04:10:11.333032
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')

