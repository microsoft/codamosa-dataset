

# Generated at 2022-06-17 04:03:08.076119
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:03:19.910799
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    import stat
    import sys

    def _get_temp_dir():
        return tempfile.mkdtemp(prefix='ansible-test-apt-repository-')

    def _get_temp_file(dir):
        return tempfile.mkstemp(prefix='ansible-test-apt-repository-', dir=dir)

    def _get_temp_file_name(dir):
        fd, name = _get_temp_file(dir)
        os.close(fd)
        return name

    def _get_temp_file_content(dir):
        fd, name = _get_temp_file(dir)
        os.close(fd)
        return name, open(name, 'r').read()


# Generated at 2022-06-17 04:03:30.329261
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/tmp/test_SourcesList___iter__')

# Generated at 2022-06-17 04:03:39.789839
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt import UbuntuSourcesList
    from ansible.module_utils.apt import distro
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.urls import fetch_url

    module = AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.fail_json = lambda **kwargs: None
    module.atomic_move = lambda *args, **kwargs: None
    module.set_mode_if_different = lambda *args, **kwargs: None
    module.params = {'codename': 'xenial'}
    distro.codename = 'xenial'


# Generated at 2022-06-17 04:03:45.930016
# Unit test for function main

# Generated at 2022-06-17 04:03:52.504989
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates multiverse')

# Generated at 2022-06-17 04:03:56.941709
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load(sources_list.default_file)
    assert sources_list.files[sources_list.default_file]


# Generated at 2022-06-17 04:04:08.773972
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:04:17.699135
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockAddPpaSigningKeysCallback(object):
        def __init__(self):
            pass

    module = MockModule()
    add_ppa_signing_keys_callback = MockAddPpaSigningKeysCallback()
    ubuntu_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    ubuntu_sources_list_copy = copy.deepcopy(ubuntu_sources_list)
    assert ubuntu_sources_list.module == ubuntu_sources_list_copy.module
    assert ubuntu_sources_list.add_ppa_signing_keys_callback == ubuntu_sources_list_copy.add_ppa_signing_keys_callback
    assert ub

# Generated at 2022-06-17 04:04:27.456219
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:05:08.334536
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Test with no args
    try:
        UbuntuSourcesList.__deepcopy__()
    except TypeError as err:
        assert 'missing 1 required positional argument' in str(err)
    # Test with one arg
    try:
        UbuntuSourcesList.__deepcopy__(UbuntuSourcesList)
    except TypeError as err:
        assert 'missing 1 required positional argument' in str(err)
    # Test with two args
    try:
        UbuntuSourcesList.__deepcopy__(UbuntuSourcesList, UbuntuSourcesList)
    except TypeError as err:
        assert 'missing 1 required positional argument' in str(err)
    # Test with three args

# Generated at 2022-06-17 04:05:18.006123
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = shutil.move
            self.set_mode_if_different = lambda *args, **kwargs: None

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return 0, '', ''

    class FakeAptPkg(object):
        class Config(object):
            @staticmethod
            def FindFile(filespec):
                return os.path.join(tmpdir, 'apt', filespec)


# Generated at 2022-06-17 04:05:24.811185
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda *args, **kwargs: sys.exit(1)
            self.run_command = lambda *args, **kwargs: (0, '', '')
            self.atomic_move = lambda *args, **kwargs: None
            self.set_mode_if_different = lambda *args, **kwargs: None

    module = Module()
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:05:31.889952
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import shutil
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'codename': 'trusty',
            }
            self.fail_json = lambda *args, **kwargs: None
            self.atomic_move = lambda *args, **kwargs: None
            self.set_mode_if_different = lambda *args, **kwargs: None
            self.run_command = lambda *args, **kwargs: None

    class FakeDistro(object):
        def __init__(self):
            self.codename = 'trusty'

    class FakeFetchUrl(object):
        def __init__(self):
            self.response = FakeResponse()

        def __call__(self, *args, **kwargs):
            return self

# Generated at 2022-06-17 04:05:43.179046
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('tests/apt_repository_test_data/sources.list')

# Generated at 2022-06-17 04:05:47.855226
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename
    assert sources_list.add_ppa_signing_keys_callback is None


# Generated at 2022-06-17 04:05:55.494436
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 1
    assert sl.files['/etc/apt/sources.list'][0][1] == True
    assert sl.files['/etc/apt/sources.list'][0][2] == True
    assert sl.files['/etc/apt/sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted'
    assert sl.files['/etc/apt/sources.list'][0][4] == ''


# Generated at 2022-06-17 04:06:07.830082
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    module.check_mode = True
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs
    module.run_command = lambda **kwargs: (0, '', '')
    module.atomic_move = lambda **kwargs: None
    module.set_mode_if_different = lambda **kwargs: None
    module.fail_json = lambda **kwargs: kwargs
    module.params = {'codename': 'xenial'}
    module.check_mode = True
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs
    module

# Generated at 2022-06-17 04:06:18.953846
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test2.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test3.list')

# Generated at 2022-06-17 04:06:24.328929
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/data/sources.list')

# Generated at 2022-06-17 04:07:46.980366
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:07:51.028118
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/sources.list')
    dumpstruct = sources.dump()
    assert dumpstruct == {'/tmp/sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}


# Generated at 2022-06-17 04:07:57.594166
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None



# Generated at 2022-06-17 04:07:59.816328
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:08:09.927972
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/apt_repository/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/apt_repository/sources.list.d/google-chrome.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/apt_repository/sources.list.d/nginx.list')

# Generated at 2022-06-17 04:08:20.844687
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': 'deb http://example.com/debian jessie main\ndeb-src http://example.com/debian jessie main\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://example.com/debian jessie main\ndeb-src http://example.com/debian jessie main\n',
                     '/etc/apt/sources.list.d/example.list': 'deb http://example.com/debian jessie main\ndeb-src http://example.com/debian jessie main\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = sources_before

# Generated at 2022-06-17 04:08:27.607369
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={
        'codename': {'type': 'str', 'default': 'xenial'},
    })
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == 'xenial'


# Generated at 2022-06-17 04:08:30.932928
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:08:42.168077
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:08:50.137868
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    assert sources_list.default_file == '/etc/apt/sources.list'
    assert sources_list.files == {}

    # Test loading of sources.list
    sources_list.load('/etc/apt/sources.list')