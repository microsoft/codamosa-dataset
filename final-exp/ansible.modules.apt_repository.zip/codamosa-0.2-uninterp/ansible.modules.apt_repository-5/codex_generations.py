

# Generated at 2022-06-17 04:03:09.216621
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import os.path
    import stat
    import filecmp

    def _create_sources_list(sources):
        fd, tmp_path = tempfile.mkstemp(prefix="sources.list-", dir=d)
        f = os.fdopen(fd, 'w')
        for source in sources:
            f.write(source + '\n')
        f.close()
        return tmp_path

    def _create_sources_list_d(sources):
        fd, tmp_path = tempfile.mkstemp(prefix="sources.list.d-", dir=d)
        f = os.fdopen(fd, 'w')
        for source in sources:
            f.write(source + '\n')
        f.close

# Generated at 2022-06-17 04:03:18.123193
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        '/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu trusty main universe\n',
        '/etc/apt/sources.list.d/ansible-test.list': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main\n',
    }

# Generated at 2022-06-17 04:03:29.522609
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/apt_repository/sources.list')

# Generated at 2022-06-17 04:03:33.026758
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None


# Generated at 2022-06-17 04:03:39.967230
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    assert sources.files[sources.default_file][0][3] == 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted'


# Generated at 2022-06-17 04:03:48.486261
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Test 1
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:04:01.077355
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sources_list = UbuntuSourcesList(module)

    sources_list.add_source('ppa:foo/bar')
    assert sources_list.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]

    sources_list.add_source('ppa:foo/bar')
    assert sources_list.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]

    sources_

# Generated at 2022-06-17 04:04:12.974916
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:04:18.052327
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:04:22.099932
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': 'deb http://example.com/debian wheezy main\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://example.com/debian wheezy main\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = sources_before
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.files == sources_after



# Generated at 2022-06-17 04:05:00.814987
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create sources.list and sources.list.d
    os.makedirs('/etc/apt/sources.list.d')
    with open('/etc/apt/sources.list', 'w') as f:
        f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
        f.write('# deb-src http://archive.canonical.com/ubuntu hardy partner\n')

# Generated at 2022-06-17 04:05:03.910955
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:05:15.663160
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')

# Generated at 2022-06-17 04:05:23.271379
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/tmp/sources.list')
    sl.modify('/tmp/sources.list', 0, enabled=False)
    assert sl.files['/tmp/sources.list'][0][2] == False
    sl.modify('/tmp/sources.list', 0, source='deb http://example.com/ubuntu trusty main')
    assert sl.files['/tmp/sources.list'][0][3] == 'deb http://example.com/ubuntu trusty main'
    sl.modify('/tmp/sources.list', 0, comment='comment')
    assert sl.files['/tmp/sources.list'][0][4] == 'comment'

# Generated at 2022-06-17 04:05:26.787486
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    sl.save()


# Generated at 2022-06-17 04:05:30.005776
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}
    assert list(sources) == []


# Generated at 2022-06-17 04:05:33.351257
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:05:44.877174
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/apt_repository/sources.list')
    sources.modify('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/apt_repository/sources.list', 0, enabled=False)
    sources.modify('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/apt_repository/sources.list', 1, source='deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:05:54.742714
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list')
    assert len(list(sources_list)) == 4
    assert list(sources_list)[0] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted', '')
    assert list(sources_list)[1] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 1, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted', '')

# Generated at 2022-06-17 04:06:06.835168
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert '/etc/apt/sources.list' in sources.files
    assert len(sources.files['/etc/apt/sources.list']) == 3
    assert sources.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert sources.files['/etc/apt/sources.list'][1] == (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')

# Generated at 2022-06-17 04:07:31.192341
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    sources = UbuntuSourcesList(module)
    sources.add_source('ppa:ansible/ansible')
    assert sources.files['/etc/apt/sources.list.d/test.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]


# Generated at 2022-06-17 04:07:38.468262
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.files = {
        'file1': [
            (0, True, True, 'source1', 'comment1'),
            (1, True, True, 'source2', 'comment2'),
            (2, True, True, 'source3', 'comment3'),
        ],
        'file2': [
            (0, True, True, 'source4', 'comment4'),
            (1, True, True, 'source5', 'comment5'),
            (2, True, True, 'source6', 'comment6'),
        ],
    }
    sources.modify('file1', 1, enabled=False, source='source7', comment='comment7')
    sources.modify('file2', 2, enabled=True, source=None, comment=None)

# Generated at 2022-06-17 04:07:47.444149
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sources_list = SourcesList(None)

# Generated at 2022-06-17 04:07:57.621942
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sources_list_file = os.path.join(self.tempdir, 'sources.list')
            self.sources_list_d_dir = os.path.join(self.tempdir, 'sources.list.d')
            self.sources_list_d_file = os.path.join(self.sources_list_d_dir, 'test.list')
            self.sources_list_d_file_2 = os.path.join(self.sources_list_d_dir, 'test2.list')
            self.sources_list_d_

# Generated at 2022-06-17 04:08:08.931270
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n',
                     '/etc/apt/sources.list.d/test.list': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n'}
    sourceslist_before = UbuntuSourcesList(module)
    sourceslist_before.load('/etc/apt/sources.list')
    sourceslist_before.load('/etc/apt/sources.list.d/test.list')

# Generated at 2022-06-17 04:08:14.812493
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources = UbuntuSourcesList(module)
    assert sources.codename == 'xenial'


# Generated at 2022-06-17 04:08:23.336184
# Unit test for function main

# Generated at 2022-06-17 04:08:35.537309
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty main restricted universe multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-updates main restricted universe multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-security main restricted universe multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-backports main restricted universe multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-proposed main restricted universe multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu trusty-updates main restricted universe multiverse')

# Generated at 2022-06-17 04:08:44.649574
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert len(sources.files) == 1
    assert sources.files[sources.default_file] == []
    assert len(list(sources)) == 0
    assert sources._apt_cfg_file('Dir::Etc::sourcelist') == '/etc/apt/sources.list'
    assert sources._apt_cfg_dir('Dir::Etc::sourceparts') == '/etc/apt/sources.list.d'
    assert sources._expand_path('/etc/apt/sources.list') == '/etc/apt/sources.list'

# Generated at 2022-06-17 04:08:54.868116
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')