

# Generated at 2022-06-17 04:03:01.001562
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import subprocess
    import json
    import apt
    import aptsources.distro
    import aptsources.sourceslist
    import aptsources.distinfo
    import aptsources.sourceslist
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distro
    import aptsources.distinfo
    import apts

# Generated at 2022-06-17 04:03:09.577721
# Unit test for function main

# Generated at 2022-06-17 04:03:20.705434
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['comment'] = ''
    module.params['file'] = None
    module.params['line'] = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    module.params['repo'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['comment'] = ''

# Generated at 2022-06-17 04:03:26.361244
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:36.643009
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:03:43.895406
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:03:51.108212
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:03:59.335061
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    assert sources_list.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]
    sources_list.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo_bar_xenial.list')

# Generated at 2022-06-17 04:04:11.729937
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import os
    import shutil
    import stat
    import sys

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = os.path.join(tmpdir, 'test.list')
    # Create temporary file
    tmpfile2 = os.path.join(tmpdir, 'test2.list')
    # Create temporary file
    tmpfile3 = os.path.join(tmpdir, 'test3.list')
    # Create temporary file
    tmpfile4 = os.path.join(tmpdir, 'test4.list')
    # Create temporary file
    tmpfile5 = os.path.join(tmpdir, 'test5.list')
    # Create temporary file
    tmpfile6 = os.path.join(tmpdir, 'test6.list')

# Generated at 2022-06-17 04:04:21.888046
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test2.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test3.list')

# Generated at 2022-06-17 04:05:00.312050
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:06.000662
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.params['codename'] = 'xenial'
    module = MockModule()
    add_ppa_signing_keys_callback = None
    obj = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    obj.codename = 'xenial'
    obj.module = module
    obj.add_ppa_signing_keys_callback = None
    obj.files = {}
    obj.new_repos = set()
    obj.default_file = '/etc/apt/sources.list'
    obj.LP_API = 'https://launchpad.net/api/1.0/~%s/+archive/%s'
    obj.__deepcopy__()


# Generated at 2022-06-17 04:05:19.693154
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('tests/data/sources.list')

# Generated at 2022-06-17 04:05:25.898073
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.sources_list import SourcesList
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.apt.sources_list import InvalidSource
    from ansible.module_utils.apt.sources_list import InvalidKeyError
    from ansible.module_utils.apt.sources_list import get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.sources_list import revert_sources_list
    from ansible.module_utils.apt.sources_list import main
    from ansible.module_utils.apt.sources_list import probe_interpreters_for_module

# Generated at 2022-06-17 04:05:28.440051
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None

    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-17 04:05:37.025398
# Unit test for function main

# Generated at 2022-06-17 04:05:46.647139
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {'/etc/apt/sources.list': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main',
                      '/etc/apt/sources.list.d/ansible-ansible-trusty.list': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'}

# Generated at 2022-06-17 04:05:54.135882
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'codename'}
    add_ppa_signing_keys_callback = 'add_ppa_signing_keys_callback'
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    usl_copy = copy.deepcopy(usl)
    assert usl_copy.module == usl.module
    assert usl_copy.add_ppa_signing_keys_callback == usl.add_ppa_signing_keys_callback
    assert usl_copy.codename == usl.codename

# Generated at 2022-06-17 04:06:03.500210
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test2.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list.d/test3.list')

# Generated at 2022-06-17 04:06:05.836116
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:07:23.003200
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list')
    assert len(list(sources_list)) == 2
    assert list(sources_list)[0] == ('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted', '')

# Generated at 2022-06-17 04:07:30.628834
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:07:38.150274
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list'''
    # Create a temporary directory to work in:
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file to work with:
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.write(b'# This is a comment\n')
    tmpfile.write(b'deb http://example.com/ubuntu trusty main\n')
    tmpfile.write(b'deb http://example.com/ubuntu trusty-updates main\n')
    tmpfile.write(b'deb http://example.com/ubuntu trusty-security main\n')
    tmpfile.close()
    # Create a module to work with:
    module = AnsibleModule({'filename': tmpfile.name})
    # Create a Sources

# Generated at 2022-06-17 04:07:47.365206
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create test sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-", dir='/etc/apt')
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\n')

# Generated at 2022-06-17 04:07:57.288320
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': '# test\n'}
    sources_after = {'/etc/apt/sources.list': '# test\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = {'/etc/apt/sources.list': [('# test\n', True, True, '# test\n', '')]}
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.files == {'/etc/apt/sources.list': [('# test\n', True, True, '# test\n', '')]}


# Generated at 2022-06-17 04:08:02.259830
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:08:11.479774
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}
    assert list(sources) == []

    # Create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-")
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\n')

# Generated at 2022-06-17 04:08:22.120377
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:08:28.852076
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-17 04:08:40.493933
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    dump = sources.dump()