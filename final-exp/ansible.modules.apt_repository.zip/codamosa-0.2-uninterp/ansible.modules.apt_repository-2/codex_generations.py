

# Generated at 2022-06-17 04:03:09.728280
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(self.tmpdir)

        def tearDown(self):
            shutil.rmtree(self.tmpdir)

        def test_save(self):
            self.sourceslist.add_source('deb http://example.com/debian wheezy main')
            self.sourceslist.save()
            self.assertTrue(os.path.exists(os.path.join(self.tmpdir, 'sources.list')))

    unittest.main()



# Generated at 2022-06-17 04:03:20.751774
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources_list.dump() == {'/etc/apt/sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical.list')

# Generated at 2022-06-17 04:03:28.913658
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert sources.files['/etc/apt/sources.list']
    assert sources.files['/etc/apt/sources.list'][0][1]
    assert sources.files['/etc/apt/sources.list'][0][2]
    assert sources.files['/etc/apt/sources.list'][0][3]
    assert sources.files['/etc/apt/sources.list'][0][4]


# Generated at 2022-06-17 04:03:38.780840
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:03:49.735481
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list')
    assert len(list(sources_list)) == 4
    assert list(sources_list)[0] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert list(sources_list)[1] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 1, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')
   

# Generated at 2022-06-17 04:04:01.550420
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates multiverse')

# Generated at 2022-06-17 04:04:05.122462
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:04:15.283262
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/google-chrome.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/nginx-stable.list')

# Generated at 2022-06-17 04:04:19.235088
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/sources.list')
    for file, n, enabled, source, comment in sources:
        assert file == '/tmp/sources.list'
        assert n == 0
        assert enabled
        assert source == 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted'
        assert comment == ''

# Generated at 2022-06-17 04:04:24.971195
# Unit test for function main

# Generated at 2022-06-17 04:05:33.709460
# Unit test for function main

# Generated at 2022-06-17 04:05:44.907454
# Unit test for function main

# Generated at 2022-06-17 04:05:54.888722
# Unit test for function main

# Generated at 2022-06-17 04:06:01.492072
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:06:07.974632
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    add_ppa_signing_keys_callback = lambda x: None
    ubuntu_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    ubuntu_sources_list.files = {'file1': [], 'file2': []}
    ubuntu_sources_list_copy = copy.deepcopy(ubuntu_sources_list)
    assert ubuntu_sources_list_copy.files == ubuntu_sources_list.files
    assert ubuntu_sources_list_copy.module == ubuntu_sources_list.module
    assert ubuntu_sources_list_copy.codename == ubuntu_sources_list.codename

# Generated at 2022-06-17 04:06:19.138100
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('tests/test_apt_repository/sources.list')
    sources_list.load('tests/test_apt_repository/sources.list.d/test.list')
    sources_list.load('tests/test_apt_repository/sources.list.d/test2.list')
    sources_list.load('tests/test_apt_repository/sources.list.d/test3.list')
    sources_list.load('tests/test_apt_repository/sources.list.d/test4.list')
    sources_list.load('tests/test_apt_repository/sources.list.d/test5.list')

# Generated at 2022-06-17 04:06:24.457797
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create sources.list with one valid source
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-")
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse\n')
    f.close()

    sources = SourcesList(module)
    assert sources.files == {tmp_path: [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse', '')]}

    # Create sources.list with one valid source and one invalid source
    fd, tmp

# Generated at 2022-06-17 04:06:29.855432
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(None)

# Generated at 2022-06-17 04:06:35.124199
# Unit test for function main

# Generated at 2022-06-17 04:06:39.281117
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/new.list': 'deb http://example.com/ubuntu trusty main\n',
    }
    sources_after = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/new.list': 'deb http://example.com/ubuntu trusty main\n',
        '/etc/apt/sources.list.d/new2.list': 'deb http://example.com/ubuntu trusty main\n',
    }
    sourceslist_before = SourcesList(None)
    sourceslist_before.files = sources_before
   

# Generated at 2022-06-17 04:08:00.508272
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    ubuntu_sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    ubuntu_sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    ubuntu_sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')

# Generated at 2022-06-17 04:08:10.444237
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    dumpstruct = sources.dump()
    assert '/etc/apt/sources.list' in dumpstruct
    assert 'deb' in dumpstruct['/etc/apt/sources.list']
    assert 'deb-src' in dumpstruct['/etc/apt/sources.list']
    assert '#' in dumpstruct['/etc/apt/sources.list']
    assert '# deb-src' in dumpstruct['/etc/apt/sources.list']
    assert '# deb' in dumpstruct['/etc/apt/sources.list']
    assert '# deb-src' in dumpstruct['/etc/apt/sources.list']

# Generated at 2022-06-17 04:08:21.722228
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:08:27.011568
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-17 04:08:36.996002
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list')
    assert len(list(sources_list)) == 4
    assert list(sources_list)[0] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert list(sources_list)[1] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 1, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')

# Generated at 2022-06-17 04:08:40.506268
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:08:51.231976
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''
    Test revert_sources_list function.
    '''
    import tempfile
    import shutil
    import os

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a sources.list file
    sources_list_file = os.path.join(tmpdir, 'sources.list')
    with open(sources_list_file, 'w') as f:
        f.write('deb http://example.com/debian jessie main\n')
        f.write('deb http://example.com/debian jessie-updates main\n')
        f.write('deb http://example.com/debian jessie-backports main\n')
        f.write('deb http://example.com/debian jessie-security main\n')

    # Create a sources

# Generated at 2022-06-17 04:08:58.412813
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import tempfile
    import shutil
    import filecmp
    import glob
    import sys
    import random
    import time
    import string
    import re

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    fd, tmp_path = tempfile.mkstemp(dir=tmpdir)
    # Create temporary file
    fd, tmp_path2 = tempfile.mkstemp(dir=tmpdir)
    # Create temporary file
    fd, tmp_path3 = tempfile.mkstemp(dir=tmpdir)
    # Create temporary file
    fd, tmp_path4 = tempfile.mkstemp(dir=tmpdir)
    # Create temporary file
    fd, tmp_path5 = tempfile.mkstemp(dir=tmpdir)

# Generated at 2022-06-17 04:09:07.828673
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:09:13.461286
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)