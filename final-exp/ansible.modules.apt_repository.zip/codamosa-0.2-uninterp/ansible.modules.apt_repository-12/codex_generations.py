

# Generated at 2022-06-17 04:03:07.845281
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/google-chrome.list')
    sources_list.load('tests/unit/modules/ansible_collections/ansible/builtin/tests/unit/modules/files/apt_repository/sources.list.d/nginx-stable.list')

# Generated at 2022-06-17 04:03:19.402693
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) > 0
    assert sources.files['/etc/apt/sources.list'][0][1] == True
    assert sources.files['/etc/apt/sources.list'][0][2] == True
    assert sources.files['/etc/apt/sources.list'][0][3].startswith('deb')
    assert sources.files['/etc/apt/sources.list'][0][4] == ''


# Generated at 2022-06-17 04:03:30.208255
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:03:39.683481
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'trusty'}
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    assert sources_list.repos_urls == ['deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main']
    sources_list.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main')
    assert sources_list.repos_urls == ['deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main']
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-17 04:03:48.247636
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical.list')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', file='/etc/apt/sources.list.d/canonical.list')

# Generated at 2022-06-17 04:03:54.621167
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}



# Generated at 2022-06-17 04:04:06.963745
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import apt
    import apt_pkg
    import aptsources.distro
    import aptsources.sourceslist
    import aptsources.distinfo
    import aptsources.distinfo.ubuntu
    import aptsources.distinfo.debian
    import aptsources.distinfo.lsb
    import aptsources.distinfo.lsb_release
    import aptsources.distinfo.os_release
    import aptsources.distinfo.lsb_release_file
    import aptsources.distinfo.os_release_file
    import aptsources.distinfo.codename_map
    import aptsources.distinfo.codename_map_file
    import aptsources.distinfo.codename_map_ubuntu
   

# Generated at 2022-06-17 04:04:18.016689
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    assert len(sources_list.files) == 1
    assert '/etc/apt/sources.list' in sources_list.files
    assert len(sources_list.files['/etc/apt/sources.list']) == 1
    assert sources_list.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu xenial main restricted', '')


# Generated at 2022-06-17 04:04:23.960278
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-17 04:04:29.630785
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves.urllib.error import HTTPError

    class MockModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(MockModule, self).__init__(*args, **kwargs)
            self.params = {}

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            self.exit_code = 1

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs


# Generated at 2022-06-17 04:05:12.348698
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    assert sl.files['/etc/apt/sources.list.d/test.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]
    sl.add_source('ppa:foo/bar', file='test2.list')
    assert sl.files['/etc/apt/sources.list.d/test2.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]
    sl.add_

# Generated at 2022-06-17 04:05:17.880931
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:05:22.370542
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')



# Generated at 2022-06-17 04:05:33.891210
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)

    sources_list.add_source('ppa:foo/bar')
    assert sources_list.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]

    sources_list.add_source('ppa:foo/bar')
    assert sources_list.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]


# Generated at 2022-06-17 04:05:44.907847
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:05:50.811932
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import json
    import pytest
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import PY3
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.apt.sources_list import SourcesList, UbuntuSourcesList, InvalidSource, get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.sources_list import probe_interpreters_for_module, respawn_module, has_respawned
    from ansible.module_utils.apt.sources_list import install_python_apt, aptsources_distro

# Generated at 2022-06-17 04:05:59.267680
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'filename': 'test.list'}
    sources = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:06:06.450833
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil
    import subprocess
    import json
    import pytest
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves import reload_module
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves import range
    from ansible.module_utils.six.moves import urllib
    from ansible.module_utils.six.moves import xmlrpc_client
    from ansible.module_utils.six.moves import http_client
    from ansible.module_utils.six.moves import http_cookiejar

# Generated at 2022-06-17 04:06:18.670841
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list'''
    import tempfile
    import shutil
    import os
    import sys
    import filecmp
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt import SourcesList

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a sources.list file
    sources_list_file = os.path.join(tmpdir, 'sources.list')
    with open(sources_list_file, 'w') as f:
        f.write('deb http://archive.ubuntu.com/ubuntu xenial main universe\n')
        f.write('deb http://archive.ubuntu.com/ubuntu xenial-updates main universe\n')

# Generated at 2022-06-17 04:06:22.741851
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    module.check_mode = True

    sl = UbuntuSourcesList(module)
    sl_copy = copy.deepcopy(sl)
    assert sl_copy.codename == 'xenial'
    assert sl_copy.module == module
    assert sl_copy.add_ppa_signing_keys_callback is None



# Generated at 2022-06-17 04:07:34.498153
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:07:38.009708
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:ansible/ansible')
    assert sources_list.files['/etc/apt/sources.list.d/test.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main', '')]


# Generated at 2022-06-17 04:07:40.693531
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:07:46.581988
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:07:56.667275
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list')
    assert len(list(sources)) == 3
    assert list(sources)[0] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 0, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted', '')
    assert list(sources)[1] == ('tests/unit/modules/ansible_collections/ansible/builtin/files/sources.list', 1, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted', '')

# Generated at 2022-06-17 04:08:07.479786
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:08:20.769914
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial-updates multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial-backports main restricted universe multiverse')

# Generated at 2022-06-17 04:08:31.400216
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Test with a valid source
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='Added by Ansible')
    assert sources.files == {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'Added by Ansible')]}

    # Test with an invalid source
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:08:42.169652
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty-updates multiverse')

# Generated at 2022-06-17 04:08:52.882469
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test_filename'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = False
    module.params['key_id'] = None
    module.params['key_url'] = None
    module.params['key_src'] = None
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = 'test comment'

    sl = UbuntuSourcesList(module)

    sl.add_source(module.params['repo'], module.params['comment'])

    assert sl.files

# Generated at 2022-06-17 04:10:54.788582
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:11:03.894410
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
    sl.add_source('ppa:ansible/ansible')
   

# Generated at 2022-06-17 04:11:15.168911
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:11:19.439451
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    assert sl.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]
    sl.add_source('ppa:foo/bar')
    assert sl.files['/etc/apt/sources.list.d/foo_bar_xenial.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', '')]

# Generated at 2022-06-17 04:11:25.538633
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:11:35.974017
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import os.path
    import stat

    # create temporary directory
    tmpdir = tempfile.mkdtemp()
    # create temporary file
    tmpfile = os.path.join(tmpdir, 'sources.list')
    # create temporary file
    tmpfile2 = os.path.join(tmpdir, 'sources.list.d', 'test.list')
    # create temporary file
    tmpfile3 = os.path.join(tmpdir, 'sources.list.d', 'test2.list')
    # create temporary file
    tmpfile4 = os.path.join(tmpdir, 'sources.list.d', 'test3.list')
    # create temporary file

# Generated at 2022-06-17 04:11:42.376866
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    dumpstruct = sources.dump()

# Generated at 2022-06-17 04:11:48.984081
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:12:00.717608
# Unit test for function main

# Generated at 2022-06-17 04:12:10.796634
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)