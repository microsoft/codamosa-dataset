

# Generated at 2022-06-17 04:03:14.386851
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.params = {
                'codename': 'xenial',
            }

    module = Module()

    sl = UbuntuSourcesList(module)
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
   

# Generated at 2022-06-17 04:03:23.300624
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:03:34.993330
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda msg: sys.exit(1)
            self.atomic_move = shutil.move

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return 0, '', ''

        def set_mode_if_different(self, filename, mode, changed):
            pass

    class FakeAptPkg(object):
        class Config(object):
            @staticmethod
            def FindFile(filespec):
                return os.path.join(tmpdir, 'apt', filespec)


# Generated at 2022-06-17 04:03:39.645036
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['keyserver'] = None
    module.params['keyid'] = None
    module.params['key_url'] = None
    module.params['key_src'] = None
    module.params['repo'] = None
    module.params['deb'] = None
    module.params['src'] = None
    module.params['ppa'] = None
    module.params['dist'] = None
    module.params['comps'] = None

# Generated at 2022-06-17 04:03:45.828772
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    import tempfile
    import subprocess
    import json

    # Save the current working directory
    cwd = os.getcwd()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary directory for the module
    module_dir = os.path.join(tmpdir, 'ansible_module')
    os.mkdir(module_dir)

    # Create a temporary directory for the module_utils
    module_utils_dir = os.path.join(tmpdir, 'ansible_module_utils')
    os.mkdir(module_utils_dir)

    # Create a temporary directory for the library
    library_dir = os.path.join(tmpdir, 'library')
    os.mkdir(library_dir)

    # Create

# Generated at 2022-06-17 04:03:47.390763
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:54.401409
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}
    assert list(sources) == []
    assert sources.dump() == {}



# Generated at 2022-06-17 04:04:04.662740
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'

    sl = UbuntuSourcesList(module)
    sl.add_source('deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main')
    assert sl.files[sl.default_file][0][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    assert sl.files[sl.default_file][0][4] == ''
    assert sl.files[sl.default_file][0][2] == True
    assert sl.files[sl.default_file][0][1] == True
    assert sl

# Generated at 2022-06-17 04:04:08.650203
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')


# Generated at 2022-06-17 04:04:16.465248
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:05:00.348393
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:05:06.022110
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:05:19.694572
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.sources_list = SourcesList(None)

# Generated at 2022-06-17 04:05:25.463087
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.files = {'test': [(0, True, True, 'deb http://example.com/debian wheezy main', '')]}
    sources.modify('test', 0, source='deb http://example.com/debian jessie main')
    assert sources.files['test'] == [(0, True, True, 'deb http://example.com/debian jessie main', '')]
    sources.modify('test', 0, comment='test')
    assert sources.files['test'] == [(0, True, True, 'deb http://example.com/debian jessie main', 'test')]
    sources.modify('test', 0, enabled=False)

# Generated at 2022-06-17 04:05:36.663005
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['update_cache_valid_age'] = 3600
    module.params['validate_certs'] = True
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = '#'
    module.params['key_id'] = None
    module.params['key_url'] = None
    module.params['key_server'] = None
    module.params['key_content'] = None
    module.params['key_src'] = None

# Generated at 2022-06-17 04:05:46.496980
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:05:55.606034
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('tests/test_apt_repository/sources.list')
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sl.dump() == {'tests/test_apt_repository/sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sl.dump() == {'tests/test_apt_repository/sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:06:07.830733
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) > 0
    assert sources.files['/etc/apt/sources.list'][0][1] == True
    assert sources.files['/etc/apt/sources.list'][0][2] == True
    assert sources.files['/etc/apt/sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu xenial main restricted'
    assert sources.files['/etc/apt/sources.list'][0][4] == ''

# Generated at 2022-06-17 04:06:18.991713
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:06:24.283222
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.fail_json = MagicMock(side_effect=Exception)
    module.atomic_move = MagicMock()
    module.set_mode_if_different = MagicMock()

    sl = UbuntuSourcesList(module)
    sl.add_source('ppa:foo/bar')
    sl.add_source('deb http://example.com/ubuntu xenial main')
    sl.save()

    sl2 = copy.deepcopy(sl)
    sl2.add_source('ppa:foo/bar')
    sl2.add_source('deb http://example.com/ubuntu xenial main')
    sl2

# Generated at 2022-06-17 04:08:07.007275
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:08:20.604030
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load('tests/apt_repository/sources.list')
    dumpstruct = sourceslist.dump()

# Generated at 2022-06-17 04:08:29.472669
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    import shutil
    import os
    import stat
    import filecmp
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file
    (fd, tmpfile) = tempfile.mkstemp(dir=tmpdir)
    # Write data to the temporary file
    os.write(fd, b"# This is a comment\n")
    os.write(fd, b"deb http://example.com/ubuntu trusty main\n")
    os.write(fd, b"deb-src http://example.com/ubuntu trusty main\n")
    os.write(fd, b"deb http://example.com/ubuntu trusty-updates main\n")

# Generated at 2022-06-17 04:08:33.930464
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:08:45.565136
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert len(sources.files) == 0

    # Create test sources.list

# Generated at 2022-06-17 04:08:56.586162
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    class Module(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda msg: None
            self.atomic_move = lambda src, dest: None
            self.set_mode_if_different = lambda path, mode, changed: None

    class Distro(object):
        def __init__(self, codename):
            self.codename = codename

    class FetchUrl(object):
        def __init__(self, status, msg):
            self.status = status
            self.msg = msg

        def read(self):
            return '{}'

    class RunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err


# Generated at 2022-06-17 04:09:01.530486
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:09:08.472697
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    sources.load('/etc/apt/sources.list.d/ansible.list')
    dump = sources.dump()

# Generated at 2022-06-17 04:09:19.835613
# Unit test for function main

# Generated at 2022-06-17 04:09:26.307342
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    dumpstruct = sources_list.dump()