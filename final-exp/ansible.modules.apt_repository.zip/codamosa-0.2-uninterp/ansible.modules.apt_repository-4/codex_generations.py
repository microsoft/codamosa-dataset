

# Generated at 2022-06-17 04:03:01.730358
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu xenial main\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://archive.ubuntu.com/ubuntu xenial main\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.load('/etc/apt/sources.list')
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.dump() == sources_before


# Generated at 2022-06-17 04:03:14.090617
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['repo'] = None
    module.params['comment'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None
    module.params['update_cache'] = None

# Generated at 2022-06-17 04:03:23.269248
# Unit test for function main

# Generated at 2022-06-17 04:03:34.951392
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    sources = UbuntuSourcesList(module)
    sources.add_source('ppa:foo/bar')
    assert sources.files[sources.default_file][0][3] == 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main'
    sources.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo.list')
    assert sources.files['/etc/apt/sources.list.d/foo.list'][0][3] == 'deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main'
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    assert sources.files

# Generated at 2022-06-17 04:03:42.688835
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert len(sources.files) == 0

    # create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-", dir='/etc/apt')
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted universe multiverse\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty-security main restricted universe multiverse\n')

# Generated at 2022-06-17 04:03:53.500343
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.load('/tmp/test_sources.list')

# Generated at 2022-06-17 04:04:04.185833
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = lambda src, dst: os.rename(src, dst)

# Generated at 2022-06-17 04:04:06.445565
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:04:18.157326
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) == 2
    assert sources.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert sources.files['/etc/apt/sources.list'][1] == (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')


# Generated at 2022-06-17 04:04:19.938186
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:04:59.795106
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert len(sources.files) == 0

    # Create sources.list and sources.list.d
    os.makedirs('/etc/apt/sources.list.d')
    with open('/etc/apt/sources.list', 'w') as f:
        f.write('# comment\n')
        f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse\n')
        f.write('# comment\n')
        f.write('deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse\n')
        f.write('# comment\n')

# Generated at 2022-06-17 04:05:05.693558
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.repository import main
    from ansible.module_utils.apt.repository import SourcesList
    from ansible.module_utils.apt.repository import UbuntuSourcesList
    from ansible.module_utils.apt.repository import InvalidSource
    from ansible.module_utils.apt.repository import get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.repository import revert_sources_list
    from ansible.module_utils.apt.repository import respawn_module
    from ansible.module_utils.apt.repository import probe_interpreters_for_module
    from ansible.module_utils.apt.repository import install_python

# Generated at 2022-06-17 04:05:19.554723
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('test/sources.list')
    dump = sources.dump()

# Generated at 2022-06-17 04:05:25.844217
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/test_sources.list')
    dump = sources.dump()

# Generated at 2022-06-17 04:05:33.137789
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:05:42.477477
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    sl = UbuntuSourcesList(module)
    sl.files = {'a': 'b'}
    sl.codename = 'yakkety'
    sl.add_ppa_signing_keys_callback = 'c'
    sl_copy = copy.deepcopy(sl)
    assert sl_copy.files == {'a': 'b'}
    assert sl_copy.codename == 'yakkety'
    assert sl_copy.add_ppa_signing_keys_callback == 'c'


# Generated at 2022-06-17 04:05:50.978013
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/data/sources.list')
    assert sources.dump() == {
        'tests/data/sources.list': '''deb http://archive.ubuntu.com/ubuntu trusty main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu trusty-updates main restricted universe multiverse
deb http://archive.ubuntu.com/ubuntu trusty-backports main restricted universe multiverse
deb http://security.ubuntu.com/ubuntu trusty-security main restricted universe multiverse
'''
    }


# Generated at 2022-06-17 04:05:59.380838
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('test/sources.list')
    dumpstruct = sources_list.dump()

# Generated at 2022-06-17 04:06:06.500016
# Unit test for function main

# Generated at 2022-06-17 04:06:17.111244
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test for method add_source(self, line, comment='', file=None)
    # of class UbuntuSourcesList
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = '# added by ansible'
    module.params['distribution'] = 'xenial'
    module.params['key_id'] = '0xF1656F24C74CD1D8'
   

# Generated at 2022-06-17 04:07:53.205504
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='# comment')

# Generated at 2022-06-17 04:07:57.619667
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert sources.files['/etc/apt/sources.list']


# Generated at 2022-06-17 04:08:08.965435
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    import stat
    import sys

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    # Write data to the temporary file
    tmpfile.write(b"deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\n")
    tmpfile.write(b"# deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted\n")
    tmpfile.write(b"deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\n")
    tmpfile.write(b"# deb-src http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\n")
   

# Generated at 2022-06-17 04:08:18.949721
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:08:29.735926
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = os.rename
            self.set_mode_if_different = lambda *args, **kwargs: None

        def get_bin_path(self, *args, **kwargs):
            return '/bin/true'

        def run_command(self, *args, **kwargs):
            return 0, '', ''

    class FakeAptPkg(object):
        class Config(object):
            @staticmethod
            def FindFile(filespec):
                return '/etc/apt/sources.list'


# Generated at 2022-06-17 04:08:41.041767
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:08:43.250608
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:08:48.155863
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/test_sources.list')
    sources.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.dump() == {'/tmp/test_sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}


# Generated at 2022-06-17 04:08:55.485393
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert len(sources.files) == 0

    # create a temporary sources.list file
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-")
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.write('# deb-src http://archive.canonical.com/ubuntu hardy partner\n')
    f.write('# deb http://archive.canonical.com/ubuntu hardy partner\n')
    f.write('deb-src http://archive.canonical.com/ubuntu hardy partner\n')

# Generated at 2022-06-17 04:09:00.834243
# Unit test for function main

# Generated at 2022-06-17 04:10:00.126998
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:10:08.922154
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None
            self.atomic_move = lambda src, dst: shutil.move(src, dst)
            self.set_mode_if_different = lambda path, mode, changed: None

    class FakeAptPkg(object):
        class Config(object):
            @staticmethod
            def FindFile(filespec):
                return os.path.join(tmpdir, filespec)

            @staticmethod
            def FindDir(dirspec):
                return os.path.join(tmpdir, dirspec)

    apt_pkg = FakeAptPkg()

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-17 04:10:14.390467
# Unit test for function main

# Generated at 2022-06-17 04:10:20.699143
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 5
    assert sl.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')
    assert sl.files['/etc/apt/sources.list'][1] == (1, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted', '')

# Generated at 2022-06-17 04:10:25.049452
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-17 04:10:36.571832
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    import os.path

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False
            self.fail_json = lambda **kwargs: sys.exit(1)
            self.atomic_move = lambda src, dst: shutil.move(src, dst)
            self.set_mode_if_different = lambda path, mode, changed: None

    class FakeAptPkg(object):
        @staticmethod
        def config_find_dir(dirspec):
            return '/etc/apt/sources.list.d'

        @staticmethod
        def config_find_file(filespec):
            return '/etc/apt/sources.list'

    module = FakeModule()

# Generated at 2022-06-17 04:10:38.098853
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:10:48.634187
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'trusty'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = False
    module.params['source'] = 'ppa:ansible/ansible'
    module.params['comment'] = '# Ansible PPA'
    module.params['file'] = None
    module.params['key_id'] = None
    module.params['key_url'] = None
    module.params['key_server'] = None
    module.params['mode'] = None
    module.params['state'] = None

# Generated at 2022-06-17 04:10:58.015618
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:11:03.309363
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None
    module.check_mode = True
    assert get_add_ppa_signing_key_callback(module) is None
