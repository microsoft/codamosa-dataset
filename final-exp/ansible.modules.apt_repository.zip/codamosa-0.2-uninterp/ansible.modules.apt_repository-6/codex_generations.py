

# Generated at 2022-06-17 04:03:07.804953
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:03:14.468196
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/tmp/test.list')
    sources.save()
    assert os.path.isfile('/tmp/test.list')
    os.remove('/tmp/test.list')


# Generated at 2022-06-17 04:03:21.684682
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:03:34.207734
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:03:45.001627
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import tempfile
    import os
    import stat

    def _read_file(path):
        with open(path, 'r') as f:
            return f.read()

    def _create_file(path, content):
        with open(path, 'w') as f:
            f.write(content)

    def _create_dir(path):
        os.makedirs(path)

    def _remove_file(path):
        os.remove(path)

    def _remove_dir(path):
        shutil.rmtree(path)

    def _create_sources_list(content):
        _create_file(sources_list_path, content)

    def _create_sources_list_d(content):
        _create_dir(sources_list_d_path)

# Generated at 2022-06-17 04:03:49.815186
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['source'] = 'ppa:ansible/ansible'
    module.params['comment'] = 'comment'

    sources_list = UbuntuSourcesList(module)
    sources_list.add_source(module.params['source'], module.params['comment'])

    assert sources_list.files['test.list'][0][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'

# Generated at 2022-06-17 04:04:01.158853
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = 'test.list'
    module.params['mode'] = '0644'
    sources = UbuntuSourcesList(module)
    sources.add_source('ppa:foo/bar')
    sources.add_source('ppa:foo/bar', file='test.list')
    sources.add_source('deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main')
    sources.add_source('deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', file='test.list')
    sources.add_source('deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main', comment='test comment')

# Generated at 2022-06-17 04:04:13.141260
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

# Generated at 2022-06-17 04:04:22.593530
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/tmp/test_sources.list')
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.save()
    assert not os.path.isfile('/tmp/test_sources.list')
    assert os.path.isfile('/tmp/test_sources.list.d/test_sources.list')
    assert os.path.isfile('/tmp/test_sources.list.d/test_sources.list.1')
    assert os.path.isfile('/tmp/test_sources.list.d/test_sources.list.2')

# Generated at 2022-06-17 04:04:33.527209
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 1
    assert sl.files['/etc/apt/sources.list'][0][1] == True
    assert sl.files['/etc/apt/sources.list'][0][2] == True
    assert sl.files['/etc/apt/sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu xenial main restricted'
    assert sl.files['/etc/apt/sources.list'][0][4] == ''


# Generated at 2022-06-17 04:05:08.293765
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/etc/apt/sources.list')
    assert len(sources_list.files) == 1
    assert len(sources_list.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:05:19.770568
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test for function revert_sources_list'''
    # Create a temporary directory to work in:
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file to work with:
    tmpfile = os.path.join(tmpdir, 'test.list')
    # Create a temporary file to work with:
    tmpfile2 = os.path.join(tmpdir, 'test2.list')
    # Create a temporary file to work with:
    tmpfile3 = os.path.join(tmpdir, 'test3.list')
    # Create a temporary file to work with:
    tmpfile4 = os.path.join(tmpdir, 'test4.list')
    # Create a temporary file to work with:
    tmpfile5 = os.path.join(tmpdir, 'test5.list')
    # Create

# Generated at 2022-06-17 04:05:24.768699
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.sources_list import SourcesList
    from ansible.module_utils.apt.sources_list import InvalidSource
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.apt.sources_list import get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.sources_list import revert_sources_list
    from ansible.module_utils.apt.sources_list import respawn_module
    from ansible.module_utils.apt.sources_list import probe_interpreters_for_module
    from ansible.module_utils.apt.sources_list import install_python_apt

# Generated at 2022-06-17 04:05:36.028185
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['repo'] = 'ppa:ansible/ansible'
    module.params['comment'] = ''
    module.params['file'] = None
    module.params['update_cache'] = False
    module.params['validate_certs'] = True
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = True

# Generated at 2022-06-17 04:05:46.105790
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile
    import shutil
    import os
    import sys
    import filecmp
    import json
    import apt
    import apt_pkg
    import aptsources.sourceslist
    import aptsources.distro
    import aptsources.distinfo
    import aptsources.distinfo.ubuntu
    import aptsources.distinfo.debian
    import aptsources.distinfo.generic
    import aptsources.distinfo.lsb
    import aptsources.distinfo.lsb_release
    import aptsources.distinfo.os_release
    import aptsources.distinfo.py_distro
    import aptsources.distinfo.system_info
    import aptsources.distinfo.system_release
    import aptsources.distinfo.system_version

# Generated at 2022-06-17 04:05:55.968100
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.params = {'codename': 'trusty'}
            self.fail_json = lambda msg: None
    module = Module()
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:06:08.162527
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.sources_list import SourcesList
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.apt.sources_list import get_add_ppa_signing_key_callback
    from ansible.module_utils.apt.sources_list import revert_sources_list
    from ansible.module_utils.apt.sources_list import main
    from ansible.module_utils.apt.sources_list import respawn_module
    from ansible.module_utils.apt.sources_list import probe_interpreters_for_module
    from ansible.module_utils.apt.sources_list import install_python_apt

# Generated at 2022-06-17 04:06:15.749812
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/test_sources.list')
    sources.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    assert sources.dump() == {'tests/test_sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}


# Generated at 2022-06-17 04:06:20.847302
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    assert len(sl.files) == 1
    assert len(sl.files['/etc/apt/sources.list']) == 1
    assert sl.files['/etc/apt/sources.list'][0] == (0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')


# Generated at 2022-06-17 04:06:26.922829
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')


# Generated at 2022-06-17 04:07:57.047680
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:08:05.272253
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create temporary sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-", dir='/etc/apt')
    f = os.fdopen(fd, 'w')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('# deb-src http://archive.ubuntu.com/ubuntu/ trusty main restricted\n')
    f.write('deb http://archive.ubuntu.com/ubuntu/ trusty-updates main restricted\n')

# Generated at 2022-06-17 04:08:08.959769
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.save()


# Generated at 2022-06-17 04:08:18.951938
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    dumpstruct = sources.dump()

# Generated at 2022-06-17 04:08:29.735857
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    import shutil
    import os
    import stat

    # Create temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create temporary file
    fd, tmp_path = tempfile.mkstemp(prefix=".test-", dir=tmpdir)
    os.close(fd)
    # Create temporary file
    fd, tmp_path2 = tempfile.mkstemp(prefix=".test-", dir=tmpdir)
    os.close(fd)
    # Create temporary file
    fd, tmp_path3 = tempfile.mkstemp(prefix=".test-", dir=tmpdir)
    os.close(fd)

    # Create temporary module
    class Module(object):
        def __init__(self):
            self.params = {}

# Generated at 2022-06-17 04:08:35.496420
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:08:45.649613
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load('/tmp/sources.list')
    sources_list.load('/tmp/sources.list.d/test.list')
    sources_list.load('/tmp/sources.list.d/test2.list')
    sources_list.load('/tmp/sources.list.d/test3.list')
    sources_list.load('/tmp/sources.list.d/test4.list')
    sources_list.load('/tmp/sources.list.d/test5.list')
    sources_list.load('/tmp/sources.list.d/test6.list')
    sources_list.load('/tmp/sources.list.d/test7.list')

# Generated at 2022-06-17 04:08:49.037913
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:08:57.997859
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:09:07.800383
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)