

# Generated at 2022-06-17 04:03:01.445869
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil
    import sys
    import json
    import subprocess
    import time
    import random
    import apt
    import aptsources.distro
    import aptsources.sourceslist
    import aptsources.distinfo
    import aptsources.distinfo.debian
    import aptsources.distinfo.ubuntu
    import aptsources.distinfo.lsb
    import aptsources.distinfo.base
    import aptsources.distinfo.distro
    import aptsources.distinfo.codename
    import aptsources.distinfo.release
    import aptsources.distinfo.version
    import aptsources.distinfo.origin
    import aptsources.distinfo.label
    import aptsources.distinfo.component
    import aptsources.distinfo

# Generated at 2022-06-17 04:03:06.749220
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    assert len(sources.files) == 1
    assert len(sources.files['/etc/apt/sources.list']) > 0


# Generated at 2022-06-17 04:03:09.424189
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:20.554457
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:03:33.202122
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load('test/sources.list')
    dumpstruct = sourceslist.dump()

# Generated at 2022-06-17 04:03:36.371450
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'install_python_apt': True, 'check_mode': False})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')
    module = AnsibleModule({'install_python_apt': True, 'check_mode': True})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:45.929499
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 04:03:57.336406
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'trusty'}
    sl = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:04:01.207472
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    assert sources_list.codename == distro.codename


# Generated at 2022-06-17 04:04:11.401302
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'file1': 'line1\nline2\n', 'file2': 'line3\nline4\n'}
    sources_after = {'file1': 'line1\nline2\n', 'file2': 'line3\nline4\n', 'file3': 'line5\nline6\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.files = sources_before
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.files == sources_before



# Generated at 2022-06-17 04:04:54.439387
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.load(os.path.join(os.path.dirname(__file__), 'test_data', 'sources.list'))

# Generated at 2022-06-17 04:05:08.036021
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:19.610552
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:05:33.306739
# Unit test for function main

# Generated at 2022-06-17 04:05:34.760814
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-17 04:05:43.446795
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/baz')
    sources_list_copy = copy.deepcopy(sources_list)
    assert sources_list.files == sources_list_copy.files
    assert sources_list.codename == sources_list_copy.codename
    assert sources_list.add_ppa_signing_keys_callback == sources_list_copy.add_ppa_signing_keys_callback


# Generated at 2022-06-17 04:05:49.803597
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar', file='/etc/apt/sources.list.d/foo.list')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu xenial main')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu xenial main', file='/etc/apt/sources.list.d/foo.list')
    sources_list.add_source('deb http://archive.ubuntu.com/ubuntu xenial main', file='foo.list')

# Generated at 2022-06-17 04:05:58.567905
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://dl.google.com/linux/chrome/deb/ stable main')
    sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:06:10.177168
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:06:16.411057
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    sourceslist = SourcesList(module)
    assert sourceslist.files == {}
    sourceslist.load('/etc/apt/sources.list')
    assert sourceslist.files != {}
    assert sourceslist.default_file == '/etc/apt/sources.list'


# Generated at 2022-06-17 04:07:34.497224
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:07:40.940147
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    assert sources_list.default_file == '/etc/apt/sources.list'
    assert sources_list.files == {}



# Generated at 2022-06-17 04:07:53.017645
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:07:56.667355
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:07:59.067463
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(argument_spec={}, check_mode=False)
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-17 04:08:09.678031
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}

    # Create sources.list
    sources.load('/etc/apt/sources.list')

# Generated at 2022-06-17 04:08:21.406390
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('/etc/apt/sources.list')
    sl.load('/etc/apt/sources.list.d/ansible.list')
    sl.load('/etc/apt/sources.list.d/ansible-2.list')
    sl.load('/etc/apt/sources.list.d/ansible-3.list')
    sl.load('/etc/apt/sources.list.d/ansible-4.list')
    sl.load('/etc/apt/sources.list.d/ansible-5.list')
    sl.load('/etc/apt/sources.list.d/ansible-6.list')

# Generated at 2022-06-17 04:08:31.367448
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)

# Generated at 2022-06-17 04:08:36.242897
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    assert sources_list.default_file == '/etc/apt/sources.list'
    assert sources_list.files == {}
    assert sources_list.new_repos == set()


# Generated at 2022-06-17 04:08:39.125394
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    sources.save()
