

# Generated at 2022-06-17 04:02:57.852127
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:03:00.559869
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('/etc/apt/sources.list')
    sources.save()



# Generated at 2022-06-17 04:03:04.834828
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule(argument_spec={})
    sources_before = {'/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n'}
    sources_after = {'/etc/apt/sources.list': 'deb http://example.com/ubuntu trusty main\n',
                     '/etc/apt/sources.list.d/example.list': 'deb http://example.com/ubuntu trusty main\n'}
    sourceslist_before = SourcesList(module)
    sourceslist_before.load('/etc/apt/sources.list')
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert not os.path.exists('/etc/apt/sources.list.d/example.list')
    assert sourceslist_before

# Generated at 2022-06-17 04:03:15.407507
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['cache_valid_time'] = None
    module.params['http_agent'] = None
    module.params['force'] = None
    module.params['timeout'] = None
    module.params['retries'] = None
    module.params['delay'] = None
    module.params['backoff'] = None
    module.params['max_attempts'] = None
    module.params['other_packages'] = None
    module.params['purge'] = None


# Generated at 2022-06-17 04:03:27.621191
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources.add_source('deb http://archive.canonical.com/ubuntu hardy partner')

# Generated at 2022-06-17 04:03:31.596341
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None
    module.check_mode = False
    assert get_add_ppa_signing_key_callback(module) is not None


# Generated at 2022-06-17 04:03:40.771452
# Unit test for function main

# Generated at 2022-06-17 04:03:52.074319
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.params = {'codename': 'trusty'}
            self.fail_json = lambda msg: None

    module = Module()
    sources_list = UbuntuSourcesList(module)
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')
    sources_list.add_source('ppa:foo/bar')

# Generated at 2022-06-17 04:04:03.597670
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:04:13.215757
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from copy import deepcopy
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.six.moves.urllib.request import urlopen
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.apt.sources_list import UbuntuSourcesList
    from ansible.module_utils.apt.sources_list import fetch_url
    from ansible.module_utils.apt.sources_list import distro

# Generated at 2022-06-17 04:04:54.439697
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:08.040918
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    from ansible.module_utils.basic import AnsibleModule

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sources_list = SourcesList(AnsibleModule(argument_spec={}))

# Generated at 2022-06-17 04:05:19.611056
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

    module = MockModule()
    sl = SourcesList(module)

# Generated at 2022-06-17 04:05:22.426992
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-17 04:05:33.934417
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial main restricted')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates main restricted')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates universe')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial multiverse')
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ xenial-updates multiverse')

# Generated at 2022-06-17 04:05:44.907845
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x
    module.run_command = lambda x, check_rc=False: (0, '', '')
    module.set_mode_if_different = lambda x, y, z: x
    module.atomic_move = lambda x, y: x
    module.params = {'codename': 'xenial'}
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = None
    module.params['update_cache'] = None
    module.params['validate_certs'] = None
    module.params['keyserver'] = None
    module.params['key_id'] = None

# Generated at 2022-06-17 04:05:54.743026
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

# Generated at 2022-06-17 04:05:57.603124
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:06:09.525683
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sources_list = SourcesList(self)

# Generated at 2022-06-17 04:06:15.693255
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load('/tmp/sources.list')
    assert sources.dump() == {'/tmp/sources.list': 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted\n'}


# Generated at 2022-06-17 04:07:28.010655
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-17 04:07:36.743684
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'trusty'
    module.params['filename'] = None
    module.params['mode'] = None
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = False
    module.params['source'] = 'ppa:ansible/ansible'
    module.params['comment'] = '#'
    module.params['file'] = None
    module.params['update_cache'] = False
    module.params['validate_certs'] = False
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    module.params['validate_certs'] = False

# Generated at 2022-06-17 04:07:45.299634
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    module.get_bin_path = lambda x: '/usr/bin/apt-get'
    module.run_command = lambda x: (0, '', '')
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')
    module.check_mode = True
    module.fail_json = lambda x: None
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-17 04:07:55.427963
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.load('tests/sources.list')
    assert len(sources.files) == 1

# Generated at 2022-06-17 04:08:04.200084
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    module.params = {'codename': 'xenial'}
    add_ppa_signing_keys_callback = lambda command: None
    ubuntu_sources_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    ubuntu_sources_list.files = {'file1': [('n1', 'valid1', 'enabled1', 'source1', 'comment1')]}
    ubuntu_sources_list.codename = 'yakkety'
    ubuntu_sources_list.add_ppa_signing_keys_callback = lambda command: None
    ubuntu_sources_list_copy = copy.deepcopy(ubuntu_sources_list)
    assert ubuntu_sources_list.files == ubuntu_sources_

# Generated at 2022-06-17 04:08:08.336996
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile
    import unittest

    class TestSourcesList(unittest.TestCase):
        def setUp(self):
            self.tempdir = tempfile.mkdtemp()
            self.sourceslist = SourcesList(None)
            self.sourceslist.default_file = os.path.join(self.tempdir, 'sources.list')
            self.sourceslist.files[self.sourceslist.default_file] = []

        def tearDown(self):
            shutil.rmtree(self.tempdir)

        def test_save_empty(self):
            self.sourceslist.save()
            self.assertFalse(os.path.exists(self.sourceslist.default_file))


# Generated at 2022-06-17 04:08:21.117026
# Unit test for function main
def test_main():
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-17 04:08:31.139193
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None
    callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '12345'])
    module.run_command.assert_called_once_with(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '12345'], check_rc=True)



# Generated at 2022-06-17 04:08:41.872268
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    assert sources.default_file == '/etc/apt/sources.list'
    assert sources.files == {}
    assert list(sources) == []

    # Create sources.list
    fd, tmp_path = tempfile.mkstemp(prefix=".sources.list-")
    f = os.fdopen(fd, 'w')
    f.write('# deb cdrom:[Debian GNU/Linux 7.0.0 _Wheezy_ - Official amd64 NETINST Binary-1 20130514-14:46]/ wheezy main\n')
    f.write('deb http://http.debian.net/debian wheezy main\n')

# Generated at 2022-06-17 04:08:49.920023
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Test that the function works when there are no new files
    sources_before = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu xenial main',
        '/etc/apt/sources.list.d/test.list': 'deb http://example.com/ubuntu xenial main',
    }
    sources_after = {
        '/etc/apt/sources.list': 'deb http://example.com/ubuntu xenial main',
        '/etc/apt/sources.list.d/test.list': 'deb http://example.com/ubuntu xenial main',
    }
    sourceslist_before = SourcesList(None)
    sourceslist_before.files = sources_before
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before

# Generated at 2022-06-17 04:12:10.562857
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import shutil
    import os
    import apt_pkg

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'codename': 'trusty',
                'filename': None,
                'mode': None,
            }

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, tmp_path, filename):
            shutil.move(tmp_path, filename)


# Generated at 2022-06-17 04:12:17.700730
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

    assert sources_list.default_file == '/etc/apt/sources.list'
    assert sources_list.files == {}

    sources_list.load('/etc/apt/sources.list')
    assert sources_list.files == {'/etc/apt/sources.list': []}

    sources_list.load('/etc/apt/sources.list.d/test.list')
    assert sources_list.files == {'/etc/apt/sources.list': [], '/etc/apt/sources.list.d/test.list': []}


# Generated at 2022-06-17 04:12:24.069283
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    sl.load('test_apt_repository.list')
    sl.modify('test_apt_repository.list', 0, enabled=False)
    sl.modify('test_apt_repository.list', 1, source='deb http://archive.canonical.com/ubuntu hardy partner')
    sl.modify('test_apt_repository.list', 2, comment='test comment')
    sl.modify('test_apt_repository.list', 3, enabled=False, source='deb http://archive.canonical.com/ubuntu hardy partner', comment='test comment')
    sl.save()
    assert os.path.isfile('test_apt_repository.list')