

# Generated at 2022-06-20 21:20:13.533001
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import pytest
    from ansible.module_utils.six.moves import StringIO

    class Module(object):
        def __init__(self, result):
            self.result = result
            self.params = {}

        def fail_json(self, **kwargs):
            raise AssertionError('Unexpected call of module.fail_json')

        def atomic_move(self, src, dest):
            self.result['atomic_move'] = (src, dest)

        def set_mode_if_different(self, path, mode, changed):
            self.result['set_mode_if_different'] = (path, mode, changed)


# Generated at 2022-06-20 21:20:18.283539
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    ppa_signing_key_callback = get_add_ppa_signing_key_callback(module)
    assert ppa_signing_key_callback is not None
    ppa_signing_key_callback(['ls'])
# ==========================


# Generated at 2022-06-20 21:20:28.863487
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class DummyModule(object):
        def __init__(self, **kwargs):
            for k in kwargs:
                setattr(self, k, kwargs[k])

        def run_command(self, command, check_rc=True):
            self.run_command_args = command

    def assert_no_change_in_command(m):
        assert m.run_command_args is None

    def assert_change_in_command(m, command):
        assert m.run_command_args == command


# Generated at 2022-06-20 21:20:42.533625
# Unit test for function install_python_apt
def test_install_python_apt():
    class FakeModule:
        def get_bin_path(self, arg):
            if arg == 'apt-get':
                return self.path
            else:
                return None
        def run_command(self, cmd):
            self.cmd = cmd
            return self.rc, self.so, self.se
    f = FakeModule()
    f.path = ""
    f.check_mode = False
    f.rc = 0
    f.so = f.se = ""
    is_present = HAVE_PYTHON_APT
    if is_present:
        install_python_apt(f, 'python3-apt')
        assert len(f.cmd) == 5, f.cmd
        assert f.cmd[1] == 'install', f.cmd

# Generated at 2022-06-20 21:20:49.175331
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-20 21:21:02.826134
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    if not HAVE_PYTHON_APT:
        return
    t = SourcesList(None)
    t.files = {
        'file1': [
            (1, False, False, '/path', 'comment'),
            (2, True, True, 'source1', 'comment'),
            (3, True, False, 'source2', 'comment'),
            (4, True, True, 'source3', 'comment'),
        ],
        'file2': [
            (5, False, False, '/path2', 'comment'),
            (6, True, True, 'source4', 'comment'),
            (7, True, False, 'source5', 'comment'),
            (8, True, True, 'source6', 'comment'),
        ],
    }
    res = list(t)

# Generated at 2022-06-20 21:21:05.192279
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    a = InvalidSource()
    assert(a)



# Generated at 2022-06-20 21:21:09.267305
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    result = get_add_ppa_signing_key_callback(module) is None
    assert result is True



# Generated at 2022-06-20 21:21:16.956366
# Unit test for function main

# Generated at 2022-06-20 21:21:28.588071
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = type('DummyModule', (), dict(
        run_command=lambda *args: (0, '', ''),
        check_mode=lambda *args: False,
        exit_json=lambda *args: sys.exit(0),
        fail_json=lambda *args: sys.exit(1),
        atomic_move=lambda *args: None,
        set_mode_if_different=lambda *args: None,
        params=dict(
            mode=None,
            filename=None,
        )
    ))()

    tmp_path = os.path.abspath(os.path.join('/tmp', 'ansible'))
    os.makedirs(tmp_path)

# Generated at 2022-06-20 21:22:03.721224
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True
    )
    version = apt_pkg.config.find_version(module.apt_pkg)
    # In python 2.6.5 apt_pkg.config.find_version returns a string
    if isinstance(version, str):
        version = tuple(map(int, version.split('.')))
    if sys.version_info[0:3] != version[0:3]:
        module.fail_json(msg='Python version has respawned, cannot continue')

# Generated at 2022-06-20 21:22:10.038705
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    """
    setUp for testing class UbuntuSourcesList
    """
    module = AnsibleModule(argument_spec={})
    module.params["codename"] = "xenial"
    u = UbuntuSourcesList(module)
    assert len(u.files) == 0
    u.add_source("deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main", comment="comment", file="file1")
    assert len(u.files) == 1



# Generated at 2022-06-20 21:22:20.400675
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class MetaModule(object):
        def __init__(self):
            self.params = dict()
            self.failed = False
            self.fail_json_called = False
            self.fail_json_dict = dict()
            self.changed = False
        def fail_json(self, msg, **kwargs):
            self.fail_json_called = True
            self.failed = True
            self.fail_json_dict = kwargs
            kwargs['msg'] = msg
            raise Exception(kwargs)

    class Module(object):
        def __init__(self):
            self.params = dict()
            self.fail_json = MetaModule().fail_json
            self.meta = MetaModule()

    class InvokeModule():
        def __init__(self):
            self.params = dict()


# Generated at 2022-06-20 21:22:32.987997
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class FakeModule(object):
        fail_json = lambda *args, **kw: False
    module = FakeModule()

    sl = SourcesList(module)
    sl.files = {'file1': [(100, False, True, 'disabled source1', 'comment1'),
                          (101, False, False, 'disabled source2', 'comment2'),
                          (102, True, True, 'source1', 'comment3'),
                          (103, True, True, 'source2', 'comment4'),
                         ]}

    sl.modify('file1', 102, enabled=False, comment='comment5')

# Generated at 2022-06-20 21:22:33.778360
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    with pytest.raises(InvalidSource):
        raise InvalidSource()


# Generated at 2022-06-20 21:22:46.411788
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():

    test_cases = [
        # line                                             | should_remove_source
        ('deb http://ppa.launchpad.net/example/example/ubuntu trusty main', True),
        ('http://ppa.launchpad.net/example/example/ubuntu trusty main', False),
        ('    deb http://ppa.launchpad.net/example/example/ubuntu trusty main', True),
        ('# deb http://ppa.launchpad.net/example/example/ubuntu trusty main', False),
        ('deb http://ppa.launchpad.net/example/example/ubuntu trusty main   # launchpad comment', True)
    ]

    for line, should_remove_source in test_cases:
        module = AnsibleModule({})
        apt_sources = UbuntuSourcesList(module)
        sources_list = [line]
        apt_s

# Generated at 2022-06-20 21:22:59.012301
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import os
    import tempfile

    module = AnsibleModule({
        'state': 'present',
        'repo': 'deb http://archive.canonical.com/ubuntu hardy partner',
    })

    lines = []
    lines.append('# deb cdrom:[Xubuntu 7.10 _Gutsy Gibbon_ - Release amd64 (20071016)]/ gutsy main multiverse restricted universe\n')
    lines.append('# deb cdrom:[Xubuntu 7.10 _Gutsy Gibbon_ - Release amd64 (20071016)]/ gutsy main multiverse restricted universe\n')
    lines.append('deb http://archive.canonical.com/ubuntu hardy partner\n')

    # create temporary directory
    tmp_dir = tempfile.mkdtemp()

    # create temporary files
    os.chmod

# Generated at 2022-06-20 21:23:06.585516
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)
    assert len(sl.files) > 0
    assert 'Dir::Etc::sourceparts' in [d[0][0] for d in list(sl.files.items())]
    assert 'Dir::Etc::sourcelist' in [d[0][0] for d in list(sl.files.items())]
    assert 'etc/apt/sources.list' == sl.default_file


# Generated at 2022-06-20 21:23:19.284327
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from .mock import patch, mock_open
    from ansible.module_utils import basic
    from ansible.module_utils import common
    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    o = SourcesList(m)
    o.files = {
        '/etc/apt/sources.list.d/test.list': [
            (1, '1', 1, '1', '1'),
            (2, '2', 2, '2', '2'),
            (3, '3', 3, '3', '3'),
            (4, '4', 4, '4', '4'),
        ],
    }

# Generated at 2022-06-20 21:23:26.581157
# Unit test for function revert_sources_list
def test_revert_sources_list():
    def mock_exit_json(module, msg, **kwargs):
        module.fail_json(msg, **kwargs)

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg, **kwargs):
            self.exit_json = mock_exit_json
            self.exit_json(self, msg, **kwargs)

    sources_after = {
        '/etc/apt/sources.list.d/new.list': 'deb-src http://deb.debian.org/debian stable main\n',
        '/etc/apt/sources.list.d/new2.list': 'deb http://deb.debian.org/debian stable main\n',
    }

# Generated at 2022-06-20 21:24:30.885074
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    import mock
    mock_module = mock.MagicMock()
    mock_module.check_mode = False
    assert get_add_ppa_signing_key_callback(mock_module) is not None
    assert mock_module.run_command.call_count == 0
    mock_module.reset_mock()
    mock_module.check_mode = True
    assert get_add_ppa_signing_key_callback(mock_module) is None
    assert mock_module.run_command.call_count == 0



# Generated at 2022-06-20 21:24:38.585399
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    test_dir = tempfile.mkdtemp()
    sl = SourcesList(None)
    sl.files = {os.path.join(test_dir, "sources.list"): [(0, True, True, "deb http://example.com/debian wheezy main", "")]}
    sl.save()
    assert os.path.isfile(os.path.join(test_dir, "sources.list"))
    os.remove(os.path.join(test_dir, "sources.list"))
    os.rmdir(test_dir)


# Generated at 2022-06-20 21:24:48.541994
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import re
    import doctest

    lines = '''
# comment1
# comment2
deb http://example.com/debian unstable main # comment3
deb http://example.com/debian-other unstable-other main
'''
    expected = [
        ('/etc/apt/sources.list', 2, True, 'deb http://example.com/debian unstable main', 'comment3'),
        ('/etc/apt/sources.list', 3, True, 'deb http://example.com/debian-other unstable-other main', ''),
    ]

    class MockModule(object):
        def __init__(self, lines):
            self.lines = lines

        def atomic_move(self, old_path, new_path):
            pass


# Generated at 2022-06-20 21:24:52.994220
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class module(object):
        def __init__(self):
            self.check_mode = False
        def run_command(self, command, check_rc=True):
            pass
    assert callable(get_add_ppa_signing_key_callback(module()))



# Generated at 2022-06-20 21:24:59.133020
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sl = SourcesList()
    sl.add_source('deb http://packages.example.org/debian wheezy main')
    assert sl.files == {'/etc/apt/sources.list': [(0, True, True, 'deb http://packages.example.org/debian wheezy main', '')]}


# Generated at 2022-06-20 21:25:09.297630
# Unit test for function install_python_apt
def test_install_python_apt():
    '''
    Use a monkey patched module class to simulate a non-Ubuntu target.
    '''
    class FakeModule:
        class FakeAptDistro:
            def __init__(self):
                self.codename = "fake"
        def __init__(self, check_mode=True, params={}):
            self.check_mode = check_mode
            self.params = params

            self.fail_json = self.fail
            self.warns = []
            self.msg = None

            self.distro = self.FakeAptDistro()
            self.get_bin_path_return_value = '/usr/bin/apt-get'

        def fail(self, msg):
            self.msg = msg
            raise Exception(msg)


# Generated at 2022-06-20 21:25:11.214182
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    pass



# Generated at 2022-06-20 21:25:19.334492
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    mod = AnsibleModule(argument_spec={})
    s = UbuntuSourcesList(mod)
    s.codename = 'trusty'
    s.files = {
        '/etc/apt/sources.list.d/foo.list': [
            (0, True, True, 'ppa:foo/bar', ''),
            (1, True, True, 'http://archive.canonical.com/ubuntu trusty partner', '')
        ]
    }
    s.remove_source("ppa:foo/bar")
    assert '%s/foo.list' % s._apt_cfg_dir('Dir::Etc::sourceparts') not in s.files


# Generated at 2022-06-20 21:25:22.358077
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource()
    except InvalidSource:
        pass



# Generated at 2022-06-20 21:25:30.457747
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
  global sl
  dumpstruct = sl.dump()