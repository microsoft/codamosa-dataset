

# Generated at 2022-06-20 21:20:09.144671
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    Unit test for method dump of class SourcesList
    '''

    class AptModule():
        def __init__(self):
            self.params = dict()

    # Capture arguments
    def atomic_move(source, dest):
        global _atomic_move_source
        _atomic_move_source = source

    apt_module = AptModule()
    apt_module.params['filename'] = 'file1'
    apt_module.atomic_move = atomic_move

    sources_list = SourcesList(apt_module)

    # Open a temp file and write a valid sources line to it
    fd, tmp_path = tempfile.mkstemp(prefix='source', dir='/tmp')
    os.close(fd)

# Generated at 2022-06-20 21:20:14.788654
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={'state': dict(default='present', choices=['absent', 'present']),
                                          'repo': dict(required=True),
                                          'filename': dict(required=False, default=None)})
    sl = SourcesList(module)
    sl.add_source(module.params['repo'])
    dumpstruct = sl.dump()
    assert isinstance(dumpstruct, dict)




# Generated at 2022-06-20 21:20:25.376944
# Unit test for function install_python_apt
def test_install_python_apt():

    # make sure that module_utils/ansible_module_common.py can be found
    if __file__.endswith('.pyc'):
        py_file = __file__[:-1]
    else:
        py_file = __file__

    common_utils = os.path.abspath(os.path.join(os.path.dirname(py_file), 'module_utils/ansible_module_common.py'))

    if os.path.isfile(common_utils):
        sys.path.append(os.path.dirname(common_utils))

    # import the module, initializing it like ansible would
    from ansible_module_common import AnsibleModule as TestAnsibleModule

    # create a temporary module in a tempfile
    dummy_module_path = tempfile.mktemp()

# Generated at 2022-06-20 21:20:26.380623
# Unit test for function install_python_apt
def test_install_python_apt():
    install_python_apt()



# Generated at 2022-06-20 21:20:33.296377
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    result = {'filename': ['file1.list', 'file2.list', 'file3.list'], 'n': [0, 1, 2], 'enabled': [False, True, True], 'source': ['deb http://archives.ubuntu.com/ubuntu trusty main restricted', 'deb http://archives.ubuntu.com/ubuntu trusty-updates main restricted', 'deb http://security.ubuntu.com/ubuntu trusty-security main restricted'], 'comment': [' disabled on upgrade to trusty', '', '']}
    assert result == SourcesList.load_sources_lists()



# Generated at 2022-06-20 21:20:41.956084
# Unit test for function revert_sources_list
def test_revert_sources_list():
    cases = (
        # basic tests:
        ({}, {}, {}, {
            None: [],
        }),
        ({}, {'new_file': 'hello'}, {}, {
            None: [],
        }),
        ({'existing_file': 'hello'}, {'existing_file': 'hello'}, {'existing_file': 'hello'}, {
            'existing_file': [],
        }),
    )
    for sources_before, sources_after, sourceslist_before, expected_results in cases:
        sources_before = AnsibleModule(name='sources_before').dict_to_sources(sources_before)
        sources_after = AnsibleModule(name='sources_after').dict_to_sources(sources_after)

# Generated at 2022-06-20 21:20:53.964906
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    expected = {'Dir::Etc::Trusted': '/dev/null', 'Dir::Etc::TrustedParts': '/dev/null',
                'Dir::Etc::Trusted': '/dev/null', 'Dir::Etc::TrustedParts': '/dev/null',
                'Dir::Etc::sourceparts': '/dev/null', 'Dir::Etc::sourceparts': '/dev/null',
                'Dir::Etc::sourceparts': '/dev/null', 'Dir::Etc::sourceparts': '/dev/null',
                'Dir::Etc::sourceparts': '/dev/null', 'Dir::Etc::sourceparts': '/dev/null',
                'Dir::Etc::sourceparts': '/dev/null', 'Dir::Etc::sourceparts': '/dev/null'}


# Generated at 2022-06-20 21:20:56.796574
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    assert True == False, "Construct unit tests for SourcesList.remove_source()"


# Generated at 2022-06-20 21:20:57.685206
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''test something'''
    pass


# Generated at 2022-06-20 21:21:01.581047
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule(object):
        params = {
            'codename': 'test_codename'
        }

    def add_ppa_signing_keys_callback(command):
        pass

    instance = UbuntuSourcesList(
        TestModule(),
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback
    )
    copy = copy.deepcopy(instance)

    assert copy.module.params['codename'] == 'test_codename'
    assert copy.add_ppa_signing_keys_callback == add_ppa_signing_keys_callback



# Generated at 2022-06-20 21:21:35.598849
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    fd, fn = tempfile.mkstemp(prefix='ansible-test-apt_repository-')
    s = SourcesList(None)
    s.files = {
        fn: [
            (0, True, True, 'deb http://archive.ubuntu.com/ubuntu trusty universe', ''),
            (1, True, False, 'deb http://archive.ubuntu.com/ubuntu trusty multiverse', 'disabled for the moment'),
            (2, False, True, 'deb http://archive.ubuntu.com/ubuntu trusty restricted', 'should not be here'),
        ],
    }

# Generated at 2022-06-20 21:21:48.390966
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Prepare test.
    module = AnsibleModule(argument_spec={})
    temp_path = tempfile.mkdtemp()
    module.add_cleanup_file(temp_path)
    module.run_command_environ_update = dict(os.environ, APT_CONFIG="Dir::Etc {0}".format(temp_path))

    list_obj = SourcesList(module)

    # Test.
    # Try with file specified explicitly.
    list_obj.add_source("deb http://server.com/ubuntu precise main", file="test.list")
    expected = {
        os.path.join(temp_path, "test.list"): "deb http://server.com/ubuntu precise main\n"
    }
    assert list_obj.dump() == expected
    list_obj.save()

   

# Generated at 2022-06-20 21:22:04.499242
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest
    import ansible.module_utils.apt_pkg
    class MockModule(object):
        @staticmethod
        def run_command(*args):
            res = {
                'exit_status': 0,
                'stdout': '',
                'stderr': '',
            }
            return res['exit_status'], res['stdout'], res['stderr']

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self, tmp, filename):
            pass

        def set_mode_if_different(self, path, mode, changed):
            pass

    class MockDistInfo(object):
        codename = 'codename'

    class MockFetchUrl(object):
        def __init__(self):
            pass


# Generated at 2022-06-20 21:22:10.890277
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils.apt_repository import SourcesList
    result = SourcesList(None)
    result.files = {"a": [(1, True, True, "b", "c")]}
    expected = set([("a", 1, True, "b", "c")])
    actual = set(result)
    assert expected == actual


# Generated at 2022-06-20 21:22:26.503409
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import os
    import tempfile
    import sys

    def writeTree(vartree, base):
        for key, value in vartree.items():
            if isinstance(value, dict):
                dirname = os.path.join(base, key)
                os.makedirs(dirname)
                writeTree(value, dirname)
            else:
                filename = os.path.join(base, key)
                with open(filename, 'w') as fd:
                    fd.write(value)

    def tree(directory):
        result = {}
        for name in os.listdir(directory):
            path = os.path.join(directory, name)
            if os.path.isfile(path):
                with open(path, 'r') as fd:
                    result[name] = fd.read

# Generated at 2022-06-20 21:22:35.551572
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class SourcesListTest(SourcesList):
        def __init__(self, module):
            pass
        def _parse(self, line, raise_if_invalid_or_disabled=False):
            return True, True, line, line
    sources = SourcesListTest(None)
    sources.files = {
        'test_file': [
            (0, True, True, 'line0', 'line0'),
            (1, False, False, 'line1', 'line1'),
            (2, True, False, 'line2', 'line2'),
            (3, False, True, 'line3', 'line3'),
        ]
    }

# Generated at 2022-06-20 21:22:36.994107
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    raise InvalidSource()


# Generated at 2022-06-20 21:22:53.301354
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

    assert len(sources.files) == 0

    sources = SourcesList(module)
    sources.load(module.get_bin_path('create_sources.list'))

    files = sources.files

    assert len(files) == 1
    assert sorted(files.keys())[0] == module.get_bin_path('create_sources.list')

    sources = list(sources)

    assert len(sources) == 3
    assert sources[0][1] == 0
    assert sources[0][2] == True
    assert sources[0][3] == 'deb http://archive.canonical.com/ubuntu hardy partner'
    assert sources[0][4] == ''

    assert sources[1][1] == 1
   

# Generated at 2022-06-20 21:23:00.099027
# Unit test for function main
def test_main():
    for param in ['update_cache', 'update_cache_retries', 'update_cache_retry_max_delay']:
        assert param in main.__code__.co_varnames
    for param in ['sourceslist_before', 'sources_before', 'sources_after', 'changed', 'diff']:
        assert param in main.__code__.co_varnames

# Generated at 2022-06-20 21:23:12.340703
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    def _setup(params):
        class _Module(object):
            pass

        module = _Module()
        module.params = params
        module.check_mode = False
        module.run_command = _run_command
        module.fail_json = _fail_json
        module.atomic_move = _atomic_move
        module.set_mode_if_different = _set_mode_if_different

        return module

    def _run_command(cmd, check_rc=True):
        return 0, '', ''

    def _fail_json(msg):
        raise Exception(msg)

    def _atomic_move(src_path, dest_path):
        return None

    def _set_mode_if_different(filename, this_mode, is_directory):
        return None


# Generated at 2022-06-20 21:23:56.343462
# Unit test for method add_source of class UbuntuSourcesList

# Generated at 2022-06-20 21:24:03.483872
# Unit test for function revert_sources_list
def test_revert_sources_list():
    """ Test revert_sources_list function """
    import tempfile
    module = AnsibleModule(
        argument_spec = dict(
            filename = dict(required=False, default=None, type='str'),
            repo = dict(required=False, default=None, type='str'),
            dist = dict(required=False, default=None, type='str'),
            state = dict(required=False, default=None, type='str'),
            update_cache = dict(required=False, default=None, type='bool'),
            mode = dict(required=False, default=None, type='str'),
        )
    )
    sources_before = None
    sources_after = None
    sourceslist_before = None
    temp_file = tempfile.NamedTemporaryFile()
    module.params['filename'] = temp_file.name

# Generated at 2022-06-20 21:24:17.262789
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''Test cases for SourcesList.modify
    '''
    class ModuleMock(object):
        params = {'mode': 0o666}

        def fail_json(self, msg):
            raise AssertionError(msg)

        def atomic_move(self, tmp_path, filename):
            os.rename(tmp_path, filename)

        def set_mode_if_different(self, filename, mode, follow_links):
            os.chmod(filename, mode)

    class TempfileMock(object):

        def mkstemp(self, prefix, dir):
            return os.open(os.path.join(dir, prefix[1:] + str(random.randint(0, 1000000))), os.O_RDWR | os.O_CREAT), None


# Generated at 2022-06-20 21:24:33.363263
# Unit test for constructor of class UbuntuSourcesList

# Generated at 2022-06-20 21:24:45.376778
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

    # n_lines, n_valid_sources, n_disabled_sources, n_valid_disabled_sources

# Generated at 2022-06-20 21:24:48.107353
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    message = "Yes, this is a test message!"
    exc = InvalidSource(message)
    assert exc.args[0] == message


# Generated at 2022-06-20 21:24:52.951085
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec=dict())
    sources_list = UbuntuSourcesList(module)
    assert sources_list.LP_API == 'https://launchpad.net/api/1.0/~%s/+archive/%s'


# ===========================================
# Main control flow


# Generated at 2022-06-20 21:25:06.272917
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    l = SourcesList(None)
    l.load('/dev/null')
    l.files = {'/dev/null': []}
    for filename, n, enabled, source, comment in l:
        pass
    l.files = {'/dev/null': [(0, False, False, 'foo', '')]}
    for filename, n, enabled, source, comment in l:
        pass
    l.files = {'/dev/null': [(0, False, False, 'foo', ''), (1, True, True, 'bar', '')]}
    for filename, n, enabled, source, comment in l:
        if filename == '/dev/null':
            assert n == 1
            assert enabled is True
            assert source == 'bar'
            assert comment == ''
            break

# Generated at 2022-06-20 21:25:22.621518
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    """Unit test for method save of class SourcesList
    """

    # backup source.list
    if os.path.isfile("/etc/apt/sources.list"):
        os.system("mv /etc/apt/sources.list /etc/apt/sources.list.bak")

    sl = SourcesList(module)
    for f in glob.iglob('/etc/apt/sources.list.d/*.list'):
        os.remove(f)

    # test for wrong parameter type
    with pytest.raises(Exception) as excinfo:
        sl.save("")
    assert 'save requires 1' in str(excinfo)

    # test with empty source.list file
    sl.save()

    # assert that the file was created and contains the expected content

# Generated at 2022-06-20 21:25:26.301434
# Unit test for function revert_sources_list
def test_revert_sources_list():
    m = AnsibleModule(argument_spec={
        'sources_before': {'type': 'dict'},
        'sources_after': {'type': 'dict'},
        'sourceslist_before': {'type': 'object'}
    })
    revert_sources_list(m.params['sources_before'], m.params['sources_after'], m.params['sourceslist_before'])



# Generated at 2022-06-20 21:26:37.208370
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    sources = SourcesList()
    lines = ['deb http://download.virtualbox.org/virtualbox/debian stretch contrib\n',
             '# deb http://download.virtualbox.org/virtualbox/debian stretch contrib\n',
             'deb http://download.virtualbox.org/virtualbox/debian stretch contrib\n']
    sources.files = {'sources.list': []}
    for l in lines:
        sources.files['sources.list'].append(sources._parse(l))

    assert list(sources.__iter__()) == [('sources.list', 0, True, 'deb http://download.virtualbox.org/virtualbox/debian stretch contrib', ''), ('sources.list', 2, True, 'deb http://download.virtualbox.org/virtualbox/debian stretch contrib', '')]

   

# Generated at 2022-06-20 21:26:46.173277
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Test that APT repo is properly inserted into a list and substituted when it's there already
    def _test(repo_line, final_output, content=''):
        module = AnsibleModule(argument_spec={})

        temp_files = []
        sources = SourcesList(module=module)

        # Create input file
        fd, input_file = tempfile.mkstemp(prefix='.input-')
        temp_files.append(input_file)
        os.close(fd)
        with open(input_file, 'w') as f:
            f.write(content)
        sources.load(input_file)

        # Create output
        fd, output_file = tempfile.mkstemp(prefix='.output-')
        temp_files.append(output_file)
        os.close(fd)


# Generated at 2022-06-20 21:26:47.346725
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-20 21:26:54.663628
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    '''Test for method __deepcopy__ of class UbuntuSourcesList'''
    import copy
    main_mock = MagicMock(name='main mocked object')
    test_module = UbuntuSourcesList(main_mock, add_ppa_signing_keys_callback=None)
    result = copy.deepcopy(test_module)
    assert result.module == main_mock and result.codename == 'saucy' and result.add_ppa_signing_keys_callback == None and result.files == {}

# Generated at 2022-06-20 21:26:55.826120
# Unit test for function main
def test_main():
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:26:58.641818
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Invalid source cause")
    except InvalidSource as e:
        if str(e) != "Invalid source cause":
            raise AssertionError("Unexpected error for InvalidSource: " + str(e))


# Generated at 2022-06-20 21:27:00.207035
# Unit test for function install_python_apt
def test_install_python_apt():
    # Stubbed
    pass



# Generated at 2022-06-20 21:27:14.617890
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    import os

    test = SourcesList(None)

    tmp = tempfile.NamedTemporaryFile(mode='w', delete=False)
    tmp.write('''
# This is a comment
line without http
http://domain
    ''')
    tmp.close()

    test.load(tmp.name)
    os.unlink(tmp.name)

    assert len(test.files[tmp.name]) == 3
    assert test.files[tmp.name][0] == (0, False, False, 'This is a comment', '')
    assert test.files[tmp.name][1] == (1, False, True, 'line without http', '')
    assert test.files[tmp.name][2] == (2, True, True, 'http://domain', '')



# Generated at 2022-06-20 21:27:23.414125
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class ModuleWrapper(object):
        def __init__(self, *args, **kwargs):
            self.params = {}
            self.check_mode = False
            self.params['src'] = line
    module = ModuleWrapper()
    sources = SourcesList(module)
    sources.add_source(line)
    for n, valid, enabled, src, comment in sources:
        assert(enabled)
    sources.remove_source(line)
    for n, valid, enabled, src, comment in sources:
        if source == src:
            assert(not enabled)

# Generated at 2022-06-20 21:27:24.156120
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass
