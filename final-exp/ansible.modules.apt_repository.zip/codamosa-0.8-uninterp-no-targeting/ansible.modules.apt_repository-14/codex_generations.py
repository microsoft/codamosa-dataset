

# Generated at 2022-06-20 21:20:04.012785
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(
        argument_spec={
            'codename': {'type': 'str'},
            'update_cache': {'type': 'bool', 'default': False},
        },
        supports_check_mode=False
    )

    sl = UbuntuSourcesList(module)
    import copy
    sl2 = copy.deepcopy(sl)

    assert sl.codename == sl2.codename
    assert sl.add_ppa_signing_keys_callback == sl2.add_ppa_signing_keys_callback

# Generated at 2022-06-20 21:20:12.156998
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec = dict(), supports_check_mode = False)

# Generated at 2022-06-20 21:20:22.205860
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # First we create a module object
    test_module = AnsibleModule(argument_spec={
        "filename": {"type": "str", "required": False},
        "ppa": {"type": "str", "required": False},
        "comment": {"type": "str", "required": False},
    }, supports_check_mode=True)
    # Then we initialize the object by passing the module object
    test_UbuntuSourcesList_object = UbuntuSourcesList(test_module)
    # Then we test the add_source method with the following inputs
    test_filename = test_comment = test_ppa = test_actual_result = None
    # When filename is set and parameter type is str
    test_filename = "test_string"
    test_comment = "test_string"
    test_ppa = "test_string"
    test_expected

# Generated at 2022-06-20 21:20:37.599581
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class Module(object):
        def __init__(self):
            self.fail_json = self.fail_json_mock
        def fail_json_mock(self, msg):
            raise Exception("Failed to remove repo")
        def params(self):
            return {'codename': 'xenial'}
        def run_command(self, key_id, check_rc=True):
            return (0, '', '')
    def add_ppa_signing_keys_callback(command):
        pass
    usl = UbuntuSourcesList(Module(), add_ppa_signing_keys_callback)
    usl.add_source("# deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main")

# Generated at 2022-06-20 21:20:47.652076
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    apt_pkg.init_config()
    apt_pkg.config['Dir'] = '/tmp/apt'
    if not os.path.exists(apt_pkg.config['Dir']):
        os.makedirs(apt_pkg.config['Dir'])

    sources = SourcesList(module)
    assert sources.files == {}

    fn = os.path.join(apt_pkg.config['Dir'], 'sources.list')
    f = open(fn, 'w')

# Generated at 2022-06-20 21:21:02.234634
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import tempfile
    from ansible.module_utils.common.respawn import probe_interpreters_for_module
    from ansible.module_utils.basic import AnsibleModule

    # - will work with python 2 & 3
    # - will work with python-apt < 0.9.0.5 and python-apt == 0.9.0.5
    # - will work when apt_pkg is a module or a package
    apt = mock.MagicMock()
    apt.__getattribute__ = mock.MagicMock(return_value='')
    module = AnsibleModule(argument_spec={'filename': {'default': None, 'type': 'str'}})
    module.get_bin_path = lambda binary: '/usr/bin/apt-get'

# Generated at 2022-06-20 21:21:03.026820
# Unit test for function install_python_apt
def test_install_python_apt():
    assert False



# Generated at 2022-06-20 21:21:10.436255
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({'check_mode': True})
    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule({'check_mode': False})
    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-20 21:21:17.474042
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # unit tests only run on linux - we can't run them on macOS or Windows
    if os.uname()[0] != 'Linux':
        return
    module = AnsibleModule({})
    sourceslist = SourcesList(module)
    sourceslist.save()
    sourceslist_content_before = str(sourceslist.dump())
    sourceslist.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sourceslist.save()
    sourceslist_content_after = str(sourceslist.dump())
    assert sourceslist_content_before != sourceslist_content_after
    sourceslist.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sourceslist.save()
    sourceslist_content_after_removal = str(sourceslist.dump())
    assert sourceslist

# Generated at 2022-06-20 21:21:28.838115
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
  sources = SourcesList(None)

  assert sources.new_repos == set()

# Generated at 2022-06-20 21:22:05.916854
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    test_module = ''
    test_sources_list = ''

    with open("unit_test_cases/UbuntuSourcesList/test_remove_source.txt", "r") as f:
        content = f.readlines()
        for i in range(len(content)):
            if i == 0:
                test_module = content[i].strip('\n')
            elif i == 1:
                test_sources_list = content[i].strip('\n')
            else:
                sources_list = UbuntuSourcesList(test_module)
                sources_list.remove_source(content[i].strip('\n'))
        assert (sources_list.dump() == ast.literal_eval(test_sources_list))


####################################################################
# Unit test cases for class UbuntuSourcesList
####################################################################



# Generated at 2022-06-20 21:22:17.601273
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    import os
    import shutil
    import json

    tmpdir = tempfile.mkdtemp()


# Generated at 2022-06-20 21:22:19.472457
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sourceslist = SourcesList(module)
    assert isinstance(sourceslist, SourcesList)



# Generated at 2022-06-20 21:22:20.911151
# Unit test for constructor of class InvalidSource
def test_InvalidSource():

    e = InvalidSource()
    assert e.message is None
    e = InvalidSource('test')
    assert e.message == 'test'


# Generated at 2022-06-20 21:22:25.767480
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass
    module = AnsibleModule(argument_spec={})
    assert revert_sources_list(module) == "Re-evaluate this function's return value once you know what return value you're expecting."



# Generated at 2022-06-20 21:22:33.858411
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    path = '/test/test_sources_list'
    module = AnsibleModule({})
    module.params['filename'] = path
    sl = SourcesList(module)
    s = 'deb http://example.org/ubuntu xenial main'
    sl.add_source(s)

    assert(sl.files[path] == [(0, True, True, 'deb http://example.org/ubuntu xenial main', '')])

    sl.save()

    assert(os.path.exists(path))

    os.remove(path)

if __name__ == '__main__':
    test_SourcesList_add_source()



# Generated at 2022-06-20 21:22:49.618047
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    '''
    Check if it removes valid source
    '''
    # input data
    tmpdir = tempfile.mkdtemp()
    file = os.path.join(tmpdir, "test.list")
    line = 'deb http://archive.ubuntu.com/ubuntu trusty main restricted universe'
    # test
    sl = SourcesList(None)
    sl.add_source(line, '#comment 1', file)
    sl.add_source(line, '#comment 2', file)
    sl.add_source(line, '#comment 3')
    sl.remove_source(line)
    # assert
    i = 0
    for filename, n, enabled, src, comment in sl:
        if src == line:
            i = i + 1
    assert i == 0, 'Expected 0, given %i' % i

# Generated at 2022-06-20 21:22:55.954285
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    try:
        import apt
        import apt_pkg
    except ImportError:
        import sys
        sys.exit(unittest.SkipTest('apt and apt_pkg modules are not available, skipping test'))

    class ModuleStub(object):
        def __init__(self):
            self.fail_json = self.error_exit
            self.params = dict(codename=distro.codename)

        def error_exit(self, msg):
            raise Exception(msg)

    us = UbuntuSourcesList(ModuleStub())
    us.load(us.default_file)

# Generated at 2022-06-20 21:22:57.835973
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    Unit test for method __iter__ of class SourcesList.
    '''
    assert False

# Generated at 2022-06-20 21:22:59.629613
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    x = InvalidSource('Invalid source error')
    assert x.message == 'Invalid source error'



# Generated at 2022-06-20 21:24:24.487885
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-20 21:24:35.846611
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class AnsibleModule():
        def __init__(self):
            self.params = {}
            self.exit_args = {}
            self.check_mode = False
            self.atomic_move = True
            self.fail_json = True
            self.run_command = True

        def fail_json(self, **kwargs):
            return 'test_fail_json'

        def get_bin_path(self, *args, **kwargs):
            return 'test_get_bin_path'

        def run_command(self, *args, **kwargs):
            return 0, 'test_run_command', ''

    obj = SourcesList(AnsibleModule())
    t1 = obj._SuggestFilename('deb http://archive.canonical.com/ubuntu trusty partner')

# Generated at 2022-06-20 21:24:46.926156
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Create dummy file
    tmp_path = tempfile.mkdtemp()
    sample_data = '''
# comment 1
deb http://us.archive.ubuntu.com/ubuntu/ trusty main restricted
# comment 2
deb http://us.archive.ubuntu.com/ubuntu/ trusty-updates main restricted
'''
    test_file_path = os.path.join(tmp_path, 'test.list')
    with open(test_file_path, "w") as text_file:
        text_file.write(sample_data)

    # Let's try to add some test sources
    sources = SourcesList(AnsibleModule(dict(file=test_file_path, repo='deb http://us.archive.ubuntu.com/ubuntu/ trusty-backports main restricted')))

    assert len(sources.files) == 1

# Generated at 2022-06-20 21:24:57.131754
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import os
    import tempfile
    import shutil

# Generated at 2022-06-20 21:25:02.329124
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={'debug': {'type': 'bool', 'default': False}})
    sources_list = SourcesList(module)
    assert sources_list
    assert sources_list.module



# Generated at 2022-06-20 21:25:03.786068
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    pass


# Generated at 2022-06-20 21:25:08.548192
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sl = UbuntuSourcesList(DummyModule(), None)
    assert sl.codename == 'trusty'
    assert sl.files == {}

    sl = UbuntuSourcesList(DummyModule(), None, codename='xenial')
    assert sl.codename == 'xenial'



# Generated at 2022-06-20 21:25:23.295827
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class MockModule:
        def __init__(self):
            self.check_mode = False
            self.return_value = 0
        def run_command(self, command, check_rc=True):
            return self.return_value, '', ''
    module = MockModule()
    add_ppa_signing_keys_callback = get_add_ppa_signing_key_callback(module)
    rc = add_ppa_signing_keys_callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'foo'])
    assert rc == 0



# Generated at 2022-06-20 21:25:34.232004
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    unit test for dump method of class SourcesList
    '''
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)

# Generated at 2022-06-20 21:25:44.806574
# Unit test for constructor of class SourcesList
def test_SourcesList():
    fd, fn = tempfile.mkstemp()

    os.write(fd, '# Comment\n# Comment\ndeb http://archive.canonical.com/ubuntu hardy partner\n'.encode('UTF-8'))
    os.close(fd)

    sources = SourcesList(fn)
    assert len(sources.files[fn]) == 2
    assert sources.files[fn][0] == (0, False, False, '', '')
    assert sources.files[fn][1] == (1, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')

    os.remove(fn)

