

# Generated at 2022-06-20 21:20:04.000084
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import ansible.module_utils.basic
    mod_args = dict(
        repo='deb http://archive.canonical.com/ubuntu trusty partner',
        state='present',
    )
    module = ansible.module_utils.basic.AnsibleModule(argument_spec=mod_args)
    sl = SourcesList(module)
    sl.add_source('deb http://archive.canonical.com/ubuntu trusty partner', file='/etc/ansible/sourceslist.d/archive_canonical_com_ubuntu_trusty_partner.list')
    sl.save()
    del sl
    sl = SourcesList(module)
    sl.modify('/etc/ansible/sourceslist.d/archive_canonical_com_ubuntu_trusty_partner.list', 0, comment='comment test')
   

# Generated at 2022-06-20 21:20:18.486296
# Unit test for function install_python_apt
def test_install_python_apt():
    class MockModule:
        def __init__(self):
            self.params = {'install_python_apt': True, 'autoremove': False}
            self.check_mode = False
        def fail_json(self, msg):
            self.msg = msg
        def get_bin_path(self, command):
            return '/usr/bin/%s' % command;
        def run_command(self, cmd, input_data=None, check_rc=False, cwd=None, environ_update=None, pre_su=None, su=None, su_user=None, su_pass=None, no_log=False):
            self.cmd = cmd
            return 0, '', ''

    m = MockModule()
    install_python_apt(m, 'python-apt')

# Generated at 2022-06-20 21:20:28.853898
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import shutil
    import tempfile

    class TestSourcesList:
        def __init__(self):
            self.module = None
            self.files = {}
            self.new_repos = set()
            self.default_file = tempfile.mkdtemp() + '/sources.list'
            os.mkdir(os.path.dirname(self.default_file))
            self.files[self.default_file] = []

        def __iter__(self):
            return iter(self)

        def _expand_path(self, filename):
            return os.path.join(os.path.dirname(self.default_file), filename)

        def _suggest_filename(self, line):
            return line


# Generated at 2022-06-20 21:20:30.118597
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    sourceslist = UbuntuSourcesList(None)
    assert sourceslist.add_ppa_signing_keys_callback is None
    assert sourceslist.codename == 'xenial'



# Generated at 2022-06-20 21:20:39.812429
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class ModuleMock(object):
        def __init__(self, fail_json_message):
            self.fail_json_message = fail_json_message

        def fail_json(self, message):
            raise ValueError(self.fail_json_message)

    def assertRaises(exception, func, *args, **kwargs):
        '''
        Assert that the given function does not raise exception.
        '''
        try:
            func(*args, **kwargs)
        except exception:
            return
        raise AssertionError("%s not raised" % type(exception))

    test_mod = ModuleMock("test")
    test_sources = SourcesList(test_mod)

# Generated at 2022-06-20 21:20:45.221896
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    testlist = ansible.module_utils.apt.SourcesList(AnsibleModule(argument_spec={}))

    for file, sources in testlist.files.items():
        for n, valid, enabled, source, comment in sources:
            assert valid
            assert enabled
            assert source
            assert comment


# Generated at 2022-06-20 21:20:56.122094
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, *cmd, **kwargs):
            self.run_command_calls.append(cmd)
            return 0, '', ''


# Generated at 2022-06-20 21:21:05.365792
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import ansible.module_utils.basic as module_utils
    module = module_utils.AnsibleModule(
        argument_spec=dict(
            id='',
            state='present',
            mode=None,
            update_cache=dict(default='no', aliases=['update-cache'], type='bool'),
            valid_exit_codes=dict(default=[0, 100], type='list')
        ),
    )
    module.params['repo']="deb http://archive.canonical.com/ubuntu trusty partner"
    module.params['action']='add'
    filename='/tmp/test.list'
    if os.path.exists(filename):
        os.remove(filename)
    sources = SourcesList(module)

# Generated at 2022-06-20 21:21:15.467945
# Unit test for function main

# Generated at 2022-06-20 21:21:28.206995
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import tempfile

    repo = 'deb http://download.example.com/ubuntu/dists/trusty trusty main'

    fd, tmp_path = tempfile.mkstemp(prefix="apt_repo_test_")

    f = os.fdopen(fd, 'w')
    f.write(repo + '\n')
    f.close()

    sl = SourcesList(None)
    sl.load(tmp_path)

    assert sl.files[tmp_path][0][0] == 0
    assert sl.files[tmp_path][0][1] == True
    assert sl.files[tmp_path][0][2] == True
    assert sl.files[tmp_path][0][3] == repo
    assert sl.files[tmp_path][0][4] == ''


# Generated at 2022-06-20 21:22:34.605384
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList(None)
    with tempfile.NamedTemporaryFile() as f:
        f.write(b'\n'.join([b'deb http://archive.canonical.com/ubuntu hardy partner',
                           b'#deb cdrom:[Ubuntu-Server 8.10 _Intrepid Ibex_ - Release i386 (20081029)]/ intrepid main restricted',
                           b'']))
        f.flush()
        sl.load(f.name)
        assert len(sl.files[f.name]) == 2
        sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
        assert len(sl.files[f.name]) == 1

# Generated at 2022-06-20 21:22:45.723323
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # define the mockup module arguments
    module = MagicMock()
    module.params = dict(
        state='present',
        name='ppa:myppa/myppa',
        filename='myppa.list'
    )

    # define valid values for the mockup codename and add them to the module
    codename = 'xenial'
    module.codename = codename

    # instantiate the class
    sl = UbuntuSourcesList(module)

    # check the codename has been set
    assert sl.codename == codename

    # check the file property is set to the expected value
    assert sl.default_file == '/etc/apt/sources.list'



# Generated at 2022-06-20 21:22:53.488238
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule(object):
        def fail_json(self, **kwargs):
            return kwargs

    def test_func(*args, **kwargs):
        return args, kwargs

    ubuntu = UbuntuSourcesList(TestModule(), add_ppa_signing_keys_callback=test_func)
    ubuntu.codename = 'trusty'
    ubuntu_copy = ubuntu.__deepcopy__()
    assert ubuntu.codename == ubuntu_copy.codename
    assert ubuntu.add_ppa_signing_keys_callback == ubuntu_copy.add_ppa_signing_keys_callback
    assert ubuntu.module is ubuntu.module
    ubuntu_copy.codename = 'xenial'
    ubuntu_copy.add_ppa_signing_keys_callback = None
    ubuntu

# Generated at 2022-06-20 21:22:58.872747
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Source list is malformed")
    except InvalidSource as exception:
        if exception.args[0] != "Source list is malformed":
            print("Unexpected exception message: '%s'" % exception.args[0])
        else:
            print("test_InvalidSource passed")

test_InvalidSource()



# Generated at 2022-06-20 21:23:04.779255
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class TestModule(object):

        def __init__(self, **kwargs):
            self.params = kwargs
            self.fail_json = lambda msg: msg
            self.run_command = lambda line, **kwargs: (0, 'data', '')
            self.atomic_move = lambda src, dest: None
            self.set_mode_if_different = lambda name, mode, changed: None

    sl = UbuntuSourcesList(
        TestModule(codename='codename', mode=None, filename='name'),
        add_ppa_signing_keys_callback=lambda command: None
    )
    assert isinstance(copy.deepcopy(sl), UbuntuSourcesList)



# Generated at 2022-06-20 21:23:16.755099
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import apt
    import os

    def create_sources_file(dir, name, contents):
        '''
        Create a sources file and add it to apt
        '''
        f = open(os.path.join(dir, name), 'w')
        f.write(contents)
        f.close()
        apt.apt_pkg.config.set('Dir::Etc::sourceparts', dir)

    def get_sources_file(dir):
        '''
        Collect all sources files from the directory and return a string
        '''
        contents = ''
        for file in os.listdir(dir):
            if not os.path.isfile(os.path.join(dir, file)):
                continue
            f = open(os.path.join(dir, file), 'r')
            contents += f.read

# Generated at 2022-06-20 21:23:25.457891
# Unit test for function main

# Generated at 2022-06-20 21:23:38.584008
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

# Generated at 2022-06-20 21:23:46.325637
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():

    #
    # Unit test for method __deepcopy__ of class UbuntuSourcesList
    #
    # This will call the __deepcopy__ method on a new instance of UbuntuSourcesList
    #
    # Args:
    #     module (dict): the AnsibleModule
    #     add_ppa_signing_keys_callback (dict): the add_ppa_signing_keys_callback
    #
    # Returns:
    #     UbuntuSourcesList: Returns the new instance of UbuntuSourcesList
    #
    pass

# Generated at 2022-06-20 21:23:56.956203
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    import shutil
    import textwrap

    def test_setup(content):
        testdir = tempfile.mkdtemp()
        fd, filename = tempfile.mkstemp(dir=testdir)
        f = os.fdopen(fd, 'w')
        try:
            f.write(content)
        finally:
            f.close()
        return testdir, filename

    def test_cleanup(testdir):
        shutil.rmtree(testdir)


# Generated at 2022-06-20 21:24:53.483825
# Unit test for function revert_sources_list
def test_revert_sources_list():
    # Ensure that adding a new file creates the file
    # and that reverting this to the previous state
    # removes the file
    new_filename = 'test_file'
    sourceslist = UbuntuSourcesList(None)
    sourceslist.add_source('test-source', file=new_filename)
    assert(new_filename in sourceslist.files)
    sourceslist.save()
    assert(os.path.exists(new_filename))
    sources_before = {new_filename: sourceslist.files[new_filename]}
    sourceslist.add_source('test-source2', file=new_filename)
    sourceslist.add_source('test-source3', file=new_filename)
    sourceslist.save()
    sources_after = sourceslist.files

# Generated at 2022-06-20 21:25:06.558827
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    sourceslist = SourcesList(module)
    assert module == sourceslist.module
    assert {} == sourceslist.files
    assert set() == sourceslist.new_repos
    assert '/etc/apt/sources.list' == sourceslist.default_file

    if PY3:
        iterator = sourceslist.__iter__()
        assert False is hasattr(iterator, '__next__')
        assert True is hasattr(iterator, '__iter__')
        assert False is hasattr(iterator, 'next')

    # __iter__() - real (not mocked) SourcesList
    # print(iter(SourcesList(module)))

# Generated at 2022-06-20 21:25:20.426658
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    line = 'deb https://cloud.google.com/apt cloud-sdk main'
    file_name = '/etc/apt/sources.list.d/google-cloud-sdk.list'
    source_list = SourcesList('test')
    source_list._add_valid_source(line, '', file=file_name)
    source_list.remove_source(line)
    for filename, n, enabled, src, comment in source_list:
        if source == src and enabled:
            raise AssertionError("Source list not correctly removed")


# Generated at 2022-06-20 21:25:30.230917
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''
    Test modify method for the class SourcesList.
    '''
    class TestModule(object):
        '''
        The class is mockup of AnsibleModule.
        '''
        def __init__(self):
            self.params = {}
            self.fail_json = self._fail_json
            self.atomic_move = self._atomic_move
            self.set_mode_if_different = self._set_mode_if_different
        def _fail_json(self, msg):
            self.msg = msg
        def _atomic_move(self, tmp_path, filename):
            '''
            Atomic move is noop for this test
            '''

# Generated at 2022-06-20 21:25:37.245938
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import tempfile
    import shutil
    import os

    def test_case(test):
        def add_ppa_signing_keys_callback(command):
            test['add_ppa_signing_keys_callback_args'].append(command)

        module = AnsibleModule(argument_spec={'codename': dict(default=None)})
        temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 21:25:46.505577
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import pytest

# Generated at 2022-06-20 21:25:53.228478
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = DummyModule()
    sl = SourcesList(module)
    sl.load('/dev/null')
    assert sl.files == {'/dev/null': []}
    sl.load('/dev/null')
    assert sl.files == {'/dev/null': []}
    sl.load('/dev/null')
    assert sl.files == {'/dev/null': []}


# Generated at 2022-06-20 21:26:01.118441
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sl = UbuntuSourcesList(mock.MagicMock())

    # Test1: A ppa line which is present in the list 'sl'
    line = 'ppa:foo/bar'
    sl._add_valid_source(line, '')
    sl.remove_source(line)
    for _, __, ___, valid_source, ____ in sl:
        if valid_source == line:
            assert False, "test_UbuntuSourcesList_remove_source1() failed"

    # Test2: A ppa line which is not present in the list 'sl'
    line = 'ppa:bar/baz'
    sl._add_valid_source(line, '')
    sl.remove_source(line)

# Generated at 2022-06-20 21:26:11.519529
# Unit test for method dump of class SourcesList

# Generated at 2022-06-20 21:26:17.458033
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = "python3-apt"
    module = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': True}})
    module.get_bin_path = lambda name: '/usr/bin/apt-get'
    module.run_command = lambda cmd: (0, '', '')
    install_python_apt(module, apt_pkg_name)



# Generated at 2022-06-20 21:28:36.473241
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    # Constructor of UbuntuSourcesList
    mod = AnsibleModule(argument_spec=dict())
    assert mod is not None
    ubuntu_sources_list = UbuntuSourcesList(mod)
    assert ubuntu_sources_list is not None


# Generated at 2022-06-20 21:28:46.204605
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.add_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources_list.save()
    sources_list.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sources_list.remove_source('deb-src http://archive.canonical.com/ubuntu hardy partner')
    sources_list.save()

# run unit test
test_SourcesList_add_source()

#
# Module execution
#



# Generated at 2022-06-20 21:28:50.486711
# Unit test for function main
def test_main():
    # Source: https://github.com/pallets/ansible/pull/45363
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 21:29:01.872627
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    l = [
        '# deb http://archive.ubuntu.com/ubuntu vivid main universe',
        'deb http://archive.ubuntu.com/ubuntu vivid main universe',
        'deb [trusted=yes] http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main',
        'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main',
        'deb http://ppa.launchpad.net/ansible/ansible',
        'deb http://localhost:8000/mytest/ubuntu trusty main',
        'deb [trusted=yes] http://localhost:8000/mytest/ubuntu trusty main'
    ]


# Generated at 2022-06-20 21:29:07.882343
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json = lambda x, **k: x

    class TestSourcesList(SourcesList):
        def __init__(self, module):
            self.module = module

    lines = [
        '# deb http://old.example.com/ old main',
        'deb http://example.com/ hardy main',
        '# deb http://example.com/ hardy main',
        'deb http://example.com/ hardy',
        '# deb http://example.com/ hardy',
    ]
    sources = TestSourcesList(TestModule())
    sources.files[None] = []
    for n, line in enumerate(lines):
        sources.files[None].append(sources._parse(line))
        sources

# Generated at 2022-06-20 21:29:22.595553
# Unit test for method save of class SourcesList
def test_SourcesList_save():

    # Create object
    sl = SourcesList()
    sl.files = {
        '/tmp/sources.list': [
            (0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', 'comment'),
            (1, False, False, 'deb-src http://archive.canonical.com/ubuntu hardy partner',),
            (2, True, True, 'deb http://archive.canonical.com/ubuntu xenial partner',),
        ],
    }

    # Run method to test
    sl.save()

    # Check for results
    with open('/tmp/sources.list', 'r') as f:
        lines = list(f.readlines())
        assert len(lines) == 2

# Generated at 2022-06-20 21:29:29.537373
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sl = SourcesList(module)
    source = "deb-src http://archive.canonical.com/ubuntu hardy partner"
    sl.add_source(source)
    expected = 1
    result = len(sl.files)
    assert expected == result

    sl.remove_source(source)
    expected = 0
    result = len(sl.files)
    assert expected == result