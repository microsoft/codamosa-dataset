

# Generated at 2022-06-20 21:19:58.122375
# Unit test for constructor of class SourcesList
def test_SourcesList():
    os.environ['APT_CONFIG'] = 'test/apt.conf.template'

    s = SourcesList(None)
    assert s._apt_cfg_file('Dir::Etc::sourceparts') == 'test/sources.list.d'
    assert s._apt_cfg_dir('Dir::Etc::sourcelist') == 'test/'

    for file, valid, enabled, source, comment in s:
        assert valid

    os.environ['APT_CONFIG'] = ''



# Generated at 2022-06-20 21:20:04.552830
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    line = "deb http://mirrors.digitalocean.com/ubuntu/ xenial main restricted"
    sl = SourcesList(None)
    sl.files['/etc/apt/sources.list'] = [(1, True, True, line, '# disabled on upgrade to bionic')]
    sl.modify('/etc/apt/sources.list', 1, enabled = True)
    assert sl.files['/etc/apt/sources.list'][1][2] == True


# Generated at 2022-06-20 21:20:12.905292
# Unit test for function main
def test_main():
    import ast


# Generated at 2022-06-20 21:20:24.199502
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList('/dir-that-does-not-exist')
    file = '/dir-that-does-not-exist/sources.list'
    with open(file, 'w') as f:
        f.write('# comment\n\n')
        f.write('http://example.com/ubuntu/ trusty main\n')
        f.write('deb-src http://example.com/ubuntu/ trusty main\n')
        f.write('deb-src [arch=amd64] http://example.com/ubuntu/ trusty main\n')
        f.write('# deb http://example.com/ubuntu/ trusty main\n')
        f.write('deb http://example.com/ubuntu/ trusty main # comment\n')
    sl.load(file)

# Generated at 2022-06-20 21:20:32.082736
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(
        argument_spec=dict(
            codename={}
        )
    )
    test_cases = [
        dict(
            line='deb http://ppa.launchpad.net/ansible-test/ppa/ubuntu bionic main',
            expected_source='deb http://ppa.launchpad.net/ansible-test/ppa/ubuntu bionic main'
        ),
        dict(
            line='ppa:ansible-test/ppa',
            expected_source='deb http://ppa.launchpad.net/ansible-test/ppa/ubuntu bionic main'
        )
    ]
    for test_case in test_cases:
        sources_list = UbuntuSourcesList(module)
        sources_list.add_source(test_case['line'])

# Generated at 2022-06-20 21:20:44.619025
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec={})
    ss = SourcesList(module)
    assert ss.dump() == {}
    ss.files['/etc/apt/sources.list'] = [(0, True, True, 'deb http://archive.canonical.com/ubuntu hardy partner', '')]
    assert ss.dump() == {'/etc/apt/sources.list': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}
    ss.files['/etc/apt/sources.list.d/my.list'] = [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')]

# Generated at 2022-06-20 21:20:49.018692
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sourcesList = SourcesList(None)
    sourcesList.files = {
        '/etc/apt/sources.list.d/mypackages.list': [
            (0, True, True, 'deb http://source.org/debian trusty main', ''),
        ]
    }
    line = 'deb http://source.org/debian trusty main'
    sourcesList.remove_source(line)
    assert sourcesList.files == {
        '/etc/apt/sources.list.d/mypackages.list': []
    }

# Generated at 2022-06-20 21:20:51.594082
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    e = InvalidSource('Exception msg')
    assert str(e) == 'Exception msg'



# Generated at 2022-06-20 21:21:01.761452
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    c = SourcesList(None)
    c.files = {
        'default_file': [
            (0, True, False, 'deb http://example.org/deb default main', ''),
            (1, True, False, 'deb-src http://example.org/deb default main', ''),
            (2, True, True, 'deb http://example.org/deb default main', ''),
            (3, False, False, 'deb http://example.org/deb default main', '# comment'),
            (4, True, True, 'deb http://example.org/deb default main', '# comment'),
            (5, True, True, 'deb http://example.org/deb default main', ''),
            (6, True, True, 'deb http://example.org/deb default main', ''),
        ]
    }

# Generated at 2022-06-20 21:21:13.029665
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import unittest
    import mock

    # Mocking the module instance, so we don't produce temp files
    with mock.patch.object(SourcesList, 'load'):
        with mock.patch.object(SourcesList, 'save'):
            sl = SourcesList(mock.MagicMock())

    # Mocking SourcesList._apt_cfg_dir and _apt_cfg_file, so we can use hardcoded paths
    with mock.patch.object(SourcesList, '_apt_cfg_dir') as mock_cfg_dir:
        with mock.patch.object(SourcesList, '_apt_cfg_file') as mock_cfg_file:
            mock_cfg_dir.return_value = os.path.dirname(__file__)

# Generated at 2022-06-20 21:21:51.673404
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock as mock
    import tempfile


# Generated at 2022-06-20 21:21:55.915627
# Unit test for function main

# Generated at 2022-06-20 21:21:58.217505
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    """Make sure we do not run in check_mode"""
    module = MockAnsibleModule()
    module.params = {'check_mode': False}
    assert get_add_ppa_signing_key_callback(module) is not None
    module.params = {'check_mode': True}
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-20 21:22:09.811261
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    assert UbuntuSourcesList.LP_API == 'https://launchpad.net/api/1.0/~%s/+archive/%s'
    assert UbuntuSourcesList.__name__ == 'UbuntuSourcesList'

    # params of module
    module_params = {
        'filename': '_some_file_name',
        'mode': '0644',
        'codename': 'test_codename'
    }

    # magicmock of module
    module = MagicMock()
    module.params = module_params

    # create test object
    sl = UbuntuSourcesList(module)
    assert isinstance(sl, UbuntuSourcesList)
    assert sl.codename == 'test_codename'
    assert sl.add_ppa_signing_keys_callback is None

# Generated at 2022-06-20 21:22:20.346777
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    def _fetch_url(module, url, headers=None):
        return None, dict(status=200)
    def _fail_json_called(msg):
        raise Exception(msg)
    def _run_command(*args, **kwargs):
        return 0, '', ''

    import sys
    import traceback

# Generated at 2022-06-20 21:22:32.985272
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    line_enabled = 'deb http://archive.canonical.com/ubuntu xenial partner'
    line_disabled = '# %s' % line_enabled
    comment = 'comment for test'
    file = '/test_SourcesList_modify'
    # init object
    sourceslist = SourcesList(None)
    # add enabled line with comment
    sourceslist.add_source(line_enabled, comment, file)
    # check that added
    sources = sourceslist.dump()
    assert sources[file] == '%s # %s\n' % (line_enabled, comment)
    # re-enable line
    enabled = True
    sourceslist.modify(file, 0, enabled, source=None, comment=None)
    # check that enabled
    sources = sourceslist.dump()

# Generated at 2022-06-20 21:22:45.529143
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    m = {}
    def u(s):
        return to_unicode(s)
    m['params'] = {'codename': u('test-codename')}
    m['run_command'] = lambda *a, **kw: False
    src_file = m['params']['codename'] + u('-updates')
    m['debug'] = lambda *a, **kw: None
    m['fail_json'] = lambda *a, **kw: None
    m['get_bin_path'] = lambda *a, **kw: u('/bin')
    r = UbuntuSourcesList(m, None)
    r.files[u('/etc/apt/sources.list.d/%s.list' % src_file)] = []

# Generated at 2022-06-20 21:22:58.593038
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(
        argument_spec={
            'filename': {'type': 'str'},
        },
    )
    d = module.tmpdir
    open(os.path.join(d, 'file1'), 'w').write('somefile')
    open(os.path.join(d, 'file2'), 'w').write('somefile')
    open(os.path.join(d, 'file3'), 'w').write('somefile')
    sl = SourcesList(module, d)

    sl.files['file1'] = [[0, True, True, 'somefile', '']]
    sl.files['file2'] = [[0, True, True, 'somefile', '']]
    sl.files['file3'] = [[0, True, True, 'somefile', '']]

# Generated at 2022-06-20 21:23:09.800291
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    how_many_tests = 20
    for test_n in range(how_many_tests):
        expected = dict()
        sl = SourcesList({'get_bin_path' : lambda x: ''})
        for n in range(random.randint(1, 3)):
            filename = 'test_%s_%s.list' % (test_n, n)
            expected[filename] = ''
            sources = []
            for m in range(random.randint(1, 3)):
                source_enabled = random.choice([True, False])

# Generated at 2022-06-20 21:23:12.374685
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource("test")
    assert exc.message == "test"



# Generated at 2022-06-20 21:25:15.257161
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    apt_pkg.config.set("Dir::Etc::sourcelist", os.devnull)
    sources = SourcesList(AnsibleModule(argument_spec={}))
    sources.files = {"/dev/null": [(0, True, True, "deb http://example.com/ubuntu xenial main", "")]}
    sources.save()



# Generated at 2022-06-20 21:25:24.879601
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={'state': dict(type='str', choices=['absent', 'present'])})
    sources = SourcesList(module)
    sources.add_source('deb http://packages.example.com/debian/ stable main ', 'Example')
    sources.add_source('deb-src http://packages.example.com/debian/ stable main')
    assert 'deb http://packages.example.com/debian/ stable main # Example\n' in sources.dump()['/etc/apt/sources.list']
    assert 'deb-src http://packages.example.com/debian/ stable main\n' in sources.dump()['/etc/apt/sources.list']


# Generated at 2022-06-20 21:25:41.174781
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    import sys
    import os
    import shutil
    from tempfile import mkdtemp

    import ansible
    from ansible.module_utils.basic import AnsibleModule

    from ansible.module_utils.apt import _get_dist
    from ansible.module_utils.apt import _get_repo_files
    from ansible.module_utils.apt import _get_version
    from ansible.module_utils.apt import _version_compare
    from ansible.module_utils.apt import add_repo
    from ansible.module_utils.apt import remove_repo
    from ansible.module_utils.apt import get_repo_filename
    from ansible.module_utils.apt import get_sources_list_file


# Generated at 2022-06-20 21:25:53.969516
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import os
    import tempfile
    from ansible.module_utils.common.system import SystemInfo


# Generated at 2022-06-20 21:25:59.677364
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sl = UbuntuSourcesList(None)
    sl._add_valid_source('ppa:fithisux/ppa', 'comment', '/somewhere/sources.list')
    sl._add_valid_source('ppa:fithisux/ppa', 'comment', '/somewhere/sources.list')
    sl.remove_source('ppa:fithisux/ppa')

    assert len(sl.files) == 0



# Generated at 2022-06-20 21:26:08.937497
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)

# Generated at 2022-06-20 21:26:11.716547
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(
        argument_spec=dict(
            test=dict(required=True, type='bool'),
        )
    )

    assert get_add_ppa_signing_key_callback(module) is None

    module = AnsibleModule(
        argument_spec=dict(
            test=dict(required=True, type='bool'),
        ),
        bypass_checks=True
    )

    assert get_add_ppa_signing_key_callback(module) is not None



# Generated at 2022-06-20 21:26:15.923410
# Unit test for function main
def test_main():
    assert HAVE_PYTHON_APT

# Generated at 2022-06-20 21:26:22.968936
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.respawn import _model_params_for_test
    module = AnsibleModule(**_model_params_for_test())
    filename = tempfile.mktemp()

# Generated at 2022-06-20 21:26:31.590102
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import tempfile
    import shutil
    import copy

    # We are going to modify default sources.list.
    # So let's save it's name and content
    default_file = os.path.abspath(os.path.join(tempfile.mkdtemp(prefix='ansible_test_'), 'sources.list'))
    with open(default_file, 'w') as f:
        f.write("# This is file for testing\n")
        f.write("deb http://first.com/debian squeeze main\n")
        f.write("# disabled\n")
        f.write("#deb http://second.com/debian squeeze main\n")
        f.write("deb-src http://third.com/debian squeeze main\n")

    # Create and populate object

# Generated at 2022-06-20 21:28:27.548528
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    if not os.access("/etc/apt/sources.list", os.R_OK):
        module.fail_json("Unit test for class SourcesList failed, sources.list not found.")
    sources = SourcesList(module)
    sources.load("/etc/apt/sources.list")
    if sources.files is None:
        module.fail_json("Unit test for class SourcesList failed, files is none.")
    if not isinstance(sources.files, dict) or len(sources.files) == 0:
        module.fail_json("Unit test for class SourcesList failed, files is empty.")
    if sources.default_file != "/etc/apt/sources.list":
        module.fail_json("Unit test for class SourcesList failed, default_file is empty.")
    module.exit

# Generated at 2022-06-20 21:28:29.366251
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    ubuntu_sources_list = UbuntuSourcesList(module)
    ubuntu_sources_list.load('tests/unittests/test_ubuntu_sources.list')
    ubuntu_sources_list.save()

# Unit tests for add_source

# Generated at 2022-06-20 21:28:34.923855
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({})
    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=None)
    assert isinstance(usl, UbuntuSourcesList)


# Generated at 2022-06-20 21:28:46.894685
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    import ansible.module_utils.ansible_release as ar
    import ansible.module_utils.apt_repository as apt_repository

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        add_file_common_args=True,
    )

    sources_list = apt_repository.SourcesList(module)

    # test with ppa repo
    source = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'
    source_names_paths = [('trusty', 'ansible'), ('trusty', 'ansible-precise')]


# Generated at 2022-06-20 21:28:51.798294
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    from ansible.module_utils import basic
    from ansible.module_utils.common.fetch import fetch_url_use_proxy
    from ansible.module_utils.urls import fetch_url
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import PY3

    module = basic.AnsibleModule
    module.get_bin_path = lambda module, bin: bin
    module.run_command = lambda module, command: (0, '', '')
    module.atomic_move = lambda src, dest: None
    module.params = dict(repo='deb http://archive.canonical.com/ubuntu hardy partner')
    module.check_mode = False

    # add a source and test the result
    sources_list = SourcesList(module)
    sources_list

# Generated at 2022-06-20 21:29:01.174418
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    line = "manual_addition"
    test_file = "/tmp/ansible_test_SourcesList_modify"
    with open(test_file, 'w') as f:
        f.write(line)
    sl = SourcesList(None)
    sl.files[test_file] = [(1, True, False, line, '')]
    sl.modify(test_file, 1, comment="comment", source="source")
    assert sl.files[test_file][0][1:] == (True, True, 'source', 'comment')
    # no source in source list will not cause exception
    sl.modify(test_file, 2, comment="comment", source="source")



# Generated at 2022-06-20 21:29:11.453414
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict(line='', mode='', filename='', state='present'))
    u = UbuntuSourcesList(module)

# Generated at 2022-06-20 21:29:23.871730
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    lines = ['',
             '# deb http://mirror1/ubuntu trusty main',
             '   deb http://mirror2/ubuntu trusty main',
             '# deb http://mirror3/ubuntu trusty main',
             '# deb http://mirror1/ubuntu trusty main',
             'deb http://mirror2/ubuntu trusty main',
             '']
    module = AnsibleModule(argument_spec={'state': {'type': 'str', 'required': True, 'choices': ['present', 'absent']},
                                           'repo': {'type': 'str', 'required': True}},
                           supports_check_mode=True)

    # Create temporary file and populate it with lines
    (fd, file) = tempfile.mkstemp()