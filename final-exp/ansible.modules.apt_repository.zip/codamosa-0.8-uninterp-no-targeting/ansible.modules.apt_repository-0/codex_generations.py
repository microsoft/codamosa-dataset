

# Generated at 2022-06-20 21:20:11.045867
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sources_before = {
        "/etc/apt/sources.list": "hi",
        "/etc/apt/sources.list.d/ansible.list": "there"
    }
    sources_after = {
        "/etc/apt/sources.list": "hi",
        "/etc/apt/sources.list.d/ansible.list": "there",
        "/etc/apt/sources.list.d/ansible2.list": "there2"
    }
    sourceslist_before = SourcesList(dict())
    sourceslist_before.files = sources_before
    revert_sources_list(sources_before, sources_after, sourceslist_before)
    assert sourceslist_before.files == sources_before



# Generated at 2022-06-20 21:20:21.452405
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class TestModule(object):
        def __init__(self):
            self.run_command_called = False
            self.check_mode = False

        def fail_json(self, **kwargs):
            raise AssertionError("fail_json was called! kwargs: %r" % kwargs)

        def run_command(self, command, check_rc=False):
            self.run_command_called = True

    test_module = TestModule()
    result = get_add_ppa_signing_key_callback(test_module)
    assert result is None

    test_module.check_mode = True
    result = get_add_ppa_signing_key_callback(test_module)
    assert result is None

    test_module.check_mode = False
    result = get_add_ppa_sign

# Generated at 2022-06-20 21:20:25.921464
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_source_test1 = InvalidSource('test1')
    if isinstance(invalid_source_test1, InvalidSource):
        pass

# Returns a list of all sources in sources.list and sources.list.d/*.list
# This class is unit tested by test_get_sources_list

# Generated at 2022-06-20 21:20:30.067359
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, supports_check_mode=True)
    sources = SourcesList(module)
    for filename, sources in sources.files.items():
        for n, valid, enabled, source, comment in sources:
            assert source is not None, filename


# Generated at 2022-06-20 21:20:35.673275
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule(object):
        def __init__(self):
            self.module = self
            self.params = {}

        def fail_json(self, msg):
            raise AssertionError(msg)

        def run_command(self, command, check_rc=True):
            # NOTE: mock of apt-key export command
            return 0, '', ''

        def atomic_move(self, src, dest):
            return True

    module = MockModule()

    # empty repository list
    sources_list = UbuntuSourcesList(module)
    assert sources_list.repos_urls == []

    # add repositoryLine
    sources_list.add_source('ppa:ansible/ansible')

# Generated at 2022-06-20 21:20:39.055941
# Unit test for function install_python_apt
def test_install_python_apt():
    class DummyModule:
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, command):
            return '/usr/bin/apt-get'

        def run_command(self, command):
            return 0, '', ''

    install_python_apt(DummyModule(), 'python-apt')
    install_python_apt(DummyModule(), 'python3-apt')


# -------------------------------------------------------------------------------------------------
# Helper functions
#
#

# Generated at 2022-06-20 21:20:45.466877
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = _create_fake_module()
    sourceslist = SourcesList(module)
    test_output = {'file': 'deb http://archive.canonical.com/ubuntu hardy partner\n'}
    test_input = 'deb http://archive.canonical.com/ubuntu hardy partner\n'
    sourceslist.load('file')
    assert sourceslist.dump() == test_output


# Generated at 2022-06-20 21:20:56.130581
# Unit test for function revert_sources_list
def test_revert_sources_list():
    print("Testing function: revert_sources_list")
    import os
    import tempfile
    import shutil
    test_dir = tempfile.mkdtemp()
    test_file_path = os.path.join(test_dir, 'test.list')
    test_file_path2 = os.path.join(test_dir, 'test2.list')
    print("Testing revert_sources_list with a non-existent file.")
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    mod = SourcesList(module)
    mod.files = {test_file_path: None}
    mod.save()
    assert(os.path.exists(test_file_path) == False)


# Generated at 2022-06-20 21:21:07.890056
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO

    f1 = StringIO()
    f1.write('''
# deb http://ftp.ubuntu.com/ubuntu/ wily main multiverse restricted
deb [arch=amd64] http://ftp.ubuntu.com/ubuntu/ wily main multiverse restricted
# deb-src http://ftp.ubuntu.com/ubuntu/ wily main multiverse restricted
# deb http://security.ubuntu.com/ubuntu/ wily-security main multiverse restricted
''')
    f1.seek(0)

    f2 = StringIO()

# Generated at 2022-06-20 21:21:15.465020
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(
        argument_spec=dict(
            apt_pkg_name=dict(type='str', required=True),
        )
    )
    apt_pkg_name = module.params.get('apt_pkg_name')
    install_python_apt(module, apt_pkg_name)
# /End unit test for function install_python_apt



# Generated at 2022-06-20 21:22:12.841022
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    sl = SourcesList.__new__(SourcesList)
    # test case 1
    line_input_1 = 'deb [arch=amd64] http://deb.debian.org/debian stretch-backports main'
    source_1 = 'deb [arch=amd64] http://deb.debian.org/debian stretch-backports main'

# Generated at 2022-06-20 21:22:23.603315
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule('', '')
    sourcelist = SourcesList(module)
    sourcelist.load('tests/files/source.list')
    sourcelist.modify('tests/files/source.list', 0, enabled=False)
    assert sourcelist.files['tests/files/source.list'][0][1] == False
    sourcelist.modify('tests/files/source.list', 1, source='deb http://mirror.linux.org/archive/debian squeeze main contrib non-free # Disabled for testing\n')
    assert sourcelist.files['tests/files/source.list'][1][3] == 'deb http://mirror.linux.org/archive/debian squeeze main contrib non-free'
    sourcelist.modify('tests/files/source.list', 2, comment=" # Disabled for testing\n")


# Generated at 2022-06-20 21:22:34.177192
# Unit test for function install_python_apt
def test_install_python_apt():
    import ansible
    import shutil
    import tempfile

    if PY3:
        module = ansible.modules.platform.linux.apt_repository.AnsibleModule(argument_spec={
            'install_python_apt': dict(type=bool, default=True),
            'repo': dict(required=True),
            'get_bin_path': dict(type=dict, default=dict(mock_bin_path={'apt-get': '/usr/bin/apt-get'})),
            'run_command': dict(type=dict, default=dict(mock_run_command={
                '/usr/bin/apt-get update': '0',
                '/usr/bin/apt-get install -y -q python3-apt': '0'
            })),
        })

# Generated at 2022-06-20 21:22:35.931176
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # FIXME: Add tests for __deepcopy__
    pass

# Generated at 2022-06-20 21:22:48.262403
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    class ModuleMock(object):
        def __init__(self, noop):
            self.check_mode = noop
            self.results = []
            self.args = []

        def run_command(self, *args, **kwargs):
            self.args.append(args)
            self.results.append(0)
            return 0, 'test', 'test'

    module = ModuleMock(False)

    callback = get_add_ppa_signing_key_callback(module)
    callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'ABCD'])
    assert len(module.results) == 1
    assert module.results[0] == 0


# Generated at 2022-06-20 21:22:52.352477
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule({
        '_ansible_check_mode': True,
    })
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    module = AnsibleModule({
        '_ansible_check_mode': False,
    })
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is not None



# Generated at 2022-06-20 21:22:53.667009
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = DummyAnsibleModule()
    sources = UbuntuSourcesList(module)
    for c in sources:
        pass



# Generated at 2022-06-20 21:23:06.304654
# Unit test for function revert_sources_list
def test_revert_sources_list():

    temp_dir = tempfile.mkdtemp()

    # Revert with no existing files
    sources_before = {}
    sources_after = {}
    sourceslist_before = SourcesList(dict(filename=temp_dir))
    revert_sources_list(sources_before, sources_after, sourceslist_before)

    # Revert with files created but unchanged
    sources_before = {}
    sources_after = {}
    sources_after['/etc/apt/sources.list.d/foo.bar.list'] = 'deb http://example.com/foo trusty bar'
    sources_after['/etc/apt/sources.list'] = 'deb http://example.com/bar foobar\n'
    sourceslist_before = SourcesList(dict(filename=temp_dir))
    sourceslist_before.files = sources_after

# Generated at 2022-06-20 21:23:10.063421
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    msg = 'Unit test of ansible.module_utils.apt_repository.InvalidSource'
    try:
        raise InvalidSource(msg)
    except InvalidSource as e:
        assert to_native(e) == msg



# Generated at 2022-06-20 21:23:20.567385
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    variable = ['deb http://www.apache.org/debian etch-backports main']
    test_module = AnsibleModule(sources_content=variable, filename='/etc/apt/sources.list')  # testmodule
    test_object = SourcesList(test_module)  # instance of SourcesList
    result = test_object._parse(line=variable, raise_if_invalid_or_disabled=True)
    test_object._remove_valid_source(source=result[2])
    assert test_object.dump() == {'/etc/apt/sources.list': ''}
    assert test_module.params['sources_content'] == []


# Generated at 2022-06-20 21:23:57.807249
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils.common.collections import ImmutableDict

    ubuntu_sources_list = UbuntuSourcesList(module=ImmutableDict())

    ubuntu_sources_list.module.params = dict(
        filename='',
        update_cache=True,
        validate_certs=True,
        state='present',
        mode=None,
        sources=['dummy_source_string'],
        codename=None,
    )

    ubuntu_sources_list_copy = copy.deepcopy(ubuntu_sources_list)

    assert ubuntu_sources_list.module == ubuntu_sources_list_copy.module
    assert ubuntu_sources_list.codename == ubuntu_sources_list_copy.codename

# Generated at 2022-06-20 21:23:58.726999
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-20 21:24:02.059570
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_source = InvalidSource("This is not a valid source")
    assert str(invalid_source) == "This is not a valid source"
    assert invalid_source.args == ("This is not a valid source",)
# End of unit test


# Generated at 2022-06-20 21:24:14.248552
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    m = AnsibleModule(argument_spec={})
    sl = UbuntuSourcesList(m)
    sl.files = {'a': [(0, True, True, 'deb http://ppa.launchpad.net/a/b/ubuntu c main', ''), (1, True, True, 'deb http://ppa.launchpad.net/b/b/ubuntu c main', '')]}

    sl.remove_source('ppa:c')

    assert sl.files == {'a': [(0, True, True, 'deb http://ppa.launchpad.net/a/b/ubuntu c main', ''), (1, True, True, 'deb http://ppa.launchpad.net/b/b/ubuntu c main', '')]}

    sl.remove_source('ppa:b/b')


# Generated at 2022-06-20 21:24:25.714291
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():

    # In case of multi-line source, remove_source() is supposed to remove all instances of it

    sl = SourcesList('apt')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.add_source('deb http://archive.canonical.com/ubuntu hardy partner')
    sl.remove_source('deb http://archive.canonical.com/ubuntu hardy partner')
    test_match = False
    for n, valid, enabled, source, comment in sl:
        if source == 'deb http://archive.canonical.com/ubuntu hardy partner':
            test_match = True

# Generated at 2022-06-20 21:24:36.740685
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    '''
    Unit test for method load of class SourcesList
    '''
    module = AnsibleModule('')

    sources = SourcesList(module)
    sources.load("/dev/null")
    assert sources.files == {}

    # add test file
    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)
    f = open(tmp_path, 'w')
    f.write("deb http://ftp.ca.debian.org/debian/ jessie main\n")
    f.write("# deb http://ftp.us.debian.org/debian/ jessie-updates main\n")
    f.close()
    sources.files = {}
    sources.load(tmp_path)

# Generated at 2022-06-20 21:24:47.837434
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import ansible.module_utils.facts.collector
    from ansible.module_utils._text import to_bytes

    def _run_ansible_module(module, *args):
        module._ANSIBLE_ARGS = [module._ANSIBLE_ARGS[0], to_bytes(json.dumps(args))]
        # Load collector
        if '_fact_cache' not in module.__dict__:
            facts_module = ansible.module_utils.facts.collector.get_module_facts()
            module.__dict__.update(facts_module.__dict__['_fact_cache'])

        # Load module
        module.no_log_values.update(['stdout', 'stderr', 'args', 'data', 'invocation'])

# Generated at 2022-06-20 21:24:52.674717
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    usl = UbuntuSourcesList(module)
    usl.add_source("ppa:username/ppa")
    usl.save()
    usl2 = copy.deepcopy(usl)
    assert usl.files == usl2.files




# Generated at 2022-06-20 21:24:58.723241
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.params['codename'] = 'xenial'
    s = UbuntuSourcesList(module)
    # test with ppa
    s.add_source("ppa:foo/bar")
    assert "deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main" in s.repos_urls
    # test with non-ppa
    s.add_source("deb http://httpredir.debian.org/debian jessie-backports main")
    assert "deb http://httpredir.debian.org/debian jessie-backports main" in s.repos_urls


# Generated at 2022-06-20 21:25:02.291548
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    assert get_add_ppa_signing_key_callback(module) is None



# Generated at 2022-06-20 21:26:32.164214
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('string')
    except InvalidSource as e:
        assert e.args[0] == 'string'



# Generated at 2022-06-20 21:26:38.517618
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    assert ''.join(SourcesList(None).files['']) == ''
    sourceslist = SourcesList(None)
    source = 'deb http://ftp.se.debian.org/debian/ jessie main'
    sourceslist.add_source(source)
    assert ''.join(sourceslist.files['']) == ''.join((source, '\n'))
    assert sourceslist.dump() == {'': source + '\n'}
    sourceslist = SourcesList(None)
    sourceslist.add_source('deb http://ftp.se.debian.org/debian/ jessie main', comment='Jessie')
    assert ''.join(sourceslist.files['']) == 'deb http://ftp.se.debian.org/debian/ jessie main # Jessie\n'
    assert sourceslist.dump()

# Generated at 2022-06-20 21:26:46.815464
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    o = SourcesList(module)

    o.load('tests/sample_sources.list')
    dumpstruct = o.dump()


# Generated at 2022-06-20 21:26:55.968953
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        import ansible_collections.notstdlib.moveitallout.plugins.module_utils.apt_pkg as apt_pkg_wrapper
        import ansible_collections.notstdlib.moveitallout.plugins.module_utils.distro as distro_wrapper
        import ansible_collections.notstdlib.moveitallout.plugins.module_utils.urls as urls_wrapper
        import ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.system as system_wrapper
        import ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts as facts_wrapper

# Generated at 2022-06-20 21:27:06.450150
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    '''
    Test UbuntuSourcesList.__deepcopy__()
    '''

    from ansible.module_utils import _AnsibleModule, ansible_module_runner
    from ansible.module_utils._text import to_bytes

    module = _AnsibleModule(
        argument_spec=dict(
            codename=dict(type='str', default='trusty'),
        )
    )

    def add_ppa_signing_keys_callback(command):
        pass

    sl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_ppa_signing_keys_callback)
    sl.files = {'test_file.list': [('test_line', True, True, 'test_source', 'test_comment')]}

    # test the method

# Generated at 2022-06-20 21:27:13.405630
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # Read input:
    test_module = '''
{
    "ANSIBLE_MODULE_ARGS": {
        "codename": "bionic",
        "mode": "0440"
    },
    "module": "apt_repository"
}
'''
    test_module = AnsibleModule(json.loads(test_module))
    test_add_ppa_signing_keys_callback = None
    test_obj = UbuntuSourcesList(test_module, test_add_ppa_signing_keys_callback)

    # Run method:
    actual_result = test_obj.__deepcopy__()

    # Check result:
    assert isinstance(actual_result, UbuntuSourcesList)
    assert actual_result.module is test_module

# Generated at 2022-06-20 21:27:14.005172
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-20 21:27:24.786172
# Unit test for function install_python_apt
def test_install_python_apt():
    import sys
    import os

    def run_command(args):
        print("Running: %s" % args)
        return (0, "", "")

    def get_bin_path(args):
        if args == "apt-get":
            return "/usr/bin/apt-get"
        return ""

    class AnsibleModule:
        def __init__(self):
            self.check_mode = False
            self.params = {"install_python_apt": "true"}

        def run_command(self, args):
            return run_command(args)

        def get_bin_path(self, args):
            return get_bin_path(args)

        def fail_json(self, msg):
            print(str(msg))
            sys.exit(1)

    module = AnsibleModule()
    install_

# Generated at 2022-06-20 21:27:33.011100
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = Mock()
    module.params = {'filename': None, 'codename': 'xenial', 'mode': None}
    module.run_command = Mock(return_value=(0, "", ""))
    module.atomic_move = Mock()
    module.set_mode_if_different = Mock()
    module.fail_json = Mock()
    module.fail_json = Mock()
    sources = UbuntuSourcesList(module)
    assert sources.codename == 'xenial'

# Generated at 2022-06-20 21:27:42.983241
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Create fake module
    module = AnsibleModule(argument_spec={})
    # Define test scenarios