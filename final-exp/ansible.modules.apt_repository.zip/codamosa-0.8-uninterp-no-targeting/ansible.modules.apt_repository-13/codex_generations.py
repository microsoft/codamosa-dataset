

# Generated at 2022-06-20 21:20:02.660773
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.released.ubuntu import distro as ubuntu_distro

    module = AnsibleModule(argument_spec={
        'codename': dict(default='xenial'),
    })

    # check for ansible 2.8 where check_mode is a class method
    orig_check_mode = module._check_mode

    try:
        if 'check_mode' in dir(module):
            module._check_mode = True

        sourceslist = get_add_ppa_signing_key_callback(module)
        assert sourceslist is None

        module._check_mode = False
        sourceslist = get_add_ppa_signing_key_callback(module)
        assert sourceslist is not None
    finally:
        module._check_mode = orig_check_mode

# Generated at 2022-06-20 21:20:11.751346
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec=dict(
        repo=dict(required=True),
        state=dict(required=True, choices=['absent', 'present']),
        mode=dict(default=None, type='int'),
    ))

    class SourcesList_test(SourcesList):
        def __init__(self, module):
            self.module = module
            self.files = {}  # group sources by file
            # Repositories that we're adding -- used to implement mode param
            self.new_repos = set()
            self.default_file = 'test'

            # read sources.list if it exists

            # read sources.list.d

        def load(self, file):
            group = []
            f = open(file, 'r')
            for n, line in enumerate(f):
                valid,

# Generated at 2022-06-20 21:20:22.543483
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Unit test for function get_add_ppa_signing_key_callback
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    ubuntu_sources_list = UbuntuSourcesList(module)
    ppa_callback_1 = get_add_ppa_signing_key_callback(module)
    # Should return None because it is check mode
    assert ppa_callback_1 is None

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    ubuntu_sources_list = UbuntuSourcesList(module)
    ppa_callback_2 = get_add_ppa_signing_key_callback(module)
    # Should not return None because it is not check mode
    assert ppa_callback_2 is not None




# Generated at 2022-06-20 21:20:32.647029
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/usr/bin/' + x
    l = SourcesList(module)
    l.load(__file__.replace('py', 'list'))

# Generated at 2022-06-20 21:20:44.877195
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class MockModule():
        def __init__(self):
            self.params={}
            self.params['filename']=None
    line_new='deb [arch=amd64] http://security.ubuntu.com/ubuntu xenial-security main'
    def mock_expand_path(filename):
        return filename
    def mock_apt_cfg_dir(dirspec):
        return dirspec
    def mock_apt_cfg_file(dirspec):
        return dirspec
    def mock_dump(dumpstruct):
        return dumpstruct
    MockModuleObject = MockModule()
    MockModuleObject._dump = mock.MagicMock(side_effect=mock_dump)
    MockModuleObject._apt_cfg_file = mock.MagicMock(side_effect=mock_apt_cfg_file)
    MockModuleObject._apt_

# Generated at 2022-06-20 21:21:00.289124
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import os
    import tempfile

    def get_SourcesList(sources=[]):
        class FakeModule:
            pass

        module = FakeModule()
        module.params = {}
        module.params['mode'] = int('600', 8)
        module.params['filename'] = None
        module.get_bin_path = os.getenv

        sl = SourcesList(module)

        for source in sources:
            sl._add_valid_source(source, comment_new='', file=os.path.join(tempfile.gettempdir(), 'ansible_test_sourceslist'))
        return sl


# Generated at 2022-06-20 21:21:00.879780
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert True

# Generated at 2022-06-20 21:21:02.593434
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name="python-apt"
    install_python_apt(module, apt_pkg_name)



# Generated at 2022-06-20 21:21:14.143200
# Unit test for function main
def test_main():
    # pylint: disable=undefined-variable
    AptSourcesModule = ansible_module_apt_repository.AptSourcesModule
    # pylint: enable=undefined-variable

    module = AptSourcesModule()

    module.params = {
        'repo': None,
        'state': None,
        'mode': None,
        'update_cache': None,
        'update_cache_retries': None,
        'update_cache_retry_max_delay': None,
        'filename': None,
        'install_python_apt': None,
        'validate_certs': None,
        'codename': None
    }

    with pytest.raises(SystemExit):
        main()

    module.params['repo'] = ''


# Generated at 2022-06-20 21:21:27.184706
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sl = SourcesList(module)
    # original sources.list does not have entries
    assert len(list(sl)) == 0
    
    result = sl.dump()
    # dump should return empty dict
    assert result == {}
    
    # add valid deb-src 
    sl.add_source('deb-src http://my.fake.repo/debian/ unstable main')
    result = sl.dump()
    # should have one entry
    assert len(list(sl)) == 1
    # that should be dict with one item
    assert len(result) == 1
    # filename should be sources.list by default
    assert 'sources.list' in result
    # the entry should be valid deb-src line

# Generated at 2022-06-20 21:22:05.136661
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import shutil

    def _p(s):
        '''_p(str) => str
        Helper to convert native path to POSIX path to make testing easier.
        '''
        if sys.platform == 'win32':
            return s.replace('\\', '/')
        else:
            return s

    # prepare

# Generated at 2022-06-20 21:22:13.613210
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest
    class UbuntuSourcesListTestCase(unittest.TestCase):

        def test_add_source_ppa_not_in_sources_list(self):
            ppa = 'ppa:developer/name'
            lp_api = UbuntuSourcesList.LP_API % ('developer', 'name')
            mocked_response = {'private': False, 'title': 'title', 'archive_name': 'archive'}

            class MockedModule(object):
                def __init__(self):
                    self.params = {'codename': 'trusty'}
                    self.run_command_called = False
                    self.run_command_status = 0

                def run_command_result(self, rc, out, err):
                    self.run_command_called = True

# Generated at 2022-06-20 21:22:18.561602
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module_args = dict(
        repo='deb http://archive.canonical.com/ubuntu hardy partner',
        filename=None,
        state='present',
        update_cache=True,
        validate_certs=True,
        keyserver='hkp://keyserver.ubuntu.com:80',
        key_id=None,
        proxy=None,
    )


# Generated at 2022-06-20 21:22:23.603314
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert_equal(set(['source1', 'source2']), set(x[3] for x in SourcesList(None).__iter__()))



# Generated at 2022-06-20 21:22:30.379360
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = None
    add_ppa_signing_keys_callback = None
    u = UbuntuSourcesList(module, add_ppa_signing_keys_callback)

    du = copy(u)
    assert u is not du
    assert u.__dict__ == du.__dict__

# Generated at 2022-06-20 21:22:39.683972
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    instance = SourcesList()
    source = "deb http://ppa.launchpad.net/my-ppa/my-ppa/ubuntu xenial main"
    instance.files[source].append("")
    instance.remove_source("ppa:my-ppa/my-ppa")
    assert not instance.files.get(source)
    instance = SourcesList()
    source = "deb http://ppa.launchpad.net/my-ppa/ubuntu xenial main"
    instance.files[source].append("")
    instance.remove_source("ppa:my-ppa")
    assert not instance.files.get(source)

# Generated at 2022-06-20 21:22:46.307287
# Unit test for function install_python_apt
def test_install_python_apt():
    m = AnsibleModule({
        'install_python_apt': True
    })
    m.get_bin_path = lambda *args: '/bin/apt-get'
    m.run_command = lambda *args: (0, 'Apt-get output', 'Apt-get error')
    install_python_apt(m, 'python3-apt')
    assert m.run_command.call_count == 2



# Generated at 2022-06-20 21:22:58.940663
# Unit test for constructor of class SourcesList
def test_SourcesList():
    # Run it with Python 2.6 or 2.7:
    # python -m pytest -v test_SourcesList.py

    class FakeModule(object):
        def __init__(self, name):
            # Required for aptsources.distro.get_distro to work
            self.deprecation = 'deprecation'
            self.name = name

        def fail_json(self, *args, **kwargs):
            raise AssertionError('failed: %s %s' % (args, kwargs))

        def run_command(self, cmd):
            if cmd[0] == 'apt-get' and cmd[1] == 'update':
                return 0, '', ''
            elif cmd[0] == 'apt-get' and cmd[1] == 'install':
                return 0, '', ''


# Generated at 2022-06-20 21:23:09.976619
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import textwrap

    module = AnsibleModule(argument_spec=dict(
        src=dict(),
        comment=dict(),
        filename=dict()
    ))
    aptsources_distro = aptsources.distro

    filename = 'sources.list'
    source = 'deb http://foo bar/baz'
    sources = [source]
    comment = 'foo bar baz'
    for source in sources:
        aptsources_distro.get_distro.return_value.id = 'Debian'
        lines = [source]

        apt_repository = AptRepository(module, sources_dict={filename: '\n'.join(lines)})
        apt_repository.SourcesList.add_source(source, comment=comment)
        apt_repository.SourcesList.save()

       

# Generated at 2022-06-20 21:23:21.867528
# Unit test for function revert_sources_list
def test_revert_sources_list():
    from ansible.module_utils.basic import AnsibleModule
    import shutil


# Generated at 2022-06-20 21:25:06.997568
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    test_object = UbuntuSourcesList(module)

    test_object.add_source("deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main")
    assert("deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main") in test_object.repos_urls
    test_object.add_source("deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main")
    assert("deb http://ppa.launchpad.net/foo/bar/ubuntu xenial main") in test_object.repos_urls
    test_object.add_source("deb http://ppa.launchpad.net/foo/barbaz/ubuntu xenial main")

# Generated at 2022-06-20 21:25:23.295260
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.common._collections_compat import Mapping

    def mockopen(file, mode, buffering):
        return open(file, mode)

    def mockmakedirs(path, mode):
        if not os.path.exists(path):
            os.makedirs(path)

    def mockatomic_move(src, dst):
        os.rename(src, dst)

    def mockset_mode_if_different(path, mode, _):
        if os.path.exists(path):
            os.chmod(path, mode)


# Generated at 2022-06-20 21:25:34.230753
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils._text import to_bytes
    module = MagicMock()
    proc = Popen(['id', '-u'], stdout=PIPE)
    out, err = proc.communicate()
    if int(out) == 0:
        module.run_command.side_effect = Exception('not expecting to run commands as root')
        get_add_ppa_signing_key_callback(module)
        module.run_command.assert_called_once_with(['id', '-u'], check_rc=True)
    else:
        module.run_command.side_effect = None
        module.run_command.return_value = (0, to_bytes(''), to_bytes(''))

# Generated at 2022-06-20 21:25:36.252723
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    sl = UbuntuSourcesList(module)
    copy = copy.deepcopy(sl)
    assert copy.module is module
    assert copy.add_ppa_signing_keys_callback is None


# Generated at 2022-06-20 21:25:46.859253
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    ppa_signing_keys_callback = basic.AnsibleModule(argument_spec={}).run_command
    line = 'ppa:ansible/ansible'

    usl = UbuntuSourcesList(module, add_ppa_signing_keys_callback=ppa_signing_keys_callback)
    assert line not in usl.repos_urls
    assert line not in usl.dump()

    usl.add_source(line)
    assert line in usl.repos_urls
    assert line in usl.dump()

    usl_copy = copy.deepcopy(usl)
    assert line in usl_copy.repos_urls
    assert line in usl_copy.dump()

# Generated at 2022-06-20 21:25:57.810534
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # dummy stream
    s = '''
    deb http://packages.us.debian.org/debian stable main
    deb-src http://packages.us.debian.org/debian stable main
    deb http://security.debian.org/ stable/updates main contrib non-free
    # not valid line
    '''
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    for file, n, enabled, source, comment in sourceslist._parse_stream(s):
        assert enabled
        assert comment == ''
        assert source in ('deb http://packages.us.debian.org/debian stable main', 'deb-src http://packages.us.debian.org/debian stable main', 'deb http://security.debian.org/ stable/updates main contrib non-free')
    # test _parse method
   

# Generated at 2022-06-20 21:25:59.191861
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec={})
    u = UbuntuSourcesList(module)



# Generated at 2022-06-20 21:26:05.606054
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    source = 'deb http://archive.ubuntu.com/ubuntu bionic main'
    comment = '# comment'
    sources_list.add_source(source + ' ' + comment, comment, file='bionic.list')
    sources_list.remove_source(source)
    assert not sources_list.files
test_SourcesList_remove_source()


# Generated at 2022-06-20 21:26:11.482317
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    sourceslist = UbuntuSourcesList(module)
    sourceslist.files = {
        '/etc/apt/sources.list': [(0, True,  True,  'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main', '')],
        '/etc/apt/sources.list.d/local.list': [(10, True, True, 'deb http://repo.localdomain/ubuntu trusty main', '')],
    }
    sourceslist_before = deepcopy(sourceslist)
    sourceslist.remove_source('ppa:ansible/ansible')

# Generated at 2022-06-20 21:26:19.149396
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    source_list = SourcesList()
    source_list.add_source('deb http://mirror.yandex.ru/ubuntu trusty main')
    source_list.add_source('deb http://mirror.yandex.ru/ubuntu/ trusty main')
    source_list.add_source('deb http://mirror.yandex.ru/ubuntu trusty main')
    source_list.add_source('deb http://mirror.yandex.ru/ubuntu trusty main', file='/etc/apt/sources.list')
    source_list.add_source('deb http://mirror.yandex.ru/ubuntu trusty main', file='sources.list')