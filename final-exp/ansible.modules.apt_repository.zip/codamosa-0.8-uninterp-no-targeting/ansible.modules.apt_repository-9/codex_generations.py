

# Generated at 2022-06-20 21:20:02.630103
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    test_sourceslist = SourcesList(AnsibleModule)
    test_sourceslist.load("filename")
    test_sourceslist.modify("filename", 0, enabled=False, source="deb http://mirror.mephi.ru/debian/ stretch main", comment="")
    test_sourceslist.modify("filename", 1, enabled=True, source="deb http://mirror.mephi.ru/debian/ stretch main", comment="")
    test_sourceslist.remove_source("# deb http://mirror.mephi.ru/debian/ stretch main")
    test_sourceslist.remove_source("deb http://mirror.mephi.ru/debian/ stretch main")

# Generated at 2022-06-20 21:20:11.709898
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    def dummy_fail_json(msg):
        print("FAIL: %s" % msg)
        sys.exit(1)

    sling = SourcesList(None)
    sling.module = None
    sling.module.fail_json = dummy_fail_json

    sling.add_source("deb http://archive.example.com/ubuntu xenial main")
    sling.add_source("deb http://archive.example.com/ubuntu xenial universe")
    sling.add_source("deb http://archive.example.com/ubuntu xenial-updates main universe")
    sling.add_source("deb http://archive.example.com/ubuntu xenial-security main universe")

    sling.add_source("deb-src http://archive.example.com/ubuntu xenial main")

# Generated at 2022-06-20 21:20:12.801896
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    e = InvalidSource('message')
    assert str(e) == 'message'


# Generated at 2022-06-20 21:20:22.454552
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.load("test/resources/ansible_sourceslist")
    dump = sources.dump()
    expected = {
        "test/resources/ansible_sourceslist": "deb http://archive.ubuntu.com/ubuntu vivid universe\ndeb http://archive.ubuntu.com/ubuntu vivid universe\n",
        "test/resources/ansible_sourceslist1": "deb http://archive.ubuntu.com/ubuntu vivid universe\n",
        "test/resources/ansible_sourceslist2": "deb http://archive.ubuntu.com/ubuntu vivid universe\n"
    }
    assert dump == expected


# Generated at 2022-06-20 21:20:38.167072
# Unit test for constructor of class UbuntuSourcesList

# Generated at 2022-06-20 21:20:44.096023
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import tempfile
    # Create temporary directory
    tmp_dir = tempfile.mkdtemp()
    sourceslist = SourcesList(dict())
    sourceslist.files = {os.path.join(tmp_dir, 'test_SourcesList_save'): [(0, True, True, 'test', '#test')]}
    sourceslist.save()


# Generated at 2022-06-20 21:20:49.042675
# Unit test for constructor of class SourcesList
def test_SourcesList():
    mod = AnsibleModule(argument_spec={})
    sources = SourcesList(mod)

    # Make sure we can read sources.list
    assert any(src[3] == 'deb http://security.ubuntu.com/ubuntu trusty-security main' for src in sources)

    # Make sure we can read sources.list.d
    assert any(src[3] == 'deb http://archive.ubuntu.com/ubuntu trusty main' for src in sources if src[0] == '/etc/apt/sources.list.d/ansible_ansible-trusty.list')



# Generated at 2022-06-20 21:21:00.803352
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    '''
    Test __iter__().
    '''
    module = AnsibleModule(
        argument_spec=dict(
            filename=dict(required=True),
        ),
        check_invalid_arguments=False,
        supports_check_mode=True,
    )

    # Mock _apt_cfg_file to return specified filename
    filename = os.path.normpath(module.params['filename'])
    orig_apt_cfg_file = SourcesList._apt_cfg_file
    SourcesList._apt_cfg_file = lambda *args: filename

    # Mock _apt_cfg_dir to return specified directory
    directory = os.path.dirname(filename)
    orig_apt_cfg_dir = SourcesList._apt_cfg_dir
    SourcesList._apt_cfg_dir = lambda *args: directory

    # Remove

# Generated at 2022-06-20 21:21:05.644584
# Unit test for function install_python_apt
def test_install_python_apt():
    global apt, apt_pkg
    module = AnsibleModule({})
    sys.modules['apt'] = module
    sys.modules['apt_pkg'] = module
    assert apt is None
    assert apt_pkg is None
    install_python_apt(module, 'python-apt')
    assert apt is not None
    assert apt_pkg is not None



# Generated at 2022-06-20 21:21:12.967579
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock()
    _run_command = get_add_ppa_signing_key_callback(module)
    assert _run_command

    module.check_mode = False
    _run_command(['command'])
    module.run_command.assert_called_with(['command'], check_rc=True)

    module.check_mode = True
    _run_command(['command'])
    module.run_command.assert_not_called()


# Generated at 2022-06-20 21:21:47.410469
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule(argument_spec={})
    install_python_apt(module, 'python-apt')
    install_python_apt(module, 'python3-apt')



# Generated at 2022-06-20 21:21:53.310859
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    desired_filename = '/etc/apt/sources.list.d/google-chrome.list'

    module = AnsibleModule({'filename': 'google-chrome'})
    sources = SourcesList(module)

    source = 'deb http://dl.google.com/linux/chrome/deb/ stable main'
    sources.add_source(source)

    assert len(sources.files) == 1
    assert sources.files[desired_filename]



# Generated at 2022-06-20 21:22:03.060651
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec=dict(
        state=dict(default='present', choices=['absent', 'present']),
        update_cache=dict(default=False, type='bool'),
    ), supports_check_mode=True)
    sl = SourcesList(module)

    module.params['state'] = 'present'
    assert sl.load('tests/data/source.list') is None
    sources = {}
    for file, n, enabled, source, comment in sl:
        if file not in sources:
            sources[file] = []
        sources[file].append((n, enabled, source, comment))

# Generated at 2022-06-20 21:22:12.627437
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    import unittest
    import tempfile
    import shutil
    import json

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            raise Exception(msg)

        def run_command(self, command, check_rc=None):
            return 0, '', ''

        def set_mode_if_different(self, path, mode, changed):
            return True

        def atomic_move(self, path, path2):
            return True

    class MockFetchURL(object):
        def __init__(self, url, status):
            self.url = url
            self.status = status


# Generated at 2022-06-20 21:22:16.167408
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = MagicMock()
    module.get_bin_path.return_value = '/usr/bin/apt-get'
    module.run_command.return_value = (0, '', '')
    SourcesList(module)



# Generated at 2022-06-20 21:22:17.133745
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    Exception()
    InvalidSource()


# Generated at 2022-06-20 21:22:19.543161
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({
        'install_python_apt': True,
    })
    install_python_apt(module, "python3-apt")


# Generated at 2022-06-20 21:22:31.445774
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class Module(object):
        pass

    module = Module()

    sl = SourcesList(module)

    # Create sources.list with single disabled source
    fd, tmp_path = tempfile.mkstemp(prefix='ansible-sources-', dir='/tmp')
    f = os.fdopen(fd, 'w')
    f.write('# disabled\n')
    f.close()
    del f

    sl.load(tmp_path)

    assert len(sl.files) == 1
    assert len(sl.files[tmp_path]) == 1
    assert sl.files[tmp_path][0] == (0, False, False, 'disabled', '')
    os.remove(tmp_path)



# Generated at 2022-06-20 21:22:36.568513
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # set up the test
    tempdir = tempfile.mkdtemp()
    sourcesFile = os.path.join(tempdir, 'test_SourcesList_save.list')

    sourceList = SourcesList(self)
    sourceList.files = {sourcesFile: [(0, True, True, "deb http://deb.debian.org/debian/ testing main", '')]}

    # perform the test
    sourceList.save()

    # clean up
    shutil.rmtree(tempdir)



# Generated at 2022-06-20 21:22:41.036466
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'install_python_apt': True})
    install_python_apt(module, 'python3-apt')
    install_python_apt(module, 'python-apt')



# Generated at 2022-06-20 21:23:23.323763
# Unit test for method load of class SourcesList

# Generated at 2022-06-20 21:23:24.853008
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({"debug": False})
    sources_list = SourcesList(module)



# Generated at 2022-06-20 21:23:34.611048
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu xenial main', comment='this is a test')
    sources.save()

    sources = SourcesList(module)
    found = False
    for filename, n, enabled, source, comment in sources:
        if source == 'deb http://archive.ubuntu.com/ubuntu xenial main':
            found = True
            assert enabled, "Invalid state for added source"
            assert comment == 'this is a test', "Invalid comment for added source"
    assert found, "Source wasn't added"

# Generated at 2022-06-20 21:23:46.413729
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    """
    Test for method `UbuntuSourcesList.__deepcopy__`
    """
    module_mock = MagicMock(return_value=None)

    add_ppa_signing_keys_callback_mock = MagicMock(return_value=None)

    usl_inst_0 = UbuntuSourcesList(
        module_mock,
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback_mock
    )

    usl_inst_1 = copy.deepcopy(usl_inst_0)

    module_mock.assert_has_calls([
        call(return_value=None),
        call(return_value=None)
    ])

    assert isinstance(usl_inst_1, UbuntuSourcesList)
    assert usl_inst_1.add

# Generated at 2022-06-20 21:23:57.068906
# Unit test for constructor of class UbuntuSourcesList

# Generated at 2022-06-20 21:24:08.927676
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    '''
    Test case to check the save method of SourcesList class
    '''
    import platform
    import shutil
    import tempfile

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    source_list_file_path = tempfile.mkdtemp(prefix='ansible_test_module_apt_')
    if platform.system() != 'Windows':
        os.chmod(source_list_file_path, 0o700)
    module.params['filename'] = 'ansible_dpkg_sources'
    source_list_file = os.path.join(source_list_file_path, 'sources.list')
    module.params['sources'] = 'deb http://archive.ubuntu.com/ubuntu trusty main universe'

# Generated at 2022-06-20 21:24:18.465206
# Unit test for function main
def test_main():
    import ansible.modules.packagemanagement.apt
    import os, tempfile, shutil

    utils = ansible.modules.packagemanagement.apt.AptUtils(None, {})
    test_dir = tempfile.mkdtemp()

    def create_test_file(test_dir, filename, contents):
        path = os.path.join(test_dir, filename)
        with open(path, 'w') as f:
            f.write(contents)
        return path

    def escape_path(path):
        return path.replace('\\', '\\\\')

    # Test case #1
    sources_list_dir = utils.get_sources_list_dir()

# Generated at 2022-06-20 21:24:26.763369
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    """
    add_source() Add ppa or APT repository to sources file

    """
    args = dict(
        comment='Docker upstream repository',
        file=None,
        line='deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main'
    )
    UbuntuSourcesList._add_valid_source("Test")
    assert result == 'Hello world'



# Generated at 2022-06-20 21:24:39.277456
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    test_case = UbuntuSourcesList(module)
    test_case.load('test.list')
    test_case.add_source('ppa:test/test')
    assert test_case.files['test.list'] == [
        (0, False, False, '### THIS IS A GENERATED FILE ### # Generated by Ansible. DO NOT CHANGE!', ''),
        (1, True, True, 'deb http://ppa.launchpad.net/test/test/ubuntu xenial main', ''),
    ]
    test_case.add_source('ppa:test/test', comment='test_comment')

# Generated at 2022-06-20 21:24:43.885557
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    test_object = UbuntuSourcesList(
        module=AnsibleModule(
            argument_spec=dict(
            )
        )
    )
    original = copy.deepcopy(test_object)
    assert copy.deepcopy(test_object) == original

# Generated at 2022-06-20 21:27:36.023095
# Unit test for function main
def test_main():
    from ansible.modules.packaging.os.apt_repository import AnsibleModule
    import sys
    stdin = sys.stdin
    sys.stdin = open(os.devnull, 'r')
    saved_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    saved_stderr = sys.stderr
    sys.stderr = open(os.devnull, 'w')

# Generated at 2022-06-20 21:27:44.047790
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible.module_utils._text import to_bytes

    class MockModule(object):
        params = {
            'filename': None,
            'codename': 'trusty',
        }

        def fail_json(self, msg):
            raise Exception(msg)

    sl = UbuntuSourcesList(module=MockModule())
    sl.add_source('ppa:someuser/ppa', file='/tmp/someuser.list')
    sl.add_source('deb http://packages.example.com/ubuntu trusty main', file='/tmp/example.list')

    # check that source exists before deletion
    repos = list(sl)
    assert len(repos) == 2
    assert repos[0][2] is True
    assert repos[1][2] is True

    # delete source and check that it's gone


# Generated at 2022-06-20 21:27:52.375896
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    sources = SourcesList(None)
    sources.add_source('deb http://example.net/foo/ ./')
    assert 'http://example.net/foo/ ./' in sources.dump()
    assert sources.new_repos
    sources.add_source('deb http://example.net/foo/ ./')
    assert len(sources.dump()) == len(sources.new_repos) == 1



# Generated at 2022-06-20 21:27:58.403865
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Test without source specified.
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse')
    assert dict(sources.files) == {'/etc/apt/sources.list': [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse', '')]}
    sources = SourcesList(module)
    sources.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main restricted universe multiverse', comment='test')

# Generated at 2022-06-20 21:28:00.946559
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    from mock import MagicMock
    utils = UbuntuSourcesList(MagicMock())

    assert utils.__deepcopy__()

# Generated at 2022-06-20 21:28:05.222244
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={},supports_check_mode=True)
    module.exit_json = MagicMock()
    main()
    module.exit_json.assert_called_with(changed=False, repo=None, state=None, diff={})


# Generated at 2022-06-20 21:28:11.228492
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sourceslist = UbuntuSourcesList()

    sourceslist.module.params = {'filename': ''}
    sourceslist.add_ppa_signing_keys_callback = mock.MagicMock()
    sourceslist.module.run_command = mock.MagicMock(return_value=(0, '', ''))

    sourceslist.add_source('ppa:ansible/ansible')
    sourceslist.add_source('ppa:ansible/ansible', file='name.list')

    cloned_sourceslist = copy.deepcopy(sourceslist)

    assert 2 == len(cloned_sourceslist.files.keys())


#
# Repo param handling helpers
#


# Generated at 2022-06-20 21:28:17.316308
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sl = SourcesList(module)
    with open('/etc/apt/sources.list', 'r') as file:
        for line in file.readlines():
            sl.add_source(line)
    for line in sl:
        sl.remove_source(line)
    assert sl.files == {}


# Generated at 2022-06-20 21:28:27.376047
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    obj = UbuntuSourcesList(module)
    assert obj is not UbuntuSourcesList.__deepcopy__(obj)
    assert obj.module is UbuntuSourcesList.__deepcopy__(obj).module
    assert obj.add_ppa_signing_keys_callback is UbuntuSourcesList.__deepcopy__(obj).add_ppa_signing_keys_callback  # pylint: disable=line-too-long



# Generated at 2022-06-20 21:28:39.287668
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
  import unittest

  class TestRemoveSource(unittest.TestCase):
    def test_remove_source(self):
      sources_list = SourcesList(None)