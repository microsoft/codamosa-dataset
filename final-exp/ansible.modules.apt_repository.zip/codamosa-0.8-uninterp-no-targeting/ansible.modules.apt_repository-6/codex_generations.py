

# Generated at 2022-06-20 21:20:06.523673
# Unit test for function install_python_apt
def test_install_python_apt():
    class FakeModule:
        def __init__(self):
            self.params = {'install_python_apt': True}
        def get_bin_path(self, bin_path):
            if bin_path == 'apt-get':
                return '/fake/path/apt-get'
            else:
                return None
        def run_command(self, args):
            # call apt-get install python-apt
            rc = 0
            if args[0] == '/fake/path/apt-get' and args[2] == 'python-apt':
                so = 'foo'
                se = 'bar'
            # call apt-get install python3-apt
            elif args[0] == '/fake/path/apt-get' and args[2] == 'python3-apt':
                so = 'bar'

# Generated at 2022-06-20 21:20:14.197762
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()
    o = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    copy = copy.deepcopy(o)

    assert copy.module == o.module
    assert add_ppa_signing_keys_callback == o.add_ppa_signing_keys_callback


# Generated at 2022-06-20 21:20:24.996636
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    '''
    Unit test for method dump of class SourcesList
    '''
    # Create test data
    _test_data = {
        '/etc/apt/sources.list.d/nginx.list':
            '''
        deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main
        deb-src http://ppa.launchpad.net/nginx/stable/ubuntu trusty main
        ''',

        '/etc/apt/sources.list.d/nginx2.list':
            '''
        # deb http://ppa.launchpad.net/nginx/stable/ubuntu trusty main
        deb-src http://ppa.launchpad.net/nginx/stable/ubuntu trusty main
        '''
    }

    # Create test object
    _test_obj = SourcesList(None)

   

# Generated at 2022-06-20 21:20:34.492621
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    mock_module = MagicMock()
    mock_module.check_mode = True
    assert get_add_ppa_signing_key_callback(mock_module) is None

    mock_module.check_mode = False

    # check the properties of the returned function
    mock_module.run_command = MagicMock()
    add_ppa_signing_key_callback = get_add_ppa_signing_key_callback(mock_module)
    assert add_ppa_signing_key_callback is not None
    assert callable(add_ppa_signing_key_callback)

    # check the behaviour

# Generated at 2022-06-20 21:20:46.192470
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({}, supports_check_mode=True)
    sources_list = SourcesList(module)
    sources_list.add_source("""
# deb cdrom:[Ubuntu 13.10 _Saucy Salamander_ - Release amd64 (20131016.1)]/ saucy main restricted
deb http://archive.ubuntu.com/ubuntu saucy main restricted
deb http://security.ubuntu.com/ubuntu saucy-security main restricted
""", comment='test')
    dumpstruct = sources_list.dump()

# Generated at 2022-06-20 21:21:01.633895
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():

    class TMP_M(object):

        def fail_json(self, *args, **kwargs):
            raise Exception()

        def atomic_move(self, *args, **kwargs):
            pass

        def set_mode_if_different(self, *args, **kwargs):
            pass

        def _expand_path(self, filename):
            if filename is None:
                return filename
            else:
                return '/tmp/%s' % filename

    class TMP_A(object):

        def __init__(self, *args, **kwargs):
            self.params = {}

    # Test set 1
    s = SourcesList(TMP_M())
    test_file = '/etc/apt/sources.list'
    s.load(test_file)

# Generated at 2022-06-20 21:21:07.345934
# Unit test for function install_python_apt
def test_install_python_apt():
    apt_pkg_name = 'python-apt'
    m = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': 'yes'}})
    m._module_options['_ansible_module_name'] = 'apt_module'
    if not HAVE_PYTHON_APT:
        install_python_apt(m, apt_pkg_name)
# End unit test


# Generated at 2022-06-20 21:21:14.216006
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: None
    sources_list = SourcesList(module)
    sources = sources_list.dump()
    for file, source in sources.items():
        sources_list.load(file)
    for file, n, enabled, source, comment in sources_list:
        assert sources[file].split("\n")[n] == ''.join(['#' if not enabled else '', source, ' # ' if comment else '', comment])


# Generated at 2022-06-20 21:21:22.836308
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    m = AnsibleModule(argument_spec={})
    sl = SourcesList(m)
    sl.load('tests/data/sources.list')
    sl.save()
    assert os.path.exists('%s/ansible.list' % sl._apt_cfg_dir('Dir::Etc::sourceparts'))
    assert os.path.exists('%s/google-chrome.list' % sl._apt_cfg_dir('Dir::Etc::sourceparts'))

# Generated at 2022-06-20 21:21:30.884867
# Unit test for function revert_sources_list
def test_revert_sources_list():
    class ModuleMock:
        def fail_json(self, args):
            self.called_fail_json = args
            raise AnsibleFailJson(args)

        def run_command(self, command, check_rc):
            raise Exception('mock - command: %s' % command)

        def atomic_move(self, source, dest, unsafe_writes):
            self.called_atomic_move = (source, dest, unsafe_writes)
            print('mock - atomic_move %s %s' % (source, dest))

    def set_mode_if_different(self, path, mode, changed):
        self.called_set_mode_if_different = (path, mode, changed)
        print('mock - set_mode_if_different %s %o' % (path, mode))

    module = Module

# Generated at 2022-06-20 21:22:02.225956
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-20 21:22:11.919193
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(arguments={'name': 'test'})
    source_list = UbuntuSourcesList(module)
    file = '/tmp/test'

# Generated at 2022-06-20 21:22:18.838355
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule({})
    sl = SourcesList(module)
    sl.load("tests/test1.list")
    sl.load("tests/test2.list")
    sl.dump()
    assert sl.dump().get("tests/test1.list") == "deb http://repo TESTS\n# deb-src http://repo TESTS\n"
    assert sl.dump().get("tests/test2.list") == "deb http://repo TESTS/testing/\n"


# Generated at 2022-06-20 21:22:25.556347
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = DummyModule()
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.atomic_move = MagicMock()
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()
    module.set_mode_if_different = MagicMock()
    module.params = {}

# Generated at 2022-06-20 21:22:35.040318
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    data = '''
# Disabled
deb http://archive.ubuntu.com/ubuntu trusty main
#comment2
#comment3
'''
    module = EmptyModule()
    sl = SourcesList(module)
    filename = 'test.list'
    fd, filename = tempfile.mkstemp(suffix=filename, prefix='.%s-' % filename)
    f = os.fdopen(fd, 'w')
    f.write(data)
    f.close()
    sl.load(filename)
    assert len(sl.files[filename]) == 4
    assert sl.files[filename][0][1] is False
    assert sl.files[filename][0][2] == 'deb http://archive.ubuntu.com/ubuntu trusty main'
    assert sl.files[filename][1][1] is False

# Generated at 2022-06-20 21:22:39.768057
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'name': 'Foo'})
    install_python_apt(module, "python-apt")
    install_python_apt(module, "python3-apt")



# Generated at 2022-06-20 21:22:40.766889
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    InvalidSource()


# Generated at 2022-06-20 21:22:51.110050
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    '''Test if PPA can be removed.'''
    class FakeModule:
        def __init__(self):
            self.params = {
                'codename': 'trusty',
            }
            self.fail_json = lambda msg: None
            self.run_command = lambda cmd, **kwargs: (0, '', '')
            self.atomic_move = lambda src, dst: None
            self.set_mode_if_different = lambda src, mode, insecure: None
        def fail_json(self, msg=None, **kwargs):
            raise Exception(msg)

    _sources_list = UbuntuSourcesList(FakeModule(), add_ppa_signing_keys_callback=lambda cmd: None)
    _sources_list.load('tests/test_sources.list')
    _sources_list.add_

# Generated at 2022-06-20 21:23:01.668431
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    failed = False
    module = AnsibleModule(argument_spec = dict(
        test = dict(required=True, type='bool'),
        repo = dict(required=True, type='str'),
        filename = dict(required=False, type='str'),
        mode = dict(required=False, type='str'),
    ))

    sl = SourcesList(module)
    sl.new_repos = {'/dev/null', '/dev/null2'}

# Generated at 2022-06-20 21:23:02.893977
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert(str(InvalidSource) == "InvalidSource")


# Generated at 2022-06-20 21:24:33.602783
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = Mock()
    res = get_add_ppa_signing_key_callback(module)
    assert res() is None

# Generated at 2022-06-20 21:24:43.270251
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    file_obj = tempfile.NamedTemporaryFile(delete=False)
    file_obj.write(b"# foo")
    file_obj.flush()
    file_obj.close()
    try:
        sources_list = SourcesList(module)
        sources_list.load(file_obj.name)
        assert sources_list.files == {
            file_obj.name: [(0, False, False, "", "foo")],
        }
    finally:
        os.remove(file_obj.name)


# Generated at 2022-06-20 21:24:54.800584
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    def add_signing_keys_callback(command):
        pass

    module = AnsibleModule(
        argument_spec={
            'codename': {'required': False, 'default': distro.codename},
        },
        supports_check_mode=True,
    )

    # test with ppa source line
    source_list = UbuntuSourcesList(module, add_ppa_signing_keys_callback=add_signing_keys_callback)
    source_list.add_source('ppa:ansible/ansible')
    expected_add_ppa_source_output = {
        '/etc/apt/sources.list.d/ansible_ansible_ubuntu_xenial.list': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main\n',
    }

    assert source_

# Generated at 2022-06-20 21:25:07.021638
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class MockModule(object):
        fail_json = lambda self, msg: sys.exit(1)
        get_bin_path = lambda self, name: None

        # This is a hack to make sure that we don't require a full module object nor playbooks in unit tests.
        def __init__(self):
            self.params = {}

    module = MockModule()

    def create_tmp_file(content, fname='sources.list'):
        content = '\n'.join([line.rstrip() for line in content.splitlines()])
        fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % fname, suffix='.list')
        os.write(fd, content.encode('utf-8'))
        os.close(fd)
        return tmp_path


# Generated at 2022-06-20 21:25:19.194801
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    def mock_module():
        return type('module', (object,), dict(exit_json=exit_json, fail_json=fail_json, atomic_move=lambda self, src, dest: None))

    def exit_json(*args, **kwargs):
        pass

    def fail_json(*args, **kwargs):
        pass

    # Create mock sources list object
    module = mock_module()
    sourceslist = SourcesList(module)

    # Create mock source
    mock_file = 'mock_file.list'
    mock_source = 'mock source'
    mock_comment = 'mock comment'

    # Add mock source to sources list
    sourceslist.add_source(mock_source, mock_comment, mock_file)

    # Dump sources list
    dump = sourceslist.dump()

    # Ass

# Generated at 2022-06-20 21:25:21.293659
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('Invalid source string')
    except InvalidSource as exc:
        print(exc)



# Generated at 2022-06-20 21:25:30.306997
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.module_utils.common.respawn
    import ansible.module_utils._text
    import tempfile
    #mock the module
    module_args = dict(
        repo="deb http://archive.canonical.com/ubuntu trusty partner",
        state="present",
        filename="filename",
    )

    # we need to mock this since we don't have the distro module in unit testing and apt is available only
    # on ubuntu (not centos and fedora)
    def get_distro():
        return "Ubuntu"

    def atomic_move(source, destination):
        os.rename(source, destination)
    # create a temporary directory for test file
    tmp_dir = tempfile.mkdtemp

# Generated at 2022-06-20 21:25:36.113583
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = DummyModule()
    sl = SourcesList(module)
    sl.add_source('deb http://example.com trusty multiverse')
    sl.save()
    import os.path
    assert os.path.exists('/etc/sources.list')
    assert os.path.exists('/etc/apt/sources.list.d/example.com.list')
    os.remove('/etc/sources.list')
    os.remove('/etc/apt/sources.list.d/example.com.list')


# Generated at 2022-06-20 21:25:37.431540
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    test_object = UbuntuSourcesList(None)
    assert test_object.__deepcopy__() == UbuntuSourcesList(None)


# Generated at 2022-06-20 21:25:39.695214
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    sl = SourcesList(module)
    assert len(sl.files) == 6

