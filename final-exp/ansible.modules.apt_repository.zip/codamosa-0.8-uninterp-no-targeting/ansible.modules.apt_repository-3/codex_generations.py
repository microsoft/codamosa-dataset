

# Generated at 2022-06-20 21:20:14.621879
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Make a temporary directory for files
    d = tempfile.mkdtemp()

# Generated at 2022-06-20 21:20:15.723578
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    assert False # TODO: implement your test here


# Generated at 2022-06-20 21:20:17.701449
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = DummyModule()
    sources = SourcesList(module)
    assert sources is not None


# Generated at 2022-06-20 21:20:28.523020
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():

    class _ModuleLike(object):
        pass

    class _SourcesListLike(object):

        def __init__(self, *args, **kwargs):
            self.files = {}

    def _expand_path(filename):
        return '/etc/apt/sources.list.d/%s' % filename

    def _apt_cfg_file(filespec):
        return os.path.join('/etc/apt/', filespec)

    def _apt_cfg_dir(dirspec):
        return os.path.join('/etc/apt/', dirspec)

    module = _ModuleLike()

    module.params = {
        'filename': None
    }

    # create sources.list.d dir, so we could find it
    os.makedirs('/etc/apt/sources.list.d/')



# Generated at 2022-06-20 21:20:39.611567
# Unit test for function main
def test_main():
    module = AnsibleModule({
        # NOTE: We don't specify 'binary_modules' here, because we want to
        # test the 'not installed' case.
        # NOTE: We don't specify 'add_python_apt' because that's tested
        # separately.

        'repo': 'deb http://archive.ubuntu.com/ubuntu xenial main',
        'state': 'present',
        'mode': '0644',
        'update_cache': False,
        'filename': '/etc/apt/sources.list.d/deadsnakes.list',
        'codename': 'xenial',
    })

    assert not HAVE_PYTHON_APT

# Generated at 2022-06-20 21:20:40.541798
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert 0

# Generated at 2022-06-20 21:20:44.871368
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    file = '/etc/apt/sources.list'
    sourceslist.load(file)
    sourceslist.dump()


# Generated at 2022-06-20 21:20:55.885395
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    with mock.patch('os.path.isfile') as mock_isfile:
        mock_isfile.return_value = True

# Generated at 2022-06-20 21:20:59.794330
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    my_exception = InvalidSource()
    assert (str(my_exception) == 'Invalid sources.list entry')


# Generated at 2022-06-20 21:21:06.262823
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})

    def mock_context(file_name, file_content):
        if file_name not in file_contents:
            file_contents[file_name] = file_content
        else:
            return 0

    def mock_atomic_move(src, dst):
        if src in sources_list.files:
            file_name = os.path.basename(src)
            file_contents[dst] = file_contents[src]
            del file_contents[src]
        else:
            return 1

    def mock_set_mode_if_different(filename, mode, follow, unsafe_writes):
        return 0

    def mock_exists(path):
        return path in file_contents


# Generated at 2022-06-20 21:21:37.919948
# Unit test for function main
def test_main():
    # No, I don't know how to test this function.
    # These lines of code are mostly copy-pasted to the test case.
    pass


# Generated at 2022-06-20 21:21:49.065572
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(
        argument_spec=dict(
            repo='',
            ppa='',
            deb='',
            state='',
            mode='',
            update_cache='',
            cache_valid_time='',
            dists='',
            filename='',
            codename='',
            repos=dict(type='list')
        ),
        supports_check_mode=True,
    )
    module.run_command = MagicMock()
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()

    ub_sources_list = UbuntuSourcesList(module)

    assert ub_sources_list



# Generated at 2022-06-20 21:21:55.274607
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    '''
    Tests for add_source
    '''
    module = AnsibleModule(argument_spec=dict())

    # Create empty object
    sources_list = SourcesList(module)

    # add_source test
    sources_list.add_source('deb http://archive.canonical.com/ubuntu hardy partner', comment='foo bar')
    # TODO: continue



# Generated at 2022-06-20 21:21:57.274659
# Unit test for function install_python_apt
def test_install_python_apt():
    assert install_python_apt(('python-apt', 'python3-apt')) == 0


# Generated at 2022-06-20 21:21:58.798109
# Unit test for function main
def test_main():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.fail_json = Mock()
    module.exit_json = Mock()
    module.params = {}
    main()

# Generated at 2022-06-20 21:22:05.796232
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class AptModule():
        def __init__(self):
            self.params = {}

    module = AptModule()
    usl = UbuntuSourcesList(module)

    source_str = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    comment = 'Managed by Ansible'
    usl.add_source(source_str, comment)

    source_str = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    usl.remove_source(source_str)

    assert len(usl.files) == 1
    assert len(usl.files[usl.default_file]) == 0



# Generated at 2022-06-20 21:22:08.865627
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    # Test with check mode set to true
    module = AnsibleModule(argument_spec={'check_mode': {'default': True, 'type': 'bool'}})
    callback = get_add_ppa_signing_key_callback(module)
    assert callback is None

    # Test with check mode set to false
    module = AnsibleModule(argument_spec={'check_mode': {'default': False, 'type': 'bool'}})
    callback = get_add_ppa_signing_key_callback(module)
    assert hasattr(callback, '__call__')



# Generated at 2022-06-20 21:22:17.917516
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    tmpdir = mkdtemp()
    repos_path = os.path.join(tmpdir, 'sources.list')

    module = AnsibleModule(argument_spec={
        'path': {'required': False, 'default': repos_path},
        'codename': {'required': False, 'default': 'xenial'}
    })

    # create sources.list file with several line of ppa: and deb-src

# Generated at 2022-06-20 21:22:24.997401
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = AnsibleModule(argument_spec=dict(None), supports_check_mode=True)
    sourceslist = SourcesList(module)
    sourceslist.add_source('deb http://example.com/debian wheezy-backports main')
    sourceslist.add_source('deb http://example.com/debian wheezy-backports-source main')
    sourceslist.add_source('deb-src http://example.com/debian wheezy main')
    sourceslist.add_source('# deb http://example.com/debian wheezy main')
    sourceslist.add_source('# deb http://example.com/debian wheezy main', comment='Update package list')

# Generated at 2022-06-20 21:22:30.104275
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    assert get_add_ppa_signing_key_callback(dict(check_mode=True)) is None



# Generated at 2022-06-20 21:24:02.985878
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''Test revert_sources_list function'''
    sources_before = {
        '/tmp/test_sourcelist1': 'foo bar baz\n',
        '/tmp/test_sourcelist2': 'foo bar baz\n',
    }
    sources_after = {
        '/tmp/test_sourcelist1': 'foo bar baz\n',
        '/tmp/test_sourcelist2': 'foo bar baz\n',
        '/tmp/test_sourcelist3': 'foo bar baz\n',
    }
    class MockModule(object):
        def fail_json(self, *args, **kwargs):
            raise Exception('fail')
        def atomic_move(self, *args, **kwargs):
            pass

# Generated at 2022-06-20 21:24:08.183907
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert UbuntuSourcesList(module, add_ppa_signing_keys_callback=None) == UbuntuSourcesList(module, add_ppa_signing_keys_callback=None).__deepcopy__()

# Generated at 2022-06-20 21:24:19.389774
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    line1 = 'deb http://archive.ubuntu.com/ubuntu trusty main restricted universe multiverse\n'
    line2 = '# deb-src http://archive.ubuntu.com/ubuntu trusty main restricted universe multiverse\n'
    line3 = 'deb http://archive.ubuntu.com/ubuntu trusty-updates main restricted universe multiverse\n'
    line4 = '# deb-src http://archive.ubuntu.com/ubuntu trusty-updates main restricted universe multiverse\n'
    line5 = 'deb http://security.ubuntu.com/ubuntu trusty-security main restricted universe multiverse\n'
    line6 = '# deb-src http://security.ubuntu.com/ubuntu trusty-security main restricted universe multiverse\n'
    line7 = 'deb http://archive.canonical.com/ubuntu trusty partner\n'
   

# Generated at 2022-06-20 21:24:30.275801
# Unit test for function main

# Generated at 2022-06-20 21:24:32.518642
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    assert False, "Test if the SourcesList object's modify method works as expected"



# Generated at 2022-06-20 21:24:45.223038
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    from ansible.module_utils.basic import AnsibleModule
    import json
    import os
    import re
    module = AnsibleModule(argument_spec={})
    module.atomic_move = os.rename
    module.set_mode_if_different = None
    sl = SourcesList(module)
    sources = json.loads('{"/etc/apt/sources.list": "deb http://archive.canonical.com/ubuntu trusty partner\n", "/etc/apt/sources.list.d/google-chrome.list": "deb http://dl.google.com/linux/chrome/deb/ stable main\n"}')
    for file, source in sources.items():
        sl.load(file)
    sl.save()

# Generated at 2022-06-20 21:24:56.225633
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    '''
    Test a method save of SourcesList class.
    '''
    # create a temp file and remove it after test
    fd, tmp_path = tempfile.mkstemp(prefix=".sources-", dir="/tmp")
    os.close(fd)

    # prepare test config
    files = {tmp_path: ['deb http://debian.org/ jessie main', 'deb-src http://debian.org/ jessie main']}
    sourceslist = SourcesList(None)
    sourceslist.files = files

    # run tested method
    sourceslist.save()

    # check the result
    expected_result = files[tmp_path][0] + "\n" + files[tmp_path][1] + "\n"
    with open(tmp_path, "r") as f:
        content = f.read

# Generated at 2022-06-20 21:25:03.050915
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # init
    _mock_module = MagicMock()
    _mock_module.debug = True
    _mock_module.check_mode = False
    _mock_module.params = {}
    _mock_module.run_command.return_value = (0, '', '')
    _mock_module.fail_json.side_effect = AnsibleModuleFail
    _mock_module.atomic_move.return_value = True
    _mock_module.get_bin_path.return_value = True
    _mock_module.set_mode_if_different = MagicMock()

    # test
    filename = 'test_filename'
    sources = [('', True, True, 'test_source_valid', 'test_comment')]

# Generated at 2022-06-20 21:25:10.615983
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class ModuleMock:
        def __init__(self, filename, path):
            self.filename = filename
            self.path = path

        # Method ``atomic_move`` should not fail to raise an exception because
        # it is used only in case we rename the file. In this test, no renaming
        # is performed.
        def atomic_move(self, src, dest):
            pass

        def fail_json(self, msg):
            raise AssertionError(msg)

        def get_bin_path(self, name):
            return name

        def set_mode_if_different(self, filename, mode, changed, diff=None):
            pass

        def run_command(self, cmd):
            if cmd == ['grep', '-v', 'deb-src', self.filename]:
                return 0, '', ''


# Generated at 2022-06-20 21:25:24.660653
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import shutil
    import tempfile
    dir = tempfile.mkdtemp()
    # prepare test data