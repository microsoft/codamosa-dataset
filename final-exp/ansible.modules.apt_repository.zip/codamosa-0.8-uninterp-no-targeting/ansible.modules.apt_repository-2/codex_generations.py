

# Generated at 2022-06-20 21:20:08.303775
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # Test for new source
    assert test_SourcesList_add_source_helper('deb https://mirror.corbina.net/ubuntu artful main multiverse restricted universe', 'mirror.corbina.net') == 0

    # Test for source with filename
    assert test_SourcesList_add_source_helper('deb https://mirror.corbina.net/ubuntu artful main multiverse restricted universe', 'mirror.corbina.net', 'sources.list.d/ubuntu-artful.list') == 0

    # Test for existing source
    assert test_SourcesList_add_source_helper('deb https://mirror.corbina.net/ubuntu artful main multiverse restricted universe', 'mirror.corbina.net') == 0
# Helper function for test_SourcesList_add_source

# Generated at 2022-06-20 21:20:17.504402
# Unit test for constructor of class SourcesList
def test_SourcesList():
    import os
    import shutil
    import tempfile

    class Module(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            raise Exception(kwargs)

        def atomic_move(self, src, dest):
            assert src != dest
            shutil.move(src, dest)

        def get_bin_path(self, binary):
            return '/usr/bin/%s' % binary

    module = Module()
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 21:20:18.294725
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass

# Generated at 2022-06-20 21:20:28.853591
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    class options(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)
    class module(object):
        def __init__(self):
            self.params = options()
            self.fail_json = lambda a: exit(1)
            self.atomic_move = lambda a, b: print("New file: %s" % b)
            self.run_command = lambda a: None
        def check_mode(self):
            return False
        def get_bin_path(self,a):
            return a
        def set_mode_if_different(self, a, b, c):
            pass

    sources = SourcesList(module())

# Generated at 2022-06-20 21:20:38.167148
# Unit test for constructor of class SourcesList
def test_SourcesList():
    mod = AnsibleModule(argument_spec={})
    sl = SourcesList(mod)

    assert isinstance(sl.files, dict)

    for file in glob.iglob('%s/*.list' % mod.tmpdir):
        assert file in sl.files

    for file, sources in sl.files.items():
        assert isinstance(sources, list)
        for n, valid, enabled, source, comment in sources:
            assert isinstance(n, int)
            assert valid or not enabled
            assert source or not enabled
            assert isinstance(comment, str)


# Generated at 2022-06-20 21:20:43.696473
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    global distro
    distro = aptsources_distro.get_distro('Ubuntu', 'bionic')
    ml = SourcesList(None)
    ml.load(ml._apt_cfg_file('Dir::Etc::sourcelist'))
    assert ml.files


# Generated at 2022-06-20 21:20:49.197050
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module_name = 'ansible.builtin.apt_repository'

    if sys.version_info[0] < 3:
        pytest.skip('This test can run only on python3')
    if not HAVE_PYTHON_APT:
        pytest.skip('This test can run only with python-apt')
    module = AnsibleModule(argument_spec={})

    mocked_module = mock.Mock()
    mocked_module.params = { 'filename': None }

    sources_list = SourcesList(mocked_module)

# Generated at 2022-06-20 21:20:57.256185
# Unit test for constructor of class SourcesList
def test_SourcesList():
    mod = AnsibleModule({'_ansible_selinux_special_fs': ['fuse', 'nfs', 'vboxsf', 'ramfs', '9p']})
    sl = SourcesList(mod)

    # Check that we've got default source file.
    assert sl.default_file == '/etc/apt/sources.list'

    # Check that we've got all sources from sources.list
    exp_num_src_list = 7
    exp_num_src_list_d = 3
    exp_num_disabled_src = 2
    exp_src = 'deb http://ppa.launchpad.net/webupd8team/y-ppa-manager/ubuntu trusty main'
    assert len(sl.files) == (exp_num_src_list + exp_num_src_list_d), sl.files
   

# Generated at 2022-06-20 21:21:05.666617
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    class test_module():
        def __init__(self, module):
            pass
        def fail_json(self, msg):
            print("Failed test: %s" % msg)
        def atomic_move(self, old, new):
            print("atomic_move: %s %s" % (old, new))
        def set_mode_if_different(self, path, mode, changed):
            print("Set mode: %s %s %s" % (path, mode, changed))
        def get_bin_path(self, name):
            return "/usr/bin/%s" % name
        def run_command(self, command):
            if command == ['/usr/bin/apt-get', 'update']:
                return 0, '', ''

# Generated at 2022-06-20 21:21:21.120233
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.fail_json = MagicMock(return_value=None)
    module.exit_json = MagicMock(return_value=None)

    module.params = {
        'codename': 'xenial',
    }
    apt_pkg.config.find_file = lambda x: '/etc/apt/sources.list'

    with open('/etc/apt/sources.list') as f:
        module.from_file = f.read()
        module.to_file = module.from_file

    ubuntu_sources_list = UbuntuSourcesList(module)

# Generated at 2022-06-20 21:21:50.962896
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    assert_raises(InvalidSource, UbuntuSourcesList(None).remove_source, 'deb  main restricted universe multiverse')



# Generated at 2022-06-20 21:21:52.115870
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-20 21:21:58.894995
# Unit test for function install_python_apt
def test_install_python_apt():
    from ansible.modules.packaging.os import apt_repository
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, {'ansible_python_interpreter': sys.executable}) # simulate ansible module interpreter
    apt_repository.install_python_apt(module, "python3-apt")
    assert apt_repository.HAVE_PYTHON_APT is True


# Generated at 2022-06-20 21:22:10.015289
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule(argument_spec=dict(
        state=dict(choices=['absent', 'present', 'listed'], type='str'),
        name=dict(required=True, aliases=['repo']),
        update_cache=dict(required=False, type='bool', default=False),
        cache_valid_time=dict(required=False, type='int', default=0),
        filename=dict(required=False, type='str', default=None),
        mode=dict(required=False, type='str', default=None)
    ))
    repo_line = 'deb http://ppa.launchpad.net/xnox/test/ubuntu trusty main'
    repo_name = 'xnox/test'
    repo_codename='trusty'
    repo_comment='This is test ppa repository'
   

# Generated at 2022-06-20 21:22:25.648172
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from tempfile import NamedTemporaryFile
    from ansible_collections.ansible.builtin.plugins.module_utils.apt.source_list import SourcesList
    from ansible_collections.ansible.builtin.plugins.module_utils.apt.source_list_item import SourceListItem

    with NamedTemporaryFile(mode='w+') as fp:
        fp.write("deb cdrom:[Debian GNU/Linux 9.9.0 _Stretch_ - Official amd64 DVD Binary-1 20191016-15:28]/ stretch contrib main\n")
        fp.write("deb http://httpredir.debian.org/debian/ stretch main contrib non-free\n")
        fp.write("deb-src http://ftp.us.debian.org/debian/ stretch main\n")
        fp.write

# Generated at 2022-06-20 21:22:28.454039
# Unit test for function install_python_apt
def test_install_python_apt():
    return



# Generated at 2022-06-20 21:22:37.248874
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    import tempfile
    import shutil
    import os

    sources_list_file = tempfile.NamedTemporaryFile(mode='w')

# Generated at 2022-06-20 21:22:53.301883
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import json

    module_args = dict(
        repo="deb http://archive.ubuntu.com/ubuntu/ xenial main",
        state="present",
        filename="mkyong.list"
    )

    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    sourceslist = SourcesList(module)

    # we're adding a new source, so the file should not exist
    filename = sourceslist._expand_path('mkyong.list')
    assert not os.path.exists(filename)

    sourceslist.add_source(module_args['repo'])

    # the file should exist now
    assert os.path.exists(filename)

    # the sources list should not be empty
    assert os.path.getsize(filename) > 0

    # reading the file should not

# Generated at 2022-06-20 21:23:02.632462
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import os
    import tempfile
    import shutil
    import stat

    module = AnsibleModule({})

    tmp_dir = tempfile.mkdtemp(prefix="ansible_test_SourcesList_modify")

# Generated at 2022-06-20 21:23:14.265269
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({}, {})
    sources = SourcesList(module)

    assert sources.default_file == '/etc/apt/sources.list'

    assert list(sources) == []
    assert sources.files == {}

    # Make sure that we will not raise exception when adding not valid sources.
    assert module.atomic_move.called == False
    assert module.set_mode_if_different.called == False

    sources.modify('/etc/apt/sources.list', 0, enabled=False, source='source_new', comment='comment_new')
    sources.modify('/etc/apt/sources.list', 1, enabled=True, source='source_new2', comment='comment_new2')

    sources.save()
    assert module.atomic_move.called == True
    assert module.set_mode

# Generated at 2022-06-20 21:24:19.877038
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Setup test variables
    module = AnsibleModule(argument_spec={})
    module.params['repo'] = 'deb http://archive.canonical.com/ubuntu trusty partner'
    module.params['state'] = 'present'
    module.params['update_cache'] = False
    # Setup test class
    sources_list = SourcesList(module)




# Generated at 2022-06-20 21:24:24.315605
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    modul = AnsibleModule(argument_spec={'a': {'type': 'str'}})

    a = UbuntuSourcesList(modul)
    b = copy.deepcopy(a)

    assert a == b
    assert a.module == b.module



# Generated at 2022-06-20 21:24:35.696540
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils import basic
    from ansible.module_utils.common.respawn import has_respawned, probe_interpreters_for_module, respawn_module
    m = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    m.exit_json = exit_json
    m.fail_json = fail_json
    m.run_command = run_command
    m.atomic_move = atomic_move
    m.run_command = run_command
    m.get_bin_path = get_bin_path
    m.no_log_values = no_log_values
    m.set_mode_if_different = set_mode_if_different

    # init module params
    params = dict()

    # init module

# Generated at 2022-06-20 21:24:47.044295
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class FakeModule:
        def fail_json(self, **kwargs):
            raise RuntimeError(kwargs['msg'])

        @staticmethod
        def get_bin_path(path):
            return None

    fake_module = FakeModule()
    sources = SourcesList(fake_module)

    # check that order of sources is not lost

# Generated at 2022-06-20 21:24:56.623168
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = MagicMock()
    module.check_mode = False
    module.run_command.return_value = 0, "", "fake_stdout"
    callback = get_add_ppa_signing_key_callback(module)
    callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'FAKE_KEY'])
    module.run_command.assert_called_once_with(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', 'FAKE_KEY'], check_rc=True)


# Generated at 2022-06-20 21:24:58.259936
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_source = InvalidSource("Invalid source")
    assert str(invalid_source) == "Invalid source"


# Generated at 2022-06-20 21:25:09.182278
# Unit test for method add_source of class SourcesList

# Generated at 2022-06-20 21:25:19.867158
# Unit test for function main
def test_main():
    import sys
    import os
    import tempfile
    import shutil

    def _test_empty_dir(name):
        assert not os.path.exists(name), '%s should not exist' % name
        try:
            os.mkdir(name)
        except:
            if os.path.exists(name):
                shutil.rmtree(name)
            raise
        assert os.path.exists(name), 'failed to create dir %s' % name
        assert not os.listdir(name), '%s should be empty' % name

    def _test_file_exists(path):
        assert os.path.exists(path), '%s should exist' % path


# Generated at 2022-06-20 21:25:24.043230
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    module = AnsibleModule({})
    test_obj = SourcesList(module)
    assert test_obj is not None



# Generated at 2022-06-20 21:25:25.118093
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    pass

