

# Generated at 2022-06-20 21:20:02.414023
# Unit test for constructor of class InvalidSource
def test_InvalidSource(): # pylint: disable=unused-variable
    """Test the constructor of class InvalidSource."""
    my_exception = InvalidSource('some error message', '/etc/apt/sources.list')
    assert my_exception.message == 'some error message'
    assert my_exception.sources_file == '/etc/apt/sources.list'


# Generated at 2022-06-20 21:20:10.979511
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = MagicMock()
    apt_cfg_file = MagicMock(return_value='/a/b/c/')
    module.params = {'filename' : 'name', 'mode': 0}
    module.get_bin_path = MagicMock(return_value='/')
    module.run_command = MagicMock(return_value=(0,'', ''))
    module.fail_json = MagicMock(return_value=None)
    module.__getitem__ = MagicMock(return_value='source_file')
    module.check_mode = False
    module.set_mode_if_different = MagicMock(return_value=True)
    module.atomic_move = MagicMock(return_value=None)
    open_func = MagicMock()
    f = MagicMock()
   

# Generated at 2022-06-20 21:20:21.171327
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = AnsibleModule(
        argument_spec=dict(
            add_ppa_signing_keys_callback=dict(required=False, default=""),
            codename=dict(required=False, default=""),
        )
    )
    module.exit_json = exit_json
    sudo_class = get_sudo_class(module)

    ubuntusourceslist = UbuntuSourcesList(module, add_ppa_signing_keys_callback=lambda a: sudo_class.run_command(a))

    assert ubuntusourceslist.repos_urls == []
    ppa_name = "ppa:nginx/stable"
    ubuntusourceslist.add_source(ppa_name)

# Generated at 2022-06-20 21:20:31.589590
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # use this to test in different versions of Python
    # interp = sys.executable
    # loc = os.path.abspath(__file__)
    # cmd = interp + ' ' + loc

    # use this to run tests in the same version of Python
    cmd = 'python -m ' + __name__

    source_old = 'deb http://downloads-distro.mongodb.org/repo/ubuntu-upstart dist 10gen'
    source_new = 'deb http://downloads-distro.mongodb.org/repo/ubuntu-upstart dist 10gen'
    comment_old = 'multiverse'
    comment_new = 'I will not change it'
    comment_new2 = 'other comment'

    os.environ['TMPDIR'] = '/tmp/'
    os.environ

# Generated at 2022-06-20 21:20:32.625680
# Unit test for function revert_sources_list
def test_revert_sources_list():
    raise NotImplementedError



# Generated at 2022-06-20 21:20:44.871993
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule({'src': 'http://example.com/repository main contrib', 'state': 'present', 'filename': 'ansible-test'})
    sl = SourcesList(module)
    assert len(sl.files) == 0
    sl.modify("test.list", 0, enabled=True, source='deb http://example.com/repository main contrib', comment="deb http://example.com/repository main contrib #added by ansible")
    assert len(sl.files) == 1
    assert "test.list" in sl.files
    assert len(sl.files["test.list"]) == 1

# Generated at 2022-06-20 21:20:55.910933
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # Test with no parameter file
    a = UbuntuSourcesList(dict(module=None, codename=None))

    # Test with non-ppa source lines
    a.add_source('deb http://us.archive.ubuntu.com/ubuntu/ bionic main restricted universe multiverse')
    assert a.files[a.default_file][0][3] == 'deb http://us.archive.ubuntu.com/ubuntu/ bionic main restricted universe multiverse'

    # Test with ppa source lines
    a.add_source('ppa:ansible/ansible')
    assert a.files[a.default_file][1][3] == 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu bionic main'

    # Test with ppa source lines and codename zesty

# Generated at 2022-06-20 21:20:59.785102
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('test')
    assert exc.args == ('test',)
    assert str(exc) == "test"



# Generated at 2022-06-20 21:21:09.744477
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = MagicMock()
    sourceslist = SourcesList(module)
    sourceslist._apt_cfg_dir = MagicMock(return_value='/test/dir')
    mocked_glob = MagicMock(return_value=['/test/dir/file.list'])
    with patch('glob.iglob', mocked_glob):
        f = MagicMock()
        f.readlines = MagicMock(return_value=['# deb http://example.com upstream main\n', 'deb http://example.com stable main\n'])
        with patch('builtins.open', f, create=True):
            sourceslist.load('/test/dir/file.list')
            it = iter(sourceslist)

# Generated at 2022-06-20 21:21:12.196033
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # SourcesList._add_valid_source
    # TODO(sashka): Write unit test.
    pass



# Generated at 2022-06-20 21:21:46.937731
# Unit test for function install_python_apt
def test_install_python_apt():
    m = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool'}})
    install_python_apt(m, 'python-apt')
    install_python_apt(m, 'python3-apt')


# get the default codename based on lsb-release information, or hard-code to 'xenial' if this is not available

# Generated at 2022-06-20 21:21:55.646344
# Unit test for constructor of class SourcesList
def test_SourcesList():
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    import os
    import aptsources.distro as aptsources_distro
    distro = aptsources_distro.get_distro()
    file = "/etc/apt/sources.list"
    sl = SourcesList(DistributionFactCollector())
    f = open(file, 'r')
    file_data = f.read()
    sl.load(file)
    try:
        assert file_data==sl.dump()
    except AssertionError:
        print("Wrong data in sources.list")


# Generated at 2022-06-20 21:21:57.649894
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule({})
    sourceslist = SourcesList(module)

    assert sourceslist is not None



# Generated at 2022-06-20 21:22:08.998765
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    class Module(object):
        def __init__(self, codename):
            self.params = {
                'codename': codename
            }

    class Distro(object):
        def __init__(self, codename):
            self.codename = codename

    module = Module('foo')
    distro = Distro('bar')
    sourceslist = UbuntuSourcesList(module)
    sourceslist.codename = 'foo'

    assert sourceslist.codename == 'foo'

    copy = copy.deepcopy(sourceslist)

    copy.codename = 'baz'

    assert sourceslist.codename == 'foo'
    assert copy.codename == 'baz'


# Generated at 2022-06-20 21:22:19.840751
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    _, f = tempfile.mkstemp()
    with open(f, 'w') as fd:
        fd.write("""
foo
deb http://example.com trusty main
bar
# deb http://example.org precise main
baz
# deb http://example.net precise main # comment
        """)
    sl = SourcesList(AnsibleModule(argument_spec={}))
    sl.load(f)

# Generated at 2022-06-20 21:22:22.540091
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    mymodule = collections.namedtuple('mymodule', ['params'])

    params = {'codename': 'xenial'}
    mymodule.params = params
    usl = UbuntuSourcesList(mymodule)

    # First test: check if method actually exists
    assert hasattr(usl, 'remove_source')



# Generated at 2022-06-20 21:22:33.631278
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Mock os functions to control class behavior
    os.path.isfile = lambda x: x in ['sources.list', 'sources.list.d/a.list']
    os.path.isdir = lambda x: x in ['sources.list.d']
    glob.iglob = lambda x: ['sources.list.d/a.list']
    os.makedirs = lambda x: True
    os.path.split = lambda x: ['sources.list.d', 'a.list']
    # Mock a temporary file handler
    tmp_file_mode = 0o0755
    tmp_file_data_dict = {}
    tmp_files = []
    def fdopen_mock(fd, mode):
        if mode == 'r':
            return tmp_file_data_dict[tmp_files[fd]]


# Generated at 2022-06-20 21:22:49.450919
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    """Check if dump is working for both Debian and Ubuntu layout"""
    # check for Debian layout
    class DummyModule(object):
        def __init__(self, extra_params=None):
            self.params = dict(
                repo='deb http://dl.google.com/linux/chrome/deb/ stable main',
                state='present',
                filename='google-chrome',
            )
            if extra_params:
                self.params.update(extra_params)
            self.params['mode'] = None

        def fail_json(self, **kwargs):
            raise AssertionError(kwargs)

        def atomic_move(self, src, dest):
            pass

        def set_mode_if_different(self, path, mode, changed):
            pass


# Generated at 2022-06-20 21:23:02.063159
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock()
    module.run_command = Mock()
    module.check_mode = False
    module.warn = Mock()

    callback = get_add_ppa_signing_key_callback(module)

    assert callback is not None

    callback(['apt-key', 'adv', '--recv-keys', '--no-tty', '--keyserver', 'hkp://keyserver.ubuntu.com:80', '12345678'])

    # run_command should be called exactly once because the callback function is not in check mode
    assert module.run_command.call_count == 1



# Generated at 2022-06-20 21:23:13.638955
# Unit test for method load of class SourcesList
def test_SourcesList_load():

    class Module(object):

        def __init__(self):
            self.params = {
                'filename': None,
            }

        def exit_json(self, **kwargs):
            pass

        @staticmethod
        def fail_json(msg):
            raise AssertionError(msg)

    module = Module()

    fd, tmp_path = tempfile.mkstemp()
    f = os.fdopen(fd, 'w')

    # input the test data

# Generated at 2022-06-20 21:24:17.773490
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    instance = UbuntuSourcesList(None)
    instance.files = {
        '/etc/apt/sources.list.d/yandex-disk.list': [
            (0, True, True, 'deb http://repo.yandex.ru/yandex-disk/deb/ stable main', ''), 
            (1, True, True, 'deb http://repo.yandex.ru/yandex-disk/deb/ stable main', '# Uncomment to receive updates')
        ]
    }
    instance.add_ppa_signing_keys_callback = None
    instance.module = None
    instance.codename = 'bionic'

    with pytest.raises(AssertionError) as err:
        instance.remove_source('')
    assert 'Source must be specified' in str(err.value)

# Generated at 2022-06-20 21:24:34.029751
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import tempfile
    module = {}
    sourceslist = SourcesList(module)
    sourceslist._expand_path = lambda filename: filename
    file = tempfile.mktemp()

    sourceslist.files[file] = [(0, True, True, 'deb http://example.com/ os distribution component1 component2', ''),
                               (1, True, True, 'deb http://example.com/ os distribution component1 component2', '# comment'),
                               (2, True, False, 'deb http://example.com/ os distribution component1 component2', ''),
                               (3, False, False, '', ''),
                               (4, True, True, 'deb http://example.com/ os distribution component1 component2 tool', '')]


# Generated at 2022-06-20 21:24:45.800293
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class module:
        @staticmethod
        def fail_json(msg):
            raise RuntimeError(msg)

    sourceslist = SourcesList(module)
    sourceslist.add_source('# deb http://archive.ubuntu.com/ubuntu utopic main',
                           '# deb-src http://archive.ubuntu.com/ubuntu utopic multiverse')

    # Remove comment-only line
    sourceslist.remove_source('# deb-src http://archive.ubuntu.com/ubuntu utopic multiverse')

    # Remove enabled deb source
    sourceslist.remove_source('deb http://archive.ubuntu.com/ubuntu utopic main')

    # Remove enabled deb source with comment
    sourceslist.add_source('deb http://archive.ubuntu.com/ubuntu utopic main', comment='disabled comment')

# Generated at 2022-06-20 21:24:53.625285
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    expected_source_list = """deb http://www.example.com unstable main # comment
deb http://www.example.com unstable main # comment
deb http://www.example.com unstable main # comment
"""
    sources_list = SourcesList()
    sources_list.load(expected_source_list)
    assert len(sources_list.files.keys()) == 1
    sources_list.remove_source('deb http://www.example.com unstable main')
    assert len(sources_list.files.keys()) == 0


# Generated at 2022-06-20 21:25:06.599533
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )

    temprory_file = '/tmp/sources.list'
    with open(temprory_file ,'w') as content:
        content.write('deb http://fake.url/\n')
        content.write('# deb http://fake.url/1\n')
        content.write('# deb http://fake.url/2\n')
        content.write('deb http://fake.url/3\n')

    sl = SourcesList(module)
    sl.default_file = temprory_file
    sl.load(temprory_file)

    # clean-up array of lists of sources

# Generated at 2022-06-20 21:25:10.726982
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    return get_add_ppa_signing_key_callback(None) == None

# Generated at 2022-06-20 21:25:11.712507
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    pass



# Generated at 2022-06-20 21:25:20.343201
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    s = SourcesList(None)

# Generated at 2022-06-20 21:25:30.190023
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    sl = SourcesList(None)
    sl.files = {
        '/tmp/some_file': [
            (0, True, True, 'source spec', 'comment'),
            (1, False, False, 'another source spec', 'another comment')
        ]
    }
    sl.modify('/tmp/some_file', 0, enabled=False)
    assert sl.files['/tmp/some_file'][0][2] == False
    sl.modify('/tmp/some_file', 0, comment='')
    assert sl.files['/tmp/some_file'][0][4] == ''
    sl.modify('/tmp/some_file', 0, source='new source spec')
    assert sl.files['/tmp/some_file'][0][3] == 'new source spec'
    sl.mod

# Generated at 2022-06-20 21:25:34.336912
# Unit test for function revert_sources_list
def test_revert_sources_list():
    def _mock_open(filename, mode):
        return io.StringIO()
    def _mock_rmtree(path):
        return None
    def _mock_remove(path):
        return None
    def _mock_rename(src, dest):
        return None
    def run_command(cmd, check_rc=True):
        return 1, "test", "test"

# Generated at 2022-06-20 21:27:35.662633
# Unit test for function main
def test_main():
    module_mock = mock.MagicMock(name='module_mock')
    module_mock.check_mode = False
    module_mock.params = {'repo': 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu trusty main', 'state': 'present', 'mode': '0644', 'update_cache': True, 'codename': '', 'update_cache_retries': 5, 'install_python_apt': True, 'update_cache_retry_max_delay': 12, 'filename': ''}
    module_mock._diff = True
    module_mock.fail_json.side_effect = fail_json
    module_mock.run_command.return_value = 0, '', ''
    module_mock.run_command.side_effect = None

# Generated at 2022-06-20 21:27:44.536701
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    module = FakeAnsibleModule()
    module.params['filename'] = None
    module.params['codename'] = None
    get_ppa_info = UbuntuSourcesList.LP_API % ('openstack-ubuntu-testing', 'icehouse-staging')

# Generated at 2022-06-20 21:27:55.665167
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Test SourceList iterator for source file with several source lines.
    filenames = []
    for d, f in [(apt_pkg.config.find_dir("Dir::Etc::sourceparts"), "ansible_test_file1"),
                   (apt_pkg.config.find_dir("Dir::Etc"), "sources.list")]:
        filename = os.path.join(d, f)
        if os.path.isfile(filename):
            os.remove(filename)
        filenames.append(filename)

    # Test SourceList iterator for source file with several source lines.
    for i in range(4):
        f = open(filenames[0], "a")
        # Add some disabled and enabled lines to test them all.
        if i % 2 == 0:
            f.write("# ")
        f

# Generated at 2022-06-20 21:27:59.345751
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule(argument_spec=dict())
    sources = UbuntuSourcesList(module)
    assert sources



# Generated at 2022-06-20 21:28:08.162123
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-20 21:28:13.636515
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    sources = SourcesList(module)
    for i, line in enumerate(sources):
        assert line == (None, i, True, 'deb http://archive.canonical.com/ubuntu hardy partner', None), "line = %s" % str(line)


# Generated at 2022-06-20 21:28:22.699204
# Unit test for method __iter__ of class SourcesList

# Generated at 2022-06-20 21:28:27.288072
# Unit test for constructor of class SourcesList
def test_SourcesList():
    p = { "filename": None,
          "state": "present",
          "update_cache": True }
    assert 'google-chrome.list' == SourcesList(AnsibleModule(argument_spec={}, params=p))._suggest_filename('deb [arch=amd64] http://dl.google.com/linux/chrome/deb/ stable main')
    assert '_'.join('ppa:nginx/stable'.split()) == SourcesList(AnsibleModule(argument_spec={}, params=p))._suggest_filename('deb http://ppa.launchpad.net/nginx/stable/ubuntu xenial main')



# Generated at 2022-06-20 21:28:39.263240
# Unit test for function revert_sources_list
def test_revert_sources_list():
    test_module = AnsibleModule(argument_spec={})
    test_sources_before = {}

# Generated at 2022-06-20 21:28:48.392880
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import os
    import shutil
    import tempfile

    class FakeModule:
        def __init__(self):
            self.params = {
                "filename": None,
                "state": 'present',
                "repo": 'deb http://archive.canonical.com/ubuntu hardy partner',
                "mode": 644
            }
            self.check_mode = False
            self.tmp_dir = tempfile.mkdtemp()
            self.src_file = self.params['repo'].split()[1]
            self.package = 'python-apt'
            self.changed = False
            self.fail_json = None

            # self.get_bin_path = lambda x: return x if x in {'apt-get', 'dpkg', 'apt-key'} else None
