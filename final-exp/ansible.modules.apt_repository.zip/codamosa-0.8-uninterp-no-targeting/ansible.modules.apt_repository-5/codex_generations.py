

# Generated at 2022-06-20 21:20:09.660646
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    import copy
    import sys
    import random
    import time
    class AnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.fail_json_called=False
            self.fail_json_msg=""
            self.exit_args = {}
            self.called=False
            self.no_log=False
            self.check_mode=False
            self.debug=False
            self.no_log=False
            self.verbose=False
            self.changed=False
            self.warnings=[]
            self.params["repo"] = "deb http://archive.canonical.com/ubuntu hardy partner"
            self.params["state"] = "absent"
            file="/tmp/apt_module_" + str(random.randint(0,sys.maxsize))

# Generated at 2022-06-20 21:20:20.106178
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    '''
    Testing the UbuntuSourcesList class with a default codename (trusty)
    '''
    import pprint
    import StringIO
    import random
    random.seed(1)
    module = AnsibleModule(argument_spec={})
    sources = UbuntuSourcesList(module)

    # save initial sources
    initial_sources = sources.dump()

    # add a PPA
    sources.add_source('ppa:chris-lea/redis-server', comment='Added by Ansible', file=None)
    sources.add_source('ppa:foobar', comment='Added by Ansible', file=None)
    sources.save()

    # check whether the PPA is present

# Generated at 2022-06-20 21:20:30.397266
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    '''Unit test for SourcesList.modify'''

    def _dump(sl):
        '''Helper function that dumps SourcesList in human-readable form'''
        lines = []
        for filename, n, enabled, source, comment in sl:
            chunks = []
            if not enabled:
                chunks.append('# ')
            chunks.append(source)
            if comment:
                chunks.append(' # ')
                chunks.append(comment)
            lines.append(''.join(chunks))
        return '\n'.join(lines)

    # Source is valid. Modifying comment.
    sl = SourcesList(None)
    sl.files[None] = [
        (0, True, True, 'deb http://foo', 'bar'),
    ]

    sl.modify(None, 0, comment='baz')



# Generated at 2022-06-20 21:20:42.994320
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    # Simple test case: sources.list contains one valid source
    test_sl_1 = SourcesList(None)
    test_sl_1.files['sources.list'] = [
        (0, True, True, 'deb http://archive.canonical.com/ubuntu trusty partner', 'partner repository'),
    ]
    assert list(test_sl_1) == [('sources.list', 0, True, 'deb http://archive.canonical.com/ubuntu trusty partner', 'partner repository')]

    # Simple test case: sources.list contains one disabled source
    test_sl_2 = SourcesList(None)
    test_sl_2.files['sources.list'] = [
        (0, True, False, 'deb http://archive.canonical.com/ubuntu trusty partner', 'partner repository'),
    ]


# Generated at 2022-06-20 21:20:55.071090
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    def get_module_mock(*args, **kwargs):
        class ModuleMock:
            def __init__(self, *args, **kwargs):
                self.params = {}
                self.params['codename'] = 'focal'

        return ModuleMock()

    module_mock = get_module_mock()

    sources_list = UbuntuSourcesList(module_mock)
    sources_list._add_valid_source('deb http://ppa.launchpad.net/coopermaa/testppa/ubuntu focal main', '')


# Generated at 2022-06-20 21:21:05.015874
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule({}, check_invalid_arguments=False)
    sources_list = SourcesList(module)

    # Add a source in default file.
    sources_list.add_source('deb http://repo1.example.com/ubuntu/ trusty main')
    dump = sources_list.dump()

    assert dump.keys() == [sources_list._apt_cfg_file('Dir::Etc::sourcelist')]
    assert dump.values() == ['deb http://repo1.example.com/ubuntu/ trusty main\n']

    # Add a source in the same file.
    sources_list.add_source('deb http://repo2.example.com/ubuntu/ trusty main')
    dump = sources_list.dump()


# Generated at 2022-06-20 21:21:07.305012
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    sl = SourcesList(AnsibleModule)
    sl.files = {}
    sl.load('/etc/apt/sources.list')



# Generated at 2022-06-20 21:21:16.096141
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.basic import AnsibleModule

    src = unfrackpath("/usr/share/ansible/ansible/module_utils/apt_pkg.py")
    mod = get_module_path(src, 'apt_pkg')
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    result = get_add_ppa_signing_key_callback(module)
    assert result is None, "Result %s is not None" % result

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    result = get_add_ppa_signing_key_callback(module)

# Generated at 2022-06-20 21:21:18.559126
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    assert False, 'No test for method save in class SourcesList'


# Generated at 2022-06-20 21:21:24.054518
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    # We don't need to check the function output, it will be done automatically
    # by the class constructur, which we simulate here.
    # The reason is that this function calls the function fetch_url,
    # which requires a defined AnsibleModule instance, so it's non-trivial
    # to create a proper test for it.
    UbuntuSourcesList(None, add_ppa_signing_keys_callback=None)

# Generated at 2022-06-20 21:22:02.351844
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    obj = SourcesList(None)
    obj.files = {
        'foo': [
            (0, True, True, 'deb http://example.org/debian stable main', ''),
            (1, False, True, 'deb http://example.org/debian testing main', ''),
            (2, True, False, 'deb http://example.org/debian unstable main', ''),
            (3, True, True, 'deb http://example.org/debian stable-backports main', ''),
        ]
    }
    res = [(filename, n, enabled, source, comment) for filename, n, enabled, source, comment in obj]

# Generated at 2022-06-20 21:22:12.097998
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    test_sources_list = UbuntuSourcesList()
    test_sources_list.files = {
        '/etc/apt/sources.list': [(0, True, True, 'ppa:smoser/test', '')],
        '/etc/apt/sources.list.d/smoser-test-ubuntu-test-xenial.list': [(1, True, True, 'deb http://ppa.launchpad.net/smoser/test/ubuntu xenial main', '')]
    }
    # test remove single entry
    test_sources_list.remove_source('ppa:smoser/test')

# Generated at 2022-06-20 21:22:21.554058
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Test case 1: one source
    sources = UbuntuSourcesList(module=MagicMock())
    source_line = 'deb http://test.com/test/test'
    sources.add_source(source_line)
    sources.remove_source(source_line)
    assert sources.files == {}

    # Test case 2: one source with comment
    sources = UbuntuSourcesList(module=MagicMock())
    sources.add_source('deb http://test.com/test/test', comment='test comment')
    sources.remove_source('deb http://test.com/test/test # test comment')
    assert sources.files == {}

    # Test case 3: multiple sources
    sources = UbuntuSourcesList(module=MagicMock())
    sources.add_source('deb http://test.com/test/test', comment='test comment')


# Generated at 2022-06-20 21:22:33.149521
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    from ansible.module_utils.apt_repository import SourcesList
    sl = SourcesList(probe_interpreters_for_module()[0])
    sl.load('/usr/share/doc/python-apt-common/examples/sources.list')
    lines = list(sl)
    assert len(lines) == 10
    assert lines[0] == ('/usr/share/doc/python-apt-common/examples/sources.list', 0, True, 'deb http://ftp.de.debian.org/debian/ stretch main', '')
    assert lines[1] == ('/usr/share/doc/python-apt-common/examples/sources.list', 1, True, 'deb-src http://ftp.de.debian.org/debian/ stretch main', '')



# Generated at 2022-06-20 21:22:33.699106
# Unit test for function install_python_apt
def test_install_python_apt():
    pass


# Generated at 2022-06-20 21:22:34.746714
# Unit test for function main
def test_main():
    with pytest.raises(AnsibleFailJson):
        main()

# Generated at 2022-06-20 21:22:41.518831
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = Mock()
    sl = UbuntuSourcesList(module)
    ex_line = 'deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main'
    sl.add_source('ppa:ansible/ansible')
    sl.remove_source("ppa:ansible/ansible")
    assert ex_line not in list(sl)


# Generated at 2022-06-20 21:22:51.517862
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    class MockModule():
        def __init__(self):
            self.params = dict()
            self.params['codename'] = None
            self.params['filename'] = None
            self.params['mode'] = None

        def fail_json(self, msg):
            raise Exception(msg)

        def atomic_move(self):
            pass

    source_list = UbuntuSourcesList(MockModule())
    source_list.load('tests/resources/sources.list.test')
    source_list.remove_source('ppa:kdenlive/kdenlive-stable')

# Generated at 2022-06-20 21:22:52.026006
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    pass

# Generated at 2022-06-20 21:23:02.527558
# Unit test for function main

# Generated at 2022-06-20 21:24:10.715175
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.params['apt_src'] = dict()
            self.params['apt_src']['keyserver'] = 'hkp://keyserver.ubuntu.com'
            self.params['apt_src']['key'] = 'C300EE8C'
            self.params['apt_src']['key_server'] = 'hkp://keyserver.ubuntu.com'
        def atomic_move(self,original,final):
            return "Fake ansible.module_utils.basic.AnsibleModule.atomic_move()"

# Generated at 2022-06-20 21:24:22.572241
# Unit test for function main
def test_main():
    import sys
    import tempfile

# Generated at 2022-06-20 21:24:28.179798
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
        module = MagicMock()
        sl = SourcesList(module)
        sl.files = {'/home/test/no_exist.list': [('test1', True, True, 'test1', 'test1')]}
        sl.remove_source('test1')
        assert not sl.files['/home/test/no_exist.list']


# Generated at 2022-06-20 21:24:37.198592
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    execute_module = module.params['_ansible_execute_module']
    sources_list = UbuntuSourcesList(module)

    ppa_uri = "ppa:ansible/ansible"
    sources_list.add_source(ppa_uri)
    execute_module(sources_list, changed=True)

    source = sources_list._expand_ppa(ppa_uri)[0]
    sources_list.remove_source(source)
    execute_module(sources_list, changed=True)

    sources_list.remove_source(ppa_uri)
    execute_module(sources_list, changed=False)



# Generated at 2022-06-20 21:24:47.775949
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # init
    module = None
    sources_list = SourcesList(module)
    # filename, n, enabled, source, comment
    sources_list.files = {
        'name1': [(0, True, True, '0', '0'),
                  (1, True, True, '1', '1'),
                  (2, True, True, '2', '2'),
                  (3, True, True, '3', '3'),
                  (4, False, True, '4', '4'),
                  (5, True, False, '5', '5'),
                  (6, False, False, '6', '6'),
                  (7, True, True, '7', '7'),
                  (8, True, True, '8', '8')]
    }
    # name, n, enabled, source, comment
    sources_

# Generated at 2022-06-20 21:24:57.754476
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
        }
    )
    module.params['filename'] = None

    aptsources = UbuntuSourcesList(module)

    test_source_1 = 'deb http://ppa.launchpad.net/asdf1/asdf2/ubuntu   bionic  main'
    test_source_2 = 'deb http://ppa.launchpad.net/asdf1/asdf3/ubuntu   bionic  main'
    test_source_3 = 'deb http://ppa.launchpad.net/asdf1/asdf4/ubuntu   bionic  main'
    test_source_4 = 'deb http://ppa.launchpad.net/asdf1/asdf5/ubuntu   bionic  main'

# Generated at 2022-06-20 21:25:07.868579
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    import tempfile
    tempf = tempfile.NamedTemporaryFile(mode='w+')
    tempf.write('deb http://example.com/ distributive component1 component2\n')
    tempf.write('# deb http://example.com/ distributive component1 component2\n')
    tempf.write('deb-src http://example.com/ distributive component1 component2 # comment\n')
    tempf.seek(0)
    sl = SourcesList(None)
    sl.load(tempf.name)

    assert sl.dump() == {tempf.name: 'deb http://example.com/ distributive component1 component2 # comment\n'}

    tempf.close()

# Generated at 2022-06-20 21:25:23.295272
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    # TODO: Refactor tests to work without AnsibleModule
    m = AnsibleModule(argument_spec={})
    s = SourcesList(m)

    # Normal source
    s.add_source('deb http://archive.ubuntu.com/ubuntu quantal main', comment='# test')
    assert len(s.files) == 1
    assert s.files[s._apt_cfg_file('Dir::Etc::sourcelist')] == [(0, True, True, 'deb http://archive.ubuntu.com/ubuntu quantal main', '# test')]

    # Existing source, different case
    s.add_source('deb http://archive.ubuntu.com/ubuntu trusty main')
    assert len(s.files[s._apt_cfg_file('Dir::Etc::sourcelist')]) == 1

    # Disable existing source
    s

# Generated at 2022-06-20 21:25:28.697952
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    sl = SourcesList('module')
    sl.load('/etc/apt/sources.list')
    dumpstruct = sl.dump()
    assert isinstance(dumpstruct, dict)
    assert isinstance(dumpstruct['/etc/apt/sources.list'], str)


# Generated at 2022-06-20 21:25:36.391228
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils._text import to_native
    from ansible.module_utils.basic import AnsibleModule

    class TestAnsibleModule(AnsibleModule):
        def __init__(self, *args, **kwargs):
            super(TestAnsibleModule, self).__init__(*args, **kwargs)

        def fail_json(self, *args, **kwargs):
            raise Exception(to_native(kwargs['msg']))
    module = TestAnsibleModule({})
    sl = UbuntuSourcesList(module)

# Generated at 2022-06-20 21:29:23.487767
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():

    def test_helper(info, expected_result):
        sources_list = SourcesList(info)
        assert [(filename, n, enabled, source, comment) for filename, n, enabled, source, comment in sources_list] == expected_result

    # Test with valid source.
    info = {'files': {'/etc/apt/sources.list': [(0, True, True, "deb http://archive.canonical.com/ubuntu bionic partner", '')]}}
    test_helper(info, [('/etc/apt/sources.list', 0, True, "deb http://archive.canonical.com/ubuntu bionic partner", '')])

    # Test with valid source from sourceparts.

# Generated at 2022-06-20 21:29:34.457836
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)
    sources.files = {
        'testfile': [
            (0, True, True, 'valid_source_1', 'comment_1'),
            (1, True, True, 'valid_source_2', 'comment_2'),
            (2, True, True, 'valid_source_3', 'comment_3'),
        ]
    }
    sources.modify('testfile', 1, enabled=False)
    assert sources.files['testfile'][1][1] is False
    sources.modify('testfile', 0, source='modified_source_1')
    assert sources.files['testfile'][0][3] == 'modified_source_1'