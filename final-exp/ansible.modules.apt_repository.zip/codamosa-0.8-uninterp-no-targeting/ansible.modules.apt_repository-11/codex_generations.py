

# Generated at 2022-06-20 21:20:22.847516
# Unit test for function install_python_apt
def test_install_python_apt():
    global apt
    # Set up fake module
    module = AnsibleModule({'use_backend': 'auto', 'install_python_apt': True}, '', True)
    # Monkey patch module.run_command
    old_run_command = module.run_command
    stub_commands = {
        'apt-get install -y -q python-apt': False,
        'apt-get install -y -q python3-apt': False
    }
    def fake_run_command(command):
        """Stub for module.run_command that just remembers which command
        was run."""
        if isinstance(command, list):
            command = ' '.join(command)
        stub_commands[command] = True
        return old_run_command(command)
    module.run_command = fake_run_command
    #

# Generated at 2022-06-20 21:20:32.883277
# Unit test for function main
def test_main():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    sys.modules['ansible.module_utils.basic'] = basic

# Generated at 2022-06-20 21:20:42.198675
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec={})
    sources = SourcesList(module)

    class Args:
        pass
    args = Args()
    args.source = "deb http://mirror.yandex.ru/debian/ testing main"
    args.comment = "debian mirror yandex"
    args.filename = "debian-yandex"

    sources.add_source(args.source, comment=args.comment, file=args.filename)

    module.fail_json(changed=True, msg="SourcesList.add_source test passed", sources_list=sources.dump())



# Generated at 2022-06-20 21:20:55.732459
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class TestModule(object):
        params = {}
        def __init__(self, **kwargs):
            self.params.update(**kwargs)
        def fail_json(self, msg=''):
            return msg
        def atomic_move(self, from_path, to_path):
            return
        def set_mode_if_different(self, path, mode, changed):
            return
    test_module = TestModule()
    test_sources_list = SourcesList(test_module)

    test_sources_list.add_source("deb http://download.webmin.com/download/repository sarge contrib")

    return test_sources_list.files


# Generated at 2022-06-20 21:20:59.644361
# Unit test for constructor of class InvalidSource
def test_InvalidSource():

    try:
        raise InvalidSource('Bad source')
    except InvalidSource as e:
        assert str(e) == 'Bad source'



# Generated at 2022-06-20 21:21:09.901615
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import tempfile

    fd, tmp_path = tempfile.mkstemp()
    os.close(fd)
    file_content = 'test\n'

    with open(tmp_path, 'w') as f:
        f.write(file_content)

    sources_before = {tmp_path: file_content}
    sources_after = {tmp_path: 'test2\n'}
    m = AnsibleModule({'repo_file': tmp_path})
    sourceslist_before = DummySourcesList(m, modules=fake_modules)
    for k, v in sources_before.items():
        sourceslist_before.files[k] = list(sourceslist_before._parse(line) for line in v.splitlines())


# Generated at 2022-06-20 21:21:17.231177
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    filename = '/tmp/test_SourcesList_load.list'
    lines = [ '    \n', '# test comment\n', '#test \n', 'deb http://test \n', 'deb-src http://test\n' ]
    fd, tmp_path = tempfile.mkstemp(prefix=".%s-" % filename, dir='/tmp')
    with os.fdopen(fd, 'w') as f:
        f.write(''.join(lines))
    os.rename(tmp_path, filename)
    sources = SourcesList(None)
    sources.load(filename)

# Generated at 2022-06-20 21:21:25.599979
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    module = AnsibleModule({})
    dummy_srcs = UbuntuSourcesList(module)

# Generated at 2022-06-20 21:21:41.066367
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    from ansible.module_utils import basic
    from ansible.module_utils.common.parameters import ParameterError
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-20 21:21:50.852294
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    import ansible.module_utils.basic
    import ansible.module_utils.apt_repository
    import ansible.module_utils._text

    # Mock
    class MockAnsibleModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def fail_json(self, *args, **kwargs):
            raise Exception(to_native(args[0]))

        @staticmethod
        def get_bin_path(command, *args, **kwargs):
            if command == 'apt-get':
                return apt_get

        def run_command(self, command):
            if command == [apt_get, 'update']:
                return 0, '', ''

# Generated at 2022-06-20 21:22:33.264458
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    # Test with empty files
    sources_list = SourcesList(None)
    assert sources_list.files == {}
    sources_list.save()
    assert sources_list.files == {}

    # Test with new repo
    sources_list = SourcesList(None)
    sources_list.add_source('deb http://archive.canonical.com/ubuntu trusty partner')
    assert sources_list.files != {}
    sources_list.save()
    assert sources_list.files == {}

    # Test with existing repo
    sources_list = SourcesList(None)
    sources_list.load(os.path.abspath('./test_sources.list'))
    sources_list.add_source('deb http://archive.canonical.com/ubuntu trusty partner', file='test_sources.list')
    assert sources_

# Generated at 2022-06-20 21:22:35.198723
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    assert InvalidSource("test")
    try:
        raise InvalidSource("test")
    except InvalidSource:
        assert True


# Generated at 2022-06-20 21:22:42.007606
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    result = {
        'one': '# deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted\n',
        'two': '# deb http://archive.ubuntu.com/ubuntu/ xenial universe multiverse\n'
    }
    sources = SourcesList('')
    sources.files['one'] = [(0, True, False, 'deb-src http://archive.ubuntu.com/ubuntu/ xenial main restricted', '')]
    sources.files['two'] = [(0, True, False, 'deb http://archive.ubuntu.com/ubuntu/ xenial universe multiverse', '')]
    assert sources.dump() == result



# Generated at 2022-06-20 21:22:46.157675
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import pprint
    module = MockModule()
    sl = SourcesList(module)
    sl.files = {'/etc/apt/sources.list': [(0, True, True, 'deb http://example.com/debian/ stable main', 'toto')]}
    sl.modify('/etc/apt/sources.list', 0, enabled=False, comment='titi')
    assert len(sl.files['/etc/apt/sources.list']) == 1
    assert sl.files['/etc/apt/sources.list'][0] == (0, True, False, 'deb http://example.com/debian/ stable main', 'titi')



# Generated at 2022-06-20 21:22:47.121210
# Unit test for function revert_sources_list
def test_revert_sources_list():
    '''
    Function to test revert_sources_list
    '''

    result = revert_sources_list()
    assert result == None


# Generated at 2022-06-20 21:22:55.003798
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    sl = SourcesList(module)
    sl.add_source('deb http://archive.ubuntu.com/ubuntu/ trusty main')
    assert(sl.files['/etc/apt/sources.list'][0][3] == 'deb http://archive.ubuntu.com/ubuntu/ trusty main')



# Generated at 2022-06-20 21:23:03.097055
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():

    class Module(object):
        def fail_json(self, *args, **kwargs):
            raise Exception(args, kwargs)
    module = Module()

    sl = SourcesList(module)

# Generated at 2022-06-20 21:23:08.195935
# Unit test for function install_python_apt
def test_install_python_apt():

    module = AnsibleModule({'install_python_apt': True
        },check_invalid_arguments=False)
    install_python_apt(module, 'python-apt')

    if HAVE_PYTHON_APT:
        import apt
        assert(apt)
    else:
        module.fail_json(msg='Failed to import apt')


# Generated at 2022-06-20 21:23:16.791350
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = AnsibleModule({
        'state': 'present',
        'update_cache': 'yes',
        'repo': ['ppa:user/ppa-name/ubuntu'],
        'vtype': 'deb'
    })
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda msg: msg
    module.run_command = lambda cmd, check_rc=True: (0, '', '') if cmd == 'lsb_release -cs' else (0, '', '')

    # Instance test
    try:
        sl = UbuntuSourcesList(module)
        module.exit_json(changed=False, result={"repos": sl.repos_urls})
    except Exception as err:
        module.fail_json(msg=to_native(err))

# Generated at 2022-06-20 21:23:18.479865
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    pass



# Generated at 2022-06-20 21:24:41.280188
# Unit test for function install_python_apt
def test_install_python_apt():
    pass



# Generated at 2022-06-20 21:24:57.176395
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    class ModuleStub:
        def atomic_move(self, tmp_path, filename):
            self.atomic_moves.append((tmp_path, filename))


# Generated at 2022-06-20 21:25:09.182279
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class MockModule(object):
        pass
    module = MockModule()
    module.check_mode = False
    module.exit_json = lambda v: None
    module.fail_json = lambda v: None
    module.atomic_move = lambda src, dst: open(dst, 'w').write(open(src).read())
    module.set_mode_if_different = lambda fn, mode, changed: None
    module.run_command = lambda cmd: (0, '', '')
    sources = SourcesList(module)
    sources.add_source('deb http://archive.canonical.com/ubuntu raring partner')
    sources.add_source('deb http://archive.ubuntu.com/ubuntu precise partner')
    sources.add_source('# deb http://archive.canonical.com/ubuntu raring partner')
    sources.add

# Generated at 2022-06-20 21:25:12.478962
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    exc = InvalidSource('test_exc')
    assert str(exc) == 'test_exc'



# Generated at 2022-06-20 21:25:20.480118
# Unit test for function main
def test_main():

    import ansible.utils


# Generated at 2022-06-20 21:25:33.448258
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    import types
    module = AnsibleModule(argument_spec={})
    sources_list = SourcesList(module)

    # init test sources.list file
    filename = 'test_sources.list'

# Generated at 2022-06-20 21:25:45.556709
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import os
    import random
    import shutil
    def _mock_atomic_move(src, dest):
        shutil.move(src, dest)
    # Prepare test
    test_dir = os.path.join('/tmp', 'tmp_' + ''.join([random.choice('abcdefghijklmnopqrstuvwxyz0123456789') for x in range(5)]))
    os.mkdir(test_dir)
    apt_pkg.config.set("Dir::Etc::sourceparts", test_dir)
    apt_pkg.config.set("Dir::Etc::sourcelist", os.path.join(test_dir, 'sources.list'))
    sl = SourcesList(None)
    sl.module = MagicMock()
    sl.module.atomic_move = _mock

# Generated at 2022-06-20 21:25:46.235515
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    pass

# Generated at 2022-06-20 21:25:57.336773
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    # Try to remove one invalid source
    # Input
    sources = SourcesList(None)
    sources.files = {'default': [(0, True, True, 'deb-src  test')]}
    # Expected Output
    expected = {'default': [(0, True, True, 'deb-src  test')]}
    # Actual Output
    sources.remove_source('deb-src http://example.com/test')
    # Assertion
    assert sources.files == expected
    # Try to remove one invalid source
    # Input
    sources = SourcesList(None)
    sources.files = {'default': [(0, True, False, 'deb-src  test')]}
    # Expected Output
    expected = {'default': [(0, True, False, 'deb-src  test')]}
    # Actual Output
    sources.remove

# Generated at 2022-06-20 21:26:01.285080
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    error_msg = "Some message"
    try:
        raise InvalidSource(error_msg)
    except InvalidSource as exception_raised:
        assert exception_raised.message == error_msg
