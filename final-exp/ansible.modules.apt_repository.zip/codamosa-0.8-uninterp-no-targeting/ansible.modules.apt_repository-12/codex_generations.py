

# Generated at 2022-06-20 21:20:08.122623
# Unit test for function revert_sources_list
def test_revert_sources_list():
    import os
    import tempfile
    import shutil

    module = AnsibleModule('')

    contents_before = {
        '/etc/apt/sources.list': 'deb http://packages.example.org/ubuntu/ xenial main universe\n'
    }
    contents_after = {
        '/etc/apt/sources.list': 'deb http://packages.example.org/ubuntu/ xenial main universe\n'
    }

    # First create the source list files with the new syntax.
    sources_before = UbuntuSourcesList(module)
    sources_after = UbuntuSourcesList(module)
    tempdir = tempfile.mkdtemp(prefix='ansible-tmp-')

# Generated at 2022-06-20 21:20:13.080074
# Unit test for method modify of class SourcesList
def test_SourcesList_modify():
    # Python 2.7 compatibility
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    sourceslist = SourcesList(module)
    sourceslist.load('./ansible_apt_repository_sources')
    assert sourceslist.files
    sourceslist.modify('./ansible_apt_repository_sources', 1, enabled=False)
    sourceslist.files['./ansible_apt_repository_sources'][1][2] == False

# Generated at 2022-06-20 21:20:19.141212
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = {
        'run_command': lambda *args, **kwargs: None,
        'fail_json': lambda *args, **kwargs: None
    }
    sources_list = UbuntuSourcesList(module)
    assert sources_list.default_file == "/etc/apt/sources.list"
    assert sources_list.codename == distro.codename
    assert sources_list.add_ppa_signing_keys_callback is None


# Generated at 2022-06-20 21:20:28.962102
# Unit test for function install_python_apt
def test_install_python_apt():
    module = AnsibleModule({'install_python_apt': True, 'check_mode': False})
    apt_pkg_name = ''
    install_python_apt(module, apt_pkg_name)
    assert ut_apt_pkg_name == ''
    assert rc == 0
    module = AnsibleModule({'install_python_apt': True, 'check_mode': True})
    apt_pkg_name = ''
    install_python_apt(module, apt_pkg_name)
    assert ut_apt_pkg_name == ''
    assert rc != 0
#######################################################################################################################
# Unit Testing

FAKE_SOURCE_FILE = '''
"# comment line"
" # comment line with spaces"
"test line"
'''


# Generated at 2022-06-20 21:20:33.019838
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    assert 'ubuntu_sources_list' in globals()
    b = deepcopy(ubuntu_sources_list)  # pylint: disable=undefined-variable
    assert b is not ubuntu_sources_list  # pylint: disable=undefined-variable
    assert b.add_ppa_signing_keys_callback is ubuntu_sources_list.add_ppa_signing_keys_callback  # pylint: disable=undefined-variable
    b.add_source('ppa:foo/bar')
    assert 'foo' not in ubuntu_sources_list.files  # pylint: disable=undefined-variable
    assert 'foo' in b.files

# Generated at 2022-06-20 21:20:41.716856
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    check_mode_callback = get_add_ppa_signing_key_callback(module)
    # check_mode_callback should be None, because module is in check mode
    assert check_mode_callback is None

    no_check_mode_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    no_check_mode_callback = get_add_ppa_signing_key_callback(no_check_mode_module)
    # no_check_mode_callback should not be None, because module is not in check mode
    assert no_check_mode_callback is not None
    # assert no_check_mode_callback is function

# Generated at 2022-06-20 21:20:46.521723
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    pass
    # file.src and file.dst should be filled
    # file.src should have source to be parsed
    # file.dst should be empty
    # sources_list = SourcesList(module=None)
    # expected_result = None
    # result = sources_list.__iter__()
    # assert result == expected_result



# Generated at 2022-06-20 21:20:49.258120
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    is_ = InvalidSource('This is exception')
    assert is_.args[0] == 'This is exception'


# Generated at 2022-06-20 21:20:56.527785
# Unit test for function install_python_apt
def test_install_python_apt():
    python_apt_name = 'python-apt'
    m = AnsibleModule(argument_spec={'install_python_apt': {'type': 'bool', 'default': True}})
    apt_get_path = m.get_bin_path('apt-get')
    if not apt_get_path:
        m.fail_json(msg="apt-get not found. Cannot auto-install %s. "
                    "You can either: 1) install %s manually, or "
                    "2) disable auto-installation by adding "
                    '"install_python_apt: False" to the apt_repository '
                    "call." % (python_apt_name, python_apt_name))



# Generated at 2022-06-20 21:21:03.632513
# Unit test for function main

# Generated at 2022-06-20 21:21:42.539545
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    if not HAVE_PYTHON_APT:
        return
    def _parse_test_data(test_data):
        test_data = test_data.split('===')
        # The test data is a dict with following keys, each key has its own set of expeted values.
        #   - new_repos - a set of new repositories which are added, the format is (file_name, expected_len_of_new_repo).
        #   - files - a dict with following keys:
        #     - file_name - a file name to test
        #     - contents - a list of expected contents in this file, each content is a dict with following keys:
        #       - n - the line number
        #       - valid - whether this line is a valid source line
        #       - enabled - whether this line is enabled
        #

# Generated at 2022-06-20 21:21:46.062597
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule({})
    sources_list = SourcesList(module)
    sources_list.save()


# Generated at 2022-06-20 21:21:48.638990
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource()
    except InvalidSource:
        assert True
    except Exception:
        assert False



# Generated at 2022-06-20 21:21:59.997184
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
    module = AnsibleModule({})
    module.exit_json = lambda *args, **kwargs: None
    sl = SourcesList(module)
    assert list(sl) == []

    tsource = 'deb http://apt.example.com/debian wheezy main'
    sl.add_source(tsource)
    assert list(sl) == [('/etc/apt/sources.list', 0, True, tsource, None)]

    tsource2 = 'deb http://apt.example.com/debian wheezy main'
    sl.add_source(tsource2)
    assert list(sl) == [('/etc/apt/sources.list', 0, True, tsource, None),
                        ('/etc/apt/sources.list', 1, True, tsource2, None)]


# Generated at 2022-06-20 21:22:05.116640
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    if not InvalidSource:
        return

    try:
        raise InvalidSource("Test exception")
    except InvalidSource as e:
        if not ("Test exception" in e.message):
            raise Exception("InvalidSource exception does not contain a message")
    except:
        raise Exception("InvalidSource exception is not InvalidSource")


# Generated at 2022-06-20 21:22:11.668554
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class MockAddSigningKeyCallback():
        def __init__(self):
            self.keys = []

        def add_ppa_signing_keys(self, command):
            self.keys.append(command)

    module = MagicMock(name='module')
    module.params = dict(
        codename='xenial',
        filename=None
    )
    module.run_command = MagicMock(name='run_command')
    module.run_command.return_value = (0, '', '')


# Generated at 2022-06-20 21:22:18.169522
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(argument_spec={})
    object = UbuntuSourcesList(module=module)
    object2 = deepcopy(object)
    assert isinstance(object2, UbuntuSourcesList)
    assert object.__dict__ != object2.__dict__
    assert object.module == object2.module
    assert object.add_ppa_signing_keys_callback == object2.add_ppa_signing_keys_callback
    assert object.codename == object2.codename


# Generated at 2022-06-20 21:22:23.155076
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = AnsibleModule(
        argument_spec={'codename': {'default': None, 'type': 'str'}}
    )
    add_ppa_signing_keys_callback = None
    list = UbuntuSourcesList(module, add_ppa_signing_keys_callback)
    assert list.__deepcopy__() is not list
    assert isinstance(list.__deepcopy__(), UbuntuSourcesList)
    assert list.__deepcopy__().module is list.module
    assert list.__deepcopy__().add_ppa_signing_keys_callback is list.add_ppa_signing_keys_callback



# Generated at 2022-06-20 21:22:25.581160
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MockAnsibleModule()
    def callback(command):
        pass
    s = UbuntuSourcesList(module, add_ppa_signing_keys_callback=callback)
    s2 = copy.deepcopy(s)
    assert s2.add_ppa_signing_keys_callback == callback



# Generated at 2022-06-20 21:22:35.068258
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    import shutil
    apt_pkg.config.clear()
    apt_pkg.config.set('Dir::Etc::sourcelist', '/tmp/SourcesList/sources.list')
    apt_pkg.config.set('Dir::Etc::sourceparts', '/tmp/SourcesList/sources.list.d')
    try:
        shutil.rmtree('/tmp/SourcesList')
    except:
        pass
    os.makedirs('/tmp/SourcesList/sources.list.d')

    sl = SourcesList(None)
    sl.files = {
        '/tmp/SourcesList/sources.list': [
            (0, True, True, 'deb http://example.com/ubuntu trusty main', None),
        ]
    }
    sl.save()

# Generated at 2022-06-20 21:23:38.855346
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec={},
    )

    if PY3:
        # with_mock_output doesn't work with py3
        pass
    else:
        with module.mock_output():
            callback = get_add_ppa_signing_key_callback(module)

        assert callback is not None



# Generated at 2022-06-20 21:23:39.209303
# Unit test for function revert_sources_list
def test_revert_sources_list():
    pass



# Generated at 2022-06-20 21:23:51.129651
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    from ansible.module_utils.common.text.converters import to_bytes
    class FakeModule():
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            pass
        def atomic_move(self, *args, **kwargs):
            pass
        def set_mode_if_different(self, *args, **kwargs):
            pass

# Generated at 2022-06-20 21:23:56.406041
# Unit test for constructor of class SourcesList
def test_SourcesList():
    module = AnsibleModule(argument_spec={})
    s = SourcesList(module)
    assert "Dir::Etc::sourcelist" in s.default_file
    assert s.default_file == s._apt_cfg_file("Dir::Etc::sourcelist")
    assert isinstance(s.files, dict)
    assert isinstance(s.new_repos, set)


# Generated at 2022-06-20 21:24:03.559029
# Unit test for function main
def test_main():
    from .mock_module import AnsibleModule, ansible_module_get_ansible_version
    import os
    import tempfile
    import shutil

    # Data taken from
    # http://packages.ubuntu.com/source/xenial/rabbitmq-server
    SAMPLE_SOURCE = 'deb http://us.archive.ubuntu.com/ubuntu/ xenial main'

    def touch(filename, data=''):
        with open(filename, 'w+') as f:
            f.write(data)

    class UbuntuSourcesListMock(UbuntuSourcesList):
        def __init__(self, *args, **kwargs):
            super(UbuntuSourcesListMock, self).__init__(*args, **kwargs)
            self.updated = False
            self.added_file = None


# Generated at 2022-06-20 21:24:10.704093
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = Mock()
    module.params = dict()
    module.params['codename'] = 'test_codename'
    usl = UbuntuSourcesList(module)
    assert usl.codename == 'test_codename'
    assert usl.new_repos == set()
    assert usl.default_file == '/etc/apt/sources.list'
    assert usl.files == {}


# Generated at 2022-06-20 21:24:22.606838
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    sources = SourcesList(module)
    sources._add_valid_source('deb http://example.com/ binary1', comment='comment1', file='file1')
    assert sources.files == {
        'file1': [
            (0, True, True, 'deb http://example.com/ binary1', 'comment1')
        ]
    }

    # Can add a source to the same file again
    sources._add_valid_source('deb http://example.com/ binary2', comment='comment2', file='file1')

# Generated at 2022-06-20 21:24:28.796029
# Unit test for function install_python_apt
def test_install_python_apt():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )


# Generated at 2022-06-20 21:24:40.162622
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    module = FakeAnsibleModule()
    sources_list = UbuntuSourcesList(module)
    expected_default_file = '/etc/apt/sources.list'
    expected_files = [expected_default_file]
    if os.path.exists(sources_list._apt_cfg_dir('Dir::Etc::sourceparts')):
        expected_files.extend(glob.iglob('%s/*.list' % sources_list._apt_cfg_dir('Dir::Etc::sourceparts')))
    # Parse sources.list and sources.list.d and fill the dictionary of sources.
    # Only enabled and valid sources are really added to the dictionary.
    expected_files = [expected_default_file]

# Generated at 2022-06-20 21:24:49.274047
# Unit test for method dump of class SourcesList