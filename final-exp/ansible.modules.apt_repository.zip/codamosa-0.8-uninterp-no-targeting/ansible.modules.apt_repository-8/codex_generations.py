

# Generated at 2022-06-20 21:20:08.334803
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    class FakeModule:
        def __init__(self, params):
            self.params = params

        def fail_json(self, msg):
            self.fail_msg = msg

    filename = '/sources.list.d/test.list'
    sources_list = SourcesList(FakeModule({'filename': filename}))
    sources_list.add_source('deb http://localhost/debian test')
    assert sources_list.dump() == {filename: 'deb http://localhost/debian test\n'}

    # No duplicate sources
    sources_list.add_source('deb http://localhost/debian test')
    assert sources_list.dump() == {filename: 'deb http://localhost/debian test\n'}

    # File will be created if new source is added

# Generated at 2022-06-20 21:20:12.102083
# Unit test for function get_add_ppa_signing_key_callback
def test_get_add_ppa_signing_key_callback():
    m = AnsibleModule(argument_spec=dict())
    assert get_add_ppa_signing_key_callback(m) is not None
    del m

    m = AnsibleModule(argument_spec=dict(), check_mode=True)
    assert get_add_ppa_signing_key_callback(m) is None
    del m



# Generated at 2022-06-20 21:20:22.918519
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    module = AnsibleModule(argument_spec = dict())

    sl = SourcesList(module)
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_data')

    # load sources
    for file in glob.iglob('%s/*.list' % path):
        sl.load(file)

    # add valid source
    sl.add_source('deb http://example.com/path/to/repo/ ./')
    # add invalid source
    sl.add_source('invalid source')
    # add valid source with comment
    sl.add_source('deb http://example.org/path/to/repo/ ./', comment='some comment')

    # now lets see what we have in the end
    dumpstruct = sl.dump()
    test_data

# Generated at 2022-06-20 21:20:26.299824
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    raised = False
    try:
        raise InvalidSource(14)
    except InvalidSource as exc:
        if exc.args[0] == 14:
            raised = True
    assert raised, 'InvalidSource constructor not working'


# Generated at 2022-06-20 21:20:32.862283
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    module = MagicMock()
    add_ppa_signing_keys_callback = MagicMock()
    ubuntu_sources_list = UbuntuSourcesList(
        module,
        add_ppa_signing_keys_callback=add_ppa_signing_keys_callback
    )
    deepcopy = ubuntu_sources_list.__deepcopy__()
    assert deepcopy != ubuntu_sources_list
    assert deepcopy.module == ubuntu_sources_list.module
    assert deepcopy.codename == ubuntu_sources_list.codename
    assert deepcopy.add_ppa_signing_keys_callback == ubuntu_sources_list.add_ppa_signing_keys_callback


# Generated at 2022-06-20 21:20:34.576778
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource("Error")
    except InvalidSource as e:
        assert e.args[0] == "Error"



# Generated at 2022-06-20 21:20:39.246139
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    # self = module, ns = class - to access the members of class
    # Initialization of members of class UbuntuSourcesList
    ns = UbuntuSourcesList(module)
    ns.add_ppa_signing_keys_callback = None
    ns.codename = 'focal'
    ns.module = module
    ns.default_file = '/etc/apt/sources.list'
    ns.files = {ns.default_file: []}
    ns.new_repos = set()

    # Test case 1 : Add ppa source
    line = 'ppa:golang-team/ppa'
    ns.add_source(line, comment='', file=None)

# Generated at 2022-06-20 21:20:47.910875
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
  __iter__ = SourcesList.__iter__.im_func
  assert __iter__({'files': {'sources.list': [
    (0, False, True, '', 'comment'),
    (1, True, True, 'debsrc http://', ''),
    (2, True, True, 'deb http://', ''),
  ]}}) == [('sources.list', 0, True, '', 'comment'), ('sources.list', 1, True, 'debsrc http://', ''), ('sources.list', 2, True, 'deb http://', '')]
  assert __iter__({'files': {'A.list': []}}) == []
  # todo: Add more tests


# Generated at 2022-06-20 21:20:55.964454
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = {"params":{}, "check_mode": False, "atomic_move": False}
    class fs:
        def __init__(self, filename, content=""):
            self.filename = filename
            self.content = content
        def read(self):
            return self.content
        def write(self, content):
            self.content += content
        def __exit__(self, exc_type, exc_value, traceback):
            os.makedirs(os.path.dirname(self.filename), exist_ok=True)
            open(self.filename, "w").write(self.content)
        def __enter__(self):
            return self

    module["run_command"] = lambda args, check_rc=True, close_fds=True: (0, '', '')
    module["atomic_move"]

# Generated at 2022-06-20 21:21:05.341424
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    class M(object):
        def fail_json(self, msg):
            raise InvalidSource(msg)
        def run_command(self, cmd):
            return 0, '', ''
        def __init__(self, test_params):
            self.params = test_params
        def atomic_move(self, tmp_path, filename):
            pass
        def get_bin_path(self, apt_get_path):
            return apt_get_path

# Generated at 2022-06-20 21:21:44.927034
# Unit test for constructor of class SourcesList
def test_SourcesList():
    sl = SourcesList()
    assert sl.files



# Generated at 2022-06-20 21:21:51.725199
# Unit test for method remove_source of class SourcesList

# Generated at 2022-06-20 21:21:53.479388
# Unit test for function main
def test_main():
    repo = {
        "state": "absent",
        "repo": "ansible/ansible"
    }
    state = "absent"
    resp = main(repo, state)
    assert resp == False

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:21:58.955233
# Unit test for method __deepcopy__ of class UbuntuSourcesList
def test_UbuntuSourcesList___deepcopy__():
    sl = UbuntuSourcesList(AnsibleModule({}), add_ppa_signing_keys_callback=None)
    sl.files = {
        '/etc/apt/sources.list.d/file1': [],
        '/etc/apt/sources.list.d/file2': []
    }

    sl2 = deepcopy(sl)

    assert sl.module is sl2.module
    assert sl.add_ppa_signing_keys_callback is sl2.add_ppa_signing_keys_callback
    assert sl.codename is sl2.codename
    assert len(sl.files) is len(sl2.files)
    for f in sl.files.values():
        assert f is not sl2.files[f]

# Generated at 2022-06-20 21:22:07.723442
# Unit test for method __deepcopy__ of class UbuntuSourcesList

# Generated at 2022-06-20 21:22:19.411719
# Unit test for function install_python_apt
def test_install_python_apt():
    import tempfile
    global apt_pkg
    (fd, aptget) = tempfile.mkstemp()
    f = open(aptget, 'w')
    f.write('#!/bin/sh\n\n')
    f.write('echo Installed: python-apt/stable 0.7.93.2ubuntu4\n')
    f.write('exit 0\n')
    f.close()
    os.environ['PATH'] = os.environ.get('PATH','') + os.pathsep + os.path.dirname(aptget)
    os.chmod(aptget, 0o755)
    mod_util = AnsibleModule(argument_spec=dict())
    mod_util.get_bin_path = lambda x: aptget

# Generated at 2022-06-20 21:22:24.146978
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    module = MockModule()
    sources = SourcesList(module)
    sources.load('test/testdata/sources-1.list')
    assert sources.dump() == {
        'test/testdata/sources-1.list': 'deb http://us.archive.ubuntu.com/ubuntu xenial main universe restricted multiverse # comment\n',
        'test/testdata/sources-1.list.disabled': '# deb http://us.archive.ubuntu.com/ubuntu xenial main universe restricted multiverse # comment\n'
    }



# Generated at 2022-06-20 21:22:29.050200
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    arg = 'ppa:fkrull/deadsnakes'
    ppa = 'deb http://ppa.launchpad.net/fkrull/deadsnakes/ubuntu xenial main'

    module = AnsibleModule(argument_spec=dict())
    module.params = dict(
        state='absent',
        regexp=None,
        update_cache=True,
        name=None,
        filename=None,
        codename=None,
        mode=None,
    )
    sl = UbuntuSourcesList(module)

    # test removal of non-existing PPA
    sl._add_valid_source(ppa, '', sl._suggest_filename(ppa))
    sl.remove_source(arg)
    assert len(sl.repos_urls) == 1

    # test removal of an existing PPA
    sl._

# Generated at 2022-06-20 21:22:31.147100
# Unit test for constructor of class UbuntuSourcesList
def test_UbuntuSourcesList():
    class TestModule(object):
        params = {
            'codename': 'test_codename'
        }
    module = TestModule()
    test_source_list = UbuntuSourcesList(module)
    default_file = test_source_list._apt_cfg_file('Dir::Etc::sourcelist')
    assert test_source_list.default_file == default_file



# Generated at 2022-06-20 21:22:35.271905
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    invalid_source = InvalidSource()
    if not isinstance(invalid_source, Exception):
        raise RuntimeError("__init__() of InvalidSource does not create an Exception")



# Generated at 2022-06-20 21:23:55.039833
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        # Make sure we can call the inherited constructor
        raise InvalidSource("Some helpful message")
    except InvalidSource:
        pass



# Generated at 2022-06-20 21:24:07.063339
# Unit test for method load of class SourcesList

# Generated at 2022-06-20 21:24:19.033625
# Unit test for method save of class SourcesList
def test_SourcesList_save():
    module = AnsibleModule(argument_spec={})
    apt_pkg.config['Dir::Etc::sourceparts'] = tmp_apt_sources_d_path()

    # Test no backup, no changes, no sources.list.d
    sl = SourcesList(module)
    sl.save()
    assert not os.path.exists(sl.default_file)
    assert not os.path.exists(tmp_apt_sources_d_path())

    # Test no backup, no changes, with sources.list.d
    _create_apt_sources_d()
    sl = SourcesList(module)
    sl.save()
    assert not os.path.exists(sl.default_file)
    assert os.path.exists(tmp_apt_sources_d_path())
    assert os.path.ex

# Generated at 2022-06-20 21:24:25.477494
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    sources = UbuntuSourcesList(module, None)
    sources.load(os.path.join('tests', 'data', 'sources.list.d', 'test-ppa.list'))
    sources.remove_source('ppa:example-ppa/example-ppa')
    assert len(sources.files) == 0
    # Load and remove the same file again
    sources.load(os.path.join('tests', 'data', 'sources.list.d', 'test-ppa.list'))
    sources.remove_source('ppa:example-ppa')
    assert len(sources.files) == 0



# Generated at 2022-06-20 21:24:31.200656
# Unit test for method add_source of class UbuntuSourcesList
def test_UbuntuSourcesList_add_source():
    sl = UbuntuSourcesList(None, None)
    sl.add_source('deb http://deb.debian.org/debian unstable main', comment='some comment')
    assert sl.files['/etc/apt/sources.list'] == [(0, True, True, 'deb http://deb.debian.org/debian unstable main', 'some comment')]
    sl.add_source('ppa:foobar', comment='ppa comment')
    assert sl.files['/etc/apt/sources.list'] == [(0, True, True, 'deb http://deb.debian.org/debian unstable main', 'some comment')]
    assert sl.files['/etc/apt/sources.list.d/foobar.list'] == [(0, True, True, 'deb http://ppa.launchpad.net/foobar/ubuntu unstable main', 'ppa comment')]



# Generated at 2022-06-20 21:24:45.010517
# Unit test for method dump of class SourcesList
def test_SourcesList_dump():
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.debug = False

        def fail_json(self, msg):
            self.msg = msg

    class FakeAptModule:
        def __init__(self, lines):
            self.module = FakeModule()
            self.files = {}
            self.new_repos = set()
            self.default_file = 'sources.list'
            self.files[self.default_file] = lines


# Generated at 2022-06-20 21:24:47.070973
# Unit test for constructor of class InvalidSource
def test_InvalidSource():
    try:
        raise InvalidSource('error message')
    except InvalidSource as e:
        assert 'error message' == e.message



# Generated at 2022-06-20 21:24:53.330824
# Unit test for method load of class SourcesList
def test_SourcesList_load():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    s = SourcesList(module)
    try:
        s.load('/tmp/sources.list')
    except IOError:
        pass
    else:
        assert False, 'IOError not raised'



# Generated at 2022-06-20 21:25:01.121428
# Unit test for method remove_source of class UbuntuSourcesList
def test_UbuntuSourcesList_remove_source():
    # Mimic the AnsibleModule in order to be able to use the utility function
    # run_command
    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.check_mode = True

        def run_command(self, command, check_rc=False):
            return 0, '', ''
    class AnsibleExitJson(Exception):
        pass
    class AnsibleFailJson(Exception):
        pass

    setattr(AnsibleModule, 'fail_json', lambda self, msg="", **kwargs: AnsibleFailJson(msg))
    setattr(AnsibleModule, 'exit_json', lambda self, **kwargs: AnsibleExitJson(kwargs))

    module = AnsibleModule()
    module.params = {}

    # Create an UbuntuSourcesList object
   

# Generated at 2022-06-20 21:25:03.714535
# Unit test for method __iter__ of class SourcesList
def test_SourcesList___iter__():
  sl = SourcesList()
  # assert isinstance(sl.__iter__(), types.GeneratorType)


# Generated at 2022-06-20 21:28:46.189093
# Unit test for function revert_sources_list
def test_revert_sources_list():
    sl = SourcesList(AnsibleModule(argument_spec={}))
    sl.add_source('deb http://example.org/debian trusty main', 'Example')
    sl.add_source('deb http://example.net/debian jessie main', 'Example')
    sl.save()
    sl2 = deepcopy(sl)
    sl.remove_source('deb http://example.org/debian trusty main')
    sl.save()
    revert_sources_list(sl.dump_lines(), sl2.dump_lines(), sl)
    sl.save()



# Generated at 2022-06-20 21:28:47.489635
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert(e.code == 0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 21:28:59.442205
# Unit test for function main
def test_main():
    # Variables
    test_func_params = dict() # dict
    test_func_params['repo'] = 'repo'
    test_func_params['state'] = 'present'
    test_func_params['mode'] = 'mode'
    test_func_params['update_cache'] = True
    test_func_params['update_cache_retries'] = 5
    test_func_params['update_cache_retry_max_delay'] = 12
    test_func_params['filename'] = 'filename'
    test_func_params['install_python_apt'] = True
    test_func_params['validate_certs'] = True
    test_func_params['codename'] = 'codename'

    # Setup mock
    # Mocked function variables
    mock_HAVE_PYTHON_AP

# Generated at 2022-06-20 21:29:05.584217
# Unit test for function revert_sources_list
def test_revert_sources_list():
    module = AnsibleModule (argument_spec={ 'codename': { 'choices': ['xenial'] },
                                            'mode': { 'choices': ['0644'], 'default': '0644' },
                                            })
    sources_before = dict()
    sources_before["/etc/apt/sources.list.d/ansible.list"] = "deb http://ppa.launchpad.net/ansible/ansible/ubuntu xenial main"
    sources_after = dict()

    with SourcesList(module) as sourceslist_before:
        revert_sources_list(sources_before, sources_after, sourceslist_before)
        assert sourceslist_before is not None


# Generated at 2022-06-20 21:29:23.547559
# Unit test for method add_source of class SourcesList
def test_SourcesList_add_source():
    def has_sources(sl, sources):
        for filename, n, enabled, source, comment in sl:
            if source in sources:
                return True
        return False

    # Set random filename for apt config file
    # Because we don't want to use real configuration file
    # We need to test that our method can create configuration file
    # And we need to reverse back changes to this file after test execution
    apt_pkg.config.set('Dir::Etc::sourceparts', tempfile.gettempdir())

# Generated at 2022-06-20 21:29:32.219512
# Unit test for method remove_source of class SourcesList
def test_SourcesList_remove_source():
    module = object()
    self = SourcesList(module)
    self.files = {'test.list': [(0, True, True, 'deb line 1','comment')]}
    self.remove_source('# deb line 1')
    assert self.files == {'test.list': [(0, True, False, 'deb line 1', 'comment')]}
    self.remove_source('# deb line 1')
    assert self.files == {'test.list': [(0, True, False, 'deb line 1', 'comment')]}
    self.remove_source('deb line 1')
    assert self.files == {'test.list': []}

