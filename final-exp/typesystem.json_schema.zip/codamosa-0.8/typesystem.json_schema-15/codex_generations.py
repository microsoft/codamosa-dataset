

# Generated at 2022-06-12 15:51:13.893234
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "num1": {"type": "integer", "maximum": 2},
                    "num2": {"type": "integer", "maximum": 2},
                    "num3": {"type": "integer", "maximum": 2},
                    "num4": {"type": "integer", "maximum": 2},
                },
                "required": ["num1", "num2", "num3", "num4"],
            }
        ],
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Field)


# Generated at 2022-06-12 15:51:15.601666
# Unit test for function from_json_schema
def test_from_json_schema():
    assert definitions["#/definitions/schema"] == JSONSchema



# Generated at 2022-06-12 15:51:20.506800
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:51:31.531510
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    expected = {
        'type': 'object',
        'properties': {
            'a': {
                'anyOf': [
                    {'type': 'string'},
                    {'type': 'integer'}
                ]
            },
            'b': {
                'anyOf': [
                    {'type': 'string'},
                    {'type': 'integer'}
                ]
            }
        }
    }
    schema = Schema(any_of_from_json_schema(expected))
    assert schema.validate({"a": "foo", "b": "bar"}) is None
    assert schema.validate({"a": "foo", "b": 42}) is None
    assert schema.validate({"a": 42, "b": "bar"}) is None

# Generated at 2022-06-12 15:51:36.725710
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    definitions = SchemaDefinitions()
    data = {"allOf": [10, {"type": "number"}]}
    assert isinstance(all_of_from_json_schema(data, definitions), AllOf)
    assert all_of_from_json_schema(data, definitions).all_of[0].const == 10



# Generated at 2022-06-12 15:51:49.861445
# Unit test for function to_json_schema
def test_to_json_schema():

    # Test case for a Single field without any properties
    class Person(Schema):
        name = String()

    assert to_json_schema(Person), {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": {
            "Person": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {"name": {"type": "string"}},
                "additionalProperties": False,
            }
        },
        "$ref": "#/definitions/Person",
    }

    # Test case for a Single field with additional properties
    class Person1(Schema):
        name = String(additional_properties=True)


# Generated at 2022-06-12 15:51:53.206668
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/phoneNumber'}
    definitions = SchemaDefinitions()
    definitions['#/definitions/phoneNumber'] = String()
    assert ref_from_json_schema(data, definitions) == Reference(to='#/definitions/phoneNumber', definitions=definitions) 
    assert definitions == SchemaDefinitions({'#/definitions/phoneNumber': String()})



# Generated at 2022-06-12 15:51:57.856325
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    result=all_of_from_json_schema({"allOf": [{"type": "number"},{"maximum": 2}]},definitions)
    assert(result.validate(1.5)==True)
    assert(result.validate(3)==False)



# Generated at 2022-06-12 15:52:09.704037
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:52:21.447569
# Unit test for function to_json_schema
def test_to_json_schema():
    string = String(
        min_length=1,
        max_length=15,
        pattern=r"[a-z]{5}",
        format="url",
        allow_blank=False,
        default="",
    )
    integer = Integer(minimum=1, maximum=2, multiple_of=3, default=4)
    number = Float(minimum=5, maximum=6, multiple_of=7, default=8)
    boolean = Boolean(default=False)
    array = Array(
        min_items=1,
        max_items=2,
        items=Integer(minimum=5),
        additional_items=Integer(maximum=7),
        unique_items=True,
        default=[],
    )

# Generated at 2022-06-12 15:52:47.863758
# Unit test for function to_json_schema
def test_to_json_schema():
    data = {"my_key": "my_value"}
    assert to_json_schema(object) == {"type": "object"}
    assert to_json_schema(dict) == {"type": "object"}
    assert to_json_schema(Any) == {"type": "object"}
    assert to_json_schema(Dict) == {"type": "object"}
    assert to_json_schema(str) == {"type": "string"}
    assert to_json_schema(String) == {"type": "string"}
    assert to_json_schema(int) == {"type": "integer"}
    assert to_json_schema(Integer) == {"type": "integer"}
    assert to_json_schema(float) == {"type": "number"}

# Generated at 2022-06-12 15:52:58.926257
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # All of the following tests should build a JSON schema that
    # is equivalent to a schema that uses if-then-else.
    # The IfThenElse field is already tested so we do simple
    # equivalence tests here.

    # Using int as an example.  Other types are similar.
    schema = {"type": "integer"}
    field = from_json_schema(schema)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_, Integer)

    # Existing tests for IfThenElse are sufficient.
    # We only test Boolean and Any here.

    schema = {"type": ["boolean"]}
    field = from_json_schema(schema)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_, Boolean)


# Generated at 2022-06-12 15:53:10.301158
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from .constraints import Not
    from .fields import String

    context = from_json_schema({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "type": "object",
        "properties": {
            "productId": {
                "type": "string",
                "not": {
                    "pattern": "[0-9]",
                }
            },
        }
    })
    field = context['productId']
    assert isinstance(field, Not)
    assert isinstance(field.negated, String)
    assert field.negated.pattern == "[0-9]"


# Generated at 2022-06-12 15:53:20.524871
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Setup
    from typesystem import from_json_schema
    from typesystem.fields import Boolean
    # Exercise
    my_enum = from_json_schema({"enum": [1, 2, 3]})
    my_enum = from_json_schema({"enum": [True, False]})
    my_enum = from_json_schema({"enum": [True, False], "default": True})
    # Verify
    val = my_enum.validate(0)
    val = my_enum.validate(1)
    val = my_enum.validate(2)
    val = my_enum.validate(3)
    val = my_enum.validate(4)

    my_enum = from_json_schema({"enum": [True, False], "default": True})

# Generated at 2022-06-12 15:53:25.661661
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({
        'enum': ['one', 'two', 'three'],
    }).validate('two')
    assert not enum_from_json_schema({
        'enum': ['one', 'two', 'three'],
    }).validate('four')
    assert not enum_from_json_schema({
        'enum': ['one', 'two', 'three'],
    }).validate(None)
    assert enum_from_json_schema({
        'nullable': True,
        'enum': ['one', 'two', 'three'],
    }).validate(None)



# Generated at 2022-06-12 15:53:29.210137
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema.__module__ == __name__

    data = {"not": {"type": "string"}}
    assert isinstance(not_from_json_schema(data=data), Not)



# Generated at 2022-06-12 15:53:37.225164
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'$schema': 'http://json-schema.org/draft-07/schema',
              '$ref': '#/definitions/Example',
              'definitions': {'Example': {'type': 'object',
                                          'properties': {'a': {'type': 'string'},
                                                         'b': {'not': {'type': 'string'}}},
                                          'required': ['a', 'b']}}}

    field = from_json_schema(schema['definitions']['Example'])




# Generated at 2022-06-12 15:53:42.246242
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    d: typing.MutableMapping[str, typing.Any] = {}

    d["if"] = {"type": "string"}
    d["then"] = {"type": "integer"}
    expected = IfThenElse(if_clause=String(), then_clause=Integer())
    assert from_json_schema(d) == expected

    d["if"] = {"type": "string"}
    d["then"] = {"type": "integer"}
    d["else"] = {"type": "float"}
    expected = IfThenElse(
        if_clause=String(), then_clause=Integer(), else_clause=Float()
    )
    assert from_json_schema(d) == expected

    d["if"] = {"type": "string"}
    d["then"] = {"type": "integer"}
    d["else"]

# Generated at 2022-06-12 15:53:48.348078
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "A", "default": "A"}
    field = const_from_json_schema(data, definitions=None)
    assert field.validate("A") == "A"
    assert field.validate("B") == "A"
    assert field.validate("A", raise_exception=False) == "A"
    assert field.validate("B", raise_exception=False) == "A"
    assert field.serialize("A") == "A"
    assert field.serialize("B") == "A"



# Generated at 2022-06-12 15:54:00.075423
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(
        {}, type_string="number", allow_null=False, definitions=None
    ) == Float()
    assert from_json_schema_type(
        {"minimum": 0}, type_string="number", allow_null=False, definitions=None
    ) == Float(minimum=0)
    assert from_json_schema_type(
        {"type": "integer"}, type_string="integer", allow_null=False, definitions=None
    ) == Integer()
    assert from_json_schema_type(
        {"type": ["null", "string"]},
        type_string="string",
        allow_null=False,
        definitions=None,
    ) == String()

# Generated at 2022-06-12 15:54:42.715127
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
      "anyOf": [
        {
          "type": "string",
          "minLength": 1
        },
        {
          "type": "integer"
        }
      ]
    }
    expected = Union(
        any_of = [
            String(min_length=1),
            Integer()
        ]
    )
    assert any_of_from_json_schema(data, None) == expected
# END test_any_of_from_json_schema



# Generated at 2022-06-12 15:54:51.433655
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.composites import OneOf
    from typesystem.fields import Boolean, Float, Integer, String
    from typesystem.schemas import Reference

    definitions = SchemaDefinitions()
    definitions["integer"] = Integer(minimum=0)
    definitions["string"] = String(min_length=2, max_length=3)

    def __(data: dict, expected: Field):
        actual = from_json_schema_type(data, type_string="any", allow_null=False, definitions=definitions)
        assert actual == expected

    __({"minimum": 0, "maximum": 0}, Integer(minimum=0, maximum=0))
    __({"type": "string", "minLength": 2, "maxLength": 3}, String(min_length=2, max_length=3))

# Generated at 2022-06-12 15:55:02.706578
# Unit test for function to_json_schema
def test_to_json_schema():
    arg1 = String()
    expected1 = {"type": "string"}
    assert to_json_schema(arg1) == expected1

    arg2 = String(allow_null=True)
    expected2 = {"type": ["string", "null"]}
    assert to_json_schema(arg2) == expected2

    arg3 = String(allow_blank=True, allow_null=True)
    expected3 = {
        "type": ["string", "null"],
        "minLength": 0
    }
    assert to_json_schema(arg3) == expected3

    arg4 = String(allow_blank=True, allow_null=True, default="foo")
    expected4 = {
        "type": ["string", "null"],
        "minLength": 0,
        "default": "foo"
    }


# Generated at 2022-06-12 15:55:11.943936
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "https://example.com/person.schema.json",
        "title": "Person",
        "description": "A person",
        "type": "object",
        "properties": {
            "firstName": {"type": "string",},
            "lastName": {"type": "string",},
            "age": {"description": "Age in years", "type": "integer", "minimum": 0,},
        },
    }

    definitions: SchemaDefinitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"

# Generated at 2022-06-12 15:55:16.614005
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref" : "#/definitions/coordinates",
        "definitions" : {
            "coordinates" : {
                "type" : "object",
                "properties" : {
                    "latitude" : {
                        "type" : "array",
                        "items" : {"type" : "number"},
                    },
                    "longitude" : {
                        "type" : "array",
                        "items" : {"type" : "number"},
                    },
                },
            },
        },
    }
    ts = from_json_schema(schema)
    assert isinstance(ts, Reference) and ts.to == "#/definitions/coordinates"


# Generated at 2022-06-12 15:55:25.517910
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    
    for j in [
            {"anyOf": [{"type": "string"}, {"type": "integer"}]},
            {"anyOf": [{"type": ["string", "integer"]}]}
        ]:
        any_of_from_json_schema(j, definitions)
    for j in [
            {"anyOf": [{"type": "string"}, {"type": ["string", "integer"]}]},
            {"anyOf": [{"type": ["string", "integer"]}, {"type": ["string", "integer"]}]},
            {"anyOf": [{"type": ["string", "integer"]}, {"type": "integer"}]}
        ]:
        try:
            any_of_from_json_schema(j, definitions)
        except AssertionError:
            pass



# Generated at 2022-06-12 15:55:36.406395
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type_string="number"
    data = {
        "type": "number",
        "minimum": 34,
        "maximum": 43,
        "exclusiveMinimum": 3,
        "exclusiveMaximum": 23,
        "multipleOf": 1,
    }
    field = from_json_schema_type(data, type_string=data["type"], allow_null=False, definitions=definitions)
    assert isinstance(field, Float)
    assert field.minimum == data["minimum"]
    assert field.maximum == data["maximum"]
    assert field.exlusive_minimum == data["exclusiveMinimum"]
    assert field.exlusive_maximum == data["exclusiveMaximum"]
    assert field.multiple_of == data["multipleOf"]

    # type_string="integer"

# Generated at 2022-06-12 15:55:46.214696
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-12 15:55:53.627967
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = vd.Schema(
        if_then_else_from_json_schema(
            data={
                "if": {"properties": {"name": {"type": "integer"}}},
                "then": {"properties": {"first_name": {"type": "string"}}},
                "else": {"properties": {"last_name": {"type": "string"}}},
            }
        )
    )

    assert vd.validate({"name": 1}, schema) == ({"first_name": ""}, None)
    assert vd.validate({"name": "1"}, schema) == ({"last_name": ""}, None)

# Generated at 2022-06-12 15:56:04.911557
# Unit test for function to_json_schema
def test_to_json_schema():
    from .marshmallow import String as StringM, Integer as IntegerM, Boolean as BooleanM
    from .marshmallow import Object as ObjectM, List as ListM, Dict as DictM, Nested as NestedM
    from .marshmallow import Required, Schema as SchemaM
    class ObjectiveM(SchemaM):
        int = IntegerM(load_from="integer")
        str = StringM(load_from="string")
        bool = BooleanM(load_from="boolean")
    class TestSchemaM(SchemaM):
        objective = NestedM(ObjectiveM(), load_from="object")
        list = ListM(StringM(), load_from="array")
        dict = DictM(StringM(), load_from="dict")
        required = StringM(required=True)
    schema = TestSchema

# Generated at 2022-06-12 15:56:35.720140
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    class IIf(IfThenElse):
        def __init__(self):
            super().__init__(if_clause=None, then_clause=None, else_clause=None)

        @property
        def if_clause(self) -> Field:
            return self.kwargs["if_clause"]

        @if_clause.setter
        def if_clause(self, value: Field):
            self.kwargs["if_clause"] = value

        @property
        def then_clause(self) -> Field:
            return self.kwargs["then_clause"]

        @then_clause.setter
        def then_clause(self, value: Field):
            self.kwargs["then_clause"] = value


# Generated at 2022-06-12 15:56:45.289627
# Unit test for function from_json_schema
def test_from_json_schema():
    # $ref
    assert from_json_schema({'$ref': '#/components/schemas/Pet'}) == Reference('#/components/schemas/Pet')
    assert from_json_schema({'definitions': {'A': {'$ref': '#/components/schemas/B'}}, '$ref': '#/components/schemas/A'}) == Reference('#/components/schemas/B')

# Generated at 2022-06-12 15:56:48.930608
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(Schema(a=Integer(), b=Integer(), c=Integer()))
    expected = {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "integer"},
            "c": {"type": "integer"},
        },
        "additionalProperties": False,
    }
    assert data == expected



# Generated at 2022-06-12 15:56:58.878568
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:57:04.077674
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = UserSchema()
    # pylint: disable=no-member
    json_schema = to_json_schema(schema)
    assert isinstance(json_schema, dict)
    assert json_schema["type"] == "object"
    assert isinstance(json_schema["properties"], dict)
    assert json_schema["properties"]["name"]["type"] == "string"
    assert json_schema["properties"]["name"]["pattern"] == "^[a-zA-Z0-9_-]+$"
    assert json_schema["properties"]["age"]["type"] == "integer"
    assert json_schema["properties"]["date_joined"]["type"] == "string"

# Generated at 2022-06-12 15:57:12.019994
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    s = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "if": {
            "type": "string",
            "pattern": "^([A-Z]{2})-",
        },
        "then": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
            },
        }
    }
    x = from_json_schema(s)

# Generated at 2022-06-12 15:57:17.831448
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # These are the tests that are in the official documentation
    data1: typing.Dict[str, typing.Any] = {
        "if": {
            "maxProperties": 5,
            "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
            "required": ["a", "b"],
        },
        "then": {"properties": {"a": {"maximum": 10}, "b": {"maximum": 10}}},
        "else": {"properties": {"a": {"maximum": 20}, "b": {"maximum": 20}}},
    }

# Generated at 2022-06-12 15:57:30.324916
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type_string == 'number'
    assert isinstance(from_json_schema_type({}, 'number', False, None), Float)
    assert isinstance(from_json_schema_type({}, 'number', True, None), Float)
    # type_string == 'integer'
    assert isinstance(from_json_schema_type({}, 'integer', False, None), Integer)
    assert isinstance(from_json_schema_type({}, 'integer', True, None), Integer)
    # type_string == 'string'
    assert isinstance(from_json_schema_type({}, 'string', False, None), String)
    assert isinstance(from_json_schema_type({}, 'string', True, None), String)
    # type_string == 'boolean'

# Generated at 2022-06-12 15:57:36.358767
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Test"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Test"] = String(name="Test")
    assert type(ref_from_json_schema(data, definitions)) == Reference



# Generated at 2022-06-12 15:57:36.974329
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert True


# Generated at 2022-06-12 15:58:05.747711
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from typesystem.composites import AllOf
    with pytest.raises(AssertionError) as excinfo:
        ref_from_json_schema({'$ref': 'https://foo/bar'})
    assert str(excinfo.value) == 'Unsupported $ref style in document.'

# Generated at 2022-06-12 15:58:15.186390
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "a": Integer(),
            "b": Object(properties={"c": Boolean(), "d": Array(items=Integer())}),
        }
    )
    validator = schema.make_validator()

    definitions = to_json_schema(validator)

# Generated at 2022-06-12 15:58:22.972127
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "name": {
                "if": {"type": "string", "minLength": 2},
                "then": {"const": "hello world!"},
            },
        },
    }
    actual = from_json_schema(json_schema)
    expected = Object(
        properties={
            "name": IfThenElse(
                if_clause=String(min_length=2), then_clause=Const("hello world!")
            )
        }
    )
    assert actual == expected

# Generated at 2022-06-12 15:58:33.349174
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        "$ref": "#/definitions/JSONSchema",
    }) == JSONSchema
    assert from_json_schema({
        "const": "value",
    }) == Const("value")
    assert from_json_schema({
        "type": "number",
        "minimum": 40,
        "maximum": 50,
    }) == Number(minimum=40, maximum=50)
    assert from_json_schema({
        "allOf": [
            {"type": "number", "minimum": 40},
            {"type": "number", "maximum": 50},
        ]
    }) == Number(minimum=40, maximum=50)
    assert from_json_schema({
        "type": "number",
        "exclusiveMinimum": 41,
        "exclusiveMaximum": 49,
    })

# Generated at 2022-06-12 15:58:43.531530
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:58:50.882243
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {"a": Integer(minimum=8, maximum=112), "b": Choice([("c", "c"), ("d", "d")])}
    )
    reference = {
        "definitions": {
            "a_definition": {
                "type": "integer",
                "minimum": 8,
                "maximum": 112,
                "default": 0,
            },
            "b_definition": {
                "enum": ["c", "d"],
                "default": "c",
            },
        },
        "$ref": "#/definitions/a_definition",
    }
    assert to_json_schema(reference) == reference

# Generated at 2022-06-12 15:58:59.289712
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    field_a = String(title="A")
    definitions["a"] = field_a
    field_b = String(title="B")
    definitions["b"] = field_b
    assert ref_from_json_schema({"$ref": "#/a"}, definitions) == field_a.bind(definitions=definitions)
    assert ref_from_json_schema({"$ref": "#/b"}, definitions) == field_b.bind(definitions=definitions)
test_ref_from_json_schema()



# Generated at 2022-06-12 15:59:02.244530
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {'type': 'object', 'properties': {'prop': {'type': 'string'}}}
    field = from_json_schema(data)
    assert field.full_name == 'Object'



# Generated at 2022-06-12 15:59:10.414883
# Unit test for function to_json_schema
def test_to_json_schema():
    """Test function to_json_schema in module mongo_vali."""
    # Test converting a field object to json schema
    integer = Integer(minimum=0, maximum=10, default=5)
    ret = to_json_schema(integer)
    assert ret == {
        "type": "integer",
        "minimum": 0,
        "maximum": 10,
        "default": 5,
    }

    # Test converting a schema to json schema
    class SimpleSchema(Schema):
        count = Integer(minimum=0, maximum=3, default=2)
        name = String(allow_null=True, max_length=10, default="John Doe")
    s = SimpleSchema()
    ret = to_json_schema(s)

# Generated at 2022-06-12 15:59:19.601368
# Unit test for function to_json_schema
def test_to_json_schema():
    from .schema import String, Integer, Any, AnyOf, OneOf, Not, Reference
    from .schema import Schema, AllOf

    main_schema = Schema({"subject": String(allow_blank=False, min_length=1)})
    assert to_json_schema(main_schema) == {
        "type": "object",
        "properties": {"subject": {"type": "string", "minLength": 1}},
        "required": ["subject"],
        "additionalProperties": False,
    }

    main_schema = Schema(
        {
            "x": AnyOf(
                [String(allow_blank=False, min_length=3), Integer(minimum=3, maximum=10)]
            )
        }
    )

# Generated at 2022-06-12 15:59:51.595580
# Unit test for function from_json_schema
def test_from_json_schema():
    # The following tests come from the JSON Schema specification
    # The first test is the default value for $ref (i.e. #)
    assert Reference("#") == from_json_schema({"$ref": "#"})
    # 01-reference
    assert Reference("#/definitions/foo") == from_json_schema({"$ref": "#/definitions/foo"})
    # 02-type
    assert Boolean() == from_json_schema({"type": "boolean"})
    assert OneOf([Boolean(), String(min_length=4, max_length=5)]) == from_json_schema(
        {"type": ["boolean", "string"]}
    )
    # 03-type-array

# Generated at 2022-06-12 15:59:56.515628
# Unit test for function to_json_schema
def test_to_json_schema():
    from .schema import Schema

    class MySchema(Schema):

        property1 = String(max_length=1)

        property2 = String(nullable=True)

        property3: String = String(pattern_regex=re.compile("^\\d{4}\\-(0[1-9]|1[012])\\-(0[1-9]|[12][0-9]|3[01])$"))

        class MyNestedSchema(Schema):

            pass

        property4 = MyNestedSchema

        class MyNestedSchema2(Schema):

            class Nested(Schema):

                pass

        property5 = MyNestedSchema2.Nested

        property6 = Array(items=String)

        property7 = Array(items=Array(items=String))


# Generated at 2022-06-12 16:00:04.805215
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer(allow_null=False)
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String(allow_null=False)
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True) == Float(allow_null=True)
    assert from_

# Generated at 2022-06-12 16:00:14.113329
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_only = {
        "type": "object",
        "properties": {
            "foo": {"type": ["string", "null"]},
            "bar": {"type": ["integer", "null"]},
        },
        "additionalProperties": False,
        "required": ["bar"],
    }
