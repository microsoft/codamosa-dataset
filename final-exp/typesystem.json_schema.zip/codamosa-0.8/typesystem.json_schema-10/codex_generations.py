

# Generated at 2022-06-12 15:50:56.432347
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "default": "test",
        "oneOf": [{
            "type": "object",
            "required": ["test"],
            "properties": {
                "test": {
                    "type": "string",
                    "format": "date-time"
                }
            }
        }, {
            "type": "string",
            "format": "date-time"
        }]
    }
    definitions = SchemaDefinitions()
    result = one_of_from_json_schema(data, definitions)
    assert type(result) == OneOf



# Generated at 2022-06-12 15:51:03.511037
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    test_data = {
        "type":"object",
        "properties":{
            "these_are_all":"required",
            "properties_are":"required"
        },
        "allOf":[
            {
                "$ref":"#/definitions/one"
            },
            {
                "$ref":"#/definitions/two"
            }
        ]
    }
    test_schema = {
        "definitions":{
            "one":{
                "type":"object",
                "properties":{
                    "one_is_a":"required"
                }
            },
            "two":{
                "type":"object",
                "properties":{
                    "two_is_b":"required"
                }
            }
        }
    }

# Generated at 2022-06-12 15:51:08.179952
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/MySchema"},
        definitions=SchemaDefinitions({
            "#/definitions/MySchema": Any(),
        })).to is "#/definitions/MySchema"



# Generated at 2022-06-12 15:51:16.781111
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "number"}]}, definitions=None) == Union(any_of=[String(), Number()])
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "number"}], "default": "test"}, definitions=None) == Union(any_of=[String(), Number()], default='test')
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "number"}, {"type": "null"}]}, definitions=None) == Union(any_of=[String(), Number(), Const(None)])

# Generated at 2022-06-12 15:51:27.172935
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    f = if_then_else_from_json_schema({
        "type": "object",
        "properties": {
            "p1": {"type": "string", "enum": ["a", "b"]},
            "p2": {"type": "string", "enum": ["c", "d"]},
        },
        "if": {"required": ["p1"]},
        "then": {"required": ["p2"]},
    }, definitions={})
    assert isinstance(f, Field)
    assert isinstance(f, Object)
    assert len(f.fields) == 1
    assert isinstance(f.fields[0], IfThenElse)
    assert isinstance(f.fields[0].if_clause, Object)
    assert len(f.fields[0].if_clause.fields) == 2

# Generated at 2022-06-12 15:51:34.123798
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "val"}).validate("val")
    assert not const_from_json_schema({"const": "foo"}).validate("bar")
    assert const_from_json_schema({"const": "val", "default": "foo"}).validate(None)
    assert const_from_json_schema({"const": "val", "default": "foo"}).validate("val")



# Generated at 2022-06-12 15:51:37.046817
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({
            'enum':['a', 'b', 'c'],
        }) == Choice(choices=[('a', 'a'), ('b', 'b'), ('c', 'c')], default=NO_DEFAULT)



# Generated at 2022-06-12 15:51:49.861550
# Unit test for function enum_from_json_schema

# Generated at 2022-06-12 15:51:55.114213
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field = enum_from_json_schema({"enum": [1, 2, 3], "default": 2}, definitions)
    assert field.validate(1) == 1
    assert field.validate(3) == 3
    assert field.validate(2) == 2


# Generated at 2022-06-12 15:52:01.553390
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {"oneOf":[
        {"type": "string", "enum": ["USA", "GDI"]},
        {"type": "string", "enum": ["NOD", "Brotherhood"]},
        {"type": "string", "enum": ["GLA", "CA"]}
    ]}
    print(one_of_from_json_schema(data=schema, definitions=SchemaDefinitions()))



# Generated at 2022-06-12 15:52:20.224311
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def check(data, expected):
        assert from_json_schema(data).to_primitive() == expected


# Generated at 2022-06-12 15:52:28.253061
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    cases = [
        ({"type": "number"}, Float),
        (
            {
                "type": "number",
                "minimum": 0,
                "maximum": 100,
                "exclusive_minimum": True,
                "exclusive_maximum": True,
                "multiple_of": 1,
            },
            Float,
        ),
        ({"type": "integer"}, Integer),
        ({"type": "string"}, String),
        ({"type": "boolean"}, Boolean),
        ({"type": "array"}, Array),
        (
            {
                "type": "object",
                "properties": {"key": {"type": "string"}},
                "additionalProperties": False,
            },
            Object,
        ),
    ]
    for json_schema, typesystem_type in cases:
        field = from_json

# Generated at 2022-06-12 15:52:33.097349
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Invalid type
    data = {"type": "xyzzy"}
    try:
        from_json_schema_type(data, type_string=data["type"], allow_null=False,
                              definitions=SchemaDefinitions())
    except AssertionError as err:
        assert str(err) == f"Invalid argument type_string={data['type']!r}"
    else:
        assert False, "Not raised"

    # Integer
    data = {"type": "integer", "minimum": 0, "maximum": 1000, "default": 8}
    field = from_json_schema_type(data, type_string=data["type"], allow_null=False,
                                  definitions=SchemaDefinitions())
    assert isinstance(field, Integer)
    assert field.allow_null is False
    assert field.minimum == 0


# Generated at 2022-06-12 15:52:44.306454
# Unit test for function to_json_schema
def test_to_json_schema():
    as_json = to_json_schema(Point)
    assert as_json == {
        "definitions": {
            "Point": {
                "type": "object",
                "properties": {
                    "x": {"type": "number"},
                    "y": {"type": "number"},
                },
            }
        },
        "type": "object",
        "properties": {
            "points": {
                "type": ["array", "null"],
                "items": {"$ref": "#/definitions/Point"},
            }
        },
    }

    from_json = from_json_schema(as_json)
    assert from_json.fields == Point.make_validator().fields

    from_json = from_json_schema(as_json, definitions=as_json["definitions"])
   

# Generated at 2022-06-12 15:52:49.836432
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field = all_of_from_json_schema({"allOf": [{"type": "integer"}, {"minimum": 0}]}, SchemaDefinitions())
    assert isinstance(field, AllOf)
    assert len(field.all_of) == 2
    assert isinstance(field.all_of[0], Integer)
    assert isinstance(field.all_of[1], Integer)


# Generated at 2022-06-12 15:52:53.147512
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert isinstance(all_of_from_json_schema({'allOf': [{'$ref': '#/definitions/color'}, {'minimum': 0}]}, None), Field)


# Generated at 2022-06-12 15:53:03.862440
# Unit test for function to_json_schema
def test_to_json_schema():
    source = Schema.definitions(
        Alpha=Integer(minimum=1),
        Beta=String(min_length=1),
        Foo=Object(
            properties={"alpha": Reference("Alpha"), "beta": Reference("Beta")},
            additional_properties=False,
        ),
    )
    target = to_json_schema(source)
    expected_target = {
        "definitions": {
            "Alpha": {"type": "integer", "minimum": 1},
            "Beta": {"type": "string", "minLength": 1},
            "Foo": {
                "properties": {"alpha": {"$ref": "#/definitions/Alpha"}, "beta": {"$ref":"#/definitions/Beta"}},
                "additionalProperties": False,
                "type": "object",
            },
        }
    }


# Generated at 2022-06-12 15:53:07.816712
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(
        data={"not": {"enum": ["a"]}}, definitions=SchemaDefinitions()
    ) == Not(negated=Choice(choices=[("a", "a")]))



# Generated at 2022-06-12 15:53:14.517202
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"enum": ["a", "b"]}})("c") is True
    assert not_from_json_schema({"not": {"enum": ["a", "b"]}})("b") is False
    assert not_from_json_schema({"not": {"type": "null"}})(None) is False

    # If the validator can not negate `not`, it just returns `True` without negating it.
    assert not_from_json_schema({"not": {"type": "int"}})("a") is True
    assert not_from_json_schema({"not": {"type": "int"}})(1) is True


# Generated at 2022-06-12 15:53:19.979244
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "number",
        "minimum": 0,
        "maximum": 10,
        "exclusiveMinimum": False,
        "exclusiveMaximum": False,
        "multipleOf": 2,
        "default": 5
    }

    assert from_json_schema_type(data, type_string="number", allow_null=True, definitions=None) == Float(
        allow_null=True, minimum=0, maximum=10, exclusive_minimum=False, exclusive_maximum=False, multiple_of=2, default=5
    )


# Generated at 2022-06-12 15:53:39.364644
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = const_from_json_schema(data={'const':1}, definitions=definitions)
    assert schema.validate(1) is True
    assert schema.validate(2) is False


# Generated at 2022-06-12 15:53:48.517335
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const1 = 10
    const2 = "hello"
    const3 = None
    data1 = {"const": const1}
    data2 = {"const": const2}
    data3 = {"const": const3}
    field1 = const_from_json_schema(data1, None)
    field2 = const_from_json_schema(data2, None)
    field3 = const_from_json_schema(data3, None)
    assert field1.validate(const1) == const1
    assert field1.validate(const2) == False
    assert field1.validate(const3) == False
    assert field2.validate(const2) == const2
    assert field2.validate(const1) == False
    assert field2.validate(const3) == False
    assert field

# Generated at 2022-06-12 15:54:00.118839
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    def _test_from_json_schema_type(type_string, data):
        field = from_json_schema_type(data, type_string=type_string, allow_null=False, definitions={})
        assert isinstance(field, type(from_json_schema_type(data, type_string, allow_null=True, definitions={})))
        return field

    assert isinstance(
        _test_from_json_schema_type("number", {
            "type": "number",
            "minimum": 1.5,
            "maximum": 2.5,
            "exclusiveMinimum": 0.1,
            "exclusiveMaximum": 0.2,
            "multipleOf": 0.3,
            "default": 0.4,
        }), Float
    )


# Generated at 2022-06-12 15:54:04.415092
# Unit test for function to_json_schema
def test_to_json_schema():
    json_schema_data = to_json_schema(TestSchema)

# Generated at 2022-06-12 15:54:08.367513
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "abc"}
    assert const_from_json_schema(data, {}) == Const("abc", False, False)
    data["default"] = "xyz"
    assert const_from_json_schema(data, {}) == Const("abc", False, False)


# Generated at 2022-06-12 15:54:19.370096
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True  # type: ignore
    assert to_json_schema(NeverMatch()) == False  # type: ignore
    assert to_json_schema(Field(default="Test")) == {"default": "Test"}  # type: ignore
    assert to_json_schema(Field(default="Test", allow_null=True)) == {  # type: ignore
        "type": ["null", "string"],
        "default": "Test",
    }

    class Person(SchemaDefinitions, Schema):
        name = Field()
        age = Integer()
        is_a_very_good_boy = Boolean()
        subjects_of_interest = Array(String())
        tags = String()

    class Point(Schema):
        x = Float()
        y = Float()


# Generated at 2022-06-12 15:54:24.499698
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["integer", "string"]}) == String(
        additional_properties=Integer()
    )



# Generated at 2022-06-12 15:54:31.563008
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": ["string", "null"],
        "default": None,
    }
    assert to_json_schema(String(allow_blank=True)) == {
        "type": ["string", "null"],
        "minLength": 0,
        "default": None,
    }
    assert to_json_schema(Integer(minimum=-Infinity)) == {
        "type": ["integer", "null"],
        "exclusiveMinimum": False,
        "default": None,
    }
    assert to_json_schema(
        Integer(minimum=0, exclusive_minimum=True)
    ) == {
        "type": ["integer", "null"],
        "minimum": 0,
        "exclusiveMinimum": True,
        "default": None,
    }

# Generated at 2022-06-12 15:54:36.059638
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    c1 = {"const": "cow"}
    c2 = const_from_json_schema(c1, None)
    assert c2(None) == "cow"
    assert c2("cow") == "cow"
    assert c2("dog") is not None



# Generated at 2022-06-12 15:54:48.326234
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None), Integer)
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=False, definitions=None), Float)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False, definitions=None), String)
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="array", allow_null=False, definitions=None), Array)

# Generated at 2022-06-12 15:56:18.993952
# Unit test for function to_json_schema
def test_to_json_schema():
    from .generic import Object, String
    from .primitives import Integer

    class Simple(Object):
        a = String()
        b = Integer(allow_null=True)

    expected = {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
            "b": {"type": ["integer", "null"]},
        },
        "additionalProperties": False,
    }
    assert to_json_schema(Simple) == expected



# Generated at 2022-06-12 15:56:22.539869
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        name = String(max_length=5)

    schema = Person.make_validator()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "name": {"type": "string", "maxLength": 5},
        },
    }

# Generated at 2022-06-12 15:56:35.012089
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    import io
    schema = Schema(
        {"name": String(), "age": Integer()},
        {"address": {
            "street": String(),
            "city": String(),
            "postal_code": String()
        }},
    )

# Generated at 2022-06-12 15:56:36.624061
# Unit test for function to_json_schema
def test_to_json_schema():
    from pyshema.formats.json_schema import load_schema

    schema = load_schema()
    assert to_json_schema(schema) == schema.to_json()

# Generated at 2022-06-12 15:56:45.983303
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # integer 
    data = {
        "integer_schema": True,
        "type": "integer",
        "minimum_schema": True,
        "minimum": 1,
        "maximum_schema": True,
        "maximum": 100,
        "exclusiveMinimum_schema": True,
        "exclusiveMinimum": 1,
        "exclusiveMaximum_schema": True,
        "exclusiveMaximum": 100,
        "multipleOf_schema": True,
        "multipleOf": 2,
        "default_schema": True,
        "default": 1
    }
    field = from_json_schema_type(data, type_string="integer", allow_null=False, definitions=None)
    assert isinstance(field, Integer)
    assert field.minimum == 1
    assert field.maximum == 100

# Generated at 2022-06-12 15:56:57.878660
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    schema = Schema(
        {
            "title": String(required=True),
            "year": Integer().minimum(1900),
            "tags": Array(items=String()).min_items(2),
            "cast": Object(
                {
                    "role": String(required=True),
                    "actor": String(),
                    "actor_id": Reference(to="Actor"),
                }
            ).required(),
        }
    )

# Generated at 2022-06-12 15:57:01.325049
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type(data={"type": "boolean"}, type_string="boolean", allow_null=False, definitions=definitions)



# Generated at 2022-06-12 15:57:06.247393
# Unit test for function to_json_schema
def test_to_json_schema():
    assert (
        to_json_schema(Integer())
        == {
            "default": NO_DEFAULT,
            "type": "integer",
        }
    )
    assert (
        to_json_schema(String(max_length=8))
        == {
            "default": NO_DEFAULT,
            "maxLength": 8,
            "type": "string",
        }
    )
    assert (
        to_json_schema(Array(items=String(max_length=8)))
        == {
            "default": NO_DEFAULT,
            "items": {
                "default": NO_DEFAULT,
                "maxLength": 8,
                "type": "string",
            },
            "type": "array",
        }
    )

# Generated at 2022-06-12 15:57:13.775218
# Unit test for function to_json_schema
def test_to_json_schema():
    from kson.validators import Integer, Object, String, union

    class Number(Integer):
        default = 42
        maximum = 100
        multiple_of = 2

    class Color(String):
        enum = [("red", "red"), ("green", "green"), ("blue", "blue")]

    class Person(Object):
        properties = {
            "name": String(allow_null=True),
            "age": Integer,
        }

    assert to_json_schema(Person) == {
        "type": "object",
        "properties": {"name": {"type": ["string", "null"]}, "age": {"type": "integer"}},
        "required": ["age"],
    }


# Generated at 2022-06-12 15:57:17.649104
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string in ["number", "integer", "string", "boolean", "array", "object"]:
        data = {"type": type_string}
        field = from_json_schema(data)



# Generated at 2022-06-12 15:57:44.051152
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Number
    from_json_schema_type(
        data={"type": "number"}, type_string="number", allow_null=False, definitions=None
    )
    from_json_schema_type(
        data={"type": "number"}, type_string="number", allow_null=True, definitions=None
    )
    # Integer
    from_json_schema_type(
        data={"type": "integer"}, type_string="integer", allow_null=False, definitions=None
    )
    from_json_schema_type(
        data={"type": "integer"}, type_string="integer", allow_null=True, definitions=None
    )
    # String

# Generated at 2022-06-12 15:57:53.226142
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:58:04.704310
# Unit test for function to_json_schema
def test_to_json_schema():
    # noinspection PyUnresolvedReferences
    from . import Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference


    class AssertionContext:
        @classmethod
        def assertSchemaEqual(
            cls,
            schema1: typing.Union[Field, typing.Type[Schema]],
            schema2: typing.Union[Field, typing.Type[Schema]],
        ) -> None:
            import json

            instance = cls()
            instance.callback(schema1, schema2)
            schema1_definition = to_json_schema(schema1)
            schema2_definition = to_json_schema(schema2)
            assert json.dumps(schema1_definition, sort_keys=True)

# Generated at 2022-06-12 15:58:10.380195
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from .function_field import Function
    from .number import Integer
    from .string import String
    from .object import Object
    from .array import Array


# Generated at 2022-06-12 15:58:17.996516
# Unit test for function to_json_schema
def test_to_json_schema():
    class Foo(Schema):
        a = Integer()
        b = String(allow_blank=True)

    class Bar(Schema):
        a = Integer(allow_null=True)
        b = String(allow_blank=True)

    class Baz(Schema):
        foo_list: typing.List[Foo]

    class Quux(Schema):
        baz = Baz()
        foo_list: typing.List[Foo]

    assert to_json_schema(Quux) == {
        "type": "object",
        "properties": {
            "baz": {"type": "object", "properties": {"foo_list": {"type": "array"}}}
        },
        "required": ["baz"],
    }


# Generated at 2022-06-12 15:58:24.240250
# Unit test for function to_json_schema
def test_to_json_schema():
    from schema import Schema, SchemaError

    # Usage: Schema(<parameter_value>)
    assert Schema(None).allow_null==None
    assert Schema(True).allow_null==True
    assert Schema(False).allow_null==False
    assert Schema(1).allow_null==False
    assert Schema('1').allow_null==False
    assert Schema(1.1).allow_null==False
    assert Schema([1]).allow_null==False
    assert Schema({1:1}).allow_null==False

    # Usage: Schema(<parameter_type>, <parameter_value>)
    assert Schema(None,None).allow_null==None
    assert Schema(None,True).allow_null==True
    assert Schema(None,False).allow_null==False


# Generated at 2022-06-12 15:58:32.704393
# Unit test for function from_json_schema
def test_from_json_schema():
    assert(from_json_schema({
        "type": "array",
        "items": {"type": "string"}
    }) == Array(items=String()))
    assert(from_json_schema({
        "enum": ["alpha", "beta", "gamma"]
    }) == Choice(choices=["alpha", "beta", "gamma"]))
    assert(from_json_schema({
        "type": "boolean",
        "const": {"one": 1, "two": 2}
    }) == Const(value={"one": 1, "two": 2}))



# Generated at 2022-06-12 15:58:42.795250
# Unit test for function to_json_schema
def test_to_json_schema():
    class ExampleSchemaDefinitions(SchemaDefinitions):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.example_string: Field = String(
                min_length=5, description="Foo bar."
            )  # type: ignore

    class ExampleSchema(Schema):
        class Meta:
            definitions = ExampleSchemaDefinitions()

        integer = Integer(minimum=10)
        integer_null = Integer(allow_null=True)
        string = String(max_length=20)
        string_null = String(max_length=20, allow_null=True)
        reference = Reference(to=ExampleSchemaDefinitions.example_string)

# Generated at 2022-06-12 15:58:50.402791
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema.make(a=String().pattern(re.compile(r"^the quick brown fox$")))
    data = to_json_schema(schema)
    expected_data = {
        "properties": {
            "a": {
                "type": "string",
                "pattern": "^the quick brown fox$",
            },
        },
        "required": ["a"],
        "type": "object",
    }
    assert data == expected_data
    data = to_json_schema(schema.make_validator())

# Generated at 2022-06-12 15:58:53.513895
# Unit test for function to_json_schema
def test_to_json_schema():
    class SchemaA(Schema):
        a = Integer()

    schema = SchemaA(allow_unknown_fields=False)
    data = to_json_schema(schema)
    assert data == {"type": "object", "properties": {"a": {"type": "integer"}}}



# Generated at 2022-06-12 15:59:19.337369
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Object(properties={"a": Integer(min_value=1, max_value=10)})
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {
            "a": {
                "type": "integer",
                "minimum": 1,
                "maximum": 10,
            }
        },
    }
    # Test with definitions
    definitions = SchemaDefinitions({"x": String(), "y": Integer()})
    schema = schema.with_definitions(definitions)
    data = to_json_schema(schema)

# Generated at 2022-06-12 15:59:29.164354
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Schema(allow_null=True)) == {
        "type": ["object", "null"],
        "default": None,
    }
    assert to_json_schema(Schema(allow_null=True, default="hi")) == {
        "type": ["object", "null"],
        "default": "hi",
    }
    assert to_json_schema(String(allow_blank=True)) == {
        "type": "string",
        "default": "",
    }
    assert to_json_schema(String(max_length="10")) == {
        "type": "string",
        "maxLength": "10",
        "default": "",
    }

# Generated at 2022-06-12 15:59:39.053117
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.base import TypeSystemException
    from typesystem.schemas import Reference
    from unittest.mock import MagicMock

    definitions = MagicMock(wraps=SchemaDefinitions())
    definitions.__getitem__ = MagicMock(side_effect=IndexError)
    data = {
        "type": "string",
        "minLength": 0,
        "maxLength": 10,
        "format": "email",
        "pattern": "foo",
        "default": "a-default-value",
    }
    field = from_json_schema_type(
        data, type_string="string", allow_null=True, definitions=definitions
    )
    assert isinstance(field, String)
    assert field.allow_null is True
    assert field.allow_blank is True

# Generated at 2022-06-12 15:59:43.982625
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Integer
    expected = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "integer",
    }
    result = to_json_schema(schema)
    assert expected == result



# Generated at 2022-06-12 15:59:54.643788
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    data = {"type": "number"}
    field = from_json_schema_type(data, type_string="number", allow_null=True, definitions=definitions)
    assert isinstance(field, Float)
    assert field.allow_null is True
    assert field.minimum is None
    assert field.maximum is None
    assert field.exclusive_minimum is None
    assert field.exclusive_maximum is None
    assert field.multiple_of is None
    assert field.default is NO_DEFAULT

    data = {"type": "null", "minimum": 12}
    field = from_json_schema_type(data, type_string="null", allow_null=True, definitions=definitions)
    assert isinstance(field, Integer)
    assert field.allow_null is True
    assert field.minimum == 12
    assert field.maximum

# Generated at 2022-06-12 15:59:59.982104
# Unit test for function to_json_schema
def test_to_json_schema():
    # check the general case
    data = to_json_schema(Integer(allow_null=True))
    assert data == {
        "type": ["integer", "null"],
    }
    assert "definitions" not in data

    data = to_json_schema(Integer(allow_null=True, min_value=1))
    assert data == {
        "type": ["integer", "null"],
        "minimum": 1,
    }
    assert "definitions" not in data

    data = to_json_schema(Integer(allow_null=True, max_value=1))
    assert data == {
        "type": ["integer", "null"],
        "maximum": 1,
    }
    assert "definitions" not in data

    data = to_json_schema(Union(String, Integer))

# Generated at 2022-06-12 16:00:10.721349
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = to_json_schema(
        And(
            String(allow_null=True, min_length=5, max_length=20, pattern=re.compile("^X")),
            Or(Integer(allow_null=True, minimum=0, maximum=100, multiple_of=3), Float()),
            Const("abc", allow_null=True),
            Object(
                allow_null=True,
                properties={
                    "a": String(allow_null=True),
                    "b": Array(allow_null=True, min_items=10, max_items=20, unique_items=True),
                },
                min_properties=3,
            ),
        )
    )