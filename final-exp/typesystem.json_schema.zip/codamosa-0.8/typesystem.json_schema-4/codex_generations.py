

# Generated at 2022-06-12 15:51:47.822131
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": "string",
        "minLength": 1,
        "maxLength": 3,
        "pattern": "^a",
        "format": "email",
    }

    field = type_from_json_schema(schema, definitions=definitions)
    assert isinstance(field, String)
    assert field.constraints["min_length"] == 1
    assert field.constraints["max_length"] == 3
    assert field.constraints["format"] == "email"
    assert field.constraints["pattern"] == re.compile("^a")

    schema = {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 3,
        "pattern": "^a",
        "format": "email",
    }

    field

# Generated at 2022-06-12 15:51:59.505796
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    definitions = {}
    data = {
        "if": {"type": "integer"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
    }

    field = if_then_else_from_json_schema(data, definitions)
    assert type(field) is IfThenElse
    assert type(field.then_clause) is Integer
    assert type(field.else_clause) is String
    assert type(field.if_clause) is Integer

    data = {"if": {"type": "integer"}, "then": {"type": "integer"}}
    field = if_then_else_from_json_schema(data, definitions)
    assert type(field) is IfThenElse
    assert type(field.then_clause) is Integer
    assert field.else_clause is None

# Generated at 2022-06-12 15:52:10.662335
# Unit test for function from_json_schema
def test_from_json_schema():
    assert Field.from_json_schema({"type": "string"}) == String()
    assert Field.from_json_schema({"type": "array", "items": {"type": "string"}}) == Array(
        items=String()
    )
    assert Field.from_json_schema({"type": "object", "properties": {"foo": {"type": "number"}}}) == Object(
        properties={"foo": Number()}
    )

# Generated at 2022-06-12 15:52:17.380653
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf":[{"type":"string"},{"type":"integer"}]}
    result = any_of_from_json_schema(schema, definitions=None)
    assert type(result) == Union
    assert len(result.any_of) == 2
    assert isinstance(result.any_of[0], String)
    assert isinstance(result.any_of[1], Integer)


# Generated at 2022-06-12 15:52:18.791991
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert False, "Test not implemented"



# Generated at 2022-06-12 15:52:27.359781
# Unit test for function to_json_schema
def test_to_json_schema():

    class TestSchema(SchemaDefinitions):
        a: str = "5"
        b: typing.List[int] = [1, 2, 3]
        c: int = 5
        d: Object = Object(
            default={"a": 1, "b": 2},
            properties={"a": Integer(maximum=6), "b": Boolean()},
            required=["a", "b"],
            min_properties=1,
            max_properties=1,
        )
        e: IfThenElse = IfThenElse(
            if_clause=Integer(maximum=6),
            then_clause=String(),
            else_clause=Boolean(),
            default=True,
        )

# Generated at 2022-06-12 15:52:32.005748
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({'type': 'number'}) == Number()
    assert from_json_schema({'type': 'number'}, SchemaDefinitions()) == Number()
    assert from_json_schema({'type': 'number'}, SchemaDefinitions({'#/definitions/key': Number()})) == Number() == Number()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({'enum': [1, 2, 3]}) == Choice(values=[1, 2, 3])
    assert from_json_schema({'const': 'foo'}) == Const(value='foo')

# Generated at 2022-06-12 15:52:42.377130
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    sample_json_data = {"oneOf": [{"type": "integer"}, {"type": "string"}], "default": "no_default"}
    sample_schema_definitions = SchemaDefinitions()
    sample_schema_definitions["#/definitions/JSONSchema"] = JSONSchema
    assert list(one_of_from_json_schema(sample_json_data, sample_schema_definitions).validate(100).messages) == []
    assert list(one_of_from_json_schema(sample_json_data, sample_schema_definitions).validate(100.0).messages) == [('one_of', ['100.0', 'no_default'])]


# Generated at 2022-06-12 15:52:54.001435
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "integer",
            "minimum": 0,
        },
        "then": {
            "type": "integer",
            "maximum": 50,
        },
        "else": {
            "type": "integer",
            "maximum": 25,
        },
    }
    expected = IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Integer(maximum=50),
        else_clause=Integer(maximum=25),
    )
    actual = if_then_else_from_json_schema(data, None)
    try:
        assert expected.default == actual.default
        assert_field_equal(expected, actual)
    except AssertionError:
        print("Expected: ", expected)

# Generated at 2022-06-12 15:53:00.377758
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "type": "integer",
                "default": 32
            },
            {
                "enum": [2,4,8]
            },
        ],
    }
    field = all_of_from_json_schema(schema, SchemaDefinitions())
    assert field.validate(2) == 2
    assert field.validate(4) == 4
    assert field.validate(8) == 8
    assert field.validate(32) == 32
    assert field.validate(1) == None



# Generated at 2022-06-12 15:53:32.140273
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    with open('schema_allOf_example.json') as f:
        data = json.load(f)
    d = data
    type_string = d['properties']['name']['type']
    print(type_string)
    print(from_json_schema_type(d, type_string, allow_null=False, definitions=definitions))
    assert False

# Generated at 2022-06-12 15:53:44.869916
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        class Meta:
            target_class = dict

        name = String(required=True, allow_blank=False)
        age = Integer(required=True)

    assert to_json_schema(MySchema) == {
        "definitions": {"MySchema": {"type": "object", "properties": {"name": {
            "type": ["string", "null"],
            "minLength": 1,
            "required": True
        }, "age": {
            "type": ["integer", "null"],
            "required": True
        }}}},
        "$ref": "#/definitions/MySchema",
    }

# Generated at 2022-06-12 15:53:49.589253
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    s = from_json_schema({"not": {"type": "integer"}})
    assert s.contains(2.0)
    assert not s.contains(5)

    s = from_json_schema({"not": {"type": "null"}})
    assert s.contains(5)
    assert not s.contains(None)

    s = from_json_schema({"not": {"type": ["null", "integer"]}})
    assert s.contains(5)
    assert not s.contains(None)
    assert not s.contains(2.0)

    # todo: don't know if this is valid
    s = from_json_schema({"not": {"not": {"type": "integer"}}})
    assert not s.contains(2.0)
   

# Generated at 2022-06-12 15:53:57.835988
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    import pytest
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions(definitions={"foo": String()})
    assert isinstance(ref_from_json_schema(data, definitions=definitions), String)
    assert "#/definitions/foo" in definitions
    assert definitions["#/definitions/foo"] is definitions["foo"]
    with pytest.raises(AssertionError):
        ref_from_json_schema({"$ref": "https://example.com"}, definitions=definitions)



# Generated at 2022-06-12 15:54:07.590923
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    defs = {
        '#/definitions/NotMaybeVersionNumber': Integer(default='1.2.3'),
        '#/definitions/MaybeVersionNumber': Integer(allow_null=True, default='4.5.6'),
        '#/definitions/VersionNumber': Integer(default='7.8.9'),
    }

# Generated at 2022-06-12 15:54:13.542206
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"if": {"type":"string"}, "then": {"type": "string"}, "else": {"type": "number"}}
    schema = if_then_else_from_json_schema(data, definitions=None)

    assert isinstance(schema, IfThenElse)
    assert isinstance(schema.then_clause, String)
    assert isinstance(schema.else_clause, Number)

test_if_then_else_from_json_schema()


#
# JsonSchemaDraft07Validator
#

# Generated at 2022-06-12 15:54:18.496312
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Test with $ref back reference
    ref_schema = {"$ref": "#/definitions/positiveInteger"}
    schema = {"definitions": {"positiveInteger": {"minimum": 0}}}
    from_json_schema(schema)["definitions"]["positiveInteger"].validate(1)
    from_json_schema(ref_schema).validate(1)

    # Test with $ref reference to external schema
    ref_schema = {"$ref": "https://json-schema.org/draft/2019-09/schema"}
    from_json_schema(ref_schema)



# Generated at 2022-06-12 15:54:20.232556
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema(): from_json_schema({"$ref" : "#/definitions/boolean_schema"})



# Generated at 2022-06-12 15:54:29.121109
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Test Not",
        "description": "An example Schema",
        "type": "object",
        "not": {
            "type": "object",
            "properties": {
                "age": {"type": "string"},
                "name": {"type": "string"}
            }
        },
        "required": ["name", "age"],
        "default": {"name": "abhi", "age": "12"},
        "additionalProperties": False
    }
    res = not_from_json_schema(schema, None)
    assert res.name == "not"
    assert res.negated.name == "object"
    assert "abhi" in res.default




# Generated at 2022-06-12 15:54:38.833241
# Unit test for function to_json_schema
def test_to_json_schema():
    # not exhaustive, just a few test cases
    data = to_json_schema(String())
    assert isinstance(data, dict)
    assert data.get("type") == "string"
    assert data.get("default") is None

    data = to_json_schema(String(default="abc"))
    assert data.get("default") == "abc"

    data = to_json_schema(Integer())
    assert isinstance(data, dict)
    assert data.get("type") == "integer"

    data = to_json_schema(Integer(default=123))
    assert data.get("default") == 123

    data = to_json_schema(Float())
    assert isinstance(data, dict)
    assert data.get("type") == "number"


# Generated at 2022-06-12 15:55:26.139339
# Unit test for function to_json_schema
def test_to_json_schema():
    def get_json_schema(
        arg: typing.Union[Field, typing.Type[Schema]],
    ) -> typing.Union[bool, dict]:
        return to_json_schema(arg, _definitions=None)

    assert get_json_schema(Any()) == True
    assert get_json_schema(NeverMatch()) == False

    assert get_json_schema(String()) == {"type": "string"}
    assert get_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert get_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert get_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-12 15:55:31.484479
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$ref": "#/definitions/name",
    }
    definitions = SchemaDefinitions()
    definitions["name"] = String(max_length=3)
    assert from_json_schema(data, definitions) == String(max_length=3)



# Generated at 2022-06-12 15:55:42.104027
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False)
        == Integer()
    )
    assert (
        from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True)
        == Integer(allow_null=True)
    )
    assert (
        from_json_schema_type({"type": "number"}, type_string="number", allow_null=False)
        == Float()
    )
    assert (
        from_json_schema_type({"type": "number"}, type_string="number", allow_null=True)
        == Float(allow_null=True)
    )

# Generated at 2022-06-12 15:55:50.815862
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    class Person(Schema):
        id = Integer()
        name = String(max_length=32, allow_blank=True)
        weight = Float(default=0.0)
        addresses = Array(
            items=String(
                min_length=256,
                pattern_regex=re.compile(
                    r"^(?:[a-zA-Z0-9-]+:)?(?://)?(?:[^@/\n]+@)?(?:[^:/\n]+)(?::\d+)?(?:/|$)"
                ),
            )
        )


# Generated at 2022-06-12 15:55:55.527992
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "string"}
    field = from_json_schema_type(data, type_string="string", allow_null=False, definitions=None)
    assert isinstance(field, String)



# Generated at 2022-06-12 15:56:04.385879
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(min_length=1, max_length=3)) == {
        "type": "string",
        "minLength": 1,
        "maxLength": 3,
    }
    assert to_json_schema(String(min_length=1, max_length=3, allow_null=True)) == {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 3,
    }
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}



# Generated at 2022-06-12 15:56:08.618624
# Unit test for function from_json_schema
def test_from_json_schema():
    test_schema = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "^[a-z]*$",
        "format": "email",
    }
    field = from_json_schema(test_schema)
    assert field == String(
        format="email",
        min_length=1,
        max_length=10,
        pattern=re.compile("^[a-z]*$"),
    )



# Generated at 2022-06-12 15:56:19.291639
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        name = String(min_length=3, max_length=10)
        email = String(pattern_regex=r"[^@]+@[^@]+\.[^@]+")
        url = String(
            pattern_regex=r"https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+",
            allow_null=True,
        )
        age = Integer(minimum=1, maximum=100)
        weight = Float(multiple_of=0.5)
        height = Float(exclusive_minimum=1.3, exclusive_maximum=2.2)
        tags = Array(items=String(), min_items=1, max_items=5)

# Generated at 2022-06-12 15:56:25.932196
# Unit test for function to_json_schema
def test_to_json_schema():
    @validator
    class TestSchema(Schema):
        test_string = String(
            min_length=1, max_length=1, pattern_regex=r"abc", format="date"
        )
        test_integer = Integer(
            minimum=0, maximum=1, exclusive_minimum=True, exclusive_maximum=True
        )
        test_number = Float(
            minimum=0.1, maximum=1.1, exclusive_minimum=True, exclusive_maximum=True
        )
        test_boolean = Boolean()
        test_array = Array(min_items=1, max_items=1, items=[String()], unique_items=True)

# Generated at 2022-06-12 15:56:37.912220
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=None).__class__==String

    assert from_json_schema_type(data={}, type_string="string", allow_null=False, definitions=None).__class__==String
    
    assert from_json_schema_type(data={"type": "string", "minLength": 0}, type_string="string", allow_null=False, definitions=None).__class__==String

    assert from_json_schema_type(data={"type": "string", "minLength": 1}, type_string="string", allow_null=False, definitions=None).__class__==String


# Generated at 2022-06-12 15:57:02.106930
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "number"}) == Number()



# Generated at 2022-06-12 15:57:12.514223
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "properties": {"type_string": {"type": "string", "enum": ["null", "boolean", "object", "array", "number", "string"]}},
        "required": ["type_string"],
    }

# Generated at 2022-06-12 15:57:17.896917
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}).__class__ == String
    assert from_json_schema({"type": "number"}).__class__ == Number
    assert from_json_schema({"type": "integer"}).__class__ == Integer
    assert from_json_schema({"type": "object"}).__class__ == Object
    assert from_json_schema({"type": "array"}).__class__ == Array
    assert from_json_schema({"type": "null"}).__class__ == Any
    assert from_json_schema({"type": "boolean"}).__class__ == Boolean
    assert from_json_schema({"type": "any"}).__class__ == Any
    assert from_json_schema({"type": "none"}).__class__ == NeverMatch

# Generated at 2022-06-12 15:57:25.069200
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test that all validator types (except NeverMatch) round-trip through to_json_schema.
    for cls in ALL_VALIDATORS:
        if not issubclass(cls, Field) or cls is NeverMatch:
            continue
        field = cls()
        assert field == from_json_schema(to_json_schema(field))


# @Utils.memoize

# Generated at 2022-06-12 15:57:34.846517
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(None) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "pattern": "foo"}) == String(
        pattern=re.compile("foo")
    )
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "integer", "format": "int32"}) == Integer(
        minimum=-2147483648, maximum=2147483647
    )
    assert from_json_

# Generated at 2022-06-12 15:57:39.810470
# Unit test for function to_json_schema
def test_to_json_schema():
    """Test function to_json_schema"""
    from pydantic.schema import Schema
    from pydantic import BaseModel

    class ABC(BaseModel):
        a: str
        b: int

    class DEF(BaseModel):
        d: str
        e: int

    class GHI(BaseModel):
        g: DEF
        h: int
        i: ABC

    class SchemaTest(Schema):
        class Config:
            schema_extra = {
                "t": "a anyOf field",
                "x": "a property",
            }

        class Defs:
            abc = ABC.schema()
            defs = DEF.schema()
            ghi = GHI.schema()


# Generated at 2022-06-12 15:57:47.160141
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test `type_string == 'number'`
    field = from_json_schema_type(
        {
            "type": "number",
            "minimum": 0,
            "maximum": 1,
            "exclusiveMinimum": 2,
            "exclusiveMaximum": 3,
            "multipleOf": 4,
            "default": 5,
        },
        type_string="number",
        allow_null=True,
    )
    assert field == Float(
        minimum=0, maximum=1, exclusive_minimum=2, exclusive_maximum=3, multiple_of=4, default=5
    )

# Generated at 2022-06-12 15:57:55.777768
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(Array()) == {"type": "array", "items": True}
    assert to_json_schema(Object()) == {"type": "object", "properties": {}}

# Generated at 2022-06-12 15:58:03.926986
# Unit test for function to_json_schema
def test_to_json_schema():
    f = from_json_schema(
        {
            "type": ["integer", "null"],
            "minimum": 0,
            "maximum": 1000,
            "multipleOf": 2,
        },
        definitions=None,
    )
    assert to_json_schema(f) == to_json_schema(Integer(minimum=0, maximum=1000, multiple_of=2, allow_null=True))
    # TODO: Add more tests



# Generated at 2022-06-12 15:58:13.910422
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    assert isinstance(
        from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False),
        Integer,
    )
    assert isinstance(
        from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True),
        Integer,
    )
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True).allow_null

    assert isinstance(
        from_json_schema_type({"type": "number"}, type_string="number", allow_null=False),
        Number,
    )

# Generated at 2022-06-12 15:58:42.980063
# Unit test for function to_json_schema
def test_to_json_schema():
    _to_json_schema = to_json_schema
    _from_json_schema = from_json_schema
    class MySchema(Schema):
        a = String().allow_blank().min_length(1)
        b = Integer().allow_null().minimum(0)
    a = _from_json_schema(_to_json_schema(MySchema))
    b = MySchema.make_validator()
    assert a == b
    assert _to_json_schema(a) == _to_json_schema(b)
test_to_json_schema()
del test_to_json_schema
Schema.to_json_schema = to_json_schema
Field.to_json_schema = classmethod(to_json_schema)



# Generated at 2022-06-12 15:58:50.493002
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    string = String(
        types=['string', 'null'],
        minimum=5,
        maximum=10,
        exclusive_minimum=5,
        exclusive_maximum=10,
        multiple_of=5,
    )
    integer = Integer(
        types=['integer', 'null'],
        minimum=5,
        maximum=10,
        exclusive_minimum=5,
        exclusive_maximum=10,
        multiple_of=5,
    )
    number = Number(
        types=['number', 'null'],
        minimum=5,
        maximum=10,
        exclusive_minimum=5,
        exclusive_maximum=10,
        multiple_of=5,
    )
    boolean = Boolean(types=['boolean', 'null'])

# Generated at 2022-06-12 15:58:57.182292
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer"
    }
    assert to_json_schema(Integer(min_value=0)) == {
        "type": "integer",
        "minimum": 0,
    }
    assert to_json_schema(Integer(min_value=0, max_value=10)) == {
        "type": "integer",
        "minimum": 0,
        "maximum": 10,
    }
    assert to_json_schema(Integer(min_value=0, max_value=10, multiple_of=3)) == {
        "type": "integer",
        "minimum": 0,
        "maximum": 10,
        "multipleOf": 3,
    }

# Generated at 2022-06-12 15:59:07.673492
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "$id": "https://clark-kent.readthedocs.io/en/latest/clark-kent/fields.html#clark-kent.fields.String",
        "type": "string",
    }


# Generated at 2022-06-12 15:59:19.147160
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_strings = {
        "number": True,
        "string": True,
        "boolean": True,
        "object": True,
        "array": True,
        "integer": True,
        "null": True,
    }

    def _test(type_string, allow_null=False):
        data = {}
        if type_string == "integer":
            data["type"] = "integer"
        elif type_string == "number":
            data["type"] = "number"
        elif type_string != "null":
            data["type"] = type_string

        if allow_null:
            data["type"] = data.get("type") | "null"

        field = from_json_schema_type(data, type_string, allow_null)

# Generated at 2022-06-12 15:59:28.064801
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "integer"}
    assert isinstance(from_json_schema_type(data, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type(data, "number", False, None), Float)
    assert isinstance(from_json_schema_type(data, "string", False, None), String)
    assert isinstance(from_json_schema_type(data, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type(data, "array", False, None), Array)
    assert isinstance(from_json_schema_type(data, "object", False, None), Object)



# Generated at 2022-06-12 15:59:38.087530
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema.from_json_schema(
        {
            "definitions": {
                "email-address": {
                    "type": "string",
                    "format": "email",
                },
            },
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 255,
                },
                "email-addresses": {
                    "type": "array",
                    "items": {"$ref": "#/definitions/email-address"},
                },
            },
        }
    )
    schema = schema.with_optional("email-addresses")

    json_schema = to_json_schema(schema)

# Generated at 2022-06-12 15:59:50.657227
# Unit test for function to_json_schema
def test_to_json_schema():
    class USState(Schema):
        name = String(choices=[("CA", "California"), ("NC", "North Carolina")])

    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer(minimum=0, exclusive_maximum=100)
        state = USState()

    json_schema = to_json_schema(Person)

# Generated at 2022-06-12 15:59:58.033805
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({"type": "string"}), Field)
    assert isinstance(from_json_schema({"type": ["string", "null"]}), Field)
    assert isinstance(from_json_schema({"type": "number"}), Field)
    assert isinstance(from_json_schema({"type": ["number", "null"]}), Field)
    assert isinstance(from_json_schema({"type": "integer"}), Field)
    assert isinstance(from_json_schema({"type": ["integer", "null"]}), Field)
    assert isinstance(from_json_schema({"type": "boolean"}), Field)
    assert isinstance(from_json_schema({"type": ["boolean", "null"]}), Field)

# Generated at 2022-06-12 16:00:05.717229
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.exceptions import InvalidError
    import typesystem

    assert from_json_schema_type({}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type(
        {"allow_null": True}, type_string="number", allow_null=False
    ) == Float()
    assert from_json_schema_type(
        {"allow_null": False}, type_string="number", allow_null=True
    ) == Float(allow_null=True)
    assert from_json_schema_type(
        {"allow_null": True}, type_string="number", allow_null=True
    ) == Float(allow_null=True)

    assert from_json_schema_type({}, type_string="integer", allow_null=False) == Integer()
   