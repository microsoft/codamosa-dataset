

# Generated at 2022-06-12 15:51:43.029858
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "integer"}) == ({'integer', 'number'}, False)
    assert get_valid_types({"type": ["string", "boolean", "null"]}) == ({'string', 'boolean'}, True)

# Generated at 2022-06-12 15:51:45.548017
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "item"}
    options = const_from_json_schema(data, definitions=None)
    assert (options.const == "item")


# Generated at 2022-06-12 15:51:49.396490
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "number"}, {"type": "string"}]}
    assert isinstance(any_of_from_json_schema(data, None), Union)


# Generated at 2022-06-12 15:51:51.361841
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = from_json_schema({"oneOf": [{"type": "string"}, {"type": "integer"}]})
    assert isinstance(schema, OneOf)


# Generated at 2022-06-12 15:52:01.999926
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:52:05.462372
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    a = one_of_from_json_schema({"oneOf": [{"type": "number"}, {"type": "string"}]}, SchemaDefinitions())
    assert a.validate(1) == None
    assert a.validate("1") == None
    assert a.validate(None) == ["Not a valid value."]
    assert a.validate(object) == ["Not a valid value."]



# Generated at 2022-06-12 15:52:16.571127
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(None) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")
    assert from_json_schema({"$ref": "#/definitions/foo", "type": "integer"}) == AllOf(
        [Reference("#/definitions/foo"), Integer()]
    )

    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(minimum=1)


# Generated at 2022-06-12 15:52:23.291282
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"const": True}, {"enum": [False]}]}
    any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    output = Union(any_of=any_of, allow_null=False)
    assert from_json_schema(data)==output



# Generated at 2022-06-12 15:52:29.490020
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
    }
    field = if_then_else_from_json_schema(json_schema)
    assert field.if_clause.base_type() == String
    assert field.then_clause.base_type() == Integer
    assert field.else_clause.base_type() == String
    assert field._allow_null is False



# Generated at 2022-06-12 15:52:34.296223
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "array"}) == ({'array'}, False)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "object"}) == ({'object'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["integer", "boolean"]}) == ({'integer','boolean'}, False)


# Generated at 2022-06-12 15:53:53.688899
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "boolean"}}
    field = not_from_json_schema(data, definitions=None)
    assert isinstance(field, Not)
    assert isinstance(field.negated, Boolean)
    assert field.default is None



# Generated at 2022-06-12 15:53:59.235830
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = all_of_from_json_schema({'default':'', 'allOf':[{'type':'string', 'maxLength':11, 'pattern':'[pat]*'}]}, {})
    assert schema.render_value('patpatpatpatpatpatpat') == 'patpatpatpatpatpatpat'
    assert type(schema.render_value('patpatpatpatpatpatpat')) is str


# Generated at 2022-06-12 15:54:05.695449
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "definitions": {
            "foo": {"type": "string"},
        },
        "$ref": "#/definitions/foo"
    }
    assert ref_from_json_schema(schema).to == "#/definitions/foo"
    schema['$ref'] = "https://example.com/schema.json"
    try:
        ref_from_json_schema(schema)
        assert False, "Expected error, got none" # pragma: no cover
    except AssertionError as error:
        assert str(error) == "Unsupported $ref style in document."



# Generated at 2022-06-12 15:54:14.686045
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:54:25.781076
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """Unit test for function from_json_schema_type
    """
    from typesystem.schemas import String, Object, Array

    # string
    data = {
        "$ref": "#/definitions/string",
        "definitions": {
            "string": {
                "type": "string",
                "minLength": 0,
                "maxLength": 10,
                "format": "date-time",
                "default": "foo",
            }
        },
    }
    field = from_json_schema(data)
    assert isinstance(field, String)
    assert field == String(
        min_length=0, max_length=10, format="date-time", default="foo"
    )

    # number

# Generated at 2022-06-12 15:54:28.961453
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert(isinstance(if_then_else_from_json_schema(
        {
            "if": {
                "type": "string"
            },
            "then": {
                "type": "string"
            },
        },
        definitions=None
    ), IfThenElse))

# Generated at 2022-06-12 15:54:32.599910
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema = {
        "allOf": [
            {
                "type": "integer",
                "minimum": 1,
                "maximum": 5
            },
            {
                "type": "integer",
                "minimum": 2,
                "maximum": 4
            }
        ]
    }
    typesystem_field = all_of_from_json_schema(json_schema, SchemaDefinitions())
    assert isinstance(typesystem_field, AllOf)


# Generated at 2022-06-12 15:54:37.296473
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "test": {
                "if": {"type": "integer"},
                "then": {"type": "string"},
                "else": {"type": "boolean"},
            }
        },
    }

    # In Python 3.7, since we're using function annotations, the checker cannot
    # infer the type of parameter definitions on functions, so we must cast.
    definitions = SchemaDefinitions()  # type: SchemaDefinitions
    field = from_json_schema(schema, definitions=definitions)

    # If clause is met
    document = {"test": 1}
    assert field.validate(document) == (True, None, None)



# Generated at 2022-06-12 15:54:42.813209
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "integer",
                "if": {"type": "integer"},
                "then": {
                    "if": {"maximum": 5},
                    "then": {"const": 1},
                    "else": {"const": 2},
                },
            }
        ]
    }
    field = from_json_schema(data)
    json = field.schema()
    assert json == {
        "type": "array",
        "items": {
            "type": "integer",
            "if": {"type": "integer"},
            "then": {
                "if": {"maximum": 5},
                "then": {"const": 1},
                "else": {"const": 2},
            },
        },
    }



# Generated at 2022-06-12 15:54:49.965429
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {
            "properties": {"foo": {"type": "number"}}
        },
        "then": {"properties": {"foo": {"type": "number", "minimum": 10}}},
        "else": {"properties": {"foo": {"type": "number", "maximum": -10}}},
    }
    typed_schema = from_json_schema(schema)

# Generated at 2022-06-12 15:55:53.019671
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        from_json_schema_type(data={"type": "number"}, type_string="number", allow_null=False)
        == Float()
    )
    assert (
        from_json_schema_type(data={"type": "integer"}, type_string="integer", allow_null=True)
        == Integer(allow_null=True)
    )
    assert (
        from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False)
        == String()
    )
    assert (
        from_json_schema_type(data={"type": "boolean"}, type_string="boolean", allow_null=False)
        == Boolean()
    )



# Generated at 2022-06-12 15:56:01.900162
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "minLength": 1,
    }
    field = from_json_schema_type(data, data["type"], False, None)
    assert field.to_json({}) == {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "minLength": 1,
    }



# Generated at 2022-06-12 15:56:08.879001
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Test for function type_from_json_schema
    """
    assert isinstance(type_from_json_schema(
        {'type': 'boolean'}, SchemaDefinitions()
    ), Boolean)
    assert isinstance(type_from_json_schema(
        {'type': 'number'}, SchemaDefinitions()
    ), Number)
    assert isinstance(type_from_json_schema(
        {'type': 'integer'}, SchemaDefinitions()
    ), Integer)
    assert isinstance(type_from_json_schema(
        {'type': 'null'}, SchemaDefinitions()
    ), Const)
    assert isinstance(type_from_json_schema(
        {'type': 'object'}, SchemaDefinitions()
    ), Object)
    assert isinstance

# Generated at 2022-06-12 15:56:19.500443
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:56:23.048755
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    >>> type_strings = ["array", "object", "string", "boolean", "number", "integer"]
    >>> for type_string in type_strings:
    ...     data = {"type": type_string}
    ...     expected = isinstance(from_json_schema(data), Field)
    ...     assert expected
    """



# Generated at 2022-06-12 15:56:27.347978
# Unit test for function to_json_schema
def test_to_json_schema():
    class SomeSchema(Schema):
        x = Numeric()

    schema = SomeSchema()
    data = to_json_schema(schema)
    assert data["properties"]["x"]["type"] == "number"



# Generated at 2022-06-12 15:56:38.946304
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": None,
    }
    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["integer", "null"],
        "default": None,
    }
    assert to_json_schema(Integer(minimum=5, maximum=10)) == {
        "type": "integer",
        "minimum": 5,
        "maximum": 10,
        "default": None,
    }
    assert to_json_schema(Integer(multiple_of=3)) == {
        "type": "integer",
        "multipleOf": 3,
        "default": None,
    }


# Generated at 2022-06-12 15:56:47.454210
# Unit test for function to_json_schema
def test_to_json_schema():  # pragma: no cover
    class Person(Schema):
        name = String(max_length=10)
        fav_number = Integer(minimum=0)
        fav_number_float = Float(minimum=0.0)
        fav_number_decimal = Decimal(minimum=Decimal("0"))
        is_cool = Boolean()
        is_cool_optional = Boolean(required=False)
        is_cool_nullable = Boolean(allow_null=True)
        is_cool_optional_nullable = Boolean(required=False, allow_null=True)
        children = Array(items=Reference("Person", to="#/definitions/Person"))

        class Meta:
            additional_properties = Boolean()
            additional_properties_required = Boolean()


# Generated at 2022-06-12 15:56:58.541829
# Unit test for function to_json_schema
def test_to_json_schema(): # type: ignore
    class A(Schema):
        a: str
    assert to_json_schema(A) == {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
        },
        "required": ["a"],
    }

    assert to_json_schema(Array(item=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }

    assert to_json_schema(Array(items=String(max_length=8), additional_items=False)) == {
        "type": "array",
        "items": {"type": "string", "maxLength": 8},
        "additionalItems": False,
    }


# Generated at 2022-06-12 15:57:09.922586
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    from_json_schema_type(data = {}, type_string = "boolean", allow_null = False, definitions = {})
    from_json_schema_type(data = {}, type_string = "array", allow_null = False, definitions = {})
    from_json_schema_type(data = {}, type_string = "object", allow_null = False, definitions = {})
    from_json_schema_type(data = {}, type_string = "number", allow_null = False, definitions = {})
    from_json_schema_type(data = {}, type_string = "integer", allow_null = False, definitions = {})


# Generated at 2022-06-12 15:57:46.226815
# Unit test for function to_json_schema
def test_to_json_schema():
    arg = String()
    data = {
        "type": ["string", "null"],
        "default": None,
        "examples": [],
        "read_only": False,
        "write_only": False,
    }
    assert to_json_schema(arg) == data



# Generated at 2022-06-12 15:57:50.870028
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "null", allow_null=True, definitions={}) == Any()
    assert from_json_schema_type({}, "null", allow_null=False, definitions={}) == NeverMatch()
    assert from_json_schema_type({}, "boolean", allow_null=False, definitions={}) == Boolean()



# Generated at 2022-06-12 15:57:51.562915
# Unit test for function to_json_schema
def test_to_json_schema():
  pass



# Generated at 2022-06-12 15:57:58.571696
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(Integer(minimum=10, maximum=20))
    assert data == {
        "type": "integer",
        "minimum": 10,
        "maximum": 20,
    }

    data = to_json_schema(Integer(minimum=10, maximum=20) | NeverMatch())
    assert data == {
        "anyOf": [
            {"type": "integer", "minimum": 10, "maximum": 20},
            {"type": "null"},
        ]
    }

    data = to_json_schema(String(format="uuid"))
    assert data == {
        "type": "string",
        "format": "uuid",
    }

    data = to_json_schema(String(format="uuid", allow_null=True))

# Generated at 2022-06-12 15:58:09.901861
# Unit test for function from_json_schema_type

# Generated at 2022-06-12 15:58:11.269417
# Unit test for function to_json_schema
def test_to_json_schema():
    from .tests import test_to_json_schema as fn
    fn()

# Generated at 2022-06-12 15:58:18.518346
# Unit test for function to_json_schema
def test_to_json_schema():
    test_field = Integer()
    test_schema = {"type":"integer"}
    assert to_json_schema(test_field) == test_schema,"test_field = Integer()"

    test_field = Integer(minimum=10)
    test_schema = {"type":"integer","minimum":10}
    assert to_json_schema(test_field) == test_schema,"test_field = Integer(minimum=10)"

    test_field = Integer(maximum=10)
    test_schema = {"type":"integer","maximum":10}
    assert to_json_schema(test_field) == test_schema,"test_field = Integer(maximum=10)"

    test_field = Integer(exclusive_minimum=10)
    test_schema = {"type":"integer","exclusiveMinimum":10}
    assert to_json

# Generated at 2022-06-12 15:58:23.236043
# Unit test for function to_json_schema
def test_to_json_schema():
    from .datetime import DateTime
    from .jsonb import JSONB
    from .uuid import UUID
    from .uuid import UUID1
    from .uuid import UUID3
    from .uuid import UUID4
    from .uuid import UUID5
    from .uuid import UUIDVersion
    from .uuid import UUIDVariant
    from .uri import URI
    from .uri import URIReference
    from .uri import URL


# Generated at 2022-06-12 15:58:33.663349
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert Any() == from_json_schema_type(
        {}, type_string="number", allow_null=True, definitions=None
    )
    assert Float() == from_json_schema_type(
        {}, type_string="number", allow_null=False, definitions=None
    )
    assert Decimal() == from_json_schema_type(
        {}, type_string="integer", allow_null=True, definitions=None
    )
    assert Integer() == from_json_schema_type(
        {}, type_string="integer", allow_null=False, definitions=None
    )

    assert String() == from_json_schema_type(
        {}, type_string="string", allow_null=True, definitions=None
    )
    assert String(allow_blank=True) == from_

# Generated at 2022-06-12 15:58:39.690768
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any) is True
    assert to_json_schema(NeverMatch) is False

    assert to_json_schema(String("foo")) == {
        "type": "string",
        "default": "foo",
    }
    assert to_json_schema(String(default="bar")) == {
        "type": "string",
        "default": "bar",
    }
    assert to_json_schema(Integer(default=42)) == {
        "type": "integer",
        "default": 42,
    }
    assert to_json_schema(Boolean(default=True)) == {
        "type": "boolean",
        "default": True,
    }

# Generated at 2022-06-12 15:59:37.599664
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": "string",
        "nullable": False,
    }

    assert to_json_schema(Array(items=String())) == {
        "type": "array",
        "items": {"type": "string", "nullable": False},
        "nullable": False,
    }


# Generated at 2022-06-12 15:59:42.610559
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema({
        'test': String()
    })
    assert to_json_schema(schema) == {
        'properties': {
            'test': {
                'type': 'string'
            }
        },
        'type': 'object'
    }

# Generated at 2022-06-12 15:59:53.832323
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import Array, Boolean, Integer, Number, Object, String
    from typesystem.types import Schema  # type: ignore

    schema = from_json_schema({"type": "integer"})
    assert isinstance(schema, Integer)
    assert schema.allow_null is False

    schema = from_json_schema({"type": "integer", "nullable": True})
    assert isinstance(schema, Integer)
    assert schema.allow_null is True

    schema = from_json_schema({"type": "number"})
    assert isinstance(schema, Number)
    assert schema.allow_null is False

    schema = from_json_schema({"type": "string"})
    assert isinstance(schema, String)
    assert schema.allow_null is False

    schema = from_json

# Generated at 2022-06-12 16:00:00.099159
# Unit test for function to_json_schema
def test_to_json_schema():
    class Root(Schema):  # type: ignore
        if_condition = Boolean()
        if_then = Boolean()
        if_else = Boolean()
        constant = Const("constant")
        choice = Choice([("a", "a"), ("b", "b")])

    class TypeA(Schema):  # type: ignore
        fieldA = String()
        fieldB = Boolean()
        fieldC = TypeB()

    class TypeB(Schema):  # type: ignore
        fieldD = Integer()
        fieldE = TypeA()

    class Container(Schema):  # type: ignore
        fieldF = Array(String())
        fieldG = Array(Integer())
        fieldH = TypeA()
        fieldI = Object(properties={"a": Integer(), "b": Boolean()})


# Generated at 2022-06-12 16:00:10.921765
# Unit test for function from_json_schema_type