

# Generated at 2022-06-12 15:51:01.022202
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = from_json_schema({
        "if": {
            "type": "number",
            "minimum": 1,
            "maximum": 3
        },
        "then": {
            "type": "object",
            "properties": {
                "one": {
                    "type": "number"
                },
                "two": {
                    "type": "number"
                }
            },
            "required": ["one", "two"]
        },
        "else": {
            "type": "string",
            "enum": ["a", "b", "c"]
        },
        "default": None
    })

    assert schema(1) == {'one': None, 'two': None}
    assert schema(3) == {'one': None, 'two': None}
    assert schema(4) is None



# Generated at 2022-06-12 15:51:06.024523
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import typesystem

    schema = typesystem.from_json_schema(
        {"allOf": [{"type": "string"}, {"maxLength": 10}]}
    )
    value = "hello"
    assert schema.is_valid(value)

    value = "hello world"
    assert not schema.is_valid(value)



# Generated at 2022-06-12 15:51:12.125553
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    field = type_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, String)

    data = {"type": "null"}
    field = type_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, Const)

    data = {"type": ["string", "null"]}
    field = type_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, Union)


# Generated at 2022-06-12 15:51:15.392817
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_json_schema = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    assert isinstance(any_of_from_json_schema(test_json_schema, definitions=None), Field)



# Generated at 2022-06-12 15:51:22.557386
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Arrange
    data = {'enum': ['a', 'b', 'c'], 'default': 'b'}
    # Act
    result = enum_from_json_schema(data, None)
    # Assert
    assert result.error_messages['invalid'] == 'Select a valid choice. That choice is not one of the available choices.'
    assert result.error_messages['invalid_choice'] == 'Select a valid choice. That choice is not one of the available choices.'
    assert result.default == 'b'
    assert result.choices == [('a', 'a'), ('b', 'b'), ('c', 'c')]
    assert result.to_python('a') == 'a'
    assert result.to_python('b') == 'b'

# Generated at 2022-06-12 15:51:33.315414
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    def check_const_from_json_schema(data):
        json_schema = from_json_schema(data)
        assert isinstance(json_schema, Const)
        assert json_schema.const == data["const"]
    test_data = {"const": {"a": "b"}}
    check_const_from_json_schema(test_data)
    test_data = {"const": ["a", "b"]}
    check_const_from_json_schema(test_data)
    test_data = {"const": 1}
    check_const_from_json_schema(test_data)
    test_data = {"const": "a"}
    check_const_from_json_schema(test_data)
    test_data = {"const": True}
    check_const_from

# Generated at 2022-06-12 15:51:39.328003
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = to_json_schema(person_schema)

# Generated at 2022-06-12 15:51:46.803459
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert (
        all_of_from_json_schema({
            "allOf": [
                {"type": "string"},
                {"enum": ["a", "b"]},
            ],
            "default": "a",
        }, definitions=None)
        == AllOf(
            all_of=[
                String(allow_blank=True),
                Choice(choices=[("a", "a"), ("b", "b")]),
            ],
            default="a",
        )
    )
# END



# Generated at 2022-06-12 15:51:59.105536
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(
        {"type": "integer"}, definitions=SchemaDefinitions()
    ) == Integer()
    assert type_from_json_schema(
        {"type": "string"}, definitions=SchemaDefinitions()
    ) == String()
    assert type_from_json_schema(
        {"type": "null"}, definitions=SchemaDefinitions()
    ) == Const(None)
    assert type_from_json_schema(
        {"type": ["integer", "null"]}, definitions=SchemaDefinitions()
    ) == Union(any_of=[Const(None), Integer()])
    assert type_from_json_schema(
        {"type": ["null", "integer"]}, definitions=SchemaDefinitions()
    ) == Union(any_of=[Const(None), Integer()])

# Generated at 2022-06-12 15:52:09.166910
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(if_clause=Any(), then_clause=Any(allow_null=True), else_clause=Any(), default=NO_DEFAULT) == if_then_else_from_json_schema({
  "$schema": "http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "foo": {
      "if": {
        "type": "string"
      },
      "then": {
        "type": ["string", "null"]
      },
      "else": {
        "type": "boolean"
      }
    }
  }
})

# Generated at 2022-06-12 15:52:29.787548
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'definitions': {'Child': {'type': 'object', 'properties': {'foo': {'type': 'string'}}}}}
    ref = Reference(to='#/definitions/Child', definitions=definitions)
    assert ref_from_json_schema({'$ref': '#/definitions/Child'}, definitions=definitions) == ref



# Generated at 2022-06-12 15:52:31.210152
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, SchemaDefinitions())
    assert isinstance(field, Reference)



# Generated at 2022-06-12 15:52:42.539275
# Unit test for function to_json_schema
def test_to_json_schema():
    """Test for to_json_schema"""

    class MyEnum(Enum):
        a = 1
        b = 2

    class NestedField(Field):
        a = String()
        b = Integer()

    class NestedSchema(Schema):
        a = String()
        b = Integer()

    class MySchema(Schema):
        a = String()
        b = Integer(min_value=0)
        c = String(pattern_regex=r"hello|world")
        d = Boolean()
        e = Array(items=Integer(maximum=12))
        f = Enum(MyEnum)
        g = NestedSchema
        h = NestedField
        i = Field(target=Integer)

    output: dict = to_json_schema(MySchema)

# Generated at 2022-06-12 15:52:54.177783
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # $ref to a defintion within the same document.
    schema = {
        "lesson": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "what_you_will_learn": {
                    # We're referencing part of the schema here.
                    "$ref": "#/lesson/properties/whats_this_for"
                },
                "when_you_will_learn_it": {
                    # We're referencing part of the schema here.
                    "$ref": "#/lesson/properties/whats_this_for"
                },
                "whats_this_for": {"type": "string"},
            },
        }
    }
    assert isinstance(schema["lesson"]["properties"]["what_you_will_learn"], dict)


# Generated at 2022-06-12 15:53:06.425393
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({"oneOf": [{"type": "object", "properties": {"a": {"$ref": "#/definitions/a"}}}]}, {}) == OneOf(one_of=[Object(properties={"a": Reference(to="#/definitions/a", definitions={})})])

# Generated at 2022-06-12 15:53:08.628441
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/Ref'}, {}), Reference)



# Generated at 2022-06-12 15:53:13.863370
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of_schema = {'oneOf': [{'type': 'string'}, {'type': 'integer'}]}
    one_of_field = one_of_from_json_schema(one_of_schema, None)
    assert isinstance(one_of_field, OneOf)
    assert len(one_of_field.one_of) == 2
    assert isinstance(one_of_field.one_of[0], String)
    assert isinstance(one_of_field.one_of[1], Integer)



# Generated at 2022-06-12 15:53:24.139895
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}},None)==Not(negated=String())
    assert not_from_json_schema({"not": {"type": "integer"}},None)==Not(negated=Integer())
    assert not_from_json_schema({"not": {"type": "number"}},None)==Not(negated=Float())
    assert not_from_json_schema({"not": {"type": "object"}},None)==Not(negated=Object())
    assert not_from_json_schema({"not": True},None)==Not(negated=Any())
    assert not_from_json_schema({"not": False},None)==Not(negated=NeverMatch())

# Generated at 2022-06-12 15:53:33.305772
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    str_schema = {
        "type": "string",
        "oneOf": [
            {"pattern": "^[^\\d]+$", "minLength": 4},
            {"pattern": "^\\d+$", "minLength": 4},
            {"pattern": "^[^\\d\\/\\$%\\^&\\*\\(\\)\\-\\+\\.]+$"},
        ],
    }
    schema = from_json_schema(str_schema)

    actual = schema.validate("abc")
    assert actual == "abc"

    with pytest.raises(ValidationError) as exc:
        schema.validate(1234)
    assert exc.value.code == "invalid_choice"

    actual = schema.validate("1234")
    assert actual == "1234"




# Generated at 2022-06-12 15:53:36.776347
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({'$ref': '#/definitions/Thing'}) == \
        Reference(to='#/definitions/Thing', definitions={})



# Generated at 2022-06-12 15:54:13.307903
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.base import acquire_object_lock

    acquire_object_lock()
    type_ = from_json_schema_type(
        data={
            "type": "string",
            "minLength": 3,
            "maxLength": 10,
            "format": "date-time",
            "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$",
            "default": "2019-02-10",
        },
        type_string="string",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )

# Generated at 2022-06-12 15:54:24.927894
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": "string",
        "default": None,
        "examples": [],
        "title": None,
        "description": None,
    }
    assert to_json_schema(Object(properties={"foo": String()})) == {
        "type": "object",
        "default": None,
        "examples": [],
        "title": None,
        "description": None,
        "properties": {"foo": {"type": "string", "default": None, "examples": [], "title": None, "description": None}},
    }, to_json_schema(Object(properties={"foo": String()}))

    class MySchema(Schema):
        foo = String()


# Generated at 2022-06-12 15:54:28.716276
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert from_json_schema(
        {"type": "string", "const": "foo"}, definitions=definitions
    ) == Const("foo")



# Generated at 2022-06-12 15:54:38.659897
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
        "description": None,
        "title": None,
        "examples": [],
    }

    assert to_json_schema(String(allow_blank=True)) == {
        "type": "string",
        "default": NO_DEFAULT,
        "description": None,
        "title": None,
        "examples": [],
    }

    assert to_json_schema(String(min_length=42)) == {
        "type": "string",
        "default": NO_DEFAULT,
        "description": None,
        "title": None,
        "examples": [],
        "minLength": 42,
    }

    assert to_json_schema

# Generated at 2022-06-12 15:54:49.018028
# Unit test for function to_json_schema
def test_to_json_schema():
    not_bool = Not(Boolean())
    assert to_json_schema(not_bool) == {
        "type": "boolean",
        "not": {
            "type": "boolean",
            "default": NO_DEFAULT,
            "const": False,
            "enum": [False],
            "exclusiveMinimum": False,
            "exclusiveMaximum": True,
            "multipleOf": 1,
            "minimum": False,
            "maximum": True,
        },
    }

    if_then_else = IfThenElse(
        if_clause=Boolean(),
        then_clause=String(),
        else_clause=not_bool,
        default=NO_DEFAULT,
    )

# Generated at 2022-06-12 15:54:55.902034
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "properties": {"a": {"const": 1}},
            "required": ["a"],
        },
        "then": {"type": "integer", "minimum": 10},
    }
    make = from_json_schema(data)
    make({"a": 1})
    make({"a": 2})  # TypeError



# Generated at 2022-06-12 15:55:04.987398
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {
            "type": "object",
            "properties": {
                "if_property": {"type": "boolean"}
            },
            "required": ["if_property"]
        },
        "then": {
            "type": "object",
            "properties": {
                "then_property": {"type": "string"}
            },
            "required": ["then_property"]
        },
        "else": {
            "type": "object",
            "properties": {
                "else_property": {"type": "integer"}
            },
            "required": ["else_property"]
        }
    }

    converted_schema = if_then_else_from_json_schema(schema, SchemaDefinitions())

# Generated at 2022-06-12 15:55:13.948671
# Unit test for function to_json_schema
def test_to_json_schema():

    text_schema = String()
    assert to_json_schema(text_schema) == {"type": "string"}

    integer_schema = Integer()
    assert to_json_schema(integer_schema) == {"type": "integer"}

    def recurse(schema: Field) -> None:
        assert schema == from_json_schema(to_json_schema(schema))


# Generated at 2022-06-12 15:55:20.094610
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(None) == {}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Noneable(String())) == {"type": ["string", "null"]}

# Generated at 2022-06-12 15:55:28.126964
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$id": "test_schema",
        "type": "object",
        "properties": {
            "field": {
                "type": "string",
                "if": {"type": "integer", "minimum": 1, "maximum": 3},
                "then": {"const": "value1"},
                "else": {"const": "value2"},
            }
        },
    }

# Generated at 2022-06-12 15:56:17.857922
# Unit test for function to_json_schema
def test_to_json_schema():
    type_string = "number"
    json_schema = to_json_schema(Float(allow_null=True))
    assert json_schema == {"type": ["number", "null"]}
    assert isinstance(from_json_schema(json_schema), Float)

    type_string = "number"
    json_schema = to_json_schema(Float(allow_null=True, default=42))
    assert json_schema == {"type": ["number", "null"], "default": 42}
    assert from_json_schema(json_schema) == 42

    type_string = "number"
    json_schema = to_json_schema(
        Float(allow_null=True, minimum=15, maximum=25, exclusive_minimum=False, exclusive_maximum=True)
    )


# Generated at 2022-06-12 15:56:25.539787
# Unit test for function to_json_schema
def test_to_json_schema():
    # Validate that we can convert a simple field to json schema
    field = String()

    # Make sure we can convert to json schema
    json_schema = to_json_schema(field)
    assert isinstance(json_schema, dict)
    assert json_schema["type"] == "string"

    # Make sure we can convert back from json schema
    field2 = from_json_schema(json_schema)
    assert isinstance(field2, String)

    # Make sure we get the same object back
    assert field == field2

    # Make sure a more complicated field works
    field = AllOf([Not(String()), Integer()], default=NO_DEFAULT)

    json_schema = to_json_schema(field)
    assert isinstance(json_schema, dict)
    # Make sure we

# Generated at 2022-06-12 15:56:37.603225
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    An automatically generated unit test for the input-based validator

    """

# Generated at 2022-06-12 15:56:46.408783
# Unit test for function from_json_schema
def test_from_json_schema():
    json_data = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "minLength": 1},
            "street": {"type": "string", "minLength": 1},
            "zip_code": {"type": "string", "minLength": 1},
            "city": {"type": "string", "minLength": 1},
            "country": {"type": "string", "minLength": 1},
        },
        "required": ["name", "street", "zip_code", "city", "country"],
    }

# Generated at 2022-06-12 15:56:57.967549
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        name = String(min_length=1)
        age = Integer(minimum=0)
        gender = Choice(choices=("male", "female"))
    schema = Person.make_validator()
    data = to_json_schema(schema)

    # PyCharm thinks that data cannot be None at this point. This is wrong,
    # because the to_json_schema function is recursive and can return None
    # in some cases. This is a bug in PyCharm. Ignore the false warning.
    assert data is not None

    definitions = data.get("definitions", None)
    assert definitions is not None
    assert definitions

# Generated at 2022-06-12 15:57:09.437566
# Unit test for function from_json_schema
def test_from_json_schema():  # TODO: adapt
    schema = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "object",
                "properties": {
                    "bar": {"type": "string", "minLength": 5, "maxLength": 10}
                }
            },
            "baz": {"type": "array", "items": {"type": "number"}},
        },
    }
    expected = Object(
        properties={
            "foo": Object(
                properties={
                    "bar": String(min_length=5, max_length=10)
                }
            ),
            "baz": Array(items=Integer()),
        }
    )
    assert from_json_schema(schema) == expected



# Generated at 2022-06-12 15:57:16.354875
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string in {
        "boolean",
        "integer",
        "number",
        "object",
        "string",
        "array",
    }:
        # Test basic types
        field = from_json_schema_type(
            data={"type": type_string},
            type_string=type_string,
            allow_null=False,
            definitions=None,
        )
        assert field.type == type_string

        # Test nullable
        field = from_json_schema_type(
            data={"type": [type_string, "null"]},
            type_string=type_string,
            allow_null=True,
            definitions=None,
        )
        assert field.type == type_string
        assert field.allow_null



# Generated at 2022-06-12 15:57:29.018750
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:57:36.886307
# Unit test for function to_json_schema
def test_to_json_schema():
    from .core import Field, Schema, Integer, Float, String

    class MySchema(Schema):
        foo = Integer()
        bar = Float()
        baz = String()

    schema = MySchema()
    assert to_json_schema(schema)

    expected = {
        "definitions": {
            "MySchema": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "foo": {"type": "integer"},
                    "bar": {"type": "number"},
                    "baz": {"type": "string"},
                },
                "required": ["foo", "bar", "baz"],
            }
        },
        "$ref": "#/definitions/MySchema",
    }
    assert to_json_schema(schema) == expected

# Generated at 2022-06-12 15:57:46.062754
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert if_then_else_from_json_schema({
        "if": {"type": "integer"},
        "then": {"type": "number"},
        "else": {"type": "string"},
        "default": None
    }) == IfThenElse(
        if_clause=Integer(),
        then_clause=Float(),
        else_clause=String(),
        default=None
    )


if __name__ == "__main__":  # pragma: no cover
    from pprint import pprint


# Generated at 2022-06-12 15:58:23.434470
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer", "minimum": 10}) == Integer(minimum=10)
    assert from_json_schema({"type": "number", "minimum": 10}) == Number(minimum=10)
    assert from_json_schema({"type": "string", "minLength": 10}) == String(min_length=10)
    assert from_json_schema({"type": "null"}) == Const(const=None)

    assert from_json_schema({"type": "integer", "const": 10}) == Integer(const=10)
    assert from_json_schema({"type": "number", "const": 10}) == Number(const=10)

# Generated at 2022-06-12 15:58:33.804641
# Unit test for function to_json_schema
def test_to_json_schema():

    schema = Schema(title="My Schema", description="This is my schema")

    @schema.define
    class Person:
        name: str
        age: IntRange(17, 121)
        address: Address = None

    @schema.define
    class Address:
        street: str
        city: str
        country: str = "United States"

    json_schema = to_json_schema(schema)


# Generated at 2022-06-12 15:58:43.741177
# Unit test for function to_json_schema
def test_to_json_schema():
    generated = (
        to_json_schema(Integer, _definitions={"Integer": Integer})
        == to_json_schema(Integer)
    )
    assert generated

    class InnerSchema(Schema):
        value = Integer()

    class OuterSchema(Schema):
        inner_object = Object(properties={"value": InnerSchema()})

    generated = (
        to_json_schema(OuterSchema.inner_object, _definitions={"InnerSchema": InnerSchema})
        == to_json_schema(OuterSchema.inner_object)
    )
    assert generated

    generated = sorted(to_json_schema(OuterSchema.inner_object)["definitions"].keys())

# Generated at 2022-06-12 15:58:52.351279
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "integer",
        "minimum": 4,
        "maximum": 8,
        "exclusiveMinimum": True,
        "exclusiveMaximum": True,
        "multipleOf": 2,
    }
    expected = Integer(
        minimum=4,
        maximum=8,
        exclusive_minimum=True,
        exclusive_maximum=True,
        multiple_of=2,
    )
    actual = from_json_schema_type(data, type_string="integer", allow_null=False, definitions=None)
    assert expected == actual

    data = {
        "type": None,
        "minimum": 4,
        "maximum": 8,
        "exclusiveMinimum": True,
        "exclusiveMaximum": True,
        "multipleOf": 2,
    }
    actual = from_json_schema_

# Generated at 2022-06-12 15:58:54.990874
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:59:06.408400
# Unit test for function to_json_schema
def test_to_json_schema():
    import datetime
    import ipaddress
    from dateutil.tz import tzutc
    from decimal import Decimal
    from typing import List

    class Address(Schema):
        house_name_or_number = String(max_length=10)
        street = String(max_length=30)
        city = String(max_length=30)
        county = String(max_length=30, allow_null=True)
        postcode = String(max_length=8, allow_blank=False, min_length=6)

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=110)
        height = Float(exclusive_minimum=0, exclusive_maximum=3)
        weight = Decimal(minimum=0, exclusive_maximum=500)

# Generated at 2022-06-12 15:59:10.406735
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    valid_data = {'if': {'type': 'integer'}, 'then': {'type': 'integer'}}
    valid_document = 42
    invalid_documents = [{}, [], None]
    if_then_schema = if_then_else_from_json_schema(valid_data, schema_definitions)
    for invalid_document in invalid_documents:
        with pytest.raises(InvalidDocumentError):
            if_then_schema.validate(invalid_document)
    assert if_then_schema.validate(valid_document) is None



# Generated at 2022-06-12 15:59:19.602951
# Unit test for function to_json_schema
def test_to_json_schema():
    from .schema import from_json_schema
    from .validators import String, Integer, Boolean, Array, Object, Reference, Choice

    class BookSchemaDefinitions(SchemaDefinitions):
        author = Reference("Author")
        author_id = Reference("Author")
        book = Object(properties={"title": String(), "author_id": author_id})
        book_authors = Object(properties={"title": String(), "author": author})

    book_schema = BookSchemaDefinitions()
    data = to_json_schema(book_schema)

# Generated at 2022-06-12 15:59:29.348587
# Unit test for function to_json_schema
def test_to_json_schema():
    data: dict = to_json_schema(AllSchema())

# Generated at 2022-06-12 15:59:39.053927
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer"
    }

    assert to_json_schema(String()) == {
        "type": "string"
    }

    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"]
    }

    assert to_json_schema(Not(String())) == {
        "not": {"type": "string"}
    }

    assert to_json_schema(String(default="x")) == {
        "type": "string",
        "default": "x",
    }

    assert to_json_schema(String(default=NO_DEFAULT)) == {
        "type": "string"
    }
