

# Generated at 2022-06-12 15:51:25.784754
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    Test the IfThenElse field constructor.
    """
    pkg = __import__(__name__)


# Generated at 2022-06-12 15:51:35.952755
# Unit test for function from_json_schema
def test_from_json_schema():
    # pylint: disable=too-many-branches
    assert from_json_schema(None) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({}) == Any()

    field = from_json_schema({"type": "string"})
    assert isinstance(field, String)

    field = from_json_schema({"type": "integer"})
    assert isinstance(field, Integer)

    field = from_json_schema({"type": "number"})
    assert isinstance(field, Number)

    field = from_json_schema({"type": "boolean"})
    assert isinstance(field, Boolean)


# Generated at 2022-06-12 15:51:39.299258
# Unit test for function from_json_schema
def test_from_json_schema():
    typesystem = from_json_schema(
        {
            "type": "string",
            "enum": ["X", "Y", "Z"],
            "minLength": 10,
            "maxLength": 15,
        }
    )
    assert typesystem == String(min_length=10, max_length=15, enum=["X", "Y", "Z"])



# Generated at 2022-06-12 15:51:42.708724
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/my_definition"}), Reference)



# Generated at 2022-06-12 15:51:53.549258
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "foo": {
                "anyOf": [
                    {
                        "properties": {
                            "this": {"type": "string", "enum": ["that"]},
                            "those": {"type": "string", "enum": ["these"]},
                        }
                    }
                ]
            }
        },
    }

    typesystem_schema = from_json_schema(schema)
    assert typesystem_schema({"foo": {"this": "that"}}) == {"foo": {"this": "that"}}
    assert typesystem_schema({"foo": {"those": "these"}}) == {"foo": {"those": "these"}}



# Generated at 2022-06-12 15:52:02.888216
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Constraint(lambda x: x % 2 == 0, error="Even"),
        then_clause=Integer(),
        else_clause=String(),
    ) == if_then_else_from_json_schema(
        {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "if": {
                "type": "integer",
                "multipleOf": 2,
                "error": "Even",
            },
            "then": {"type": "integer"},
            "else": {"type": "string"},
        }
    )


# Generated at 2022-06-12 15:52:07.739047
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, String)

    data = {"type": ["string", "number"]}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, Union)



# Generated at 2022-06-12 15:52:19.296814
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": '#/definitions/StringNumber',
        "definitions": {
            "StringNumber": {
                "oneOf": [
                    {"type": "string"},
                    {"type": "number"},
                ]
            }
        }
    }
    field = from_json_schema(schema)
    assert field.validate("hello") is None
    assert field.validate("") is None
    assert field.validate("    ") is None
    assert field.validate("-0.0") is None
    assert field.validate(0.0) is None
    assert field.validate(2.2) is None
    assert field.validate(-2.2) is None
    assert field.validate(3) is None
    assert field.validate(-3) is None


# Generated at 2022-06-12 15:52:21.647500
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "number"}, {"type": "string"}]}
    field = any_of_from_json_schema(data, definitions=None)
    assert isinstance(field, Union)



# Generated at 2022-06-12 15:52:25.331514
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_definitions = SchemaDefinitions()
    schema_definitions["#/definitions/MyType"] = Integer()
    assert ref_from_json_schema({"$ref": "#/definitions/MyType"}, definitions=schema_definitions) == Integer()



# Generated at 2022-06-12 15:53:13.718061
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "Foo", "default": None}
    const_field = const_from_json_schema(data, None)
    assert const_field.validate("Foo") == True, "Ensure the data is valid"
    assert const_field.validate("") == False, "Ensure the data is invalid"


# Generated at 2022-06-12 15:53:19.452901
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    with pytest.raises(TypeError):
        IfThenElse()
    with pytest.raises(TypeError):
        IfThenElse(if_clause=field.String())
    with pytest.raises(TypeError):
        IfThenElse(then_clause=field.String())



# Generated at 2022-06-12 15:53:27.830371
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:53:35.746966
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "if": {"type": "string"},
        "then": {"type": "integer", "maximum": 3},
        "else": {"type": "integer", "maximum": 10},
    }

    json_schema_if_then = {
        "if": {"type": "string"},
        "then": {"type": "integer", "maximum": 3},
    }

    json_schema_if_else = {
        "if": {"type": "string"},
        "else": {"type": "integer", "maximum": 10},
    }

    json_schema_then = {"then": {"type": "integer", "maximum": 3}}

    json_schema_else = {"else": {"type": "integer", "maximum": 10}}

    json_schema_empty = {}

    field = if_

# Generated at 2022-06-12 15:53:39.417088
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "string"}}
    assert not_from_json_schema(data, {}) == Not(negated=String())



# Generated at 2022-06-12 15:53:44.294949
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    x = {
        '$schema': 'http://json-schema.org/draft-07/schema#',
        '$ref': '#/definitions/Person',
        'definitions': {
            'Person': {
                'if': {'properties': {'age': {'minimum': 18}}},
                'then': {'properties': {'socialSecurityNumber': {'type': 'string'}}},
                'else': {'properties': {'childID': {'type': 'string'}}},
                'type': 'object',
                'properties': {
                    'age': {'type': 'integer'}, 'name': {'type': 'string'}
                }
            }
        }
    }
    y = from_json_schema(x)

# Generated at 2022-06-12 15:53:50.820413
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
# This test checks if the function all_of_from_json_schema takes into account 
# the default value
    data = {
        "allOf": [{
            'type': 'integer',
            'minimum': 2,
            'maximum': 8,
            'default': 5
        }],
        'default': 2
    }
    definitions = SchemaDefinitions()
    all_of_from_json_schema(data, definitions)
    assert definitions.get_schema(data['allOf'][0]) == definitions.get_schema(data)
    assert definitions.get_schema(data['allOf'][0]).default == 5
    assert definitions.get_schema(data).default == 2


# Generated at 2022-06-12 15:53:56.037428
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    result = all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 1}]}, None)
    assert result.validate("hello") == "hello"
    assert result.validate("") is False
    assert result.validate(None) is False


# Generated at 2022-06-12 15:53:59.149127
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {"allOf": [{"type": "integer"}, {"minimum": 1, "maximum": 10}]}
    assert from_json_schema(schema).validate(5) == 5



# Generated at 2022-06-12 15:54:06.853542
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string, allow_null, minimum, maximum in [
        ("string", False, None, None),
        ("integer", True, 0, 100),
        ("boolean", False, None, None),
        ("number", False, None, None),
        ("array", True, 1, None),
        ("object", False, None, None),
    ]:
        schema = {"type": type_string}
        if allow_null:
            schema["type"] = ["null", type_string]
        if minimum is not None:
            schema["minimum"] = minimum
        if maximum is not None:
            schema["maximum"] = maximum
        field = from_json_schema(schema)

        assert field.types == [type_string]
        assert field.allow_null == allow_null
        assert field.minimum == minimum

# Generated at 2022-06-12 15:54:27.868681
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "number"}) == Number()
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "null"}) == Const(None)
    assert (
        type_from_json_schema({"type": "array", "items": {"type": "integer"}})
        == Array(items=Integer())
    )

# Generated at 2022-06-12 15:54:32.188982
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    Write your unit test for function if_then_else_from_json_schema
    """
    json_data = {
        "if": {
            "$ref": "#/definitions/test"
        },
        "then": {
            "$ref": "#/definitions/test"
        },
        "default": {
            "$ref": "#/definitions/test"
        }
    }
    definitions = {
        "test": {
            "type": "integer"
        }
    }
    data = if_then_else_from_json_schema(json_data, definitions)
    assert isinstance(data, IfThenElse)
    data = data.validate("123")
    assert data == "123"
    data = data.validate("abc")
    assert data == "123"
    data

# Generated at 2022-06-12 15:54:39.989673
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    def _test(data, type_string, allow_null, expected):
        assert from_json_schema_type(data, type_string, allow_null, definitions).as_json_schema() == expected
    definitions = SchemaDefinitions()
    _test(
        {
            "exclusiveMinimum": 0,
            "minimum": 1,
            "type": "integer",
        },
        "integer",
        True,
        {
            "type": "integer",
            "minimum": 1,
            "exclusiveMinimum": 0,
        },
    )
    _test(
        {
            "type": "boolean",
        },
        "boolean",
        True,
        {
            "type": "boolean",
        },
    )

# Generated at 2022-06-12 15:54:49.814003
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:55:02.009892
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}

    assert to_json_schema(String(allow_null=True, min_length=0)) == {
        "type": ["string", "null"],
        "minLength": 0,
    }
    assert to_json_schema(String(allow_null=True, max_length=0)) == {
        "type": ["string", "null"],
        "maxLength": 0,
    }

# Generated at 2022-06-12 15:55:07.820876
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "string",
        "maxLength": 2,
        "default": '"a"'
    }
    obj = from_json_schema_type(data, "string", False, definitions=None)
    assert str(obj) == '(String(allow_null=False, allow_blank=True, min_length=1, max_length=2, ' \
                      'default="a", pattern=None, format=None))'



# Generated at 2022-06-12 15:55:17.368565
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:55:26.264300
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({'type': 'string'}).to_primitive() == {'type': 'string'}
    assert type_from_json_schema({'type': 'null'}).to_primitive() == {'type': 'null'}
    assert type_from_json_schema({'type': 'string', 'format': 'email'}).to_primitive() == {
        'type': 'string',
        'format': 'email'
    }
    assert type_from_json_schema( {'type': 'object'}).to_primitive() == {'type': 'object'}

# Generated at 2022-06-12 15:55:37.268054
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, None) == Integer(None, None)
    base_schema = {"type": "number"}
    assert type_from_json_schema(base_schema, None) == Number(None, None)
    base_schema["minimum"] = 5
    assert type_from_json_schema(base_schema, None) == Number(minimum=5, maximum=None)
    base_schema["maximum"] = 5
    assert type_from_json_schema(base_schema, None) == Number(minimum=5, maximum=5)
    base_schema["exclusiveMinimum"] = True
    assert type_from_json_schema(base_schema, None) == Number(
        minimum=5, maximum=5, exclusive_minimum=True
    )

# Generated at 2022-06-12 15:55:41.868817
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "object", "patternProperties": {"^a": {"type": "string"}}, "patternProperties": {"^c": {"type": "integer"}}}
    result = from_json_schema_type(data, type_string="object", allow_null=False, definitions=None)
    assert isinstance(result, Object)



# Generated at 2022-06-12 15:56:04.634792
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(bool(True)) == Any()
    assert from_json_schema(bool(False)) == NeverMatch()
    assert from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")

# Generated at 2022-06-12 15:56:16.406094
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": ["string", "null"]}) == String() | None
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"enum": ["A", "B"]}) == Choice(choices=["A", "B"])
    assert from_json_schema({"const": "A"}) == Const(const="A")

# Generated at 2022-06-12 15:56:24.055485
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
        assert from_json_schema_type({}, type_string='number') == Any()
        assert from_json_schema_type({}, type_string='integer') == Any()
        assert from_json_schema_type({}, type_string='string') == Any()
        assert from_json_schema_type({}, type_string='boolean') == Any()
        assert from_json_schema_type({}, type_string='array') == Any()
        assert from_json_schema_type({}, type_string='object') == Any()
        assert from_json_schema_type({}, type_string='never-match') == Any()
        assert from_json_schema_type({'default': 'I am a default value'}, type_string='number') == Any()
        assert from_json_schema_type

# Generated at 2022-06-12 15:56:29.794144
# Unit test for function from_json_schema
def test_from_json_schema():
    definitions = SchemaDefinitions()
    with open("tests/examples/json_schema.json", "r") as f:
        json_schema = json.load(f)
    field = from_json_schema(json_schema, definitions=definitions)
    assert field.validate({"property": "value"}) == {"property": "value"}



# Generated at 2022-06-12 15:56:35.805499
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {
        "type": "array",
        "items": {"type": "string"},
        "additionalItems": False,
        "minItems": 0,
        "maxItems": None,
        "uniqueItems": False,
        "default": NO_DEFAULT,
    }
    from_json_schema_type(schema, type_string="array", allow_null=False, definitions=None)



# Generated at 2022-06-12 15:56:45.324424
# Unit test for function to_json_schema
def test_to_json_schema():
    def _assert_roundtrip(arg) -> None:
        # roundtrip arguments using json encoder/decoder
        result = to_json_schema(arg)
        data = ujson.dumps(result, option=ujson.OPT_COMMENTS)
        data = ujson.loads(data)
        arg_2 = from_json_schema(data)
        result_2 = to_json_schema(arg_2)
        assert result == result_2

    _assert_roundtrip(Integer(maximum=10))
    _assert_roundtrip(Integer(multiple_of=2))
    _assert_roundtrip(Integer(minimum=2))
    _assert_roundtrip(Integer(minimum=2, maximum=10))
    _assert_roundtrip(Integer(allow_null=True))

# Generated at 2022-06-12 15:56:57.378442
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:57:03.521704
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer", "minimum": 1, "maximum": 2}) == Integer(minimum=1, maximum=2)
    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(minimum=1)
    assert from_json_schema({"type": "integer", "maximum": 2}) == Integer(maximum=2)
    assert from_json_schema({"type": "integer"}) == Integer()

    assert from_json_schema({"enum": [1, 2]}) == Choice([1, 2])
    assert from_json_schema({"enum": [1, 2], "type": "integer", "minimum": 1}) == Choice([1, 2])

# Generated at 2022-06-12 15:57:08.300153
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": [
            "string",
            "null",
        ],
        "format": "email",
        "nullable": True,
        "title": "Email",
        "default": "test@test.com",
        "readOnly": True,
    }
    field = from_json_schema_type(data, type_string="string", allow_null=True)
    assert isinstance(field, String)
    assert field.allow_null is True
    assert field.allow_blank is False
    assert field.min_length == 1
    assert field.max_length is None
    assert field.format == "email"


# Generated at 2022-06-12 15:57:17.854602
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:57:42.040902
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, {}) == Float()
    assert from_json_schema_type({}, "integer", False, {}) == Integer()
    assert from_json_schema_type({}, "string", False, {}) == String()
    assert from_json_schema_type({}, "boolean", False, {}) == Boolean()
    assert from_json_schema_type({}, "array", False, {}) == Array()
    assert from_json_schema_type({}, "object", False, {}) == Object()



# Generated at 2022-06-12 15:57:52.372696
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "object",
        "properties": {
            "array_field": {"type": "array", "items": {"type": "number"}},
            "string_field": {"type": "string", "minLength": 0},
            "number_field": {
                "type": "number",
                "minimum": 0,
                "maximum": 10,
                "multipleOf": 2,
                "default": 0,
            },
            "integer_field": {"type": "integer", "maximum": 100, "default": 0},
            "boolean_field": {"type": "boolean"},
            "null_field": {"type": "null"},
        },
    }
    schema = from_json_schema(data)
    assert schema is not None

# Generated at 2022-06-12 15:58:02.777978
# Unit test for function to_json_schema
def test_to_json_schema():
    try:
        field = String(allow_blank=False).make_validator()
        to_json_schema(field)
    except ValueError:
        pass
    else:
        assert False, "Did not reject conversion of field with modified "
        "allow_blank behavior"

    field = String(format="date")
    data = to_json_schema(field)
    assert data == {
        "type": "string",
        "format": "date",
    }

    field = OneOf(
        Integer(minimum=1, maximum=10),
        Integer(minimum=11, maximum=20),
    )
    data = to_json_schema(field)

# Generated at 2022-06-12 15:58:03.498231
# Unit test for function to_json_schema
def test_to_json_schema():
    pass

# Generated at 2022-06-12 15:58:13.561766
# Unit test for function to_json_schema
def test_to_json_schema():

    TEST_SCHEMAS = {
        "SingleFieldSchema": Schema(StringField(format="uri")),
        "NestedFieldSchema": Schema(
            ObjectField(
                properties={
                    "name": StringField(),
                    "birthday": IntegerField(
                        description="An integer value with a description"
                    ),
                }
            )
        ),
    }


# Generated at 2022-06-12 15:58:23.049648
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.constraints import Minimum, MultipleOf
    from typesystem.fields import Boolean, Field, Number, String
    from typesystem.schemas import Reference

    schema_definitions = SchemaDefinitions()
    schema_definitions["def"] = Reference("#/definitions/other_def")
    schema_definitions["other_def"] = Boolean()

    assert from_json_schema(
        {"type": "integer", "minimum": 1, "multipleOf": 3},
        definitions=schema_definitions,
    ) == Integer(
        minimum=1, multiple_of=3,
    )

    assert from_json_schema(
        {"$ref": "#/definitions/def"}, definitions=schema_definitions
    ) == Boolean()



# Generated at 2022-06-12 15:58:33.548178
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:58:39.791825
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    test = {
        "type": "string",
        "minLength": 2,
        "maxLength": 10,
        "pattern": "^[a-zA-Z]*$",
    }
    field = type_from_json_schema(test, definitions={})
    assert field.__class__ == String
    assert field.min_length == 2
    assert field.max_length == 10
    assert field.pattern == r"^[a-zA-Z]*$"



# Generated at 2022-06-12 15:58:44.442346
# Unit test for function to_json_schema
def test_to_json_schema():
    field = AllOf(
        all_of=[
            Integer(minimum=1, maximum=2, allow_null=True),
            Const(const=1, allow_null=True, default=1),
            Not(negated=Boolean(default=True), default=True),
            OneOf(
                one_of=[
                    Const(const=True, allow_null=True),
                    Const(const=False, allow_null=True),
                    Const(const=None, allow_null=True),
                ],
                default=True,
            ),
        ],
        allow_null=True,
        default=True,
    )

# Generated at 2022-06-12 15:58:52.976926
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": ["integer", "null"],
        "minimum": 1,
        "exclusiveMinimum": True,
        "maximum": 10,
        "exclusiveMaximum": True,
        "multipleOf": 2,
    }
    field = type_from_json_schema(data=data, definitions=SchemaDefinitions())
    required_field = from_json_schema_type(
        data=data, type_string="integer", allow_null=False, definitions=SchemaDefinitions()
    )
    assert isinstance(field, Union)
    assert len(field.any_of) == 2
    assert required_field in field.any_of
    assert isinstance(field.any_of[1], Const)
    assert field.any_of[1].value is None
    assert field.allow_null

# Generated at 2022-06-12 15:59:18.931895
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Tests expected schema generation from known JSON schema objects.
    """
    # Any
    assert Any(allow_null=True) == from_json_schema({"type": "null"})
    assert Any(allow_null=True) == from_json_schema({"type": ["null", "number"]})
    assert Any() == from_json_schema({"type": ["number", "boolean"]})

    # Never
    assert NeverMatch(allow_null=True) == from_json_schema({"type": "boolean"})
    assert NeverMatch() == from_json_schema({"type": "null"})

    # Number
    assert Number() == from_json_schema({"type": "number"})

# Generated at 2022-06-12 15:59:28.913062
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=False), Number)
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=True), Number)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False), Integer)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=True), Integer)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=True), String)

# Generated at 2022-06-12 15:59:38.923819
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:59:51.461474
# Unit test for function to_json_schema
def test_to_json_schema():
    value1 = String.make_validator(format="date-time")
    value2 = String.make_validator(format="email")
    try:
        value3 = String.make_validator(format="abc")
    except ValueError:
        pass
    value4 = Choice.make_validator(choices=[("one", "one"), ("two", "two")])
    value5 = Array.make_validator(
        min_items=2, max_items=3, items=Integer.make_validator(minimum=0)
    )

# Generated at 2022-06-12 15:59:58.595770
# Unit test for function to_json_schema
def test_to_json_schema():
    from flex.utils.testing import json_round_trip

    @json_round_trip
    class StringSchema(Schema):
        text = String()

    @json_round_trip
    class IntegerSchema(Schema):
        number = Integer()

    @json_round_trip
    class FloatSchema(Schema):
        number = Float()

    @json_round_trip
    class DecimalSchema(Schema):
        number = Decimal()

    @json_round_trip
    class BooleanSchema(Schema):
        flag = Boolean()

    @json_round_trip
    class ArraySchema(Schema):
        array = Array()

    @json_round_trip
    class ObjectSchema(Schema):
        object = Object()


# Generated at 2022-06-12 16:00:03.761445
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({
        "type": "string",
        "minLength": 0,
        "maxLength": 100,
        "pattern": "^[a-z]{2}$",
    },
       type_string="string",
       allow_null=False,
       definitions=None,
    ) == String(allow_null=False, min_length=0, max_length=100, pattern="^[a-z]{2}$")



# Generated at 2022-06-12 16:00:13.384336
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import from_json_schema
    from typesystem.schemas import Reference
    from typesystem.composites import Union, Not

    assert isinstance(from_json_schema({"type": "number"}), Float)
    assert isinstance(from_json_schema({"type": "integer"}), Integer)
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": "boolean"}), Boolean)
    assert isinstance(from_json_schema({"type": "array"}), Array)
    assert isinstance(from_json_schema({"type": "object"}), Object)
    assert isinstance(from_json_schema({"type": "null"}), Const)