

# Generated at 2022-06-12 15:52:02.632262
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # This is required because mypy doesn't support dynamic keyword arguments like
    # IfThenElse(**kwargs).
    IfThenElse(**{"if_clause": None, "then_clause": None, "else_clause": None})
    IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    IfThenElse(if_clause=None, then_clause=None)
    IfThenElse(if_clause=None, else_clause=None)
    IfThenElse(**{"if_clause": None, "then_clause": None, "else_clause": None, "default": {"const": 1}})
    IfThenElse(if_clause=None, then_clause=None, else_clause=None, default={"const": 1})


# Generated at 2022-06-12 15:52:08.805206
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    (
        if_clause,
        then_clause,
        else_clause,
        default_,
    ) = if_then_else_from_json_schema({"if": {"type": "string"}, "then": {"type": "integer"}})._if_then_else_args
    assert if_clause.field_type == String
    assert then_clause.field_type == Integer
    assert else_clause is None
    assert default_ is NO_DEFAULT

# Generated at 2022-06-12 15:52:15.860776
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "string"},
        "then": {"minLength": 2},
        "else": {"type": "boolean"},
    }
    converted = if_then_else_from_json_schema(data=schema)
    json_equivalent = if_then_else_to_json_schema(converted)
    assert json_equivalent == schema


# Unit tests for functions get_valid_types and type_from_json_schema

# Generated at 2022-06-12 15:52:24.626507
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = Integer(minimum=0)
    then_clause = Integer(minimum=1)
    else_clause = Integer(minimum=2)
    if_then_else = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert if_then_else == if_then_else_from_json_schema(
        {"if": {"type": "integer", "minimum": 0}, "then": {"type": "integer", "minimum": 1}, "else": {"type": "integer", "minimum": 2}},
        definitions=SchemaDefinitions()
    )



# Generated at 2022-06-12 15:52:30.880963
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:52:37.933955
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    validation = String(min_length=1, pattern_regex=re.compile("foo"))
    assert to_json_schema(validation) == {
        "type": "string",
        "minLength": 1,
        "pattern": "foo",
    }



# Generated at 2022-06-12 15:52:45.337860
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [{"type": "string"}, {"type": "integer"}]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    to_python = field.to_python
    assert to_python("1") == "1"
    assert to_python(1) == "1"
    assert to_python(2.0) == "2.0"
    assert to_python(u"1") == u"1"
    assert isinstance(to_python(None), types.Undefined)
    assert to_python(None).undefined is None


# Generated at 2022-06-12 15:52:51.402167
# Unit test for function to_json_schema
def test_to_json_schema():
    from .model import Schema

    from .validations import is_alphanumeric_or_space
    from .fields import Integer, Float, Decimal, Boolean, String, Array, Object
    from .fields import Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference

    class SimpleSchema(Schema):
        field_int = Integer(validator=is_alphanumeric_or_space)
        field_float = Float(validator=is_alphanumeric_or_space)
        field_decimal = Decimal(validator=is_alphanumeric_or_space, precision=5)
        field_bool = Boolean(validator=is_alphanumeric_or_space)
        field_string = String(validator=is_alphanumeric_or_space)

# Generated at 2022-06-12 15:52:58.740816
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "$ref": "#/definitions/Person",
        "definitions": {
            "Person": {
                "type": "object",
                "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
            }
        },
    }
    field = from_json_schema(json_schema)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/Person"
    assert isinstance(field.get_definition(), Object)



# Generated at 2022-06-12 15:53:03.997938
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    f = from_json_schema_type({}, type_string="string", allow_null=False, definitions={})
    assert isinstance(f, String)
    assert f.allow_null == False
    assert f.min_length == 0
    assert f.default is None


# Generated at 2022-06-12 15:53:44.195095
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "number"}
        ]
    }
    field = from_json_schema(schema)

    assert field.validate(0) is None
    assert field.validate(1.1) is None
    assert field.validate("foo") is None

    assert len(field.validate([])) > 0



# Generated at 2022-06-12 15:53:46.446863
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'integer'},{'type':'string'}]})


# Generated at 2022-06-12 15:53:52.725711
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema(
        {"enum": [True, False], "default": None}, None
    ).validate(True)
    assert enum_from_json_schema(
        {"enum": [True, False], "default": None}, None
    ).validate(False)
    assert enum_from_json_schema(
        {"enum": [True, False], "default": None}, None
    ).validate(None)
    assert not enum_from_json_schema(
        {"enum": [True, False], "default": None}, None
    ).validate(1)
    assert not enum_from_json_schema(
        {"enum": [True, False], "default": None}, None
    ).validate("1")

# Generated at 2022-06-12 15:54:00.216385
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # pylint:disable=too-many-arguments
    json_schema_type_field_class_mapping = {
        "object": Object,
        "string": String,
        "number": Number,
        "integer": Integer,
        "float": Float,
        "decimal": Decimal,
        "boolean": Boolean,
        "const": Const,
        "enum": Choice,
        "array": Array,
        "any": Any,
    }
    json_schema = {"type": ["integer"]}
    assert type_from_json_schema(json_schema) == json_schema_type_field_class_mapping[
        "integer"
    ]()
    json_schema = {"type": ["integer"], "minimum": 1}

# Generated at 2022-06-12 15:54:09.311912
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = [{"type": String()}, {"type": String()}]
    assert any_of_from_json_schema(data, definitions = None).type == "typesystem.union" # tests whether or not it returns a Union
    assert len(any_of_from_json_schema(data, definitions = None).any_of) == 2
    assert any_of_from_json_schema(data, definitions = None).any_of[0].type == "typesystem.string"
    assert any_of_from_json_schema(data, definitions = None).any_of[1].type == "typesystem.string"
    return True
test_any_of_from_json_schema()


# Generated at 2022-06-12 15:54:16.870176
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    values = [
        ({"allOf": [{"type": "string"}, {"type": "integer"}]}, True),
        ({"allOf": [{"type": "integer"}, {"type": "number"}]}, True),
        ({"allOf": [{"type": "number"}, {"type": "integer"}]}, False),
        ({"allOf": [{"type": "integer"}, {"type": "integer", "maximum": 0}]}, True),
        ({"allOf": [{"type": "string"}, {"type": "integer", "maximum": 0}]}, False),
    ]
    for data, is_valid in values:
        all_of = all_of_from_json_schema(data, SchemaDefinitions())
        assert is_valid == all_of.validate("")


# Generated at 2022-06-12 15:54:23.183523
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'not': {'enum': [1, 2, 3]}, 'default': 4}
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.default == 4
    assert field.validate(4)
    assert not field.validate(1)
    assert not field.validate(2)
    assert not field.validate(3)


# Generated at 2022-06-12 15:54:30.900921
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from typesystem import Array, Integer, String
    from typesystem.fields import Any
    from typesystem.schemas import SchemaDefinitions
    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema
    
    schema = {'anyOf': [{'type': 'null'}, {'type': 'string'}]}
    result = any_of_from_json_schema(schema,definitions)

# Generated at 2022-06-12 15:54:37.688038
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_data = {
        "enum": ["red", "amber", "green"]
    }
    field = enum_from_json_schema(data=json_data,definitions=SchemaDefinitions())
    assert field.validate_choice('red') == 'red'
    assert field.validate_choice('amber') == 'amber'
    assert field.validate_choice('green') == 'green'
    assert field.validate_choice('blue') == 'Invalid Choice'
    

# Generated at 2022-06-12 15:54:40.344637
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from_json_schema(
        {
            "if": {"type": "string"},
            "then": {"minLength": 5, "default": "foo"},
            "else": {"default": "bar"},
        }
    ) # Passed, if in the future fails, check if the type hint was right.


# Generated at 2022-06-12 15:55:18.796179
# Unit test for function to_json_schema
def test_to_json_schema():
    arg = to_json_schema(
        Any()
    )
    assert arg is True

    arg = to_json_schema(
        NeverMatch()
    )
    assert arg is False

    arg = to_json_schema(
        IfThenElse(
            if_clause=Choice(
                [
                    ("a", "a"),
                    ("b", "b"),
                ]
            ),
            then_clause=Integer(max_value=7),
            else_clause=Integer(min_value=7),
            default=10,
        )
    )

# Generated at 2022-06-12 15:55:27.330851
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any())
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(const=42)) == {
        "type": "integer",
        "const": 42,
    }
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Integer(default=42)) == {
        "type": "integer",
        "default": 42,
    }
    assert to_json_schema(Integer(minimum=10, maximum=42)) == {
        "type": "integer",
        "minimum": 10,
        "maximum": 42,
    }
    assert to_json

# Generated at 2022-06-12 15:55:38.267312
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Unit test for function 'from_json_schema'.
    """
    import json
    import os

    import typesystem

    def _test_json_schema(
        json_schema: typing.Union[bool, dict],
        definitions: typing.Dict[str, typing.Any] = None,
    ) -> None:
        if definitions is None:
            definitions = {}
        schema = from_json_schema(json_schema, definitions=definitions)
        assert schema is not None
        # Check that the field can be instantiated successfully
        assert isinstance(schema, Field)
        assert isinstance(schema.to_dict(), dict)
        schema = from_json_schema(schema.to_dict(), definitions=definitions)
        assert schema is not None
        # Check that the field can be

# Generated at 2022-06-12 15:55:47.814309
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:55:51.368162
# Unit test for function to_json_schema
def test_to_json_schema():
    import rf_api_client.schemas.definitions.some_example_schema as some_example_schema
    definitions_to_json_schema = to_json_schema(some_example_schema.definitions)
    assert isinstance(definitions_to_json_schema, dict)
    assert "definitions" in definitions_to_json_schema
test_to_json_schema()


# Generated at 2022-06-12 15:55:55.812382
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const = const_from_json_schema({"const": 1}, None)
    assert const == Const(const=1, default=NO_DEFAULT)



# Generated at 2022-06-12 15:55:58.757072
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 2, 'default': 3}).const == 2
    assert const_from_json_schema({'const': 2}).const == 2
    
    

# Generated at 2022-06-12 15:56:03.376805
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Function from_json_schema() converts from JSON Schema to a typesystem Field.
    """
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "integer"}) == Integer()



# Generated at 2022-06-12 15:56:05.750990
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    result = const_from_json_schema(data={"const": "a"}, definitions=definitions)
    assert result.validate("a") == "a"
    assert not result.validate("b")


# Generated at 2022-06-12 15:56:18.062526
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(Reference(to="123")) == {"$ref": "#/definitions/123"}

    assert to_json_schema(String()) == {"type": ["string", "null"], "default": None}

    schema = Object(properties={})
    assert to_json_schema(schema) == {"type": ["object", "null"], "default": None}

    schema = Integer(minimum=3, allow_null=False)

# Generated at 2022-06-12 15:56:59.537746
# Unit test for function to_json_schema
def test_to_json_schema():
    from django_stachoutils.fields import DjangoField, CharField, IntegerField

    simple = CharField(max_length=100, required=True)
    simple_data = {
        "type": "string",
        "maxLength": 100,
        "required": True,
    }
    assert to_json_schema(simple) == simple_data

    ref = DjangoField(field=CharField(max_length=100, required=True))
    ref_data = {
        "type": "string",
        "maxLength": 100,
        "required": True,
    }
    assert to_json_schema(ref) == ref_data

    definitions = DjangoField(field=CharField(max_length=100, required=True))

# Generated at 2022-06-12 15:57:05.271588
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
    }

    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["integer", "null"],
        "default": NO_DEFAULT,
    }

    assert to_json_schema(Integer(minimum=0)) == {
        "type": "integer",
        "minimum": 0,
        "default": NO_DEFAULT,
    }

    assert to_json_schema(Integer(maximum=10)) == {
        "type": "integer",
        "maximum": 10,
        "default": NO_DEFAULT,
    }


# Generated at 2022-06-12 15:57:13.688497
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = from_json_schema(
        {
            "$ref": "#/definitions/first-name",
            "const": "x",
            "enum": ["x"],
            "type": "string",
            "pattern": "^[a-zA-Z]+$",
            "format": "date-time",
            "minLength": 2,
            "maxLength": 25,
            "definitions": {
                "first-name": {
                    "type": "string",
                    "pattern": "^[a-zA-Z]+$",
                    "format": "date-time",
                    "minLength": 2,
                    "maxLength": 25,
                }
            },
        }
    )

# Generated at 2022-06-12 15:57:27.176198
# Unit test for function to_json_schema
def test_to_json_schema():
    from .tests.schema import Person

    SCHEMA = to_json_schema(Person)
    assert SCHEMA["$schema"] == "http://json-schema.org/draft-07/schema#", SCHEMA
    assert SCHEMA["title"] == "Person"
    assert SCHEMA["type"] == "object"
    assert list(SCHEMA["properties"].keys()) == [
        "name",
        "age",
        "birthday",
        "address",
        "email",
        "phone",
    ]
    assert SCHEMA["required"] == ["name", "age", "birthday"]
    assert SCHEMA["definitions"]["Address"]["properties"]["city"]["minLength"] == 1

# Generated at 2022-06-12 15:57:35.864919
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:57:46.521219
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type: () -> None
    """Unit test for function from_json_schema_type."""
    assert from_json_schema_type(
        {"type": "number"}, type_string="number", allow_null=False, definitions=SchemaDefinitions()
    ) == Number()
    assert from_json_schema_type(
        {"type": "number"},
        type_string="number",
        allow_null=True,
        definitions=SchemaDefinitions(),
    ) == Number(allow_null=True)
    assert from_json_schema_type(
        {"type": "integer"}, type_string="integer", allow_null=False, definitions=SchemaDefinitions()
    ) == Integer()

# Generated at 2022-06-12 15:57:53.232631
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        from_json_schema_type(
            data={
                "type": "string",
                "minLength": "2",
                "maxLength": "255",
                "pattern": "^[a-z]+$",
                "format": "email",
            },
            type_string="string",
            allow_null=False,
            definitions=SchemaDefinitions(),
        )
        == String(min_length=2, max_length=255, pattern=re.compile(r"^[a-z]+$"))
    )



# Generated at 2022-06-12 15:58:04.847719
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    schema = SchemaDefinitions(
        items=List(items=String()),
        def1=Object(properties={"a": String()}, additional_properties=False),
        def2=Object(
            properties={"b": String()},
            pattern_properties={"^d": String()},
            additional_properties=True,
        ),
    )

# Generated at 2022-06-12 15:58:10.161601
# Unit test for function to_json_schema
def test_to_json_schema():
    x = Field(
        allow_null=True,
        default=NO_DEFAULT,
        description="This is a string.",
        title="String Title",
        examples=[],
        deprecated=False,
    )
    json_schema = to_json_schema(x)
    expected = {"type": ["string", "null"]}
    assert json_schema == expected

# Generated at 2022-06-12 15:58:12.647609
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    with pytest.raises(AssertionError):
        from_json_schema_type({"type": "invalid"}, "invalid", False, SchemaDefinitions())



# Generated at 2022-06-12 15:59:56.866769
# Unit test for function from_json_schema
def test_from_json_schema():
    assert (
        from_json_schema(
            {
                "$ref": "#/definitions/Person",
                "definitions": {
                    "Person": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
                        "required": ["name"],
                    }
                },
            }
        )
        == Schema(
            {
                "properties": {
                    "name": String(required=True),
                    "age": Integer(),
                }
            },
            definitions={
                "#/definitions/Person": Schema(
                    {
                        "properties": {
                            "name": String(required=True),
                            "age": Integer(),
                        }
                    }
                )
            },
        )
    )



# Generated at 2022-06-12 16:00:03.566491
# Unit test for function from_json_schema
def test_from_json_schema():
    ref = Reference("Object", definitions=definitions)
    definitions["Object"] = Object(properties={"value": String()})
    assert ref.validate({"value": "valid"}) == {"value": "valid"}
    assert ref.validate({"value": ""}) != {}
    assert ref.validate({"not_value": ""}) == {}
    assert ref.serialize({"value": "valid"}) == {"value": "valid"}
    assert ref.serialize({"value": ""}) != {"value": ""}
    assert ref.serialize({"not_value": ""}) == {}



# Generated at 2022-06-12 16:00:13.283559
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )

    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )

    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(
        allow_null=True
    )

    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )

    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(
        allow_null=True
    )

    assert from_json_schema