

# Generated at 2022-06-12 15:50:56.954410
# Unit test for function to_json_schema
def test_to_json_schema():
    field = String(max_length=10)
    result = to_json_schema(field)
    assert result == {"type": "string", "maxLength": 10}
test_to_json_schema()



# Generated at 2022-06-12 15:51:03.567693
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-12 15:51:06.375738
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 1}) == Const(const=1)
# END Unit test for function const_from_json_schema



# Generated at 2022-06-12 15:51:15.883463
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_text = """
        {
            "definitions": {
                "foo": {
                    "type": "string"
                },
                "bar": {
                    "type": "string"
                }
            },
            "properties": {
                "something": {
                    "$ref": "#/definitions/foo"
                },
                "somethingElse": {
                    "$ref": "#/definitions/bar"
                }
            }
        }
    """
    schema = Schema(from_json_schema(schema_text))
    schema_definitions = schema.definitions

# Generated at 2022-06-12 15:51:18.462895
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": 3}, None)
    assert isinstance(field, Const)
    assert field.validate(3) == 3
    assert field.validate(4) == 4


# Generated at 2022-06-12 15:51:25.409646
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"$ref": "#/definitions/foo"},
            {"$ref": "#/definitions/baz"},
        ],
        "definitions": {
            "foo": {"type": "string"},
            "baz": {"type": "integer"},
        },
    }
    res = any_of_from_json_schema(schema, {})
    assert res.validate("test")
    assert res.validate(5)
    assert not res.validate(True)


# Generated at 2022-06-12 15:51:28.941687
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = {"#/definitions/foo": Integer()}
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-12 15:51:38.044202
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Unit test for `from_json_schema_type()`.
    """
    # Invalid argument
    try:
        from_json_schema_type(data={}, type_string="xyzzy", allow_null=False, definitions=None)
    except AssertionError as exc:
        assert str(exc) == "Invalid argument type_string='xyzzy'"
    else:
        assert False, "should have raised an exception"  # pragma: no cover

    # Nullable and non-nullable

# Generated at 2022-06-12 15:51:43.451163
# Unit test for function from_json_schema
def test_from_json_schema():
    assert json_schema_fields(
        (
            typing.Optional[typing.Union[int, str]]
            | Object(properties={"x": String(min_length=1, max_length=10)})
        )
    ) == {
        "type": ["object", "number", "string"],
        "properties": {"x": {"type": "string", "minLength": 1, "maxLength": 10}},
    }

# Generated at 2022-06-12 15:51:46.711119
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    with SchemaDefinitions() as definitions:
        definitions["#/definitions/foo"] = String()
        assert isinstance(ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions), Reference)



# Generated at 2022-06-12 15:52:26.415804
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert isinstance(one_of_from_json_schema({
        "oneOf": [
            {"type": "integer"},
            {"type": "string", "pattern": "^#[0-9a-fA-F]{6}$"},
        ],
        "default": "none"
    }), OneOf)



# Generated at 2022-06-12 15:52:33.846512
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    def _test(schema, allow_null, expectations):
        # type: (dict, bool, typing.Dict[str, Field]) -> None
        field = type_from_json_schema(schema, definitions=SchemaDefinitions())
        if allow_null:
            field = field.allow_null()
        for dtype, expected in expectations.items():
            if isinstance(expected, Field):
                assert expected == field.of_type(dtype)
            else:
                with expected:
                    field.validate(dtype)

    # Boolean
    _test(
        {"type": "boolean"},
        allow_null=False,
        expectations={"boolean": Boolean(allow_null=False)},
    )

# Generated at 2022-06-12 15:52:44.659964
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data1 = {"type": "integer", "oneOf": [{"type": "integer", "multipleOf": 2}, {"type": "integer", "multipleOf": 3}]}
    definitions1 = {}
    assert one_of_from_json_schema(data1, definitions1).validate(1) == (False, "Not allowed by one_of")
    assert one_of_from_json_schema(data1, definitions1).validate(2) == (True, None)
    assert one_of_from_json_schema(data1, definitions1).validate(3) == (True, None)
    assert one_of_from_json_schema(data1, definitions1).validate(4) == (False, "Not allowed by one_of")

# Generated at 2022-06-12 15:52:50.770247
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, AllOf, IfThenElse
    import functools

    def check(expected: dict, actual: dict):
        a = json.dumps(actual, sort_keys=True, allow_nan=False)
        b = json.dumps(expected, sort_keys=True, allow_nan=False)
        assert a == b

    def check_schema(field: Field, expected: dict):
        check(expected, to_json_schema(field))

    check_schema(String(), {"type": "string"})
    check_schema(Integer(), {"type": "integer"})
    check_schema(Boolean(), {"type": "boolean"})

# Generated at 2022-06-12 15:52:57.297429
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)



# Generated at 2022-06-12 15:53:03.038687
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:53:12.611407
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        'allOf': [{
            'type': 'number', 
            'minimum': 0
            }, 
            {
            'type': 'object', 
            'required': ['a'], 
            'properties': {
            'a': {'type': 'string'}
            }
        }], 
        'default': 0
    }
    definitions = SchemaDefinitions()
    result = all_of_from_json_schema(data, definitions=definitions)
    assert result.__class__.__name__ == 'AllOf'
    assert result.all_of[0].__class__.__name__ == 'Float'
    assert result.all_of[0].minimum == 0
    assert result.all_of[1].__class__.__name__ == 'Object'
    assert result

# Generated at 2022-06-12 15:53:22.649831
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema_object = {
        "type": "string"
    }

    field = from_json_schema_type(json_schema_object, "string", allow_null=False, definitions=definitions)
    assert isinstance(field, String)

    json_schema_object = {
        "type": "integer"
    }

    field = from_json_schema_type(json_schema_object, "integer", allow_null=False, definitions=definitions)
    assert isinstance(field, Integer)

    json_schema_object = {
        "type": "boolean"
    }

    field = from_json_schema_type(json_schema_object, "boolean", allow_null=False, definitions=definitions)
    assert isinstance(field, Boolean)

    json

# Generated at 2022-06-12 15:53:25.818600
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema(): # type: ignore
    _data = {"if": {"const": True}, "then": "string"}
    _f = if_then_else_from_json_schema(_data)
    assert _f.default == NO_DEFAULT
    assert _f.render(value=None) == '"string"'

# Generated at 2022-06-12 15:53:30.373501
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "object", "properties": {"hello": {"type": "string"}}}}
    field = not_from_json_schema(data, definitions=None)
    assert field.validate("hi") == ("hi", None)
    assert field.validate("hello") == (None, "not(«object»)")


# Generated at 2022-06-12 15:54:00.035339
# Unit test for function to_json_schema
def test_to_json_schema():

    schema =Schema(
        {
            "a": Integer(minimum=5, maximum=10, multiple_of=2, default=6),
            "b": String(allow_blank=True, default=""),
            "c": Boolean(default=True),
        }
    )
    schema_data = {
        "type": "object",
        "properties": {
            "a": {
                "type": "integer",
                "minimum": 5,
                "maximum": 10,
                "multipleOf": 2,
                "default": 6,
            },
            "b": {
                "type": "string",
                "default": "",
            },
            "c": {
                "type": "boolean",
                "default": True,
            },
        },
        "additionalProperties": False,
    }

# Generated at 2022-06-12 15:54:05.585827
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    type_schema = type_from_json_schema(data={"type": ["integer", "string"]})
    assert type_schema.validate(123) is None
    assert type_schema.validate("abc") is None
    assert type_schema.validate(None) is None
    assert type_schema.validate(1.23) == ["Must be one of: integer, string"]



# Generated at 2022-06-12 15:54:14.576126
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    class TestDefinition:
        # dict to Field
        def test_ref_to_self(self):
            data = {
                "$ref": "#/definitions/Person"
            }
            definitions = SchemaDefinitions()
            definitions['#/definitions/Person'] = Object
            field = ref_from_json_schema(data, definitions=definitions)
            assert isinstance(field, Reference)
            assert field.to == '#/definitions/Person'
        def test_ref_to_other_definition(self):
            data = {
                "$ref": "#/definitions/Female"
            }
            definitions = SchemaDefinitions()
            definitions['#/definitions/Male'] = Object
            definitions['#/definitions/Female'] = Object

# Generated at 2022-06-12 15:54:25.660032
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(
        data={
            "type": "array",
            "items": {
                "type": "number",
                "minimum": 0,
            },
        },
        definitions=SchemaDefinitions(),
    ) == Array(items=Number(minimum=0), min_items=0)
    assert type_from_json_schema(
        data={
            "type": "array",
            "items": {
                "type": "number",
                "minimum": 0,
            },
            "uniqueItems": True,
        },
        definitions=SchemaDefinitions(),
    ) == Array(items=Number(minimum=0), unique_items=True, min_items=0)

# Generated at 2022-06-12 15:54:37.619762
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert repr(type_from_json_schema({}, None)) == "{True: Any(), False: NeverMatch()}"
    assert repr(type_from_json_schema({"type": "null"}, None)) == "Const(None)"
    assert repr(type_from_json_schema({"type": "boolean"}, None)) == "Boolean()"
    assert repr(type_from_json_schema({"type": "string"}, None)) == "String()"
    assert repr(type_from_json_schema({"type": "number"}, None)) == "Number()"
    assert repr(type_from_json_schema({"type": "integer"}, None)) == "Integer()"
    assert repr(type_from_json_schema({"type": "array"}, None)) == "Array()"

# Generated at 2022-06-12 15:54:43.404168
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # current issue on
    # https://github.com/alecthomas/voluptuous/issues/362
    import voluptuous as v

    if_clause = Object({Required("foo", msg="foo is required"): String()})
    then_clause = String()
    else_clause = String()
    if_then_else = {
        "if": {"$ref": "#/definitions/if"},
        "then": {"$ref": "#/definitions/then"},
        "else": {"$ref": "#/definitions/else"},
    }
    definitions = {
        "if": if_clause,
        "then": then_clause,
        "else": else_clause,
        "if_then_else": if_then_else,
    }


# Generated at 2022-06-12 15:54:52.017600
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema_data = {
        "type": "object",
        "properties": {
            "a": {"if": {"$ref": "#/definitions/boolean"}, "then": {"type": "string"}},
            "b": {"if": {"$ref": "#/definitions/boolean"}, "then": {"type": "string"}},
            "c": {"if": {"$ref": "#/definitions/boolean"}, "then": {"type": "string"}},
            "d": {"if": {"$ref": "#/definitions/boolean"}, "then": {"type": "string"}},
        },
        "definitions": {
            "number": {"type": "number"},
            "boolean": {"type": "boolean"},
        },
    }

# Generated at 2022-06-12 15:54:55.234263
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-04/schema",
        "type": "string",
        "enum": [
            "Cabo Verde",
            "Cape Verde",
            "CV",
        ],
    }
    field = enum_from_json_schema(data, definitions)
    assert field == Choice(
        choices=[
            ('Cabo Verde', 'Cabo Verde'),
            ('Cape Verde', 'Cape Verde'),
            ('CV', 'CV'),
        ],
        default=NO_DEFAULT
    )



# Generated at 2022-06-12 15:54:58.478543
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    SCHEMA = {
        "$ref": "#/definitions/Constraint"
    }
    data = {
        "definitions": {
            "Constraint": {
                "const": [None]
            }
        }
    }

    field = from_json_schema(data)
    constraint = from_json_schema(SCHEMA)

    assert constraint.validate(None) == []
    assert constraint.validate(True) == [
        (field, "Value does not match const constraint.", "True")
    ]



# Generated at 2022-06-12 15:54:59.712319
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': ['red']}, {}).validate('red')=='red'


# Generated at 2022-06-12 15:55:49.242337
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "object",
            "properties": {
                "foo": {"type": "string"},
            },
        },
        "then": {
            "type": "object",
            "properties": {
                "bar": {"type": "string"},
            },
            "minProperties": 1,
            "maxProperties": 1,
            "required": ["bar"],
        },
        "else": {
            "type": "object",
            "properties": {
                "baz": {"type": "string"},
            },
            "minProperties": 1,
            "maxProperties": 1,
            "required": ["baz"],
        },
        "default": {
            "bar": "bar",
        }
    }
    field = from_json_schema

# Generated at 2022-06-12 15:55:54.702772
# Unit test for function to_json_schema
def test_to_json_schema():
    class ExampleSchema(SchemaDefinitions):
        string_example = String()
        object_example = Object(
            properties={
                "foo": String(max_length=5),
                "bar": Integer(minimum=10),
            }
        )
    schema = ExampleSchema()

    data = to_json_schema(schema)
    root_schema = data["definitions"]["ExampleSchema"]

# Generated at 2022-06-12 15:56:05.131731
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    function_kwargs = {
        "default": False,
        "if_clause": {
            "type": "number",
            "propertyNames": {
                "const": "x",
            },
        },
        "then_clause": {
            "pattern": {
                "type": "string",
                "pattern": "x",
            },
            "propertyNames": {
                "pattern": {
                    "type": "string",
                    "pattern": "x",
                },
            },
        },
        "else_clause": {
            "type": "number",
            "propertyNames": {
                "const": "x",
            },
        },
    }
    definitions = SchemaDefinitions()
    definitions.register_class(IfThenElse)
    result = if_then_else_from_json

# Generated at 2022-06-12 15:56:17.589355
# Unit test for function to_json_schema
def test_to_json_schema():
    from typing import Optional

    # Type 1: Any
    schema = Any()
    json_schema = to_json_schema(schema)
    assert json_schema is True

    # Type 2: NeverMatch
    schema = NeverMatch()
    json_schema = to_json_schema(schema)
    assert json_schema is False

    # Type 3: String
    schema = String()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "string",
        "default": None,
    }
    schema = String(allow_null=True)
    json_schema = to_json_schema(schema)

# Generated at 2022-06-12 15:56:25.422693
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "number"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
    }
    definitions = SchemaDefinitions()
    got = if_then_else_from_json_schema(data, definitions)
    want = IfThenElse(
        If(Float()),
        Then(Integer()),
        Else(String())
    )
    ok_(got == want)
# Test error case
    data = {
        "if": {"type": "number"},
        "then": {"type": "integer"},
    }
    got = if_then_else_from_json_schema(data, definitions)
    want = IfThenElse(
        If(Float()),
        Then(Integer()),
        Else(Any()),
    )
   

# Generated at 2022-06-12 15:56:37.466935
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = make_schema(name=String())
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "name": {"type": ["string", "null"]},
        },
        "required": ["name"],
    }

################################################################################
# ALIASES
################################################################################
# Docstring for Alias
Alias.__doc__ = """
Alias for a field.

This field will resolve to the field it is aliased to, without modification.

.. versionadded:: 3.0
"""

# Docstring for Alias.__init__
Alias.__init__.__doc__ = """
Create an Alias.

Args:
    alias: Field that this alias points to.
"""
# Docstring for Alias

# Generated at 2022-06-12 15:56:46.376046
# Unit test for function to_json_schema
def test_to_json_schema():
    assert isinstance(to_json_schema(Any()), bool)
    assert isinstance(to_json_schema(NeverMatch()), bool)
    assert isinstance(to_json_schema(String()), dict)
    assert isinstance(to_json_schema(Integer()), dict)
    assert isinstance(to_json_schema(Float()), dict)
    assert isinstance(to_json_schema(Decimal()), dict)
    assert isinstance(to_json_schema(Boolean()), dict)
    assert isinstance(to_json_schema(Array()), dict)
    assert isinstance(to_json_schema(Object()), dict)
    assert isinstance(to_json_schema(Choice([("a", "b")])), dict)

# Generated at 2022-06-12 15:56:57.966870
# Unit test for function from_json_schema
def test_from_json_schema():
    assert JSONSchema.validate(from_json_schema(True))
    assert JSONSchema.validate(from_json_schema({"type": "boolean"}))
    assert JSONSchema.validate(from_json_schema({"type": "string"}))
    assert JSONSchema.validate(from_json_schema({"type": "integer"}))
    assert JSONSchema.validate(from_json_schema({"type": "number"}))
    assert JSONSchema.validate(from_json_schema({"type": "array"}))
    assert JSONSchema.validate(from_json_schema({"type": "object"}))
    assert JSONSchema.validate(from_json_schema({"type": "null"}))

# Generated at 2022-06-12 15:57:05.448743
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "number", "enum": [1, 2, 3]}) == Choice(
        [1, 2, 3]
    )



# Generated at 2022-06-12 15:57:13.147173
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause_data = {"type": "string"}
    then_clause_data = {"pattern": "^\\w+\\.\\w+$"}
    else_clause_data = {"const": "not valid"}
    data = {
        "if": if_clause_data,
        "then": then_clause_data,
        "else": else_clause_data,
    }
    if_clause = from_json_schema(if_clause_data)
    then_clause = from_json_schema(then_clause_data)
    else_clause = from_json_schema(else_clause_data)

# Generated at 2022-06-12 15:57:34.877794
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=line-too-long,bad-whitespace
    class MySchema(Schema):
        property_a = String()
        property_b = Integer(maximum=10)

    schema = MySchema.make_validator()
    data = to_json_schema(schema)
    assert data == {
        "properties": {
            "property_a": {"type": "string"},
            "property_b": {"maximum": 10, "type": "number", "exclusiveMaximum": False},
        },
        "required": ["property_a", "property_b"],
        "type": "object",
        "additionalProperties": False,
    }
    assert data == to_json_schema(data)
    assert data == to_json_schema(schema)
    assert data == to

# Generated at 2022-06-12 15:57:45.755082
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:57:54.676365
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:58:04.526174
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any) == True
    assert to_json_schema(NeverMatch) == False
    schema = Schema({"value": Integer()})
    json_schema = to_json_schema(schema)
    assert (
        json_schema
        == {
            "definitions": {
                "value": {
                    "type": ["integer", "null"],
                    "default": None,
                }
            },
            "properties": {
                "value": {"$ref": "#/definitions/value"}
            },
            "required": ["value"],
            "type": ["object", "null"],
        }
    )

# Generated at 2022-06-12 15:58:14.060775
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # TODO: Write unit tests for function from_json_schema_type
    #       Use the following names for your tests
    #          test_from_json_schema_type_default
    #          test_from_json_schema_type_allow_null
    #          test_from_json_schema_type_boolean
    #          test_from_json_schema_type_number
    #          test_from_json_schema_type_integer
    #          test_from_json_schema_type_string
    #          test_from_json_schema_type_array
    #          test_from_json_schema_type_object
    assert False, "TODO: Write unit tests for function from_json_schema_type"



# Generated at 2022-06-12 15:58:20.296528
# Unit test for function to_json_schema
def test_to_json_schema():
    # flake8: noqa
    from datetime import date, datetime, time
    from typing import List, Optional, Tuple, Union
    from pydantic import BaseModel
    import pydantic_json

    strict = pydantic_json.StrictJSONSchema(to_json_schema)
    nonstrict = pydantic_json.NonStrictJSONSchema(to_json_schema)

    def test(schema: typing.Union[Field, typing.Type[Schema]]) -> None:
        strict(schema)
        nonstrict(schema)

    test(String(min_length=1, max_length=1, pattern_regex=".*"))
    test(Integer(minimum=5, maximum=5, exclusive_minimum=5, exclusive_maximum=5))

# Generated at 2022-06-12 15:58:29.430750
# Unit test for function to_json_schema
def test_to_json_schema():

    # Simple field
    field = String()
    assert to_json_schema(field) == {
        "type": "string",
    }

    # Nested field
    field = Object(properties={"name": String()})
    assert to_json_schema(field) == {
        "type": "object",
        "properties": {"name": {"type": "string"}},
    }

    # Choice field
    field = Choice(choices=(("active", True), ("inactive", False)))
    assert to_json_schema(field) == {
        "enum": ["active", "inactive"],
    }

    # Choice field with sub-fields

# Generated at 2022-06-12 15:58:36.715884
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(Integer) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Integer(minimum=-1)) == {"type": "integer", "minimum": -1}
    assert to_json_schema(Integer(maximum=10)) == {"type": "integer", "maximum": 10}
    assert to_json_schema(Integer(exclusive_minimum=True)) == {
        "type": "integer",
        "exclusiveMinimum": True,  # type: ignore
    }
    assert to_json_schema(Integer(exclusive_maximum=True)) == {
        "type": "integer",
        "exclusiveMaximum": True,  # type: ignore
    }
    assert to_json_

# Generated at 2022-06-12 15:58:46.615056
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")
    assert from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": String()}) == String()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["string", "integer"]}) == String() | Integer()
    assert from_json_schema({"enum": ["foo"]}).enum == {"foo"}
    assert from_json_schema({"enum": ["foo"]}).description == "one of ['foo']"
    assert from_json_schema({"enum": ["foo"], "description": "foo"}).description == "foo"
    assert from_json_

# Generated at 2022-06-12 15:58:55.252606
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String) == {
        "$ref": "#/definitions/String"
    }, "to_json_schema(String) failed"

    assert to_json_schema(Integer) == {
        "$ref": "#/definitions/Integer"
    }, "to_json_schema(Integer) failed"

    assert to_json_schema(Float) == {
        "$ref": "#/definitions/Float"
    }, "to_json_schema(Float) failed"

    assert to_json_schema(Boolean) == {
        "$ref": "#/definitions/Boolean"
    }, "to_json_schema(Boolean) failed"


# Generated at 2022-06-12 15:59:19.454914
# Unit test for function from_json_schema
def test_from_json_schema():
    # $ref
    data = {"$ref": "foo"}
    assert ref_from_json_schema(data) == Reference("foo")
    # const
    data = {"const": "foo"}
    assert const_from_json_schema(data) == Const("foo")
    # allOf
    data = {"allOf": [{"type": "string"}]}
    assert all_of_from_json_schema(data) == AllOf([String()])
    # anyOf
    data = {"anyOf": [{"type": "string"}]}
    assert any_of_from_json_schema(data) == Any([String()])
    # oneOf
    data = {"oneOf": [{"type": "string"}]}
    assert one_of_from_json_schema(data) == OneOf([String()])


# Generated at 2022-06-12 15:59:23.878575
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema(
        {
            "$ref": "#/definitions/string_with_minimum",
        }
    ) == Reference(to="#/definitions/string_with_minimum")
# End of unit test for function ref_from_json_schema



# Generated at 2022-06-12 15:59:31.351210
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = {
        "type": "object",
        "required": ["string", "int"],
        "properties": {
            "string": {"type": "string"},
            "int": {"type": "number", "multipleOf": 2},
            "bool": {"type": "boolean", "default": True},
        },
        "definitions": {
            "int": {"type": "number", "multipleOf": 2},
            "myref": {"$ref": "#/definitions/int"},
        },
    }
    schema_type = from_json_schema(schema)

    assert schema == to_json_schema(schema_type)
    assert schema == to_json_schema(schema_type.make_validator())



# Generated at 2022-06-12 15:59:35.464309
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # pylint: disable=unused-argument
    data = {
        "type": "number",
        "minimum": 2.0,
        "maximum": 20.0,
    }
    type_string = "number"
    allow_null = False
    definitions = SchemaDefinitions()
    field = from_json_schema_type(data, type_string, allow_null, definitions)
    assert field.minimum == 2.0
    assert field.maximum == 20.0


# Generated at 2022-06-12 15:59:42.456675
# Unit test for function to_json_schema
def test_to_json_schema():
    from .schemas import Schema, String, Reference, Definition, Integer, Float, Boolean
    from .fields import Array, Object, Choice, Const, Union, AllOf, OneOf, IfThenElse, Not

    assert to_json_schema(String(max_length=10, allow_blank=False)) == {
        "type": "string",
        "maxLength": 10,
        "minLength": 1,
    }

    assert to_json_schema(Array(min_items=2, max_items=10, items=Integer())) == {
        "type": "array",
        "items": {"type": "integer"},
        "minItems": 2,
        "maxItems": 10,
    }


# Generated at 2022-06-12 15:59:53.720040
# Unit test for function to_json_schema
def test_to_json_schema(): # type: ignore
    from pydantic import BaseModel

    class Model(BaseModel):
        a: str
        b: typing.List[int]

    base_schema = to_json_schema(Model)
    assert sorted(base_schema["definitions"].keys()) == ["Model"]

# Generated at 2022-06-12 16:00:03.287811
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)


# Generated at 2022-06-12 16:00:05.761162
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string='boolean', allow_null=False, definitions=None) == Boolean()

