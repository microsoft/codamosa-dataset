

# Generated at 2022-06-12 15:51:38.075354
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_schema = {
        "const": "Hello World",
    }
    const_field = const_from_json_schema(const_schema, definitions)

    assert const_field.is_valid(None) == False
    assert const_field.is_valid("Hello World") == True


# Generated at 2022-06-12 15:51:50.297495
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

    schema = String(pattern_regex=re.compile("[0-9]+", re.RegexFlag.UNICODE))
    assert to_json_schema(schema) == {"type": "string", "pattern": "[0-9]+"}

    schema = Integer(minimum=10)

# Generated at 2022-06-12 15:52:01.226377
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert (enum_from_json_schema({'enum': [1, 2, 3], 'default': 1}, None)).type_name == "choice"
    assert (enum_from_json_schema({'enum': [1, 2, 3], 'default': 1}, None)).default == "1"
    assert (enum_from_json_schema({'enum': [1, 2, 3], 'default': 1}, None)).choices == [(1, 1), (2, 2), (3, 3)]
    assert (enum_from_json_schema({'enum': ["a", "b"], 'default': "a"}, None)).type_name == "choice"
    assert (enum_from_json_schema({'enum': ["a", "b"], 'default': "a"}, None)).default == "a"

# Generated at 2022-06-12 15:52:07.214475
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    base_url = r"https://example.com/schemas/"
    for reference_string in (
        "#/definitions/Foo", "", "Foo", "#/definitions/Foo#/bar", ""
    ):
        data = {"$ref": reference_string}
        definitions = SchemaDefinitions()
        field = ref_from_json_schema(data, definitions)
        assert field.to == reference_string
        assert field.definitions == definitions



# Generated at 2022-06-12 15:52:10.913850
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    kwargs = {"enum": ["123", "456", "789"]}
    field = Choice(choices=[("123", "123"), ("456", "456"), ("789", "789")])
    assert from_json_schema(kwargs) == field



# Generated at 2022-06-12 15:52:22.782598
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert_deserializes(
        {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
            "multipleOf": 5,
        },  # JSON Schema
        {"v": 1},  # valid
        {"v": 0},  # invalid
    )
    assert_deserializes(
        {
            "type": "object",
            "properties": {
                "v": {"type": "integer", "minimum": 1, "maximum": 10, "multipleOf": 5}
            },
        },  # JSON Schema
        {"v": 1},  # valid
        {"v": 0},  # invalid
    )

# Generated at 2022-06-12 15:52:28.081875
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    print("test_enum_from_json_schema")
    options = {
        "enum": [1, 2, 3],
        "default": 2
    }
    schema = enum_from_json_schema(options, SchemaDefinitions())
    print(schema.default)
    print(schema.to_primitive())
    print(schema.validate(2))


# Generated at 2022-06-12 15:52:29.918392
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {"$ref": "#/definitions/ValidatingString"}
    field = from_json_schema(schema)
    assert field.to == "#/definitions/ValidatingString"
# End of unit test for function ref_from_json_schema



# Generated at 2022-06-12 15:52:41.777372
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"})
    assert from_json_schema({"type": ["integer", "number"]}) == (Integer() | Number())
    assert from_json_schema({"type": ["number", "integer"]}) == (Integer() | Number())
    assert from_json_sche

# Generated at 2022-06-12 15:52:47.277047
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_1 = const_from_json_schema({'const':123})
    assert const_1.validate(123) == 123
    assert const_1.validate(123.0) == 123
    assert const_1.validate('123') == 123
    assert const_1.validate('123.0') == 123


# Generated at 2022-06-12 15:53:48.305805
# Unit test for function to_json_schema
def test_to_json_schema():
    import pytest
    from .enums import CogState
    from .models import EmailField, URLField

    definitions = {}
    assert to_json_schema(Any(default="foo"), definitions=definitions) == "foo"

    data = to_json_schema(String(default="foo"), definitions=definitions)
    assert data["type"] == "string"
    assert data["default"] == "foo"

    data = to_json_schema(String(), definitions=definitions)
    assert data["type"] == "string"

    data = to_json_schema(String(allow_null=True), definitions=definitions)
    assert data["type"] == ["string", "null"]

    data = to_json_schema(EmailField, definitions=definitions)

# Generated at 2022-06-12 15:53:53.899616
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "null"}, {"type": "string"}, {"type": "integer"}]}
    assert isinstance(all_of_from_json_schema(data, definitions=definitions), AllOf)
    assert isinstance(all_of_from_json_schema(data, definitions=definitions).all_of[0], type_from_json_schema)
    assert isinstance(all_of_from_json_schema(data, definitions=definitions).all_of[1], type_from_json_schema)
    assert isinstance(all_of_from_json_schema(data, definitions=definitions).all_of[2], type_from_json_schema)
    assert all_of_from_json_schema(data, definitions=definitions).all_of[0].type

# Generated at 2022-06-12 15:54:01.862758
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    jsonschema = {
        'anyOf': [
            {
                'type': 'object',
                'properties': {
                    'x': {'type': 'number'},
                },
                'required': ['x'],
            },
            {
                'type': 'object',
                'properties': {
                    'y': {'type': 'number'},
                },
                'required': ['y'],
            },
        ],
    }
    field = from_json_schema(jsonschema)
    assert field.validate({'x': 1}) is None
    assert field.validate({'y': 1}) is None
    assert field.validate({'x': 1, 'y': 1}) is None
    assert field.validate({'z': 1}) is not None
    assert field.validate

# Generated at 2022-06-12 15:54:12.286363
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Ensure that from_json_schema() can generate JSON Schema from every valid JSON Schema
    """
    from typesystem import Schema, validate
    from json_schema.validators.draft7_format_checker import Draft7FormatChecker
    from json_schema.validators import create
    from json_schema.exceptions import FormatError, ValidationError

    from collections import OrderedDict
    from typing import Union, List, Optional

    from json_schema.validators.draft7_format_checker import Draft7FormatChecker
    validator = create(meta_schema={}, format_checker=Draft7FormatChecker, )


# Generated at 2022-06-12 15:54:16.045621
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    input_schema = {"allOf": [{"type": "boolean"},{"const": False}]}
    assert all_of_from_json_schema(input_schema, definitions=None) == AllOf(all_of=[Boolean(),Const(const=False)])



# Generated at 2022-06-12 15:54:27.093296
# Unit test for function to_json_schema
def test_to_json_schema():
    from .fields import Array, Boolean, Const, Integer, OneOf, String, Union

    schema = Array(
        items=[
            Integer(
                minimum=24,
                maximum=27,
                multiple_of=2,
                default=lambda _: [25, 26],
            ),
            String(format="date", allow_blank=False),
        ]
    )
    data = to_json_schema(schema)

# Generated at 2022-06-12 15:54:30.942196
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": "bar",
        "default": "foo",
    }
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.default == "foo"
    try:
        field.validate("baz")
    except ValidationError as e:
        assert (
            e.message == "'baz' is not equal to 'bar'"
        ), "Message should match '{}' is not equal to '{}'".format("baz", "bar")
        assert e.code == "const"



# Generated at 2022-06-12 15:54:39.066532
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(
        data={"not": {"enum": [1, 2]}}, definitions=SchemaDefinitions()
    ) == Not(
        negated=Choice(choices=[(1, 1), (2, 2)], default=NO_DEFAULT), default=NO_DEFAULT
    )
    assert not_from_json_schema(
        data={"not": {"enum": [1, 2], "default": 5}}, definitions=SchemaDefinitions()
    ) == Not(
        negated=Choice(choices=[(1, 1), (2, 2)], default=NO_DEFAULT), default=5
    )



# Generated at 2022-06-12 15:54:40.399221
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema(True), Any)
    assert isinstance(from_json_schema(False), NeverMatch)



# Generated at 2022-06-12 15:54:45.752914
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert bool(
        IfThenElse(
            if_clause=Boolean(),
            then_clause=Integer(),
            else_clause=String(),
            default=NO_DEFAULT
        ).validate(True)
    )
    assert bool(
        IfThenElse(
            if_clause=Boolean(),
            then_clause=Integer(),
            else_clause=String(),
            default=NO_DEFAULT
        ).validate("hi")
    )
    assert not bool(
        IfThenElse(
            if_clause=Boolean(),
            then_clause=Integer(),
            else_clause=String(),
            default=NO_DEFAULT
        ).validate(1)
    )

# Generated at 2022-06-12 15:56:58.501672
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """Test if then else from json schema"""
    pftj = if_then_else_from_json_schema
    assert pftj({'if': {'properties': {'x': {'enum': [1, 2]}}}}) == \
        IfThenElse(if_clause=Object(properties={'x': Choice(choices=[(1, 1), (2, 2)])}))
    assert pftj({'if': {'properties': {'x': {'allOf': [{'enum': [1, 2]}]}}}}) == \
        IfThenElse(if_clause=Object(properties={'x': AllOf(all_of=[Choice(choices=[(1, 1), (2, 2)])])}))

# Generated at 2022-06-12 15:57:05.279272
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema({
        "if": {"type": "string"},
        "then": {"const": "positive"},
        "else": {"const": "negative"},
    }, SchemaDefinitions()), IfThenElse)


###############################################################################
# Field -> JSON Schema
###############################################################################


# Generated at 2022-06-12 15:57:13.053007
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # invalid test
    invalid_json_schema = {
        "type": "object",
        "properties": {"name": {"type": "string", "default": "NULL"}},
        "oneOf": [{"type": "number","properties": {"name": {"type": "number", "default": "NULL"}}}],
        "default": "NULL"
    }
    # valid test
    one_of_data_ref = {
        "oneOf": [
            {"type": "string"},
            {"type": "number"},
            {
                "type": "object",
                "properties": {"name": {"type": "string", "maxLength": 4}},
            },
        ],
        "default": "NULL"
    }
    assert one_of_from_json_schema(one_of_data_ref)

# Generated at 2022-06-12 15:57:25.549215
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string", "enum": [1, "a"]}) == String(enum=[1, "a"])
    assert from_json_schema({"type": "number", "multipleOf": 2}) == Number(multiple_of=2)
    assert from_json_schema({"type": "object", "properties": {"a": {"type": "string"}}}) == Object(properties={"a": String()})
    assert from_json_schema({"type": "array", "items": {"type": "string"}}) == Array(items=String())
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), None])

# Generated at 2022-06-12 15:57:34.717047
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {
                "type": "string",
                "enum": ["blue", "yellow", "red", "green", "purple"],
                "default": "blue",
            },
            {
                "type": "integer",
                "minimum": 0,
                "maximum": 255,
                "default": 0,
            },
        ]
    }
    field = one_of_from_json_schema(schema, None)
    assert field.validate(10) == 10
    assert field.validate("red") == "red"
    assert field.validate(10.5) == 10
    assert field.validate(256) == 256
    assert field.validate(None) == None



# Generated at 2022-06-12 15:57:45.676078
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test for simple string
    raw_string = to_json_schema(String())
    assert raw_string == {
        "type": "string",
        "default": NO_DEFAULT,
        "description": None,
        "title": None,
        "minLength": 0,
        "maxLength": None,
        "pattern": None,
        "format": None,
    }

    # Test for reference
    class my_class(Reference):
        to = "#/definitions/target"

    raw_reference = to_json_schema(my_class())
    assert raw_reference == {"$ref": "#/definitions/target"}

    # Test for simple all_of
    test_all_of = AllOf([String(), Integer()])

# Generated at 2022-06-12 15:57:54.640070
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, "number", False, None)
    assert from_json_schema_type({"type": "integer"}, "integer", False, None)
    assert from_json_schema_type({"type": "string"}, "string", False, None)
    assert from_json_schema_type({"type": "boolean"}, "boolean", False, None)

    assert isinstance(from_json_schema_type({"type": ["number"]}, "number", False, None), Float)
    assert isinstance(from_json_schema_type({"type": ["integer"]}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({"type": ["string"]}, "string", False, None), String)
    assert isinstance

# Generated at 2022-06-12 15:58:03.026359
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    oneOf = [{"type":"string","minLength":1},{"type":"integer","multipleOf":5}]
    one_of = [from_json_schema(item, definitions=definitions) for item in oneOf]
    kwargs = {"one_of": one_of, "default": NO_DEFAULT}
    field = OneOf(**kwargs)
    assert field.validate('some text') is None
    assert field.validate(5) is None
    assert field.validate('_') is not None



# Generated at 2022-06-12 15:58:13.202685
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_of_data = {'oneOf': [{'type': 'number', 'minimum': 1, 'maximum': 100}, {'type': 'number', 'minimum': 1, 'maximum': 100}], 'default': 50}
    ret = one_of_from_json_schema(dict_of_data, definitions=definitions)
    assert ret is not None, "Expected non-None, but got None"
    assert isinstance(ret, OneOf), "Expected OneOf, but got {0}".format(type(ret))
    assert ret.one_of[0].minimum == 1 and ret.one_of[0].maximum == 100, "Expected 'minimum': 1, 'maximum': 100, but got {0}, {1}".format(ret.one_of[0].minimum, ret.one_of[0].maximum)


# Generated at 2022-06-12 15:58:15.814907
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = ARRAY(Integer())
    assert to_json_schema(schema) == {
        "type": "array",
        "items": {"type": "integer"},
        "default": NO_DEFAULT,
    }



# Generated at 2022-06-12 16:00:02.958057
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.types import String

    assert from_json_schema({}) == Any()
    assert from_json_schema({'type': 'string'}) == String()
    assert from_json_schema({'type': 'number'}) == Number()
    assert from_json_schema({'type': 'integer'}) == Integer()
    assert from_json_schema({'type': 'boolean'}) == Boolean()
    assert from_json_schema({'type': 'array'}) == Array()



# Generated at 2022-06-12 16:00:12.777649
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema.make(
        title="test-schema",
        x=String(),
        y=Integer(),
        z=Dict(
            String(),
            Integer(),
            min_items=2,
            unique_items=True,
            allow_blank=False,
            min_length=4,
            max_length=4,
            pattern=r"^3",
        ),
    )
    data = to_json_schema(schema)
    data.pop("definitions")
    schema_json = json.dumps(
        data, indent=2, ensure_ascii=False, sort_keys=True, default=repr
    )