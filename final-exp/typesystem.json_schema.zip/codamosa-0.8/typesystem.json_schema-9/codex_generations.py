

# Generated at 2022-06-12 15:51:21.468923
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(Nullable(Integer())) == {
        "type": ["integer", "null"]
    }


# Generated at 2022-06-12 15:51:32.308977
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Given
    test_schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {
            "enum_basic": {
                "enum": [1, 2, 3]
            }
        },
        "required": ["enum_basic"]
    }
    test_data = {
        "enum_basic": 1,
    }
    expected_output = {
        "enum_basic": 1,
    }
    # When
    TestEnumBasic = from_json_schema(test_schema)
    result = TestEnumBasic.validate(test_data)
    # Then
    assert result is None, "Validation success"
    assert result == expected_output, "Validation result matches expected output"


# Generated at 2022-06-12 15:51:44.304505
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    x = if_then_else_from_json_schema({
        "if": {
            "properties": {
                "name": {
                    "type": "string",
                    "maxLength": 1
                }
            },
            "required": ["name"]
        },
        "then": {
            "type": "string",
            "anyOf": [
                {
                    "const": 'a'
                },
                {
                    "const": 'b'
                }
            ]
        },
        "else": {
            "const": 'c'
        },
        "default": 'c'
    }, definitions=None)
    assert validate_object(x, 
        {"name": "a"}) == {"name": "a"}

# Generated at 2022-06-12 15:51:48.589305
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {'enum': ['a', 'b', 'c']}
    assert enum_from_json_schema(schema, None).validate('a')
    assert not enum_from_json_schema(schema, None).validate('d')



# Generated at 2022-06-12 15:51:54.579485
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():

    data = {"oneOf": [{"const":12},{"const":13}]}
    definitions = {}
    assert (one_of_from_json_schema(data,definitions)).schema() == {"one_of":[Schema({"const":12}),Schema({"const":13})]}
    assert (one_of_from_json_schema(data,definitions)).validate(12) == True
    assert (one_of_from_json_schema(data,definitions)).validate(13) == True
    assert (one_of_from_json_schema(data,definitions)).validate(14) == False

    data = {"oneOf": [{"const":12},{"const":13}], "default": 13}
    assert (one_of_from_json_schema(data,definitions)).schema()

# Generated at 2022-06-12 15:52:05.069972
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of_schema = {
        "oneOf": [
            {
                "type": "number",
                "minimum": 5,
                "maximum": 10,
            },
            {
                "type": "integer",
                "minimum": 5,
                "maximum": 10,
            },
        ]
    }
    one_of_field = one_of_from_json_schema(one_of_schema, definitions={})
    assert one_of_field.validate(1) == ([], 1)
    assert one_of_field.validate(11) == (['test:test0', 'test:test1'], 11)
    assert one_of_field.validate(3.5) == (['test:test1'], 3.5)

# Generated at 2022-06-12 15:52:09.616017
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of = [from_json_schema({"type": "string"}, definitions=definitions), from_json_schema({"type": "integer"}, definitions=definitions)]
    kwargs = {"one_of": one_of, "default": None}
    assert OneOf(**kwargs).one_of == one_of



# Generated at 2022-06-12 15:52:21.355228
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type({}, type_string="string", allow_null=False, definitions=None),
        String,
    )
    assert isinstance(
        from_json_schema_type({}, type_string="number", allow_null=False, definitions=None),
        Float,
    )
    assert isinstance(
        from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None),
        Integer,
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="boolean", allow_null=False, definitions=None
        ),
        Boolean,
    )

# Generated at 2022-06-12 15:52:30.905692
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test the function 'from_json_schema_type'.
    """
    # More tests below, but this is a test of the general case.
    data = {
        "type": "number",
        "title": "An integer",
        "description": "An integer",
        "minimum": 0,
        "maximum": 10,
        "default": 0,
    }
    assert isinstance(from_json_schema_type(data, "number", False, None), Float)
    assert isinstance(from_json_schema_type(data, "integer", False, None), Integer)
    assert from_json_schema_type(data, "integer", False, None).minimum == 0
    assert from_json_schema_type(data, "integer", False, None).maximum == 10
    assert from_json_

# Generated at 2022-06-12 15:52:42.258819
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    print("test_type_from_json_schema")
    def test(data, expected):
        print("data:", data)
        actual = type_from_json_schema(data, definitions=None)
        print("actual:", actual)
        assert actual == expected, "Actual does not match expected."
    data = {}
    expected = Any()
    test(data, expected)
    data = {"type": "null"}
    expected = Const(None)
    test(data, expected)
    data = {"type": "null", "enum": []}
    expected = Const(None)
    test(data, expected)
    data = {"type": "null", "enum": [None]}
    expected = Const(None)
    test(data, expected)

# Generated at 2022-06-12 15:53:21.890409
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'type': 'number', 'not': {'type': 'number', 'multipleOf': 5}}
    field = not_from_json_schema(schema, definitions=None)
    print(field)
    print(field.validate(1))
    print(field.serialize(10))


# Generated at 2022-06-12 15:53:28.759571
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/some_reference"
    }
    definitions = SchemaDefinitions()

    # The actual result of this is a DefinitionReference.
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)
    assert f"#/definitions/some_reference" == ref_from_json_schema(data, definitions=definitions)


# Generated at 2022-06-12 15:53:36.378599
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "type": {
                        "const": "measurement"
                    },
                    "value": {
                        "type": "number"
                    }
                }
            },
            {
                "type": "object",
                "properties": {
                    "type": {
                        "const": "measurement"
                    },
                    "value": {
                        "type": "number"
                    },
                    "unit": {
                        "type": "string"
                    }
                }
            }
        ]
    }
    data = {
        "type": "measurement",
        "value": 24.2,
        "unit": "metres"
    }

# Generated at 2022-06-12 15:53:41.605990
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    ref = Reference("#/definitions/test", definitions)
    definitions[ref.to] = ref

    data = {"$ref": "#/definitions/test"}
    assert ref_from_json_schema(data, definitions) == ref



# Generated at 2022-06-12 15:53:49.110288
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    class Person(BaseModel):
        age: int = ...

    class PersonWithSsn(BaseModel):
        age: int
        ssn: str = ...

    class PersonWithSsnAndId(BaseModel):
        age: int
        ssn: str = ...
        id: str = ...

    my_person1 = Person(age=18)
    my_person2 = Person(age=19)
    my_person3 = Person(age=20)
    my_person4 = Person(age=21)
    person_with_ssn1 = PersonWithSsn(age=22, ssn="123-45-6789")
    person_with_ssn2 = PersonWithSsn(age=23, ssn="123-45-6789")

# Generated at 2022-06-12 15:54:00.159478
# Unit test for function ref_from_json_schema

# Generated at 2022-06-12 15:54:08.507826
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    min_max_schema = {
        "allOf": [
            {"type": "number", "minimum": 5},
            {"type": "number", "maximum": 10},
        ]
    }
    field = from_json_schema(min_max_schema)
    assert field.validate(0) == [('all_of', '[0].minimum', 'too-small')]
    assert field.validate(15) == [('all_of', '[1].maximum', 'too-big')]
    assert field.validate(5) == []
    assert field.validate(10) == []
    assert field.default == 5



# Generated at 2022-06-12 15:54:16.081907
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["number", "null"],
        "minimum": -2147483648,
        "maximum": 2147483647,
    }
    assert to_json_schema(Any(allow_null=True)) == {"type": ["null"]}
    assert to_json_schema(IfThenElse(if_clause=Any)) == {
        "if": {"type": "object"},
        "then": {"type": "object"},
        "else": {"type": "object"},
    }
# End unit test for function to_json_schema



# Generated at 2022-06-12 15:54:27.092445
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "description": "description"}) == String(description="description")
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "minItems": 1}) == Array(min_items=1)
    assert from_json_schema({"type": "object", "properties": {"foo": {"type": "string"}}}) == Object(properties={'foo': String()})
    assert from_json_schema({"type": "object", "additionalProperties": False}) == Object(additional_properties=False)

# Generated at 2022-06-12 15:54:37.915141
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "number"},
            {"maximum": 10},
        ],
        "default": True,
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate(9) == 9
    assert field.validate(10) == 10
    assert field.validate(11) == 11
    assert field.default == True
    assert field.to_json_schema() == {
        "allOf": [
            {"type": "number"},
            {"maximum": 10},
        ],
        "default": True,
    }

# Generated at 2022-06-12 15:54:58.410040
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "integer"}
    assert from_json_schema_type(data, type_string="integer", allow_null=False, definitions=definitions) == Integer()
test_from_json_schema_type()



# Generated at 2022-06-12 15:55:03.543380
# Unit test for function to_json_schema
def test_to_json_schema():
    from_json_schema(to_json_schema(String()))
    from_json_schema(to_json_schema(String(default="foo")))
    from_json_schema(to_json_schema(String(min_length=5)))
    from_json_schema(to_json_schema(String(max_length=10)))
    from_json_schema(to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))))
    from_json_schema(to_json_schema(String(format="date")))
    from_json_schema(to_json_schema(Integer()))
    from_json_schema(to_json_schema(Integer(default=0)))

# Generated at 2022-06-12 15:55:12.401035
# Unit test for function to_json_schema
def test_to_json_schema():
    string = String(pattern_regex=re.compile(r"a+"))
    integer = Integer(minimum=5)
    data = to_json_schema(
        AnyOf(
            [
                integer,
                IfThenElse(
                    if_clause=String(pattern_regex=re.compile(r"b+")),
                    then_clause=AllOf([Not(String()), String()]),
                ),
            ]
        )
    )

# Generated at 2022-06-12 15:55:16.236130
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(
        if_then_else_from_json_schema(
            {
                "if": {"type": "number"},
                "then": {"type": "integer"},
                "else": {"type": "string"},
            },
            definitions=None,
        ),
        IfThenElse,
    )



# Generated at 2022-06-12 15:55:25.404410
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float(allow_null=False)
    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", False, None) == Integer(allow_null=False)
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)
    assert from_json_schema_type({}, "string", False, None) == String(
        allow_null=False, allow_blank=True
    )
    assert from_json_schema_type({}, "string", True, None) == String(
        allow_null=True, allow_blank=True
    )
    assert from_json

# Generated at 2022-06-12 15:55:36.402783
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Parse a schema which is an array of one schema or another schema
    schema_json = """
{
    "type": "object",
    "properties": {
        "foo": {
            "if": {
                "type": "string"
            },
            "then": {
                "type": "array",
                "items": {
                    "enum": ["bar", "baz"]
                }
            },
            "else": {
                "type": "object",
                "properties": {
                    "hello": {
                        "enum": [1, 2, 3]
                    }
                }
            }
        }
    }
}
"""
    parsed_schema = from_json_schema(json.loads(schema_json))

# Generated at 2022-06-12 15:55:46.171889
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.base import FieldMeta

    assert isinstance(from_json_schema({}), Any)
    assert isinstance(
        from_json_schema({"type": "null"}), Const
    )  # type: ignore
    assert isinstance(
        from_json_schema({"type": "null"}), Const
    )  # type: ignore
    assert isinstance(
        from_json_schema({"type": "string"}), String
    )  # type: ignore
    assert isinstance(
        from_json_schema({"type": "boolean"}), Boolean
    )  # type: ignore
    assert isinstance(
        from_json_schema({"type": "array"}), Array
    )  # type: ignore

# Generated at 2022-06-12 15:55:53.655579
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:56:01.360635
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_strings = {"number", "string", "boolean", "object", "array", "integer"}
    assert type_strings == get_valid_types({})

    assert {"null"} == get_valid_types({"type": "null"})
    assert {"null", "string"} == get_valid_types({"type": ["string", "null"]})

    assert {"string", "boolean"} == get_valid_types({"type": ["string", "boolean"]})



# Generated at 2022-06-12 15:56:08.597253
# Unit test for function from_json_schema
def test_from_json_schema():
    empty = {}
    schema = from_json_schema(empty)
    assert isinstance(schema, Any)

    empty_definitions = {"": {}}
    schema = from_json_schema(empty_definitions)
    assert isinstance(schema, Object)
    assert schema.properties[""] == Any()
    assert list(schema.properties.keys()) == [""]

    empty_definitions = {"definitions": {}}
    schema = from_json_schema(empty_definitions)
    assert isinstance(schema, Object)
    assert schema.properties["definitions"] == Any()
    assert list(schema.properties.keys()) == ["definitions"]

    boolean = {"type": "boolean"}
    schema = from_json_schema(boolean)
    assert isinstance(schema, Boolean)



# Generated at 2022-06-12 15:56:35.013537
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "number"
        },
        "then": {
            "type": "string"
        },
        "else": {
            "type": "array"
        }
    }
    definitions = None

    field = if_then_else_from_json_schema(data, definitions)
    assert field.if_clause.num_errors == 0
    assert field.then_clause.num_errors == 0
    assert field.else_clause.num_errors == 0

    assert field.if_clause.is_strict_subset(field.then_clause)
    assert field.then_clause.is_strict_subset(field.else_clause)

# Generated at 2022-06-12 15:56:39.384212
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema_data = {'$schema': 'http://json-schema.org/draft-07/schema#', 'if': {'type': 'integer'}, 'then': {'type': 'string'}, 'else': {'type': 'number'}, 'default': 12345}
    assert isinstance(if_then_else_from_json_schema(schema_data, SchemaDefinitions()), IfThenElse)
    assert if_then_else_from_json_schema(schema_data, SchemaDefinitions()).validate(9) == '9'
    assert if_then_else_from_json_schema(schema_data, SchemaDefinitions()).validate(9.9) == 9.9

# Generated at 2022-06-12 15:56:47.774976
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    data = {
        "type": "string",
        "minLength": 5,
        "maxLength": 10,
        "format": "email",
        "pattern": r"\d+",
        "default": "hello@example.org",
    }

    field = from_json_schema_type(
        data, type_string="string", allow_null=False, definitions=SchemaDefinitions()
    )
    assert isinstance(field, String)
    assert field.allow_null is False
    assert field.allow_blank is False
    assert field.min_length == 5
    assert field.max_length == 10
    assert field.format == "email"
    assert isinstance(field.pattern, re.Pattern)
    assert field.pattern.pattern == r"\d+"

# Generated at 2022-06-12 15:56:58.582303
# Unit test for function from_json_schema
def test_from_json_schema():
    field = from_json_schema({
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer", "minimum": 0, "maximum": 99}
            },
            "required": ["name", "age"]
        },
        "additionalItems": False,
        "minItems": 0
    })
    assert isinstance(field, Array)
    assert isinstance(field.items, Object)
    assert isinstance(field.items.properties["name"], String)
    assert isinstance(field.items.properties["age"], Integer)
    assert field.items.properties["name"].min_length is None
    assert field.items.properties["name"].max_length is None
    assert isinstance

# Generated at 2022-06-12 15:57:03.744417
# Unit test for function to_json_schema
def test_to_json_schema():
    class ExampleSchema(Schema):
        id = Integer(maximum=100)
        name = String(max_length=32, allow_null=True)
        state = Choice(choices=[(1, "active"), (2, "completed")])
        tags = Array(String(), min_items=1)
        nested = Object(properties={"a": Integer(), "b": Float()})
        reference = Reference("ExampleSchema")
        validation = IfThenElse(
            if_clause=["a", "b"],
            then_clause=Integer(minimum=42),
            else_clause=Float(),
        )
        compound = Union(Integer(), Float()) | Not(Integer(multiple_of=3))


# Generated at 2022-06-12 15:57:11.804756
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import make_validator, SchemaDefinitions, Reference
    from .fields import (
        Integer,
        Float,
        Decimal,
        String,
        Boolean,
        Array,
        Object,
        Choice,
        Const,
        Union,
        OneOf,
        AllOf,
        IfThenElse,
        Not,
    )
    from .validators import validate, ValidationError


# Generated at 2022-06-12 15:57:17.603875
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
        "default": 5,
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_clause.validate(1)
    assert field.then_clause.validate("1")
    assert field.else_clause.validate(1)
    assert field.validate("1")
    assert field.validate(1)
    assert field.validate(5)
    assert not field.validate("not a integer")
    assert not field.validate("")
    assert not field.validate("1.2")
    assert not field.validate("")



# Generated at 2022-06-12 15:57:30.187840
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(allow_null=True)
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(allow_null=True)

# Generated at 2022-06-12 15:57:37.295848
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({'type': 'string'}, type_string='string', allow_null=True), String)
    assert isinstance(from_json_schema_type({'type': 'number'}, type_string='number', allow_null=True), Float)
    assert isinstance(from_json_schema_type({'type': 'integer'}, type_string='integer', allow_null=True), Integer)
    assert isinstance(from_json_schema_type({'type': 'boolean'}, type_string='boolean', allow_null=True), Boolean)
    assert isinstance(from_json_schema_type({'type': 'array'}, type_string='array', allow_null=True), Array)


# Generated at 2022-06-12 15:57:46.091748
# Unit test for function to_json_schema
def test_to_json_schema():
    from .validators import (
        Integer,
        Array,
        Not,
        Object,
        Boolean,
        Choice,
        Const,
        AllOf,
        OneOf,
        Union,
        IfThenElse,
        String,
    )

    s = Object(
        properties={"name": String(allow_blank=False, allow_null=True)},
        additional_properties=False,
    )

    schema = to_json_schema(s)
    assert schema == {
        "type": ["object", "null"],
        "properties": {"name": {"type": ["string", "null"], "minLength": 1}},
        "additionalProperties": False,
    }

    schema = to_json_schema(Union(all_of=[Const("foo"), Not(Const("bar"))]))
   

# Generated at 2022-06-12 15:58:34.951400
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover
    int_field = from_json_schema_type({}, type_string="integer", allow_null=False)
    assert int_field == Integer()

    float_field = from_json_schema_type({}, type_string="number", allow_null=False)
    assert float_field == Float()

    array_field = from_json_schema_type({}, type_string="array", allow_null=False)
    assert array_field == Array()

    object_field = from_json_schema_type({}, type_string="object", allow_null=False)
    assert object_field == Object()

    string_field = from_json_schema_type({}, type_string="string", allow_null=False)
    assert string_field == String()

    boolean_field = from_

# Generated at 2022-06-12 15:58:45.145185
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(dict(type="number"), type_string="number", allow_null=False) == Float()
    assert from_json_schema_type(dict(type="integer"), type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type(dict(type="string"), type_string="string", allow_null=False) == String()
    assert from_json_schema_type(dict(type="boolean"), type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type(dict(type="array"), type_string="array", allow_null=False) == Array()
    assert from_json_schema_type(dict(type="object"), type_string="object", allow_null=False) == Object()

# Generated at 2022-06-12 15:58:53.787257
# Unit test for function to_json_schema
def test_to_json_schema():
    # We can convert a Field to a JSON schema, by walking the
    # structure of the field, and converting each part as appropriate
    field = String(
        description="The name of the user",
        format="email",
        pattern_regex=re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"),
        allow_blank=False,
    )
    schema = to_json_schema(field)

# Generated at 2022-06-12 15:58:56.971967
# Unit test for function from_json_schema
def test_from_json_schema():
    from_json_schema({
        "type": "string",
        "enum": ["foo", "bar"],
        "minLength": 3,
    })

# Generated at 2022-06-12 15:59:07.526272
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string", "minLength": 0}) == String(min_length=0)
    assert from_json_schema({"type": "string"}) == String()

    assert from_json_schema(
        {
            "type": ["integer", "number"],
            "minimum": 1,
            "maximum": 5,
            "multipleOf": 0.1,
        }
    ) == Number(
        type=["integer", "number"],
        minimum=1,
        maximum=5,
        multiple_of=0.1,
    )

    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(
        minimum=1
    )

# Generated at 2022-06-12 15:59:19.146026
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=None)
    from_json_schema_type(data={"type": "object"}, type_string="object", allow_null=False, definitions=None)
    from_json_schema_type(data={"type": "null"}, type_string="null", allow_null=False, definitions=None)
    from_json_schema_type(data={}, type_string="null", allow_null=False, definitions=None)

    from_json_schema_type(data={"type": "number"}, type_string="number", allow_null=False, definitions=None)

# Generated at 2022-06-12 15:59:24.387779
# Unit test for function to_json_schema
def test_to_json_schema():  # type: ignore
    """
    Read the docstring of methods to_json_schema and from_json_schema,
    then run this function to test them.
    """

    schema = Object(
        properties={
            "key": String(max_length=10),
            "number": Integer(minimum=0, exclusive_minimum=True),
            "base": OneOf([String(min_length=1), Integer(min_length=1), Boolean()])
            .with_default("unset"),
            "complex": Object(properties={"foo": Object(properties={})}),
            "stringify": Any(),
        },
        required=["key", "number"],
    )

    encoded = schema.to_json_schema()
    print("JSON encoder test:")

# Generated at 2022-06-12 15:59:30.110794
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["integer", "string"]}) == Union(
        items=[Integer(), String()]
    )
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({"if": {"type": "integer"}, "then": "foo"}) == IfThenElse(
        if_=Integer(), then="foo"
    )



# Generated at 2022-06-12 15:59:39.176801
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions={}) == Integer()
    assert from_json_schema_type({}, type_string="integer", allow_null=True, definitions={}) == Integer(allow_null=True)
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions={}) == Float()
    assert from_json_schema_type({}, type_string="number", allow_null=True, definitions={}) == Float(allow_null=True)
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions={}) == String()

# Generated at 2022-06-12 15:59:51.594443
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        nested: typing.Optional[TestSchema] = None
        named_nested: typing.Optional["TestSchema"] = None
        integer: int = Integer(minimum=0, maximum=4)
        float_number: float = Float(multiple_of=3.0)
        decimal: decimal.Decimal = Decimal(multiple_of=decimal.Decimal("3.14"))
        string: typing.Optional[str] = None
        format_string: typing.Optional[str] = None
        array_string: typing.List[str] = Array(items=String(allow_blank=True))