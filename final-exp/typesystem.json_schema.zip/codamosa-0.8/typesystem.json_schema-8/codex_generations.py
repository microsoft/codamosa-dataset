

# Generated at 2022-06-12 15:51:10.067944
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean"}, True)
    assert get_valid_types({"type": ["null", "boolean", "array"]}) == (
        {"boolean", "array"},
        True,
    )
    assert get_valid_types({"type": ["boolean", "array"]}) == ({"boolean", "array"}, False)

    # number and integer is treated as an union of two fields.
    assert get_valid_types({"type": ["number", "integer"]}) == (
        {"number", "integer"},
        False,
    )

    # If

# Generated at 2022-06-12 15:51:18.601604
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-12 15:51:24.408917
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
	data_1 = {'anyOf': [{'$ref': '#/definitions/Car'}, {"$ref": '#/definitions/Bike'}]}
	assert any_of_from_json_schema(data_1, definitions) == Union(any_of=[Reference(to='#/definitions/Car', definitions=definitions), Reference(to='#/definitions/Bike', definitions=definitions)])



# Generated at 2022-06-12 15:51:27.559989
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(
        AllOf(
            [Any(), Not(AllowNull(Bool())), OneOf([Const("a"), Const("b")])],
            default=list,
        )
    ) == {"allOf": [{}, {"not": {"type": "boolean", "null": True}}, {"oneOf": [{"const": "a"}, {"const": "b"}]}], "default": list}



# Generated at 2022-06-12 15:51:37.348609
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Test that:
    - From a valid json schema value, a proper Field is returned.
    - An invalid json schema value raises an exception.
    - A Field is returned even when the json schema definition is not valid
      (this behavior may change).
    """
    assert type_from_json_schema({'type': 'string'}) == String()
    assert type_from_json_schema({'type': ['string']}) == String()
    assert type_from_json_schema({'type': 'number'}) == Number()
    assert type_from_json_schema({'type': ['number']}) == Number()
    assert type_from_json_schema({'type': 'integer'}) == Integer()
    assert type_from_json_schema({'type': ['integer']}) == Integer()
    assert type_

# Generated at 2022-06-12 15:51:48.580064
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    def check(data, default=None):
        field = all_of_from_json_schema({"allOf": data, "default": default})
        assert isinstance(field, AllOf)
        assert field.all_of == data
        assert field.default == default

    check([Boolean(allow_null=True)])
    check([Boolean(allow_null=False), {"type": "string"}])
    check([Boolean(allow_null=False), {"type": "string"}], "")

    with pytest.raises(AssertionError):
        check([Boolean(allow_null=True), {"type": "string"}])
    with pytest.raises(AssertionError):
        check([])



# Generated at 2022-06-12 15:51:54.311919
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = dict(oneOf=[dict(type="string"), dict(type="integer"), dict(type="number")])
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert 1 == OneOf(**kwargs)(1)
    assert None == OneOf(**kwargs)(None)
    assert 5.0 == OneOf(**kwargs)(5)
    assert 5 == OneOf(**kwargs)(5)
    assert "5" == OneOf(**kwargs)("5")
    assert False == OneOf(**kwargs)(False)


# Generated at 2022-06-12 15:52:03.241337
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {'allOf': [{'$ref': '#/definitions/ref1', 'type': 'string'}, {'type': 'integer'}, {'const': 4}]}
    fieldSchema = all_of_from_json_schema(data, definitions)
    assert len(fieldSchema.all_of) == 3
    assert isinstance(fieldSchema.all_of[0], Field)
    assert isinstance(fieldSchema.all_of[0].schema, String)
    assert isinstance(fieldSchema.all_of[1], Field)
    assert isinstance(fieldSchema.all_of[1].schema, Integer)
    assert isinstance(fieldSchema.all_of[2], Field)
    assert isinstance(fieldSchema.all_of[2].schema, Const)


# Generated at 2022-06-12 15:52:06.293365
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
  assert enum_from_json_schema({"enum": ["red", "green", "blue"]}) == Choice(choices=[("red", "red"), ("green", "green"), ("blue", "blue")])


# Generated at 2022-06-12 15:52:17.435171
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import from_json_schema

    # Check all core type fields
    for field_class in [
        Any,
        AnyOf,
        AllOf,
        Boolean,
        Const,
        OneOf,
        Not,
        IfThenElse,
        Object,
        String,
        Integer,
        Number,
        Decimal,
        Float,
        Array,
        Choice,
        Union,
    ]:
        field = field_class()
        schema = to_json_schema(field)
        field2 = from_json_schema(schema)
        assert field == field2

    # Check strict and non-strict Object
    for field_class in [Object, String]:
        field = field_class(strict=True)
        schema = to_json_schema(field)
       

# Generated at 2022-06-12 15:53:17.197653
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"$ref": "#/definitions/integer"}, {"$ref": "#/definitions/decimal"}]}
    definitions = SchemaDefinitions()
    definitions["integer"] = Integer()
    definitions["decimal"] = Decimal()
    field = any_of_from_json_schema(data, definitions)
    assert list(field.any_of) == [definitions["integer"], definitions["decimal"]]



# Generated at 2022-06-12 15:53:25.153489
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schemas = {
    "$schema": "draft 07",
    "definitions": {
        "schema1": {
            "type": "object",
            "properties": {
                "property1": {"type": "string"},
                "property2": {
                    "type": "object",
                    "properties": {
                        "property3": {"type": "string"},
                        "property4": {"type": "string"},
                    },
                },
            },
        }
    },
    "not": {"$ref": "#/definitions/schema1"},
}
    field = from_json_schema(schemas)
    assert isinstance(field, Not)
    assert field.negated.to == "schema1"
    assert field.default is NO_DEFAULT

# Generated at 2022-06-12 15:53:34.178271
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:53:41.081900
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "integer"},
            {"enum": [1, 2, 3]},
        ]
    }
    field = all_of_from_json_schema(schema, definitions=definitions)
    assert isinstance(field, AllOf), "field is an AllOf"
    assert field.validate(1) == 1



# Generated at 2022-06-12 15:53:45.358910
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    util.assert_equivalent_fields(
        not_from_json_schema({
            "not": {
                "type": "integer",
                "minimum": 5,
                "maximum": 10
            }
        }),
        Not(
            constrained=Integer(minimum=5, maximum=10)
        )
    )



# Generated at 2022-06-12 15:53:49.881904
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
   assert not IfThenElse(if_clause=Boolean(True), then_clause=None, else_clause=None).validate(None)
   assert not IfThenElse(if_clause=Boolean(True), then_clause=None, else_clause=None).validate(1)
   assert IfThenElse(if_clause=Boolean(True), then_clause=None, else_clause=None).validate(True)

# Generated at 2022-06-12 15:53:54.943465
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/A"] = String()
    data = {"$ref": "#/definitions/A"}
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-12 15:54:01.700399
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.schemas import Reference
    from typesystem.fields import Field

    class Sample(Field):
        pass

    data = {"$ref": "#/path"}
    definitions = SchemaDefinitions()
    definitions["#/path"] = Sample
    assert from_json_schema_type(data, "string", True, definitions) == Reference(
        "#/path"
    )

    data = {"oneOf": [{}, {}]}
    assert isinstance(
        from_json_schema_type(data, "string", True, definitions), OneOf
    )



# Generated at 2022-06-12 15:54:08.505748
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "number"}, None) == Number()

    schema = {
        "type": [
            "integer",
            "number",
        ],
    }
    expected = Union(
        any_of=[
            Integer(),
            Number(),
        ]
    )
    actual = type_from_json_schema(schema, None)
    assert actual == expected

    schema = {
        "type": [
            "integer",
            "number",
        ],
        "minimum": 10,
    }
    expected = Union(
        any_of=[
            Integer(minimum=10),
            Number(minimum=10),
        ]
    )
    actual = type_from_json_schema(schema, None)
    assert actual == expected


# Generated at 2022-06-12 15:54:14.761556
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"const": "foo"},
        "then": {"const": True},
        "else": {"const": False},
    }
    result = if_then_else_from_json_schema(data, definitions={})
    # Strict equality
    assert result == IfThenElse(
        if_clause=Const(const="foo"),
        then_clause=Const(const=True),
        else_clause=Const(const=False),
    )



# Generated at 2022-06-12 15:55:01.202130
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=None) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=None) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=None) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=None) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=None) == Object()
    assert (
        type_from_json_schema({"type": "array"}, definitions=None)
        == Array(items=Any())
    )
    assert type_from_json_sche

# Generated at 2022-06-12 15:55:09.922502
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "integer",
            "minimum": 0
        },
        "then": {
            "type": ["integer", "string"],
            "minimum": 0
        },
        "else": {
            "type": "integer",
            "maximum": 0
        }
    }
    definitions = SchemaDefinitions()
    actual = if_then_else_from_json_schema(data, definitions)
    expected = IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Union(any_of=[Integer(minimum=0), String()]),
        else_clause=Integer(maximum=0),
    )
    assert actual == expected, f"IF THEN ELSE Field not as expected: expected={expected}, but got {actual}"



# Generated at 2022-06-12 15:55:15.983844
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({
        'enum': ['A','B','C','D','E'],
        'default': 'C'
    }) == Choice(choices=[('A','A'),('B','B'),('C','C'),('D','D'),('E','E')],default='C')
    assert enum_from_json_schema({
        'enum': ['A','B','C','D','E']
    }) == Choice(choices=[('A','A'),('B','B'),('C','C'),('D','D'),('E','E')])



# Generated at 2022-06-12 15:55:22.836821
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema_example='{"enum": [true, false, null]}'
    data_example='true'
    data_example2='false'
    data_example3='null'
    assert enum_from_json_schema(schema_example,data_example).validate(data_example) == True
    assert enum_from_json_schema(schema_example,data_example).validate(data_example2) == True
    assert enum_from_json_schema(schema_example,data_example).validate(data_example3) == True



# Generated at 2022-06-12 15:55:34.355229
# Unit test for function to_json_schema
def test_to_json_schema():
    case_1 = Any()
    assert to_json_schema(case_1) == True

    case_2 = NeverMatch()
    assert to_json_schema(case_2) == False

    case_3 = String(
        pattern_regex=set_regex
    )  # Why this pattern regex? Because it has a flag set.

    assert to_json_schema(case_3) == {
        "type": "string",
        "pattern": "{[^}]*}",
    }

    case_4 = String(min_length=2, max_length=3)
    assert to_json_schema(case_4) == {
        "type": "string",
        "minLength": 2,
        "maxLength": 3,
    }

    case_5 = String(format="uri")

# Generated at 2022-06-12 15:55:42.242956
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, 2, 3], "default": 1}
    field = enum_from_json_schema(data=data, definitions=None)

    assert field.validate(1)
    assert field.validate(2)
    assert field.validate(3)
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(3) == 3
    assert field.validate('') == 'Field is required'
    assert field.validate('3') == 'Value not one of expected choices'



# Generated at 2022-06-12 15:55:50.916554
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "properties": {"foo": {"const": "bar"}},
            "required": ["foo"],
            "additionalProperties": False,
        },
        "then": {
            "type": "number",
            "minimum": 0,
            "maximum": 100,
        },
        "else": {
            "const": None,
        },
    }
    schema = from_json_schema(data)
    # For the following:
    #  - 1   is valid
    #  - -2  is invalid (not in the range [0, 100])
    #  - bar is invalid (not a number)
    #  - {}  is invalid (missing key foo)
    #  - {'foo': 'bar', 'baz':'quux'}  is invalid (additional

# Generated at 2022-06-12 15:56:03.249520
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "TestAllOfSchema",
        "type": "object",
        "properties": {"foo": {"type": "string"}},
        "allOf": [
            {"$ref": "#/definitions/TestSchema"},
            {"properties": {"bar": {"type": "number", "minimum": 2, "maxmimum": 20}}}
        ],
        "definitions": {
            "TestSchema": {
                "type": "object",
                "properties": {
                    "foo": {"type": "string", "pattern": "^[0-9]+$"}
                }
            }
        }
    }
    field = from_json_schema(data)

# Generated at 2022-06-12 15:56:09.861249
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Method to test function enum_from_json_schema for string
    def do_test_string(enum_field):
        # Create a field based on the enum_field
        field = enum_from_json_schema(enum_field, definitions=definitions)

        # Check that field is a choice
        assert isinstance(field, Choice)

        # Check that choices is the enum field
        assert field.choices == enum_field['enum']

        # Check that default is the enum field
        assert field.default == enum_field.get("default")

    # Method to test function enum_from_json_schema for number
    def do_test_number(enum_field):
        # Create a field based on the enum_field
        field = enum_from_json_schema(enum_field, definitions=definitions)

        # Check

# Generated at 2022-06-12 15:56:13.464585
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum':[1, 2, 3], 'default':1}, None)
    assert not enum_from_json_schema({'enum':[1, 2, 3], 'default':4}, None)



# Generated at 2022-06-12 15:57:22.044916
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
                {"type": "string", "enum": ["foo"]},
                {"type": "string", "enum": ["bar", "baz"]}
            ]
    }
    definitions = SchemaDefinitions()
    one_of = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(one_of, OneOf)
    assert one_of.one_of == [Union(any_of=[String(enum=["foo"])]), Union(any_of=[String(enum=["bar"]), String(enum=["baz"])])]



# Generated at 2022-06-12 15:57:29.411234
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema
    one_of = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(one_of, OneOf)
    assert isinstance(one_of.one_of[0], Integer)
    assert isinstance(one_of.one_of[1], String)



# Generated at 2022-06-12 15:57:37.136263
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}

    assert to_json_schema(String(example="")) == {"type": "string", "example": ""}

    assert to_json_schema(String(example="", description="")) == {
        "type": "string",
        "example": "",
        "description": "",
    }

    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}

    assert to_json_schema(String(max_length=5)) == {
        "type": "string",
        "maxLength": 5,
    }


# Generated at 2022-06-12 15:57:44.103263
# Unit test for function to_json_schema
def test_to_json_schema():
    definition = def_schema({"name": String()})
    field = definition.make_validator()
    data = to_json_schema(field)
    assert data == {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "additionalProperties": False,
        "minProperties": 1,
        "maxProperties": 1,
        "required": ["name"],
    }
    assert "definitions" not in data

# Generated at 2022-06-12 15:57:50.046521
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    Test if_then_else_from_json_schema
    """
    schema = {
          "if": {
            "type": "string"
          },
          "then": {
            "const": "Then"
          },
          "else": {
            "const": "Else"
          },
          "default":"Default"
        }
    schema_field = if_then_else_from_json_schema(schema, None)
    assert isinstance(schema_field, IfThenElse)
    assert schema_field.default=="Default"
    assert schema_field.if_clause.data_type=="string"
    assert isinstance(schema_field.then_clause, Const)
    assert isinstance(schema_field.else_clause, Const)

# Generated at 2022-06-12 15:57:57.659799
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Integer()
    assert to_json_schema(field) == {"type": ["integer", "null"], "allowNull": True}
    assert to_json_schema(field, _definitions={}) == {"type": ["integer", "null"], "allowNull": True}
    assert (to_json_schema(field) == to_json_schema(field, _definitions={}))

    field = Integer(default=5)
    assert to_json_schema(field) == {"type": ["integer", "null"], "allowNull": True, "default": 5}
    assert (to_json_schema(field) == to_json_schema(field, _definitions={}))

    field = Object(
        properties={"foo": Integer()},
    )

# Generated at 2022-06-12 15:58:08.546769
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'type': 'string', 'const': 'John'}, {'type': 'string', 'const': 'Mike'}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.__class__.__name__ == 'OneOf'
    assert field.default == NO_DEFAULT
    assert field.one_of[0].__class__.__name__ == 'Const'
    assert field.one_of[0].const == 'John'
    assert field.one_of[1].__class__.__name__ == 'Const'
    assert field.one_of[1].const == 'Mike'


# Generated at 2022-06-12 15:58:18.456521
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:58:25.929561
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema(False), NeverMatch)
    assert isinstance(from_json_schema(True), Any)

    assert isinstance(from_json_schema({"$ref": "#/definitions/foo"}), Reference)

    assert isinstance(from_json_schema({"enum": [6]}), Choice)
    assert isinstance(from_json_schema({"const": 6}), Const)
    assert isinstance(from_json_schema({"allOf": [6]}), AllOf)
    assert isinstance(from_json_schema({"anyOf": [6]}), OneOf)
    assert isinstance(from_json_schema({"oneOf": [6]}), OneOf)
    assert isinstance(from_json_schema({"not": 6}), Not)
   

# Generated at 2022-06-12 15:58:28.505416
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
  assert issubclass(one_of_from_json_schema({"oneOf":[{"const":"Wonders"}]}, SchemaDefinitions()), Schema)


# Generated at 2022-06-12 15:59:39.391827
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema
    from .types import String, Integer, Array

    class Person(Schema):
        first_name = String(
            min_length=1, max_length=64, allow_blank=False, default="John"
        )
        last_name = String(
            min_length=1, max_length=64, allow_blank=False, default="Doe"
        )
        age = Integer(minimum=0, exclusive_minimum=True, maximum=120)
        children = Array(
            Field(
                name="Child",
                allow_null=True,
                properties={"name": String(allow_null=True, allow_blank=True)},
            ),
            default=["Jack", "Jill"],
        )

    data = to_json_schema(Person)

# Generated at 2022-06-12 15:59:47.614848
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test function from_json_schema_type
    """
    with open("tests/json_schemas/image.json", "r") as file:
        json_schema = json.load(file)

    type_ = from_json_schema_type(
        data=json_schema,
        type_string="object",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    assert isinstance(type_, Object)



# Generated at 2022-06-12 15:59:53.237004
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
           "const": 5
        },
        "then": {
            "type": "string"
        },
        "else": {
            "type": "number"
        }
    }
    field = if_then_else_from_json_schema(data, SchemaDefinitions())
    assert field.validate(5) == "5"
    assert field.validate(10) == 10

# Generated at 2022-06-12 15:59:59.693008
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields as f

    schema = f.Object(properties={"foo": f.String(pattern_regex=re.compile(r"^wow$"))})
    result = to_json_schema(schema)
    assert result == {
        "type": "object",
        "properties": {
            "foo": {"type": "string", "pattern": "^wow$"},
        },
    }

    schema = f.String(
        max_length=123,
        pattern_regex=re.compile(r"^wow$", flags=re.RegexFlag.UNICODE),
    )
    result = to_json_schema(schema)
    assert result == {
        "type": "string",
        "maxLength": 123,
        "pattern": "^wow$",
    }



# Generated at 2022-06-12 16:00:04.658650
# Unit test for function to_json_schema
def test_to_json_schema():

    # Test simple type
    schema = Integer(minimum=10)
    json_schema = to_json_schema(schema)
    expected = {"type": "integer", "minimum": 10}
    assert json_schema == expected

    # Test multiple types
    schema = Union(Integer(minimum=10), Float(), Decimal("1.1"))
    json_schema = to_json_schema(schema)
    expected = {
        "anyOf": [{"type": "integer", "minimum": 10}, {"type": "number"}],
        "type": ["integer", "number"],
    }
    assert json_schema == expected

    # Test definitions

# Generated at 2022-06-12 16:00:13.983251
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(None) == False
    assert to_json_schema(Any()) == True
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(null_allowed=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
