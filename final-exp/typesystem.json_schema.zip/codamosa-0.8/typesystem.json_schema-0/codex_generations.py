

# Generated at 2022-06-12 15:51:32.814094
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "not": {"oneOf":[{"type":"integer"},{"type":"number"}]},
        "default": NO_DEFAULT
    }
    assert isinstance(one_of_from_json_schema(data, None), OneOf)



# Generated at 2022-06-12 15:51:38.108716
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "string",
        "enum": ["b", "c", "d"],
        "default": "c"
    }
    result = enum_from_json_schema(schema, None)
    assert isinstance(result, Choice)
    assert result.default == "c"
    assert result.choices == [("b", "b"), ("c", "c"), ("d", "d")]



# Generated at 2022-06-12 15:51:50.296431
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import types
    from typesystem.decorators import one_of
    from typesystem.fields import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Date,
        DateTime,
        Decimal,
        Dict,
        Field,
        Float,
        Integer,
        Number,
        Object,
        String,
    )
    from typesystem.schemas import Schema
    from typesystem.tools import (
        not_from_json_schema,
        one_of_from_json_schema,
        type_from_json_schema,
    )

    schema = Schema(properties={"foo": Any(), "bar": Any()})


# Generated at 2022-06-12 15:52:01.157799
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "x": {"if": {"type": "integer"}, "then": {"type": "integer"}, "else": {"type": "string"}},
            "y": {"if": {"type": "string"}, "then": {"type": "string"}},
            "z": {"if": {"type": "string"}, "then": {"type": "string"}, "else": {"type": "integer"}},
        },
    }
    field = from_json_schema(schema)
    assert_valid(field, {"x": 1, "y": "bla", "z": "bla"})

# Generated at 2022-06-12 15:52:07.113569
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"minLength": 3}) == String(min_length=3)
    assert from_json_schema({"maxLength": 3}) == String(max_length=3)
    assert from_json_schema({"enum": ["a", "b"]}) == Choice(["a", "b"])
    assert from_json_schema({"maximum": 3}) == Number(maximum=3)
    assert from_json_schema({"exclusiveMaximum": 3}) == Number(exclusive_maximum=3)

# Generated at 2022-06-12 15:52:11.631072
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {}
    data["if"] = {"type": "string"}
    data["then"] = {"enum": ["foo", "bar"]}
    data["else"] = {"const": 123}
    field = if_then_else_from_json_schema(data=data, definitions=None)
    assert isinstance(field, IfThenElse)



# Generated at 2022-06-12 15:52:23.466169
# Unit test for function to_json_schema
def test_to_json_schema():
    settings = ValidatorSettings()
    settings.allow_blank = False  # pragma: no cover
    settings.allow_null = False  # pragma: no cover

    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
    }  # noqa
    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["integer", "null"],
        "default": NO_DEFAULT,
    }  # noqa
    assert to_json_schema(Integer(settings=settings)) == {
        "type": "integer",
        "default": NO_DEFAULT,
        "minLength": 1,
    }  # noqa

# Generated at 2022-06-12 15:52:27.569439
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema([
        {
            'type': 'number',
            'minimum': 13
        },
        {
            'type': 'number',
            'maximum': 13
        }
    ], None), Union)
    

# Generated at 2022-06-12 15:52:29.595480
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {"$ref": "#/definitions/NonNegativeInteger"}
    field = ref_from_json_schema(schema)
    assert isinstance(field, Reference)



# Generated at 2022-06-12 15:52:33.571730
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data_all_of = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
            {"maxLength": 512},
        ],
        "default": 'test',
    }
    assert all_of_from_json_schema(data_all_of, definitions=definitions) == AllOf([
        String(allow_blank=False, min_length=1, max_length=512),
        String(allow_blank=False, min_length=1, max_length=512),
        String(allow_blank=False, min_length=1, max_length=512)
    ], default='test')



# Generated at 2022-06-12 15:52:58.415748
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert(one_of_from_json_schema({'oneOf': [{'const': True, 'title': 'True'}, {'const': False, 'title': 'False'}]}, SchemaDefinitions()) == OneOf(one_of=[Const(const=True, title='True'), Const(const=False, title='False')]))


# Generated at 2022-06-12 15:53:10.217871
# Unit test for function to_json_schema
def test_to_json_schema():
    class Param(Schema):
        name = String(max_length=None)
        value = String(max_length=None, allow_null=True)

    class OneOfProperty(Schema):
        prop_a = String(max_length=None)
        prop_b = String(max_length=None)

    class MultipleOfProperty(Schema):
        prop = Integer(multiple_of=17)

    class NameSchema(Schema):
        name = String(max_length=None)

    class ObjectWithPatterns(Schema):
        _pattern_re = re.compile("^foo.*$")
        _pattern_field = String(max_length=None)
        _pattern_fields = Array(items=String(max_length=None))

        other = String(max_length=None)


# Generated at 2022-06-12 15:53:14.089068
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/x'}), Reference)
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/x'}).to, str)
    assert ref_from_json_schema({'$ref': '#/definitions/x'}).to == '#/definitions/x'



# Generated at 2022-06-12 15:53:19.040749
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from_json_schema({'allOf': [{'type': 'integer', 'minimum': 1, 'maximum': 5}, {'type': 'integer', 'minimum': 4, 'maximum': 10}]})
    assert True



# Generated at 2022-06-12 15:53:25.552560
# Unit test for function to_json_schema
def test_to_json_schema():
    expected_schema_data = {
        "allOf": [
            {"$ref": "#/definitions/ordinal"},
            {
                "type": "integer",
                "minimum": 1,
                "maximum": 12,
            },
        ],
        "definitions": {
            "ordinal": {
                "type": ["null", "integer"],
                "default": 1,
            },
        },
    }

    class OrdinalSchema(Schema):
        def make_validator(self) -> Field:
            return Integer(
                default=1, allow_null=True, min_value=1, max_value=12
            )

    ordinal_field = Integer(default=1, allow_null=True, min_value=1, max_value=12)
    actual_schema_data = to_

# Generated at 2022-06-12 15:53:26.748854
# Unit test for function from_json_schema
def test_from_json_schema():
    # TODO
    raise NotImplementedError()



# Generated at 2022-06-12 15:53:34.182822
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "number"}}
    definitions = None
    negated = from_json_schema(data["not"], definitions=definitions)
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    assert Not(**kwargs).validate(1.0) == False
    assert Not(**kwargs).validate(2.0) == False
    assert Not(**kwargs).validate(None) == False
    assert Not(**kwargs).validate("hi") == True
    assert Not(**kwargs).validate(True) == True



# Generated at 2022-06-12 15:53:42.831557
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'type': 'integer'}, {'type': 'array', 'items': {'type': 'string'}}, {'type': 'string'}]}
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert isinstance(OneOf(**kwargs), OneOf)


# Generated at 2022-06-12 15:53:47.468820
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "string",
            },
        },
    }
    t = from_json_schema(data)
    data = {"not": data}
    u = not_from_json_schema(data)
    assert t == Not(negated=u.negated)



# Generated at 2022-06-12 15:53:54.384209
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Test function ref_from_json_schema.

    """
    ref = "http://json-schema.org/draft-07/schema#"
    data = {"$ref": ref}
    definitions = SchemaDefinitions()
    field = ref_from_json_schema(data, definitions=definitions)
    assert field.to == ref



# Generated at 2022-06-12 15:54:18.500792
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 0}) == String()
    assert from_json_schema({"type": "integer"}).type_name == "integer"
    assert from_json_schema({"type": "number"}).type_name == "number"
    assert from_json_schema({"type": "object"}).type_name == "object"
    assert from_json_schema({"type": "object", "properties": {"foo": None}}) == Object(
        properties={"foo": Any()}
    )
    assert from_json_schema({"type": "array"}).type_name == "array"

# Generated at 2022-06-12 15:54:26.438410
# Unit test for function from_json_schema
def test_from_json_schema():  # type: ignore
    data = {
        "type": "string",
        "minLength": 5,
        "maxLength": 10,
    }

    actual = from_json_schema(data)
    expected = String(min_length=5, max_length=10)

    assert actual.validate("10") is True
    assert actual.validate("100") is False
    assert actual.validate("abcdef") is True
    assert actual.validate("abcdefghij") is True
    assert actual.validate("abcdefghijk") is False
    assert actual.validate(10.0) is False

    assert actual == expected


# Generated at 2022-06-12 15:54:37.885608
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Integer(multiple_of=2)) == {"type": "integer", "multipleOf": 2}
    assert to_json_schema(Integer(multiple_of=2, options=[(1, 1), (2, 2)])) == {
        "type": "integer",
        "multipleOf": 2,
        "enum": [1, 2],
    }
    assert to_json_schema(Integer(options=[(1, 1), (2, 2)])) == {
        "type": "integer",
        "enum": [1, 2],
    }

# Generated at 2022-06-12 15:54:43.527498
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Integer(minimum=1),
        then_clause=Integer(minimum=2, maximum=3),
        else_clause=Integer(minimum=4, maximum=5),
    ) == IfThenElse(
        if_clause=Integer(minimum=1),
        then_clause=Integer(minimum=2, maximum=3),
        else_clause=Integer(minimum=4, maximum=5),
    )


# Generated at 2022-06-12 15:54:51.938271
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:54:58.127107
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "null",
        "type": "boolean",
        "type": "object",
        "type": "array",
        "type": "number",
        "type": "integer",
        "type": "string"
    }
    for key, value in data.items():
        field = from_json_schema_type(value, key, True)
        assert field



# Generated at 2022-06-12 15:55:01.884138
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type":"string","multipleOf":2}]}
    assert isinstance(any_of_from_json_schema(data, None), Union)



# Generated at 2022-06-12 15:55:06.336749
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = JSONSchema.validate({"not": {"type": "number"}})
    negated = from_json_schema(data["not"], definitions=definitions)
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    assert kwargs == {'negated': Float(), 'default': NO_DEFAULT}
    assert Not(**kwargs) == Not(negated=Float())


# Generated at 2022-06-12 15:55:11.625671
# Unit test for function to_json_schema
def test_to_json_schema():
    from .unit_test import to_json_schema_test_cases

    for test_case in to_json_schema_test_cases:
        if isinstance(test_case, SchemaDefinitions):
            schema = test_case
        else:
            schema = from_json_schema(test_case)
        converted = to_json_schema(schema)
        assert test_case == converted

# Generated at 2022-06-12 15:55:20.502681
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="any", allow_null=False) == Any()
    assert from_json_schema_type({}, type_string="any", allow_null=True) == Const(None)

    assert from_json_schema_type({}, type_string="null", allow_null=False) == NeverMatch()
    assert from_json_schema_type({}, type_string="null", allow_null=True) == Const(None)

    assert from_json_schema_type({}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Const(None)

    assert from_json_schema_type({}, type_string="integer", allow_null=False)

# Generated at 2022-06-12 15:56:01.989743
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "minLength": 0,
        "const": "",
    }) == String(min_length=0, const="")

    assert isinstance(from_json_schema({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "enum": ["", " "],
    }), Union)



# Generated at 2022-06-12 15:56:08.792626
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    class ExampleSchema(SchemaDefinitions):
        class Meta(SchemaDefinitions.Meta):  # noqa: D106
            field_definitions = {
                "simple_integer": Integer(),
                "simple_object": Object(
                    properties={
                        "name": String(min_length=1),
                        "value": Integer(minimum=0),
                    }
                ),
            }

        class Test(Schema):
            """Test."""

            required_string = String(min_length=1)
            not_required_string = String()
            required_integer = Integer(
                minimum=0, multiple_of=2, exclusive_maximum=10,
            )
            not_required_integer = Integer()

# Generated at 2022-06-12 15:56:16.099434
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(
        IfThenElse(
            if_clause=(String()),
            then_clause=Choice(choices=[("foo", "foo"), ("bar", "bar")]),
        )
    )
    assert data == {
        "type": "object",
        "properties": {
            "if": {
                "type": "string",
            },
            "then": {
                "type": "string",
                "enum": ["foo", "bar"],
            },
        },
    }



# Generated at 2022-06-12 15:56:21.317618
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_schema = yaml.safe_load(
    """
    not:
      type: object
      properties:
        foo:
          type: string
      required:
        - foo
    """
    )
    field = not_from_json_schema(not_schema, definitions=None)
    print(field)
test_not_from_json_schema()


# Generated at 2022-06-12 15:56:26.739215
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False, definitions={}) == Integer()

    # Missing 'type' property
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions={}) == Integer()

    # Invalid 'type' property
    assert from_json_schema_type({}, type_string="decimal", allow_null=False, definitions={}) == Integer()

    # 'allow_null' is True
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True, definitions={}) == Integer(allow_null=True)



# Generated at 2022-06-12 15:56:34.799561
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number"), Field)
    assert isinstance(from_json_schema_type({}, "integer"), Field)
    assert isinstance(from_json_schema_type({}, "string"), Field)
    assert isinstance(from_json_schema_type({}, "boolean"), Field)
    assert isinstance(from_json_schema_type({}, "array"), Field)
    assert isinstance(from_json_schema_type({}, "object"), Field)



# Generated at 2022-06-12 15:56:44.609179
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)

    data = {"type": ["string", "number"]}
    assert type_from_json_schema(data, SchemaDefinitions()) == Union(
        any_of=[String(), Number()]
    )
    data = {"type": ["string", "integer"]}

# Generated at 2022-06-12 15:56:50.860350
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field = not_from_json_schema({
        "not": {"type": "string"},
        "default": "hello"
    })
    assert field.default == "hello"
    assert field.asdict() == {
        "negated": {"type": "string"},
        "default": "hello"
    }



# Generated at 2022-06-12 15:56:59.990937
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    schema_a = Schema(
        name=String(max_length=20, example="John Doe"),
        age=Integer(minimum=21, multiple_of=3, example=42),
        email=String(format="email", example="john.doe@company.com"),
        starsign=Choice(
            [
                ("aries", "Aries"),
                ("taurus", "Taurus"),
                ("gemini", "Gemini"),
                ("cancer", "Cancer"),
            ],
            example="aries",
        ),
    )


# Generated at 2022-06-12 15:57:05.041893
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field = type_from_json_schema({'type': []}, definitions={})
    assert isinstance(field, Union)
    field = type_from_json_schema({'type': ['null']}, definitions={})
    assert field.allow_null


# Generated at 2022-06-12 15:57:31.296964
# Unit test for function to_json_schema
def test_to_json_schema():
    from .builder import String, Integer, Float, Decimal, Boolean, Array, Object, Choice
    from .builder import Const, Union, OneOf, AllOf, Not, IfThenElse
    from .builder import Schema, field, ref

    any_field = Any()
    never_field = NeverMatch()
    string_field = String()
    int_field = Integer()
    float_field = Float()
    decimal_field = Decimal()
    bool_field = Boolean()
    array_field = Array()
    object_field = Object()
    choice_field = Choice()
    const_field = Const()
    union_field = Union()
    one_of_field = OneOf()
    all_of_field = AllOf()
    not_field = Not()
    if_then_else_field = IfThenElse()
    schema

# Generated at 2022-06-12 15:57:37.134315
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type(from_json_schema_type({"type": "string", "minLength": 1}, "string", True, {})) == String
    assert type(from_json_schema_type({"type": "integer", "minimum": 1}, "integer", True, {})) == Integer



# Generated at 2022-06-12 15:57:46.066349
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        '$schema': 'http://json-schema.org/draft-04/schema#',
        'definitions': {
            'number': {'type': 'number'},
            'string': {'type': 'string'},
        },
        'properties': {
            'my_number': {'$ref': '#/definitions/number'},
            'my_string': {'$ref': '#/definitions/string'},
            'my_string_without_slash_definitions_string': {'$ref': '#definitions/string'},
        }
    }
    assert Reference(to='#/definitions/string', definitions=definitions) == ref_from_json_schema(schema['properties']['my_string'], definitions)

# Generated at 2022-06-12 15:57:54.888955
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.from_json_schema import from_json_schema
    from typesystem.from_json_schema import to_json_schema


# Generated at 2022-06-12 15:58:06.503956
# Unit test for function not_from_json_schema

# Generated at 2022-06-12 15:58:15.562682
# Unit test for function to_json_schema
def test_to_json_schema():
    from .validators import Schema, String

    class Address(Schema):
        street = String().required().max_length(100)
        city = String().required().max_length(100)
        zip_code = String().max_length(10)

    class User(Schema):
        id = String().required()
        name = String().required()
        agency = String().required().one_of(
            String().pattern_regex(r"\d{3}"), String().pattern_regex(r"\d{4}")
        )
        address = Address()
        notes = String().allow_null()


# Generated at 2022-06-12 15:58:20.917487
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    x = {"not": {"type": "boolean"}}
    assert not_from_json_schema(x, definitions=definitions).serialize() == {"__not": [{"__boolean": {}}]}

    x = {"not": {"type": "boolean", "default": True}}
    assert not_from_json_schema(x, definitions=definitions).serialize() == {"__not": [{"__boolean": {}}], "default": True}

    x = {"not": {"type": "boolean", "default": False}}
    assert not_from_json_schema(x, definitions=definitions).serialize() == {"__not": [{"__boolean": {}}], "default": False}



# Generated at 2022-06-12 15:58:27.291926
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "format": "regex",
        "pattern": r"\d+"
    }
    field = from_json_schema_type(data, "string", allow_null=False, definitions=None)
    assert field.to_json_schema() == data

    data = {
        "type": "integer",
        "multipleOf": 2,
        "minimum": 1,
        "maximum": 10,
        "exclusiveMinimum": 5,
        "exclusiveMaximum": 5,
    }
    field = from_json_schema_type(data, "integer", allow_null=False, definitions=None)
    assert field.to_json_schema() == data


# Generated at 2022-06-12 15:58:35.350542
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test with a positive integer
    positive_integer_schema = {
        "type": "object",
        "properties" : {
            "input" : {
                "type": "integer",
                "minimum" : 0
            }
        }
    }
    negated_field = not_from_json_schema(positive_integer_schema, definitions=definitions)
    assert negated_field.validate("input", 1) is not None
    assert negated_field.validate("input", -1) is None
    # Test with a string
    string_schema = {
        "type": "object",
        "properties" : {
            "input" : {
                "type": "string",
                "minLength" : 2
            }
        }
    }
    negated_field = not_from

# Generated at 2022-06-12 15:58:38.730828
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/test_schema'}
    field = ref_from_json_schema(data, definitions)
    assert isinstance(field, typesystem.fields.Reference)



# Generated at 2022-06-12 15:59:00.242775
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    This test is extracted from the JSON Schema Draft 7 test suite.
    """

# Generated at 2022-06-12 15:59:09.166644
# Unit test for function to_json_schema
def test_to_json_schema():
    """
        Note: This test is not exhaustive.
    """
    assert to_json_schema(Integer) == {"type": "integer", "default": NO_DEFAULT}

    source = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "default": ""},
            "age": {"type": "integer", "minimum": 0, "default": 0},
        },
        "required": ["name"],
    }
    schema = Schema.from_json_schema(source)
    target = to_json_schema(schema)
    assert target == source


# Generated at 2022-06-12 15:59:19.307416
# Unit test for function not_from_json_schema

# Generated at 2022-06-12 15:59:22.490198
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "mode": {
                "type": "string",
                "enum": ["a", "b"]
            }
        }
    }
    result = not_from_json_schema(schema, definitions=None)
    assert isinstance(result, Not)
    assert result.negated.choices==[("a","a"),("b","b")]



# Generated at 2022-06-12 15:59:26.777813
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string in ["number", "integer", "string", "boolean", "array", "object"]:
        _ = from_json_schema_type(
            data={"type": type_string, "default": NO_DEFAULT},
            type_string=type_string,
            allow_null=False,
        )



# Generated at 2022-06-12 15:59:36.933705
# Unit test for function to_json_schema
def test_to_json_schema():

    import json
    from .things import Person
    from .test_fields import choose, person  # noqa

    person_field = person()
    person_schema = to_json_schema(Person)

# Generated at 2022-06-12 15:59:43.335938
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    number_data = {
        "$schema": "http://json-schema.org/draft-07/schema",
        "type": "number",
        "default": 0,
    }
    number_field = from_json_schema_type(number_data, "number", False, SchemaDefinitions())
    assert type(number_field) is Float
    assert number_field.default == 0
    with pytest.raises(AssertionError):
        from_json_schema_type(number_data, "number", True, SchemaDefinitions())

    simple_field = from_json_schema_type(
        {"type": "string", "format": "url"}, "string", False, SchemaDefinitions()
    )
    assert type(simple_field) is String

# Generated at 2022-06-12 15:59:54.037776
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(None) == {"type": "null", "default": None}

    # Use dummy class for testing, since we have no static type checking here.
    class DummyField(Field):

        def _validate(self, value: typing.Any, path: Path) -> typing.Any:
            pass

    dummy_field = DummyField(
        allow_null=True, minimum=5.5, maximum=6.5, exclusive_minimum=6.0
    )

    assert to_json_schema(dummy_field) == {
        "type": ["number", "null"],
        "minimum": 5.5,
        "maximum": 6.5,
        "exclusiveMinimum": 6.0,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-12 16:00:01.088317
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema_data = {"not": {"const": "hello"}}
    json_schema = from_json_schema(schema_data)
    assert not json_schema.validate("hello")
    assert json_schema.validate("world")

    schema_data = {"not": {"type": "string"}}
    json_schema = from_json_schema(schema_data)
    assert not json_schema.validate("hello")
    assert json_schema.validate(None)



# Generated at 2022-06-12 16:00:07.295615
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    document = {'definitions': {'test': {'$ref': '#/definitions/test'}}}
    field = from_json_schema(document)
    assert field.to().to() == '#/definitions/test'
    assert field.definitions['#/definitions/test'].to() == '#/definitions/test'
