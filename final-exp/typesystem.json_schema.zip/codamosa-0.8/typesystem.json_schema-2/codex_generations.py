

# Generated at 2022-06-12 15:51:06.529750
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any(allow_null=True, default="foo")) == {
        "$schema": "http://json-schema.org/draft/2019-09/schema#",
        "type": ["string", "null"],
        "default": "foo",
    }
    assert to_json_schema(Any(allow_null=False, default="foo")) == {
        "$schema": "http://json-schema.org/draft/2019-09/schema#",
        "type": "string",
        "default": "foo",
    }

# Generated at 2022-06-12 15:51:16.144145
# Unit test for function to_json_schema
def test_to_json_schema():
    arg = from_json_schema({
        "type": "object",
        "properties": {
            "integer": {"type": "integer"},
            "boolean": {"type": "boolean"},
            "string": {"type": "string"},
            "nullable_string": {"type": ["string", "null"]}
        }
    })
    result = to_json_schema(arg)

# Generated at 2022-06-12 15:51:26.557316
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def test_then_else(if_clause, then_clause, else_clause, value, expected):
        json_schema = {'if': if_clause, 'then': then_clause, 'else': else_clause}

        field = if_then_else_from_json_schema(json_schema, None)
        assert field.deserialize(value) == expected

    # then
    test_then_else(
        {'const': 1},
        {'const': 2},
        None,
        1,
        2
    )

    # else
    test_then_else(
        {'const': 1},
        None,
        {'const': 2},
        2,
        2
    )

    # neither

# Generated at 2022-06-12 15:51:36.578143
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=Float()) == if_then_else_from_json_schema(
        {"if": {"type": "integer"}, "then": {"type": "string"}, "else": {"type": "number"}}
    )

    assert IfThenElse(if_clause=Integer(), then_clause=String()) == if_then_else_from_json_schema(
        {"if": {"type": "integer"}, "then": {"type": "string"}}
    )
    assert IfThenElse(if_clause=Integer(), else_clause=String()) == if_then_else_from_json_schema(
        {"if": {"type": "integer"}, "else": {"type": "string"}}
    )


JSONSchemaDraft07

# Generated at 2022-06-12 15:51:41.255655
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "integer", "minimum": 0}) == Integer(minimum=0)
    assert from_json_schema({"type": "integer", "enum": [0]}) == Choice(
        items=[Const(0)]
    )
    assert from_json_schema({"type": "integer", "const": 0}) == Const(0)
    assert from_json_schema({"type": "integer", "const": 0, "exclusiveMaximum": 1}) == AllOf(
        [Const(0), Field(maximum=1, exclusive_maximum=True)]
    )

    # $ref
    defs = SchemaDefinitions()

# Generated at 2022-06-12 15:51:45.930975
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    print("\n======================Begin test_all_of_from_json_schema()======================")
    a_field1 = Array(items=Integer())
    a_field2 = Array(items=Integer())
    a_field3 = Array(items=Integer())
    a_all_of = AllOf(all_of=[a_field1, a_field2, a_field3])
    assert a_all_of == all_of_from_json_schema(data={"allOf": [{"type": "array"}, {"type": "array"}, {"type": "array"}]}, definitions=definitions)
    print("Test function all_of_from_json_schema(): PASS!")
    print("======================End test_all_of_from_json_schema()======================")
# Test for function all_of_from_

# Generated at 2022-06-12 15:51:58.392988
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "object"}) == Object()

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-12 15:52:03.404175
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "a"}
    json_schema_const = const_from_json_schema(data=data, definitions=definitions)
    assert json_schema_const.validate("a")



# Generated at 2022-06-12 15:52:08.435568
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data={'oneOf': [{'const': 'red'}, {'const': 'blue'}]}
    field=one_of_from_json_schema(data,"")
    assert field.one_of[0].const=='red'
    assert field.one_of[1].const=='blue'
#test_one_of_from_json_schema()



# Generated at 2022-06-12 15:52:14.141267
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, "integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, "string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, "boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, "array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, "object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-12 15:52:41.696024
# Unit test for function not_from_json_schema

# Generated at 2022-06-12 15:52:44.589985
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert (not_from_json_schema(
        {'not': {'$ref': '#/definitions/string'}}, definitions={'#/definitions/string': String()}
    ) == Not(negated=String()))



# Generated at 2022-06-12 15:52:46.901756
# Unit test for function to_json_schema
def test_to_json_schema():
    from_ = from_json_schema(definition, definitions=None)
    assert from_ == to_json_schema(from_)
if __name__ == "__main__":
    test_to_json_schema()




# Generated at 2022-06-12 15:52:58.229253
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from jsonschema import Draft7Validator
    from .core import IfThenElse
    from .core import Boolean
    from .core import Integer
    from .core import String
    from .core import Number
    from .core import Const
    from .core import Choice
    from .core import Any
    from .core import Reference


# Generated at 2022-06-12 15:53:10.054178
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "value": {"type": "number"},
            "enabled": {"type": "boolean"},
        },
        "required": ["name", "value"],
    }

    schema2 = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "value": {"type": "number"},
            "enabled": {"type": "boolean"},
        },
        "required": ["name", "value"],
    }


# Generated at 2022-06-12 15:53:17.816687
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{'type': 'number', 'minimum': 0}, {'type': 'number', 'maximum': 5}], 'type': 'number'}
    field = all_of_from_json_schema(data,None)
    assert field.validate(4) == 4, 'allOf_from_json_schema should return a field with the correct number of items in allOf'
    assert field.validate(9) != 9, 'allOf_from_json_schema should return a field with correct validation'



# Generated at 2022-06-12 15:53:25.653742
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions.add("#/string_schema", String())
    definitions.add("#/integer_schema", Integer())
    definitions.add("#/number_schema", Number())
    definitions.add("#/boolean_schema", Boolean())
    definitions.add("#/array_schema", Array())
    definitions.add("#/object_schema", Object())
    schema = {
        "$ref": "#/string_schema",
    }
    assert isinstance(ref_from_json_schema(schema, definitions=definitions), Reference)
    assert (
        ref_from_json_schema(schema, definitions=definitions).to == "#/string_schema"
    )

    schema = {
        "$ref": "#/integer_schema",
    }

# Generated at 2022-06-12 15:53:28.939381
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "boolean"}, {"type": "boolean"}]}
    assert isinstance(any_of_from_json_schema(data, definitions=definitions), Union)



# Generated at 2022-06-12 15:53:36.445675
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["string", "integer"]}) == String() | Integer()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == NeverMatch()

# Generated at 2022-06-12 15:53:47.330624
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "$ref": "blah",
            "type": "string",
            "default": None,
            "enum": ["a", "b"],
            "const": "a",
            "allOf": [
                {"type": "string"},
                {"type": "integer"},
            ],
            "anyOf": [
                {"type": "string"},
                {"type": "integer"},
            ],
            "oneOf": [
                {"type": "string"},
                {"type": "integer"},
            ],
            "not": {"type": "number"},
            "if": {
                "then": {},
                "else": {},
            },
        },
        "default": None,
    }


# Generated at 2022-06-12 15:54:20.158723
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/Car"
    }
    definitions = {"Car": "Car"}
    assert ref_from_json_schema(data, definitions=definitions) == "Car"


# Generated at 2022-06-12 15:54:25.576205
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({"anyOf": [{
        "type": "string"
    }]}, SchemaDefinitions()).any_of[0].type_ == String
    assert any_of_from_json_schema({"anyOf": [{
        "type": "integer"
    }]}, SchemaDefinitions()).any_of[0].type_ == Integer



# Generated at 2022-06-12 15:54:37.582175
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = from_json_schema(
        {
            "$ref": "#/definitions/Person",
            "definitions": {
                "Person": {
                    "type": "object",
                    "properties": {
                        "first_name": {
                            "type": "string",
                            "minLength": 5,
                            "maxLength": 10,
                            "pattern": "^[A-Z]+$",
                        },
                        "age": {"type": "integer", "minimum": 0},
                        "address": {
                            "type": "object",
                            "properties": {
                                "street": {"type": "string"},
                                "zipcode": {"type": "string"},
                            },
                        },
                    },
                }
            },
        }
    )

# Generated at 2022-06-12 15:54:40.635188
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert_schema_equals(
        IfThenElse(
            if_clause=Integer(minimum=3),
            then_clause=Any(),
            else_clause=NeverMatch(),
        ),
        {
            "if": {"type": "integer", "minimum": 3},
            "then": {},
            "else": {},
        },
    )



# Generated at 2022-06-12 15:54:50.289769
# Unit test for function to_json_schema
def test_to_json_schema():
    # noinspection PyComparisonWithNone
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(min_length=3)) == {
        "type": "string",
        "minLength": 3,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-12 15:55:02.386521
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema({"if": {}}), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}, "then": {}}), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}, "else": {}}), IfThenElse)
    assert isinstance(
        if_then_else_from_json_schema({"if": {}, "then": {}, "else": {}}), IfThenElse
    )
    # Test argument type validation
    with pytest.raises(ValueError, match="The argument 'if_clause' must be of type"):
        IfThenElse(if_clause={})

# Generated at 2022-06-12 15:55:10.940181
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    definition = {
        "definitions": {
            "odd_number": {
                "type": "number",
                "multipleOf": 2,
                "maximum": 100,
                "exclusiveMaximum": True,
            }
        }
    }

    if_then_else_case = {
        "definitions": {
            "even_number": {
                "type": "number",
                "multipleOf": 2,
                "maximum": 100,
                "exclusiveMaximum": True,
                "if": {"$ref": "#/definitions/odd_number"},
                "then": {"multipleOf": 4},
            }
        }
    }


# Generated at 2022-06-12 15:55:19.504701
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "a": {
                "type": "integer",
                "if": {"type": "integer", "minimum": 10},
                "then": {"type": "integer", "minimum": 11},
            },
            "b": {
                "type": "integer",
                "if": {"type": "integer", "minimum": 10},
                "then": {"type": "integer", "minimum": 11},
                "else": {"type": "integer", "minimum": 12},
            },
            "c": {
                "type": "integer",
                "if": {"type": "integer", "minimum": 10},
                "else": {"type": "integer", "minimum": 12},
            },
        },
    }

# Generated at 2022-06-12 15:55:23.843099
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    definitions = {}
    field = {'anyOf': [{'type': 'null'}, {'type': 'object'}]}
    assert any_of_from_json_schema(field, definitions).validate(None)
    assert any_of_from_json_schema(field, definitions).validate({})



# Generated at 2022-06-12 15:55:30.068451
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "string", False), String)
    assert isinstance(from_json_schema_type({}, "number", False), Float)
    assert isinstance(from_json_schema_type({}, "integer", False), Integer)
    assert isinstance(from_json_schema_type({}, "boolean", False), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False), Array)
    assert isinstance(from_json_schema_type({}, "object", False), Object)
    assert from_json_schema_type({}, "foo", False) == Any()
    assert from_json_schema_type({}, "null", False) == Const(None)



# Generated at 2022-06-12 15:56:28.000950
# Unit test for function to_json_schema
def test_to_json_schema():
    from jsl import String, Array, EnumField, EnumChoice

    schema = Array(
        [String(choices=[EnumChoice("A"), EnumChoice("B")]), EnumField(["X", "Y"])],
    )
    converted = to_json_schema(schema)

# Generated at 2022-06-12 15:56:39.376671
# Unit test for function from_json_schema_type

# Generated at 2022-06-12 15:56:47.718325
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "test",
        "title": "test",
        "default": "test",
        "if": {
            "type": "string"
        },
        "then": {
            "type": "string"
        },
        "else": {
            "type": "boolean"
        }
    }

    json_schema_field = from_json_schema(data, definitions=definitions)

# Generated at 2022-06-12 15:56:58.579666
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True).typename == (
        "Number"
    )
    assert from_json_schema_type({}, type_string="integer", allow_null=True).typename == (
        "Integer"
    )
    assert from_json_schema_type({}, type_string="string", allow_null=True).typename == (
        "String"
    )
    assert from_json_schema_type({}, type_string="boolean", allow_null=True).typename == (
        "Boolean"
    )
    assert from_json_schema_type({}, type_string="array", allow_null=True).typename == (
        "Array"
    )
    assert from_json_sche

# Generated at 2022-06-12 15:57:09.922550
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert issubclass(
        IfThenElse, IfThenElse(IfThenElse(Any(), Any()), Any())
    ), "Type hinting is not behaving as expected"



# Generated at 2022-06-12 15:57:14.042435
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # pylint: disable=redefined-outer-name
    data = {
        "type": "array",
        "items": {"type": "string"},
        "maxItems": None,
        "uniqueItems": False,
    }
    assert isinstance(from_json_schema_type(data, type_string="array", allow_null=None, definitions=None), Array)



# Generated at 2022-06-12 15:57:27.317407
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({'$ref': 'json_schema'}) == Reference('json_schema')
    assert from_json_schema({'enum': [1, 2, 3]}) == Choice(options=[1, 2, 3])
    assert from_json_schema({'const': 'abc'}) == Const('abc')
    assert from_json_schema({'allOf':[{'type': 'integer'}, {'minimum': 1}]}) == AllOf([Integer(), Integer(minimum=1)])
    assert from_json_schema({'anyOf':[{'type': 'integer'}, {'minimum': 1}]}) == Choice([Integer(), Integer(minimum=1)])

# Generated at 2022-06-12 15:57:29.056369
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Boolean()
    ) == if_then_else_from_json_schema({"if": {"type": "boolean"}, "then": {"type": "boolean"}},SchemaDefinitions())

# Generated at 2022-06-12 15:57:36.922655
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string in {
        "number",
        "integer",
        "string",
        "boolean",
        "array",
        "object",
    }:
        from_json_schema_type({}, type_string=type_string, allow_null=False, definitions=definitions)
    with pytest.raises(AssertionError):
        from_json_schema_type({}, type_string="invalid", allow_null=False, definitions=definitions)



# Generated at 2022-06-12 15:57:45.997959
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:58:09.685849
# Unit test for function to_json_schema
def test_to_json_schema():
    import fastjsonschema
    from .validation import validate_json_schema

    class Person(Schema):

        first_name = String(
            min_length=1, max_length=50, allow_blank=False, default="Bob"
        )
        last_name = String(
            min_length=1, max_length=50, allow_blank=True, default="Builder"
        )
        age = Integer(minimum=1, maximum=120)
        alive = Boolean(default=True)
        height = Float(
            minimum=1.2,
            maximum=2.7,
            exclusive_minimum=True,
            exclusive_maximum=False,
            multiple_of=0.1,
        )
        is_male = Boolean(default=False)

    class PersonWithDefinitions(Schema):

        first

# Generated at 2022-06-12 15:58:17.606801
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer) == {"type": "integer"}

    # Empty schema
    schema = Schema()
    assert to_json_schema(schema) == {"type": "object"}

    # Schema with one single field
    class MySchema(Schema):
        integer = Integer()

    schema = MySchema()
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {"integer": {"type": "integer"}},
    }
    assert to_json_schema(schema.integer) == {"type": "integer"}

    # Empty array field
    schema = Array()
    assert to_json_schema(schema) == {"type": "array"}

    # Array field with items field
    schema = Array(items=Integer())

# Generated at 2022-06-12 15:58:20.958861
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:58:30.439115
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic.main import Model
    from typing import Optional

    class IntModel(Model):
        """ A model for JSON Schema tests
        """

        foo: int
        bar: int = None

    class Test(Model):

        """ A test model
        """


# Generated at 2022-06-12 15:58:34.495548
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        a = Integer()

    schema = MySchema()
    result = to_json_schema(schema)

    assert result == {
        "type": "object",
        "properties": {"a": {"type": "integer"}},
        "additionalProperties": False,
        "required": ["a"],
    }



# Generated at 2022-06-12 15:58:44.633996
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    def test_case(data: typing.Dict, type_string: str, allow_null: bool, expected):
        field = from_json_schema_type(data, type_string, allow_null, definitions)
        assert field == expected

    definitions = SchemaDefinitions()
    definitions["#/definitions/Address"] = String()

    data = {
        "type": "number",
        "minimum": -10,
        "maximum": 10,
        "exclusiveMinimum": None,
        "exclusiveMaximum": None,
        "multipleOf": None,
        "default": 4,
    }
    test_case(data, "number", False, Float(minimum=-10, maximum=10, default=4))

# Generated at 2022-06-12 15:58:50.648570
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema({"hello": String(const="world"), "goodbye": Integer(min_value=1)})

    assert to_json_schema(schema) == {
        "properties": {
            "hello": {"const": "world", "default": "world", "type": "string"},
            "goodbye": {"default": 1, "minimum": 1, "type": "integer"},
        },
        "required": ["hello", "goodbye"],
        "type": "object",
    }



# Generated at 2022-06-12 15:59:01.578464
# Unit test for function from_json_schema
def test_from_json_schema():
    json_schema = {
        "type": "object"
    }
    assert from_json_schema(json_schema) == Object(properties={})

    json_schema = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "string"
            }
        }
    }
    assert from_json_schema(json_schema) == Object(properties={"foo": String()})

    json_schema = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "integer",
                "minimum": 1
            }
        }
    }
    assert from_json_schema(json_schema) == Object(
        properties={"foo": Integer(minimum=1)}
    )

    json_

# Generated at 2022-06-12 15:59:07.673172
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    test_data = [
        ("number", Float()),
        ("integer", Integer()),
        ("string", String()),
        ("boolean", Boolean()),
        ("array", Array(unique_items=True)),
        ("object", Object(properties={})),
    ]
    for type_string, field in test_data:
        data = {"type": type_string}
        assert from_json_schema_type(data, type_string, False, SchemaDefinitions()) == field



# Generated at 2022-06-12 15:59:17.044518
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    field = if_then_else_from_json_schema(
        {
            "if": {"type": "string"},
            "then": {},
            "else": {"type": "object"},
            "default": "foo",
        },
        SchemaDefinitions(),
    )
    assert isinstance(field, IfThenElse)
    assert field.if_clause.type_string == "string"
    assert not field.then_clause
    assert field.else_clause.type_string == "object"
    assert field.default == "foo"

# Generated at 2022-06-12 15:59:42.568889
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {'type': 'number', 'minimum': 1, 'maximum': 2, 'default': None}
    result = from_json_schema_type(schema, type_string='number', allow_null=False, definitions=SchemaDefinitions())
    assert isinstance(result, Float)



# Generated at 2022-06-12 15:59:52.139339
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type(from_json_schema_type(data={"type": "string"})) is String
    assert type(from_json_schema_type(data={"type": "integer"})) is Integer
    assert type(from_json_schema_type(data={"type": "number"})) is Number
    assert type(from_json_schema_type(data={"type": "boolean"})) is Boolean
    assert type(from_json_schema_type(data={"type": "array"})) is Array
    assert type(from_json_schema_type(data={"type": "object"})) is Object



# Generated at 2022-06-12 16:00:02.998918
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {
            "root": {
                "type": "string",
                "default": "nothing",
                "if": {"properties": {"x": {"default": "x_default"}}},
                "then": {"type": "integer"},
                "else": {"type": "string"},
            }
        },
    }
    # Step 1: Create an object to hold all of our schema definitions
    schema_definitions = SchemaDefinitions()
    # Step 2: Create a SchemaRef instance
    schema_definitions["#/properties/root"] = from_json_schema(
        data["properties"]["root"], definitions=schema_definitions
    )
   

# Generated at 2022-06-12 16:00:12.278465
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, SchemaDefinitions()) == Float()
    assert (
        from_json_schema_type({}, "integer", False, SchemaDefinitions()) == Integer()
    )
    assert (
        from_json_schema_type({}, "string", False, SchemaDefinitions()) == String()
    )
    assert (
        from_json_schema_type({}, "boolean", False, SchemaDefinitions()) == Boolean()
    )
    assert from_json_schema_type({}, "array", False, SchemaDefinitions()) == Array()
    assert (
        from_json_schema_type({}, "object", False, SchemaDefinitions()) == Object()
    )

