

# Generated at 2022-06-12 15:50:58.115280
# Unit test for function from_json_schema
def test_from_json_schema():
    json_schema = {
        "if": {"not": {"type": "boolean"}},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    field = from_json_schema(json_schema)
    assert field.validate("true") == "true"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("false") ==  None
    assert field.validate(None) == None
test_from_json_schema()


# Generated at 2022-06-12 15:51:06.163141
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [True, False]}
    field = enum_from_json_schema(data)
    assert field.to_json_schema() == {"type": "boolean", "enum": [True, False]}

    data = {"enum": ["a", "b"]}
    field = enum_from_json_schema(data)
    assert field.to_json_schema() == {"type": "string", "enum": ["a", "b"]}



# Generated at 2022-06-12 15:51:15.600487
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    test_cases = [
        # Primitives
        {"type": "null", "allow_null": True},
        {"type": "boolean"},
        {"type": "integer"},
        {"type": "number"},
        {"type": "string"},
        # Enums
        {"type": "integer", "enum": [1, 2, 3]},
        # Ranges
        {"type": "number", "minimum": 0, "multipleOf": 0.1},
        {"type": "integer", "minimum": 0, "exclusiveMinimum": True},
        {"type": "number", "minimum": 0, "maximum": 10},
        {"type": "integer", "minimum": 0, "maximum": 10, "exclusiveMaximum": True},
    ]

    for test_case in test_cases:
        type_string = test_case.pop("type")


# Generated at 2022-06-12 15:51:19.041610
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "string",
        "minLength": 2,
    }
    assert isinstance(from_json_schema(data), String)

    data = {
        "type": "string",
        "minLength": 2,
    }
    assert isinstance(from_json_schema(data), String)



# Generated at 2022-06-12 15:51:24.726111
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema = {
        "allOf": [
            {"$ref": "#/definitions/integer"},
            {"maximum": 10}
        ]
    }
    result = all_of_from_json_schema(json_schema, definitions)
    assert result.validate(5, error_tag_suffix=".5") == 5
    assert result.validate(15, error_tag_suffix=".15") == None

# Generated at 2022-06-12 15:51:33.232376
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert AllOf(
        all_of=[
            Integer(minimum=0),
            AllOf(
                all_of=[
                    Integer(maximum=100),
                    Integer(maximum=10),
                ],
            ),
        ],
        allow_null=False,
    ).validate(0) == 0
    assert AllOf(
        all_of=[
            Integer(minimum=0),
            AllOf(
                all_of=[
                    Integer(maximum=100),
                    Integer(maximum=10),
                ],
            ),
        ],
        allow_null=False,
    ).validate(5) == 5



# Generated at 2022-06-12 15:51:36.667530
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    foo_reference = ref_from_json_schema(data, SchemaDefinitions())
    assert isinstance(foo_reference, Reference)
    assert foo_reference.to == "#/definitions/foo"
    assert foo_reference.definitions is None



# Generated at 2022-06-12 15:51:49.817598
# Unit test for function to_json_schema
def test_to_json_schema():
    from xschema.xschema import XSchema, SchemaDefinitions
    import json

    schema = XSchema(
        {
            "str": String(allow_null=True),
            "num": Integer(minimum=10, maximum=20),
            "a": Any(),
            "b": NeverMatch(),
            "required": Object(
                required=["a", "b"],
                properties={
                    "a": Integer(minimum=0, maximum=5),
                    "b": Integer(minimum=10, maximum=15),
                },
            ),
            "x": Reference(to="required"),
            "enum": Choice(choices=[(0, "A"), (1, "B"), (2, "+"), (3, "-")]),
            "const": Const(const=(0, 1, 2)),
        }
    )



# Generated at 2022-06-12 15:52:00.812269
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-12 15:52:03.130526
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")



# Generated at 2022-06-12 15:52:35.452769
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import json

    data = json.loads("""
    {
        "allOf": [
            {
                "$ref": "#/definitions/postalCode",
                "type": "string"
            },
            {
                "pattern": "[0-9]{5}",
                "type": "string"
            }
        ],
        "default": "02093",
        "definitions": {
            "postalCode": {
                "description": "A postal code defined by the local country.",
                "type": "string"
            }
        },
        "type": "string"
    }
    """)
    field = from_json_schema(data)
    assert field.validate("02093") == "02093"
    assert field.validate("02094") != "02094"

# Generated at 2022-06-12 15:52:45.523094
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "object",
        "default": {"foo": "bar"},
        "title": "My Schema",
        "description": "My Schema",
        "properties": {
            "user": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer", "minimum": 0},
                },
                "required": ["name", "age"],
            }
        },
    }

# Generated at 2022-06-12 15:52:51.529242
# Unit test for function to_json_schema
def test_to_json_schema():

    PersonSchema = Schema(
        name=String(),
        age=Integer(),
        location=OneOf(
            Object(city=String(), state=String()),
            Object(lat=Decimal(), lng=Decimal()),
        ),
    )

    USACountryState = Schema(
        name=String(),
        code=String(),
    )

    USACounty = Schema(
        name=String(),
        state=Reference(
            to="USACountryState",
            description="The US state in which the county is located.",
        ),
    )


# Generated at 2022-06-12 15:53:00.662851
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Test the null case
    test_data = {
        "allOf": [
        ]
    }
    result = all_of_from_json_schema(test_data, None)
    assert isinstance(result, AllOf)
    assert len(result._all_of) == 0

    # Test a case where we have a single constraint
    test_data = {
        "allOf": [
            {"type": "string", "minLength": 2, "maxLength": 10}
        ]
    }
    result = all_of_from_json_schema(test_data, None)
    assert isinstance(result, AllOf)
    assert len(result._all_of) == 1
    assert isinstance(result._all_of[0], String)
    assert result._all_of[0]._min_length

# Generated at 2022-06-12 15:53:11.434779
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import fields
    from typesystem.schemas import definitions
    definitions.clear()

    assert Any() == from_json_schema_type({}, type_string="any", allow_null=True)

    assert (
        String(min_length=0, allow_blank=False, allow_null=True)
        == from_json_schema_type({}, type_string="string", allow_null=True)
    )

    assert (
        String(min_length=0, allow_blank=True, allow_null=True)
        == from_json_schema_type({}, type_string="string", allow_null=True)
    )


# Generated at 2022-06-12 15:53:19.855169
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    py_schema = all_of_from_json_schema(
        {
            "allOf": [
                {
                    "type": "number",
                    "minimum": 0,
                    "exclusiveMinimum": True
                },
                {
                    "type": "number",
                    "maximum": 10,
                    "exclusiveMaximum": True
                }
            ]
        },
        definitions=definitions
    )
    assert isinstance(py_schema, AllOf)
    assert isinstance(py_schema.all_of[0], Float)
    assert isinstance(py_schema.all_of[1], Float)



# Generated at 2022-06-12 15:53:21.551106
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 5}) == Const(const=5)
    assert const_from_json_schema({"const": 5, "default": "hello"}) == Const(const=5, default="hello")



# Generated at 2022-06-12 15:53:28.616647
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string, value in [
        ("number", 0.0),
        ("integer", 0),
        ("string", ""),
        ("boolean", True),
        ("array", []),
        ("object", {}),
    ]:
        field = from_json_schema_type({}, type_string=type_string, allow_null=True, definitions=SchemaDefinitions())
        assert field.validate(value) == True



# Generated at 2022-06-12 15:53:31.242430
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"enum": [1, 2, "c"]}
    definitions = SchemaDefinitions()
    actual = const_from_json_schema(data, definitions)
    assert isinstance(actual, Choice)



# Generated at 2022-06-12 15:53:35.058714
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    _schema = {
        "enum": [
            "one",
            "two",
        ],
    }
    _expected = Choice(choices=[
        ("one", "one"),
        ("two", "two"),
    ])
    _actual = enum_from_json_schema(_schema, definitions={})
    assert _actual == _expected

# Generated at 2022-06-12 15:54:10.816610
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf":[
            {"type":"string"},
            {"type":"integer"}
        ]
    }
    json_schema = any_of_from_json_schema(schema, definitions)
    assert isinstance(json_schema, Union), f"Should be Object but was {type(json_schema)}"
    assert isinstance(json_schema.any_of[0], String), f"Should be String but was {type(json_schema.any_of[0])}"
    assert isinstance(json_schema.any_of[1], Integer), f"Should be Integer but was {type(json_schema.any_of[1])}"



# Generated at 2022-06-12 15:54:17.724492
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_data = {"anyOf": [{"type": "integer"}, {"type": "number"}]}
    field = any_of_from_json_schema(json_data, definitions)

    assert field.validators[0].validate(1)
    assert field.validators[0].validate(1.0)
    assert not field.validators[0].validate("1")



# Generated at 2022-06-12 15:54:22.290286
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {
                "type": "string",
                "minLength": 2,
                "maxLength": 2
            },
            {
                "type": "object",
                "properties": {
                    "first": {"type": "string"},
                    "last": {"type": "string"}
                }
            }
        ]
    }

    field = one_of_from_json_schema(schema, definitions=definitions)
    assert field.validates("XX")
    assert not field.validates("X")
    assert field.validates({"first": "A", "last": "B"})
    assert not field.validates({"first": "X", "last": "XX"})



# Generated at 2022-06-12 15:54:28.234827
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of = [{"type": "integer"}, {"type": "boolean"}]
    kwargs = {"one_of": one_of, "default": NO_DEFAULT}
    schema = OneOf(**kwargs)
    data = {"type": "integer"}
    value = from_json_schema(data)
    assert value == schema.validate(value.to_primitive())



# Generated at 2022-06-12 15:54:32.233575
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    '''
    This function tests the function one_of_from_json_schema
    '''
    data = {'oneOf': [1, 2, 3]}
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions)
    data1 = {'oneOf': [{'$ref': '#/definitions/test', 'definitions': {'test': String()}}, String()]}
    assert one_of_from_json_schema(data1, definitions) == Union(any_of=[String(), String()])



# Generated at 2022-06-12 15:54:33.836109
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import from_json_schema

    assert from_json_schema({"type": "string"}) == String()



# Generated at 2022-06-12 15:54:45.834701
# Unit test for function to_json_schema
def test_to_json_schema():
    from .test_schemas import TestSchema

    schema = TestSchema()
    arguments = to_json_schema(schema)
    assert "definitions" in arguments, "Expected definitions to be defined."
    for key, value in schema.definitions.items():
        assert value.target.name in arguments["definitions"], (
            f"Expected to see definition for {value.target.name!r}."
        )


# Generated at 2022-06-12 15:54:51.153302
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_schema = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "object", "properties": 1},
        ]
    }
    definitions = SchemaDefinitions()
    result = one_of_from_json_schema(test_schema, definitions)
    assert result.one_of[0] == String(allow_blank=True, min_length=1)
    assert result.one_of[1] == Object(properties={})


# Generated at 2022-06-12 15:54:55.532010
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {'const': 'hello', 'default': 'a', 'type': 'string'}
    definitions = SchemaDefinitions()
    assert const_from_json_schema(data, definitions)



# Generated at 2022-06-12 15:55:04.653069
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, None) == Any()
    assert type_from_json_schema({"type": "null"}, None) == Const(None)
    assert type_from_json_schema(
        {"type": "boolean"}, None
    ) == Boolean(**Boolean.DEFAULT_CONSTRAINTS)
    assert type_from_json_schema(
        {"type": "string"}, None
    ) == String(**String.DEFAULT_CONSTRAINTS)
    assert type_from_json_schema(
        {"type": "integer"}, None
    ) == Integer(**Integer.DEFAULT_CONSTRAINTS)

# Generated at 2022-06-12 15:55:38.840212
# Unit test for function to_json_schema
def test_to_json_schema():
    import pytest  # type: ignore
    from . import schema, validators

    # Checked against https://jsonschema.net
    assert to_json_schema(Any) == True
    assert to_json_schema(NeverMatch) == False
    assert to_json_schema(String(min_length=3, max_length=20)) == {
        "type": "string",
        "minLength": 3,
        "maxLength": 20,
    }
    assert to_json_schema(String(pattern=r"\d{3}-\d{3}-\d{4}")) == {
        "type": "string",
        "pattern": "\\d{3}-\\d{3}-\\d{4}",
    }

# Generated at 2022-06-12 15:55:42.049798
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({
        "anyOf": [
            {"type": "string"},
            {"type": "integer"}
        ]
    }, None), Union)


# Generated at 2022-06-12 15:55:44.931085
# Unit test for function to_json_schema
def test_to_json_schema():
    string = String(minimum_length=2, max_length=4, allow_blank=False)
    schema = Schema(name=string)
    schema.to_json_schema()



# Generated at 2022-06-12 15:55:52.728238
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    # String
    assert String() == from_json_schema_type(
        {}, "string", allow_null=False, definitions=SchemaDefinitions()
    )
    assert String(allow_null=True) == from_json_schema_type(
        {}, "string", allow_null=True, definitions=SchemaDefinitions()
    )
    assert String(allow_blank=False) == from_json_schema_type(
        {"minLength": 1}, "string", allow_null=False, definitions=SchemaDefinitions()
    )
    assert String(min_length=2) == from_json_schema_type(
        {"minLength": 2}, "string", allow_null=False, definitions=SchemaDefinitions()
    )
    assert String(max_length=2) == from_json_schema

# Generated at 2022-06-12 15:55:57.356634
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(max_length=4),
            "age": Integer(minimum=14, exclusive_minimum=True),
            "address": {
                "street": String(max_length=10),
                "postal_code": String(max_length=5),
            },
        }
    )
    data = to_json_schema(schema)

# Generated at 2022-06-12 15:56:06.560739
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type({}, type_string="null", allow_null=True, definitions={}),
        Const
    )
    assert isinstance(
        from_json_schema_type({}, type_string="null", allow_null=False, definitions={}),
        NeverMatch
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="integer", allow_null=False, definitions={}
        ),
        Integer
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="integer", allow_null=True, definitions={}
        ),
        Choice
    )

# Generated at 2022-06-12 15:56:11.102746
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type(
        data=dict(type="string", pattern=r"^[0-9]+$"),
        type_string="string",
        allow_null=False,
        definitions=None,
    )



# Generated at 2022-06-12 15:56:21.165889
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:56:23.814256
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({
        'anyOf': [{'type': 'null'}, {'type': 'boolean'}],
    }, SchemaDefinitions()) == Union(any_of=[
        Const(const=None), Boolean()
    ])



# Generated at 2022-06-12 15:56:29.391127
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field  = one_of_from_json_schema(
        {
            "oneOf": [
                {"type": "string"},
                {"type": "number"},
                {"type": "boolean"},
            ]
        },
        definitions=None
    )
    assert len(field.to_native_constraints) == 3



# Generated at 2022-06-12 15:56:44.666588
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"$ref": "#/definitions/integer"}) == Any()



# Generated at 2022-06-12 15:56:50.746555
# Unit test for function to_json_schema
def test_to_json_schema():
    class UserSchema(Schema):
        name = String(max_length=30)
        email = String(format="email")
        status = Choice(choices=[("active", "active"), ("inactive", "inactive")])
        is_active = Boolean()

    data = to_json_schema(UserSchema)


# Generated at 2022-06-12 15:56:59.897560
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """Unit test for function from_json_schema_type"""
    data = {
        "minimum": 1,
        "maximum": 10,
        "type": "number",
        "default": 2,
    }
    result = from_json_schema_type(
        data=data,
        type_string="number",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    assert isinstance(result, Float)
    assert result.minimum == 1
    assert result.maximum == 10
    assert result.default == 2
    assert not hasattr(result, "allow_null")
    assert not hasattr(result, "exclusive_minimum")
    assert not hasattr(result, "exclusive_maximum")
    assert not hasattr(result, "multiple_of")


# Generated at 2022-06-12 15:57:10.609104
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:57:21.360997
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    def check(arg, expected, ref=False):  # noqa: C901
        if ref:
            assert isinstance(arg, Schema)
            if isinstance(expected, str):
                expected = {"$ref": expected}
            expected["definitions"] = {
                str(arg): to_json_schema(arg)
            }  # type: ignore

        actual = to_json_schema(arg)

# Generated at 2022-06-12 15:57:24.556391
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer(allow_null=False)



# Generated at 2022-06-12 15:57:34.510540
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice(choices=[])) == {"enum": []}
    assert to_json_schema(String(null=True)) == {"type": ["string", "null"]}

# Generated at 2022-06-12 15:57:45.590282
# Unit test for function from_json_schema_type

# Generated at 2022-06-12 15:57:54.527162
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "title": "A representation of a person, company, organization, or place",
        "description": "https://github.com/json-schema/json-schema/blob/master/examples/geo.json",
        "properties": {
            "type": {"type": "string"},
            "name": {"type": "string"},
            "coordinates": {
                "type": "array",
                "items": {"type": "number"},
            },
        },
    }
    field = from_json_schema(json_schema)
    assert isinstance(field, Object)

# Generated at 2022-06-12 15:58:04.983101
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "null", True, None), Field)
    assert isinstance(from_json_schema_type({}, "boolean", False, None), Field)
    assert isinstance(from_json_schema_type({}, "string", False, None), Field)
    assert isinstance(from_json_schema_type({}, "object", False, None), Field)
    assert isinstance(from_json_schema_type({}, "array", False, None), Field)
    assert isinstance(from_json_schema_type({}, "integer", False, None), Field)
    assert isinstance(from_json_schema_type({}, "number", False, None), Field)



# Generated at 2022-06-12 15:58:23.434027
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "integer"), Integer)
    assert isinstance(from_json_schema_type({}, "number"), Float)
    assert isinstance(from_json_schema_type({}, "string"), String)
    assert isinstance(from_json_schema_type({}, "boolean"), Boolean)
    assert isinstance(from_json_schema_type({}, "array"), Array)
    assert isinstance(from_json_schema_type({}, "object"), Object)
    assert isinstance(from_json_schema_type({}, "null"), Any)



# Generated at 2022-06-12 15:58:33.807335
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    s = from_json_schema_type({"type": "number"}, type_string="number", allow_null=False, definitions=definitions)
    assert isinstance(s, Float)

    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False, definitions=definitions)
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=definitions)
    assert from_json_schema_type({}, type_string="boolean", allow_null=True, definitions=definitions)

    assert from_json_schema_type({}, type_string=None, allow_null=False, definitions=definitions)


# Generated at 2022-06-12 15:58:39.778886
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    from pydantic.schema import schema
    from typing_json_schema.json_schema import (
        schema_from_json,
        to_json_schema,
    )
    from tests.schemas.basic_schemas import (
        Address,
        AddressWithChoices,
        PersonWithAddressesWithChoices,
        PersonWithChoices,
    )

    assert schema_from_json(to_json_schema(PersonWithAddressesWithChoices)) == schema(
        PersonWithAddressesWithChoices
    )
    assert schema_from_json(to_json_schema(PersonWithChoices)) == schema(
        PersonWithChoices
    )

# Generated at 2022-06-12 15:58:48.601729
# Unit test for function from_json_schema
def test_from_json_schema():
    # Check the function returns a schema
    schema = from_json_schema({'type': 'string'})
    assert isinstance(schema, String)

    # Check the function returns a field
    field = from_json_schema({'type': 'string', 'maxLength': 10})
    assert isinstance(field, String)
    assert field.max_length == 10

    # Check the function properly supports $ref
    definitions = {'foo': {'type': 'integer'}}
    schema = from_json_schema({
        '$ref': '#/definitions/foo',
        'definitions': definitions,
    })
    field = from_json_schema({
        '$ref': '#/definitions/foo',
        'definitions': definitions,
        'exclusiveMinimum': 0,
    })

# Generated at 2022-06-12 15:58:54.227849
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Tests function from_json_schema_type.
    """
    DATA = {
        "type": "string",
        "default": "foobar",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "^[A-Z]+$",
    }

    field = from_json_schema_type(DATA, "string", False, None)
    assert field == String(
        default="foobar", min_length=1, max_length=10, pattern=re.compile(r"^[A-Z]+$")
    )

    field = from_json_schema_type(DATA, "string", True, None)

# Generated at 2022-06-12 15:59:05.926309
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    invalid_type_strings = set(["number", "integer", "string", "boolean", "array", "object"]) - set(["string"]) - set(["boolean"])
    for type_string in invalid_type_strings:
        try:
            from_json_schema_type({"type": type_string}, "string", True, SchemaDefinitions())
        except AssertionError:
            pass
        else:
            raise AssertionError(f"Should have raised AssertionError for type_string={type_string!r}")


# Generated at 2022-06-12 15:59:12.479428
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema({'type': 'boolean'}) == Boolean()
    assert type_from_json_schema({'type': 'integer'}) == Integer()
    assert type_from_json_schema({'type': 'number'}) == Number()
    assert type_from_json_schema({'type': 'object'}) == Object()
    assert type_from_json_schema({'type': 'array'}) == Array()
    assert type_from_json_schema({'type': 'string'}) == String()
    assert type_from_json_schema({'type': ['boolean', 'integer']}) == Choice(
        any_of=[Boolean(), Integer()])
    assert type_from_json_schema({'type': 'null'}) == Const(None)
    assert type_

# Generated at 2022-06-12 15:59:20.445280
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({}, "string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({}, "boolean", allow_null=True) == Boolean(allow_null=True)
    assert from_json_schema_type({}, "array", allow_null=True) == Array(allow_null=True)
    assert from_json_schema_type({}, "object", allow_null=True) == Object(allow_null=True)



# Generated at 2022-06-12 15:59:22.638670
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()



# Generated at 2022-06-12 15:59:31.009819
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="number", allow_null=False, definitions=definitions), Float)
    assert isinstance(from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False, definitions=definitions), Integer)
    assert isinstance(from_json_schema_type({"type": "string"}, type_string="string", allow_null=False, definitions=definitions), String)
    assert isinstance(from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False, definitions=definitions), Boolean)

# Generated at 2022-06-12 15:59:53.720763
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, SchemaDefinitions()) == Float()
    assert from_json_schema_type({}, "integer", False, SchemaDefinitions()) == Integer()
    assert (
        from_json_schema_type({}, "string", False, SchemaDefinitions()) == String(allow_null=False)
    )
    assert (
        from_json_schema_type({"minLength": 1}, "string", False, SchemaDefinitions())
        == String(min_length=1)
    )
    assert (
        from_json_schema_type({"maxLength": 1}, "string", False, SchemaDefinitions())
        == String(max_length=1)
    )

# Generated at 2022-06-12 15:59:58.594764
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    import json

    data = {"type": "object", "properties": {"answer": {"type": "number"}}}
    schema = make_schema_from_json_schema(data)

    result1 = to_json_schema(schema)
    assert result1 == data

    result2 = to_json_schema(JSONSchema.from_data(data))
    assert result2 == data

    result3 = json.dumps(result2, sort_keys=True, indent=2)
    print(result3)



# Generated at 2022-06-12 16:00:08.375041
# Unit test for function to_json_schema
def test_to_json_schema():
    from .tests import test_bool, test_int, test_list, test_flat_object, test_nested_object, test_simple_union, test_choice, test_const, test_if_then_else, test_not, test_all_of, test_one_of, test_any_of

    def assert_json_schema(field, json_schema):
        assert to_json_schema(field) == json_schema

    assert_json_schema(test_bool, True)
    assert_json_schema(test_int, {"type": "integer", "minimum": 0})
    assert_json_schema(test_list, {"type": "array", "items": {"type": "string"}})

# Generated at 2022-06-12 16:00:14.573475
# Unit test for function to_json_schema
def test_to_json_schema():
    field = AllOf(
        [
            String(min_length=2, pattern_regex=re.compile(r"^[a-z]+$")),
            Const(const=["yes", "no"]),
        ]
    )
    data = to_json_schema(field)
    assert data == {
        "allOf": [
            {
                "type": "string",
                "pattern": "^[a-z]+$",
                "minLength": 2,
                "enum": ["yes", "no"],
            }
        ]
    }

