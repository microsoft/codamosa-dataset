

# Generated at 2022-06-12 15:51:16.854038
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data={'const':0}
    definitions=SchemaDefinitions()
    definition=from_json_schema(data,definitions=definitions)
    assert definition.validate(0)==0
    assert definition.validate(1)==1
    assert definition.validate(2)==2
    data={'const':'test'}
    definitions=SchemaDefinitions()
    definition=from_json_schema(data,definitions=definitions)
    assert definition.validate('test')=='test'
    assert definition.validate(1)==1
    assert definition.validate(2)==2
    data={'const':{'test':'test'}}
    definitions=SchemaDefinitions()
    definition=from_json_schema(data,definitions=definitions)
    assert definition.validate

# Generated at 2022-06-12 15:51:18.932118
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    kwargs = {"one_of": [String(max_length=10), Integer(minimum=9)], "default": NO_DEFAULT}
    return OneOf(**kwargs)



# Generated at 2022-06-12 15:51:29.032617
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():

    schema = {
        "if": {"type": "string"},
        "then": {"const": "expected"},
        "default": "otherwise",
    }
    data_true = "yep"
    data_false = "nope"
    data_none = None

    field = from_json_schema(schema)
    jsonable_object(field)
    assert field(data_true) == "expected"
    assert field(data_false) == "otherwise"
    assert field(data_none) == "otherwise"

    schema = {
        "if": {"type": "string"},
        "then": {"const": "expected"},
    }
    data_true = "yep"
    data_false = "nope"
    data_none = None


# Generated at 2022-06-12 15:51:38.108521
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "number",
        },
        "then": {
            "type": "number",
        },
        "else": {
            "type": "string",
        },
    }
    assert if_then_else_from_json_schema(data, None) == IfThenElse(
        if_clause=Integer(allow_null=False),
        then_clause=Integer(allow_null=False),
        else_clause=String(allow_null=False),
    )

    data = {
        "if": {
            "type": "number",
        },
        "then": {
            "type": "number",
        },
    }

# Generated at 2022-06-12 15:51:42.851092
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():

    data = {"type": ["array","object"]}
    definitions = {"type":"object"}
    data = any_of_from_json_schema(data, definitions)
    assert data.type_name == 'Union of Array and Object'


# Generated at 2022-06-12 15:51:48.623944
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {'type': 'object', 'allOf': [{'type': 'string', 'const': 'Hello'}, {'type': 'string', 'const': 'World'}]}
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validates('HelloWorld') == True
    assert field.validates('NotValidated') == False



# Generated at 2022-06-12 15:51:58.605808
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    description = "allOf"
    data = {
        "allOf": [
            {"type": "number", "minimum": 0},
            {"type": "number", "maximum": 100},
        ],
    }
    schema = all_of_from_json_schema(data, SchemaDefinitions())

    tests = [
        (description, (0, True)),
        (description, (-1, False)),
        (description, (1, True)),
        (description, (101, False)),
    ]
    for description, (value, expected) in tests:
        assert schema.validate(value) == expected, f"{description}: {value}"


# Generated at 2022-06-12 15:52:01.648770
# Unit test for function to_json_schema
def test_to_json_schema():
    pass



# Generated at 2022-06-12 15:52:11.343796
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.base import Context
    import json
    data = {
        "type": "array",
        "items": [
            {"type": "string"},
            {"type": "integer"},
        ],
    }
    field = type_from_json_schema(data, definitions={})
    assert isinstance(field, Union)
    assert field.allow_null is False
    assert field.is_valid(None, context=Context()).is_valid is False
    assert field.is_valid(None, context=Context(allow_null=True)).is_valid is True
    assert field.is_valid([], context=Context()).is_valid is False
    assert field.is_valid(["a"], context=Context()).is_valid is True
    assert field.is_valid([1], context=Context()).is_valid

# Generated at 2022-06-12 15:52:23.164509
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(
        {
            "type": "integer",
            "multipleOf": 10,
        }, 
        definitions=definitions
    ) == Integer(multiple_of=10)

    assert type_from_json_schema(
        {
            "type": ["integer", "null"],
        }, 
        definitions=definitions
    ) == Union(
        any_of=[
            Integer(allow_null=False),
            Const(None),
        ],
        allow_null=True
    )

    assert type_from_json_schema(
        {
            "enum": [10, "TEN"],
        }, 
        definitions=definitions
    ) == Choice(choices=[10, "TEN"])


# https://json-schema.org/draft/2019-09

# Generated at 2022-06-12 15:53:26.057324
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.exceptions import ValidationError

    # This is the oneOf property that I would like to convert to typesystem.
    data = {
            "oneOf": [
                {
                    "type": "string",
                    "minLength": 2
                },
                {
                    "type": "integer"
                }
            ],
            "default": None
    }
    # This is the oneOf property converted to typesystem
    test = one_of_from_json_schema(data, definitions)
    print(test)
    # This is the first element of oneOf in typesystem
    test2 = from_json_schema_type(data["oneOf"][0], "string", False, definitions)
    print(test2)
    # This is the second element of oneOf in typesystem
    test3 = from_json

# Generated at 2022-06-12 15:53:32.907866
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_schema_doc = {
        "oneOf": [
            {"type": "string"}, {"type": "number"}
        ]
    }
    schema = one_of_from_json_schema(json_schema_doc, None)
    assert isinstance(schema, OneOf)
    assert isinstance(schema.one_of, list)
    assert len(schema.one_of) == 2
    assert isinstance(schema.one_of[0], String)
    assert isinstance(schema.one_of[1], Float)



# Generated at 2022-06-12 15:53:44.909012
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(Number, AllowNull(String), IfThenElse(Equal(1), Const(1), Const(0)))
    assert to_json_schema(schema) == {
        "allOf": [
            {"enum": [1, 0], "const": 1},
            {
                "if": {"type": ["number", "null"], "const": 1},
                "then": {"const": 1},
                "else": {"const": 0},
            },
        ]
    }


# Generated at 2022-06-12 15:53:48.127325
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert (
        from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")
    )
    assert (
        from_json_schema({"$ref": "#/definitions/foo"}, definitions={"foo": Integer()})
        == Integer()
    )
    assert (
        from_json_schema({"$ref": "#/definitions/foo"}, definitions={"foo": Integer()})
        == Integer()
    )



# Generated at 2022-06-12 15:53:55.175805
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({
        'type': 'string',
        'oneOf': [
            {'type': 'integer'},
            {'type': 'number'}
        ]},
        definitions=None) == OneOf([Integer(), Float()], default=NO_DEFAULT)
# Tests for function not_from_json_schema

# Generated at 2022-06-12 15:53:57.475994
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({"$ref": "#/definitions/reference"}), Schema
    )



# Generated at 2022-06-12 15:54:05.685589
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test for simple string with length
    test_field = String(min_length=1, pattern_regex=re.compile(r"[a-zA-Z0-9]"))
    expected_result = (
        {"type": "string", "minLength": 1, "pattern": "[a-zA-Z0-9]"}
    )
    assert to_json_schema(test_field) == expected_result
    assert isinstance(to_json_schema(test_field), dict)

    # Test for choice field with multi-value enum
    test_field = Choice([(1, 0), (2, 5), (3, 7)])
    expected_result = {"enum": [1, 2, 3]}
    assert to_json_schema(test_field) == expected_result

    # Test for multiple choice field

# Generated at 2022-06-12 15:54:10.561348
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Bool"}
    typesystem_schema = ref_from_json_schema(data, SchemaDefinitions())
    assert str(typesystem_schema) == "Reference('Bool')"
    assert typesystem_schema.validates({})
    assert not typesystem_schema.validates(None)



# Generated at 2022-06-12 15:54:12.698700
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.json_schema.tests.fixtures import json_schema_dict

    for fixture in json_schema_dict:
        type_ = from_json_schema(fixture["json_schema"])
        assert type_.validate(fixture["input"]) == fixture["output"]



# Generated at 2022-06-12 15:54:22.872706
# Unit test for function to_json_schema
def test_to_json_schema():

    class Simple1(Schema):
        email = Email()

    class Simple2(Schema):
        field = OneOf([String(), Boolean(), Integer()])

    def assert_equal(given, expected):
        result = to_json_schema(given)
        assert result == expected

    assert_equal(Simple1, {'type': 'object', 'properties': {'email': {'type': 'string'}}, 'definitions': {}})
    assert_equal(Simple2, {'oneOf': [{'type': 'string'}, {'type': 'boolean'}, {'type': 'integer'}]})
    assert_equal(Any(), True)
    assert_equal(NeverMatch(), False)


# Generated at 2022-06-12 15:55:02.086820
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "number"}}
    definitions = {}
    result = not_from_json_schema(data, definitions)
    assert isinstance(result, Not)
    assert result.negated == Float()
    assert result.default == NO_DEFAULT

    data = {"not": {"type": "number"}, "default": "true"}
    definitions = {}
    result = not_from_json_schema(data, definitions)
    assert isinstance(result, Not)
    assert result.negated == Float()
    assert result.default == "true"



# Generated at 2022-06-12 15:55:03.506551
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema({"not": {}}, definitions={}), Not)



# Generated at 2022-06-12 15:55:05.412091
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_class = not_from_json_schema({"not": {"type": "string"}})
    assert not_class.negated.type == String



# Generated at 2022-06-12 15:55:13.180536
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": "string",
        "format": "email",
        "maxLength": 64,
    }
    field = type_from_json_schema(schema, definitions)
    assert isinstance(field, String)
    schema = {
        "type": ["string", "null"],
        "format": "email",
        "maxLength": 64,
    }
    field = type_from_json_schema(schema, definitions)
    assert isinstance(field, Union)
    schema = {
        "type": ["boolean", "null"],
    }
    field = type_from_json_schema(schema, definitions)
    assert isinstance(field, Union)
    schema = {
        "type": ["boolean", "null"],
    }
    field = type_from_json

# Generated at 2022-06-12 15:55:16.995036
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field = enum_from_json_schema(dict(enum=["a", "b", "c"]))
    assert field.validate(None) == "a"
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.serialize("a") == "a"
    assert field.serialize("b") == "b"
    assert field.serialize("c") == "c"
    assert field.serialize(None) == "a"



# Generated at 2022-06-12 15:55:26.055619
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice()) == {"enum": []}
    assert to_json_schema(Const()) == {"const": None}

    definitions = SchemaDefinitions()
    definitions["SomeType"] = String()

# Generated at 2022-06-12 15:55:37.177741
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'number'}, {'type': 'integer'}], 'default': 1}
    any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    assert Union(**kwargs).validate(1)
    data = {'anyOf': [{'type': 'string'}, {'type': 'integer'}], 'default': 1}
    any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    assert Union

# Generated at 2022-06-12 15:55:46.861298
# Unit test for function to_json_schema
def test_to_json_schema():

    x = String(allow_null=False)
    assert to_json_schema(x) == {"type": "string"}

    x = String(allow_null=True)
    assert to_json_schema(x) == {"type": ["string", "null"]}

    x = String(allow_null=True, default="Yes")
    assert to_json_schema(x) == {
        "type": ["string", "null"],
        "default": "Yes",
    }

    x = String(min_length=1, max_length=100)
    assert to_json_schema(x) == {
        "type": "string",
        "minLength": 1,
        "maxLength": 100,
    }


# Generated at 2022-06-12 15:55:50.566460
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {'enum': ["a", "b"]}
    choices = [(item, item) for item in data["enum"]]
    kwargs = {"choices": choices, "default": data.get("default", NO_DEFAULT)}
    assert Choice(**kwargs).choices == [('a', 'a'), ('b', 'b')]
    assert data.get("default", NO_DEFAULT) == NO_DEFAULT


# Generated at 2022-06-12 15:56:02.909536
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # If there is a oneOf that contains both a number and an integer
    # then a typesystem.Union will be created.
    field = any_of_from_json_schema(
        {
            "anyOf": [
                {"type": "integer", "minimum": 10, "maximum": 20},
                {"type": "number", "minimum": 10, "maximum": 20},
            ]}, definitions
    )
    assert isinstance(field, Union)
    # Unit test for if both number and integer are not specified
    # then an error will be raised

# Generated at 2022-06-12 15:56:41.052783
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    # Check that the correct field is returned for all the possible types
    assert isinstance(from_json_schema_type(data={"type": "number"}, type_string="number", allow_null=False, definitions=None), Float)
    assert isinstance(from_json_schema_type(data={"type": "integer"}, type_string="integer", allow_null=False, definitions=None), Integer)
    assert isinstance(from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=None), String)
    assert isinstance(from_json_schema_type(data={"type": "boolean"}, type_string="boolean", allow_null=False, definitions=None), Boolean)

# Generated at 2022-06-12 15:56:48.533357
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    t = type_from_json_schema({"type": "string"}, definitions={})
    assert isinstance(t, String)

    t = type_from_json_schema({"type": "number"}, definitions={})
    assert isinstance(t, Number)

    t = type_from_json_schema({"type": "integer"}, definitions={})
    assert isinstance(t, Integer)

    t = type_from_json_schema({"type": "boolean"}, definitions={})
    assert isinstance(t, Boolean)

    t = type_from_json_schema({"type": "object"}, definitions={})
    assert isinstance(t, Object)

    t = type_from_json_schema({"type": "array"}, definitions={})
    assert isinstance(t, Array)

    t = type_from

# Generated at 2022-06-12 15:56:58.722005
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate('123') == True
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate(123) == True
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate([123]) == False
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate({'test': 123}) == False
    assert any_of_from_json_schema

# Generated at 2022-06-12 15:57:01.653265
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from jsonschema import validate
    from .storage import Choice, String

    typ = from_json_schema({"enum": ["foo", "bar"]})

    assert isinstance(typ, Choice)
    assert typ.choices == [("foo", "foo"), ("bar", "bar")]
    validate("foo", {"enum": ["foo", "bar"]})
    validate("bar", {"enum": ["foo", "bar"]})



# Generated at 2022-06-12 15:57:08.389626
# Unit test for function to_json_schema
def test_to_json_schema():
    class ExampleObject(Schema):
        example = Boolean(default=True)

    class Example(Schema):
        id = Integer()
        string = String()
        boolean = Boolean()
        integer = Integer()
        float = Float()
        array = Array(String())
        object = ExampleObject()


# Generated at 2022-06-12 15:57:10.680426
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False)
        == String()
    )



# Generated at 2022-06-12 15:57:12.187229
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema(data={"anyOf":[]}),Union)



# Generated at 2022-06-12 15:57:15.039045
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Foo"}
    definitions = {
        "#/definitions/Foo": String()
    }
    field = ref_from_json_schema(data, definitions=definitions)
    assert field == Reference("#/definitions/Foo", definitions=definitions)



# Generated at 2022-06-12 15:57:22.661604
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": ["boolean_true", "boolean_false"],
        "default": "boolean_true",
    }
    field = enum_from_json_schema(data, definitions)
    assert isinstance(field, Choice)
    assert field.choices == [("boolean_true", "boolean_true"), ("boolean_false", "boolean_false")]
    assert field.default == "boolean_true"



# Generated at 2022-06-12 15:57:33.404422
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definition_ref_a = Reference("#/definitions/a", definitions=definitions)
    definition_ref_b = Reference("#/definitions/b", definitions=definitions)
    definition_ref_b_def = definition_ref_b

    definitions["a"] = definition_ref_a

    definitions["b"] = definition_ref_b_def

    data = {"$ref": "#/definitions/a"}
    expected = Reference("#/definitions/a", definitions=definitions)
    actual = ref_from_json_schema(data, definitions=definitions)
    assert actual == expected

    data = {"$ref": "#/definitions/b"}
    expected = Reference("#/definitions/b", definitions=definitions)
    actual = ref_from_json_schema(data, definitions=definitions)

# Generated at 2022-06-12 15:58:22.674076
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.printer import dump_field
    from typesystem.utils import get_type
    from typesystem.validators import Equals, Length, Regex, Unique

    def assert_constraint(constraints, constraint_class):
        for constraint in constraints:
            if isinstance(constraint, constraint_class):
                return True
        return False

    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    # type
    field = from_json_schema({"type": "string"})
    assert get_type(field) == type(String())
    assert isinstance(field.validators[0], Length)
    field = from_json_schema({"type": "boolean"})

# Generated at 2022-06-12 15:58:28.376071
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test type_string=number
    data = dict(type="number")
    field = from_json_schema_type(data, type_string="number", allow_null=False, definitions=definitions)
    assert str(field) == "Float()"
    assert type(field) is Float

    field = from_json_schema_type(data, type_string="number", allow_null=True, definitions=definitions)
    assert str(field) == "Float(allow_null=True)"
    assert type(field) is Float

    data = dict(type="number", minimum=10)
    field = from_json_schema_type(data, type_string="number", allow_null=False, definitions=definitions)
    assert str(field) == "Float(minimum=10)"
    assert type(field) is Float

# Generated at 2022-06-12 15:58:36.108253
# Unit test for function to_json_schema
def test_to_json_schema():
    class InnerSchema(Schema):
        field_3 = String(format="date-time")

    class OutterSchema(Schema):
        field_1 = Reference("InnerSchema")
        field_2 = Object(
            additional_properties=Any(),
            pattern_properties={"a+": Reference("InnerSchema")},
        )


# Generated at 2022-06-12 15:58:43.790016
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    with pytest.raises(AssertionError):
        assert isinstance(from_json_schema({"$ref": "#foo"}), Reference)
    # same with a reference to a definition on the root level
    assert isinstance(from_json_schema({"$ref": "#/foo"}), Reference)
    with pytest.raises(AssertionError):
        assert isinstance(from_json_schema({"$ref": "foo"}), Reference)




# Generated at 2022-06-12 15:58:51.085038
# Unit test for function to_json_schema
def test_to_json_schema():

    field1 = String(max_length=10, allow_blank=True)
    data1 = {
        "type": "string",
        "maxLength": 10,
        "minLength": 0
    }
    assert to_json_schema(field1) == data1

    field2 = String(max_length=10, allow_blank=False)
    data2 = {
        "type": "string",
        "maxLength": 10,
        "minLength": 1
    }
    assert to_json_schema(field2) == data2

    field3 = String(pattern_regex=re.compile("^(foo|bar)$"))
    data3 = {
        "type": "string",
        "pattern": "^(foo|bar)$"
    }

# Generated at 2022-06-12 15:58:57.710455
# Unit test for function to_json_schema
def test_to_json_schema():
    def _test_to_json_schema(arg: typing.Union[Field, typing.Type[Schema]],
                             expected: typing.Union[bool, dict]):
        assert to_json_schema(arg) == expected
    _test_to_json_schema(Any, True)
    _test_to_json_schema(NeverMatch, False)
    _test_to_json_schema(String, {"type": "string"})
    _test_to_json_schema(Object, {"type": "object"})
    _test_to_json_schema(Array, {"type": "array"})
    _test_to_json_schema(Boolean, {"type": "boolean"})
    _test_to_json_schema(Integer, {"type": "integer"})
    _

# Generated at 2022-06-12 15:59:07.992801
# Unit test for function from_json_schema
def test_from_json_schema():
    json_schema = {
        "type": "number",
        "minimum": 5,
        "maximum": 10,
        "$ref": "/foo",
        "enum": ["a", "b"],
        "const": "c",
        "allOf": [{"$ref": "/foo"}],
        "anyOf": [{"$ref": "/foo"}],
        "oneOf": [{"$ref": "/foo"}],
        "not": {"$ref": "/foo"},
        "if": {"$ref": "/foo"},
        "then": {"$ref": "/foo"},
        "else": {"$ref": "/foo"},
    }
    definitions = SchemaDefinitions()
    definitions["/foo"] = Any()
    field = from_json_schema(json_schema, definitions=definitions)
    assert type(field)

# Generated at 2022-06-12 15:59:12.976718
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": String()}),
        Reference,
    )



# Generated at 2022-06-12 15:59:20.998698
# Unit test for function from_json_schema_type

# Generated at 2022-06-12 15:59:29.817646
# Unit test for function from_json_schema
def test_from_json_schema():
    # Basic
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": ["string", "integer"]}) == String() | Integer()
    assert from_json_schema({"enum": [1, 2, 3]}) == Const([1, 2, 3])
    assert from_json_schema({"const": 1}) == Const(1)
    assert from_json_schema({"allOf": [{"type": "string"}, {"minLength": 0}]}) == (
        String() & Integer(minimum=0)
    )

# Generated at 2022-06-12 15:59:55.273279
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    def make_schema(cls):
        schema_cls = make_schema_class(
            "MySchema",
            field=cls(),
            strict=True,
            options=SchemaOptions(unknown=EXCLUDE),
        )
        return schema_cls()

    schema1 = make_schema(String)
    schema2 = make_schema(AllOf)
    schema3 = make_schema(AnyOf)
    schema4 = make_schema(OneOf)
    schema5 = make_schema(Not)
    schema6 = make_schema(IfThenElse)


# Generated at 2022-06-12 15:59:58.912448
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {'type': ['boolean', 'string', 'null']}
    field = type_from_json_schema(data, definitions={})
    assert isinstance(field, Union)
    assert len(field.any_of) == 3
    assert field.allow_null



# Generated at 2022-06-12 16:00:03.936789
# Unit test for function to_json_schema

# Generated at 2022-06-12 16:00:13.558135
# Unit test for function from_json_schema_type