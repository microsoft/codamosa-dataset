

# Generated at 2022-06-12 15:51:27.130295
# Unit test for function enum_from_json_schema

# Generated at 2022-06-12 15:51:33.067282
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Integer(minimum=10)
    foo = Any()
    foo.bind("#/definitions/foo", definitions)

    schema = {"$ref": "#/definitions/foo"}
    assert isinstance(from_json_schema(schema, definitions=definitions), Reference)



# Generated at 2022-06-12 15:51:40.797652
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        'if': {'const': 'string'},
        'then': {'const': 'Composite'}
    }
    definitions = SchemaDefinitions()
    definitions[''] = Any()
    field = if_then_else_from_json_schema(data, definitions)
    json_schema = field.to_json_schema()
    assert json_schema == {
        'const': 'Composite',
        'if': {
            'const': 'string'
        }
    }



# Generated at 2022-06-12 15:51:46.576851
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field1=Boolean()
    field2=String()
    field3=Float()
    field4=Integer()
    field5=Object()
    field6=Array()
    data={"anyOf":[field1,field2,field3,field4,field5,field6]}
    field=any_of_from_json_schema(data,definitions)
    assert isinstance(field,Union)


# Generated at 2022-06-12 15:51:57.995532
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_data_1 = {"not": {"type": "integer"}}
    not_field_1 = not_from_json_schema(not_data_1, definitions=None)
    not_data_2 = {"not": {"type": "string"}}
    not_field_2 = not_from_json_schema(not_data_2, definitions=None)
    not_field_1.validate(0)
    not_field_2.validate(0)
    with pytest.raises(ValidationError):
        not_field_1.validate("0")
    with pytest.raises(ValidationError):
        not_field_2.validate("0")


# Generated at 2022-06-12 15:52:09.929377
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        '$schema': 'http://json-schema.org/draft-07/schema#',
        'definitions': {
            'number': {
                'allOf': [
                    {'type': 'number'},
                    {'minimum': 0},
                ],
            },
        },
        'allOf': [
            {'$ref': '#/definitions/number'},
            {'$ref': '#/definitions/number'},
        ],
    }
    assert all_of_from_json_schema(schema, {})
    assert all_of_from_json_schema(schema, {}).validate(1) is True
    assert all_of_from_json_schema(schema, {}).validate(-1) is False



# Generated at 2022-06-12 15:52:14.108703
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {}
    data["oneOf"] = [data]
    schema = one_of_from_json_schema(data, SchemaDefinitions())
    with pytest.raises(ResolverException):
        schema.resolve(data)


# Generated at 2022-06-12 15:52:24.662859
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test single choice
    choices = [
        (["a"], ['a']),
        ((1,), [1]),
        ((1, 2), [1, 2]),
        (['a', 'b'], ['a', 'b']),
        (([1], [2]), [[1], [2]]),
    ]
    for choice, enum in choices:
        choice_field = Choice(choices=choice)
        schema_field = enum_from_json_schema({"enum": enum})
        assert choice_field, "Choice field could not be created"
        assert schema_field, "Schema field could not be created"
        # Check that all values are valid for both
        for value in choice:
            assert choice_field.is_valid(value), f'Choice Field fails to validate {value}'

# Generated at 2022-06-12 15:52:36.355380
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == to_json_schema(String(allow_null=False)) == {
        "type": "string"
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    # Multiple types, multiple properties
    multi_arg = String(min_length=1, max_length=5, default="hello")
    assert to_json_schema(multi_arg) == {
        "type": ["string", "null"],
        "default": "hello",
        "minLength": 1,
        "maxLength": 5,
    }
    # Multiple types, single property
    multi_arg = String(allow_null=True, default="hello")

# Generated at 2022-06-12 15:52:45.972443
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = Const(const=True)
    then_clause = Const(const="hello world")
    else_clause = Const(const=False)
    if_then_else_field = if_then_else_from_json_schema(
        {
            "if": {"const": True},
            "then": {"const": "hello world"},
            "else": {"const": False},
        },
        definitions={},
    )
    assert if_then_else_field.if_clause == if_clause
    assert if_then_else_field.then_clause == then_clause
    assert if_then_else_field.else_clause == else_clause



# Generated at 2022-06-12 15:53:12.277303
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number", False, None), Float)
    assert isinstance(from_json_schema_type({}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({}, "string", False, None), String)
    assert isinstance(from_json_schema_type({}, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False, None), Array)
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)

    with pytest.raises(AssertionError, match="Invalid argument type_string='xxx'"):
        from_json_schema_type({}, "xxx", False, None)



# Generated at 2022-06-12 15:53:14.057128
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from pytest import raises

    with raises(AssertionError):
        from_json_schema_type({}, "invalid_type_string", False, definitions=None)



# Generated at 2022-06-12 15:53:24.076546
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem.types import Array, Choice, Const
    assert enum_from_json_schema(
        dict(enum=["value"]), definitions=None) == Choice(choices=[('value', 'value')])
    assert enum_from_json_schema(
        dict(enum=["value", "value"]), definitions=None) == Choice(choices=[('value', 'value')])
    assert enum_from_json_schema(
        dict(enum=["value1", "value2"]), definitions=None) == Choice(choices=[('value1', 'value1'), ('value2', 'value2')])

# Generated at 2022-06-12 15:53:28.794099
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, "2"]}
    enum_field = enum_from_json_schema(data, definitions)
    assert enum_field.validate(1) == 1
    assert enum_field.validate("2") == "2"
    assert enum_field.validate("3") == "2"



# Generated at 2022-06-12 15:53:36.521081
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    with pytest.raises(Exception) as e_info:
        one_of_from_json_schema(data=[1, 2, 3], definitions=[1])
    with pytest.raises(Exception) as e_info:
        one_of_from_json_schema(data={"oneOf": [1, 2, 3]}, definitions=[1])
    with pytest.raises(Exception) as e_info:
        one_of_from_json_schema(data={"oneOf": [1, 2, 3]}, definitions=SchemaDefinitions)



# Generated at 2022-06-12 15:53:42.920591
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    f = any_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert isinstance(f, Union)
    assert isinstance(f._any_of[0], String)
    assert isinstance(f._any_of[1], Integer)



# Generated at 2022-06-12 15:53:50.117627
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "string", "maxLength": 4},
            {"type": "string", "maxLength": 10, "enum": ["foo", "bar", "baz"]},
            {
                "type": "object",
                "required": ["a", "b"],
                "properties": {
                    "a": {"type": "integer", "minimum": 1, "maximum": 10},
                    "b": {"type": "integer", "minimum": 1, "maximum": 10},
                },
            },
        ]
    }
    data = None
    field = any_of_from_json_schema(schema, definitions=None)
    assert field.validate(data) == (False, [{'type': 'any_of'}])

    data = "abcde"

# Generated at 2022-06-12 15:54:01.070898
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(allow_blank=True)) == {
        "type": "string",
        "minLength": 0,
    }

    test_schema = Schema(
        name=String(allow_blank=False),
        age=Integer(minimum=0),
        phones=Array(items=String(allow_blank=False), min_items=1, max_items=5),
    )

# Generated at 2022-06-12 15:54:07.291847
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "null"},
            {"type": "string"},
            {"type": "integer"},
            {"type": "object"},
            {"type": "boolean"},
            {"type": "number"},
        ]
    }
    kwargs = {"one_of": [
        {
            True: Const(None),
            False: NeverMatch()
        }[True],
        String(),
        Integer(),
        Object(),
        Boolean(),
        Number(),
    ], "default": NO_DEFAULT}
    assert one_of_from_json_schema(data, definitions=None) == OneOf(**kwargs)



# Generated at 2022-06-12 15:54:12.241502
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {'enum': ['red', 'amber', 'green'],
            'default': 'red'}
    schema = enum_from_json_schema(data, None)
    assert schema.validate('red') == 'red'
    assert schema.validate('amber') == 'amber'
    assert schema.validate('green') == 'green'
    assert schema.validate('blue') == 'red'


# Generated at 2022-06-12 15:54:38.454044
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    class Robby(Schema):
        name = String(required=True, allow_blank=False)
        age = Integer(required=True)
        alive = Boolean(required=True, default=True)
        weight = Float(required=True, minimum=0, maximum=400)
        height = Float(required=True, minimum=0, maximum=400)
        favorite_aliens = Array(required=True, items=String(allow_blank=False))

    data = to_json_schema(Robby)


# Generated at 2022-06-12 15:54:48.904737
# Unit test for function from_json_schema

# Generated at 2022-06-12 15:55:01.091598
# Unit test for function to_json_schema
def test_to_json_schema():
    from .fields import String, Integer, Boolean, OneOf, Not, TypedDict, Reference
    from .schema import Schema, field
    from .to_json_schema import to_json_schema

    actual = to_json_schema(String())
    expected = {
        "type": "string",
    }
    assert actual == expected, f"Invalid JSON Schema: {actual!r} != {expected!r}"

    actual = to_json_schema(Integer())
    expected = {
        "type": "integer",
    }
    assert actual == expected, f"Invalid JSON Schema: {actual!r} != {expected!r}"

    actual = to_json_schema(OneOf([String(), Integer()]))

# Generated at 2022-06-12 15:55:09.677214
# Unit test for function to_json_schema
def test_to_json_schema():
    assert_equal(
        to_json_schema(from_json_schema({"type": "integer"})),
        {"type": "integer"})
    assert_equal(
        to_json_schema(from_json_schema({"type": "integer", "default": 5})),
        {"type": "integer", "default": 5})
    assert_equal(
        to_json_schema(from_json_schema({"type": "string"})),
        {"type": "string"})
    assert_equal(
        to_json_schema(from_json_schema({"type": "boolean"})),
        {"type": "boolean"})

# Generated at 2022-06-12 15:55:18.140280
# Unit test for function to_json_schema
def test_to_json_schema():
    from .tests import simple_schema as schema

    field = schema.get_field("top_object")
    data = to_json_schema(field)

    assert data["$schema"] == "http://json-schema.org/draft-07/schema#"
    assert len(data["definitions"]) == 11
    assert data["definitions"]["top_object"] == data["definitions"]["inner_object"]

# Generated at 2022-06-12 15:55:21.826530
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    reference_string = data["$ref"]
    assert reference_string.startswith("#/"), "Unsupported $ref style in document."
    Reference(to=reference_string, definitions=SchemaDefinitions())



# Generated at 2022-06-12 15:55:31.809604
# Unit test for function from_json_schema
def test_from_json_schema(): # pylint: disable=unused-variable
    # JSON Schema: https://json-schema.org/draft/2019-09/json-schema-validation.html
    assert isinstance(from_json_schema(True), Any)
    assert isinstance(from_json_schema(False), NeverMatch)
    assert from_json_schema({"$ref": "#"}) == Reference("#")
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-12 15:55:35.871514
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """Test function ref_from_json_schema"""
    assert ref_from_json_schema({'$ref': '#/foo/bar'}) == Reference(definitions=definitions, to='#/foo/bar')



# Generated at 2022-06-12 15:55:45.698017
# Unit test for function to_json_schema
def test_to_json_schema():
    # fmt: off
    data: dict = to_json_schema(Person, _definitions=None)
    assert data == {
        "definitions": {
            "Person": {
                "type": "object",
                "properties": {
                    "age": {
                        "type": ["integer", "null"],
                        "minimum": 0,
                        "maximum": 200,
                    },
                    "name": {
                        "type": ["string", "null"],
                        "minLength": 1,
                    },
                }
            }
        }
    }

    data: dict = to_json_schema(Pet, _definitions=None)

# Generated at 2022-06-12 15:55:53.255482
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = from_json_schema(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string", "pattern": "^[A-Za-z]+$"},
                "age": {"type": "integer", "minimum": 0, "maximum": 150},
                "pets": {
                    "type": "array",
                    "items": {"type": "string"},
                    "additionalItems": False,
                    "minItems": 1,
                },
            },
            "required": ["name"],
            "additionalProperties": False,
        }
    )
    assert schema.is_valid({"name": "Luke", "age": 24, "pets": ["dog", "cat"]})

# Generated at 2022-06-12 15:57:19.272293
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(Integer(allow_null=False)) == {
        "type": "integer",
        "default": NO_DEFAULT
    }

    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["integer", "null"],
        "default": NO_DEFAULT
    }

    assert to_json_schema(Integer(maximum=3, allow_null=False)) == {
        "type": "integer",
        "maximum": 3,
        "default": NO_DEFAULT
    }


# Generated at 2022-06-12 15:57:31.395117
# Unit test for function to_json_schema
def test_to_json_schema():  # pragma: no cover
    # Consider using a string constant for the arguments to create a precise
    # test case.
    assert to_json_schema(
        Array(
            items=String(),
            unique_items=True,
            allow_blank=True,
            nullable=True,
            description="A list",
        ),
    ) == {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": ["array", "null"],
        "items": {"type": ["string", "null"]},
        "uniqueItems": True,
        "nullable": True,
        "description": "A list",
    }

    assert to_json_schema(Any()) == {"$schema": "http://json-schema.org/draft-07/schema#"}

# Generated at 2022-06-12 15:57:40.285837
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "format": "email",
        "pattern": ".*",
        "default": "",
    }
    result = from_json_schema_type(data, type_string="string", allow_null=False, definitions=None)
    assert result == String(
        allow_null=False,
        allow_blank=False,
        min_length=1,
        max_length=10,
        format="email",
        pattern=".*",
        default="",
    )



# Generated at 2022-06-12 15:57:42.706988
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}



# Generated at 2022-06-12 15:57:52.775090
# Unit test for function to_json_schema

# Generated at 2022-06-12 15:58:03.717279
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Field(type=str, allow_null=False, default=NO_DEFAULT)
    assert to_json_schema(field) == {"type": "string"}

    field = Field(type=str, allow_null=True, default=NO_DEFAULT)
    assert to_json_schema(field) == {"type": ["string", "null"]}

    field = Field(type=str, allow_null=False, default="hello")
    assert to_json_schema(field) == {"type": "string", "default": "hello"}

    field = Field(
        type=str, allow_null=False, default="hello", min_length=1, max_length=50
    )

# Generated at 2022-06-12 15:58:13.757004
# Unit test for function to_json_schema
def test_to_json_schema():
    from .fields import String, Integer

    schema = String(required=True) * 2
    assert to_json_schema(schema) == {
        "type": "array",
        "items": {"type": "string"},
        "minItems": 2,
        "maxItems": 2,
        "uniqueItems": True,
    }

    schema = Integer(minimum=0, maximum=10) | Integer(minimum=100)
    assert to_json_schema(schema) == {
        "oneOf": [
            {"type": "integer", "minimum": 0, "maximum": 10},
            {"type": "integer", "minimum": 100},
        ]
    }

    schema = Integer(minimum=0) + Integer(maximum=100)

# Generated at 2022-06-12 15:58:19.473538
# Unit test for function to_json_schema
def test_to_json_schema():  # type: ignore
    definitions = {}
    schema = to_json_schema(
        String(format="date-time", min_length=1, max_length=10, null=True),
        _definitions=definitions,
    )
    assert "definitions" not in schema
    assert schema["type"] == ["string", "null"]
    assert schema["format"] == "date-time"
    assert schema["minLength"] == 1
    assert schema["maxLength"] == 10
    
    schema = to_json_schema(
        String(format="date-time", min_length=1, max_length=10, null=True),
        _definitions=definitions,
    )
    assert defi

# Generated at 2022-06-12 15:58:26.478389
# Unit test for function from_json_schema
def test_from_json_schema():
    # pylint: disable=line-too-long
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({}) == Any()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "number", "format": "integer"}) == Integer()
    assert from_json_schema({"type": "number", "format": "float"}) == Float()
    assert from_json_schema({"type": "number", "format": "decimal"}) == Decimal()
    assert from_json_schema({"type": "string"}) == String()


# Generated at 2022-06-12 15:58:34.893695
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(String) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_null=True, allow_blank=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(Integer) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_sche

# Generated at 2022-06-12 15:58:58.435133
# Unit test for function to_json_schema
def test_to_json_schema():
    class NestedSchema(Schema):
        foo = String(default="Hello")
        bar = Integer(minimum=1, maximum=100, default=5)

    class MySchema(Schema):
        name = String(default="John Smith")
        age = Integer(minimum=0, maximum=100, default=26)
        email = String(format="email")
        is_lucky_number = Boolean(default=False)
        favorite_numbers = Array(
            items=Integer(minimum=0), default=[7, 11, 13, 17, 19]
        )
        favorite_foods = Object(
            properties={"kofta": Integer(minimum=0), "sambusa": Integer(minimum=0)}
        )

# Generated at 2022-06-12 15:59:08.180148
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["integer", "number"]}) == Number()
    assert from_json_schema({"type": "integer", "minimum": 1, "maximum": 3}) == Integer(
        minimum=1, maximum=3
    )
    assert from_json_schema({"type": "integer", "enum": [1, 2, 3], "minimum": 1}) == Choice(
        [Integer(1), Integer(2), Integer(3)]
    )
    assert from_json_schema({"type": "array", "items": {"type": "integer"}}) == Array(
        items=Integer()
    )

# Generated at 2022-06-12 15:59:19.180891
# Unit test for function to_json_schema
def test_to_json_schema():  # type: () -> None

    schema = Object(
        properties={
            "list": Array(
                items=Union(
                    elements=[
                        Integer(
                            minimum=0,
                            exclusive_minimum=True,
                            maximum=100,
                            exclusive_maximum=True,
                        ),
                        String(
                            min_length=1,
                            max_length=20,
                            pattern_regex=re.compile("[a-z]+", re.RegexFlag.UNICODE),
                            format=StringFormat.uri,
                            allow_blank=False,
                        ),
                    ]
                )
            )
        }
    )


# Generated at 2022-06-12 15:59:26.834213
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {
        "type": "number",
        "minimum": 0,
        "maximum": 100,
        "exclusiveMinimum": 0,
        "exclusiveMaximum": 100,
        "multipleOf": 1,
        "default": 50,
    }

    field = from_json_schema(schema)
    assert isinstance(field, Float)
    assert field.minimum == 0
    assert field.maximum == 100
    assert field.exclusive_minimum == 0
    assert field.exclusive_maximum == 100
    assert field.multiple_of == 1
    assert field.default == 50



# Generated at 2022-06-12 15:59:37.109332
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice()) == {"enum": []}
    assert to_json_schema(Integer() | Boolean()) == {"anyOf": [{"type": "integer"}, {"type": "boolean"}]}
    assert to_json_schema(Integer() & Boolean()) == {"allOf": [{"type": "integer"}, {"type": "boolean"}]}

# Generated at 2022-06-12 15:59:49.167466
# Unit test for function to_json_schema
def test_to_json_schema():

    class MySchema(Schema):
        x = Integer(minimum=0, maximum=10)
        y = String(min_length=10)

    schema = MySchema()
    assert schema.to_json_schema() == {
        "definitions": {
            "MySchema": {
                "type": "object",
                "required": ["x", "y"],
                "properties": {
                    "x": {
                        "type": "integer",
                        "minimum": 0,
                        "maximum": 10,
                    },
                    "y": {
                        "type": "string",
                        "minLength": 10,
                    },
                },
            },
        },
        "$ref": "#/definitions/MySchema",
    }



# Generated at 2022-06-12 15:59:57.265207
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {"number": Integer(min_value=1, max_value=100).comment("a number from 1 to 100")},
        definitions = {
            "address": Schema(
                {
                    "street_name": String(min_length=5, max_length=100),
                    "street_number": String(r"^\d+$"),
                    "city": String(r"^[A-Z\s]+$"),
                    "postcode": String(r"^\d{4}$"),
                    "country": String(allowed_values=["AU", "NZ", "US", "GB", "FR"]),
                }
            )
        },
    )


# Generated at 2022-06-12 16:00:05.252700
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({'type': 'boolean'}) == Boolean()
    assert from_json_schema({'type': 'number'}) == Number()
    assert from_json_schema({'type': 'string'}) == String()
    assert from_json_schema({'type': 'object'}) == Object()
    assert from_json_schema({'type': 'array'}) == Array()
    assert from_json_schema({'type': 'null'}) == Const(None)

# Generated at 2022-06-12 16:00:14.381303
# Unit test for function from_json_schema
def test_from_json_schema():
    json_schema = {
        "type": "object",
        "properties": {
            "id": {"type": "integer"},
            "name": {"type": "string"},
        },
    }
    schema = Schema.from_json_schema(json_schema)
    assert schema.validate({"id": 1, "name": "foo"}) == {}
    assert "Invalid type" in schema.validate({"id": 1, "name": 3})["name"]
    assert "Required" in schema.validate({"name": "foo"})["id"]
