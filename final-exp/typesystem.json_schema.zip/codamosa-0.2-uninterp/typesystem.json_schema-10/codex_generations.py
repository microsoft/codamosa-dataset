

# Generated at 2022-06-18 12:24:54.716808
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("c") == "c"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("c") == "c"
   

# Generated at 2022-06-18 12:25:00.190629
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("c") == "c"



# Generated at 2022-06-18 12:25:06.915293
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "number"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, String)
    assert isinstance(field.else_clause, Float)



# Generated at 2022-06-18 12:25:16.434930
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:25:20.015778
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions), Reference)



# Generated at 2022-06-18 12:25:28.342466
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": [
            "red",
            "amber",
            "green",
        ],
    }
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("red") == "red"
    assert field.validate("amber") == "amber"
    assert field.validate("green") == "green"
    assert field.validate("blue") == "blue"



# Generated at 2022-06-18 12:25:34.405682
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": ["string", "null"]}, definitions=SchemaDefinitions()) == Union(any_of=[String(), Const(None)])
    assert type_from_json_schema({"type": ["string", "null"], "minLength": 1}, definitions=SchemaDefinitions()) == Union(any_of=[String(min_length=1), Const(None)])
    assert type_from_json_schema({"type": "string", "minLength": 1}, definitions=SchemaDefinitions()) == String(min_length=1)
    assert type_

# Generated at 2022-06-18 12:25:37.571604
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:25:50.045165
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from

# Generated at 2022-06-18 12:26:00.874259
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
            {"maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") == "abcdefghij"
    assert field.validate(None) == ""
    assert field.validate(1) == "1"
    assert field.validate(1.0) == "1.0"
    assert field.validate(True) == "True"
    assert field.valid

# Generated at 2022-06-18 12:26:30.558935
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(any_of=[String(), Integer()])



# Generated at 2022-06-18 12:26:35.217375
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 2}]}, definitions=definitions) == AllOf(all_of=[String(), String(min_length=2)])
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 2}], "default": "hello"}, definitions=definitions) == AllOf(all_of=[String(), String(min_length=2)], default="hello")


# Generated at 2022-06-18 12:26:36.466349
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema({}, None), IfThenElse)



# Generated at 2022-06-18 12:26:40.682187
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions)
    assert field.validate("") == "This field may not be blank."
    assert field.validate("abc") == None
    assert field.validate("abcdefghijklmnopqrstuvwxyz") == "Ensure this field has no more than 10 characters."
    assert field.validate("abcdefghijklmnopqrstuvwxyz123") == "Ensure this field has no more than 10 characters."

# Generated at 2022-06-18 12:26:44.775612
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("bar") == "foo"



# Generated at 2022-06-18 12:26:54.429273
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate(0) == 0
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(None) is None
    assert field.validate(1.0) == 1.0
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []

# Generated at 2022-06-18 12:27:04.673624
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:27:16.056454
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:27:24.537051
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Schema

    class TestSchema(Schema):
        string = String()
        integer = Integer()
        float = Float()
        boolean = Boolean()
        array = Array(items=Integer())
        object = Object(properties={"string": String()})
        choice = Choice(choices=[("a", "a"), ("b", "b")])
        const = Const(const="a")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])

# Generated at 2022-06-18 12:27:32.803113
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
        "default": "",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == ""
    assert field.if_clause.type == "string"
    assert field.then_clause.type == "integer"
    assert field.else_clause.type == "number"



# Generated at 2022-06-18 12:28:26.401301
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:28:33.600996
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "pattern": "^[0-9]{3}-[0-9]{2}-[0-9]{4}$"
        },
        "then": {
            "type": "string",
            "pattern": "^[0-9]{3}-[0-9]{2}-[0-9]{4}$"
        },
        "else": {
            "type": "string",
            "pattern": "^[0-9]{3}-[0-9]{2}-[0-9]{4}$"
        }
    }
    definitions = SchemaDefinitions()
    field = if_then_else_from_json_schema(data, definitions)

# Generated at 2022-06-18 12:28:45.465340
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:28:56.074217
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema.make_validator()
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema.make_validator(allow_null=True)
    assert to_json_schema(schema) == {
        "type": ["object", "null"],
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema.make_validator(allow_blank=True)

# Generated at 2022-06-18 12:29:04.591569
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": "^\\d+$",
    }
    assert to_

# Generated at 2022-06-18 12:29:15.050656
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
                "pattern": "^[a-zA-Z0-9]+$",
            },
            {"type": "string", "minLength": 5},
        ]
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("abcde") == "abcde"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz") is None

# Generated at 2022-06-18 12:29:25.109713
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:29:35.673439
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:29:42.393717
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_clause.type_string == "string"
    assert field.then_clause.type_string == "string"
    assert field.else_clause.type_string == "integer"
    assert field.default == NO_DEFAULT



# Generated at 2022-06-18 12:29:52.700687
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-18 12:30:16.588195
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2,
            "pattern": "^[a-z]{1,2}$",
        },
        "then": {"type": "integer", "minimum": 1, "maximum": 10},
        "else": {"type": "integer", "minimum": 11, "maximum": 20},
    }
    schema = if_then_else_from_json_schema(data, definitions=None)
    assert schema.validate("a") == 1
    assert schema.validate("aa") == 1
    assert schema.validate("ab") == 11
    assert schema.validate("abc") == 11
    assert schema.validate("") == 11
    assert schema.validate(None) == 11
    assert schema

# Generated at 2022-06-18 12:30:24.400274
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_clause.type == "string"
    assert field.then_clause.min_length == 1
    assert field.else_clause.type == "integer"



# Generated at 2022-06-18 12:30:35.979138
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_blank=False)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:30:45.427695
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema(allow_unknown=True)
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
        "additionalProperties": True,
    }

    schema = TestSchema(allow_unknown=False)
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:30:53.595830
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "boolean"},
    }
    result = if_then_else_from_json_schema(data, definitions=None)
    assert result.validate("foo") == 0
    assert result.validate(1) == 0
    assert result.validate(False) == 0
    assert result.validate(None) == 1
    assert result.validate(1.0) == 1
    assert result.validate([]) == 1
    assert result.validate({}) == 1

# Generated at 2022-06-18 12:31:01.368323
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:13.164477
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:23.082647
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-18 12:31:30.237527
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"type": "integer"},
        "default": "default",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == "default"
    assert field.if_clause.type == "string"
    assert field.then_clause.min_length == 1
    assert field.else_clause.type == "integer"



# Generated at 2022-06-18 12:31:37.311294
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:01.825556
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    class TestSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    schema = TestSchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["name", "age"],
    }

    class TestSchema2(Schema):
        name = fields.String()
        age = fields.Integer()

        class Meta:
            title = "Test Schema"

    schema = TestSchema2()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:32:09.058837
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:32:19.910639
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:32:29.205346
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema(allow_null=True)
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": ["object", "null"],
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema(allow_blank=True)
    json_schema = to_json_schema(schema)

# Generated at 2022-06-18 12:32:39.570574
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        String(), Const(None)
    )

# Generated at 2022-06-18 12:32:48.313581
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

    assert from_json_

# Generated at 2022-06-18 12:32:58.308954
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:33:04.712198
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:14.497858
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:33:23.289371
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:43.882715
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])