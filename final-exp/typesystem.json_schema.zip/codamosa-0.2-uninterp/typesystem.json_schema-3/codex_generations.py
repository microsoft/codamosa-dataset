

# Generated at 2022-06-18 12:25:06.036748
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("a")
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("b")
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("c")
    assert not enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("d")
    assert enum_from_json_schema({"enum": ["a", "b", "c"], "default": "b"}, definitions=None).validate(None)

# Generated at 2022-06-18 12:25:15.160726
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "enum": ["a", "b", "c"]},
            {"type": "string", "enum": ["d", "e", "f"]},
        ],
        "default": "a",
    }
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions=definitions) == OneOf(
        one_of=[
            Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")]),
            Choice(choices=[("d", "d"), ("e", "e"), ("f", "f")]),
        ],
        default="a",
    )



# Generated at 2022-06-18 12:25:21.208051
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks

    from . import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Float,
        Integer,
        Not,
        Object,
        OneOf,
        Reference,
        Schema,
        String,
        Union,
        IfThenElse,
        AllOf,
    )

    class MySchema(Schema):
        """
        Test schema
        """

        a = Integer(minimum=1, maximum=10)
        b = String(min_length=1, max_length=10)
        c

# Generated at 2022-06-18 12:25:32.950708
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:25:46.389246
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "enum": [
            "a",
            "b",
            "c"
        ]
    }
    field = enum_from_json_schema(schema, definitions)
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"
    assert field.validate("e") == "e"
    assert field.validate("f") == "f"
    assert field.validate("g") == "g"
    assert field.validate("h") == "h"
    assert field.validate("i") == "i"
    assert field.validate("j") == "j"
    assert field.validate("k")

# Generated at 2022-06-18 12:25:56.649012
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 4}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=4)

# Generated at 2022-06-18 12:26:01.345987
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "test"}
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.validate("test") == "test"
    assert field.validate("test2") == "test"



# Generated at 2022-06-18 12:26:13.314976
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Test that the function works with all combinations of if, then and else
    # clauses.
    schema = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.validate(1) == "1"
    assert field.validate(True) == True
    assert field.validate(None) == None

    schema = {"if": {"type": "integer"}, "then": {"type": "string"}}
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.validate(1) == "1"
    assert field.validate(True) == True


# Generated at 2022-06-18 12:26:17.667532
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "number"},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("") is None
    assert field.validate(1) is None
    assert field.validate(1.0) is None
    assert field.validate(None) is None
    assert field.validate(True) is not None
    assert field.validate(False) is not None
    assert field.validate({"a": 1}) is not None
    assert field.validate([1]) is not None



# Generated at 2022-06-18 12:26:25.141531
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=Float(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "number"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:27:00.418495
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:27:10.113101
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:27:20.959799
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }


# Generated at 2022-06-18 12:27:26.328941
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:27:38.930456
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:27:46.290395
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:27:57.828280
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z]+$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("123") == "123"
    assert field.validate("abc") is None
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:28:07.135159
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema, String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions
    from .fields import NO_DEFAULT

    class TestSchema(Schema):
        string = String(min_length=1, max_length=10, pattern_regex=r"^[a-z]+$")
        integer = Integer(minimum=0, maximum=10, multiple_of=2)
        boolean = Boolean()
        array = Array(items=String(min_length=1, max_length=10))
        object = Object(properties={"string": String(min_length=1, max_length=10)})
        choice = Choice(choices=[("a", "a"), ("b", "b")])

# Generated at 2022-06-18 12:28:18.350876
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import Schema, SchemaDefinitions

    class TestSchema(Schema):
        string = String()
        integer = Integer()
        boolean = Boolean()
        array = Array(items=String())
        object = Object(properties={"string": String()})
        choice = Choice(choices=[("a", "a"), ("b", "b")])
        const = Const(const="a")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])

# Generated at 2022-06-18 12:28:26.902014
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float(allow_null=False)
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer(allow_null=False)
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String(allow_null=False)
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean(allow_null=False)
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array(allow_null=False)
    assert from_json_schema

# Generated at 2022-06-18 12:28:52.920018
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse

    # Test basic types
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array(items=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }
    assert to_json_schema(Object(properties={"foo": String()})) == {
        "type": "object",
        "properties": {"foo": {"type": "string"}},
    }

    # Test nullable types
    assert to_json

# Generated at 2022-06-18 12:29:02.705598
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=definitions) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=definitions) == Boolean()
    assert type_from_json_schema({"type": "array"}, definitions=definitions) == Array()
    assert type_from_json_schema({"type": "object"}, definitions=definitions) == Object()
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)

# Generated at 2022-06-18 12:29:08.691997
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:29:13.771312
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:29:23.175671
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:29:28.853291
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions



# Generated at 2022-06-18 12:29:39.270837
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:29:46.909829
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern=re.compile("^[a-z]+$")
    )
    assert from_json_schema({"type": "string", "format": "date"}) == String(
        format="date"
    )

# Generated at 2022-06-18 12:29:57.322854
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 2,
            "pattern": "^[a-z]+$",
        },
        "then": {"type": "integer", "minimum": 0, "maximum": 100},
        "else": {"type": "integer", "minimum": 0, "maximum": 100},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, Integer)
    assert isinstance(field.else_clause, Integer)



# Generated at 2022-06-18 12:30:07.028390
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 5}) == String(min_length=5)
    assert from_json_schema({"type": "string", "maxLength": 5}) == String(max_length=5)
    assert from_json_schema({"type": "string", "pattern": "^[0-9]+$"}) == String(
        pattern=re.compile("^[0-9]+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "number"}) == Number()

# Generated at 2022-06-18 12:30:35.269806
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Integer()
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:30:44.164029
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:54.902293
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
    from . import Schema
    from . import NO_DEFAULT
    from . import SchemaDefinitions
   

# Generated at 2022-06-18 12:30:58.141078
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/foo",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:31:09.672271
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:20.333687
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference
    from . import SchemaDefinitions, Schema

    class MySchema(Schema):
        foo = String(max_length=10)
        bar = Integer(minimum=0)
        baz = Boolean()
        qux = Array(items=Integer())
        quux = Object(properties={"a": Integer(), "b": Integer()})
        corge = Choice(choices=[(1, "one"), (2, "two")])
        grault = Const(const=1)
        garply = Union(any_of=[Integer(), String()])
        waldo = OneOf(one_of=[Integer(), String()])
        fred = AllOf(all_of=[Integer(), String()])

# Generated at 2022-06-18 12:31:30.452288
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    schema = fields.Object(
        properties={
            "name": fields.String(max_length=100),
            "age": fields.Integer(minimum=0, maximum=150),
            "address": fields.Object(
                properties={
                    "street": fields.String(max_length=100),
                    "city": fields.String(max_length=100),
                    "state": fields.String(max_length=2),
                    "zip": fields.String(max_length=10),
                }
            ),
            "phone": fields.Array(
                items=fields.String(max_length=20), min_items=1, max_items=3
            ),
        },
        required=["name", "age"],
    )
    data = to_json_schema(schema)
    assert data

# Generated at 2022-06-18 12:31:32.454644
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:31:41.653323
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:31:52.527973
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:32:10.881144
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:32:19.205465
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
        is_admin = Boolean()
        tags = Array(items=String(max_length=10))

    schema = TestSchema()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:32:26.016385
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:32:36.101801
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()

# Generated at 2022-06-18 12:32:45.655673
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=no-member
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(max_length=10)) == {
        "type": "string",
        "maxLength": 10,
    }

# Generated at 2022-06-18 12:32:55.371965
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import Schema, SchemaDefinitions

    class TestSchema(Schema):
        a = String()
        b = Integer()
        c = Float()
        d = Boolean()
        e = Array(String())
        f = Object(properties={"g": String()})
        h = Choice(choices=[("a", "a"), ("b", "b")])
        i = Const("a")
        j = Union(String(), Integer())
        k = OneOf(String(), Integer())
        l = AllOf(String(), Integer())
        m = IfThenElse(String(), then_clause=Integer())
        n = Not(String())

    schema = TestSchema()
    data

# Generated at 2022-06-18 12:33:02.514732
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const
    from . import Union, OneOf, AllOf, IfThenElse, Not, Reference

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

# Generated at 2022-06-18 12:33:08.272399
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == NeverMatch()

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-18 12:33:18.189555
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    assert to_json_schema(fields.Any()) == True
    assert to_json_schema(fields.NeverMatch()) == False

    assert to_json_schema(fields.String()) == {"type": "string"}
    assert to_json_schema(fields.String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(fields.String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(fields.String(max_length=10)) == {
        "type": "string",
        "maxLength": 10,
    }

# Generated at 2022-06-18 12:33:26.842885
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(String(), Const(None))

# Generated at 2022-06-18 12:33:50.617192
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("a"))) == {
        "type": "string",
        "pattern": "a",
    }