

# Generated at 2022-06-18 12:25:19.234110
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=definitions) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=definitions) == Boolean()
    assert type_from_json_schema({"type": "object"}, definitions=definitions) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=definitions) == Array()
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)


# Generated at 2022-06-18 12:25:26.953682
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": "test",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("test") == "test"
    assert field.validate(1) == 1



# Generated at 2022-06-18 12:25:37.732688
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]+$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") is None
    assert field.validate("abc") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz1234567890") is None

# Generated at 2022-06-18 12:25:50.195275
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=SchemaDefinitions()) == Array()
    assert type_from_json

# Generated at 2022-06-18 12:25:56.336868
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ]
    }
    field = all_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None



# Generated at 2022-06-18 12:26:03.855146
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "hello",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("hello") == "hello"
    assert field.validate("hello world") == "hello"



# Generated at 2022-06-18 12:26:12.130826
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") is None



# Generated at 2022-06-18 12:26:16.649820
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "number", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(None) == ""
    assert field.validate("") == ""
    assert field.validate(0) == 0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(True) == ""
    assert field.validate(False) == ""

# Generated at 2022-06-18 12:26:19.413360
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:26:30.077257
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate(None) == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("baz") == "foo"



# Generated at 2022-06-18 12:27:13.901223
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
        "default": "default",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == "default"
    assert field.validate("string") == "string"
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(None) == "default"
    assert field.validate("") == "default"
    assert field.validate(True) == "default"
    assert field.validate(False) == "default"
    assert field.validate([]) == "default"

# Generated at 2022-06-18 12:27:21.716767
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("c") == "c"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("d") is None



# Generated at 2022-06-18 12:27:28.695904
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:27:40.650494
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    schema = fields.Object(
        properties={
            "name": fields.String(max_length=100),
            "age": fields.Integer(minimum=0, maximum=150),
            "address": fields.Object(
                properties={
                    "street": fields.String(max_length=100),
                    "city": fields.String(max_length=100),
                    "state": fields.String(max_length=2),
                    "zip": fields.String(max_length=10),
                }
            ),
        }
    )


# Generated at 2022-06-18 12:27:46.432299
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, {}).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, {}).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b"]}, {}).validate("c") == "c"



# Generated at 2022-06-18 12:27:57.817624
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:28:04.913156
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:28:16.064284
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "array"}, definitions=SchemaDefinitions()) == Array()
    assert type_from

# Generated at 2022-06-18 12:28:25.550188
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-18 12:28:32.887700
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:29:25.315403
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json

# Generated at 2022-06-18 12:29:35.919630
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:29:40.774310
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions



# Generated at 2022-06-18 12:29:45.886083
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, Integer)
    assert isinstance(field.else_clause, Float)



# Generated at 2022-06-18 12:29:48.976953
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert ref_from_json_schema(data, definitions=definitions) == String()



# Generated at 2022-06-18 12:30:00.969912
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:30:09.012289
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern="^[a-z]+$"
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )

# Generated at 2022-06-18 12:30:19.704648
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:24.518718
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()
    assert from_json_schema_type({}, "null", False, None) == Const(None)
    assert from_json_schema_type({}, "null", True, None) == Any()

# Generated at 2022-06-18 12:30:36.065163
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_blank=False)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}

# Generated at 2022-06-18 12:31:07.016200
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:18.397581
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:28.693786
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from .schema import Schema

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=10)) == {"type": "string", "minLength": 10}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:31:36.389263
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Const(None)]
    )

# Generated at 2022-06-18 12:31:42.709673
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
        },
        definitions=SchemaDefinitions(),
    )



# Generated at 2022-06-18 12:31:47.282023
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(
        if_then_else_from_json_schema(
            {
                "if": {"type": "string"},
                "then": {"type": "integer"},
                "else": {"type": "boolean"},
            },
            definitions=SchemaDefinitions(),
        ),
        IfThenElse,
    )



# Generated at 2022-06-18 12:31:58.686124
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:32:08.906226
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:32:15.031844
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {},
            "then": {},
            "else": {},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:32:23.352212
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:57.024931
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:33:05.268146
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == NeverMatch()
    assert from_json_schema({"type": ["string", "null"]}) == String() | NeverMatch()
    assert from_json_schema({"type": ["string", "null"], "enum": ["foo", "bar"]}) == Choice

# Generated at 2022-06-18 12:33:12.764829
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:21.604018
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "integer", "enum": [1, 2, 3]}) == Choice(
        [1, 2, 3], type=Integer()
    )

# Generated at 2022-06-18 12:33:31.011075
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 1,
            "pattern": "^[a-zA-Z]$",
        },
        "then": {"type": "string", "minLength": 1, "maxLength": 1},
        "else": {"type": "string", "minLength": 2, "maxLength": 2},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("a") == "a"
    assert field.validate("aa") == "aa"
    assert field.validate("") is None
    assert field.validate("1") is None
    assert field.validate("aaa") is None

# Generated at 2022-06-18 12:33:40.339674
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions, Schema

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        height = Float(minimum=0.0)
        is_adult = Boolean()
        children = Array(items=Reference(to="Person"))
        spouse = Reference(to="Person")

    class PersonWithDefinitions(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0)
        height = Float(minimum=0.0)
        is_adult = Boolean()
        children = Array(items=Reference(to="Person"))
        spouse = Reference(to="Person")



# Generated at 2022-06-18 12:33:50.264615
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(Integer(allow_null=True)) == {
        "type": ["integer", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(Integer(minimum=1)) == {
        "type": "integer",
        "minimum": 1,
        "default": NO_DEFAULT,
    }
    assert to_json_schema(Integer(maximum=1)) == {
        "type": "integer",
        "maximum": 1,
        "default": NO_DEFAULT,
    }