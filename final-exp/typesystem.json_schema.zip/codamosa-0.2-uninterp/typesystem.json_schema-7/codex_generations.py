

# Generated at 2022-06-18 12:25:12.922309
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()
    assert type_from_json_schema({"type": "string"}, definitions={}) == String()
    assert type_from_json_schema({"type": "integer"}, definitions={}) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions={}) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions={}) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions={}) == Const(None)
    assert type_from_json_schema({"type": "array"}, definitions={}) == Array()
    assert type_from_json_schema({"type": "object"}, definitions={}) == Object()
    assert type_from_json_sche

# Generated at 2022-06-18 12:25:15.240638
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:25:21.047982
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]+$",
        },
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Not)
    assert field.negated.__class__ == String
    assert field.negated.min_length == 1
    assert field.negated.max_length == 10
    assert field.negated.pattern == "^[a-zA-Z0-9_]+$"
    assert field.default == ""


# Generated at 2022-06-18 12:25:32.824321
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("a")
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("b")
    assert not enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("c")
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "a"}, definitions=None).validate(None)
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "a"}, definitions=None).validate("a")

# Generated at 2022-06-18 12:25:46.183162
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "null", "enum": ["foo"]}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "null", "enum": [None]}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "null", "enum": [None, "foo"]}, definitions=SchemaDefinitions()) == Const(None)
    assert type_

# Generated at 2022-06-18 12:25:50.299298
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:25:55.806229
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": [1, 2, 3],
        "default": 2
    }
    field = enum_from_json_schema(data, definitions=definitions)
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(3) == 3
    assert field.validate(4) == 2
    assert field.validate(None) == 2


# Generated at 2022-06-18 12:25:58.571352
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}) == Choice(choices=[("a", "a"), ("b", "b")])



# Generated at 2022-06-18 12:26:01.461696
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:26:13.640985
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z]+$",
        },
        "then": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z]+$",
        },
        "else": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z]+$",
        },
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("abc") == "abc"

# Generated at 2022-06-18 12:27:33.334704
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": "test",
    }
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(
        any_of=[String(), Integer()], default="test"
    )



# Generated at 2022-06-18 12:27:43.643604
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions=None).validate("bar") == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions=None).validate("baz") == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions=None).validate("foo") == "foo"

# Generated at 2022-06-18 12:27:50.072874
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "const"}
    assert const_from_json_schema(data, None).const == "const"
    data = {"const": "const", "default": "default"}
    assert const_from_json_schema(data, None).const == "const"
    assert const_from_json_schema(data, None).default == "default"



# Generated at 2022-06-18 12:27:57.898739
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("") == ""
    assert field.validate("abc") == "abc"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") == "abcdefghijk"



# Generated at 2022-06-18 12:28:01.514617
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
                "required": ["name", "age"],
            },
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
                "required": ["name", "age"],
            },
        ]
    }
    definitions = SchemaDefinitions()
    assert isinstance(one_of_from_json_schema(data, definitions), OneOf)



# Generated at 2022-06-18 12:28:12.897961
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, Schema, SchemaDefinitions

    class TestSchema(Schema):
        string = String()
        integer = Integer()
        float = Float()
        boolean = Boolean()
        array = Array(items=String())
        object = Object(properties={"string": String()})
        choice = Choice(choices=[("a", "a"), ("b", "b")])
        const = Const("a")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])

# Generated at 2022-06-18 12:28:18.499737
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "number", "minimum": 0},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1

# Generated at 2022-06-18 12:28:23.901638
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Float,
        Integer,
        NeverMatch,
        Object,
        String,
    )

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json

# Generated at 2022-06-18 12:28:30.429112
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
            {"maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") == "abcdefghijk"



# Generated at 2022-06-18 12:28:41.974533
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:37.849411
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:30:44.460361
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("a"))) == {
        "type": "string",
        "pattern": "a",
    }

# Generated at 2022-06-18 12:30:55.128886
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:31:02.195152
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array(items=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }
    assert to_json_schema(Object(properties={"foo": String()})) == {
        "type": "object",
        "properties": {"foo": {"type": "string"}},
    }

# Generated at 2022-06-18 12:31:14.382800
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"\d+"))) == {
        "type": "string",
        "pattern": r"\d+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:31:24.304154
# Unit test for function to_json_schema
def test_to_json_schema():
    def assert_json_schema(
        arg: typing.Union[Field, typing.Type[Schema]],
        expected: typing.Union[bool, dict],
        definitions: dict = None,
    ) -> None:
        actual = to_json_schema(arg, _definitions=definitions)
        assert actual == expected

    assert_json_schema(Any(), True)
    assert_json_schema(NeverMatch(), False)
    assert_json_schema(String(), {"type": "string"})
    assert_json_schema(String(allow_null=True), {"type": ["string", "null"]})
    assert_json_schema(String(default="foo"), {"type": "string", "default": "foo"})

# Generated at 2022-06-18 12:31:34.081407
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference

    assert to_json_schema(String()) == {
        "type": "string",
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
    }
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(max_length=1)) == {
        "type": "string",
        "maxLength": 1,
    }

# Generated at 2022-06-18 12:31:44.312984
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:31:55.515551
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[0-9]+$"))) == {
        "type": "string",
        "pattern": "^[0-9]+$",
    }

# Generated at 2022-06-18 12:32:06.802360
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"\d+"))) == {
        "type": "string",
        "pattern": r"\d+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:32:45.217588
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:51.667124
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:33:00.178661
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:33:08.933583
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )

# Generated at 2022-06-18 12:33:18.557838
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Const(None)])

# Generated at 2022-06-18 12:33:27.421850
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:33:37.877813
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Any()]
    )

# Generated at 2022-06-18 12:33:47.111578
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields
    from . import validators
    from . import schemas

    assert to_json_schema(fields.Any()) == True
    assert to_json_schema(fields.NeverMatch()) == False

    assert to_json_schema(fields.String()) == {"type": "string"}
    assert to_json_schema(fields.String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(fields.String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(fields.String(max_length=10)) == {
        "type": "string",
        "maxLength": 10,
    }
    assert to_json_sche