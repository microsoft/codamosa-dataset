

# Generated at 2022-06-18 12:24:52.730341
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") == "String must be at least 1 characters long."
    assert field.validate("abc") == None
    assert field.validate("abc123") == None
    assert field.validate("abc123456789") == None
    assert field.validate("abc1234567890") == "String must be at most 10 characters long."

# Generated at 2022-06-18 12:25:02.360148
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:25:13.726452
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:25:22.424465
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 1},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate(1) == 1
    assert field.validate(0) == ""
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate(None) == ""



# Generated at 2022-06-18 12:25:29.524368
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 1}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=1)



# Generated at 2022-06-18 12:25:36.494345
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None



# Generated at 2022-06-18 12:25:46.907973
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"type": "integer", "maximum": 100},
        ],
        "default": 0,
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate(0) == 0
    assert field.validate(50) == 50
    assert field.validate(100) == 100
    assert field.validate(101) == "Must be less than or equal to 100."
    assert field.validate(-1) == "Must be greater than or equal to 0."



# Generated at 2022-06-18 12:25:53.294884
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.if_clause.type == "integer"
    assert field.then_clause.type == "string"
    assert field.else_clause.type == "boolean"



# Generated at 2022-06-18 12:26:01.475882
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:26:13.728325
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=2)) == {"type": "string", "minLength": 2}
    assert to_json_schema(String(max_length=2)) == {"type": "string", "maxLength": 2}
    assert to_json_schema(String(pattern_regex=re.compile("^a+$"))) == {
        "type": "string",
        "pattern": "^a+$",
    }
    assert to_json_schema

# Generated at 2022-06-18 12:26:32.149406
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 1}) == Const(const=1)
    assert const_from_json_schema({'const': 1, 'default': 2}) == Const(const=1, default=2)



# Generated at 2022-06-18 12:26:38.464601
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import SchemaDefinitions
    from . import NO_DEFAULT

    def assert_json_schema(
        field: Field, expected: typing.Union[bool, dict], definitions: dict = None
    ):
        actual = to_json_schema(field, _definitions=definitions)
        assert actual == expected, f"Expected {expected!r}, got {actual!r}"

    assert_json_schema(String(), {"type": "string"})
    assert_json_schema(String(allow_null=True), {"type": ["string", "null"]})
    assert_json_schema(String(min_length=1), {"type": "string", "minLength": 1})

# Generated at 2022-06-18 12:26:44.460847
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    result = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/foo"
    assert result.definitions is definitions



# Generated at 2022-06-18 12:26:51.913551
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "number"},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert isinstance(field, OneOf)
    assert len(field.one_of) == 2
    assert isinstance(field.one_of[0], String)
    assert isinstance(field.one_of[1], Float)



# Generated at 2022-06-18 12:26:58.434864
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:27:04.736125
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer", "minimum": 1},
            {"type": "integer", "maximum": -1},
        ],
        "default": 0,
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.validate(0) == 0
    assert field.validate(2) == 2
    assert field.validate(-2) == -2



# Generated at 2022-06-18 12:27:11.275442
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_clause.type == "integer"
    assert field.then_clause.type == "integer"
    assert field.else_clause.type == "string"
    assert field.default == NO_DEFAULT

    data = {
        "if": {"type": "integer"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
        "default": "default",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_cl

# Generated at 2022-06-18 12:27:16.025255
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).definitions is None



# Generated at 2022-06-18 12:27:19.379232
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1}) == Const(const=1)
    assert const_from_json_schema({"const": 1, "default": 2}) == Const(const=1, default=2)



# Generated at 2022-06-18 12:27:23.317691
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("c") == "c"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, None).validate("d") is None



# Generated at 2022-06-18 12:27:42.552776
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:27:46.340421
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"



# Generated at 2022-06-18 12:27:57.816556
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema, String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not

    class TestSchema(Schema):
        a = String(max_length=10)
        b = Integer(minimum=5, maximum=10)
        c = Boolean()
        d = Array(items=Integer(minimum=0, maximum=10))
        e = Object(
            properties={
                "a": String(max_length=10),
                "b": Integer(minimum=5, maximum=10),
                "c": Boolean(),
                "d": Array(items=Integer(minimum=0, maximum=10)),
            }
        )
        f = Choice(choices=[("a", "a"), ("b", "b")])
        g = Const("a")
        h = Union

# Generated at 2022-06-18 12:28:07.180104
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:28:10.774084
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"



# Generated at 2022-06-18 12:28:21.596441
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:28:29.563543
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]*$"}) == String(
        pattern=re.compile("^[a-z]*$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema

# Generated at 2022-06-18 12:28:32.025668
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:28:42.922366
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from

# Generated at 2022-06-18 12:28:54.416813
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()

# Generated at 2022-06-18 12:30:07.552074
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Const(None)])

# Generated at 2022-06-18 12:30:17.344400
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Any()])
    assert from_json_schema({"type": ["string", "null"], "enum": ["a", "b"]}) == Choice

# Generated at 2022-06-18 12:30:21.770758
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:30:27.218218
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:30:29.871833
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}) == Reference(to="#/definitions/foo")



# Generated at 2022-06-18 12:30:39.114119
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference
    from . import SchemaDefinitions
    from . import NO_DEFAULT, NO_DEFINITIONS

    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
        "definitions": NO_DEFINITIONS,
    }
    assert to_json_schema(String(default="foo")) == {
        "type": "string",
        "default": "foo",
        "definitions": NO_DEFINITIONS,
    }

# Generated at 2022-06-18 12:30:49.284739
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:30:58.916944
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:10.428953
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions


# Generated at 2022-06-18 12:31:20.912721
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern=re.compile("^[a-z]+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "number"}) == Number()

# Generated at 2022-06-18 12:31:51.222104
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^a"}) == String(pattern="^a")
    assert from_json_schema({"type": "string", "format": "email"}) == String(format="email")
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:31:53.748379
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:32:05.158597
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema

    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    class TestSchema2(Schema):
        field = String(allow_null=True)

    schema2 = TestSchema2()
    assert to_json_schema(schema2) == {
        "type": "object",
        "properties": {"field": {"type": ["string", "null"]}},
        "required": ["field"],
    }

    class TestSchema3(Schema):
        field = String(allow_null=True, default="")

    schema3 = TestSche

# Generated at 2022-06-18 12:32:12.477596
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:22.437503
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_blank=False)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(min_length=5)) == {"type": "string", "minLength": 5}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:32:31.023629
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"\d+"))) == {
        "type": "string",
        "pattern": r"\d+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:32:35.825603
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"



# Generated at 2022-06-18 12:32:45.612327
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:32:51.834590
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_

# Generated at 2022-06-18 12:33:00.244537
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "definitions": {
            "TestSchema": {
                "type": "object",
                "properties": {"field": {"type": "string"}},
                "required": ["field"],
            }
        },
        "$ref": "#/definitions/TestSchema",
    }

    schema = TestSchema(allow_null=True)
    json_schema = to_json_schema(schema)

# Generated at 2022-06-18 12:33:31.686841
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:33:40.792723
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^\\d+$"}) == String(
        pattern=re.compile("^\\d+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "integer"}) == Integer()

# Generated at 2022-06-18 12:33:50.460821
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    assert to_json_schema(fields.Any()) == True
    assert to_json_schema(fields.NeverMatch()) == False
    assert to_json_schema(fields.String()) == {
        "type": "string",
        "default": None,
    }
    assert to_json_schema(fields.String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": None,
    }
    assert to_json_schema(fields.String(default="foo")) == {
        "type": "string",
        "default": "foo",
    }