

# Generated at 2022-06-18 12:24:54.270712
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from

# Generated at 2022-06-18 12:25:03.554089
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:25:14.438513
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                    "address": {"type": "string"},
                },
            },
        ]
    }
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert OneOf(**kwargs) == OneOf

# Generated at 2022-06-18 12:25:21.901553
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(1)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(2)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(3)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(4)



# Generated at 2022-06-18 12:25:30.520848
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("bar") == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("bar") == "bar"



# Generated at 2022-06-18 12:25:34.022344
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1}) == Const(const=1)
    assert const_from_json_schema({"const": 1, "default": 2}) == Const(const=1, default=2)



# Generated at 2022-06-18 12:25:47.306972
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:25:50.600714
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer"},
            {"type": "string"},
        ]
    }
    definitions = SchemaDefinitions()
    one_of = one_of_from_json_schema(data, definitions)
    assert isinstance(one_of, OneOf)
    assert len(one_of.one_of) == 2
    assert isinstance(one_of.one_of[0], Integer)
    assert isinstance(one_of.one_of[1], String)



# Generated at 2022-06-18 12:25:56.646104
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z]+$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("123") is None
    assert field.validate("abc") is not None



# Generated at 2022-06-18 12:26:00.314150
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions={'#/definitions/foo': 'bar'}), Reference)


# Generated at 2022-06-18 12:27:05.683498
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": "foo"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("bar") == "bar"
    assert field.validate(1) == "foo"



# Generated at 2022-06-18 12:27:12.312679
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate(1) == "1"
    assert field.validate(None) == ""



# Generated at 2022-06-18 12:27:22.561346
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "string"},
                },
                "required": ["a", "b"],
            },
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "integer"},
                },
                "required": ["a", "b"],
            },
        ],
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions=definitions)
    assert field.validate({"a": 1, "b": "2"}) == {"a": 1, "b": "2"}
    assert field.validate

# Generated at 2022-06-18 12:27:35.613782
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        a = String()
        b = Integer()
        c = Array(items=String())
        d = Object(properties={"e": String()})
        f = Union(any_of=[String(), Integer()])
        g = OneOf(one_of=[String(), Integer()])
        h = AllOf(all_of=[String(), Integer()])
        i = IfThenElse(
            if_clause=String(),
            then_clause=Integer(),
            else_clause=Boolean(),
        )
        j = Not(negated=String())

    schema = MySchema()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:27:40.514534
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(
        any_of=[String(), Integer()], allow_null=False
    )



# Generated at 2022-06-18 12:27:46.775044
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"minimum": 0},
        "else": {"type": "string"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate(0) == 0
    assert field.validate("0") == "0"
    assert field.validate(None) is None
    assert field.validate("a") is None
    assert field.validate(1.0) is None
    assert field.validate(1.0) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate([]) is None
    assert field.validate({}) is None



# Generated at 2022-06-18 12:27:57.858214
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference
    from .schema import SchemaDefinitions

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_sche

# Generated at 2022-06-18 12:28:07.272758
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test simple types
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    # Test nullable types
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
   

# Generated at 2022-06-18 12:28:18.596516
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "pattern": "^[0-9]{4}-[0-9]{2}-[0-9]{2}$",
        },
        "then": {
            "type": "string",
            "format": "date",
        },
        "else": {
            "type": "string",
            "format": "date-time",
        },
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("2020-01-01") == "2020-01-01"
    assert field.validate("2020-01-01T00:00:00") == "2020-01-01T00:00:00"

# Generated at 2022-06-18 12:28:27.083803
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:28:58.739595
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:29:05.878519
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_

# Generated at 2022-06-18 12:29:13.225847
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
            },
            {
                "type": "string",
                "pattern": "^[a-z]+$",
            },
        ],
    }
    field = all_of_from_json_schema(data, definitions)
    assert field.validate("abc") is None
    assert field.validate("ABC") is not None



# Generated at 2022-06-18 12:29:20.540408
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
            {"maxLength": 10},
        ]
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("abc") == "abc"
    assert field.validate("") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz") is None
    assert field.validate(1) is None
    assert field.validate(None) is None



# Generated at 2022-06-18 12:29:30.595952
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-18 12:29:40.817301
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:29:47.809794
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }

# Generated at 2022-06-18 12:29:59.251698
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:06.401597
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") is None



# Generated at 2022-06-18 12:30:09.585273
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string"},
            {"maxLength": 5},
        ]
    }
    field = all_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate("hello") is None
    assert field.validate("hello world") is not None



# Generated at 2022-06-18 12:30:37.247235
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

    assert from_json_

# Generated at 2022-06-18 12:30:47.539181
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:30:57.590798
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import SchemaDefinitions, Schema

    class TestSchema(Schema):
        string = String(max_length=10)
        integer = Integer(minimum=0)
        boolean = Boolean()
        array = Array(items=Integer(minimum=0))
        object = Object(properties={"string": String(max_length=10)})
        choice = Choice(choices=[("foo", "foo"), ("bar", "bar")])
        const = Const("foo")
        union = Union(any_of=[String(max_length=10), Integer(minimum=0)])
        one_of = OneOf(one_of=[String(max_length=10), Integer(minimum=0)])


# Generated at 2022-06-18 12:31:08.783329
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=2)) == {"type": "string", "minLength": 2}
    assert to_json_schema(String(max_length=2)) == {"type": "string", "maxLength": 2}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:31:19.583895
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:31:24.388444
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions



# Generated at 2022-06-18 12:31:34.117687
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields
    from . import schema

    class TestSchema(schema.Schema):
        name = fields.String(max_length=100)
        age = fields.Integer(minimum=0, maximum=150)
        is_cool = fields.Boolean()
        tags = fields.Array(fields.String(max_length=20))

    schema_data = to_json_schema(TestSchema)

# Generated at 2022-06-18 12:31:44.315469
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern=re.compile("^[a-z]+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "integer"}) == Integer()

# Generated at 2022-06-18 12:31:55.557952
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:06.759750
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(max_length=100),
            "age": Integer(minimum=0, maximum=150),
            "address": {
                "street": String(max_length=100),
                "city": String(max_length=100),
                "state": String(max_length=2),
                "zip": String(max_length=10),
            },
            "phone": String(max_length=20),
            "email": String(max_length=100),
            "website": String(max_length=100),
        }
    )
    json_schema = to_json_schema(schema)

# Generated at 2022-06-18 12:32:47.341739
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, Not, AllOf, IfThenElse, OneOf

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": "^\\d+$",
    }
   

# Generated at 2022-06-18 12:32:57.324158
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:05.717061
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Decimal(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json

# Generated at 2022-06-18 12:33:15.950400
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)

# Generated at 2022-06-18 12:33:20.390090
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:33:23.304296
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert ref_from_json_schema(data, definitions=definitions) == String()



# Generated at 2022-06-18 12:33:33.662345
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(allow_null=True)
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(allow_null=True)

# Generated at 2022-06-18 12:33:40.086506
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:50.045689
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_