

# Generated at 2022-06-18 12:25:05.402426
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:25:07.844850
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:25:14.031086
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=Float(),
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "number"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:25:20.175381
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 1,
            "pattern": "^[a-z]$",
        },
        "then": {"type": "string", "minLength": 1, "maxLength": 1},
        "else": {"type": "string", "minLength": 2, "maxLength": 2},
    }
    schema = if_then_else_from_json_schema(data, definitions=None)
    assert schema.validate("a") == "a"
    assert schema.validate("aa") == "aa"
    assert schema.validate("A") is None
    assert schema.validate("") is None
    assert schema.validate(None) is None



# Generated at 2022-06-18 12:25:32.116584
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 0}) == String(min_length=0)
    assert from_json_schema({"type": "string", "maxLength": 0}) == String(max_length=0)
    assert from_json_schema({"type": "string", "pattern": "^a"}) == String(pattern="^a")
    assert from_json_schema({"type": "string", "format": "email"}) == String(format="email")
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "number", "minimum": 0}) == Number(minimum=0)
    assert from_json_sche

# Generated at 2022-06-18 12:25:36.947259
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions, Schema

    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0, maximum=100)
        is_active = Boolean()
        friends = Array(items=String(max_length=10))
        address = Object(
            properties={
                "street": String(max_length=10),
                "city": String(max_length=10),
                "state": String(max_length=10),
                "zip": String(max_length=10),
            }
        )
        gender = Choice(choices=[("male", "Male"), ("female", "Female")])
        lucky_

# Generated at 2022-06-18 12:25:49.477975
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(String(), Const(None))

# Generated at 2022-06-18 12:25:54.098121
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic import BaseModel

    class TestModel(BaseModel):
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[typing.Union[int, str]]
        e: typing.Dict[str, int]
        f: typing.Dict[str, typing.Union[int, str]]
        g: typing.Dict[str, typing.List[int]]
        h: typing.Dict[str, typing.List[typing.Union[int, str]]]
        i: typing.Dict[str, typing.Dict[str, int]]
        j: typing.Dict[str, typing.Dict[str, typing.Union[int, str]]]


# Generated at 2022-06-18 12:25:58.347316
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
                "required": ["name"],
            },
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
                "required": ["age"],
            },
        ]
    }
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}

# Generated at 2022-06-18 12:26:03.343523
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "bar"



# Generated at 2022-06-18 12:26:31.330510
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"type": "integer", "maximum": 100},
        ],
        "default": 0,
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(100) == 100
    assert field.validate(-1) == -1
    assert field.validate(101) == 101



# Generated at 2022-06-18 12:26:35.806117
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "number"},
            {"type": "string"},
        ],
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert isinstance(field, Union)
    assert len(field.any_of) == 2
    assert isinstance(field.any_of[0], Float)
    assert isinstance(field.any_of[1], String)



# Generated at 2022-06-18 12:26:39.709507
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": ["a", "b", "c"]}
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"



# Generated at 2022-06-18 12:26:51.759102
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        },
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.default == ""
    assert field.validate("") is None
    assert field.validate("abc") is None
    assert field.validate("abc123") is None
    assert field.validate("abc123!") is not None
    assert field.validate("abc123!") == "Value does not match the 'not' constraint."

# Generated at 2022-06-18 12:26:58.271047
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(String(), Const(None))

# Generated at 2022-06-18 12:27:06.902763
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:27:18.018384
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:27:25.194798
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
                "pattern": "^[A-Za-z0-9]+$",
                "default": "",
            },
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
                "pattern": "^[A-Za-z0-9]+$",
                "default": "",
            },
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    assert isinstance(one_of_from_json_schema(data, definitions), OneOf)



# Generated at 2022-06-18 12:27:37.887433
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    assert to_json_schema(fields.String()) == {"type": "string"}
    assert to_json_schema(fields.String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(fields.String(default="foo")) == {
        "type": "string",
        "default": "foo",
    }
    assert to_json_schema(fields.String(min_length=5)) == {
        "type": "string",
        "minLength": 5,
    }
    assert to_json_schema(fields.String(max_length=5)) == {
        "type": "string",
        "maxLength": 5,
    }

# Generated at 2022-06-18 12:27:45.799881
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") is None
    assert field.validate("abc") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz") is None
    assert field.validate("abcdefghijklmnopqrstuvwxyz1234567890") is None

# Generated at 2022-06-18 12:28:11.470140
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:28:22.093842
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:28:26.258055
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    result = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/foo"
    assert result.definitions == definitions



# Generated at 2022-06-18 12:28:33.438344
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]*$",
        },
        "then": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]*$",
        },
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("hello") == "hello"
    assert field.validate("hello world") is None
    assert field.validate("hello_world") is None
    assert field.validate("hello world!") is None
    assert field

# Generated at 2022-06-18 12:28:45.471557
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:28:52.142797
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:28:56.275680
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": Integer()}) == Integer()



# Generated at 2022-06-18 12:29:04.728261
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-18 12:29:15.102900
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:29:25.233062
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:29:51.315623
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/Foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:30:02.791977
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        a = Integer(minimum=1, maximum=10)
        b = String(min_length=1, max_length=10)
        c = Array(items=Integer(minimum=1, maximum=10), min_items=1, max_items=10)
        d = Object(
            properties={
                "a": Integer(minimum=1, maximum=10),
                "b": String(min_length=1, max_length=10),
            },
            min_properties=1,
            max_properties=10,
        )
        e = Choice(choices=[(1, "one"), (2, "two")])
        f = Const(const=1)

# Generated at 2022-06-18 12:30:12.909206
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:30:24.606555
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:30:36.192068
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:30:45.771421
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()

# Generated at 2022-06-18 12:30:56.197554
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        a = String(min_length=1, max_length=10)
        b = Integer(minimum=0, maximum=100)

    schema = TestSchema()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "a": {"type": "string", "minLength": 1, "maxLength": 10},
            "b": {"type": "integer", "minimum": 0, "maximum": 100},
        },
        "required": ["a", "b"],
    }

    schema = TestSchema(allow_unknown=True)
    json_schema = to_json_schema(schema)

# Generated at 2022-06-18 12:31:05.240476
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()

    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)

# Generated at 2022-06-18 12:31:17.021081
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:27.120164
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

# Generated at 2022-06-18 12:32:08.258371
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:19.298911
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:32:28.360214
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:32:38.746517
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:47.577723
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()
    assert from_json_schema({"type": ["null", "string"]}) == String() | Any()
    assert from_json_

# Generated at 2022-06-18 12:32:55.112481
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:02.296688
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()

# Generated at 2022-06-18 12:33:11.957890
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Const(None)]
    )

# Generated at 2022-06-18 12:33:20.976678
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:33:30.589224
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test for type_string=number
    data = {
        "type": "number",
        "minimum": 1,
        "maximum": 2,
        "exclusiveMinimum": 3,
        "exclusiveMaximum": 4,
        "multipleOf": 5,
        "default": 6,
    }
    assert from_json_schema_type(data, type_string="number", allow_null=False, definitions=None) == Float(
        minimum=1,
        maximum=2,
        exclusive_minimum=3,
        exclusive_maximum=4,
        multiple_of=5,
        default=6,
    )