

# Generated at 2022-06-18 12:24:45.992845
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer", "minimum": 0},
            {"type": "integer", "maximum": 0},
        ]
    }
    definitions = SchemaDefinitions()
    one_of = one_of_from_json_schema(data, definitions=definitions)
    assert one_of.validate(1) == 1
    assert one_of.validate(-1) == -1
    assert one_of.validate(0) == 0
    assert one_of.validate(1.0) == 1
    assert one_of.validate(-1.0) == -1
    assert one_of.validate(0.0) == 0
    assert one_of.validate("1") == 1
    assert one_of.validate("-1") == -1


# Generated at 2022-06-18 12:24:55.408207
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
            },
            {
                "type": "integer",
                "minimum": 0,
                "maximum": 100,
            },
        ],
    }
    definitions = SchemaDefinitions()
    schema = one_of_from_json_schema(data, definitions=definitions)
    assert schema.validate("abc") == "abc"
    assert schema.validate(1) == 1
    assert schema.validate(None) is None
    assert schema.validate(1.0) == 1.0
    assert schema.validate(True) is True
    assert schema.validate(False) is False

# Generated at 2022-06-18 12:25:00.143409
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(
        if_then_else_from_json_schema(
            {
                "if": {"type": "string"},
                "then": {"type": "integer"},
                "else": {"type": "boolean"},
            },
            definitions=None,
        ),
        IfThenElse,
    )



# Generated at 2022-06-18 12:25:07.662397
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:25:16.962672
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("abc") == "abc"
    assert field.validate(123) == 123
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.23) == 1.23
    assert field.validate(1.23) == 1.23
    assert field.validate(1.23) == 1.23
    assert field.validate(1.23) == 1.23
    assert field.validate(1.23)

# Generated at 2022-06-18 12:25:29.311581
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("c") == "c"
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "c"}, None).validate(None) == "c"
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "c"}, None).validate("a") == "a"

# Generated at 2022-06-18 12:25:32.908297
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:25:40.190467
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a")
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b")
    assert not enum_from_json_schema({"enum": ["a", "b"]}, None).validate("c")



# Generated at 2022-06-18 12:25:50.402601
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/my_schema",
        "definitions": {
            "my_schema": {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
            }
        }
    }
    definitions = SchemaDefinitions()
    field = from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/my_schema"
    assert field.definitions == definitions
    assert field.definitions["#/definitions/my_schema"] == String(min_length=1, max_length=10)



# Generated at 2022-06-18 12:25:57.283252
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "number"},
        "else": {"type": "boolean"},
        "default": "default",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == "default"
    assert field.if_clause.type == "string"
    assert field.then_clause.type == "number"
    assert field.else_clause.type == "boolean"



# Generated at 2022-06-18 12:26:49.660057
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 1}]}) == AllOf(
        all_of=[String(), String(min_length=1)]
    )



# Generated at 2022-06-18 12:26:56.632022
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "integer"}, {"minimum": 0}]}
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    assert field.validate("1.0") == "1.0"
    assert field.validate(None) is None
    assert field.validate("") == ""
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate([]) == []
    assert field.validate({}) == {}

# Generated at 2022-06-18 12:27:01.883893
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("abc") == "abc"
    assert field.validate("abcdefghijklmnopqrstuvwxyz") is None



# Generated at 2022-06-18 12:27:12.009473
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "string"},
                },
                "required": ["a", "b"],
            },
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "c": {"type": "string"},
                },
                "required": ["a", "c"],
            },
        ],
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate({"a": "a", "b": "b"}) == {"a": "a", "b": "b"}

# Generated at 2022-06-18 12:27:22.251972
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:27:35.507849
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:27:44.852296
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(default="foo")) == {
        "type": "string",
        "default": "foo",
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-18 12:27:56.483728
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        a = Integer()
        b = String()
        c = Boolean()
        d = Array(String())
        e = Object(properties={"f": Integer()})
        g = Choice(choices=[("a", "a"), ("b", "b")])
        h = Const("a")
        i = Union(String(), Integer())
        j = OneOf(String(), Integer())
        k = AllOf(String(), Integer())
        l = IfThenElse(
            if_clause=String(),
            then_clause=Integer(),
            else_clause=Boolean(),
        )
        m = Not(String())
        n = Reference("a")

    schema = TestSchema()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:28:00.540101
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
        "default": 0,
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == 0
    assert field.if_clause.type == "string"
    assert field.then_clause.type == "integer"
    assert field.else_clause.type == "number"



# Generated at 2022-06-18 12:28:11.142926
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema({}, None), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}}, None), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}, "then": {}}, None), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}, "else": {}}, None), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({"if": {}, "then": {}, "else": {}}, None), IfThenElse)

# Generated at 2022-06-18 12:28:37.075606
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}}, definitions=None) == Not(negated=String())
    assert not_from_json_schema({"not": {"type": "string"}, "default": "foo"}, definitions=None) == Not(negated=String(), default="foo")



# Generated at 2022-06-18 12:28:48.379953
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        a = String()
        b = Integer()
        c = Boolean()
        d = Array(String())
        e = Object(properties={"a": String(), "b": Integer()})
        f = Choice(choices=[("a", "a"), ("b", "b")])
        g = Const("a")
        h = Union(any_of=[String(), Integer()])
        i = OneOf(one_of=[String(), Integer()])
        j = AllOf(all_of=[String(), Integer()])
        k = IfThenElse(
            if_clause=String(),
            then_clause=Integer(),
            else_clause=Boolean(),
        )
        l = Not(negated=String())

    schema = TestSchema()
    data = to_json_schema

# Generated at 2022-06-18 12:28:52.131005
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "test"}, definitions=None).validate("test")
    assert not const_from_json_schema({"const": "test"}, definitions=None).validate("test2")



# Generated at 2022-06-18 12:29:02.039249
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:29:08.384053
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}).validate("bar") == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}).validate(None) == "bar"



# Generated at 2022-06-18 12:29:18.560633
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:29:21.489638
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test that Not(negated=Any()) is equivalent to NeverMatch()
    assert not_from_json_schema({"not": {"type": "any"}}, definitions=None) == NeverMatch()



# Generated at 2022-06-18 12:29:25.918408
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "enum": ["a", "b", "c"]}) == Choice(
        choices=["a", "b", "c"]
    )
    assert from_json_schema({"type": "string", "const": "a"}) == Const("a")
    assert from_json_schema({"type": "string", "const": "a", "enum": ["a", "b", "c"]}) == (
        Choice(choices=["a", "b", "c"]) & Const("a")
    )

# Generated at 2022-06-18 12:29:36.457458
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }
    assert to_json_schema(String(format="date")) == {"type": "string", "format": "date"}


# Generated at 2022-06-18 12:29:45.421176
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") == (False, "String must not be empty.")
    assert field.validate("a") == (True, None)
    assert field.validate("abcdefghijklmnopqrstuvwxyz") == (False, "String must be at most 10 characters long.")

# Generated at 2022-06-18 12:30:17.177544
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test basic types
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}

    # Test nullable types
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}

# Generated at 2022-06-18 12:30:24.607061
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"type": "integer"},
    }
    schema = if_then_else_from_json_schema(data, definitions=None)
    assert schema.validate("") == "String is too short."
    assert schema.validate("a") is None
    assert schema.validate(1) is None



# Generated at 2022-06-18 12:30:33.483214
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:30:41.639187
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
        "default": 0,
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.default == 0
    assert field.validate("foo") == 0
    assert field.validate(1) == 1
    assert field.validate(1.5) == 1.5
    assert field.validate(None) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate([]) is None
    assert field.validate({}) is None
    assert field.validate({"foo": "bar"}) is None
    assert field.valid

# Generated at 2022-06-18 12:30:52.468776
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:00.740078
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:12.637236
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions, Schema
    from . import NO_DEFAULT
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions, Schema
    from . import NO_DEFAULT
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions, Schema
    from . import NO_DEFAULT
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions

# Generated at 2022-06-18 12:31:22.565683
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }


# Generated at 2022-06-18 12:31:32.786300
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import validators

    assert to_json_schema(validators.String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(validators.String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(validators.String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
        "default": NO_DEFAULT,
    }
    assert to_json_schema(validators.String(max_length=10)) == {
        "type": "string",
        "maxLength": 10,
        "default": NO_DEFAULT,
    }
    assert to

# Generated at 2022-06-18 12:31:42.709397
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:32:23.035554
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:31.659039
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 3},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("foo") is None
    assert field.validate(1) is None
    assert field.validate(None) is None
    assert field.validate(True) is not None
    assert field.validate(False) is not None
    assert field.validate(1.0) is not None
    assert field.validate([]) is not None
    assert field.validate({}) is not None
    assert field.validate("f") is not None
    assert field.validate("fo") is not None

# Generated at 2022-06-18 12:32:41.715613
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    class MySchema(Schema):
        field = String()

    schema = MySchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = MySchema(allow_unknown=True)
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
        "additionalProperties": True,
    }

    schema = MySchema(allow_unknown=False)
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:32:49.719374
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=5)) == {"type": "string", "minLength": 5}
    assert to_json_schema(String(max_length=5)) == {"type": "string", "maxLength": 5}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:32:57.194026
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:03.428137
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, String)
    assert isinstance(field.else_clause, Integer)
    assert field.default is NO_DEFAULT



# Generated at 2022-06-18 12:33:09.258773
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    class TestSchema(Schema):
        field = fields.String(max_length=10)

    schema = TestSchema()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "field": {
                "type": "string",
                "maxLength": 10,
            },
        },
        "required": ["field"],
    }



# Generated at 2022-06-18 12:33:18.891993
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("[a-z]+"))) == {
        "type": "string",
        "pattern": "[a-z]+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:33:25.284015
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:35.990860
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Integer, String, Object, Array, Choice, Const, Not, Union, OneOf, AllOf
    from . import IfThenElse, Reference

    class TestSchema(SchemaDefinitions):
        a = Integer()
        b = String()
        c = Object(properties={"d": Integer(), "e": String()})
        f = Array(items=Integer())
        g = Choice(choices=[("a", "a"), ("b", "b")])
        h = Const("a")
        i = Not(Integer())
        j = Union(any_of=[Integer(), String()])
        k = OneOf(one_of=[Integer(), String()])
        l = AllOf(all_of=[Integer(), String()])