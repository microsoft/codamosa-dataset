

# Generated at 2022-06-18 12:24:39.731354
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]+$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") == (False, "Value must not match schema.")
    assert field.validate("abc") == (True, None)
    assert field.validate("abc123") == (True, None)
    assert field.validate("abc123!") == (False, "Value must not match schema.")
    assert field.validate(None) == (True, None)
    assert field.validate(True) == (True, None)
   

# Generated at 2022-06-18 12:24:51.471434
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]+$",
            "default": "",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abc") == "abc"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") == "abcdefghijk"
    assert field.validate("abcdefghijkl") == "abcdefghijkl"


# Generated at 2022-06-18 12:24:59.317578
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "enum": ["a", "b", "c"],
        "default": "a",
    }
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "a"



# Generated at 2022-06-18 12:25:03.092317
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "string"},
        "default": "default",
    }
    definitions = SchemaDefinitions()
    result = not_from_json_schema(data, definitions)
    assert isinstance(result, Not)
    assert result.negated == String()
    assert result.default == "default"



# Generated at 2022-06-18 12:25:07.895380
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions) == OneOf(
        one_of=[String(), Integer()], default=NO_DEFAULT
    )



# Generated at 2022-06-18 12:25:12.580982
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(any_of=[String(), Integer()])



# Generated at 2022-06-18 12:25:16.679968
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Person",
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "enum": ["Alice", "Bob", "Eve"],
            },
        },
    }
    field = from_json_schema(data)
    assert field.validate("name", "Alice") is None
    assert field.validate("name", "Bob") is None
    assert field.validate("name", "Eve") is None
    assert field.validate("name", "Alice2") == ["Must be one of: Alice, Bob, Eve."]



# Generated at 2022-06-18 12:25:29.050648
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "number"},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("") == ""
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(None) == ""
    assert field.validate(False) == ""
    assert field.validate(True) == ""
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1

# Generated at 2022-06-18 12:25:33.462280
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "pattern": "^[0-9]{3}-[0-9]{2}-[0-9]{4}$",
        },
        "then": {
            "type": "string",
            "format": "date",
        },
        "else": {
            "type": "string",
            "format": "date-time",
        },
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("123-45-6789") == "123-45-6789"
    assert field.validate("123-45-6789T01:23:45") == "123-45-6789T01:23:45"
    assert field.validate

# Generated at 2022-06-18 12:25:46.591520
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean"}, True)
    assert get_valid_types({"type": ["null", "object"]}) == ({"object"}, True)
    assert get_valid_

# Generated at 2022-06-18 12:26:10.275660
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:26:13.315791
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "foo"}
    definitions = SchemaDefinitions()
    assert const_from_json_schema(data, definitions) == Const(const="foo")



# Generated at 2022-06-18 12:26:24.946844
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("abc") == "abc"
    assert field.validate("") == ""
    assert field.validate(None) == ""
    assert field.validate(1) == ""
    assert field.validate("abcdefghijklmnopqrstuvwxyz") == ""
    assert field.validate("abcdefghijklmnopqrstuvwxyz", strict=True) == ""

# Generated at 2022-06-18 12:26:33.646755
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

    assert from_json_

# Generated at 2022-06-18 12:26:39.654260
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "a"}, definitions=None).validate("a")
    assert not const_from_json_schema({"const": "a"}, definitions=None).validate("b")
    assert const_from_json_schema({"const": "a", "default": "a"}, definitions=None).validate("a")
    assert const_from_json_schema({"const": "a", "default": "a"}, definitions=None).validate(None)
    assert const_from_json_schema({"const": "a", "default": "a"}, definitions=None).validate("b")
    assert const_from_json_schema({"const": "a", "default": "b"}, definitions=None).validate("a")

# Generated at 2022-06-18 12:26:51.723705
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "integer"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "c": {"type": "integer"},
                },
            },
        ]
    }
    field = from_json_schema(schema)
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:26:58.271864
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:27:06.566109
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=String(),
        else_clause=Integer(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "string"},
            "else": {"type": "integer"},
        },
        definitions=None,
    )

    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=None,
        else_clause=Integer(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {"if": {"type": "boolean"}, "else": {"type": "integer"}}, definitions=None
    )



# Generated at 2022-06-18 12:27:10.992189
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}) == Reference(to="#/definitions/foo")
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": Integer()}) == Integer()



# Generated at 2022-06-18 12:27:21.716550
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:28:12.147640
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:28:20.953515
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions={'#/definitions/foo': 'bar'}), Reference)
    assert ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions={'#/definitions/foo': 'bar'}).to == '#/definitions/foo'
    assert ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions={'#/definitions/foo': 'bar'}).definitions == {'#/definitions/foo': 'bar'}


# Generated at 2022-06-18 12:28:29.044923
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^a*$"))) == {
        "type": "string",
        "pattern": "^a*$",
    }
    assert to_json_schema

# Generated at 2022-06-18 12:28:40.222786
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:28:43.790266
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert ref_from_json_schema(data, definitions=definitions) == String()



# Generated at 2022-06-18 12:28:55.067134
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)

# Generated at 2022-06-18 12:29:03.922532
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema, String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import NO_DEFAULT, NO_DEFAULT_VALUE
    from . import SchemaDefinitions

    class TestSchema(Schema):
        a = String(default="hello")
        b = Integer(default=42)
        c = Boolean(default=True)
        d = Array(Integer, default=[1, 2, 3])
        e = Object(
            {
                "f": String(default="hello"),
                "g": Integer(default=42),
                "h": Boolean(default=True),
            },
            default={"f": "hello", "g": 42, "h": True},
        )

# Generated at 2022-06-18 12:29:09.438522
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:29:19.785350
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:29:29.939506
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:27.880894
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Float,
        Integer,
        NeverMatch,
        Object,
        String,
    )

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json

# Generated at 2022-06-18 12:30:38.069687
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 10}) == String(max_length=10)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern=re.compile("^[a-z]+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "number"}) == Number()

# Generated at 2022-06-18 12:30:48.216780
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import Schema, SchemaDefinitions
    from . import NO_DEFAULT
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import Schema, SchemaDefinitions
    from . import NO_DEFAULT
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import Schema, SchemaDefinitions
    from . import NO_DEFAULT

# Generated at 2022-06-18 12:30:55.644167
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:31:02.441403
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:14.520199
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:24.387635
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:31:34.148801
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(max_length=1)) == {
        "type": "string",
        "maxLength": 1,
    }
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }

# Generated at 2022-06-18 12:31:41.525768
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:31:52.411163
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:32:38.432203
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:45.190039
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:51.633679
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json

# Generated at 2022-06-18 12:32:58.812281
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic import BaseModel

    class Model(BaseModel):
        a: int
        b: str
        c: typing.List[int]
        d: typing.List[str]
        e: typing.Dict[str, int]
        f: typing.Dict[str, str]

    schema = to_json_schema(Model)

# Generated at 2022-06-18 12:33:07.198898
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:33:11.381519
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:18.101311
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:26.841747
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:37.285039
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Any()]
    )

# Generated at 2022-06-18 12:33:46.553506
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

