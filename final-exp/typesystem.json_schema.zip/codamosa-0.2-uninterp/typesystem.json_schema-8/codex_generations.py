

# Generated at 2022-06-18 12:24:49.004180
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:24:57.736256
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}]}, None) == Union(any_of=[String(), Integer()], allow_null=False)
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}], "default": "abc"}, None) == Union(any_of=[String(), Integer()], allow_null=False, default="abc")



# Generated at 2022-06-18 12:25:03.461619
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert isinstance(field, Union)
    assert len(field.any_of) == 2
    assert isinstance(field.any_of[0], String)
    assert isinstance(field.any_of[1], Number)



# Generated at 2022-06-18 12:25:12.874657
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": None},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("hello") == "hello"
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate([]) == []
    assert field.validate({}) == {}



# Generated at 2022-06-18 12:25:19.681280
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import Schema, SchemaDefinitions
    from . import NO_DEFAULT

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, maximum=150)
        is_adult = Boolean()

    class PersonList(Schema):
        people = Array(items=Person)

    class PersonDict(Schema):
        people = Object(properties={"name": Person})

    class PersonChoice(Schema):
        person = Choice(choices=[("Person", Person)])

    class PersonConst(Schema):
        person = Const(const=Person)


# Generated at 2022-06-18 12:25:25.199347
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        },
        "default": "",
    }
    not_field = not_from_json_schema(data, definitions=None)
    assert not_field.default == ""
    assert not_field.negated.default == ""
    assert not_field.negated.min_length == 1
    assert not_field.negated.max_length == 10
    assert not_field.negated.pattern == "^[a-zA-Z0-9]*$"
    assert not_field.negated.allow_blank == False

# Generated at 2022-06-18 12:25:36.548640
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
        }
    }
    field = not_from_json_schema(data, definitions=None)
    assert field.validate("") == "This field may not be blank."
    assert field.validate("abc") == "This field may not be blank."
    assert field.validate("abcdefghij") == "This field may not be blank."
    assert field.validate("abcdefghijk") == "Ensure this field has no more than 10 characters."
    assert field.validate("abcdefghijk1") == "Ensure this field has no more than 10 characters."
    assert field.validate

# Generated at 2022-06-18 12:25:49.003420
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-18 12:25:52.503983
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:26:04.273402
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(
        allow_null=True
    )
    assert from_json_schema

# Generated at 2022-06-18 12:27:36.139528
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, OneOf)
    assert len(field.one_of) == 2
    assert isinstance(field.one_of[0], String)
    assert isinstance(field.one_of[1], Integer)


# Generated at 2022-06-18 12:27:45.141001
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
        ]
    }
    definitions = SchemaDefinitions()
    one_of_from_json_schema(data, definitions)
    assert definitions["#/oneOf/0"] == Object(
        properties={
            "name": String(),
            "age": Integer(),
        }
    )

# Generated at 2022-06-18 12:27:56.664478
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:28:00.074762
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:28:10.520494
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:28:16.163378
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:28:21.516674
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:28:30.203210
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate(1) == "1"
    assert field.validate(None) == ""
    assert field.validate(True) == "True"
    assert field.validate(False) == "False"
    assert field.validate(1.1) == "1.1"
    assert field.validate(1.0) == "1.0"

# Generated at 2022-06-18 12:28:37.619186
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ]
    }
    field = all_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None



# Generated at 2022-06-18 12:28:48.809226
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema
    from .fields import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference

    class TestSchema(Schema):
        string = String(allow_null=True)
        integer = Integer(allow_null=True)
        float = Float(allow_null=True)
        boolean = Boolean(allow_null=True)
        array = Array(allow_null=True)
        object = Object(allow_null=True)
        choice = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
        const = Const(const="a", allow_null=True)
        union = Union(any_of=[String(), Integer()], allow_null=True)

# Generated at 2022-06-18 12:29:26.540045
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    def assert_json_schema_equals(field: Field, expected: dict):
        actual = to_json_schema(field)
        assert actual == expected

    assert_json_schema_equals(fields.Any(), True)
    assert_json_schema_equals(fields.NeverMatch(), False)
    assert_json_schema_equals(fields.String(), {"type": "string"})
    assert_json_schema_equals(
        fields.String(allow_null=True), {"type": ["string", "null"]}
    )
    assert_json_schema_equals(
        fields.String(allow_blank=True), {"type": "string", "minLength": 0}
    )

# Generated at 2022-06-18 12:29:36.959704
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()

    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()
    assert from_json_schema({"type": ["integer", "null"]}) == Integer() | Any()
    assert from_json_

# Generated at 2022-06-18 12:29:45.704050
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields as f

    assert to_json_schema(f.Any()) == True
    assert to_json_schema(f.NeverMatch()) == False
    assert to_json_schema(f.String()) == {"type": "string"}
    assert to_json_schema(f.String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(f.String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(f.String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:29:56.831493
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:06.762365
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(1)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(2)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(3)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(4)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(None)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate("1")

# Generated at 2022-06-18 12:30:16.882609
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()

    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()
    assert from_json_schema({"type": ["integer", "null"]}) == Integer() | Any()
    assert from_json_

# Generated at 2022-06-18 12:30:25.979452
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(1)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(2)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(3)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, definitions=None).validate(4)



# Generated at 2022-06-18 12:30:32.289460
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)



# Generated at 2022-06-18 12:30:40.873609
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "enum_field": {
                "type": "string",
                "enum": ["a", "b", "c"],
            }
        },
    }
    field = from_json_schema(schema["properties"]["enum_field"])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"
    assert field.validate("d") == "d"
    assert field.validate("d") == "d"

# Generated at 2022-06-18 12:30:51.507669
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:31:36.725170
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:47.197442
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:31:58.732540
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()
    assert from_json_schema({"type": ["integer", "null"]}) == Integer() | Any()
    assert from_json_

# Generated at 2022-06-18 12:32:02.505391
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:32:11.245157
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:19.528886
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(max_length=10),
            "age": Integer(minimum=0, maximum=100),
            "is_admin": Boolean(),
            "tags": Array(items=String(max_length=10)),
        }
    )
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:32:28.772434
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Float,
        Integer,
        NeverMatch,
        Not,
        Null,
        Number,
        Object,
        OneOf,
        String,
        Union,
    )

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(Null()) == {"type": "null"}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}

# Generated at 2022-06-18 12:32:39.196581
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:48.000917
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:57.966579
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference, SchemaDefinitions

    class TestSchema(Schema):
        string = String()
        integer = Integer()
        boolean = Boolean()
        array = Array(items=[String(), Integer()])
        object = Object(properties={"string": String(), "integer": Integer()})
        choice = Choice(choices=[("string", "string"), ("integer", "integer")])
        const = Const(const="const")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])

# Generated at 2022-06-18 12:33:28.519178
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice()) == {"enum": []}
    assert to_json_schema

# Generated at 2022-06-18 12:33:36.201683
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:43.587048
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

