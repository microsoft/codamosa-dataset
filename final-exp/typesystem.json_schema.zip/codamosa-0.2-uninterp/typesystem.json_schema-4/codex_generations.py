

# Generated at 2022-06-18 12:25:48.493424
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    definitions = SchemaDefinitions()
    field = if_then_else_from_json_schema(data, definitions=definitions)
    assert field.validate(1) == "1"
    assert field.validate(True) is True
    assert field.validate(None) is None
    assert field.validate("foo") is None
    assert field.validate(1.0) is None
    assert field.validate(1.1) is None
    assert field.validate(1.5) is None
    assert field.validate(1.9) is None
    assert field.validate(2) == "2"

# Generated at 2022-06-18 12:25:58.785356
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=definitions) == Number()
    assert type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema({"type": "boolean"}, definitions=definitions) == Boolean()
    assert type_from_json_schema({"type": "object"}, definitions=definitions) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=definitions) == Array()
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)

# Generated at 2022-06-18 12:26:09.295541
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": "default"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("foo") == "foo"
    assert field.validate(1) == "default"
    assert field.validate(None) == "default"
    assert field.validate(False) == "default"
    assert field.validate(True) == "default"
    assert field.validate([]) == "default"
    assert field.validate({}) == "default"



# Generated at 2022-06-18 12:26:21.267381
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:26:25.564102
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).definitions is None



# Generated at 2022-06-18 12:26:28.739874
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])



# Generated at 2022-06-18 12:26:32.997485
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)



# Generated at 2022-06-18 12:26:36.239240
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ],
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("test") == "test"
    assert field.validate(1) == 1



# Generated at 2022-06-18 12:26:41.401319
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "enum": ["John", "Jane"],
                "default": "John",
            }
        },
    }
    schema = from_json_schema(data)
    assert schema.validate({"name": "John"}) == {"name": "John"}
    assert schema.validate({"name": "Jane"}) == {"name": "Jane"}
    assert schema.validate({"name": "Jill"}) == {"name": "John"}
    assert schema.validate({"name": None}) == {"name": "John"}



# Generated at 2022-06-18 12:26:52.165379
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:27:33.124671
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/Person",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/Person"] = String()
    assert ref_from_json_schema(data, definitions=definitions) == String()



# Generated at 2022-06-18 12:27:37.833857
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions) == OneOf(one_of=[String(), Integer()])



# Generated at 2022-06-18 12:27:43.226759
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ]
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None



# Generated at 2022-06-18 12:27:53.580801
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "number", "minimum": 0},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate("a")
    assert field.validate(1)
    assert not field.validate(None)
    assert not field.validate(True)
    assert not field.validate(False)
    assert not field.validate(0)
    assert not field.validate("")
    assert not field.validate(-1)



# Generated at 2022-06-18 12:27:58.742860
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "number"},
    }
    schema = if_then_else_from_json_schema(data, definitions=None)
    assert schema.validate(1) == "1"
    assert schema.validate(1.0) == 1.0
    assert schema.validate("1") == "1"
    assert schema.validate(None) is None
    assert schema.validate(True) == "True"
    assert schema.validate(False) == "False"
    assert schema.validate([1]) == [1]
    assert schema.validate({"a": 1}) == {"a": 1}



# Generated at 2022-06-18 12:28:08.590299
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Const(None)]
    )

# Generated at 2022-06-18 12:28:19.805949
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]+$",
            "default": "",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions)
    assert field.default == ""
    assert field.validate(None) == None
    assert field.validate("") == None
    assert field.validate("abc") == None
    assert field.validate("abcdefghij") == None
    assert field.validate("abcdefghijk") == "Value must not match schema."

# Generated at 2022-06-18 12:28:23.756546
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions



# Generated at 2022-06-18 12:28:33.289900
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1

# Generated at 2022-06-18 12:28:37.067192
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10
            },
            {
                "type": "string",
                "pattern": "^[A-Za-z0-9]*$"
            }
        ]
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("abc123") == "abc123"
    assert field.validate("abc123!") == "abc123!"



# Generated at 2022-06-18 12:29:12.797691
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    class TestSchema2(Schema):
        field = String(allow_null=True)

    schema = TestSchema2()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": ["string", "null"]}},
        "required": ["field"],
    }

    class TestSchema3(Schema):
        field = String(allow_blank=True)



# Generated at 2022-06-18 12:29:22.425846
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^a$"))) == {
        "type": "string",
        "pattern": "^a$",
    }

# Generated at 2022-06-18 12:29:24.526015
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}) == Reference(to="#/definitions/foo")
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": String()}) == String()



# Generated at 2022-06-18 12:29:35.048117
# Unit test for function to_json_schema
def test_to_json_schema():
    def assert_json_schema(
        field: Field, expected: typing.Union[bool, dict], definitions: dict = None
    ):
        actual = to_json_schema(field, _definitions=definitions)
        assert actual == expected

    assert_json_schema(Any(), True)
    assert_json_schema(NeverMatch(), False)
    assert_json_schema(String(), {"type": "string"})
    assert_json_schema(String(allow_null=True), {"type": ["string", "null"]})
    assert_json_schema(
        String(allow_null=True, default=""), {"type": ["string", "null"], "default": ""}
    )

# Generated at 2022-06-18 12:29:44.234274
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:29:55.962069
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:01.400422
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"



# Generated at 2022-06-18 12:30:09.205477
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema, String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import NO_DEFAULT, NO_DEFAULT_FACTORY

    class TestSchema(Schema):
        string = String(default="hello")
        integer = Integer(default=42)
        boolean = Boolean(default=True)
        array = Array(items=Integer(default=0), default=lambda: [1, 2, 3])
        object = Object(properties={"a": Integer(default=0), "b": Integer(default=1)})
        choice = Choice(choices=[("a", "a"), ("b", "b")], default="a")
        const = Const(const="a", default="a")

# Generated at 2022-06-18 12:30:16.371140
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:30:29.001368
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:08.818489
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()
    assert from_json_schema_type({}, "null", False, None) == Const(None)

    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_

# Generated at 2022-06-18 12:31:19.594728
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": r"^[a-z]+$",
    }

# Generated at 2022-06-18 12:31:29.722319
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:31:34.161273
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).definitions is None



# Generated at 2022-06-18 12:31:44.325044
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Any()])
    assert from_json_schema({"type": ["string", "null"], "enum": ["a", "b"]}) == Choice

# Generated at 2022-06-18 12:31:55.699574
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=too-many-locals
    # pylint: disable=too-many-statements
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks

    # Test basic types
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}

# Generated at 2022-06-18 12:32:06.845588
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:08.835261
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:32:19.694682
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:32:29.011314
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^a$"))) == {
        "type": "string",
        "pattern": "^a$",
    }

# Generated at 2022-06-18 12:33:38.459706
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": ["string", "null"]}) == Union(
        String(), Const(None)
    )

# Generated at 2022-06-18 12:33:47.913536
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:33:54.364542
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()

