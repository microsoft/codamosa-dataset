

# Generated at 2022-06-18 12:25:14.316273
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:25:20.456372
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string", "minLength": 1},
            {"type": "number", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(
        any_of=[String(min_length=1), Number(minimum=0)], default=""
    )



# Generated at 2022-06-18 12:25:32.318694
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from

# Generated at 2022-06-18 12:25:45.142728
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(1)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(2)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(3)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(4)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(None)
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 1}, None).validate(None)



# Generated at 2022-06-18 12:25:46.263953
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:25:53.031174
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=None)
    assert field.validate("") == ""
    assert field.validate("12345") == "12345"
    assert field.validate("12345678901") is None



# Generated at 2022-06-18 12:26:05.083199
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}) == Choice(choices=[("a", "a"), ("b", "b")])
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "a"}) == Choice(choices=[("a", "a"), ("b", "b")], default="a")
    assert enum_from_json_schema({"enum": ["a", "b"], "default": "c"}) == Choice(choices=[("a", "a"), ("b", "b")], default="c")
    assert enum_from_json_schema({"enum": ["a", "b"], "default": None}) == Choice(choices=[("a", "a"), ("b", "b")], default=None)
    assert enum_from_json

# Generated at 2022-06-18 12:26:12.792740
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate(None) == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, None).validate("baz") == "bar"



# Generated at 2022-06-18 12:26:18.421009
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions



# Generated at 2022-06-18 12:26:29.621080
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from

# Generated at 2022-06-18 12:27:18.806701
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": "^\\d+$",
    }
    assert to_

# Generated at 2022-06-18 12:27:26.209976
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not

    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(min_length=5)) == {
        "type": "string",
        "minLength": 5,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-18 12:27:38.841226
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()

    assert from_json_schema({"type": ["string", "null"]}) == String() | Any()
    assert from_json_schema({"type": ["integer", "null"]}) == Integer() | Any()
    assert from_json_

# Generated at 2022-06-18 12:27:45.521900
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert isinstance(field, OneOf)
    assert field.one_of[0].type == "string"
    assert field.one_of[1].type == "integer"
    assert field.default == ""



# Generated at 2022-06-18 12:27:57.024971
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }


# Generated at 2022-06-18 12:28:04.495420
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference

    # Test basic types
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    # Test nullable types
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_

# Generated at 2022-06-18 12:28:12.758416
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(allow_null=True),
        then_clause=String(allow_null=True),
        else_clause=Integer(allow_null=True),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": ["boolean", "null"]},
            "then": {"type": ["string", "null"]},
            "else": {"type": ["integer", "null"]},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:28:22.826316
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 3,
            "pattern": "^[a-z]*$",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") is None
    assert field.validate("a") is None
    assert field.validate("ab") is None
    assert field.validate("abc") is None
    assert field.validate("abcd") is not None
    assert field.validate("1") is not None
    assert field.validate("1a") is not None
    assert field.validate("1ab") is not None

# Generated at 2022-06-18 12:28:29.687520
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "integer",
            "minimum": 0,
            "maximum": 10,
            "default": 0,
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions)
    assert field.validate(11) == 11
    assert field.validate(-1) == -1
    assert field.validate(0) == 0
    assert field.validate(10) == 0
    assert field.validate(None) == 0
    assert field.validate("") == 0



# Generated at 2022-06-18 12:28:41.221929
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate(1) == "1"
    assert field.validate(True) is True
    assert field.validate(None) is None
    assert field.validate("1") is None
    assert field.validate(1.0) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None


# Generated at 2022-06-18 12:29:41.111660
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]})

# Generated at 2022-06-18 12:29:47.949721
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=False)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(min_length=2)) == {"type": "string", "minLength": 2}
    assert to_json_schema(String(max_length=3)) == {"type": "string", "maxLength": 3}

# Generated at 2022-06-18 12:29:59.334113
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Const(None)]
    )

# Generated at 2022-06-18 12:30:08.387678
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions


# Generated at 2022-06-18 12:30:18.896815
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:30:31.449330
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(max_length=10),
            "age": Integer(minimum=0, maximum=100),
            "address": {
                "street": String(max_length=100),
                "city": String(max_length=100),
                "state": String(max_length=2),
                "zip": String(max_length=5),
            },
        }
    )
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:30:39.465663
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "integer", "minimum": 0}) == Integer(minimum=0)
    assert from_json_schema({"type": "integer", "maximum": 0}) == Integer(maximum=0)

# Generated at 2022-06-18 12:30:49.844634
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:59.204851
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-18 12:31:10.603258
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice([("a", "a"), ("b", "b")])) == {"enum": ["a", "b"]}
    assert to_json_schema(Const("a")) == {"const": "a"}

# Generated at 2022-06-18 12:31:59.869242
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:07.489476
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:32:18.463170
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:32:22.616141
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.if_clause.type == "string"
    assert field.then_clause.type == "integer"
    assert field.else_clause.type == "number"



# Generated at 2022-06-18 12:32:31.145967
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "null", True, None) == Const(None)
    assert from_json_schema_type({}, "boolean", True, None) == Boolean(allow_null=True)
    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)
    assert from_json_schema_type({}, "string", True, None) == String(allow_null=True)
    assert from_json_schema_type({}, "array", True, None) == Array(allow_null=True)
    assert from_json_schema_type({}, "object", True, None) == Object(allow_null=True)

# Generated at 2022-06-18 12:32:40.688642
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, "number", False, None) == Float()
    assert from_json_schema_type({"type": "integer"}, "integer", False, None) == Integer()
    assert from_json_schema_type({"type": "string"}, "string", False, None) == String()
    assert from_json_schema_type({"type": "boolean"}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({"type": "array"}, "array", False, None) == Array()
    assert from_json_schema_type({"type": "object"}, "object", False, None) == Object()



# Generated at 2022-06-18 12:32:49.068534
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields as f

    assert to_json_schema(f.String()) == {"type": "string"}
    assert to_json_schema(f.String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(f.String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(f.String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(f.String(pattern_regex=re.compile("^a$"))) == {
        "type": "string",
        "pattern": "^a$",
    }

# Generated at 2022-06-18 12:32:58.769876
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:07.160806
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union(String(), Any())

# Generated at 2022-06-18 12:33:17.352458
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:49.561341
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
        "else": {"type": "boolean"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.if_clause.type == "string"
    assert field.then_clause.type == "integer"
    assert field.else_clause.type == "boolean"



# Generated at 2022-06-18 12:33:56.889337
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

