

# Generated at 2022-06-18 12:24:53.540137
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:25:01.954635
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    assert field.validate(None) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate(1.23) is None
    assert field.validate(["hello"]) is None
    assert field.validate({"hello": "world"}) is None



# Generated at 2022-06-18 12:25:13.204850
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": ["null", "string"]}, definitions=SchemaDefinitions()) == Union(any_of=[Const(None), String()])
    assert type_from_json_schema({"type": ["null", "string"]}, definitions=SchemaDefinitions()) == Union(any_of=[Const(None), String()])

# Generated at 2022-06-18 12:25:23.663388
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 0}) == String(min_length=0)
    assert from_json_schema({"type": "string", "maxLength": 0}) == String(max_length=0)
    assert from_json_schema({"type": "string", "pattern": "^a"}) == String(pattern="^a")
    assert from_json_schema({"type": "string", "format": "email"}) == String(format="email")
    assert from_json_schema({"type": "number"}) == Number()
    assert from_

# Generated at 2022-06-18 12:25:28.997070
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "array"}, definitions=SchemaDefinitions()) == Array()
    assert type_from

# Generated at 2022-06-18 12:25:33.525246
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    one_of_field = one_of_from_json_schema(data, definitions)
    assert isinstance(one_of_field, OneOf)
    assert len(one_of_field.one_of) == 2
    assert isinstance(one_of_field.one_of[0], String)
    assert isinstance(one_of_field.one_of[1], Integer)



# Generated at 2022-06-18 12:25:46.801648
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9]*$",
            "default": "",
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("abc") == "abc"
    assert field.validate("abcdefghijklmnopqrstuvwxyz") == "abcdefghijklmnopqrstuvwxyz"

# Generated at 2022-06-18 12:25:54.556903
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "number"},
            {"type": "string"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(None) == None
    assert field.validate(True) == None
    assert field.validate(False) == None
    assert field.validate([]) == None
    assert field.validate({}) == None



# Generated at 2022-06-18 12:26:01.345441
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": "else"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("a") == "a"
    assert field.validate(1) == "else"
    assert field.validate(None) == "else"

# Generated at 2022-06-18 12:26:05.763917
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}]}, SchemaDefinitions()) == Union(any_of=[String(), Integer()])



# Generated at 2022-06-18 12:27:19.164590
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:27:22.171774
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions), Reference)



# Generated at 2022-06-18 12:27:35.456885
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:27:43.838993
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") is None
    assert field.validate(1) is None
    assert field.validate(None) is None



# Generated at 2022-06-18 12:27:55.660366
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:27:59.174151
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"



# Generated at 2022-06-18 12:28:09.372418
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"\d+"))) == {
        "type": "string",
        "pattern": r"\d+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:28:20.382626
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:28:23.266284
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:28:31.050723
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"$ref": "#/definitions/positiveInteger"},
            {"minimum": 0},
        ],
        "definitions": {
            "positiveInteger": {
                "type": "integer",
                "minimum": 0,
            },
        },
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/positiveInteger"] = Integer(minimum=0)
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.validate(1.0) == 1.0
    assert field.validate(-1.0) == -1.0
    assert field.valid

# Generated at 2022-06-18 12:29:44.941885
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "enum": ["John", "Jane"],
            }
        }
    }
    field = from_json_schema(data)
    assert field.validate("name", "John") == "John"
    assert field.validate("name", "Jane") == "Jane"
    assert field.validate("name", "Jill") == "Jill"
    assert field.validate("name", "Jack") == "Jack"
    assert field.validate("name", "Jill") == "Jill"
    assert field.validate("name", "Jack") == "Jack"
    assert field

# Generated at 2022-06-18 12:29:56.307101
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("foo") == "foo"
    assert field.validate(1) == 1
    assert field.validate(None) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate(1.0) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None
    assert field.validate(1.1) is None
    assert field.validate([]) is None
    assert field.validate

# Generated at 2022-06-18 12:30:06.364315
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    def assert_json_schema(field: Field, expected: dict):
        actual = to_json_schema(field)
        assert actual == expected

    assert_json_schema(fields.String(), {"type": "string"})
    assert_json_schema(fields.String(allow_null=True), {"type": ["string", "null"]})
    assert_json_schema(
        fields.String(min_length=5, max_length=10),
        {"type": "string", "minLength": 5, "maxLength": 10},
    )
    assert_json_schema(
        fields.String(pattern_regex=re.compile("^[a-z]+$")),
        {"type": "string", "pattern": "^[a-z]+$"},
    )


# Generated at 2022-06-18 12:30:16.671400
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:24.917553
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(1)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(2)
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(3)
    assert not enum_from_json_schema({"enum": [1, 2, 3]}, None).validate(4)



# Generated at 2022-06-18 12:30:31.613874
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("a")
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("b")
    assert not enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("c")



# Generated at 2022-06-18 12:30:37.850822
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "number"},
        "else": {"type": "boolean"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, Float)
    assert isinstance(field.else_clause, Boolean)



# Generated at 2022-06-18 12:30:42.778616
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)



# Generated at 2022-06-18 12:30:48.747578
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 1}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=1)



# Generated at 2022-06-18 12:30:54.402096
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("a")
    assert enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("b")
    assert not enum_from_json_schema({"enum": ["a", "b"]}, definitions=None).validate("c")



# Generated at 2022-06-18 12:33:18.930899
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions, Schema
    from . import NO_DEFAULT

    class MySchema(Schema):
        string = String()
        integer = Integer()
        boolean = Boolean()
        array = Array(items=String())
        object = Object(properties={"string": String()})
        choice = Choice(choices=[("a", "a"), ("b", "b")])
        const = Const("a")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])

# Generated at 2022-06-18 12:33:28.463992
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])
    assert from_json_schema({"type": "string", "const": "a"}) == Const("a")
    assert from_json_schema({"type": "string", "const": "a", "enum": ["a", "b"]}) == Const("a")
    assert from_json_schema({"type": "string", "const": "c", "enum": ["a", "b"]}) == Choice(["a", "b"])
    assert from_json_schema({"type": "string", "const": "a", "enum": ["a", "b"], "minLength": 1})

# Generated at 2022-06-18 12:33:38.262144
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:44.171419
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": "default"},
        "default": "default",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("abc") == "abc"
    assert field.validate(1) == "default"
    assert field.validate(None) == "default"



# Generated at 2022-06-18 12:33:53.459456
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Decimal, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not
    from . import SchemaDefinitions, Reference
    from . import Schema, Field
    from . import NO_DEFAULT
    from . import SchemaError

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_blank=True))