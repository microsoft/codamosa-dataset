

# Generated at 2022-06-18 12:24:40.415043
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert isinstance(field, Union)
    assert field.any_of[0].type == "string"
    assert field.any_of[1].type == "integer"



# Generated at 2022-06-18 12:24:52.111591
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    assert to_json_schema(fields.Any()) == True
    assert to_json_schema(fields.NeverMatch()) == False

    assert to_json_schema(fields.String()) == {"type": "string"}
    assert to_json_schema(fields.String(allow_null=True)) == {"type": ["string", "null"]}

    assert to_json_schema(fields.Integer()) == {"type": "integer"}
    assert to_json_schema(fields.Integer(allow_null=True)) == {"type": ["integer", "null"]}

    assert to_json_schema(fields.Float()) == {"type": "number"}
    assert to_json_schema(fields.Float(allow_null=True)) == {"type": ["number", "null"]}

    assert to_

# Generated at 2022-06-18 12:25:01.721360
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:25:13.113088
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "integer"}, {"type": "string"}]}
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(None) is None
    assert field.validate("") is None
    assert field.validate(1.0) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate([]) is None
    assert field.validate({}) is None
    assert field.validate({"a": 1}) is None
    assert field.validate({"a": "1"}) is None



# Generated at 2022-06-18 12:25:17.323207
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string", "minLength": 1}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    return OneOf(**kwargs)


# Generated at 2022-06-18 12:25:22.782391
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).definitions is None



# Generated at 2022-06-18 12:25:33.761722
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ],
        "default": "default_value",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("string") == "string"
    assert field.validate(1) == 1
    assert field.validate(None) == "default_value"
    assert field.validate(True) == "default_value"
    assert field.validate(False) == "default_value"
    assert field.validate({}) == "default_value"
    assert field.validate([]) == "default_value"



# Generated at 2022-06-18 12:25:41.908834
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 1},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema(data, definitions) == Union(
        any_of=[String(min_length=1), Integer(minimum=1)], default=""
    )



# Generated at 2022-06-18 12:25:46.290632
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=3)) == {"type": "string", "minLength": 3}
    assert to_json_schema(String(max_length=3)) == {"type": "string", "maxLength": 3}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to_json_schema(String(format="date")) == {"type": "string", "format": "date"}

    assert to

# Generated at 2022-06-18 12:25:56.557343
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "pattern": "^[a-zA-Z0-9]*$",
        },
        "then": {
            "type": "string",
            "pattern": "^[a-z]*$",
        },
        "else": {
            "type": "string",
            "pattern": "^[A-Z]*$",
        },
    }
    field = if_then_else_from_json_schema(data, None)
    assert field.validate("abc")
    assert field.validate("ABC")
    assert not field.validate("abc123")
    assert not field.validate("ABC123")
    assert not field.validate("abcABC")
    assert not field.validate("ABCabc")


# Generated at 2022-06-18 12:26:28.422309
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = {
        "const": "foo",
        "default": "bar"
    }
    field = const_from_json_schema(schema, definitions)
    assert field.validate("foo") == "foo"
    assert field.validate("bar") == "bar"
    assert field.validate("baz") == "baz"



# Generated at 2022-06-18 12:26:33.070397
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    json_schema = to_json_schema(schema)
    assert json_schema == {
        "definitions": {
            "TestSchema": {
                "type": "object",
                "properties": {"field": {"type": "string"}},
                "required": ["field"],
            }
        }
    }

    class TestSchema2(Schema):
        field = String()

    schema = TestSchema2()
    json_schema = to_json_schema(schema)

# Generated at 2022-06-18 12:26:39.173475
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": "^\\d+$",
    }
    assert to_

# Generated at 2022-06-18 12:26:51.218310
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Object, Array, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference, SchemaDefinitions


# Generated at 2022-06-18 12:26:57.855312
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                    "gender": {"type": "string"},
                },
            },
        ]
    }
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert OneOf(**kwargs) == one_

# Generated at 2022-06-18 12:27:06.148877
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.validate(0) == 0
    assert field.validate(None) is None
    assert field.validate(False) is False
    assert field.validate(True) is True
    assert field.validate(1.0) == 1.0
    assert field.valid

# Generated at 2022-06-18 12:27:12.388846
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    schema = fields.Schema(
        {
            "name": fields.String(max_length=10),
            "age": fields.Integer(minimum=0, maximum=100),
            "address": fields.Object(
                {
                    "street": fields.String(max_length=100),
                    "city": fields.String(max_length=100),
                    "state": fields.String(max_length=2),
                    "zip": fields.String(max_length=5),
                }
            ),
            "phone_numbers": fields.Array(
                fields.String(max_length=10), min_items=1, max_items=5
            ),
        }
    )

# Generated at 2022-06-18 12:27:22.671445
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": "^\\d+$",
    }
    assert to_

# Generated at 2022-06-18 12:27:30.693308
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}) == Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert enum_from_json_schema({"enum": ["a", "b", "c"], "default": "b"}) == Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], default="b")



# Generated at 2022-06-18 12:27:40.823045
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 3,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]*$",
        }
    }
    result = not_from_json_schema(data, definitions=None)
    assert isinstance(result, Not)
    assert isinstance(result.negated, String)
    assert result.negated.min_length == 3
    assert result.negated.max_length == 10
    assert result.negated.pattern == "^[a-zA-Z0-9_]*$"



# Generated at 2022-06-18 12:28:25.581576
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": ["null", "string"]}, SchemaDefinitions()) == Union(any_of=[Const(None), String()])
    assert type_from_json_schema({"type": ["null", "string"], "minLength": 5}, SchemaDefinitions()) == Union(any_of=[Const(None), String(min_length=5)])



# Generated at 2022-06-18 12:28:35.677477
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])
    assert from_json_schema({"type": "string", "const": "a"})

# Generated at 2022-06-18 12:28:41.932529
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": ["a", "b", "c"]}
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"



# Generated at 2022-06-18 12:28:47.602576
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert ref_from_json_schema(data, definitions=definitions) == Reference(
        to="#/definitions/foo", definitions=definitions
    )



# Generated at 2022-06-18 12:28:53.179208
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": ["a", "b", "c"]}
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == "c"
    assert field.validate("d") == "d"



# Generated at 2022-06-18 12:29:02.894724
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(min_length=1),
            "age": Integer(minimum=0, maximum=150),
            "address": Object(
                properties={
                    "street": String(min_length=1),
                    "city": String(min_length=1),
                    "state": String(min_length=2, max_length=2),
                    "zip": String(min_length=5, max_length=5),
                }
            ),
        }
    )
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:29:14.078238
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_

# Generated at 2022-06-18 12:29:21.448646
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"type": "integer", "maximum": 100},
        ],
        "default": 0,
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate(0) == 0
    assert field.validate(50) == 50
    assert field.validate(100) == 100
    assert field.validate(-1) == -1
    assert field.validate(101) == 101



# Generated at 2022-06-18 12:29:31.629894
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 3}) == String(min_length=3)
    assert from_json_schema({"type": "string", "maxLength": 3}) == String(max_length=3)
    assert from_json_schema({"type": "string", "pattern": "^[a-z]+$"}) == String(
        pattern=re.compile("^[a-z]+$")
    )
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "number"}) == Number()

# Generated at 2022-06-18 12:29:41.826337
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=definitions) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=definitions) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)
    assert type_from_json_schema({"type": "object"}, definitions=definitions) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=definitions) == Array()

# Generated at 2022-06-18 12:30:19.647267
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:30:31.978509
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:30:36.563168
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"



# Generated at 2022-06-18 12:30:46.659171
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=False)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}

# Generated at 2022-06-18 12:30:56.753644
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic import BaseModel

    class MyModel(BaseModel):
        a: int
        b: str

    assert to_json_schema(MyModel) == {
        "definitions": {
            "MyModel": {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "string"},
                },
                "required": ["a", "b"],
            }
        },
        "$ref": "#/definitions/MyModel",
    }

    class MyModel2(BaseModel):
        a: int
        b: typing.Optional[str]


# Generated at 2022-06-18 12:31:06.311942
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:31:17.964751
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:31:28.310133
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b", "c"]}) == Choice(
        choices=["a", "b", "c"]
    )

# Generated at 2022-06-18 12:31:31.734560
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:31:40.270039
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    assert to_json_schema(fields.String()) == {"type": "string"}
    assert to_json_schema(fields.String(allow_null=True)) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(fields.String(default="foo")) == {
        "type": "string",
        "default": "foo",
    }
    assert to_json_schema(fields.String(allow_blank=True)) == {
        "type": "string",
        "minLength": 0,
    }
    assert to_json_schema(fields.String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }

# Generated at 2022-06-18 12:32:08.101815
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, "number", False, None) == Float()
    assert from_json_schema_type({"type": "number"}, "number", True, None) == Float(
        allow_null=True
    )
    assert from_json_schema_type({"type": "integer"}, "integer", False, None) == Integer()
    assert from_json_schema_type({"type": "integer"}, "integer", True, None) == Integer(
        allow_null=True
    )
    assert from_json_schema_type({"type": "string"}, "string", False, None) == String()
    assert from_json_schema_type({"type": "string"}, "string", True, None) == String(
        allow_null=True
    )
   

# Generated at 2022-06-18 12:32:19.059794
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:28.214827
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from .schema import SchemaDefinitions

    class MySchema(Schema):
        name = String()
        age = Integer()
        is_admin = Boolean()
        friends = Array(String())
        address = Object(
            {
                "street": String(),
                "city": String(),
                "state": String(),
                "zip": String(),
            }
        )
        color = Choice(
            [
                ("red", "Red"),
                ("green", "Green"),
                ("blue", "Blue"),
            ]
        )
        constant = Const("constant")
        union = Union(String(), Integer())
        one_of = OneOf(String(), Integer())
        all

# Generated at 2022-06-18 12:32:38.700936
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^a$"))) == {
        "type": "string",
        "pattern": "^a$",
    }

# Generated at 2022-06-18 12:32:47.615168
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:57.610646
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
    }

    schema = TestSchema(allow_extra_fields=True)
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {"field": {"type": "string"}},
        "required": ["field"],
        "additionalProperties": True,
    }

    schema = TestSchema(allow_extra_fields=False)
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:33:02.628853
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/foo",
        "definitions": {
            "foo": {
                "type": "string",
                "minLength": 1,
            }
        }
    }
    field = from_json_schema(schema)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions["#/definitions/foo"].min_length == 1



# Generated at 2022-06-18 12:33:09.175574
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:33:18.807147
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Const(None)]
    )

# Generated at 2022-06-18 12:33:28.507157
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:33:55.582754
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()

    assert from_json_