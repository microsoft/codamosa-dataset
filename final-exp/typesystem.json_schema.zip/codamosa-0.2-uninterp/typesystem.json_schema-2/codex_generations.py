

# Generated at 2022-06-18 12:25:29.008828
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "enum": ["foo", "bar"]}) == Choice(
        choices=["foo", "bar"]
    )
    assert from_json_schema({"type": "string", "const": "foo"}) == Const("foo")
    assert from_json_schema({"type": "string", "const": "foo", "enum": ["foo", "bar"]}) == (
        Const("foo") | Choice(choices=["foo", "bar"])
    )

# Generated at 2022-06-18 12:25:41.120665
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=definitions) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=definitions) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)
    assert type_from_json_schema({"type": "array"}, definitions=definitions) == Array()
    assert type_from_json_schema({"type": "object"}, definitions=definitions) == Object()

# Generated at 2022-06-18 12:25:52.458211
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
            {"maxLength": 10},
        ],
        "default": "default",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None
    assert field.validate(None) is None
    assert field.validate(1) is None
    assert field.validate(True) is None
    assert field.validate(False) is None
    assert field.validate([]) is None
    assert field.validate({}) is None
    assert field.validate({"hello": "world"}) is None

# Generated at 2022-06-18 12:25:54.469098
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:26:06.960317
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("") == ""
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate([]) == []


# Generated at 2022-06-18 12:26:17.988491
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "minLength": 2,
            "maxLength": 3,
            "pattern": "^[a-zA-Z]+$",
        },
        "then": {"type": "integer"},
        "else": {"type": "number"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("abc") == "abc"
    assert field.validate(123) == 123
    assert field.validate(123.45) == 123.45
    assert field.validate("ab") == "ab"
    assert field.validate("abcd") == "abcd"
    assert field.validate("a1") == "a1"

# Generated at 2022-06-18 12:26:22.166099
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, None).validate("bar") == "foo"



# Generated at 2022-06-18 12:26:32.058398
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "array"}, definitions=SchemaDefinitions()) == Array()
    assert type_from

# Generated at 2022-06-18 12:26:37.322079
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("b") == "b"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("c") == "c"
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None).validate("d") == "d"



# Generated at 2022-06-18 12:26:42.321590
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'null'}) == ({'null'}, True)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': ['integer', 'number']}) == ({'integer', 'number'}, False)
    assert get_valid_types({'type': ['null', 'integer', 'number']}) == ({'integer', 'number'}, True)

# Generated at 2022-06-18 12:28:46.378024
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("") == ""
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate("a") == "a"
    assert field.validate("") == ""
    assert field.validate(None) == ""
    assert field.validate(True) == ""
    assert field

# Generated at 2022-06-18 12:28:56.661555
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:29:03.398371
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:29:09.858990
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("hello")
    assert field.validate(123)
    assert not field.validate(True)



# Generated at 2022-06-18 12:29:20.120825
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:29:22.075265
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:29:25.922674
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"



# Generated at 2022-06-18 12:29:36.374763
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    field = one_of_from_json_schema(schema, definitions=None)
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate(["test"]) == ["test"]
    assert field.valid

# Generated at 2022-06-18 12:29:40.229955
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-18 12:29:46.882366
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
                "pattern": "^[a-zA-Z0-9]*$",
            },
            {"type": "null"},
        ]
    }
    field = one_of_from_json_schema(data, None)
    assert isinstance(field, OneOf)
    assert len(field.one_of) == 2
    assert isinstance(field.one_of[0], String)
    assert isinstance(field.one_of[1], Const)
    assert field.one_of[1].const == None



# Generated at 2022-06-18 12:30:16.673305
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "string"},
        "default": "default",
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert field.validate(None) == "default"
    assert field.validate(True) == "default"
    assert field.validate(1) == "default"
    assert field.validate("") == "default"
    assert field.validate("string") == "default"
    assert field.validate(["string"]) == "default"



# Generated at 2022-06-18 12:30:28.949505
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]+$",
        },
        "default": "",
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Not)
    assert isinstance(field.negated, String)
    assert field.negated.min_length == 1
    assert field.negated.max_length == 10
    assert field.negated.pattern == "^[a-zA-Z0-9_]+$"
    assert field.default == ""



# Generated at 2022-06-18 12:30:31.713931
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-18 12:30:38.871134
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[a-zA-Z0-9_]+$",
        }
    }
    result = not_from_json_schema(data, definitions=None)
    assert isinstance(result, Not)
    assert isinstance(result.negated, String)
    assert result.negated.min_length == 1
    assert result.negated.max_length == 10
    assert result.negated.pattern == "^[a-zA-Z0-9_]+$"



# Generated at 2022-06-18 12:30:40.731787
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}}, definitions=None) == Not(negated=String())



# Generated at 2022-06-18 12:30:46.564700
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
        ],
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("a") == "a"
    assert field.validate("") == "a"
    assert field.validate(1) == "a"



# Generated at 2022-06-18 12:30:52.777244
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "integer", "minimum": 1},
            {"type": "integer", "maximum": 10},
        ],
        "default": 5,
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate(5) == 5
    assert field.validate(10) == 10
    assert field.validate(11) == 5



# Generated at 2022-06-18 12:30:58.100359
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1},
        ],
    }
    field = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.validate("foo") == "foo"
    assert field.validate("") is None
    assert field.validate(1) is None
    assert field.validate(None) is None



# Generated at 2022-06-18 12:31:09.581381
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(
        choices=["a", "b"]
    )

# Generated at 2022-06-18 12:31:17.610927
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()



# Generated at 2022-06-18 12:31:47.017983
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert from_json_schema_type({}, "object", False, None) == Object()

    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)

# Generated at 2022-06-18 12:31:58.449696
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({"type": "array"}, type_string="array", allow_null=False) == Array()
    assert from_json_schema_type({"type": "object"}, type_string="object", allow_null=False) == Object()

# Generated at 2022-06-18 12:32:08.764185
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        name = String()
        age = Integer()
        is_admin = Boolean()
        tags = Array(String())
        address = Object(
            properties={"street": String(), "city": String(), "zip": String()}
        )
        gender = Choice(choices=[("male", "Male"), ("female", "Female")])

    schema = TestSchema()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:32:19.733469
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse

    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}

# Generated at 2022-06-18 12:32:28.972154
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:39.444102
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_

# Generated at 2022-06-18 12:32:48.157016
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(["a", "b"])

# Generated at 2022-06-18 12:32:58.042442
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)
    assert from_json_schema({"type": "string", "maxLength": 1}) == String(max_length=1)
    assert from_json_schema({"type": "string", "pattern": "^a+$"}) == String(
        pattern=re.compile("^a+$")
    )
    assert from_json_schema({"type": "string", "format": "date-time"}) == String(
        format="date-time"
    )
    assert from_json_schema({"type": "number"}) == Number()

# Generated at 2022-06-18 12:33:06.569686
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_

# Generated at 2022-06-18 12:33:16.795369
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()
    assert from_json_

# Generated at 2022-06-18 12:33:47.554736
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_blank=False)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(min_length=5)) == {"type": "string", "minLength": 5}