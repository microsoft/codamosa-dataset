

# Generated at 2022-06-18 12:25:01.428310
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "string"},
                }
            },
            {
                "type": "object",
                "properties": {
                    "c": {"type": "string"},
                    "d": {"type": "string"},
                }
            },
        ]
    }
    definitions = SchemaDefinitions()

# Generated at 2022-06-18 12:25:12.684869
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    class TestSchema(Schema):
        field = String(min_length=1, max_length=10)

    schema = TestSchema()
    data = to_json_schema(schema)
    assert data == {
        "type": "object",
        "properties": {
            "field": {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
            }
        },
        "required": ["field"],
    }

    schema = TestSchema(allow_unknown=True)
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:25:18.263097
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": [1, 2, 3], "default": 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)



# Generated at 2022-06-18 12:25:21.788001
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
        },
        definitions=None,
    )



# Generated at 2022-06-18 12:25:25.657523
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, String)
    assert isinstance(field.else_clause, Integer)
    assert field.default is NO_DEFAULT



# Generated at 2022-06-18 12:25:32.640620
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(allow_blank=True)) == {"type": "string"}
    assert to_json_schema(String(allow_blank=False)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_

# Generated at 2022-06-18 12:25:46.017592
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "string",
                "not": {"enum": ["bar"]}
            }
        }
    }
    field = from_json_schema(schema)
    assert field.validate({"foo": "baz"}) == {"foo": "baz"}
    assert field.validate({"foo": "bar"}) == {"foo": "bar"}
    assert field.validate({"foo": "bar"}, raise_on_error=True) == {"foo": "bar"}
    assert field.validate({"foo": "bar"}, raise_on_error=True) == {"foo": "bar"}

# Generated at 2022-06-18 12:25:56.293290
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:26:03.916575
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ]
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("hello") == "hello"
    assert field.validate("") is None
    assert field.validate("hello world") is None



# Generated at 2022-06-18 12:26:09.343210
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "string"},
        "then": {"maxLength": 5},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123



# Generated at 2022-06-18 12:26:32.735103
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": "hello"
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("hello") == "hello"
    assert field.validate(1) == 1
    assert field.validate(None) == "hello"



# Generated at 2022-06-18 12:26:35.958427
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert isinstance(field, OneOf)
    assert len(field.one_of) == 2
    assert isinstance(field.one_of[0], String)
    assert isinstance(field.one_of[1], Integer)



# Generated at 2022-06-18 12:26:39.993180
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"$ref": "#/definitions/string"},
            {"minLength": 1},
        ],
        "definitions": {
            "string": {"type": "string"},
        },
    }
    field = from_json_schema(schema)
    assert field.validate("foo") == "foo"
    assert field.validate("") is None



# Generated at 2022-06-18 12:26:50.186519
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "string"}]}, definitions=definitions) == AllOf(all_of=[String()])
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"type": "integer"}]}, definitions=definitions) == AllOf(all_of=[String(), Integer()])
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"type": "integer"}], "default": "test"}, definitions=definitions) == AllOf(all_of=[String(), Integer()], default="test")


# Generated at 2022-06-18 12:26:54.888878
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "minLength": 1},
            {"type": "integer", "minimum": 0},
        ],
        "default": "",
    }
    definitions = SchemaDefinitions()
    one_of_from_json_schema(data, definitions)
    assert definitions["#/oneOf/0"] == String(min_length=1)
    assert definitions["#/oneOf/1"] == Integer(minimum=0)



# Generated at 2022-06-18 12:27:04.747050
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:27:10.140521
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string"},
            {"minLength": 3},
        ]
    }
    field = from_json_schema(schema)
    assert field.validate("abc") == "abc"
    assert field.validate("ab") is None
    assert field.validate(1) is None



# Generated at 2022-06-18 12:27:16.561432
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ]
    }
    definitions = SchemaDefinitions()
    field = any_of_from_json_schema(data, definitions)
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    assert field.validate(None) == None



# Generated at 2022-06-18 12:27:24.843704
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-18 12:27:34.180879
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "maxLength": 10},
        ],
        "default": "",
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate("abcdefghij") == "abcdefghij"
    assert field.validate("abcdefghijk") == "abcdefghijk"



# Generated at 2022-06-18 12:28:25.355614
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("foo") == "foo"
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate("bar") == "foo"
    assert const_from_json_schema({"const": "foo"}, definitions=None).validate(None) == "foo"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions=None).validate(None) == "bar"
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions=None).validate("baz") == "bar"

# Generated at 2022-06-18 12:28:31.335205
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number", False, None), Float)
    assert isinstance(from_json_schema_type({}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({}, "string", False, None), String)
    assert isinstance(from_json_schema_type({}, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False, None), Array)
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)



# Generated at 2022-06-18 12:28:42.633753
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference, SchemaDefinitions

    class TestSchema(SchemaDefinitions):
        string = String()
        integer = Integer()
        float = Float()
        boolean = Boolean()
        array = Array(items=String())
        object = Object(properties={"string": String()})
        choice = Choice(choices=[("a", "A"), ("b", "B")])
        const = Const("a")
        union = Union(any_of=[String(), Integer()])
        one_of = OneOf(one_of=[String(), Integer()])
        all_of = AllOf(all_of=[String(), Integer()])
        not_ = Not(negated=String())
        if_then_

# Generated at 2022-06-18 12:28:49.903600
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "a"}
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.validate("a") == "a"
    assert field.validate("b") == "a"
    assert field.validate(None) == "a"
    assert field.validate(True) == "a"
    assert field.validate(False) == "a"



# Generated at 2022-06-18 12:28:57.442778
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "a"}, None).validate("a")
    assert not const_from_json_schema({"const": "a"}, None).validate("b")
    assert const_from_json_schema({"const": "a", "default": "b"}, None).validate(None)
    assert const_from_json_schema({"const": "a", "default": "b"}, None).validate("a")
    assert not const_from_json_schema({"const": "a", "default": "b"}, None).validate("b")



# Generated at 2022-06-18 12:29:05.437916
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, IfThenElse, Not, Reference
    from . import SchemaDefinitions, Schema
    from . import NO_DEFAULT

    class TestSchema(Schema):
        a = String(default="hello")
        b = Integer(default=42)
        c = Float(default=3.14)
        d = Boolean(default=True)
        e = Array(Integer, default=[1, 2, 3])
        f = Object({"x": Integer, "y": Integer}, default={"x": 1, "y": 2})
        g = Choice(
            [
                ("a", "A"),
                ("b", "B"),
                ("c", "C"),
            ],
            default="a",
        )
       

# Generated at 2022-06-18 12:29:16.160113
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": 1},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(None) == 1
    assert field.validate(True) == 1
    assert field.validate(False) == 1
    assert field.validate(0) == 1
    assert field.validate(0.0) == 1
    assert field.validate(0.1) == 1
    assert field.validate([]) == 1
    assert field.validate({}) == 1
    assert field.validate({"a": 1})

# Generated at 2022-06-18 12:29:24.668006
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "enum": ["foo", "bar"],
        },
        "then": {
            "type": "string",
            "enum": ["foo", "bar"],
        },
        "else": {
            "type": "string",
            "enum": ["foo", "bar"],
        },
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("foo") == "foo"
    assert field.validate("bar") == "bar"
    assert field.validate("baz") == "baz"



# Generated at 2022-06-18 12:29:35.175104
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:29:44.380587
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:30:30.508792
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {
            "name": String(),
            "age": Integer(minimum=0, maximum=100),
            "address": {
                "street": String(min_length=1, max_length=100),
                "city": String(min_length=1, max_length=100),
                "state": String(min_length=2, max_length=2),
                "zip": String(min_length=5, max_length=5),
            },
            "phone": String(min_length=10, max_length=10),
        }
    )

# Generated at 2022-06-18 12:30:39.476942
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:30:45.310786
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 1},
        "else": {"const": "no"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate("yes") == "yes"
    assert field.validate("no") == "no"
    assert field.validate(1) == "no"

# Generated at 2022-06-18 12:30:55.814106
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    class TestSchema(Schema):
        name = fields.String(min_length=1, max_length=10)
        age = fields.Integer(minimum=0, maximum=100)
        gender = fields.Choice(choices=[("M", "Male"), ("F", "Female")])

    schema = TestSchema.make_validator()
    data = to_json_schema(schema)

# Generated at 2022-06-18 12:31:02.545539
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"\d+"))) == {
        "type": "string",
        "pattern": r"\d+",
    }
    assert to_json_sche

# Generated at 2022-06-18 12:31:14.652031
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Any()])
    assert from_json_schema({"type": ["string", "null"], "enum": ["a", "b"]}) == Choice

# Generated at 2022-06-18 12:31:24.720644
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=1)) == {"type": "string", "maxLength": 1}
    assert to_json_schema(String(pattern_regex=re.compile("^a$"))) == {
        "type": "string",
        "pattern": "^a$",
    }

# Generated at 2022-06-18 12:31:34.455318
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String()
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({"type": "string"}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({"type": "string"}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({"type": "string"}, type_string="number", allow_null=False) == Float()

# Generated at 2022-06-18 12:31:44.718502
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile(r"^\d+$"))) == {
        "type": "string",
        "pattern": r"^\d+$",
    }
    assert to

# Generated at 2022-06-18 12:31:56.115750
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=5)) == {"type": "string", "minLength": 5}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:32:19.570056
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(data={}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type(data={}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type(data={}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type(data={}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type(data={}, type_string="array", allow_null=False, definitions=None) == Array()

# Generated at 2022-06-18 12:32:28.812404
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-18 12:32:39.316196
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        a = String()
        b = Integer()
        c = Array(items=String())
        d = Object(properties={"a": String(), "b": Integer()})
        e = Choice(choices=[("a", "a"), ("b", "b")])
        f = Const("a")
        g = Union(any_of=[String(), Integer()])
        h = OneOf(one_of=[String(), Integer()])
        i = AllOf(all_of=[String(), Integer()])
        j = IfThenElse(
            if_clause=String(),
            then_clause=Integer(),
            else_clause=Float(),
        )
        k = Not(negated=String())

    schema = TestSchema()
    data = to_json_schema(schema)


# Generated at 2022-06-18 12:32:48.063921
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(
        allow_null=True
    )
    assert from_json_schema

# Generated at 2022-06-18 12:32:58.005243
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:33:06.608267
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Const(None)

# Generated at 2022-06-18 12:33:16.795037
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "null"}) == Any()
    assert from_json_schema({"type": ["string", "null"]}) == Union(
        [String(), Any()]
    )

# Generated at 2022-06-18 12:33:22.757685
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Boolean, Array, Object, Choice, Const, Union, OneOf, AllOf, Not, IfThenElse, Reference

    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Choice(choices=[("a", "A"), ("b", "B")])) == {
        "enum": ["a", "b"]
    }
    assert to_json_schema(Const(const="a")) == {"const": "a"}


# Generated at 2022-06-18 12:33:33.161705
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(String(min_length=1)) == {"type": "string", "minLength": 1}
    assert to_json_schema(String(max_length=10)) == {"type": "string", "maxLength": 10}
    assert to_json_schema(String(pattern_regex=re.compile("^[a-z]+$"))) == {
        "type": "string",
        "pattern": "^[a-z]+$",
    }

# Generated at 2022-06-18 12:33:41.578644
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(Integer(default=42)) == {
        "type": "integer",
        "default": 42,
    }
    assert to_json_schema(Integer(default=42, allow_null=True)) == {
        "type": ["integer", "null"],
        "default": 42,
    }
    assert to_json_schema(Integer(default=42, allow_null=True, minimum=0)) == {
        "type": ["integer", "null"],
        "default": 42,
        "minimum": 0,
    }