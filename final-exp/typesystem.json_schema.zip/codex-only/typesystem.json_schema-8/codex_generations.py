

# Generated at 2022-06-24 10:49:17.583541
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "integer"}]}
    schema = from_json_schema(data)
    assert schema.validate(1) == 1
    assert schema.validate("a") == "a"


# Generated at 2022-06-24 10:49:19.916896
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'string'}, {'type': 'integer'}]}
    result = any_of_from_json_schema(data, definitions)
    type(result) == Union



# Generated at 2022-06-24 10:49:30.547062
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "integer", "minimum": 0}]}, None).validate(0) == 0
    assert not all_of_from_json_schema({"allOf": [{"type": "integer", "minimum": 0}]}, None).validate(-1)
    assert not all_of_from_json_schema({"allOf": [{"type": "integer", "minimum": 0}]}, None).validate(None)
    assert all_of_from_json_schema({"allOf": [{"type": "integer", "minimum": 0}], "default": 0}, None).validate(None) == 0

# Generated at 2022-06-24 10:49:33.565925
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "integer"},
        "then": {"minimum": 5},
        "else": {"maximum": 10},
    }

    definition = if_then_else_from_json_schema(schema, SchemaDefinitions())
    assert definition.validate(4) == 10
    assert definition.validate(4.0) == 4.0
    assert definition.validate(4.0, default_value=None) is None



# Generated at 2022-06-24 10:49:45.476735
# Unit test for function get_standard_properties
def test_get_standard_properties():
    f = Field(default="a")
    assert get_standard_properties(f) == {"default": "a"}

    f = Float(default=3.14)
    assert get_standard_properties(f) == {"default": 3.14}

    f = Array(default=["a", "b", "c"])
    assert get_standard_properties(f) == {"default": ["a", "b", "c"]}

    f = Object(default={"a": 3.14})
    assert get_standard_properties(f) == {"default": {"a": 3.14}}

    f = Choice(default="a", choices=[("a", "A"), ("b", "B"), ("c", "C")])
    assert get_standard_properties(f) == {"default": "a"}


# Generated at 2022-06-24 10:49:51.167724
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from .fields import IfThenElse

    data = {
        "if": {"type": "string"},
        "then": {"type": "integer", "minimum": 1, "default": 1,},
        "else": {
            "type": "string",
            "pattern": "^(?!then\\b)\\w+$",
            "default": "else",
        },
    }
    f = if_then_else_from_json_schema(data, definitions=None)
    assert isinstance(f, IfThenElse)
    assert f.if_clause.is_valid("0") is True
    assert f.else_clause.is_valid("0") is True
    assert f.if_clause.default == NO_DEFAULT
    assert f.then_clause.default == 1
    assert f.else_

# Generated at 2022-06-24 10:49:57.594806
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    #pylint: disable=E1101
    assert enum_from_json_schema({'enum': [1, 2, 3, 4]}, definitions=None) == Choice(choices=[(1, 1), (2, 2), (3, 3), (4, 4)])
    assert enum_from_json_schema({'enum': ['a', 'b', 'c', 'd']}, definitions=None) == Choice(choices=[('a', 'a'), ('b', 'b'), ('c', 'c'), ('d', 'd')])
    assert enum_from_json_schema({'enum': [], 'default': 'a'}, definitions=None) == Choice(choices=[], default='a')



# Generated at 2022-06-24 10:50:09.142573
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-24 10:50:21.896290
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema_obj1 = {
        "if": {
            "type": "string",
            "minLength": 1
        },
        "then": {
            "type": "string",
            "pattern": "^[0-9]+$"
        },
        "else": {
            "type": "string",
            "pattern": "^[a-z]*$"
        }
    }
    field1 = if_then_else_from_json_schema(json_schema_obj1, None)
    assert field1.if_clause.check(["foo"])
    assert field1.then_clause.check(["123456789"])

# Generated at 2022-06-24 10:50:32.945852
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Tests that any_of_from_json_schema correctly converts anyOf json_schema to field.
    # Arrange
    data = {
                "anyOf": [
                {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 5
                },
                {
                    "type": "string",
                    "minLength": 7,
                    "maxLength": 15
                }
            ]
        }
    definitions = SchemaDefinitions()
    any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    # Act
    kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    field = Union(**kwargs)
    # Assert

# Generated at 2022-06-24 10:50:39.639272
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "number", "nullable": True}) == ({"number"}, True)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null", "boolean", "object", "array", "number", "string"]}) == (set(), False)


# Generated at 2022-06-24 10:50:47.301605
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == Union([String(), Const(None)])

# Generated at 2022-06-24 10:50:59.103064
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Float()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "null"}) == Const(None)

    assert from_json_schema({"type": ["string", "null"]}) == String(allow_null=True)
    assert from_json_schema({"type": ["number"]}) == Float()
    assert from_json_sche

# Generated at 2022-06-24 10:51:12.045996
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
  import functools
  import json

  @functools.lru_cache(maxsize=None)
  def read_json_schema(filename):
    with open(filename) as file:
      return json.load(file)

  json_schema = read_json_schema("tests/fixtures/json_schema/enum_schema.json")
  typesystem_field = from_json_schema(json_schema)
  assert typesystem_field.validate("one") is None
  assert typesystem_field.validate("two") is None
  assert typesystem_field.validate("three") is None
  assert typesystem_field.validate("four") is None
  assert isinstance(typesystem_field.validate("five"), Choice)



# Generated at 2022-06-24 10:51:15.094545
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data: dict = {"anyOf": [True, False, None]}
    definitions: SchemaDefinitions = {}
    field: Field = any_of_from_json_schema(data=data, definitions=definitions)
    assert field.validate(value=True)



# Generated at 2022-06-24 10:51:22.108489
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = from_json_schema(
        {
            "definitions": {
                "Animal": {"type": "object", "properties": {"name": {"type": "string"}}},
                "Dog": {"$ref": "#/definitions/Animal"},
            },
            "$ref": "#/definitions/Dog",
        }
    )
    assert isinstance(schema, Reference)
    assert schema.to == "#/definitions/Dog"
    assert isinstance(schema.resolve(), Object)
    assert schema.resolve().properties["name"].type == "string"



# Generated at 2022-06-24 10:51:28.393905
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": ["red", "green", "blue"], "type": "string"}
    data = {"color": "green"}

    field = enum_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate(data)

    data = {"color": "violet"}
    assert not field.validate(data)


# Generated at 2022-06-24 10:51:38.190891
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    d = {"type": "string", "anyOf": [{"type": "string", "enum": ["a","b","c"]},{"type": "string", "enum": ["d","e","f"]}]}
    assert(isinstance(any_of_from_json_schema(d,None), Union))
    d = {"type": "string", "anyOf": [{"type": "string", "enum": ["a","b","c"]},{"type": "object", "additionalProperties": False}]}
    assert(isinstance(any_of_from_json_schema(d,None), Union))
    d = {"type": "string", "anyOf": [{"type": "string", "enum": ["a","b","c"]}]}
    assert(isinstance(any_of_from_json_schema(d,None), Union))

# Generated at 2022-06-24 10:51:42.444909
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(None) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()



# Generated at 2022-06-24 10:51:44.199084
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="abc")) == {"default": "abc"}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}



# Generated at 2022-06-24 10:51:56.095865
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "https://example.com/person.schema.json",
        "title": "Person",
        "description": "A person",
        "type": "object",
        "properties": {
            "age": {
                "description": "Age in years which must be equal to or greater than zero.",
                "type": "integer",
                "minimum": 0,
            },
            "name": {"description": "A person's name.", "type": "string"},
        },
        "required": ["name"],
        "default": {"age": 18},
    }
    person = from_json_schema(data)

# Generated at 2022-06-24 10:52:04.071255
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    source = {
        "definitions": {
            "foo": {
                "type": "object",
                "properties": {
                    "bar": {"$ref": "#/definitions/baz"},
                    "baz": {"$ref": "#/definitions/bar"},
                },
            },
            "bar": {"type": "string"},
            "baz": {"type": "integer"},
        },
    }
    referenced = from_json_schema(source)
    assert isinstance(referenced, Schema)
    assert referenced.definitions
    assert isinstance(referenced.definitions["#/definitions/bar"], Field)
    assert isinstance(referenced.definitions["#/definitions/baz"], Field)
    assert referenced.definitions["#/definitions/baz"].parent_field


# Generated at 2022-06-24 10:52:14.688929
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "number",
                "minimum": 2
            },
            {
                "type": "number",
                "maximum": 7
            }
        ]
    }
    assert all_of_from_json_schema(data, definitions = definitions) == AllOf([ Number(minimum = 2), Number(maximum = 7) ])
    data = {
        "allOf": [
            {
                "type": "string",
                "pattern": "\\w+"
            },
            {
                "type": "string",
                "maxLength": 10
            }
        ]
    }

# Generated at 2022-06-24 10:52:24.591319
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    If-then-else condition in JSON schema is not yet implemented
    in marshmallow schemas.
    """

# Generated at 2022-06-24 10:52:29.040573
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # type: () -> None

    # Without "then" and "else"
    data = {"if": {"type": "integer"}}
    field = if_then_else_from_json_schema(data, SchemaDefinitions())
    assert_valid(field, 42)
    assert_invalid(field, 42.0)

    # With "then"
    data = {
        "if": {"type": "integer"},
        "then": {"minimum": 10},
    }
    field = if_then_else_from_json_schema(data, SchemaDefinitions())
    assert_valid(field, 42)
    assert_invalid(field, 9)

    # With "then" and "else"

# Generated at 2022-06-24 10:52:33.225266
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json_schema_object = {
        "type": "object",
        "properties": {"type": {"enum": ["track", "album", "artist"]}},
        "not": {"type": "string"},
    }
    field = not_from_json_schema(json_schema_object, definitions=SchemaDefinitions())
    assert field.validate({"type": "track"}) == {"type": "track"}


# Generated at 2022-06-24 10:52:43.466129
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, {}) is Any()
    assert type_from_json_schema({"type": "string"}, {}) is String()
    assert type_from_json_schema({"type": "boolean"}, {}) is Boolean()
    assert type_from_json_schema({"type": "integer"}, {}) is Integer()
    assert type_from_json_schema({"type": "number"}, {}) is Float()
    assert type_from_json_schema({"type": ["integer", "number"]}, {}) is Number()
    assert type_from_json_schema({"type": "null"}, {}) is Const(None)
    assert type_from_json_schema({"type": "null"}, {}).allow_null


# Generated at 2022-06-24 10:52:46.156093
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/string'}, definitions={}), Reference)


# Generated at 2022-06-24 10:52:51.171471
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    any_of = any_of_from_json_schema(
        data={"anyOf":[{"type":"number"},{"enum":[1,2,3]}],"default":1}
        )
    print(any_of.validate(1))
    print(any_of.validate("1"))    


# Generated at 2022-06-24 10:53:01.425810
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({'type': 'string'}, None).type == String.type
    assert type_from_json_schema({'type': 'integer'}, None).type == Integer.type
    assert type_from_json_schema({'type': 'number'}, None).type == Number.type
    assert type_from_json_schema({'type': 'boolean'}, None).type == Boolean.type
    assert type_from_json_schema({'type': 'array'}, None).type == Array.type
    assert type_from_json_schema({'type': 'object'}, None).type == Object.type
    assert type_from_json_schema({'type': 'null'}, None).type == Const.type


# Generated at 2022-06-24 10:53:08.742219
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    e1 = enum_from_json_schema({"enum": [1, "foo", None], "default": 1})
    assert e1.validate(1) is True
    assert e1.validate(2) is False
    e2 = enum_from_json_schema({"enum": [1, "foo", None]})
    assert e2.validate(1) is True
    assert e2.validate(2) is None



# Generated at 2022-06-24 10:53:15.541676
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    enum_data = {"$schema": "http://json-schema.org/draft/2019-09/schema", "enum": ["a", "b"], "default": "a"}
    enum_field = enum_from_json_schema(enum_data, None)
    assert isinstance(enum_field, Choice)
    assert enum_field.choices == [('a', 'a'), ('b', 'b')]
    assert enum_field.validate('a') == 'a'
    assert enum_field.validate('b') == 'b'
    assert enum_field.validate('c') == None
    assert enum_field.default == 'a'



# Generated at 2022-06-24 10:53:24.657345
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, 2, 3]}
    assert enum_from_json_schema(data, {}).validate(1)
    assert not enum_from_json_schema(data, {}).validate("1")
    assert not enum_from_json_schema(data, {}).validate("1.1")
    assert not enum_from_json_schema(data, {}).validate("hi")
    data = {"enum": [1, "1.1", 3]}
    assert enum_from_json_schema(data, {}).validate(1)
    assert enum_from_json_schema(data, {}).validate("1.1")
    assert not enum_from_json_schema(data, {}).validate("hi")
    data["default"] = "1.1"
   

# Generated at 2022-06-24 10:53:27.588196
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "foo"}
    field = const_from_json_schema(data, definitions)
    assert {"foo"} == field.const


# Generated at 2022-06-24 10:53:35.504016
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {
        "enum": [True, False]
    }

    field = from_json_schema(data)
    assert isinstance(field, Boolean)
    assert field.choices == {True, False}

    data = {"$ref": "#/definitions/Foo"}

    definitions = SchemaDefinitions()
    definitions["#/definitions/Foo"] = String()

    field = from_json_schema(data, definitions=definitions)
    assert isinstance(field, String)

    data = {"const": True}

    field = from_json_schema(data)
    assert isinstance(field, Const)
    assert field.value == True

    data = {
        "allOf": [{"const": True}, {"const": False}]
    }


# Generated at 2022-06-24 10:53:39.712965
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = any_of_from_json_schema({
        "anyOf": [
            {"type":"integer"},
            {"type":"string"},
        ]
    }, definitions=None)
    assert isinstance(field, Union)
    assert field.any_of[0] == Integer()
    assert field.any_of[1] == String()


# Generated at 2022-06-24 10:53:45.501921
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {
        "enum": [
            "small",
            "medium",
            "large",
        ],
    }
    field = enum_from_json_schema(json_schema, None)
    assert type(field) == Choice
    assert field.choices == [('small', 'small'), ('medium', 'medium'), ('large', 'large')]


# Generated at 2022-06-24 10:53:57.775672
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }

    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
    }

    assert to_json_schema(String(max_length=10)) == {
        "type": "string",
        "maxLength": 10,
    }

    assert to_json_schema(Integer(minimum=5)) == {
        "type": "integer",
        "minimum": 5,
    }

    assert to_json_schema(Integer(maximum=10)) == {
        "type": "integer",
        "maximum": 10,
    }


# Generated at 2022-06-24 10:54:07.854242
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=True), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=True), Integer)
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=True), Number)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=True), String)

    items = {"const": 1}
    data = {"type": "array", "items": items}
    field = from_json_schema_type(data, type_string="array", allow_null=True)
    assert isinstance(field, Array)
    assert field.items == from_json_

# Generated at 2022-06-24 10:54:15.200996
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "foo": {
                "enum": [
                    "a",
                    "b",
                    "c"
                ],
                "type": "string"
            }
        }
    }

    field = enum_from_json_schema(data['properties']['foo'], definitions=None)
    # TODO: assert field == Choice()



# Generated at 2022-06-24 10:54:20.000728
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = Integer()
    then_clause = String()
    else_clause = Array(items=Integer())
    field = IfThenElse(
        if_clause=if_clause, then_clause=then_clause, else_clause=else_clause
    )

    valid_then_data = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "array", "items": {"type": "integer"}},
    }
    assert field.validate(valid_then_data) == (True, [])


# Generated at 2022-06-24 10:54:29.968996
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(AllOf(String(), Integer())) == {
        "allOf": [{"type": ["string", "null"]}, {"type": ["integer", "null"]}]
    }
    assert to_json_schema(AnyOf(String(), Integer())) == {
        "anyOf": [{"type": ["string", "null"]}, {"type": ["integer", "null"]}]
    }
    assert to_json_schema(OneOf(String(), Integer())) == {
        "oneOf": [{"type": ["string", "null"]}, {"type": ["integer", "null"]}]
    }
    assert to_json_schema(Not(String())) == {"not": {"type": ["string", "null"]}}

# Generated at 2022-06-24 10:54:36.393894
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    
    schema_object={
        "type": "number",
        "minimum": -10,
        "maximum": 10,
        "exclusiveMinimum": True,
        "exclusiveMaximum": True,
        "multipleOf": 2,
    }
    field=from_json_schema_type(schema_object,"number", False,None)
    assert type(field) == Float
    assert field.min_value == -10
    assert field.max_value == 10
    assert field.exclusive_min == True
    assert field.exclusive_max == True
    assert field.multiple_of == 2

    schema_object={
        "type": "integer",
        "minimum": -10,
        "maximum": 10,
        "exclusiveMinimum": True,
        "exclusiveMaximum": True,
        "multipleOf": 2,
    }
   

# Generated at 2022-06-24 10:54:45.016623
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    """
    This is a test to ensure that the enum_from_json_schema function works as expected
    """
    enum_data = {
        "$ref": None,
        "type": "string",
        "enum": [
            "red",
            "amber",
            "green",
            "blue",
            "white",
            "black",
            "grey",
            "silver",
            "gold",
            "pink",
            "yellow",
            "purple",
        ],
    }

    enum_data_field = from_json_schema(enum_data)

    reference_string = enum_data["$ref"]
    assert reference_string is None

    type_string = enum_data["type"]
    assert type_string == "string"

    choices = enum_data["enum"]
    assert choices

# Generated at 2022-06-24 10:54:53.709770
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test case 1
    schema_object = {"$ref": "#/definitions/m_type"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/m_type"] = Any()
    field = not_from_json_schema(schema_object, definitions=definitions)
    assert field.default == NO_DEFAULT
    assert field.negated.__class__.__name__ == "Reference"
    assert field.default == NO_DEFAULT
    assert field(None) == True

    # Test case 2
    schema_object = {
        "const": None,
        "boolean_schema": False,
        "type": "boolean",
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(schema_object, definitions=definitions)
   

# Generated at 2022-06-24 10:54:59.724755
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "number",
                "minimum": 1,
                "maximum": 10,
            },
            {
                "type": "number",
                "minimum": 5,
            },
        ],
    }
    from_json_schema(data).validate(5)
    with pytest.raises(typesystem.FieldError):
        from_json_schema(data).validate(10)



# Generated at 2022-06-24 10:55:05.135374
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "string"}}
    definitions = SchemaDefinitions()
    result = not_from_json_schema(data, definitions)
    assert result.negated == String()



# Generated at 2022-06-24 10:55:11.425964
# Unit test for function get_standard_properties
def test_get_standard_properties():
    a_field = String()
    assert get_standard_properties(a_field) == {}
    a_field = String(default="Hello")
    assert get_standard_properties(a_field) == {"default": "Hello"}


_TO_JSON_SCHEMA_CACHE: typing.Dict[
    typing.Tuple[typing.Union[Field, typing.Type[Schema]], typing.Optional[dict]],
    typing.Dict[str, typing.Union[bool, dict]],
] = {}



# Generated at 2022-06-24 10:55:17.849139
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"if": {"type": "integer"}, "then": {"maximum": 5}}
    field = from_json_schema(data)
    assert field.validate(5)
    assert not field.validate(6)

    data = {"if": {"type": "integer"}, "then": {"maximum": 5}, "else": {"type": "string"}}
    field = from_json_schema(data)
    assert field.validate(5)
    assert not field.validate("hello")
    assert field.validate("world")

    data = {"if": {"type": "integer"}, "then": {"maximum": 5}, "else": {"const": "hello"}}
    field = from_json_schema(data)
    assert field.validate(5)
    assert not field.validate("world")

# Generated at 2022-06-24 10:55:29.286426
# Unit test for function to_json_schema
def test_to_json_schema():
    from .test_schema import StringField, StringSchema

    schema = StringSchema(max_length=500)
    expected = {
        "type": "string",
        "maxLength": 500,
        "default": None
    }
    assert to_json_schema(schema) == expected

    schema = StringSchema(max_length=500, default="Some string!")
    expected = {
        "type": "string",
        "maxLength": 500,
        "default": "Some string!"
    }
    assert to_json_schema(schema) == expected

    schema = StringSchema(max_length=500, default=NO_DEFAULT)
    expected = {
        "type": "string",
        "maxLength": 500
    }

# Generated at 2022-06-24 10:55:39.446045
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "test",
        "type": "number",
        "default": 12,
        "minimum": 10,
        "maximum": 20,
        "exclusive_minimum": 11,
        "exclusive_maximum": 21,
        "multiple_of": 10,
    }) == Float(
        default=12,
        minimum=10,
        maximum=20,
        exclusive_minimum=11,
        exclusive_maximum=21,
        multiple_of=10
    )



# Generated at 2022-06-24 10:55:48.641103
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Int()
    schema_dict = to_json_schema(schema)
    assert isinstance(schema_dict, dict)
    assert schema_dict == {
        "type": "integer",
    }

    schema = Int(default=42)
    schema_dict = to_json_schema(schema)
    assert isinstance(schema_dict, dict)
    assert schema_dict == {
        "type": "integer",
        "default": 42,
    }

    schema = OneOf(
        (
            Int(),
            Float(),
        )
    )
    schema_dict = to_json_schema(schema)
    assert isinstance(schema_dict, dict)

# Generated at 2022-06-24 10:55:59.042983
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-24 10:56:08.980810
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    f = from_json_schema_type({}, type_string="number", allow_null=True, definitions=None)
    assert isinstance(f, Float)
    assert f.allow_null == True
    assert f.allow_nan == True
    assert f.allow_infinity == True
    assert f.minimum == None
    assert f.maximum == None
    assert f.exclusive_minimum == None
    assert f.exclusive_maximum == None
    assert f.multiple_of == None

    f = from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None)
    assert isinstance(f, Integer)
    assert f.allow_null == False
    assert f.minimum == None
    assert f.maximum == None
    assert f.exclusive_minimum == None
    assert f.exclusive_

# Generated at 2022-06-24 10:56:18.769303
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"const": "a"},
        "then": {"const": "b"},
        "else": {"const": "c"},
        "default": "x",
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert type(field) is IfThenElse
    assert field({"const": "a"}) == "b"
    assert field({"const": "x"}) == "c"

    # Test that the function doesn't validate the JSON schema itself.
    data = {
        "if": {"const": "a"},
        "then": {"const": "b"},
        "else": {"const": "c"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)

# Generated at 2022-06-24 10:56:26.775291
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "number",
            "minimum": 10,
            "maximum": 100
        },
        "then": {
            "type": "integer"
        },
        "else": {
            "type": "string"
        }
    }
    actual = if_then_else_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(actual, IfThenElse), "it should be IfThenElse"

# Generated at 2022-06-24 10:56:38.355691
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': 'string'}) != ({'string'}, True)
    assert get_valid_types({'type': 'null'}) == ({'null'}, True)
    assert get_valid_types({'type': ['string']}) == ({'string'}, False)
    assert get_valid_types({'type': ['number', 'string']}) == ({'number', 'string'}, False)
    assert get_valid_types({'type': ['number', 'string', 'null']}) == ({'number', 'string'}, True)

# Generated at 2022-06-24 10:56:44.830641
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(
        if_then_else_from_json_schema(
            {
                "if": {"type": {"type": "string", "const": "integer"}},
                "then": {"type": "integer"},
                "else": {"type": "string"},
            },
            None,
        ),
        IfThenElse,
    )

definitions["JSONSchema"] = JSONSchema

# Generated at 2022-06-24 10:56:48.017857
# Unit test for function to_json_schema
def test_to_json_schema():
    data: typing.Dict[str, typing.Any] = to_json_schema(
        Any(
            additional_properties=Any({}, optional=True),
            default=None,
            allow_null=True,
        )
    )
    assert data == {
        "type": ["object", "null"],
        "properties": {},
        "additionalProperties": True,
    }



# Generated at 2022-06-24 10:56:52.797041
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Test: const with invalid input
    schema = const_from_json_schema({"const": [1, 2]})
    assert not schema.validate([1, 2])
    # Test: const with valid input
    schema = const_from_json_schema({"const": [1, 2]})
    assert schema.validate([1, 2])


# Generated at 2022-06-24 10:56:59.789749
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data: dict = {'anyOf': [{'$ref': '#/definitions/opening_hour'}, {'maxLength': 5}], 'title': 'Opening Hours', 'description': 'A textual description of the business hours.', 'type': 'string', 'minLength': 1, 'maxLength': 5}
    definitions: SchemaDefinitions = {}
    definitions['#/definitions/opening_hour'] = {}
    definitions['#/definitions/opening_hour']['title'] = 'Opening Hour'
    definitions['#/definitions/opening_hour']['description'] = 'An opening hour value in RFC3339 format.'
    definitions['#/definitions/opening_hour']['type'] = 'string'
    definitions['#/definitions/opening_hour']['format'] = 'time'

# Generated at 2022-06-24 10:57:03.739750
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {"allOf": [{"type": "string"}, {"maxLength": 5}, {"enum": ["hello", "hi"]}]}
    assert all_of_from_json_schema(schema).validate("hello")



# Generated at 2022-06-24 10:57:10.936211
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/Person",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/Person"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)
    assert ref_from_json_schema(data, definitions=definitions).to == "#/definitions/Person"
    # Unsupported $ref style in document
    data = {"$ref": "http://www.example.com/Person"}
    from typesystem.exceptions import ValidationError
    try:
        ref_from_json_schema(data, definitions=definitions)
    except ValidationError:
        pass
    else:
        assert False, "Should not allow unsupported $ref styles."  # pragma: no cover



# Generated at 2022-06-24 10:57:18.305615
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Setup
    class FieldWithDefault(Field):
        def has_default(self):
            return True
        def get_default(self):
            pass
        def __init__(self, default: int = 3) -> None:
            self.default = default
            super().__init__()
    field = FieldWithDefault()
    # Exercise
    result = get_standard_properties(field)
    # Verify
    assert result == {"default": 3}
    # Cleanup - none necessary



# Generated at 2022-06-24 10:57:26.841908
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type(data={"type": "object"}, type_string="object", allow_null=True, definitions=None), Object
    )
    assert isinstance(
        from_json_schema_type(data={"type": "object"}, type_string="object", allow_null=False, definitions=None), Object
    )
    assert isinstance(
        from_json_schema_type(data={"type": "null"}, type_string="object", allow_null=True, definitions=None), Const
    )
    assert isinstance(
        from_json_schema_type(data={"type": "null"}, type_string="object", allow_null=False, definitions=None), NeverMatch
    )



# Generated at 2022-06-24 10:57:30.734987
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"const": 5}}
    definitions = SchemaDefinitions()
    result = not_from_json_schema(data, definitions)
    expected = Not(negated=Const(const=5))
    assert result == expected



# Generated at 2022-06-24 10:57:38.904674
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'string', 'object', 'null', 'integer', 'number', 'array'}, False)
    assert get_valid_types({"type": "null"}) ==  ({}, True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["object", "string"]}) == ({"string", "object"}, False)
    assert get_valid_types({"type": "boolean"})

# Generated at 2022-06-24 10:57:39.592950
# Unit test for function from_json_schema
def test_from_json_schema():
    pass



# Generated at 2022-06-24 10:57:51.409534
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": ["string", "boolean"],
        "minLength": 3,
        "maxLength": 10,
    }
    field = type_from_json_schema(schema, definitions={})

    assert isinstance(field, Choice)
    assert len(field.any_of) == 2
    assert isinstance(field.any_of[0], String)
    assert field.any_of[0].min_length == 3
    assert field.any_of[0].max_length == 10
    assert isinstance(field.any_of[1], Boolean)

    schema = {"type": "string", "enum": ["foo", "bar"]}
    field = type_from_json_schema(schema, definitions={})
    assert isinstance(field, Choice)

# Generated at 2022-06-24 10:57:58.931365
# Unit test for function get_valid_types
def test_get_valid_types():
    test_cases = [
        {
            "data": {"type": "number"},
            "expected_type_strings": {"number"},
            "expected_allow_null": False,
        },
        {
            "data": {"type": ["number", "integer"]},
            "expected_type_strings": {"integer", "number"},
            "expected_allow_null": False,
        },
        {
            "data": {},
            "expected_type_strings": {"array", "boolean", "integer", "null", "number", "object", "string"},
            "expected_allow_null": False,
        },
    ]

    for test_case in test_cases:
        result = get_valid_types(test_case["data"])

# Generated at 2022-06-24 10:58:10.683158
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number", False, None), Float)
    assert isinstance(from_json_schema_type({}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({}, "string", False, None), String)
    assert isinstance(from_json_schema_type({}, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False, None), Array)
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)
    assert isinstance(from_json_schema_type({}, "null", True, None), Const)



# Generated at 2022-06-24 10:58:18.830101
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Basic JSON Schema object
    data = {
            "$schema": "http://json-schema.org/draft-04/schema#",
            "title": "Product set",
            "type": "object",
            "properties": {
                "title": {"type": "string"},
                "type": {"type": "string"},
                "properties": {"$ref": "#/definitions/product"},
            },}
    # Create SchemaDefinitions object
    definitions = SchemaDefinitions()
    # Build field
    field = one_of_from_json_schema(data, definitions)
    # Check values
    assert isinstance(field, OneOf)
    assert field.one_of is not None
    assert field.default == NO_DEFAULT

    # Basic JSON Schema object with null

# Generated at 2022-06-24 10:58:27.087727
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 3,
                "enum": ["a", "b"],
            },
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 3,
                "enum": ["a", "b"],
            },
        ]
    }
    definitions = SchemaDefinitions()
    choices = all_of_from_json_schema(data, definitions)
    assert choices.validate("a") == "a"
    assert choices.validate("b") == "b"
    assert choices.validate("aa") == "aa"
    assert choices.validate("bb") == "bb"
    assert choices.validate("aaaa") == "aaaa"
   

# Generated at 2022-06-24 10:58:31.674095
# Unit test for function get_valid_types
def test_get_valid_types():
    test_json = {
        "type": "integer"
    }
    type_strings, allow_null = get_valid_types(test_json)
  
    assert not allow_null
    assert type_strings == set(['integer'])

    test_json = {
        "type": ["integer", "string"]
    }
    type_strings, allow_null = get_valid_types(test_json)
    assert not allow_null
    assert type_strings == set(['integer', 'string'])

    test_json = {
        "type": "null"
    }
    type_strings, allow_null = get_valid_types(test_json)
    assert allow_null
    assert type_strings == set()

    test_json = {
        "type": ["null", "string"]
    }
   

# Generated at 2022-06-24 10:58:35.638039
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from_json_schema(
        schema={
            "type": "object",
            "definitions": {
                "Person": {
                    "type": "object",
                    "properties": {"age": {"type": "number"}}
                },
                "Family": {
                    "type": "object",
                    "properties": {"father": {"$ref": "#/definitions/Person"}}
                }
            },
            "properties": {"name": {"type": "number"}, "parent": {"$ref": "#/definitions/Family"}}
        },
        definitions=SchemaDefinitions()
    )



# Generated at 2022-06-24 10:58:40.855107
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {"$ref": "#/definitions/my-schema"}
    definitions = SchemaDefinitions()
    definitions['#/definitions/my-schema'] = Integer(minimum=0)
    field = ref_from_json_schema(schema, definitions=definitions)
    assert field.is_validate({0})
    assert not field.is_validate({1})


# Generated at 2022-06-24 10:58:50.771956
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.exceptions import TypesystemValidationError

    field = type_from_json_schema(data={"type": "string"}, definitions=None)
    assert field.validate("test") == "test"
    with pytest.raises(TypesystemValidationError):
        field.validate(1)

    field = type_from_json_schema(data={"type": "string", "nullable": True}, definitions=None)
    assert field.validate(None) is None
    assert field.validate("test") == "test"
    with pytest.raises(TypesystemValidationError):
        field.validate(1)

    field = type_from_json_schema(data={"nullable": True}, definitions=None)
    assert field.validate(None) is None

# Generated at 2022-06-24 10:59:02.152918
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()), Const)
    assert isinstance(type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()), String)
    assert isinstance(type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()), Boolean)
    assert isinstance(type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()), Number)
    assert isinstance(type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()), Integer)
    assert isinstance(type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()), Object)

# Generated at 2022-06-24 10:59:08.961387
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    a = const_from_json_schema({"const": 0}, SchemaDefinitions())
    assert a.validate(0) == 0
    assert a.validate(1) == "Value must be 0."
    assert a.validate(None) == "Value must be 0."
    b = const_from_json_schema({"const": "hello"}, SchemaDefinitions())
    assert b.validate("hello") == "hello"
    assert b.validate("HELLO") == "Value must be hello."
    assert b.validate(None) == "Value must be hello."
test_const_from_json_schema()



# Generated at 2022-06-24 10:59:18.642620
# Unit test for function type_from_json_schema