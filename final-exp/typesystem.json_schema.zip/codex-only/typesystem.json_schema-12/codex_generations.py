

# Generated at 2022-06-24 10:49:21.905096
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Unit test for function type_from_json_schema
    """

# Generated at 2022-06-24 10:49:29.397284
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    definitions = SchemaDefinitions()
    for type_string, allow_null in [
        ("number", False),
        ("integer", False),
        ("string", False),
        ("boolean", False),
        ("array", False),
        ("object", False),
        ("number", True),
        ("integer", True),
        ("string", True),
        ("boolean", True),
        ("array", True),
        ("object", True),
    ]:
        field = from_json_schema_type(
            {"type": type_string}, type_string=type_string, allow_null=allow_null, definitions=definitions
        )
        assert isinstance(field, Field)



# Generated at 2022-06-24 10:49:31.396973
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/defn"}).to == "#/definitions/defn"



# Generated at 2022-06-24 10:49:34.526786
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/TestType"] = String(max_length=10)
    assert ref_from_json_schema({"$ref": "#/definitions/TestType"}, definitions=definitions).to_json_schema() == {
        "$ref": "#/definitions/TestType"
    }



# Generated at 2022-06-24 10:49:39.216626
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(IfThenElse, type(if_then_else_from_json_schema))



# Generated at 2022-06-24 10:49:51.427579
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": ["string"]}) == String()
    assert type_from_json_schema({"type": ["string", "null"]}) == String(allow_null=True)
    assert type_from_json_schema({"type": ["string", "integer"]}) == String() | Integer()
    assert type_from_json_schema({"type": ["string", "integer"], "nullable": True}) == String() | Integer(allow_null=True)
    assert type_from_json_schema({"type": ["string", "null"], "nullable": True}) == String(allow_null=True)


# Generated at 2022-06-24 10:49:56.104151
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "definitions": {
            "FooTypeEnum": {
                "type": "string",
                "enum": ["foo", "bar"],
            }
        },
        "allOf": [
            {"$ref": "#/definitions/FooTypeEnum"},
        ],
    }
    field = from_json_schema(schema)
    assert field.validate("foo") == "foo"



# Generated at 2022-06-24 10:50:01.603026
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert isinstance(type_from_json_schema({}, definitions=SchemaDefinitions()), Any)
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert isinstance(
        type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()), Integer
    )
    assert type_from_json_schema(
        {"type": "integer"}, definitions=SchemaDefinitions()).minimum == None
    assert type_from_json_schema(
        {"type": "integer", "minimum": 4}, definitions=SchemaDefinitions()
    ).minimum == 4

# Generated at 2022-06-24 10:50:04.101232
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="abc")) == {"default": "abc"}
    assert get_standard_properties(String()) == {}

# Generated at 2022-06-24 10:50:14.037461
# Unit test for function get_valid_types
def test_get_valid_types():
    assert set(get_valid_types({})[0]) == {
        "null",
        "boolean",
        "object",
        "array",
        "number",
        "string",
    }
    assert get_valid_types({})[1] is True
    assert (
        set(get_valid_types({ "type": "number" })[0]) == {"number"}
    )
    assert (
        set(get_valid_types({ "type": ["number", "integer"] })[0]) == {"number"}
    )
    assert (
        set(get_valid_types({ "type": ["null", "number", "integer"] })[0]) == {"number"}
    )

# Generated at 2022-06-24 10:50:25.660751
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # If
    if_schema = {
        "if": {"const": True},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }

    assert_equal(if_then_else_from_json_schema(if_schema), String())

    assert_equal(if_then_else_from_json_schema(if_schema, allow_null=True), Union(String(), Const(None)))

    assert_equal(if_then_else_from_json_schema(if_schema, allow_blank=True), Union(String(), Const('')))

    assert_equal(if_then_else_from_json_schema(if_schema, allow_blank=True, allow_null=True), Union(String(), Const(None), Const('')))


# Generated at 2022-06-24 10:50:29.229880
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": []}, SchemaDefinitions()).serialize() == ""
    assert all_of_from_json_schema({"allOf": [{}]}, SchemaDefinitions()).serialize() == "::"
    assert all_of_from_json_schema({"allOf": [{"type": "null"}]}, SchemaDefinitions()).serialize() == ":Null:"



# Generated at 2022-06-24 10:50:37.052756
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/a"}).to == "#/a"
    assert ref_from_json_schema({"$ref": "#/definitions/b"}).to == "#/definitions/b"
    assert ref_from_json_schema({"$ref": "#/c/d"}).to == "#/c/d"
    assert ref_from_json_schema({"$ref": "#/definitions/e/f"}).to == "#/definitions/e/f"



# Generated at 2022-06-24 10:50:44.843030
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "$id": "http://example.com/example.json",
        "type": "object",
        "definitions": {},
        "$schema": "http://json-schema.org/draft-07/schema#",
        "properties": {
            "one": {
                "oneOf": [{"type": "number", "enum": [1]}, {"type": "number", "enum": [2]}]
            }
        },
    }
    schema = Schema({"one": OneOf(one_of=[Integer(const=1), Integer(const=2)])})
    assert from_json_schema(data) == schema



# Generated at 2022-06-24 10:50:49.984347
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"const": "this is a test issue"}, {"type": "integer"}]}
    all_of = from_json_schema(data)
    assert all_of == AllOf(all_of=[Const(const="this is a test issue"), Integer()])



# Generated at 2022-06-24 10:50:55.643865
# Unit test for function to_json_schema
def test_to_json_schema():
    from asyncapi.fields import String, Integer, Float, Decimal, Boolean
    from asyncapi.fields import Array, Object, Choice
    from asyncapi.fields import Const, Union, OneOf, AllOf, Not, IfThenElse
    from asyncapi.fields import Any, NeverMatch

    assert to_json_schema(Any) is True
    assert to_json_schema(NeverMatch) is False
    assert to_json_schema(String(min_length=3, max_length=5, allow_null=True)) == {
        "type": ["string", "null"],
        "minLength": 3,
        "maxLength": 5,
    }

# Generated at 2022-06-24 10:50:59.362282
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'const': {'x':42, 'y':43}, 'not': {'const': {'x':44, 'y':45}}}
    f = from_json_schema(schema)
    assert f.is_valid(44)
    assert not f.is_valid(42)
    assert not f.is_valid(43)
    assert not f.is_valid(45)
    assert not f.is_valid({'x':42, 'y':45})



# Generated at 2022-06-24 10:51:04.472623
# Unit test for function to_json_schema
def test_to_json_schema():
    class ArraySchema(Schema):
        items: typing.List[int]

    data = to_json_schema(ArraySchema)
    assert data == {
        "type": "object",
        "properties": {"items": {"type": "array", "items": {"type": "integer"}}},
        "required": ["items"],
    }

    class ObjectSchema(Schema):
        properties: typing.List[int]

    data = to_json_schema(ObjectSchema)
    assert data == {
        "type": "object",
        "properties": {"properties": {"type": "array", "items": {"type": "integer"}}},
        "required": ["properties"],
    }

    class PatternPropertiesSchema(Schema):
        regexes: typing.Dict[str, typing.Pattern]

   

# Generated at 2022-06-24 10:51:11.866194
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    This tests that all valid JSON types are supported by
    ``typesystem.from_json_schema_type(type_string)``.
    """
    # This test may seem redundant, but it ensures that we have tested all
    # possible arguments to ``from_json_schema_type()``.
    for type_string in ("array", "boolean", "integer", "number", "null", "object", "string"):
        # noqa
        # type_string=type_string
        from_json_schema_type({}, type_string, False, SchemaDefinitions())



# Generated at 2022-06-24 10:51:17.293306
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/StringOrNull"] = String() | Const(None)

    field = ref_from_json_schema({"$ref": "#/definitions/StringOrNull"}, definitions=definitions)
    assert field.validate(None) is None
    assert field.validate("abc") == "abc"
    assert field.validate(b"abc".decode("utf-8")) == "abc"
    assert field.validate(1) == "1"  # string conversion
    assert field.validate(True) == "True"  # string conversion



# Generated at 2022-06-24 10:51:19.802643
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Unit test for function from_json_schema
    """
    from_json_schema({})



# Generated at 2022-06-24 10:51:27.935073
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Test creation of a typesystem field based on type definitions in a JSON schema object.
    """
    schema = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "^[A-Z]{2,}$",
    }
    data = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "^[A-Z]{2,}$",
    }
    field = from_json_schema(data)
    assert field == String(min_length=1, max_length=10, pattern=re.compile("^[A-Z]{2,}$"))
    assert field.validate(data) is None

# Generated at 2022-06-24 10:51:33.616693
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    input = {"type": "string", "const": "red"}
    expected = String(optional=False, const='red')
    assert const_from_json_schema(input, definitions={}) == expected



# Generated at 2022-06-24 10:51:40.538000
# Unit test for function to_json_schema
def test_to_json_schema():
    from validator import Schema, Required, Optional, In, Regex, Match, Length, Range

    class StoreSchema(Schema):
        """
        A store has a name, a list of items, and a flag to indicate it is open.
        """

        name = Required(str)
        items = Required([str], min_items=1)
        open = Required(bool)

    assert to_json_schema(StoreSchema) == {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "name": {"type": "string"},
            "items": {"type": "array", "items": {"type": "string"}, "minItems": 1},
            "open": {"type": "boolean"},
        },
        "required": ["name", "items", "open"],
    }

# Generated at 2022-06-24 10:51:50.715217
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any(allow_null=False)) == {"type": "any"}
    assert to_json_schema(Any(allow_null=True)) == {"type": ["any", "null"]}
    assert to_json_schema(NeverMatch(allow_null=False)) == False
    assert to_json_schema(NeverMatch(allow_null=True)) == {"type": ["never", "null"]}
    assert to_json_schema(String(allow_null=False)) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer(allow_null=False)) == {"type": "integer"}

# Generated at 2022-06-24 10:51:58.533808
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": {
            "x": {
                "const": "x",
            }
        },
        "allOf": [
            {"$ref": "#/definitions/x"},
        ]
    }
    assert AllOf(all_of=[Const(const='x')]) == from_json_schema(schema)
    assert Const(const='x') == from_json_schema(schema)
    # assert Const(const='x') == json_schema_to_typesystem(Const(const='x'))



# Generated at 2022-06-24 10:52:04.724009
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field = one_of_from_json_schema({'oneOf':[{'type':'string', 'const':'one'}, {'type':'string', 'const':'two'}]}, SchemaDefinitions())
    assert field.validate('one') == None
    assert field.validate('two') == None
    assert field.validate('three') == 'Must be one of ["one", "two"].'
    assert field.validate(None) == 'Must be one of ["one", "two"].'
    assert field.validate(['one', 'two']) == 'Must be one of ["one", "two"].'



# Generated at 2022-06-24 10:52:13.309062
# Unit test for function to_json_schema
def test_to_json_schema():
    class Author(Schema):
        first_name = String()
        middle_initial = String(required=False)
        last_name = String()

    class Book(Schema):
        title = String()
        genre = Choice(choices=(("action", "Action"), ("scifi", "Science Fiction")))
        cover = Choice(choices=(("soft", "Soft"), ("hard", "Hard")), allow_null=True)
        authors = Array(items=Author())
        pages = Integer(minimum=1, maximum=999)
        published = Decimal(
            minimum=datetime.datetime(1900, 1, 1), maximum=datetime.datetime.now()
        )
        price = Decimal(minimum=0)
        suggested_age = Integer(minimum=0, maximum=100)

    # The round-trip test
    data

# Generated at 2022-06-24 10:52:17.327425
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from typesystem.fields import Array
    from typesystem.types import String
    from json import loads
    from . import FIXTURE_PATH

    data = loads(open(FIXTURE_PATH/'allOf.json').read())
    assert all_of_from_json_schema(data, None) == Array(items=String(min_length=1))



# Generated at 2022-06-24 10:52:24.698707
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    import sys
    import os


    path = os.path.join(os.path.dirname(__file__), "json-schema-test-suite")
    assert os.path.isdir(path)


    class JSONSerializer(json.JSONEncoder):


        def default(self, o):
            if isinstance(o, set):
                return sorted(o)
            elif isinstance(o, (re.Pattern, re.Match)):
                return {"pattern": o.pattern, "flags": o.flags}
            if sys.version_info[0] < 3:
                # py2
                if isinstance(o, typing.Union):
                    return [x.__name__ for x in o.__args__]

# Generated at 2022-06-24 10:52:30.230304
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from jsonsubschema import from_json_schema
    assert validate_json_schema(from_json_schema({
        'not': {
            'type': 'string',
            'pattern': '\\d{3}-\\d{3}-\\d{4}'
        }
    }), '123-456-7890')
    assert not validate_json_schema(from_json_schema({
        'not': {
            'type': 'string',
            'pattern': '\\d{3}-\\d{3}-\\d{4}'
        }
    }), '111-222-3333')


# Generated at 2022-06-24 10:52:34.433446
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field = enum_from_json_schema({"enum": ["foo", "bar"]}, None)
    assert field.validate_choice("foo") is None
    assert field.validate_choice("bar") is None
    assert field.serialize_choice("foo") == "foo"
    assert field.serialize_choice("bar") == "bar"



# Generated at 2022-06-24 10:52:40.508626
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
            "is_retired": {"type": "boolean"},
            "age": {"type": "integer"},
            "pets": {"type": "array", "items": {"type": "string"}},
            "previous_last_names": {"type": "array", "items": {"type": "string"}},
            "meta": {"type": "object", "properties": {"name": {"type": "string"}}},
        },
        "required": ["first_name", "last_name"],
    }
    field = from_json_schema(data)

# Generated at 2022-06-24 10:52:47.584695
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = any_of_from_json_schema({'anyOf':[{'$ref': '#/definitions/a'},{'$ref': '#/definitions/b'}]},SchemaDefinitions())
    assert field.any_of[0].to == '#/definitions/a' and field.any_of[1].to == '#/definitions/b'

# Generated at 2022-06-24 10:52:58.409685
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field = from_json_schema_type({}, "boolean", False)
    assert isinstance(field, Boolean)

    field = from_json_schema_type({}, "integer", False)
    assert isinstance(field, Integer)

    field = from_json_schema_type({}, "null", True)
    assert isinstance(field, Const)
    assert field.default == None

    field = from_json_schema_type({}, "number", False)
    assert isinstance(field, Number)

    field = from_json_schema_type({}, "string", False)
    assert isinstance(field, String)

    field = from_json_schema_type({}, "array", False)
    assert isinstance(field, Array)


# Generated at 2022-06-24 10:53:10.149931
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # pylint: disable=line-too-long
    schema = {
        "$id": "http://example.com/root.json",
        "definitions": {
            "test": {
                "$id": "http://example.com/test.json",
                "type": "string"
            }
        },
        "$ref": "#/definitions/test"
    }
    definitions = SchemaDefinitions()
    string_field = from_json_schema(schema, definitions)
    assert definitions == {
        "http://example.com/test.json": String(),
        "http://example.com/root.json": String(),
    }

# Generated at 2022-06-24 10:53:17.422384
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    def assert_constraints(schema, constraints):
        field = from_json_schema(schema)
        for constraint in constraints:
            assert constraint(field)
        assert len(constraints) == len(field.constraints)

    schema = {
        "allOf": [
            {"type": "integer", "maximum": 10},
            {"type": "integer", "minimum": 0},
        ]
    }

# Generated at 2022-06-24 10:53:21.680928
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf":[{"type":"string","minLength":1}]}
    return_value = one_of_from_json_schema(data)
    expected_value = OneOf(one_of=[String(min_length=1)])
    assert return_value == expected_value, "Error: The values are not equal"
    data = {"oneOf":[{"type":"float","minimum":1}]}
    return_value = one_of_from_json_schema(data)
    expected_value = OneOf(one_of=[Float(minimum=1)])
    assert return_value == expected_value, "Error: The values are not equal"
    data = {"oneOf":[{"const":"one"},{"const":"two"},{"const":"three"}]}
    return_value = one_of_from_json_schema(data)
    expected_value

# Generated at 2022-06-24 10:53:31.512307
# Unit test for function get_valid_types
def test_get_valid_types():
    schema = {
        "properties": {"room": {"type": "string"}}
    }
    assert get_valid_types(schema["properties"]["room"]) == ({'string'}, False)
    schema = {
        "properties": {"room": {"type": ["string", "null"]}}
    }
    assert get_valid_types(schema["properties"]["room"]) == ({'string'}, True)
    schema = {
        "properties": {"room": {"type": ["null", "string"]}}
    }
    assert get_valid_types(schema["properties"]["room"]) == ({'string'}, True)
    schema = {
        "properties": {"room": {"type": ["null"]}}
    }

# Generated at 2022-06-24 10:53:42.771637
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # We do not test the default case because we never expect to encounter it.
    import json
    test_data = [
        ('{"oneOf": [{"const": 1}, {"const": 2}]}', 1, True),
        ('{"oneOf": [{"const": 1}, {"const": 2}]}', 2, True),
        ('{"oneOf": [{"const": 1}, {"const": 2}]}', 3, False),
        ('{"oneOf": [{"const": 1}, {"const": null}]}', 1, True),
        ('{"oneOf": [{"const": 1}, {"const": null}]}', None, True),
        ('{"oneOf": [{"const": 1}, {"const": null}]}', 3, False),
    ]
    for json_string, value, expected_valid in test_data:
        data = json.loads

# Generated at 2022-06-24 10:53:53.906855
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type: () -> None

    # Test all possible strings.
    for type_string in {
        "null",
        "boolean",
        "object",
        "array",
        "number",
        "integer",
        "string",
    }:
        from_json_schema_type({}, type_string=type_string, allow_null=False, definitions={})

    # Test null.
    assert isinstance(
        from_json_schema_type({}, type_string="null", allow_null=False, definitions={}),
        Const,
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="null", allow_null=True, definitions={}
        ),
        Const,
    )

    # Test boolean.

# Generated at 2022-06-24 10:54:00.253900
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_schema = {"oneOf": [{"type": "integer"}]}

    base = from_json_schema(json_schema)
    assert isinstance(base, OneOf)
    assert isinstance(base.one_of[0], Integer)

    json_schema = {"oneOf": [{"type": "number"}, {"type": "integer"}]}

    base = from_json_schema(json_schema)
    assert isinstance(base, OneOf)
    assert isinstance(base.one_of[0], Float)
    assert isinstance(base.one_of[1], Integer)


# Generated at 2022-06-24 10:54:07.001679
# Unit test for function to_json_schema
def test_to_json_schema():
    file_path = os.path.join(os.path.dirname(__file__), "testdata", "test_schema.json")
    with open(file_path, "r") as file:
        test_schema_data = json.load(file)
    test_schema = from_json_schema(test_schema_data)
    schema_json = to_json_schema(test_schema)
    assert schema_json == test_schema_data
    json.dumps(schema_json)

# Generated at 2022-06-24 10:54:11.512612
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"$ref": "#/definitions/foo"},
            {"$ref": "#/definitions/bar"},
        ]
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Object(properties={})
    definitions["#/definitions/bar"] = Object(properties={})
    result = all_of_from_json_schema(data, definitions=definitions)
    assert isinstance(result, AllOf)
    assert len(result.all_of) == 2
    assert isinstance(result.all_of[0], Reference)
    assert isinstance(result.all_of[1], Reference)



# Generated at 2022-06-24 10:54:18.800623
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/MyDefinition"
    }
    definitions = {
        "#/definitions/MyDefinition": String()
    }
    field = ref_from_json_schema(data, definitions)
    assert field.reference_to == "#/definitions/MyDefinition"
    assert field.validate("abc") == True
    assert field.validate(1) == False
    assert field.validate(None) == False



# Generated at 2022-06-24 10:54:30.016130
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:54:33.142127
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [1,2]}
    definitions = SchemaDefinitions()
    assert Any() == any_of_from_json_schema(data, definitions)



# Generated at 2022-06-24 10:54:42.542521
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    input_data = {
        "allOf": [
            {"$ref": "#/definitions/Type1"},
            {"$ref": "#/definitions/Type2"},
        ],
        "description": "description",
        "default": 1,
    }
    field = all_of_from_json_schema(input_data, {})
    assert field.default == 1
    assert field.description == "description"
    assert field.all_of[0].to == "#/definitions/Type1"
    assert field.all_of[1].to == "#/definitions/Type2"

# Generated at 2022-06-24 10:54:53.125853
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    assert type_from_json_schema(data, definitions=SchemaDefinitions()) is String()

    data = {"type": ["string", "number"]}
    items = [String(), Number()]
    assert type_from_json_schema(data, definitions=SchemaDefinitions()) == Union(
        items, allow_null=False
    )

    data = {"type": []}
    assert type_from_json_schema(data, definitions=SchemaDefinitions()) is NeverMatch()


# Generated at 2022-06-24 10:54:56.309389
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(Const(const=1, choice_error="test"))
    assert data == {}
    data2 = get_standard_properties(String(default="yasoob"))
    assert data2 == {"default": "yasoob"}
    data3 = get_standard_properties(Integer(default=1))
    assert data3 == {"default": 1}

# Generated at 2022-06-24 10:55:03.582683
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    """
    Tests whether the function converts the right data
    """
    data = {"$schema": "http://json-schema.org/draft-07/schema#", "type": "number", "enum": [
        3.141592653589793, 3, 141592653589793
    ]}

    choice_obj = enum_from_json_schema(
        data, definitions=SchemaDefinitions()
    )

    assert choice_obj.choices == [(3.141592653589793, 3.141592653589793), (3, 3), (141592653589793, 141592653589793)]


# Generated at 2022-06-24 10:55:06.972687
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_schema = {
        "type": "object",
        "not": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "const": "john"
                }
            }
        }
    }
    assert not_from_json_schema(not_schema, None) == Object()

# Generated at 2022-06-24 10:55:11.749299
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    def check(expected, schema):
        assert expected == not_from_json_schema(schema, definitions=None).dump()
    # check(expected, schema)
    check({'const': 'value'}, {'not': {'const': 'value'}, 'default':'value'})
    check({'all_of': [{'const': 'value'}]}, {'not': {'all_of': [{'const': 'value'}]}, 'default':'value'})
    check({'any_of': [{'enum': ['value']}]}, {'not': {'any_of': [{'enum': ['value']}]}, 'default':'value'})

# Generated at 2022-06-24 10:55:20.252531
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    schema = from_json_schema(data={
            "definitions": {
                "integer": {
                    "type": "integer",
                },
            },
        },
        definitions=definitions,
    )
    assert schema == Reference('#/definitions/integer', definitions=definitions)



# Generated at 2022-06-24 10:55:23.407887
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert isinstance(one_of_from_json_schema({"oneOf": [{"type": "string"}]}, SchemaDefinitions()),OneOf)



# Generated at 2022-06-24 10:55:32.893803
# Unit test for function to_json_schema
def test_to_json_schema():
    # Ensure that each type of field is correctly converted to a schema.
    from . import fields

    fields["object"].allow_null = False

    for name, field in fields.items():
        assert to_json_schema(field) == to_json_schema(field.make_validator())

    for name, schema in schema_definitions.items():
        assert to_json_schema(schema) == to_json_schema(schema.make_validator())

    # Ensure that schemas with circular references work (we don't care about the
    # specific output in this case).
    to_json_schema(circular_a)
    to_json_schema(circular_b)
    to_json_schema(circular_c)
    to_json_schema(circular_d)

   

# Generated at 2022-06-24 10:55:37.151907
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "enum": [
            1,
            2.0,
            "a",
            True,
            False,
            None,
        ]
    }
    assert enum_from_json_schema(schema, None)

# Generated at 2022-06-24 10:55:45.370842
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'not': {'type': 'null'}, 'default': None}
    definitions = SchemaDefinitions()
    assert not_from_json_schema(data, definitions=definitions) == Not(negated=type_from_json_schema(data['not'], definitions=definitions))



# Generated at 2022-06-24 10:55:48.878519
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': ['one', 'two', 'three']}) == Choice(choices=[('one', 'one'), ('two', 'two'), ('three', 'three')])



# Generated at 2022-06-24 10:55:57.868232
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer"},
        "then": {"minimum": 10},
        "else": {"minimum": 20},
        "default": 30,
    }
    field = if_then_else_from_json_schema(data, definitions={})
    assert field.if_clause == Integer()
    assert field.then_clause == Integer(minimum=10)
    assert field.else_clause == Integer(minimum=20)
    assert field.default == 30
    with pytest.raises(ValidationError):
        field.validate(0)
    with pytest.raises(ValidationError):
        field.validate(9)
    assert field.validate(10) == 10
    assert field.validate(20) == 20



# Generated at 2022-06-24 10:56:07.895356
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{'type': 'integer'}, {'minimum': 10}]}, None).validate(10)
    assert not all_of_from_json_schema({"allOf": [{'type': 'integer'}, {'minimum': 10}]}, None).validate(9)
    assert not all_of_from_json_schema({"allOf": [{'type': 'integer'}, {'minimum': 10}]}, None).validate('10')
    assert not all_of_from_json_schema({"allOf": [{'type': 'integer'}, {'minimum': 10}]}, None).validate(10.5)

# Generated at 2022-06-24 10:56:16.525804
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="a string")) == {"default": "a string"}
    assert get_standard_properties(String()) == {}


# Unit tests for function to_json_schema

# Generated at 2022-06-24 10:56:21.414307
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema = {
        "type": "string",
        "minLength": 1,
        "maxLength": 3,
        "default": "test",
    }
    assert from_json_schema(json_schema) == String(
        min_length=1, max_length=3, default="test"
    )



# Generated at 2022-06-24 10:56:27.479105
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = all_of_from_json_schema({"allOf": [{"minimum": 1}, {"maximum": 5}]}, definitions)
    assert schema.validate(1) == 1
    assert not schema.validate(0)
    assert schema.validate(2.5) == 2.5
    assert not schema.validate(5.5)


# Generated at 2022-06-24 10:56:35.359003
# Unit test for function to_json_schema
def test_to_json_schema():
    from .fields import Array, Choice, Const, Integer, Not, Object, Reference, String, Union
    from .schema import Schema


# Generated at 2022-06-24 10:56:38.447294
# Unit test for function get_standard_properties
def test_get_standard_properties():
    print("Testing get_standard_properties")
    data = get_standard_properties(String(default="default"))
    assert data == {"default": "default"}

    data = get_standard_properties(String())
    assert data == {}

# Generated at 2022-06-24 10:56:40.458578
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "integer"}}, None).field_class == Not



# Generated at 2022-06-24 10:56:51.487010
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()).get("default", "") == ""
    assert get_standard_properties(String(default="")).get("default", "") == ""
    assert get_standard_properties(String(default="bob")).get("default", "") == "bob"

    assert get_standard_properties(Integer()).get("default", "") == ""
    assert get_standard_properties(Integer(default=1)).get("default", "") == 1
    assert get_standard_properties(Integer(default=1.5)).get("default", "") == 1

    assert get_standard_properties(Float()).get("default", "") == ""
    assert get_standard_properties(Float(default=1)).get("default", "") == 1
    assert get_standard_properties(Float(default=1.5)).get

# Generated at 2022-06-24 10:57:02.022741
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:57:07.053789
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = """{
    "$schema": "http://json-schema.org/draft-07/schema#",
    "$id": "http://example.com/root.json",
    "title": "Root",
    "type": "object",
    "required": [
      "number",
      "float",
      "integer"
    ],
    "properties": {
      "number": {
        "oneOf": [
          {
            "type": "number"
          },
          {
            "type": "integer"
          }
        ]
      },
      "float": {
        "type": "number"
      },
      "integer": {
        "type": "integer"
      }
    }
  }"""
    field = from_json_schema(json.loads(schema))
   

# Generated at 2022-06-24 10:57:15.634044
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(
        if_then_else_from_json_schema(
            data={
                "if": {"type": "integer"},
                "then": {
                    "if": {"type": "integer"},
                    "then": {"type": "integer"},
                    "else": {"type": "string"},
                },
                "else": {"type": "string"},
            },
            definitions=None,
        ),
        IfThenElse,
    )



# Generated at 2022-06-24 10:57:23.374087
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:57:28.472918
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/Pet",
    }
    definitions = SchemaDefinitions()
    definitions["Pet"] = Any()
    field = ref_from_json_schema(schema, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/Pet"
    assert field.definitions == definitions



# Generated at 2022-06-24 10:57:36.531778
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class TestString(String):
        def __init__(self, default=NO_DEFAULT):
            super(TestString, self).__init__(default)

    class TestObject(Object):
        def __init__(self, default=NO_DEFAULT):
            super(TestObject, self).__init__(default)

    class TestObjectChoice(ObjectChoice):
        def __init__(self, default=NO_DEFAULT):
            super(TestObjectChoice, self).__init__(default)

    class TestClass(Field):
        def __init__(self, default=NO_DEFAULT):
            super(TestClass, self).__init__(default)
    field_no_default = TestClass()
    field_default = TestClass(default="test")

    assert get_standard_properties(field_no_default) == {}

# Generated at 2022-06-24 10:57:43.206437
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # string
    assert type_from_json_schema({}, definitions={}) == Any()
    assert type_from_json_schema({"type": "string"}, definitions={}) == String()
    assert (
        type_from_json_schema({"type": "string", "enum": ["a", "b"]}, definitions={})
        == Choice(
            title="Must be one of the following values",
            options=[{"value": "a"}, {"value": "b"}],
        )
    )
    assert (
        type_from_json_schema({"type": "string", "enum": []}, definitions={})
        == NeverMatch()
    )

# Generated at 2022-06-24 10:57:49.796586
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String()
    result = get_standard_properties(field)
    assert result == {}

    expected = {"default": "hello world"}
    field = String(default="hello world")
    result = get_standard_properties(field)
    assert result == expected

    field = String()
    field.__dict__["default"] = "hello world"
    result = get_standard_properties(field)
    assert result == expected


# Generated at 2022-06-24 10:57:51.636846
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema={"const":1}
    const_from_json_schema(schema, definitions=None)



# Generated at 2022-06-24 10:57:55.141384
# Unit test for function get_standard_properties
def test_get_standard_properties():

    # Tests for a Schema
    class MySchema(Schema):
        a = Field(String)
        b = Field(String, default="foo")

    field = MySchema.make_validator()
    assert get_standard_properties(field) == {}

    # Tests for individual Fields
    field = String()
    assert get_standard_properties(field) == {}

    field = String(default="foo")
    assert get_standard_properties(field) == {"default": "foo"}



# Generated at 2022-06-24 10:57:57.276721
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/def1'}, {}), Reference)



# Generated at 2022-06-24 10:58:10.168375
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert str(from_json_schema_type({}, type_string="number", allow_null=False)) == "Float"
    assert str(from_json_schema_type({}, type_string="number", allow_null=True)) == "Float"

    assert str(
        from_json_schema_type({}, type_string="integer", allow_null=False)
    ) == "Integer"
    assert str(
        from_json_schema_type({}, type_string="integer", allow_null=True)
    ) == "Integer"

    assert str(from_json_schema_type({}, type_string="string", allow_null=False)) == "String"
    assert str(from_json_schema_type({}, type_string="string", allow_null=True)) == "String"

    assert str

# Generated at 2022-06-24 10:58:18.604021
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    result = enum_from_json_schema({'enum': [1,2,3], 'default': 3})
    assert result._choices == [(1,1), (2,2), (3,3)]
    assert result.default == 3

    result = enum_from_json_schema({'enum': [1,2,3], 'default': 2})
    assert result._choices == [(1,1), (2,2), (3,3)]
    assert result.default == 2

    result = enum_from_json_schema({'enum': [1,2,3], 'default': 1})
    assert result._choices == [(1,1), (2,2), (3,3)]
    assert result.default == 1


# Generated at 2022-06-24 10:58:25.884363
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {}
    data['$ref'] = "#/definitions/foo"
    assert ref_from_json_schema(data).__class__.__name__ == "Reference"
# END



# Generated at 2022-06-24 10:58:33.553890
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True).boundaries == Any().boundaries
    assert from_json_schema(False).boundaries == NeverMatch().boundaries

    assert from_json_schema({"$ref": "#/definitions/Baz"}).boundaries == {
        "type": "object",
        "properties": {"baz": {"type": "number"}},
    }

    assert from_json_schema({"type": "string"}).boundaries == {"type": "string"}
    assert from_json_schema({"type": "string", "default": "123"}).boundaries == {
        "type": "string",
        "default": "123",
    }

# Generated at 2022-06-24 10:58:36.211984
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'not': {'type': 'string'}}, None) == Not(negated=String(), default=NO_DEFAULT)



# Generated at 2022-06-24 10:58:41.914335
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": ["a", "b", "c"]}
    assert enum_from_json_schema(schema, definitions=None).validate("a")
    assert enum_from_json_schema(schema, definitions=None).validate("b")
    assert enum_from_json_schema(schema, definitions=None).validate("c")
    assert not enum_from_json_schema(schema, definitions=None).validate("d")



# Generated at 2022-06-24 10:58:48.114220
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["foo", "bar"]}).choices == [("foo", "foo"), ("bar", "bar")]
    assert enum_from_json_schema({"enum": ["foo", "bar"], "default": "bar"}).default == "bar"
    assert enum_from_json_schema({"enum": ["foo", "bar"], "default": "baz"}).default == NO_DEFAULT



# Generated at 2022-06-24 10:58:55.503721
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    with open("tests/fixtures/oneof_1.json") as f:
        data = json.load(f)
    definitions = SchemaDefinitions()
    fields = one_of_from_json_schema(data, definitions)
    assert fields.validate({"foo": 4})
    assert fields.validate({"foo": "foo"})
    assert not fields.validate({"foo": {"foo": 5}})
    assert not fields.validate({"foo": 7})
    assert not fields.validate({"foo": "foo", "bar": "bar"})
# End of unit test for function one_of_from_json_schema



# Generated at 2022-06-24 10:59:05.089793
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(
        Schema(
            first=String(),
            second=Array(items=Integer()),
            ref=Reference("third"),
            fourth=Schema(fifth=String()),
        ),
    )

# Generated at 2022-06-24 10:59:10.618787
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "toto"}, None).validate("toto") is True
    assert const_from_json_schema({"const": "toto"}, None).validate("titi") is False
    assert const_from_json_schema({"const": "toto", "default": "tata"}, None).validate("titi") is False
    assert const_from_json_schema({"const": "toto", "default": "tata"}, None).validate("tata") is True
    assert const_from_json_schema({"const": "toto", "default": "tata"}, None).validate("toto") is True



# Generated at 2022-06-24 10:59:19.315547
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "number",
        "minimum": 2,
        "maximum": 10,
        "multipleOf": 2
    }
    actual = from_json_schema_type(data, type_string="number", allow_null=False, definitions=definitions)
    expected = Float(minimum=2, maximum=10, multiple_of=2, allow_null=False)
    assert actual == expected

    data = {
        "type": "integer",
        "minimum": 2,
        "maximum": 10,
        "multipleOf": 2
    }
    actual = from_json_schema_type(data, type_string="integer", allow_null=False, definitions=definitions)
    expected = Integer(minimum=2, maximum=10, multiple_of=2, allow_null=False)
    assert actual