

# Generated at 2022-06-24 10:49:22.519176
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    data = {
        "$ref": "#/definitions/JSONSchema",
        "definitions": {
            "JSONSchema": {
                "type": "boolean",
            },
        },
    }
    schema = from_json_schema(data)
    assert schema == definitions["#/definitions/JSONSchema"]

    data = {"enum": [True]}
    assert from_json_schema(data) == Choice(choices=[True])

    data = {"type": "integer"}
    assert from_json_schema(data) == Integer()

    data = {"type": ["integer"]}
    assert from_json_schema(data) == Integer()


# Generated at 2022-06-24 10:49:24.898290
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const":1}
    definitions = SchemaDefinitions()
    assert const_from_json_schema(data, definitions).const == data['const']

# Generated at 2022-06-24 10:49:27.464436
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_field = not_from_json_schema({"not": {"type": "number"}})
    assert isinstance(not_field, Not)
    assert isinstance(not_field.negated, Float)



# Generated at 2022-06-24 10:49:35.036836
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test the function 'from_json_schema_type'.
    """
    assert isinstance(
        from_json_schema_type({"type": "number"}, "number", True, None), Number
    )
    assert isinstance(
        from_json_schema_type({"type": "integer"}, "integer", True, None), Integer
    )
    assert isinstance(from_json_schema_type({"type": "string"}, "string", True, None), String)
    assert isinstance(from_json_schema_type({"type": "boolean"}, "boolean", True, None), Boolean)
    assert isinstance(from_json_schema_type({"type": "array"}, "array", True, None), Array)

# Generated at 2022-06-24 10:49:45.562329
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "type": "object",
        "properties": {
            "productId": {
                "type": "string",
                "description": "The unique identifier for a product",
                "pattern": "^(?P<part>[A-Z]{3})-(?P<serial>[0-9]{4})$"
            }
        },
        "additionalProperties": False
    } 
    definitions = SchemaDefinitions()
    const_field = const_from_json_schema(const_data, definitions)
    assert(const_field.const == None)

# Generated at 2022-06-24 10:49:51.218239
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def test_if_then_else_from_json_schema_raises(this: dict, exc: Exception):
        try:
            # noinspection PyUnusedLocal
            if_then_else_from_json_schema(this, None)
        except exc.__class__ as e:
            assert str(e) == str(exc)
            return
        assert False

    def test_if_then_else_from_json_schema_value(this: dict, expected: typing.Any):
        result = if_then_else_from_json_schema(this, None)
        assert result == expected

    # The following test is not a valid JSON schema.
    # It only tests the function if_then_else_from_json_schema().
    # pylint: disable=line-too-long
    test

# Generated at 2022-06-24 10:49:57.710620
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type":"null"}) == (set(), True)
    assert get_valid_types({"type":"boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type":"object"}) == ({'object'}, False)
    assert get_valid_types({"type":"array"}) == ({'array'}, False)
    assert get_valid_types({"type":"number"}) == ({'number'}, False)
    assert get_valid_types({"type":"number"}) == ({'number', 'integer'}, False)
    assert get_valid_types({"type":"string", "type":"number"}) == ({'number', 'integer', 'string'}, False)
    assert get_valid_types({"type":"string", "type":"number", "type":"string"})

# Generated at 2022-06-24 10:50:06.979733
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "integer",
        "minimum": 1,
        "maximum": 10,
        "default": 5,
    }
    field = from_json_schema_type(data, type_string=data['type'], allow_null=False, definitions=definitions)
    assert isinstance(field, Integer)
    assert field.minimum == data['minimum']
    assert field.maximum == data['maximum']
    assert field.default == data['default']
    assert field.allow_null == False
    assert field.allow_blank == False


# Generated at 2022-06-24 10:50:20.907740
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:50:31.176610
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Integer(allow_null=False, maximum=3)) == {
        "type": "integer",
        "maximum": 3,
    }
    assert to_json_schema(Boolean(allow_null=False)) == {"type": "boolean"}
    assert to_json_schema(Boolean(allow_null=True)) == {"type": ["boolean", "null"]}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to

# Generated at 2022-06-24 10:50:35.105043
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = Field(name="name")
    const_field = const_from_json_schema(data={"const": 5}, definitions=None)
    const_field.bind("name", field)
    assert const_field.to_primitive() == 5
    const_field.validate(5)
    assert_raises_validation_errors(const_field, {"name": 6})



# Generated at 2022-06-24 10:50:40.199106
# Unit test for function get_standard_properties
def test_get_standard_properties():
    for value, expected in (
        (True, dict(default=True)),
        (False, dict(default=False)),
        (None, dict()),
        ("xyz", dict(default="xyz")),
    ):
        field = Field(value)
        assert get_standard_properties(field) == expected
        assert field.has_default()
        assert field.is_default(value)
        assert not field.is_default(None)



# Generated at 2022-06-24 10:50:42.697487
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Not(negated=Boolean())
    assert not_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Not(negated=Float())



# Generated at 2022-06-24 10:50:54.161912
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        "type": "string",
        "pattern": "^[a-zA-Z]+$"
    }) == String(format="regex", pattern="^[a-zA-Z]+$")

    assert from_json_schema({
        "$ref": "#/definitions/schema"
    }) == Reference("#/definitions/schema")

    assert from_json_schema({
        "allOf": [
            {"type": "string"},
            {"minLength": 2},
            {"maxLength": 5}
        ]
    }) == AllOf([
        String(),
        String(min_length=2),
        String(max_length=5)
    ])



# Generated at 2022-06-24 10:51:02.944938
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, {}) is None
    assert type_from_json_schema({"type": []}, {}) is None
    assert type_from_json_schema({"type": "string"}, {}) == String()
    assert type_from_json_schema({"type": "null"}, {}) == Const(None)
    assert type_from_json_schema({"type": ["string", "integer"]}, {}) == Union(items=[String(), Integer()])
    assert type_from_json_schema({"type": ["string", "null"]}, {}) == Union(items=[String()], allow_null=True)

# Generated at 2022-06-24 10:51:09.105148
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "enum": ["value1", "value2"],
        "title": "Enum"
    }
    field = enum_from_json_schema(data, definitions)
    assert isinstance(field, Choice)
    # TODO: assert the rest of the field



# Generated at 2022-06-24 10:51:17.520217
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    import pytest
    from typesystem import SchemaDefinitions
    from typesystem.schemas import Reference

    global definitions
    definitions = SchemaDefinitions()

    def validate_reference_field(data: dict) -> Field:
        field = ref_from_json_schema(data, definitions=definitions)
        assert isinstance(field, Reference)
        assert field.to == data["$ref"]
        return field

    # A $ref to a definition that has not been defined should raise an error.
    with pytest.raises(Exception):
        validate_reference_field(data={"$ref": "#/definitions/MyField"})

    # Define the definition...
    definitions["#/definitions/MyField"] = String()

    # ... and ensure that we can reference it.

# Generated at 2022-06-24 10:51:18.789432
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({}, None), Field)



# Generated at 2022-06-24 10:51:27.437570
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()
    assert (
        type_from_json_schema({"type": "integer"}, definitions=None) == Integer()
    )
    assert type_from_json_schema({"type": "number"}, definitions=None) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=None) == Boolean()
    assert type_from_json_schema({"type": "object"}, definitions=None) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=None) == Array()
    assert type_from_json_schema({"type": "null"}, definitions=None) == Const(None)


# Generated at 2022-06-24 10:51:36.906650
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "foo": {
                "type": "string",
                "enum": ["bar", "baz"],
                "default": "bar",
            }
        }
    }

    from_json_schema(data).to_json_schema() == data

    data = {
        "type": ["object", "null"],
        "properties": {
            "foo": {
                "type": "string",
                "enum": ["bar", "baz"],
                "default": "bar",
            }
        }
    }

    from_json_schema(data).to_json_schema() == data



# Generated at 2022-06-24 10:51:43.676805
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field = all_of_from_json_schema(
        {
            "allOf": [
                {"type": "number", "minimum": 2.0},
                {"type": "number", "maximum": 3.0},
                {"type": "number", "multipleOf": 0.1}
            ]
        },
        definitions=SchemaDefinitions()
    )
    assert field.to_json_schema() == {
        "allOf": [
            {"type": "number", "minimum": 2.0},
            {"type": "number", "maximum": 3.0},
            {"type": "number", "multipleOf": 0.1}
        ]
    }



# Generated at 2022-06-24 10:51:52.328714
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": "null", "minimum": 3}) == ({"null"}, True)
    assert get_valid_types({"type": "null", "minimum": 2}) == ({"null", "number"}, True)

    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "boolean", "minimum": 3}) == ({"boolean"}, False)
    assert get_valid_types({"type": "boolean", "minimum": 2}) == ({"boolean"}, False)

    assert get_valid_types({"type": "object"}) == ({"object"}, False)

# Generated at 2022-06-24 10:52:01.494566
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    Test function not_from_json_schema
    """
    def test_backslash_not_in_string(data):
        f = not_from_json_schema(data, definitions=None)
        assert f("1")
        assert f("#/definitions/test")
        assert not f("\\")
        assert not f("\\a")
        assert not f("\\\\")

    def test_backslash_not_in_string_dual_definitions(data):
        definitions = SchemaDefinitions()
        f = not_from_json_schema(data, definitions=definitions)
        assert f("1")
        assert not f("#/definitions/test")
        assert not f("\\")
        assert not f("\\a")
        assert not f("\\\\")


# Generated at 2022-06-24 10:52:10.128490
# Unit test for function get_valid_types
def test_get_valid_types():
    # pylint: disable=line-too-long, E1123, protected-access
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["string", "integer", "null"]}) == (
        {"string", "integer"},
        True,
    )
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["integer", "null"]}) == ({"integer"}, True)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["number", "null"]}) == ({"number"}, True)

# Generated at 2022-06-24 10:52:18.182334
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field = all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 1}]}, SchemaDefinitions())
    assert field.validate_json({"allOf": [{"type": "string"}, {"minLength": 1}]}, SchemaDefinitions()) == {"allOf": [{"type": "string"}, {"minLength": 1}]}
    field.validate_json({"allOf": [{"type": "string"}, {"minLength": 1}]}, SchemaDefinitions()) == {"allOf": [{"type": "string"}, {"minLength": 1}]}
    field.validate_json({"allOf": [{"type": "string"}, {"minLength": 1}]}, SchemaDefinitions()) == {"allOf": [{"type": "string"}, {"minLength": 1}]}

# Generated at 2022-06-24 10:52:21.790297
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"type": "number", "const": 3, "default": 3}
    kwargs = {"const": 3, "default": 3}
    field = Const(**kwargs)
    assert const_from_json_schema(data, definitions) == field, "Const field should be created with the right default value and const value"


# Generated at 2022-06-24 10:52:23.242177
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({"oneOf": [{"type":"string"}]})!=None


# Generated at 2022-06-24 10:52:26.211877
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "C"}
    result = from_json_schema(data)
    expected = Const(const="C", default=NO_DEFAULT)
    assert result.json() == expected.json()



# Generated at 2022-06-24 10:52:31.406702
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/inlineObject",
        "definitions": {
            "inlineObject": {"propertyOne": {"type": "string"}, "propertyTwo": {"type": "integer"}},
        },
    }
    field = from_json_schema(schema)
    assert field.properties == {
        "propertyOne": String(allow_blank=True),
        "propertyTwo": Integer(),
    }



# Generated at 2022-06-24 10:52:36.721074
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    print("test for function one_of_from_json_schema")
    data = {"oneOf": ["one", "two", "three", "four", "five"]}

    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    test_result = OneOf(**kwargs)

    test_result_one_ofs = test_result.one_of

    assert test_result_one_ofs[0].__class__.__name__ == "String", "first item must be String"
    assert test_result_one_ofs[1].__class__.__name__ == "String", "second item must be String"
    assert test

# Generated at 2022-06-24 10:52:37.751615
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema({"not": {"type": "null"}}, {}), Not)



# Generated at 2022-06-24 10:52:45.121387
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(DummySchema)

# Generated at 2022-06-24 10:52:48.110615
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from . import assert_validates
    assert_validates(
        schema=enum_from_json_schema({'enum': ["a", "b"],}, definitions=None),
        instance="a")



# Generated at 2022-06-24 10:52:51.276848
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data={"const":12}
    definitions = SchemaDefinitions()

    const_from_json_schema(data, definitions=definitions)



# Generated at 2022-06-24 10:53:01.531408
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"}, # Test coverage is 100%
            {"type": "integer"},
            {"type": "number"}
        ],
        "default": NO_DEFAULT
    }
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("hello")
    assert field.validate(123)
    assert field.validate(1.23)

    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"}, # Test coverage is 100%
            {"type": "number"}
        ],
        "default": NO_DEFAULT
    }
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("hello")
    assert field.valid

# Generated at 2022-06-24 10:53:12.811733
# Unit test for function get_valid_types
def test_get_valid_types():
    _tuples = get_valid_types({})
    assert "null" in _tuples[0]
    assert "boolean" in _tuples[0]
    assert "object" in _tuples[0]
    assert "array" in _tuples[0]
    assert "number" in _tuples[0]
    assert "string" in _tuples[0]
    assert _tuples[1] == False
    _tuples = get_valid_types({"type": "integer"})
    assert "integer" not in _tuples[0]
    assert "number" in _tuples[0]
    assert _tuples[1] == False
    _tuples = get_valid_types({"type": "null"})
    assert "null" not in _tuples[0]

# Generated at 2022-06-24 10:53:15.879450
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    enum = one_of_from_json_schema({"oneOf":[{"type":"string"},{"type":"integer"}]},SchemaDefinitions())
    print(json.dumps(enum.to_primitive()))



# Generated at 2022-06-24 10:53:24.917008
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_data = {
            "anyOf": [
                {
                    "type": "number",
                    "minimum": 0
                },
                {
                    "enum": [
                        0,
                        100
                    ]
                }
            ]
        }
    json_schema_field = any_of_from_json_schema(json_data, None)
    assert json_schema_field.validate(-1) is False
    assert json_schema_field.validate(-1, strict=True) == {'a': "must be one of [0, 100]"}
    assert json_schema_field.validate(0) is True
    assert json_schema_field.validate(0, strict=True) == {}
    assert json_schema_field.validate(1) is True
    assert json_

# Generated at 2022-06-24 10:53:31.172862
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    type_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "my_enum": {
                "type": "string",
                "const": "b",
                "default": "a",
                "enum": ["a", "b", "c"],
            }
        },
    }

# Generated at 2022-06-24 10:53:40.993896
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "boolean"}
    res = type_from_json_schema(data, None)
    assert isinstance(res, Boolean)

    data = {"type": "null"}
    res = type_from_json_schema(data, None)
    assert isinstance(res, Const)
    assert res.value is None

    data = {"type": ["null", "boolean"]}
    res = type_from_json_schema(data, None)
    assert isinstance(res, Union)
    assert isinstance(res.any_of[0], Const)
    assert res.any_of[0].value is None
    assert isinstance(res.any_of[1], Boolean)



# Generated at 2022-06-24 10:53:46.653468
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = one_of_from_json_schema({'oneOf': [{'const': 123}, {'const': 456}]},
                                     SchemaDefinitions())
    assert schema == OneOf(one_of=[Const(const=123), Const(const=456)], default=NO_DEFAULT)

# Generated at 2022-06-24 10:53:52.430939
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"const": 1}, {"const": "hi"}]}) == AllOf(all_of=[Const(const=1), Const(const='hi')])



# Generated at 2022-06-24 10:54:05.002236
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
    "anyOf": [
        {
            "type": "string",
            "enum": [
                "street_number"
            ]
        },
        {
            "type": "object",
            "properties": {
                "lat": {
                    "type": "number"
                },
                "lng": {
                    "type": "number"
                }
            },
            "additionalProperties": False
        }
    ],
    "default": "string"
}

    v1 = any_of_from_json_schema(data, SchemaDefinitions())

# Generated at 2022-06-24 10:54:09.715891
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "number", "minimum": 1, "maximum": 2, "multipleOf": 3}
    actual = from_json_schema_type(data, type_string="number", allow_null=False, definitions=None)
    expected = Float(minimum=1, maximum=2, multiple_of=3, allow_null=False)
    assert actual == expected
# Test for function from_json_schema_type
test_from_json_schema_type()



# Generated at 2022-06-24 10:54:13.865354
# Unit test for function from_json_schema
def test_from_json_schema():
    from_json_schema(
        {
            "type": "object",
            "properties": {
                "foo": {
                    "type": "object",
                    "properties": {"bar": {"type": "boolean"}},
                }
            },
        }
    )


# Generated at 2022-06-24 10:54:25.555937
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # No type
    assert from_json_schema_type({}, type_string="null", allow_null=False, definitions=None) == NO_DEFAULT

    # type: "number"
    result = from_json_schema_type({}, type_string="number", allow_null=False, definitions=None)
    assert isinstance(result, (Integer, Float))
    assert not result.allow_null

    result = from_json_schema_type({}, type_string="number", allow_null=True, definitions=None)
    assert isinstance(result, (Integer, Float))
    assert result.allow_null

    # type: "integer"
    result = from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None)
    assert isinstance(result, Integer)
   

# Generated at 2022-06-24 10:54:31.080706
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(
        String(default="test_string")
    ) == {"default": "test_string"}
    assert get_standard_properties(
        Integer(default=10)
    ) == {"default": 10}
    assert get_standard_properties(
        Float(default=10.5)
    ) == {"default": 10.5}
    assert get_standard_properties(
        Decimal(default=Decimal("10.5"))
    ) == {"default": Decimal("10.5")}
    assert get_standard_properties(
        Boolean(default=True)
    ) == {"default": True}
    assert get_standard_properties(
        Array(default=[1, 2, 3])
    ) == {"default": [1, 2, 3]}

# Generated at 2022-06-24 10:54:35.547199
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert issubclass(OneOf(one_of=[Any()]), Field)



# Generated at 2022-06-24 10:54:40.893470
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/age'}
    definitions = SchemaDefinitions()
    definitions['#/definitions/age'] = Integer()
    assert ref_from_json_schema(data, definitions=definitions) is definitions['#/definitions/age']

# Generated at 2022-06-24 10:54:43.861819
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "string"}
    }
    expected = Not(negated=String())
    actual = not_from_json_schema(data, definitions=None)
    assert actual == expected



# Generated at 2022-06-24 10:54:53.355780
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    # Integer
    assert Integer(minimum=1).to_json_schema() == {"type": "integer", "minimum": 1}
    assert (
        Integer(minimum=1, maximum=10).to_json_schema()
        == {"type": "integer", "minimum": 1, "maximum": 10}
    )
    assert (
        Integer(minimum=1, maximum=10, allow_null=True).to_json_schema()
        == {"type": ["integer", "null"], "minimum": 1, "maximum": 10}
    )

    # Float
    assert Float(minimum=1).to_json_schema() == {"type": "number", "minimum": 1}

# Generated at 2022-06-24 10:54:54.792660
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    type_from_json_schema({"type": "string"})



# Generated at 2022-06-24 10:55:03.944716
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema_data = {'allOf': [{'type': 'integer'},{'minimum': 0}]}
    fields = all_of_from_json_schema(json_schema_data, SchemaDefinitions())
    assert isinstance(fields, AllOf)
    assert isinstance(fields.all_of[0], Integer)
    assert fields.all_of[0].minimum == 0
    json_schema_data = {'allOf': [{'type': 'string'},{'pattern': '^[a-z][a-z0-9]+$'}]}
    fields = all_of_from_json_schema(json_schema_data, SchemaDefinitions())
    assert isinstance(fields, AllOf)
    assert isinstance(fields.all_of[0], String)

# Generated at 2022-06-24 10:55:13.097578
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["string", "null"]}) == ({"string"}, True)
    assert get_valid_types({"type": ["object", "null"]}) == ({"object"}, True)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "number", "enum": [1.0]}) == ({"number"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)

# Generated at 2022-06-24 10:55:20.368845
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # 1. simple case
    data = {
        "anyOf": [
            {"type": "string", "minLength": 1},
            {"type": "string", "minLength": 2},
            {"type": "string", "minLength": 3},
            {"type": "string", "minLength": 4},
        ],
    }
    schema = from_json_schema(data)
    assert schema.validate("abcd", context=None)
    assert not schema.validate("a", context=None)
    assert not schema.validate("ab", context=None)
    assert not schema.validate("abc", context=None)

    # 2. simple case

# Generated at 2022-06-24 10:55:30.884950
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'integer'}, {'type': 'string'}]}) == Union(any_of=[Integer(allow_blank=False, allow_null=False, multiple_of=None, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, default=NO_DEFAULT), String(allow_blank=True, allow_null=False, min_length=None, max_length=None, format=None, pattern=None, default=NO_DEFAULT)], allow_null=False, default=NO_DEFAULT)

# Generated at 2022-06-24 10:55:41.537242
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = {"const": 10.22}
    field = const_from_json_schema(schema, None)
    assert field.validate(10.22)
    assert not field.validate(101)
    assert not field.validate("10.22")
    assert not field.validate([10.22])
    assert not field.validate({"a": 10.22})
    try:
        field.validate({"a": 10.22}, validate_const=True)
        assert False
    except AssertionError as e:
        assert e.args[0] == "Basic data type of {} and {} do not match!".format(type(10.22), type({"a": 10.22}))

# Generated at 2022-06-24 10:55:44.508204
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = any_of_from_json_schema({'anyOf': [{'$ref': 'http://json-schema.org/draft-07/schema#'}]},SchemaDefinitions())
    assert schema.validate(3) == "3"


# Generated at 2022-06-24 10:55:48.981829
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    anyOf_schema = {"anyOf": [{"type": "number"}, {"type": "string"}]}
    typesystem_schema = from_json_schema(anyOf_schema)
    assert isinstance(typesystem_schema, Union)


# Generated at 2022-06-24 10:55:52.232806
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["bar"]}, definitions).to_native("bar") == "bar"



# Generated at 2022-06-24 10:56:00.037835
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
      "allOf": [
        {
          "type": "number"
        },
        {
          "type": "integer",
          "minimum": 10
        }
      ]
    }
    definitions = SchemaDefinitions()
    result = all_of_from_json_schema(data, definitions)
    assert (result(0) == False)
    assert (result(10.1) == True)
    assert (result(10) == True)
    
    

# Generated at 2022-06-24 10:56:10.122136
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float(minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, allow_null=False, default=NO_DEFAULT)
    assert from_json_schema_type({"default":1.0}, "number", False, None) == Float(minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, allow_null=False, default=1.0)
    assert from_json_schema_type({}, "integer", False, None) == Integer(minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, allow_null=False, default=NO_DEFAULT)
    assert from_json_schema

# Generated at 2022-06-24 10:56:14.817340
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer()) == {}
    assert get_standard_properties(Integer(default=1)) == {"default": 1}
    assert get_standard_properties(DeferredObject(None)) == {}

# Generated at 2022-06-24 10:56:25.621147
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Test `type_string` as single string
    assert type_from_json_schema({'type': 'integer'}).__class__.__name__ == "Integer"
    assert type_from_json_schema({'type': 'integer', 'maximum': 5}).__class__.__name__ == "Integer"
    assert type_from_json_schema({'type': 'boolean'}).__class__.__name__ == "Boolean"
    assert type_from_json_schema({'type': 'boolean', 'enum': [True, False]}).__class__.__name__ == "Boolean"
    assert type_from_json_schema({'type': 'string'}).__class__.__name__ == "String"

# Generated at 2022-06-24 10:56:30.467529
# Unit test for function not_from_json_schema

# Generated at 2022-06-24 10:56:36.420121
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null"]}) == (set(), True)
    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean"}, True)



# Generated at 2022-06-24 10:56:38.270371
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()



# Generated at 2022-06-24 10:56:42.834197
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    a = {
    "not":
        {"type":"string","minLength":5,"maxLength":10,"pattern":r"^[a-z]+$","enum":["foo","bar","baz"]}
    }
    s = not_from_json_schema(a, definitions=None)
    assert s.validate('Test') == 'Test'
    assert s.validate('test') == 'test'
    assert s.validate('testTestTest') is None
    


# Generated at 2022-06-24 10:56:52.269010
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(
        from_json_schema(
            {"type": "integer", "maximum": 5, "minimum": -10, "multipleOf": 2}
        ),
        Integer,
    )
    assert from_json_schema({"type": "integer", "maximum": 5, "minimum": -10, "multipleOf": 2}).maximum == 5
    assert from_json_schema({"type": "integer", "maximum": 5, "minimum": -10, "multipleOf": 2}).minimum == -10
    assert from_json_schema({"type": "integer", "maximum": 5, "minimum": -10, "multipleOf": 2}).multiple_of == 2


# Generated at 2022-06-24 10:56:55.863053
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/pattern_name"}).__class__ == Reference



# Generated at 2022-06-24 10:57:07.633307
# Unit test for function get_standard_properties
def test_get_standard_properties():
    expected_data = {'default': 'foo'}
    data = get_standard_properties(String(default='foo'))
    assert data == expected_data
    expected_data = {'default': 3}
    data = get_standard_properties(Integer(default=3))
    assert data == expected_data
    expected_data = {'default': {'a': 'foo', 'b': 'bar'}}
    data = get_standard_properties(Object(properties = {'a': String(default='foo'), 'b': String(default='bar')}))
    assert data == expected_data
    expected_data = {'default': ['foo', 'bar', 'baz']}
    data = get_standard_properties(Array(items=String(default=["foo", "bar", "baz"])))
    assert data == expected_data

# Generated at 2022-06-24 10:57:08.817200
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(
        String(default="Hello", allow_null=True)
    ) == {"default": "Hello"}



# Generated at 2022-06-24 10:57:20.423118
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "number"}).validate(5) == 5
    assert from_json_schema({"type": "number"}).validate(5.5) == 5.5
    assert from_json_schema({"type": "integer"}).validate(5) == 5
    assert from_json_schema({"type": "string"}).validate(5) == "5"
    assert from_json_schema({"type": "boolean"}).validate(5) == True
    assert from_json_schema({"type": "boolean"}).validate(0) == False
    assert from_json_schema({"type": "object"}).validate({"foo": 5}) == {"foo": 5}

# Generated at 2022-06-24 10:57:25.177303
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"}, 
            {"type": "string"}, 
            {"type": "integer"}, 
            {"type": "integer"}, 
            {"type": "integer"}, 
            {"type": "integer"}, 
            {"type": "integer"}, 
        ],
    }
    definitions = {}
    assert one_of_from_json_schema(data, definitions).validate("one")
    assert one_of_from_json_schema(data, definitions).validate("two")
    assert one_of_from_json_schema(data, definitions).validate(1)
    assert one_of_from_json_schema(data, definitions).validate(2)

# Generated at 2022-06-24 10:57:34.782485
# Unit test for function to_json_schema

# Generated at 2022-06-24 10:57:39.781370
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    '''Verification using JSON schemas and attempting to validate given example value data.'''
    data = {'allOf': [{'type': 'number', 'multipleOf': 5},
     {'type': 'number', 'maximum': 35}],
     'type': 'number'}
    definitions = SchemaDefinitions()
    assert all_of_from_json_schema(data, definitions=definitions).is_valid(value=25)



# Generated at 2022-06-24 10:57:44.359450
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number", False, SchemaDefinitions()), Float)
    assert isinstance(from_json_schema_type({}, "integer", False, SchemaDefinitions()), Integer)
    assert isinstance(from_json_schema_type({}, "string", False, SchemaDefinitions()), String)
    assert isinstance(from_json_schema_type({}, "boolean", False, SchemaDefinitions()), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False, SchemaDefinitions()), Array)
    assert isinstance(from_json_schema_type({}, "object", False, SchemaDefinitions()), Object)

    type_strings, allow_null = get_valid_types({})

# Generated at 2022-06-24 10:57:54.442488
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({"type": "number"}, "number", False, None), Number)
    assert isinstance(from_json_schema_type({"type": "integer"}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({"type": "string"}, "string", False, None), String)
    assert isinstance(from_json_schema_type({"type": "boolean"}, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type({"type": "array"}, "array", False, None), Array)
    assert isinstance(from_json_schema_type({"type": "object"}, "object", False, None), Object)


# Generated at 2022-06-24 10:58:01.908504
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"type": "integer"}}
    field = not_from_json_schema(schema, SchemaDefinitions())
    valid_inputs = [
        {"value": 123, "error": True},
        {"value": "foo", "error": False},
        {"value": None, "error": False},
    ]
    for index, entry in enumerate(valid_inputs):
        assert entry["error"] == field.validate(entry["value"])[0], index



# Generated at 2022-06-24 10:58:03.304730
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/anything"}), Reference)

# Generated at 2022-06-24 10:58:12.926897
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # input
    data = {
        "not": {
            "type": "object",
            "required": ["bar"],
            "properties": {
                "bar": {"type": "integer"},
                "baz": {"type": "string"}
            }
        }
    }

    # expected output

# Generated at 2022-06-24 10:58:21.490520
# Unit test for function to_json_schema
def test_to_json_schema():
    schema_a = all_of(
        integer(),
        minimum(7),
    )
    schema_b = any_of(
        const(3),
        const(4),
        const(7),
    )
    schema_c = if_then_else(
        schema_a,
        then_clause=schema_b,
        else_clause=const(0),
    )
    data = to_json_schema(schema_c)

# Generated at 2022-06-24 10:58:26.374514
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    test_schema = {
        "type": ["null", "string"],
    }
    field = type_from_json_schema(test_schema, definitions=SchemaDefinitions())
    assert isinstance(field, Union)
    assert field.allow_null
    assert isinstance(field.any_of[0], String)
    assert isinstance(field.any_of[1], Const)
    assert field.any_of[1].default == None



# Generated at 2022-06-24 10:58:33.884415
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert from_json_schema({"anyOf":[{"type": "string"},{"type": "integer"}]}).validate("foo")
    assert from_json_schema({"anyOf":[{"type": "string"},{"type": "integer"}]}).validate(123)
    assert not from_json_schema({"anyOf":[{"type": "string"},{"type": "integer"}]}).validate(False)
    assert from_json_schema({"anyOf":[{"type": "string"},{"type": "null"}]}).validate(None)
    assert from_json_schema({"anyOf":[{"type": "string"},{"type": "null"}]}).validate("null")
    assert not from_json_schema({"anyOf":[{"type": "string"},{"type": "null"}]}).validate(123)




# Generated at 2022-06-24 10:58:36.115450
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema_data = {
        "type": "number"
    }

    from_json_schema(schema_data)


# Generated at 2022-06-24 10:58:43.970624
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        'not': {
            'type': 'integer',
        },
        'default': None,
    }
    definitions = SchemaDefinitions()
    negated = from_json_schema(data["not"], definitions=definitions)
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    obj = Not(**kwargs)
    assert obj.negated == from_json_schema(data["not"], definitions=definitions)



# Generated at 2022-06-24 10:58:49.881619
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/Person"}), Reference)
    assert isinstance(
        ref_from_json_schema({"$ref": "https://example.com/person.schema.json"}), Reference
    )



# Generated at 2022-06-24 10:58:57.509584
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": ["null", "boolean", "object", "array", "number", "string"]}
    field = enum_from_json_schema(data=schema, definitions=None)
    assert isinstance(field, Choice) is True
    assert field.choices == [("null", "null"), ("boolean", "boolean"), ("object", "object"), ("array", "array"), ("number", "number"), ("string", "string")]



# Generated at 2022-06-24 10:59:06.354827
# Unit test for function to_json_schema
def test_to_json_schema():
    schema_1 = Object.of(
        type=String.of(),
        subtype=String.of(),
        allow_null=Boolean.of(),
        minimum=Integer.of(),
        maximum=Integer.of(),
        exclusive_minimum=Integer.of(),
        exclusive_maximum=Integer.of(),
        multiple_of=Integer.of(),
        formats=Array.of(String.of()),
        default="default_val",
    )


# Generated at 2022-06-24 10:59:13.358936
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"type": "string", "minLength": 1}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Test"] = from_json_schema(data)
    data = {"$ref": "#/definitions/Test"}
    assert ref_from_json_schema(data, definitions=definitions) == Reference("#/definitions/Test", definitions=definitions)



# Generated at 2022-06-24 10:59:22.961567
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    Test that the not_from_json_schema is working properly
    """
    data = {
        "not": {
            "type": "string"
        },
        "default": "A string"
    }

    definitions = SchemaDefinitions()
    actual = not_from_json_schema(data, definitions)
    expected = Not(field=String(), default="A string")
    assert actual == expected
    assert actual.default == expected.default
    assert not actual(2)

    data = {
        "not": {
            "type": "number"
        },
        "default": "A string"
    }

    definitions = SchemaDefinitions()
    actual = not_from_json_schema(data, definitions)
    expected = Not(field=Number(), default="A string")
    assert actual