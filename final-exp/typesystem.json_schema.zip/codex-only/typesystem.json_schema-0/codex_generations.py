

# Generated at 2022-06-24 10:49:21.098615
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from typesystem.test import assert_errors
    schema = {
        "anyOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 12,
            },
            {
                "type": "integer",
                "minimum": 4,
                "maximum": 4,
            },
            {
                "type": "null"
            },
            {
                "type": "number",
                "multipleOf": 2
            },
            {
                "type": "array",
                "items": {
                    "enum": [
                        "foo",
                        "bar",
                        "baz"
                    ]
                }
            }
        ]
    }
    field = any_of_from_json_schema(schema, definitions)
    assert_errors(field, "")

# Generated at 2022-06-24 10:49:30.585041
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {
        "type": "string",
        "minLength": 5,
        "maxLength": 20,
        "pattern": "^[a-z]+$",
    }
    field = from_json_schema(data)
    assert field.type == String()
    assert field.min_length == 5
    assert field.max_length == 20
    assert field.pattern == "^[a-z]+$"

    data = {
        "type": "string",
        "minLength": 5,
        "maxLength": 20,
        "pattern": "^[a-z]+$",
        "enum": ["a", "b"],
    }
    field = from_json_schema(data)
    assert field.type == String()
    assert field.min_length == 5
    assert field.max_

# Generated at 2022-06-24 10:49:38.293815
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
  testdata = {
    "type": "string",
    "const": "1.0.0"
  }
  output = Const(const="1.0.0", default=NO_DEFAULT)
  assert const_from_json_schema(testdata, definitions=None) == output



# Generated at 2022-06-24 10:49:42.191808
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Field()) == {}
    assert get_standard_properties(Field(default=123)) == {"default": 123}
    assert get_standard_properties(Field(default=NO_DEFAULT)) == {}



# Generated at 2022-06-24 10:49:47.503222
# Unit test for function from_json_schema
def test_from_json_schema():
    assert type(from_json_schema({})) == Any
    assert type(from_json_schema({"type": "string"})) == String
    assert type(from_json_schema({"type": "integer"})) == Integer
    assert type(from_json_schema({"type": "number"})) == Number
    assert type(from_json_schema({"type": "object"})) == Object
    assert type(from_json_schema({"type": "array"})) == Array
    assert type(from_json_schema({"enum": ["a", "b"]})) == Choice
    assert type(from_json_schema({"const": "a"})) == Const

    # Minimum
    assert type(from_json_schema({"type": "number", "minimum": 2})) == Number

# Generated at 2022-06-24 10:49:53.393593
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
        ],
        "default": "a default",
    }
    field = any_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate("one") == "one"
    assert field.validate(1) == 1
    assert field.validate({}) == "a default"



# Generated at 2022-06-24 10:49:55.917993
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="Hello")) == {"default":"Hello"}


# Generated at 2022-06-24 10:50:08.088763
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import *

    _report_issue("https://github.com/alecthomas/voluptuous_serialize/issues/48")
    assert to_json_schema(Any()) is True
    assert to_json_schema(NeverMatch()) is False

    assert to_json_schema(String(default="")) == {"type": "string", "default": ""}
    assert to_json_schema(Integer(default=0)) == {"type": "integer", "default": 0}
    assert to_json_schema(Boolean(default=False)) == {"type": "boolean", "default": False}
    assert to_json_schema(Array(default=[])) == {"type": "array", "default": []}

# Generated at 2022-06-24 10:50:19.587366
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    test function not_from_json_schema
    """
    data_fail = {"not": {"type": "number"}, "default": None}
    data_pass = {"not": {"type": "string"}, "default": None}
    data_pass1 = {"not": {"type": "number"}, "default": 1}
    assert not_from_json_schema(data_fail, definitions=None).validate(1) is False
    assert not_from_json_schema(data_pass, definitions=None).validate(1) is True
    assert not_from_json_schema(data_pass1, definitions=None).validate(2) is True


# Generated at 2022-06-24 10:50:30.146306
# Unit test for function get_valid_types
def test_get_valid_types():
    # No type given in JSON schema
    type_strings, allow_null = get_valid_types({})
    assert "null" in type_strings
    assert "boolean" in type_strings
    assert "object" in type_strings
    assert "array" in type_strings
    assert "number" in type_strings
    assert "string" in type_strings
    assert not allow_null

    # String type is given in JSON schema
    type_strings, allow_null = get_valid_types({"type": "string"})
    assert "string" in type_strings
    assert len(type_strings) == 1
    assert not allow_null

    # Null type is given in JSON schema
    type_strings, allow_null = get_valid_types({"type": "null"})
    assert len(type_strings) == 0


# Generated at 2022-06-24 10:50:33.693279
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(
        data={}, type_string="string", allow_null=False, definitions=SchemaDefinitions()
    ) == String()



# Generated at 2022-06-24 10:50:37.397552
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/foo"
    }
    definitions = SchemaDefinitions()
    field = ref_from_json_schema(data, definitions)
    assert type(field) == typing.cast(typing.Type, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions

# Generated at 2022-06-24 10:50:43.503188
# Unit test for function get_valid_types
def test_get_valid_types():
    """Unit test for function get_valid_types."""
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["integer", "null"]}) == ({"integer"}, True)



# Generated at 2022-06-24 10:50:51.122289
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_then_else_from_json_schema(
        {
            "if": {
                "type": "string",
                "enum": ["A", "B"]
            },
            "then": {
                "type": "string",
                "enum": ["A"]
            },
            "else": {
                "type": "string",
                "enum": ["B"]
            }
        }, None
    )

# Generated at 2022-06-24 10:50:56.021995
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema = {
        "anyOf": [
            {
                "type": "object",
                "properties": {
                    "foo": {
                        "enum": [
                            "bar",
                            "baz"
                        ]
                    }
                }
            },
            {
                "type": "object",
                "properties": {
                    "bar": {
                        "enum": [
                            "foo",
                            "baz"
                        ]
                    }
                }
            }
        ]
    }
    field = any_of_from_json_schema(json_schema, definitions)

    assert len(field.any_of) == 2
    assert field.any_of[0].type_name == "object"
    assert field.any_of[1].type_name == "object"

# Generated at 2022-06-24 10:50:58.862196
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/Person",
        "definitions": {
            "Person": {"type": "object", "properties": {"name": {"type": "integer"}}}
        },
    }
    result = from_json_schema(schema)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/Person"



# Generated at 2022-06-24 10:51:04.915266
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Union(
            any_of=[String(), Integer(), Float()],
            allow_null=False,
        ),
        else_clause=NeverMatch(),
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema({
        "if": {"type": "boolean"},
        "then": {"type": ["null", "string", "number"]},
        "else": {"type": "never-matching-type"},
        "default": NO_DEFAULT,
    }, SchemaDefinitions())


# Generated at 2022-06-24 10:51:12.400618
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema_data = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "list": {"type": "array", "items": {"type": "integer", "default": 0}}
                },
            },
            {"type": "object", "properties": {"list": {"type": "array", "minItems": 1}}},
        ]
    }
    all_of_field = all_of_from_json_schema(schema_data, SchemaDefinitions())
    assert all_of_field.validate({"list": [1, 2]}) == {"list": [1, 2]}



# Generated at 2022-06-24 10:51:16.014655
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Any()
    assert isinstance(ref_from_json_schema(json, definitions), Reference)



# Generated at 2022-06-24 10:51:24.345114
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = {}
    data = get_standard_properties(None)
    assert len(data) == 0
    data = get_standard_properties('hello')
    assert len(data) == 0
    data = get_standard_properties(field.meta)
    assert len(data) == 1
    data = get_standard_properties(field.allow_null)
    assert len(data) == 1
    data = get_standard_properties(field.allow_null)
    assert len(data) == 1
    data = get_standard_properties(field.default)
    assert len(data) == 1
    data = get_standard_properties(field.description)
    assert len(data) == 1



# Generated at 2022-06-24 10:51:35.283043
# Unit test for function type_from_json_schema

# Generated at 2022-06-24 10:51:38.648771
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(data= {
        "not": Boolean(allow_null=False)
    }, definitions=SchemaDefinitions()) == Not(negated=Boolean(allow_null=False))
test_not_from_json_schema()



# Generated at 2022-06-24 10:51:45.089029
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    field = from_json_schema({'$ref': '#/definitions/foo'}, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == '#/definitions/foo'



# Generated at 2022-06-24 10:51:56.257675
# Unit test for function from_json_schema
def test_from_json_schema():
    import pytest  # type: ignore
    import json

    # Test schemas require an extra attribute 'default' which tests the
    # serialization of typesystem by testing the deserialization of JSON Schema.
    # The simple schemas are reused to test that behavior.

# Generated at 2022-06-24 10:52:03.300723
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "$id": "test_schema_object",
        "type": "object",
        "required": [
            "test_const_field"
        ],
        "properties": {
            "test_const_field": {
                "const": "const_value"
            }
        }
    }
    json_schema_field = from_json_schema(data)
    assert json_schema_field.validate('{"test_const_field": "const_value"}') == 'const_value'
    assert json_schema_field.validate('{"test_const_field": "wrong_value"}') == 'wrong_value'


# Generated at 2022-06-24 10:52:05.539589
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "hello"}
    assert const_from_json_schema(data, None) == Const(const="hello")
    data = {"const": "hello", "default": "goodbye"}
    assert const_from_json_schema(data, None) == Const(const="hello", default="goodbye")



# Generated at 2022-06-24 10:52:14.093349
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import Boolean, Composite, Field
    from typesystem.constraints import enum_from_json_schema
    from typesystem.fields import Integer, Object, String, Union
    from typesystem.schemas import Reference
    schema_definitions = SchemaDefinitions()
    schema_definitions["x"] = Union(
        [
            Integer(minimum=0),
            Reference("y", definitions=schema_definitions),
            Reference("z", definitions=schema_definitions),
        ]
    )
    schema_definitions["y"] = Boolean(required=True)
    schema_definitions["z"] = Object(properties={"a": String(), "b": Integer()})

# Generated at 2022-06-24 10:52:19.321067
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": [1, "one", False, None],
        "type": ["integer", "string", "boolean", "null"],
    }
    enum_field = enum_from_json_schema(data, SchemaDefinitions())
    assert enum_field.validate(1) == 1
    assert enum_field.validate("one") == "one"
    assert enum_field.validate(False) is False
    assert enum_field.validate(None) is None



# Generated at 2022-06-24 10:52:25.532522
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:52:34.245706
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definition_dict={}) == Any()
    assert type_from_json_schema({"type": "array"}, definition_dict={}) == Array()
    assert (
        type_from_json_schema({"type": ["null", "object"]}, definition_dict={})
        == Union(any_of=[Const(None), Object()])
    )
    assert type_from_json_schema({"type": "null"}, definition_dict={}) == Const(None)
    assert type_from_json_schema({"type": "integer"}, definition_dict={}) == Integer()
    assert (
        type_from_json_schema(
            {"type": "integer", "maximum": 10}, definition_dict={}
        )
        == Integer(maximum=10)
    )
   

# Generated at 2022-06-24 10:52:43.764248
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"enum": [0, 1, 2, 3]},
        ]
    }
    field = all_of_from_json_schema(schema, definitions=None)
    assert field.validate(1) == 1
    assert field.to_json_schema() == {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"enum": [0, 1, 2, 3]},
        ]
    }
    assert field.default == None

# Generated at 2022-06-24 10:52:51.311520
# Unit test for function to_json_schema
def test_to_json_schema():
    integer_field = Integer(minimum=1, maximum=10)
    json_schema = {
        "type": "integer",
        "minimum": 1,
        "maximum": 10,
        "default": 1,
    }
    assert to_json_schema(integer_field) == json_schema

    integer_field = Integer(minimum=1, maximum=10, allow_null=True)
    json_schema = {
        "type": ["integer", "null"],
        "minimum": 1,
        "maximum": 10,
        "default": 1,
    }
    assert to_json_schema(integer_field) == json_schema

    integer_field = Integer(minimum=1, maximum=10, read_only=False)

# Generated at 2022-06-24 10:53:02.328940
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type({}, type_string="boolean", allow_null=True, definitions={})
    from_json_schema_type(
        {"default": None},
        type_string="boolean",
        allow_null=True,
        definitions={},
    )
    from_json_schema_type(
        {}, type_string="number", allow_null=True, definitions={},
    )
    from_json_schema_type(
        {"minimum": 0, "maximum": 100},
        type_string="number",
        allow_null=True,
        definitions={},
    )
    from_json_schema_type(
        {"minimum": 0, "maximum": 100},
        type_string="integer",
        allow_null=True,
        definitions={},
    )
   

# Generated at 2022-06-24 10:53:06.883207
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, definitions={}) == Const(const="foo")
    assert const_from_json_schema({"const": "foo", "default": "bar"}, definitions={}) == Const(const="foo", default="bar")



# Generated at 2022-06-24 10:53:12.029555
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = IfThenElse(
        if_clause=Object(properties={"foo": Const("bar")}),
        then_clause=Object(properties={"baz": Integer()}),
    )

    document = {
        "if": {"properties": {"foo": {"const": "bar"}}},
        "then": {"properties": {"baz": {"type": "integer"}}},
    }

    assert from_json_schema(document) == schema

# Generated at 2022-06-24 10:53:17.163535
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
   data = {
     "oneOf": [
       {"type": "number"},
       {"type": "string"}
     ]
   }
   expected = {
       'type': 'number',
       'type': 'string'
   }
   definitions = SchemaDefinitions()
   actual = one_of_from_json_schema(data, definitions)
   assert actual == expected



# Generated at 2022-06-24 10:53:21.877166
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Hello"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Hello"] = "Hello World!"
    field = ref_from_json_schema(data, definitions=definitions)
    assert field.validate("Hello World!") is None
    assert field.validate("Hello") is not None



# Generated at 2022-06-24 10:53:24.432032
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {"default": NO_DEFAULT}
    assert get_standard_properties(String(default="foo")) == {"default": "foo"}



# Generated at 2022-06-24 10:53:29.852859
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    oneof_schema_0 = {"oneOf": [{"type": "number"}, {"type": "string"}]}
    oneof_schema_1 = {"oneOf": [{"type": "number"}, {"type": "string"},
                                {"type": "array"}]}
    oneof_schema_2 = {"oneOf": [{"type": "number"}]}
    oneof_schema_3 = {"oneOf": [{"type": "number"}, {"type": "string"},
                                {"const": "Number"}]}
    oneof_schema_4 = {"oneOf": [{"type": "number"}, {"type": "number"}]}
    assert isinstance(one_of_from_json_schema(oneof_schema_0,
                                              SchemaDefinitions()), Union)

# Generated at 2022-06-24 10:53:32.022590
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf": [{'type': 'number'}, {'type': 'string'}]}
    field = any_of_from_json_schema(schema, None)
    assert isinstance(field, Union)
    assert isinstance(field.any_of[0], Float)
    assert isinstance(field.any_of[1], String)


# Generated at 2022-06-24 10:53:38.472860
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "maxLength": 10
            },
            "birth_date": {
                "type": "string",
                "format": "date-time"
            },
            "age": {
                "type": "integer",
                "minimum": 0,
                "maximum": 150
            }
        },
        "required": [
            "name",
            "birth_date",
            "age"
        ]
    }
    field = from_json_schema(data)
    assert field.properties["name"].type == String()
    assert field.properties["name"].max_length == 10
    assert field.properties["birth_date"].type == String()

# Generated at 2022-06-24 10:53:41.303794
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data={"anyOf":[{"type":"boolean"},{"type":"integer"}]}
    definitions=SchemaDefinitions()
    test_result=any_of_from_json_schema(data,definitions)
    assert test_result.__name__=="Union"


# Generated at 2022-06-24 10:53:49.730349
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # pylint: disable=line-too-long
    # fmt: off
    a = from_json_schema({
        "if": {
            "type": "string"
        },
        "then": {
            "pattern": "^[a-zA-Z]+$"
        }
    })
    assert a.validate("abc")
    assert not a.validate(123)
    assert not a.validate("123")

    b = from_json_schema({
        "if": {
            "type": "string"
        },
        "else": {
            "type": "integer"
        }
    })
    assert b.validate(123)
    assert b.validate("abc")


# Generated at 2022-06-24 10:53:59.271149
# Unit test for function get_valid_types
def test_get_valid_types():
    test_schemas = [
        {},
        {"type": "null"},
        {"type": ["null"]},
        {"type": "boolean"},
        {"type": ["boolean"]},
        {"type": "null", "type": "boolean"},
        {"type": ["null", "boolean"]},
        {"type": "boolean", "type": "string"},
        {"type": ["boolean", "string"]},
        {"type": ["boolean", "string", "null"]},
        {"type": ["boolean", "number"]},
        {"type": ["boolean", "number", "null"]},
        {"type": ["boolean", "integer"]},
        {"type": ["boolean", "integer", "null"]},
    ]

# Generated at 2022-06-24 10:54:08.494931
# Unit test for function to_json_schema
def test_to_json_schema():

    # We don't expect the round trip to produce the same validator, because we
    # excuse ourselves from supporting all features of JSON schema.
    #
    # However, the round trip should produce an equivalent validator, which is
    # what the following tests check.

    import pathlib
    import json

    test_dir = pathlib.Path(__file__).parent.joinpath("../json_schema/tests")

    format_tests = test_dir.joinpath("draft7/format.json")
    with open(str(format_tests)) as fp:
        test_cases = json.load(fp)
    for case in test_cases:
        schema = from_json_schema(case["schema"])
        for data in case["tests"]:
            name = data["description"]

# Generated at 2022-06-24 10:54:17.551416
# Unit test for function to_json_schema
def test_to_json_schema():
    # Basic validation
    to_json_schema(String())
    to_json_schema(String(allow_blank=False))
    to_json_schema(Integer())
    to_json_schema(Integer(minimum=0))
    to_json_schema(Boolean())
    to_json_schema(Array())
    to_json_schema(Object())
    to_json_schema(Object(properties={"foo": String()}))
    to_json_schema(Object(additional_properties=False))
    to_json_schema(Object(additional_properties=String()))
    to_json_schema(Choice([("foo", "bar"), ("baz", "qux")]))
    to_json_schema(Const("foo"))

# Generated at 2022-06-24 10:54:21.907719
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = None
    result = ref_from_json_schema(data, definitions)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/foo"
    assert result.definitions is definitions

    data = {"$ref": "http://foo.org/schemas/bar.json"}
    try:
        ref_from_json_schema(data, definitions)
        assert False, "Should have raised."  # pragma: no cover
    except AssertionError:
        pass



# Generated at 2022-06-24 10:54:33.508105
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        field1 = Integer()
        field2 = String()
    from_schema = from_json_schema(to_json_schema(MySchema()), MySchema)
    # from_schema's fields are Field instances, whereas MySchema's are Schema
    # field instances.  We can still test for equality because the type of
    # constructor for the Field instance is the same.
    assert from_schema.field1.__class__ == MySchema.field1.__class__
    assert from_schema.field1.__class__ == Integer
    assert from_schema.field2.__class__ == MySchema.field2.__class__
    assert from_schema.field2.__class__ == String


# Generated at 2022-06-24 10:54:38.777580
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {
            "type": "string",
            "pattern": "^A",
        },
        "then": {
            "type": "string",
            "minLength": 3,
        },
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field(None) is None
    assert field(True) is None
    assert field(False) is None
    assert field(0) is None
    assert field(1) is None
    assert field(1.0) is None
    assert field("foo") is None
    assert field("Abc") == "Abc"
    assert field("Bcd") is None



# Generated at 2022-06-24 10:54:43.463217
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert issubclass(
        if_then_else_from_json_schema(
            # Test if-then
            {"if": {"type": "boolean"}, "then": {"type": "string"}},
            definitions=None,
        ),
        IfThenElse,
    )
    assert issubclass(
        if_then_else_from_json_schema(
            # Test if-then-else
            {
                "if": {"type": "boolean"},
                "then": {"type": ["boolean", "number"]},
                "else": {"type": "string"},
            },
            definitions=None,
        ),
        IfThenElse,
    )

# Generated at 2022-06-24 10:54:47.266319
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test = {"not": {"type": "string"}}
    assert not_from_json_schema(test, definitions=None) == Not(negated=String(allow_null=False))



# Generated at 2022-06-24 10:54:54.202775
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # test data
    data = {
        "oneOf": [
            {"type": "number", "minimum": 0.0},
            {"type": "number", "maximum": 0.0},
        ]
    }
    # initialize instance
    schema = one_of_from_json_schema(data, definitions)
    # check output
    assert schema.passes(-1) == False
    assert schema.passes(0.0) == True
    assert schema.passes(1.0) == False


# Generated at 2022-06-24 10:54:59.095852
# Unit test for function to_json_schema
def test_to_json_schema():
    FullName = Object.of(
        properties={
            "first_name": String.max_length(20),
            "last_name": String.max_length(20),
        }
    )
    assert to_json_schema(FullName) == {
        "type": "object",
        "properties": {
            "first_name": {"type": "string", "maxLength": 20},
            "last_name": {"type": "string", "maxLength": 20},
        },
    }

    Person = Object.of(
        properties={
            "name": Reference.to(FullName),
            "age": Integer.between(0, 130),
            "address": Reference.to("Address"),
        }
    )
    Address = Object.of(properties={"street": String})
    definitions = Person.make_def

# Generated at 2022-06-24 10:55:06.459744
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": ["a", "b", "c", "d", "5", "10", "15"], "default": "5"}
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())

    assert field.validate("5") == "5"
    assert field.validate("10") == "10"
    assert field.validate("15") == "15"



# Generated at 2022-06-24 10:55:08.444421
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(Integer(default=0)) == {"default": 0}



# Generated at 2022-06-24 10:55:17.909110
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    test_schema = {
        "type":"object",
        "allOf": [
            {
                "type":"object",
                "properties": {
                    "hello": {
                        "type": "string",
                        "enum": ["world"]
                    }
                },
                "minProperties": 1,
            },
            {
                "type":"object",
                "properties": {
                    "foo": {
                        "type": "number"
                    }
                },
                "minProperties": 1,
            }
        ]
    }
    test_data = {
        "foo": 3,
        "hello": "world"
    }
    result = test_data == all_of_from_json_schema(test_schema, definitions={})

    assert result == True



# Generated at 2022-06-24 10:55:24.822543
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": ["number", "integer"]}) == ({'number', 'integer'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": ["integer", "number"]}) == ({'number', 'integer'}, False)



# Generated at 2022-06-24 10:55:29.562976
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "string"},
            {"type": "number", "minimum": 42},
        ]
    }
    data = {"number": 40}

    field = any_of_from_json_schema(schema, definitions)
    assert field.validate(data) is None



# Generated at 2022-06-24 10:55:40.935574
# Unit test for function type_from_json_schema
def test_type_from_json_schema():

    from_json_schema_type = from_json_schema

    assert from_json_schema_type({"type": "string"}) == String()
    assert from_json_schema_type({"type": "string", "minLength": 3}) == String(min_length=3)
    assert from_json_schema_type({"type": "string", "maxLength": 3}) == String(max_length=3)
    assert from_json_schema_type({"type": "string", "pattern": r"foo"}) == String(
        pattern=r"foo"
    )
    assert from_json_schema_type({"type": "number"}) == Number()
    assert from_json_schema_type({"type": "number", "minimum": 3}) == Number(minimum=3)

# Generated at 2022-06-24 10:55:53.791155
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    def check(data, expected):
        actual = from_json_schema_type(
            data, type_string="string", allow_null=False, definitions=None
        ).to_primitive()
        assert actual == expected, f"{actual!r} != {expected!r}"

    check(
        {
            "pattern": "^[A-Z]+$",
            "maxLength": 100,
            "default": "ABCD",
            "minLength": 5,
        },
        {
            "title": "String",
            "type": "string",
            "pattern": "^[A-Z]+$",
            "default": "ABCD",
            "maxLength": 100,
            "minLength": 5,
        },
    )

# Generated at 2022-06-24 10:56:05.591916
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array()
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object()



# Generated at 2022-06-24 10:56:10.175859
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    item = {"enum": [1, 2, 3]}
    field = enum_from_json_schema(item, definitions=None)
    assert field.validate(1) == 1  # Same as JSON Schema



# Generated at 2022-06-24 10:56:14.889924
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/reference_schema"
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/reference_schema"] = String()
    assert isinstance(ref_from_json_schema(data, definitions=definitions), Reference)



# Generated at 2022-06-24 10:56:24.269684
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    a = { 'const': 3, 'default': 2 }
    a_type = const_from_json_schema(a)
    b = { 'const': 'hello', 'default': 'hi'}
    b_type = const_from_json_schema(b)
    c = { 'const': 'Hello'}
    c_type = const_from_json_schema(c)

    assert a_type.is_valid(3)
    assert b_type.is_valid('hello')
    assert not a_type.is_valid(2)
    assert not b_type.is_valid('hi')
    assert not c_type.is_valid('hello')



# Generated at 2022-06-24 10:56:32.600164
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "one": {
                "oneOf": [
                    {
                        "type": "string",
                        "minLength": 10,
                        "maxLength": 20
                    },
                    {
                        "type": "string",
                        "pattern": "^[0-9]+$"
                    }
                ],
                "default": "abc"
            }
        }
    }

# Generated at 2022-06-24 10:56:41.996588
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover
    from_json_schema_type(
        data={"type": "string"},
        type_string="string",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    from_json_schema_type(
        data={"type": "integer"},
        type_string="integer",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    from_json_schema_type(
        data={"type": "number"},
        type_string="number",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )

# Generated at 2022-06-24 10:56:49.878513
# Unit test for function from_json_schema_type

# Generated at 2022-06-24 10:56:55.428197
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
            "type": "object",
            "allOf": [
                {"type": "object", "properties": {"color": "string"}},
                {"type": "object", "properties": {"shape": "string"}},
            ],
        }
    field = all_of_from_json_schema(data)
    assert isinstance(field, AllOf)
    assert isinstance(field.all_of[0], Object)
    assert isinstance(field.all_of[1], Object)



# Generated at 2022-06-24 10:57:01.892937
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Integer(default=1)
    assert get_standard_properties(field) == {"default": 1}

    field = Integer()
    assert get_standard_properties(field) == {}

    field = String(default=1)
    assert get_standard_properties(field) == {"default": 1}

    field = String()
    assert get_standard_properties(field) == {}

    field = String(default="some string")
    assert get_standard_properties(field) == {"default": "some string"}

    field = String(default="")
    assert get_standard_properties(field) == {"default": ""}

    field = Array(items=String(), default=[])
    assert get_standard_properties(field) == {"default": []}

    field = Array(items=String(), default="")

# Generated at 2022-06-24 10:57:07.595479
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    constraint = not_from_json_schema(data['not'],definitions=definitions)
    assert isinstance(constraint, Not)
    assert constraint.negated == {"type": "string", "maxLength": 5}
    assert constraint.default == NO_DEFAULT


# Generated at 2022-06-24 10:57:19.760230
# Unit test for function to_json_schema
def test_to_json_schema():
    import jsonschema

    field = Field(
        default="Hello",
        choices=[
            ("a", "Option A"),
            ("b", "Option B"),
            ("c", "Option C"),
        ],
    )
    field = field.as_json_schema()

    assert field.default == "Hello"
    assert field.choices == [
        ("a", "Option A"),
        ("b", "Option B"),
        ("c", "Option C"),
    ]

    data = to_json_schema(field)
    jsonschema.validate(instance=data, schema=JSONSchema)

    data2 = to_json_schema(field, _definitions=data.get("definitions", {}))
    jsonschema.validate(instance=data2, schema=JSONSchema)


# Generated at 2022-06-24 10:57:22.220329
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    f = Any()  # placeholder
    assert any_of_from_json_schema({'anyOf': [1, 2, 3]}, None).validate(1)


# Generated at 2022-06-24 10:57:26.101274
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"const": 2}}
    definitions = SchemaDefinitions()
    negated = not_from_json_schema(data, definitions)
    
    assert not negated.validate(2), "Expected not to be true"
    assert negated.validate(3), "Expected not to be false"



# Generated at 2022-06-24 10:57:34.233563
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "integer"}, Any()) == Integer() | Any()
    assert type_from_json_schema({"type": "null"}) == Const(None)
    assert type_from_json_schema({"type": ["null", "integer"]}) == Integer() | Const(None)
    assert type_from_json_schema({"type": ["null", "integer"]}, Any()) == Integer() | Const(None) | Any()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "string"}, Any()) == String() | Any()

# Generated at 2022-06-24 10:57:42.144168
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        True,
    )
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean", "object"]}) == ({"boolean", "object"}, False)
    assert get_valid_types({"type": "boolean", "nullable": True}) == ({"boolean"}, True)
    assert get_valid_types({"type": "number"}) == ({"number", "integer"}, False)

# Generated at 2022-06-24 10:57:52.984945
# Unit test for function from_json_schema
def test_from_json_schema():

    field = from_json_schema({
        "$id": "schema-1",
        "type": "boolean"})
    assert field == Boolean()
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("true") == "Field must be of type 'boolean'"

    field = from_json_schema({
        "$id": "schema-1",
        "type": "string",
        "minimum": 5,
        "maximum": 10,
        "pattern": "^[A-Z]+$"})
    assert field == String(minimum=5, maximum=10, pattern=re.compile('^[A-Z]+$'))
    assert field.validate("AA") == "Value must be a string of 5-10 characters in length"


# Generated at 2022-06-24 10:57:55.429424
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert (
        ref_from_json_schema(
            data={"$ref": "#/definitions/my_reference"}, definitions=definitions
        )
        == Reference("#/definitions/my_reference", definitions=definitions)
    )



# Generated at 2022-06-24 10:57:58.193669
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({
        "const": "john doe",
        "default": "Noname"
    }, definitions = None)
    assert field.__class__.__name__ == "Const"
    assert field.const == "john doe"
    assert field.default.value == "Noname"


# Generated at 2022-06-24 10:58:10.682075
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({"anyOf": [{"type": "string"},{"type": "number"}]}, SchemaDefinitions) == Union(any_of= [String(),Float()], allow_null=False)
    assert any_of_from_json_schema({"anyOf": [{"type": "string"},{"type": "boolean"}]}, SchemaDefinitions) == Union(any_of= [String(),Boolean()], allow_null=False)
    assert any_of_from_json_schema({"anyOf": [{"type": "array"},{"type": "boolean"}]}, SchemaDefinitions) == Union(any_of= [Array(),Boolean()], allow_null=False)
    #assert any_of_from_json_schema({"anyOf": [{"type": "number"},{"type":

# Generated at 2022-06-24 10:58:22.122406
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {'null', 'boolean', 'object', 'array', 'number', 'string'},
        False
    )
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "integer", "maximum": 5}) == ({'number', 'integer'}, False)
    assert get_valid_types({"type": "integer", "exclusiveMaximum": 5}) == ({'number', 'integer'}, False)
    assert get_valid_types({"type": "integer", "minimum": 5}) == ({'number', 'integer'}, False)

# Generated at 2022-06-24 10:58:27.101787
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Unit tests for function `from_json_schema_type`.
    """
    data = {
        "type": "number",
        "default": 1.0,
        "minimum": -1,
        "maximum": 1,
        "exclusive_minimum": -0.5,
        "exclusive_maximum": 0.5,
        "multiple_of": 0.1,
    }
    schema = from_json_schema_type(
        data, type_string="number", allow_null=False, definitions=definitions
    )
    assert isinstance(schema, Float)
    assert schema.default == 1.0
    assert schema.minimum == -1
    assert schema.maximum == 1
    assert schema.exclusive_minimum == -0.5
    assert schema.exclusive_maximum == 0.5

# Generated at 2022-06-24 10:58:34.181531
# Unit test for function from_json_schema
def test_from_json_schema():
    # Basic Schema
    schema = {
        'type': 'string',
        'minLength': 10,
        'maxLength': 100,
        'pattern': r'^[a-zA-Z0-9_]+$'
    }
    field = from_json_schema(schema)
    assert isinstance(field, String)
    assert field.minimum_length == 10
    assert field.maximum_length == 100
    assert field.pattern == re.compile(r'^[a-zA-Z0-9_]+$')

    # Schema with constraints
    schema = {
        'type': 'string',
        'enum': ['foo', 'bar', 'baz']
    }
    field = from_json_schema(schema)
    assert isinstance(field, Choice)

# Generated at 2022-06-24 10:58:36.810688
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {'type': 'string', 'enum': ['red', 'amber', 'green']}
    assert from_json_schema(data).choices == ['red', 'amber', 'green']



# Generated at 2022-06-24 10:58:43.702852
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "const": "Yes",
        },
        "then": {
            "type": "integer",
        },
    }
    schema = if_then_else_from_json_schema(
        data, definitions=SchemaDefinitions()
    )
    assert schema.serialise(None, "Yes") == 1
    assert schema.serialise(None, "No") is None


JSONSchemaCompiler = JSONSchemaCompilerType()

if __name__ == "__main__":
    from .utils import run_doctest

    run_doctest()
    test_if_then_else_from_json_schema()

# Generated at 2022-06-24 10:58:51.547716
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(const=True),
        then_clause=Boolean(const=True),
        else_clause=Boolean(const=True),
    ) == if_then_else_from_json_schema(
        data={
            "if": {"const": True},
            "then": {"const": True},
            "else": {"const": True},
        },
        definitions=SchemaDefinitions(),
    )



# Generated at 2022-06-24 10:59:00.250295
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = "if_clause"
    then_clause = "then_clause"
    else_clause = "else_clause"
    result = if_then_else_from_json_schema(
        data={"if": if_clause, "then": then_clause, "else": else_clause},
        definitions=None
    )
    assert result.if_clause == if_clause
    assert result.then_clause == then_clause
    assert result.else_clause == else_clause

# Generated at 2022-06-24 10:59:05.676347
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema_data = {
        "allOf": [
            {
                "$ref": "#/definitions/i",
            },
            {
                "type": "integer",
            }
        ],
        "default": 9,
        "definitions": {
            "i": {
                "type": "integer",
            }
        },
    }
    actual = all_of_from_json_schema(json_schema_data, SchemaDefinitions())
    assert isinstance(actual, AllOf)


# Generated at 2022-06-24 10:59:12.379226
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": "John"}, definitions=None)
    assert field.validate("John")
    assert field.validate(const="John")
    assert not field.validate("Michael")
    assert not field.validate(const="Michael")
    assert field.get_default_value() == "John"
