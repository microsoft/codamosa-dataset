

# Generated at 2022-06-24 10:49:19.617269
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {"enum": ["bad", "good"]}
    enum = enum_from_json_schema(json_schema, definitions=definitions)
    assert enum.validate("bad") is None
    assert enum.validate("good") is None
    assert enum.validate("ugly") == ["Value must be one of ['bad', 'good']."]
    assert enum.validate(None) == ["Value must be one of ['bad', 'good']."]



# Generated at 2022-06-24 10:49:22.725400
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema_data = {"$ref": "#/definitions/MySchema"}
    definitions = {
        "MySchema": Integer(minimum=0, maximum=100),
    }
    expected_field = Reference("#/definitions/MySchema", definitions=definitions)
    actual_field = ref_from_json_schema(json_schema_data, definitions)
    assert actual_field == expected_field

# Generated at 2022-06-24 10:49:28.796517
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {'allOf': [{'type': ['array']}, {'items': {'type': 'integer'}}], 
              'default': [], 
              'type': ['array']}
    field = all_of_from_json_schema(schema, [])
    assert field.validate([]) == []
    assert field.validate([1]) == []
    assert field.validate([1, 1.0, 'a']) == ['Invalid type.']
    assert field.validate([[]]) == ['Invalid type.']


# Generated at 2022-06-24 10:49:36.560760
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.fields import String, Integer, Object
    from typesystem.schemas import SchemaDefinitions

    definitions = SchemaDefinitions()

    assert from_json_schema({"type": "string"}, definitions=definitions) == String()
    assert from_json_schema({"type": "integer"}, definitions=definitions) == Integer()
    assert from_json_schema({"type": ["string", "integer"]}, definitions=definitions) == (
        String() | Integer()
    )
    assert from_json_schema(True, definitions=definitions) == Any()
    assert from_json_schema(False, definitions=definitions) == NeverMatch()

# Generated at 2022-06-24 10:49:40.802784
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema(): # pragma: no cover
    from typesystem import Reference

    data = {'$ref': '#/definitions/Schema'}
    assert ref_from_json_schema(data) == Reference(to='#/definitions/Schema')



# Generated at 2022-06-24 10:49:47.901586
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{'type': 'number'},
                                               {'minimum': 0}],
                                    "type": "number"}, definitions=None) == AllOf(
                                        [Float(minimum=0), Float()])
    assert all_of_from_json_schema({"allOf": [{'type': 'number'},
                                               {'minimum': 0}]}, definitions=None) == AllOf(
                                                   [Float(minimum=0), Float()])


# Generated at 2022-06-24 10:49:56.527549
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(
        data={
            "type": "string",
            "minLength": 20,
            "maxLength": 100,
            "format": "email",
            "default": '"hello@example.com"',
        },
        type_string="string",
        allow_null=False,
        definitions=None,
    ) == String(
        allow_blank=True,
        allow_null=False,
        default='"hello@example.com"',
        format="email",
        max_length=100,
        min_length=20,
    )


# Generated at 2022-06-24 10:50:08.487579
# Unit test for function to_json_schema
def test_to_json_schema():
    class Properties(Schema):
        name = String(default="test")
        age = Integer(default=33)

    prop = Properties()
    prop_validator = Properties.make_validator()

    data = to_json_schema(prop)
    assert data == {
        "type": "object",
        "properties": {
            "name": {"type": "string", "default": "test"},
            "age": {"type": "integer", "default": 33},
        },
        "required": ["name", "age"],
    }

    data = to_json_schema(prop_validator)

# Generated at 2022-06-24 10:50:21.642586
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Note: property default is not included because it is handled elsewhere
    simple_all_of = {
        'allOf': [
            {'type': 'string'}, 
            {'minLength': 1},
            {'maxLength': 5},
            {'enum': ['lorem', 'ipsum']}
        ]
    }

    assert isinstance(all_of_from_json_schema(simple_all_of, definitions=None), AllOf)
    assert len(all_of_from_json_schema(simple_all_of, definitions=None).all_of) == 4
    assert all_of_from_json_schema(simple_all_of, definitions=None).all_of[0].min_length == 0

# Generated at 2022-06-24 10:50:26.795415
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema({'not': {'type': 'array'}}, SchemaDefinitions()), Not)
    assert not_from_json_schema({'not': {'type': 'array'}}, SchemaDefinitions()).negated.__class__ == Array
    assert not_from_json_schema({'not': {'type': 'array', 'items': {'type': 'integer'}}}, SchemaDefinitions()).negated.__class__ == Array



# Generated at 2022-06-24 10:50:30.291462
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {"if": {"type": "integer"}, "then": {"type": "integer"}, "else": {"type": "integer"}}
    if_then_else_field = if_then_else_from_json_schema(schema, {})
    assert if_then_else_field.if_clause.type is Integer
    assert if_then_else_field.then_clause.type is Integer
    assert if_then_else_field.else_clause.type is Integer

# Generated at 2022-06-24 10:50:34.476838
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    kwargs = {"const": 0, "default": data.get("default", NO_DEFAULT)}
    assert (const_from_json_schema(data, definitions)==0)


# Generated at 2022-06-24 10:50:42.855790
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    definitions = SchemaDefinitions()

    # Number
    schema = {"type": "number"}
    field = from_json_schema(schema, definitions=definitions)
    assert field.allow_null
    assert isinstance(field, Float)
    assert field.allow_null

    schema = {"type": "number", "minimum": -1234}
    field = from_json_schema(schema, definitions=definitions)
    assert field.allow_null
    assert isinstance(field, Float)
    assert field.maximum is None
    assert field.minimum == -1234

    schema = {"type": "number", "maximum": 1234}
    field = from_json_schema(schema, definitions=definitions)
    assert field.allow_null
    assert isinstance(field, Float)

# Generated at 2022-06-24 10:50:52.716378
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}], "default": "oneof"}
    field = one_of_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, OneOf)
    assert isinstance(field.one_of[0], String)
    assert isinstance(field.one_of[1], Integer)
    assert field.one_of[0].validate("oneof") == (None, "oneof")
    assert field.one_of[1].validate("oneof") == ("Value must be in integer format.", None)



# Generated at 2022-06-24 10:50:59.368070
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["number", "null"]}) == ({"number"}, True)
    assert get_valid_types({"type": ["integer", "null", "boolean"]}) == ({"integer", "boolean"}, True)



# Generated at 2022-06-24 10:51:12.346404
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    number_schema = {"private": "foo", "type": "number"}
    assert type_from_json_schema(number_schema) == Number(private={"foo"})

    number_or_string_schema = {"private": "foo", "type": ["number", "string"]}
    assert type_from_json_schema(number_or_string_schema) == Union(
        any_of=[
            Number(private={"foo"}),
            String(private={"foo"}),
        ],
        allow_null=True,
    )

    integer_schema = {"private": "foo", "type": "integer"}
    assert type_from_json_schema(integer_schema) == Integer(private={"foo"})

    string_schema = {"private": "foo", "type": "string"}

# Generated at 2022-06-24 10:51:22.842413
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, None) == String(allow_null=False)
    assert type_from_json_schema({"type": "string", "nullable": True}, None) == String(
        allow_null=True
    )
    assert type_from_json_schema({"type": "string", "nullable": False}, None) == String(
        allow_null=False
    )
    assert type_from_json_schema({"type": "integer"}, None) == Integer(allow_null=False)
    assert type_from_json_schema({"type": "number"}, None) == Number(allow_null=False)
    assert type_from_json_schema({"type": "boolean"}, None) == Boolean(allow_null=False)
    assert type_

# Generated at 2022-06-24 10:51:34.753988
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:51:43.203028
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data_1 = {"not":{"type":"number"}}
    data_2 = {"not":{"type":"number"},"default":5.5}
    data_3 = {"not":{"type":"number"},"default":None}
    assert [
        {
            "class": Not,
            "negated": {"class": Float, "allow_null": False, "default": NO_DEFAULT},
            "default": 5.5,
        },
        {
            "class": Not,
            "negated": {"class": Float, "allow_null": False, "default": NO_DEFAULT},
            "default": None,
        },
        {
            "class": Not,
            "negated": {"class": Float, "allow_null": False, "default": NO_DEFAULT},
            "default": NO_DEFAULT,
        },
    ]

# Generated at 2022-06-24 10:51:48.215172
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'array', 'string', 'object', 'integer', 'number'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': ['string', 'null']}) == ({'string'}, True)
    assert get_valid_types({'type': ['number', 'null']}) == ({'number'}, True)



# Generated at 2022-06-24 10:51:53.330983
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {"type": "string", "pattern": "^[0-9]+$"}
    field = from_json_schema(schema)
    assert isinstance(field, String)
    assert field.format == "regex"
    assert field.min_length == 1
    assert field.max_length is None
    assert field.default is NO_DEFAULT



# Generated at 2022-06-24 10:52:01.887553
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    test_json_schema = {
        "$ref": "#/definitions/test",
        "definitions": {
            "test": {
                "type": "string"
            }
        }
    }
    result = []
    result.append(test_json_schema["$ref"] == ref_from_json_schema(test_json_schema).reference_string)
    test_json_schema = {
        "$ref": "#/definitions/test",
        "definitions": {
        }
    }
    result.append(test_json_schema["$ref"] == ref_from_json_schema(test_json_schema).reference_string)

    return result


# Generated at 2022-06-24 10:52:10.450176
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()
    assert type_from_json_schema({"type": "boolean"}, definitions=None) == Boolean()
    assert type_from_json_schema({"type": "integer"}, definitions=None) == Integer(
        exclusive_minimum=0
    )
    assert type_from_json_schema({"type": "number"}, definitions=None) == Float()
    assert type_from_json_schema({"type": "array"}, definitions=None) == Array()
    assert type_from_json_schema({"type": "object"}, definitions=None) == Object()
    assert type_from_json_schema({"type": "null"}, definitions=None) == Const(None)


# Generated at 2022-06-24 10:52:11.369296
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from_json_schema({"if": {"type": "integer"}, "then": {"minimum": 0}})

# Generated at 2022-06-24 10:52:18.420352
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/my_very_special_type"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/my_very_special_type"] = String()
    field = ref_from_json_schema(data, definitions=definitions)
    assert field.validate("ABC") == "ABC"



# Generated at 2022-06-24 10:52:23.646844
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_dict = {"id": {"type": "string"}, "group": {"type": "string", "enum": ["red","green","blue"]}}
    schema = from_json_schema(json_dict, definitions=None)
    assert isinstance(schema, Schema)
    assert len(schema.fields) == 2
    assert isinstance(schema.fields[0], String)
    assert isinstance(schema.fields[1], Choice)
    assert schema.fields[1].choices == [("red","red"),("green","green"),("blue","blue")]



# Generated at 2022-06-24 10:52:31.315441
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": String()})
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == {"#/definitions/foo": String()}
    assert field.schema_key() == ("#/definitions/foo",)
    assert field.validate("bar") == "bar"
    assert field.to_primitive(None) == None
    assert field.to_primitive(42) == "42"
    assert field.to_primitive("foo") == "foo"



# Generated at 2022-06-24 10:52:38.855868
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["string", "number"]}) == ({"string", "number"}, False)
    assert get_valid_types({}) == ({"number", "string", "object", "boolean", "integer", "array"}, False)
    assert get_valid_types({"type": "null"}) == ({"boolean", "object", "array", "number", "string"}, True)
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)
    assert get_valid_

# Generated at 2022-06-24 10:52:50.288995
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = {
        "#/definitions/object": Object(properties={"property": String()}),
        "#/definitions/integer": Integer(),
        "#/definitions/float": Float(),
    }

    content = {'$ref': '#/definitions/object'}
    field = ref_from_json_schema(data=content, definitions=definitions)
    assert field.field_name is None
    assert field.get_default() == NO_DEFAULT

    content = {'$ref': '#/definitions/integer'}
    field = ref_from_json_schema(data=content, definitions=definitions)
    assert field.field_name is None
    assert field.get_default() == NO_DEFAULT

    content = {'$ref': '#/definitions/float'}

# Generated at 2022-06-24 10:52:58.003790
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.schemas import from_json_schema

    schema = from_json_schema(
        {
            "type": "object",
            "properties": {
                "Person": {"type": "object", "properties": {"name": {"type": "string"}, "age": {"type": "integer"}}}
            }
        },
        definitions={},
    )

    assert schema.validate({"Person": {"name": "Turanga Leela", "age": 42}})
    assert not schema.validate({"Person": {"name": "Turanga Leela", "age": "42"}})



# Generated at 2022-06-24 10:53:00.104625
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
  def validate():
    pass

  validator = Const(const="hello", validate=validate)
  validator.validate("hello")



# Generated at 2022-06-24 10:53:08.990404
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import pytest
    # Test with a combined schema of JSONSchema
    schema = {'allOf': [{'$ref': '#/definitions/JSONSchema'}, {'type': 'string'}]}
    json_schema = from_json_schema(schema)
    assert isinstance(json_schema, field.AllOf)
    assert isinstance(json_schema.all_of[0], Reference)
    assert json_schema.all_of[1] == String()
    # Test with a combined schema of Choice and Const
    schema = {'allOf': [{'const': 'a'}, {'enum': ['b', 'c', 'd']}]}
    json_schema = from_json_schema(schema)
    assert isinstance(json_schema, field.AllOf)


# Generated at 2022-06-24 10:53:12.399218
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref" : "#/definitions/emptyObject"}
    field = ref_from_json_schema(data = data)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/emptyObject"


# Generated at 2022-06-24 10:53:17.920409
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    expected = Union(
        any_of=[Integer(), Float()],
        allow_null=True,
        default=None,
        description=None,
        meta=None,
        name=None,
    )
    data = {"type": ["integer", "number"], "default": None}
    actual = type_from_json_schema(data, SchemaDefinitions())
    assert actual == expected



# Generated at 2022-06-24 10:53:26.016711
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": ['null', 'object']}) == ({"object"}, True)
    assert get_valid_types({"type": ['object', 'null']}) == ({"object"}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
   

# Generated at 2022-06-24 10:53:32.447237
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "type": "string",
        "enum": [
            "franco",
            "franco_2.0",
            "bavarian",
            "bavarian_2.0",
        ]
    }
    f = enum_from_json_schema(schema, definitions=None)
    assert f.validate("franco") == "franco"
    assert f.validate("franco_2.0") == "franco_2.0"
    assert f.validate("bavarian") == "bavarian"
    assert f.validate("bavarian_2.0") == "bavarian_2.0"
    assert not f.validate("franco-bavarian")


# Generated at 2022-06-24 10:53:32.980846
# Unit test for function get_valid_types
def test_get_valid_types():
    pass



# Generated at 2022-06-24 10:53:43.431316
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    f = enum_from_json_schema({'enum': ['one', 'two', 'three'],}, {})
    assert f.validate('one')
    assert f.validate('two')
    assert f.validate('three')
    assert not f.validate('four')
    assert not f.validate(None)



# Generated at 2022-06-24 10:53:47.296436
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":[{
            "type":"string"
    },{
            "type":"integer"
    }]}
    field = any_of_from_json_schema(data,None)
    assert isinstance(field,Union)
    assert isinstance(field.any_of[0],String)
    assert isinstance(field.any_of[1],Integer)



# Generated at 2022-06-24 10:53:58.645435
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    fields = {}
    fields['const'] = [{
        'const': 'string',
        'default': 'string'
    }, {
        'const': True,
        'default': True
    }, {
        'const': 1,
        'default': 1
    }, {
        'const': {
            'xx': 'string'
        },
        'default': {
            'xx': 'string'
        }
    }, {
        'const': [
            'string'
        ],
        'default': 'string'
    }]

# Generated at 2022-06-24 10:54:01.890689
# Unit test for function get_standard_properties
def test_get_standard_properties():
    arg = Boolean(default=True)
    data = get_standard_properties(arg)
    assert data == {"default": True}

    arg = Boolean()
    data = get_standard_properties(arg)
    assert data == {}



# Generated at 2022-06-24 10:54:09.546592
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "integer"}) == ({'integer', 'number'}, False)
    assert get_valid_types({"type": ["null", "object"]}) == ({'object'}, True)
    assert get_valid_types({"type": "integer", "maximum": 0}) == ({'integer', 'number'}, False)
    assert get_valid_types({"type": "null", "maximum": 0}) == ({'number'}, True)
    assert get_valid_types({"type": ["number", "integer"]}) == ({'number', 'integer'}, False)



# Generated at 2022-06-24 10:54:15.454513
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [0, 1]}, None) == Union(any_of=(Integer(minimum=0, maximum=0), Integer(minimum=1, maximum=1)))
    assert any_of_from_json_schema({'anyOf': [0, 1]}, None) == Union(any_of=(Integer(minimum=0, maximum=0), Integer(minimum=1, maximum=1)))
    


# Generated at 2022-06-24 10:54:19.742497
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    test_field = String()
    test_definition = const_from_json_schema({"const": "test", "default": "test"}, definitions = None)
    assert test_field.validate("test") == test_definition.validate("test")



# Generated at 2022-06-24 10:54:21.578836
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert "#/foo" == ref_from_json_schema({'$ref': '#/foo'})



# Generated at 2022-06-24 10:54:23.651555
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert len(definitions) > 0

# Generated at 2022-06-24 10:54:32.642223
# Unit test for function from_json_schema
def test_from_json_schema():
    """Unit test for function from_json_schema."""
    assert Any() == from_json_schema(True)
    assert Any() == from_json_schema({"type": "any"})
    assert Any() == from_json_schema({"enum": ["a", "b"]})
    assert Any() == from_json_schema({"const": None})

    assert NeverMatch() == from_json_schema(False)
    assert NeverMatch() == from_json_schema({"not": True})
    assert NeverMatch() == from_json_schema({"not": {"type": "any"}})
    assert NeverMatch() == from_json_schema({"not": {"enum": ["a", "b"]}})

# Generated at 2022-06-24 10:54:43.963969
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'string', 'boolean', 'null', 'object', 'array', 'number', 'integer'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': 'null'}) == ({}, True)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': ['null', 'number']}) == ({'number'}, True)
    assert get_valid_types({'type': ['number', 'null']}) == ({'number'}, True)
    assert get_valid_types({'type': ['null', 'integer']}) == ({'integer'}, True)

# Generated at 2022-06-24 10:54:54.518492
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string", "enum": ["abc", "123"]}) == String(enum=["abc", "123"])
    assert from_json_schema({"type": "string", "$ref": "#/definitions/foo"}) == String()
    assert from_json_schema({"type": "string", "const": "abc"}) == Const("abc")
    assert from_json_schema({"type": "string", "minLength": 5}) == String(min_length=6)
    assert from_json_schema({"type": "string", "maxLength": 5}) == String(max_length=5)
    assert from_json_schema({"type": "string", "pattern": "^A*$"}) == String(pattern="^A*$")
    assert from_json

# Generated at 2022-06-24 10:54:59.813265
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_json_schema = {
        "const": 10,
    }
    field = const_from_json_schema(const_json_schema, definitions=None)
    assert field.validate(10)
    assert not field.validate(9)
    assert not field.validate(11)
    assert not field.validate("10")
    assert not field.validate(None)



# Generated at 2022-06-24 10:55:04.059269
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    kwargs = {"any_of": [String(), String()], "default": "NO_DEFAULT"}
    expected = Union(**kwargs)
    data = {"anyOf": [{}, {}], "default": "NO_DEFAULT"}
    result = any_of_from_json_schema(data, definitions=None)
    assert expected == result



# Generated at 2022-06-24 10:55:12.637727
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "string"
    }

    schema = type_from_json_schema(data, None)
    assert "{'type': 'string'}" == str(schema)

    data = {
        "type": ["string", "null"]
    }

    schema = type_from_json_schema(data, None)
    assert '{(\'type\': "string") | (Const(None))}' == str(schema)

    data = {
        "type": ["string", "integer"]
    }

    schema = type_from_json_schema(data, None)
    assert '{(\'type\': "string") | (\'type\': "integer")}' == str(schema)



# Generated at 2022-06-24 10:55:19.707222
# Unit test for function get_valid_types
def test_get_valid_types():
    # Empty type
    type_strings, allow_null = get_valid_types({})
    assert type_strings == {"null", "boolean", "object", "array", "number", "string"}
    assert allow_null is True

    # String type
    type_strings, allow_null = get_valid_types({"type": "null"})
    assert type_strings == set()
    assert allow_null is True

    type_strings, allow_null = get_valid_types({"type": "null", "nullable": True})
    assert type_strings == set()
    assert allow_null is True

    type_strings, allow_null = get_valid_types({"type": "null", "nullable": False})
    assert type_strings == set()
    assert allow_null is False

    type_strings, allow_null

# Generated at 2022-06-24 10:55:20.444690
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert True



# Generated at 2022-06-24 10:55:30.885140
# Unit test for function get_valid_types
def test_get_valid_types(): 
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)

# Generated at 2022-06-24 10:55:41.570647
# Unit test for function to_json_schema
def test_to_json_schema():
    validator = Schema({
        "name": String(min_length=3, max_length=20),
        "age": Integer(minimum=0, multiple_of=3),
    })
    schema = to_json_schema(validator)
    assert schema == {
        'properties': {
            'age': {
                'type': 'integer',
                'multipleOf': 3,
                'minimum': 0
            },
            'name': {
                'type': 'string',
                'minLength': 3,
                'maxLength': 20
            }
        }
    }

# Generated at 2022-06-24 10:55:47.592997
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer()) == {}
    assert get_standard_properties(Integer(default=42)) == {"default": 42}
    assert get_standard_properties(Integer(default=NO_DEFAULT, nullable=True)) == {}
    assert get_standard_properties(Integer(default=42, nullable=True)) == {"default": 42}

# Generated at 2022-06-24 10:55:53.157279
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#foo'}, definitions={}), Reference)
    assert isinstance(
        ref_from_json_schema({'$ref': '#foo'}, definitions={'#foo': Any()}), Any
    )



# Generated at 2022-06-24 10:56:04.976733
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover
    assert from_json_schema_type(data={"type": "number"}, type_string="number", allow_null=False, definitions=SchemaDefinitions()) == Float()
    assert from_json_schema_type(data={"type": "integer"}, type_string="integer", allow_null=False, definitions=SchemaDefinitions()) == Integer()
    assert from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=SchemaDefinitions()) == String()
    assert from_json_schema_type(data={"type": "boolean"}, type_string="boolean", allow_null=False, definitions=SchemaDefinitions()) == Boolean()

# Generated at 2022-06-24 10:56:17.826517
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": None}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": []}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": ["string", "integer"]}) == ({'integer', 'string'}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null", "string"]}) == ({'string'}, True)

# Generated at 2022-06-24 10:56:20.093051
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1}, None).to_primitive() == {
        "const": 1
    }



# Generated at 2022-06-24 10:56:27.255742
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"if": {"type": "string", "minLength": 5}, "then": {"const": 5}}

    field = if_then_else_from_json_schema(data, SchemaDefinitions())

    assert isinstance(field, IfThenElse)
    assert isinstance(field.then_clause, Const)
    assert field.then_clause.clause == 5



# Generated at 2022-06-24 10:56:39.393482
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, definitions).class_name == "Integer"

    field = type_from_json_schema({"type": "number"}, definitions)
    assert isinstance(field, Float | Decimal)
    assert field.class_name == "Union"

    valid_types = (
        {"type": "string"},
        {"type": "boolean"},
        {"type": ["null"]},
        {"type": ["number", "null"]},
        {"type": ["number", "string"]},
    )
    for schema in valid_types:
        assert type_from_json_schema(schema, definitions)


# Generated at 2022-06-24 10:56:43.514194
# Unit test for function get_valid_types
def test_get_valid_types():
    # case: no type is given
    result = get_valid_types({})
    assert result == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    # case: type is given
    result = get_valid_types({'type': 'string'})
    assert result == ({'string'}, False)
    # case: null is given as type
    result = get_valid_types({'type': 'null'})
    assert result == (set(), True)



# Generated at 2022-06-24 10:56:50.644468
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf":[{"type":"string"}, {"type":"integer"}]}
    str_or_int = any_of_from_json_schema(schema, definitions=None)
    assert str_or_int.validate("abc") is None
    assert str_or_int.validate(123) is None
    assert str_or_int.validate(123.4) is not None
    assert str_or_int.validate(None) is not None
    


# Generated at 2022-06-24 10:56:51.729248
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Field(default=1)
    assert get_standard_properties(field) == {"default": 1}


# Generated at 2022-06-24 10:57:02.121111
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema(): # pragma: no cover
    schema_for_then_clause = {'type': 'integer'}
    schema_for_else_clause = {'type': 'string'}
    schema_for_if_clause = {'type': 'string', 'enum': ['go']}
    schema = {
        'if': schema_for_if_clause,
        'then': schema_for_then_clause,
        'else': schema_for_else_clause
    }
    def if_then_else(x):
        if x == 'go':
            return 5
        else:
            return 'five'
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert field.default == NO_DEFAULT
    assert field.validate(None) is error_type

# Generated at 2022-06-24 10:57:05.361809
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default=0)) == {"default": 0}



# Generated at 2022-06-24 10:57:17.678466
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    _all_of_from_json_schema = all_of_from_json_schema

    # successful run
    assert(_all_of_from_json_schema({
        "allOf": [
            {
                "type": "number",
                "minimum": 100
            },
            {
                "type": "number",
                "maximum": 200
            }
        ],
        "default": 50
    }, SchemaDefinitions()) == AllOf(all_of=[
        Float(minimum=100),
        Float(maximum=200)
    ], default=50))
    # failed run

# Generated at 2022-06-24 10:57:26.923715
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    def check(json_schema, field):
        schema = from_json_schema(json_schema)
        result = Field.from_json(schema.to_json())
        assert isinstance(result, AllOf)
        assert result.all_of == field.all_of

    json_schema = {
      "allOf": [
        {
          "type": "integer"
        },
        {
          "maximum": 10
        }
      ]
    }
    field = AllOf(all_of=[Integer(), Integer(maximum=10)])
    check(json_schema, field)


# Generated at 2022-06-24 10:57:34.996624
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    def validate_value(value, field):
        assert field.validate(value) == value
        assert value in field.get_choices(value)

    # test string types
    # type: string
    field = type_from_json_schema({"type": "string"})
    validate_value("string", field)
    # type: string, allow null
    field = type_from_json_schema({"type": ["string", "null"]})
    validate_value("string", field)
    validate_value(None, field)
    # type: union, string, integer
    field = type_from_json_schema({"type": ["string", "integer"]})
    validate_value("string", field)
    validate_value(123, field)
    # type: union, string, integer, allow null
    field

# Generated at 2022-06-24 10:57:38.173273
# Unit test for function ref_from_json_schema

# Generated at 2022-06-24 10:57:48.658108
# Unit test for function not_from_json_schema
def test_not_from_json_schema():

    data = {
        "not": {
            "anyOf": [
                {"type": "string", "minLength": 1},
                {"type": "string", "maxLength": 0},
            ]
        }
    }

    def to_string(field):
        return json.dumps(field.to_json_schema())

    negated = from_json_schema(data)
    assert to_string(negated) == """"not": {
    "anyOf": [
        {"minLength": 1, "type": "string"},
        {"maxLength": 0, "type": "string"}
    ]
}"""



# Generated at 2022-06-24 10:57:51.590655
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(minimum=1)



# Generated at 2022-06-24 10:57:53.770308
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from typesystem.fields import Reference, SchemaDefinitions
    definitions = SchemaDefinitions({"#/foo": Integer(minimum=0)})
    assert ref_from_json_schema({"$ref": "#/foo"}, definitions=definitions) == Reference("#/foo", definitions=definitions)



# Generated at 2022-06-24 10:57:54.954565
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="foo")) == {"default": "foo"}

# Generated at 2022-06-24 10:57:57.611036
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_field = const_from_json_schema({'const':1},definitions=definitions)
    # We expect that it is a const field for value of 1
    assert(isinstance(const_field,Const))
    assert(const_field.const==1)


# Generated at 2022-06-24 10:58:03.526222
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    guido_schema = {
        "not": {
            "allOf": [
                {
                  "properties": {
                    "name": {
                      "type": "string"
                    }
                  },
                  "type": "object"
                },
                {
                  "properties": {
                    "name": {
                      "pattern": "^Guido$"
                    }
                  },
                  "type": "object"
                }
              ]
            }
        }
    assert not_from_json_schema(guido_schema, definitions={}) == Not(
        AllOf(
            [
                Object(properties={
                    "name": String()
                }),
                Object(properties={
                    "name": String(pattern="^Guido$")
                })
            ]
        )
    )



# Generated at 2022-06-24 10:58:07.403354
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert (
        str(
            ref_from_json_schema(data={"$ref": "#/definitions/Blah"}, definitions={})
        )
        == "Reference(to='#/definitions/Blah')"
    )



# Generated at 2022-06-24 10:58:12.536100
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"type": "string"}}
    result = not_from_json_schema(schema, definitions=None)

    assert result.validates(None)
    assert result.validates(True)
    assert result.validates(1)
    assert result.validates("")
    assert result.validates([])
    assert result.validates({})
    assert not result.validates("foo")


# Generated at 2022-06-24 10:58:20.534591
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [String(), Integer()]}
    assert any_of_from_json_schema(data, definitions=definitions).check_type("5")
    assert not any_of_from_json_schema(data, definitions=definitions).check_type(5)
    assert not any_of_from_json_schema(data, definitions=definitions).check_type(None)
    assert any_of_from_json_schema(data, definitions=definitions).check_type("foo")



# Generated at 2022-06-24 10:58:30.009808
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from jsonschema import validate
    from typesystem.base import ValidationError

    field = enum_from_json_schema(
        data={"enum": ["red", "green", "blue"]}, definitions=definitions
    )
    assert field.validate("red") == "red"
    assert field.validate("green") == "green"
    assert field.validate("blue") == "blue"
    try:
        field.validate("purple")
    except ValidationError:
        pass
    else:
        assert False, "Expected an exception"



# Generated at 2022-06-24 10:58:40.252505
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from jsonschema import validate
    validate(get_standard_properties(String()),STRING_PROPERTIES)
    validate(get_standard_properties(Integer()),INTEGER_PROPERTIES)
    validate(get_standard_properties(Float()),FLOAT_PROPERTIES)
    validate(get_standard_properties(Decimal()),DECIMAL_PROPERTIES)
    validate(get_standard_properties(Boolean()),BOOLEAN_PROPERTIES)
    validate(get_standard_properties(Array(items=String())),ARRAY_PROPERTIES)
    validate(get_standard_properties(Object(properties={"name":String()})),OBJECT_PROPERTIES)
test_get_standard_properties()


# Generated at 2022-06-24 10:58:50.465791
# Unit test for function get_valid_types

# Generated at 2022-06-24 10:59:01.889489
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({"type" : "string"}), String)
    assert isinstance(from_json_schema({"type" : "number"}), Number)
    assert isinstance(from_json_schema({"type" : "integer"}), Integer)
    assert isinstance(from_json_schema({"type" : "boolean"}), Boolean)
    assert isinstance(from_json_schema({"type" : "array"}), Array)
    assert isinstance(from_json_schema({"type" : "object"}), Object)
    assert from_json_schema({"type" : "number", "multipleOf" : 2}) == Number(multiple_of=2)

# Generated at 2022-06-24 10:59:04.411272
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"type": "string", "allOf": [{"type": "string"}]}
    actual = all_of_from_json_schema(data, definitions=None)
    expected = AllOf(all_of=[String()])
    assert actual == expected


# Generated at 2022-06-24 10:59:12.244709
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [1,2,3]}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)
    # result = one_of_from_json_schema(data, definitions)
    assert False



# Generated at 2022-06-24 10:59:14.944812
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({"anyOf": [{"const": "a string"}]}, SchemaDefinitions()),
                                Union)

