

# Generated at 2022-06-24 10:49:21.140826
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import (
        ANY,
        BOOLEAN,
        CHOICE,
        CONST,
        INTEGER,
        NUMBER,
        OBJECT,
        STRING,
        UNION,
    )
    from typesystem.schemas import Reference

    data = {
        "type": "string",
        "minLength": 10,
        "maxLength": 20,
        "pattern": "^[a-zA-Z]+$",
    }
    field = from_json_schema(data)
    assert isinstance(field, STRING)
    assert field.min_length == 10
    assert field.max_length == 20
    assert isinstance(field.pattern, type(re.compile("")))


# Generated at 2022-06-24 10:49:30.584960
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type':[]}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type':'null'}) == (set(), True)
    assert get_valid_types({'type': [1,2,3]}) == ({'array', 'string', 'integer', 'number', 'object', 'boolean'}, False)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': ['integer', 'null']}) == ({'null', 'integer'}, True)
    assert get_valid_types

# Generated at 2022-06-24 10:49:44.377245
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer", "atLeast": 10},
            {"type": "integer", "atLeast": 25},
            {"type": "integer", "atLeast": 50},
        ]
    }
    definitions = SchemaDefinitions()
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)

    assert definitions == {}
    assert type(definitions) == SchemaDefinitions

    assert data["oneOf"][0]["type"] == "integer"
    assert data["oneOf"][0]["atLeast"] == 10


# Generated at 2022-06-24 10:49:47.421904
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    data = {"oneOf" : [
            {"type":"string"},
            {"type":"number"},
            {"type":"integer"}
            ]}
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data,definitions)[2].minimum == 0



# Generated at 2022-06-24 10:49:52.827682
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer"},
            {"const": 5},
            {"type": "string", "format": "date-time"},
            {"const": "foo"},
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, OneOf)
    assert field.default == NO_DEFAULT
    assert isinstance(field.one_of[0], Integer)
    assert isinstance(field.one_of[1], Const)
    assert isinstance(field.one_of[2], String)
    assert isinstance(field.one_of[3], Const)

    assert field.one_of[0].allow_null is False

# Generated at 2022-06-24 10:49:59.364629
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String(allow_blank=True)
    assert from_json_schema_type({}, type_string="array", allow_null=False, definitions=None) == Array(allow_blank=True)
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object(allow_blank=True)
    assert from_json_schema_type({}, type_string="integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()

# Generated at 2022-06-24 10:50:04.094415
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema_1 = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "title": {"type": "string"},
                    "authors": {
                        "type": "array",
                        "items": {"type": "string"}
                    }
                },
                "additionalProperties": False,
                "required": ["title", "authors"]
            },
            {"$ref": "#/definitions/Book"},
            {
                "allOf": [
                    {"$ref": "#/definitions/CreativeWork"},
                    {
                        "type": "object",
                        "properties": {
                            "isbn": {"type": "string"}
                        },
                        "additionalProperties": False
                    }
                ]
            }
        ]
    }
    schema_2 = AllOf

# Generated at 2022-06-24 10:50:11.872152
# Unit test for function to_json_schema
def test_to_json_schema():  # pragma: no cover
    import pytest

    from .test_fields import (
        model_a,
        model_b,
        model_c,
        model_d,
        model_e,
        model_f,
        model_g,
        model_h,
        model_i,
        model_j,
        model_k,
        model_l,
        model_m,
        model_n,
        model_o,
        model_p,
        model_q,
        model_r,
    )
    from .test_schema_definitions import schema_definitions

    def check_json_schema(arg):
        schema = to_json_schema(arg)
        exact_schema = to_json_schema(arg, {})

# Generated at 2022-06-24 10:50:22.991986
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": ["number"],
        "minimum": 2,
        "maximum": 5,
        "exclusiveMinimum": 1,
        "exclusiveMaximum": 3,
        "multipleOf": 2,
        "default": 1,
    }

    field = from_json_schema_type(
        data=data, type_string="object", allow_null=False, definitions=None
    )
    assert field.schema == {
        'type': 'object',
        'properties': None,
        'patternProperties': None,
        'additionalProperties': None,
        'propertyNames': None,
        'minProperties': None,
        'maxProperties': None,
        'required': None,
        'default': 1,
    }
    assert field.kwargs == {'allow_null': False}

# Generated at 2022-06-24 10:50:33.741325
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        foo = String()
        bar = Integer()
        baz = Boolean()
        bat = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
        bee = Object(properties={"sub1": Integer(), "sub2": Choice(choices=["a", "b", "c"])})

    schema = TestSchema()
    data = to_json_schema(schema)

# Generated at 2022-06-24 10:50:41.597604
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": "boolean"}), Boolean)
    assert isinstance(from_json_schema({"type": "integer"}), Integer)
    assert isinstance(from_json_schema({"type": "number"}), Number)
    assert isinstance(from_json_schema({"type": "object"}), Object)
    assert isinstance(from_json_schema({"type": "array"}), Array)
    assert isinstance(from_json_schema({"type": ["string", "null"]}), Choice)
    assert isinstance(from_json_schema({"type": ["string", "boolean"]}), Union)

# Generated at 2022-06-24 10:50:47.427409
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert any([type(from_json_schema_type({}, "null", False, {})) is Any])
    assert any([type(from_json_schema_type({}, "boolean", False, {})) is Boolean])
    assert any([type(from_json_schema_type({'items': {}}, "array", False, {})) is Array])
    assert any([type(from_json_schema_type({}, "object", False, {})) is Object])
    assert any([type(from_json_schema_type({}, "string", False, {})) is String])
    assert any([type(from_json_schema_type({}, "number", False, {})) is Number])
    assert any([type(from_json_schema_type({}, "integer", False, {})) is Integer])



# Generated at 2022-06-24 10:50:50.778963
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
  assert const_from_json_schema({"const": 4}, None).to_primitive() == {"type": "const", "const": 4}


# Generated at 2022-06-24 10:50:53.077445
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 'abc'}, definitions=definitions)=={'const': 'abc'}



# Generated at 2022-06-24 10:50:57.111203
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"$ref": "#/definitions/Product"}) == Reference("Product")
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": ["string", "null"]}) == Union(fields=[String(), None])



# Generated at 2022-06-24 10:51:01.604133
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data_list = [
        ({'default': 'default 1'}, {'default': 'default 1'}),
        ({}, {}),
    ]
    for data_tuple in data_list:
        data_dict, result_dict = data_tuple
        standard_properties = get_standard_properties(field=data_dict)
        assert standard_properties == result_dict

# Generated at 2022-06-24 10:51:11.953648
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    test_data = {
        "if": {
            "type": "object",
            "properties": {
                "c": {"type": "integer"},
                "d": {"type": "integer"},
            },
            "required": ["c"],
        },
        "then": {"type": "integer"},
        "else": {"type": "number"},
    }

    field = if_then_else_from_json_schema(test_data, {})
    field.validate({"d": 0.5, "c": 1})
    with pytest.raises(ValidationError):
        field.validate({"c": "string"})

    field.validate({"d": 0.5, "c": 1})

# Generated at 2022-06-24 10:51:15.001802
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(required=False)) == {}
    assert get_standard_properties(String(required=False, default="test")) == {
        "default": "test"
    }
    assert get_standard_properties(String(required=True, default="test")) == {
        "default": "test"
    }
    assert get_standard_properties(String(required=True)) == {}
    assert get_standard_properties(String(required=True, default=NO_DEFAULT)) == {}



# Generated at 2022-06-24 10:51:19.836534
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        name = String(max_length=100)
        age = Integer(minimum=0, max_length=100)
        addresses = Array(String(max_length=100), max_items=5)
        is_active = Boolean(default=True)

    assert to_json_schema(MySchema()) == {
        "properties": {
            "name": {"type": "string", "maxLength": 100},
            "age": {"type": "integer", "minimum": 0, "maximum": 100},
            "addresses": {
                "type": "array",
                "items": {"type": "string", "maxLength": 100},
                "maxItems": 5,
            },
            "is_active": {"type": "boolean", "default": True},
        }
    }

# Generated at 2022-06-24 10:51:26.581964
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean"]}) == ({"boolean"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null"]}) == (set(), True)
    assert get_valid_types({"type": "null", "type": ["boolean"]}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object", "type": "null"}) == ({"object"}, True)
    assert get_valid_types({"type": "null", "type": "null"}) == (set(), True)

# Generated at 2022-06-24 10:51:32.932211
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/some/path/to/schema"}
    ref = ref_from_json_schema(data, definitions)
    assert str(ref) == "Reference(to='#/some/path/to/schema')"
    with definitions:
        definitions["#/some/path/to/schema"] = "MyType"
    assert ref.to_python("foo") == "foo"
    assert ref.validate("foo") is None



# Generated at 2022-06-24 10:51:36.791788
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json = {"if": {"type": "string"}, "then": {"const": "Hello!"}}
    field = if_then_else_from_json_schema(json, None)
    assert field.validate("Hello").is_valid

# Generated at 2022-06-24 10:51:48.836067
# Unit test for function to_json_schema
def test_to_json_schema():
    from tests.utils import get_json_from_schema_file
    from vali import from_file, SchemaDefinitions
    from vali.field import String, Integer, Float, Decimal, Boolean, Array, Object, Reference
    from vali.field import String, Integer, Float, Decimal, Boolean, Array, Object

    def test_to_json_schema_from_file(self, file_name: str):
        assert file_name.endswith(".schema.json")
        schema = from_file(file_name)
        schema_json = get_json_from_schema_file(file_name)
        actual = to_json_schema(schema)
        self.assertEqual(actual, schema_json)


# Generated at 2022-06-24 10:51:53.575139
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["my_ref"] = String()
    data = {"$ref": "#/my_ref"}
    field = ref_from_json_schema(data, definitions=definitions)
    assert type(field) is Reference
    assert field.to == "#/my_ref"
    assert field.definitions == definitions



# Generated at 2022-06-24 10:51:55.569392
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert False
# End unit test



# Generated at 2022-06-24 10:52:00.522413
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    choices = [
        {"type": "string", "enum": ["red", "amber", "green"]},
        {"$ref": "#/definitions/traffic_light_color"},
    ]
    for choice in choices:
        enum_field = enum_from_json_schema(choice, None)
        color_field = from_json_schema(choice, None)
        assert color_field == enum_field



# Generated at 2022-06-24 10:52:09.496791
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type": ["any"]}
    type_set, allow_null = get_valid_types(data)
    assert type_set == set(["boolean", "object", "array", "number", "string"])
    assert allow_null == True

    data = {"type": ["any", "null"]}
    type_set, allow_null = get_valid_types(data)
    assert type_set == set(["boolean", "object", "array", "number", "string"])
    assert allow_null == True

    data = {"type": ["number", "null"]}
    type_set, allow_null = get_valid_types(data)
    assert type_set == set(["number"])
    assert allow_null == True



# Generated at 2022-06-24 10:52:18.461370
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "null"
    }
    schema = type_from_json_schema(data, definitions=None)
    assert schema.serialize(None) == None
    assert schema.serialize("abc") != None

    data = {
        "type": "null",
        "const": "x"
    }
    schema = type_from_json_schema(data, definitions=None)
    assert schema.serialize("x") == "x"
    assert schema.serialize(None) != None
test_type_from_json_schema()



# Generated at 2022-06-24 10:52:22.133119
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref = ref_from_json_schema(
        data={"$ref": "#/definitions/MyRef"}, definitions=definitions
    )
    assert isinstance(ref, Reference)
    assert ref.to == "#/definitions/MyRef"



# Generated at 2022-06-24 10:52:25.144607
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/ref"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/ref"] = Field(allow_null=False)
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/ref"



# Generated at 2022-06-24 10:52:28.092577
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({'$ref': '#/definitions/Foo'}, definitions={'#/definitions/Bar': Any(), '#/definitions/Foo': String()}) == String()



# Generated at 2022-06-24 10:52:36.660350
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":[{"type":"number"},{"type":"integer"}]}
    schema = any_of_from_json_schema(data=data)
    assert (schema(1) == True)
    assert (schema(1.0) == True)
    assert (schema(0) == True)
    assert (schema(0.0) == True)
    assert (schema(0.001) == True)
    assert (schema(0.0015) == True)
    assert (schema(0.00149) == True)
    assert (schema(None) == False)
    assert (schema("1.0") == False)
    assert (schema("0.0") == False)
    assert (schema("true") == False)
    assert (schema("false") == False)

# Generated at 2022-06-24 10:52:40.282787
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": 1})
    assert field.validate(1)
    assert not field.validate(2)
    assert field.default == 1



# Generated at 2022-06-24 10:52:48.002128
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {
                "type": "number",
                "minimum": 5
            },
            {
                "type": "number",
                "maximum": 10
            }
        ]
    }
    actual = any_of_from_json_schema(data, definitions=None)
    expected = Union(any_of=[
        Integer(minimum=5),
        Integer(maximum=10)
    ])
    assert actual == expected


# Generated at 2022-06-24 10:52:58.965713
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema",
        "type": "object",
        "definitions": {
            "price": {
                "type": "object",
                "properties": {"currency": {"type": "string"}, "value": {"type": "number"}},
                "enum": [{"currency": "EUR", "value": 1}, {"currency": "USD", "value": 2}],
            }
        },
        "properties": {"priceProp": {"$ref": "#/definitions/price"}},
    }

    field = from_json_schema(schema)
    result = field.validate({"priceProp": {"currency": "EUR", "value": 1}})

# Generated at 2022-06-24 10:53:10.842969
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "type": [
            "null",
            "boolean"
        ]
    }

    type_strings = data.get("type", [])
    if isinstance(type_strings, str):
        type_strings = {type_strings}
    else:
        type_strings = set(type_strings)

    if not type_strings:
        type_strings = {"null", "boolean", "object", "array", "number", "string"}

    if "number" in type_strings:
        type_strings.discard("integer")

    allow_null = False
    if "null" in type_strings:
        allow_null = True
        type_strings.remove("null")

    assert type_strings == {'boolean'}
    assert allow_null == True


# Generated at 2022-06-24 10:53:13.318123
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({
            "$ref": "#/definitions/MyRef"
        }) == Reference(to="#/definitions/MyRef", definitions=None)



# Generated at 2022-06-24 10:53:23.011996
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "pattern": "^patron$"
        },
        "then": {
            "type": "string",
            "pattern": "^book$"
        },
        "else": {
            "type": "number"
        },
        "default": 3.14
    }

    field = if_then_else_from_json_schema(data, None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, String)
    assert field.if_clause.pattern == data["if"]["pattern"]
    assert isinstance(field.then_clause, String)
    assert field.then_clause.pattern == data["then"]["pattern"]

# Generated at 2022-06-24 10:53:31.780775
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "null", True, None) == Const(None)
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array(items=Any())
    assert from_json_schema_type({}, "object", False, None) == Object(properties={})



# Generated at 2022-06-24 10:53:39.713277
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert not enum_from_json_schema({"enum": []}).is_valid(None), "Fail, empty"
    assert enum_from_json_schema({"enum": ["a"]}).is_valid("a"), "Fail, matches"
    assert not enum_from_json_schema({"enum": ["a"]}).is_valid("b"), "Fail, mismatches"
    assert enum_from_json_schema({"enum": ["a"], "default": "a"}).is_valid(None), "Fail, default"



# Generated at 2022-06-24 10:53:49.529823
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.schema import OneOf
    from typing import Union
    from typesystem.fields import String
    import typesystem
    import requests
    import json
    import pathlib
    p = pathlib.Path(typesystem.__file__).parent / "examples/json-schema.json"
    with open(p, "r") as f:
        schema = json.load(f)
    data = json.loads(requests.get(schema["id"]).text)
    test_data = data["properties"]["streetAddress"]["oneOf"]
    assert isinstance(one_of_from_json_schema(test_data[0], typesystem.schemas.SchemaDefinitions()), Union)



# Generated at 2022-06-24 10:53:59.248369
# Unit test for function get_valid_types
def test_get_valid_types():
    for key in ('string', 'boolean', 'null', 'object', 'array', 'integer', 'number'):
        print(key)
        type_strings, allow_null = get_valid_types({'type': key})
        print("type_strings: ", type_strings)
        print("allow_null:", allow_null)
        print("")

    print("null and string")
    type_strings, allow_null = get_valid_types({'type': ['null', 'string']})
    print("type_strings: ", type_strings)
    print("allow_null:", allow_null)
    print("")

    print("['string', 'integer', 'boolean', 'null']")

# Generated at 2022-06-24 10:54:08.473132
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:54:17.506791
# Unit test for function to_json_schema
def test_to_json_schema():
    schema: SchemaDefinitions = {
        "Node": {"type": "object", "properties": {"name": {"type": "string"}}},
        "Branch": {"allOf": [{"$ref": "#/definitions/Node"}, {"properties": {}}]},
        "Leaf": {"allOf": [{"$ref": "#/definitions/Node"}, {"properties": {}}]},
    }

# Generated at 2022-06-24 10:54:28.787460
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True).validate("foo") == "foo"
    assert from_json_schema(False).validate("foo") == "must be False"
    assert from_json_schema({"type": "boolean"}).validate("foo") == "must be a boolean"
    assert from_json_schema({"type": "boolean"}).validate(True) is True
    assert from_json_schema({"type": "boolean"}).validate(False) is False

VALID_TYPE_VALUES = {
    "integer": Integer,
    "number": Number,
    "string": String,
    "boolean": Boolean,
    "object": Object,
    "array": Array,
    "null": Const(value=None, default=NO_DEFAULT),
}




# Generated at 2022-06-24 10:54:37.887111
# Unit test for function from_json_schema

# Generated at 2022-06-24 10:54:45.622850
# Unit test for function to_json_schema
def test_to_json_schema():
    def assert_to_json_schema(field: Field, expected: typing.Any):
        actual = to_json_schema(field)
        assert actual == expected, pformat(actual)

    # TODO: test all the other fields
    assert_to_json_schema(
        String(min_length=1, max_length=10, pattern_regex=re.compile("^[A-Za-z]+$")),
        {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": "^[A-Za-z]+$",
        }
    )


# Generated at 2022-06-24 10:54:51.171314
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {"allOf": [{"maximum": 3}, {"minimum": 0}]}
    field = all_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert field.validate(1) == 1
    assert field.validate(-1) == -1
    assert field.default == "1"



# Generated at 2022-06-24 10:54:57.095225
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_data = {'oneOf': [{'$ref': '#/definitions/simpleNumber'},
                           {'type': 'string'}],
                 'definitions': {'simpleNumber': {'type': 'number', 'minimum': 1, 'maximum': 5}}}
    s = one_of_from_json_schema(test_data, definitions)
    print(s)



# Generated at 2022-06-24 10:55:02.316857
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:55:12.241527
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:55:26.194343
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """Test type_from_json_schema"""
    assert type_from_json_schema(
        {
            "type": "string",
        },
        definitions=None
    ) == String()
    assert type_from_json_schema(
        {
            "type": "string",
            "maxLength": 2,
        },
        definitions=None
    ) == String(max_length=2)
    assert type_from_json_schema(
        {
            "type": "string",
            "minLength": "2",
        },
        definitions=None
    ) == String(min_length=2)
    assert type_from_json_schema(
        {
            "type": "number",
        },
        definitions=None
    ) == Number()
    assert type_from_json_sche

# Generated at 2022-06-24 10:55:34.681953
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import Integer, String, Float, Boolean, Array, Object

    data = {
        "type": "string",
        "minLength": 10,
        "maxLength": 20,
        "default": "",
    }
    assert from_json_schema_type(data, type_string="string", allow_null=False, definitions=None) == String(
        allow_null=False,
        allow_blank=False,
        min_length=10,
        max_length=20,
        format=None,
        pattern=None,
        default="",
    )

# Generated at 2022-06-24 10:55:42.818707
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_data = {'const': 'value', 'default':'value'}
    assert const_from_json_schema(const_data)
    const_data['const'] = 'val'
    assert not const_from_json_schema(const_data)
    const_data['const'] = ''
    assert const_from_json_schema(const_data)
    const_data['default'] = 'val'
    assert not const_from_json_schema(const_data)
    const_data['const'] = 'val'
    assert not const_from_json_schema(const_data)
    const_data['const'] = 'value'
    assert const_from_json_schema(const_data)
    const_data['default'] = ''

# Generated at 2022-06-24 10:55:51.329538
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema = {
        "type": ["null", "string"],
        "minLength": 1,
        "maxLength": 4,
        "pattern": "s",
        "format": "email",
    }
    field = from_json_schema(json_schema)
    assert isinstance(field, Union)
    assert isinstance(field.any_of[0], String)
    assert field.any_of[0].allow_null



# Generated at 2022-06-24 10:56:00.948485
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_schema_object = {
        "oneOf": [{
                "const": [1, 2, 3]
            },
            {
                "const": True
            }
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(json_schema_object, definitions)
    assert field.to_dict() == {
        'oneOf': [{
            'const': True
        }, {
            'const': [1, 2, 3]
        }],
        'baseType': 'oneOf'
    }



# Generated at 2022-06-24 10:56:07.188838
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():

    assert AllOf(all_of=[Any(), Any()]) == all_of_from_json_schema({"allOf":[{},{}]}, definitions)
    assert AllOf(all_of=[Any(), Any()]) == all_of_from_json_schema({"allOf":[True, True]}, definitions)

    assert AllOf(all_of=[Any(), Any()], default=2) == all_of_from_json_schema({"allOf":[True, True], "default": 2}, definitions)



# Generated at 2022-06-24 10:56:13.590390
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # This unit test really belongs in fields.py.  It is here to document
    # the result of calling enum_from_json_schema.
    schema = {"enum": ["a", "b", "c"]}
    value = "a"
    field = enum_from_json_schema(schema, definitions=None)
    assert field.validate(value) == {"valid": True, "value": value}



# Generated at 2022-06-24 10:56:22.788373
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of_data = {
        "oneOf": [
            {"type": "integer", "not": {"const": 0}},
            {"type": "string"},
        ]
    }
    one_of_schema = one_of_from_json_schema(one_of_data, definitions=None)
    one_of_input = 1
    one_of_expected = 1
    one_of_actual = one_of_schema.validate(one_of_input)
    assert one_of_expected == one_of_actual, 'test_one_of_from_json_schema failed'



# Generated at 2022-06-24 10:56:31.249395
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    for x in range(2):
        if x == 1:
            default_value = {'const': 'foo', 'default': 'blah'}
        else:
            default_value = {'const': 'foo', 'default': 'foo'}
        my_actual_field = const_from_json_schema(default_value,SchemaDefinitions())
        my_correct_field = Const(const='foo',default='foo')
        assert (my_actual_field == my_correct_field)

# Generated at 2022-06-24 10:56:37.034609
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    enum_field = enum_from_json_schema(
        {"type": "string", "enum": ["spam", "eggs"]}, definitions=None
    )
    assert isinstance(enum_field, Choice)
    assert enum_field.choices == [("spam", "spam"), ("eggs", "eggs")]
# End unit test for function enum_from_json_schema



# Generated at 2022-06-24 10:56:38.880772
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()
test_from_json_schema()



# Generated at 2022-06-24 10:56:41.698434
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(default="A string")
    assert get_standard_properties(field) == {"default": "A string"}

    field = String()
    assert get_standard_properties(field) == {}


# Utility functions

# Generated at 2022-06-24 10:56:52.678039
# Unit test for function from_json_schema
def test_from_json_schema():
    # type: () -> None
    assert isinstance(from_json_schema({"type": "number"}), Number)
    assert isinstance(from_json_schema({"type": "integer"}), Integer)
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": "boolean"}), Boolean)
    assert isinstance(from_json_schema({"type": "object"}), Object)
    assert isinstance(from_json_schema({"type": "array"}), Array)

# Generated at 2022-06-24 10:56:59.480842
# Unit test for function from_json_schema
def test_from_json_schema():
    # the structure of json schema is a little more complicated than we
    # would ideally wish for, but it's a popular and well understood standard
    # so we do our best to import it and export it
    field = from_json_schema(
        {"type": "string", "enum": ["A", "B", "C"], "default": "A"}
    )
    assert field.default == "A"
    assert field.validate("A") == "A"
    assert field.validate("B") == "B"
    assert field.validate("C") == "C"
    assert field.validate("D") is None
    assert field.validate("A", validate=False) == "A"
    assert field.validate("D", validate=False) == "D"


# Generated at 2022-06-24 10:57:09.199156
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf":[{"type":"object","properties":{"a":{"type":"integer","minimum":1,"maximum":10}}},{"type":"object","properties":{"b":{"type":"integer"},"c":{"type":"integer"}}}]}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)

    if "$ref" in data:
        print('ref_from_json_schema')
        return ref_from_json_schema(data, definitions=definitions)

    constraints = []  # typing.List[Field]

# Generated at 2022-06-24 10:57:20.459274
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null="true", definitions={}) is Number(allow_null=True)
    assert from_json_schema_type({}, type_string="integer", allow_null=True, definitions={}) is Integer(allow_null=True)
    assert from_json_schema_type({}, type_string="string", allow_null=True, definitions={}) is String(allow_null=True, allow_blank=True)
    assert from_json_schema_type({}, type_string="boolean", allow_null=True, definitions={}) is Boolean(allow_null=True)

# Generated at 2022-06-24 10:57:25.754541
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    '''
    Tests the const_from_json_schema function to make sure that the
    function correctly converts from a json schema format into a typesystem
    const object. 
    '''
    type_ref = const_from_json_schema({'const': 'ref'}, {})
    assert type_ref._schema == 'ref'


# Generated at 2022-06-24 10:57:31.909790
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema(data={"const": "value"}, definitions={}) == Const(const="value")
    assert const_from_json_schema(data={"const": "value", "default": "default"}, definitions={}) == Const(const="value", default="default")
    assert const_from_json_schema(data={"const": "value", "default": "bar"}, definitions={}) == Const(const="value", default="bar")


# Generated at 2022-06-24 10:57:39.664372
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({"$ref": "#/definitions/string"}) == Reference(
        "#/definitions/string"
    )
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": ["null", "string"]}) == Union([String(), None])
    assert from_json_schema({"enum": []}) == NeverMatch()
    assert from_json_schema({"enum": [0]}) == Const(0)
    assert from_json_schema({"enum": [0, 1]}) == Choice([0, 1])

# Generated at 2022-06-24 10:57:45.578137
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # given
    data = {'enum': ['a', 'b']}
    # when
    field = enum_from_json_schema(data, definitions={})
    # then
    assert isinstance(field, Choice)
    assert field.choices == [('a', 'a'), ('b', 'b')]



# Generated at 2022-06-24 10:57:50.607942
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = (
        Object()
    )
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions)
    assert field.schema() == {"$ref": "#/definitions/foo"}



# Generated at 2022-06-24 10:57:53.848515
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref = ref_from_json_schema({"$ref": "#/foo"}, definitions={})
    assert ref.to == "#/foo"
    assert ref.definitions == {}
    assert ref.can_be_none is False



# Generated at 2022-06-24 10:57:56.397566
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data={'$ref': '#/definitions/Schema'}
    defs = {}
    result=ref_from_json_schema(data,defs)
    assert result == Reference(to='#/definitions/Schema')



# Generated at 2022-06-24 10:57:58.532048
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/abc"}), Reference)



# Generated at 2022-06-24 10:58:10.895185
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({}, definitions=SchemaDefinitions()), Any)
    assert isinstance(
        type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()), String
    )
    assert isinstance(
        type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()), Integer
    )
    assert isinstance(
        type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()), Number
    )
    assert isinstance(
        type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()), Const
    )

# Generated at 2022-06-24 10:58:19.442140
# Unit test for function get_standard_properties
def test_get_standard_properties():
    b0 = Boolean(default=False)
    assert get_standard_properties(b0) == {'default': False}
    b1 = Boolean(default=True)
    assert get_standard_properties(b1) == {'default': True}
    s0 = String(default='')
    assert get_standard_properties(s0) == {'default': ''}
    s1 = String(default='s1')
    assert get_standard_properties(s1) == {'default': 's1'}
    a0 = Array(default=[])
    assert get_standard_properties(a0) == {'default': []}
    a1 = Array(default=[1, 2, 3])
    assert get_standard_properties(a1) == {'default': [1, 2, 3]}

# Generated at 2022-06-24 10:58:27.422867
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
        "description": (
            "Field value must be a JSON-compatible integer, "
            "including the string '123'."
        ),
    }
    assert to_json_schema(Integer().minimum(0)) == {
        "type": "integer",
        "default": NO_DEFAULT,
        "description": (
            "Field value must be a JSON-compatible integer, including "
            "the string '123', and must be greater than or equal to 0."
        ),
        "minimum": 0,
    }


# Generated at 2022-06-24 10:58:39.013658
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    file = open('test.json')
    data = json.load(file)
    field = one_of_from_json_schema(data, definitions)
    assert isinstance(field, typesystem.Schema)
    assert isinstance(field, typesystem.fields.OneOf)
    assert field.one_of[0].one_of[0].multiple_of == 3
    assert field.one_of[0].one_of[1].pattern == "^[a-zA-Z0-9 ]*$"
    assert field.one_of[1].one_of[0].one_of[0].format == 'date'
    assert field.one_of[1].one_of[0].one_of[1].format == 'date-time'

# Generated at 2022-06-24 10:58:47.093630
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "type": "string",
            "maxLength": 3
        },
        "then": {
            "type": "boolean",
            "const": True
        },
        "else": {
            "type": "boolean",
            "const": False
        }
    }
    definitions = SchemaDefinitions()
    schema = if_then_else_from_json_schema(data, definitions=definitions)
    value, error = schema.validate("foobar")
    assert error is None
    assert value is False



# Generated at 2022-06-24 10:58:52.797014
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def test_if_then(data, expected):
        field = if_then_else_from_json_schema(data, definitions=None)
        assert field.if_clause.input_type == expected[0]
        assert field.if_clause.output_type == expected[1]
        assert field.then_clause.input_type == expected[2]
        assert field.then_clause.output_type == expected[3]
        assert field.else_clause is None

    def test_if_then_else(data, expected):
        field = if_then_else_from_json_schema(data, definitions=None)
        assert field.if_clause.input_type == expected[0]
        assert field.if_clause.output_type == expected[1]
        assert field.then_

# Generated at 2022-06-24 10:58:59.413777
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "number"},
        "default": "default value",
    }
    kwargs = {"default": data.get("default", NO_DEFAULT)}
    assert not_from_json_schema(data, definitions=definitions) == Not(negated=Float(**kwargs), **kwargs)
test_not_from_json_schema()



# Generated at 2022-06-24 10:59:06.811804
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for key, value in {
        "null": (None, True),
        "boolean": (False, False),
        "object": ({"foo": 1}, False),
        "array": ([1, 2, 3], False),
        "integer": (1, False),
        "number": (1.0, False),
        "string": ("foo", False),
    }.items():
        data = {"type": key}
        field = from_json_schema_type(data, type_string=key, allow_null=value[1], definitions=None)
        assert field.validate(value[0]) == value[0]
        assert field.validate(value[0]) is value[0]



# Generated at 2022-06-24 10:59:16.989568
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": ["null", "boolean"]}) == ({'boolean'}, True)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "number", "nullable": True}) == ({'number'}, True)

