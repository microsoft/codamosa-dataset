

# Generated at 2022-06-24 10:49:17.502131
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(
        Field(default="Foo")
    ) == {"default": "Foo"}



# Generated at 2022-06-24 10:49:28.668594
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:49:35.287828
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["string"]}) == ({"string"}, False)
    assert get_valid_types({"type": ["string", "null"]}) == ({"string"}, True)
    assert get_valid_types({"type": ["string", "string"]}) == ({"string"}, False)
    assert get_valid_types({"type": ["null", "null"]}) == (set(), True)
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)



# Generated at 2022-06-24 10:49:40.088375
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data={"not":{"type":"string"}}
    assert_that(not_from_json_schema(data,definitions),is_(type(Not(negated=String()))))



# Generated at 2022-06-24 10:49:44.999999
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': ['a', 'b', 'c']}) == Choice(
        choices=[('a', 'a'), ('b', 'b'), ('c', 'c')], allow_null=False
    )
    assert enum_from_json_schema({'enum': [1, 2, 3]}) == Choice(
        choices=[(1, 1), (2, 2), (3, 3)], allow_null=False
    )



# Generated at 2022-06-24 10:49:50.593473
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    all_of_data = {
        'allOf': [
            {'type': 'object'},
            {'$ref': '#/definitions/Person'}
        ]
    }
    definitions = SchemaDefinitions()
    definitions["Person"] = Any()
    all_of = from_json_schema(all_of_data, definitions)
    assert isinstance(all_of, AllOf)
    assert all_of.all_of == [Any()]



# Generated at 2022-06-24 10:49:52.668456
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    test_schema = {
        "const":"test"
    }
    test_field = const_from_json_schema(test_schema, None)
    assert test_field.validate_const("test") == None


# Generated at 2022-06-24 10:49:59.201058
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "boolean", False, None) == Boolean(allow_null=False)
    assert from_json_schema_type({}, "boolean", True, None) == Boolean(allow_null=True)
    assert from_json_schema_type({}, "integer", False, None) == Integer(allow_null=False)
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)
    assert from_json_schema_type({}, "number", False, None) == Float(allow_null=False)
    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)

# Generated at 2022-06-24 10:50:09.269376
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
        any_of_as_dict = {"anyOf": [{"type": "integer"}, {"type": "string"}]}
        any_of_field = any_of_from_json_schema(any_of_as_dict, definitions=definitions)
        assert(any_of_field.validate(1) == 1)
        assert(any_of_field.validate("hello") == "hello")
        assert(any_of_field.validate(None) == None)
        assert(any_of_field.validate(1.0) == "Value must be an integer.")
        assert(any_of_field.validate(True) == "Value must be an integer or string.")
        

# Generated at 2022-06-24 10:50:12.430631
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=None) == Float()



# Generated at 2022-06-24 10:50:23.341282
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    json_schema = """
    {
       "$schema": "http://json-schema.org/draft-07/schema#",
       "type": "object",
       "properties": {
          "name": {
             "type": "string",
             "minLength": 1
          }
       },
       "required": [
          "name"
       ]
    }
    """
    json_schema = json.loads(json_schema)

    definitions = SchemaDefinitions()
    field = from_json_schema(json_schema, definitions=definitions)

    assert isinstance(field, Object)
    assert len(field.properties) == 1
    assert isinstance(field.properties["name"], String)
    assert field.required == ["name"]
    

# Generated at 2022-06-24 10:50:34.339531
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        "$ref": "#/definitions/Test",
    }) == Reference("#/definitions/Test")

    assert from_json_schema({
        "$ref": "#/definitions/Test",
        "type": "boolean",
    }) == Reference("#/definitions/Test")

    assert from_json_schema({
        "type": "string",
    }) == String()

    assert from_json_schema({
        "type": "array",
        "items": {
            "type": "string",
        },
    }) == Array(items=String())


# Generated at 2022-06-24 10:50:42.537591
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from pytest import raises

    # Build a JSON schema object and pass it to from_json_schema_type
    line = ""
    with raises(AssertionError):
        from_json_schema_type({"type": "foo"}, type_string="foo")

    # Build a JSON schema object and pass it to from_json_schema_type
    line = "{{'type': 'integer'}}"
    field = from_json_schema_type(eval(line), type_string="integer")
    assert field.default == NO_DEFAULT

    line = "{{'type': 'integer', 'default': 42}}"
    field = from_json_schema_type(eval(line), type_string="integer")
    assert field.default == 42



# Generated at 2022-06-24 10:50:47.195727
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict = {
        'oneOf': [{
            '$ref': 'anything'
        }, {
            'type': 'integer'
        }]
    }
    assert isinstance(one_of_from_json_schema(dict, definitions=definitions), OneOf)



# Generated at 2022-06-24 10:50:49.497470
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/JSONSchema"}
    result = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/JSONSchema"



# Generated at 2022-06-24 10:51:00.325644
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({"oneOf": [{"$ref":"#/oneOf/0"}, {"$ref":"#/oneOf/1"}]}, SchemaDefinitions()).validate(0)
    assert one_of_from_json_schema({"oneOf": [{"$ref":"#/oneOf/0"}, {"$ref":"#/oneOf/1"}]}, SchemaDefinitions()).validate(1)
    assert not one_of_from_json_schema({"oneOf": [{"$ref":"#/oneOf/0"}, {"$ref":"#/oneOf/1"}]}, SchemaDefinitions()).validate(2)

# Generated at 2022-06-24 10:51:10.641635
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema={"enum":["abc","def"]}
    choices = [(item, item) for item in schema["enum"]]
    assert enum_from_json_schema(schema, definitions)==Choice(choices=[('abc', 'abc'), ('def', 'def')])
    schema={"enum":["abc","def"],"default":"def"}
    choices = [(item, item) for item in schema["enum"]]
    assert enum_from_json_schema(schema, definitions)==Choice(default='def', choices=[('abc', 'abc'), ('def', 'def')])
test_enum_from_json_schema()


# Generated at 2022-06-24 10:51:17.367472
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema(
        {"if": {"type": "string"}, "then": {"type": "string"}, "else": {"type": "string"}},
        SchemaDefinitions()
    ), IfThenElse)
    assert isinstance(if_then_else_from_json_schema(
        {"if": {"type": "string"}, "else": {"type": "string"}},
        SchemaDefinitions()
    ), IfThenElse)
    assert isinstance(if_then_else_from_json_schema(
        {"if": {"type": "string"}, "then": {"type": "string"}},
        SchemaDefinitions()
    ), IfThenElse)



# Generated at 2022-06-24 10:51:25.542380
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.fields import Integer, Object, String

    # Test None type.
    data = {"type": "null"}

    field = from_json_schema(data)
    assert isinstance(field, Const)
    assert field.value is None

    # Test integer type.
    data = {"type": "integer", "minimum": 0, "maximum": 100}

    field = from_json_schema(data)
    assert isinstance(field, Integer)
    assert field.minimum == 0
    assert field.maximum == 100

    # Test number type.
    data = {"type": "number", "minimum": 0, "maximum": 100}

    field = from_json_schema(data)
    assert isinstance(field, Float)
    assert field.minimum == 0
    assert field.maximum == 100

    # Test string type.

# Generated at 2022-06-24 10:51:28.939543
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({}, definitions=None), Any)
    assert isinstance(
        type_from_json_schema({"type": "string"}, definitions=None), String
    )



# Generated at 2022-06-24 10:51:38.483393
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "null"}) == ({'null'}, True)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "object"}) == ({'object'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)

# Generated at 2022-06-24 10:51:45.553282
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import Schema, fields, ValidationError

    class Person(Schema):
        name = fields.String(max_length=50, required=True)
        year_of_birth = fields.Integer(min=1900, max=2099)
        hobbies = fields.Array(fields.String(), min_items=1, max_items=10)

    class Message(Schema):
        sender = fields.String(required=True)
        recipient = fields.String(required=True)
        content = fields.String(required=True, min_length=1, max_length=140)

    class Notification(Schema):
        category = fields.Const("notification")
        person = fields.Reference(Person)
        message = fields.Reference(Message)

    schema = Notification()
    print(str(schema))


# Generated at 2022-06-24 10:51:50.261358
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/product'}
    definitions = SchemaDefinitions()
    definitions['#/definitions/product'] = Object({'title':String()})
    fld = ref_from_json_schema(data, definitions=definitions)
    assert fld.validate({"title":"title"})==None
    assert fld.validate({})!=None


# Generated at 2022-06-24 10:51:56.796708
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("a") == "a"
    assert enum_from_json_schema({"enum": ["a", "b"]}, None).validate("b") == "b"
    assert enum_from_json_schema({"enum": [1, 2]}, None).validate(1) == 1
    assert enum_from_json_schema({"enum": [1, 2]}, None).validate(2) == 2



# Generated at 2022-06-24 10:51:59.302821
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    type_from_json_schema({}, definitions={})


# Generated at 2022-06-24 10:52:03.533339
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    anyOf = [{"type": "boolean"}, {"type": "string"}]
    data = {"anyOf": anyOf}
    definitions = SchemaDefinitions()
    any_of = any_of_from_json_schema(data, definitions)
    print(any_of)
    assert isinstance(any_of, Field)
    assert isinstance(any_of, Union)
    # Union(any_of=[Boolean(), String()])



# Generated at 2022-06-24 10:52:05.997321
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    obj = {
        "type": "object",
        "properties": {"x": {"type": "string"}},
        "not": {"minProperties": 2},
    }
    expected = Object(properties={"x": String()}, negated=Object(min_properties=2))
    actual = from_json_schema(obj)
    assert expected == actual



# Generated at 2022-06-24 10:52:08.403728
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = const_from_json_schema({'const':10}, None)
    assert schema.validate(10) is True
    assert schema.validate(0) is False



# Generated at 2022-06-24 10:52:16.491353
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()

    assert from_json_schema({"type": "string", "maxLength": 10}) == String(max_length=10)



# Generated at 2022-06-24 10:52:22.887890
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "number"},
            {"type": ["string", "integer", "number"]},
        ]
    }
    definitions = SchemaDefinitions()
    schema = one_of_from_json_schema(data, definitions=definitions)
    assert schema.validate(3) == 3
    assert schema.validate(3.0) == 3.0
    assert schema.validate("a") == "a"


# Generated at 2022-06-24 10:52:25.336923
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({'$ref': '#/definitions/name'}) == Reference(to='#/definitions/name', definitions=SchemaDefinitions())


# Generated at 2022-06-24 10:52:28.537721
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not":{"const":"good"}}
    definitions = SchemaDefinitions()

    expected_result = Not(negated=Const(const="good"))
    result = not_from_json_schema(data, definitions=definitions)

    assert result.render() == expected_result.render()



# Generated at 2022-06-24 10:52:30.291923
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # This function is not covered in unittests
    # TODO: fix this
    pass



# Generated at 2022-06-24 10:52:38.191108
# Unit test for function to_json_schema
def test_to_json_schema():
    from byceps.services.ticketing.models.ticket_category import TicketCategory
    from byceps.services.ticketing.models.ticket_type import TicketType
    from byceps.services.ticketing.models.ticket_type_group import TicketTypeGroup

    category = TicketCategory('open_air', 'Open Air', 'Some description.')
    ticket_type_group = TicketTypeGroup('normal',
        "Normal tickets", "These are the normal tickets.", category.id,
        [], [], set())
    ticket_type = TicketType('normal', 'Adult', 'normal', None, 150,
        datetime(2016, 7, 11, 8, 0), datetime(2016, 7, 11, 23, 59), None, None, False)

    data = to_json_schema(ticket_type)

    # The result is a JSON

# Generated at 2022-06-24 10:52:48.104803
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    type_string = 'oneOf'
    data={'definitions': {'user': {'properties': {'name': {'type': 'string'}}, 'type': 'object'}}, 'oneOf': [{'$ref': '#/definitions/user'}]}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = '#/definitions/{key}'.format(key=key)
        definitions[ref] = from_json_schema(value, definitions=definitions)
    field = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, OneOf)


# Generated at 2022-06-24 10:52:59.061251
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array(
        allow_null=True
    )
    assert from_json_schema

# Generated at 2022-06-24 10:53:04.400002
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/thing"
    }
    definitions = SchemaDefinitions()
    definitions['#/definitions/thing'] = Integer()
    assert ref_from_json_schema(data=data, definitions=definitions) == Reference(to="#/definitions/thing", definitions=definitions)
    assert ref_from_json_schema(data=data, definitions=definitions).validate(99) == 99



# Generated at 2022-06-24 10:53:14.870791
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type: () -> None
    """
    Test the 'from_json_schema_type' function
    """
    # pylint: disable=missing-docstring
    types = [
        ("number", Float,),
        ("integer", Integer,),
        ("string", String,),
        ("boolean", Boolean,),
        ("array", Array,),
        ("object", Object,),
    ]
    for type_string, type_cls in types:
        field = from_json_schema_type(
            data={"type": type_string},
            type_string=type_string,
            allow_null=False,
            definitions=SchemaDefinitions(),
        )
        assert isinstance(field, type_cls)


# Generated at 2022-06-24 10:53:24.262878
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    import json
    data = {
        "if": {
            "type": "string",
            "minLength": 3
        },
        "then": {
            "type": "string",
            "minLength": 4
        },
        "default": "123"
    }
    json_data = json.dumps(data)
    ite_field = if_then_else_from_json_schema(data=data)
    ite_field2 = IfThenElse(if_clause=String(min_length=3),
                            then_clause=String(min_length=4),
                            default="123")
    assert ite_field == ite_field2

definitions["SchemaDefinitions"] = definitions.as_field()


# Generated at 2022-06-24 10:53:33.050407
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(name=String(), id=Integer())
    assert_equal(
        to_json_schema(schema),
        {
            "definitions": {
                "name": {
                    "type": ["string", "null"],
                    "default": {"const": ""},
                },
                "id": {
                    "type": ["integer", "null"],
                    "default": {"const": 0},
                },
            },
            "properties": {
                "name": {"$ref": "#/definitions/name"},
                "id": {"$ref": "#/definitions/id"},
            },
            "required": ["name", "id"],
            "type": "object",
        },
    )



# Generated at 2022-06-24 10:53:42.818533
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_data_1 = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "test",
        "description": "test",
        "default": None,
        "anyOf": [
            {
                "type": "null"
            }
        ]
    }
    result = any_of_from_json_schema(test_data_1, definitions)
    assert result == Const(const=None, **{"default": None})

# Generated at 2022-06-24 10:53:48.928727
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "$ref": "#/definitions/SUB-SCHEMA-B"
            }
        ]
    }
    defs = {
        "SUB-SCHEMA-B": {
            "properties": {
                "rating": {
                    "type": "number"
                }
            },
            "type": "object",
            "required": [
                "rating"
            ]
        }
    }
    definitions = SchemaDefinitions()
    definitions.update(defs)
    r = one_of_from_json_schema(data, definitions=definitions)
    assert(r.one_of[0].properties["rating"].type == "number")


# Generated at 2022-06-24 10:53:59.104616
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from . import sub_factory

# Generated at 2022-06-24 10:54:08.390447
# Unit test for function get_valid_types

# Generated at 2022-06-24 10:54:12.966155
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from_json_schema({
        "$schema": "http://json-schema.org/draft-07/schema#",
        "if": {
            "type": "string"
        },
        "then": {
            "type": "object",
            "required": ["$data"],
            "properties": {
                "$data": {
                    "type": "string"
                },
                "required": {
                    "type": "array",
                    "items": {
                        "$data"
                    },
                    "minItems": 1
                }
            },
        }
    }, definitions=SchemaDefinitions())

test_if_then_else_from_json_schema()

# Generated at 2022-06-24 10:54:24.073016
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Object(
        properties={"name": String(), "age": Integer(minimum=0, maximum=200)}
    )
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer", "minimum": 0, "maximum": 200},
        },
    }
    assert to_json_schema(schema, _definitions={}) == {
        "definitions": {},
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer", "minimum": 0, "maximum": 200},
        },
    }



# Generated at 2022-06-24 10:54:31.265341
# Unit test for function get_valid_types
def test_get_valid_types():
    t1 = get_valid_types({"type": ["null", "string"]})
    assert t1 == ({"string"}, True)
    t2 = get_valid_types({"type": ["number", "boolean", "object"]})
    assert t2 == ({"number", "boolean", "object"}, False)
    t3 = get_valid_types({"type": ["null", "boolean", "object"]})
    assert t3 == ({"boolean", "object"}, True)


# Generated at 2022-06-24 10:54:37.191356
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"const": 3},
        "default": 1,
    }
    definitions = SchemaDefinitions()
    negated = from_json_schema(data["not"], definitions=definitions)
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    assert Not(**kwargs).evaluate(None,1) == {"success": False, "value": 1}
    assert Not(**kwargs).evaluate(None,2) == {"success": True, "value": 2}




# Generated at 2022-06-24 10:54:45.413895
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'not': {'type': 'array'}}).validate([]) == ([], [], {})
    assert not_from_json_schema({'not': {'type': 'array'}}).validate({}) == ([], [], {})
    assert not_from_json_schema({'not': {'type': 'array'}}).validate(None) == ([], [], {})
    assert not_from_json_schema({'not': {'type': 'array'}}).validate("") == ([], [], {})
    assert not_from_json_schema({'not': {'type': 'array'}}).validate("a") ==  ([], [], {})

# Generated at 2022-06-24 10:54:51.252924
# Unit test for function to_json_schema
def test_to_json_schema(): # pragma: no cover
    from pydantic import BaseModel
    from pydantic.fields import Field

    class Model(BaseModel):
        a: str
        b: int
        c: typing.List[int]
        d: typing.Dict[str, int]
        e: int = 5

    class InnerModel(BaseModel):
        a: int
        b: typing.List[str]

    class WithCustomFields(BaseModel):
        a: typing.Union[InnerModel, str] = Field(
            None, alias="x", description="Custom description"
        )

    class Test:
        pass

    class TestSchema(Schema):
        class Meta:
            target = Test

    data = to_json_schema(Model)

# Generated at 2022-06-24 10:54:56.231133
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Setup
    data={"enum": [3, 2, 1]}

    # Execute
    result = enum_from_json_schema(data, definitions=definitions)
    # Verify
    assert isinstance(result, Choice)
    assert result.choices == [(3, 3), (2, 2), (1, 1)]
    assert result.default == NO_DEFAULT



# Generated at 2022-06-24 10:55:00.915873
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": ["a", "b", "c", 1], "default": "b"}
    field = enum_from_json_schema(schema, definitions=definitions)
    assert field.validate(None) == "b"
    assert field.validate("b") == "b"
    assert field.validate(2) is None



# Generated at 2022-06-24 10:55:08.433781
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema(): # pragma: no cover
    definitions = SchemaDefinitions(
        {
            "#/definitions/Date": String(format='date'),
            "#/definitions/Author": Object(properties={'name': String(), 'name2': String()}),
            "https://foo.bar/schema/Person": Object(properties={'name': String(), 'name2': String()}),
        }
    )
    data1 = {"$ref": "#/definitions/Date"}
    data2 = {"$ref": "#/definitions/Author"}
    data3 = {"$ref": "https://foo.bar/schema/Person"}
    check1 = ref_from_json_schema(data1, definitions=definitions)
    check2 = ref_from_json_schema(data2, definitions=definitions)
    check3 = ref_

# Generated at 2022-06-24 10:55:17.938302
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Not(Integer()) -> Integer()
    data = {
        "not": {"type": "integer"}
    }
    definition = not_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(definition, Not)
    assert isinstance(definition.negated, Integer)

    data = {
        "allOf": [
            {"not": {"type": "integer"}},
            {"type": "string"},
        ]
    }
    definition = from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(definition, AllOf)
    assert len(definition.all_of) == 2
    assert isinstance(definition.all_of[0], Not)
    assert isinstance(definition.all_of[0].negated, Integer)

# Generated at 2022-06-24 10:55:20.996196
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/id'}), Reference)


# Generated at 2022-06-24 10:55:27.689017
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema = {
        "allOf": [
            {"type": "string"},
            {"maxLength": 10}
        ],
        "default": ""
    }
    schema = all_of_from_json_schema(json_schema, SchemaDefinitions())
    assert schema.validate("abc") == ("abc", None)
    assert schema.validate("abc1234567890") == ("abc1234567890", "Must be 10 characters or fewer.")



# Generated at 2022-06-24 10:55:35.623808
# Unit test for function get_standard_properties
def test_get_standard_properties():
    import pytest
    S = String(default="foo")
    assert get_standard_properties(S) == {"default": "foo"}

    I = Integer(default=42)
    assert get_standard_properties(I) == {"default": 42}

    B = Boolean(default=True)
    assert get_standard_properties(B) == {"default": True}

    A = Array(default=[1, 2, 3])
    assert get_standard_properties(A) == {"default": [1, 2, 3]}

    O = Object(default={"a": "b"})
    assert get_standard_properties(O) == {"default": {"a": "b"}}

    C = Const(const="test")
    assert get_standard_properties(C) == {}
    with pytest.raises(AttributeError):
        _ = get

# Generated at 2022-06-24 10:55:43.210676
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({})[0], Any)
    assert from_json_schema({"type": ["string"]})[0].__class__.__name__ == "String"
    assert from_json_schema({"type": ["string"]})[0].meta.get("default") == ""
    assert from_json_schema({"type": ["string"], "default": "foo"})[0].meta.get("default") == "foo"

    assert (
        from_json_schema({"type": ["integer"], "default": 0})[0].meta.get("default") == 0
    )
    assert from_json_schema({"type": ["number"], "default": 0})[0].meta.get("default") == 0

# Generated at 2022-06-24 10:55:54.076476
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "not": {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
            "pattern": r"^[a-z0-9_]+$",
            "format": "email",
        }
    }
    checker = from_json_schema(schema)
    assert checker.check(" ") == False
    assert checker.check("") == True
    assert checker.check("test") == False
    assert checker.check("test@example.com") == False
    assert checker.check("te st") == False
    assert checker.check("@example.com") == True


# Generated at 2022-06-24 10:56:05.782710
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "string"
        }
    }
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == ~ String()
    data = {
        "not": {
            "type": ["string", "integer"]
        }
    }
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == ~ Union(
        any_of=[String(), Integer()]
    )
    data = {
        "not": {
            "$ref": "/something/else"
        }
    }
    definitions = SchemaDefinitions()
    definitions[data["not"]["$ref"]] = String()

# Generated at 2022-06-24 10:56:13.453254
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def assert_ref(content,                                               # type: ignore
                   expected_definition,                                   # type: ignore
                   definitions=SchemaDefinitions()):                      # type: ignore
        actual = from_json_schema(                                        # type: ignore
            content, definitions=definitions).to_python(None)
        assert actual is expected_definition, f"{actual} != {expected_definition}"
    assert_ref({"$ref": "#/definitions/foo"}, definitions["#/definitions/foo"])



# Generated at 2022-06-24 10:56:14.714833
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_then_else_from_json_schema(data["if"], definitions=None)

# Generated at 2022-06-24 10:56:25.604913
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, None) == String()
    assert type_from_json_schema({"type": ["string"]}, None) == String()
    assert isinstance(type_from_json_schema({"type": ["string", "null"]}, None), Union)
    assert type_from_json_schema({"type": ["integer"]}, None) == Integer()
    assert type_from_json_schema({"type": ["number"]}, None) == Number()
    assert type_from_json_schema({"type": ["object"]}, None) == Object()
    assert type_from_json_schema(
        {"type": ["object"]}, None,
    ).properties == {}
    assert type_from_json_schema({"type": ["array"]}, None) == Array

# Generated at 2022-06-24 10:56:29.188445
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 2}, None) == Const(const=2, default=NO_DEFAULT)



# Generated at 2022-06-24 10:56:31.249502
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Any()



# Generated at 2022-06-24 10:56:38.855599
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def from_ref(ref):
        return from_json_schema({"$ref": ref})

    field = from_ref("#/definitions/id")
    assert field._to == "#/definitions/id"
    assert field._definitions is None

    field = from_ref("blah")
    assert field._to == "blah"
    assert field._definitions is None

    definitions = SchemaDefinitions()
    field = from_ref("blah", definitions)
    assert field._to == "blah"
    assert field._definitions is definitions



# Generated at 2022-06-24 10:56:49.429942
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema1 = {
        "type": "object",
        "anyOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "integer"}
                }
            },
            {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "c": {"type": "integer"}
                }
            }
        ]
    }

# Generated at 2022-06-24 10:56:57.949732
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = """
    {
        "type": "object",
        "allOf": [
            {
                "type": "object",
                "minProperties": 2
            },
            {
                "type": "object",
                "minProperties": 1
            }
        ]
    }
    """
    schema = json.loads(schema)
    all_of = all_of_from_json_schema(schema, definitions = None)
    assert isinstance(all_of, AllOf)
    assert all_of.all_of[0].min_properties == 2
    assert all_of.all_of[1].min_properties == 1



# Generated at 2022-06-24 10:57:08.814697
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)

# Generated at 2022-06-24 10:57:20.424622
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    class T(object):
        pass

# Generated at 2022-06-24 10:57:23.959082
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({
        "anyOf": [
            {
                "type": "number",
                "multipleOf": 3
            }
        ]
    }, SchemaDefinitions()) == Union(any_of=[Number(multiple_of=3)])



# Generated at 2022-06-24 10:57:32.082788
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["mysql"],
                    },
                    "host": {
                        "type": "string",
                    },
                    "port": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 65535,
                    },
                    "database": {
                        "type": "string",
                    }
                },
                "required": ["type", "host", "port", "database"],
                "additionalProperties": False,
            }
        ]
    }
    field = from_json_schema(schema)

# Generated at 2022-06-24 10:57:40.876075
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field = from_json_schema(
        {
            "type": "object",
            "properties": {
                "id": {"type": "integer"},
                "name": {"type": "string", "minLength": 3},
                "numbers": {"type": "array", "items": {"type": "number"}},
                "friends": {
                    "type": "array",
                    "items": {"properties": {"id": {"type": "integer"}}},
                },
            },
        }
    )
    assert field.validate({"id": 1, "name": "foo", "numbers": [1.2, 3.4], "friends": []}) == (
        {"id": 1, "name": "foo", "numbers": [1.2, 3.4], "friends": []},
        None
    ), field

# Generated at 2022-06-24 10:57:45.062584
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
  data = {'const': 1, 'default': 'blue'}
  definitions = SchemaDefinitions()
  test_const = const_from_json_schema(data, definitions)
  assert test_const.const == 1, "The constant was not converted properly."



# Generated at 2022-06-24 10:57:52.289964
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    def f1():
        data = {
            "not": {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "integer"},
                },
                "required": ["a", "b"],
            }
        }
        return from_json_schema(data)

    def f2():
        return Not(negated=AllOf([Object(properties={"a": String()})]))

    assert f1() == f2()



# Generated at 2022-06-24 10:57:59.334379
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": ""}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null"}) == ({'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({"type": "null", "type": "string"}) == ({'boolean', 'object', 'array', 'number', 'string'}, True)
    
    types = "null"
    assert get_valid_types({"type": types}) == ({'boolean', 'object', 'array', 'number', 'string'}, True)

# Generated at 2022-06-24 10:58:07.758712
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    def test_one(text, expected):
        data = json.loads(text)
        output = all_of_from_json_schema(data)
        assert expected == str(output)

    test_one('{"allOf": [{"minimum": 1, "maximum": 2}, {"minimum": 3, "maximum": 4}]}',
             '{"allOf": [{"minimum": 1, "maximum": 2}, {"minimum": 3, "maximum": 4}]}')


# Generated at 2022-06-24 10:58:10.604574
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert isinstance(
        enum_from_json_schema({"enum": [1, 2.0, "3"]}, definitions=None), Choice
    )



# Generated at 2022-06-24 10:58:18.774319
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/schema#",
        "definitions": {
            "schemaA": {
                "type": "string",
                "max_length": 10,
                "min_length": 0
            },
            "schemaB": {
                "type": "string",
                "max_length": 8,
                "min_length": 4
            },
            "schemaC": {
                "type": "string",
                "max_length": 8,
                "min_length": 4
            }
        }
    }
    definitions = SchemaDefinitions()
    for key, value in schema["definitions"].items():
        ref = f"#/definitions/{key}"

# Generated at 2022-06-24 10:58:31.921861
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:58:40.783893
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert (
        get_valid_types(
            {"type": ["null", "string"], "maximum": 1, "exclusiveMaximum": False}
        )
        == ({"number", "string"}, True)
    )
    assert (
        get_valid_types(
            {"type": ["null", "string"], "minimum": 1, "exclusiveMinimum": False}
        )
        == ({"number", "string"}, True)
    )



# Generated at 2022-06-24 10:58:45.879751
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/User"}
    definitions = SchemaDefinitions()
    definitions["User"] = String()
    ref = ref_from_json_schema(data, definitions=definitions)
    assert ref.schema["$ref"] == "#/definitions/User"


# Generated at 2022-06-24 10:58:51.310802
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    testData = {"test":"test"}
    
    def test_method(data):
        return data
    
    negated = Not()
    negated.negated = test_method
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}

    assert  negated.negated == test_method

    

    

# Generated at 2022-06-24 10:58:53.823721
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const={"const":1}
    const_from_json_schema(const,None)



# Generated at 2022-06-24 10:58:57.579049
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_data = {
        "not": {
            "anyOf": [
                {"type": "integer"},
                {"type": "string"}
            ]
        }
    }
    result = not_from_json_schema(test_data, {})
    assert isinstance(result, Not)
    assert isinstance(result.negated, Union)



# Generated at 2022-06-24 10:59:06.416127
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        name = String()
        age = Integer()

        class Meta:
            additional_properties = False

    person_schema = Person.make_validator()
    person_schema_json_schema = to_json_schema(person_schema)  # type: ignore
    expected_json_string = r"""
{
    "definitions": {
        "Person": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                },
                "age": {
                    "type": "integer",
                },
            },
            "additionalProperties": false
        },
    },
    "$ref": "#/definitions/Person",
}"""

# Generated at 2022-06-24 10:59:17.666328
# Unit test for function not_from_json_schema