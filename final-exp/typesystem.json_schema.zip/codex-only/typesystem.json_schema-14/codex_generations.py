

# Generated at 2022-06-24 10:49:20.572330
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Test the case of the const being a string
    schema = {'const': 'a'}
    result = const_from_json_schema(schema, definitions)
    assert result.const == 'a'
    # Test the case of the const being an integer
    schema = {'const': 1}
    result = const_from_json_schema(schema, definitions)
    assert result.const == 1
    # Test the case of the const being an object
    schema = {'const': {'key': 'value'}}
    try:
        result = const_from_json_schema(schema, definitions)
        assert False
    except AssertionError:
        pass


# Generated at 2022-06-24 10:49:29.480085
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)
    assert get_valid_types({"type": ["null", "number"]}) == ({"number"}, True)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)



# Generated at 2022-06-24 10:49:37.039468
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(min_length=1)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(pattern_regex=re.compile(r"(.+)\1+"))) == {
        "type": "string",
        "pattern": r"(.+)\1+",
    }
    assert to_json_schema(Integer(minimum=0, maximum=100)) == {
        "type": "integer",
        "minimum": 0,
        "maximum": 100,
    }
    assert to_json_schema(Boolean()) == {"type": "boolean"}

# Generated at 2022-06-24 10:49:41.730903
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer", "maximum": 10},
        "then": {"type": "integer", "maximum": 100},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    print(field.schema(resolver=None))



# Generated at 2022-06-24 10:49:47.416166
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    input_data = {"default": "1", "enum": ["1", "2", "3"]}

    assert enum_from_json_schema(input_data, definitions=None).default == "1"
    assert enum_from_json_schema(input_data, definitions=None).choices == [("1", "1"), ("2", "2"), ("3", "3")]

test_enum_from_json_schema()



# Generated at 2022-06-24 10:49:50.575755
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "Max", "default": "Max"}
    expected = Const(const="Max", default="Max")
    assert const_from_json_schema(data, definitions) == expected
## End Test



# Generated at 2022-06-24 10:49:53.775331
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class TestField(Field):
    
        def __init__(self, default: typing.Any) -> None:
            self.default = default
    
        def make_default(self, strict: bool = False) -> typing.Any:
            return self.default

        def has_default(self) -> bool:
            return True

    assert get_standard_properties(TestField(default="foo")) == {"default": "foo"}
    assert get_standard_properties(TestField(default=None)) == {"default": None}



# Generated at 2022-06-24 10:50:06.330433
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const" : "foo"}, None) == Const("foo")
    assert const_from_json_schema({"const" : 7}, None) == Const(7)
    assert const_from_json_schema({"const" : 7.1}, None) == Const(7.1)
    assert const_from_json_schema({"const" : { "foo" : "bar" }}, None) == Const({ "foo" : "bar" })
    assert const_from_json_schema({"const" : True}, None) == Const(True)
    assert const_from_json_schema({"const" : False}, None) == Const(False)
    assert const_from_json_schema({"const" : None}, None) == Const(None)
    assert const_from

# Generated at 2022-06-24 10:50:10.686823
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, 2, 3], "type": "integer"}
    field = enum_from_json_schema(data, definitions={})
    assert isinstance(field, Choice) and field.choices == [(1, 1), (2, 2), (3, 3)], "enum_from_json_schema did not produce expected Choice field"
test_enum_from_json_schema()



# Generated at 2022-06-24 10:50:16.030827
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string", "minLength": 2}, {"type": "integer", "minimum": 0}]}
    schema = any_of_from_json_schema(data, definitions=definitions)
    assert isinstance(schema, Union)
    assert len(schema.any_of) == 2



# Generated at 2022-06-24 10:50:24.842112
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types(data={"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types(data={}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types(data={"type": ["string"]}) == ({"string"}, False)
    assert get_valid_types(data={"type": None}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types(data={"type": "null"}) == ({"null"}, True)



# Generated at 2022-06-24 10:50:31.095537
# Unit test for function get_standard_properties
def test_get_standard_properties():
    import pytest
    from validation.deprecation import Deprecation
    def my_validate(value, field, options): pass
    def my_function(value, field, options): pass
    def my_prepare(value, field, options): pass
    def my_serialize(value, field, options): pass
    def my_deserialize(value, field, options): pass
    def test_function_field():
        field = Function(validate=my_validate, prepare=my_prepare, default=5)
        assert get_standard_properties(field) == dict(default=5)
    def test_deprecated_field():
        field = Deprecated(
            name="deprecated-field", version=3.0, replacement="new-field"
        )
        assert get_standard_properties(field) == dict()


# Generated at 2022-06-24 10:50:38.480692
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = { "not": {"type": "integer"} }
    field = not_from_json_schema(data, definitions=definitions)
    assert field.default == NO_DEFAULT
    assert field.check(None)
    assert field.check(1)
    assert field.check(1.0)
    assert field.check(True)
    assert field.check(False)
    assert field.check({"a": 1})
    assert field.check(["a", 1])
    assert not field.check("a")



# Generated at 2022-06-24 10:50:44.349282
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": ["string", "integer"]}) == (
        Choice(any_of=[String(), Integer()])
    )
    assert type_from_json_schema({"type": ["string", "integer"], "nullable": True}) == (
        Choice(any_of=[String(), Integer()], allow_null=True)
    )
    assert type_from_json_schema({"type": ["string", "null"]}) == (
        Choice(any_of=[String(), Const(None)], allow_null=True)
    )



# Generated at 2022-06-24 10:50:50.780193
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert {'default': NO_DEFAULT} == get_standard_properties(None)
    assert {'default': NO_DEFAULT} == get_standard_properties(Const(const='hello'))
    assert {'default': 'hello'} == get_standard_properties(Const(const='hello', default='hello'))

# Generated at 2022-06-24 10:51:00.989309
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    test_schema = {"enum": [1, 2, 3]}
    expected = {
        1: 1,
        2: 2,
        3: 3,
        "": None
    }
    assert Choice(choices=[(1, 1), (2, 2), (3, 3)]) == enum_from_json_schema(test_schema, definitions)
    assert expected == enum_from_json_schema(test_schema, definitions).adapt(
        {"enum": [1, 2, 3]}
    )
    assert expected == enum_from_json_schema(test_schema, definitions).adapt(
        {"enum": [1, 2, 3], "default": 4}
    )

# Generated at 2022-06-24 10:51:09.842763
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "integer", "minimum": 1, "maximum": 3},
            {"type": "integer", "minimum": 4, "maximum": 6},
            {"type": "integer", "minimum": 7, "maximum": 9},
        ]
    }
    definitions = SchemaDefinitions()
    f = any_of_from_json_schema(data, definitions=definitions)
    assert f.validate(0) == False
    assert f.validate(1) == True
    assert f.validate(2) == True
    assert f.validate(3) == True
    assert f.validate(4) == True
    assert f.validate(5) == True
    assert f.validate(6) == True
    assert f.validate(7) == True


# Generated at 2022-06-24 10:51:12.950977
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {'type': 'string'}
    field = type_from_json_schema(data=data, definitions=None)
    assert isinstance(field, String)



# Generated at 2022-06-24 10:51:20.935888
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)
    assert isinstance(from_json_schema_type({}, "array", False, None), Array)



# Generated at 2022-06-24 10:51:27.412673
# Unit test for function from_json_schema
def test_from_json_schema():
    import json
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Float, Decimal, Object, Array, Enum


# Generated at 2022-06-24 10:51:31.894425
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    try:
        any_of_from_json_schema({'anyOf': [{'type': 'number'}, {'const': 2}]}, SchemaDefinitions())
        print(True)
    except TypeError:
        print(False)
test_any_of_from_json_schema()



# Generated at 2022-06-24 10:51:41.059446
# Unit test for function from_json_schema
def test_from_json_schema():
    ###
    ### Test all possible JSONSchema fields, except for:
    ###
    ###   - "$ref"
    ###   - "properties"
    ###   - "dependencies"
    ###
    ### Some of these fields are tested a bit more extensively in the tests
    ### for individual fields (e.g., String, Integer, Array, etc.)
    ###
    X = from_json_schema(
        {
            "type": "string",
            "format": "email",
            "enum": ["foo@bar.com"],
            "minLength": 1,
            "maxLength": 15,
            "pattern": r"^\S+@\S+$",
        }
    )
    assert isinstance(X, String)
    assert X.min_length == 1
    assert X.max_length == 15

# Generated at 2022-06-24 10:51:42.957883
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "not": {"type": "integer"},
    }
    assert from_json_schema(data) == ~ Integer()



# Generated at 2022-06-24 10:51:51.958416
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of_schema_1 = {"type": "object", "oneOf": [{"enum": ["one"]}, {"enum": ["two"]}]}
    one_of_field_1 = one_of_from_json_schema(one_of_schema_1, SchemaDefinitions())
    assert one_of_field_1.validate("one") is None

    one_of_schema_2 = {"type": "object", "oneOf": [{"enum": ["one"]}, {"enum": ["one"]}]}
    one_of_field_2 = one_of_from_json_schema(one_of_schema_2, SchemaDefinitions())
    assert one_of_field_2.validate("one") == "Field contains duplicates."


# Generated at 2022-06-24 10:51:56.180786
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        'anyOf': [
            {'type': 'integer'},
            {'type': 'string'},
        ]
    }
    definitions = SchemaDefinitions()
    assert isinstance(any_of_from_json_schema(data, definitions=definitions), Union)


# Generated at 2022-06-24 10:52:04.638725
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer) == {"type": "integer"}
    assert to_json_schema(Integer(const=5)) == {"type": "integer", "const": 5}
    assert to_json_schema(Integer(const=5, allow_null=True)) == {
        "type": ["integer", "null"], "const": 5
    }
    assert to_json_schema(Integer(const=5, allow_null=True, default="x")) == {
        "type": ["integer", "null"], "const": 5, "default": "x"
    }
    assert to_json_schema({}) == {
        "type": "object",
        "properties": {},
        "patternProperties": {},
        "additionalProperties": True,
        "propertyNames": None,
    }

# Generated at 2022-06-24 10:52:08.975310
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Any(), then_clause=Boolean()
    ).validate({"a": "b"}).value is None
    assert IfThenElse(
        if_clause=Any(), then_clause=Boolean()
    ).validate({"a": 1}).value is None
    assert IfThenElse(
        if_clause=Any(), then_clause=Boolean()
    ).validate({"a": False}).value is False
    assert IfThenElse(
        if_clause=Any(), then_clause=Boolean()
    ).validate({"a": True}).value is True

# Generated at 2022-06-24 10:52:11.305938
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
  unit_test_data = {
        'anyOf': [
            {'type': 'string'},
            {'type': 'integer'},
            {'type': 'boolean'},
            {'type': 'null'},
        ]
    }
  assert (any_of_from_json_schema(data=unit_test_data, definitions=None) is not None)


# Generated at 2022-06-24 10:52:23.201727
# Unit test for function to_json_schema
def test_to_json_schema():

    class PersonSchema(Schema):
        name = pydantic.fields.String(min_length=3)
        age = pydantic.fields.PositiveInt()

    class PeopleSchema(Schema):
        people = pydantic.fields.List(PersonSchema)

    result = to_json_schema(PeopleSchema)

# Generated at 2022-06-24 10:52:25.143632
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    print(const_from_json_schema({"const": 3}, definitions=None))



# Generated at 2022-06-24 10:52:29.772337
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"type": "number", "maximum": 0}
    fields = from_json_schema(schema)
    assert fields.validate(1) == (1, [])

    schema = {"type": "number", "not": {"maximum": 0}}
    fields = from_json_schema(schema)
    assert fields.validate(1) == (1, [])
    fields = from_json_schema(schema)
    assert fields.validate(-1) == (-1, [])



# Generated at 2022-06-24 10:52:37.818277
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "null", "enum": [None]}) == ({}, True)
    assert get_valid_types({"type": "null", "enum": [1]}) == ({}, True)
    assert get_valid_types({"type": "null", "enum": [None, 1]}) == ({}, True)

    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "object", "enum": [{}]}) == ({"object"}, False)
    assert get_valid_types({"type": "object", "enum": [""]}) == ({"object"}, False)

# Generated at 2022-06-24 10:52:39.057999
# Unit test for function from_json_schema
def test_from_json_schema():
    d = {"a":{"type":"string"}}
    assert from_json_schema(d) == {"a": String()}


# Generated at 2022-06-24 10:52:47.825933
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    s = const_from_json_schema({'const': 'a'})
    assert s.validate('a')
    assert not s.validate('b')
    assert not s.validate(None)
    s = const_from_json_schema({'const': None})
    assert s.validate(None)
    assert not s.validate('a')
    assert not s.validate('')


# Generated at 2022-06-24 10:52:53.428483
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    doc = {'const': 'A', 'default': 'A'}
    schema = const_from_json_schema(doc, None)
    assert schema.valid_value('A')
    assert not schema.valid_value('B')
    assert not schema.valid_value(None)
    assert schema.default == 'A'



# Generated at 2022-06-24 10:53:03.886540
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["null", "string", "number", "array"]}) == Any()

# Generated at 2022-06-24 10:53:12.641325
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    s = SchemaDefinitions()
    s["#/definitions/is_string"] = String()


# Generated at 2022-06-24 10:53:22.566982
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Basic usage.
    data = {"$ref": "#/definitions/string_schema"}
    string_schema = {"type": "string"}
    definitions = {"string_schema": string_schema}
    assert ref_from_json_schema(data, definitions=definitions).type == "string"

    # $ref to a $ref
    definitions = SchemaDefinitions()
    definitions["a"] = Reference(to="#/b", definitions=definitions)
    definitions["b"] = Reference(to="#/c", definitions=definitions)
    definitions["c"] = {"type": "string"}
    result = ref_from_json_schema({"$ref": "#/a"}, definitions=definitions)
    assert result.type == "string"

    # Test circular references
    definitions = SchemaDefinitions()
    definitions

# Generated at 2022-06-24 10:53:24.922466
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "number"},
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": None
    }
    assert isinstance(one_of_from_json_schema(data, None), OneOf)


# Generated at 2022-06-24 10:53:26.812691
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    global_definitions = SchemaDefinitions()
    data = {"not": {}, "default": None}
    not_field = Not(negated=Any(), default=None)
    assert not_from_json_schema(data, global_definitions) == not_field


# Generated at 2022-06-24 10:53:35.030882
# Unit test for function from_json_schema
def test_from_json_schema():
    import json
    json_schema_str = """
    {
        "type": "object",
        "additionalProperties": false,
        "properties": {
            "name": {"type": "string"},
            "birth_date": {"type": "string", "format": "date"}
        },
        "required": ["name"]
    }
    """
    json_schema = json.loads(json_schema_str)
    s = from_json_schema(json_schema)
    assert (
        json.dumps(
            s.to_json_schema(),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
            indent=4,
        )
        == json_schema_str
    )



# Generated at 2022-06-24 10:53:44.000104
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:53:50.569234
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    condition = {
        "type": "string",
        "minLength": 1,
    }
    then_clause = {
        "type": "integer",
        "default": 0
    }
    else_clause = {
        "type": "integer"
    }

    assert validate({"foo": None}, if_then_else_from_json_schema({
        "if": condition,
        "then": then_clause,
        "else": else_clause
    })) == {"foo": 0}

    assert validate({"foo": ""}, if_then_else_from_json_schema({
        "if": condition,
        "then": then_clause,
        "else": else_clause
    })) == {"foo": None}


# Generated at 2022-06-24 10:53:56.697803
# Unit test for function from_json_schema
def test_from_json_schema():
    assert definitions is not None
    assert JSONSchema is not None
    assert isinstance(JSONSchema, Object)
    assert "$ref" in JSONSchema.properties
    assert isinstance(JSONSchema.properties["$ref"], (String, OneOf))
    assert {"$ref", "type"} == set(JSONSchema.properties)
    assert isinstance(JSONSchema.properties["type"], (String, Array))



# Generated at 2022-06-24 10:54:01.986085
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = { "const": "foo", "default": "bar"}
    definitions = SchemaDefinitions()
    result = const_from_json_schema(data, definitions)
    assert(result.const == "foo")
    assert(result.default == "bar")
# Test



# Generated at 2022-06-24 10:54:09.599525
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    class FooSchema(Schema):
        foo = String()
        bar = Boolean()
        baz = Integer()

    assert json.dumps(to_json_schema(FooSchema), sort_keys=True) == json.dumps(
        {
            "definitions": {
                "FooSchema": {
                    "properties": {
                        "bar": {"type": "boolean"},
                        "baz": {"type": "integer"},
                        "foo": {"type": "string"}
                    },
                    "required": ["foo", "bar", "baz"],
                    "type": "object",
                }
            }
        },
        sort_keys=True,
    )

    class SchemaWithAdvancedFields(Schema):
        foo = String()

# Generated at 2022-06-24 10:54:17.731506
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Integer(
        allow_null=False,
        default=None,
        minimum=10,
        maximum=20,
        exclusive_minimum=True,
        exclusive_maximum=False,
        multiple_of=2,
    )
    json_schema = to_json_schema(field)
    assert json_schema == {
        "type": "integer",
        "minimum": 10,
        "maximum": 20,
        "exclusiveMinimum": True,
        "exclusiveMaximum": False,
        "multipleOf": 2,
    }
    converted_field = from_json_schema(json_schema)
    assert field == converted_field



# Generated at 2022-06-24 10:54:20.323520
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # TODO: Implement unit tests for this function.
    pass
# End unit test for function type_from_json_schema



# Generated at 2022-06-24 10:54:25.726955
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "number"}, {'type': 'array', 'items': {'type': 'number'}}]}
    any_of = [Number(), Array(items=Number())]
    kwargs = {"any_of": any_of, "default": NO_DEFAULT}
    assert Union(**kwargs) == any_of_from_json_schema(data, definitions=definitions)


# Generated at 2022-06-24 10:54:28.247898
# Unit test for function get_standard_properties
def test_get_standard_properties():
    f = String(default="value")
    x = get_standard_properties(f)
    assert x == {"default": "value"}

    f = AllOf(all_of=[
        String(),
        String(default="value"),
    ])
    x = get_standard_properties(f)
    # Expect the schema to not have a default, because AllOf does not specify one
    assert x == {}



# Generated at 2022-06-24 10:54:41.258900
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft/2019/schema#",
        "type": "object",
        "properties": {
            "name": {
                "if": {"type": "string"},
                "then": {"maxLength": 10},
                "else": {"enum": ["apple", "pear", "banana"]},
            }
        },
    }
    field = from_json_schema(schema)
    assert field.validate("name", "banana") is None
    assert field.validate("name", "too long") is not None
    assert field.validate("name", "apple") is None
    assert field.validate("name", 5) is None
    assert field.validate("name", True) is not None


# Generated at 2022-06-24 10:54:44.994019
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    my_data = {'const': 'hello'}
    field = const_from_json_schema(my_data, definitions=definitions)
    assert field.validate('hello') == 'hello'
    assert field.validate('not hello') == None



# Generated at 2022-06-24 10:54:50.870655
# Unit test for function to_json_schema
def test_to_json_schema():
    data = {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
            "b": {"type": "number"},
            "c": {
                "type": "object",
                "properties": {
                    "d": {"type": "string"},
                    "e": {"type": "integer"},
                },
            },
            "f": {
                "type": "array",
                "items": {
                    "oneOf": [
                        {"type": "string"},
                        {"type": "number"},
                    ],
                },
            },
        },
    }

    class A:
        a: str
        b: float
        c: "C"
        f: typing.List[typing.Union[str, int, float]]

    class C:
        d: str
       

# Generated at 2022-06-24 10:55:02.962262
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()
    assert isinstance(
        type_from_json_schema({"type": "string"}, definitions={}), String
    )
    assert isinstance(
        type_from_json_schema({"type": ["string", "integer"]}, definitions={}),
        Union,
    )
    assert isinstance(
        type_from_json_schema({"type": "null", "enum": ["string"]}, definitions={}),
        Choice,
    )
    assert isinstance(
        type_from_json_schema({"type": ["null", "integer"]}, definitions={}),
        Integer,
    )

# Generated at 2022-06-24 10:55:16.823895
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": ["string", "number"]}) == ({"number", "string"}, False)
    assert get_valid_types({"type": ["string", "null"]}) == ({"string"}, True)
    assert get_valid_types({"type": ["integer", "null"]}) == ({"integer"}, True)

    assert get_valid_types({"type": "string", "enum": ["abc"]}) == ({"string"}, False)
    assert get_valid_types({"type": "number", "enum": [42]}) == ({"number"}, False)
    assert get_

# Generated at 2022-06-24 10:55:28.314540
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True).validate(None) == None
    assert from_json_schema(False).validate(None) == "Value does not match schema."
    assert from_json_schema({"type": "integer"}).validate(5) == None
    assert from_json_schema({"type": "string"}).validate(5) != None
    assert from_json_schema({"enum": [1, 2, 3]}).validate(5) != None
    assert from_json_schema({"enum": [1, 2, 3]}).validate(2) == None
    assert from_json_schema({"const": 5}).validate(2) != None
    assert from_json_schema({"const": 5}).validate(5) == None
    assert from_json

# Generated at 2022-06-24 10:55:35.777277
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Create and use view for definition for reference.
    """
    ref_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {"first": {"description": "first", "$ref": "#/definitions/ref"}},
        "definitions": {
            "ref": {
                "type": "object",
                "properties": {"second": {"description": "second", "type": "number"}},
            }
        },
    }
    field_schema = from_json_schema(ref_schema)
    assert isinstance(field_schema, Object)
    assert field_schema.properties["first"]["second"].type() == Number



# Generated at 2022-06-24 10:55:43.257672
# Unit test for function from_json_schema
def test_from_json_schema():
    from .test_utils import TestSchema

    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema(
        {
            "type": "string",
            "minLength": 0,
            "maxLength": 10,
            "pattern": "^[a-f]+$",
            "format": "regex",
        }
    ) == String(
        min_length=0,
        max_length=10,
        format="regex",
        pattern=re.compile("^[a-f]+$"),
    )

    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_

# Generated at 2022-06-24 10:55:56.120872
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    """
    Test we can convert json schema const fields to typesystem const fields
    """
    from typesystem import Number

    json_schema = {"const": 1}
    field = const_from_json_schema(json_schema, SchemaDefinitions())
    assert field.validate(1) == 1
    assert type(field) == Const

    json_schema = {"const": 2147483647}
    field = const_from_json_schema(json_schema, SchemaDefinitions())
    assert field.validate(2147483647) == 2147483647
    assert type(field) == Const

    json_schema = {"const": 2147483648}
    field = const_from_json_schema(json_schema, SchemaDefinitions())

# Generated at 2022-06-24 10:56:00.086153
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "string"}, {"minLength": 7}]}) == AllOf(
        all_of=[String(), String(min_length=7)])



# Generated at 2022-06-24 10:56:02.825428
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    with pytest.raises(AssertionError):
        from_json_schema_type(None, None, None, None)



# Generated at 2022-06-24 10:56:07.309010
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(default="foo")
    data = get_standard_properties(field)
    assert data == {"default":"foo"}, "The value that is returned is incorrect"
    field = String(default=NO_DEFAULT)
    data = get_standard_properties(field)
    assert data == {}, "NO_DEFAULT should not be in the dictionary"


# Generated at 2022-06-24 10:56:13.579249
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():  # TODO: delete after #288
    from typesystem.validators import Check, CheckValue

    data = {
        "oneOf": [
            {"type": "number", "minimum": 1},
            {
                "type": "string",
                "enum": ["a", "b", "c"],
                "validators": [{"name": "check_value", "options": {"choices": ["a", "b"],}}],
                "default": "a",
            },
        ]
    }
    field = one_of_from_json_schema(data, definitions=SchemaDefinitions())

    assert field.validate("1") == "1"
    assert field.validate(2) == 2

    assert field.validate("c") == "c"

# Generated at 2022-06-24 10:56:25.109475
# Unit test for function from_json_schema
def test_from_json_schema():

    schema = {
        "description": "A person",
        "type": "object",
        "properties": {
            "firstName": {"type": "string"},
            "lastName": {"type": "string"},
            "age": {"description": "Age in years", "type": "integer", "minimum": 0},
        },
    }
    field = from_json_schema(schema)
    assert field.schema.dict() == schema

    field = Field(name="first_name")
    field.schema = schema
    assert field.validate("first_name", data="") == ("", None)
    assert field.validate("first_name", data="foo") == ("", "foo")
    assert field.validate("first_name", data=42) == ("Invalid type 42. Expected: str", None)


# Generated at 2022-06-24 10:56:33.090324
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"$ref": "#/definitions/whatever"}) == Reference("whatever")
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"const": 42}) == Const(42)
    assert from_json_schema({"const": True}) == Const(True)
    assert from_json_schema({"allOf": [{"const": 42}]}) == AllOf([Const(42)])
    assert from_json_schema({"anyOf": [{"const": 42}]}) == Const(42)

# Generated at 2022-06-24 10:56:41.498678
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {"if": {"type": "integer"}}
    field = if_then_else_from_json_schema(schema, None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, Integer)
    assert field.then_clause is None
    assert field.else_clause is None

    schema = {"if": {"type": "integer"}, "then": {"type": "string"}}
    field = if_then_else_from_json_schema(schema, None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, Integer)
    assert isinstance(field.then_clause, String)
    assert field.else_clause is None


# Generated at 2022-06-24 10:56:45.810568
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Test that a valid const is allowed
    try:
        const_from_json_schema({"const": 1})
    except Exception:
        assert False, "Should not raise"

    # Test that an invalid const raises
    try:
        const_from_json_schema({"const": 1})
        assert False, "Should raise"
    except Exception:
        pass



# Generated at 2022-06-24 10:56:55.389114
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(from_json_schema({"type": "integer"}), Integer)
    assert isinstance(from_json_schema({"type": "number"}), Number)
    assert isinstance(from_json_schema({"type": "boolean"}), Boolean)
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": "array"}), Array)
    assert isinstance(from_json_schema({"type": "object"}), Object)
    assert isinstance(
        from_json_schema({"type": ["integer", "null"]}), Integer
    )
    assert isinstance(
        from_json_schema({"type": ["integer", "boolean"]}), Union
    )

# Generated at 2022-06-24 10:57:03.806433
# Unit test for function to_json_schema
def test_to_json_schema():
    import json


# Generated at 2022-06-24 10:57:10.958696
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False)
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True).allow_null == True
    assert from_json_schema_type({"type": "number", "minimum": 4}, type_string="number", allow_null=True).allow_null == True
    assert from_json_schema_type({"type": "number", "multipleOf": 2}, type_string="number", allow_null=True).allow_null == True
    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False)

# Generated at 2022-06-24 10:57:17.542317
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(from_json_schema({}), Field)
    assert isinstance(from_json_schema({'type': None}), Field)
    assert isinstance(from_json_schema({'type': bool}), Field)
    assert isinstance(from_json_schema({'type': ''}), Field)
    assert isinstance(from_json_schema({'type': []}), Field)



# Generated at 2022-06-24 10:57:24.246420
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = (
        {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "alpha": {"type": ["string", "null"]},
                "beta": {"type": "boolean"},
                "gamma": {"type": ["integer", "number"]},
                "delta": {"allOf": [{"type": ["array", "null"]}, {"items": {"type": "number"}}]},
            },
        }
    )
    result = from_json_schema(schema)
    assert isinstance(result, Object)
    fields = result.get_properties()
    assert "alpha" in fields
    assert isinstance(fields["alpha"], Union)
    assert String() in fields["alpha"].any_of


# Generated at 2022-06-24 10:57:26.225444
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference
    )



# Generated at 2022-06-24 10:57:28.929271
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert from_json_schema({"allOf": [{"type": "string"}, {"maxLength": 5}]}).validate(
        "hello"
    ) is None



# Generated at 2022-06-24 10:57:38.569991
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "number",
        "exclusiveMinimum": 0.0,
        "exclusiveMaximum": 10.0,
        "multipleOf": 2.0,
        "default": 2.0
    }
    field = from_json_schema_type(data, type_string="number", allow_null=False, definitions=None)
    assert isinstance(field, Float), field
    assert field.exclusive_minimum == 0.0
    assert field.exclusive_maximum == 10.0
    assert field.multiple_of == 2.0
    assert field.default == 2.0

    data = {
        "type": "integer",
        "exclusiveMinimum": 0,
        "exclusiveMaximum": 10,
        "multipleOf": 2,
        "default": 2
    }
    field = from_json_schema_type

# Generated at 2022-06-24 10:57:44.600651
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)
    try: assert isinstance(ref_from_json_schema({"$ref": "http://www.example.com"}), Reference)
    except AssertionError: pass
    else: raise Exception  # pragma: no cover



# Generated at 2022-06-24 10:57:48.300639
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1}).validate(1) == 1
    assert const_from_json_schema({"const": 1}).validate(2) is None


# Generated at 2022-06-24 10:57:55.093936
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "if": {"type": "array", "maxItems": 1,},
            "then": {"type": "array", "maxItems": 1,},
            "else": {"type": "array", "maxItems": 1,},
        },
    }

    field = if_then_else_from_json_schema(data, definitions=None)
    result = field.loads({"if": [1], "then": [2], "else": [3]})
    assert result == [1]

    result = field.loads({"if": [], "then": [2], "else": [3]})
    assert result == [3]

    result = field

# Generated at 2022-06-24 10:57:59.262614
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_dict = {"not":{"type":"string"}}
    not_field = not_from_json_schema(not_dict,None)
    # since the function is not exported, we cannot test the field returned
    assert not_field != None, "not_from_json_schema returns an object"



# Generated at 2022-06-24 10:58:06.047482
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": ["string", "null"]}, SchemaDefinitions()) == Union(
        any_of=[String(allow_null=False), Const(None)], allow_null=True
    )
    assert type_from_json_schema({"type": "number"}, SchemaDefinitions()) == Number()


# Generated at 2022-06-24 10:58:15.776159
# Unit test for function not_from_json_schema
def test_not_from_json_schema():

    # Test that the to_json_schema function of Not is the inverse of not_from_json_schema,
    # this is the closest we can get to a unit test of not_from_json_schema itself.
    fields = [
        Integer(minimum=10),
        Integer(maximum=10),
        Integer(minimum=10, maximum=10),
    ]
    for field in fields:
        data = field.to_json_schema()
        negated_field = from_json_schema(data["not"])

        assert negated_field.to_json_schema() == data
        assert negated_field.default == field.default



# Generated at 2022-06-24 10:58:23.675389
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    For testing purposes, we want to get a more human-readable version of
    the JSON schema which matches a given Field object.

    This test is a bit brittle, as it ultimately depends on testing
    that the given string equals the result of `json.dumps()` with
    `indent` set to 4. If this test fails but the output changes still
    seem valid, it probably just means that `json.dumps` changed how
    it prints the same data.
    """
    from .primitives import Boolean

    def test_one(expected: str, field: Field):
        schema = to_json_schema(field)
        delta = expected.splitlines()
        delta[0] = delta[0].lstrip()
        got = json.dumps(schema, indent=4).partition("\n")[2]

# Generated at 2022-06-24 10:58:32.639481
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert True==const_from_json_schema({'const': True, 'default': False}, {}).validate(True)
    assert None==const_from_json_schema({'const': None}, {}).validate(None)
    assert False==const_from_json_schema({'const': False}, {}).validate(False)
    assert '5'==const_from_json_schema({'const': '5'}, {}).validate('5')
    assert ['5']==const_from_json_schema({'const': ['5']}, {}).validate(['5'])
    assert {'5':5}==const_from_json_schema({'const': {'5': 5}}, {}).validate({'5':5})


# Generated at 2022-06-24 10:58:41.978141
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(data={}, type_string="null", allow_null=True) == Const(None)

    assert from_json_schema_type(data={}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    assert from_json_schema_type(data={}, type_string="object", allow_null=True) == Object(
        allow_null=True
    )
    assert from_json_schema_type(data={}, type_string="array", allow_null=True) == Array(
        allow_null=True
    )
    assert from_json_schema_type(data={}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    assert from_json_

# Generated at 2022-06-24 10:58:50.334672
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "title": "JSON Schema for simple description of products",
        "type": "object",
        "properties": {
            "product": {"type": "string"},
            "price": {
                "type": "number",
                "minimum": 0,
                "exclusiveMinimum": True,
            },
        },
        "required": ["product", "price"],
    }

    s = from_json_schema(schema, definitions)

    s.validate({
        "product": "Apple",
        "price": 0.1,
    })




# Generated at 2022-06-24 10:58:58.015904
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():

    json_schema_doc = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer",
                    "minimum": 0,
                    "maximum": 150},
            "languages": {
                "type": "array",
                "items": {"type": "string"}
            }
        },
        "anyOf": [
            {
                "type": "object",
                "allOf": [
                    {"$ref": "#/properties/name"},
                    {"$ref": "#/properties/age"},
                ],
            },
            {
                "type": "object",
                "allOf": [
                    {"$ref": "#/properties/languages"},
                ]
            }
        ]
    }
    definitions = SchemaDefinitions()


# Generated at 2022-06-24 10:59:06.669291
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "null", allow_null=True, definitions=None) is Const(None)
    assert from_json_schema_type({}, "null", allow_null=False, definitions=None) is NeverMatch()

    assert from_json_schema_type({"type": "number"}, "number", allow_null=False, definitions=None) is Float()
    assert from_json_schema_type({"type": "integer"}, "integer", allow_null=False, definitions=None) is Integer()
    assert from_json_schema_type({"type": "string"}, "string", allow_null=False, definitions=None) is String()
    assert from_json_schema_type({"type": "boolean"}, "boolean", allow_null=False, definitions=None) is Boolean()


# Generated at 2022-06-24 10:59:09.356564
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # For each of the fields defined in the json schema, test the serialization and deserialization
    pass


# Generated at 2022-06-24 10:59:18.778510
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}).validate(42) is None
    assert from_json_schema({"type": "integer"}).validate("42") is not None
    assert from_json_schema({"type": "integer", "enum": [42]}).validate(42) is None
    assert from_json_schema({"type": "integer", "enum": [42]}).validate(43) is not None
    assert from_json_schema({"type": "integer", "const": 42}).validate(42) is None
    assert from_json_schema({"type": "integer", "const": 42}).validate(43) is not None
    assert from_json_schema({"type": "integer", "const": 42}).validate(42) is None
   