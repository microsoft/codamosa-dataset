

# Generated at 2022-06-24 10:49:19.061551
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {
                "type": "string",
                "minLength": 5,
                "maxLength": 10
            },
            {
                "type": "integer",
                "minimum": 0,
                "maximum": 100
            }
        ]
    }
    definitions = SchemaDefinitions()
    # from_schema method shall be able to create a Union object from the anyOf field of the schema
    assert isinstance(any_of_from_json_schema(data, definitions), Union)
    # from_schema method shall be able to create a Union object from the anyOf field of the schema
    # that contains at least one integer field, for an integer schema
    assert isinstance(any_of_from_json_schema(data, definitions).any_of[1], Integer)
   

# Generated at 2022-06-24 10:49:25.823041
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Not function
    schema = {
        "allOf": [
            {"$ref": "#/definitions/positiveIntegers"},
            {"$ref": "#/definitions/negativeIntegers"},
        ]
    }

    assert not_from_json_schema(schema,SchemaDefinitions()) == None

# Generated at 2022-06-24 10:49:29.275189
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        'type': 'number'
    }
    assert type_from_json_schema(schema, None).__class__.__name__ == 'Number'



# Generated at 2022-06-24 10:49:36.908561
# Unit test for function to_json_schema
def test_to_json_schema(): # pragma: no cover
    data = to_json_schema([Any],)
    assert data == {
        "type": "array",
        "items": True,
    }

    assert to_json_schema([Integer]) == {
        "type": "array",
        "items": {"type": "integer"},
    }

    assert to_json_schema(Integer) == {
        "type": "integer",
    }

    assert to_json_schema({"foo": Integer}) == {
        "type": "object",
        "properties": {
            "foo": {"type": "integer"},
        },
        "required": ["foo"],
    }


# Generated at 2022-06-24 10:49:45.658773
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """Ensure that types are correctly parsed."""
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({}, allow_null=True) == Union(any_of=[Any(), Const(None)])
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "string"}, allow_null=True) == Union(
        any_of=[String(), Const(None)]
    )
    assert type_from_json_schema({"type": "number"}, allow_null=True) == Union(
        any_of=[Number(), Const(None)]
    )

# Generated at 2022-06-24 10:49:53.099865
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    
    assert set(get_valid_types({"type": ["null", "string"]})[0]) == {"string"}

# Generated at 2022-06-24 10:49:59.603866
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "$id": "#/components/schemas/PetCoordinate",
        "$schema": "http://json-schema.org/draft/2019-09/schema",
        "description": "A coordinate of a pet on a grid",
        "type": "object",
        "required": [
            "x",
            "y"
        ],
        "properties": {
            "x": {
                "$ref": "#/components/schemas/ConstrainedInteger",
                "const": 2
            },
            "y": {
                "$ref": "#/components/schemas/ConstrainedInteger",
                "const": 5
            }
        }
    }
    definitions = SchemaDefinitions()

# Generated at 2022-06-24 10:50:02.419714
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():  # pragma: no cover
    assert isinstance(enum_from_json_schema({'enum': ['a','b','c']}), Choice)



# Generated at 2022-06-24 10:50:03.790069
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="value")) == {"default": "value"}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}



# Generated at 2022-06-24 10:50:13.769685
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'not': {'type': 'boolean'}, 'default': True}
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data, definitions)
    print("\ntest_not_from_json_schema - field.schema()=", field.schema())
    for sample_data in [False, True]:
        print("test_not_from_json_schema - field.is_valid(sample_data)=", field.is_valid(sample_data))
    assert field.is_valid(False)
    assert not field.is_valid(True)


# Generated at 2022-06-24 10:50:24.088741
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "type": "string",
        "minLength": 3,
        "allOf": [{"type": "string", "maxLength": 20}, {"pattern": "^[a-z]+$"}],
    }
    field = from_json_schema(data)
    assert isinstance(field, AllOf)
    assert isinstance(field.all_of[0], String)
    assert field.all_of[0].min_length == 3
    assert field.all_of[0].max_length == 20
    assert isinstance(field.all_of[1], String)
    assert isinstance(field.all_of[1].pattern, re.Pattern)
    assert field.all_of[1].pattern.pattern == "^[a-z]+$"



# Generated at 2022-06-24 10:50:26.900775
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from_json_schema({
        "if": {
            "const": {"foo": "bar"},
        },
        "then": {
            "const": {"bar": "baz"},
        },
    })



# Generated at 2022-06-24 10:50:37.925582
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null"]}) == (set(), True)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": ["object"]}) == ({"object"}, False)
    assert get_valid_types({"type": "number"}) == ({"number", "integer"}, False)
    assert get_valid_types({"type": ["number"]}) == ({"number", "integer"}, False)
    assert get_valid_types({"type": ["number", "integer"]}) == (
        {"number", "integer"},
        False,
    )

# Generated at 2022-06-24 10:50:40.003104
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/test"})



# Generated at 2022-06-24 10:50:43.905176
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="abc")) == {"default": "abc"}
    assert get_standard_properties(Boolean(default=True)) == {"default": True}
    assert get_standard_properties(Boolean(default=False)) == {"default": False}
    assert get_standard_properties(Integer(default=None)) == {"default": None}

# Generated at 2022-06-24 10:50:56.314369
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_

# Generated at 2022-06-24 10:50:59.839605
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="foo bar")) == {"default": "foo bar"}
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default=None)) == {"default": None}



# Generated at 2022-06-24 10:51:12.400535
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "integer"},{"type": "string"}]}
    field = one_of_from_json_schema(data, {})
    assert isinstance(field, OneOf)
    assert field.one_of[0].type_name == "integer"
    assert field.one_of[1].type_name == "string"
    
    data = {"oneOf": [{"type": "integer"},{"type": "string"}]}
    field = one_of_from_json_schema(data, {})
    assert isinstance(field, OneOf)
    assert field.one_of[0].type_name == "integer"
    assert field.one_of[1].type_name == "string"
    
    data = {"oneOf": [{"type": "integer"},{"type": "string"}]}


# Generated at 2022-06-24 10:51:21.422528
# Unit test for function get_standard_properties
def test_get_standard_properties():
    @dataclass
    class TestClass(Field):
        default: typing.Any = NO_DEFAULT

    assert get_standard_properties(TestClass()) == {}
    assert get_standard_properties(TestClass(default=None)) == {"default": None}
    assert get_standard_properties(TestClass(default=3)) == {"default": 3}
    assert get_standard_properties(TestClass(default=False)) == {"default": False}
    assert get_standard_properties(TestClass(default=False)) == {"default": False}
    assert get_standard_properties(TestClass(default="abc")) == {"default": "abc"}



# Generated at 2022-06-24 10:51:27.185921
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"type": "string", "anyOf": [ {"type": "string", "minLength": 5 }, {"type": "string", "maxLength": 3 },]}
    obtained = any_of_from_json_schema(schema, definitions=None)
    assert obtained._min_length == 5



# Generated at 2022-06-24 10:51:39.487582
# Unit test for function get_standard_properties
def test_get_standard_properties():
    dicts = {}
    dicts["test1"] = {"type": "object", "properties": {"test": {"default": False}}}
    dicts["test2"] = {"type": "object", "properties": {"test": {"default": True}}}
    dicts["test3"] = {"type": "object", "properties": {"test": {"default": "test"}}}
    dicts["test4"] = {"type": "object", "properties": {"test": {"default": 0}}}
    dicts["test5"] = {"type": "object", "properties": {"test": {"default": None}}}

    assert get_standard_properties(Boolean()) == dicts["test1"]
    assert get_standard_properties(Boolean(default=True)) == dicts["test2"]

# Generated at 2022-06-24 10:51:43.898164
# Unit test for function get_standard_properties
def test_get_standard_properties():
    with pytest.raises(ValueError) as excinfo:
        get_standard_properties(String(default="foo"))
    assert (
        str(excinfo.value)
        == "Cannot convert field type 'rioak.validators.core.String' to JSON Schema"
    )

    data = get_standard_properties(String())
    assert len(data) == 0

    data = get_standard_properties(Boolean(default=True))
    assert data == {"default": True}



# Generated at 2022-06-24 10:51:53.078050
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": "string"
    }
    assert type_from_json_schema(schema, definitions=SchemaDefinitions()) == String()

    schema = {
        "type": ["string", "null"]
    }
    assert type_from_json_schema(schema, definitions=SchemaDefinitions()) == Union(any_of=[String(), None])

    schema = {
        "type": ["string", "integer"]
    }
    assert type_from_json_schema(schema, definitions=SchemaDefinitions()) == Union(any_of=[String(), Integer()])



# Generated at 2022-06-24 10:51:56.700613
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    enum = const_from_json_schema({"const" : [1,2,3,4]}, None)
    assert(enum.validate([1,2,3,4]))

# Generated at 2022-06-24 10:52:04.783224
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "test_allOf_from_json_schema": {
                "type": "number",
                "allOf": [{"minimum": 5}, {"maximum": 10}],
            }
        },
    }
    field_instance = from_json_schema(schema)
    assert field_instance.all_of[0].minimum == 5
    assert field_instance.all_of[1].maximum == 10
    assert field_instance.validate(5) == 5



# Generated at 2022-06-24 10:52:07.083265
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    actual = not_from_json_schema(
        data={"not": {"type": "string"}, 
        "default": "default_value"}, 
        definitions=None)
    expected = Not(negated=String(allow_null=False), default="default_value")
    assert actual == expected



# Generated at 2022-06-24 10:52:11.496845
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_definitions = SchemaDefinitions()
    schema_definitions["#/definitions/foo"] = Integer()
    schema_definitions["#/definitions/bar"] = String()
    data = {"$ref": "#/definitions/foo"}
    field = ref_from_json_schema(data, schema_definitions)
    assert field == Reference(to="#/definitions/foo", definitions=schema_definitions)



# Generated at 2022-06-24 10:52:18.694825
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "not": {
            "enum": ["foo", "bar"],
        },
    }
    result = not_from_json_schema(schema, definitions=None)
    assert result.default is NO_DEFAULT
    assert result.validate("baz") is None
    assert result.validate("foo") == "Value is one of ['foo', 'bar']."
    assert result.validate("bar") == "Value is one of ['foo', 'bar']."
    assert result.validate(None) == "Value is one of ['foo', 'bar']."



# Generated at 2022-06-24 10:52:21.134677
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": ["null", "number"]}) == ({"number"}, True)



# Generated at 2022-06-24 10:52:26.659709
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:52:31.514567
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["null"]}) == (set(), True)
    assert get_valid_types({"type": ["null", "string"]}) == ({'string'}, True)
    assert get_valid_types({"type": ["null", "integer"]}) == ({'integer'}, True)
    assert get_valid_types({"type": ["string", "integer"]}) == ({'string', 'integer'}, False)
    assert get_valid_types({"type": ["string", "integer", "null"]}) == ({'string', 'integer'}, True)



# Generated at 2022-06-24 10:52:36.515076
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem.base import ValidationError
    schema = {'enum': [1, 2, 3]}
    field = enum_from_json_schema(schema)
    assert field.validate(1) == 1
    assert field.validate(3) == 3
    with pytest.raises(ValidationError) as e:
        field.validate(4)
    assert e.value.message == "'4' is not an allowed value"



# Generated at 2022-06-24 10:52:44.813007
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "boolean"}) == Boolean()
    assert type_from_json_schema({"type": "number"}) == Number()
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "null"}) == Const(None)
    assert type_from_json_schema({"type": "object"}) == Object(required=[])
    assert type_from_json_schema({"type": "array"}) == Array()

    assert type_from_json_schema({"type": ["string"]}) == String()
   

# Generated at 2022-06-24 10:52:52.018892
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'boolean'}]}) == Union(any_of=[String(), Boolean()])
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'boolean'}], 'default': 'str'}) == Union(any_of=[String(), Boolean()], default='str')



# Generated at 2022-06-24 10:52:56.007319
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({"anyOf":"1,2"},{"1":"1","2":"2"}),Union)
    assert isinstance(any_of_from_json_schema({"anyOf":"1,2"},{"2":"2"}),Union)
    
    

# Generated at 2022-06-24 10:53:01.709123
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    input = {
        "anyOf": [
            {"type": "integer", "minimum": 10},
            {"type": "number", "minimum": 20.5, "exclusiveMinimum": True},
        ],
        "default": 0.5,
    }
    output = any_of_from_json_schema(data=input, definitions=definitions)
    assert output.default == 0.5



# Generated at 2022-06-24 10:53:07.849712
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field = from_json_schema_type(
        data={"type": "string", "minLength": 0},
        type_string="string",
        allow_null=False,
        definitions=None,
    )
    assert field.allow_blank is True

    field = from_json_schema_type(
        data={"type": "string", "minLength": 1},
        type_string="string",
        allow_null=False,
        definitions=None,
    )
    assert field.allow_blank is False



# Generated at 2022-06-24 10:53:08.503353
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    pass



# Generated at 2022-06-24 10:53:16.336726
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:53:21.960785
# Unit test for function type_from_json_schema

# Generated at 2022-06-24 10:53:24.134866
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}}, None) == Not(
        String(allow_blank=True)
    )


# Generated at 2022-06-24 10:53:33.525786
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from typesystem.schemas import SchemaDefinitions
    from typesystem.fields import Integer

    defintions = SchemaDefinitions()
    schema = {
        'anyOf': [
            {'type': 'integer', 'minimum': 0, 'maximum': 100},
            {'type': 'integer', 'minimum': 100, 'maximum': 200}
        ]
    }
    field = any_of_from_json_schema(schema, definitions=defintions)

    assert isinstance(field, Union)
    assert len(field.any_of) == 2
    assert field.any_of[0].convert(123) == 123
    assert isinstance(field.any_of[1], Integer)
    assert field.any_of[1].minimum == 100
    assert field.any_of[1].maximum == 200



# Generated at 2022-06-24 10:53:46.908273
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string", "minLength": 10}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, String) and field.min_length == 10

    data = {"type": "number"}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, Number)

    data = {"type": "integer"}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, Integer)

    data = {"type": "boolean"}
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, Boolean)

    data = {"type": "null"}
    field = type_from

# Generated at 2022-06-24 10:53:58.511284
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.base import Field

    schema = from_json_schema(
        {
            "allOf": [
                {
                    "if": {
                        "properties": {
                            "foo": {
                                "type": "string",
                                "pattern": r"^a*$",
                            }
                        },
                        "required": ["foo"],
                    },
                },
                {
                    "properties": {
                        "bar": {"type": "number"}
                    }
                }
            ],
            "properties": {
                "foo": {
                    "type": "string"
                },
                "bar": {
                    "type": "number",
                },
            },
        }
    )
    assert isinstance(schema, Object)
    assert isinstance(schema.fields["foo"], String)


# Generated at 2022-06-24 10:54:07.894872
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert str(any_of_from_json_schema(data={"anyOf":[]}, definitions=SchemaDefinitions()))=='Union()'
    assert str(any_of_from_json_schema(data={"anyOf":[{"type":"number"}]}, definitions=SchemaDefinitions()))=='Union(any_of=Union(any_of=[Float()]))'
    assert str(any_of_from_json_schema(data={"anyOf":[{"type":"number"},{"type":"integer"}]}, definitions=SchemaDefinitions()))=='Union(any_of=Union(any_of=[Float(), Integer()]))'

# Generated at 2022-06-24 10:54:12.790754
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    d = {"allOf": [{"type": "string"}, {"pattern": "banana"}]}
    f = all_of_from_json_schema(data=d, definitions=None)
    assert isinstance(f, AllOf)
    assert len(f.all_of) == 2



# Generated at 2022-06-24 10:54:23.222473
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert repr(ref_from_json_schema({"$ref": "#/definitions/foo"})) == (
        "Reference(to='#/definitions/foo')"
    )
    assert repr(ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={})) == (
        "Reference(to='#/definitions/foo')"
    )
    assert repr(
        ref_from_json_schema(
            {"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": Number()}
        )
    ) == "Reference(to='#/definitions/foo')"  # pragma: no cover



# Generated at 2022-06-24 10:54:34.199465
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({
        'anyOf': [
            {
                'type': 'integer',
                'default': 3
            },
            {
                'type': 'string',
                'default': 'string'
            }
        ]
    }, None).validate(1) == 1
    assert any_of_from_json_schema({
        'anyOf': [
            {
                'type': 'integer',
                'default': 3
            },
            {
                'type': 'string',
                'default': 'string'
            }
        ]
    }, None).validate('string2') == 'string2'

# Generated at 2022-06-24 10:54:44.128192
# Unit test for function from_json_schema
def test_from_json_schema():
    assert definitions["JSONSchema"].validate({"type": "object"}) == {"type": "object"}
    assert definitions["JSONSchema"].validate({"$ref": "#/definitions/JSONSchema"}) == (
        {"$ref": "#/definitions/JSONSchema"}
    )

    json_object = {
        "description": "example",
        "required": True,
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "string"},
            "c": {"type": "array", "items": {"type": "integer"}},
        },
        "additionalProperties": False,
    }


# Generated at 2022-06-24 10:54:53.304746
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {
        "type": "array",
        "items": {"type": "number"},
    }
    assert isinstance(from_json_schema(schema), Array)
    assert isinstance(from_json_schema(schema)["items"], Float)

    schema = {"type": ["number", "string", "array", "object"]}
    assert isinstance(from_json_schema(schema), Union)

    schema = {"type": "array", "items": [{"type": "number"}, {"type": "string"}]}
    assert isinstance(from_json_schema(schema), Array)
    assert isinstance(from_json_schema(schema)["items"], Union)
    assert isinstance(from_json_schema(schema)["items"][0], Float)

# Generated at 2022-06-24 10:54:58.235565
# Unit test for function to_json_schema
def test_to_json_schema():
    from .marshmallow import MarshalSchema
    from .marshmallow import String, UUID, Field, Integer, Decimal, Boolean, Array

    class CustomField(Field):
        allow_none = True

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

        def serialize(self, value, **kwargs):
            return value

        def deserialize(self, value, **kwargs):
            return value

    class CustomFieldSubclass(CustomField):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

    class LocalDefinitions(SchemaDefinitions):
        custom_field = CustomField()
        custom_field_subclass = CustomFieldSubclass()


# Generated at 2022-06-24 10:55:09.239977
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "type": "object",
        "properties": {
            "name": {"$ref": "#/definitions/name"}
        },
        "definitions": {
            "name": {
                "type": "string",
                "maxLength": 200
            }
        }
    }
    definitions = {}
    field = from_json_schema(json_schema, definitions=definitions)
    assert field.properties["name"].max_length == 200
    field.validate({"name": "Elliot"})
    field.validate({"name": "Elliot Forbes"})
    field.validate({"name": "Elliot Forbes Forbes Forbes Forbes Forbes Forbes Forbes Forbes Forbes"})
    field.validate({"name": "Elliot Forbes Forbes Forbes Forbes Forbes Forbes Forbes Forbes Forbes Forbes"})



# Generated at 2022-06-24 10:55:17.994320
# Unit test for function from_json_schema
def test_from_json_schema():

    assert from_json_schema(False).validate('foo') is False
    assert from_json_schema(True).validate('foo') is True

    assert from_json_schema({"type": "string"}).validate('foo') is True
    assert from_json_schema({"type": "string"}).validate(1) is False
    assert from_json_schema({"type": "string"}).validate(1.1) is False
    assert from_json_schema({"type": "string"}).validate(None) is False

    assert from_json_schema({"type": "integer"}).validate('foo') is False
    assert from_json_schema({"type": "integer"}).validate(1) is True

# Generated at 2022-06-24 10:55:28.670560
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "default": "abc",
        "allOf": [
            {
                "type": "string",
                "minLength": 2,
            },
            {
                "type": "string",
                "maxLength": 5,
            },
        ],
    }

    field = all_of_from_json_schema(schema, SchemaDefinitions())
    assert field.is_valid("abcd")
    assert field.is_valid("abc")
    assert field.is_valid("ab")
    assert not field.is_valid("abcde")
    assert not field.is_valid("a")
    assert not field.is_valid("abcdab")
    assert field.default == "abc"



# Generated at 2022-06-24 10:55:32.957513
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": "test",
        "default": "test"
    }
    definitions = None
    field = const_from_json_schema(data, definitions=definitions)
    assert field.validate("test") == True
    assert field.validate("different") == False
    assert field.validate(None) == False



# Generated at 2022-06-24 10:55:36.232712
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    source = {
        "enum": ["a", "b", "c"],
    }
    actual_output = enum_from_json_schema(source, definitions=None)
    expected_output = Choice(
        choices=[("a", "a"), ("b", "b"), ("c", "c")], default=NO_DEFAULT
    )
    assert actual_output == expected_output

# Generated at 2022-06-24 10:55:43.911747
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/ValidObject"] = Object(
        properties={
            "Name": String(),
            "Age": Integer(minimum=0),
        }
    )
    data = {
        "$ref": "#/definitions/ValidObject",
    }
    expected = Reference(to="#/definitions/ValidObject", definitions=definitions)
    assert ref_from_json_schema(data, definitions=definitions) == expected



# Generated at 2022-06-24 10:55:56.304995
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=False), Boolean)
    assert isinstance(
        from_json_schema_type({}, type_string="integer", allow_null=False), Integer
    )
    assert isinstance(
        from_json_schema_type({}, type_string="number", allow_null=False), Decimal
    )
    assert isinstance(
        from_json_schema_type({}, type_string="string", allow_null=False), String
    )
    assert isinstance(from_json_schema_type({}, type_string="array", allow_null=False), Array)
    assert isinstance(
        from_json_schema_type({}, type_string="object", allow_null=False), Object
    )




# Generated at 2022-06-24 10:55:57.925063
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}



# Generated at 2022-06-24 10:56:02.976206
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foobar"}
    defs = SchemaDefinitions()
    defs["#/definitions/foobar"] = String()
    assert ref_from_json_schema(data, definitions=defs) == Reference("#/definitions/foobar")



# Generated at 2022-06-24 10:56:12.333304
# Unit test for function to_json_schema

# Generated at 2022-06-24 10:56:14.015421
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    return



# Generated at 2022-06-24 10:56:25.329748
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, {}) == Any()
    assert type_from_json_schema({"type": "integer"}, {}) == Integer()
    assert type_from_json_schema({"type": "number"}, {}) == Number()
    assert type_from_json_schema({"type": "object"}, {}) == Object()
    assert type_from_json_schema({"type": "string"}, {}) == String()
    assert type_from_json_schema({"type": "null"}, {}) == Const(None)
    assert (
        type_from_json_schema({"type": "null", "type": "integer"}, {})
        == Integer() | Const(None)
    )

# Generated at 2022-06-24 10:56:37.119298
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    def _test():
        definitions = SchemaDefinitions()
        schema = {
            "$schema": "",
            "type": "object",
            "properties": {
                "a": {
                    "oneOf": [
                        {"type": "integer", "minimum": 0},
                        {"type": "integer", "maximum": 0},
                    ]
                },
                "b": {
                    "oneOf": [
                        {"type": "integer", "minimum": 0},
                        {"type": "integer", "maximum": 0},
                    ]
                },
            },
        }
        schema = from_json_schema(schema, definitions)
        print(schema)
        print(schema.validate_definition())
    # _test()



# Generated at 2022-06-24 10:56:43.942958
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type(
        {"type": "number"}, type_string="number", allow_null=False, definitions=definitions
    )

    from_json_schema_type(
        {"type": "number"}, type_string="number", allow_null=True, definitions=definitions
    )

    from_json_schema_type(
        {"type": "integer"},
        type_string="integer",
        allow_null=False,
        definitions=definitions,
    )

    with pytest.raises(AssertionError, match=r"Invalid argument type_string='array'"):
        from_json_schema_type(
            {"type": "array"}, type_string="array", allow_null=False, definitions=definitions
        )


# Generated at 2022-06-24 10:56:51.348134
# Unit test for function to_json_schema

# Generated at 2022-06-24 10:57:00.995823
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    #Case1:
    data = {'oneOf': [{'$id': '#', 'type': 'number'}, {'$id': '#', 'type': 'number'}]}
    defs = {}
    assert one_of_from_json_schema(data, defs) == OneOf(one_of=[Float(), Float()])
    #Case2:
    data = {'oneOf': [{'$ref': '#/definitions/test'}, {'$id': '#', 'type': 'number'}]}
    defs = {'#/definitions/test':Float()}
    assert one_of_from_json_schema(data, defs) == OneOf(one_of=[Reference(to='#/definitions/test', definitions={}), Float()])
    #Case3:


# Generated at 2022-06-24 10:57:09.573255
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":[{"type":"string"},{"type":"integer"}]}
    result = any_of_from_json_schema(data, definitions=definitions)
    assert type(result) is typesystem.field.Union
    assert len(result.any_of) is 2
    assert all(type(x) is typesystem.fields.String for x in result.any_of) or all(type(x) is typesystem.fields.Integer for x in result.any_of) 



# Generated at 2022-06-24 10:57:20.495275
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.fields import Array, Boolean, Integer, Number, Object, String

    s = Schema(properties={"a": type_from_json_schema({"type": "integer"})})
    assert s.is_valid({"a": 1})
    assert s.is_valid({"a": 0})
    assert s.is_valid({"a": None})
    assert s.is_valid({"a": False})
    assert s.is_valid({"a": True})
    assert not s.is_valid({"a": "1"})
    assert not s.is_valid({"a": 1.5})
    assert not s.is_valid({"a": {"foo": "bar"}})
    assert not s.is_valid({"a": ["foo", "bar"]})


# Generated at 2022-06-24 10:57:31.356021
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    def validate(kwargs):
        data = {"type": kwargs["type"]}
        data.update(kwargs.get("kwargs", {}))
        return from_json_schema(data)

    def test(data):
        asserts = [
            validate(kwargs) == value
            for kwargs, value in data.items()
            if kwargs["type"] == "boolean"
        ]
        assert all(asserts)

    test(
        {
            {"type": "boolean"}: Boolean(),
            {"type": "boolean", "kwargs": {"default": True}}: Boolean(default=True),
            {"type": "boolean", "kwargs": {"default": False}}: Boolean(default=False),
        }
    )


# Generated at 2022-06-24 10:57:33.802163
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class Schema(SchemaDefinitions):
        class field(Field):
            default = ""
    assert get_standard_properties(Schema.field) == {"default": ""}



# Generated at 2022-06-24 10:57:41.852660
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    '''
    Unit test for function if_then_else_from_json_schema
    '''

    json_schema = {
        'if': {'type': 'number'},
        'then': {'type': 'number'},
        'else': {'type': 'string'},
    }
    if_then_else = if_then_else_from_json_schema(json_schema, None)
    assert isinstance(if_then_else, IfThenElse)

    json_schema = {
        'if': {'type': 'number'},
        'then': {'type': 'number'},
    }
    if_then_else = if_then_else_from_json_schema(json_schema, None)

# Generated at 2022-06-24 10:57:52.903682
# Unit test for function from_json_schema
def test_from_json_schema():
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})
    assert JSONSchema.validate({"type": "object", "properties": {"foo": {"type": "string"}}})

# Generated at 2022-06-24 10:58:03.196913
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1,2,3]}, definitions=definitions).validate(1) == 1
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=definitions).validate("a") == "a"
    assert enum_from_json_schema({"enum": [False, True]}, definitions=definitions).validate(False) == False
    assert enum_from_json_schema({"enum": [None]}, definitions=definitions).validate(None) == None
    assert enum_from_json_schema({"enum": [None]}, definitions=definitions).validate("b") == "b"

# Generated at 2022-06-24 10:58:07.580186
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = any_of_from_json_schema({"anyOf": [{'type': 'string'}, {'type': 'integer'}]}, SchemaDefinitions())
    assert isinstance(field, Union)
    assert len(field.any_of) == 2



# Generated at 2022-06-24 10:58:18.004477
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type(from_json_schema_type({"type": "string"}, "string", False, None)) == String
    assert type(from_json_schema_type({"type": "number"}, "number", False, None)) == Float
    assert type(from_json_schema_type({"type": "integer"}, "integer", False, None)) == Integer
    assert type(from_json_schema_type({"type": "boolean"}, "boolean", False, None)) == Boolean
    assert type(from_json_schema_type({"type": "object"}, "object", False, None)) == Object
    assert type(from_json_schema_type({"type": "array"}, "array", False, None)) == Array
    assert type(from_json_schema_type({}, "null", True, None)) == Const

# Generated at 2022-06-24 10:58:24.761929
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=False), Float)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False), Integer)
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=False), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="array", allow_null=False), Array)
    assert isinstance(from_json_schema_type({}, type_string="object", allow_null=False), Object)


# Generated at 2022-06-24 10:58:31.440707
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test = {
        "oneOf": [
            {
                "type": "integer"
            },
            {
                "type": "string"
            }
        ]
    }
    res = one_of_from_json_schema(test, definitions=definitions)
    for i in range(-3,3,1):
        assert res(str(i)) == False
        assert res("a") == False
    for i in range(3,6,1):
        assert res("a") == False
        assert res(str(i)) == True


# Generated at 2022-06-24 10:58:35.270268
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({
        "allOf": [
            {"type": "number"},
            {"minimum": 1}
        ]
    }) == AllOf(all_of=[
        Number(),
        Number(minimum=1)
    ])



# Generated at 2022-06-24 10:58:38.835011
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({
        "oneOf": [
            {"type": "number"},
            {"type": "integer"},
        ]
    }, definitions=SchemaDefinitions()).validate(2) == 2


# Generated at 2022-06-24 10:58:48.606128
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(data={"type": "string"}, definitions=definitions) == String()
    assert type_from_json_schema(data={"type": ["string", "integer"]}, definitions=definitions) == Union(
        items=[String(), Integer()], allow_null=False
    )
    assert type_from_json_schema(data={"type": ["object", "array"], "items": {"type": "string"}}, definitions=definitions) == Union(
        items=[
            Object(properties={"items": Array(items=String())}),
        ],
        allow_null=False
    )
    assert type_from_json_schema(data={}, definitions=definitions) == Any()



# Generated at 2022-06-24 10:58:56.834142
# Unit test for function get_valid_types
def test_get_valid_types():
    null_allowed_data = {"type": "null"}
    valid_types, allow_null = get_valid_types(null_allowed_data)
    try:
        assert valid_types == set()
    except AssertionError:
        print("Test failed: null allowed")
    try:
        assert allow_null == True
    except AssertionError:
        print("Test failed: null allowed")

    null_disallowed_data = {"type": "boolean"}
    valid_types, allow_null = get_valid_types(null_disallowed_data)
    try:
        assert valid_types == set("boolean")
    except AssertionError:
        print("Test failed: null not allowed")

# Generated at 2022-06-24 10:59:00.948543
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    import json

    data = json.loads('{ "not": { "type": "integer" } }')
    assert isinstance(not_from_json_schema(data, None), Not)
    assert isinstance(not_from_json_schema(data, None).negated, Integer)



# Generated at 2022-06-24 10:59:04.744364
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert isinstance(enum_from_json_schema({'enum':[1,2,3,4]},SchemaDefinitions()),Choice)
    assert enum_from_json_schema({'enum':[1,2,3,4]},SchemaDefinitions()).choices == [(1,1),(2,2),(3,3),(4,4)]



# Generated at 2022-06-24 10:59:10.955579
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import get_valid_types
    from typesystem.fields import Number, Integer, String, Boolean, Array, Object, Float
    from typesystem.schemas import SchemaDefinitions

    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema
    for allow_null, type_string in get_valid_types({"type": "boolean"}):
        field = from_json_schema_type(
            data={"type": "boolean"},
            type_string=type_string,
            allow_null=allow_null,
            definitions=definitions,
        )
        assert isinstance(field, Boolean)
