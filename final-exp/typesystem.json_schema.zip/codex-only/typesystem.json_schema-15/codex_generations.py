

# Generated at 2022-06-24 10:49:21.608154
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": ["unknown"]}) == ({"unknown"}, False)
    assert get_valid_types({"type": "unknown"}) == ({"unknown"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)
    assert get_valid_types({"type": ["null", "number"]}) == ({"number"}, True)
    assert get_valid_types({"type": ["null", "number"], "multipleOf": 2}) == ({}, True)
    assert get_valid_types({"type": "integer", "multipleOf": 2}) == ({"integer"}, False)
    assert get_valid_types({"type": "number", "multipleOf": 2}) == ({"number"}, False)

# Generated at 2022-06-24 10:49:32.858669
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()
    assert type_from_json_schema({"type": True}, definitions={}) == Any()
    assert type_from_json_schema({"type": False}, definitions={}) == NeverMatch()
    assert type_from_json_schema({"type": "boolean"}, definitions={}) == Boolean()
    assert type_from_json_schema({"type": "null"}, definitions={}) == {True: Const(None), False: NeverMatch()}[True]
    assert type_from_json_schema({"type": "integer"}, definitions={}) == Integer()
    assert type_from_json_schema({"type": "number"}, definitions={}) == Number()
    assert type_from_json_schema({"type": "string"}, definitions={}) == String

# Generated at 2022-06-24 10:49:42.128811
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}
    assert get_standard_properties(String(default="hello")) == {"default": "hello"}
    assert get_standard_properties(String(default=None)) == {"default": None}


decorator_results: typing.MutableMapping[typing.Tuple[str, int], DecoratorResult] = {}



# Generated at 2022-06-24 10:49:48.483240
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem import Schema

    schema = from_json_schema(
        {
            "type": "string",
            "enum": ["foo", "bar"],
            "default": "bar",
        }
    )
    assert isinstance(schema, Field)
    assert isinstance(schema, Choice)

    schema = Schema(schema=schema)
    assert schema.is_valid("foo")
    assert schema.is_valid("bar")
    assert not schema.is_valid("baz")
    assert not schema.is_valid(None)
    assert schema.serialize() == "bar"



# Generated at 2022-06-24 10:49:53.637807
# Unit test for function to_json_schema
def test_to_json_schema():
    field = String(pattern_regex=r"^\d{4}$")
    result = to_json_schema(field)
    expected = {
        "type": "string",
        "pattern": "^\\d{4}$",
        "description": None,
        "title": None,
        "default": None,
    }
    assert result == expected



# Generated at 2022-06-24 10:50:03.581893
# Unit test for function to_json_schema
def test_to_json_schema():
    import jsonschema
    from .schemas import ExampleSchema

    schema = ExampleSchema.make_validator()
    schema_def = to_json_schema(schema)

    jsonschema.Draft7Validator(schema_def)
    assert jsonschema.validate({"age": 25}, schema_def) is None
    errors = list(jsonschema.iter_errors({"age": -1}, schema_def))
    assert len(errors) == 1
    error = errors[0]
    assert error.validator == "minimum"
    assert error.validator_value == 0



# Generated at 2022-06-24 10:50:16.029312
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_schema = {
        "type": "object",
        "properties": {
            "firstName": {"type": "string"},
            "lastName": {"type": "string"},
            "age": {"type": "integer"},
        },
        "required": ["firstName", "lastName"],
    }

# Generated at 2022-06-24 10:50:28.216854
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    validator = Integer(minimum=10, maximum=20, default=11)
    assert to_json_schema(validator) == {
        "type": "integer",
        "minimum": 10,
        "maximum": 20,
        "default": 11,
    }

    validator = Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")])
    assert to_json_schema(validator) == {"enum": ["a", "b", "c"]}

    validator = String(allow_blank=True, pattern_regex=re.compile(r"^[a-z]{5,10}$", re.I))

# Generated at 2022-06-24 10:50:38.754687
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "$ref": "#/definitions/simple_schema_restriction_object"
            },
            {
                "$ref": "#/definitions/simple_string_restriction_object"
            }
        ]
    }
    definitions = {
        "simple_schema_restriction_object": {
            "definitions": {
                "simple_string_restriction_object": {
                    "type": "string"
                }
            }
        },
        "simple_string_restriction_object": {
            "type": "string"
        }
    }


# Generated at 2022-06-24 10:50:42.200676
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": ["number"]}}
    result = not_from_json_schema(data, definitions=None)
    expected = Not(negated=Float(min_value=None, max_value=None, allow_null=False))
    assert result == expected



# Generated at 2022-06-24 10:50:49.128984
# Unit test for function to_json_schema
def test_to_json_schema():
    from .standard_fields import string, integer, float, boolean
    from .struct import Object, Array
    from .containers import Choice, Const

    class Person(Object):
        name = string()
        age = integer()
        height = float()
        surname = string(optional=True)

        def __init__(self, name: str, age: int, height: float, surname: str = None):
            super().__init__()
            self.name = name
            self.age = age
            self.height = height
            self.surname = surname

    class People(Array, items=Person):
        def __init__(self, items: typing.List[Person] = None):
            super().__init__()
            self.items = items

    class PeopleSchema(Object):
        class Schema:
            name = string

# Generated at 2022-06-24 10:51:00.088327
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
      "allOf": [
        {
          "$ref": "#/definitions/$_id"
        },
        {
          "properties": {
            "_rev": {
              "$ref": "#/definitions/$_rev"
            }
          }
        }
      ]
    }

    definitions = SchemaDefinitions()
    definitions["$_id"] = String(pattern=r"^[A-Za-z0-9]{5}$")
    definitions["$_rev"] = String(pattern=r"^[0-9]+-[A-Za-z]+$")

    test = from_json_schema(data, definitions=definitions)
    assert test.is_valid("ABC12") is False
    assert test.is_valid("ABC12", _rev="1-B") is True

# Generated at 2022-06-24 10:51:04.040450
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    """
    Test function 'enum_from_json_schema'
    """
    assert enum_from_json_schema({'enum': [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({'enum': [1, 2, 3], 'default': 2}) == Choice(choices=[(1, 1), (2, 2), (3, 3)], default=2)


# Generated at 2022-06-24 10:51:05.930617
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
	assert all_of_from_json_schema({}) == None


# Generated at 2022-06-24 10:51:18.436079
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # type: () -> None
    if_clause_str = """{
    "type": "number"
}"""
    then_clause_str = """{
    "const": 6
}"""
    else_clause_str = """{
    "not": {"const": 5}
}"""
    data = {
        "if": loads(if_clause_str),
        "then": loads(then_clause_str),
        "else": loads(else_clause_str),
    }
    actual = if_then_else_from_json_schema(data, SchemaDefinitions())
    assert isinstance(actual, IfThenElse)
    assert isinstance(actual.if_clause, Float)
    assert isinstance(actual.then_clause, Const)

# Generated at 2022-06-24 10:51:23.279009
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields as f
    from . import schemas
    from .validators import Any, Boolean, Const, Integer

    assert to_json_schema(Any) is True
    assert to_json_schema(Boolean) == {"type": "boolean"}
    assert to_json_schema(Const(const="foo")) == {"const": "foo"}
    assert to_json_schema(Integer(minimum=2)) == {"minimum": 2, "type": "integer"}
    assert to_json_schema(Integer(minimum=2, default="baz")) == {
        "minimum": 2,
        "type": "integer",
        "default": "baz",
    }

# Generated at 2022-06-24 10:51:25.888313
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    >>> definitions = SchemaDefinitions()
    >>> schema = {'type':['integer', 'null']}
    >>> from_json_schema(schema, definitions=definitions)
    Union(any_of=[Integer()], allow_null=True)
    """



# Generated at 2022-06-24 10:51:30.791883
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Object(
        properties={
            "name": String(min_length=2, max_length=8, allow_null=True),
            "age": Integer(minimum=18, maximum=65, allow_null=True),
        },
        required=["name"],
    )

    schema_json = to_json_schema(schema)
    assert schema_json == {
        "type": "object",
        "properties": {
            "name": {"type": ["string", "null"], "minLength": 2, "maxLength": 8,},
            "age": {"type": ["integer", "null"], "minimum": 18, "maximum": 65,},
        },
        "required": ["name"],
    }

    ref_schema = Object(properties={"ref": Reference("#/definitions/name")})
    schema

# Generated at 2022-06-24 10:51:36.183085
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not":{"type":"string"}}
    definitions = {'not': {"type":"string"}}
    test_result = from_json_schema(data, definitions)
    assert isinstance(test_result, Not)


# Generated at 2022-06-24 10:51:38.500790
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": True}
    const = const_from_json_schema(data, definitions=None)
    assert const.validate(value=True) == True



# Generated at 2022-06-24 10:51:42.731036
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf":[{"$ref":"#/definitions/Ref"}]},definitions).str_schema() == "AllOf(Ref)"


# Generated at 2022-06-24 10:51:51.825327
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert str(from_json_schema_type(
        {}, type_string="number", allow_null=False, definitions=None
    )) == "typesystem.Float(allow_null=False)"

    assert str(from_json_schema_type(
        {}, type_string="integer", allow_null=False, definitions=None
    )) == "typesystem.Integer(allow_null=False)"

    assert str(from_json_schema_type(
        {}, type_string="string", allow_null=False, definitions=None
    )) == "typesystem.String(allow_null=False)"

    assert str(from_json_schema_type(
        {}, type_string="boolean", allow_null=False, definitions=None
    )) == "typesystem.Boolean(allow_null=False)"

   

# Generated at 2022-06-24 10:52:01.216241
# Unit test for function from_json_schema
def test_from_json_schema():
    assert(from_json_schema({"$ref": "#/definitions/MyDefinition"}) == Reference("MyDefinition"))
    assert(from_json_schema({"type": "string"}) == String())
    assert(from_json_schema({"type": ["string", "null"]}) == Union([String(), None]))
    assert(from_json_schema({"enum": ["a", "b"]}) == Choice(["a", "b"]))
    assert(from_json_schema({"const": "value"}) == Const("value"))

    assert(from_json_schema({"allOf": [{"type": "string"}, {"enum": ["a", "b"]}]}) == \
    AllOf([String(), Choice(["a", "b"])]))

# Generated at 2022-06-24 10:52:06.426980
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    input_data = {
        "type": "object",
        "properties": {"foo": {"type": "number"}},
        "not": {
            "type": "object",
            "properties": {"bar": {"type": "number"}},
        },
    }
    result = not_from_json_schema(input_data, definitions=None)
    assert isinstance(result, types.Not)
    assert isinstance(result.field, types.Object)
    assert isinstance(result.negated, types.Object)
    assert result.field.properties == {"foo": Integer()}
    assert result.negated.properties == {"bar": Integer()}



# Generated at 2022-06-24 10:52:14.764226
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()
    assert type_from_json_schema({"type": "string", "null": True}, definitions=None) == Union(any_of=[String(), Const(None)], allow_null=True)
    assert type_from_json_schema({"type": "integer"}, definitions=None) == Integer()
    assert type_from_json_schema({"type": "integer", "null": True}, definitions=None) == Union(any_of=[Integer(), Const(None)], allow_null=True)
    assert type_from_json_schema({"type": "number"}, definitions=None) == Number()

# Generated at 2022-06-24 10:52:18.828879
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_then_else = IfThenElse.from_json_schema(
        {
            "if": {"type": "number"},
            "then": {"type": "number"},
            "else": {"type": "string"},
            "default": "foo",
        }
    )
    assert if_then_else.validate(123) == 123
    assert if_then_else.validate("foo") == "foo"
    assert if_then_else.validate(None) == "foo"
    assert if_then_else.validate(False) == "foo"
    assert if_then_else.validate(True) == "foo"
    assert if_then_else.validate("bar") is None



# Generated at 2022-06-24 10:52:25.337078
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf":[{"$ref":"#/definitions/titles"}, {"$ref":"#/definitions/key"}]}
    definitions = SchemaDefinitions()
    definitions["titles"] = String(pattern=re.compile(r'^[a-zA-Z\s]+$'))
    definitions["key"] = String(pattern=re.compile(r'^[a-zA-Z0-9\s]+$'))
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate("engineer") is None
    assert field.validate("Engineer") is None



# Generated at 2022-06-24 10:52:34.136478
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema_object = {"type": "integer", "minimum": 1, "maximum": 10}
    result = from_json_schema_type(
        json_schema_object,
        type_string="integer",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    assert isinstance(result, Integer), f"Expected an instance of Integer but got {result!r}"
    assert result.allow_null == False
    assert result.minimum == 1
    assert result.maximum == 10
    assert result.exclusive_minimum == None
    assert result.exclusive_maximum == None
    assert result.multiple_of == None
    assert result.default == NO_DEFAULT


# Generated at 2022-06-24 10:52:36.586925
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({"oneOf": ["1", "2"]}, None).one_of == ["1", "2"]
    assert one_of_from_json_schema({"oneOf": ["4", "5"]}, None).one_of == ["4", "5"]



# Generated at 2022-06-24 10:52:40.495171
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    enum_values = [1, 2, 3]
    data = {"enum": enum_values}
    choices = enum_from_json_schema(data, definitions)
    assert all([choice in choices for choice in enum_values])



# Generated at 2022-06-24 10:52:49.852153
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema({}) == Any()
    assert from_json_schema({"type": ["integer"]}) == Integer()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": ["null"]}) == NeverMatch()
    assert from_json_schema

# Generated at 2022-06-24 10:52:55.921770
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "null"},
        "default": None
    }
    definitions = SchemaDefinitions()
    expected = Not(
        negated=from_json_schema(
            data["not"], definitions=definitions
        ),
        default=data.get("default", NO_DEFAULT)
    )
    result = not_from_json_schema(data, definitions)
    assert result == expected



# Generated at 2022-06-24 10:53:05.819799
# Unit test for function from_json_schema
def test_from_json_schema():
    # Given
    json_schema = {
        "type": "object",
        "required": ["field_1", "field_2", "field_3"],
        "properties": {
            "field_1": {"type": "null"},
            "field_2": {"type": "integer"},
            "field_3": {"type": "string", "pattern": "^[a-z]+$"},
        },
    }

    # When
    field = from_json_schema(json_schema)

    # Then
    assert field.validate_and_convert({"field_2": 3, "field_3": "abc"}) == {
        "field_1": None,
        "field_2": 3,
        "field_3": "abc",
    }
    assert field.validate_and_con

# Generated at 2022-06-24 10:53:14.251743
# Unit test for function get_valid_types
def test_get_valid_types():
    test_cases = [({"type": "string"}, {"string"}, False),
                  ({"type": ["string", "integer"]}, {"string", "integer"}, False),
                  ({"type": "null"}, {"null"}, True),
                  ({"type": ["string", "null"]}, {"string"}, True),
                  ({"type": ["string", "number"]}, {"string", "number"}, False),
                  ({"type": ["string", "integer", "null"]}, {"string", "integer"}, True),
                  ({}, {"null", "boolean", "object", "array", "number", "string"}, False)]
    for test_case in test_cases:
        type_strings, allow_null = get_valid_types(test_case[0])
        assert(type_strings == test_case[1])

# Generated at 2022-06-24 10:53:15.618849
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()



# Generated at 2022-06-24 10:53:23.051223
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = '{"allOf": [{"type": "string", "minLength": 3}, {"type": "string", "maxLength": 10}]}'
    parsed_schema = Schema(schema)
    assert all_of_from_json_schema(parsed_schema._schema["allOf"], SchemaDefinitions()) == AllOf({
        type_from_json_schema({"type": "string", "minLength": 3}, SchemaDefinitions()),
        type_from_json_schema({"type": "string", "maxLength": 10}, SchemaDefinitions())
    })


# Generated at 2022-06-24 10:53:30.189224
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "type": "integer",
                "minimum": 2,
                "maximum": 4
            },
            {
                "type": "integer",
                "minimum": 3,
                "maximum": 6
            }
        ]
    }
    definitions = {}
    field = all_of_from_json_schema(data, definitions=definitions)
    assert(field.validate(4) == 4)
    assert(field.validate(5) == None)


# Generated at 2022-06-24 10:53:41.204445
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=line-too-long
    ref = Reference("string")
    assert to_json_schema(ref) == {
        "type": "string",
        "definitions": {
            "string": {
                "type": "string",
            },
        },
    }

    schema = Any(name="string")
    assert to_json_schema(schema) == {"type": "string"}
    assert to_json_schema(schema, {
        "string": {
            "type": "string",
        },
    }) == {"$ref": "#/definitions/string"}

    schema = Integer(name="int", allow_null=True)
    assert to_json_schema(schema) == {
        "type": ["integer", "null"],
    }

    schema = Integer

# Generated at 2022-06-24 10:53:52.799128
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)
    assert get_valid_types({"type": ["number", "string"]}) == ({"number", "string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)

# Generated at 2022-06-24 10:53:59.704385
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json_schema_string = """
    {
        "not": {
            "type": "string"
        }
    }
    """
    x = from_json_schema(json.loads(json_schema_string))
    assert x.validate(123)
    assert not x.validate("abc")

# Generated at 2022-06-24 10:54:01.623192
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, 'string', False, SchemaDefinitions()) == String()



# Generated at 2022-06-24 10:54:04.594179
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = const_from_json_schema({"const": "abc"}, definitions=None)
    assert schema.validate("abc") == "abc"
    assert schema.validate("def") == "abc"



# Generated at 2022-06-24 10:54:07.674560
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref_field = ref_from_json_schema( {"$ref": "#/number"})
    assert ref_field.to == "#/number"
    assert ref_field.definitions is None
# unit test for function test_json_schema

# Generated at 2022-06-24 10:54:15.831327
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from .util import Validator

    class C3(Schema):
        def __init__(self, default=3):
            field = Integer(default=default)
            super().__init__(field=field)

    c3 = C3()
    c3_result = Validator(c3.make_validator())
    assert c3_result(1) == 1
    assert c3_result("1") == 1
    assert c3_result("-1") is None
    assert c3_result() == 3
    assert c3_result("") is None
    assert c3_result("x") is None



# Generated at 2022-06-24 10:54:27.326054
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # We do not provide default in data dict
    data = {"allOf": [
        {"type":"integer", "minimum":2, "maximum":20, "required": True},
        {"type":"integer", "minimum":10, "maximum":24, "required": True},
        {"type":"integer", "minimum":16, "maximum":30, "required": True}
    ]}
    result = all_of_from_json_schema(data, definitions=None)
    assert len(result.all_of) == 3
    assert result.default == NO_DEFAULT
    assert result.all_of[0].minimum == 2
    assert result.all_of[0].maximum == 20
    assert isinstance(result.all_of[2], Integer)

    # We provide default in data dict

# Generated at 2022-06-24 10:54:34.811504
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': ['null']}) == (set(), True)
    assert get_valid_types({'type': 'boolean'}) == ({'boolean'}, False)
    assert get_valid_types({'type': ['boolean']}) == ({'boolean'}, False)
    assert get_valid_types({'type': ['boolean', 'null']}) == ({'boolean'}, True)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)

# Generated at 2022-06-24 10:54:40.724971
# Unit test for function get_standard_properties
def test_get_standard_properties():
    a = Integer(default=1)
    data = get_standard_properties(a)
    assert data["default"] == 1
    b = Object(properties={"a": Integer()}, default={"a": 1})
    data = get_standard_properties(b)
    assert data["default"] == {"a": 1}



# Generated at 2022-06-24 10:54:48.339153
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({"type": "null"}) == Const(None)
    assert type_from_json_schema({"type": "null", "const": None}) == Const(None)
    assert type_from_json_schema({"type": "null", "const": 42}) == NeverMatch()
    assert type_from_json_schema({"type": ["null", "string"]}) == Union(
        any_of=[Const(None), String()], allow_null=True
    )
    assert type_from_json_schema({"type": "boolean"}) == Boolean()
    assert type_from_json_schema({"type": "string"}) == String()

# Generated at 2022-06-24 10:54:58.557782
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema({}, definitions={}) is Any()
    assert type_from_json_schema({"type": None}, definitions={}) is Any()
    assert type_from_json_schema({"type": "null"}, definitions={}) is Const(None)
    assert type_from_json_schema({"type": "boolean"}, definitions={}) is Boolean()
    assert type_from_json_schema({"type": "integer"}, definitions={}) is Integer()
    assert type_from_json_schema({"type": "number"}, definitions={}) is Number()
    assert type_from_json_schema({"type": "string"}, definitions={}) is String()
    assert type_from_json_schema({"type": "array"}, definitions={}) is Array()
    assert type_from_json_schema

# Generated at 2022-06-24 10:55:05.136023
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    try:
        not_from_json_schema({"not": "not"}, definitions=definitions)
    except AttributeError:
        pass
    except Exception as e:
        assert AttributeError, e



# Generated at 2022-06-24 10:55:16.626414
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        properties={
            "a": Integer(allow_null=True),
            "b": String(max_length=10, pattern_regex=re.compile(r"^abc$")),
        },
        additional_properties=False,
    )
    data = to_json_schema(schema)
    expected_data = {
        "properties": {
            "a": {"type": ["integer", "null"]},
            "b": {
                "type": "string",
                "maxLength": 10,
                "pattern": "^abc$",
            },
        },
        "additionalProperties": False,
        "type": "object",
    }
    assert data == expected_data



# Generated at 2022-06-24 10:55:28.222487
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="asdf")) == {"default": "asdf"}
    assert get_standard_properties(String()) == {}



# Generated at 2022-06-24 10:55:35.904112
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': ['null', 'string']}) == ({'string'}, True)
    assert get_valid_types({'type': 'array'}) == ({'array'}, False)

# Generated at 2022-06-24 10:55:43.367500
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    schema = {
        "type": "object",
        "properties": {
            "color": {"type": "string", "enum": ["black", "white"]},
            "number": {"type": "number", "multipleOf": 1.5},
            "created": {"type": "string", "format": "date-time"},
            "status": {"type": "integer", "minimum": 1, "maximum": 5},
            "version": {"type": "string", "pattern": r"^(0|[1-9]\d*)$"},
        },
        "required": ["version", "color", "created", "status"],
    }


# Generated at 2022-06-24 10:55:56.198058
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(IntegerString()) == {
        "type": ["string", "number", "null"],
        "format": "integer-string"
    }

    assert to_json_schema(String(min_length=2, max_length=10,
                                 pattern_regex=re.compile('^[a-z]+$'))) == {
        "type": "string",
        "minLength": 2,
        "maxLength": 10,
        "pattern": '^[a-z]+$'
    }

    assert to_json_schema(DecimalString()) == {
        "type": ["string", "number", "null"],
        "format": "decimal-string"
    }


# Generated at 2022-06-24 10:56:01.165719
# Unit test for function get_valid_types
def test_get_valid_types():
    # Test the null allow case
    type_strings, allow_null = get_valid_types(dict(type=["null", "boolean"]))
    assert allow_null
    assert "boolean" in type_strings

    # Test the null not allowed case
    type_strings, allow_null = get_valid_types(dict(type=["boolean"]))
    assert not allow_null
    assert "boolean" in type_strings


# Generated at 2022-06-24 10:56:10.148734
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "string"},
                },
                "required": ["a", "b"],
            },
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "c": {"type": "string"},
                },
                "required": ["a", "c"],
            },
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.validate(instance={"a": 1, "b": "b"}) == True

# Generated at 2022-06-24 10:56:13.555610
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    val = one_of_from_json_schema({'oneOf':[{'const': 3},{'const': 4}]}, {}).convert({})
    assert isinstance(val, OneOf)
    assert len(val.one_of) == 2
    assert isinstance(val.one_of[0], Const)
    assert isinstance(val.one_of[1], Const)
    assert val.one_of[0].const == 3
    assert val.one_of[1].const == 4



# Generated at 2022-06-24 10:56:15.794749
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    definition={"not": {"type":"string"}}
    field=not_from_json_schema(definition, None)
    assert isinstance(field, Not)
    assert field.negated is Any()



# Generated at 2022-06-24 10:56:26.281574
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, "hello", "world"]}, definitions={}) == Choice(choices=[(1, 1), (2, 2), ("hello", "hello"), ("world", "world")], default=None)
    assert enum_from_json_schema({"enum": [1, 2, "hello"], "default": "world"}, definitions={}) == Choice(choices=[(1, 1), (2, 2), ("hello", "hello")], default="world")
    # Test for objects that accept null
    assert enum_from_json_schema({"enum": [1, 2, None]}, definitions={}) == Choice(choices=[(1, 1), (2, 2), (None, None)], allow_null=True, default=None)
    # Test for numbers that accept null
   

# Generated at 2022-06-24 10:56:33.994368
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of = {"oneOf": [
        {"type": "string", "minLength": 1},
        {"type": "integer", "minimum": 1, "maximum": 10}
    ]}
    assert one_of_from_json_schema(one_of, definitions=definitions).validate(1)
    assert one_of_from_json_schema(one_of, definitions=definitions).validate("test")


# Generated at 2022-06-24 10:56:42.050549
# Unit test for function get_valid_types
def test_get_valid_types():
    # Given
    data1 = {
        "type": "boolean",
    }
    data2 = {
        "type": "boolean",
        "nullable": True,
    }
    data3 = {
        "type": "null",
    }
    data4 = {
        "type": ["number", "null"],
    }
    data5 = {
        "type": ["null", "number"],
    }

    # When
    type_strings1, allow_null1 = get_valid_types(data1)
    type_strings2, allow_null2 = get_valid_types(data2)
    type_strings3, allow_null3 = get_valid_types(data3)
    type_strings4, allow_null4 = get_valid_types(data4)
    type_strings5,

# Generated at 2022-06-24 10:56:52.886403
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    #"allOf":[{"$ref":"#/definitions/positiveInteger"},{"minimum":3}]
    schema = {"$schema": "http://json-schema.org/draft/2019-09/schema#","allOf":[{"$ref":"#/definitions/positiveInteger"},{"minimum":3}],"definitions":{"positiveInteger":{"type":"integer","exclusiveMinimum":0}}}
    schema_definitions = SchemaDefinitions()
    schema_definitions["#/definitions/positiveInteger"] = from_json_schema(schema["definitions"]["positiveInteger"])
    assert isinstance(all_of_from_json_schema(schema, schema_definitions), AllOf)
    #"allOf":[{"enum":["a","b"]},{"minimum":2}]

# Generated at 2022-06-24 10:57:02.597822
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # type: () -> None
    """
    Unit test for function if_then_else_from_json_schema
    """

    # Test basics
    data = {"if": {"const": True}, "then": {"const": True}, "else": {"const": False}}

    field = if_then_else_from_json_schema(data, definitions=SchemaDefinitions())

    assert validate(field, True) == True
    assert validate(field, False) == False

    # Test that allow_null is taken into account
    data = {
        "if": {"const": None},
        "then": {"const": None, "type": "object"},
        "else": {"const": None, "type": "integer"},
    }


# Generated at 2022-06-24 10:57:10.740383
# Unit test for function to_json_schema
def test_to_json_schema():
    def assert_type(arg, expected_type):
        assert isinstance(arg, expected_type)
        assert not isinstance(arg, type(expected_type))

    # References
    args = Schema(Reference("str", definitions=dict(str=String())))
    data = to_json_schema(args)
    assert data == {
        "type": "string",
        "definitions": {"str": {"type": "string"}},
    }

    # Strings
    args = Schema(String())
    data = to_json_schema(args)
    assert data["type"] == "string"
    assert_type(data["type"], typing.Iterable)

    args = Schema(String(min_length=5))
    data = to_json_schema(args)

# Generated at 2022-06-24 10:57:21.130217
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:57:29.325674
# Unit test for function from_json_schema

# Generated at 2022-06-24 10:57:38.919567
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import from_json_schema

    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"$ref": "#/definitions/foo"}) == Schema(
        ref="#/definitions/foo"
    )

    assert from_json_schema({"$ref": "#/definitions/foo", "patternProperties": {}}) == AllOf(
        [
            Schema(ref="#/definitions/foo"),
            Object(properties={}, pattern_properties={}),
        ]
    )

    assert from_json_schema({"type": "string"}) == String()

# Generated at 2022-06-24 10:57:43.456624
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 4}, definitions={}).match(4)
    assert not const_from_json_schema({"const": 4}, definitions={}).match(4.0)



# Generated at 2022-06-24 10:57:49.233222
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    data = {"$ref": "#/definitions/foo"}
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.definitions is definitions
    assert field.to == "#/definitions/foo"



# Generated at 2022-06-24 10:57:55.879479
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="null", allow_null=True) == Any()
    assert from_json_schema_type({}, type_string="null", allow_null=False) == NeverMatch()
    assert from_json_schema_type({}, type_string="string", allow_null=True) == Any()
    assert from_json_schema_type({}, type_string="number", allow_null=False) == Float()
    assert from_json_schema_type({}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({}, type_string="boolean", allow_null=False) == Boolean()
    assert from_json_schema_type({}, type_string="array", allow_null=False) == Array()
   

# Generated at 2022-06-24 10:57:59.529718
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field = from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=definitions)
    assert isinstance(field, String)
    assert field.allow_null is False



# Generated at 2022-06-24 10:58:06.340193
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_data = {"anyOf": [{"type": "integer"}, {"type": "string"}], "default": "meow"}
    field = any_of_from_json_schema(test_data, [])
    assert (
        repr(field) == repr(Union(any_of=[Integer(), String()], default="meow"))
    )



# Generated at 2022-06-24 10:58:16.906874
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {"type": ["boolean", "null"]}
    actual = type_from_json_schema(schema, definitions=SchemaDefinitions())
    assert isinstance(actual, Union)
    assert isinstance(actual.any_of[0], Boolean)
    assert isinstance(actual.any_of[1], Const)
    assert actual.any_of[1].const == None

    schema = {"type": "string"}
    actual = type_from_json_schema(schema, definitions=SchemaDefinitions())
    assert isinstance(actual, String)

    schema = {"type": "null"}
    actual = type_from_json_schema(schema, definitions=SchemaDefinitions())
    assert isinstance(actual, Const)
    assert actual.const == None

    schema = {"type": "number"}
   

# Generated at 2022-06-24 10:58:23.423603
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "string"}, {"maxLength": 10}]}
    allof1 = all_of_from_json_schema(data, definitions=None)
    assert allof1.validate("five") == "five"
    assert allof1.validate("12345678910") == "12345678910"
    assert allof1.serialize("five") == "five"
    assert allof1.serialize("12345678910") == "12345678910"
    assert allof1.to_json_schema() == \
        {"allOf": [{"type": "string"}, {"maxLength": 10}]}



# Generated at 2022-06-24 10:58:26.177051
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="foo")) == {"default": "foo"}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}



# Generated at 2022-06-24 10:58:30.319262
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference_string = "#/definitions/Decimal"
    definitions = SchemaDefinitions()
    definitions[reference_string] = Decimal()
    out = ref_from_json_schema({"$ref": reference_string}, definitions=definitions)
    assert isinstance(out, Reference)
    assert out.to == reference_string



# Generated at 2022-06-24 10:58:34.686899
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = any_of_from_json_schema(
        data={"anyOf": [{"type": "integer"}, {"type": "string"}]},
        definitions=SchemaDefinitions(),
    )
    field.validate(3)
    field.validate("abc")



# Generated at 2022-06-24 10:58:43.462323
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    d = {
        'type': 'object',
        'allOf': [
            {'properties': {'a': {'type': 'string'}}},
            {'properties': {'a': {'minLength': 1}}},
        ]
    }
    assert all_of_from_json_schema(d, definitions=definitions) == AllOf(
        all_of=[
            Object(properties={'a': String(allow_null=False)}),
            Object(properties={'a': String(min_length=1, allow_null=False)}),
        ],
        allow_null=False,
    )



# Generated at 2022-06-24 10:58:49.489318
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema({}, {"string"}) == Any() # TODO: this is not correct
    assert type_from_json_schema({"type": "integer"}, {"integer"}) == Any() # TODO: this is not correct



# Generated at 2022-06-24 10:58:55.066807
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from pprint import pprint

# Generated at 2022-06-24 10:59:03.381513
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Testing Integer
    type_string = 'integer'
    data = {
        "minimum": 1,
        "maximum": 3,
        "default": 2
    }
    assert from_json_schema_type(data, type_string, False, None).minimum == 1
    assert from_json_schema_type(data, type_string, False, None).maximum == 3
    assert from_json_schema_type(data, type_string, False, None).default == 2

    data = {
        "minimum": 2,
        "maximum": 3,
        "default": 0
    }
    assert from_json_schema_type(data, type_string, False, None).minimum == 2
    assert from_json_schema_type(data, type_string, False, None).maximum == 3
    assert from_

# Generated at 2022-06-24 10:59:10.457405
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    schema = {
        "type": ["string", "null"],
        "minLength": 0,
        "maxLength": 10,
        "format": "email",
        "pattern": r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
        "default": "foo@bar.com",
    }
    typesystem_field = from_json_schema_type(schema, type_string="string", allow_null=True)
    assert isinstance(typesystem_field, String)

# Generated at 2022-06-24 10:59:21.423784
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    print("\n test_any_of_from_json_schema")
    definitions = SchemaDefinitions()
    input_schema = {
        "$schema": "http://json-schema.org/draft-07/schema",
        "definitions": {
            "stringOrNumber": {
                "$id": "#/definitions/stringOrNumber",
                "anyOf": [
                    {"type": "string"},
                    {"type": "number"},
                ]
            }},
        "$id": "http://example.com/example.json",
        "$type": "object",
        "anyOf": [
            {"$ref": "#/definitions/stringOrNumber"},
            {"$ref": "#/definitions/stringOrNumber"}
        ]
    }