

# Generated at 2022-06-24 10:49:18.155952
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data= {"allOf":[{"minimum":1}],"default": 1}
    f=all_of_from_json_schema(data,SchemaDefinitions())
    data= {"allOf":[1],"default": 1}
    f=all_of_from_json_schema(data,SchemaDefinitions())


# Generated at 2022-06-24 10:49:28.733444
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "if": {"properties": {"foo": {"const": "bar"}}},
        "then": {"properties": {"bar": {"type": "string"}}},
        "else": {"properties": {"bar": {"type": "integer"}}},
    }
    if_clause = from_json_schema(data["if"], definitions={})
    then_clause = from_json_schema(data["then"], definitions={})
    else_clause = from_json_schema(data["else"], definitions={})

# Generated at 2022-06-24 10:49:32.645341
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert (
        ref_from_json_schema({"$ref": "#/definitions/Foo"}, definitions=definitions)
        .to == "#/definitions/Foo"
    )
    assert (
        ref_from_json_schema({"$ref": "#/definitions/Foo"}, definitions=definitions)
        .definitions
        is definitions
    )



# Generated at 2022-06-24 10:49:38.785615
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import json

    assert all_of_from_json_schema(json.loads(r"""{
        "allOf": [
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 8
            },
            {
                "enum": [
                    "john",
                    "jane",
                    "jack"
                ]
            }
        ]
    }""")) == AllOf(
        all_of=[
            String(
                min_length=1,
                max_length=8,
                allow_blank=False,
                allow_null=False
            ),
            Choice(
                choices=[
                    ("john", "john"),
                    ("jane", "jane"),
                    ("jack", "jack")
                ]
            )
        ]
    )


# Generated at 2022-06-24 10:49:46.787776
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    def test_single_field():
        field = any_of_from_json_schema({"anyOf": [{"type": "string"}]}, None)
        assert isinstance(field, Union)
        assert field.any_of == [String()]
        assert field.allow_null == False
    
    def test_multiple_fields():
        field = any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}]}, None)
        assert isinstance(field, Union)
        assert field.any_of == [String(), Integer()]
        assert field.allow_null == False
    
    def test_complex_fields():
        field = any_of_from_json_schema({"anyOf": [{"type": "object"}]}, None)
        assert isinstance

# Generated at 2022-06-24 10:49:55.545376
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "null", "enum": ["cat", "dog", "horse"]}) == (
        {"string"}, True
    )
    assert get_valid_types({"type": ["number", "boolean"]}) == (
        {"number", "boolean"},
        False,
    )
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["number", "integer"]}) == (
        {"number"},
        False,
    )
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)



# Generated at 2022-06-24 10:49:59.828508
# Unit test for function not_from_json_schema

# Generated at 2022-06-24 10:50:04.585643
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    Test the if/then/else feature of advanced schema.
    """

# Generated at 2022-06-24 10:50:09.711802
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/String'}), Reference)
    assert ref_from_json_schema({'$ref': '#/definitions/String'}).to == '#/definitions/String'
    assert ref_from_json_schema({'$ref': '#/definitions/String'}).definitions == {}



# Generated at 2022-06-24 10:50:22.223857
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
  schema = {
    "anyOf": [
      {
        "type": "object",
        "properties": {
          "type1": {
            "type": "string"
          }
        }
      },
      {
        "type": "object",
        "properties": {
          "type2": {
            "type": "string"
          }
        }
      },
      {
        "type": "object",
        "properties": {
          "type3": {
            "type": "string"
          }
        }
      }
    ]
  }
  result = any_of_from_json_schema(schema, None)
  assert isinstance(result, Union)
  assert isinstance(result.any_of, list)
  assert len(result.any_of) == 3
 

# Generated at 2022-06-24 10:50:27.703969
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type":{"type":"string","enum":["one","two"]}}}
    field = from_json_schema(data)
    assert field.negated.choices == (("one", "one"), ("two", "two"))
    assert field.negated.const is None
    data = {"not": {"type":"string","enum":["one","two"]}}
    field = from_json_schema(data)
    assert field.negated.choices == (("one", "one"), ("two", "two"))
    assert field.negated.const is None




# Generated at 2022-06-24 10:50:38.450214
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert (
        type_from_json_schema({"type": ["integer"]}, SchemaDefinitions())
        == Integer(constraints=[{"type": "integer"}])
    )
    assert (
        type_from_json_schema({"type": ["integer", "null"]}, SchemaDefinitions())
        == Union(
            any_of=[Integer(constraints=[{"type": "integer"}]), Const(None)],
            allow_null=True,
        )
    )
    assert (
        type_from_json_schema({"type": "integer"}, SchemaDefinitions())
        == Integer(constraints=[{"type": "integer"}])
    )

# Generated at 2022-06-24 10:50:40.257197
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, None) == Const("foo")



# Generated at 2022-06-24 10:50:43.823321
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/integer_schema"] = Integer()
    assert ref_from_json_schema(
        {"$ref": "#/definitions/integer_schema"}, definitions=definitions
    ) == definitions["#/definitions/integer_schema"]



# Generated at 2022-06-24 10:50:49.098950
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "string", False, None), String)
    assert isinstance(from_json_schema_type({}, "number", False, None), Float)
    assert isinstance(from_json_schema_type({}, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)
    assert isinstance(from_json_schema_type({}, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type({}, "array", False, None), Array)



# Generated at 2022-06-24 10:51:00.048758
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import json
    json_string = """
    {
      "type": "object",
      "properties": {
        "price": {
          "type": "number"
        },
        "tax": {
          "type": "number"
        }
      },
      "allOf": [
        {
          "required": [
            "price",
            "tax"
          ]
        },
        {
          "properties": {
            "price": {
              "maximum": 100
            },
            "tax": {
              "maximum": 10
            }
          }
        }
      ]
    }"""
    data = json.loads(json_string)

# Generated at 2022-06-24 10:51:02.169249
# Unit test for function get_standard_properties
def test_get_standard_properties():
    boolean_field = Boolean(default=True)
    standard_properties_dict = get_standard_properties(boolean_field)
    assert standard_properties_dict == {"default": True}


# Generated at 2022-06-24 10:51:09.464362
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data1 = {"const": "hello"}
    assert const_from_json_schema(data1,definitions) == Const(const="hello")
    data2 = {"const": 1}
    assert const_from_json_schema(data2,definitions) == Const(const=1)
    data3 = {"const": 1.5}
    assert const_from_json_schema(data3,definitions) == Const(const=1.5)



# Generated at 2022-06-24 10:51:21.630561
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(
        {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
            "exclusiveMinimum": True,
            "exclusiveMaximum": True,
        }
    ) == Integer(
        minimum=1, maximum=10, exclusive_minimum=True, exclusive_maximum=True
    )
    assert type_from_json_schema(
        {
            "type": "number",
            "minimum": 1.1,
            "maximum": 10.5,
            "exclusiveMinimum": True,
            "exclusiveMaximum": True,
        }
    ) == Float(
        minimum=1.1, maximum=10.5, exclusive_minimum=True, exclusive_maximum=True
    )

# Generated at 2022-06-24 10:51:25.301220
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "field": {
                "type": "string",
                "not": {"type": "string", "minLength": 3}
            }
        }
    }
    assert from_json_schema(schema) == Object(
        properties={"field": Not(negated=String(min_length=3))}
    )



# Generated at 2022-06-24 10:51:36.049659
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field: Field = type_from_json_schema(
        {
            "type": "object",
            "properties": {
                "prop1": {"type": "number", "minimum": 1},
                "prop2": {"type": "number", "maximum": 10},
            },
        },
        definitions={},
    )
    assert isinstance(field, Object)
    assert field.properties["prop1"] == Integer(minimum=1)
    assert field.properties["prop2"] == Integer(maximum=10)

    field: Field = type_from_json_schema(
        {"type": "integer", "minimum": 1, "maximum": 10}, definitions={}
    )
    assert isinstance(field, Integer)
    assert field.minimum == 1
    assert field.maximum == 10

    field: Field = type_from_json

# Generated at 2022-06-24 10:51:41.478163
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type':'string'}) == ({'string'}, False)
    assert get_valid_types({'type':'null'}) == (set(), True)
    assert get_valid_types({'type':['number', 'null']}) == ({'number'}, True)
    assert get_valid_types({'type':['number', 'null', 'integer']}) == ({'integer', 'number'}, True)
    assert get_valid_types({'type':['null', 'integer']}) == ({'integer'}, True)
    assert get_valid_types({'type':['null', 'boolean', 'integer']}) == ({'boolean', 'integer'}, True)


# Generated at 2022-06-24 10:51:47.042518
# Unit test for function get_valid_types
def test_get_valid_types():
    type_strings, allow_null = get_valid_types({})
    assert allow_null == False
    assert type_strings == {"null", "boolean", "object", "array", "number", "string"}

    type_strings, allow_null = get_valid_types({"type": "string"})
    assert allow_null == False
    assert type_strings == {"string"}

    type_strings, allow_null = get_valid_types({"type": ["null", "string"]})
    assert allow_null == True
    assert type_strings == {"string"}



# Generated at 2022-06-24 10:51:50.653456
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert_valid_json(
        {
            "anyOf": [
                {"type": "integer"},
                {"type": "string"},
                {"type": "boolean"},
            ],
            "default": "foo",
        },
        Any(),
        ["1", "foo", "true"],
    )



# Generated at 2022-06-24 10:51:58.566114
# Unit test for function to_json_schema
def test_to_json_schema():
    from django_stachoutils.json_schema import schema  # noqa

    class TestSchema(schema.Schema):
        name = schema.String(format="email", allow_blank=False)
        age = schema.Integer(minimum=0)

    valid_data = {"name": "foo@bar.baz", "age": 21}

    # Test with a schema directly
    json_schema = to_json_schema(TestSchema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "name": {"type": "string", "format": "email", "minLength": 1},
            "age": {"type": "integer", "minimum": 0},
        },
        "required": ["name", "age"],
    }

    # Test with data
    json

# Generated at 2022-06-24 10:52:07.071421
# Unit test for function get_valid_types
def test_get_valid_types():
    # type_string
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': 'array'}) == ({'array'}, False)
    assert get_valid_types({'type': 'boolean'}) == ({'boolean'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': 'object'}) == ({'object'}, False)

# Generated at 2022-06-24 10:52:10.086454
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref = ref_from_json_schema({"$ref": "#/definitions/foo"})
    assert isinstance(ref, Reference)
    assert ref.to == "#/definitions/foo"
    assert ref.definitions is not None



# Generated at 2022-06-24 10:52:18.176165
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "string"}
    assert from_json_schema_type(data, "string", False, None) == String()

    data = {"type": ["string", "null"]}
    assert from_json_schema_type(data, "string", True, None) == String()

    data = {"type": ["string", "null"]}
    assert from_json_schema_type(data, "null", False, None) == Const(None)



# Generated at 2022-06-24 10:52:22.453215
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "number"},
        "then": {"type": "boolean"},
        "else": {"type": "string"},
    }
    result = if_then_else_from_json_schema(data, definitions=None)
    expected = IfThenElse(
        if_clause=Float(allow_null=False, allow_infinity=True),
        then_clause=Boolean(allow_null=False),
        else_clause=String(
            allow_null=False,
            allow_blank=True,
            min_length=None,
            max_length=None,
            format=None,
            pattern=None,
        ),
    )
    if not result == expected:
        print(result.to_json_schema())  # pragma: no cover
       

# Generated at 2022-06-24 10:52:29.773625
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    definitions = SchemaDefinitions()
    input = {'not': {'type': 'number'}, 'default': 0}
    kwargs = {'negated': Float(default=NO_DEFAULT), 'default': 0}
    desired = Not(**kwargs)
    actual = not_from_json_schema(data=input, definitions=definitions)
    assert actual == desired
    definitions = SchemaDefinitions()
    input = {'not': {'type': 'number'}}
    kwargs = {'negated': Float(default=NO_DEFAULT), 'default': NO_DEFAULT}
    desired = Not(**kwargs)
    actual = not_from_json_schema(data=input, definitions=definitions)
    assert actual == desired



# Generated at 2022-06-24 10:52:37.792595
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test with a simple enum value
    data = {"enum": ["A"]}
    field = enum_from_json_schema(data, definitions)
    result = field.validate("A")
    assert result == "A"

    # Test with a default value
    data = {"enum": ["A", "B"], "default": "A"}
    field = enum_from_json_schema(data, definitions)
    result = field.validate(None)
    assert result == "A"
# End unit test for function enum_from_json_schema



# Generated at 2022-06-24 10:52:42.938051
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'not':{'type':'string', 'maxLength':3, 'pattern':'\\d'},'default': 'abc'}

    test_field = not_from_json_schema(data, None)
    
    # Check if the field is a not type field
    assert isinstance(test_field, Not)
    assert test_field.negated
    
    # Checking if the default value is applied
    assert test_field.default == 'abc'



# Generated at 2022-06-24 10:52:52.357579
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = from_json_schema_type(
        {},
        type_string="object",
        allow_null=True,
        definitions=SchemaDefinitions(),
    )
    assert schema.validate({"x": "y"}) == {"x": "y"}
    assert schema.validate(None) is None
    assert schema.validate({}) == {}
    assert schema.validate(1) == {"_schema_error": ["NOT_A_DICTIONARY"]}
    assert schema.validate([]) == {"_schema_error": ["NOT_A_DICTIONARY"]}
    assert isinstance(schema, Object)



# Generated at 2022-06-24 10:52:59.588865
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 3},
            {"maxLength": 6},
        ],
    }
    field = all_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, AllOf)
    assert len(field.all_of) == 3
    assert isinstance(field.all_of[0], String)
    assert isinstance(field.all_of[1], String)
    assert isinstance(field.all_of[2], String)



# Generated at 2022-06-24 10:53:08.446359
# Unit test for function type_from_json_schema

# Generated at 2022-06-24 10:53:13.172835
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'integer', 'minimum': 0}, {'type': 'integer', 'maximum': -1}]}

    union = any_of_from_json_schema(data, definitions)
    schema = union.schema()
    assert schema['anyOf'][0]['minimum'] == 0
    assert schema['anyOf'][1]['maximum'] == -1


# Generated at 2022-06-24 10:53:19.060370
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data={
        "oneOf": [
            {
                "type": "integer",
                "minimum": 1
            },
            {
                "type": "string",
                "minLength": 1,
                "maxLength": 1
            }
        ]
    }
    definitions = SchemaDefinitions()
    i=one_of_from_json_schema(data,definitions)
    # print(i)




# Generated at 2022-06-24 10:53:25.986220
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": ["integer", "boolean"]}, SchemaDefinitions()) == Integer() | Boolean()
    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": ["integer", "null"]}, SchemaDefinitions()) == Integer() | Const(None)
    assert type_from_json_schema({"type": ["null", "boolean"]}, SchemaDefinitions()) == (
        Boolean() | Const(None)
    )



# Generated at 2022-06-24 10:53:32.421495
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Integer
    assert type_from_json_schema(
        {"type": "integer"}, definitions=definitions
    ) == Integer(allow_null=False)

    # String
    assert type_from_json_schema(
        {"type": "string"}, definitions=definitions
    ) == String(allow_null=False)

    # Number
    assert type_from_json_schema(
        {"type": "number"}, definitions=definitions
    ) == Number(allow_null=False)

    # Boolean
    assert type_from_json_schema(
        {"type": "boolean"}, definitions=definitions
    ) == Boolean(allow_null=False)

    # Null
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)

    # Array

# Generated at 2022-06-24 10:53:38.023513
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "if": {
            "properties": {
                "number": {"type": "integer"},
            },
            "required": ["number"],
            "type": "object",
        },
        "then": {"properties": {"string": {"type": "string"}}, "required": ["string"], "type": "object"},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, Object)
    assert field.if_clause.properties["number"].allow_null == False
    assert isinstance(field.if_clause.properties["number"], Integer)

# Generated at 2022-06-24 10:53:45.641637
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({"enum": [1, "a", True]}) == Choice([1, "a", True])
    assert from_json_schema({"const": "a"}) == Const("a")
    assert from_json_schema({"allOf": [{"const": "a"}, {"const": "b"}]}) == Const("a")
    assert from_json_schema({"anyOf": [{"const": "a"}, {"const": "b"}]}) == Choice(["a", "b"])
    assert from_json_schema({"oneOf": [{"const": "a"}, {"const": "b"}]}) == Choice(["a", "b"])

# Generated at 2022-06-24 10:53:57.904487
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({"type": "string"}, type_string="string", allow_null=False, definitions=definitions), String)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="number", allow_null=False, definitions=definitions), Float)
    assert isinstance(from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False, definitions=definitions), Integer)
    assert isinstance(from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False, definitions=definitions), Boolean)

# Generated at 2022-06-24 10:54:04.108154
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    definitions = SchemaDefinitions()
    field = const_from_json_schema({"const": "constant"}, definitions=definitions)
    assert field.validate("constant")
    assert not field.validate("not constant")
    assert field.to_json_schema() == {
        "const": "constant",
        "type": "const"
    }



# Generated at 2022-06-24 10:54:08.622473
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/foo'}, definitions={'#/definitions/foo': Any()}), Reference)
    try:
        ref_from_json_schema({'$ref': 'http://example.com'}, definitions={'#/definitions/foo': Any()})
    except AssertionError:
        pass



# Generated at 2022-06-24 10:54:15.028004
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1]}) == Choice(choices=[(1, 1)])
    assert enum_from_json_schema({"enum": [1, "a"]}) == Choice(choices=[(1, 1), ("a", "a")])
    assert enum_from_json_schema({"enum": [1], "default": 2}) == Choice(choices=[(1, 1)], default=2)



# Generated at 2022-06-24 10:54:19.343615
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    fields = all_of_from_json_schema({'allOf': [{}, {}]}, SchemaDefinitions())
    assert fields.all_of == [Any(), Any()]
    fields = all_of_from_json_schema({'allOf': [{'const': 1}, {'const': 2}]}, SchemaDefinitions())
    assert fields.all_of == [Const(const=1), Const(const=2)]



# Generated at 2022-06-24 10:54:24.466302
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type" : "number"}]}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)
    if "$ref" in data:
        return ref_from_json_schema(data, definitions=definitions)

    constraints = []  # typing.List[Field]
    if any([property_name in data for property_name in TYPE_CONSTRAINTS]):
        constraints.append(type_from_json_schema(data, definitions=definitions))
    if "enum" in data:
        constraints.append(enum_from_json_schema(data, definitions=definitions))

# Generated at 2022-06-24 10:54:33.180422
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test with a list and a string
    data = {"oneOf": [{"type": "string"}, {"type": "number"}]}
    expected = OneOf(one_of=[String(), Float()])
    typesystem.core.assert_equals(
        from_json_schema(data),
        expected
    )
    # Test with a list, a string and a list
    data = {"oneOf": [{"type": "string"}, {"type": "integer"},
                      {"type": "array", "items": {"type": "string"}, "minItems": 1}]}
    expected = OneOf(
        one_of=[
            String(),
            Integer(),
            Array(items=String(), min_items=1)
        ]
    )

# Generated at 2022-06-24 10:54:41.396373
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "string"}
    assert isinstance(from_json_schema_type(data, type_string="string", allow_null=False, definitions=None), String)
    assert isinstance(from_json_schema_type(data, type_string="number", allow_null=False, definitions=None), Float)
    assert isinstance(from_json_schema_type(data, type_string="integer", allow_null=False, definitions=None), Integer)
    assert isinstance(from_json_schema_type(data, type_string="boolean", allow_null=False, definitions=None), Boolean)
    assert isinstance(from_json_schema_type(data, type_string="array", allow_null=False, definitions=None), Array)

# Generated at 2022-06-24 10:54:43.035150
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="")) == {"default": ""}



# Generated at 2022-06-24 10:54:53.348683
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) is Any()
    assert type_from_json_schema({"type": "string"}, definitions={}) is String()
    assert type_from_json_schema({"type": "null"}, definitions={}) is Const(None)
    assert type_from_json_schema({"type": "number"}, definitions={}) is Number()
    assert type_from_json_schema({"type": "integer"}, definitions={}) is Integer()
    assert type_from_json_schema({"type": "boolean"}, definitions={}) is Boolean()
    assert type_from_json_schema({"type": "array"}, definitions={}) is Array()
    assert type_from_json_schema({"type": "object"}, definitions={}) is Object()

    assert type_from_json_sche

# Generated at 2022-06-24 10:54:55.932451
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    assert enum_from_json_schema({"enum": ["goodbye", "hello"]}) == Choice(choices=[("goodbye", "goodbye"), ("hello", "hello")])

# Generated at 2022-06-24 10:54:58.753366
# Unit test for function get_standard_properties
def test_get_standard_properties():
    schema = Schema(default=3, nullable=True)
    field = schema.make_validator()
    assert {"default": 3} == get_standard_properties(field)

    schema = Schema(nullable=True)
    field = schema.make_validator()
    assert {} == get_standard_properties(field)



# Generated at 2022-06-24 10:55:03.452498
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        age = Integer(minimum=0, default=None, allow_null=True)
        name = String(min_length=1)
        friends = Array(items=Reference("#/definitions/Person", definitions=Definitions))

    schema = Schema(
        age=Integer(minimum=0, allow_null=True),
        name=String(min_length=1),
        friends=Array(
            items=Reference("#/definitions/Person", definitions=Definitions),
            allow_null=True,
        ),
    )

    schema_2 = Schema(
        age=Integer(minimum=0, allow_null=True),
        name=String(min_length=1),
        friends=Array(
            items=Person,
            allow_null=True,
        ),
    )

   

# Generated at 2022-06-24 10:55:12.403104
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference_string = '#/definitions/Example'
    definitions = SchemaDefinitions()
    definitions[reference_string] = String()
    data = {"$ref": reference_string}
    field = ref_from_json_schema(data, definitions=definitions)
    assert field == Reference(to=reference_string, definitions=definitions)



# Generated at 2022-06-24 10:55:19.603770
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-24 10:55:25.060743
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Any()
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions)
    assert str(field) == "*"
# Done with unit test for function ref_from_json_schema



# Generated at 2022-06-24 10:55:33.934536
# Unit test for function to_json_schema

# Generated at 2022-06-24 10:55:42.686072
# Unit test for function type_from_json_schema

# Generated at 2022-06-24 10:55:47.640507
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, 2]}
    actual = enum_from_json_schema(data, definitions=None)
    assert actual.to_primitive() == {"type": "choice", "choices": [("1", 1), ("2", 2)]}



# Generated at 2022-06-24 10:55:52.027086
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = Field()
    for field in const_from_json_schema(field, definitions = None):
        if data == "const":
            return const
        else:
            return NO_DEFAULT



# Generated at 2022-06-24 10:55:58.102856
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "boolean"},
        ]
    }
    result = any_of_from_json_schema(schema, {})
    assert type(result) == Union
    assert len(result.any_of) == 3


# Generated at 2022-06-24 10:56:08.037855
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Integer(default=1)
    assert get_standard_properties(field) == {"default": 1}
    field = Integer(default=1).required
    assert get_standard_properties(field) == {}
    field = Integer(default=1, allow_null=True)
    assert get_standard_properties(field) == {}
    field = Integer()
    assert get_standard_properties(field) == {}
    field = Integer(default=NO_DEFAULT)
    assert get_standard_properties(field) == {}
    field = String(default="hello")
    assert get_standard_properties(field) == {"default": "hello"}
    field = String(default="hello").required
    assert get_standard_properties(field) == {}
    field = String(default="hello", allow_null=True)
    assert get_standard_

# Generated at 2022-06-24 10:56:18.743896
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data1 = {
        "allOf": [
            {"type": "string", "maxLength": 5, "minLength": 3},
            {"type": "string", "format": "date-time"},
        ],
        "default": "2018-08-01T09:43:50Z"
    }
    data2 = {
        "allOf": [
            {"type": "string", "maxLength": 5, "minLength": 3},
            {"type": "string", "format": "date-time"},
            {"type": "string"},
        ],
        "default": "2018-08-01T09:43:50Z"
    }

# Generated at 2022-06-24 10:56:24.400303
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema(
            data={"$ref": "#/definitions/foo"},
            definitions=SchemaDefinitions({"#/definitions/foo": Integer()}),
        ),
        Reference,
    )



# Generated at 2022-06-24 10:56:32.664421
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_1 = any_of_from_json_schema({"anyOf": [{"type": "integer"}, {"type": "string"}]}, SchemaDefinitions())
    assert test_1.default == "string"
    assert test_1.allow_null == True
    assert test_1.__class__ == Union

    test_2 = any_of_from_json_schema({"anyOf": [{"type": "integer"}, {"type": ["integer", "string"]}]}, SchemaDefinitions())
    assert test_2.default == "integer"
    assert test_2.allow_null == True
    assert test_2.__class__ == Union

    test_3 = any_of_from_json_schema({"anyOf": [{"type": "integer"}, {'const':1}]}, SchemaDefinitions())


# Generated at 2022-06-24 10:56:40.985947
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "number", "minimum": 0, "multipleOf": 3},
            {"type": "integer"},
            {"const": 6},
        ],
        "default": 6,
    }
    assert isinstance(all_of_from_json_schema(data, definitions=definitions), AllOf)
    assert all_of_from_json_schema(data, definitions=definitions).validate(3)
    assert all_of_from_json_schema(data, definitions=definitions).validate(6)
    assert not all_of_from_json_schema(data, definitions=definitions).validate(7)
    assert not all_of_from_json_schema(data, definitions=definitions).validate(8)



# Generated at 2022-06-24 10:56:49.370939
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    js1 = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "type": "object",
        "title": "Product",
        "required": ["id", "price"],
        "properties": {
            "id": {
                "type": "integer",
                "minimum": 0
            },
            "price": {
                "type": "number",
                "exclusiveMinimum": 0
            }
        }
    }
    schem = all_of_from_json_schema(js1, {})
    assert 4 == len(schem.all_of)
    assert(schem.all_of[0].name == 'id')

# Generated at 2022-06-24 10:56:57.039301
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    expected_result = const_from_json_schema({"const": "Naz" }, None)
    schema = Schema({"$schema":"http://json-schema.org/draft-07/schema#",
  "type": "object",
  "properties": {
    "a": { "const": "Naz" },
    "c": { "const": 42 }
  }}
)
    field = schema.fields['a']
    assert field == expected_result , "function const_from_json_schema failed"
test_const_from_json_schema()



# Generated at 2022-06-24 10:57:00.668256
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(_) == Any()

# Generated at 2022-06-24 10:57:03.916397
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/Foo'}
    assert ref_from_json_schema(data, SchemaDefinitions()).to == '#/definitions/Foo'



# Generated at 2022-06-24 10:57:10.997086
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "object"}) == ({'object',}, False)
    assert get_valid_types({"type": "array"}) == ({'array',}, False)
    assert get_valid_types({"type": "number"}) == ({'number',}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer',}, False)
    assert get_valid_types({"type": "string"}) == ({'string',}, False)
    assert get_valid_types({"type": "boolean"}) == ({'boolean',}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)

    assert get_valid_types({"type": ["integer", "boolean"]}) == ({'boolean',}, False)

# Generated at 2022-06-24 10:57:21.297913
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({
        "oneOf": [{
            "type": "string"
        }, {
            "type": "integer"
        }, {
            "type": "null"
        }]
    }, definitions=SchemaDefinitions()).validate("abc") == "abc"
    assert one_of_from_json_schema({
        "oneOf": [{
            "type": "string"
        }, {
            "type": "integer"
        }, {
            "type": "null"
        }]
    }, definitions=SchemaDefinitions()).validate(123) == 123

# Generated at 2022-06-24 10:57:25.717404
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    f = enum_from_json_schema({"enum":[1,2,3]}, None)
    assert f.validate(1) == True
    assert f.validate(2) == True
    assert f.validate(3) == True
    assert f.validate(4) == False


# Generated at 2022-06-24 10:57:35.073957
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': ['integer']}) == ({'integer'}, False)
    assert get_valid_types({'type': ['null', 'integer']}) == ({'integer'}, True)
    assert get_valid_types({'type': ['number']}) == ({'number'}, False)

# Generated at 2022-06-24 10:57:38.917444
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"enum": ["x"]}}
    expected = Not(
        negated=Enum(choices=[("x", "x")]), default=NO_DEFAULT
    )
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == expected



# Generated at 2022-06-24 10:57:50.751465
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "string",
        "default": "red",
        "nullable": True,
    }
    schema = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(schema, Union)
    assert schema.allow_null
    assert isinstance(schema.any_of[1], Const)
    assert schema.any_of[1].const is None

    data = {"type": "string", "default": "red"}
    schema = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(schema, String)
    assert schema.default == "red"

    data = {
        "type": "string",
        "nullable": True,
    }

# Generated at 2022-06-24 10:57:57.803720
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    sch1 = {
        "if": {
            "const": True
        },
        "then": {
            "type": "string",
            "minLength": 4,
            "maxLength": 10
        },
        "else": {
            "const": "None"
        }
    }
    sch2 = IfThenElse(
        if_clause=Const(const=True),
        then_clause=String(min_length=4, max_length=10, allow_null=False),
        else_clause=Const(const="None", allow_null=False)
    )
    assert if_then_else_from_json_schema(sch1, definitions=None) == sch2



# Generated at 2022-06-24 10:58:10.325482
# Unit test for function get_valid_types
def test_get_valid_types():
    # Check that strings come back as strings
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": ["boolean"]}) == ({'boolean'}, False)
    # Check that numbers get merged into numbers
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": ["integer", "number"]}) == ({'number'}, False)
    assert get_valid_types({"type": ["number", "integer"]}) == ({'number'}, False)
    # Check that null/not(null) are handled correctly
    assert get_valid_types({"type": "null"}) == ({'null'}, True)

# Generated at 2022-06-24 10:58:18.389984
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # JSON schema with a single type in type keyword
    assert type_from_json_schema({'type': 'string'}) == String()
    # JSON schema with multiple types in type keyword
    assert type_from_json_schema({'type': ['string', 'integer']}) == \
           String() | Integer()
    # JSON schema with multiple types in type keyword and nullable
    assert type_from_json_schema({'type': ['string', 'integer'], 'nullable': True}) == \
           String() | Integer() | Const(None)
    # JSON schema with a single type and nullable set to true
    assert type_from_json_schema({'type': 'string', 'nullable': True}) == \
           String() | Const(None)



# Generated at 2022-06-24 10:58:22.565650
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert from_json_schema({'$ref': '#/definitions/foo'}) == Reference(to='#/definitions/foo')
    assert from_json_schema({'allOf': [{'$ref': '#/definitions/foo'}]}) == AllOf(all_of=[Reference(to='#/definitions/foo')])


# Generated at 2022-06-24 10:58:29.564636
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    test_data = {"enum": ["a", "b", "c"]}
    result = enum_from_json_schema(test_data, definitions={})
    test_result = isinstance(result, Choice) and hasattr(result, "choices") and \
                  result.choices == [("a", "a"), ("b", "b"), ("c", "c")]
    assert test_result, "Failed to apply function enum_from_json_schema"



# Generated at 2022-06-24 10:58:38.405336
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type":"number"}, {"type":"integer"}]}
    schema_def = SchemaDefinitions()
    result = AnyOf([Integer(), Float()])
    assert one_of_from_json_schema(data, schema_def) == result

    data = {"oneOf": [{"type":"number"}, {"type":"integer", "maxLength":20}]}
    schema_def = SchemaDefinitions()
    result = AllOf([Integer(max_value=20), Float()])
    assert one_of_from_json_schema(data, schema_def) == result


# Generated at 2022-06-24 10:58:49.015798
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': None}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': False}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': 'number'}) == ({'number', 'integer'}, False)

# Generated at 2022-06-24 10:58:57.154928
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    function = if_then_else_from_json_schema

    data = {"default": "DEFAULT"}
    actual = function(data, definitions=None)
    expected = IfThenElse(default="DEFAULT")
    assert actual == expected

    data = {"if": {"type": "integer"}, "default": "DEFAULT"}
    actual = function(data, definitions=None)
    expected = IfThenElse(if_clause=Integer(allow_null=False), default="DEFAULT")
    assert actual == expected

    data = {"if": {"type": "integer"}, "then": {"type": "integer"}, "default": "DEFAULT"}
    actual = function(data, definitions=None)

# Generated at 2022-06-24 10:59:01.268619
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Const("bar")
    assert ref_from_json_schema(json_schema, definitions) == Const("bar")
    return



# Generated at 2022-06-24 10:59:06.354690
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {'$id': '#test', 'enum': [0, 1, 2]}
    field = from_json_schema(schema)
    assert 0 in field.valid_choices
    assert 1 in field.valid_choices
    assert 2 in field.valid_choices
    assert len(field.valid_choices) == 3
    assert field.to_dict() == {'$id': '#test', 'enum': [0, 1, 2]}


# Generated at 2022-06-24 10:59:11.183625
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_schema = {"anyOf": [{"type": "string"}, {"type": "number"}]}
    field = any_of_from_json_schema(test_schema, definitions)
    assert type(field) == Union


# Generated at 2022-06-24 10:59:19.522616
# Unit test for function one_of_from_json_schema