

# Generated at 2022-06-24 10:49:21.099031
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Invalid argument
    try:
        from_json_schema_type({}, type_string="invalid_type", allow_null=False)
    except AssertionError:
        pass
    else:
        assert False

    # Boolean types
    assert from_json_schema_type({}, type_string="boolean", allow_null=False).to_dict()=={"type":"boolean"}
    assert from_json_schema_type({}, type_string="boolean", allow_null=True).to_dict()== {"type": "union", "any_of": [{"type": "null"}, {"type": "boolean"}]}

    # String types
    assert from_json_schema_type({}, type_string="string", allow_null=False).to_dict() == {"type": "string"}
    assert from_

# Generated at 2022-06-24 10:49:23.944694
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema("string") == String()
# End unit test for function type_from_json_schema


# Generated at 2022-06-24 10:49:34.516631
# Unit test for function to_json_schema
def test_to_json_schema():
    class SimpleJSONSchema(Schema):
        name = String()
        age = Integer()
        valid = Boolean()

    json_schema = to_json_schema(SimpleJSONSchema)

    assert validators.validate(json_schema, json_schema) is None
    assert validators.validate(json_schema, {"name": "John Smith", "age": 42}) is None
    assert validators.validate(json_schema, {"name": "John Smith"}) is not None
    assert validators.validate(json_schema, {"age": 42}) is not None
    assert validators.validate(json_schema, {"name": "John Smith", "age": -42}) is None


# Generated at 2022-06-24 10:49:40.158089
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="string", allow_null=True) == String(
        allow_null=True, min_length=None, max_length=None, pattern=None, format=None
    )
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    assert from_json_schema_type({}, type_string="array", allow_null=True) == Array

# Generated at 2022-06-24 10:49:46.053560
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = Any()
    field._allow_null = True
    assert any_of_from_json_schema({'anyOf': [{'type': 'boolean'}, {'type': 'string'}]}, {}) == field
    field = Boolean()
    field._allow_null = True
    assert any_of_from_json_schema({'anyOf': [{'type': 'boolean'}]}, {}) == field
    field = String()
    field._allow_null = True
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}]}, {}) == field



# Generated at 2022-06-24 10:49:53.275843
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.fields import Decimal, Integer
    from typesystem.composites import NeverMatch, Union
    from typesystem.schemas import Reference

    # Test with {'type': 'number'}
    data = {"type": "number"}
    result = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert result == Union(any_of=[Decimal(), Integer()], allow_null=False)

    # Test with {'type': ['number', 'string']}
    data = {"type": ["number", "string"]}
    result = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert result == Union(any_of=[Decimal(), Integer(), String()], allow_null=False)

    # Test with {'type': 'string', 'minLength': 0}

# Generated at 2022-06-24 10:50:04.963024
# Unit test for function from_json_schema
def test_from_json_schema():
    f = from_json_schema({"type": "integer"})
    assert isinstance(f, Integer)

    f = from_json_schema({"type": ["integer", "null"]})
    assert isinstance(f, Union) and len(
        [s for s in f.schemas if isinstance(s, Integer)]
    ) == 1
    assert isinstance(f, Union) and len([s for s in f.schemas if isinstance(s, Any)]) == 1

    f = from_json_schema({"type": "integer", "enum": [1, 2, 3]})
    assert isinstance(f, Choice) and len(
        [s for s in f.choices if isinstance(s, Integer)]
    ) == 1

# Generated at 2022-06-24 10:50:14.187036
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"null", "boolean", "object", "array", "number", "string"}
    assert allow_null is False

    data = {"type": "number"}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"number"}
    assert allow_null is False

    data = {"type": "null"}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == set()
    assert allow_null is True

    data = {"type": ["null", "integer"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"integer"}
    assert allow_null is True

   

# Generated at 2022-06-24 10:50:25.694627
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema({"first_name": String(), "last_name": String()})
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
        },
        "required": ["first_name", "last_name"],
    }
    assert to_json_schema(schema, _definitions={}) == {
        "type": "object",
        "properties": {
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
        },
        "required": ["first_name", "last_name"],
    }

# Generated at 2022-06-24 10:50:36.841914
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}) == Any()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "number"}) == Number()
    assert type_from_json_schema({"type": "array"}) == Array(min_items=0)
    assert type_from_json_schema({"type": "object"}) == Object()
    assert type_from_json_schema({"type": "boolean"}) == Boolean()
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "null"}) == Const(None)


# Generated at 2022-06-24 10:50:42.731145
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "foo"}
    defs = {}
    assert const_from_json_schema(data,defs).is_valid("foo")
    assert not const_from_json_schema(data,defs).is_valid("bar")
    assert const_from_json_schema(data,defs).is_valid("foo", strict=False)
    assert const_from_json_schema(data,defs).default == "foo"



# Generated at 2022-06-24 10:50:51.320474
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema(
        {"enum": ["foo", "bar"]}, definitions=None
    ).validate("foo") == "foo"
    assert enum_from_json_schema(
        {"enum": ["foo", "bar"]}, definitions=None
    ).validate("baz") == "baz"
    assert enum_from_json_schema(
        {"enum": ["foo", "bar"], "default": "bar"}, definitions=None
    ).validate(None) == "bar"



# Generated at 2022-06-24 10:51:01.124325
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", allow_null=True) == Float(allow_null=True)
    assert from_json_schema_type({}, "integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({}, "string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({}, "boolean", allow_null=True) == Boolean(allow_null=True)
    assert from_json_schema_type({}, "array", allow_null=True) == Array(allow_null=True)
    assert from_json_schema_type({}, "object", allow_null=True) == Object(allow_null=True)



# Generated at 2022-06-24 10:51:09.637157
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    """
    Check if the generated Schema using oneOf rule, accepts only one of the choices.
    """
    oneOf_schema = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    one_of_schema = one_of_from_json_schema(oneOf_schema, definitions=definitions)
    # Should pass
    assert one_of_schema.validate(1) is None
    assert one_of_schema.validate("1") is None
    # Should fail
    assert one_of_schema.validate(1.1) is not None
    assert one_of_schema.validate(True) is not None
    assert one_of_schema.validate(None) is not None



# Generated at 2022-06-24 10:51:14.952398
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({'oneOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate('1')
    assert not one_of_from_json_schema({'oneOf': [{'type': 'string'}, {'type': 'number'}]}, None).validate(1)



# Generated at 2022-06-24 10:51:23.429398
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=True), Float)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False), Integer)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=False), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="array", allow_null=False), Array)
    assert isinstance(from_json_schema_type({}, type_string="object", allow_null=False), Object)



# Generated at 2022-06-24 10:51:28.293254
# Unit test for function to_json_schema
def test_to_json_schema():
    from thinqpony.openapi import Schema

    class Person(Schema):
        name = String().to_json_schema()
        age = Integer().to_json_schema()

    class Pet(Schema):
        name = String().to_json_schema()
        age = Integer().to_json_schema()
        owner = Ref(Person).to_json_schema()

    assert to_json_schema(Person) == {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
        },
    }


# Generated at 2022-06-24 10:51:38.196697
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Given
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "enum": [
            "Active",
            "Disabled",
            "Deleted",
        ]
    }

    # When
    result = enum_from_json_schema(data, definitions=SchemaDefinitions())

    # Then
    choices = [
        ("Active", "Active"),
        ("Disabled", "Disabled"),
        ("Deleted", "Deleted"),
    ]
    assert result.choices == choices



# Generated at 2022-06-24 10:51:44.772277
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    reference_string = "#/definitions/Baz"
    data = {"$ref": reference_string}

    returned = ref_from_json_schema(data, definitions={})
    assert isinstance(returned, Reference)
    assert returned.to is reference_string
# /Unit test for function ref_from_json_schema



# Generated at 2022-06-24 10:51:47.079120
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{}, {}]}, SchemaDefinitions()) == Union(any_of=[Any(), Any()])


# Generated at 2022-06-24 10:51:49.246105
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field = type_from_json_schema({'type': 'string','minLength': 1,'minLength': 2,'pattern': 'a'})
    assert isinstance(field, String)
    assert field.min_length == 1
    assert field.max_length == 2
    assert field.format == 'a'



# Generated at 2022-06-24 10:51:58.283662
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from datetime import datetime
    from typesystem.fields import Date, DateTime, Time

    for type_string in ["number", "integer", "string", "boolean", "array", "object"]:
        field = from_json_schema_type(
            data={"type": type_string}, type_string=type_string, allow_null=False, definitions=SchemaDefinitions()
        )
        assert isinstance(field, Field)
        assert not field.allow_null

    field = from_json_schema_type(
        data={"type": "number", "format": "date-time"},
        type_string="number",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    assert isinstance(field, DateTime)


# Generated at 2022-06-24 10:52:01.279347
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    """
    Test for any_of_from_json_schema
    """
    data = {"anyOf":[]}
    assert any_of_from_json_schema(data,definitions) == Any()


# Generated at 2022-06-24 10:52:09.839217
# Unit test for function get_valid_types

# Generated at 2022-06-24 10:52:16.532717
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = not_from_json_schema({'not': {'type': 'integer'}})
    results = [schema.validate(1), schema.validate('foo')]
    assert results[0] == [('type', 'Expected value of type "integer".')]
    assert results[1] == []



# Generated at 2022-06-24 10:52:20.087182
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    with pytest.raises(AssertionError):
        one_of_from_json_schema({"oneOf": ["hi"]}, SchemaDefinitions())



# Generated at 2022-06-24 10:52:26.436681
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    :return:
    """
    d = {"not":{"type":"null","default":"blah"}}
    res = not_from_json_schema(data = d, definitions = None)
    assert isinstance(res, Not) and res.default == "blah" and isinstance(res.negated, AllOf) and len(res.negated.all_of) == 2 and isinstance(res.negated.all_of[0], Const) and res.negated.all_of[0].const != None and isinstance(res.negated.all_of[1], Const) and res.negated.all_of[1].const != "blah"



# Generated at 2022-06-24 10:52:30.603046
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic import BaseSchema, Field

    class TestSchema(BaseSchema):
        test: str = Field(..., description="Foobar")

    result = to_json_schema(TestSchema)
    assert result["properties"]["test"]["description"] == "Foobar"



# Generated at 2022-06-24 10:52:40.719901
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [3, 4, 5], "default": 4}
    typesystem_field = enum_from_json_schema(data, definitions=None)
    assert typesystem_field.validate(4) == 4
    assert typesystem_field.validate(5) == 5
    assert typesystem_field.validate(6) is None
    data = {"enum": ["a", "b", "c"], "default": "a"}
    typesystem_field = enum_from_json_schema(data, definitions=None)
    assert typesystem_field.validate("a") == "a"
    assert typesystem_field.validate("b") == "b"
    assert typesystem_field.validate("d") is None



# Generated at 2022-06-24 10:52:47.033492
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def reference_schema():  # type: ignore
        return Object(properties={"a": Integer()})

    definitions["#/definitions/reference_schema"] = reference_schema()
    assert isinstance(ref_from_json_schema({'$ref': '#/definitions/reference_schema'}, definitions=definitions), Object)




# Generated at 2022-06-24 10:52:57.726768
# Unit test for function to_json_schema
def test_to_json_schema():
    import datetime
    import decimal
    import json
    import pytest
    from datetime import date, time, datetime, timedelta
    import pydantic as p

    class TestModel(p.BaseModel):
        a = p.String(min_length=1)
        b = p.Int(gt=0)
        c = p.Float(gt=0.0)
        d = p.Decimal(gt=0.0)
        e = p.Bool()
        f = p.String(max_length=1)
        g = p.Int(lt=0)
        h = p.Float(lt=0.0)
        i = p.Decimal(lt=0.0)
        j = p.Int(min=1)
        k = p.Int(max=10)
        l = p

# Generated at 2022-06-24 10:53:02.207451
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    d = {"anyOf": [{"const": "a"}, {"const": "b"}]}
    actual = any_of_from_json_schema(d, None)
    assert isinstance(actual, Union)
    assert len(actual.schema) == 2
    assert actual.schema[0] == "a"
    assert actual.schema[1] == "b"



# Generated at 2022-06-24 10:53:12.936473
# Unit test for function get_standard_properties
def test_get_standard_properties():

    field = String(default="example")
    assert get_standard_properties(field) == {"default": "example"}

    field = String(default=NO_DEFAULT)
    assert get_standard_properties(field) == {}

    field = Integer(default=5)
    assert get_standard_properties(field) == {"default": 5}

    field = Boolean(default=True)
    assert get_standard_properties(field) == {"default": True}

    field = Array(default=[1, 2, 3, 4, 5])
    assert get_standard_properties(field) == {"default": [1, 2, 3, 4, 5]}

    field = Object(default={"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-24 10:53:22.815725
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test wrapper function
    def wrap_test_not_from_json_schema(
        schema: typing.Union[dict, str],
        expected: typing.Union[str, ValidationError],
        definitions: SchemaDefinitions = None,
    ):
        if definitions is None:
            definitions = SchemaDefinitions()

        data = schema if isinstance(schema, dict) else json.loads(schema)

        field = from_json_schema(data, definitions=definitions)
        assert isinstance(field, Not)
        if isinstance(expected, str):
            assert validate(expected, field) is None
        else:
            assert validate(expected, field) == expected

    # Valid
    yield wrap_test_not_from_json_schema, '{"not": {"type": "null"}}', None
    yield

# Generated at 2022-06-24 10:53:30.604017
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="boolean"), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="integer"), Integer)
    assert isinstance(from_json_schema_type({}, type_string="number"), Number)
    assert isinstance(from_json_schema_type({}, type_string="string"), String)
    assert isinstance(from_json_schema_type({}, type_string="array"), Array)
    assert isinstance(from_json_schema_type({}, type_string="object"), Object)



# Generated at 2022-06-24 10:53:32.194554
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Any()) == {}
    assert get_standard_properties(Any(default="undefined")) == {"default":"undefined"}
    assert get_standard_properties(Any(default=NO_DEFAULT)) == {}

# Generated at 2022-06-24 10:53:42.774034
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.base import Field, Integer, Const, Union
    from typesystem.exceptions import ValidationError

    assert type_from_json_schema(
        {
            "type": "integer",
            "minimum": -10,  # ignored
            "maximum": 10,  # ignored
            "exclusiveMinimum": -20,  # ignored
            "exclusiveMaximum": 20,  # ignored
            "multipleOf": 2,  # ignored
            "const": -20,  # ignored
        }
    ) is Integer()


# Generated at 2022-06-24 10:53:45.087823
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf':[{'type':'string'},{'type':'integer'}]}
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions) == OneOf(one_of=[String(),Integer()])



# Generated at 2022-06-24 10:53:51.436864
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-24 10:53:53.293234
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [1,2]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.one_of == [1, 2]



# Generated at 2022-06-24 10:54:03.009739
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({'allOf': [{'$schema': 'http://json-schema.org/draft-07/schema#', 'type': 'number', 'minimum': 10, 'maximum': 20}, {'$schema': 'http://json-schema.org/draft-07/schema#', 'type': 'number', 'multipleOf': 2}]}, {}) == AllOf(all_of=[Float(minimum=10, maximum=20), Integer(multiple_of=2)], default=NO_DEFAULT)
test_all_of_from_json_schema()


# Generated at 2022-06-24 10:54:07.823897
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert (
        if_then_else_from_json_schema(
            {
                "if": {},
                "then": {},
                "else": {},
            },
            definitions={},
        )
        == IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any(), default=None)
    )  # type: ignore



# Generated at 2022-06-24 10:54:17.857945
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type: () -> None
    assert from_json_schema_type({}, "number", True, None) == Float(allow_null=True)
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", True, None) == Integer(allow_null=True)
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", True, None) == String(allow_null=True)
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", True, None) == Boolean(allow_null=True)
    assert from_json

# Generated at 2022-06-24 10:54:29.221032
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {
        "type": "number",
        "minimum": 1.0,
        "maximum": 3.5,
        # "exclusiveMinimum": 1.1,
        # "exclusiveMaximum": 2.5,
        "multipleOf": 2,
    }
    assert from_json_schema_type(data=schema, type_string="number", allow_null=False) == (
        Float(minimum=1.0, maximum=3.5, multiple_of=2.0)
    )
    schema = {
        "type": "number",
        "minimum": 1.0,
        # "maximum": 3.5,
        "exclusiveMinimum": 1.1,
        "exclusiveMaximum": 2.5,
        "multipleOf": 2,
    }

# Generated at 2022-06-24 10:54:38.245850
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = Any()
    data = {'type': 'any'}
    assert from_json_schema(data) == schema

    data = {'type': 'boolean'}
    schema = Boolean()
    assert from_json_schema(data) == schema

    data = {'type': 'integer'}
    schema = Integer()
    assert from_json_schema(data) == schema

    data = {'type': 'number'}
    schema = Number()
    assert from_json_schema(data) == schema

    data = {'enum': ['a', 'b', 'c']}
    schema = Choice(['a', 'b', 'c'])
    assert from_json_schema(data) == schema

    data = {'const': 'a'}
    schema = Const(value='a')


# Generated at 2022-06-24 10:54:45.710290
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "test1": {"type": "string"},
                }
            },
            {
                "type": "object",
                "properties": {
                    "test2": {"type": "string"},
                }
            },
        ]
    }
    definitions = SchemaDefinitions()
    result = one_of_from_json_schema(data, definitions=definitions)
    assert result.validate({"test1": "test"})
    assert not result.validate({"test1": "test", "test2": "test"})
    assert not result.validate({"test1": "test", "test2": 1})
    assert result.validate({"test2": "test"})

# Generated at 2022-06-24 10:54:55.840399
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [
        {"type": "integer"},
        {"type": "string"},
        {"type": "string", "const": "John"},
        {"type": "null", "enum": [None]}
    ]}
    definitions = SchemaDefinitions()
    one_off = one_of_from_json_schema(data, definitions)
    assert one_off._one_of[0] == Integer(allow_null=False)
    assert one_off._one_of[1] == String(allow_null=False, allow_blank=True)
    assert one_off._one_of[2] == Const("John")
    assert one_off._one_of[3] == Const(None)



# Generated at 2022-06-24 10:54:57.853406
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Field(default="abc")
    assert get_standard_properties(field) == {"default": "abc"}
    field = Field()
    assert get_standard_properties(field) == {}



# Generated at 2022-06-24 10:55:09.203782
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'object'}) == ({'object'}, False)
    assert get_valid_types({'type': ['string', 'null']}) == ({'string'}, True)
    assert get_valid_types({'type': ['string', 'integer']}) == ({'string', 'integer'}, False)
    assert get_valid_types({'type': ['number', 'integer']}) == ({'number'}, False)
    assert get_valid_types({'type': ['number', 'integer', 'null']}) == ({'number'}, True)
    assert get_valid

# Generated at 2022-06-24 10:55:11.853172
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":[True,1,2,2]}
    value = any_of_from_json_schema(data, None)
    assert value.any_of[3].minimum == 2, "minimum is not 2"



# Generated at 2022-06-24 10:55:17.610756
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=None) == Any()
    assert type_from_json_schema({"type": "null"}, definitions=None) == Const(None)
    assert type_from_json_schema({"type": ["null", "boolean"]}, definitions=None) == Boolean()
    assert type_from_json_schema({"type": ["null", "boolean", "string"]}, definitions=None) == Union(
        {True: Boolean(), False: Union({True: String(), False: Const(None)})}
    )



# Generated at 2022-06-24 10:55:22.249790
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "string"}}
    expected = Not(negated=String())
    actual = not_from_json_schema(data, definitions=None)
    assert_equal(actual, expected)


# Generated at 2022-06-24 10:55:31.961200
# Unit test for function get_valid_types
def test_get_valid_types():
    l = get_valid_types(
        {
            "type": [
                "null",
                "boolean",
                "object",
                "array",
                "number",
                "string",
            ]
        }
    )
    assert l == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)

    l = get_valid_types(
        {
            "type": [
                "null",
            ]
        }
    )
    assert l == ({'null'}, True)

    l = get_valid_types(
        {
            "type": [
                "boolean"
            ]
        }
    )
    assert l == ({'boolean'}, False)

    l=get_valid_types({})

# Generated at 2022-06-24 10:55:38.809028
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # A validator that accepts any number that starts with 2 or 5
    schema = {
        "allOf": [
            {"type": "number"},
            {
                "if": {"type": "number"},
                "then": {"pattern": "^[25]"},
            }
        ]
    }
    v = from_json_schema(schema)
    assert v.is_valid(24) is False
    assert v.is_valid(25) is True



# Generated at 2022-06-24 10:55:53.021609
# Unit test for function from_json_schema_type

# Generated at 2022-06-24 10:55:57.180231
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "string"},
            {"minLength": 1}
        ]
    }
    print(all_of_from_json_schema(data, definitions=None))


# Generated at 2022-06-24 10:56:07.456118
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions).__class__ == Any
    assert type_from_json_schema({'type': 'number'}, definitions).__class__ == Number
    assert type_from_json_schema({'type': ['number', 'string']}, definitions).__class__ == Union
    assert type_from_json_schema({'type': 'number', 'minimum': 1}, definitions).__class__ == Integer
    assert type_from_json_schema({'type': 'number', 'maximum': 1}, definitions).__class__ == Integer
    assert type_from_json_schema({'type': 'number', 'minimum': 1, 'maximum': 2}, definitions).__class__ == Integer
    assert type_from_json_schema({'type': 'null'}, definitions).__class__ == Const
    assert type

# Generated at 2022-06-24 10:56:12.992943
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    kwargs = {
        "allow_null": True,
        "negated": Integer(),
        "default": NO_DEFAULT,
    }
    assert Not(**kwargs) == not_from_json_schema({"not": {"type": "integer"}}, definitions=definitions)



# Generated at 2022-06-24 10:56:15.620136
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    f = enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions=None)
    assert f.validate("a")
    assert not f.validate("d")



# Generated at 2022-06-24 10:56:17.920291
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'not': {'const': 1}}
    expected = Not(Const(1))
    actual = not_from_json_schema(schema, None)
    assert expected == actual

# Generated at 2022-06-24 10:56:29.676278
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        'type': 'integer',
        'enum': [1, 2, 3, 4]
    }) == Choice(
        [
            Integer(enum=[1, 2, 3, 4]),
        ]
    )

    assert from_json_schema({
        'type': 'array',
        'items': {
            'type': 'integer',
            'enum': [1, 2, 3, 4]
        }
    }) == Array(
        items=Choice(
            [
                Integer(enum=[1, 2, 3, 4]),
            ]
        )
    )


# Generated at 2022-06-24 10:56:37.943349
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    enum_field = enum_from_json_schema({"enum": [1, 2, 4, 7]})
    assert len(enum_field.choices) == 4 #check that the right amount of choices are in the field
    assert enum_field(1) == 1 #check that the choice 1 gives the right output
    #assert enum_field(1) == 1 #check that the choice 2 gives the right output
    #assert enum_field(1) == 1 #check that the choice 4 gives the right output
    #assert enum_field(1) == 1 #check that the choice 7 gives the right output



# Generated at 2022-06-24 10:56:42.032978
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "not": {"type": "integer"}
    }
    json_to_schema(schema)



# Generated at 2022-06-24 10:56:45.876591
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    input_data = {'not': {'type': 'boolean'}, 'default': None}
    expected_result = Not(negated=Boolean(allow_null=False, default=NO_DEFAULT), default=None)
    assert not_from_json_schema(input_data, None) == expected_result



# Generated at 2022-06-24 10:56:55.425953
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": None}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": ["null"]}) == ({"null"}, True)
    assert get_valid_types({"type": ["null", "array"]}) == ({"array", "null"}, True)

# Generated at 2022-06-24 10:57:06.251072
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    import jsonschema
    string_schema = {
        "type": "string",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "^\\d+$",
        "format": "date-time",
        "default": "abc123",
    }

    number_schema = {
        "type": "number",
        "minimum": 1,
        "maximum": 10,
        "exclusiveMinimum": 1,
        "exclusiveMaximum": 10,
        "multipleOf": 5,
        "default": 5,
    }


# Generated at 2022-06-24 10:57:16.697437
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "password": {"type": "string"},
                },
            },
        ],
    }
    field = from_json_schema(schema)
    assert isinstance(field, AllOf)
    assert len(field.all_of) == 2
    assert isinstance(field.all_of[0], Object)
    assert isinstance(field.all_of[1], Object)



# Generated at 2022-06-24 10:57:21.105858
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema1 = "schema/member_age_schema.json"
    with open(schema1) as age_data:
        age_schema = json.load(age_data)
    assert enum_from_json_schema(age_schema) == Choice(choices=[('20', '20'), ('21', '21'), ('22', '22')])


# Generated at 2022-06-24 10:57:23.999470
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field = one_of_from_json_schema({"oneOf": [{"type": "number"}, {"type": "string"}]})
    assert field.validate(5)
    assert not field.validate(True)



# Generated at 2022-06-24 10:57:29.904566
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    input_value = {
        "$ref": "#/definitions/STRING_TYPE"
    }
    expected_value = {
        "#/definitions/STRING_TYPE": Reference("#/definitions/STRING_TYPE"),
    }
    output_value = ref_from_json_schema(input_value, expected_value)
    assert output_value == Reference("#/definitions/STRING_TYPE"), output_value



# Generated at 2022-06-24 10:57:39.362933
# Unit test for function to_json_schema
def test_to_json_schema():

    class StringSchema(Schema):
        string = String()

    class StringWithFormatSchema(Schema):
        string_with_format = String(format="date-time")

    class StringWithPatternSchema(Schema):
        string_with_pattern = String(pattern="[A-Z]+")

    class StringWithLengthSchema(Schema):
        string_with_length = String(min_length=2, max_length=10)

    class StringWithAllProperties(Schema):
        string_with_all_properties = String(
            min_length=2,
            max_length=10,
            pattern="[A-Z]+",
            format="date-time",
            allow_null=True,
        )

    class IntegerSchema(Schema):
        integer = Integer()


# Generated at 2022-06-24 10:57:51.621172
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"enum": ["red"]}) == Choice(["red"])
    assert from_json_schema({"const": "red"}) == Const("red")
    assert from_json_schema({"allOf": [{"type": "integer"}]}) == Integer()
    assert from_json_schema({"anyOf": [{"type": "integer"}]}) == Integer()
    assert from_json_schema({"oneOf": [{"type": "integer"}]}) == Integer()
    assert from_json_schema({"not": {"type": "integer"}}) == ~Integer()
    assert from_json_schema({"if": {"type": "integer"}}) == Integer()
    assert from_json_

# Generated at 2022-06-24 10:57:58.247716
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions=SchemaDefinitions()
    definitions['#/simple_string']=String(max_length=10)
    assert isinstance(ref_from_json_schema({'$ref': '#/simple_string'}, definitions=definitions), Reference)
    assert isinstance(ref_from_json_schema({'$ref': '#/simple_string'}, definitions=definitions).to_python(), String)
    assert ref_from_json_schema({'$ref': '#/simple_string'}, definitions=definitions).to_python().max_length==10

# Generated at 2022-06-24 10:58:10.756089
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    load_const = from_json_schema({'const': 123})
    assert load_const.validate(123) == (123, None)
    assert load_const.validate(122) == (None, ['Value is not equal to int(123).'])
    assert load_const.validate(None) == (None, ['Value is not equal to int(123).'])

    load_const = from_json_schema({'const': {'deep': 123}})
    assert load_const.validate({'deep': 123}) == (
        {'deep': 123}, None
    )
    assert load_const.validate({'deep': 122}) == (None, ['Value is not equal to int(123).'])
    assert load_const.validate({'deep': None}) == (None, ['Value is None.'])

# Generated at 2022-06-24 10:58:19.372445
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema = {
        "definitions": {
            "person": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            }
        },
        "anyOf": [
            {"$ref": "#/definitions/person"},
            {"type": "string", "minLength": 3},
            {"type": "integer", "minimum": 0},
        ],
    }
    field = any_of_from_json_schema(json_schema, definitions=SchemaDefinitions())
    assert "(Union(all_of=<Field: Object(properties={'name': String(), 'age': Integer()})>, any_of=<Field: String()>) | Integer())" == str(field)



# Generated at 2022-06-24 10:58:26.372002
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_field_1 = const_from_json_schema({"const": 5, "default": 10}, definitions=definitions)
    assert const_field_1.to_primitive() == {"const": 5, "default": 10}



# Generated at 2022-06-24 10:58:33.836715
# Unit test for function get_valid_types

# Generated at 2022-06-24 10:58:45.223292
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Test that all JSON schema types can be converted to a typesystem field.
    """
    def assert_typesystem_field_is_expected_field(
        typesystem_field: Field, expected_field: Field
    ):
        assert(isinstance(typesystem_field, expected_field.__class__))
        assert(typesystem_field.to_primitive() == expected_field.to_primitive())

    assert_typesystem_field_is_expected_field(
        type_from_json_schema({"type": "string"}), String()
    )
    assert_typesystem_field_is_expected_field(
        type_from_json_schema({"type": "integer"}), Integer()
    )

# Generated at 2022-06-24 10:58:48.761712
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert(const_from_json_schema({
        "const": 1,
        "default": 2,
    }, definitions=None)
    == Const(1, 2))



# Generated at 2022-06-24 10:58:56.932565
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def run_with(data: str) -> None:
        # Define a schema, and encode it to a dictionary.
        schema = String(format="regex", pattern=re.compile(r"\d{8}"))
        definitions = SchemaDefinitions()
        definitions["../definitions/social_security_number"] = schema
        data = schema.to_json_schema(definitions=definitions)

        # Convert the dictionary back to a schema.
        root_schema = Object(properties={"foo": Reference("../definitions/social_security_number")})
        root_schema.to_python(data)

    run_with('{"$ref": "#/definitions/social_security_number"}')
    run_with('{"$ref": "../definitions/social_security_number"}')

# Generated at 2022-06-24 10:58:59.502223
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref = ref_from_json_schema(data={"$ref": "#/definitions/ref"}, definitions=None)
    assert ref.name == "#/definitions/ref"



# Generated at 2022-06-24 10:59:07.362756
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.fields import Integer, String

    data = {"type": "string"}
    field = from_json_schema(data)

    assert isinstance(field, String)

    data = {"type": "integer"}
    field = from_json_schema(data)

    assert isinstance(field, Integer)

    data = {"type": "number"}
    field = from_json_schema(data)

    assert isinstance(field, Float)

    data = {"type": "number", "minimum": 1}
    field = from_json_schema(data)

    assert isinstance(field, Float)
    assert field.minimum == 1

    data = {"type": "number", "minimum": 1, "maximum": 10}
    field = from_json_schema(data)

    assert isinstance(field, Float)


# Generated at 2022-06-24 10:59:13.916554
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    allof_json = {}
    allof_json["allOf"] = [
        {"type": "number", "minimum": 0},
        {"type": "number", "maximum": 100},
    ]
    allof_typesystem = from_json_schema(allof_json)
    assert allof_typesystem.is_valid(10)
    assert not allof_typesystem.is_valid(-1)

