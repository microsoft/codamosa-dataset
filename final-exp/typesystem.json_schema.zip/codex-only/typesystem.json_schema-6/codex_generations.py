

# Generated at 2022-06-24 10:49:21.390825
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert str(not_from_json_schema({"$ref": "#/definitions/positive-integer"}))=="Not(<Reference: '#/definitions/positive-integer'>,)"# pragma: no cover
    assert str(not_from_json_schema({"not": {"type":"integer"}}))=="Not(Integer(allow_null=False, minimum=0, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=NO_DEFAULT),)"# pragma: no cover

# Generated at 2022-06-24 10:49:27.692422
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Any(),
        then_clause=None,
        else_clause=None,
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema({"if": {}}, None)
    assert IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=None,
        default=NO_DEFAULT,
    ) == if_then_else_from_json_schema({"if": {}, "then": {}}, None)

# Generated at 2022-06-24 10:49:36.064877
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"integer", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": [None]}) == ({"integer", "boolean", "object", "array", "number", "string"}, True)
    assert get_valid_types({"type": ["null"]}) == ({"integer", "boolean", "object", "array", "number", "string"}, True)
    assert get_valid_types({"type": [1, "null", {"items": {}}]}) == (
        {"integer", "boolean", "object", "array", "number", "string"}, True)
    assert get_valid_types({"type": ["null", "number"]}) == ({"number"}, True)

# Generated at 2022-06-24 10:49:45.586742
# Unit test for function get_valid_types
def test_get_valid_types():
    # Test 1 - null is valid, empty type
    assert get_valid_types({"type": None}) == ({}, True)
    # Test 2 - null is valid, explicit valid null type
    assert get_valid_types({"type": "null", "minLength": 0}) == ({}, True)
    # Test 3 - null is valid, explicit invalid null type
    assert get_valid_types({"type": "null", "minLength": 1}) == ({}, False)
    # Test 4 - null is invalid, explicit valid null type
    assert get_valid_types({"type": "string", "minLength": 0}) == ({"string"}, True)
    # Test 5 - null is invalid, explicit invalid null type
    assert get_valid_types({"type": "string", "minLength": 1}) == ({"string"}, False)
    # Test 6

# Generated at 2022-06-24 10:49:55.145223
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "number"}) == ({'number'}, False)

    assert get_valid_types({"type": "null"}) == (set(), True)

    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)

    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean"}, True)

    assert get_valid_types({"type": ["null", "number"]}) == ({'number'}, True)

    assert get_valid_types({"type": ["null", "integer"]}) == ({'integer'}, True)

    assert get_valid_types({"type": ["null", "array"]}) == ({'array'}, True)

    assert get_valid_types({"type": ["null", "object"]})

# Generated at 2022-06-24 10:50:04.102641
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {"type": "object"}
    assert isinstance(from_json_schema(schema), Object)
    schema = {"type": "object", "$ref": "test"}
    assert isinstance(from_json_schema(schema), Object)
    schema = {"definitions": {"test": {"type": "object"}}}
    assert isinstance(from_json_schema(schema), Object)
    schema = {"definitions": {"test": {"type": "object"}}, "$ref": "#/definitions/test"}
    assert isinstance(from_json_schema(schema), Object)



# Generated at 2022-06-24 10:50:09.218707
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    base_object = {"const":"asd"}
    base_field = const_from_json_schema(data=base_object)
    assert base_field.schema() == Schema(const="asd") and base_field.const() == "asd"



# Generated at 2022-06-24 10:50:14.800420
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = all_of_from_json_schema({"allOf": [
        {"const": 1},
        {"type": "integer", "maximum": 10}
    ]}, definitions)
    assert schema.validate(1) == 1
    assert schema.validate(11) == 11


# Generated at 2022-06-24 10:50:19.002022
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 'test'}, SchemaDefinitions()) == Const("test")



# Generated at 2022-06-24 10:50:27.250939
# Unit test for function to_json_schema
def test_to_json_schema():

    from . import Integer, Float, Decimal, String, Boolean, Object, Reference

    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(
        Object(properties={"hello": Integer()}, pattern_properties={"hello": Integer()})
    ) == {
        "type": "object",
        "properties": {"hello": {"type": "integer"}},
        "patternProperties": {"hello": {"type": "integer"}},
    }

# Generated at 2022-06-24 10:50:38.176540
# Unit test for function to_json_schema
def test_to_json_schema():
    def make_field(value, **kwargs):
        return String(default=value, **kwargs)
    field = make_field("foo")
    schema = to_json_schema(field)
    assert schema == {"type": "string", "default": "foo"}
    field = make_field(None)
    schema = to_json_schema(field)
    assert schema == {"type": "string"}
    field = make_field(None, allow_null=True)
    schema = to_json_schema(field)
    assert schema == {"type": ["string", "null"]}
    field = make_field(5, minimum=3)
    schema = to_json_schema(field)

# Generated at 2022-06-24 10:50:44.377435
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "$ref": "#/definitions/Integer",
                "default": "123",
                "default2": "456"
            }, {
                "$ref": "#/definitions/String"
            }
        ],
        "default": "789"
    }
    definitions = SchemaDefinitions()
    Integer = Integer(default="123", default2="456")
    String = String()
    definitions["Integer"] = Integer
    definitions["String"] = String
    result = all_of_from_json_schema(data, definitions)
    assert(result.all_of[0] == Integer)
    assert(result.all_of[1] == String)
    assert(result.default == "789")



# Generated at 2022-06-24 10:50:49.552427
# Unit test for function to_json_schema
def test_to_json_schema():
    from datetime import timezone

    data = to_json_schema(Email())
    assert data["type"] == "string"
    assert data["format"] == "email"

    data = to_json_schema(FQDN())
    assert data["type"] == "string"
    assert data["format"] == "hostname"

    data = to_json_schema(URL())
    assert data["type"] == "string"
    assert data["format"] == "uri"

    data = to_json_schema(URI())
    assert data["type"] == "string"
    assert data["format"] == "uri-reference"

    data = to_json_schema(UUID())
    assert data["type"] == "string"
    assert data["format"] == "uuid"

    data = to_json_schema

# Generated at 2022-06-24 10:51:00.365398
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    SCHEMA = '{"$ref": "#/definitions/Test"}'
    DEFINITIONS = '{"definitions": {"Test": {"type": "number"}}}'
    json_schema = json.loads(SCHEMA)
    definitions = json.loads(DEFINITIONS)
    assert not ref_from_json_schema(json_schema, definitions=definitions).validate(1)
    assert ref_from_json_schema(json_schema, definitions=definitions).validate(1.0)
    assert ref_from_json_schema(json_schema, definitions=definitions).validate(1.5)
    assert not ref_from_json_schema(json_schema, definitions=definitions).validate("1")

# Generated at 2022-06-24 10:51:09.842942
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Array(allow_null=True)) == {"type": ["array", "null"]}
    assert to_json_schema(Object(allow_null=True)) == {"type": ["object", "null"]}
    assert to_json_schema(Integer(allow_null=True)) == {"type": ["integer", "null"]}
    assert to_json_schema(Float(allow_null=True)) == {"type": ["number", "null"]}

# Generated at 2022-06-24 10:51:13.767042
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert AllOf(all_of=[Any()]) == all_of_from_json_schema({"allOf": [{}]}, None)
    assert AllOf(all_of=[Any(), Any()]) == all_of_from_json_schema({"allOf": [{}, {}]}, None)



# Generated at 2022-06-24 10:51:20.054144
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_cases = [{"oneOf": [1, 2, 3], "default": 4},
                  {"oneOf": ["one", "two", "three"]}]
    for test_case in test_cases:
        json_schema = test_case
        python_schema = one_of_from_json_schema(json_schema, SchemaDefinitions())
        assert test_schema(python_schema, json_schema)


# Generated at 2022-06-24 10:51:21.624093
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()



# Generated at 2022-06-24 10:51:28.468490
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [{"enum": [False]}, {"type": "string"}, {"const": None}, {"allOf": []}],
        "default": "default",
    }
    field = one_of_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, OneOf)
    assert field.default == "default"
    assert field.one_of[0] == Choice(choices=[(False, False)])
    assert field.one_of[1] == String()
    assert field.one_of[2] == Const(const=None)
    assert field.one_of[3] == AllOf(all_of=[])



# Generated at 2022-06-24 10:51:35.929631
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    test_data = """
    {
      "enum": [
        1,
        "1",
        true,
        false
      ]
    }
    """
    enum = enum_from_json_schema(json.loads(test_data), SchemaDefinitions())
    assert isinstance(enum, Choice)
    assert enum(1) == 1
    assert enum("1") == "1"
    assert enum(True) == True
    assert enum(False) == False
    assert enum("2") == "2"



# Generated at 2022-06-24 10:51:37.999558
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="bob")) == {
        "default": "bob"
    }



# Generated at 2022-06-24 10:51:49.126962
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "test": {"type": "string"},
        },
    }
    schema = from_json_schema(data)
    assert isinstance(schema, Object)
    assert isinstance(schema.properties["test"], String)
    data = {
        "type": ["object", "null"],
        "properties": {
            "test": {"type": "string"},
        },
    }
    schema = from_json_schema(data)
    assert isinstance(schema, Union)
    assert isinstance(schema.any_of[0], Object)
    assert isinstance(schema.any_of[1], Const)
    assert schema.any_of[1].const == None



# Generated at 2022-06-24 10:51:55.037576
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    """
    Make sure the oneOf works
    """
    data = {
        "oneOf": [
            {
                "type": "string"
            },
            {
                "type": "integer"
            }
        ]
    }
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert OneOf(**kwargs) == OneOf(kwargs)


# Generated at 2022-06-24 10:51:57.388101
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert JSONSchema.validate({"not": {}}) == ({'not': {}}, None)
    assert JSONSchema.validate({"not": {"not": {}}}) == ({'not': {'not': {}}}, None)
    assert JSONSchema.validate({"not": {"type": "string"}}) == ({'not': {'type': 'string'}}, None)



# Generated at 2022-06-24 10:52:06.799526
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer(const=5)) == {"type": "integer", "const": 5}
    assert to_json_schema(Array(items=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }
    assert to_json_schema(Object(properties={"test": String()})) == {
        "type": "object",
        "properties": {"test": {"type": "string"}},
    }

# Generated at 2022-06-24 10:52:12.393748
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": ["string", "null"]}) == ({'string'}, True)
    assert get_valid_types({"type": ["string", "null", "integer"]}) == (
        {'integer', 'string'},
        True,
    )
    assert get_valid_types({"type": ["number"]}) == ({"number"}, False)



# Generated at 2022-06-24 10:52:16.341090
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    d = {
        "$ref": "#/definitions/SomeRef",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/SomeRef"] = String(default="Cherry")
    ref = ref_from_json_schema(d, definitions)
    assert ref.validate("Cherry") == "Cherry"
    
    



# Generated at 2022-06-24 10:52:19.439360
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    from jsonschema import ValidationError
    s = const_from_json_schema({"const": 1})
    s.validate(1)
    try:
        s.validate(2)
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-24 10:52:24.907360
# Unit test for function from_json_schema
def test_from_json_schema():
    assert type(from_json_schema({"type": "integer"})) is Integer
    assert type(from_json_schema({"type": "number"})) is Union
    assert type(from_json_schema({"type": "boolean"})) is Boolean
    assert type(from_json_schema({"type": "string"})) is String
    assert type(from_json_schema({"type": "object"})) is Object
    assert type(from_json_schema({"type": "array"})) is Array



# Generated at 2022-06-24 10:52:31.097962
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, None) == String()
    assert type_from_json_schema({"type": "null"}, None) == Const(None)
    assert type_from_json_schema({"type": "null"}, None) == Const(None)
    assert type_from_json_schema({"type": ["null", "string"]}, None) == Union(
        any_of=[
            Const(None),
            String(),
        ],
        allow_null=False
    )



# Generated at 2022-06-24 10:52:38.783317
# Unit test for function to_json_schema
def test_to_json_schema():
    class PersonSchema(Schema):
        name = String(allow_null=False)
        age = Integer(allow_null=False, minimum=0, maximum=139)
        license_number = String()

    data = to_json_schema(PersonSchema)

# Generated at 2022-06-24 10:52:40.160049
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from_json_schema({"type":"number"})



# Generated at 2022-06-24 10:52:46.695833
# Unit test for function to_json_schema
def test_to_json_schema():
    class Test(Schema):
        field = String()

    assert to_json_schema(Test)["definitions"] == {
        "Test.field": {
            "type": "string",
            "default": NO_DEFAULT,
        }
    }



# Generated at 2022-06-24 10:52:51.925772
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data={"type":"object","allOf":[{"type":"object","properties":{"type": {"type": "string", "enum": ["A", "B"]}},"required":["type"]}]}
    definitions = SchemaDefinitions()
    all_of_from_json_schema(data, definitions)
    return True

# Generated at 2022-06-24 10:52:56.218238
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3], 'default': 2}).default == 2
    assert enum_from_json_schema({"enum": [1, 2, 3]}).default is NO_DEFAULT


# Generated at 2022-06-24 10:53:06.097461
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    This test demonstrates that the IfThenElse field type is working.
    """
    schema = {
        "$ref": "#/definitions/foo",
        "definitions": {
            "foo": {
                "type": "object",
                "properties": {
                    "property1": {"type": "string"},
                    "property2": {"type": "integer"},
                    "property3": {"type": "boolean"},
                    "property4": {"type": "null"},
                },
            }
        },
    }


# Generated at 2022-06-24 10:53:09.122866
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema(data={"anyOf":[{"type":"integer"},{"type":"string"}]}, definitions=SchemaDefinitions()).any_of == [Integer(), String()]


# Generated at 2022-06-24 10:53:19.246179
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    assert isinstance(type_from_json_schema(data, definitions=SchemaDefinitions()), String)

    data = {"type": "integer"}
    assert isinstance(type_from_json_schema(data, definitions=SchemaDefinitions()), Integer)

    data = {"type": "number"}
    assert isinstance(type_from_json_schema(data, definitions=SchemaDefinitions()), Number)

    data = {"type": "float"}
    assert isinstance(type_from_json_schema(data, definitions=SchemaDefinitions()), Float)

    data = {"type": "decimal"}
    assert isinstance(type_from_json_schema(data, definitions=SchemaDefinitions()), Decimal)

    data = {"type": "boolean"}
   

# Generated at 2022-06-24 10:53:23.460374
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "number", "maximum": 10},
            {"type": "number", "minimum": 2},
        ]
    }
    field = from_json_schema(schema)
    assert field.validate(2) == 2
    assert field.serialize(2) == 2
    


# Generated at 2022-06-24 10:53:33.012684
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({"default": True}, "boolean", False, None) == Boolean(default=True)
    assert from_json_schema_type({"default": True}, "boolean", False, None) == Boolean(default=True)
    assert from_json_schema_type({"default": True}, "boolean", False, None) == Boolean(default=True)
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({"default": 1.5}, "number", False, None) == Float(default=1.5)
    assert from_json_schema_type({}, "integer", False, None) == Integer

# Generated at 2022-06-24 10:53:46.891473
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:53:53.728169
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {}
    definitions = SchemaDefinitions()
    output = type_from_json_schema(data, definitions=definitions)
    assert "allow_null" in output.constraints
    assert "field_type" in output.constraints
    assert output.allow_null is True
    assert output.field_type == "any"


# Generated at 2022-06-24 10:54:06.983289
# Unit test for function to_json_schema
def test_to_json_schema():
    from .fields import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Dict,
        Field,
        Float,
        Integer,
        List,
        NeverMatch,
        Noneable,
        Not,
        Object,
        OneOf,
        Optional,
        Reference,
        SchemaDefinitions,
        String,
        Union,
    )

    # Test that field types which are not compatible with JSON Schema raise ValueError
    try:
        Any().render_to_json_schema()
    except ValueError:
        pass
    else:
        assert False, "ValueError expected"  # pragma: no cover
    try:
        NeverMatch().render_to_json_schema()
    except ValueError:
        pass

# Generated at 2022-06-24 10:54:10.235535
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = {}
    field = String(default="value")
    data.update(get_standard_properties(field))
    assert data == {'default': 'value'}

    # test if default is None
    data = {}
    field = String(default=None)
    data.update(get_standard_properties(field))
    assert data == {}



# Generated at 2022-06-24 10:54:15.101766
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {"enum": ["foo", "bar", "baz"], "default": "bar"}
    field = enum_from_json_schema(json_schema, definitions)
    assert isinstance(field, Choice)
    assert len(field.choices) == 3
    assert field.default == "bar"



# Generated at 2022-06-24 10:54:17.369134
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference
    )



# Generated at 2022-06-24 10:54:19.756358
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"const": "hello"}}
    definitions = SchemaDefinitions()
    kwargs = {"negated": Const("hello"), "default": NO_DEFAULT}
    assert not_from_json_schema(data, definitions=definitions) == Not(**kwargs)



# Generated at 2022-06-24 10:54:24.877192
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"$ref": "definitions.json"}
    definitions = SchemaDefinitions()
    definitions["definitions.json"] = Const("foo")
    assert not_from_json_schema(data, definitions).apply(None) == False
    assert not_from_json_schema(data, definitions).apply("foo") == False
    assert not_from_json_schema(data, definitions).apply("bar") == True


# Generated at 2022-06-24 10:54:33.462419
# Unit test for function to_json_schema
def test_to_json_schema():
    import pytest  # type: ignore
    from pydantic import BaseModel, Schema  # type: ignore

    class User(BaseModel):
        name: str = Field(
            description="Name of the user.",
            title="User name",
            max_length=20,
            regex="^[\w]+$",
        )

    class Item(BaseModel):
        name: str
        price: float

    class Invoice(BaseModel):
        user: User
        items: typing.List[Item]
        total: float

    user_schema = to_json_schema(User)

# Generated at 2022-06-24 10:54:36.067375
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema(True), Field)
    assert isinstance(from_json_schema(False), Field)
    assert isinstance(from_json_schema({"type": "number"}), Field)

# Generated at 2022-06-24 10:54:45.123567
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=None) == String(min_length=0)
    assert from_json_schema_type({}, type_string="string", allow_null=True, definitions=None) == String(min_length=0, allow_null=True)
    assert from_json_schema_type({}, type_string="object", allow_null=False, definitions=None) == Object(min_properties=0)
    assert from_json_schema_type({}, type_string="object", allow_null=True, definitions=None) == Object(min_properties=0, allow_null=True)

# Generated at 2022-06-24 10:54:50.863809
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # fmt: off
    data = {
        "if": {"type": "string", "pattern": "^[0-9]$"},
        "then": {"type": "integer"},
        "else": {"type": "string"},
        "default": "no value"
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.to_json_schema() == data
    # fmt: on



# Generated at 2022-06-24 10:55:00.710161
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({
        "title": "User",
        "type": "object",
        "properties": {
            "age": {
                "type": "integer",
                "minimum": 0
            },
            "name": {
                "type": "string"
            }
        },
        "required": [
            "age",
            "name"
        ]
    }, {}) == {
        "properties": {
            "age": {
                "type": "integer",
                "minimum": 0
            },
            "name": {
                "type": "string"
            }
        },
        "required": [
            "age",
            "name"
        ]
    }, "all_of_from_json_schema should return Field"



# Generated at 2022-06-24 10:55:07.172974
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()
    assert from_json_schema_type({}, "integer", False, None) == Integer()
    assert from_json_schema_type({}, "string", False, None) == String()
    assert from_json_schema_type({}, "boolean", False, None) == Boolean()
    assert from_json_schema_type({}, "array", False, None) == Array()
    assert isinstance(from_json_schema_type({}, "object", False, None), Object)



# Generated at 2022-06-24 10:55:09.414290
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": "a"}, definitions = definitions)
    assert field.validate("a")
    assert not field.validate("b")


# Generated at 2022-06-24 10:55:17.551512
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    definitions = SchemaDefinitions()
    schema = {
        "type": "object",
        "properties": {
            "foo": {
                "oneOf": [
                    {
                        "type": "number",
                        "const": 3
                    },
                    {
                        "type": "object",
                        "required": ["foo"],
                        "properties": {
                            "foo": {
                                "type": "number"
                            }
                        }
                    }
                ]
            }
        }
    }
    root_field = from_json_schema(schema, definitions=definitions)
    assert root_field.validate({"foo": 3}) == {"foo": 3}
    assert root_field.validate({"foo": {"foo": 5}}) == {"foo": {"foo": 5}}


# Generated at 2022-06-24 10:55:28.855857
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=False), Number)
    assert str(
        from_json_schema_type({}, type_string="number", allow_null=False)
    ).startswith("Number<")

    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False), Integer)
    assert str(
        from_json_schema_type({}, type_string="integer", allow_null=False)
    ).startswith("Integer<")

    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)

# Generated at 2022-06-24 10:55:36.686834
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {"enum": ["a", "b"]}
    field = enum_from_json_schema(json_schema, definitions=definitions)
    assert field.validate("a")
    assert field.validate("b")
    assert not field.validate("c")
    assert field.to_json_schema() == json_schema



# Generated at 2022-06-24 10:55:41.459483
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(
        data={"not": {"type": "string"}}, definitions=SchemaDefinitions()
    ) == Not(negated=String())



# Generated at 2022-06-24 10:55:45.696190
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": 88, "default": 99}
    kwargs = {"const": 88, "default": 99}
    assert const_from_json_schema(data, definitions).kwargs == kwargs


# Generated at 2022-06-24 10:55:49.436726
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Boolean(),
        else_clause=Boolean(),
    ) == if_then_else_from_json_schema({
        "if": {"type": "boolean"},
        "then": {"type": "boolean"},
        "else": {"type": "boolean"},
    })

# Generated at 2022-06-24 10:55:59.642112
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "integer", "minimum": 0},
        "then": {"type": "string"},
        "else": {"type": "array", "items": {"type": "integer", "minimum": 0}},
    }
    field = if_then_else_from_json_schema(schema, definitions=None)
    validate(field, 0, "test")
    try:
        validate(field, -1, "test")
    except Invalid as exc:
        assert str(exc) == f'Invalid value (-1). The field "if" is invalid. Invalid value (-1). The field "type" is invalid. Value is not one of {{"integer", "number"}}.'
    else:
        assert False, "Should not happen"
    validate(field, [])

# Generated at 2022-06-24 10:56:06.835073
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema({"type": "string", "minLength": 0}) == String(
        allow_blank=True
    )

    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "integer", "default": 42}) == Integer(
        default=42
    )

    assert type_from_json_schema({"type": "array"}) == Array()
    assert type_from_json_schema({"type": "array", "minItems": 0}) == Array(min_items=0)

    assert type_from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-24 10:56:16.093713
# Unit test for function from_json_schema

# Generated at 2022-06-24 10:56:26.499395
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schemas = [
        {
            "const": "hi"
        },
        {
            "enum": ["hi", "hello"]
        },
        {
            "type": "string",
            "minLength": 3,
            "maxLength": 10
        },
        {
            "type": "integer",
            "minimum": 5
        }
    ]
    for schema in schemas:
        field = not_from_json_schema({"not": schema})
        assert field.validate("hi") == (False, [])
        assert field.validate("hello") == (False, [])
        assert field.validate("hiyoo") == (False, [])
        assert field.validate(7) == (False, [])
        assert field.validate("") == (True, None)
        assert field

# Generated at 2022-06-24 10:56:34.922832
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True).validate(True) == {"__root__": True}
    assert from_json_schema(False).validate(False) == {"__root__": False}
    assert from_json_schema({"enum": [1, 2, 3]}).validate(2) == {"__root__": 2}
    assert from_json_schema({"type": "integer", "minimum": 3, "maximum": 5}).validate(4) == {"__root__": 4}



# Generated at 2022-06-24 10:56:45.003468
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_from_json_schema_type = lambda data: from_json_schema_type(
        data=data, type_string="number", allow_null=False, definitions=SchemaDefinitions()
    )
    assert type_from_json_schema_type({}) == Float()
    assert type_from_json_schema_type({"minimum": 0.0}) == Float(minimum=0.0)
    assert type_from_json_schema_type({"maximum": 1.0}) == Float(maximum=1.0)
    assert type_from_json_schema_type(
        {
            "minimum": 0.0,
            "maximum": 1.0,
        }
    ) == Float(
        minimum=0.0, maximum=1.0
    )
    assert type_from_json_

# Generated at 2022-06-24 10:56:51.692503
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions) == Any()
    assert (
        type_from_json_schema(
            {"type": "string"}, definitions
        )
        == String(allow_null=False)
    )
    assert (
        type_from_json_schema(
            {"type": ["string", "null"]}, definitions
        )
        == Union(any_of=[String(allow_null=False), Const(None)])
    )



# Generated at 2022-06-24 10:57:02.121169
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        title = 'Example Schema',
        type = 'object',
        properties = {
            'firstName': {
                'type': 'string'
            },
            'lastName': {
                'type': 'string'
            },
            'age': {
                'description': 'Age in years',
                'type': 'integer',
                'minimum': 0
            }
        },
        required = ['firstName', 'lastName']
    )

    result = to_json_schema(schema)


# Generated at 2022-06-24 10:57:07.112636
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_field = const_from_json_schema({"const":123}, definitions=None)
    assert const_field.validate(123) == 123
    assert const_field.validate(456) == None


# Generated at 2022-06-24 10:57:19.302386
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    input = {
        'oneOf': [
            {'type': 'integer'},
            {'type': 'string'},
        ],
        'default': 'default',
    }
    expectations = {
        'one_of': [Integer(), String()],
        'default': 'default',
    }
    actual = one_of_from_json_schema(input, definitions=None)
    actual_kwargs = actual.get_kwargs()
    for key in expectations.keys():
        assert key in actual_kwargs, f'key {key} not in {actual_kwargs}'
        assert actual_kwargs[key] == expectations[key], \
            f'actual[{key}] = {actual_kwargs[key]} != expectations[{key}] = {expectations[key]}'
    return actual



# Generated at 2022-06-24 10:57:27.954929
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Test const of JSON schema in numbers
    jsonSchema1 = {'const': 1}
    assert isinstance(const_from_json_schema(jsonSchema1, None), Object)
    jsonSchema2 = {'const': 3.14}
    assert isinstance(const_from_json_schema(jsonSchema2, None), Object)

    # Test const of JSON schema in strings
    jsonSchema3 = {'const': 'Some String'}
    assert isinstance(const_from_json_schema(jsonSchema3, None), Object)

    # Test const of JSON schema with default value
    jsonSchema4 = {'const': 'Some String', 'default': 'Another String'}
    assert isinstance(const_from_json_schema(jsonSchema4, None), Object)

    # Test const of

# Generated at 2022-06-24 10:57:31.197005
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const = "greet"
    data = {"const": const}
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions=definitions)
    assert field.const == const



# Generated at 2022-06-24 10:57:33.624789
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": 1.5
    }
    assert "1.5" in const_from_json_schema(data).to_primitive()



# Generated at 2022-06-24 10:57:39.865462
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json = {
        "$schema": "http://json-schema.org/draft/2019-09/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "description": "A product from Acme's catalog",
        "type": "object",
        "properties": {
            "id": {"type": "number"},
            "name": {"type": "string"},
            "price": {"type": "number"},
        },
        "required": ["id", "name", "price"],
    }

    ret = one_of_from_json_schema(json, {})
    print(ret)



# Generated at 2022-06-24 10:57:50.836872
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    test_schema = {
        "if": {"type": "boolean"},
        "then": {
            "type": "object",
            "required": ["ifTrue"],
            "properties": {"ifTrue": {"type": "boolean"}},
        },
        "else": {
            "type": "object",
            "required": ["ifFalse"],
            "properties": {"ifFalse": {"type": "boolean"}},
        },
    }
    field = from_json_schema(test_schema)
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, Boolean)
    assert isinstance(field.then_clause, Object)
    assert isinstance(field.else_clause, Object)

# Generated at 2022-06-24 10:57:53.322679
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert (
        str(ref_from_json_schema(data={"$ref": "#/a/b/c"}, definitions=SchemaDefinitions()))
        == "Reference(#/a/b/c)"
    )



# Generated at 2022-06-24 10:57:55.917146
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "integer", "minimum": 0}, {"type": "integer", "maximum": 9}]}
    all_of = all_of_from_json_schema(data, definitions)
    assert all_of.validate(5)



# Generated at 2022-06-24 10:58:01.848622
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    doc = {"$ref": "#/definitions/person"}
    schema = SchemaDefinitions()
    schema["#/definitions/person"] = String()
    field = ref_from_json_schema(data=doc, definitions=schema)

    assert isinstance(field, Reference)
    assert field.to == "#/definitions/person"



# Generated at 2022-06-24 10:58:12.357192
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "$ref": "#/definitions/MyUnionOfBooleanOrString",
        "type": "boolean",
        "definitions": {
            "MyUnionOfBooleanOrString": {
                "anyOf": [
                    "boolean",
                    {"$ref": "#/definitions/MyString"},
                ]
            },
            "MyString": {
                "type": "string",
                "default": "hello",
            }
        }
    }
    definitions = SchemaDefinitions()
    definitions["/MyUnionOfBooleanOrString"] = from_json_schema(data, definitions=definitions)
    schema = from_json_schema(data, definitions=definitions)
    assert isinstance(schema, Reference)
    assert isinstance(schema.resolve(definitions), Union)


# Generated at 2022-06-24 10:58:14.723942
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(String(default="string"))
    assert data == {"default": "string"}



# Generated at 2022-06-24 10:58:23.269810
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({
        "enum": [10, 20],
        "default": 30
    }, definitions=SchemaDefinitions()) == Choice(choices=[(10, 10), (20, 20)], default=30)
    assert enum_from_json_schema({
        "enum": [10, 20]
    }, definitions=SchemaDefinitions()) == Choice(choices=[(10, 10), (20, 20)])
    assert enum_from_json_schema({
        "enum": [10, 20],
        "default": None
    }, definitions=SchemaDefinitions()) == Choice(choices=[(10, 10), (20, 20)])

# Generated at 2022-06-24 10:58:32.404774
# Unit test for function get_valid_types
def test_get_valid_types():
    test_data = {
        ({"type": "null"}, {"null"}, True): True,
        ({"type": "string"}, {"string"}, False): True,
        ({"type": ["null", "string"]}, {"string"}, True): True,
        ({"type": ["null", "string"]}, {"string"}, False): False,
        ({"type": ["null", "string"]}, {"null", "string"}, False): False,
    }
    for key, value in test_data.items():
        ret = (get_valid_types(key[0]), key[1], key[2]) == (
            value,
            key[1],
            key[2],
        )
        assert ret is True, "get_valid_types test failed"
test_get_valid_types()



# Generated at 2022-06-24 10:58:33.058225
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer"}) == Integer()

# Generated at 2022-06-24 10:58:44.207335
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "string",
        "minLength": 0,
        "maxLength": 10,
        "format": "date-time",
        "pattern": r"^(.*)$",
        "default": "",
    }
    for type_string in data["type"]:
        assert isinstance(
            from_json_schema_type(data, type_string, allow_null=False, definitions={}),
            String,
        )

    data = {
        "type": ["number", "integer"],
        "minimum": 0.0,
        "maximum": 100.0,
        "exclusiveMinimum": 0.0,
        "exclusiveMaximum": 100.0,
        "multipleOf": 1.0,
        "default": 0,
    }

# Generated at 2022-06-24 10:58:54.689845
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    import pathlib

    schema = Schema._make_validator(
        {
            "foo": "bar",
            "hello": "world",
            "foo_array": ["hello", "world"],
            "schema_array": [1, 2, 3, 4],
        }
    )
    schema_json = to_json_schema(schema)
    print(json.dumps(schema_json, indent=4))
    assert schema_json["definitions"]["#"]["properties"]["foo_array"]["items"][0] == {
        "$ref": "#/definitions/##/properties/hello"
    }


# Generated at 2022-06-24 10:59:04.066985
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"})==(set(), True)
    assert get_valid_types({"type": ["null"]})==(set(), True)
    assert get_valid_types({"type": "integer"}) == ({"integer"},False)
    assert get_valid_types({"type": "number"}) == ({"number"},False)
    assert get_valid_types({"type": ["number", "integer"]})==({"number"},False)
    assert get_valid_types({"type": ["number", "integer","boolean","object","array", "string"]})==({"number","integer","boolean","object","array", "string"},False)
    assert get_valid_types({"type": "string"})==({"string"},False)



# Generated at 2022-06-24 10:59:10.706806
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type({}, type_string="object", allow_null=False, definitions=None)
    from_json_schema_type(
        {}, type_string="array", allow_null=False, definitions=None
    )
    from_json_schema_type(
        {}, type_string="string", allow_null=False, definitions=None
    )
    from_json_schema_type(
        {}, type_string="integer", allow_null=False, definitions=None
    )
    from_json_schema_type(
        {}, type_string="boolean", allow_null=False, definitions=None
    )
    from_json_schema_type({}, type_string="null", allow_null=True, definitions=None)



# Generated at 2022-06-24 10:59:21.652568
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field0 = enum_from_json_schema({"enum": ["a", "b", "c"]}, definitions={})
    expected0 = Choice([("a", "a"), ("b", "b"), ("c", "c")])
    assert field0 == expected0
    field1 = enum_from_json_schema({"enum": ["a", "b", "c"], "default": "b"}, definitions={})
    expected1 = Choice([("a", "a"), ("b", "b"), ("c", "c")], default="b")
    assert field1 == expected1
    field2 = enum_from_json_schema(
        {"enum": ["a", "b", "c"], "default": "d"}, definitions={}
    )