

# Generated at 2022-06-24 10:49:21.538625
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 5,
        "pattern": "^hello.*",
        "enum": ["hello", "bye"],
        "const": "bye"
    }
    result = type_from_json_schema(data, definitions=None)
    expected = Union(
        any_of=[
            String(min_length=1, max_length=5, pattern=re.compile("^hello.*")),
            Choice(any_of=["hello", "bye"]),
        ],
        allow_null=True
    )
    assert result == expected


# Generated at 2022-06-24 10:49:24.669813
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Arrange
    boolean_field: Field = Boolean(default=False)
    string_field: Field = String(default="hello")
    never_field: Field = NeverMatch()

    # Act & Assert
    assert get_standard_properties(boolean_field) == {
        "default": False
    }
    assert get_standard_properties(string_field) == {
        "default": "hello"
    }
    assert get_standard_properties(never_field) == {}
    assert get_standard_properties(None) == {}

# Generated at 2022-06-24 10:49:28.669128
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/id"] = Integer()
    definitions["#/definitions/name"] = String()
    field = from_json_schema(
        {"$ref": "#/definitions/id"}, definitions=definitions
    )
    assert isinstance(field, Reference), "The field must be a Reference"



# Generated at 2022-06-24 10:49:30.932864
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/MyReference"}) == Reference(
        to="#/definitions/MyReference")


# Generated at 2022-06-24 10:49:37.515635
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-24 10:49:44.316862
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()



# Generated at 2022-06-24 10:49:50.316312
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["string", "integer"]}) == ({"string", "integer"}, False)
    assert get_valid_types({"type": ["string", "null"]}) == ({"string"}, True)



# Generated at 2022-06-24 10:49:57.921949
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.schemas import Reference
    from typesystem.types import String
    from typesystem import typesystem

    definitions = typesystem.SchemaDefinitions()

    assert from_json_schema_type(
        {"type": "string"},
        type_string="string",
        allow_null=False,
        definitions=definitions,
    ) == String()
    assert from_json_schema_type(
        {"type": "null", "default": None},
        type_string="null",
        allow_null=True,
        definitions=definitions,
    ) == String()
    assert from_json_schema_type(
        {"type": "null", "default": None},
        type_string="null",
        allow_null=True,
        definitions=definitions,
    ) == String()

# Generated at 2022-06-24 10:50:07.164642
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': ['null']}) == (set(), True)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': ['number', 'null']}) == ({'number'}, True)
    assert get_valid_types({'type': ['number', 'integer']}) == ({'number', 'integer'}, False)



# Generated at 2022-06-24 10:50:21.026832
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Int(default=3)) == {"default": 3}
    assert get_standard_properties(String(default="Hello")) == {"default": "Hello"}
    assert get_standard_properties(IfThenElse(if_clause=True, then_clause=True)) == {}
    assert get_standard_properties(Not(negated=True)) == {}
    assert get_standard_properties(OneOf(one_of=[True])) == {}
    assert get_standard_properties(Array(items=True)) == {}
    assert get_standard_properties(Object(properties={"name": True})) == {}
    assert get_standard_properties(Choice(choices=[])) == {}
    assert get_standard_properties(Const(const=False)) == {}

# Generated at 2022-06-24 10:50:27.547155
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Unit test for function 'ref_from_json_schema'.
    """
    assert ref_from_json_schema({"$ref": "#/definitions/some-definition"}) == Reference(
        to="#/definitions/some-definition"
    )
    try:
        ref_from_json_schema({"$ref": "//some.example.com/custom"})
        assert False, "Should have raised an exception"  # pragma: no cover
    except:
        pass

# Generated at 2022-06-24 10:50:38.313721
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    import pytest
    from typesystem.schemas import Reference

    assert isinstance(type_from_json_schema({"type": "string"}, definitions=definitions), String)
    assert isinstance(type_from_json_schema({"type": "integer"}, definitions=definitions), Integer)
    assert isinstance(type_from_json_schema({"type": "number"}, definitions=definitions), Number)
    assert isinstance(type_from_json_schema({"type": "boolean"}, definitions=definitions), Boolean)
    assert isinstance(type_from_json_schema({"type": "array"}, definitions=definitions), Array)
    assert isinstance(type_from_json_schema({"type": "object"}, definitions=definitions), Object)

# Generated at 2022-06-24 10:50:47.146680
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_schema_definition = {
    'oneOf': [{
        'type': 'string',
        'pattern': "^[A-Za-z]+$",
        }]}
    one_of_field = one_of_from_json_schema(json_schema_definition, SchemaDefinitions())
    data = "Alphabet"
    # Functions as expected
    one_of_field.validate(data)
    data = "Alphabet123"
    # Fails as expected
    with pytest.raises(ValidationError):
        one_of_field.validate(data)



# Generated at 2022-06-24 10:50:52.871755
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "number"},
            {"type": "number", "minimum": 10},
        ],
    }
    assert all_of_from_json_schema(data, definitions=definitions) == AllOf(
        all_of=[Float(), Float(minimum=10)]
    )



# Generated at 2022-06-24 10:51:00.776598
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "string",
        "format": "email",
    }
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert field == String(format="email")

    data = {
        "type": "string",
        "format": "email",
        "nullable": True,
    }
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert field == Union(
        any_of=[String(format="email"), Const(None)],
        allow_null=True,
    )



# Generated at 2022-06-24 10:51:09.777804
# Unit test for function from_json_schema
def test_from_json_schema():
    boolean_field = from_json_schema({"type": "boolean"})
    assert isinstance(boolean_field, type(Boolean()))
    assert boolean_field.validate(True) is None
    assert boolean_field.validate(False) is None
    assert boolean_field.validate(0) == ['Must be of type "boolean".']
    assert boolean_field.validate("False") == ['Must be of type "boolean".']

    string_field = from_json_schema({"type": "string"})
    assert isinstance(string_field, type(String()))
    assert string_field.validate("") is None
    assert string_field.validate("foo") is None
    assert string_field.validate("0") is None
    assert string_field.validate(0)

# Generated at 2022-06-24 10:51:18.117277
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.json_schema import from_json_schema

    data = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    schema = from_json_schema(data)
    assert schema.validate(1) == 1
    assert schema.validate("1") == "1"
    assert schema.validate(1.0) == 1.0

    assert schema.validate_instance(1) == (1, None)
    assert schema.validate_instance("1") == ("1", None)
    assert schema.validate_instance(1.0) == (None, ["oneOf"])



# Generated at 2022-06-24 10:51:27.143716
# Unit test for function from_json_schema_type

# Generated at 2022-06-24 10:51:37.422158
# Unit test for function from_json_schema
def test_from_json_schema():
    # Boolean
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    # String
    assert from_json_schema({'type': 'string'}) == String()
    # Integer
    assert from_json_schema({'type': 'integer'}) == Integer()
    # Number
    assert from_json_schema({'type': 'number'}) == Number()
    # Union
    assert from_json_schema({'type': ['string', 'null']}) == Union(fields=[String(), None])
    # Array
    assert from_json_schema({'type': 'array'}) == Array()
    assert from_json_schema({'type': 'array', 'items': {'type': 'string'}}) == Array(items=String())


# Generated at 2022-06-24 10:51:40.438951
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'integer'}], 'default': 0}, definitions),Union)



# Generated at 2022-06-24 10:51:50.621709
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    from typesystem.schema import Schema
    from typesystem.fields import Boolean, Integer, Object, String

    schema_data = {
        "title": "User",
        "required": ["first_name", "last_name"],
        "type": "object",
        "properties": {
            "uuid": {"type": "string", "format": "uuid", "default": "00000000-0000-0000-0000-000000000000"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
        },
    }
    schema = Schema(schema_data)

    assert isinstance(schema, Schema)
    assert isinstance(schema.fields["uuid"], String)
    assert isinstance(schema.fields["first_name"], String)

# Generated at 2022-06-24 10:51:51.941793
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, None) == Any()



# Generated at 2022-06-24 10:51:56.096497
# Unit test for function get_valid_types
def test_get_valid_types():
    print(get_valid_types({"type" : "null"}))
    print(get_valid_types({"type" : ["null","number"]}))
    #print(get_valid_types({"type" : {"null","number"}})) # Uncomment to see error
test_get_valid_types()


# Generated at 2022-06-24 10:52:04.098949
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type_from_json_schema(
        {"type": "number"}, definitions=SchemaDefinitions()
    ) == Float(allow_null=False)

    assert type_from_json_schema(
        {"type": "integer"}, definitions=SchemaDefinitions()
    ) == Integer(allow_null=False)

    assert type_from_json_schema(
        {"type": "string"}, definitions=SchemaDefinitions()
    ) == String(allow_null=False, allow_blank=True, min_length=None, max_length=None)

    assert type_from_json_schema(
        {"type": "boolean"}, definitions=SchemaDefinitions()
    ) == Boolean(allow_null=False)


# Generated at 2022-06-24 10:52:08.238292
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {"type": "string"}
    assert from_json_schema(schema) == String()

    schema = {"type": ["string", "null"]}
    assert from_json_schema(schema) == String(allow_null=True)

    schema = {"type": ["string", "number"]}
    assert from_json_schema(schema) == Union(
        any_of=[String(), Number(allow_null=False)], allow_null=False
    )

    schema = {"type": ["string", "number"], "nullable": True}
    assert from_json_schema(schema) == Union(
        any_of=[String(), Number(allow_null=False)], allow_null=True
    )

    schema = {"type": ["string", "object", "null"]}
    assert from_json

# Generated at 2022-06-24 10:52:11.213380
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    s=from_json_schema({"type": "object", "properties": {"a": {"allOf": [{"type": "number"}, {"minimum": 0} ]}}})
    print(s)
test_all_of_from_json_schema()


# Generated at 2022-06-24 10:52:17.655268
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "integer",
            "maximum": 3,
            "default": 0,
        },
    }
    expected_result = Not(
        negated=Integer(minimum=4, default=0),
        default=data["not"]["default"],
    )
    actual_result = not_from_json_schema(data)
    assert expected_result.flatten() == actual_result.flatten()



# Generated at 2022-06-24 10:52:24.847537
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema_json_string = json.dumps(
        {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "if": {"type": "string"},
            "then": {"minLength": 1},
            "else": {"type": "integer"},
        },
    )
    schema = from_json_schema(json.loads(schema_json_string))
    result = schema.validate(None)
    assert isinstance(result, Invalid)
    result = schema.validate("")
    assert isinstance(result, Invalid)
    result = schema.validate("x")
    assert result == "x"
    result = schema.validate(0)
    assert isinstance(result, Invalid)
    result = schema.validate(1)
    assert result == 1



# Generated at 2022-06-24 10:52:27.608650
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {"$schema": "http://json-schema.org/draft-07/schema#", "allOf": [{"type": "integer"}, {"const": 1}]}
    _from_json_schema = AllOf(all_of=[Integer(), Const(const=1)])
    assert from_json_schema(schema) == _from_json_schema


# Generated at 2022-06-24 10:52:31.822644
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    json_schema = {
        "const": 5,
        "default": {"foo": "bar"}
    }
    expected = Const(
        const=5,
        default={"foo": "bar"}
    )
    assert const_from_json_schema(json_schema, definitions=None) == expected


# Generated at 2022-06-24 10:52:36.475776
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "default": "foo",
        "not": {"type": "string"},
        "type": "object",
    }
    result = not_from_json_schema(data, None)
    assert result.default == "foo"



# Generated at 2022-06-24 10:52:40.391615
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field = one_of_from_json_schema({"oneOf": {"a" : "b"}}, definitions = None)
    assert isinstance(field, OneOf)
    assert field.one_of == [{"a" : "b"}]
    assert field.default == None

    field = one_of_from_json_schema({"oneOf": [{"a" : "b"}], "default": "ab"}, definitions = None)
    assert isinstance(field, OneOf)
    assert field.one_of == [{"a" : "b"}]
    assert field.default == "ab"



# Generated at 2022-06-24 10:52:46.201377
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert len(all_of_from_json_schema({"allOf": [{"type": "string"}, {"type": "number"}]},definitions={"test":True}).all_of) == 2


# Generated at 2022-06-24 10:52:57.083164
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type":"null"}
    assert get_valid_types(data) == ({}, True)
    data = {"type":"boolean"}
    assert get_valid_types(data) == ({"boolean"}, False)
    data = {"type":"array"}
    assert get_valid_types(data) == ({"array"}, False)
    data = {"type":"number"}
    assert get_valid_types(data) == ({"number"}, False)
    data = {"type":"string"}
    assert get_valid_types(data) == ({"string"}, False)
    data = {"type":[]}
    assert get_valid_types(data) == ({"null", "boolean", "object", "array", "number", "string"}, True)
    data = {"type":"null,boolean"}
    assert get_valid_types(data)

# Generated at 2022-06-24 10:52:59.439877
# Unit test for function ref_from_json_schema

# Generated at 2022-06-24 10:53:06.178929
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema(data={"const": 0}) == Const(const=0)
    assert const_from_json_schema(data={"const": "abc"}) == Const(const="abc")
    assert const_from_json_schema(data={"const": {"a": "a"}}) == Const(const={"a": "a"})



# Generated at 2022-06-24 10:53:12.987004
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json_schema = {
        "item1": {"type": ["string", "integer"]},
        "item2": {"type": ["integer"]},
        "not": {"anyOf": [{"$ref": "#/item1"}, {"$ref": "#/item2"}]},
        "default": "default_not",
    }
    deserialized = from_json_schema(json_schema, SchemaDefinitions())
    assert deserialized.default == "default_not"
    assert deserialized.id == "not(anyof(ref(item1), ref(item2)))"



# Generated at 2022-06-24 10:53:22.855035
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "boolean"},
    }
    schema = if_then_else_from_json_schema(data, None)
    assert isinstance(schema, IfThenElse)
    assert isinstance(schema.if_clause, String)
    assert isinstance(schema.then_clause, Boolean)
    assert schema.else_clause is None
    data = {
        "if": {"type": "string"},
        "then": {"type": "boolean"},
        "else": {"type": "integer"},
    }
    schema = if_then_else_from_json_schema(data, None)
    assert isinstance(schema, IfThenElse)
    assert isinstance(schema.if_clause, String)

# Generated at 2022-06-24 10:53:32.639996
# Unit test for function not_from_json_schema

# Generated at 2022-06-24 10:53:35.048069
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'$ref': '#/definitions/MySchema'}
    result = not_from_json_schema(data, definitions=None)
    assert result == Reference(to='#/definitions/MySchema', definitions=None)
    assert result.get_default() == NO_DEFAULT



# Generated at 2022-06-24 10:53:40.356206
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Basic structure
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "if": {"type": "number"},
        "then": {"type": "string"},
        "default": "otherwise",
    }
    value = if_then_else_from_json_schema(schema, definitions=None)
    assert value.default == "otherwise"
    assert value.if_clause.type == "number"
    assert value.then_clause.type == "string"
    assert value.else_clause is None

    # No assert

# Generated at 2022-06-24 10:53:44.492607
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'not': {'type': 'string'}, 'default': 'foo'}) == Not(negated=String(allow_null=False, allow_blank=False, default=NO_DEFAULT), default='foo')

# Generated at 2022-06-24 10:53:50.778926
# Unit test for function get_valid_types
def test_get_valid_types():
    test_true = [
        {'type':['integer','boolean','array']},
        {'$ref':'#/definitions/Person'},
        {'type':['integer','boolean','array'], 'nullable': True},
        {'type':['integer','boolean','array'], 'nullable': False},
        {'type':'integer', 'nullable': True},
        {'type':'integer', 'nullable': False},
    ]
    test_false = [
        {'type':['object']},
        {'$ref':'#/definitions/Person'},
        {'type':'object', 'nullable': True},
        {'type':'object', 'nullable': False},
        {'type':'integer', 'nullable': False},
    ]

# Generated at 2022-06-24 10:53:59.505130
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, True)
    assert get_valid_types({"type": "number"}) == ({"number"}, True)
    assert get_valid_types({"type": "string"}) == ({"string"}, True)
    assert get_valid_types({"type": "array"}) == ({"array"}, True)
    assert get_valid_types({"type": "object"}) == ({"object"}, True)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean", "type": "null"})

# Generated at 2022-06-24 10:54:05.160480
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "type": ["string"],
        "anyOf": [{"enum": ["foo"]}, {"enum": ["bar"]}],
    }
    field = from_json_schema(schema)
    assert field.is_valid("foo")
    assert field.is_valid("bar")
    assert field.is_valid("baz") is False
    assert field.is_valid(None) is False



# Generated at 2022-06-24 10:54:11.905902
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, None) == Any()
    assert type_from_json_schema({"type": "null"}, None) == Const(None)
    assert type_from_json_schema({"type": "string"}, None) == String()
    assert type_from_json_schema({"type": "number"}, None) == Number()
    assert type_from_json_schema({"type": "integer"}, None) == Integer()
    assert type_from_json_schema({"type": "boolean"}, None) == Boolean()
    assert type_from_json_schema({"type": "object"}, None) == Object()
    assert type_from_json_schema({"type": "array"}, None) == Array()

# Generated at 2022-06-24 10:54:24.622990
# Unit test for function to_json_schema
def test_to_json_schema():
    from jsonschema import validate

    def test_round_trip(arg):
        if isinstance(arg, SchemaDefinitions) and not arg:
            return

        data = to_json_schema(arg)
        # if isinstance(arg, Field):
        #     print(repr((f'validate({arg}, **data)', data)))
        validate(instance=arg.default, schema=data)
        new_arg = from_json_schema(data)
        assert repr(arg) == repr(new_arg)

    class TestSchema(Schema):
        arg0 = String(regex="^[0-9a-f]{5}$")
        arg1 = String(regex="^[0-9a-f]{5}$")


# Generated at 2022-06-24 10:54:33.307558
# Unit test for function to_json_schema
def test_to_json_schema():
    class Data(SchemaDefinitions):
        _definition_name = "data"
        string_a = String(required=True)
        string_b = String(min_length=1, pattern_regex=re.compile("[a-z]+", flags=re.I))
        integer_a = Integer(required=True)
        integer_b = Integer(minimum=0, multiple_of=2)
        boolean = Boolean()
        array = Array(items=[String(), Integer(minimum=0)])
        object_a = Object(properties={"nested_string": String(min_length=1)})
        object_b = Object(
            properties={
                "nested_string": String(min_length=1),
                "nested_number": Integer(minimum=0),
            }
        )

# Generated at 2022-06-24 10:54:39.290896
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type(
            {}
        ),  # pylint: disable=W0212
        typesystem.fields.Any,
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="integer"
        ),  # pylint: disable=W0212
        typesystem.fields.Integer,
    )
    assert isinstance(
        from_json_schema_type(
            {}, type_string="number"
        ),  # pylint: disable=W0212
        typesystem.fields.Float,
    )

# Generated at 2022-06-24 10:54:42.493846
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": "v1"}, definitions={})
    assert field.validate("v1") == "v1"
    assert field.validate("v2") == FieldValidationError



# Generated at 2022-06-24 10:54:53.126993
# Unit test for function type_from_json_schema
def test_type_from_json_schema():

    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "boolean"}, SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "number"}, SchemaDefinitions()) == Number()
    assert type_from_json_schema(
        {"type": "integer"}, SchemaDefinitions()
    ) == Integer()
    assert type_from_json_schema({"type": "string"}, SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "array"}, SchemaDefinitions()) == Array()
    assert type_from_json_schema({"type": "object"}, SchemaDefinitions()) == Object()

    assert type_from_json_sche

# Generated at 2022-06-24 10:54:59.378905
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        from_json_schema_type(
            data={"type": "number"},
            type_string="number",
            allow_null=False,
            definitions=SchemaDefinitions(),
        )
        == Number()
    )
    assert (
        from_json_schema_type(
            data={"type": "integer"},
            type_string="integer",
            allow_null=False,
            definitions=SchemaDefinitions(),
        )
        == Integer()
    )
    assert (
        from_json_schema_type(
            data={"type": "string"},
            type_string="string",
            allow_null=False,
            definitions=SchemaDefinitions(),
        )
        == String()
    )

# Generated at 2022-06-24 10:55:07.933805
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    schema = IfThenElse(
        if_clause=String(),
        then_clause=String(),
        else_clause=Integer(),
    )
    assert from_json_schema(data) == schema
    assert from_json_schema(data).default == NO_DEFAULT
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer", "default": 0},
    }
    schema = IfThenElse(
        if_clause=String(),
        then_clause=String(),
        else_clause=Integer(default=0),
    )


# Generated at 2022-06-24 10:55:15.237539
# Unit test for function get_valid_types
def test_get_valid_types():
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema",
        "type": "string"
    }
    expect = ({"string"}, False)
    assert expect == get_valid_types(schema)

    schema = {
        "$schema": "http://json-schema.org/draft-04/schema",
        "type": "null"
    }
    expect = (set(), True)
    assert expect == get_valid_types(schema)

    schema = {
        "$schema": "http://json-schema.org/draft-04/schema",
        "type": "object"
    }
    expect = ({"object"}, False)
    assert expect == get_valid_types(schema)


# Generated at 2022-06-24 10:55:19.049009
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema = {
        "anyOf": [
            {"type": "integer"},
            {"type": "string"},
        ],
        "default": "string",
    }
    field = any_of_from_json_schema(json_schema, definitions)
    assert field.validate(2) == 2
    assert field.validate("string") == "string"
    assert field.validate("string") == field.default



# Generated at 2022-06-24 10:55:23.783220
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    pass
    # Code that fails the type checker:
    # IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())


JSONSchema.set_validator(from_json_schema)

# Generated at 2022-06-24 10:55:33.143493
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "properties": {
                "a": {"const": "foo"},
                "b": {"type": "number"},
            },
            "required": ["a", "b"],
        },
        "then": {"properties": {"c": {"type": "number"}}},
        "else": {"properties": {"d": {"type": "number"}}},
    }
    definitions = SchemaDefinitions()
    schema = if_then_else_from_json_schema(data, definitions=definitions)
    assert isinstance(schema, IfThenElse)
    assert isinstance(schema.if_clause, Object)
    assert len(schema.if_clause.properties) == 2
    assert isinstance(schema.if_clause.properties["a"], Const)

# Generated at 2022-06-24 10:55:41.403307
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": ["integer", "null"]}) == ({'integer'}, True)
    assert get_valid_types({}) == (set({'null', 'boolean', 'object', 'array', 'number', 'string'}), False)
    assert get_valid_types({}) == (set({'null', 'boolean', 'object', 'array', 'number', 'string'}), False)
    assert get_valid_types({}) == (set({'null', 'boolean', 'object', 'array', 'number', 'string'}), False)



# Generated at 2022-06-24 10:55:50.977279
# Unit test for function get_standard_properties
def test_get_standard_properties():
    standard_properties = get_standard_properties(Integer(default=3))
    assert standard_properties == {"default": 3}, (
        "Standard properties should be equal to 'default': 3"
    )
    standard_properties = get_standard_properties(Integer(default=3, name="test"))
    assert standard_properties == {"default": 3}, (
        "Standard properties should be equal to 'default': 3"
    )
    standard_properties = get_standard_properties(Integer(name="test"))
    assert standard_properties == {}, "Standard properties should be empty"

# Generated at 2022-06-24 10:55:53.994429
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    with pytest.raises(AssertionError):
        from_json_schema_type(data={}, type_string="invalid", allow_null=False, definitions=SchemaDefinitions())



# Generated at 2022-06-24 10:56:05.697286
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:56:12.461741
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    test_schema = {
        "type": "object",
        "properties": {
            "type": {"type": "string"},
            "value": {
                "if": {"properties": {"type": {"const": "boolean"}}, "required": ["type"]},
                "then": {"type": "boolean"},
                "else": {"type": "number"},
            },
        },
    }
    field = from_json_schema(test_schema)
    assert field.serialize({"type": "boolean", "value": True}) == {
        "type": "boolean",
        "value": True,
    }
    assert field.serialize({"type": "integer", "value": 1}) == {
        "type": "integer",
        "value": 1,
    }
    assert field.serialize

# Generated at 2022-06-24 10:56:18.912878
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft/2019-09/schema",
        "if": {"type": "integer"},
        "then": {"maximum": 100},
    }
    definitions = SchemaDefinitions()
    schema = if_then_else_from_json_schema(data, definitions=definitions)
    validator = get_validator(schema)
    assert validator(None)
    assert validator("foo")
    assert validator("bar")
    assert validator(123)
    assert validator(None)
    assert validator(10)
    assert not validator("123")
    assert not validator("foo")
    assert not validator("bar")



# Generated at 2022-06-24 10:56:25.910649
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field_without_default = Integer(default=NO_DEFAULT)
    field_with_default = Integer(default=42)
    assert (
        get_standard_properties(field_without_default) == {}
    ), "empty definition."
    assert (
        get_standard_properties(field_with_default) == {"default": 42}
    ), "default in definition."

# Generated at 2022-06-24 10:56:34.261267
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "null"}, SchemaDefinitions()) == Const(None)
    assert type_from_json_schema({"type": "integer", "nullable": True}, SchemaDefinitions()) == Integer(allow_null=True)
    assert type(type_from_json_schema({"type": ["null", "integer"]}, SchemaDefinitions())) == Union



# Generated at 2022-06-24 10:56:39.925900
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': 'null'}) == ({}, True)
    assert get_valid_types({'type': ['null', 'integer']}) == ({'integer'}, True)



# Generated at 2022-06-24 10:56:43.712489
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    schema = Object(properties={"foo":Integer()})
    definitions['#/baz'] = schema
    assert ref_from_json_schema({"$ref": "#/baz"}, definitions=definitions) == schema



# Generated at 2022-06-24 10:56:51.154453
# Unit test for function to_json_schema
def test_to_json_schema():
    class Structure(Schema):
        field_a = String(allow_blank=False)
        field_b = String()
        field_c = Integer(min_value=1, max_value=5)

    struct = Structure.make_validator()

    assert to_json_schema(struct) == {
        "type": "object",
        "required": ["field_a"],
        "properties": {
            "field_a": {"type": "string", "minLength": 1},
            "field_b": {"type": "string"},
            "field_c": {"type": "integer", "minimum": 1, "maximum": 5},
        },
    }

# Generated at 2022-06-24 10:56:55.645743
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        'anyOf': [
            {'type': 'string'},
            {'type': 'integer'}
        ]
    }
    field = any_of_from_json_schema(schema, None)
    assert field.any_of[0].check_valid('') == ''
    assert field.any_of[1].check_valid(2) == 2



# Generated at 2022-06-24 10:56:58.443540
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/arrayOfObjects'}
    definitions = SchemaDefinitions()
    definitions[data['$ref']] = Array(items=Object())
    schema = ref_from_json_schema(data, definitions)
    assert isinstance(schema, Reference)



# Generated at 2022-06-24 10:57:09.091566
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "type": [
            "null",
            "string",
            "integer"
        ]
    }
    expected_type_strings = {"null","string", "integer"}
    expected_allow_null = True
    result_type_strings, result_allow_null = get_valid_types(data)
    assert result_type_strings == expected_type_strings
    assert result_allow_null == expected_allow_null

    data = {
        "type": [
            "string",
            "integer"
        ]
    }
    expected_type_strings = {"string", "integer"}
    expected_allow_null = False
    result_type_strings, result_allow_null = get_valid_types(data)
    assert result_type_strings == expected_type_strings
    assert result_allow_

# Generated at 2022-06-24 10:57:18.394722
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'properties': {'payload': {'properties': {'foo': {'nullable': True, 'type': 'string'}}}}}, {'properties': {'payload': {'properties': {'foo': {'nullable': True, 'type': 'integer'}}}}}]}

    definitions = SchemaDefinitions()

    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    
    for item in one_of:
        print(item)

test_one_of_from_json_schema()


# Generated at 2022-06-24 10:57:20.206711
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # TODO: unit test for function not_from_json_schema
    pass


# Generated at 2022-06-24 10:57:27.074487
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "default": [],
        "anyOf": [
            {"type": "array", "items": {"type": "integer"}},
            {"type": "array", "items": {"type": "integer"}},
        ],
    }

    definitions = None
    field = any_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Union)
    assert len(field.any_of) == 2



# Generated at 2022-06-24 10:57:30.098518
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({"$ref": "#/definitions/foo"}, SchemaDefinitions()),
        Reference,
    )



# Generated at 2022-06-24 10:57:39.465622
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.fields import Boolean, Integer, Float, String, Array, Object

    data = {"type": "number"}
    assert isinstance(from_json_schema_type(data, type_string="number", allow_null=False, definitions=None), Float)

    data = {"type": "integer"}
    assert isinstance(from_json_schema_type(data, type_string="integer", allow_null=False, definitions=None), Integer)

    data = {"type": "string"}
    assert isinstance(from_json_schema_type(data, type_string="string", allow_null=False, definitions=None), String)

    data = {"type": "boolean"}

# Generated at 2022-06-24 10:57:42.850539
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Number(allow_null=True)

# Generated at 2022-06-24 10:57:53.271972
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {
        "type": "string",
        "enum": [
            "application/json",
            "application/ld+json",
            "application/vnd.api+json",
            "application/csp-report"
        ]
    }
    field = enum_from_json_schema(json_schema, definitions=SchemaDefinitions())
    assert isinstance(field, Choice)
    assert field.choices == [('application/json', 'application/json'), ('application/ld+json', 'application/ld+json'), ('application/vnd.api+json', 'application/vnd.api+json'), ('application/csp-report', 'application/csp-report')]
    assert field.default == NO_DEFAULT



# Generated at 2022-06-24 10:57:55.546163
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type": "string"}
    (type_strings, allow_null) = get_valid_types(data)
    assert type_strings == {"string"}
    assert allow_null is False


# Generated at 2022-06-24 10:58:04.964330
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": {
            "root": {
                "type": "object",
                "properties": {
                    "key1": {
                        "type": "object",
                        "properties": {
                            "$ref": {"$ref": "#/definitions/root"}
                        }
                    }
                }
            }
        }
    }
    result = from_json_schema(schema)
    assert Reference in type(result).__mro__



# Generated at 2022-06-24 10:58:15.227330
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = from_json_schema({
        "title": "Example Schema",
        "type": "object",
        "properties": {
            "firstName": { "type": "string" },
            "lastName": { "type": "string" },
            "age": { "description": "Age in years", "type": "integer", "minimum": 0 }
        },
        "required": ["firstName", "lastName"]
    })
    assert schema.is_valid({"firstName": "Kyle", "lastName": "Cannon"}) == True
    assert schema.is_valid({"firstName": "Kyle", "lastName": "Cannon", "age": -1}) == False


# Generated at 2022-06-24 10:58:23.370759
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_schema = {"not":{"type": "string"}}
    assert not_from_json_schema(not_schema, definitions = None) == Not(negated = String(allow_null = False, allow_blank = True, min_length = None, max_length = None, format = None, pattern = None, default = NO_DEFAULT))
    schema = {"if":{"type":"string"},"then":{"type":"number"},"else":{"type":"null"}}

# Generated at 2022-06-24 10:58:32.698098
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    class JSONSchemaTypeTest(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            return value

    for type_string in ("boolean", "integer", "number", "object", "string", "array"):
        field = from_json_schema_type(data=dict(type=type_string), type_string=type_string, allow_null=False, definitions=definitions)
        assert isinstance(field, JSONSchemaTypeTest)

    field = from_json_schema_type(data=dict(type="number"), type_string="number", allow_null=False, definitions=definitions)
    assert isinstance(field, Float)


# Generated at 2022-06-24 10:58:36.315344
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "number"}, {"minimum": 0}]}
    assert all_of_from_json_schema(data=data, definitions={}) == AllOf(
        all_of=[Number(), Integer(minimum=0)]
    )


# Generated at 2022-06-24 10:58:40.871948
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}).types == {"string"}
    assert from_json_schema({"type": "string", "enum": ["spam", "eggs"]}).items == {"spam", "eggs"}



# Generated at 2022-06-24 10:58:50.812841
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({'type':True}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({'type':False}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({'type':None}) == ({"null", "boolean", "object", "array", "number", "string"}, False)

    assert get_valid_types({'type':'null'}) == (set(), True)
    assert get_valid_types({'type':'integer'}) == ({'integer'}, False)

# Generated at 2022-06-24 10:59:02.352364
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:59:13.355078
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema",
        "type": "object",
        "properties": {
            "data": {
                "oneOf": [
                    {
                        "properties": {
                            "a": {"type": "number"},
                            "b": {"type": "number"},
                        },
                        "required": ["a", "b"]
                    },
                    {
                        "properties": {
                            "c": {"type": "number"},
                            "d": {"type": "number"},
                        },
                        "required": ["c", "d"]
                    },
                ]
            },
        },
        "required": ["data"],
    }
    field = one_of_from_json_schema(data, definitions=SchemaDefinitions())


# Generated at 2022-06-24 10:59:15.757085
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}, None).to_python(2)

