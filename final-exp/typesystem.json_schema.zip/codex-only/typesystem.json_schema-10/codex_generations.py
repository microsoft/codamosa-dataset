

# Generated at 2022-06-24 10:49:21.042798
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["string"]}) == ({"string"}, False)
    assert get_valid_types({"type": ["number", "string"]}) == (
        {"number", "string"},
        False,
    )
    assert get_valid_types({"type": ["null", "number", "string"]}) == (
        {"number", "string"},
        True,
    )
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)

# Generated at 2022-06-24 10:49:22.631241
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String()
    assert get_standard_properties(field) == {}
    field = String(default="test")
    assert get_standard_properties(field) == {"default": "test"}



# Generated at 2022-06-24 10:49:31.000743
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = dict(type="string")
    field = from_json_schema_type(data=schema, type_string="string", allow_null=False)
    assert isinstance(field, String)
    assert field.allow_null is False
    assert field.allow_blank is True

    field = from_json_schema_type(data=schema, type_string="string", allow_null=True)
    assert field.allow_null is True

    schema = dict(type="number")
    field = from_json_schema_type(data=schema, type_string="number", allow_null=False)
    assert isinstance(field, Float)

    schema = dict(type="integer")
    field = from_json_schema_type(data=schema, type_string="integer", allow_null=False)

# Generated at 2022-06-24 10:49:37.992383
# Unit test for function to_json_schema
def test_to_json_schema():
    from schematics.models import Model
    from schematics.types import StringType, IntType, ListType, ModelType

    class Person(Model):
        name = StringType()
        age = IntType()

    class Family(Model):
        mother = ModelType(Person)
        father = ModelType(Person)
        children = ListType(ModelType(Person))
        name = StringType()

    data = to_json_schema(Family)


# Generated at 2022-06-24 10:49:46.388625
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()
    assert type_from_json_schema({'type': 'null'}, definitions={}) == Const(None)
    assert type_from_json_schema({'type': 'integer'}, definitions={}) == Integer()
    assert type_from_json_schema({'type': ['string', 'null']}, definitions={}) == Union(
        any_of=[String(), Const(None)]
    )
    assert type_from_json_schema({'type': 'array'}, definitions={}) == Array()
    assert type_from_json_schema(
        {'type': 'array', 'items': {'type': 'integer'}}, definitions={}
    ) == Array(items=Integer())

# Generated at 2022-06-24 10:49:55.763469
# Unit test for function from_json_schema
def test_from_json_schema():

    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"type": "boolean"}) == Boolean(default=NO_DEFAULT)
    assert from_json_schema({"type": False}) == Boolean(default=False, default_raw=False)

    assert from_json_schema({"type": "integer"}) == Integer(default=NO_DEFAULT)
    assert from_json_schema({"type": 1}) == Integer(default=1, default_raw=1)
    assert from_json_schema({"type": 1.1}) == Integer(default=NO_DEFAULT)

    assert from_json_schema({"type": "number"}) == Any(default=NO_DEFAULT)

# Generated at 2022-06-24 10:50:07.972486
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.schemas import Any, Object, String

# Generated at 2022-06-24 10:50:21.475261
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {
                "anyOf": [
                    {
                        "type": "integer",
                        "minimum": 0
                    },
                    {
                        "type": "string",
                        "pattern": "^[a-z]*$"
                    }
                ],
            },
            {
                "type": "string",
                "pattern": "^[a-z0-9]*$"
            }
        ],
    }
    field = all_of_from_json_schema(data = schema, definitions = None)
    assert field.validate("123") == "123"
    assert field.validate("abc") == "abc"
    assert field.validate(123) == 123
    assert field.validate(4.4) == None

# Generated at 2022-06-24 10:50:28.270713
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:50:29.201524
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Text()), {"default": ""}



# Generated at 2022-06-24 10:50:35.178015
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def assert_valid(schema: dict, value: typing.Any):
        json_schema = from_json_schema(schema)
        assert_valid_against_json_schema(json_schema, value)

    def assert_invalid(schema: dict, value: typing.Any):
        json_schema = from_json_schema(schema)
        assert_invalid_against_json_schema(json_schema, value)

    schema = {
        "if": {"type": "string"},
        "then": {"maxLength": 3},
        "else": {"type": "number", "minimum": 5},
    }

    assert_valid(schema, "foo")
    assert_invalid(schema, "foobar")
    assert_valid(schema, 5)
    assert_in

# Generated at 2022-06-24 10:50:37.499725
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert from_json_schema({
        'not': {
            'type': 'integer'
        }
    }) == Not(negated=Integer())



# Generated at 2022-06-24 10:50:45.130954
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
    {'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null"}) == (
    {'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({"type": "integer"}) == (
    {"integer", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "null", "type":"integer"}) == (
    {"integer", "boolean", "object", "array", "number", "string"}, True)



# Generated at 2022-06-24 10:50:57.230641
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "null"}, definitions=definitions) == Const(None)
    assert type(type_from_json_schema({"type": "boolean"}, definitions=definitions)) == Boolean
    assert type(type_from_json_schema({"type": "object"}, definitions=definitions)) == Object
    assert type(type_from_json_schema({"type": "string"}, definitions=definitions)) == String
    assert type(type_from_json_schema({"type": "number"}, definitions=definitions)) == Number
    assert type(type_from_json_schema({"type": "integer"}, definitions=definitions)) == Integer
    assert type(type_from_json_schema({"type": "array"}, definitions=definitions)) == Array

# Generated at 2022-06-24 10:51:07.629215
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.json_schema import from_type_schema
    from typesystem.schemas import validate

    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["string", "null"]}) == String(nullable=True)
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-24 10:51:11.053053
# Unit test for function get_standard_properties
def test_get_standard_properties():
    arg = String(description = "aa", max_length=10, min_length=4, pattern_regex=None, format="", default="abc")
    #arg = String()
    #arg.description="aa"
    #arg.max_length=10
    #arg.min_length=4
    #arg.pattern_regex=None
    #arg.format=""
    #arg.default="abc"
    a = get_standard_properties(arg)
    b = {"default": "abc"}
    assert a == b
test_get_standard_properties()

# Generated at 2022-06-24 10:51:18.384911
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [{"type": "object", "properties": {"name": {"type": "string"}}},{"type": "object", "properties": {"age": {"type": "integer"}}}]
    }
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    return OneOf(**kwargs)


# Generated at 2022-06-24 10:51:22.108163
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = {"const": 1}
    const_from_json_schema(schema, definitions=SchemaDefinitions())

    schema = {"const": "1"}
    const_from_json_schema(schema, definitions=SchemaDefinitions())



# Generated at 2022-06-24 10:51:26.851166
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    my_definitions = SchemaDefinitions()
    my_data = {"allOf": [{}, {}]}
    my_field = all_of_from_json_schema(my_data, definitions = my_definitions)


# Generated at 2022-06-24 10:51:33.443581
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': ['foo', 'bar'], 'type': 'string'})._field_info['choices'] == [('foo', 'foo'), ('bar', 'bar')]
    assert enum_from_json_schema({'enum': [1, 2, 3], 'type': 'number'})._field_info['choices'] == [(1.0, 1.0), (2.0, 2.0), (3.0, 3.0)]



# Generated at 2022-06-24 10:51:36.515368
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from super_state_machine.fields import String

    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String("foo")) == {"default": "foo"}

# Generated at 2022-06-24 10:51:42.832527
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/boolean_schema"] = Boolean()
    data = {
        "$ref": "#/definitions/boolean_schema"
    }
    field = ref_from_json_schema(data,definitions)
    assert field.validate(True) == True
    assert field.serialize(True) == True
    assert field.validate(False) == True
    assert field.serialize(False) == False
    assert field.validate(None) == False
    assert field.serialize(None) == None



# Generated at 2022-06-24 10:51:50.956151
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    """
    Test that a JSON schema 'anyOf' is turned into a Union()
    """

    assert any_of_from_json_schema({'anyOf': [{'type': 'number'}, {'type': 'string'}], 'default': 'hello'}, definitions) == Union(any_of=[Float(allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default='hello'), String(allow_null=False, allow_blank=False, min_length=None, max_length=None, format=None, pattern=None, default='hello')], allow_null=False, default='hello')


# Generated at 2022-06-24 10:51:58.200852
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json = {
        "oneOf": [
            {
                "properties": {
                    "age": {"type": "integer"},
                    "name": {"type": "string"},
                    "sex": {"type": "string"},
                    "enrolled": {"type": "boolean"},
                }
            },
            {"type": "string", "maxLength": 14},
        ],
        "default": None,
    }
    t = one_of_from_json_schema(json,None)
    assert isinstance(t, OneOf)
    
test_one_of_from_json_schema()



# Generated at 2022-06-24 10:52:03.313990
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': ['hello', 'world'], 'type': 'string'}).to_builtin() == {'enum': ['hello', 'world'], 'type': 'string'}
    assert enum_from_json_schema({'enum': [1, 2, 3], 'type': 'integer'}).to_builtin() == {'enum': [1, 2, 3], 'type': 'integer'}


# Generated at 2022-06-24 10:52:10.385167
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "fruit": {
                "enum": ["apple", "banana", "orange"],
                "default": "banana"
            }
        }
    }
    schema = from_json_schema(data)
    example_data = schema.to_primitive({})
    assert example_data == {"fruit": "banana"}
    fruit_field: Choice = schema.fields["fruit"]
    assert fruit_field.choices == [("apple", "apple"), ("banana", "banana"), ("orange", "orange")]
    assert fruit_field.default == "banana"



# Generated at 2022-06-24 10:52:18.335380
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(False) == NeverMatch()

    # String
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"minLength": 0}) == String(min_length=0)
    assert from_json_schema({"maxLength": 0}) == String(max_length=0)
    assert from_json_schema({"format": "email"}) == String(format="email")
    assert from_json_schema(
        {"type": "string", "minLength": 5, "maxLength": 10}
    ) == String(min_length=5, max_length=10)

    # Integer
    assert from_json_schema({"type": "integer"}) == Integer()

# Generated at 2022-06-24 10:52:26.532466
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="number", allow_null=False), Number)
    assert isinstance(from_json_schema_type({}, type_string="integer", allow_null=False), Integer)
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)
    assert isinstance(from_json_schema_type({}, type_string="boolean", allow_null=False), Boolean)
    assert isinstance(from_json_schema_type({}, type_string="array", allow_null=False), Array)
    assert isinstance(from_json_schema_type({}, type_string="object", allow_null=False), Object)


# Generated at 2022-06-24 10:52:31.449983
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    choice = enum_from_json_schema(data={
        "enum": [
            "a",
            "b",
            "c",
        ]
    })
    assert choice("a") == "a"
    assert choice("b") == "b"
    assert choice("c") == "c"
    with pytest.raises(ValueError):
        choice("d")



# Generated at 2022-06-24 10:52:41.330185
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field = Union(any_of=[String(), Boolean()])
    assert field.validate("hello") == "hello"
    assert field.validate(False) == False
    assert field.validate(None) is None
    assert field.validate(3) == 3

    field = Schema(
        defintions=definitions,
        properties={
            "is_private": Union(any_of=[Boolean(), String()])
        }
    )
    assert field.validate({"is_private": "hello"}) == {"is_private": "hello"}
    assert field.validate({"is_private": True}) == {"is_private": True}



# Generated at 2022-06-24 10:52:49.882251
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$ref": '#/definitions/NamedType',
        "type": "object",
        "properties": {
            "type": {
                "const": "record"
            },
            "name": {
                "type": "string",
                "minLength": 1
            },
            "fields": {
                "type": "array",
                "items": {
                    "$ref": '#/definitions/Field'
                }
            }
        },
        "required": [
            "type",
            "name",
            "fields"
        ],
        "default": {}
    }
    definitions = SchemaDefinitions()
    typeschema = enum_from_json_schema(data, definitions)

# Generated at 2022-06-24 10:53:00.227593
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    f = const_from_json_schema(
        {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "topColor": {
                    "$ref": "#/definitions/color"
                }
            },
            "$id": "http://example.com/example.json",
            "definitions": {
                "color": {
                    "$id": "#/definitions/color",
                    "const": "#ff0000",
                    "type": "string",
                    "pattern": "^#([A-Fa-f0-9]{6})$"
                }
            }
        }
    )
    # print(f.validate("#ff0011"))

# Generated at 2022-06-24 10:53:06.139335
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "integer"}, {"minimum": 1}]}
    field = all_of_from_json_schema(data, definitions=definitions)
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(-1) == -1
    assert field.validate(-2) == -2
    assert field.validate(0) == 0
    assert not field.validate(0.5)


# Generated at 2022-06-24 10:53:14.608269
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"if": "Foo", "then": {"type": "integer"}}

    if_then_else_from_json_schema(data, SchemaDefinitions())
    data["else"] = {"type": "integer"}
    if_then_else_from_json_schema(data, SchemaDefinitions())
    data["default"] = 123
    if_then_else_from_json_schema(data, SchemaDefinitions())
    #
    # Type checker needs some help with the 'then_clause-or-else_clause'
    # requirement
    data["then"] = None
    if_then_else_from_json_schema(data, SchemaDefinitions())
    data["else"] = None
    if_then_else_from_json_schema(data, SchemaDefinitions())


# Generated at 2022-06-24 10:53:21.577319
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "integer"}}, definitions=None).validate(1) is False
    assert not_from_json_schema({"not": {"type": "integer"}}, definitions=None).validate("1") is True
    assert not_from_json_schema({"not": {"type": "integer"}}, definitions=None).validate(None) is True
    assert not_from_json_schema({"not": {"type": "integer"}}, definitions=None).validate([]) is True



# Generated at 2022-06-24 10:53:28.072087
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": ["integer", "string"]}) == ({'integer', 'string'}, False)
    assert get_valid_types({"type": "null"}) == ({'null'}, True)
    assert get_valid_types({"type": ["null", "string"]}) == ({'string'}, True)
    assert get_valid_types({"type": ["null", "object", "integer"]}) == ({'object', 'integer'}, True)
    assert get_valid_types({}) == ({"boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types

# Generated at 2022-06-24 10:53:31.593786
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class TestField(Field):
        def has_default(self):
            return True
        def default_validator(self):
            return None
    field = TestField(default=None)
    assert get_standard_properties(field) == {"default": None}



# Generated at 2022-06-24 10:53:33.914649
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    pass



# Generated at 2022-06-24 10:53:42.713589
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = {
        "#/definitions/foo": String()
    }
    actual = ref_from_json_schema(data={"$ref": "#/definitions/foo"}, definitions=definitions)
    assert actual.to == "#/definitions/foo"



# Generated at 2022-06-24 10:53:45.298292
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    input = {"enum": [1, 2, 3]}
    output = enum_from_json_schema(input, SchemaDefinitions())
    assert set(output.choices) == set(input["enum"])

# Generated at 2022-06-24 10:53:50.956128
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'number'}, {'type': 'integer'}]}).to_json_schema() == {
        'anyOf': [
            {'type': 'number'},
            {'type': 'integer'}
        ]
    }
    assert any_of_from_json_schema({'anyOf': [{'type': 'number'}, {'type': 'integer'}]}).validate(1) == 1
    assert any_of_from_json_schema({'anyOf': [{'type': 'number'}, {'type': 'integer'}]}).validate(1.2) == 1.2


# Generated at 2022-06-24 10:53:55.970052
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/name"}
    definitions = SchemaDefinitions(
        {"#/definitions/name": Reference("#/definitions/name", definitions)}
    )
    assert ref_from_json_schema(data, definitions) == definitions["#/definitions/name"]



# Generated at 2022-06-24 10:54:00.216622
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Float(allow_null=True, default=0.0)
    data = get_standard_properties(field)
    assert data == {"default": 0.0}
    field = String(min_length=1, default="")
    data = get_standard_properties(field)
    assert data == {"default": ""}

# Generated at 2022-06-24 10:54:08.442386
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert issubclass(if_then_else_from_json_schema({
        "if": {
            "type": "string"
        }, 
        "then": {
            "type": "boolean"
        }
    }, None).__class__, IfThenElse)
    assert issubclass(if_then_else_from_json_schema({
        "if": {
            "type": "string"
        }, 
        "then": {
            "type": "boolean"
        },
        "else": {
            "type": "integer"
        }
    }, None).__class__, IfThenElse)


# Unit tests for function not_from_json_schema

# Generated at 2022-06-24 10:54:13.822093
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field = one_of_from_json_schema({'oneOf': [{'type': 'string'}, {'type': 'number'}], 'default': 'hello'},SchemaDefinitions())
    assert field._one_of[0]() == False
    assert field._one_of[1]() == False
    assert field.default == 'hello'


# Generated at 2022-06-24 10:54:23.386331
# Unit test for function get_valid_types
def test_get_valid_types():
    test_cases = [
        ({}, ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)),
        ({'type': 'number'}, ({'number'}, False)),
        ({'type': ['integer']}, ({'integer'}, False)),
        ({'type': ['number', 'null']}, ({'number'}, True)),
        ({'type': 'number', 'nullable': True}, ({'number'}, True)),
    ]

    for data, expected in test_cases:
        test_result = get_valid_types(data)
        assert test_result == expected, test_result

# Generated at 2022-06-24 10:54:34.187028
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    s = {"type": "string"}
    f = from_json_schema(s)
    assert f == String()
    assert f.validate("") is None

    s = {"type": ["string", "number"]}
    f = from_json_schema(s)
    assert f == Union(any_of=[String(), Number()])
    assert f.validate("") is None
    assert f.validate(1) is None

    s = {"type": ["null", "string"]}
    f = from_json_schema(s)
    assert f == Union(any_of=[String(), Const(None)], allow_null=True)
    assert f.validate(None) is None
    assert f.validate("") is None

    s = {"type": "null"}
    f = from_json_sche

# Generated at 2022-06-24 10:54:40.725003
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = make_field(default="default")
    data = get_standard_properties(field)
    expected = {"default": "default"}
    assert data == expected

    field = make_field(default=NO_DEFAULT)
    data = get_standard_properties(field)
    expected = {}
    assert data == expected
# End unit test for function get_standard_properties



# Generated at 2022-06-24 10:54:42.477275
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(default="foo")
    data = get_standard_properties(field)
    assert {"default": "foo"} == data



# Generated at 2022-06-24 10:54:53.164130
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Boolean()) == {}
    assert get_standard_properties(Boolean(default=True)) == {"default": True}
    assert get_standard_properties(Boolean(default=False)) == {"default": False}

    assert get_standard_properties(Integer()) == {}
    assert get_standard_properties(Integer(default=2)) == {"default": 2}

    assert get_standard_properties(Float()) == {}
    assert get_standard_properties(Float(default=2.5)) == {"default": 2.5}

    assert get_standard_properties(Decimal(2, 2)) == {}
    assert (
        get_standard_properties(Decimal(2, 2, default=Decimal("2.5"))) == {"default": "2.5"}
    )

    assert get_standard_properties(String())

# Generated at 2022-06-24 10:54:56.493183
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert type(all_of_from_json_schema(
        data={'allOf': [{'$ref': '#/definitions/name'}, {'$ref': '#/definitions/pet'}]},
        definitions=definitions
    )) == AllOf



# Generated at 2022-06-24 10:55:05.430552
# Unit test for function from_json_schema

# Generated at 2022-06-24 10:55:10.251690
# Unit test for function not_from_json_schema

# Generated at 2022-06-24 10:55:18.072870
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Boolean
    assert Schema(type="boolean").to_json_schema() == {"type": "boolean"}
    assert Schema(type="boolean", allow_null=True).to_json_schema() == {
        "type": ["boolean", "null"],
    }
    assert Schema(type="boolean", default=False).to_json_schema() == {
        "type": "boolean",
        "default": False,
    }

    # Number
    assert Schema(type="number").to_json_schema() == {"type": "number"}
    assert Schema(type="number", allow_null=True).to_json_schema() == {
        "type": ["number", "null"],
    }
    assert Schema(type="number", default=1.1).to_json

# Generated at 2022-06-24 10:55:29.468418
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "null"}
    allow_null = True
    type_string = "null"
    definitions = SchemaDefinitions()
    field = from_json_schema_type(data, type_string, allow_null, definitions)
    assert field.allow_null == True

    data = {"type": "boolean"}
    allow_null = True
    type_string = "boolean"
    definitions = SchemaDefinitions()
    field = from_json_schema_type(data, type_string, allow_null, definitions)
    assert field.allow_null == True

    data = {"type": "number"}
    allow_null = True
    type_string = "number"
    definitions = SchemaDefinitions()

# Generated at 2022-06-24 10:55:37.111270
# Unit test for function to_json_schema
def test_to_json_schema():
    import jsonschema
    from rjs.validators import BaseField, String, Integer, Float, Array, Object

    class Definition(SchemaDefinitions):
        string_before_number: String
        number_before_string: Integer
        nullable_number_before_string: Float(allow_null=True)
        nested_field: Array[Object[{"s": String, "n": Integer}]]

    schema = Definition.from_schema()
    data = to_json_schema(schema)

# Generated at 2022-06-24 10:55:44.390480
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"enum": [1, 2, 3]},
        "default": None,
    }
    top_kwargs = {
        "negated": Choice(choices=[(1, 1), (2, 2), (3, 3)], default=None),
        "default": None,
    }
    assert not_from_json_schema(data) == Not(**top_kwargs)



# Generated at 2022-06-24 10:55:51.717610
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    class Color(Schema):
        properties = {"name": String(), "hex": String(format="hex-color")}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Color"] = Color

# Generated at 2022-06-24 10:55:55.121642
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(
        ref_from_json_schema({'$ref': '#/definitions/tag'}), typesystem.Reference
    )

# Generated at 2022-06-24 10:56:05.987119
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    i = Boolean()
    t = Integer()
    e = String()
    ite = if_then_else_from_json_schema(
        {"if": {"type": "boolean"}, "then": {"type": "integer"}, "else": {"type": "string"}},
        definitions={},
    )
    assert ite == IfThenElse(i, t, e)
    obj = {"a": 12}

    assert obj in ite.if_clause  # type: ignore
    assert obj not in t  # type: ignore
    assert obj not in e  # type: ignore
    assert obj in ite  # type: ignore
    assert obj not in IfThenElse(
        Boolean(const=False), Integer(), String()
    )  # type: ignore



# Generated at 2022-06-24 10:56:13.318395
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # type: () -> None
    from_json_schema({"type": "array"})
    from_json_schema({"type": "boolean"})
    from_json_schema({"type": "integer"})



# Generated at 2022-06-24 10:56:19.487691
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test the function 'from_json_schema_type()'.
    """
    # Any
    data = {"type": "any"}
    assert from_json_schema_type({}, type_string=data["type"], allow_null=False) == Any()

    # Number
    data = {
        "type": "number",
        "multipleOf": 10,
        "minimum": 100,
        "maximum": 200,
        "exclusiveMinimum": 110,
        "exclusiveMaximum": 190,
    }
    field = from_json_schema_type({}, type_string=data["type"], allow_null=False)
    for key, value in data.items():
        assert getattr(field, key) == value

    # String

# Generated at 2022-06-24 10:56:30.295412
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Integer()
    expected = {
        "type": ["integer", "null"],
        "default": null,
    }
    assert to_json_schema(schema) == expected
    expected = {"type": "integer"}
    assert to_json_schema(schema, {'x': schema}) == expected
    assert to_json_schema(schema, {'x': schema}) == expected
    schema = Integer(min_value=0, max_value=100)
    expected = {
    "type": ["integer", "null"],
    "minimum": 0,
    "maximum": 100
    }
    assert to_json_schema(schema) == expected
    expected = {
        "type": "integer",
        "minimum": 0,
        "maximum": 100
    }
    assert to_json_

# Generated at 2022-06-24 10:56:35.334359
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/Reference"] = String()
    data = {"$ref": "#/definitions/Reference"}
    field = from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference), repr(field)
    assert field.to == "#/definitions/Reference"



# Generated at 2022-06-24 10:56:38.766344
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "$ref": "#/components/schemas/Person",
    }
    result = ref_from_json_schema(json_schema, definitions=definitions)
    assert result == Reference("#/components/schemas/Person", definitions=definitions)



# Generated at 2022-06-24 10:56:42.135061
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from_json_schema({'allOf':[{'multipleOf': 5}, {'maximum': 20}]})


# Generated at 2022-06-24 10:56:52.880586
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type: () -> None
    assert isinstance(
        from_json_schema_type(
            {"type": "number"}, type_string="number", allow_null=True, definitions=None
        ),
        Number,
    )

    assert isinstance(
        from_json_schema_type(
            {"type": "integer"}, type_string="integer", allow_null=True, definitions=None
        ),
        Integer,
    )

    assert isinstance(
        from_json_schema_type(
            {"type": "string"}, type_string="string", allow_null=True, definitions=None
        ),
        String,
    )


# Generated at 2022-06-24 10:56:59.841475
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["null", "string"]}) == String() | Const(None)
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()

# Generated at 2022-06-24 10:57:01.438949
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    with pytest.raises(TypeError):
        not_from_json_schema(None, None)


# Generated at 2022-06-24 10:57:09.986181
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = const_from_json_schema({'const': 1})

    # Test the const field is ok
    assert schema.validate(1) == 1

    # Test the const field is not ok
    try:
        schema.validate(2)
    except Exception as e:
        assert isinstance(e, Exception)

    # Test the const field is not ok
    try:
        schema.validate(1, allow_const=False)
    except Exception as e:
        assert isinstance(e, Exception)



# Generated at 2022-06-24 10:57:16.417391
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"type": "object", "properties": {"test": False}}
    f = not_from_json_schema(schema, definitions=None)
    assert isinstance(f, Not)
    assert isinstance(f.negated, Object)
    assert f.negated.properties["test"].field_type == "anything"
    assert isinstance(f.negated.properties["test"], NeverMatch)



# Generated at 2022-06-24 10:57:21.399149
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Test the conversion to a reference from a JSON Schema document.
    """
    definition = {"type": "object", "properties": {"foo": {"type": "string"}}}
    schema_data = {"$ref": "#/definitions/foo", "definitions": {"foo": definition}}
    field = from_json_schema(schema_data)
    assert field.to_primitive() == {"type": "string"}



# Generated at 2022-06-24 10:57:28.513188
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {'if': {
        'type':'string',
        'const': 'cat'
        },
        'default': 'dog'
    }
    definitions = SchemaDefinitions()
    def1 = if_then_else_from_json_schema(data, definitions)
    assert def1.if_clause.const == data['if']['const']
    assert def1.default== data['default']


# Generated at 2022-06-24 10:57:33.273937
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "https://example.com/person.schema.json",
        "type": ("string", "integer"),
    }
    assert get_valid_types(data) == ({'string', 'integer'}, False)



# Generated at 2022-06-24 10:57:39.089288
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="abc")) == {"default": "abc"}
    assert get_standard_properties(String(default=None)) == {"default": None}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}

    assert get_standard_properties(Integer(default=123)) == {"default": 123}
    assert get_standard_properties(Float(default=123.4)) == {"default": 123.4}

    assert get_standard_properties(Boolean(default=True)) == {"default": True}
    assert get_standard_properties(Boolean(default=False)) == {"default": False}

    assert get_standard_properties(Array(default=["a", "b", "c"])) == {
        "default": ["a", "b", "c"]
    }
    assert get_

# Generated at 2022-06-24 10:57:51.017742
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {
            "null",
            "boolean",
            "object",
            "array",
            "number",
            "string",
        },
        False,
    )
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'boolean'}) == ({'boolean',}, False)
    assert get_valid_types({'type': 'integer'}) == ({'integer',}, False)
    assert get_valid_types({'type': 'number'}) == ({'number',}, False)
    assert get_valid_types({'type': 'string'}) == ({'string',}, False)
    assert get_valid_types({'type': 'array'}) == ({'array',}, False)

# Generated at 2022-06-24 10:57:53.659305
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const":"1"}
    expected = Const(const = "1")
    assert const_from_json_schema(data,None) == expected



# Generated at 2022-06-24 10:57:56.792353
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({
        "boolean",
        "object",
        "array",
        "number",
        "string"
    }, False)
    assert get_valid_types({
        "type": "string"
    }) == ({'string'}, False)
    assert get_valid_types({
        "type": [
            "string",
            "integer"
        ]
    }) == ({
        'string',
        'integer'
    }, False)



# Generated at 2022-06-24 10:57:59.019200
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "$ref": "#/definitions/foo"
    }
    with pytest.raises(AssertionError):
        ref_from_json_schema(data=json_schema, definitions={})



# Generated at 2022-06-24 10:58:02.926332
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    f = const_from_json_schema({"const": True}, SchemaDefinitions())
    assert f.validate(True) == True


# Generated at 2022-06-24 10:58:12.716137
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean"]}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean", "null"]}) == ({"boolean"}, True)
    assert get_valid_types({"type": ["boolean", "null", "integer"]}) == (
        {"boolean", "integer"},
        True,
    )
    assert get_valid_types({"type": ["boolean", "null", "integer", "number"]}) == (
        {"boolean", "integer", "number"},
        True,
    )

# Generated at 2022-06-24 10:58:22.991035
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "bar": {
                "type": "string",
                "enum": ["a", "b"],
                "const": "b",
                "minLength": 5,
            }
        },
        "required": ["bar"],
    }
    actual = from_json_schema(data)
    expected = Object(
        properties={"bar": String(enum=["a", "b"], const="b", min_length=5)}, required=["bar"]
    )
    assert actual == expected

    data = {"type": "boolean", "const": True}
    actual = from_json_schema(data)
    expected = Const(True, type=bool)
    assert actual == expected

    # Test 'optionals_from_json_schema'

# Generated at 2022-06-24 10:58:25.183569
# Unit test for function get_standard_properties
def test_get_standard_properties():
    target = Value("random string", "random string", default="random string")
    result = get_standard_properties(target)
    assert result == {"default": "random string"}



# Generated at 2022-06-24 10:58:33.209444
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.fields import String, Integer, Boolean
    from jsonschema import validate
    import pytest
    # String
    field = String()
    assert type_from_json_schema({'type':'string'}) == field
    assert validate(instance="string", schema={'type':'string'})
    assert validate(instance=None, schema={'type':'string'})
    assert validate(instance="string", schema={'type':['string','null']})
    assert validate(instance=None, schema={'type':['string','null']})
    assert not validate(instance=1, schema={'type':'string'})
    assert not validate(instance=1, schema={'type':['string','null']})
    # Integer
    field = Integer()

# Generated at 2022-06-24 10:58:37.366232
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_schema = {
        "not": {
            "type": "boolean"
        }
    }
    result = not_from_json_schema(test_schema, "")
    assert isinstance(result, Not)
    assert result.default == NO_DEFAULT
    assert isinstance(result.negated, Boolean)


# Generated at 2022-06-24 10:58:48.977219
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    min_number = Integer(minimum=12)
    max_number = Integer(maximum=128)

    all_of = {
        "allOf": [{"type": "integer", "minimum": 12}, {"type": "integer", "maximum": 128}],
        "default": "test_default"
    }

    assert all_of_from_json_schema(all_of, definitions=None).encode(None) == "test_default"
    assert all_of_from_json_schema(all_of, definitions=None).encode(12) == 12
    assert all_of_from_json_schema(all_of, definitions=None).encode(128) == 128


# Generated at 2022-06-24 10:58:57.124090
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(TestSchema)

# Generated at 2022-06-24 10:58:59.192093
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": ["foo", "bar"], "default": "bar"}
    enum_field = enum_from_json_schema(data, definitions)
    assert enum_field == Choice(choices=[("foo", "foo"), ("bar", "bar")])



# Generated at 2022-06-24 10:59:02.450417
# Unit test for function get_standard_properties
def test_get_standard_properties():
    with pytest.raises(ValueError):
        get_standard_properties(Any())
    assert get_standard_properties(String(default="")) == {"default": ""}
    assert get_standard_properties(Integer(default=42)) == {"default": 42}

# Generated at 2022-06-24 10:59:10.075150
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = { "$ref" : "any" }
    data1 = {
        "items": {
            "$ref": "any"
        },
        "additionalItems": False
    }
    data2 = {
        "items": {
            "$ref": "any"
        },
        "additionalItems": False
    }
    data3 = {
        "items": {
            "$ref": "any"
        },
        "additionalItems": False
    }
    data4 = {
        "items": {
            "$ref": "any"
        },
        "additionalItems": False
    }
    data5 = {
        "items": {
            "$ref": "any"
        },
        "additionalItems": False
    }

# Generated at 2022-06-24 10:59:11.517669
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()

