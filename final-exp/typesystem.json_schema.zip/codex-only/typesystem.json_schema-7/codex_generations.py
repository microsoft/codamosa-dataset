

# Generated at 2022-06-24 10:49:19.373348
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        str(from_json_schema_type({"type": "number"}, type_string="number"))
        == "Float(allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=<NO_DEFAULT>)"
    )
    assert (
        str(from_json_schema_type({"type": "integer"}, type_string="integer"))
        == "Integer(allow_null=False, minimum=None, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=<NO_DEFAULT>)"
    )

# Generated at 2022-06-24 10:49:26.485785
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = dict({"oneOf": [{"type": "string"}]})
    definitions = SchemaDefinitions()
    expected = OneOf(one_of=[String()], default=NO_DEFAULT)
    result = one_of_from_json_schema(data, definitions)
    assert result == expected, "Should be equal"
# End of unit test for function one_of_from_json_schema



# Generated at 2022-06-24 10:49:35.865554
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": ["string", "integer"]}) == (
        {"integer", "string"},
        False,
    )

# Generated at 2022-06-24 10:49:42.982634
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    test_value = {"allOf": [{"const": 1},{"const": 2}]}
    assert all_of_from_json_schema(test_value, definitions=None) == AllOf([Const(1), Const(2)])
    test_value = {"allOf": [{"const": 1},{"const": 2}], "default": 2}
    assert all_of_from_json_schema(test_value, definitions=None) == AllOf([Const(1), Const(2)], default=2)


# Generated at 2022-06-24 10:49:44.872437
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(
        {"not": {"type": "number"}}, definitions=SchemaDefinitions(
        )
    ) == Not(
        negated=Float(allow_null=False)
    )

# Generated at 2022-06-24 10:49:52.810473
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type(
            data={"type": "number"}, type_string="number", allow_null=False, definitions=SchemaDefinitions()
        ),
        Number,
    )

    assert isinstance(
        from_json_schema_type(
            data={"type": "boolean"}, type_string="boolean", allow_null=False, definitions=SchemaDefinitions()
        ),
        Boolean,
    )

    assert isinstance(
        from_json_schema_type(
            data={"type": "integer"}, type_string="integer", allow_null=False, definitions=SchemaDefinitions()
        ),
        Integer,
    )


# Generated at 2022-06-24 10:49:56.132823
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_field = const_from_json_schema({"const": "myconst"}, SchemaDefinitions())
    # print(const_field)
    assert const_field.validate("myconst")
    assert const_field.validate(1) is False
    assert const_field.validate(False) is False


# Generated at 2022-06-24 10:50:08.310843
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.composites import NeverMatch
    from typesystem.fields import Any as Any1

    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True) == Any1()
    assert from_json_schema_type({"type": "number"}, type_string="boolean", allow_null=True) == NeverMatch()

    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=False) == Any1()
    assert from_json_schema_type({"type": "number"}, type_string="boolean", allow_null=False) == NeverMatch()

    assert from_json_schema_type({"type": "number"}, type_string="number", allow_null=True) == Any1()

# Generated at 2022-06-24 10:50:11.334545
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="bar")) == {"default": "bar"}



# Generated at 2022-06-24 10:50:22.483451
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": ""}) == ({}, True)
    assert get_valid_types({"type": None}) == ({}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": ["null"]}) == ({}, True)
    assert get_valid_types({"type": ["array"]}) == ({"array"}, False)
    assert get_valid_types({"type": ["array", "null"]}) == ({"array"}, True)
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, True)



# Generated at 2022-06-24 10:50:33.504953
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "null", "required": True}) == ({}, True)
    assert get_valid_types({"type": None}) == ({}, False)
    assert get_valid_types({}) == ({}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["integer"]}) == ({"integer"}, False)
    assert get_valid_types({"type": ["integer", "boolean"]}) == (
        {"integer", "boolean"},
        False,
    )

# Generated at 2022-06-24 10:50:42.471707
# Unit test for function get_valid_types
def test_get_valid_types():
    #Test for single type
    data = {"type": "string"}
    type_string, allow_null = get_valid_types(data)
    assert type_string == {"string"}
    assert allow_null == False

    data = {"type": "null"}
    type_string, allow_null = get_valid_types(data)
    assert type_string == set()
    assert allow_null == True

    #Test for multiples types
    data = {"type": ["string", "null"]}
    type_string, allow_null = get_valid_types(data)
    assert type_string == {"string"}
    assert allow_null == True

    #Test for all types
    data = {"type": [1, 2, 3]}
    type_string, allow_null = get_valid_types(data)
    assert type_

# Generated at 2022-06-24 10:50:44.649152
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(  # type: ignore
        String(min_length=1, default="abc")
    ) == {"default": "abc"}



# Generated at 2022-06-24 10:50:56.772280
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    # string
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "enum": ["a", "b"]}) == Choice(items=["a", "b"])
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "string", "pattern": "a"}) == String(
        pattern=re.compile("a")
    )
    assert from_json_schema({"type": "string", "minLength": 1}) == String(min_length=1)


# Generated at 2022-06-24 10:50:59.586048
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    x = not_from_json_schema(data = {'not':{'type': 'boolean'}})
    assert not isinstance(x, Boolean)

# Generated at 2022-06-24 10:51:12.347906
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-24 10:51:20.737967
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from_json_schema({"not": {"type": "null"}})
    from_json_schema({"not": {"type": "integer"}})
    from_json_schema({"not": {"type": "array"}})
    from_json_schema({"not": {"type": "object"}})
    from_json_schema({"not": {"type": "string"}})
    from_json_schema({"not": {"type": "number"}})
    from_json_schema({"not": {"type": "boolean"}})



# Generated at 2022-06-24 10:51:23.192121
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="Hello, World!")) == {
        "default": "Hello, World!"
    }



# Generated at 2022-06-24 10:51:28.915127
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "format": "email"}) == String(
        format="email"
    )
    assert from_json_schema({"type": "string", "pattern": "^a*$"}) == String(
        format=re.compile("^a*$")
    )
    assert from_json_schema({"type": "string", "enum": ["foo"]}) == Choice(
        choices=["foo"]
    )



# Generated at 2022-06-24 10:51:38.507190
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    test_data = [
        ([True], Boolean()),
        (["boolean", "integer"], Boolean() | Integer()),
        (["boolean", "null"], Boolean(allow_null=True) | Const(None)),
        (["string"], String(allow_blank=True)),
        (["string"], String(allow_blank=True)),
        ([{"anyOf": [{"type": "integer"}, {"type": "string"}]}], Any()),
    ]
    for type_strings, expected_value in test_data:
        for type_string in type_strings:
            for allow_null in [True, False]:
                data = {"type": type_string}
                result = from_json_schema_type(
                    data, type_string=type_string, allow_null=allow_null, definitions={}
                )
               

# Generated at 2022-06-24 10:51:41.277189
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(minimum=1)



# Generated at 2022-06-24 10:51:43.749466
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()


# Generated at 2022-06-24 10:51:48.442995
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field = enum_from_json_schema({
        'enum':['true', 'false'],
        'default':'true',
    }, definitions)
    assert field.validate('') == None
    assert field.validate('true') == 'true'
    assert field.validate('false') == 'false'


# Generated at 2022-06-24 10:51:55.595789
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from tests.utils import test_against_example_strings

    def _test_all_of_from_json_schema(json_string):
        data = json.loads(json_string)
        schema = from_json_schema(data)
        assert isinstance(schema, AllOf), f"{schema!r}"

    test_against_example_strings(
        directory_path="examples/json-schema.org/allOf",
        test_function=_test_all_of_from_json_schema,
    )



# Generated at 2022-06-24 10:52:04.130182
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {
                'type': 'object',
                'properties': {
                    'a': {
                        'type': 'integer',
                        'minimum': 1,
                        'maximum': 4
                    }
                },
                'required': ['a']
            },
            {
                'type': 'object',
                'properties': {
                    'b': {
                        'type': 'string'
                    }
                },
                'required': ['b']
            }
        ]
    }
    schema_typesystem = one_of_from_json_schema(schema, None)
    assert schema_typesystem.validate({"a": 1}) == {"a": 1}
    assert schema_typesystem.validate({"b": "a"}) == {"b": "a"}

# Generated at 2022-06-24 10:52:05.355706
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b"]}) == {"a": "a", "b": "b"}



# Generated at 2022-06-24 10:52:08.637971
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_data = {"oneOf": [{"type": "string"}, {"type": "integer"}, {"type": "number"}]}
    result = one_of_from_json_schema(test_data, definitions=None)
    assert result.errors == "one of these options"


# Generated at 2022-06-24 10:52:20.513427
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    number = {"type": "number"}
    string = {"type": "string"}
    object = {"type": "object"}
    array = {"type": "array"}
    boolean = {"type": "boolean"}
    integer = {"type": "integer"}
    union = {"type": ["number", "string"]}
    union_null = {"type": ["number", "string", "null"]}
    union_null_and_boolean = {"type": ["boolean", "null"]}
    assert type_from_json_schema(number) == Number()
    assert type_from_json_schema(string) == String()
    assert type_from_json_schema(object) == Object()
    assert type_from_json_schema(array) == Array()

# Generated at 2022-06-24 10:52:24.828645
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.fields import OneOf
    from typesystem.schema import Schema

    json_schema_data = {
        "oneOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }

    expected = OneOf(one_of=[String(), Integer()])
    actual = one_of_from_json_schema(json_schema_data)

    assert expected == actual, "JSON Schema oneOf didn't return a OneOf field"



# Generated at 2022-06-24 10:52:33.598545
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": ["integer", "number"]}) == Integer() | Number()
    assert from_json_schema({"type": "number", "maximum": 10}) == Number(maximum=10)


# Generated at 2022-06-24 10:52:43.734467
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # basic types
    assert get_standard_properties(Integer(default=1)) == {"default": 1}
    assert get_standard_properties(Integer(default=1.0)) == {"default": 1.0}
    assert get_standard_properties(Integer(default=True)) == {"default": True}
    assert get_standard_properties(Integer(default=None)) == {"default": None}
    assert get_standard_properties(Integer(default="")) == {"default": ""}

    # string
    assert get_standard_properties(
        String(default="", pattern_regex="[a-z]")
    ) == {"default": ""}

    # choice
    assert get_standard_properties(Choice(choices=[(1, 1), (2, "2")], default=1)) == {
        "default": 1
    }

   

# Generated at 2022-06-24 10:52:48.681570
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'$schema': 'http://json-schema.org/draft-07/schema#', 'type': 'object', 'properties': {'test': {'oneOf': [{'type': 'string'}, {'type': 'integer'}]}}, 'required': ['test']}
    definitions = SchemaDefinitions()
    my_schema = Schema(fields=from_json_schema(data, definitions=definitions))
    assert my_schema.fields['test'].__class__ is OneOf
    assert my_schema.fields['test'].one_of[0].__class__ is String
    assert my_schema.fields['test'].one_of[1].__class__ is Integer



# Generated at 2022-06-24 10:52:54.117031
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    value=enum_from_json_schema({"enum": [1,2,3]},None)
    q=value.validate(value.get_default())
    assert q
    q=value.validate(2)
    assert q
    q=value.validate(5)
    assert not q




# Generated at 2022-06-24 10:52:59.168781
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    definitions = SchemaDefinitions()
    assert any_of_from_json_schema({ "anyOf": [{'type':'string', 'minLength': 1}, {'type': 'integer'}]}, definitions) == Union([String(min_length=1, allow_blank=True), Integer()])



# Generated at 2022-06-24 10:53:09.046142
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "string", "const": 4}) == ({'string'}, False)
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null", "const": 4}) == ({'object', 'array', 'number', 'string'}, True)


_VALID_TYPE_STRINGS = {"null", "boolean", "object", "array", "number", "string"}



# Generated at 2022-06-24 10:53:16.812924
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=False) == String(allow_null=False)
    assert from_json_schema_type({"type": "string"}, type_string="string", allow_null=True) == String(allow_null=True)
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False) == Integer(allow_null=False)
    assert from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=True) == Integer(allow_null=True)
    assert from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False) == Boolean(allow_null=False)

# Generated at 2022-06-24 10:53:23.747439
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    typesystem = from_json_schema({"enum": ["one", "two", "three"]})
    assert typesystem.validate("one") == "one"
    assert typesystem.validate("two") == "two"
    assert typesystem.validate("three") == "three"
    try:
        typesystem.validate("four")
    except Exception as error:
        assert error.args[0] == '"four" is not a valid choice.'



# Generated at 2022-06-24 10:53:27.868963
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"type": "number", "multipleOf": 5}}
    assert_validate(from_json_schema(schema), data=3)
    assert_not_validate(from_json_schema(schema), data=5)



# Generated at 2022-06-24 10:53:30.685442
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": ["string", "number", "integer"]}
    expected_result = OneOf(one_of=["string", "number", "integer"])
    result = one_of_from_json_schema(data, definitions=None)
    assert result == expected_result



# Generated at 2022-06-24 10:53:32.168734
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"minLength": 4}}
    assert isinstance(not_from_json_schema(data, definitions=None), Not)



# Generated at 2022-06-24 10:53:38.949847
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer(default=1)) == {"default": 1}
    assert get_standard_properties(Integer(allow_null=True, default=None)) == {
        "default": None
    }
    assert get_standard_properties(AllOf(default=1)) == {"default": 1}
    assert get_standard_properties(Choice(choices=[(1, 1), (2, 2)])) == {
        "default": 1
    }
    assert get_standard_properties(Choice(default=1)) == {"default": 1}
    assert get_standard_properties(String(default="hello")) == {"default": "hello"}
    assert get_standard_properties(String(allow_null=True, default=None)) == {
        "default": None
    }

# Generated at 2022-06-24 10:53:42.657770
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    expected = Const(const=1.234,default=1.234,validate=True)
    data = {"const": 1.234, "default": 1.234}
    actual = const_from_json_schema(data,definitions)
    assert expected == actual


# Generated at 2022-06-24 10:53:44.848850
# Unit test for function get_standard_properties
def test_get_standard_properties():
    def get_test_field():
        return String(default="Hello")
    assert get_standard_properties(get_test_field()) == {'default': 'Hello'}



# Generated at 2022-06-24 10:53:49.956728
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_field = String(format='uuid')
    then_field = String()

# Generated at 2022-06-24 10:53:59.313768
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({
        'allOf': [
            {'$ref': '#/definitions/schema_1'},
            {'$ref': '#/definitions/schema_2'}
        ],
        'definitions': {
            'schema_1': {'type': ['number']},
            'schema_2': {'type': ['string']},
        }
    }, definitions={}) == AllOf(all_of=[
        Reference('#/definitions/schema_1', definitions={}),
        Reference('#/definitions/schema_2', definitions={}),
    ])

# Generated at 2022-06-24 10:54:08.504613
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-24 10:54:16.721712
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema(): 
    schema_definition = {
        "type": "object",
        "properties": {
            "a": {"oneOf": [{"type": "string", "maxLength": 5}, {"type": "integer"}]}
        },
    }
    schema = from_json_schema(schema_definition)
    assert isinstance(schema, Schema)
    assert isinstance(schema['a'], OneOf)
    assert schema.fields[0].one_of[0].max_length == 5
    assert schema.fields[0].one_of[1].__class__ == Integer
    assert schema.fields[0].default == NO_DEFAULT
    
test_one_of_from_json_schema()  



# Generated at 2022-06-24 10:54:20.865908
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/name"
    }
    assert ref_from_json_schema(data, definitions)
    # Check that definitions becomes a pair: (name, Field)
    assert "name" in definitions.field_names


# Generated at 2022-06-24 10:54:31.296895
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': 'integer'}) == ({'integer'}, False)
    assert get_valid_types({'type': 'boolean'}) == ({'boolean'}, False)
    assert get_valid_types({'type': 'null'}) == (set(), True)
    assert get_valid_types({'type': 'array'}) == ({'array'}, False)

# Generated at 2022-06-24 10:54:43.933928
# Unit test for function get_valid_types
def test_get_valid_types():
    test_data = [
        ({"type": "null"}, ([], True)),
        ({"type": []}, (["boolean", "object", "array", "number", "string"], False)),
        ({"type": ["integer", "null"]}, (["integer"], True)),
        ({"type": "integer"}, (["integer"], False)),
        ({}, (["boolean", "object", "array", "number", "string"], False)),
        ({"type": "number"}, (["number"], False)),
        ({"type": "object"}, (["object"], False)),
        ({"type": ["number", "null"]}, (["number"], True)),
    ]


# Generated at 2022-06-24 10:54:51.379313
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    all_of_schema = {
        "allOf": [
            {"type": "integer", "minimum": 0},
            {"type": "integer", "maximum": 100},
        ]
    }
    schema = from_json_schema(all_of_schema)
    assert type(schema) == AllOf
    assert all([isinstance(x, Integer) for x in schema.all_of])
    assert schema.allow_null == False
    assert schema.minimum == 0
    assert schema.maximum == 100



# Generated at 2022-06-24 10:54:59.813627
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if" : {
            "type": "string",
            "maxLength": 3
        },
        "then": {
            "type": "string",
            "minLength": 4
        }
    }
    definitions = SchemaDefinitions()
    result = if_then_else_from_json_schema(data, definitions=definitions)
    assert isinstance(result, IfThenElse)
    assert isinstance(result.if_clause, String)
    assert result.if_clause.max_length == 3
    assert isinstance(result.then_clause, String)
    assert result.then_clause.min_length == 4

# Generated at 2022-06-24 10:55:08.293103
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(
        from_json_schema(
            {
                "type": "string",
                "minLength": 2,
                "maxLength": 2,
            }
        ),
        String,
    )

    # https://json-schema.org/understanding-json-schema/reference/object.html#properties
    assert isinstance(
        from_json_schema(
            {
                "type": "object",
                "properties": {
                    "definitions": {"type": ["string", "boolean"]},
                    "definitions2": {
                        "type": "boolean",
                        "enum": [True, False],
                    },
                },
                "additionalProperties": False,
            }
        ),
        Object,
    )

    # https://json-schema.org/under

# Generated at 2022-06-24 10:55:15.505669
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
        "default": "foo"
    }, SchemaDefinitions()) == Union(
        any_of=[
            String(),
            Integer(),
        ],
        default="foo"
    )
    assert any_of_from_json_schema({
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ],
    }, SchemaDefinitions()) == Union(
        any_of=[
            String(),
            Integer(),
        ],
    )

# Generated at 2022-06-24 10:55:21.968746
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": ["string"]}), String)
    assert isinstance(
        from_json_schema({"type": "string", "const": "value"}), Const
    )
    assert isinstance(
        from_json_schema({"type": "string", "const": "value"}).value, str
    )
    assert from_json_schema({"type": "string", "const": "value"}).value == "value"
    assert isinstance(
        from_json_schema({"type": "string", "const": "value1"}), Const
    )

# Generated at 2022-06-24 10:55:31.806070
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem.schemas import OneOf
    from typesystem.fields import Boolean, String


# Generated at 2022-06-24 10:55:40.272862
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_data = {'oneOf': [{"type": "integer"}, {"type": "string"}]}
    one_of = [from_json_schema(item, definitions=definitions) for item in json_data["oneOf"]]
    assert isinstance(one_of[0], Integer)
    assert isinstance(one_of[1], String)
    kwargs = {"one_of": one_of, "default": json_data.get("default", NO_DEFAULT)}
    assert isinstance(kwargs["one_of"][0], Integer)
    assert isinstance(kwargs["one_of"][1], String)

# Generated at 2022-06-24 10:55:43.879436
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Any()) == {}
    assert get_standard_properties(Integer()) == {}
    assert get_standard_properties(Integer(default=1)) == {
        "default": 1
    }
test_get_standard_properties()



# Generated at 2022-06-24 10:55:48.721763
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": [1, 2], "default": 1}
    field = enum_from_json_schema(schema, definitions)
    assert field(1) == (True, None, 1)
    assert field(3) == (False, "Invalid choice.", 1)



# Generated at 2022-06-24 10:55:52.493639
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer(minimum=1)) == {}
    assert get_standard_properties(Integer(minimum=1, default=2)) == {"default": 2}



# Generated at 2022-06-24 10:56:04.267130
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {"type": "number"}
    assert isinstance(from_json_schema_type(schema, "number", True, None), Float)
    assert isinstance(from_json_schema_type(schema, "integer", False, None), Integer)
    assert isinstance(from_json_schema_type(schema, "string", False, None), String)
    assert isinstance(from_json_schema_type(schema, "boolean", False, None), Boolean)
    assert isinstance(from_json_schema_type(schema, "array", False, None), Array)
    assert isinstance(from_json_schema_type(schema, "object", False, None), Object)

    schema = {"type": "null"}

# Generated at 2022-06-24 10:56:07.159180
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/JSONSchema"}
    reference = ref_from_json_schema(data, definitions)
    assert isinstance(reference, Reference)
    assert reference.to == "#/definitions/JSONSchema"



# Generated at 2022-06-24 10:56:10.042944
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default=False)) == {"default": False}
    assert get_standard_properties(String(default="hello")) == {"default": "hello"}


# Generated at 2022-06-24 10:56:20.989219
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    sch = one_of_from_json_schema({
        'oneOf': [
            {'type': 'number', 'multipleOf': 3},
            {'type': 'number', 'multipleOf': 5}
        ]
    }, SchemaDefinitions())
    print(sch.schema)

    assert sch.schema['anyOf'][0]['multipleOf'] == 3
    assert sch.schema['anyOf'][1]['multipleOf'] == 5



# Generated at 2022-06-24 10:56:31.114537
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf": [{"type": "integer", "maximum": 1}, {"type": "integer", "minimum": 2,}]}
    field = any_of_from_json_schema(schema, None)
    assert field == Union(
        any_of=[
            Integer(allow_null=False, minimum=None, maximum=1, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=NO_DEFAULT),
            Integer(allow_null=False, minimum=2, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=NO_DEFAULT),
        ],
        allow_null=False,
        default=NO_DEFAULT,
    )
test_any_of_from_json_schema()



# Generated at 2022-06-24 10:56:34.135173
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = Object(properties={"a": String()})
    definitions = SchemaDefinitions(definitions={"#/definitions/foo": schema})
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions) == schema



# Generated at 2022-06-24 10:56:42.217868
# Unit test for function to_json_schema
def test_to_json_schema():
    from djangofloor.json_schema import deserialize_schema

    class MySchema(Schema):
        myfield: Reference("foo") | Reference("bar")

    schema = MySchema()
    json_schema = to_json_schema(schema)
    schema2 = deserialize_schema(
        json_schema,
        definitions=schema.definitions,
    )
    assert isinstance(schema2.myfield, Union)
    assert len(schema2.myfield.any_of) == 2
    assert schema2.myfield.any_of[0].target_string == "foo"
    assert schema2.myfield.any_of[1].target_string == "bar"


# pylint: enable=unused-variable,unused-argument,function-red

# Generated at 2022-06-24 10:56:51.982342
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Test for 'ref_from_json_schema'.
    """
    # 'ref_from_json_schema' just returns a Reference.
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={})
    assert str(field) == "<Reference to='#/definitions/foo'>"

    # If a validator is already stored in the definitions, the Reference
    # is created with a reference to that validator.
    field = ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={"#/definitions/foo": String()})
    assert str(field) == "<Reference to='#/definitions/foo'>"



# Generated at 2022-06-24 10:56:54.799637
# Unit test for function get_valid_types
def test_get_valid_types():
    test_get_valid_types.counter += 1
    return get_valid_types({
        "type": "null"
    })
test_get_valid_types.counter = 0
# End unit test for function get_valid_types

# Generated at 2022-06-24 10:57:02.991617
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json = {}
    json["type"] = "object"
    json["properties"] = {
        "name": {
            "type": "string"
        },
        "age": {
            "type": "integer",
            "minimum": 0,
            "maximum": 150
        }
    }
    json["required"] = ["name", "age"]
    json["additionalProperties"] = False

    data = {
        "not":json
    }
    field = not_from_json_schema(data)
    assert field.validate({"test":"test"}) == True
    assert field.validate({}) == True
    assert field.validate({"name": "test", "age": 10}) == False
    
    


# Generated at 2022-06-24 10:57:09.424448
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf": [{"type": "string"}, {"type": "boolean"}]}
    types = any_of_from_json_schema(schema, definitions=definitions)
    assert isinstance(types,typesystem.fields.Union)
    assert types.any_of[0].__class__ == typesystem.fields.String
    assert types.any_of[1].__class__ == typesystem.fields.Boolean



# Generated at 2022-06-24 10:57:13.145388
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Object(properties={"type": "string"})
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions) == definitions["#/definitions/foo"], "Ref to external"
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=definitions).to_schema(definitions=definitions) == {"$ref": "#/definitions/foo"}, "Ref to external (to json)"



# Generated at 2022-06-24 10:57:22.054566
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema1 = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "default": "hello",
    }
    field1 = if_then_else_from_json_schema(schema1, definitions=None)
    assert str(field1.if_clause) == "Integer()"
    assert str(field1.then_clause) == "String()"
    assert str(field1.else_clause) == "Const('hello')"
    assert field1.default == "hello"

    schema2 = {
        "if": {"type": "integer"},
        "then": {"type": "string"},
        "else": {"type": "number"},
    }
    field2 = if_then_else_from_json_schema(schema2, definitions=None)

# Generated at 2022-06-24 10:57:32.723147
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Tests for "if"/"then"/"else"
    assert IfThenElse(
        if_clause=Const(1),
        then_clause=Const(2),
        else_clause=Const(3),
    ) == from_json_schema(
        {
            "if": {"const": 1},
            "then": {"const": 2},
            "else": {"const": 3},
        }
    )

    assert IfThenElse(
        if_clause=Const(1),
        then_clause=Const(2),
    ) == from_json_schema(
        {
            "if": {"const": 1},
            "then": {"const": 2},
        }
    )


# Generated at 2022-06-24 10:57:35.575286
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1}) == Const(const=1)
    assert const_from_json_schema({"const": "abc"}) == Const(const="abc")


# Generated at 2022-06-24 10:57:42.268415
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema_1 = {
        "$schema": "http://json-schema.org/draft-06/schema#",
        "type": "object",
        "properties": {
            "color": {
                "type": "string",
                "oneOf": [
                    {"const": "red"},
                    {"enum": ["red", "green", "blue"]},
                    {"const": "green"},
                    {"const": "blue"},
                ],
            }
        },
    }
    expected_1 = {
        "color": OneOf(
            [Const("red"), Choice(choices=[("red", "red"), ("green", "green"), ("blue", "blue")]), Const("green"), Const("blue")],
        )
    }
    assert from_json_schema(schema_1) == expected_1


# Generated at 2022-06-24 10:57:53.151277
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type_string in data
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
    }
    field = from_json_schema(schema)
    assert isinstance(field, Object)
    assert field.allow_null is False

    # type_string in data.items
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "items": [{"type": "string"}, {"type": "integer"}],
    }
    field = from_json_schema(schema)
    assert isinstance(field, Object)
    assert field.allow_null is False

    # type_string in data.items.items
    schema

# Generated at 2022-06-24 10:57:59.913948
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, definitions=None) == Integer()
    assert type_from_json_schema({"type": "string"}, definitions=None) == String()
    assert type_from_json_schema({"type": "number"}, definitions=None) == Number()
    assert type_from_json_schema({"type": "boolean"}, definitions=None) == Boolean()
    assert (
        type_from_json_schema({"type": "null"}, definitions=None) == Const(None)
    )

    assert (
        type_from_json_schema({"type": "integer", "maximum": 10}, definitions=None)
        == Integer(maximum=10)
    )

# Generated at 2022-06-24 10:58:07.716240
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {"type": "string", "minLength": 3},
            {"type": "integer", "minimum": 5},
        ]
    }
    expected_result = OneOf(one_of=[
        String(min_length=3),
        Integer(minimum=5),
    ])
    assert one_of_from_json_schema(schema, definitions=None) == expected_result


# Generated at 2022-06-24 10:58:17.033404
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    x = {
        "if": {
            "properties": {
                "firstName": {"type": "string", "minLength": 1},
                "lastName": {"type": "string", "minLength": 1},
            },
            "required": ["firstName", "lastName"],
            "type": "object",
        },
        "then": {"type": "object", "properties": {"name": {"type": "string"}},},
        "else": {"type": "object", "properties": {"name": {"type": "string"}},},
    }

    y = if_then_else_from_json_schema(x, None)
    assert y is not None

# Generated at 2022-06-24 10:58:17.869296
# Unit test for function to_json_schema
def test_to_json_schema():
    # TODO
    pass


# Generated at 2022-06-24 10:58:22.089549
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        str(from_json_schema_type({"type": "number", "minimum": 5}, "number", False, None))
        == "Number(default=None, minimum=5, maximum=None, "
        "exclusive_minimum=None, exclusive_maximum=None, "
        "multiple_of=None, allow_null=False)"
    )



# Generated at 2022-06-24 10:58:29.159505
# Unit test for function to_json_schema
def test_to_json_schema():

    string_field = String(min_length=1)
    integer_field = Integer(minimum=0)
    schema = Schema(
        {"a": string_field, "b": integer_field}
    ).make_validator()  # type: ignore

    data = to_json_schema(schema)


# Generated at 2022-06-24 10:58:40.291807
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-24 10:58:48.939078
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem.types import JSONObject
    schema = {
        "definitions": {
            "inner_schema": {
                "properties": {"a": {"type": "string"}, "b": {"type": "number"}}
            },
        },
        "allOf": [{"$ref": "#/definitions/inner_schema"}, {"properties": {"c": {"type": "string"}}}],
        "type": "object",
    }
    field = from_json_schema(schema)
    assert isinstance(field, JSONObject)
    assert field.properties == {'a': String(), 'b': Number(), 'c': String()}


# Generated at 2022-06-24 10:58:52.904742
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(1) == {}
    assert get_standard_properties(Any()) == {}
    assert get_standard_properties(String(default="test")) == {"default": "test"}

# Generated at 2022-06-24 10:58:59.032501
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Setup
    data = {'enum': ['hello', 'world']}

    # Test
    field = enum_from_json_schema(data, definitions)

    # Validate
    assert field.validate('hello') == 'hello'
    assert field.validate('world') == 'world'
    assert not field.validate('nope')



# Generated at 2022-06-24 10:59:05.853272
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = dict(
        if_clause="if_clause",
        then_clause="then_clause",
        else_clause="else_clause",
        default="default"
    )
    actual = if_then_else_from_json_schema(data, definitions={})
    assert isinstance(actual, IfThenElse)
    assert actual.if_clause == "if_clause"
    assert actual.then_clause == "then_clause"
    assert actual.else_clause == "else_clause"
    assert actual.default == "default"



# Generated at 2022-06-24 10:59:13.618323
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from .fixtures import definitions_object, input_object
    from .utils import assert_schema

    schema = from_json_schema(definitions_object)
    assert_schema(
        schema,
        data_passes=['test', 'test2', 'test3'],
        data_fails=['test4', 'test5', 'test6'],
        input_object=input_object
    )


