

# Generated at 2022-06-26 10:21:04.106005
# Unit test for function to_json_schema
def test_to_json_schema():
    from datetime import datetime
    from decimal import Decimal
    from typesystem import String, Integer, Float, Decimal, Boolean, DateTime, \
        Array, Object, String, Choice, Const, Union, OneOf, AllOf, Reference, \
        any_of, all_of, object, fields

    TestEnum = Choice(choices=[("a", "A"), ("b", "B"), ("c", "C")])
    TestConst = Const(const="foo")


# Generated at 2022-06-26 10:21:16.072088
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'number'}) == ({'number'}, False)
    assert get_valid_types({'type': 'null'}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({'type': ['null', 'string']}) == ({'null', 'string'}, False)
    assert get_valid_types({'type': ['null', 'string', 'number']}) == ({'null', 'string', 'number'}, False)
    assert get_valid_types({'type': ['null', 'number']}) == ({'null', 'number'}, False)
    assert get_valid

# Generated at 2022-06-26 10:21:23.232310
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {"if": {}, "default": "1"}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)
    assert field_0.default == "1" and field_0.if_clause == {}


# Generated at 2022-06-26 10:21:36.836638
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema(
        {"allOf": [{"type": "string", "pattern": "^hello"}]}, SchemaDefinitions()
    ) == AllOf(all_of=[String(pattern="^hello")])

    assert all_of_from_json_schema(
        {"allOf": [{"type": "string", "pattern": "^hello"}]}, SchemaDefinitions()
    ) != AllOf(all_of=[String(pattern="^hel")])

    assert all_of_from_json_schema(
        {"allOf": [{"type": "string", "pattern": "^hello"}]}, SchemaDefinitions()
    ) == AllOf(all_of=[String(pattern="^hello")])


# Generated at 2022-06-26 10:21:40.080037
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = any_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:21:44.414664
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Example of minimal valid document in JSON-Schema format.
    data = {"type": "integer", "minimum": 2, "maximum": 4}
    schema = from_json_schema(data)
    assert schema == Integer(minimum=2, maximum=4)

    # Example of minimal valid document in JSON-Schema format.
    data = {"type": "object", "properties": {"number": {"type": "integer"}}}
    schema = from_json_schema(data)
    assert schema == Object(properties={"number": Integer()})

    # Example of minimal valid document in JSON-Schema format.
    data = {"type": "object", "properties": {"number": {"type": "integer"}}}
    schema = from_json_schema(data)
    assert schema == Object(properties={"number": Integer()})



# Generated at 2022-06-26 10:21:46.830367
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert callable(all_of_from_json_schema)
    assert isinstance(all_of_from_json_schema(dict, definitions=None), Field)



# Generated at 2022-06-26 10:22:01.529131
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Tests for function type_from_json_schema
    dict_0 = {'type': 'integer'}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)
    field_1 = module_0.Integer(minimum=1, maximum=1)
    assert isinstance(field_0, module_0.Integer) == field_1
    dict_1 = {'type': 'integer'}
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_2 = one_of_from_json_schema(dict_1, schema_definitions_1)
    field_3 = module_0.Const(1)

# Generated at 2022-06-26 10:22:05.763090
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {
        "if": {
            "$ref": "#/definitions/if",
            "definitions": {
                "if": {
                    "enum": [
                        1,
                        2,
                        3,
                    ],
                    "type": "integer",
                },
            },
            "description": "if",
        },
        "then": "then",
        "type": "object",
    }
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)

    assert field_0.validate({"if": 1, "then": "then"}) == ("then", None), "Test Case 0"



# Generated at 2022-06-26 10:22:09.607374
# Unit test for function to_json_schema
def test_to_json_schema():
    import typesystem
    arg = typesystem.String(maximum=20)
    expected = {
        "type": "string",
        "maxLength": 20,
    }
    assert to_json_schema(arg) == expected



# Generated at 2022-06-26 10:23:06.247034
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    try:
        assert True # TODO: implement your test here
    except AssertionError as e:
        print(e)



# Generated at 2022-06-26 10:23:10.761341
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": var_0
    }
    definitions = var_0
    assert const_from_json_schema(data, definitions) == var_0


# Generated at 2022-06-26 10:23:23.883212
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    var_0 = {'allOf': [{'$ref': '#/definitions/positiveInteger'}, {'minimum': 0}]}
    var_1 = {
  "type": "object",
  "required": [
    "a",
    "b"
  ],
  "properties": {
    "a": {
      "type": "integer"
    },
    "b": {
      "type": "string"
    }
  }
}
    var_3 = Schema(
          Object(
              properties={
                  "a": Integer(),
                  "b": String(),
              },
              required=["a", "b"],
          ),
      )
    var_2 = var_3
    pass


# Generated at 2022-06-26 10:23:37.753330
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_1 = True
    var_2 = None
    var_3 = Integer()
    var_4 = "test case 0"
    var_5 = Not(negated=AllOf([var_1, var_2, var_3]))
    var_6 = [var_5]
    var_7 = {"type": "array", "items": {"allOf": [{"type": "boolean"}, {"type": "null"}, {"type": "integer"}]}, "not": {"allOf": [{"type": "boolean"}, {"type": "null"}, {"type": "integer"}]}}

# Generated at 2022-06-26 10:23:43.338291
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema({"a": 1, "b": "2"})
    jschema = to_json_schema(schema)
    assert jschema == {
        "definitions": {"a": {"const": 1, "type": "integer"}, "b": {"const": "2", "type": "string"}},
        "properties": {"a": {"$ref": "#/definitions/a"}, "b": {"$ref": "#/definitions/b"}},
        "required": ["a", "b"], 
        "title": "schema",
        "type": "object",
    }



# Generated at 2022-06-26 10:23:46.899159
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = None
    field = not_from_json_schema(data)
    field.validate(var_0)

test_case_0()

# Generated at 2022-06-26 10:23:55.369187
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    var_1 = {'enum': [1, 2, 3]}
    var_2 = Choice({'choices': [(1, 1), (2, 2), (3, 3)]})
    var_3 = enum_from_json_schema(var_1)
    assert var_2 == var_3


# Generated at 2022-06-26 10:23:56.727270
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    var_0 = None



# Generated at 2022-06-26 10:24:11.240863
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = from_json_schema_type({}, type_string="boolean", allow_null=True, definitions={})
    assert var_0.match("") == (None, False)
    assert var_0.match("0") == (None, False)
    assert var_0.match(" ") == (None, False)
    assert var_0.match("a") == (None, False)
    assert var_0.match("null") == (None, False)
    assert var_0.match("false") == (False, True)
    assert var_0.match("true") == (True, True)
    assert var_0.serialize(None) == ("null", True)
    assert var_0.serialize(False) == ("false", True)

# Generated at 2022-06-26 10:24:17.877523
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    var_0 = from_json_schema_type(None, "boolean", True, None)
    var_1 = from_json_schema_type(None, "integer", True, None)
    var_2 = from_json_schema_type(None, "number", True, None)
    var_3 = from_json_schema_type(None, "string", True, None)
    var_4 = from_json_schema_type(None, "boolean", True, None)
    var_5 = from_json_schema_type(None, "integer", True, None)
    var_6 = from_json_schema_type(None, "number", True, None)
    var_7 = from_json_schema_type(None, "string", True, None)

    assert not var_

# Generated at 2022-06-26 10:24:41.590785
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': []}
    field_0 = enum_from_json_schema(dict_0, {})
    assert field_0.choices == []
    assert field_0.default is None


# Generated at 2022-06-26 10:24:43.251948
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {}


# Generated at 2022-06-26 10:24:45.242837
# Unit test for function from_json_schema
def test_from_json_schema():
    result = from_json_schema({})
    assert isinstance(result, Any)

    result = from_json_schema(False)
    assert isinstance(result, NeverMatch)



# Generated at 2022-06-26 10:24:57.922193
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    import typesystem
    import pytest
    import inspect
    import re

    # Capture results
    with pytest.raises(AssertionError) as result:
        enum_from_json_schema('data', 'definitions')
    with pytest.raises(AssertionError) as result:
        enum_from_json_schema(b'data', b'definitions')
    with pytest.raises(AssertionError) as result:
        enum_from_json_schema(bytearray(b'data'), bytearray(b'definitions'))
    with pytest.raises(AssertionError) as result:
        enum_from_json_schema(bytearray(b'data'), 'definitions')

# Generated at 2022-06-26 10:25:01.169722
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {}
    field_0 = not_from_json_schema(dict_0)


# Generated at 2022-06-26 10:25:08.440989
# Unit test for function from_json_schema
def test_from_json_schema():
    # 1. Arrange
    # Dictionary with no schema
    dict_0 = {}

    # 2. Act - Create Field from json schema
    field_0 = from_json_schema(dict_0)

    # 3. Assert
    assert field_0.to_json_schema() == dict_0


# Generated at 2022-06-26 10:25:11.467598
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    pass



# Generated at 2022-06-26 10:25:18.038412
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test the conversion of various fields to JSON schema, and check if
    # the output is the expected value.
    field_0 = Any()
    expected_output_0 = True
    actual_output_0 = to_json_schema(field_0)
    assert actual_output_0 == expected_output_0

    field_1 = NeverMatch()
    expected_output_1 = False
    actual_output_1 = to_json_schema(field_1)
    assert actual_output_1 == expected_output_1

    field_2 = String(min_length=5)
    expected_output_2 = {
        "type": "string",
        "minLength": 5,
    }
    actual_output_2 = to_json_schema(field_2)
    assert actual_output_2 == expected_output

# Generated at 2022-06-26 10:25:22.148444
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'anyOf': [{'type': 'string'}, {'type': 'integer'}]}
    result = any_of_from_json_schema(dict_0)
    expected_result = Union(any_of=Union(any_of=Union(any_of=[String(), Integer()])))
    assert result == expected_result


# Generated at 2022-06-26 10:25:32.782665
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Generate structure that not_from_json_schema should return
    dict_0 = {'$schema': 'http://json-schema.org/draft-04/schema#', 'additionalItems': {'enum': ['Yes', 'No'], 'type': 'string'}, 'items': [{'default': '1.0', 'format': 'float', 'type': 'number'}, {'default': 'Yes', 'enum': ['Yes', 'No'], 'type': 'string'}], 'required': ['version', 'test'], 'type': 'array', 'uniqueItems': True}
    field_0 = from_json_schema(dict_0)
    # Generate structure that is not supposed to be returned

# Generated at 2022-06-26 10:26:50.046585
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Test that we can convert from a JSON schema anyOf to a Field
    # Test that we raise an exception if the JSON schema is not valid
    # Test that we raise an exception if the JSON schema does not have an anyOf
    # Test that we raise an exception if the JSON schema is not a dict

    data_any_of_0: typing.Dict[str, typing.Any] = {"anyOf": [{'default': None, 'const': True}]}
    any_of_0 = any_of_from_json_schema(data_any_of_0, definitions=None)
    assert isinstance(any_of_0, Union)
    assert any_of_0.any_of[0].const == True
    assert any_of_0.any_of[0].default == None
    assert any_of_0.any_

# Generated at 2022-06-26 10:26:56.627636
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-26 10:26:59.813149
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test type_string = 'integer'
    data = {'oneOf': [{'type': 'integer'}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert isinstance(field, Field)
    assert field.run('1') == (True, '1')
    assert field.run(1) == (False, '1 is not an integer.')


# Generated at 2022-06-26 10:27:07.128056
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_0 = "number"
    data_0 = {}
    allow_null_0 = True
    definitions_0 = {}
    field_0 = from_json_schema_type(data_0, type_0, allow_null_0, definitions_0)
    assert field_0.__class__ == Float


# Generated at 2022-06-26 10:27:14.449392
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {"anyOf": [{"type": "string"}, {"type": "number"}]}
    field_0 = any_of_from_json_schema(dict_0, None)


# Generated at 2022-06-26 10:27:16.663676
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"type":"object", "properties":{"a":{"type":"integer"}}, "oneOf":[{"type":"object","properties":{"b":{"type":"integer"}}}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    

# Generated at 2022-06-26 10:27:19.612967
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/content"}, definitions=definitions) == Reference(to="#/definitions/content", definitions=definitions)



# Generated at 2022-06-26 10:27:33.260563
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "number",
                "multipleOf": 3,
            },
            {
                "type": "string",
                "minLength": 5,
                "maxLength": 10,
            },
        ],
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)

    # Make sure we've got the correct schema
    assert field.type == OneOf
    assert len(field.one_of) == 2

    # Check the first subfield matches
    first_subfield = field.one_of[0]
    assert type(first_subfield) is Field
    first_subfield_schema = first_subfield.schema
    assert first_subfield_schema.type == Float
   

# Generated at 2022-06-26 10:27:35.884719
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [1, 2, 3]}, None)



# Generated at 2022-06-26 10:27:46.146512
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_1 = {"anyOf": [{"type": "integer"}]}
    field_1 = from_json_schema(dict_1)
    # Test the following lines:
    # any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    # kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    assert field_1.any_of[0].type_string == "integer"

    dict_2 = {"anyOf": [{"type": "integer"}], "default": False}
    field_2 = from_json_schema(dict_2)
    # Test the following lines:
    # any_of = [from_json_schema(item, definitions=definitions) for item in data["any

# Generated at 2022-06-26 10:28:30.936270
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string", "minLength": 0}) == String(min_length=0)
    assert from_json_schema({"type": "string", "maxLength": 0}) == String(max_length=0)
    assert from_json_schema({"type": "string", "pattern": "a-zA-Z"}) == String(
        pattern=r"a-zA-Z"
    )
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json

# Generated at 2022-06-26 10:28:49.454646
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    input_values = [
        {"not": {"type": "integer"}},
        {"not": {"type": "null"}},
        {"not": {"type": "boolean"}},
        {"not": {"type": "string"}},
        {"not": {"type": "number"}},
        {"not": "number"},
        {"not": {"type": "array"}},
        {"not": {"type": "object"}},
        {"not": {"type": "string", "const": "foo"}},
    ]

# Generated at 2022-06-26 10:29:02.900631
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Boolean()) == {"type": "boolean"}, "Unittest failed"
    assert to_json_schema(Boolean(allow_null=True)) == {"type": ["boolean", "null"]}, "Unittest failed"

    assert to_json_schema(Integer()) == {"type": "integer"}, "Unittest failed"

    assert to_json_schema(String()) == {"type": "string"}, "Unittest failed"
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}, "Unittest failed"
    assert to_json_schema(String(min_length=10)) == {"type": "string", "minLength": 10}, "Unittest failed"

# Generated at 2022-06-26 10:29:10.623315
# Unit test for function to_json_schema
def test_to_json_schema():
    field = String(
        min_length=1,
        max_length=100,
        pattern_regex=re.compile(r"^Hello,\s+"),
        format=StringFormat.DATE_TIME,
        allow_null=True,
    )
    output = to_json_schema(field)
    expected_output = {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 100,
        "pattern": r"^Hello,\s+",
        "format": "date-time",
        "default": None,
        "$schema": "http://json-schema.org/draft-07/schema#",
    }
    assert output == expected_output


# Generated at 2022-06-26 10:29:17.686365
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Boolean
    data = {"not": False}
    negated = from_json_schema(data["not"])
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    assert Not(**kwargs) == Any()

    data = {"not": True}
    negated = from_json_schema(data["not"])
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
    assert Not(**kwargs) == NeverMatch()

    # Integer and Float
    data = {"not": {"type":"integer"}}
    negated = from_json_schema(data["not"])
    kwargs = {"negated": negated, "default": data.get("default", NO_DEFAULT)}
   

# Generated at 2022-06-26 10:29:25.482369
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert (
        IfThenElse(
            if_clause=Any(),
            then_clause=Any(),
            else_clause=Any(),
            default=NO_DEFAULT,
        )
        == if_then_else_from_json_schema({"if": {}, "then": {}, "else": {}})
    )



# Generated at 2022-06-26 10:29:30.170731
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data_ = {
        "$ref": "#/definitions/first"
    }

    definitions_ = SchemaDefinitions()

    definitions_["#/definitions/first"] = String()

    reference_ = ref_from_json_schema(data_, definitions_)

    assert isinstance(reference_, Reference)
    assert reference_.to == "#/definitions/first"
    assert definitions_ == reference_.definitions


# Generated at 2022-06-26 10:29:41.213250
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {"if": {"type": "string"}, "then": {"minLength": 0}}
    field = if_then_else_from_json_schema(json_schema)
    assert field.accepts("t")
    assert not field.accepts(0)
    assert field.accepts(None)

    json_schema = {"if": {"type": "string"}, "then": {"minLength": 5}}
    field = if_then_else_from_json_schema(json_schema)
    assert field.accepts("test")
    assert not field.accepts("t")
    assert field.accepts(None)

    json_schema = {"if": {"type": "string"}, "then": {"minLength": 5}, "else": {"type": "string"}}
    field = if_then_else

# Generated at 2022-06-26 10:29:53.059582
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {
        "$ref": "#/definitions/user",
        "definitions": {
            "user": {
                "type": 'object',
                "properties": {
                    "name": {
                        "type": "string",
                        "minLength": 2,
                        "maxLength": 32,
                    },
                    "age": {"type": "integer", "minimum": 0, "maximum": 200},
                },
            }
        },
    }
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:29:59.824410
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Baseline test for function from_json_schema_type
    definitions = SchemaDefinitions()
    data = {}
    type_string = "any_type"
    allow_null = False
    field = from_json_schema_type(data, type_string, allow_null, definitions)
    assert field is not None
