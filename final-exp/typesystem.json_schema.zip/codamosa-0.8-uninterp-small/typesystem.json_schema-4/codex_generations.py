

# Generated at 2022-06-26 10:21:15.488808
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})
    bool_0 = True
    assert field_0.is_valid({'a':bool_0})

# Generated at 2022-06-26 10:21:26.573595
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Test case 0
    data_0 = {"const": 1}
    definitions_0 = {}
    field_0 = const_from_json_schema(data_0, definitions_0)
    assert field_0.to_json_schema() == {
        "type": "number",
        "const": 1,
    }
    assert field_0.run(1) == 1
    assert field_0.run(2) == 2
    # Test case 1
    data_1 = {"const": 2}
    definitions_1 = {}
    field_1 = const_from_json_schema(data_1, definitions_1)
    assert field_1.to_json_schema() == {
        "type": "number",
        "const": 2,
    }

# Generated at 2022-06-26 10:21:38.920391
# Unit test for function from_json_schema

# Generated at 2022-06-26 10:21:42.473887
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string", "minLength": 0}]}
    actual = any_of_from_json_schema(data, definitions=None)
    expected = Union(any_of=[String()], allow_null=False)
    assert actual == expected, "Test failed"



# Generated at 2022-06-26 10:21:45.434198
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data_0 = {'const': 9}
    definitions_0 = {}
    field_0 = const_from_json_schema(data_0, definitions_0)



# Generated at 2022-06-26 10:21:52.291210
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    def ref_from_json_schema(data: dict, definitions: dict) -> Field:
        reference_string = data["$ref"]
        assert reference_string.startswith("#/"), "Unsupported $ref style in document."
        return Reference(to=reference_string, definitions=definitions)

    # Create definitions dictionary
    definitions = {}
    definitions["a"] = Reference(to="b")
    definitions["b"] = Integer()

    # Create a JSON Schema
    data_0 = {"$ref": "#/a"}
    data_1 = {"not": {"$ref": "#/a"}}
    data_2 = {"not": {"$ref": "#/b"}}

    # Test not schema in the definitions dictionary
    # Check that the output is of type Field

# Generated at 2022-06-26 10:22:04.046653
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test 1
    data_1 = {
        "oneOf": [
            {"type": "string"},
            {"type": "number"},
        ],
    }
    definitions_1 = None
    field_1 = one_of_from_json_schema(data_1, definitions_1)
    assert field_1.label == "one_of"
    value_1 = "foo"
    result_1 = field_1.validate(value_1)
    assert result_1.value == value_1
    value_2 = 12
    result_2 = field_1.validate(value_2)
    assert result_2.value == value_2
    value_3 = False
    result_3 = field_1.validate(value_3)

# Generated at 2022-06-26 10:22:09.441472
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    allOf = {"allOf": [{"type": "number"}, {"type": "number", "minimum": 0}]}
    field_0 = from_json_schema(allOf)
    field_1 = AllOf(all_of=[Number(), Number(minimum=0)])
    assert field_0 == field_1


# Generated at 2022-06-26 10:22:22.048596
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = Boolean()
    then_clause = Boolean()
    else_clause = Boolean()

    data = {
        "if": {},
        "then": {},
        "else": {},
    }

    definitions = SchemaDefinitions()

    actual = if_then_else_from_json_schema(data=data, definitions=definitions)

    expected = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
        else_clause=else_clause,
        default=NO_DEFAULT,
    )

    assert actual == expected


# Generated at 2022-06-26 10:22:24.587557
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": True}
    field = not_from_json_schema(data=data, definitions=definitions)
    assert isinstance(field, Not)
    assert field.negated == True


# Generated at 2022-06-26 10:22:44.798576
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert callable(if_then_else_from_json_schema)


# Generated at 2022-06-26 10:22:52.548818
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Preparing input data
    data = {"type" : "string", "maxLength" : 5}
    type_string = "string"
    allow_null = False
    definitions = None

    # Expected output
    expected_output = "String"

    # Function output
    output = from_json_schema_type(data, type_string, allow_null, definitions)
    assert isinstance(output, str)

    # Asserting the output is equal to the expected output
    assert output == expected_output



# Generated at 2022-06-26 10:23:00.614436
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema(True), Any)
    assert isinstance(from_json_schema(False), NeverMatch)

    schema = {
        "type": "string",
        "minLength": 1,
        "format": "date-time",
    }
    field = from_json_schema(schema)

    assert isinstance(field, String)
    assert field.min_length == 1
    assert field.format == "date-time"


# Generated at 2022-06-26 10:23:06.022474
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/Boolean'}
    reference_string = data['$ref']
    assert reference_string.startswith("#/"), "Unsupported $ref style in document."


# Generated at 2022-06-26 10:23:18.034070
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {}
    assert not_from_json_schema(data, None).to_dict() == {'negated': {'type': 'any'}, 'default': NO_DEFAULT}

# Generated at 2022-06-26 10:23:25.209613
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "a": {
                "$id": "#/properties/a",
                "type": "object",
                "properties": {
                    "b": {
                        "$id": "#/properties/a/properties/b",
                        "type": "string",
                    },
                    "c": {
                        "$id": "#/properties/a/properties/c",
                        "type": "string",
                    },
                },
            }
        },
    }
    field_0 = from_json_schema(json_schema)


# Generated at 2022-06-26 10:23:35.082116
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Input:
    data_0 = {
        "$ref": "#/definitions/Person",
        "type": "object",
        "definitions": {
            "Person": {"type": ["string", "null"], "maxLength": 10}
        },
    }
    definitions = SchemaDefinitions()
    # Output:
    field_0 = ref_from_json_schema(data_0, definitions=definitions)
    # Return:
    return (field_0)



# Generated at 2022-06-26 10:23:45.570493
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data_0 = {"enum": ['myenum1', 'myenum2']}
    field_0 = enum_from_json_schema(data_0, definitions=definitions)
    assert field_0.choices == [('myenum1', 'myenum1'), ('myenum2', 'myenum2')]
    data_1 = {"enum": ['myenum1', 'myenum2'], "default": "myenum2"}
    field_1 = enum_from_json_schema(data_1, definitions=definitions)
    assert field_1.choices == [('myenum1', 'myenum1'), ('myenum2', 'myenum2')]
    assert field_1.default == "myenum2"


# Generated at 2022-06-26 10:24:00.745068
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        test_field = String(min_length=1)

    test_schema = TestSchema()
    test_field_json_schema = to_json_schema(test_schema.test_field)
    assert test_field_json_schema == {
        "type": "string",
        "minLength": 1,
        "maxLength": None,
        "allow_blank": True,
        "pattern": None,
        "allow_null": False,
        "default": NO_DEFAULT,
    }

    test_schema_json_schema = to_json_schema(test_schema)

# Generated at 2022-06-26 10:24:12.793351
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {"type": "boolean"}
    field_0 = from_json_schema(dict_0)

    dict_1 = {"type": "boolean", "enum": [False]}
    field_1 = from_json_schema(dict_1)

    dict_2 = {"type": "boolean", "enum": [True]}
    field_2 = from_json_schema(dict_2)

    dict_3 = {"type": "boolean", "enum": [True, False]}
    field_3 = from_json_schema(dict_3)

    dict_4 = {"type": "number", "default": 3.14159, "multipleOf": 3.14159}
    field_4 = from_json_schema(dict_4)


# Generated at 2022-06-26 10:24:51.452775
# Unit test for function not_from_json_schema

# Generated at 2022-06-26 10:25:02.543467
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:25:05.145408
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field_0 = from_json_schema({"not": {}})
    field_1 = from_json_schema({})
    assert field_0.negated == field_1


# Generated at 2022-06-26 10:25:10.161712
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {"anyOf": [True, 1]}
    definitions = {
        "my-schema": {"anyOf": [True, False]}
    }
    field = from_json_schema(data, definitions=definitions)
    assert field.validate(True) == True
    assert field.validate(0) == None



# Generated at 2022-06-26 10:25:17.234014
# Unit test for function from_json_schema
def test_from_json_schema():
    bool_0 = True
    field_0 = from_json_schema(bool_0)
    bool_1 = False
    field_1 = from_json_schema(bool_1)
    bool_2 = False
    field_2 = from_json_schema(bool_2)
    dict_3 = {"$ref":"#/definitions/test"}
    field_3 = from_json_schema(dict_3)
    dict_4 = {"$ref":"#/definitions/test"}
    field_4 = from_json_schema(dict_4)
    dict_5 = {"$ref":"#/definitions/test"}
    field_5 = from_json_schema(dict_5)
    dict_6 = {"$ref":"#/definitions/test"}
    field_6 = from_json

# Generated at 2022-06-26 10:25:24.794696
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data_0 = {"not": {"type": "integer"}}
    field_0 = from_json_schema(data_0)
    assert isinstance(field_0, Not)
    assert not isinstance(field_0.negated, Integer)

    data_1 = {"type": "integer"}
    field_1 = from_json_schema(data_1)
    assert isinstance(field_1, Integer)
    assert not isinstance(field_1, Not)

    data_2 = {"not": {"type": "number"}}
    field_2 = from_json_schema(data_2)
    assert isinstance(field_2, Not)
    assert not isinstance(field_2.negated, Number)

    data_3 = {"type": "number"}
    field_3 = from_json_schema

# Generated at 2022-06-26 10:25:34.261394
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string = "array"
    allow_null = False
    data = {
        "type": type_string,
        "allow_null": allow_null,
        "items": {
            "$ref": "#/definitions/person"
        },
        "minItems": 2,
        "maxItems": None,
        "additionalItems": {
            "$ref": "#/definitions/pet"
        },
        "uniqueItems": True,
        "default": None,
    }
    definitions = SchemaDefinitions()
    definitions["pet"] = from_json_schema(data)
    ret_0 = from_json_schema_type(data, type_string, allow_null, definitions)

# Generated at 2022-06-26 10:25:39.337690
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    bool_0 = True
    field_0 = from_json_schema(bool_0)

    bool_1 = False
    field_1 = from_json_schema(bool_1)

    assert type(field_0) == type(field_1)
    assert field_0 != field_1


# Generated at 2022-06-26 10:25:49.926552
# Unit test for function from_json_schema
def test_from_json_schema():
    # input data
    bool_0 = True

# Generated at 2022-06-26 10:25:59.086308
# Unit test for function from_json_schema
def test_from_json_schema():
    import json
    with open("json_schema_tests.json", "r") as data_file:
        data = json.load(data_file)
    for test_case in data:
        data = test_case['data']
        result = test_case['result']
        field = from_json_schema(data)
        d = {'field': field, 'value': None, 'error': None}
        field.validate(**d)
        assert d['error'] == result['error'], "Error not equal"



# Generated at 2022-06-26 10:26:21.382734
# Unit test for function to_json_schema
def test_to_json_schema():
    
    # Here we are just testing that the function works with the provided example,
    # we could add further tests but it's not necessary for this task
    json_schema = to_json_schema(from_json_schema(schema_example))
    
    assert json_schema == schema_example
    
# Run unit tests
if __name__ == '__main__':
    test_case_0()
    test_to_json_schema()
    print("Success!")

# Generated at 2022-06-26 10:26:34.617422
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    print('Test from_json_schema_type:')
    # Case 0 
    try:
        schema0 = {"type": "string", "minLength": 5, "maxLength": 10}
        assert(isinstance(from_json_schema_type(schema0, 'string', False, None), String))
        print('Case 0: Pass')
    except:
        print('Case 0: Fail')
    # Case 1
    try:
        schema1 = {"type": "number", "minimum": 5, "maximum": 10}
        assert(isinstance(from_json_schema_type(schema1, 'number', False, None), Float))
        print('Case 1: Pass')
    except:
        print('Case 1: Fail')
    # Case 2

# Generated at 2022-06-26 10:26:39.809706
# Unit test for function to_json_schema
def test_to_json_schema():
    bool_0 = Boolean(allow_null = False, title = 'TrueOrFalse', description = 'Boolean field', default = True)
    dict_0 = to_json_schema(bool_0)
    bool_1 = bool_0.make_validator()
    dict_1 = to_json_schema(bool_1)
    assert dict_0 == dict_1 == {"type": "boolean", "title": "TrueOrFalse", "description": "Boolean field", "default": True}

    bool_2 = Boolean(allow_null = True, title = 'TrueOrFalse', description = 'Boolean field', default = True)
    dict_2 = to_json_schema(bool_2)
    bool_3 = bool_2.make_validator()

# Generated at 2022-06-26 10:26:46.500886
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    bool_0 = True
    test_data_0 = {
      "if": {
        "const": true
      },
      "then": {
        "const": false
      }
    }
    definitions = SchemaDefinitions()
    assert not_from_json_schema(test_data_0, definitions) ==  IfThenElse(IfThenElse(Const(True), Const(False), None))



# Generated at 2022-06-26 10:26:49.665683
# Unit test for function to_json_schema
def test_to_json_schema():
    # Validate that the type of arg is: typing.Union[Field, typing.Type[Schema]]
    arg = None
    _definitions = None
    result = to_json_schema(arg, _definitions)
    assert result is not None, "Function `to_json_schema` returned None."



# Generated at 2022-06-26 10:26:51.189458
# Unit test for function to_json_schema
def test_to_json_schema():
    output_json_schema = to_json_schema(bool_0)
    assert output_json_schema == True
 

# Generated at 2022-06-26 10:27:02.038444
# Unit test for function from_json_schema
def test_from_json_schema():

    defn_0 = False
    defn_1 = True
    defn_2 = Any()
    defn_3 = {
        "custom": {"$ref": "#/definitions/object_1"},
        "definitions": {"object_1": {"properties": {"foo": {"type": "integer"}}}},
    }
    defn_4 = Integer()
    defn_5 = {
        "type": "object",
        "properties": {"foo": {"type": "integer"}},
    }
    defn_6 = {
        "type": ["integer", "string"],
    }
    defn_7 = {
        "enum": [1, 2, 3],
    }

# Generated at 2022-06-26 10:27:08.343261
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Test case 2
    data = {'type': 'string', 'enum': ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'], 'pattern': '^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)$'}
    definitions = SchemaDefinitions()
    assert type_from_json_schema(data, definitions).validate(True) == True

    # Test case 3
    data = {'type': 'array', 'items': [{'type': 'integer'}, {'type': 'string'}, {'$ref': '#/definitions/Date'}]}
    definitions = SchemaDefinitions()
    assert type_from_json_schema(data, definitions).validate(True) == True

    # Test case 4

# Generated at 2022-06-26 10:27:21.255277
# Unit test for function from_json_schema

# Generated at 2022-06-26 10:27:26.613567
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data_0 = {}
    definitions_0 = {}
    field_0 = if_then_else_from_json_schema(data_0, definitions_0)
    bool_0 = field_0 is Any
    bool_1 = field_0.default != NO_DEFAULT
    bool_2 = not field_0.allow_null
    assert(bool_0) == True
    assert(bool_1) == True
    assert(bool_2) == True


# Generated at 2022-06-26 10:28:03.608859
# Unit test for function from_json_schema
def test_from_json_schema():
    bool_0 = True
    bool_1 = False
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_

# Generated at 2022-06-26 10:28:06.757007
# Unit test for function to_json_schema
def test_to_json_schema():
    test_field = Boolean()
    test_result = to_json_schema(test_field)
    print(type(test_result))
    assert_equals(test_result,{"type": "boolean", "default": NO_DEFAULT})


# Generated at 2022-06-26 10:28:16.523668
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Check if function can handle integers
    assert isinstance(from_json_schema_type({"type": "integer"}, type_string="integer", allow_null=False, definitions=definitions), Integer)
    # Check if function can handle floats
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="number", allow_null=False, definitions=definitions), Float)
    # Check if function can handle strings
    assert isinstance(from_json_schema_type({"type": "string"}, type_string="string", allow_null=False, definitions=definitions), String)
    # Check if function can handle booleans
    assert isinstance(from_json_schema_type({"type": "boolean"}, type_string="boolean", allow_null=False, definitions=definitions), Boolean)

# Generated at 2022-06-26 10:28:24.075398
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    obj_0 = JSONSchema("""
{"if": {"const": 4}, "then": {"const": 5}, "default": 7}
""")
    obj_1: Field = if_then_else_from_json_schema(obj_0, None)
    assert obj_1.validate(4) == 5


# Function to check if two JSONSchemas are equal

# Generated at 2022-06-26 10:28:30.226462
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Setup
    data = {"if": {}, "then": {}, "else": {}}

    definitions = SchemaDefinitions()

    # Test
    result = if_then_else_from_json_schema(data, definitions)

    # Verify
    assert isinstance(result, IfThenElse)
    assert result.if_clause == Any()
    assert result.then_clause == Any()
    assert result.else_clause == Any()
    assert result.default is NO_DEFAULT

# Generated at 2022-06-26 10:28:48.696915
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data_0 = {
        'type': 'integer',
        'maximum': 150,
        'exclusiveMaximum': True,
        'multipleOf': 3,
    }
    def is_valid(field):
        return isinstance(field, Integer)
    expected_0 = is_valid
    actual_0 = is_valid(type_from_json_schema(data_0, {}))
    assert actual_0 == expected_0
    data_1 = {
        'type': 'integer',
        'maximum': 150,
        'exclusiveMaximum': True,
        'multipleOf': 3,
    }
    def is_valid(field):
        return isinstance(field, Integer)
    expected_1 = is_valid
    actual_1 = is_valid(type_from_json_schema(data_1, {}))
   

# Generated at 2022-06-26 10:29:02.810649
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # String provided as 'type_string' (type: str)
    with pytest.raises(AssertionError):
        if_then_else_from_json_schema("string")
    # Boolean provided as 'type_string' (type: bool)
    with pytest.raises(AssertionError):
        if_then_else_from_json_schema(False)
    # Integer provided as 'type_string' (type: int)
    with pytest.raises(AssertionError):
        if_then_else_from_json_schema(int(0))
    # Float provided as 'type_string' (type: float)
    with pytest.raises(AssertionError):
        if_then_else_from_json_schema(0.0)
    # List provided as 'type

# Generated at 2022-06-26 10:29:05.954762
# Unit test for function to_json_schema
def test_to_json_schema():
    result = to_json_schema(bool_0)
    assert result == True



# Generated at 2022-06-26 10:29:07.999582
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(bool_0) == True


# Generated at 2022-06-26 10:29:16.440427
# Unit test for function type_from_json_schema
def test_type_from_json_schema():

    # Test field
    bool_0 = True
    dict_0 = {"type": "boolean"}
    dict_1 = {"type": "number"}
    dict_2 = {"type": "integer"}
    dict_3 = {"type": "string"}
    dict_4 = {"type": "object"}
    dict_5 = {"type": "array"}

    # Test constant
    dict_6 = {"type": "boolean", "const": True}
    dict_7 = {"type": "number", "const": 0.0}
    dict_8 = {"type": "integer", "const": 0}
    dict_9 = {"type": "string", "const": "0"}
    dict_10 = {"type": "object", "const": {}}
    dict_11 = {"type": "array", "const": []}

    # Test

# Generated at 2022-06-26 10:29:40.563695
# Unit test for function from_json_schema
def test_from_json_schema():
    data_0 = True
    definitions_0 = SchemaDefinitions()
    result_0 = from_json_schema(data_0,definitions_0)
    assert result_0 == Any()

    data_1 = False
    definitions_1 = SchemaDefinitions()
    result_1 = from_json_schema(data_1,definitions_1)
    assert result_1 == NeverMatch()

    data_2 = {"type": "null"}
    definitions_2 = SchemaDefinitions()
    result_2 = from_json_schema(data_2,definitions_2)
    assert result_2 == None

    data_3 = {"type": "integer", "maximum": 10}
    definitions_3 = SchemaDefinitions()

# Generated at 2022-06-26 10:29:42.522651
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Place your statements here
    bool_0 = True
    
    


# Generated at 2022-06-26 10:29:45.324940
# Unit test for function to_json_schema
def test_to_json_schema():
    bool_0 = to_json_schema(Any())

    assert bool_0 == True


# Generated at 2022-06-26 10:29:53.102427
# Unit test for function to_json_schema
def test_to_json_schema():
    val_arg_0 = test_case_0()
    expect_val_ret_0 = test_case_0()
    val_ret_0 = to_json_schema(val_arg_0)
    # Check return value
    assert val_ret_0 == expect_val_ret_0


# Generated at 2022-06-26 10:29:59.338181
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data_0 = {}
    definitions_0 =  {}
    assert type_from_json_schema(data_0, definitions_0) == Any()
    data_1 = {}
    definitions_1 =  {}
    assert type_from_json_schema(data_1, definitions_1) == Any()
    data_2 = {}
    definitions_2 =  {}
    assert type_from_json_schema(data_2, definitions_2) == Any()
    data_3 = {}
    definitions_3 =  {}
    assert type_from_json_schema(data_3, definitions_3) == Any()
    data_4 = {}
    definitions_4 =  {}
    assert type_from_json_schema(data_4, definitions_4) == Any()
    data_5 = {}
    definitions

# Generated at 2022-06-26 10:30:07.969863
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    print("Testing function from_json_schema_type")
    assert from_json_schema_type({'type': 'number'}, 'number', False, {}) is not None, "Should not be None"
    assert from_json_schema_type({'type': 'number'}, 'integer', False, {}) is not None, "Should not be None"
    assert from_json_schema_type({'type': 'number'}, 'string', False, {}) is not None, "Should not be None"
    assert from_json_schema_type({'type': 'number'}, 'boolean', False, {}) is not None, "Should not be None"
    assert from_json_schema_type({'type': 'number'}, 'array', False, {}) is not None, "Should not be None"

# Generated at 2022-06-26 10:30:19.422105
# Unit test for function to_json_schema
def test_to_json_schema():
    bool_0 = True
    assert to_json_schema(bool_0) == True
    bool_1 = False
    assert to_json_schema(bool_1) == False

    int_0 = Integer(description="description")
    assert to_json_schema(int_0) == {'type': 'integer', 'description': 'description'}

    int_1 = Integer(description="description", default=5)
    assert to_json_schema(int_1) == {
                                            'default': 5,
                                            'type': 'integer',
                                            'description': 'description'
                                    }

    str_0 = String(description="description")
    assert to_json_schema(str_0) == {'type': 'string', 'description': 'description'}

    str_1 = String