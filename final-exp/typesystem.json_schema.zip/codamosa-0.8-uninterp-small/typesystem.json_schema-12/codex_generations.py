

# Generated at 2022-06-26 10:20:56.793532
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Run the tests
    field_0 = None
    field_0 = Not(negated=field_0, default=NO_DEFAULT)
    dict_0 = get_standard_properties(field_0)

    field_1 = None
    field_1 = Object(properties=field_1, default=NO_DEFAULT)
    field_1 = Not(negated=field_1, default=NO_DEFAULT)
    dict_1 = get_standard_properties(field_1)

    assert dict_0 == {'default': None, '__repr__': 'Not(negated=None)', '__str__': 'Not(negated=None)'}

# Generated at 2022-06-26 10:21:01.034848
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    field_0 = Reference("")
    dict_0 = {"$ref":""}
    assert ref_from_json_schema(dict_0) == field_0


# Generated at 2022-06-26 10:21:03.447083
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    pass


# Generated at 2022-06-26 10:21:09.887563
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field = AllOf([Any()])
    field_dict = {
        'allOf': [{'type': 'any'}],
    }
    assert check_methods(field, field_dict, 'all_of_from_json_schema')


# Generated at 2022-06-26 10:21:12.101797
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Test: Basic setup
    assert True


# Generated at 2022-06-26 10:21:22.008489
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    try:
        if_then_else_from_json_schema(None, None)
        assert False
    except Exception:
        assert True
    try:
        if_then_else_from_json_schema({"if": None, "then": None}, None)
        assert False
    except Exception:
        assert True
    try:
        if_then_else_from_json_schema({"if": {"enum": []}, "then": {"enum": []}}, None)
        assert False
    except Exception:
        assert True
    assert if_then_else_from_json_schema(
        {"if": {"enum": []}, "then": {"enum": []}, "default": True}, None
    ) != "Error"

# Generated at 2022-06-26 10:21:27.013144
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'array', 'items': {'type': 'number'}}, {'type': 'string'}], 'default': None}
    definitions = {}
    result = any_of_from_json_schema(data, definitions)
    source = field_to_source(result)
    assert source == 'Union(any_of = [Array(items = Float(allow_null = False), allow_null = False), String(allow_null = False)], allow_null = False, default = None)'


# Generated at 2022-06-26 10:21:32.642333
# Unit test for function to_json_schema
def test_to_json_schema():
    # String
    field = String(
        min_length=1,
        max_length=10,
        allow_blank=False,
        pattern_regex=re.compile("[A-Z]+"),
        format="url",
    )
    schema_0 = to_json_schema(field)
    schema_1 = to_json_schema(String)
    assert schema_0 == schema_1

    # Integer
    field = Integer(
        minimum=1,
        maximum=10,
        exclusive_minimum=False,
        exclusive_maximum=True,
        multiple_of=2,
    )
    schema_0 = to_json_schema(field)
    schema_1 = to_json_schema(Integer)
    assert schema_0 == schema_1

    # Float

# Generated at 2022-06-26 10:21:43.599573
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field_0 = Array(
        items=Reference("pet"), 
        additional_properties=False, 
        default='[{"name": "dog", "description": "Yellow dog"}, {"name": "cat"}]', 
        min_items=1
    )
    dict_0 = get_standard_properties(field_0)

    field_1 = Reference("pet")
    dict_1 = get_standard_properties(field_1)

    field_2 = Reference("user")
    dict_2 = get_standard_properties(field_2)

    field_3 = Array(
        items=Any(), 
        additional_properties=False, 
        default='[{"name": "dog", "description": "Yellow dog"}, {"name": "cat"}]', 
        min_items=1
    )
    dict_3 = get_

# Generated at 2022-06-26 10:21:51.351670
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0 = AllOf([])
    dict_0 = get_standard_properties(field_0)
    dict_1 = {'allOf': []}
    assert (dict_0==dict_1)
    field_1 = AllOf([])
    dict_2 = get_standard_properties(field_1, default=True)
    dict_3 = {'allOf': [], 'default': True}
    assert (dict_2==dict_3)
    field_2 = AllOf([Boolean(), Boolean(allow_null=True)])
    dict_4 = get_standard_properties(field_2)
    dict_5 = {'allOf': [{'type': ['boolean']}, {'type': ['boolean', 'null']}]}
    assert (dict_4==dict_5)

# Generated at 2022-06-26 10:22:14.914635
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data_0 = {
        "minimum": 12,
        "maximum": 15,
        "multipleOf": None,
        "exclusiveMinimum": None,
        "exclusiveMaximum": None,
        "default": NO_DEFAULT
    }
    type_string_0 = "number"
    allow_null_0 = False

    data_1 = {
        "minimum": 12,
        "maximum": 15,
        "multipleOf": None,
        "exclusiveMinimum": None,
        "exclusiveMaximum": None,
        "default": NO_DEFAULT
    }
    type_string_1 = "integer"
    allow_null_1 = False


# Generated at 2022-06-26 10:22:23.273011
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0 = AllOf(
        all_of=[
            Object(
                properties={
                    "foo": String(),
                }),
        ],
    )
    dict_0 = get_standard_properties(field_0)
    dict_1 = {
        "allOf": [
            {
                "properties": {
                    "foo": {"type": "string"},
                },
                "type": "object",
            },
        ],
        "type": "object",
    }
    assert dict_0 == dict_1



# Generated at 2022-06-26 10:22:27.152241
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {"allOf": [{"type": "string"}, {"maxLength": 1}]}
    field_0 = all_of_from_json_schema(dict_0, None)
    dict_1 = get_standard_properties(field_0)
    assert dict_1 == {"allow_null": False, "min_length": None, "max_length": 1}



# Generated at 2022-06-26 10:22:28.722365
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field_0 = OneOf({"a", "b"})
    assert is_equal(
        one_of_from_json_schema(field_0.dict(), None),
        field_0,
    )



# Generated at 2022-06-26 10:22:37.533238
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Case 0:
    field_0 = None
    data_0 = get_standard_properties(field_0)
    data_0["if"] = {
        "type": ["string", "boolean"],
        "enum": ["a", "b"],
        "const": "a",
    }
    data_0["then"] = {
        "type": ["string", "boolean"],
        "enum": ["a", "b"],
        "const": "a",
    }
    data_0["else"] = {
        "type": ["string", "boolean"],
        "enum": ["a", "b"],
        "const": "a",
    }

# Generated at 2022-06-26 10:22:44.080047
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0 = AllOf(items=[Integer(),String()], default=42)
    field_1 = AllOf(items=[Integer(),String()], default=42)
    definitions_0 = None
    data_0 = get_standard_properties(field_0) 
    data_0["allOf"] = [get_standard_properties(field_1), get_standard_properties(field_1)]
    ans = all_of_from_json_schema(data_0, definitions_0)
    assert ans == field_0


# Generated at 2022-06-26 10:22:50.517743
# Unit test for function not_from_json_schema
def test_not_from_json_schema():

    # test case 0
    dict_0 = {"type": "string", "maximum": 10, "default": "Hello world!"}
    field_0 = from_json_schema(dict_0)
    field_1 = from_json_schema({"not": dict_0})
    assert field_1.negated == field_0


# Generated at 2022-06-26 10:23:02.381727
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    field_0 = String(format='string_format')
    dict_0 = get_standard_properties(field_0)
    dict_0['format'] = 'string_format'
    assert dict_0 == ref_from_json_schema(field_0.to_json_schema(), SchemaDefinitions())

    field_1 = String(format='string_format', allow_blank=True)
    dict_1 = get_standard_properties(field_1)
    dict_1['format'] = 'string_format'
    assert dict_1 == ref_from_json_schema(field_1.to_json_schema(), SchemaDefinitions())

    field_2 = String(format='string_format', allow_blank=False)
    dict_2 = get_standard_properties(field_2)

# Generated at 2022-06-26 10:23:14.301658
# Unit test for function to_json_schema
def test_to_json_schema():

    # Test for function get_standard_properties
    test_case_0()

    from __builtin__ import str
    
    from metadsl import *
    
    from .types import Int, Float
    
    from .string import FormattedString, PatternString, LengthString
    
    from .boolean import Boolean
    
    from .array import Array, AnyArray
    
    from .choice import Choice
    
    from .dsl import AllOf
    
    from .number import Number
    
    from .object import Object, AnyObject
    
    from .one_of import OneOf
    
    from .reference import Reference
    
    from .union import Union
    

# Generated at 2022-06-26 10:23:25.589202
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Testing if the function returns correct field object
    field_0 = None
    dict_0 = get_standard_properties(field_0)
    assert is_instance_of_field(enum_from_json_schema(dict_0))
    field_1 = Choice()
    dict_1 = get_standard_properties(field_1)
    assert is_instance_of_field(enum_from_json_schema(dict_1))
    # Testing if the function returns correct field object with allow_null
    assert is_instance_of_field(enum_from_json_schema(dict_1, True))
    # Testing if the function returns correct field object with enum
    field_2 = Choice(enum=['value'])
    dict_2 = get_standard_properties(field_2)
    assert is_instance_of_field

# Generated at 2022-06-26 10:24:10.387009
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    Test for to_json_schema
    """
    input_0 = {"allow_null": True}
    input_1 = Any()
    input_2 = Integer(allow_null=True)
    input_3 = Choice(choices=[(1, 1), (2, 2)], allow_null=False)
    input_4 = Object(allow_null=True)
    input_5 = Object(allow_null=True, properties={"key0": String()})
    input_6 = Object(allow_null=True, properties={"key0": String()}, required=["key0"])
    input_7 = Object(allow_null=True, properties={"key0": String()}, required=[])
    input_8 = Object(allow_null=True, properties={"key0": String()}, required=None)


# Generated at 2022-06-26 10:24:17.365257
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {'type': 'object'}

    assert isinstance(
        from_json_schema_type(
            data, type_string='number', allow_null=False, definitions=None),
        Float)

    assert isinstance(
        from_json_schema_type(
            data, type_string='integer', allow_null=False, definitions=None),
        Integer)

    assert isinstance(
        from_json_schema_type(
            data, type_string='string', allow_null=False, definitions=None),
        String)

    assert isinstance(
        from_json_schema_type(
            data, type_string='boolean', allow_null=False, definitions=None),
        Boolean)


# Generated at 2022-06-26 10:24:21.827107
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {"enum": [1, 2, 3], "default": 3}
    fields = enum_from_json_schema(data, definitions)
    # compare field's enums against dict's enum value
    assert fields.choices == data["enum"]



# Generated at 2022-06-26 10:24:34.132961
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema_0 = {"if": {"type": "object"}, "then": {"type": "object"}}
    kwargs_0 = {"if_clause": Object(), "then_clause": Object(allow_null=False)}
    field_0 = IfThenElse(**kwargs_0)
    dict_0 = get_standard_properties(field_0)
    if_then_else_0 = if_then_else_from_json_schema(json_schema_0, None)
    dict_1 = get_standard_properties(if_then_else_0)

    assert dict_0 == dict_1


# Generated at 2022-06-26 10:24:42.465647
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const" : 5, "default" : NO_DEFAULT}
    defs = SchemaDefinitions()
    const_field = const_from_json_schema(data, defs)
    assert isinstance(const_field, Const)
    assert const_field.const == 5

# Test case for const_ranges
# Because Ranges are not supported in JSON Schemas, there will be an error thrown
#def test_const_ranges():
#    data = {}
#    defs = SchemaDefinitions()
#    const_field = const_from_json_schema(data, defs)
#    assert isinstance(const_field, Const)
#    assert const_field.const_range == None


# Generated at 2022-06-26 10:24:50.742624
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field_0 = Any()
    field_1 = Integer(no_default=True)
    field_2 = Integer(minimum=1,no_default=True)
    json_schema_0 = to_json_schema(field_0)
    json_schema_1 = to_json_schema(field_1)
    json_schema_2 = to_json_schema(field_2)
    assert field_0 == type_from_json_schema(json_schema_0)
    assert field_1 == type_from_json_schema(json_schema_1)
    assert field_2 == type_from_json_schema(json_schema_2)


# Generated at 2022-06-26 10:25:02.435801
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": [
            "a",
            False,
            [1, 2, 3],
            {4: "4", 5: "5"},
        ],
        "default": [1, 2, 3, 4],
    }
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions=definitions)
    assert field.constraint == (["a", False, [1, 2, 3], {4: "4", 5: "5"}], [1, 2, 3, 4])
    data = {
        "const": None,
        "default": constant.DEFAULT,
    }
    field = const_from_json_schema(data, definitions=definitions)
    assert field.constraint == (constant.DEFAULT,)

# Generated at 2022-06-26 10:25:09.679122
# Unit test for function to_json_schema
def test_to_json_schema():
    for v in generate_test_values():
        f = make_test_field(v)
        schema = to_json_schema(f)

        assert isinstance(schema, dict)
        assert set(schema.keys()) == {"type", "default"}
        assert schema["type"] == "string"
        assert schema["default"] == v


# Generated at 2022-06-26 10:25:16.963106
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "bar": {
                        "type": "integer",
                        "minimum": 0,
                        "maximum": 10,
                        "exclusiveMaximum": True,
                    }
                },
            },
            {
                "type": "number",
                "minimum": 5,
                "maximum": 10,
                "exclusiveMaximum": True,
            },
        ]
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert isinstance(field, OneOf)
    assert isinstance(field.one_of[0], Object)
    assert isinstance(field.one_of[1], Number)



# Generated at 2022-06-26 10:25:24.662643
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema_0 = {'type': 'string', 'minLength': 0, 'maxLength': 0, 'format': '', 'pattern': None,
                'default': NO_DEFAULT}
    field_0 = from_json_schema(schema_0)
    schema_1 = {'type': 'number', 'minimum': None, 'maximum': None, 'exclusiveMinimum': None, 'exclusiveMaximum': None,
                'multipleOf': None, 'default': NO_DEFAULT}
    field_1 = from_json_schema(schema_1)
    schema_2 = {'type': 'integer', 'minimum': None, 'maximum': None, 'exclusiveMinimum': None, 'exclusiveMaximum': None,
                'multipleOf': None, 'default': NO_DEFAULT}

# Generated at 2022-06-26 10:26:21.041596
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(schema_definitions_0) == {
        "definitions": {
            "StringDefaults": {
                "type": "string",
                "minLength": 1,
                "maxLength": 10,
                "pattern": "^[a-z]*$",
                "format": "date-time",
            }
        }
    }


if __name__ == "__main__":
    import typing
    import json
    from typesystem import fields
    from typesystem import types
    from typesystem import validators
    from typesystem import schemas
    from typesystem.validators import *

    schema_definitions_0 = schemas.SchemaDefinitions()
    test_case_0()
    test_to_json_schema()

# Generated at 2022-06-26 10:26:31.661467
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_definitions_0 = module_0.SchemaDefinitions()
    var_0 = to_json_schema(schema_definitions_0)
    var_1 = {"$ref": "#/definitions/JSONSchema"}
    var_2 = ref_from_json_schema(var_1, schema_definitions_0)
    assert type(var_2) == type(var_0)
    assert var_2 == var_0


# Generated at 2022-06-26 10:26:40.200199
# Unit test for function to_json_schema
def test_to_json_schema():
    # Set up test data
    schema_definitions = module_0.SchemaDefinitions()
    # Execute function under test
    var = to_json_schema(schema_definitions)
    # Check result
    assert var == {}



# Generated at 2022-06-26 10:26:49.603549
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test case where data is not of type <dict>
    # TypeError: isinstance() arg 2 must be a type or tuple of types
    try:
        enum_from_json_schema([], None)
    except TypeError as error:
        assert error.args[0] == "isinstance() arg 2 must be a type or tuple of types"
    # Test case where definitions is not of type <SchemaDefinitions>
    # TypeError: isinstance() arg 2 must be a type or tuple of types
    try:
        enum_from_json_schema({}, None)
    except TypeError as error:
        assert error.args[0] == "isinstance() arg 2 must be a type or tuple of types"
    # Test case where data.get("enum") is not of type <list>
    # TypeError: isinstance() arg

# Generated at 2022-06-26 10:26:58.135062
# Unit test for function enum_from_json_schema

# Generated at 2022-06-26 10:27:10.320087
# Unit test for function from_json_schema
def test_from_json_schema():

    # Test without definitions
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()

    # Test with definitions
    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema

    # TODO: test for JSONSchema



# Generated at 2022-06-26 10:27:21.968835
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    import jsonschema

    schema_definitions_0 = module_0.SchemaDefinitions()
    var_1 = module_0.IfThenElse(
        if_clause=module_0.Integer(allow_null=True, minimum=1, maximum=3),
        then_clause=module_0.Integer(allow_null=True, minimum=1, maximum=3),
        else_clause=module_0.Integer(allow_null=True, minimum=1, maximum=3),
    )
    var_0 = to_json_schema(var_1, definitions=schema_definitions_0)
    var_2 = from_json_schema(var_0, definitions=schema_definitions_0)

# Generated at 2022-06-26 10:27:22.472610
# Unit test for function to_json_schema
def test_to_json_schema():
    pass

# Generated at 2022-06-26 10:27:29.452740
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Case 1
    # Input:
    data = {"type": ""}
    definitions = SchemaDefinitions()

    # Expected output:
    expected_output = Any()

    # Actual output:
    actual_output = type_from_json_schema(data=data, definitions=definitions)

    # Compare outputs:
    assert actual_output == expected_output


# Generated at 2022-06-26 10:27:38.200527
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema_definitions_0 = module_0.SchemaDefinitions()
    var_0 = to_json_schema(schema_definitions_0)
    data_0 = {
        'id': '#',
        '$schema': 'http://json-schema.org/draft-07/schema#',
        'type': 'object',
        'properties': {
            'foo': {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'properties': {
                        'bar': {
                            'type': 'integer',
                            'minimum': 0,
                            'maximum': 100
                        }
                    }
                }
            }
        }
    }
    var_0 = to_json_schema(schema_definitions_0)
    var_

# Generated at 2022-06-26 10:28:19.339866
# Unit test for function to_json_schema
def test_to_json_schema():
    # Check that the function properly fails with an invalid type
    test_schema_0: typing.Union[Field, typing.Type[Schema]] = Field
    try:
        to_json_schema(test_schema_0)
    except TypeError:
        pass
    else:
        assert False, "Expected an exception."  # pragma: no cover

    # Check that the function properly fails with an invalid type
    test_schema_1: typing.Union[Field, typing.Type[Schema]] = Field
    try:
        to_json_schema(test_schema_1)
    except TypeError:
        pass
    else:
        assert False, "Expected an exception."  # pragma: no cover

    # Check that the function properly fails with an invalid type

# Generated at 2022-06-26 10:28:30.529748
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test SchemaDefinitions
    schema_definitions_0 = module_0.SchemaDefinitions()
    assert isinstance(schema_definitions_0, module_0.SchemaDefinitions)
    schema_definitions_0.clear()
    var_0 = schema_definitions_0.get("SomeKey", None)
    assert var_0 is None
    schema_definitions_0["SomeKey"] = module_0.String(name="SomeKey")
    var_1 = schema_definitions_0.get("SomeKey", None)
    assert isinstance(var_1, module_0.String)
    var_2 = schema_definitions_0.get("Somekey", None)
    assert var_2 is None
    schema_definitions_0.pop("SomeKey", None)
    var_3 = schema_

# Generated at 2022-06-26 10:28:38.616858
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test branches

    # Test return type
    assert isinstance(enum_from_json_schema(), typesystem.fields.Field)

    # Test function call
    try:
        enum_from_json_schema()
    except Exception as e:
        assert False



# Generated at 2022-06-26 10:28:46.751183
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema_definitions_0 = module_0.SchemaDefinitions()
    var_0 = to_json_schema(schema_definitions_0)
    assert var_0 == {"$id": "#", "definitions": {}}
    test_case_0()
    test_case_1()




# Generated at 2022-06-26 10:29:02.688715
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test if we can convert an empty schema definitions object to a JSON schema
    # dictionary.
    schema_definitions_0 = SchemaDefinitions()
    var_0 = to_json_schema(schema_definitions_0)
    assert var_0 == {}

    # Test if we can convert a single reference to a JSON schema dictionary.
    field_0 = Ref("my_type")
    var_1 = to_json_schema(field_0)
    assert var_1 == {"$ref": "#/definitions/my_type"}

    # Test if we can convert a single string field to a JSON schema dictionary.
    field_1 = String()
    var_2 = to_json_schema(field_1)
    assert var_2 == {"type": "string"}

    # Test if we can convert a string field with a

# Generated at 2022-06-26 10:29:12.191385
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.schemas import SchemaDefinitions

    definitions: typing.Dict[str, Field] = {}
    definitions["definitions"] = SchemaDefinitions(**definitions)


# Generated at 2022-06-26 10:29:18.779330
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test case where allow_null is False, type_string is "object", and value for "default" exists
    data_0 = {'default': {}}
    type_string_0 = "object"
    allow_null_0 = False
    definitions_0 = {}
    test_0 = from_json_schema_type(data_0, type_string_0, allow_null_0, definitions_0)
    field_0 = module_0.Object(allow_null=allow_null_0, default=data_0.get("default", NO_DEFAULT))
    assert field_0 == test_0
    # Test case where allow_null is False, type_string is "array", and value for "default" exists
    data_1 = {'default': [1, 2, 3]}

# Generated at 2022-06-26 10:29:24.086556
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {"enum": [1, 2, 3]}
    definitions_0 = {}
    field_0 = enum_from_json_schema(dict_0, definitions_0)


# Generated at 2022-06-26 10:29:29.886491
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem.fields import Choice
    from typesystem.schemas import SchemaDefinitions

    # Given
    data = {"enum": ["foo", "bar"]}

    # When
    field = enum_from_json_schema(data=data, definitions=SchemaDefinitions())

    # Then
    assert isinstance(field, Choice)
    expected_choices = [
        ("foo", "foo"),
        ("bar", "bar"),
    ]
    assert field.choices == expected_choices



# Generated at 2022-06-26 10:29:40.951018
# Unit test for function to_json_schema
def test_to_json_schema():
    schema_definitions_0 = module_0.SchemaDefinitions()

# Generated at 2022-06-26 10:30:06.479465
# Unit test for function from_json_schema
def test_from_json_schema():
    # Test function from_json_schema
    sample_json_schema_0_json = open("test/json/sample_json_schema_0.json", "r")
    sample_json_schema_0 = json.loads(sample_json_schema_0_json.read())
    assert isinstance(sample_json_schema_0, dict)
    sample_json_schema_0_json.close()
    field_0 = typesystem.from_json_schema(sample_json_schema_0)
    assert isinstance(field_0, typesystem.Schema) is True
    sample_json_schema_1_json = open("test/json/sample_json_schema_1.json", "r")

# Generated at 2022-06-26 10:30:18.747795
# Unit test for function from_json_schema
def test_from_json_schema():
    
    dict_0 = {}
    dict_1 = dict_0
    dict_1["$ref"] = None
    dict_1["type"] = None
    dict_1["enum"] = None
    dict_1["definitions"] = None
    dict_1["minLength"] = None
    dict_1["maxLength"] = None
    dict_1["pattern"] = None
    dict_1["format"] = None
    dict_1["minimum"] = None
    dict_1["maximum"] = None
    dict_1["exclusiveMinimum"] = None
    dict_1["exclusiveMaximum"] = None
    dict_1["multipleOf"] = None
    dict_1["properties"] = None
    dict_1["minProperties"] = None
    dict_1["maxProperties"] = None