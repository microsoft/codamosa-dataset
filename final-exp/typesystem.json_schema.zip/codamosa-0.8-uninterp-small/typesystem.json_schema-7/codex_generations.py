

# Generated at 2022-06-26 10:21:39.920002
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_1 = {
        "_id": "5e8f5e4792ea9b0018a391c5",
        "name": "Arlington County",
        "county": "Arlington",
        "state": "Virginia"
    }
    dict_2 = {
        "_id": "5e8f5e4792ea9b0018a391c5",
        "name": "Arlington County",
        "county": "Arlington",
        "state": "Virginia"
    }
    dict_3 = {
        "_id": "5e8f5e4792ea9b0018a391c5",
        "name": "Arlington County",
        "county": "Arlington",
        "state": "Virginia"
    }

# Generated at 2022-06-26 10:21:48.549776
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test 0
    data = {
        "definitions": {
            "data": {
                "type": "object",
                "properties": {
                    "a": {"type": "string"},
                    "b": {"type": "integer"},
                    "c": {"type": "boolean"},
                    "d": {"type": "null"},
                    "e": {"type": "array", "items": {"type": "string"}},
                    "f": {"type": "object", "properties": {"g": {"type": "number"}}},
                },
                "required": ["a", "b", "c"],
            }
        }
    }

    # Test 1
    type_string = "object"
    allow_null = False
    definitions = SchemaDefinitions()

# Generated at 2022-06-26 10:21:54.253292
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:22:04.792925
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {
        'oneOf': [{'type': 'number'}, {'type': 'number', 'minimum': 5}],
        'default': 5
    }
    field_0 = one_of_from_json_schema(dict_0, SchemaDefinitions())
    test_0 = field_0.validate(4)
    assert test_0.value == 4
    test_1 = field_0.validate(5)
    assert test_1.value == 5
    try:
        result_0 = field_0.validate(6)
    except ValidationError as error_0:
        assert error_0.detail == "must be one of [{'type': 'number'}, {'type': 'number', 'minimum': 5}]"


# Generated at 2022-06-26 10:22:11.706559
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {
            "type": "object",
            "required": ["username"],
            "properties": {
                "username": {"type": "string", "maxLength": 200},
                "password": {"type": "string", "maxLength": 200},
            },
            "additionalProperties": False,
        }
    field_0 = from_json_schema(dict_0)
    assert field_0.validate_schema()



# Generated at 2022-06-26 10:22:24.659094
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'items': {'type': ['boolean']}}
    field_0 = from_json_schema(dict_0)
    # Omit the function name 'any_of_from_json_schema' in the function call below
    assert field_0.validate(field_0.serialize(True))[0]
    dict_1 = {'items': {'enum': ['asdf']}}
    field_1 = from_json_schema(dict_1)
    assert field_1.validate(field_1.serialize('asdf'))[0]
    dict_2 = {'items': {'const': 'asdf'}}
    field_2 = from_json_schema(dict_2)
    assert field_2.validate(field_2.serialize('asdf'))

# Generated at 2022-06-26 10:22:32.640397
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': ['a', 'b', 'c']}
    field_0 = enum_from_json_schema(dict_0, definitions)
    assert field_0.validate('a') == ('a', None)
    assert field_0.validate('b') == ('b', None)
    assert field_0.validate('c') == ('c', None)
    assert field_0.validate('d') == (None, [{'type': 'choice', 'choices': [('a', 'a'), ('b', 'b'), ('c', 'c')]}])

    dict_1 = {'enum': ['a', 'b', 'c'], 'default': 'b'}
    field_1 = enum_from_json_schema(dict_1, definitions)
    assert field_1.valid

# Generated at 2022-06-26 10:22:39.820675
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    A = "{\"type\": \"string\"}"
    B = "{\"$ref\": \"#/definitions/A\",\"definitions\": {\"A\": "+ A +"}}"
    C = {'$ref': '#/definitions/A', 'definitions': {'A': {'type': 'string'}}}


# Generated at 2022-06-26 10:22:46.011474
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    field_0 = Field(default=NO_DEFAULT, if_clause=Any())
    field_1 = Field(
        default=NO_DEFAULT,
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any(),
    )


# Generated at 2022-06-26 10:22:52.091616
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"if": {"type": "string"}, "then": {"minLength": 5}}
    if_then_else = if_then_else_from_json_schema(data)
    result0 = if_then_else.validate("hello")
    result1 = if_then_else.validate(5)
    assert result0 == "hello"
    assert result1 == 5


# Generated at 2022-06-26 10:23:23.009951
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {"anyOf": "string"}
    field_0 = from_json_schema(dict_0)
    try:
        assert field_0.types[0] == (Union, {'any_of': [String], 'default': None, 'allow_null': False})
    except:
        print("Error: Expected type: Union")
        raise


# Generated at 2022-06-26 10:23:26.698545
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {'$ref': '#/definitions/0'}
    field_0 = ref_from_json_schema(dict_0)
    assert field_0.to == '#/definitions/0'


# Generated at 2022-06-26 10:23:37.910546
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "integer", "default": 0},
            {"type": "string", "default": ""},
        ],
    }
    expected_f0 = Integer(allow_null=False, default=0)
    expected_f1 = String(allow_null=False, default="")
    expected = Union(any_of=[expected_f0, expected_f1], allow_null=False, default="")
    expected_type = Union

    field = any_of_from_json_schema(data, definitions=None)
    assert type(field) == expected_type, "Test #0 failed"


# Generated at 2022-06-26 10:23:38.758526
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    result = True
    assert result


# Generated at 2022-06-26 10:23:44.450877
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {'$ref': '#/definitions/foo'}
    field_0 = ref_from_json_schema(dict_0)
    assert field_0 is not None


# Generated at 2022-06-26 10:23:49.822598
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_1 =  {"allOf": [{"$ref": "#/definitions/Person"}, {"$ref": "#/definitions/Author"}]}
    field_1 = all_of_from_json_schema(dict_1)




# Generated at 2022-06-26 10:23:56.451723
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {"allOf": [{"type": "string"}, {"type": "integer"}]}
    field_0 = from_json_schema(dict_0)
    print(field_0)


# Generated at 2022-06-26 10:24:11.116089
# Unit test for function from_json_schema_type
def test_from_json_schema_type():

    # type_string = 'number'
    data = {"type": ["number"], "allow_null": True, "minimum": 4, "maximum": 5}
    type_string = "number"
    allow_null = False
    field_0 = Number(allow_null=allow_null)

    assert field_0 == from_json_schema_type(data, type_string, allow_null, definitions)

    # type_string = 'integer'
    data = {
        "type": ["integer"],
        "allow_null": False,
        "minimum": 4,
        "maximum": 5,
        "exclusive_minimum": 6,
        "exclusive_maximum": 7,
        "multiple_of": 8,
    }
    type_string = "integer"
    allow_null = True


# Generated at 2022-06-26 10:24:17.751951
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:24:26.661279
# Unit test for function to_json_schema
def test_to_json_schema():
    # type: () -> None
    from arg_validate.schema import Schema
    from arg_validate.primitive import Integer, Array, Reference
    from arg_validate.control import IfThenElse, Const
    import json

# Generated at 2022-06-26 10:25:01.681177
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Testing if "$ref" in data
    if_then_else_from_json_schema({'$ref': '#/definitions/test1'}, SchemaDefinitions())
    if_then_else_from_json_schema({'$ref': '#/definitions/test2'}, SchemaDefinitions())
    # Testing if "$if" in data
    if_then_else_from_json_schema({'if': {}}, SchemaDefinitions())
    if_then_else_from_json_schema({'if': {'$ref': '#/definitions/test1'}}, SchemaDefinitions())
    if_then_else_from_json_schema({'if': {'type': 'string'}}, SchemaDefinitions())
    # Testing if "$then" in data
    if_then_

# Generated at 2022-06-26 10:25:13.757517
# Unit test for function ref_from_json_schema

# Generated at 2022-06-26 10:25:23.150657
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test cases
    data_field_0 = {
    'type': "integer",
    'minimum': 1,
    'maximum': 9,
    'exclusive_minimum': None,
    'exclusive_maximum': None,
    'multiple_of': None,
    'default': NO_DEFAULT,
    'allow_null': False
    }
    data_dict_0 = {
    'not': {
        'type': "integer",
        'minimum': 1,
        'maximum': 9
    }
    }

    # Test case

# Generated at 2022-06-26 10:25:28.266766
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    cases = [
        {"if": {"const": True}, "then": {"const": True}, "else": {"const": False}}
    ]

    for case in cases:
        field = if_then_else_from_json_schema(case)
        assert field.matches(True)
        assert not field.matches(False)



# Generated at 2022-06-26 10:25:36.176591
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:25:41.323048
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Arrange
    test_data = {"$ref": "1"}
    definitions = SchemaDefinitions()
    definitions["1"] = String()

    # Act
    result = ref_from_json_schema(test_data, definitions=definitions)

    # Assert
    assert isinstance(result, Field)
    assert isinstance(result, Reference)



# Generated at 2022-06-26 10:25:42.621959
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert True

## Unit test for function test_case_0

# Generated at 2022-06-26 10:25:54.682530
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {"type": "string"}
    type_0 = "string"
    allow_null_0 = False
    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema
    field_0 = from_json_schema_type(dict_0, type_0, allow_null_0, definitions=definitions)
    dict_1 = {"type": "number"}
    type_1 = "number"
    allow_null_1 = False
    field_1 = from_json_schema_type(dict_1, type_1, allow_null_1, definitions=definitions)
    dict_2 = {"type": "object"}
    type_2 = "object"
    allow_null_2 = False

# Generated at 2022-06-26 10:26:01.770808
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    # Setup test data
    data = {"$ref": '#/definitions/PhoneNumber'}
    reference_string = '#/definitions/PhoneNumber'
    definitions = {"#/definitions/PhoneNumber": String()}

    # Perform test
    result = ref_from_json_schema(data, definitions)
    assert isinstance(result, Reference)
    assert result.to == '#/definitions/PhoneNumber'


# Generated at 2022-06-26 10:26:12.766181
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {
            "const": True
        },
        "then": {
            "type": "string"
        },
        "else": {
            "const": False
        }
    }
    field = if_then_else_from_json_schema(schema, SchemaDefinitions())
    assert field.check(None) is False
    assert field.check(False) is False
    assert field.check(True) is False
    assert field.check(0) is False
    assert field.check(1) is False
    assert field.check(0.1) is False
    assert field.check("0.1") is False
    assert field.check([]) is False
    assert field.check([0]) is False
    assert field.check({}) is False

# Generated at 2022-06-26 10:26:52.802118
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {}
    field_0 = SchemaDefinitions(
        dict_0,
        additional_properties=Reference("JSONSchema", definitions=dict_0),
    )

    dict_1 = {
        "value": {
            "$ref": "#/definitions/OtherDefinition"
        },
        "definitions": {
            "OtherDefinition": True
        }
    }
    field_1 = SchemaDefinitions(
        dict_1,
        additional_properties=Reference("JSONSchema", definitions=dict_1)
    )

    field_2 = from_json_schema(dict_0)
    field_3 = from_json_schema(dict_1)
    assert field_2 == field_3

    obj1 = {"a": 1, "b": 2}

# Generated at 2022-06-26 10:26:58.350157
# Unit test for function to_json_schema
def test_to_json_schema():
    class ExampleSchema(Schema):
        name = String().min_length(1)
        age = Integer().minimum(0).multiple_of(2)

    example = {"name": "steve", "age": 1}
    example_errors = {"age": ["Must be a multiple of 2."]}

    json_schema = to_json_schema(ExampleSchema)
    assert json_schema == {
        "type": "object",
        "properties": {
            "name": {"type": "string", "minLength": 1},
            "age": {"type": "integer", "minimum": 0, "multipleOf": 2},
        },
        "required": ["name", "age"],
    }
    assert ExampleSchema().validate(example) == example

# Generated at 2022-06-26 10:27:09.580506
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Case 1
    dict_1 = {"if": {"type": "string", "$id": "/properties/id/if"}, "then": {"type": "string", "$id": "/properties/id/then"}, "else": {"type": "string", "$id": "/properties/id/else"}, "$id": "/properties/id", "$schema": "http://json-schema.org/draft-07/schema#"}
    field_1 = if_then_else_from_json_schema(dict_1)
    assert field_1 == IfThen(a=String(), b=String())


# Generated at 2022-06-26 10:27:17.398149
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {}
    field_0 = not_from_json_schema(dict_0)
    field_1 = not_from_json_schema(field_0)
    field_2 = not_from_json_schema(field_1)
    field_3 = not_from_json_schema(field_2)

test_case_0()
test_not_from_json_schema()

# Generated at 2022-06-26 10:27:28.056598
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():

    expected_0 = IfThenElse(
        if_clause=String(allow_null=True),
        then_clause=NeverMatch(allow_null=True),
        else_clause=NeverMatch(allow_null=True),
        default=NO_DEFAULT,
    )
    schema = {
        "if": {"type": "string", "minLength": 1},
        "then": {"type": "string", "minLength": 5},
        "else": {"type": "string", "minLength": 10},
    }

    actual_0 = if_then_else_from_json_schema(schema)
    assert actual_0 == expected_0


# Generated at 2022-06-26 10:27:37.543938
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {
        "if": {
            "type": "number",
            "minimum": 3,
            "maximum": 6
        },
        "then": {
            "type": "number",
            "minimum": 10,
            "maximum": 15,
        },
        "else": {
            "type": "number",
            "minimum": 20,
            "maximum": 25
        }
    }
    field_0 = if_then_else_from_json_schema(dict_0)
    # Check the type of field_0
    assert isinstance(field_0, IfThenElse)
    # Check the value of field_0.if_clause
    assert isinstance(field_0.if_clause, AllOf)

# Generated at 2022-06-26 10:27:42.789058
# Unit test for function to_json_schema
def test_to_json_schema():
    name: Field = String(max_length=100, default="test")
    age: Field = Integer(minimum=0)
    person: Field = Object(properties={"name": name, "age": age})
    json_schema = to_json_schema(person)
    assert json_schema == {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "maxLength": 100,
                "default": "test",
            },
            "age": {
                "type": "integer",
                "minimum": 0,
            },
        },
        "required": ["name", "age"],
    }

# Generated at 2022-06-26 10:27:47.181494
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    dict_0 = {}
    field_0 = from_json_schema(dict_0)
    assert type(field_0) is Any


# Generated at 2022-06-26 10:27:48.952408
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert True == True



# Generated at 2022-06-26 10:28:03.445019
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test the Any type
    str_0 = to_json_schema(Any())
    assert(str_0 == True)

    # Test the NeverMatch type
    str_1 = to_json_schema(NeverMatch())
    assert(str_1 == False)

    # Test the String type with no arguments
    dict_0 = {"type": "string"}
    str_2 = to_json_schema(String())
    assert(str_2 == dict_0)

    # Test the String type with all arguments
    dict_1 = {"type": "string", "minLength": 1,
              "maxLength": 10, "pattern": "a*b", "format": "email"}

# Generated at 2022-06-26 10:28:24.539401
# Unit test for function to_json_schema
def test_to_json_schema():
    defn_0 = SchemaDefinitions()
    defn_0["key_0"] = Integer()
    test_0 = to_json_schema(defn_0)


# Generated at 2022-06-26 10:28:32.706389
# Unit test for function to_json_schema
def test_to_json_schema():
    json_0 = {'if': {}, 'then': {'const': 1234}}
    json_1 = {'if': {'$ref': '#/definitions/object_1'}, 'then': {'const': 1234}}
    json_2 = {'if': {'if': {}, 'then': {'const': 1234}}}
    json_3 = {'if': {'if': {'$ref': '#/definitions/object_1'}, 'then': {'const': 1234}}}
    # Test if the type of result is correct
    assert isinstance(json_0, dict)
    assert isinstance(json_1, dict)
    assert isinstance(json_2, dict)
    assert isinstance(json_3, dict)



# Generated at 2022-06-26 10:28:38.256259
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_1 = {'if': {'const': '0'}, 'then': {'const': '1'}, 'else': {'const': '2'}}
    field_1 = from_json_schema(dict_1)
    assert field_1.validate('0') == '1'
    assert field_1.validate('1') == '2'
    dict_2 = {'if': {'const': '0'}, 'then': {'const': '1'}}
    field_2 = from_json_schema(dict_2)
    assert field_2.validate('0') == '1'
    assert field_2.validate('1') == '1'
    dict_3 = {'if': {'const': '0'}}

# Generated at 2022-06-26 10:28:44.144013
# Unit test for function from_json_schema
def test_from_json_schema():
    print("Testing function from_json_schema...", end="")
    pass
    print("Passed.")


# Generated at 2022-06-26 10:28:46.755021
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema(), Field)
    assert not_from_json_schema() is not None

# Generated at 2022-06-26 10:29:02.690117
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_1 = {"type": "string"}
    field_1 = from_json_schema(dict_1)
    dict_2 = to_json_schema(field_1)
    assert dict_2 == dict_1

    dict_3 = {"type": ["string", "null"]}
    field_3 = from_json_schema(dict_3)
    dict_4 = to_json_schema(field_3)
    assert dict_4 == dict_3


# Generated at 2022-06-26 10:29:07.777331
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {"if": {}, "then": {}, "default": None}
    dict_1 = {"if": {}, "then": {"default": None}, "default": None}
    field_0 = from_json_schema(dict_0)
    field_1 = from_json_schema(dict_1)


# Generated at 2022-06-26 10:29:16.320637
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {
        "type": "object",
        "properties": {
            "fieldA": {
                "type": ["null", "string"],
                "default": "test"
            },
            "fieldB": {
                "type": "number",
                "minimum": 0
            }
        },
        "required": ["fieldB"]
    }
    field_0 = from_json_schema(dict_0)
    if to_json_schema(field_0) != dict_0:
        raise ValueError("test case 0 failed")


# Generated at 2022-06-26 10:29:26.193541
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'$schema': 'http://json-schema.org/draft-07/schema#', 'type': 'number', 'x-nullable': True, 'not': {'minimum': 1}}, definitions={}) == Not(negated=AllOf(all_of=[Float(allow_null=False, minimum=1, maximum=None, exclusive_minimum=None, exclusive_maximum=None, multiple_of=None, default=NO_DEFAULT)]))


# Generated at 2022-06-26 10:29:35.479346
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = """{
        "if": {"type": "integer"},
        "then": {"maximum": 100},
        "else": {"type": "string"}
    }"""
    data = json.loads(data)
    field = if_then_else_from_json_schema(data, None)
    assert isinstance(field, Field)


# Generated at 2022-06-26 10:30:11.432387
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = dict(type="string")
    dict_1 = dict(type="boolean")
    dict_2 = dict(type=["null", "string"])
    dict_3 = dict(enum=["foo", "bar", "baz"])
    dict_4 = dict(const="foo")
    dict_5 = dict(definitions=dict(foo=dict(type="string")))

# Generated at 2022-06-26 10:30:20.252263
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string = "object"
    allow_null = False
    definitions = SchemaDefinitions()
    data = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "address": {
                "type": "object",
                "properties": {"street_address": {"type": "string"}, "city": {"type": "string"}},
            },
        },
    }
    field_1 = from_json_schema_type(data, type_string, allow_null, definitions)
    assert isinstance(field_1, Object)
    assert field_1.allow_null == allow_null
    assert isinstance(field_1.properties["name"], String)
    assert isinstance(field_1.properties["address"], Object)