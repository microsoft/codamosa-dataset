

# Generated at 2022-06-26 10:21:25.761847
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {'allOf': [{'allOf': [{}, {}]}, {}]}
    schema_definitions_0 = None
    field_0 = all_of_from_json_schema(dict_0, schema_definitions_0)
    value_0 = field_0.is_valid(None)
    assert isinstance(value_0, bool)
    assert not value_0
    value_1 = field_0.is_valid(False)
    assert isinstance(value_1, bool)
    assert not value_1
    value_2 = field_0.is_valid(True)
    assert isinstance(value_2, bool)
    assert not value_2
    value_3 = field_0.is_valid('hello')
    assert isinstance(value_3, bool)

# Generated at 2022-06-26 10:21:37.133819
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
            {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                },
            },
        ]
    }
    schema_definitions_0 = None
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)

# Generated at 2022-06-26 10:21:46.460493
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test 1
    dict_0 = {"not": {"type": "boolean"}}
    schema_definitions_0 = None
    field_0 = not_from_json_schema(dict_0, schema_definitions_0)
    assert(isinstance(field_0, Not))
    assert(field_0.negated is not None)
    assert(field_0.default is None)

    # Test 2
    dict_0 = {"not": {"type": "string", "minLength": 0}}
    schema_definitions_0 = None
    field_0 = not_from_json_schema(dict_0, schema_definitions_0)
    assert(field_0.negated is not None)
    assert(field_0.default is None)

    # Test 3

# Generated at 2022-06-26 10:21:53.088962
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    import json
    with open("data_files/json_schema_enum.json") as json_data:
        schema_data = json.load(json_data)
        field_0 = ref_from_json_schema(schema_data, definitions)
    assert field_0.constraint == [4, 6]


# Generated at 2022-06-26 10:21:59.791891
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    value_0 = "#/definitions/integer"
    dict_0 = {"$ref": "#/definitions/integer"}
    field_0 = ref_from_json_schema(dict_0, definitions)
    assert field_0 == Integer(default=NO_DEFAULT, allow_null=True)
    assert isinstance(field_0._reference, Reference)


# Generated at 2022-06-26 10:22:08.071965
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'object', 'string', 'boolean', 'array', 'number'}, False)
    assert get_valid_types({'type': {'integer'}}) == ({'integer', 'string', 'boolean', 'array', 'number'}, False)
    assert get_valid_types({'type': {'integer', 'number'}}) == ({'integer', 'number'}, False)
    assert get_valid_types({'type': {'integer', 'number', 'null'}}) == ({'integer', 'number'}, True)




# Generated at 2022-06-26 10:22:14.466592
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    dict_0 = {"const": "c"}
    schema_definitions_0 = SchemaDefinitions()
    field_0 = const_from_json_schema(dict_0, schema_definitions_0)
    const_0 = field_0.const
    assert const_0 == "c"
    field_1 = const_from_json_schema({"const": 42}, SchemaDefinitions())
    assert field_1.const == 42
    field_2 = const_from_json_schema({"const": True}, SchemaDefinitions())
    assert field_2.const is True



# Generated at 2022-06-26 10:22:25.002792
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Test no type specified
    dict_0 = {}
    schema_definitions_0 = None
    field_0 = type_from_json_schema(dict_0, schema_definitions_0)

    # Test single type specified
    dict_0 = {'type': 'integer'}
    schema_definitions_0 = None
    field_0 = type_from_json_schema(dict_0, schema_definitions_0)

    # Test object type
    dict_0 = {'type': 'object'}
    schema_definitions_0 = None
    field_0 = type_from_json_schema(dict_0, schema_definitions_0)

    # Test object type with properties
    dict_0 = {'type': 'object', 'properties': {'a': {'type': 'integer'}}}


# Generated at 2022-06-26 10:22:35.166223
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert test_case_0() == {True: Const(None), False: NeverMatch()}[allow_null]

    # INPUT
    # (dict_1, schema_definitions_1) = ({'const': '123'}, SchemaDefinitions(Schema))
    # EXPECTED
    # {'const': '123', 'default': NO_DEFAULT}

    # INPUT
    # (dict_2, schema_definitions_2) = ({'const': '123'}, SchemaDefinitions(Schema))
    # EXPECTED
    # {'const': '123', 'default': NO_DEFAULT}

    # INPUT
    # (dict_3, schema_definitions_3) = ({'const': '123'}, SchemaDefinitions(Schema))
    # EXPECTED
    # {'const':

# Generated at 2022-06-26 10:22:40.917301
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    definitions = {}
    assert to_json_schema(String(), definitions) == {'type': 'string'}
    assert to_json_schema(Integer(), definitions) == {'type': 'integer'}
    assert to_json_schema(Float(), definitions) == {'type': 'number'}
    assert to_json_schema(Decimal(), definitions) == {'type': 'number'}
    assert to_json_schema(Boolean(), definitions) == {'type': 'boolean'}
    assert to_json_schema(Array(), definitions) == {'type': 'array'}
    assert to_json_schema(Object(), definitions) == {'type': 'object'}
   

# Generated at 2022-06-26 10:23:45.741079
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_definitions_object = SchemaDefinitions()
    schema_definitions_object["a"] = String()
    data_object = {"a": String()}
    reference_string_object = "#/a"
    ref_field_object = Reference(to=reference_string_object, definitions=schema_definitions_object)
    ref_field_res_object = ref_from_json_schema(data_object, schema_definitions_object)
    assert ref_field_res_object == ref_field_object

    schema_definitions_object = SchemaDefinitions()
    schema_definitions_object = {"a": String()}
    data_object = {"$ref": "#/a"}
    reference_string_object = "#/a"

# Generated at 2022-06-26 10:23:51.885965
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Setup
    data = {'enum':['a', 'b', 'c']}
    definitions = SchemaDefinitions()
    expected_result = Choice(choices=[('a', 'a'), ('b', 'b'), ('c', 'c')])

    # Exercise
    result = enum_from_json_schema(data, definitions)

    # Verify
    assert expected_result == result


# Generated at 2022-06-26 10:23:53.992657
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {"$ref": "#/definitions/A"}
    schema_definitions_0 = SchemaDefinitions()
    field_0 = ref_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:23:59.704818
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Check if correct work of function if no parameters
    dict_0 = {}
    schema_definitions_0 = None
    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)

    # Check if correct work of function if one parameter
    dict_1 = {'if': {}}
    schema_definitions_1 = None
    field_1 = if_then_else_from_json_schema(dict_1, schema_definitions_1)

    # Check if correct work of function if three parameters
    dict_2 = {'if': {}, 'then': {}, 'else': {}}
    schema_definitions_2 = None
    field_2 = if_then_else_from_json_schema(dict_2, schema_definitions_2)

# Generated at 2022-06-26 10:24:02.319968
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    pass
# Function case_enum_from_json_schema_0

# Generated at 2022-06-26 10:24:13.359101
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(Integer(default=12, allow_null=False),None)
    assert "type" in data
    assert "default" in data
    assert "type" == "integer"
    assert "default" == 12
    data["type"] = data["type"][0:1]
    assert data == {"type": "integer", "default": 12}

    data = to_json_schema(Boolean(default=True, allow_null=False),None)
    assert "type" in data
    assert "default" in data
    assert "type" == "boolean"
    assert "default" == True
    data["type"] = data["type"][0:1]
    assert data == {"type": "boolean", "default": True}


# Generated at 2022-06-26 10:24:22.405731
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {"type": "integer"}
    schema_definitions_0 = None
    field_0 = from_json_schema(dict_0, schema_definitions_0)
    assert isinstance(field_0, Field)
    assert field_0.__name__ == "Integer"
    assert field_0.required == True
    assert field_0.default == NO_DEFAULT
    assert field_0.constraints == {"minimum": 0, "exclusiveMinimum": True}
    assert isinstance(field_0.error, str)



# Generated at 2022-06-26 10:24:34.573845
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {
        "type": ["string", "null"],
        "default": None,
    }
    assert to_json_schema(Integer()) == {
        "type": ["integer", "null"],
        "default": None,
    }
    assert to_json_schema(Boolean()) == {
        "type": ["boolean", "null"],
        "default": None,
    }
    assert to_json_schema(Array()) == {
        "type": ["array", "null"],
        "default": None,
    }

# Generated at 2022-06-26 10:24:43.164378
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {
        "enum": [
            "a",
            "b",
            "c",
        ],
    }
    schema_definitions_0 = None
    field_0 = from_json_schema(dict_0, schema_definitions_0)
    dict_1 = {
        "properties": {
            "b": {
                "type": "integer",
                "minimum": 0,
                "exclusiveMinimum": True,
            },
            "c": {
                "type": "integer",
                "minimum": 0,
                "exclusiveMinimum": True,
            },
        },
    }
    schema_definitions_1 = None
    field_1 = from_json_schema(dict_1, schema_definitions_1)

# Generated at 2022-06-26 10:24:51.559905
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {}
    dict_1 = {'definitions': {'schema_0': {'title': 'schema_0_title_0'}, 'schema_1': {'title': 'schema_1_title_0'}, 'schema_2': {'title': 'schema_2_title_0'}}}
    dict_2 = {'definitions': {'schema_0': {'title': 'schema_0_title_0'}}, 'items': {'$ref': '#/definitions/schema_0'}}

# Generated at 2022-06-26 10:25:20.711543
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert type(any_of_from_json_schema({'anyOf': [1]}, {})) == Union



# Generated at 2022-06-26 10:25:31.766454
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {'$ref': '#/definitions/JSONSchema', 'definitions': {'JSONSchema': {'$ref': '#/definitions/JSONSchema', 'type': 'boolean'}}}
    schema_definitions_0 = None
    field_0 = from_json_schema(dict_0, schema_definitions_0)
    assert field_0 is not None
    assert isinstance(field_0, Boolean)

    dict_1 = {'$ref': '#/definitions/JSONSchema'}
    schema_definitions_1 = None
    field_1 = from_json_schema(dict_1, schema_definitions_1)
    assert isinstance(field_1, Reference)
    assert isinstance(field_1, Reference)
    assert not field_1.required
   

# Generated at 2022-06-26 10:25:37.348371
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {
        'definitions': {
            'test': {
                'type': 'object',
                 'properties': {
                     'foo': {'type': 'string'}
                }
            }
        }
    }
    definitions_0 = None
    data_0 = {'$ref': '#/definitions/test'}
    field_0 = ref_from_json_schema(data_0, definitions_0)
    assert field_0.__class__.__name__ == 'Reference'
    assert field_0.__dict__ == {'to': '#/definitions/test', 'definitions': None}



# Generated at 2022-06-26 10:25:45.233829
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'default': {}, 'anyOf': []}
    schema_definitions_0 = None
    field_0 = any_of_from_json_schema(dict_0, schema_definitions_0)
    assert field_0.name == 'Union'
    assert field_0.required == True
    assert field_0.allow_null == False
    assert field_0.default == {}
    assert field_0.any_of == []
    assert field_0.children == []
    assert field_0.description == ''
    assert field_0.error_messages == {}
    assert field_0.name == 'Union'
    assert field_0.required == True
    assert field_0.allow_null == False
    assert field_0.default == {}

# Generated at 2022-06-26 10:25:57.989345
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    kwargs_0 = {}
    kwargs_1 = {'type_string': 'number'}
    kwargs_2 = {'type_string': 'integer'}
    kwargs_3 = {'type_string': 'string'}
    kwargs_4 = {'type_string': 'boolean'}
    kwargs_5 = {'type_string': 'object'}
    kwargs_6 = {'type_string': 'array'}

    # Load argument values
    arg_1 = 'number'
    arg_2 = True
    arg_3 = 'String'
    arg_4 = 'Boolean'
    arg_5 = 'Object'
    arg_6 = 'Array'

# Generated at 2022-06-26 10:26:09.222727
# Unit test for function to_json_schema
def test_to_json_schema():
    """A unit test for to_json_schema"""

    from .validators import Const, Integer, String, Boolean

    test_schema = Const(const="test")
    test_schema_json = to_json_schema(test_schema)
    assert test_schema_json == {"const": "test"}

    test_schema = String(allow_null=True, const="test")
    test_schema_json = to_json_schema(test_schema)
    assert test_schema_json == {"type": ["string", "null"], "const": "test"}

    test_schema = Integer(minimum=1, maximum=10)
    test_schema_json = to_json_schema(test_schema)

# Generated at 2022-06-26 10:26:22.293467
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    schema_definitions_0 = None
    field_0 = any_of_from_json_schema(dict_0, schema_definitions_0)
    field_1 = any_of_from_json_schema(dict_1, schema_definitions_0)
    field_2 = any_of_from_json_schema(dict_2, schema_definitions_0)
    field_3 = any_of_from_json_schema(dict_3, schema_definitions_0)
    assert field_0.__eq__(field_1) is true
    assert field_2.__eq__(field_3) is true


# Generated at 2022-06-26 10:26:27.411639
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {}
    schema_definitions_0 = None
    field_0 = any_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:26:37.438361
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {"type": "array", "items": "integer"}
    schema_definitions_0 = None
    field_0 = from_json_schema(dict_0, schema_definitions_0)
    dict_1 = {"type": "integer"}
    schema_definitions_1 = None
    field_1 = from_json_schema(dict_1, schema_definitions_1)
    dict_2 = {"type": "string"}
    schema_definitions_2 = None
    field_2 = from_json_schema(dict_2, schema_definitions_2)
    dict_3 = {"type": "number"}
    schema_definitions_3 = None
    field_3 = from_json_schema(dict_3, schema_definitions_3)

# Generated at 2022-06-26 10:26:48.937705
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {'if': {'type': "string", 'minLength': 1}, 'then': {'type': "string", 'minLength': 1}, 'else': {'type': "number", 'minimum': 1}}
    schema_definitions_0 = {"#/": {}}
    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)
    assert_equal(field_0.default, NO_DEFAULT)
    assert_equal(field_0.if_clause.allow_blank, False)
    assert_equal(field_0.if_clause.allow_null, True)
    assert_equal(field_0.if_clause.format, None)
    assert_equal(field_0.if_clause.max_length, None)
   

# Generated at 2022-06-26 10:27:37.166068
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    Test case for function to_json_schema
    """

    # Test Case #1
    arg_1 = {"const": 5}
    _definitions_1 = None
    expected_1 = const_from_json_schema(arg_1, _definitions_1)

    # Test Case #2
    arg_2 = {"$ref": "#/definitions/address_0"}
    _definitions_2 = {"address_0": {"type": ["object", {"ref": "#/definitions/address"}]}}
    expected_2 = ref_from_json_schema(arg_2, _definitions_2)

    # Test Case #3
    arg_3 = {"type": "string", "enum": ["a", "b", "c"]}
    _definitions_3 = None
    expected_3 = enum

# Generated at 2022-06-26 10:27:43.291948
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {}
    dict_0["type"] = ["integer", "null"]
    dict_0["const"] = 50
    field_0 = type_from_json_schema(dict_0)
    dict_0_ = to_json_schema(field_0)
    assert dict_0_["type"] == dict_0["type"]
    assert dict_0_["const"] == dict_0["const"]
    dict_1 = {}
    dict_1["type"] = ["object", "null"]
    dict_1["properties"] = {}
    dict_1["properties"]["my_dict_0"] = {}
    dict_1["properties"]["my_dict_0"]["type"] = ["number", "null"]
    dict_1["properties"]["my_dict_0"]["default"]

# Generated at 2022-06-26 10:27:57.528630
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:28:08.914153
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test with number
    dict_0 = {'type': 'number'}
    type_string_0 = 'number'
    allow_null_0 = False
    schema_definitions_0 = None
    field_0 = from_json_schema_type(dict_0, type_string_0, allow_null_0,
        schema_definitions_0)
    assert field_0.name == 'Float'
    assert field_0.allow_null == False
    assert field_0.minimum == None
    assert field_0.maximum == None
    assert field_0.exclusive_minimum == None
    assert field_0.exclusive_maximum == None
    assert field_0.multiple_of == None
    # Test with boolean
    dict_1 = {'type': 'boolean'}

# Generated at 2022-06-26 10:28:17.651339
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {"additionalItems": False, "additionalProperties": True, "boolean_schema": False, "contains": False, "dependencies": False, "exclusiveMaximum": False, "exclusiveMinimum": False, "items": False, "maxItems": False, "maxLength": False, "maxProperties": False, "maximum": False, "minItems": False, "minLength": False, "minProperties": False, "minimum": False, "multipleOf": False, "pattern": False, "patternProperties": False, "properties": False, "propertyNames": False, "required": False, "type": False, "uniqueItems": False}
    schema_definitions_0 = None
    field_0 = from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:28:29.538411
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True

    assert to_json_schema(NeverMatch()) == False

    reference_0 = Reference(to='#/definitions/abc', definitions={})
    schema_definitions_0 = None
    assert to_json_schema(reference_0, schema_definitions_0) == {
        '$ref': '#/definitions/abc'
    }

    string_0 = String(allow_null=False, min_length=0, max_length=7,
                      pattern_regex=None, format=None)
    assert to_json_schema(string_0) == {
        'type': 'string',
        'minLength': 0,
        'maxLength': 7,
    }


# Generated at 2022-06-26 10:28:37.064805
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {}
    json_schema = to_json_schema(dict_0)
    assert json_schema == {'type': 'object', 'properties': {}, 'additionalProperties': False, 'required': []}

# Generated at 2022-06-26 10:28:39.471572
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {}
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:28:52.046507
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = (
        {"definitions": {"string": {"anyOf": [{"type": "string"}, {"type": "null"}]}}}
    )
    type_string_0 = "string"
    allow_null_0 = True
    schema_definitions_0 = None
    field_0 = from_json_schema_type(dict_0, type_string_0, allow_null_0, schema_definitions_0)

# Generated at 2022-06-26 10:29:06.229667
# Unit test for function to_json_schema
def test_to_json_schema():
    schema_definitions_0: typing.Mapping[str, Field] = {}
    class_0 = type('class_0', (Schema,), {'make_validator': ()})
    field_0 = to_json_schema(class_0, schema_definitions_0)
    assert isinstance(field_0, dict)
    assert field_0 == None
    str_0 = "This is a string"
    field_1 = to_json_schema(str_0, schema_definitions_0)
    assert isinstance(field_1, dict)
    assert field_1 == None
    none_0 = None
    field_2 = to_json_schema(none_0, schema_definitions_0)
    assert isinstance(field_2, dict)
    assert field_2 == None

#