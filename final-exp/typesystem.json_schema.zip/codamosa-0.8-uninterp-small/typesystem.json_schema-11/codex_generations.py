

# Generated at 2022-06-26 10:21:13.896744
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    dict_0 = {"type":"string","const":"aaa","maxLength":3,"minLength":3}
    definitions = SchemaDefinitions()
    field_0 = type_from_json_schema(dict_0, definitions)



# Generated at 2022-06-26 10:21:26.417462
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Tests for docstring examples
    test_data_0 = {"if": {"const": "test"}, "then": {"const": 20}, "else": {"const": 30}}
    field_0 = if_then_else_from_json_schema(test_data_0)
    assert field_0.get_option("default") == NO_DEFAULT
    assert field_0.validate("test") == 20
    assert field_0.validate("false") == 30

    # Tests for full coverage
    test_data_1 = {"if": {"const": "test"}, "then": {"const": "true"}}
    field_1 = if_then_else_from_json_schema(test_data_1)
    assert field_1.get_option("default") == NO_DEFAULT

# Generated at 2022-06-26 10:21:35.863960
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    for _ in range(10):
        data_0 = {'type': 'string', 'enum': ['foo', 'bar']}
        definitions_0 = SchemaDefinitions()
        field_0 = from_json_schema(data_0, definitions_0)
        data_1 = {'not': field_0}
        field_1 = not_from_json_schema(data_1, definitions_0)
        assert (any(choice_0 in field_1.as_choices() for choice_0, _ in field_1.choices)) is False


# Generated at 2022-06-26 10:21:40.458961
# Unit test for function type_from_json_schema
def test_type_from_json_schema():

    print("\n***** Running type_from_json_schema unit test *****")
    print("testcase_0")

    str_0 = '{"type":["string","null"]}'
    dict_0 = json.loads(str_0)

    field_0 = type_from_json_schema(dict_0)
    res_0 = field_0.const
    res_1 = field_0.validate("abc")

    print(res_0)
    print(res_1)
    print("Success!")
    return



# Generated at 2022-06-26 10:21:49.210841
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Test with following inputs:
    data = {
        "$ref": "#/definitions/JSONSchema",
        "type": "object",
        "properties": {
            "allOf": {
                "type": "array",
                "items": {"oneOf": [{"$ref": "#"}, {"$ref": "#/definitions/JSONSchema"}]},
            }
        },
    }
    definitions = {"JSONSchema": {"type": "object"}}

    # Function should return an instance of AllOf
    assert isinstance(all_of_from_json_schema(data, definitions), AllOf)
    # Function should return a None value.

# Generated at 2022-06-26 10:22:01.976658
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-26 10:22:12.631252
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    bool_0 = False
    field_0 = from_json_schema(bool_0)
    field_1 = NeverMatch()
    assert field_0 == field_1
    str_0 = "#/definitions/JSONSchema"
    dict_0 = {"type": "string", "$ref": str_0}
    field_2 = from_json_schema(dict_0)
    field_3 = Reference(str_0)
    assert field_2 == field_3
    bool_1 = True
    dict_1 = {"type": "string", "const": bool_1}
    field_4 = from_json_schema(dict_1)
    field_5 = Const(True)
    assert field_4 == field_5
    str_1 = "#/definitions/JSONSchema"

# Generated at 2022-06-26 10:22:16.241077
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Integer(min_value=-2, max_value=3)
    assert to_json_schema(field) == {
        "minimum": -2,
        "maximum": 3,
        "type": ["integer", "null"],
    }



# Generated at 2022-06-26 10:22:21.662805
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    bool_0 = False
    dict_1 = {
        "type": "boolean",
        "enum": [
            False],
        "const": False}
    field_0 = from_json_schema(dict_1)
    assert field_0.validate(bool_0) == bool_0



# Generated at 2022-06-26 10:22:29.788758
# Unit test for function to_json_schema
def test_to_json_schema():
    Schema_0 = typing.List[int]
    field_0 = to_json_schema(Schema_0)
    assert field_0 == {"type": "array"}, "Assertion failed"

    Schema_1 = typing.List[int] | typing.List[str]
    field_1 = to_json_schema(Schema_1)
    assert field_1 == {"anyOf": [{"type": "array"}, {"type": "array"}]}, "Assertion failed"



# Generated at 2022-06-26 10:22:58.360461
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {'$id': 'https://example.com/person.schema.json', '$schema': 'http://json-schema.org/draft-07/schema#', 'title': 'Person', 'type': 'object', 'properties': {'firstName': {'type': 'string', 'description': 'The person\'s first name.'}, 'lastName': {'type': 'string', 'description': 'The person\'s last name.'}, 'age': {'description': 'Age in years which must be equal to or greater than zero.', 'type': 'integer', 'minimum': 0}}, 'required': ['firstName', 'lastName']}
    # Pass string "object"
    type_string = 'object'
    allow_null = True
    definitions = SchemaDefinitions()
    field_0 = from_json_schema_

# Generated at 2022-06-26 10:23:05.484523
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data_0 = {"if": ["string", "null"], "then": "string"}
    if_then_else_0 = if_then_else_from_json_schema(data_0, {})
    assert is_instance(if_then_else_0, IfThenElse)
    assert if_then_else_0.if_clause != None
    assert if_then_else_0.then_clause != None
    assert if_then_else_0.else_clause == None

    data_1 = {"if": {"required": ["foo"]}, "then": {"properties": {"foo": "string"}}, "else": "null"}
    if_then_else_1 = if_then_else_from_json_schema(data_1, {})

# Generated at 2022-06-26 10:23:10.681198
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    any_of_0 = [Boolean(), None]
    data_0 = {'anyOf': any_of_0}
    field_0 = any_of_from_json_schema(data_0)


# Generated at 2022-06-26 10:23:24.319354
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema_0 = {"type": "string"}
    field_0 = type_from_json_schema(schema_0, definitions)
    assert isinstance(field_0, String)
    assert field_0.to_primitive() == {"type": "string"}

    schema_1 = {"type": ["string", "number"]}
    field_1 = type_from_json_schema(schema_1, definitions)
    assert isinstance(field_1, Choice)
    assert field_1.to_primitive() == {
        "anyOf": [{"type": "string"}, {"type": "number"}]
    }

    schema_2 = {"type": "integer", "minimum": 1, "maximum": 5}
    field_2 = type_from_json_schema(schema_2, definitions)

# Generated at 2022-06-26 10:23:38.026605
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "array"
    }

    assert from_json_schema_type(data, "array", False, None) == Array()
    assert from_json_schema_type(data, "array", True, None) == Array(allow_null=True)
    #assert from_json_schema_type(data, "array", False, None) == data

    data = {
        "type": "object"
    }

    assert from_json_schema_type(data, "object", False, None) == Object()
    assert from_json_schema_type(data, "object", True, None) == Object(allow_null=True)
    #assert from_json_schema_type(data, "object", False, None) == data


# Generated at 2022-06-26 10:23:42.359887
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test for one_of
    # Testing a definition that represents a "one of" condition
    data = {
        "type": "object",
        "properties": {
            "age": {
                "oneOf": [
                    {"type": "integer", "minimum": 0},
                    {"type": "string", "pattern": "^[a-zA-Z]+$"},
                ]
            }
        },
    }

# Generated at 2022-06-26 10:23:44.745193
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert str(IfThenElse({}, True, True)) == 'IfThenElse(if_clause={}, then_clause=True, else_clause=True)'


# Generated at 2022-06-26 10:23:46.284574
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Setup test data
    data_0 = {"oneOf": []}
    definitions_0 = {}

    # Invoke method
    result = one_of_from_json_schema(data_0, definitions_0)



# Generated at 2022-06-26 10:24:00.901730
# Unit test for function to_json_schema
def test_to_json_schema():
    _definitions = {}
    schema = String
    json_schema = to_json_schema(schema, _definitions)
    assert json_schema == {"type": "string"}
    
    schema = Integer
    json_schema = to_json_schema(schema, _definitions)
    assert json_schema == {"type": "integer"}
    
    schema = Float
    json_schema = to_json_schema(schema, _definitions)
    assert json_schema == {"type": "number"}

    schema = Decimal
    json_schema = to_json_schema(schema, _definitions)
    assert json_schema == {"type": "number"}

    schema = Boolean
    json_schema = to_json_schema(schema, _definitions)
   

# Generated at 2022-06-26 10:24:05.946979
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "integer"}, {"type": "string"}]}
    expected = Union(any_of=[Integer(), String()])
    assert from_json_schema(data) == expected


# Generated at 2022-06-26 10:24:37.014046
# Unit test for function from_json_schema
def test_from_json_schema():
    assert len(var_0.keys()) == 0
    assert var_0["definitions"] == {}
    assert var_0["type"] == "boolean"
    assert var_0["allOf"] == [{}, {}]
    assert var_0["anyOf"] == [{}, {}]
    assert var_0["oneOf"] == [{}, {}]
    assert var_0["not"] == {}
    assert var_0["required"] == ["a", "b"]
    assert var_0["maxItems"] == 2
    assert var_0["minItems"] == 1
    assert var_0["items"] == [{}, {}]
    assert var_0["enum"] == ["a", "b"]
    assert var_0["const"] == "a"
    assert var_0["format"] == "a"
    assert var_

# Generated at 2022-06-26 10:24:42.708900
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_1 = {}
    var_1 = {'not': {'const': 1}}
    var_2 = None
    var_2 = not_from_json_schema(var_1)
    assert var_2 is not None


# Generated at 2022-06-26 10:24:49.201357
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    var_1 = var_0.get("allOf", {})
    var_2 = []
    for item in var_1:
        var_3 = from_json_schema(item, definitions=definitions)
        var_2.append(var_3)

    var_4 = var_0.get("default", NO_DEFAULT)
    var_5 = AllOf(all_of=var_2, default=var_4)
    return (var_5)



# Generated at 2022-06-26 10:24:54.499636
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    var_0 = AllOf(all_of = [Any()])
    r = all_of_from_json_schema(var_0)
    assert type(r) == AllOf


# Generated at 2022-06-26 10:24:56.856083
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    var_0 = {}
    from_json_schema(var_0)


# Generated at 2022-06-26 10:25:01.169803
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    print("Testing one_of_from_json_schema")
    assert one_of_from_json_schema(var_0) == None
    print("Test Complete")

# Generated at 2022-06-26 10:25:03.251954
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_1 = {}
    # var_0 = {}
    var_2 = not_from_json_schema(var_1)
    return None


# Generated at 2022-06-26 10:25:05.916341
# Unit test for function to_json_schema
def test_to_json_schema():
    # TODO
    var_0 = {}


# Generated at 2022-06-26 10:25:14.963233
# Unit test for function to_json_schema
def test_to_json_schema():
    at = assert_equal
    at(to_json_schema(Any()), True)
    at(to_json_schema(NeverMatch()), False)
    at(to_json_schema(String()), {"type": "string"})
    at(to_json_schema(List[Integer]()), {"type": "array", "items": {"type": "integer"}})
    at(to_json_schema(Object()), {"type": "object"})
    at(to_json_schema(Integer()), {"type": "integer"})
    at(to_json_schema(Boolean()), {"type": "boolean"})
    at(to_json_schema(Choice()), {"enum": []})
    at(to_json_schema(Const()), {"const": None})
   

# Generated at 2022-06-26 10:25:17.488294
# Unit test for function to_json_schema
def test_to_json_schema():
    var_1 = schema_from_string('{"type":"object","properties":{"0":{"type":"string"}}}')
    var_2 = to_json_schema(var_1)
    assert var_2 == {'type': 'object', 'properties': {'0': {'type': 'string'}}}


# Generated at 2022-06-26 10:25:44.266531
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_3 = {}
    var_4 = {}
    var_5 = {}
    var_6 = {}
    var_7 = {}
    var_8 = {}
    var_9 = {}
    var_10 = {}
    var_11 = {}
    var_12 = {}
    var_13 = {}
    var_14 = {}
    var_15 = {}
    var_16 = {}
    var_17 = {}
    var_18 = {}
    var_19 = {}
    var_20 = {}
    var_21 = {}
    var_22 = {}
    var_23 = {}
    var_24 = {}
    var_25 = {}
    var_26 = {}
    var_27 = {}
    var_

# Generated at 2022-06-26 10:25:55.977089
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # var_0 = {}
    var_1 =  ("array", "null")
    # var_2 = None
    var_3 =  ("object", "null")
    var_4 =  ("integer", "null")
    var_5 =  ("string", "null")
    var_6 =  ("number", "null")
    var_7 =  ("boolean", "null")
    var_8 =  ("null", False)
    var_9 =  ("array", "null", False)
    var_10 =  ("object", "null", False)
    var_11 =  ("integer", "null", False)
    var_12 =  ("string", "null", False)
    var_13 =  ("number", "null", False)
    var_14 =  ("boolean", "null", False)
   

# Generated at 2022-06-26 10:26:04.309972
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # We use a fake schema to ensure the reference is properly resolved
    definitions = SchemaDefinitions()
    definitions["#/my_ref"] = Integer()
    ref_field = not_from_json_schema({"not": {"$ref": "#/my_ref"}}, definitions=definitions)
    assert ref_field.validate(1) is False
    assert isinstance(ref_field.validate(1), ValidationError)
    assert ref_field.validate(0) is True


# Test 'not' constraining field

# Generated at 2022-06-26 10:26:08.938898
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Test case 0
    var_0 = {}
    try:
        all_of_from_json_schema(var_0)
    except:
        print("'all_of_from_json_schema' raised an exception")
        raise



# Generated at 2022-06-26 10:26:16.630944
# Unit test for function to_json_schema
def test_to_json_schema():

    # Test instance and type
    assert isinstance(var_0, {})
    assert isinstance(var_0, dict)

    # Test keys
    assert not var_0.keys()

    # Test values
    assert not var_0.values()

    # Test is empty
    assert not var_0
import json

# Import function to_json_schema
from h_matchers.to_json_schema import to_json_schema


# Generated at 2022-06-26 10:26:21.723306
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    var_0 = {}
    var_0 = [var_0]
    var_1 = {}
    var_1 = test_one_of_from_json_schema.__wrapped__(var_1)
    assert var_0 == var_1



# Generated at 2022-06-26 10:26:27.252997
# Unit test for function to_json_schema
def test_to_json_schema():
    var_0 = {}
    var_1 = to_json_schema(var_0)
    if var_1 is not {}:
        raise ValidationError("Invalid value of var_1")



# Generated at 2022-06-26 10:26:30.252532
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    var_1 = from_json_schema(var_0, None)
    var_2 = test_case_0()
    assert var_1 == var_2


# Generated at 2022-06-26 10:26:32.341577
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    var_1 = not_from_json_schema(var_0)


# Generated at 2022-06-26 10:26:37.875570
# Unit test for function from_json_schema
def test_from_json_schema():

    assert True, "The function is implemented"
test_from_json_schema()
test_case_0()



# Generated at 2022-06-26 10:26:58.285557
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Assert that 'all_of_from_json_schema' is callable
    # Assert that 'all_of_from_json_schema' is callable
    assert callable(all_of_from_json_schema)


# Generated at 2022-06-26 10:27:11.065133
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # If type_string is `number`, `integer`, `string`, `boolean`, `array`, or `object`, then the function should return a `Field`
    assert isinstance(from_json_schema_type({}, "number"), Field)
    assert isinstance(from_json_schema_type({}, "integer"), Field)
    assert isinstance(from_json_schema_type({}, "string"), Field)
    assert isinstance(from_json_schema_type({}, "boolean"), Field)
    assert isinstance(from_json_schema_type({}, "array"), Field)
    assert isinstance(from_json_schema_type({}, "object"), Field)
    # If type_string is not a valid type, then the function should raise a `AssertionError`

# Generated at 2022-06-26 10:27:12.175994
# Unit test for function to_json_schema
def test_to_json_schema():
    json_0 = to_json_schema(field_0)
    assert json_0 == {}


# Generated at 2022-06-26 10:27:22.926906
# Unit test for function from_json_schema
def test_from_json_schema():
    print("Testing function from_json_schema")

    ### TEST CASE 1
    print("Test case 1: All allowable conditions")

# Generated at 2022-06-26 10:27:27.878780
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {}
    field_0 = from_json_schema(dict_0)
    dict_1 = to_json_schema(field_0)
    assert dict_1 == dict_0

    dict_0 = {"type": "null"}
    field_0 = from_json_schema(dict_0, definitions={})
    dict_1 = to_json_schema(field_0)
    assert dict_1 == dict_0

    dict_0 = {"type": "null", "default": "", "description": "hello"}
    field_0 = from_json_schema(dict_0, definitions={})
    dict_1 = to_json_schema(field_0)
    assert dict_1 == dict_0

    dict_0 = {"type": "string"}
    field_0 = from_

# Generated at 2022-06-26 10:27:37.421050
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = True
    field_0 = from_json_schema(dict_0)
    dict_1 = {"$ref": '#/definitions/label'}
    field_1 = from_json_schema(dict_1)
    dict_2 = {"type": 'integer'}
    field_2 = from_json_schema(dict_2)
    dict_3 = {"type": 'string'}
    field_3 = from_json_schema(dict_3)
    dict_4 = {"type": 'number'}
    field_4 = from_json_schema(dict_4)
    dict_5 = {"type": 'object'}
    field_5 = from_json_schema(dict_5)
    dict_6 = {"type": 'array'}

# Generated at 2022-06-26 10:27:43.569616
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:27:55.260075
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {"allOf": [{}, {"$ref": "#/definitions/some_field"}], "definitions": {"some_field": {"type": "string", "maxLength": 10, "default": "hello world"}}}
    field_0 = from_json_schema(dict_0)
    assert field_0.check_type({"some_field": "hello world"}) == True
    assert field_0.check_type({"some_field": "hi"}) == True
    assert field_0.check_type({"some_field": "hello worlds"}) == False



# Generated at 2022-06-26 10:27:58.137174
# Unit test for function to_json_schema
def test_to_json_schema():
    from django_stachoutils.json_schema.tests.fixtures import json_schema_fixture

    fixture = json_schema_fixture()

    field = from_json_schema(fixture)

    field_json = to_json_schema(field)

    assert fixture == field_json


# Generated at 2022-06-26 10:28:09.036600
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    from . import String, Object, Integer, Choice, Const, Union, AllOf, OneOf
    from . import IfThenElse, Not, Reference

    assert json.dumps(
        to_json_schema(String()), indent=4, sort_keys=True
    ) == """\
{
    "type": "string"
}
"""

    assert json.dumps(to_json_schema(Object(properties={"key": String()})), indent=4) == """\
{
    "properties": {
        "key": {
            "type": "string"
        }
    },
    "type": "object"
}
"""


# Generated at 2022-06-26 10:28:46.751175
# Unit test for function from_json_schema
def test_from_json_schema():
    boolean_schema = {
        "type": "boolean",
        "minLength": 2,
        "maxLength": 3,
        "pattern": "\\d+",
        "format": "regex",
    }
    assert boolean_schema == to_json_schema(from_json_schema(boolean_schema))

    boolean_schema = {
        "type": "boolean",
        "minimum": 2,
        "maximum": 3,
        "exclusiveMinimum": 2,
        "exclusiveMaximum": 3,
        "multipleOf": 2,
    }
    assert boolean_schema == to_json_schema(from_json_schema(boolean_schema))


# Generated at 2022-06-26 10:28:52.338199
# Unit test for function to_json_schema
def test_to_json_schema():
    # Testing for code coverage.
    class MySchema(Schema):
        @classmethod
        def make_validator(cls):
            return Any(default="hello")

    assert to_json_schema(MySchema()) == {"default": "hello"}
    assert to_json_schema(Any(default="world")) == {"default": "world"}
    assert to_json_schema(None) is None
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False


# Generated at 2022-06-26 10:29:06.454548
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {"type":"string"}
    field_0 = from_json_schema(dict_0)
    assert (type(field_0) == type(String()))
    print(field_0)

    dict_1 = {"type":"integer"}
    field_1 = from_json_schema(dict_0)
    assert (type(field_1) == type(Integer()))
    print(field_1)

    dict_2 = {"type":"number"}
    field_2 = from_json_schema(dict_0)
    assert (type(field_2) == type(Number()))
    print(field_2)

    dict_3 = {"type":"array"}
    field_3 = from_json_schema(dict_0)
    assert (type(field_3) == type(Array()))

# Generated at 2022-06-26 10:29:16.261841
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test for type_string = 'number'
    data = {
        "type": "number",
        "minimum": 1.0,
        "maximum": 2.0,
        "exclusiveMinimum": 3.0,
        "exclusiveMaximum": 4.0,
        "multipleOf": 5.0,
        "default": 6.0,
    }
    type_string = "number"
    allow_null = False
    definitions = SchemaDefinitions()
    field_0 = from_json_schema_type(
        data, type_string=type_string, allow_null=allow_null, definitions=definitions
    )
    assert field_0.allow_null == allow_null, "Expected: {1}, Actual: {0}".format(
        field_0.allow_null, allow_null
    )
   

# Generated at 2022-06-26 10:29:29.029876
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # test case 1
    dict_1 = {"type": "null"}
    type_string_1 = get_valid_types(dict_1)[0].pop()
    allow_null_1 = get_valid_types(dict_1)[1]
    assert [type(type_string_1), type(allow_null_1)] == [str, bool]

    # test case 2
    dict_2 = {"type": "boolean"}
    type_string_2 = get_valid_types(dict_2)[0].pop()
    allow_null_2 = get_valid_types(dict_2)[1]
    assert [type(type_string_2), type(allow_null_2)] == [str, bool]

    # test case 3
    dict_3 = {"type": "object"}
    type_string_3 = get

# Generated at 2022-06-26 10:29:41.412509
# Unit test for function from_json_schema
def test_from_json_schema():
    from expecter import expect
    from uuid import UUID

    expect(from_json_schema({"type": "integer"})) == Integer()
    expect(from_json_schema({"type": "number"})) == Number()
    expect(from_json_schema({"type": "string"})) == String()
    expect(from_json_schema({"type": "boolean"})) == Boolean()
    expect(from_json_schema({"type": "object"})) == Object()
    expect(from_json_schema({"type": "array"})) == Array()
    expect(from_json_schema({"type": ["null", "boolean"]})) == Boolean()
    uuid_schema = String(format="uuid")
    definitions = SchemaDefinitions()

# Generated at 2022-06-26 10:29:55.567625
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {"required": True, "type": "boolean"}
    field_0 = from_json_schema_type(dict_0, "boolean", False, None)
    assert isinstance(field_0, Boolean)
    dict_0 = {"maximum": 67, "type": "integer"}
    field_0 = from_json_schema_type(dict_0, "integer", False, None)
    assert isinstance(field_0, Integer)
    dict_0 = {"required": True, "type": "number"}
    field_0 = from_json_schema_type(dict_0, "number", False, None)
    assert isinstance(field_0, Float)
    dict_0 = {"maxItems": 16, "type": "array"}

# Generated at 2022-06-26 10:30:06.346341
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({}), Any)
    assert isinstance(from_json_schema([]), Any)
    assert isinstance(from_json_schema(""), Any)
    assert isinstance(from_json_schema("abc"), Any)
    assert isinstance(from_json_schema(False), NeverMatch)
    assert isinstance(from_json_schema(True), Any)
    assert isinstance(from_json_schema({"type": "integer"}), Integer)
    assert isinstance(from_json_schema({"type": "string"}), String)
    assert isinstance(from_json_schema({"type": ["string", "null"]}), String | Const(None))

# Generated at 2022-06-26 10:30:12.278086
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "boolean", False, {}).get_type() == Boolean
    assert from_json_schema_type({"items": {}}, "array", False, {}).get_type() == Array
