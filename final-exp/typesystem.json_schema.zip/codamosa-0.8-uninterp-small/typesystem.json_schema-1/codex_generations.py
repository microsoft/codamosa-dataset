

# Generated at 2022-06-26 10:21:16.179600
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_1 = {"if": {u"enum": [1, 2, 3]}, u"then": True, u"else": False}
    field_1 = if_then_else_from_json_schema(dict_1, {})
    dict_2 = {"enum": [{u"multipleOf": 4}, {u"multipleOf": 2}]}
    field_2 = enum_from_json_schema(dict_2, {})
    dict_3 = {u"$ref": u"#/definitions/foo"}
    field_3 = ref_from_json_schema(dict_3, {})
    dict_4 = {u"const": 3.5}
    field_4 = const_from_json_schema(dict_4, {})

# Generated at 2022-06-26 10:21:27.297715
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:21:39.756286
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)
    string_0 = "m"
    string_1 = "m"
    boolean_schema_0 = {string_0: string_1}
    string_2 = "m"
    string_3 = "m"
    string_4 = "p"
    string_5 = "p"
    boolean_schema_1 = {string_2: string_3, string_4: string_5}
    string_6 = "e"
    boolean_schema_2 = {string_6: boolean_schema_1}
    string_7 = "t"
    string

# Generated at 2022-06-26 10:21:45.201062
# Unit test for function to_json_schema
def test_to_json_schema():

    # Setup
    dict_0 = {
        "additionalProperties": True,
        "default": None,
        "definitions": {},
        "patternProperties": {},
        "properties": {},
        "type": "object",
    }


# Generated at 2022-06-26 10:21:52.163986
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    dict_0 = {0: 0, 0: 0}
    field_0 = from_json_schema(dict_0)
    dict_0 = {0: 0, 0: 0}
    field_0 = from_json_schema(dict_0)
    dict_0 = {'const': 'const', 0: 0}
    field_0 = from_json_schema(dict_0)
    dict_0 = {0: 0, 'const': 'const'}
    field_0 = from_json_schema(dict_0)
    const = 'const'
    dict_0 = {'const': 'const'}
    field_0 = from_json_schema(dict_0)
    dict_0 = {'const': 'const'}

# Generated at 2022-06-26 10:22:03.918325
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type": ["string", "boolean", "integer", "number", "null"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"string", "boolean", "integer", "number"}
    assert allow_null == True

    data = {"type": ["boolean", "integer", "number", "null"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"boolean", "integer", "number"}
    assert allow_null == True

    data = {"type": ["null", "boolean", "integer", "number"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"boolean", "integer", "number"}
    assert allow_null == True

   

# Generated at 2022-06-26 10:22:12.586789
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test number
    number_int = [3, 4, 5]
    number_int_bdd = Field()
    number_int_bdd.type = ["number"]
    number_int_bdd.minimum = 3
    number_int_bdd.maximum = 5
    number_int_bdd.multiple_of = 1
    assert from_json_schema_type(number_int[0], "number", 0, None) == number_int_bdd

    number_float = [3.0, 4.0, 5.0]
    number_float_bdd = Field()
    number_float_bdd.type = ["number"]
    number_float_bdd.minimum = 3.0
    number_float_bdd.maximum = 5.0
    number_float_bdd.multiple_of = 1.

# Generated at 2022-06-26 10:22:15.876906
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:22:26.141791
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)
    dict_1 = {'allOf': dict_0, 'required': dict_0, 'type': dict_0, 'oneOf': dict_0, '$ref': dict_0, 'const': dict_0, 'anyOf': dict_0, 'not': dict_0}
    field_1 = from_json_schema(dict_1)

# Generated at 2022-06-26 10:22:32.959197
# Unit test for function get_valid_types
def test_get_valid_types():
    test_case_0()
    test_get_valid_types_0()
    test_get_valid_types_1()
    test_get_valid_types_2()
    test_get_valid_types_3()
    test_get_valid_types_4()
    test_get_valid_types_5()
    test_get_valid_types_6()
    test_get_valid_types_7()
# Test 0

# Generated at 2022-06-26 10:23:25.447413
# Unit test for function type_from_json_schema

# Generated at 2022-06-26 10:23:32.580819
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert False
    """
    # TODO: Implement unit test for function any_of_from_json_schema
    try:
        raise RuntimeError()
    except:
        pass

    assert False, "Assertion Failed"
    """


# Generated at 2022-06-26 10:23:44.614586
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-26 10:23:56.387052
# Unit test for function to_json_schema
def test_to_json_schema():
    float_0 = -3944.300277
    dict_0 = {
        'default': float_0,
        'exclusiveMinimum': float_0,
        'minimum': float_0,
        'type': 'number',
    }
    field_0 = from_json_schema(dict_0)

    def callback_func():
        return to_json_schema(field_0)

    assert_raises(ValueError, callback_func)


# Generated at 2022-06-26 10:24:09.364475
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Generate inputs
    float_input_1 = -8462.643042
    dict_input_2 = {float_input_1: float_input_1, float_input_1: float_input_1, float_input_1: float_input_1}

    # Compute expected outputs
    expected_output = from_json_schema(dict_input_2)

    # Check if any_of_from_json_schema returns the expected output
    actual_output = any_of_from_json_schema(dict_input_2, definitions)
    assert actual_output == expected_output, 'Test failed'


# Generated at 2022-06-26 10:24:20.116612
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field_obj = String()
    input_obj = {
        "anyOf": [
            field_obj,
            field_obj,
            field_obj,
            field_obj,
            field_obj,
            field_obj,
            field_obj,
            field_obj,
            field_obj,
        ],
    }
    assert any_of_from_json_schema(input_obj) == field_obj


# Generated at 2022-06-26 10:24:20.692695
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema(): 
    pass


# Generated at 2022-06-26 10:24:25.373598
# Unit test for function from_json_schema
def test_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)
    field_1 = from_json_schema(dict_0)
    assert field_0.validate(dict_0) == dict_0
    assert field_1.validate(dict_0) == dict_0
    field_2 = from_json_schema(dict_0)
    assert field_2.validate(dict_0) == dict_0
    int_0 = 63
    list_0 = [float_0, int_0, int_0, int_0]

# Generated at 2022-06-26 10:24:33.229276
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {
        "type": "number",
        "minimum": 5,
        "maximum": 10,
    }
    field = from_json_schema_type(schema, type_string="number", allow_null=False, definitions=definitions)
    assert field.minimum == 5
    assert field.maximum == 10
    assert field.allow_null == False
    assert field.default == NO_DEFAULT



# Generated at 2022-06-26 10:24:42.500851
# Unit test for function get_valid_types
def test_get_valid_types():
    test_dict = {
        "type": "string",
        "enum": [
            "string",
            "object",
            "array",
            "boolean",
            "number",
            "integer",
            "null",
        ],
    }

    # Test case with type being "string"
    type_strings, allow_null = get_valid_types(test_dict)

    assert len(type_strings) == 1
    assert "string" in type_strings
    assert allow_null == False

    # Change type to "array"
    test_dict["type"] = "array"

    type_strings, allow_null = get_valid_types(test_dict)

    assert len(type_strings) == 1
    assert "array" in type_strings
    assert allow_null == False

    # Change type to "

# Generated at 2022-06-26 10:25:27.946725
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # 1. Input parameters

    # 2. Recommended values

    # 3. Computed values

    # 4. Expected Pass/Fail results
    expected_result = NotImplemented

    # 5. Call the function under test
    actual_result = test_case_0()

    # 6. Compare actual_result to expected_result and determine Pass/Fail
    assert actual_result == expected_result, "Actual result does not match expected result"



# Generated at 2022-06-26 10:25:29.030509
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {'type': 'boolean'}
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:25:42.345866
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    float_0 = -14.636
    int_0 = -88
    test_0 = 0
    test_1 = -18
    test_2 = -110
    test_3 = 0
    test_4 = 0
    test_5 = -3.761708228942711
    test_6 = 26
    test_7 = -105
    test_8 = 0
    test_9 = -78
    test_10 = 0
    test_11 = 0
    test_12 = -7
    test_13 = -7.614
    test_14 = 0
    test_15 = 0
    test_16 = -120
    test_17 = -83
    test_18 = 0
    test_19 = 0
    test_20 = -7
    test_21 = 0

# Generated at 2022-06-26 10:25:44.190154
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert JSONSchema.is_valid(dict_0)



# Generated at 2022-06-26 10:25:50.372853
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    str_0 = 'zYf'
    dict_0 = {'oneOf': [{'type': 'integer'}, {'type': 'string'}, {'type': 'integer'}]}
    float_0 = -16763.292
    dict_1 = {'oneOf': [{'type': 'array'}, {'type': 'integer'}, {'type': 'boolean'}, {'type': 'null', 'const': float_0}]}

# Generated at 2022-06-26 10:26:03.095441
# Unit test for function from_json_schema
def test_from_json_schema():
    float_0 = -3944.300277
    float_1 = -3944.300277
    float_2 = -3944.300277
    float_3 = -3944.300277
    float_4 = -3944.300277
    float_5 = -3944.300277
    float_6 = -3944.300277
    float_7 = -3944.300277
    float_8 = -3944.300277
    float_9 = -3944.300277
    float_10 = -3944.300277
    float_11 = -3944.300277
    float_12 = -3944.300277
    float_13 = -3944.300277
    float_14 = -3944.300277
    float_15 = -3944.300277
    float_16 = -39

# Generated at 2022-06-26 10:26:15.401902
# Unit test for function to_json_schema
def test_to_json_schema():
    try:
        import json
    except ImportError:
        return

    # Test cases:
    assert json.loads(json.dumps(to_json_schema(Integer()))) == {"type": ["integer", "null"]}
    assert json.loads(json.dumps(to_json_schema(Integer(allow_null=False)))) == {"type": "integer"}
    assert json.loads(json.dumps(to_json_schema(Integer(minimum=0)))) == {
        "type": ["integer", "null"],
        "minimum": 0,
    }
    assert json.loads(json.dumps(to_json_schema(Integer(maximum=50)))) == {
        "type": ["integer", "null"],
        "maximum": 50,
    }

# Generated at 2022-06-26 10:26:23.028940
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {"const": float_0, float_0: float_0, float_0: float_0}
    dict_1 = {}
    dict_2 = {"definitions": {}, "const": float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)
    field_1 = from_json_schema(dict_1)
    field_2 = from_json_schema(dict_2)
    assert field_0 == field_1 == field_2 == Const(-3944.300277)


# Generated at 2022-06-26 10:26:25.994164
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    print(test_case_0.__name__)
    test_case_0()



# Generated at 2022-06-26 10:26:31.196733
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    float_0 = -3944.300277
    dict_0 = {float_0: float_0, float_0: float_0, float_0: float_0}
    field_0 = from_json_schema(dict_0)
    assert type(field_0) is Union


# Generated at 2022-06-26 10:29:02.751208
# Unit test for function to_json_schema
def test_to_json_schema():
    # TODO
    field = String()
    expected = {
        "type": "string",
        "default": None,
    }
    actual = to_json_schema(field)
    assert actual == expected

    field = Integer()
    expected = {
        "type": "integer",
        "default": None,
    }
    actual = to_json_schema(field)
    assert actual == expected

    field = Integer(minimum=1)
    expected = {
        "type": "integer",
        "default": None,
        "minimum": 1,
    }
    actual = to_json_schema(field)
    assert actual == expected

    field = Array(Integer())

# Generated at 2022-06-26 10:29:06.530151
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {}

    union = any_of_from_json_schema(dict_0, definition)
    assert isinstance(union, Union)



# Generated at 2022-06-26 10:29:13.174855
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)

    not_json_schema = Not(negated=Boolean())
    assert not_json_schema.to_json_schema() == {'not': {'type': 'boolean'}}



# Generated at 2022-06-26 10:29:27.109965
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # null
    assert from_json_schema_type({}, type_string="null", allow_null=True) == Const(None)
    # boolean
    assert from_json_schema_type({}, type_string="boolean", allow_null=True) == Boolean(
        allow_null=True
    )
    # number
    assert from_json_schema_type({}, type_string="number", allow_null=True) == Float(
        allow_null=True
    )
    # integer
    assert from_json_schema_type(
        {}, type_string="integer", allow_null=True
    ) == Integer(allow_null=True)
    # string

# Generated at 2022-06-26 10:29:35.391000
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {'not': {'$ref': '#/definitions/integer'}}
    field_0 = Not(negated=Reference(to='#/definitions/integer', definitions={}))
    assert field_0 == not_from_json_schema(dict_0, {})


# Generated at 2022-06-26 10:29:44.556731
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # The 'default' key must be a default value of the field.
    # 'Const' in json schema is a default value of the field.
    dict_0 = {'const': 'const', 'default': 'const'}
    field_0 = any_of_from_json_schema(dict_0, {})
    assert field_0.const == 'const'
    assert field_0.default == 'const'
    
    # The 'default' key does not have to be a default value of the field.
    # 'Const' in json schema is not a default value of the field.
    dict_1 = {'const': 'const'}
    field_1 = any_of_from_json_schema(dict_1, {})
    assert field_1.const == 'const'
    assert field_1.default == NO

# Generated at 2022-06-26 10:29:55.627633
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'type': ['integer'], 'anyOf': [{'type': ['integer'], 'const': 1}, {'type': ['integer'], 'const': 2}, {'type': ['integer'], 'const': 3}]}
    field_0 = from_json_schema(dict_0)
    result = field_0.validate(1)
    assert result == 1
    result = field_0.validate(2)
    assert result == 2
    result = field_0.validate(3)
    assert result == 3
    result = field_0.validate(4)
    assert result == None


# Generated at 2022-06-26 10:29:57.780475
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_1 = {"allOf":[{"properties":{},"type":"object"}]}
    assert isinstance(all_of_from_json_schema(dict_1, definitions), AllOf)



# Generated at 2022-06-26 10:30:05.419495
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {"properties": {"x": {"type": "object"}}}
    dict_1 = {"not": {"properties": {"x": {"type": "object"}}}}
    field_0 = from_json_schema(dict_0)
    field_1 = from_json_schema(dict_1)
    assert field_0 == field_1, "Expected Field({'allow_null': False, 'properties': {'x': Field({'allow_null': False, 'type': <class 'object'>})}})"



# Generated at 2022-06-26 10:30:18.433192
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {}
    field_0 = from_json_schema(dict_0)
    dict_1 = {"oneOf": [{"type": "integer"}]}
    field_1 = from_json_schema(dict_1)
    dict_2 = {"oneOf": [{"type": "integer"}], "default": "3"}
    field_2 = from_json_schema(dict_2)
    dict_3 = {"oneOf": [{"type": "integer"}], "default": 3}
    field_3 = from_json_schema(dict_3)
    assert type(field_0) == Any
    assert type(field_1) == OneOf
    assert type(field_2) == OneOf
    assert type(field_3) == OneOf

