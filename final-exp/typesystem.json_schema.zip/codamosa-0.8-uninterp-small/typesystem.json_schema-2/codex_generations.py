

# Generated at 2022-06-26 10:21:29.448961
# Unit test for function const_from_json_schema

# Generated at 2022-06-26 10:21:33.668612
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const = 'test'
    kwargs = {"const": const, "default": 'test'}
    assert const_from_json_schema('test', 'test') == Const(**kwargs)


# Generated at 2022-06-26 10:21:34.579485
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert False



# Generated at 2022-06-26 10:21:42.138749
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "properties": {
                "a": {
                    "type": "number",
                }
            },
            "required": [
                "a"
            ]
        },
        "then": {
            "type": "number",
            "minimum": 0
        },
        "else": {
            "type": "number",
            "minimum": -10,
            "maximum": 0
        }
    }
    definitions = SchemaDefinitions()
    field = if_then_else_from_json_schema(data, definitions)

# Generated at 2022-06-26 10:21:51.289951
# Unit test for function to_json_schema
def test_to_json_schema():
    str_0 = String()
    field_0 = str_0
    var_0 = to_json_schema(field_0)
    assert var_0 == {
        "type": "string",
        "default": NOT_SET,
        "minLength": 0,
    }

    str_1 = String(max_length=10)
    field_1 = str_1
    var_1 = to_json_schema(field_1)
    assert var_1 == {
        "type": "string",
        "default": NOT_SET,
        "minLength": 0,
        "maxLength": 10,
    }

    str_2 = String(format="email")
    field_2 = str_2
    var_2 = to_json_schema(field_2)

# Generated at 2022-06-26 10:22:00.512581
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    case_0_data = {'const': [1, 2, 3], 'default': [1, 2, 3]}
    case_0_expected = Const(const=case_0_data['const'], default=case_0_data['default'])
    case_0_actual = const_from_json_schema(case_0_data, None)
    assert case_0_expected == case_0_actual, 'case_0_expected: {}, case_0_actual: {}'.format(case_0_expected, case_0_actual)


# Generated at 2022-06-26 10:22:11.219527
# Unit test for function from_json_schema
def test_from_json_schema():
    # Simple case
    data_0 = {"type": "string", "minLength": 10}
    field_0 = from_json_schema(data_0)
    assert isinstance(field_0, String)
    assert field_0.min_length == 10

    # Array items case
    data_1 = {"type": "array", "items": {"type": "string"}}
    field_1 = from_json_schema(data_1)
    assert isinstance(field_1, Array)
    assert isinstance(field_1.items, String)

    # Array items + additionalItems case
    data_2 = {"type": "array", "items": [{"type": "string"}, {"type": "object"}]}
    field_2 = from_json_schema(data_2)

# Generated at 2022-06-26 10:22:21.662667
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    """
    This helps to ensure compatibility with other implementations.
    """
    data = {"if": {"const": True}, "then": {"const": True}, "else": {"const": False}}
    schema = IfThenElse(
        if_clause=Const(True), then_clause=Const(True), else_clause=Const(False)
    )

    assert isinstance(from_json_schema(data), IfThenElse)
    assert to_json_schema(schema) == data


# Generated at 2022-06-26 10:22:31.519207
# Unit test for function from_json_schema
def test_from_json_schema():
    print("Running test for function from_json_schema")
    # Case 0
    var_0 = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "definitions": {
            "user": {"properties": {"age": {"minimum": 0, "type": "integer"}}}
        },
        "properties": {
            "title": {"type": "string"},
            "users": {
                "items": {"$ref": "#/definitions/user"},
                "minItems": 1,
                "type": "array",
            },
        },
    }
    field_0 = from_json_schema(var_0)
    print("type(field_0): {}".format(type(field_0)))

# Generated at 2022-06-26 10:22:42.205485
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    var_0 = Reference("#/definitions/JSONSchema", definitions=definitions)
    var_1 = from_json_schema(var_0, definitions=definitions)
    var_2 = from_json_schema(var_1, definitions=definitions)
    var_3 = from_json_schema(var_2, definitions=definitions)
    var_4 = from_json_schema(var_3, definitions=definitions)
    var_5 = from_json_schema(var_4, definitions=definitions)
    var_6 = from_json_schema(var_5, definitions=definitions)


# Generated at 2022-06-26 10:23:36.483963
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    input_0 = [{"$ref": "#/definitions/IF"}, {"$ref": "#/definitions/A"}, {"$ref": "#/definitions/B"}, {"$ref": "#/definitions/THEN"}]
    input_1 = {"a": {"$ref": "#/definitions/A"}, "b": {"$ref": "#/definitions/B"}}
    var_0 = type(any_of_from_json_schema(input_0, input_1))
    assert var_0 == Union


# Generated at 2022-06-26 10:23:38.656452
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == []
    assert allow_null == True



# Generated at 2022-06-26 10:23:46.892654
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from typesystem import Integer

    data = {
        "type": "integer",
        "minimum": 1,
        "maximum": 10,
        "exclusiveMinimum": True,
        "exclusiveMaximum": True,
    }
    return type_from_json_schema(data, definitions=None) == Integer(
        minimum=1,
        maximum=10,
        exclusive_minimum=True,
        exclusive_maximum=True,
        allow_null=False,
    )



# Generated at 2022-06-26 10:23:48.483372
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0 = None
    var_0 = to_json_schema(field_0)



# Generated at 2022-06-26 10:23:54.451531
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:23:56.190727
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:24:01.486545
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data_0 = {"enum": [1, 2, 3], "default": 1}
    field_0 = enum_from_json_schema(data_0, None)


# Generated at 2022-06-26 10:24:11.877105
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic import BaseModel

    class Person(BaseModel):
        name: str = "Jim"
        age: float = 2.0


    class PersonSchema(Schema):
        name: str = "Jim"
        age: float = 2.0


    assert to_json_schema(Person) == to_json_schema(PersonSchema)
    assert to_json_schema(Person()) == to_json_schema(PersonSchema())
    assert to_json_schema(Person) == to_json_schema(PersonSchema)
    assert to_json_schema(Person()) == to_json_schema(PersonSchema())

# Generated at 2022-06-26 10:24:14.703949
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    kwargs = {"one_of": [String(), Integer()]}
    field_0 = OneOf(**kwargs)
    var_0 = to_json_schema(field_0)
    assert field_0 == one_of_from_json_schema(var_0, definitions=definitions)


# Generated at 2022-06-26 10:24:22.200541
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'null'}, {'type': 'boolean'}, {'type': 'integer'}]}
    expected = {'anyOf': [{'type': 'null'}, {'type': 'boolean'}, {'type': 'integer'}]}
    actual = any_of_from_json_schema(data, None)
    assert expected == actual.__dict__


# Generated at 2022-06-26 10:25:08.283439
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    try:
        import uuid
    except ImportError:
        print("SKIP")
        return

    json_schema_object = {
        "oneOf": [
            {
                "id": "/properties/id",
                "type": "string",
                "title": "The ID Schema",
                "default": str(uuid.uuid4()),
                "examples": [str(uuid.uuid4())],
            }
        ]
    }

    field_0 = one_of_from_json_schema(json_schema_object)
    assert isinstance(field_0, OneOf)

    json_schema_object["oneOf"][0]["default"] = None
    field_0 = one_of_from_json_schema(json_schema_object)

# Generated at 2022-06-26 10:25:21.476062
# Unit test for function from_json_schema
def test_from_json_schema():
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)

    if "$ref" in data:
        return ref_from_json_schema(data, definitions=definitions)

    constraints = []  # typing.List[Field]
    if any([property_name in data for property_name in TYPE_CONSTRAINTS]):
        constraints.append(type_from_json_schema(data, definitions=definitions))
    if "enum" in data:
        constraints.append(enum_from_json_schema(data, definitions=definitions))

# Generated at 2022-06-26 10:25:32.352206
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {'allOf': [{'type': 'object', 'properties': {'a': {'type': 'string'}}}, {'type': 'object', 'properties': {'b': {'type': 'string'}}}], 'definitions': {}}

# Generated at 2022-06-26 10:25:43.439072
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data_0 = {'type': 'string'}
    type_string_0 = data_0.get('type', [])
    allow_null_0 = False
    definitions_0 = SchemaDefinitions()
    field_0 = from_json_schema_type(data_0, type_string_0, allow_null_0, definitions_0)
    data_1 = {'type': 'string', 'minLength': 0}
    type_string_1 = data_1.get('type', [])
    allow_null_1 = False
    definitions_1 = SchemaDefinitions()
    field_1 = from_json_schema_type(data_1, type_string_1, allow_null_1, definitions_1)
    data_2 = {'type': 'string', 'minLength': 0}
   

# Generated at 2022-06-26 10:25:55.485657
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field_1 = Boolean()
    var_1 = not_from_json_schema({'not': {'type': 'boolean'}})
    assert is_identical_to(field_1, var_1)
    field_2 = Not(negated=Boolean())
    var_2 = not_from_json_schema({'not': {'type': 'boolean'},'default': None})
    assert is_identical_to(field_2, var_2)
    field_3 = Not(negated=Boolean())
    var_3 = not_from_json_schema({'not': {'type': 'boolean'},'default': ''})
    assert is_identical_to(field_3, var_3)
    field_4 = Not(negated=Any())
    var_4

# Generated at 2022-06-26 10:26:00.762519
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # example from the spec
    data_0 = {
        "oneOf": [
            {"type": "integer"},
            {"maximum": 0},
            {"const": 1},
            {"const": 2},
            {"minimum": 10},
        ],
        "default": 0,
    }
    field = one_of_from_json_schema(data_0, definitions=definitions)
    assert field.one_of == [
        Integer(allow_null=True),
        Integer(maximum=0, allow_null=True),
        Const(1, allow_null=True),
        Const(2, allow_null=True),
        Integer(minimum=10, allow_null=True),
    ], f"Expected {field!r} to be {field!r}"

# Generated at 2022-06-26 10:26:03.830857
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert field_0 is None
    # Raise exception if not instance of Field
    with raises(AssertionError):
        all_of_from_json_schema(field_0, definitions=None)


# Generated at 2022-06-26 10:26:16.152451
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    input_0 = {'type': 'string', 'multipleOf': 3, 'const': 'hello', 'format': 'ipv4'}
    expected_0 = {"type": "string", "const": "hello", "multipleOf": 3, "format": "ipv4"}
    output_0 = all_of_from_json_schema(input_0, None)
    assert output_0 == expected_0


# Generated at 2022-06-26 10:26:24.212506
# Unit test for function to_json_schema
def test_to_json_schema():
    field_0 = String()
    var_0 = to_json_schema(field_0)
    assert var_0 == {"type": "string"}

    field_1 = String(default="")
    var_1 = to_json_schema(field_1)
    assert var_1 == {
        "type": "string",
        "default": "",
    }

    field_2 = String(default="")
    var_2 = to_json_schema(field_2)
    assert var_2 == {
        "type": "string",
        "default": "",
    }

    field_3 = String(default="", allow_blank=True)
    var_3 = to_json_schema(field_3)

# Generated at 2022-06-26 10:26:35.238985
# Unit test for function to_json_schema
def test_to_json_schema():
    
    field_0 = Boolean(const=True)
    field_1 = ToJsonSchema(field_0)
    data_0 = to_json_schema(field_1)
    assert data_0 == {'const': True, 'type': 'boolean'}
    
    field_2 = IfThenElse(required=True, if_clause=data_0, else_clause=field_1)
    field_3 = ToJsonSchema(field_2)
    data_1 = to_json_schema(field_3)
    assert data_1 == {'required': True, 'if': {'const': True, 'type': 'boolean'}, 'then': None, 'else': {'const': True, 'type': 'boolean'}}
    

# Generated at 2022-06-26 10:28:03.823583
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field_0 = None
    var_0 = to_json_schema(field_0)



# Generated at 2022-06-26 10:28:10.808686
# Unit test for function to_json_schema
def test_to_json_schema():
    field_0 = String(allow_null=True)
    var_0 = to_json_schema(field_0)

    field_1 = String(allow_blank=False)
    var_1 = to_json_schema(field_1)

    field_2 = String(allow_blank=True)
    var_2 = to_json_schema(field_2)

    field_3 = String(min_length=1)
    var_3 = to_json_schema(field_3)

    field_4 = String(max_length=5)
    var_4 = to_json_schema(field_4)

    field_5 = String(min_length=1, max_length=5)
    var_5 = to_json_schema(field_5)


# Generated at 2022-06-26 10:28:18.727509
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    template = None
    data = {
        "title": 'array type test',
        "description": 'test working og array type',
        "type": 'array',
        "items": {
            "type": 'number',
        }
    }
    definitions = None
    type_string = data.get("type", None)
    allow_null = False
    result = from_json_schema_type(data, type_string, allow_null, definitions)
    template["description"] = data['description']
    template["type"] = data['type']
    template["items"]["type"] = data['items']['type']
    assert result.to_primitive() == template

# Generated at 2022-06-26 10:28:29.505841
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field_1 = Not(negated=Any(), default=NO_DEFAULT)
    var_1 = to_json_schema(field_1)
    assert var_1 == {"not": {"type": "any"}, "default": NO_DEFAULT}
    field_2 = Not(negated=Any(), default=None)
    var_2 = to_json_schema(field_2)
    assert var_2 == {"not": {"type": "any"}, "default": None}
    field_3 = Not(negated=Any(), default=15)
    var_3 = to_json_schema(field_3)
    assert var_3 == {"not": {"type": "any"}, "default": 15}


# Generated at 2022-06-26 10:28:48.348844
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.schemas import OneOf
    from typesystem.fields import String, Integer

    a = String(min_length=3, max_length=5)
    b = Integer(minimum=1, maximum=100)
    schema_a = to_json_schema(a)
    schema_b = to_json_schema(b)
    data = {"oneOf": [schema_a, schema_b]}

    test_field_1 = one_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(test_field_1, OneOf)


# Generated at 2022-06-26 10:29:02.753216
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(None) is None
    assert to_json_schema(Any()) is True
    assert to_json_schema(NeverMatch()) is False
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(allow_null=True)) == {"type": ["string", "null"]}
    assert to_json_schema(Array(items=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }

# Generated at 2022-06-26 10:29:06.408370
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json_schema_0 = {"allOf": [{"type": "object"}, {"properties": {"a": {"type": "string"}}}]}
    field_0 = not_from_json_schema(json_schema_0, definitions={})
    var_0 = to_json_schema(field_0)


# Generated at 2022-06-26 10:29:15.952120
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # test_case_0
    data_0 = {}
    definitions_0 = {}
    field_0 = one_of_from_json_schema(data=data_0, definitions=definitions_0)
    var_0 = to_json_schema(field_0)
    assert var_0 == {}


# Generated at 2022-06-26 10:29:22.289743
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-26 10:29:31.144248
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test case for one_of_from_json_schema with normal inputs
    field_0 = {'minimum': 10, 'maximum': 20.5, 'type': 'number'}
    field_1 = ['hi', 'hello', 'bye']
    field_2 = {'maxLength': 20, 'type': 'string'}
    field_3 = {'minimum': 13, 'maximum': 23, 'type': 'integer'}
    field_list = [field_0, field_1, field_2, field_3]
    var_0 = one_of_from_json_schema({'oneOf': field_list}, None)
    var_1 = var_0.field_0.minimum
    var_2 = var_0.field_0.maximum
    var_3 = var_0.field_1[0]

# Generated at 2022-06-26 10:30:14.853753
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    field_0 = None
    var_0 = to_json_schema(field_0)
    #print(var_0)

