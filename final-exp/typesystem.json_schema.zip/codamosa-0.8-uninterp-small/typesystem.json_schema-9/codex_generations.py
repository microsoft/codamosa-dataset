

# Generated at 2022-06-26 10:21:26.050815
# Unit test for function get_valid_types
def test_get_valid_types():
    dict_0 = {'type': 'null'}
    dict_1 = {'type': 'integer'}
    dict_2 = {'type': ['integer', 'null']}
    dict_3 = {'type': 'number'}

    tuple_0 = get_valid_types(dict_0)
    tuple_1 = get_valid_types(dict_1)
    tuple_2 = get_valid_types(dict_2)
    tuple_3 = get_valid_types(dict_3)

    assert (tuple_0 == ({'null'}, True))
    assert (tuple_1 == ({'integer'}, False))
    assert (tuple_2 == ({'integer'}, True))
    assert (tuple_3 == ({'number','integer'}, False))


# Generated at 2022-06-26 10:21:37.192131
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type": ["null", "string"]}
    #function call
    type_strings, allow_null = get_valid_types(data)
    #assert statements
    assert allow_null
    assert len(type_strings) == 1
    data_1 = {"type": "array"}
    type_strings_1, allow_null_1 = get_valid_types(data_1)
    assert not allow_null_1
    assert len(type_strings_1) == 1
    data_2 = {"type": "object"}
    type_strings_2, allow_null_2 = get_valid_types(data_2)
    assert not allow_null_2
    assert len(type_strings_2) == 1
    data_3 = {"type": "null"}
    type_strings_3, allow_null_3

# Generated at 2022-06-26 10:21:41.055877
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Invalid argument type_string='const'
    data = {"if": {"const" : "a"}, "then" : {"const": "b"}}
    definitions = None
    field = if_then_else_from_json_schema(data, definitions)
    assert field.get_default() == NO_DEFAULT


# Generated at 2022-06-26 10:21:51.173237
# Unit test for function from_json_schema
def test_from_json_schema():
    # test case 0
    field_0 = None
    dict_0 = get_standard_properties(field_0)
    assert from_json_schema(dict_0,definitions=definitions) == Any()

    # test case 1
    field_1 = Any()
    dict_1 = get_standard_properties(field_1)
    assert from_json_schema(dict_1,definitions=definitions) == Any()

    # test case 2
    field_2 = Boolean()
    dict_2 = get_standard_properties(field_2)
    assert from_json_schema(dict_2,definitions=definitions) == Boolean()

    # test case 3
    field_3 = Integer(minimum=2)
    dict_3 = get_standard_properties(field_3)
    assert from_json_sche

# Generated at 2022-06-26 10:21:57.931223
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_data = {"const": "const"}
    const_field = from_json_schema(const_data)
    assert isinstance(const_field, Const)
    assert isinstance(const_field.const, str)
    assert const_field.const == const_data["const"]


# Generated at 2022-06-26 10:22:02.275398
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    example_if_then_else_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "if": {
            "type": "number",
            "minimum": 5,
            "multipleOf": 5,
        },
        "then": {
            "type": "string",
            "pattern": "^[a-f]{24}$",
        },
        "else": {
            "type": "integer",
            "maximum": 1023,
        },
    }


# Generated at 2022-06-26 10:22:12.817560
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # type: () -> None
    field_0 = None
    field_1 = get_standard_properties(field_0)
    field_2 = String()
    field_3 = String()
    field_4 = Integer()
    field_5 = Choice()
    field_6 = Integer()
    field_7 = None
    field_8 = None
    field_9 = None
    field_10 = None
    field_11 = None
    field_12 = None
    field_13 = None
    field_14 = None
    field_15 = None
    field_16 = None
    field_17 = None
    field_18 = None
    field_19 = String()
    field_20 = String()
    field_21 = String()
    field_22 = String()
    field_23 = String()
    field_24

# Generated at 2022-06-26 10:22:18.244067
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field_0 = None
    dict_0 = get_standard_properties(field_0)
    field_0 = Boolean()
    dict_0 = get_standard_properties(field_0)
    field_0 = Any()
    dict_0 = get_standard_properties(field_0)
    field_1 = Any()
    field_2 = Array(items=field_1)
    schema_0 = Schema(properties={"field_0": field_0, "field_1": field_1, "field_2": field_2})
    dict_0 = schema_0.get_json_schema()
    field_0 = from_json_schema(dict_0["properties"]["field_0"])
    field_1 = from_json_schema(dict_0["properties"]["field_1"])

# Generated at 2022-06-26 10:22:29.678669
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    input_data = {
        "$ref": "#/definitions/schema_with_enum",
        "type": "string",
        "enum": [
            "foo",
            "bar",
        ]
    }
    input_definitions = {
        "$ref": "#/definitions/schema_with_enum",
        "type": "string",
        "enum": [
            "foo",
            "bar",
        ]
    }
    output = enum_from_json_schema(input_data, input_definitions)
    expected_output = Choice(choices=(("foo", "foo"), ("bar", "bar")), default=NO_DEFAULT)
    assert output == expected_output, "Expected output does not match observed output"



# Generated at 2022-06-26 10:22:43.207182
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {
            "allOf": [
                {"$ref": "#/definitions/if-clause"},
                {"$ref": "#/definitions/then-clause"},
            ]
        },
        "then": {"$ref": "#/definitions/then-clause"},
        "else": {"$ref": "#/definitions/else-clause"},
    }
    field = if_then_else_from_json_schema(data=data, definitions={})
    dict = field.to_primitive()

# Generated at 2022-06-26 10:23:17.511066
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert False, "Test not implemented"


# Generated at 2022-06-26 10:23:26.251872
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field_0 = Not(negated=Not(negated=Any(), default=NO_DEFAULT), default=NO_DEFAULT)
    dict_0 = get_standard_properties(field_0)

# Generated at 2022-06-26 10:23:38.545400
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field_0 = String(max_length=0).as_json_schema()
    field_1 = None
    type_0 = type_from_json_schema(field_0)
    type_1 = type_from_json_schema(field_1)
    assert type_0 == String(max_length=0) and type_1 == String(max_length=0)


# def get_standard_properties(data: dict) -> dict:
#     """
#     Get all standard JSON schema type properties.
#     :param data: JSON Schema data
#     """
#     properties = {}
#     for key in TYPE_CONSTRAINTS:
#         if key in data:
#             properties[key] = data[key]
#     return properties



# Generated at 2022-06-26 10:23:50.170655
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = """{"maxLength": 10, "minLength": 3, "pattern": "^[a-zA-Z0-9]+$"}"""
    data_0 = {"$ref": "#", "type": "string"}
    data_1 = {"$ref": "#", "type": "string", "enum": ["A", "B", "C", "D"]}
    data_2 = {"$ref": "#", "type": "integer"}
    data_3 = {"$ref": "#", "type": "integer", "enum": ["10", "20", "30", "40"]}
    data_4 = {"$ref": "#", "type": "number"}
    data_5 = {"$ref": "#", "type": "number", "enum": ["1.1", "1.2", "1.3", "1.4"]}

# Generated at 2022-06-26 10:23:58.932909
# Unit test for function to_json_schema
def test_to_json_schema():
    definition = {
        "title": "example",
        "definitions": {
            "syntax": {
                "type": "object",
                "patternProperties": {
                    "^_": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "property": {"type": "string"},
                                "values": {
                                    "type": "array",
                                    "items": {"type": "string"},
                                },
                            },
                        },
                    },
                },
            }
        },
    }
    fields = from_json_schema(definition)
    assert fields.to_json_schema() == definition
    assert fields.to_json_schema() == to_json_schema(fields)

    # Test empty

# Generated at 2022-06-26 10:24:06.642342
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from_json_schema({
        "type": "object",
        "properties": {
            "foo": {
                "type": "object",
                "properties": {
                    "bar": {
                        "type": "string",
                        "const": "hello"
                    }
                }
            }
        },
        "not": {
            "type": "object",
            "properties": {
                "baz": {"type": "string"}
            }
        }
    })


# Generated at 2022-06-26 10:24:15.056929
# Unit test for function from_json_schema
def test_from_json_schema():
    # Boolean
    assert from_json_schema(True) == Any()
    assert from_json_schema(True).to_json_schema() == True
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(False).to_json_schema() == False

    # Primitive
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "boolean"}).to_json_schema() == {
        "type": "boolean",
    }

    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string"}).to_json_schema() == {
        "type": "string",
    }



# Generated at 2022-06-26 10:24:25.701112
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_strings = "string"
    allow_null = False
    definitions = SchemaDefinitions()
    data = {
        "type": "string",
        "minLength": 0,
        "maxLength": None,
        "format": None,
        "pattern": None,
        "default": NO_DEFAULT}
    
    assert from_json_schema_type(data, type_strings, allow_null, definitions)
    type_strings = "number"
    allow_null = True
    assert from_json_schema_type(data, type_strings, allow_null, definitions)
    type_strings = "integer"
    assert from_json_schema_type(data, type_strings, allow_null, definitions)
    type_strings = "boolean"

# Generated at 2022-06-26 10:24:31.904451
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    field_0 = Not(negated=Not(negated=Not(negated=Not(negated=Not(negated=Enum(choices=[(1, 1)]))))))
    dict_0 = get_standard_properties(field_0)


# Generated at 2022-06-26 10:24:48.538155
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema_0 = {'if': {'$ref': '#/definitions/if_if'}, 'then': {'$ref': '#/definitions/if_then'}, 'else': {'$ref': '#/definitions/if_else'}}
    json_schema_1 = {'if': {'$ref': '#/definitions/if_if'}, 'then': {'$ref': '#/definitions/if_then'}}

# Generated at 2022-06-26 10:25:45.309868
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test for type_string == 'string', minLength == 0
    data_0 = {'type': 'string', 'minLength': 0}
    type_string_0 = 'string'
    allow_null_0 = False
    definitions_0 = SchemaDefinitions()
    field_0 = from_json_schema_type(data_0, type_string_0, allow_null_0, definitions_0)
    # Validate field_0 with String(allow_blank=True, allow_null=False, default=NO_DEFAULT)
    assert isinstance(field_0, String)
    assert field_0.allow_null is False
    assert field_0.allow_blank is True
    assert field_0.default is NO_DEFAULT

    # Test for type_string == 'string', minLength == 1
    data_

# Generated at 2022-06-26 10:25:51.439961
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data_0 = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    one_of_0 = one_of_from_json_schema(data_0, definitions)
    data_1 = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    one_of_1 = one_of_from_json_schema(data_1, definitions)
    data_2 = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    one_of_2 = one_of_from_json_schema(data_2, definitions)
    data_3 = {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    one_of_3 = one_of_from_json_schema(data_3, definitions)
    data_

# Generated at 2022-06-26 10:25:56.073422
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    bool_0 = False
    bool_1 = True
    list_0 = [bool_0, bool_1]
    field_0 = from_json_schema(list_0)
    str_0 = field_0.__str__()
    pass


# Generated at 2022-06-26 10:26:08.223611
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    string_0 = "integer"
    string_1 = "string"
    string_2 = "decimal"
    data = {"type": string_0, "enum": [1, 2, 3], "definitions": {"decimal": {"type": string_2, "enum": [1.1, 2.2, 3.3]}, "integer": {"type": string_0, "enum": [1, 2, 3]}, "string": {"type": string_1, "enum": ["123", "456", "789"]}}}
    string_3 = "#/definitions/decimal"
    expected_result = Reference(string_3, definitions)
    definitions[string_3] = Any()
    result = ref_from_json_schema(data, definitions)

    assert result == expected_result

# Tests function ref_from_json_

# Generated at 2022-06-26 10:26:19.789308
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(max_length=3)) == dict(
        type="string", maxLength=3, default=None
    )
    assert to_json_schema(String(unique=True)) == dict(
        type="string", uniqueItems=True, default=None
    )
    assert to_json_schema(String(min_length=3)) == dict(
        type="string", minLength=3, default=None
    )
    assert to_json_schema(String(format="email")) == dict(
        type="string", format="email", default=None
    )
    assert to_json_schema(String(allow_blank=False)) == dict(
        type="string", minLength=1, default=None
    )

# Generated at 2022-06-26 10:26:34.181795
# Unit test for function from_json_schema
def test_from_json_schema():

    object_0 = {'$ref': '#', 'type': 'boolean_schema'}
    bool_0 = False
    field_0 = typesystem.from_json_schema(object_0)
    field_0 = typesystem.from_json_schema(bool_0)

    object_0 = {'type': 'integer_schema'}
    bool_0 = False
    field_0 = typesystem.from_json_schema(object_0)
    field_0 = typesystem.from_json_schema(bool_0)

    object_0 = {'type': 'integer_schema'}
    bool_0 = False
    field_0 = typesystem.from_json_schema(object_0)
    field_0 = typesystem.from_json_schema(bool_0)

# Generated at 2022-06-26 10:26:37.232273
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Ignore this line, it just allows the tests to run properly
    field_0 = from_json_schema({"$ref": ""})
    assert field_0.to == "#/", "test failed"


# Generated at 2022-06-26 10:26:48.892895
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    bool_0 = {
      "anyOf": [
        {
          "const": 44.624282003005784,
          "default": True
        },
        False
      ]
    }

    bool_1 = {
      "anyOf": [
        {
          "const": 44.624282003005784,
          "default": True
        },
        False
      ]
    }

    # Call the function
    field_0 = any_of_from_json_schema(bool_0, {})
    field_1 = any_of_from_json_schema(bool_1, {})   

    # Check the value
    assert field_0.any_of == [Const(44.624282003005784, default=True), Boolean(false, default=False)]
    assert field_

# Generated at 2022-06-26 10:26:51.827820
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():

    # Default arrage
    data = {
      "type": "string"
    }
    definitions = {}
    expected = String()

    # Actual output
    actual = one_of_from_json_schema(data, definitions)

    # Compare expected and actual
    assert actual == expected


# Generated at 2022-06-26 10:26:55.406812
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert type(from_json_schema_type({}, 'number', False, {})) == type(Float())


# Generated at 2022-06-26 10:27:13.450475
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-26 10:27:16.969273
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'$ref': '#/definitions/Constraint1'}, {'enum': ['two']}]}
    definitions = SchemaDefinitions()
    definitions['#/definitions/Constraint1'] = Any()
    fields = [from_json_schema(item, definitions=definitions) for item in data['oneOf']]
    assert fields == [Any(), Choice(choices=[('two', 'two')])]


# Generated at 2022-06-26 10:27:19.086176
# Unit test for function from_json_schema
def test_from_json_schema():
    bool_0 = False
    field_0 = from_json_schema(bool_0)
    bool_1 = True
    field_1 = from_json_schema(bool_1)
    assert field_0 == NeverMatch() and field_1 == Any()


# Generated at 2022-06-26 10:27:32.284708
# Unit test for function to_json_schema
def test_to_json_schema():
    # Boolean
    data = {
        "type": "boolean",
        "default": True,
        "nullable": True,
    }
    assert to_json_schema(from_json_schema(data)) == data
    assert data == to_json_schema(Boolean(allow_null=True, default=True))

    # String
    data = {
        "type": "string",
        "minLength": 10,
    }
    assert to_json_schema(from_json_schema(data)) == data
    assert data == to_json_schema(String(min_length=10))

    # Integer

# Generated at 2022-06-26 10:27:40.091060
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-26 10:27:42.941838
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    import random
    import json

    assert isinstance(one_of_from_json_schema({"oneOf" : [True, False, 5]}), OneOf)
    assert isinstance(one_of_from_json_schema({"oneOf" : [True, False, 5]}).one_of, list)
    

# Generated at 2022-06-26 10:27:44.451994
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert issubclass(OneOf, Field)
    assert issubclass(OneOf, Schema)
    assert isinstance(OneOf, OneOf)


# Generated at 2022-06-26 10:27:57.613203
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestCase(Schema):
        field_0 = String(allow_null=False)
        field_1 = Integer(allow_null=False)
        field_2 = Float(allow_null=False)
        field_3 = Decimal(allow_null=False)
        field_4 = Boolean(allow_null=False)
        field_5 = String(allow_null=True)
        field_6 = Integer(allow_null=True)
        field_7 = Float(allow_null=True)
        field_8 = Decimal(allow_null=True)
        field_9 = Boolean(allow_null=True)

    schema = TestCase()
    schema_dict = to_json_schema(schema)

# Generated at 2022-06-26 10:28:06.225992
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data_0 = {
        "type": [
            "object",
        ],
        "properties": {
            "a": {
                "type": [
                    "string",
                ],
            },
        },
    }
    definitions_0 = {
        "a": {
            "type": [
                "string",
            ],
        },
    }
    field_0 = type_from_json_schema(data_0, definitions_0)



# Generated at 2022-06-26 10:28:16.112690
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    definitions = SchemaDefinitions()
    boolean_schema = {
        "$ref": "#/definitions/boolean",
        "type": "boolean",
        "definitions": {"boolean": {"type": "boolean"}},
        "const": True,
        "default": True,
    }
    boolean = from_json_schema_type(
        boolean_schema,
        "boolean",
        False,
        definitions=definitions,
    )
    assert boolean.validate(True) == True, "Boolean doesn't validate True"
    assert boolean.validate(False) == False, "Boolean doesn't validate False"

    boolean_nullable = from_json_schema_type(
        boolean_schema,
        "boolean",
        True,
        definitions=definitions,
    )


# Generated at 2022-06-26 10:28:49.086244
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Unit test for function from_json_schema
    """

# Generated at 2022-06-26 10:29:02.881100
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test type_string = 'null'
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "https://example.com/person.schema.json",
        "title": "Person",
        "description": "A person",
        "type": "null",
        "properties": {
            "firstName": {
                "description": "The person's first name.",
                "type": "string",
            },
            "lastName": {
                "description": "The person's last name.",
                "type": "string",
            },
            "age": {
                "description": "Age in years which must be equal to or greater than zero.",
                "type": "integer",
                "minimum": 0,
            },
        },
    }


# Generated at 2022-06-26 10:29:08.293939
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    bool_0 = bool
    data_0 = {'definitions': {'integer': {'maximum': 1, 'minimum': 1, 'type': 'integer'}}, 'type': 'boolean'}
    definitions_0 = SchemaDefinitions()
    result = type_from_json_schema(data_0, definitions_0)
    assert isinstance(result, bool_0)


# Generated at 2022-06-26 10:29:16.724666
# Unit test for function to_json_schema
def test_to_json_schema():
    field_0 = String(max_length=14, allow_null=True, default=NO_DEFAULT)
    actual_0 = to_json_schema(field_0)
    expected_0 = {
        "type": ["string", "null"],
        "maxLength": 14,
    }
    assert expected_0 == actual_0

    field_1 = Integer.make_validator()
    actual_1 = to_json_schema(field_1, _definitions=None)
    expected_1 = {
        "type": ["integer"],
    }
    assert expected_1 == actual_1

    field_2 = Integer(multiple_of=1.0, default=NO_DEFAULT, allow_null=True)
    actual_2 = to_json_schema(field_2, _definitions=None)


# Generated at 2022-06-26 10:29:27.986170
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(Integer()) == {
        "type": "integer"
    }
    assert to_json_schema(Integer(nullable=False)) == {
        "type": "integer"
    }
    assert to_json_schema(Integer(nullable=True)) == {
        "type": ["integer", "null"]
    }
    assert to_json_schema(Any(nullable=True)) == True
    assert to_json_schema(Any(nullable=False)) == True



# Generated at 2022-06-26 10:29:40.865090
# Unit test for function from_json_schema

# Generated at 2022-06-26 10:29:46.530738
# Unit test for function from_json_schema
def test_from_json_schema():
    import json

    # JSON-schema for an empty Object
    json_0 = {"type": "object", "properties": {}}
    field_0 = from_json_schema(json_0)
    assert field_0.conforms(json_0, strict=True)
    assert not field_0.conforms({"foo": 42})

    def strip_indentation(s: str) -> str:
        lines = [line.strip() for line in s.split("\n")]
        return "\n".join(line for line in lines if line)


# Generated at 2022-06-26 10:29:47.931559
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test 0
    bool_0 = False
    field_0 = from_json_schema(bool_0)
    data_0 = to_json_schema(field_0)


# Generated at 2022-06-26 10:30:04.931469
# Unit test for function from_json_schema_type

# Generated at 2022-06-26 10:30:11.978689
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_schema_0 = {'oneOf': [{'$ref': '#/definitions/Foo', 'const': 'bar', 'enum': [1, 2], 'type': 'string'}, {'const': 'bar', 'enum': [1, 2], 'type': 'string'}, {'$ref': '#/definitions/Foo', 'type': 'string'}]}
    definitions_0 = SchemaDefinitions({"#/definitions/Foo": String()})
    field_0 = one_of_from_json_schema(json_schema_0, definitions_0)


if __name__ == "__main__":
    import bm

    if sys.argv[-1] == "profile":
        # Coverage measurement does not work with cProfile
        import cProfile
