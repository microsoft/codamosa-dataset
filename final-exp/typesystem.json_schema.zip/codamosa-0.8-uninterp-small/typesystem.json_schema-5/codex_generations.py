

# Generated at 2022-06-26 10:21:26.648436
# Unit test for function to_json_schema
def test_to_json_schema():
    print("to_json_schema:")
    import sys
    import json
    import os
    import pathlib
    import unittest
    from dh_segment_torch.config import Params

    def load_config_schema(file_path: pathlib.Path) -> typing.Tuple[Field, dict]:
        with open(file_path, "r") as input_stream:
            data = json.load(input_stream)
        schema_definition = from_json_schema(data)
        definitions = data["definitions"]
        return (schema_definition, definitions)

    def load_config(file_path: pathlib.Path) -> typing.Tuple[Params, Params]:
        with open(file_path, "r") as input_stream:
            data = json.load(input_stream)

# Generated at 2022-06-26 10:21:39.048792
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema(
        {'if': {'$ref': '#/definitions/JSONSchema'}, 'then': {'$ref': '#/definitions/JSONSchema'},
         'else': {'$ref': '#/definitions/JSONSchema'}, 'default': NO_DEFAULT},
        definitions={
            'JSONSchema': Reference('JSONSchema', definitions={
                'JSONSchema': JSONSchema
            })
        }
    ), IfThenElse)

# Generated at 2022-06-26 10:21:43.167760
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    temp_0 = [2, True, 4]
    temp_1 = {"default": "object", "allOf": temp_0}
    temp_2 = all_of_from_json_schema(temp_1)
    temp_3 = temp_2.typesystem_schema
    assert isinstance(temp_3, Field)


# Generated at 2022-06-26 10:21:49.043572
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    value = AllOf(
        [Boolean(), Integer(), Float()],
        default=None,
        description="Sums up the values in a provided list.",
    )
    data = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "allOf": [
            {"type": ["boolean"]},
            {"type": ["integer"]},
            {"type": ["number"]},
        ],
    }
    assert data == to_json_schema(value)



# Generated at 2022-06-26 10:21:58.478418
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    str_0 = "integer"
    str_1 = "string"
    one_of = [str_0, str_1]
    kwargs = {"one_of": one_of}
    var_0 = Field(**kwargs)
    print("var_0:")
    print(var_0)
    assert var_0.to_json_schema() == {"oneOf": [{"type": "integer"}, {"type": "string"}]}
    
    

# Generated at 2022-06-26 10:22:05.936644
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    object_0 = Object(
    properties={
        "allOf": Array(items=Reference("JSONSchema", definitions=definitions))
    },
    additional_properties=False,
)
    var_0 = from_json_schema(object_0)

# Generated at 2022-06-26 10:22:14.102102
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    any_of_json_schema = {'anyOf':[{'type':'integer'},{'type':'string','minLength':1}]}
    any_of_schema = any_of_from_json_schema(any_of_json_schema, definitions=definitions)
    integer_0 = 0
    var_0 = any_of_schema.validate(integer_0)
    str_0 = 'test'
    var_1 = any_of_schema.validate(str_0)
    bool_0 = False
    var_2 = any_of_schema.validate(bool_0)
    
    

# Generated at 2022-06-26 10:22:22.507726
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    var_1:typing.Dict[str, typing.Any]
    var_2:typing.Union[int, None, str]
    var_1 = {'allOf': [{'type': 'number', 'exclusiveMinimum': 5.0}, {'type': 'number', 'minimum': 4.0}], 'default': 3}
    var_2 = to_json_schema(all_of_from_json_schema(data=var_1))
    assert var_2 is not None


# Generated at 2022-06-26 10:22:26.562972
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        'type': 'string'
    }

    type_string = 'string'
    allow_null = False
    definitions = None

    result = from_json_schema_type(data, type_string, allow_null, definitions)
    assert type(result) is String

    data = {
        'type': 'string',
        'minLength': 1
    }

    type_string = 'string'
    allow_null = False
    definitions = None

    result = from_json_schema_type(data, type_string, allow_null, definitions)
    assert type(result) is String

    data = {
        'type': 'number',
        'minimum': 1
    }

    type_string = 'number'
    allow_null = False
    definitions = None

    result = from_json_

# Generated at 2022-06-26 10:22:36.574492
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():  # noqa: D103
    data = {
        "if": {
            "allOf": [
                {"type": "number"},
                {"minimum": 0},
                {"multipleOf": 2},
            ]
        },
        "then": {"type": "string"},
        "else": {"type": "null"},
    }
    definitions = SchemaDefinitions()
    data_type = if_then_else_from_json_schema(data, definitions=definitions)
    assert isinstance(data_type, IfThenElse)
    assert data_type.default == NO_DEFAULT
    assert isinstance(data_type.if_clause, AllOf)
    assert len(data_type.if_clause.all_of) == 3
    assert isinstance(data_type.else_clause, Const)
    assert data

# Generated at 2022-06-26 10:23:01.758902
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    bool_0 = Boolean()
    var_0 = to_json_schema(bool_0)
    bool_1 = Boolean()
    var_1 = to_json_schema(bool_1)
    test_case_0(var_0 == var_1)


# Generated at 2022-06-26 10:23:04.130538
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    string_0 = "lqo6c"
    var_0 = {'$ref': string_0}
    var_1 = Reference(var_0)
    assert var_1 == ref_from_json_schema(
        var_0
    )


# Generated at 2022-06-26 10:23:14.944730
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    bool_0 = False
    dict_0 = {"enum": [1, 2, 3, 4]}
    dict_1 = {"enum": ["a", "b", "c"]}
    dict_2 = {"enum": [1, 2, "a", "b"]}
    dict_3 = {"enum": [1.0, 2.0, 3.0, 4.0]}
    dict_4 = {"enum": [1, 2, 3, 4], "default": 1}
    dict_5 = {"enum": ["a", "b", "c"], "default": "a"}
    dict_6 = {"enum": [1, 2, "a", "b"], "default": "a"}
    dict_7 = {"enum": [1.0, 2.0, 3.0, 4.0], "default": 1.0}
    dict

# Generated at 2022-06-26 10:23:23.705627
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "string",
        "minLength": 0,
        "maxLength": None,
        "format": "",
        "pattern": "",
        "default": NO_DEFAULT,
    }
    type_string = "string"
    allow_null = False
    definitions = {
        "#/definitions/JSONSchema": JSONSchema
    }

    result = from_json_schema_type(
        data, type_string, allow_null, definitions
    )
    assert type(result) == String



# Generated at 2022-06-26 10:23:31.780805
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    print('Unit test for function ref_from_json_schema')
    definitions = SchemaDefinitions()
    definitions['#/definitions/integer'] = Integer()
    data = {'$ref': '#/definitions/integer'}
    res = ref_from_json_schema(data, definitions)


# Generated at 2022-06-26 10:23:36.316285
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    var_0 = False
    var_1 = { "$ref": "string"}
    var_2 = SchemaDefinitions()
    var_3 = ref_from_json_schema(var_1, var_2)
    assert var_3 is not None

#// Keyword argument tests for function ref_from_json_schema

# Generated at 2022-06-26 10:23:46.409287
# Unit test for function to_json_schema
def test_to_json_schema():
    bool_0 = False
    var_0 = Any(default=bool_0)
    var_1 = NeverMatch(default=bool_0)
    var_2 = String(max_length=u"\uecac", pattern=u"\uf4de\u2c70\u3fa3", default=True)
    var_3 = Integer(minimum=u"\uea89", default=False)
    var_4 = Float(default=True)
    var_5 = Decimal(multiple_of=u"\u8fee\udc6a", default=True)
    var_6 = Boolean(default=False)
    var_7 = Array(items=var_0, default=True)
    var_8 = Object(required=[u"\u1f0e"], default=True)
    var_9 = Choice

# Generated at 2022-06-26 10:24:00.472632
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Check if the string  is expected to be true
    assert (
        type_string == "number"
        if "minimum" in data
        else type_string == "integer"
        if "minimum" in data
        else type_string == "string"
        if "minLength" in data
        else type_string == "boolean"
        if "default" in data
        else type_string == "array"
        if "items" in data
        else type_string == "object"
        if "properties" in data
        else None
    )
    # Check that the function object is true

# Generated at 2022-06-26 10:24:02.407756
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert True == False


# Generated at 2022-06-26 10:24:06.706373
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = {
        "oneOf": [
            {"type": "integer", "const": 5},
            {"type": "integer", "const": 8},
            {"type": "string", "const": "frog"},
            {"type": "string", "const": "bar"},
            {"type": "object", "const": {}},
        ]
    }

    result = from_json_schema(schema, definitions=definitions)
    assert type(result) is OneOf
    assert_has_validator(result, Const, const=5)
    assert_has_validator(result, Const, const=8)
    assert_has_validator(result, Const, const="frog")
    assert_has_validator(result, Const, const="bar")
    assert_has_validator(result, Const, const={})




# Generated at 2022-06-26 10:24:49.904935
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # data
    data = {"type":"string", "minLength":0}
    # definitions
    definitions = SchemaDefinitions()
    # type_string
    type_string = "string"
    # allow_null
    allow_null = False
    assert type(from_json_schema_type(
        data, type_string=type_string, allow_null=allow_null, definitions=definitions
    )) == String


# Generated at 2022-06-26 10:24:56.019001
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data_0 = {'anyOf': [{'type': 'string'}, {'type': 'integer'}]}
    field_0 = Any()
    field_1 = any_of_from_json_schema(data_0)
    print(field_1)


# Generated at 2022-06-26 10:25:03.412687
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    enum_0 = enum_from_json_schema({'enum': [1, 2, 3], 'default': 3})
    enum_1 = enum_from_json_schema({'enum': [1, '2', 3]})
    assert enum_0.choices == [(1, 1), (2, 2), (3, 3)], 'assert enum_0.choices == [(1, 1), (2, 2), (3, 3)]'
    assert enum_1.choices == [(1, 1), ('2', '2'), (3, 3)], 'assert enum_1.choices == [(1, 1), (\'2\', \'2\'), (3, 3)]'


# Generated at 2022-06-26 10:25:09.294956
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "const": True,
        "not": {
            "const": False,
        }
    }
    definitions = SchemaDefinitions()
    field = not_from_json_schema(data=data, definitions=definitions)
    assert field.validate(False) == False
    assert field.validate(0) == True
    assert field.validate(True) == False


# Generated at 2022-06-26 10:25:16.700968
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data_0 = {
        "$ref": "#/definitions/id",
        "const": "'foo'",
        "default": "6547322134660804608",
        "oneOf": [
            {"$ref": "#/definitions/flag"},
            {"$ref": "#/definitions/id"},
        ],
    }
    definitions_0 = {
        "#/definitions/id": Integer(
            multiple_of=None,
            minimum=None,
            maximum=None,
            exclusive_minimum=None,
            exclusive_maximum=None,
            allow_nan=False,
            allow_infinity=False,
            default=NO_DEFAULT,
        ),
        "#/definitions/flag": Boolean(default=NO_DEFAULT),
    }

# Generated at 2022-06-26 10:25:21.194444
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    test_schema = {"enum": ["a", "b"]}

    enum_field = enum_from_json_schema(test_schema, definitions)

    correct_field = Choice(choices=[("a", "a"), ("b", "b")])

    assert(enum_field.to_primitive() == correct_field.to_primitive())



# Generated at 2022-06-26 10:25:32.048443
# Unit test for function from_json_schema
def test_from_json_schema():
    # $ref = "https://raw.githubusercontent.com/OAI/OpenAPI-Specification/master/schemas/v3.0/schema.json#/schema/fractionDigits"
    ref_0 = {
        "$ref": "https://raw.githubusercontent.com/OAI/OpenAPI-Specification/master/schemas/v3.0/schema.json#/schema/fractionDigits"
    }
    field_0 = from_json_schema(ref_0)
    # $ref = "https://raw.githubusercontent.com/OAI/OpenAPI-Specification/master/schemas/v3.0/schema.json#/schema/minProperties"

# Generated at 2022-06-26 10:25:36.841384
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    array_0 = []
    array_1 = [1, 2, 3]
    array_2 = [1, 2, 3]
    array_3 = [1, 2, 3]
    array_4 = [1, 2, 3]
    field_0 = enum_from_json_schema()
    assert field_0 is None
    field_0 = enum_from_json_schema(array_0, array_1)
    assert field_0 is None
    field_0 = enum_from_json_schema(array_4, array_3)
    assert field_0 is None
    field_0 = enum_from_json_schema(array_1, array_2)
    assert field_0 is None



# Generated at 2022-06-26 10:25:40.660862
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema(
        {
            "const": "abc"
        },
        definitions={},
    ).to_json_schema() == {
        "const": "abc"
    }


# Generated at 2022-06-26 10:25:42.621993
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_0 = const_from_json_schema({'const':1})
    assert const_0.const == 1


# Generated at 2022-06-26 10:26:48.651418
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test simple cases
    type_string = "string"
    allow_null = True

# Generated at 2022-06-26 10:27:01.385097
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    print("Testing function enum_from_json_schema")

    # Phase 0
    # Preparations
    test_enum_from_json_schema_data = {"enum": [42]}

    # Phase 1
    # Execution
    test_enum_from_json_schema_result = enum_from_json_schema(test_enum_from_json_schema_data, definitions)

    # Phase 2
    # Postconditions and return value
    assert (test_enum_from_json_schema_result == Choice(choices=[[(42, 42)]])), \
        "Function enum_from_json_schema did not return the expected value"

    # Return from function
    return test_enum_from_json_schema_result



# Generated at 2022-06-26 10:27:07.828496
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_0_data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    test_0_value = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    test_0_result = one_of_from_json_schema(test_0_data)
    assert test_0_result == test_0_value

    test_1_data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    test_1_value = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    test_1_result = one_of_from_json_schema(test_1_data)
    assert test_1_result == test_1_value


# Generated at 2022-06-26 10:27:21.177820
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data_0 = {
        "if": {
            "allOf": [
                {"type": "object"},
                {"required": ["a"]},
                {
                    "properties": {
                        "a": {
                            "allOf": [{"type": "number"}, {"maximum": 0}]
                        }
                    }
                },
            ]
        },
        "then": {"enum": [False]},
        "default": {},
    }
    field_0 = if_then_else_from_json_schema(data=data_0)


# Generated at 2022-06-26 10:27:32.458559
# Unit test for function from_json_schema
def test_from_json_schema():
    # Test of boolean field
    bool_0 = True
    bool_1 = False
    field_0 = from_json_schema(bool_0)
    field_1 = from_json_schema(bool_1)
    # Test of enum field
    enum_0 = {"enum": ["1", "2"]}
    enum_1 = {"enum": [True, False]}
    field_2 = from_json_schema(enum_0)
    field_3 = from_json_schema(enum_1)
    # Test of const field
    const_0 = {"const": "1"}
    const_1 = {"const": True}
    field_4 = from_json_schema(const_0)
    field_5 = from_json_schema(const_1)
    # Test of one of field
   

# Generated at 2022-06-26 10:27:38.495108
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data_0 = {'type': 'number', 'format': 'int32', 'minimum': 1, 'maximum': 10}
    field_0 = from_json_schema_type(data_0, type_string='number', allow_null=False, definitions=None)



# Generated at 2022-06-26 10:27:41.392426
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    for items in [[], [1], [1, "a"], [{'type': 'number'}, {'type': 'string'}]]:
        oneOf_1 = {'oneOf': items}
        result = one_of_from_json_schema(oneOf_1, definitions)
        assert(True)


# Generated at 2022-06-26 10:27:49.656640
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema_0 = {"type": "string", "minLength": 0}
    definitions_0 = SchemaDefinitions()
    type_string_0 = "string"
    allow_null_0 = False
    field_0 = from_json_schema_type(json_schema_0, type_string_0, allow_null_0, definitions_0)
    field_1 = String(allow_null=False, allow_blank=True)
    assert field_0 == field_1


# Generated at 2022-06-26 10:28:03.855524
# Unit test for function to_json_schema
def test_to_json_schema():
    def test(
        field: Field,
        expected_bool: bool,
        expected_dict: dict,
    ):
        definitions: dict = {}
        result_bool = to_json_schema(field, _definitions=definitions)
        assert result_bool == expected_bool
        result_dict = to_json_schema(field)
        assert result_dict == expected_dict
        definitions: dict = {}
        result_dict_with_definitions = to_json_schema(
            field, _definitions=definitions
        )
        assert result_dict_with_definitions["definitions"] == definitions

    test(Boolean(allow_null=True), True, {"type": ["boolean", "null"]})

# Generated at 2022-06-26 10:28:05.213078
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data_0 = {'enum': ['a', 'b', 'c']}
    bool_0 = True
    enum_from_json_schema(data_0, bool_0)


# Generated at 2022-06-26 10:28:30.304668
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:28:38.213662
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    any_of_0 = {"anyOf": [{"type": "number"}, {"type": "string"}]}
    field_0 = any_of_from_json_schema(any_of_0)
    assert isinstance(field_0, Union)



# Generated at 2022-06-26 10:28:43.518383
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_then_else = {"if": {"$ref": "if_schema"}, "then": {"$ref": "then_schema"}, "else": {"$ref": "else_schema"}}
    if_schema = {"const": 10}
    then_schema = {"const": 10}
    else_schema = {"const": 10}
    definitions = {"if_schema": if_schema, "then_schema": then_schema, "else_schema": else_schema}
    field_0 = if_then_else_from_json_schema(if_then_else, definitions)



# Generated at 2022-06-26 10:28:52.544182
# Unit test for function to_json_schema
def test_to_json_schema():
    from pydantic.schema import Field
    from pydantic.dataclasses import dataclass
    from pydantic.types import AnyInt, AnyStr

    expected_output_0 = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "a": {"type": ["integer", "null"]},
            "b": {"type": ["string", "null"]},
        },
    }

    @dataclass
    class TestClass_0:
        a: AnyInt
        b: AnyStr

    arg_0 = TestClass_0
    arg_0 = arg_0.make_validator()
    output_0 = to_json_schema(arg_0)
    assert output_0 == expected_output

# Generated at 2022-06-26 10:29:02.165634
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    import typesystem
    from typesystem.types import (
        Union,
        Integer,
    )
    data = {"oneOf": [{"type": "integer", "const": 1}]}
    definitions = typesystem.SchemaDefinitions()
    field_0 = one_of_from_json_schema(data=data, definitions=definitions)
    assert isinstance(field_0, Union)
    assert isinstance(field_0.any_of[0], Integer)
    assert field_0.any_of[0].const == 1


# Generated at 2022-06-26 10:29:11.526994
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.fields import Field

    expected_0 = Choice(choices=(('enum_item_0', 'enum_item_0'), ('enum_item_1', 'enum_item_1')))
    actual_0 = one_of_from_json_schema({'oneOf': [{'enum': ['enum_item_0', 'enum_item_1']}]})
    assert repr(actual_0) == repr(expected_0)
    expected_1 = Field()
    actual_1 = one_of_from_json_schema({'oneOf': [None]})
    assert repr(actual_1) == repr(expected_1)
    expected_2 = Field()
    actual_2 = one_of_from_json_schema({'oneOf': []})

# Generated at 2022-06-26 10:29:18.523455
# Unit test for function to_json_schema
def test_to_json_schema():

    # Test: check if empty schema data is returned when Field object is passed
    schema_data = to_json_schema(Field())
    assert isinstance(schema_data, dict) and len(schema_data.keys()) == 0

    # Test: check if empty schema data is returned when Field object with True
    #       "allow_null" property is passed
    schema_data = to_json_schema(Field(allow_null=True))
    assert isinstance(schema_data, dict) and len(schema_data.keys()) == 0

    # Test: check if schema data with "type" key is returned when Field object
    #       is passed
    schema_data = to_json_schema(Field())
    assert isinstance(schema_data, dict) and len(schema_data.keys()) == 0


################################

# Generated at 2022-06-26 10:29:30.107333
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_0 = {"$ref": "#/definitions/TestSchemaA"}
    json_1 = {"$ref": "#/definitions/TestSchemaB"}
    json_2 = {"anyOf": [json_0, json_1]}
    json_3 = "#/definitions/TestSchemaC"
    definitions_0 = SchemaDefinitions()
    definitions_0["#/definitions/TestSchemaA"] = Reference(to="TestSchemaA", definitions=definitions_0)
    definitions_0["#/definitions/TestSchemaB"] = Reference(to="TestSchemaB", definitions=definitions_0)
    definitions_0["#/definitions/TestSchemaC"] = Reference(to="TestSchemaC", definitions=definitions_0)

# Generated at 2022-06-26 10:29:41.873055
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-26 10:29:50.918164
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test 1
    one_of = [Any(), NeverMatch()]
    data = {"oneOf": one_of}
    field_0 = OneOf(one_of=one_of, default=None)
    field_1 = one_of_from_json_schema(data, definitions=definitions)
    assert field_0 == field_1

