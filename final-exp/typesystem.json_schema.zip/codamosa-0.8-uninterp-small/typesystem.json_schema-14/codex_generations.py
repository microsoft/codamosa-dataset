

# Generated at 2022-06-26 10:21:16.368430
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_schema_obj = {'not': {'type': 'string'}}
    field_0 = not_from_json_schema(test_schema_obj, None)
    field_0.validate(4, None)
    field_0.validate('not-a-string', None)


# Generated at 2022-06-26 10:21:27.298491
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    # Test a simple ref string
    ref_str = "#/definitions/test"
    definitions = SchemaDefinitions()
    reference = ref_from_json_schema({"$ref": ref_str}, definitions)

    assert reference.to == ref_str

    # Test a ref string and add a definition for the ref'd field
    ref_str = "#/definitions/test"
    definitions = SchemaDefinitions()
    field = from_json_schema({"type": "integer"})
    definitions[ref_str] = field

    reference = ref_from_json_schema({"$ref": ref_str}, definitions)
    assert reference.to == ref_str

    # Test a ref string without a definition
    ref_str = "#/definitions/test"
    definitions = SchemaDefinitions()
    field = from_

# Generated at 2022-06-26 10:21:39.798379
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    kwargs_0 = {
        "allow_null": False,
        "minimum": None,
        "maximum": None,
        "exclusive_minimum": None,
        "exclusive_maximum": None,
        "multiple_of": None,
        "default": NO_DEFAULT,
    }
    schema_definitions_0 = module_0.SchemaDefinitions()

# Generated at 2022-06-26 10:21:43.955836
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {}
    str_0 = "number"
    bool_0 = False
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = from_json_schema_type(dict_0, str_0, bool_0, schema_definitions_0)


# Generated at 2022-06-26 10:21:51.544257
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:21:57.606516
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': [1, 2, 3]}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = enum_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:22:06.141730
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {'allOf': [{'const': 'a'}, {'const': 'b'}, {'const': 'c'}]}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = all_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:22:08.111613
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {'if': {'type': 'integer'}, 'then': {'type': 'integer'}, 'default': 0}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:22:15.761366
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {
        "oneOf": [
            {
                "title": "empty",
                "type": "any",
                "allOf": [
                    {
                        "type": "object",
                        "additionalProperties": {"$ref": "#/definitions/Empty"},
                    }
                ],
            }
        ]
    }
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)
    str_0 = "OneOf(one_of=[Object(properties={'additionalProperties': " + str(
        field_0.one_of[0]["additionalProperties"]
    ) + "}, type='object')], default=NO_DEFAULT)"

# Generated at 2022-06-26 10:22:23.080292
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {"$ref": "#/definitions/Product"}
    schema_definitions_0 = module_0.SchemaDefinitions()
    schema_definitions_0[dict_0["$ref"]] = "MODULE_HERE.Reference"
    field_0 = ref_from_json_schema(dict_0, schema_definitions_0)
    if isinstance(field_0, Reference):
        assert field_0.to == dict_0["$ref"]



# Generated at 2022-06-26 10:23:18.405440
# Unit test for function to_json_schema
def test_to_json_schema():

    class BasicSchema(Schema):
        name = String(min_length=2, max_length=5, pattern=r"A*")
        number = Integer(minimum=42)

    basic_schema = BasicSchema()
    basic_schema.validate({"name": "ABC", "number": 42})

    to_json_schema(basic_schema)

    definitions = to_json_schema(basic_schema).get("definitions")
    assert definitions is not None
    ref_schema = definitions["BasicSchema"]

# Generated at 2022-06-26 10:23:26.011129
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {'allOf': [{'title': 'First', 'not': {'type': 'string'}, 'const': 'a', 'type': 'integer'}, {'type': 'boolean'}, {'type': 'boolean'}, {'type': 'string'}], 'description': 'A schema with an allOf composition', 'title': 'AllOf composition'}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = from_json_schema_type(dict_0, 'integer', False, schema_definitions_0)

# Generated at 2022-06-26 10:23:33.176886
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {"type": "string"}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = from_json_schema_type(dict_0, "string", True, schema_definitions_0)


# Generated at 2022-06-26 10:23:35.460004
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {'$ref': '#/definitions/type2'}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:23:47.092672
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data_0 = {}
    type_string_0 = 'number'
    allow_null_0 = True
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = from_json_schema_type(data_0, type_string_0, allow_null_0, schema_definitions_0)
    assert isinstance(field_0, module_0.Float)
    assert field_0.allow_null == True
    assert field_0.minimum == None
    assert field_0.maximum == None
    assert field_0.default == None

    data_1 = {'maximum': 8, 'minimum': 50}
    type_string_1 = 'number'
    allow_null_1 = False
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_

# Generated at 2022-06-26 10:23:50.140655
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_1 = {"const": 1}
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_1 = any_of_from_json_schema(dict_1, schema_definitions_1)


# Generated at 2022-06-26 10:24:05.250471
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test example 0
    dict_0 = {}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = all_of_from_json_schema(dict_0, schema_definitions_0)
    boolean_0 = to_json_schema(field_0, schema_definitions_0)

    # Test example 1
    dict_0 = {}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = all_of_from_json_schema(dict_0, schema_definitions_0)
    boolean_0 = to_json_schema(field_0, schema_definitions_0)

    # Test example 2
    boolean_0 = True
    field_0 = from_json_schema(boolean_0, {})


# Generated at 2022-06-26 10:24:14.542897
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({"type": "number"}, "number"), typesystem._fields.Float)
    assert isinstance(from_json_schema_type({"type": "integer"}, "integer"), typesystem._fields.Integer)
    assert isinstance(from_json_schema_type({"type": "string"}, "string"), typesystem._fields.String)
    assert isinstance(from_json_schema_type({"type": "boolean"}, "boolean"), typesystem._fields.Boolean)
    assert isinstance(from_json_schema_type({"type": "array"}, "array"), typesystem._fields.Array)
    assert isinstance(from_json_schema_type({"type": "object"}, "object"), typesystem._fields.Object)

# Generated at 2022-06-26 10:24:16.130601
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:24:31.041951
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():

    def throw():
        raise AssertionError()

    def test(input: dict, definitions: module_0.SchemaDefinitions) -> module_0.Field:

        key = list(input.keys())[0]

        if key == 'allOf':
            any_of = [from_json_schema(item, definitions=module_0.SchemaDefinitions()) for item in input['allOf']]
            kwargs = {'all_of': any_of, 'default': input.get('default', module_0.NO_DEFAULT)}

            return module_0.AllOf(**kwargs)

        elif key == 'anyOf':
            any_of = [from_json_schema(item, definitions=module_0.SchemaDefinitions()) for item in input['anyOf']]

# Generated at 2022-06-26 10:25:49.239974
# Unit test for function to_json_schema
def test_to_json_schema():
    var_2 = to_json_schema(String())
    assert var_2 == {'type': 'string', 'default': NO_DEFAULT}
    var_3 = to_json_schema(String(default='hello'))
    assert var_3 == {'type': 'string', 'default': 'hello'}
    var_4 = to_json_schema(String(allow_null=True))
    assert var_4 == {'type': ['string', 'null'], 'default': NO_DEFAULT}


# Generated at 2022-06-26 10:25:50.670013
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert False, "TEST INCOMPLETE"


# Generated at 2022-06-26 10:25:52.699088
# Unit test for function to_json_schema
def test_to_json_schema():
    test_case_0()

# Generated at 2022-06-26 10:26:04.590621
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Some initial test to prove the function works
    test_case_0()

    # Create the input for the function
    var_2 = 2.0
    var_3 = 3.0
    var_4 = String(min_length = var_2, max_length = var_3)

    # Use the function
    # TODO: Add test for this
    # fixme:
    # var_5 = any_of_from_json_schema(var_4)

    # Format the result
    out_0 = "anyOf"
    out_1 = "["
    out_2 = "{"
    out_3 = "type"
    out_4 = ":"
    out_5 = "'string'"
    out_6 = ","
    out_7 = "minLength"
    out_8 = ":"
    out

# Generated at 2022-06-26 10:26:12.766661
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    var_0 = {"anyOf": [{"type": "string"}, {"type": "number"}], "default": None}
    var_1 = any_of_from_json_schema(var_0, definitions=SchemaDefinitions())
    assert var_1.__class__ == Union
    assert var_1.allow_null == False
    assert len(var_1.any_of) == 2
    assert var_1.any_of[0].__class__ == String
    assert var_1.any_of[1].__class__ == Number


# Generated at 2022-06-26 10:26:14.748781
# Unit test for function from_json_schema
def test_from_json_schema():
    var = None
    print(var)



# Generated at 2022-06-26 10:26:18.395717
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    var_0 = None
    var_1 = any_of_from_json_schema(var_0, None)
    assert var_1 == None


# Generated at 2022-06-26 10:26:22.178585
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    all_of = [{"type": "number"}, {"type": "string"}]
    data = {"anyOf": all_of}
    res = any_of_from_json_schema(data, None)


# Generated at 2022-06-26 10:26:26.726071
# Unit test for function from_json_schema
def test_from_json_schema():
    try:
        assert var_1.__name__ == "Any"
    except Exception as e:
        print("Test case 0 : fail")



# Generated at 2022-06-26 10:26:28.774565
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(None) is None


# Generated at 2022-06-26 10:27:02.495811
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(data={}, type_string='string', allow_null=True, definitions=definitions) == String(allow_null=True)
    assert from_json_schema_type(data={}, type_string='string', allow_null=False, definitions=definitions) == String(allow_null=False)
    assert from_json_schema_type(data={'maxLength': 0}, type_string='string', allow_null=True, definitions=definitions) == String(allow_null=True, max_length=0)
    assert from_json_schema_type(data={'default': 1}, type_string='boolean', allow_null=True, definitions=definitions) == Boolean(allow_null=True, default=1)

# Generated at 2022-06-26 10:27:12.038556
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(None) == {"$ref": "#/definitions/none"}
    assert to_json_schema(str) == {"$ref": "#/definitions/str"}
    assert to_json_schema(int) == {"$ref": "#/definitions/int"}
    assert to_json_schema(float) == {"$ref": "#/definitions/float"}
    assert to_json_schema(Decimal) == {"$ref": "#/definitions/decimal"}
    assert to_json_schema(bool) == {"$ref": "#/definitions/bool"}
    assert to_json_schema(dict) == {"$ref": "#/definitions/dict"}
    assert to_json_schema(list) == {"$ref": "#/definitions/list"}
    assert to_json

# Generated at 2022-06-26 10:27:17.548811
# Unit test for function to_json_schema
def test_to_json_schema():
    var_0 = None
    var_0 = to_json_schema(var_0)
    var_1 = {
        "type": "null",
    }
    assert compare_json(var_0, var_1)

    var_2 = String(min_length=1, max_length=5, allow_null=True)
    var_2 = to_json_schema(var_2)
    var_3 = {
        "type": ["string", "null"],
        "maxLength": 5,
        "minLength": 1,
    }
    assert compare_json(var_2, var_3)


# Generated at 2022-06-26 10:27:23.214907
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string = '''integer'''
    allow_null = True
    data = {'uniqueItems': True, 'pattern': '^[a-z]$', 'type': 'number', 'format': 'int32'}
    definitions = {'': {}, '#/definitions/B': 1, '$ref': '#/definitions/B'}
    var_0 = from_json_schema_type(data, type_string, allow_null, definitions)


# Generated at 2022-06-26 10:27:29.585767
# Unit test for function to_json_schema
def test_to_json_schema():

    # This is a static test case for the function to_json_schema
    # The successful assertion for this test case should raise no AssertionError

    # The dynamic test case is parameterized and is dependent on the
    # data type of the parameters
    var_0 = None
    var_1 = to_json_schema(var_0)


# Generated at 2022-06-26 10:27:36.228127
# Unit test for function from_json_schema
def test_from_json_schema():
    json = {
  "type": "object",
  "properties": {
    "title": {
      "type": "string"
    },
    "content": {
      "type": "string"
    },
    "author": {
      "type": "string"
    }
  },
  "required": [
    "title",
    "content",
    "author"
  ]
}

    fields = from_json_schema(json)
    assert fields.to_json_schema() == json


# Generated at 2022-06-26 10:27:46.228122
# Unit test for function from_json_schema
def test_from_json_schema():
    definitions = SchemaDefinitions()
    data = {
        "$schema": "http://json-schema.org/draft/2020-12/schema",
        "$id": "http://example.com/bar",
        "$ref": "#/definitions/foo",
        "title": "Foo",
        "description": "Foo description",
        "definitions": {
            "foo": {
                "title": "Foo",
                "description": "Foo description",
                "type": "boolean",
            }
        },
    }
    expected_result = Boolean()
    result = from_json_schema(data, definitions=definitions)
    assert result == expected_result

    result_str = str(result)
    expected_result_str = 'Boolean(default="Valid")'
    assert result_

# Generated at 2022-06-26 10:27:47.516345
# Unit test for function from_json_schema
def test_from_json_schema():
    assert 0


# Generated at 2022-06-26 10:27:51.135953
# Unit test for function to_json_schema
def test_to_json_schema():
    filename = inspect.getfile(test_to_json_schema)
    pytest.main([filename])

test_case_0()

# Generated at 2022-06-26 10:27:53.764311
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    var_0 = {"type": "string"}
    var_1 = to_json_schema(var_0)


# Generated at 2022-06-26 10:28:20.241614
# Unit test for function from_json_schema
def test_from_json_schema():
    assert callable(from_json_schema)


# Generated at 2022-06-26 10:28:30.871749
# Unit test for function to_json_schema
def test_to_json_schema():
    assert {} == to_json_schema(Any())
    assert {} == to_json_schema(NeverMatch())
    assert {} == to_json_schema(NoneField())
    assert {} == to_json_schema(null_field)
    assert {} == to_json_schema(NoneOptionalField())
    assert {} == to_json_schema(optional_null_field)

    assert {} == to_json_schema(Integer(0))
    assert {} == to_json_schema(Integer(1))

    assert {} == to_json_schema(String(""))
    assert {} == to_json_schema(String("test"))

    assert {} == to_json_schema(Boolean(False))
    assert {} == to_json_schema(Boolean(True))

    assert {} == to_json_

# Generated at 2022-06-26 10:28:48.261073
# Unit test for function from_json_schema
def test_from_json_schema():
    print("from_json_schema()")

    definitions = SchemaDefinitions()
    definitions['#/foo'] = {
        'type': 'string',
        'format': 'uuid',
        'required': True
    }

    # Test 'from_json_schema' function
    print("from_json_schema()")

    schema = {
        'type': 'object',
        'properties': {
            'foo': {
                '$ref': '#/foo'
            }
        }
    }

    assert from_json_schema(schema, definitions=definitions) == Object(properties={
        'foo': String(format='uuid')
    })



# Generated at 2022-06-26 10:29:02.762304
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()

    assert from_json_schema({"type": "integer", "enum": [1]}) == Const(1)
    assert from_json

# Generated at 2022-06-26 10:29:10.557580
# Unit test for function to_json_schema
def test_to_json_schema():
    string: typing.Optional[str] = None
    array: typing.Optional[typing.List[str]] = None
    number = 123
    number_float = 123.456
    boole = True

    # Test empty schema
    field = from_json_schema({}, {})
    assert field.validate(string) is None
    assert field.validate(array) is None
    assert field.validate(number) is None
    assert field.validate(number_float) is None
    assert field.validate(boole) is None

    # Test simple string
    field = String()
    dict_string = to_json_schema(field)
    assert dict_string == {"type": "string"}
    field_test = from_json_schema(dict_string)

# Generated at 2022-06-26 10:29:18.002403
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.base import Constraint

    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}

# Generated at 2022-06-26 10:29:29.854358
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {"type":"object","properties":{},"items":{},"additionalProperties":{},"required":True}
    schema_0 = from_json_schema(dict_0)
    dict_1 = to_json_schema(schema_0)
    assert(dict_0==dict_1) # "dict_0 is correctly converted back to json_schema"

    dict_2 = {"type":"object","properties":{},"items":{},"additionalProperties":{},"patternProperties":{"^[0-9]+$":{"type":"string"}}}
    schema_1 = from_json_schema(dict_2)
    dict_3 = to_json_schema(schema_1)
    assert(dict_2==dict_3) # "dict_2 is correctly converted back to json_schema"

    dict

# Generated at 2022-06-26 10:29:39.803954
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    dict_0 = {"type": "integer"}
    field_0 = type_from_json_schema(dict_0, definitions)
    assert isinstance(field_0, Field)
    dict_1 = {"type": ["integer", "boolean"]}
    field_1 = type_from_json_schema(dict_1, definitions)
    assert isinstance(field_1, Field)
    dict_2 = {}
    field_2 = type_from_json_schema(dict_2, definitions)
    assert isinstance(field_2, Field)


# Generated at 2022-06-26 10:29:54.994666
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema_0 = {
        'if': {'type': 'string'},
        'then': {'minLength': 3},
        'else': {'type': 'number'},
    }
    field_0 = if_then_else_from_json_schema(schema_0, definitions={})
    assert(field_0.validate("") is False)
    assert(field_0.validate(3) is True)
    assert(field_0.validate(".") is False)
    assert(field_0.validate("abc") is True)
    schema_1 = {
        'if': {'type': 'string'},
        'then': {'minLength': 3},
    }
    field_1 = if_then_else_from_json_schema(schema_1, definitions={})


# Generated at 2022-06-26 10:30:06.082479
# Unit test for function to_json_schema
def test_to_json_schema():
    _any = Any()
    dict_0 = to_json_schema(_any)
    assert dict_0 == True

    integer_0 = Integer()
    dict_1 = to_json_schema(integer_0)
    assert dict_1 == {"type": "integer"}

    integer_0 = Integer(min_length=5)
    dict_0 = to_json_schema(integer_0)
    assert dict_0 == {"type": "integer", "minLength": 5}

    integer_0 = Integer(allow_null=True)
    dict_0 = to_json_schema(integer_0)
    assert dict_0 == {"type": ["integer", "null"]}

    integer_0 = Integer(allow_null=True)
    dict_0 = to_json_schema(integer_0)