

# Generated at 2022-06-26 10:21:09.994102
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    dict_0 = {'const': 3}
    definitions_0 = module_0.SchemaDefinitions()
    field_0 = const_from_json_schema(dict_0, definitions_0)
    assert field_0.default == None


# Generated at 2022-06-26 10:21:16.655813
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = None
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:21:22.112389
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': [1]}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = enum_from_json_schema(dict_0, schema_definitions_0)

    return True


# Generated at 2022-06-26 10:21:32.751926
# Unit test for function get_valid_types
def test_get_valid_types():
    dict_0 = {'type': 'object'}
    assert get_valid_types(dict_0) == ({'object'}, False)

    dict_1 = {'type': 'number'}
    assert get_valid_types(dict_1) == ({'number'}, False)

    dict_2 = {'type': ['number', 'array']}
    assert get_valid_types(dict_2) == ({'number', 'array'}, False)

    dict_3 = {'type': ['number', 'array'], 'nullable': True}
    assert get_valid_types(dict_3) == ({'number', 'array'}, True)

    dict_4 = {'type': ['number', 'null'], 'nullable': True}

# Generated at 2022-06-26 10:21:37.157935
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = None
    field_0 = ref_from_json_schema(dict_0, None)
import typesystem.fields as module_0
import typesystem.schemas as module_1


# Generated at 2022-06-26 10:21:37.798458
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert False



# Generated at 2022-06-26 10:21:38.406904
# Unit test for function from_json_schema
def test_from_json_schema():
    any_of_from_json_schema


# Generated at 2022-06-26 10:21:46.828859
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # no json schema type
    dict_0 = None
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = type_from_json_schema(dict_0, schema_definitions_0)

    # single json schema type
    dict_1 = None
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_1 = type_from_json_schema(dict_1, schema_definitions_1)

    # multiple json schema types
    dict_2 = None
    schema_definitions_2 = module_0.SchemaDefinitions()
    field_2 = type_from_json_schema(dict_2, schema_definitions_2)



# Generated at 2022-06-26 10:21:52.152673
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_1 = None
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_1 = any_of_from_json_schema(dict_1, schema_definitions_1)


# Generated at 2022-06-26 10:22:03.959541
# Unit test for function const_from_json_schema
def test_const_from_json_schema():

    # Test 0
    dict_0 = {'default': 'default_0', 'const': 'const_0'}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = const_from_json_schema(dict_0, schema_definitions_0)
    assert field_0.default == 'default_0'
    assert field_0.const == 'const_0'

    # Test 1
    dict_1 = {'const': 123}
    schema_definitions_1 = module_0.SchemaDefinitions()
    field_1 = const_from_json_schema(dict_1, schema_definitions_1)
    assert field_1.const == 123
    assert field_1.default is module_0.NO_DEFAULT


# Generated at 2022-06-26 10:22:43.328321
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Setting up initial data
    dict_0 = dict()
    dict_1 = dict()
    dict_0["const"] = "Z"
    dict_0["const"] = "Z"
    dict_1["const"] = "Z"
    dict_1["const"] = "Z"
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"] = [dict_1]
    dict_0["oneOf"]

# Generated at 2022-06-26 10:22:53.897201
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    @SimplePattern
    def pattern(data: str):
        return data == "apple"

    data1 = {"type": "string"}
    data2 = {"type": "string"}
    data3 = {"type": "string", "const": "apple"}
    data4 = {"if": data1, "then": data2, "else": data3}
    data5 = {"type": "string", "format": "pattern", "pattern": pattern}
    data6 = {"if": data1, "then": data2, "else": data5}

    data7 = [data1, data2, data3]
    data8 = {"if": data1, "then": data7, "else": data5}

    data9 = [data1, data2, data3]

# Generated at 2022-06-26 10:23:01.279572
# Unit test for function to_json_schema
def test_to_json_schema():
    class DummySchema(Schema):
        """This is a dummy docstring for the schema."""
        field_0 = Integer(description="This is a dummy docstring.")
        field_1 = Any(description="This is a dummy docstring.")
        field_2 = Not(Any(description="This is a dummy docstring."))
        field_3 = Object(properties={"field_0": Any()})
        field_4 = Array(items=Any())
        field_5 = Const(1)
        field_6 = Float(default=1.0)
        field_7 = Boolean(allow_null=True, default=False)
        field_8 = Const(1, allow_null=True)
        field_9 = Choice(choices=[(1, "one"), (2, "two")])


# Generated at 2022-06-26 10:23:13.941007
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema:
        y = Choice(choices=[(0, 0), (1, 1)])
        v = String()
        b = String(allow_blank=True, min_length=0, max_length=None, format="hello")
        c = String(
            allow_blank=True,
            min_length=None,
            max_length=0,
            format="hello",
            pattern_regex=re.compile(".*"),
        )
        d = String(allow_blank=True, min_length=0, max_length=None, pattern_regex=re.compile(".*"), format="hello")
        e = String(allow_blank=True, min_length=None, max_length=0, pattern_regex=re.compile(".*"), format="hello")
        f

# Generated at 2022-06-26 10:23:25.499452
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dict_1 = {False:bool_0, True:bool_0, bool_0:bool_0, bool_0:bool_0}
    assert type_from_json_schema(dict_0, dict_1) == dict_0
    dict_2 = {False:bool_0, False:bool_0, True:bool_0, bool_0:bool_0}
    assert type_from_json_schema(dict_1, dict_2) == dict_2
    dict_3 = {False:bool_0, False:bool_0, True:bool_0, True:bool_0}
    assert type_from_

# Generated at 2022-06-26 10:23:38.618918
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dict_1 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dict_2 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dict_3 = {bool_0: bool_0}
    dict_4 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}

# Generated at 2022-06-26 10:23:50.257056
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({}), Any)
    assert isinstance(from_json_schema({}), Field)
    assert from_json_schema({}).validate({}) == {}

    assert from_json_schema({"type": "integer"}).validate(1) == 1
    assert from_json_schema({"type": "integer"}).validate(1.0) == 1.0
    assert from_json_schema({"type": "number"}).validate(1) == 1
    assert from_json_schema({"type": "number"}).validate(1.0) == 1.0
    assert from_json_schema({"type": "string"}).validate("foo") == "foo"

# Generated at 2022-06-26 10:24:05.354491
# Unit test for function not_from_json_schema
def test_not_from_json_schema():

    dict_0 = {
        'type': 'not_from_json_schema',
        'keyword': 'not_from_json_schema',
        'reference': 'not_from_json_schema',
        'keyword': 'not_from_json_schema',
    }
    dict_0["type"] = dict_0.get("type", "not_from_json_schema")
    dict_0["keyword"] = dict_0.get("type", "not_from_json_schema")
    dict_0["reference"] = dict_0.get("type", "not_from_json_schema")
    dict_0["keyword"] = dict_0.get("reference", "not_from_json_schema")
    assert not_from_json_schema(dict_0) == False

# Generated at 2022-06-26 10:24:20.073297
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
  # Test data for definitions
  definitions_0 = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  definitions_1 = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  definitions_2 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
  definitions_3 = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  definitions_4 = [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  definitions_5 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}

# Generated at 2022-06-26 10:24:23.771335
# Unit test for function from_json_schema
def test_from_json_schema():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    field_0 = from_json_schema(bool_0)
    print(field_0)



# Generated at 2022-06-26 10:24:55.651111
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from .fields import Field
    from .fields import Any
    from .fields import Boolean
    data = {'if': {'type': 'boolean'}, 'then': {'type': 'boolean'}, 'default': True}
    definitions = None
    if_then_else_from_json_schema(data, definitions)
    assert True


# Generated at 2022-06-26 10:25:04.357046
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Assert that every path through the function results in an assertion
    """

# Generated at 2022-06-26 10:25:06.651624
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert callable(all_of_from_json_schema)


# Generated at 2022-06-26 10:25:14.562886
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {"type": "array", "items": {"type": "integer"}}
    json_schema = from_json_schema(schema)
    assert issubclass(json_schema.__class__, Array)
    assert issubclass(json_schema.items.__class__, Integer)

    schema = {"type": "boolean"}
    json_schema = from_json_schema(schema)
    assert issubclass(json_schema.__class__, Boolean)

    schema = {"type": "string"}
    json_schema = from_json_schema(schema)
    assert issubclass(json_schema.__class__, String)



# Generated at 2022-06-26 10:25:19.568858
# Unit test for function to_json_schema
def test_to_json_schema():
    # Initialize test data
    class_0 = {'r': '|', '1dD': 'T', 'Jf': '7', '+Q': 'J;', '@d': 'V', '+9X': '6q'}
    class_1 = {'x': 'A3', 'Lm': ':f', '%9': 'E', 'G': '+4', 'BcG': '43', 'f': 'E2'}

# Generated at 2022-06-26 10:25:26.648009
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    array_0 = []
    dict_0 = {array_0: array_0, array_0: array_0, array_0: array_0, array_0: array_0}
    bool_0 = True
    field_0 = any_of_from_json_schema(dict_0, schem)
    # assert falgs
    assert field_0 is not None


# Generated at 2022-06-26 10:25:30.900198
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    field_0 = from_json_schema(dict_0)
    assert field_0.default == NO_DEFAULT


# Generated at 2022-06-26 10:25:34.293486
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    field_0 = ref_from_json_schema(dict_0)
    assert field_0 is not None


# Generated at 2022-06-26 10:25:37.775309
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference_string = data["$ref"]
    assert reference_string.startswith("#/"), "Unsupported $ref style in document."
    return Reference(to=reference_string, definitions=definitions)


# Generated at 2022-06-26 10:25:47.814714
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    str_0 = "T"
    list_0 = [{str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}]
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    list_0.append(list_0)
    bool_0 = True

# Generated at 2022-06-26 10:26:31.635661
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string = "integer"
    data = {"minimum": 1, "maxLength": None, 'multipleOf': None}
    field = from_json_schema_type(data, type_string, False, SchemaDefinitions())
    assert field.min_value == 1
    
    
    type_string = "number"
    data = {"maximum": 33.0, "maxLength": None, 'multipleOf': None}
    field = from_json_schema_type(data, type_string, False, SchemaDefinitions())
    assert field.max_value == 33


# Generated at 2022-06-26 10:26:37.826100
# Unit test for function to_json_schema
def test_to_json_schema():
    field_0: typing.Optional[Field] = String()
    bool_0 = to_json_schema(field_0)
    bool_1 = to_json_schema(field_0)
    bool_0 = to_json_schema(field_0)
    assert bool_1 or bool_0
    bool_0 = to_json_schema(field_0)
    bool_1 = to_json_schema(field_0)
    assert bool_1 or bool_0
    bool_0 = to_json_schema(field_0)
    bool_1 = to_json_schema(field_0)
    assert bool_1 or bool_0
    bool_0 = to_json_schema(field_0)
    bool_1 = to_json_schema(field_0)
   

# Generated at 2022-06-26 10:26:46.847049
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [{}, {}],
        "default": {},
        "not": {},
        "if": {},
        "then": {},
        "else": {},
    }
    definitions = SchemaDefinitions()
    definitions["JSONSchema"] = JSONSchema

    field_0 = one_of_from_json_schema(data, definitions=definitions)
    assert field_0 is not None
    assert isinstance(field_0, OneOf)


# Generated at 2022-06-26 10:26:57.415211
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-26 10:27:10.748346
# Unit test for function from_json_schema
def test_from_json_schema():
    bool_0 = False
    bool_1 = True
    dict_0 = {bool_1: bool_0, bool_0: bool_0, bool_0: bool_0, bool_1: bool_1}
    dict_1 = {bool_0: bool_0, bool_0: bool_0, bool_1: bool_1, bool_1: bool_1}
    dict_2 = {bool_0: dict_0, bool_1: dict_1, bool_1: dict_1, bool_0: dict_0}
    dict_3 = {bool_0: bool_1, bool_1: bool_0, bool_1: bool_1, bool_0: bool_0}

# Generated at 2022-06-26 10:27:12.832124
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of_from_json_schema(
        {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {"oneOf": {}}}}}}}}}}},
        None)


# Generated at 2022-06-26 10:27:22.416500
# Unit test for function from_json_schema
def test_from_json_schema():
    # Input parameters
    bool_0 = True
    bool_1 = False
    tuple_0 = (bool_1, bool_1, bool_1, bool_1)
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    set_0 = {bool_1, tuple_0, dict_0}
    # Output: field_0
    field_0 = from_json_schema({})
    dict_1 = {'maximum': True}
    dict_2 = {'definitions': dict_1}
    # Output: field_1
    field_1 = from_json_schema(dict_0)
    dict_3 = {"type": 'type'}

# Generated at 2022-06-26 10:27:34.955323
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    items_0 = []
    items_1 = [None, 'a', None, None, None, None, None, 'c', 'c', 'c', None, None]
    items_2 = ['x4A4', 'x4A4', None, None, 'x4A4', None, 'x4A4', 'x4A4']
    items_3 = [None, 'f', 'f', 'f', 'f', None, None]
    items_4 = ['b', None, None, None, None, 'b', 'b', 'b', 'b']
    items_5 = [None, None, None, None, None, None, 'a', 'a']

# Generated at 2022-06-26 10:27:45.712549
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    test_data = {
        "type": "array",
        "required": True,
        "minItems": 4,
        "maxItems": 8,
        "items": [
            {
                "type": "string",
                "required": True,
                "minLength": 4,
                "maxLength": 8,
                "pattern": "^[a-zA-Z0-9]*$",
            },
            {
                "type": "string",
                "required": True,
                "minLength": 4,
            },
        ],
        "additionalItems": {
            "type": "string",
            "required": False,
            "minLength": 4,
            "maxLength": 8,
            "pattern": "^[a-zA-Z0-9]*$",
        },
    }

# Generated at 2022-06-26 10:27:54.505715
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0 = from_json_schema({
        'type': 'string',
        'pattern': '^\\d{3,4}$',
        'maxLength': 4,
        'minLength': 3,
        'allOf': [
            {'default': ''},
            {'pattern': '^\\d{3,4}$', 'type': 'string'}
        ]
    })

    assert field_0.pattern == '^\\d{3,4}$'


# Generated at 2022-06-26 10:28:21.426559
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'not': {'type': 'array'}}, SchemaDefinitions()) == Not(negated=Array(items=Any()))
    assert not_from_json_schema({'not': False}, SchemaDefinitions()) == Not(negated=NeverMatch())
    assert not_from_json_schema({'not': {'type': 'array', 'minItems': '0'}}, SchemaDefinitions()) == Not(negated=Array(items=Any()))
    assert not_from_json_schema({'not': {'type': 'array', 'default': '0'}}, SchemaDefinitions()) == Not(negated=Array(items=Any(), default=0))

# Generated at 2022-06-26 10:28:23.010010
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    test_case_0()


# Generated at 2022-06-26 10:28:31.813471
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    any_of_0 = [{'items': 'object', 'type': 'array', 'definitions': {'integer': {'type': 'integer'}, 'string': {'type': 'string'}}, 'properties': {'number': {'type': 'number'}, 'string': {'type': 'string'}, 'integer': {'type': 'integer'}, 'boolean': {'type': 'boolean'}}}, {'type': 'array', 'definitions': {'integer': {'type': 'integer'}, 'string': {'type': 'string'}}, 'properties': {'number': {'type': 'number'}, 'string': {'type': 'string'}, 'integer': {'type': 'integer'}, 'boolean': {'type': 'boolean'}}}]

# Generated at 2022-06-26 10:28:40.421767
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference_string_0 = '#/'
    definitions_0 = SchemaDefinitions()
    data_0 = {'$ref': reference_string_0}
    field_0 = ref_from_json_schema(data_0, definitions_0)



# Generated at 2022-06-26 10:28:52.366572
# Unit test for function to_json_schema
def test_to_json_schema():
    from dp.validation.fields import String, Integer, Numeric, Object, Array, Choice


# Generated at 2022-06-26 10:29:00.264514
# Unit test for function to_json_schema
def test_to_json_schema():
    bool_0 = True
    bool_1 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    field_0 = from_json_schema(bool_1)
    json_schema_0 = to_json_schema(field_0)
    assert json_schema_0 == bool_1


# Generated at 2022-06-26 10:29:03.983977
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Setup
    data = {"not": {"type": "array"}}
    definitions = SchemaDefinitions()

    # Exercise
    result = not_from_json_schema(data, definitions)

    # Verify
    assert result.negated.__class__.__name__ == "Array"

    # Cleanup - none necessary



# Generated at 2022-06-26 10:29:13.590943
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(
        String(min_length=3, max_length=10, allow_null=True, pattern_regex=re.compile(r'[a-zA-Z0-9@]+$'))
    ) == {'type': ['string', 'null'], 'minLength': 3, 'maxLength': 10, 'pattern': '[a-zA-Z0-9@]+$'}
    assert to_json_schema(
        Integer(minimum=0, maximum=100, allow_null=True, multiple_of=5)
    ) == {'type': ['integer', 'null'], 'minimum': 0, 'maximum': 100, 'multipleOf': 5}
   

# Generated at 2022-06-26 10:29:27.273111
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definition_testcase_0 = {'$ref': '#/definitions/test_case_0'}
    assert ref_from_json_schema(definition_testcase_0, {'test_case_0': Boolean()}) == None
    assert ref_from_json_schema(definition_testcase_0, {'test_case_0': Boolean()}) == None
    assert ref_from_json_schema(definition_testcase_0, {'test_case_0': Boolean()}) == None
    assert ref_from_json_schema(definition_testcase_0) == None
    assert ref_from_json_schema(definition_testcase_0, {'test_case_0': None}) == None

# Generated at 2022-06-26 10:29:31.017522
# Unit test for function to_json_schema
def test_to_json_schema():
    arg_0 = Read('<str>', format='date-time', default='2001-01-01T00:00:00')
    ret_0 = to_json_schema(arg_0)
    assert ret_0 == {'default': '2001-01-01T00:00:00', 'format': 'date-time', 'type': 'string'}
