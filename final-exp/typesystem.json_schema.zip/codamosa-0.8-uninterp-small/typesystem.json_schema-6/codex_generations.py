

# Generated at 2022-06-26 10:21:29.922458
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema({
        "not": False}), Not)
    assert isinstance(not_from_json_schema({"not": {}}), Not)
    assert isinstance(not_from_json_schema({
        "not": {"type": "array"}}), Not)
    assert isinstance(not_from_json_schema({
        "not": {"type": "array", "minItems": 0}}), Not)
    assert isinstance(not_from_json_schema({"not": {
        "type": "object", "properties": {
            "property_0": {"type": "array", "minItems": 1}
        }
    }}), Not)

# Generated at 2022-06-26 10:21:41.137382
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data_0 = {
        'type': 'string',
        'maxLength': 20,
        'format': 'ABC',
        'minLength': 0,
        'default': 'abc',
        'pattern': 'abc'
    }
    type_string_0 = 'string'
    allow_null_0 = True
    definitions_0 = SchemaDefinitions()
    field_0 = from_json_schema_type(data_0, type_string_0, allow_null_0, definitions_0)
    assert field_0 is not None, f"Failed to get field_0"
    data_1 = {
        'type': 'boolean',
        'default': False
    }
    type_string_1 = 'boolean'
    allow_null_1 = True
    definitions_1 = SchemaDefinitions

# Generated at 2022-06-26 10:21:51.257315
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {"oneOf": []}
    field_0 = from_json_schema(dict_0)
    assert isinstance(field_0, OneOf)
    assert field_0._one_of == []
    assert field_0._default == None
    dict_1 = {"oneOf": [None], "default": None}
    field_1 = from_json_schema(dict_1)
    assert isinstance(field_1, OneOf)
    assert field_1._one_of == [None]
    assert field_1._default == None
    dict_2 = {"oneOf": [{'$ref': '#/definitions/JSONSchema'}, {'default': '#/definitions/JSONSchema'}]}
    field_2 = from_json_schema(dict_2)

# Generated at 2022-06-26 10:22:03.407938
# Unit test for function get_valid_types
def test_get_valid_types():
    bool_0 = True
    bool_1 = False
    int_0 = 0
    int_1 = 1
    char_0 = 'null'
    char_1 = 'boolean'
    char_2 = 'object'
    char_3 = 'array'
    char_4 = 'number'
    char_5 = 'string'
    field_0 = get_valid_types({char_0:bool_0})
    bool_2 = bool_0
    bool_3 = bool_1
    field_1 = get_valid_types({char_0:bool_0,char_1:bool_1,char_2:bool_0,char_3:bool_0,char_4:bool_0,char_5:bool_0})
    bool_4 = bool_1
    bool_5 = bool_0


# Generated at 2022-06-26 10:22:13.612225
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string_0 = "number"
    allow_null_0 = False
    data_0 = {"type": "number"}
    field_0 = from_json_schema_type(data_0, type_string_0, allow_null_0)
    assert isinstance(field_0,Field) and isinstance(field_0,Number) and field_0.allow_null == allow_null_0 and field_0.minimum == None and field_0.maximum == None and field_0.exclusive_minimum == None and field_0.exclusive_maximum == None and field_0.multiple_of == None and field_0.default == NO_DEFAULT

    type_string_1 = "integer"
    allow_null_1 = True
    data_1 = {"type": "integer"}
    field_1 = from_json_schema

# Generated at 2022-06-26 10:22:18.737982
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
      "oneOf": [
        {
          "type": "number"
        },
        {
          "type": "string",
          "minLength": 3,
          "maxLength": 4
        }
      ]
    }

    type_strings, allow_null = get_valid_types(data)
    assert len(type_strings) <= 1
    assert not allow_null
    type_string = type_strings.pop()
    assert type_string == "oneOf"
    one_of = [from_json_schema_type(data, type_string=type_string, allow_null=False)]
    assert isinstance(one_of, list)
    assert len(one_of) == 2
    assert any([isinstance(i, Integer) for i in one_of])

# Generated at 2022-06-26 10:22:21.662924
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    # Assert that an exception has not been raised.
    try:
        test_case_0()
    except Exception as e:
        assert False, "An exception has been raised."


# Generated at 2022-06-26 10:22:31.557135
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test Case # 0
    assert from_json_schema(dict(enum=["a"])) == Choice(choices=[("a", "a")])

    # Test Case # 1
    assert from_json_schema(dict(enum=[dict(enum=["a"])])) == Choice(
        choices=[(Choice(choices=[("a", "a")]), Choice(choices=[("a", "a")]))]
    )

    # Test Case # 2

# Generated at 2022-06-26 10:22:36.518756
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    input_0 = {"enum": [1, 2, 3]}
    expected_output_1 = {"allow_null": False, "choices": [(1, 1), (2, 2), (3, 3)], "default": NO_DEFAULT}
    observed_output_0 = enum_from_json_schema(input_0, None)
    observed_output_1 = observed_output_0.__dict__
    assert expected_output_1 == observed_output_1


# Generated at 2022-06-26 10:22:41.724658
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-26 10:23:16.849377
# Unit test for function not_from_json_schema
def test_not_from_json_schema():

    # Case 0:
    # input: object = {"type": "object"}
    # return: Not(negated=Object)
    object_0 = {"type": "object"}
    field_0 = from_json_schema(object_0)
    result_0 = not_from_json_schema(object_0, None)
    assert result_0 == field_0

    # Case 1:
    # input: object = {"type": "string"}
    # return: Not(negated=String)
    object_1 = {"type": "string"}
    field_1 = from_json_schema(object_1)
    result_1 = not_from_json_schema(object_1, None)
    assert result_1 == field_1

    # Case 2:
    # input: object = {"type": "bo

# Generated at 2022-06-26 10:23:25.487857
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause_0: Field = Any()
    then_clause_0: typing.Optional[Field] = None
    else_clause_0: typing.Optional[Field] = None
    kwargs_0:{'if_clause': Field, 'then_clause': typing.Optional[Field], 'else_clause': typing.Optional[Field]} = {'if_clause': if_clause_0, 'then_clause': then_clause_0, 'else_clause': else_clause_0} # type: ignore
    then_clause_1: typing.Optional[Field] = None
    else_clause_1: typing.Optional[Field] = None

# Generated at 2022-06-26 10:23:35.550375
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    input_0 = {"if": {"const": {"enum": [1, 2, 3]}}, "then": {"const": 1}}
    if_then_and_else_0 = IfThenElse(if_clause=Const(None, const={"enum": [1, 2, 3]}), then_clause=Const(None, const=1), else_clause=Const(None, const=None))
    assert from_json_schema(input_0) == if_then_and_else_0


# Generated at 2022-06-26 10:23:46.152190
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {"if": {"type": "string"}, "then": {"minLength": 10}}
    field = if_then_else_from_json_schema(json_schema)
    assert field.__class__.__name__ == "IfThenElse"
    json_value = '"longer than 10 characters"'
    value = field.validate_json(json_value)
    assert value == json_value
    json_value = '"short"'
    with pytest.raises(ValidationError) as e_info:
        field.validate_json(json_value)
    error = e_info.value
    assert isinstance(error, ValidationError)
    assert error.value == json_value

# Generated at 2022-06-26 10:24:00.844758
# Unit test for function to_json_schema
def test_to_json_schema():
    field_0 = Integer(allow_null=False, minimum=0, maximum=100)
    field_1 = Array(allow_null=True, min_items=2, max_items=3, unique_items=True)
    field_2 = String(allow_blank=False, allow_null=False)
    field_3 = Choice(choices=[(1, "one"), (2, "two"), (3, "three")], allow_null=False)
    field_4 = Object(
        allow_null=False,
        properties={
            "field_0": field_0,
            "field_1": field_1,
            "field_2": field_2,
            "field_3": field_3,
        },
    )
    json_0 = to_json_schema(field_4)
    field

# Generated at 2022-06-26 10:24:12.866795
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    test_dict = {
        "type": "array",
        "items": [
            {"type": "string"},
            {
                "type": "object",
                "properties": {
                    "a": {"type": "integer"},
                    "b": {"type": "boolean"},
                    "c": {"type": "number", "default": 4.0},
                },
            },
        ],
    }

    assert type(from_json_schema_type(test_dict, "object", True, None)) == Object
    assert type(from_json_schema_type(test_dict, "array", True, None)) == Array
    assert isinstance(from_json_schema_type(test_dict, "array", True, None), Field)

# Generated at 2022-06-26 10:24:22.450850
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    print("Testing function: all_of_from_json_schema")
    input_1 = {'allOf': [{'type': 'string'}, {'maxLength': 100}]}
    output_1 = AllOf(all_of=[String(), String(max_length=100)], default=NO_DEFAULT)
    assert output_1 == all_of_from_json_schema(input_1, definitions=SchemaDefinitions())

    input_2 ={'allOf': [{'type': 'string'}, {'uniqueItems': True}]}
    assert None == all_of_from_json_schema(input_2, definitions=SchemaDefinitions())

    input_3 = {'allOf': [{'type': 'string'}, {'maxLength': 101}]}
    assert None == all_of_from_

# Generated at 2022-06-26 10:24:35.686139
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # AssertionError: <bool: False> != <false: False>
    bool_0 = False
    # AssertionError: <bool: False> != <false: False>
#     pass
    kwargs = {}
    # Accepts argument 'any_of', but does not expected argument 'all_of'.
    any_of = [
        from_json_schema(bool_0, definitions=definitions),
    ]
    # AssertionError: <bool: False> != <false: False>
    assert field_0 == False
    # AssertionError: <bool: False> != <false: False>
    assert field_0 == False
    # AssertionError: <bool: False> != <false: False>
    assert field_0 == False
    # AssertionError: <bool: False> !=

# Generated at 2022-06-26 10:24:49.089875
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # Test for without else clause.
    data = {"if": {"const": "1"}, "then": {"const": "1"}, "default": "null"}
    if_then_else = if_then_else_from_json_schema(data=data)
    assert isinstance(if_then_else, IfThenElse)
    assert "if_clause" in dir(if_then_else)
    assert "then_clause" in dir(if_then_else)
    assert "else_clause" in dir(if_then_else)

    data = {"if": {"const": "1"}, "then": {"const": "1"}}
    if_then_else = if_then_else_from_json_schema(data=data)
    assert isinstance(if_then_else, IfThenElse)

# Generated at 2022-06-26 10:25:00.966041
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    json_string = """{
                        "const": false
                    }"""
    data = eval(json_string)
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.validate(data["const"]) is True
    json_string = """{
                        "const": "ab"
                    }"""
    data = eval(json_string)
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.validate(data["const"]) is True


all_of_from_json_schema = compose(AllOf, convert_list(from_json_schema))
any_of_from_json_schema = compose(OneOf, convert_list(from_json_schema))
one_

# Generated at 2022-06-26 10:25:47.945428
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Test case
    json_schema_0 = {
        "allOf": [
            {"$ref": "#/definitions/foo"},
            {"$ref": "#/definitions/bar"},
            {"$ref": "#/definitions/baz"},
        ],
        "default": False,
    }
    definitions = {
        "foo": {"type": "number"},
        "bar": {"type": "number"},
        "baz": {"type": "number"},
    }

    field_0 = any_of_from_json_schema(json_schema_0, definitions)
    field_0.validate(1)



# Generated at 2022-06-26 10:25:52.521569
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference_string = "test"
    reference_string_value = "#/test"
    definitions = {reference_string: reference_string_value}
    data = "/test"
    field = ref_from_json_schema(data, definitions)


# Generated at 2022-06-26 10:26:04.499294
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Const value creation
    dict_1 = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "boolean"},
        ]
    }
    ret_1 = {type_string: String() for type_string in ["string", "integer"]}
    ret_2 = {type_string: Boolean() for type_string in ["boolean"]}

    # Type should be Field
    assert isinstance(field_0, Field)
    # Currently, there are no unit tests for the class Union.
    # assert issubclass(field_0.__class__, Union)
    # Type should be Field
    assert isinstance(field_1, Field)
    # Currently, there are no unit tests for the class Union.
    # assert issubclass(field_1.__class__

# Generated at 2022-06-26 10:26:09.422211
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    str_0 = "#/definitions/Image"
    dict_0 = {"$ref": str_0, "definitions": {}}
    field_0 = ref_from_json_schema(dict_0, None)
    s = str(field_0)
    assert "Image" in s


# Generated at 2022-06-26 10:26:16.796293
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    number_1 = {"type": "number"}
    data_0 = {"if": number_1, "then": number_1}
    definitions_0 = {}
    field_0 = from_json_schema(data_0, definitions=definitions_0)


# Generated at 2022-06-26 10:26:21.813691
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Prepare for test
    data = {"anyOf": [{"type": "array"}, {"type": "string"}]}

    # Test
    field = any_of_from_json_schema(data, None)

    assert type(field) == Union
    assert type(field.any_of[0]) == Array
    assert type(field.any_of[1]) == String


# Generated at 2022-06-26 10:26:29.641241
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {"type": "number", "multipleOf": 2.5}
    type_string = "number"
    allow_null = False
    definitions = SchemaDefinitions()
    field = from_json_schema_type(data, type_string, allow_null, definitions)
    assert isinstance(field, Number)



# Generated at 2022-06-26 10:26:33.787686
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data_0 = {}
    data_0['$ref'] = 'self'
    data_0['definitions'] = {}
    field_0 = ref_from_json_schema(data_0, definitions=definitions)
    assert field_0.id == 'self'


# Generated at 2022-06-26 10:26:41.587434
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    const_0 = Const(const=1)
    not_0 = not_from_json_schema(const_0)
    assert not_0.negated == 1

    enum_0 = enum_from_json_schema(enum=1)
    not_1 = not_from_json_schema(enum_0)
    assert not_1.negated == 1

    object_0 = Object()
    not_2 = not_from_json_schema(object_0)
    assert not_2.negated == {}

    string_0 = String()
    not_3 = not_from_json_schema(string_0)
    assert not_3.negated == ''

    array_0 = Array()
    not_4 = not_from_json_schema(array_0)
    assert not_4

# Generated at 2022-06-26 10:26:50.014028
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test cases
    data_0 = {"not": {"$ref": "#/definitions/JSONSchema"}}
    data_1 = {"not": {"type": "string"}}
    data_2 = {"not": {"type": "integer"}}
    data_3 = {"not": {"type": "null"}}
    data_4 = {"not": {"type": "boolean"}}
    data_5 = {"not": {"enum": [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]}}
    data_6 = {"not": {"const": True}}
    data_7 = {"not": {"allOf": [{"$ref": "#/definitions/JSONSchema"}]}}

# Generated at 2022-06-26 10:27:08.059716
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # var_0 is an empty dict
    var_0 = {}
    # var_1 is argument of type dict
    var_1 = {
        "type": "null"
    }
    # var_2 is argument of type dict
    var_2 = {
        "type": "string"
    }
    # var_3 is argument of type dict
    var_3 = {
        "type": "integer"
    }
    # var_4 is argument of type dict
    var_4 = {
        "type": "number"
    }
    # var_5 is argument of type dict
    var_5 = {
        "type": "boolean"
    }
    # var_6 is argument of type dict
    var_6 = {
        "type": "object"
    }
    # var_7 is argument

# Generated at 2022-06-26 10:27:11.289452
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    var_0 = {}
    assert ref_from_json_schema(var_0, {}) == Any()


# Generated at 2022-06-26 10:27:15.114784
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Set types
    type_string = "any"
    allow_null = False
    definitions = definitions
    data = var_0
    # Call function
    var_1 = from_json_schema_type(data, type_string, allow_null, definitions)
    # Verify
    assert isinstance(var_1, Any)



# Generated at 2022-06-26 10:27:16.251202
# Unit test for function to_json_schema
def test_to_json_schema():
    print(test_case_0())

test_to_json_schema()


# Generated at 2022-06-26 10:27:18.219119
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    not_from_json_schema(data=var_0, definitions=None)
    return


# Generated at 2022-06-26 10:27:26.934901
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    def test_function_from_json_schema(data, definitions=None):
        var_1 = {}
        if isinstance(data, bool):
            return {True: Any(), False: NeverMatch()}[data]
        if definitions is None:
            var_2 = SchemaDefinitions()
            for var_3, var_4 in data.get('definitions', {}).items():
                var_5 = '#/definitions/'
                var_6 = var_3
                var_7 = var_5 + var_6
                var_2[var_7] = test_function_from_json_schema(var_4, definitions=var_2)
        if '$ref' in data:
            var_8 = data['$ref']
            var_9 = '#/'


# Generated at 2022-06-26 10:27:31.967119
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    print("Testing function not_from_json_schema")
    var_0 = {}
    var_1 = Field.from_json_schema(var_0)
    var_2 = Not(negated=var_1)
    var_3 = var_2.validate(None)
    assert var_3 == None


# Generated at 2022-06-26 10:27:37.453208
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    try:
        var_0 = {}
        var_0 = {'definitions': {'test': {'type': 'integer', 'enum': [0, 1, 2]}}, 'properties': {'value': {'$ref': '#/definitions/test'}}, 'type': 'object'}
        var_0 = {'type': 'integer'}
        var_0 = {'type': 'integer'}
    except Exception:
        raise Exception('Test Failed')



# Generated at 2022-06-26 10:27:41.016628
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    print("Testing function Not(negated=Any())")

    var_0 = {}

    result = not_from_json_schema(data=var_0,definitions=definitions)


# Generated at 2022-06-26 10:27:43.592814
# Unit test for function to_json_schema
def test_to_json_schema():
    import json

    # Setup
    arg = var_0

    # Exercise
    result = to_json_schema(arg)

    # Verify
    assert result == json.loads('{}')

    # Cleanup - none necessary


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:28:21.702291
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    test_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string", "minLength": 2, "maxLength": 10},
            "price": {"type": ["number", "null"], "minimum": 0},
            "tags": {"type": "array", "items": {"type": "string", "enum": ["small", "medium", "large"]}},
            "stock": {"type": "object", "properties": {"warehouse": {"type": "integer", "minimum": 0}, "retail": {"type": "integer", "minimum": 0}}},
        },
    }
    validate = from_json_schema(test_schema).validate

# Generated at 2022-06-26 10:28:24.578688
# Unit test for function from_json_schema
def test_from_json_schema():
    var_0 = {}

    # Call function
    var_0 = from_json_schema(var_0)

    assert isinstance(var_0, Field), "'var_0' is of type '{}'".format(type(var_0))
    
    return None



# Generated at 2022-06-26 10:28:25.698061
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    check_types_result = test_case_0()
    assert check_types_result == None

# Generated at 2022-06-26 10:28:29.860813
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # type_string = None
    # allow_null = True
    # data = var_0
    # definitions = None

    var_0 = from_json_schema_type(data=var_0, type_string=type_string, allow_null=allow_null, definitions=definitions)
    print(var_0)

# Generated at 2022-06-26 10:28:33.278861
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_0 = {}
    func_0 = not_from_json_schema
    var_0["schema"] = False
    var_0.update(schema=False)

# Generated at 2022-06-26 10:28:44.073964
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    var_0 = {}
    var_1 = type_from_json_schema(var_0)
    try:
        assert isinstance(var_1, Any)
    except AssertionError as e:
        raise AssertionError("Test Case 0 Failed")


# Generated at 2022-06-26 10:28:47.729958
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    var_1 = {}
    var_1 = not_from_json_schema({'default': None, 'not': {}}, {})
    # print("var_1: ", var_1)



# Generated at 2022-06-26 10:28:54.157977
# Unit test for function to_json_schema
def test_to_json_schema():
    val = to_json_schema(Any())
    assert val is True
    val = to_json_schema(NeverMatch())
    assert val is False
    class A(Schema):
        a = Any()
    val = to_json_schema(A.make_validator())
    assert val == {"type": "object", "properties": {"a": True}}
    class B(Schema):
        b = A.field()
    val = to_json_schema(B.make_validator())
    assert val == {
        "type": "object",
        "properties": {"b": {"type": "object", "properties": {"a": True}}},
    }
    class C(Schema):
        c = B.field()
    val = to_json_schema(C.make_validator())
   

# Generated at 2022-06-26 10:29:00.313866
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    var_0 = {}
    var_1 = "integer"
    var_2 = False
    var_3 = SchemaDefinitions()

    from_json_schema_type(var_0, type_string=var_1, allow_null=var_2, definitions=var_3)


# Generated at 2022-06-26 10:29:09.247700
# Unit test for function from_json_schema
def test_from_json_schema():
    var_0 = {}
    var_1 = from_json_schema(var_0)
    assert isinstance(var_1, Any)

    var_0 = {"type": "boolean"}
    var_1 = from_json_schema(var_0)
    assert isinstance(var_1, Boolean)

    var_0 = {"type": True}
    var_1 = from_json_schema(var_0)
    assert isinstance(var_1, Any)

    var_0 = {"type": "integer"}
    var_1 = from_json_schema(var_0)
    assert isinstance(var_1, Integer)

    var_0 = {"type": "number"}
    var_1 = from_json_schema(var_0)
    assert isinstance(var_1, Number)

# Generated at 2022-06-26 10:30:03.249005
# Unit test for function to_json_schema
def test_to_json_schema():
    assert str(to_json_schema({}, _definitions=None)) == "{}"

test_case_0()
test_to_json_schema()

# Generated at 2022-06-26 10:30:06.196391
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    var_0 = {}
    assert (from_json_schema_type(var_0, 'number', False, {}) == 'number')



# Generated at 2022-06-26 10:30:08.252153
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(var_0) == var_0


# Generated at 2022-06-26 10:30:19.535903
# Unit test for function to_json_schema
def test_to_json_schema():

    # Check that NO_DEFAULT can be converted to a JSON schema
    field = Field.make_validator(
        type=type(None),
        choices=[(None, None)],
        default=NO_DEFAULT,
    )
    json_schema = to_json_schema(field)
    expected_json_schema = {
        "type": "null",
        "choices": [["null", None]]
    }
    assert json_schema == expected_json_schema

    # Check that the reverse transformation is not supported
    _field = from_json_schema(json_schema, {})
    with pytest.raises(ValueError):
        _field.validate(NO_DEFAULT)

    # Check that null can be converted to a JSON schema