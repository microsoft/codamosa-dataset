

# Generated at 2022-06-26 10:21:13.860098
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {"if": {"type": "string"}, "then": {"type": "number"}, "else": {"type": "number"}}
    field_0 = if_then_else_from_json_schema(dict_0)
    assert field_0.if_clause.describe() == "string"
    assert field_0.then_clause.describe() == "number"
    assert field_0.else_clause.describe() == "number"


# Generated at 2022-06-26 10:21:26.362544
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'anyOf': [{'type': 'string'}]}
    field_0 = from_json_schema(dict_0)
    assert field_0.get_default() == None
    assert field_0.allow_null == True
    assert field_0.any_of[0].allow_null == False
    assert field_0.any_of[0].default == None
    assert field_0.any_of[0].get_default() == None
    assert field_0.any_of[0].format == None
    assert field_0.any_of[0].max_length == None
    assert field_0.any_of[0].min_length == None
    assert field_0.any_of[0].pattern == None
    assert field_0.default == None


# Generated at 2022-06-26 10:21:32.921173
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': ['3', '1', '2']}
    field_0 = enum_from_json_schema(dict_0, None)
    try:
        field_0.validate('2')
    except Exception as error:
        print(error)


# Generated at 2022-06-26 10:21:43.829458
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {
        "anyOf": [
            {
                "type": "string",
                "minLength": 3,
            },
            {
                "type": "string",
                "maxLength": 5,
            },
        ],
    }
    field_0 = from_json_schema(dict_0)
    assert field_0.validate("foo")
    assert field_0.validate("food")
    assert field_0.validate("foods")
    assert not field_0.validate("")
    assert not field_0.validate("fo")
    assert not field_0.validate("foods!")


# Generated at 2022-06-26 10:21:53.265281
# Unit test for function to_json_schema
def test_to_json_schema():
    dict_0 = {}
    dict_0["type"] = "string"
    dict_0["description"] = "Description"
    dict_0["definition"] = "Definition"
    dict_0["properties"] = {}
    dict_0["properties"]["a"] = "a"
    dict_0["properties"]["b"] = "b"
    dict_0["title"] = "Title"
    dict_0["default"] = "7"

    string_field_0 = String(description="Description", definition="Definition", properties={"a":"a", "b":"b"}, title="Title", allow_blank=True, min_length=5, max_length=5, pattern_regex=re.compile("a+"), pattern_error="pattern_error", format="email", format_error="format_error")
    string_field_

# Generated at 2022-06-26 10:22:01.224390
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    dict_0 = {"const": 3}
    field_0 = from_json_schema(dict_0)
    assert type(field_0) is Const
    assert isinstance(field_0, Const)
    print("Test 0 passed")
    dict_1 = {"const": [3]}
    field_1 = from_json_schema(dict_1)
    assert type(field_1) is Const
    assert isinstance(field_1, Const)
    print("Test 1 passed")


# Generated at 2022-06-26 10:22:11.941498
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    dict_0 = {"type":"array","items":{"type":"string"}}
    result_0 = type_from_json_schema(dict_0)
    assert result_0.__class__.__name__ == "Field"
    
    dict_1 = {"type":["string","number","boolean"]}
    result_1 = type_from_json_schema(dict_1)
    assert isinstance(result_1, Union)
    
    dict_2 = {"type":"sdfsdfs"}
    result_2 = type_from_json_schema(dict_2)
    assert result_2.__class__.__name__ == "NeverMatch"
    
    dict_3 = {"type":"string","enum":["a","b","c","d"]}

# Generated at 2022-06-26 10:22:24.730882
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Set up value for all_of parameter
    dict_0 = {'items': {'type': 'string'}, 'type': 'array', 'uniqueItems': True}
    dict_1 = {'type': 'string'}
    all_of_for_parameter = [dict_0, dict_1]
    # Call function
    field_0 = all_of_from_json_schema(all_of_for_parameter, None)
    # Check results
    assert isinstance(field_0, AllOf)
    assert isinstance(field_0.all_of, list)
    assert isinstance(field_0.all_of[0], Array)
    assert field_0.all_of[0].items == String()
    assert field_0.all_of[0].unique_items == True
    assert field_

# Generated at 2022-06-26 10:22:26.141749
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    dict_0 = {"oneOf": [{"type": "null"}, {"type": "integer"}]}
    field_0 = one_of_from_json_schema(dict_0)

# Generated at 2022-06-26 10:22:36.230742
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data0 = {"enum": ["a", "b", "c"], "default": "a"}
    data1 = {"enum": [1, 2, 3], "default": 2}
    data2 = {"enum": [True, False], "default": True}
    data3 = {"enum": ["A", "B", "C"], "default": "B"}
    data4 = {"enum": [1, 2, 3], "default": 3}
    data5 = {"enum": [1, 2, 3], "default": "1"}

    result0 = enum_from_json_schema(data0, definitions)
    result1 = enum_from_json_schema(data1, definitions)
    result2 = enum_from_json_schema(data2, definitions)

# Generated at 2022-06-26 10:23:05.029273
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
  dict_0 = {}
  dict_1 = {'if': {'type': 'integer', 'minimum': 4}, 'then': {'type': 'string'}}
  dict_2 = {'if': {'type': 'string', 'minLength': 3}, 'then': {'type': 'integer', 'minimum': 3, 'maximum': 10}}
  dict_3 = {'if': {'type': 'string', 'maxLength': 10}, 'then': {'type': 'string', 'minLength': 1}, 'else': {'type': 'string', 'minLength': 11}}
  dict_4 = {'if': {'type': 'string', 'maxLength': 0}, 'then': {'type': 'string', 'minLength': 1}, 'else': {'type': 'string', 'minLength': 11}}

# Generated at 2022-06-26 10:23:14.601827
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {
        "if": {
            "type": "string",
            "minLength": 2,
            "const": "abc",
        },
        "then": {
            "type": "number",
            "minimum": 5,
            "maximum": 30,
            "default": 10,
        },
        "else": {
            "type": "number",
            "minimum": 2,
            "maximum": 10,
        }
    }
    field_0 = if_then_else_from_json_schema(dict_0)

# Generated at 2022-06-26 10:23:19.673876
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    input_value_0 = {}
    input_value_0["if"] = 1
    input_value_0["then"] = ""
    input_value_0["else"] = FakeSchema.FakeSchema()
    input_value_1 = {}
    input_value_1["if"] = 2
    input_value_1["then"] = ""
    input_value_1["else"] = 1
    input_value_2 = {}
    input_value_2["if"] = 3
    input_value_2["else"] = 1
    input_value_3 = {}
    input_value_3["if"] = 4
    input_value_3["then"] = 1

# Generated at 2022-06-26 10:23:26.900867
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_string_0 = "object"
    allow_null_0 = True
    field_0 = from_json_schema_type({}, type_string_0, allow_null_0, {})
    type_string_1 = "string"
    allow_null_1 = True
    field_1 = from_json_schema_type({}, type_string_0, allow_null_0, {})
    type_string_2 = "boolean"
    allow_null_2 = False
    field_2 = from_json_schema_type({}, type_string_0, allow_null_0, {})
    type_string_3 = "array"
    allow_null_3 = False

# Generated at 2022-06-26 10:23:29.847809
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({'allOf': [], 'default': NO_DEFAULT}, SchemaDefinitions()) == Any()
    assert all_of_from_json_schema({'allOf': [], 'default': '177'}, SchemaDefinitions()) == Const('177')



# Generated at 2022-06-26 10:23:42.816821
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({
        "type": "array",
        "items": {
            "definitions": {},
            "type": "string"
        }
    }, "array", False) == Array(min_items=0, items=String()), "Test failed"
    assert from_json_schema_type({
        "type": "array",
        "items": {
            "definitions": {},
            "type": "string"
        }
    }, "array", False) == from_json_schema({
        "definitions": {},
        "type": "array",
        "items": {
            "type": "string"
        }
    }), "Test failed"

# Generated at 2022-06-26 10:23:44.935616
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data_0 = {}
    definitions_0 = {}

    assert all_of_from_json_schema(data=data_0,definitions=definitions_0)


# Generated at 2022-06-26 10:23:58.948683
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {
        "if": {
            "const": "spec",
            "type": "object",
            "required": ["info", "paths"],
            "properties": {
                "info": {
                    "type": "object",
                    "required": ["version", "title"],
                    "properties": {
                        "version": {"type": "string"},
                        "title": {"type": "string"},
                        "description": {"type": "string"},
                    },
                }
            },
        },
        "then": {"type": ["null", "string"], "default": "spec", "const": "spec"},
    }
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:24:11.998220
# Unit test for function from_json_schema
def test_from_json_schema():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    test_case_22()
    test_case_23()
    test_case_24()

# Generated at 2022-06-26 10:24:24.383333
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test with args_0, data_0, allow_null_0, and definitions_0
    args_0 = {"oneOf": []}
    data_0 = args_0
    allow_null_0 = False
    definitions_0 = None
    try:
        field_0 = from_json_schema_type(data_0, "number", allow_null_0, definitions_0)
    except AssertionError:
        print("Assertion error (line 281)")
    except TypeError:
        print("Type error (line 281)")
    # Test with args_1, data_1, allow_null_1, and definitions_1
    args_1 = {"oneOf": []}
    data_1 = args_1
    allow_null_1 = True
    definitions_1 = None

# Generated at 2022-06-26 10:24:57.554635
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {"type": "object", "properties": {"default": {"type": "string"}}}
    schema_0 = from_json_schema(dict_0)

    assert schema_0.__name__ == "Object"

    dict_0 = {
        "type": "object",
        "properties": {"default": {"type": "string"}},
        "default": {"name": "value"},
    }
    schema_0 = from_json_schema(dict_0)

    assert schema_0.__name__ == "Object"


# Generated at 2022-06-26 10:25:02.031133
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {}
    assert ref_from_json_schema(dict_0) == None
    assert ref_from_json_schema(dict_0) is not None



# Generated at 2022-06-26 10:25:11.256671
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    type_strings, allow_null = get_valid_types(type_string)
    type_string = type_strings.pop()

    data = {"$ref": "#/definitions/numeric"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/numeric"] = Reference(to="#/definitions/numeric", definitions=definitions)
    field_0 = ref_from_json_schema(data, definitions)

    type_string = type_strings.pop()

    if not isinstance(field_0, Reference):
        assert False, "Invalid return type"


# Generated at 2022-06-26 10:25:21.814011
# Unit test for function from_json_schema
def test_from_json_schema():
    # Raw test cases
    # Raw test used to generate unit test data from.
    #
    # $ python3
    # from typesystem_json_schema import from_json_schema
    # from pprint import pprint
    # pprint(from_json_schema({'$ref': '#/definitions/Example'}))
    # ref_from_json_schema({'$ref': '#/definitions/Example'}, definitions={'#/definitions/Example': '<typesystem-schema>'})
    ref_from_json_schema_test_0_data = {'$ref': '#/definitions/Example'}
    ref_from_json_schema_test_0_definitions = {'#/definitions/Example': '<typesystem-schema>'}
    ref_from

# Generated at 2022-06-26 10:25:32.586628
# Unit test for function to_json_schema
def test_to_json_schema():
    data = {
        "type": "object",
        "properties": {
            "username": {"type": "string"},
            "first_name": {"type": "string"},
            "age": {"type": "number"},
            "is_active": {"type": "boolean"},
            "friends": {
                "type": "array",
                "items": {"$ref": "#/definitions/User"},
                "additionalItems": False,
            },
        },
    }
    field = from_json_schema(data)
    field = field.replace(User=Ref("User"))
    json_schema = to_json_schema(field)


# Generated at 2022-06-26 10:25:43.439233
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    dict_0 = {"not": {"type": "array", "maxItems": 1}}
    field_0 = not_from_json_schema(dict_0,None)

    dict_1 = {"not": {"type": "boolean"}}
    field_1 = not_from_json_schema(dict_1,None)

    dict_2 = {"not": {"type": "integer"}}
    field_2 = not_from_json_schema(dict_2,None)

    dict_3 = {"not": {"type": "number"}}
    field_3 = not_from_json_schema(dict_3,None)

    dict_4 = {"not": {"type": "object", "maxProperties": 1, "minProperties": 0}}

# Generated at 2022-06-26 10:25:55.486409
# Unit test for function to_json_schema
def test_to_json_schema():
    fields_0 = [
        Integer(minimum=0, maximum=10, multiple_of=3),
        Boolean(const=True),
        String(
            max_length=10,
            pattern_regex=re.compile(r"[a-z]", flags=re.UNICODE),
            format="date-time",
        ),
        Object(properties={"a": String()}, required=["a"]),
        Array(items=Decimal(minimum=0, maximum=10), min_items=1, max_items=3),
    ]
    for field_0 in fields_0:
        schema_0 = to_json_schema(field_0)
        field_1 = from_json_schema(schema_0)

# Generated at 2022-06-26 10:26:07.828410
# Unit test for function not_from_json_schema

# Generated at 2022-06-26 10:26:09.605683
# Unit test for function to_json_schema
def test_to_json_schema():
    test_case_0()


if __name__ == "__main__":
    test_to_json_schema()

# Generated at 2022-06-26 10:26:22.590655
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test string cases
    field_0 = String(min_length=2, max_length=5)
    result_0 = to_json_schema(field_0)
    assert result_0 == {
        "minLength": 2,
        "maxLength": 5,
        "type": "string"
    }

    # Test integer cases
    field_1 = Integer(minimum=0, maximum=2, multiple_of=1)
    result_1 = to_json_schema(field_1)
    assert result_1 == {
        "minimum": 0,
        "maximum": 2,
        "multipleOf": 1,
        "type": "integer"
    }

    # Test boolean cases
    field_2 = Boolean()
    result_2 = to_json_schema(field_2)
    assert result_

# Generated at 2022-06-26 10:27:01.829818
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    string_0 = '"P\\|0=Rnpte<@'

# Generated at 2022-06-26 10:27:11.834674
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "null"}) == Const(None)
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()

# Generated at 2022-06-26 10:27:12.865509
# Unit test for function from_json_schema
def test_from_json_schema():
    assert True



# Generated at 2022-06-26 10:27:22.057364
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {
        "type": "string",
        "default": "abba"
    }
    assert from_json_schema_type(dict_0, "string", False, definitions) == String(default="abba", allow_null=False)
    dict_1 = {
        "type": "string",
        "default": "abba",
        "minLength": 1,
        "maxLength": 10,
        "pattern": "regex",
        "format": "format"
    }
    assert from_json_schema_type(dict_1, "string", False, definitions) == String(default="abba", allow_null=False, pattern="regex", format="format", min_length=1, max_length=10)


# Generated at 2022-06-26 10:27:23.503829
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert callable(type_from_json_schema)


# Generated at 2022-06-26 10:27:27.721136
# Unit test for function to_json_schema
def test_to_json_schema():
    # Simple field test
    field_0 = String(min_length=1)
    dict_0 = to_json_schema(field_0)
    assert dict_0 == {
        "type": "string",
        "minLength": 1,
    }

    # Simple schema test
    schema_0 = SimpleSchema()
    dict_0 = to_json_schema(schema_0)
    assert dict_0 == {
        "definitions": {
            "SimpleSchema": {
                "type": "object",
            },
        },
        "$ref": "#/definitions/SimpleSchema",
    }

    # Schema with field reference
    schema_0 = SimpleSchema(num_0=Integer())
    dict_0 = to_json_schema(schema_0)
    assert dict_0

# Generated at 2022-06-26 10:27:37.392306
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test boolean type
    boolean_field = Boolean()
    boolean_res = to_json_schema(boolean_field)
    assert boolean_res == {"type": "boolean"}
    
    # Test nullable boolean type
    boolean_field = Boolean(allow_null=True)
    boolean_res = to_json_schema(boolean_field)
    assert boolean_res == {"type": ["boolean", "null"]}

    # Test string type
    string_field = String()
    string_res = to_json_schema(string_field)
    assert string_res == {"type": "string"}
    
    # Test nullable string type
    string_field = String(allow_null=True)
    string_res = to_json_schema(string_field)

# Generated at 2022-06-26 10:27:41.593913
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Stub: data = {...}
    # Stub: type_string = "any"
    # Stub: allow_null = True
    # Stub: definitions = {...}
    # Result: field = Field()
    field = Field()
    # Return value: field
    return field


# Generated at 2022-06-26 10:27:46.865439
# Unit test for function to_json_schema
def test_to_json_schema():
    # Simple test case
    field_0 = Object(properties={
        "first_name": String(max_length=30, allow_blank=False, allow_null=True),
        "last_name": String(min_length=2, max_length=30, allow_blank=False, allow_null=True),
        "email": String(min_length=5, max_length=254, allow_blank=False, allow_null=True, format="email")
    })
    dict_0 = to_json_schema(field_0)

    # Object with nested object

# Generated at 2022-06-26 10:28:02.079639
# Unit test for function to_json_schema
def test_to_json_schema():
    class Test(Schema):
        a = Integer(minimum=1, allow_null=True)
        b = Integer(maximum=3)
        c = Integer()
        d = String(pattern_regex=re.compile(r"^[a-z]*$"))
        e = String(min_length=1)

    dict_0 = to_json_schema(Test)

# Generated at 2022-06-26 10:28:29.538963
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {
        "type": [
            "object",
            "string",
            "null",
        ],
    }
    type_0 = "array"
    allow_null_0 = True
    definitions_0 = SchemaDefinitions()
    field_0 = from_json_schema_type(dict_0, type_0, allow_null_0, definitions_0)
    assert field_0.__class__ == Array
    assert field_0.allow_null == True
    assert field_0.min_items == 0
    assert field_0.max_items == None
    assert field_0.unique_items == False
    assert field_0.items == None
    assert field_0.default == NO_DEFAULT
    assert field_0.default_factory == NO_DEFAULT
    assert field_

# Generated at 2022-06-26 10:28:38.004800
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {
        "type": "string",
        "maxLength": 5
    }
    field_0 = from_json_schema(dict_0)
    assert type(field_0)==typesystem.fields.String
    assert field_0.max_length == 5


# Generated at 2022-06-26 10:28:51.450523
# Unit test for function to_json_schema
def test_to_json_schema():
    from typing import List

    # Test to_json_schema with a string
    data = {
        "type": "string",
        "minLength": 2,
        "maxLength": 100,
        "pattern": "^[A-Za-z0-9_-]*$",
        "format": "email",
        "default": "example@example.com"
    }
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(String(min_length=2)) == {"type": "string", "minLength": 2}
    assert to_json_schema(String(max_length=100)) == {"type": "string", "maxLength": 100}

# Generated at 2022-06-26 10:29:05.018256
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert String(allow_blank=True, allow_null=False) == from_json_schema_type(
        {"minLength": 0}, "string", allow_null=False, definitions=None
    )
    assert String(min_length=2, allow_null=False) == from_json_schema_type(
        {"minLength": 2}, "string", allow_null=False, definitions=None
    )
    assert String(min_length=2, allow_null=True) == from_json_schema_type(
        {"minLength": 2}, "string", allow_null=True, definitions=None
    )
    assert String(max_length=2, allow_null=False) == from_json_schema_type(
        {"maxLength": 2}, "string", allow_null=False, definitions=None
    )

# Generated at 2022-06-26 10:29:16.239589
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {
        "type": "integer",
        "properties": {
            "bar": {"$ref": "#/definitions/foo"},
            "foo": {
                "type": "boolean_schema",
                "properties": {"bar": {"$ref": "#/definitions/foo"}},
                "minimum": 1,
            },
        },
        "items": [{"$ref": "#/definitions/foo"}],
        "required": ["foo"],
        "definitions": {
            "foo": {"allOf": [{"$ref": "#/definitions/bar"}]}
        },
    }
    field_0 = from_json_schema(dict_0)

# Generated at 2022-06-26 10:29:25.274696
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {}
    dict_0["type"] = "string"
    dict_0["pattern"] = r"^[a-zA-Z]{3}$"
    field_0 = from_json_schema(dict_0)
    assert str(field_0) == 'Any( constraints=[Type( name="string"), Pattern( "^[a-zA-Z]{3}$")])'


# Generated at 2022-06-26 10:29:32.898435
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {'$schema': 'http://json-schema.org/draft-07/schema#', 'definitions': {'bar': {'properties': {'example': {'type': 'string'}}}, 'foo': {'type': 'object', 'properties': {'dynamic': {'$ref': '#/definitions/bar'}}}}, 'type': 'object', 'properties': {'foo': {'$ref': '#/definitions/foo'}}}
    field_0 = from_json_schema(dict_0)

# Generated at 2022-06-26 10:29:43.446671
# Unit test for function to_json_schema

# Generated at 2022-06-26 10:29:55.294006
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    sub_dict = {"minimum": 10, "maximum": 25}
    parent_dict = {
        "type": sub_dict,
        "definitions": {
            "x": {"minimum": 10, "maximum": 25},
            "y": {
                "type": {"minimum": 10, "maximum": 25},
                "definitions": {"x": {"minimum": 10, "maximum": 25}}
            },
            "z": {"type": {"minimum": 10, "maximum": 25}},
        },
        "$ref": "y",
    }
    field = from_json_schema(parent_dict)

# Test case for issue #85

# Generated at 2022-06-26 10:30:06.173430
# Unit test for function from_json_schema
def test_from_json_schema():
    type_schema = {"type": "string"}
    field = from_json_schema(type_schema)
    assert isinstance(field, String)
    assert field.validate("hello world") is True

    type_schema = {"type": ["string"]}
    field = from_json_schema(type_schema)
    assert isinstance(field, String)
    assert field.validate("hello world") is True

    type_schema = {"type": ["string", "array"]}
    field = from_json_schema(type_schema)
    assert isinstance(field, Union)
    assert isinstance(field.fields[0], String)
    assert isinstance(field.fields[1], Array)
    assert field.validate("hello world") is True
