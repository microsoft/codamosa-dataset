

# Generated at 2022-06-26 10:21:09.811976
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field_0: Field = module_0.AllOf(
        all_of=[module_0.String(), module_0.Integer()], default="abc"
    )

# Generated at 2022-06-26 10:21:19.613281
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test the normal flow of the code
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.name == "oneOf"
    assert field.one_of[0].name == "string"
    assert field.one_of[1].name == "integer"

    # Test if the code handles the exception
    try:
        data = {"oneOf": [{"type": "string"}, {"type": "integer"}], "default": "false"}
        definitions = SchemaDefinitions()
        field = one_of_from_json_schema(data, definitions)
    except:
        pass



# Generated at 2022-06-26 10:21:30.856946
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref_0 = JSONSchema.get_reference()
    ref_1 = ref_0.get_to()
    ref_2 = ref_1.get_to()
    ref_3 = ref_2.get_to()
    # print('ref_3', ref_3)
    def _get_value(item):
        return item.get_to()
    # print(_get_value(ref_0))
    output_0 = ref_from_json_schema(ref_0)
    output_1 = output_0.get_to()
    # print('output_1', output_1)
    output_2 = _get_value(output_0)
    output_3 = _get_value(output_2)
    output_4 = _get_value(output_3)
    # print('output_4

# Generated at 2022-06-26 10:21:32.536843
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # No coverage because this function isn't implemented
    # This function is required to resolve mocked functions.
    pass


# Generated at 2022-06-26 10:21:43.473948
# Unit test for function get_valid_types
def test_get_valid_types():
    test_dict = {
        "type": ["boolean", "array", "integer"],
        "default": "Default",
    }
    expected = ({'boolean', 'array', 'integer'}, False)
    actual = get_valid_types(test_dict)
    # Assert that expected and actual are equal
    assert expected == actual

    test_dict = {
        "type": "string",
        "default": "Default",
    }
    expected = ({'string'}, False)
    actual = get_valid_types(test_dict)
    # Assert that expected and actual are equal
    assert expected == actual

    test_dict = {
        "type": "",
        "default": "Default",
    }

# Generated at 2022-06-26 10:21:51.266048
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Test cases
    parameters_1 = {"data": {"anyOf": [{"type": "integer"}, {"type": "string"}]}}
    expected_0 = [{"type": "integer"}, {"type": "string"}]
    tags_0 = {"basic"}
    parameters_2 = {
        "data": {"anyOf": [{"type": "integer"}, {"type": "string"}], "default": None}
    }
    expected_1 = [{"type": "integer"}, {"type": "string"}]
    tags_1 = {"basic"}

    # Test case test_case_0
    arguments_1 = parameters_1
    arguments_2 = dict_0
    any_of_from_json_schema_1 = any_of_from_json_schema(**arguments_1)
    assert any_of_from_json_

# Generated at 2022-06-26 10:21:58.319137
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "null",
    }
    assert (
        type_from_json_schema(data=data, definitions={})
        == Const(None)
    ), "type_from_json_schema(data=data, definitions={}) returned {type_from_json_schema(data=data, definitions={})!r} but expected {Const(None)!r}"
    data = {
        "type": ["string", "integer", "number", "boolean"],
    }
    assert (
        type_from_json_schema(data=data, definitions={})
        == Any()
    ), "type_from_json_schema(data=data, definitions={}) returned {type_from_json_schema(data=data, definitions={})!r} but expected {Any()!r}"
    data

# Generated at 2022-06-26 10:22:11.211503
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dummy_data_0: str
    dummy_data_1: str
    dummy_data_2: str
    dummy_data_3: str
    dummy_data_4: str
    dummy_data_5: str
    dummy_data_6: int