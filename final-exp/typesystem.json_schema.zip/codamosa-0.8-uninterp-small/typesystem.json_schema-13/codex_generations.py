

# Generated at 2022-06-26 10:21:20.491394
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    def module_0(arg_0, arg_1):
        call_0 = arg_0
        call_1 = arg_1
        call_2 = call_1

        test_0 = call_0
        test_1 = call_1
        test_2 = call_2
        if not test_0:
            if not test_1:
                if not test_2:
                    return True
        else:
            if test_1:
                if test_2:
                    return False
        return False
    def module_1():
        var_0 = module_0
        var_1 = var_0
        var_2 = var_1
        var_3 = var_2

        test_0 = var_0
        test_1 = var_1
        test_2 = var_2
        test_3 = var

# Generated at 2022-06-26 10:21:31.081785
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    list_0 = ["a", "b", "c"]
    dict_0 = {"if": {}, "then": {}}
    schema_definitions_0 = module_0.SchemaDefinitions()

    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)

    dict_1 = {"if": {}, "else": {}}
    field_1 = if_then_else_from_json_schema(dict_1, schema_definitions_0)

    dict_2 = {"if": {}, "then": {}, "else": {}}
    field_2 = if_then_else_from_json_schema(dict_2, schema_definitions_0)


# Generated at 2022-06-26 10:21:37.357140
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    dict_0 = {'anyOf': [{'type': 'number'}, {'type': 'string'}]}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = any_of_from_json_schema(dict_0, schema_definitions_0)
    assert type(field_0) == typesystem.Union


# Generated at 2022-06-26 10:21:44.039517
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {"enum": ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = enum_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:21:49.435509
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_1 = {"$ref": "#/definitions/test"}
    schema_definitions_1 = module_0.SchemaDefinitions()
    schema_definitions_1["#/definitions/test"] = module_0.Integer(allow_null=True)
    field_1 = ref_from_json_schema(dict_1, schema_definitions_1)
    assert isinstance(field_1, module_0.Reference) == True
    assert field_1.to == "#/definitions/test"


# Generated at 2022-06-26 10:21:58.341259
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    dict_0 = {'enum': ['f', 'x'], 'definitions': {}}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = ref_from_json_schema(dict_0, schema_definitions_0)
    assert field_0.choices == [('f', 'f'), ('x', 'x')]
    assert field_0.default == 'f'


# Generated at 2022-06-26 10:22:11.186159
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Test cases for function all_of_from_json_schema

    import random
    import typesystem

    from typesystem.schemas import SchemaDefinitions

    class TestAllOf(typesystem.TestCase):
        def test_all_of_from_json_schema_0(self):
            dict_0 = {
                "allOf": [
                    {
                        "$ref": "#/definitions/SomeReference",
                    },
                    {
                        "type": "object",
                        "properties": {
                            "field_1": {
                                "$ref": "#/definitions/String",
                            },
                        },
                        "required": [
                            "field_1",
                        ],
                    },
                ],
            }
            schema_definitions_0 = SchemaDefinitions()
            field_0 = ref_

# Generated at 2022-06-26 10:22:17.744727
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    dict_0 = {}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = if_then_else_from_json_schema(dict_0, schema_definitions_0)


# Generated at 2022-06-26 10:22:29.577749
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {"$ref": "schema"}
    schema_definitions_0 = module_0.SchemaDefinitions()
    (result_0, result_1) = ref_from_json_schema(dict_0, schema_definitions_0)
    result_0 = module_0.Reference(to='schema', definitions=schema_definitions_0)
    assert result_0 == result_1
    dict_1 = {"$ref": "schema"}
    schema_definitions_1 = module_0.SchemaDefinitions()
    (result_2, result_3) = ref_from_json_schema(dict_1, schema_definitions_1)
    result_2 = module_0.Reference(to='schema', definitions=schema_definitions_1)
    assert result_2 == result

# Generated at 2022-06-26 10:22:43.113657
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test that the output of one_of_from_json_schema(data, definitions) is the same
    # as OneOf(one_of=[from_json_schema(item, definitions=definitions) for item in data["oneOf"]], default=data.get("default", NO_DEFAULT))
    dict_0 = {"oneOf": [{"type": "integer", "minimum": 0, "maximum": 5}, {"type": "integer", "minimum": 0, "maximum": 5}, {"type": "integer", "minimum": 0, "maximum": 5}], "default": 3}
    schema_definitions_0 = module_0.SchemaDefinitions()
    field_0 = one_of_from_json_schema(dict_0, schema_definitions_0)
    assert field_0.one_of[0].minimum == 0

# Generated at 2022-06-26 10:23:53.084569
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    dict_0 = {"$ref": "#/definitions/JSONSchema"}
    field_0 = ref_from_json_schema(dict_0, definitions=definitions)
    expected_0 = Reference(to="#/definitions/JSONSchema", definitions=definitions)
    assert field_0 == expected_0


# Generated at 2022-06-26 10:24:05.826941
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {}
    dict_1 = dict_0
    dict_2 = dict_0
    dict_3 = dict_0
    dict_3["allOf"] = [dict_1, dict_2]
    field_0 = from_json_schema(dict_3)
    assert 1

# Test for function all_of_from_json_schema
# Test for function all_of_from_json_schema
# Test for function all_of_from_json_schema
# Test for function all_of_from_json_schema
# Test for function all_of_from_json_schema

# Bug Reproduction for function all_of_from_json_schema
# Bug Reproduction for function all_of_from_json_schema
# Bug Reproduction for function all_of_from_json_

# Generated at 2022-06-26 10:24:14.761158
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test: {"type": "array", "items": {"type": "string"}
    assert to_json_schema(Array(String())) == {
        "type": "array",
        "items": {"type": "string"},
    }

    # Test: {"type": "array", "items": {"type": ["string", "null"]}}
    assert to_json_schema(Array(String(allow_null=True))) == {
        "type": "array",
        "items": {"type": ["string", "null"]},
    }

    # Test: {"type": ["array", "null"], "items": {"type": "string"}}

# Generated at 2022-06-26 10:24:21.564061
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_dict_0 = {'const': 'a'}
    const_field_0 = const_from_json_schema(const_dict_0)

    assert const_field_0.clean('a') == 'a'
    assert const_field_0.clean('b') != 'b'

#   Test the contanst field to check if it returns a field.

# Generated at 2022-06-26 10:24:27.418573
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    import json
    with open("allof.json") as f:
        d = json.load(f)
    field = from_json_schema(d)
    print(field)



# Generated at 2022-06-26 10:24:33.298387
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict_0 = {}
    dict_0["allOf"] = [{
        "properties": {
            "a": {"type": "integer"}
        }
    },{
        "properties": {
            "a": {"type": "integer"}
        }
    }]
    field_0 = from_json_schema(dict_0)



# Generated at 2022-06-26 10:24:37.091992
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    print("Test 1")
    dict_0 = {}
    dict_0['$ref'] = '#/definitions/test'
    field_0 = ref_from_json_schema(dict_0)
    assert type(field_0) is Reference
 

# Generated at 2022-06-26 10:24:42.500795
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    dict_0 = {'const': 'test const', 'default': 'test default'}
    field_0 = from_json_schema(dict_0)
    assert str(field_0) == "Const(allow_blank=False, allow_null=False, choices=[('test const', 'test const')], const='test const', default='test default', help_text=None, label=None, regex_flags=0, regex_pattern=None)"


# Generated at 2022-06-26 10:24:51.403104
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test cases
    data_0 = {'not': {'not': {}}}
    assert not_from_json_schema(data_0, SchemaDefinitions()) == Any()
    data_1 = {'not': {'type': 'null'}}
    assert not_from_json_schema(data_1, SchemaDefinitions()) == Not(negated=Const(None))
    data_2 = {'not': {'type': 'number'}}
    assert not_from_json_schema(data_2, SchemaDefinitions()) == Not(negated=Float())
    data_3 = {'not': {'type': 'integer'}}
    assert not_from_json_schema(data_3, SchemaDefinitions()) == Not(negated=Integer())

# Generated at 2022-06-26 10:24:58.195471
# Unit test for function to_json_schema
def test_to_json_schema():
    name = "name"
    field = String()
    _definitions = {name: field}
    data = to_json_schema(field, _definitions=_definitions)
    assert isinstance(data, dict)
    assert data["$ref"] == f"#/definitions/{name}"
    assert data["definitions"][name] == to_json_schema(field)



# Generated at 2022-06-26 10:25:44.799161
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {
        'properties': {
            'first_name': {'type': 'string'},
            'last_name': {'type': 'string'}
        },
        'type': 'object'
    }
    field_0 = from_json_schema(dict_0)


# Generated at 2022-06-26 10:25:57.578128
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String(allow_blank=True)) == {
        "type": "string",
        "minLength": 1,
    }
    assert to_json_schema(String(allow_null=True, allow_blank=True)) == {
        "type": ["string", "null"],
        "minLength": 1,
    }
    assert to_json_schema(
        String(
            allow_null=True, allow_blank=True, min_length=10, max_length=20, pattern="foo"
        )
    ) == {
        "type": ["string", "null"],
        "minLength": 10,
        "maxLength": 20,
        "pattern": "foo",
    }

# Generated at 2022-06-26 10:26:07.194372
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {
        "if": {"const": True},
        "then": {"type": "string","maxLength": 10},
        "else": {"type": "string", "maxLength": 20},
    }
    field_0 = from_json_schema(dict_0)
    dict_1 = {"type": "string", "maxLength": 20}
    field_1 = from_json_schema(dict_1)
    json_0 = field_0.serialize_value("hello world")
    json_1 = field_1.serialize_value("hello world")
    if json_0 != json_1:
        test_case_0()


# Generated at 2022-06-26 10:26:18.959782
# Unit test for function from_json_schema
def test_from_json_schema():
    import random
    import pprint

    x = 1

# Generated at 2022-06-26 10:26:32.048548
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
    }
    assert to_json_schema(String(allow_null=True)) == {
        "type": ["string", "null"],
        "default": NO_DEFAULT,
    }
    assert to_json_schema(Integer(minimum=3, maximum=6)) == {
        "type": "integer",
        "minimum": 3,
        "maximum": 6,
        "default": NO_DEFAULT,
    }

# Generated at 2022-06-26 10:26:47.938854
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dict0 = {'type': 'object', 'properties': {'test': {'type': 'string', 'default': 'hello'}}, 'allOf': [{'type': 'object', 'properties': {'test': {'type': 'string', 'default': 'hello'}, 'test2': {'type': 'string', 'default': 'hello'}}}], 'default': {'test': 'hello'}}
    res0 = from_json_schema(dict0)
    assert res0.validate({'test': 'hello', 'test2': 'hello'}) == None


# Generated at 2022-06-26 10:27:01.801072
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()
    
    # Test that $ref converts to Schema
    ref_data = {"$ref": "#/definitions/0"}
    assert isinstance(from_json_schema(ref_data), Reference)
    
    # Test that type converts
    type_data = {"type": "string"}
    assert isinstance(from_json_schema(type_data), String)

    # Test that enum converts
    enum_data = {"enum": ["a", "b"]}
    assert isinstance(from_json_schema(enum_data), Choice)

    # Test that const converts
    const_data = {"const": "a"}
    assert isinstance(from_json_schema(const_data), Const)

# Generated at 2022-06-26 10:27:03.385909
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    test_case_0()
    

# Generated at 2022-06-26 10:27:07.797114
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema(True) == Any()


# Generated at 2022-06-26 10:27:20.502314
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert issubclass(from_json_schema_type({'type': 'integer'}, type_string='integer', allow_null=False, definitions=definitions), Integer)
    assert issubclass(from_json_schema_type({'type': 'string'}, type_string='string', allow_null=False, definitions=definitions), String)
    assert issubclass(from_json_schema_type({'type': 'object'}, type_string='object', allow_null=False, definitions=definitions), Object)
    assert issubclass(from_json_schema_type({'type': 'array'}, type_string='array', allow_null=False, definitions=definitions), Array)


# Generated at 2022-06-26 10:28:04.180653
# Unit test for function to_json_schema
def test_to_json_schema():
    def test_str_regex(regex: str) -> str:
        try:
            field = String(pattern_regex=re.compile(regex))
        except ValueError:
            return f"Fail to compile regex: {regex!r}"
        except Exception as e:
            return f"Fail to create field: {e}"
        data = to_json_schema(field)
        expected = {"type": "string", "pattern": regex}
        if data != expected:
            return f"Expected {expected!r}, got {data!r}"
        return ""

    def test_int_range(min_value: typing.Optional[int], max_value: typing.Optional[int]) -> str:
        field = Integer(minimum=min_value, maximum=max_value)
        data = to_json_schema

# Generated at 2022-06-26 10:28:11.298311
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    result = from_json_schema_type(
        data={"type": "string"}, type_string="string", allow_null=False, definitions=SchemaDefinitions()
    )
    field = String()
    assert result == field


# Generated at 2022-06-26 10:28:21.195058
# Unit test for function from_json_schema
def test_from_json_schema():
    dict_0 = {}
    field_0 = from_json_schema(dict_0)
    assert isinstance(field_0, Field)

    dict_1 = {"type": "string"}
    field_1 = from_json_schema(dict_1)
    assert isinstance(field_1, Field)

    dict_2 = {"type": "string", "minLength": 10}
    field_2 = from_json_schema(dict_2)
    assert isinstance(field_2, Field)

    dict_3 = {"type": "string", "minLength": 10, "maxLength": 20}
    field_3 = from_json_schema(dict_3)
    assert isinstance(field_3, Field)


# Generated at 2022-06-26 10:28:31.002256
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(String()) == {'type': 'string'}
    assert to_json_schema(Integer()) == {'type': 'integer'}
    assert to_json_schema(Boolean()) == {'type': 'boolean'}
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(Array()) == {'additionalItems': True, 'maxItems': None, 'minItems': 0, 'type': 'array'}
    assert to_json_schema(Object()) == {'additionalProperties': True, 'maxProperties': None, 'minProperties': None, 'type': 'object'}

# Generated at 2022-06-26 10:28:49.454745
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    _field_0 = from_json_schema_type(_data__0, _type_string__0, _allow_null__0, _definitions__0)
    _field_1 = from_json_schema_type(_data__1, _type_string__1, _allow_null__1, _definitions__1)
    _field_2 = from_json_schema_type(_data__2, _type_string__2, _allow_null__2, _definitions__2)
    _field_3 = from_json_schema_type(_data__3, _type_string__3, _allow_null__3, _definitions__3)
    _field_4 = from_json_schema_type(_data__4, _type_string__4, _allow_null__4, _definitions__4)

# Generated at 2022-06-26 10:29:02.900583
# Unit test for function to_json_schema
def test_to_json_schema():

    # Just to get 100% test coverage
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}


# Generated at 2022-06-26 10:29:08.135864
# Unit test for function to_json_schema
def test_to_json_schema():
    class Data(Schema):
        integer = Integer()
        string = String(max_length=20)
    
    data = Data()
    data.load(dict(integer=42, string="Hello world"))
    assert data.dump() == {'integer': 42, 'string': 'Hello world'}

test_case_0()
test_to_json_schema()

# Generated at 2022-06-26 10:29:16.612265
# Unit test for function to_json_schema
def test_to_json_schema():
    assert (
        to_json_schema(
            String(format="email")
        )
        == {
            "type": "string",
            "format": "email",
            "blank": True,
            "null": False,
            "empty": True,
        }
    ), "Test case 0 failed"

# Generated at 2022-06-26 10:29:24.140475
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    dict_0 = {
    "type": "string",
    "default": "Hello World!"
    }
    type_string = "string"
    allow_null = False
    definitions = SchemaDefinitions()
    dict_1 = from_json_schema_type(dict_0, type_string, allow_null, definitions)


# Generated at 2022-06-26 10:29:32.314737
# Unit test for function to_json_schema
def test_to_json_schema():
    # Test for POJO, Boolean
    field_0 = Boolean()
    assert to_json_schema(field_0) == {'type': 'boolean'}
    # Test for POJO, Array
    field_1 = Array()
    field_1_dict = to_json_schema(field_1)
    assert 'type' in field_1_dict
    assert field_1_dict['type'] == 'array'
    assert 'items' not in field_1_dict
    # Test for POJO, Object
    field_2 = Object()
    field_2_dict = to_json_schema(field_2)
    assert 'type' in field_2_dict
    assert field_2_dict['type'] == 'object'
    assert 'properties' not in field_2_dict
    # Test for POJO