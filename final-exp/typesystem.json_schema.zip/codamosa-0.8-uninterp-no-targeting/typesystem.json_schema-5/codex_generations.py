

# Generated at 2022-06-22 05:58:10.597674
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {'null', 'object', 'boolean', 'array', 'number', 'string'},
        False
    )
    assert get_valid_types({'type': 'number'}) == (
        {'number'},
        False
    )
    assert get_valid_types({'type': 'null'}) == (
        set(),
        True
    )
    assert get_valid_types({'type': ['boolean', 'null']}) == (
        {'boolean'},
        True
    )
    assert get_valid_types({'type': ['boolean', 'null']}) == (
        {'boolean'},
        True
    )

# Generated at 2022-06-22 05:58:21.926183
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # TODO: write unit test for from_json_schema_type

    from typesystem.types import JSONSchema as JSONSchema_
    from typesystem import to_json_schema


# Generated at 2022-06-22 05:58:30.151615
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    print("Testing function all_of_from_json_schema")
    schema = {
        "allOf": [
            {"type": "string", "format": "email"},
            {"type": "string", "minLength": 6},
        ]
    }
    field = from_json_schema(schema)
    print(field)
    assert isinstance(field, AllOf)
    assert len(field.all_of) == 2
    assert isinstance(field.all_of[0], String)
    assert field.all_of[0].format == "email"
    assert isinstance(field.all_of[1], String)
    assert field.all_of[1].min_length == 6



# Generated at 2022-06-22 05:58:33.365941
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String("hello")
    assert get_standard_properties(field) == {}

    field.default = "world"
    assert get_standard_properties(field) == {"default": "world"}


# Generated at 2022-06-22 05:58:36.596293
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    func = if_then_else_from_json_schema
    schema = {"if": {"type": "integer"}}
    result = func(schema, None)
    expected = IfThenElse(if_clause=Integer())
    assert expected == result



# Generated at 2022-06-22 05:58:45.072358
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    string_schema = {"type":"string"}
    negated = not_from_json_schema(string_schema, definitions=definitions)
    assert negated.negated.type == "string"
    assert negated.type == "null"
    
    num_schema = {"type":"number"}
    negated = not_from_json_schema(num_schema, definitions=definitions)
    assert negated.negated.type == "number"
    assert negated.type == "null"



# Generated at 2022-06-22 05:58:51.902192
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    test_schema = {'const': 'kyle'}
    test = const_from_json_schema(test_schema, definitions=definitions)
    assert test.serialize('kyle'), 'kyle'
    assert test.serialize('not kyle'), None

# Generated at 2022-06-22 05:58:57.495211
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["integer", "number"]}) == ({"number"}, False)
    assert get_valid_types({"type": ["integer", "null"]}) == ({"integer"}, True)
    assert (
        get_valid_types({"type": ["array", "integer", "null"]})
        == ({"array", "integer"}, True)
    )



# Generated at 2022-06-22 05:59:01.202101
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {
                "type": "number",
                "minimum": 0
            },
            {
                "type": "number",
                "maximum": 0
            }
        ]
    }
    expected = Union(
        any_of=[
            Float(minimum=0),
            Float(maximum=0)
        ]
    )
    actual = any_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert actual == expected


# Generated at 2022-06-22 05:59:06.435191
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "integer", "enum": [1, 2, 3]},
        "then": {"type": "string"},
        "else": {"type": "boolean"},
    }
    definitions = SchemaDefinitions()
    field = if_then_else_from_json_schema(data, definitions=definitions)
    assert field.validate(1) is True
    assert field.validate(2) is True
    assert field.validate(3) is True
    assert field.validate(4) is False
    assert field.validate("hello") is False
    assert field.validate(True) is False
    assert field.validate(False) is False

# Generated at 2022-06-22 06:00:02.761289
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"const": "hello"}) == Const("hello")
    assert (
        from_json_schema({"type": "string", "maxLength": 10})
        == String(max_length=10)
    )



# Generated at 2022-06-22 06:00:12.110667
# Unit test for function to_json_schema
def test_to_json_schema():
    field = String(
        min_length=1,
        min_items=2,
        max_items=8,
        default="Hello",
        pattern_regex=re.compile(r"^\d+\.\d+$"),
    )
    data = to_json_schema(field)
    expected = {
        "type": "string",
        "default": "Hello",
        "minLength": 1,
        "maxItems": 8,
        "pattern": "^\\d+\\.\\d+$",
    }
    assert data == expected

# Generated at 2022-06-22 06:00:21.739897
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True)
    assert from_json_schema(False) is NeverMatch()

    schema = from_json_schema({"$ref": "#/definitions/Test"})
    assert schema.is_strict_supertype_of(None)
    assert schema.is_strict_supertype_of("")
    assert not schema.is_strict_supertype_of(1)

    assert {"title": "", "description": ""} in from_json_schema(
        {"$ref": "#/definitions/Test"}
    )

    assert from_json_schema({"$ref": "#/definitions/Test"}).python_type == dict

    schema = from_json_schema({"enum": [1, 2, 3]})
    assert 1 in schema

# Generated at 2022-06-22 06:00:33.269608
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert (
        type_from_json_schema(
            {"type": "string", "maxLength": 5}, definitions=SchemaDefinitions()
        )
        == String(max_length=5)
    )
    assert type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions()) == Const(None)
    assert (
        type_from_json_schema({"type": "null"}, definitions=SchemaDefinitions())
        == Const(None)
    )

# Generated at 2022-06-22 06:00:41.363936
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(
        {
            "definitions": {
                "minimal_integer": Integer(minimum=1, maximum=100),
                "optional_integer": Integer(minimum=1, maximum=100, allow_null=True),
            }
        }
    )
    assert data == {
        "definitions": {
            "minimal_integer": {
                "type": "integer",
                "minimum": 1,
                "maximum": 100,
            },
            "optional_integer": {
                "type": ["integer", "null"],
                "minimum": 1,
                "maximum": 100,
            },
        }
    }
    print(json.dumps(data, indent=2))
    print("Should be:")

# Generated at 2022-06-22 06:00:46.240896
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {'const': 'value'}
    expected = Const(const='value', default=NO_DEFAULT)
    assert const_from_json_schema(data, definitions=None) == expected



# Generated at 2022-06-22 06:00:58.869850
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class Test(Field):

        def __init__(
            self,
            allow_null: bool = False,
            default: typing.Any = NO_DEFAULT,
            **kwargs,
        ):
            super().__init__(
                allow_null=allow_null,
                default=default,
                **kwargs
            )

    fld = Test()
    assert test_get_standard_properties._get_standard_properties(fld) == {}

    fld = Test(default='default')
    assert test_get_standard_properties._get_standard_properties(fld) == {'default': 'default'}

    fld = Test(default=NO_DEFAULT)
    assert test_get_standard_properties._get_standard_properties(fld) == {}

# Generated at 2022-06-22 06:01:07.250177
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf":[{'const':2},{'const':4}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert (field.validate(2) == 2), "Test one_of_from_json_schema: validate(2) return a different value than 2"

# Generated at 2022-06-22 06:01:18.340652
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Verify that a field which allows null properties will be created.
    data = {"type": ["string", "null"]}
    field = type_from_json_schema(data, definitions)
    assert field.allow_null

    # Verify that a union field which allows null properties will be created.
    data = {"type": ["string", "boolean", "null"]}
    field = type_from_json_schema(data, definitions)
    assert field.allow_null

    # Verify that any field will be created for a null field.
    data = {"type": "null"}
    field = type_from_json_schema(data, definitions)
    assert isinstance(field, Any)

    # Verify that never match field will be created for an unknown field.
    data = {"type": "unknown"}
    field = type_from_json

# Generated at 2022-06-22 06:01:24.822783
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "string", "const": "Male"},
            {"type": "string", "const": "Female"}
        ]
    }
    definitions = SchemaDefinitions()
    assert one_of_from_json_schema(data, definitions=definitions) == OneOf(
        one_of=[
            Const(const="Male"),
            Const(const="Female")
        ]
    )


# Generated at 2022-06-22 06:02:14.174603
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_data = {
        "type": "string"
    }
    a = any_of_from_json_schema(json_data, {'definitions':{}})
    assert(isinstance(a, String))
    assert(a.allow_blank)
    json_data = {
        "type": "string",
        "minLength": 0
    }
    a = any_of_from_json_schema(json_data, {'definitions':{}})
    assert(isinstance(a, String))
    assert(a.allow_blank)
    json_data = {
        "type": "string",
        "minLength": 1
    }
    a = any_of_from_json_schema(json_data, {'definitions':{}})

# Generated at 2022-06-22 06:02:22.190914
# Unit test for function to_json_schema
def test_to_json_schema():
    def inner_test_to_json_schema(
        field: Field, expected: typing.Union[bool, dict]
    ) -> None:

        output = to_json_schema(field)
        assert output == expected

    inner_test_to_json_schema(Any(), True)
    inner_test_to_json_schema(NeverMatch(), False)
    inner_test_to_json_schema(String(), {"type": "string"})
    inner_test_to_json_schema(String(allow_null=True), {"type": ["string", "null"]})
    inner_test_to_json_schema(
        String(allow_blank=False, min_length=10),
        {"type": "string", "minLength": 10},
    )
    inner_test_to_json_sche

# Generated at 2022-06-22 06:02:32.380201
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        properties={
            "name": String(
                pattern_regex=re.compile(r"^[A-Z]+$"),
                default="Joan",
                allow_blank=False,
            ),
            "age": Integer(minimum=0),
            "children": Array(items=String(), min_items=0, max_items=4),
            "married": Boolean(default=False),
        }
    )
    result = to_json_schema(schema)

# Generated at 2022-06-22 06:02:39.265115
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
     "anyOf": [
         {
             "type": "string",
             "minLength": 3
         },
         {
             "type": "string",
             "enum": ["yes", "no"]
         }
     ]
    }
    field = any_of_from_json_schema(data, definitions=definitions)
    assert field.validate("yes") == "yes"
    assert field.validate("no") == "no"
    assert field.validate("y") is None
    assert field.validate("n") is None



# Generated at 2022-06-22 06:02:44.860738
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        'enum': [
            1,
            3,
            5
        ]
    }
    definitions = SchemaDefinitions()
    enum_field = enum_from_json_schema(data,definitions=definitions)
    assert enum_field.choices[0] == (1, 1)
    assert enum_field.choices[1] == (3, 3)
    assert enum_field.choices[2] == (5, 5)



# Generated at 2022-06-22 06:02:49.707486
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "grapefruit"}, {}).validate(
        "grapefruit"
    ) == "grapefruit"
    assert const_from_json_schema({"const": "grapefruit"}, {}).validate("grape") is None


# Generated at 2022-06-22 06:03:01.628574
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types(data={"type": "object"}) == ({"object"}, False)
    assert get_valid_types(data={"type": ["object", "integer"]}) == (
        {"object", "integer"},
        False,
    )
    assert get_valid_types(data={"type": ["null", "object"]}) == (
        {"object"},
        True,
    )
    assert get_valid_types(data={"type": ["null", "object"], "nullable": False}) == (
        {"object"},
        False,
    )
    assert get_valid_types(data={"type": "null"}) == (set(), True)

# Generated at 2022-06-22 06:03:10.428638
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    test_schema = {
        "definitions": {
            "def_1": {"type": "string"},
            "def_2": {"type": "string"},
            "def_3": {"type": "integer", "enum": [1, 2, 3]},
        },
        "properties": {
            "string_field": {
                "oneOf": [
                    {"$ref": "#/definitions/def_1"},
                    {"$ref": "#/definitions/def_2"},
                ]
            },
            "enum_field": {"$ref": "#/definitions/def_3"}
        }
    }
    test_field = from_json_schema(test_schema)
    assert test_field.validate("string_field", "abc")

# Generated at 2022-06-22 06:03:22.434775
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(False) == NeverMatch()
    
    assert from_json_schema(True) == Any()

    assert from_json_schema({"type": "null"}) == Any()

    assert from_json_schema({"type": "boolean"}) == Boolean()

    assert from_json_schema({"type": "string"}) == String()

    assert from_json_schema({"type": "number"}) == Number()

    assert from_json_schema({"type": "integer"}) == Integer()

    assert from_json_schema({"type": "object"}) == Object()

    assert from_json_schema({"type": "array"}) == Array()

    assert from_json_schema({"type": "any"}) == Any()

    assert from_json

# Generated at 2022-06-22 06:03:30.704181
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
    "allOf": [
    {
    "type": "string",
    "minLength": 3
        },
    {
    "type": "string",
    "maxLength": 8
        }
        ]
    }
    schema_actual = all_of_from_json_schema(schema, None)
    schema_expected = AllOf(all_of=[String(min_length=3, allow_blank=False), String(min_length=3, max_length=8, allow_blank=False)])
    assert schema_actual == schema_expected


# Generated at 2022-06-22 06:04:03.610914
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data ={
        "if" : {
            "type": "string"
        },
        "then": {
            "minLength": 3
        },
        "default" :4
    }

    assert if_then_else_from_json_schema(data,{}).default == 4
    assert if_then_else_from_json_schema(data,{}).detailed_default == 4
    assert if_then_else_from_json_schema(data,{}) == IfThenElse({"minimum" : 3})

    data ={
        "if" : {
            "type": "string"
        },
        "then": {
            "minLength": 3
        }
    }
    
    assert if_then_else_from_json_schema(data,{}).default == NO_

# Generated at 2022-06-22 06:04:14.197325
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # type: () -> None
    """Unit test for function type_from_json_schema."""
    definitions = SchemaDefinitions()
    definitions["#/definitions/String"] = String()

    assert type_from_json_schema(None, definitions=definitions) == Any()
    assert type_from_json_schema({"type": None}, definitions=definitions) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=definitions).__class__ == String
    assert type_from_json_schema({"type": ["null", "string"]}, definitions=definitions).__class__ == Union
    assert type_from_json_schema({"type": ["string"]}, definitions=definitions).__class__ == String



# Generated at 2022-06-22 06:04:25.906087
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from .serializers import serialize_field
    from .utils import pprint
    print(pprint(serialize_field(type_from_json_schema({
        "type": [
            "float",
            "number"
        ]
    }))))
    print(pprint(serialize_field(type_from_json_schema({
        "type": [
            "float",
            "number"
        ],
        "maxLength": 3,
        "exclusiveMaximum": 3
    }))))
    print(pprint(serialize_field(type_from_json_schema({
        "type": [
            "float",
            "number"
        ],
        "minimum": 10,
        "maximum": 100,
        "exclusiveMaximum": True,
        "multipleOf": 3
    }))))

# Generated at 2022-06-22 06:04:32.259458
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(Switch(String(required=True), default_field=True, default="SomeField"))
    assert data == {"default": True}

    data = get_standard_properties(String(default="SomeField"))
    assert data == {"default": "SomeField"}

    data = get_standard_properties(String(default_field=False))
    assert data == {}



# Generated at 2022-06-22 06:04:39.684565
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    s = not_from_json_schema({"not":{"type":"integer"}}, SchemaDefinitions())
    assert s == Not(negated=Integer(), allow_null=None) # doctest: +ELLIPSIS
    assert not_from_json_schema({"not":{"type":"integer"}, "default":None}, SchemaDefinitions()) == Not(negated=Integer(), allow_null=None, default=None) # doctest: +ELLIPSIS



# Generated at 2022-06-22 06:04:50.021036
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    schema = from_json_schema({"type": "string"})
    assert isinstance(schema, String)
    assert not schema.required

    schema = from_json_schema({"type": ["string", "null"]})
    assert isinstance(schema, Union)
    assert schema.fields[0] == String()
    assert schema.fields[1] == Null()

    schema = from_json_schema({"type": "string", "minLength": 3})
    assert isinstance(schema, String)
    assert schema.min_length == 3

    schema = from_json_schema({"type": "integer", "minimum": 2, "maximum": 5})

# Generated at 2022-06-22 06:04:54.119884
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": 1}
    f = const_from_json_schema(data, definitions=None)
    assert f.validate(1) == 1
    assert f.validate(0)  == 0
    assert f.validate("")  == ""


# Generated at 2022-06-22 06:04:58.910059
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    test_data = {'default': '1234', 'oneOf': [{'type': 'null'}, {'type': 'integer'}, {'type': 'boolean'}, {'type': 'string'}, {'type': 'array'}, {'type': 'object'}, {'type': 'number'}]}
    definitions = SchemaDefinitions()
    x = one_of_from_json_schema(test_data, definitions)
    assert isinstance(x, OneOf)


# Generated at 2022-06-22 06:05:02.753332
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="")) == {"default": ""}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}


# Generated at 2022-06-22 06:05:14.096428
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    def test_with_type(json: typing.Dict[str, typing.Any]):
        schema = JSONSchema.validate(json)
        field = type_from_json_schema(schema, definitions)
        assert field.validate(schema["type"])

    test_with_type({"type": "integer"})
    test_with_type({"type": "number"})
    test_with_type({"type": "string"})
    test_with_type({"type": "boolean"})
    test_with_type({"type": "array"})
    test_with_type({"type": "object"})
    test_with_type({"type": ["integer", "null"]})
    test_with_type({"type": ["number", "null"]})
    test_with

# Generated at 2022-06-22 06:05:45.510244
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "Example",
        "type": "object",
        "properties": {
            "N1": {"type": "number"},
            "N2": {
                "allOf": [
                    {"$ref": "#/definitions/N1"},
                    {"minimum": 1},
                    {"multipleOf": 2},
                ]
            },
        },
        "definitions": {"N1": {"type": "number"}},
    }

    schema_types = from_json_schema(schema)

# Generated at 2022-06-22 06:05:49.869368
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
            "b": {"type": "boolean"},
            "c": {"type": "object"},
        },
    }
    definitions = {
        "if": from_json_schema(schema["properties"]["a"]),
        "another": from_json_schema(schema["properties"]["b"]),
        "then": from_json_schema(schema["properties"]["c"]),
        "else": from_json_schema(schema["properties"]["a"]),
    }


# Generated at 2022-06-22 06:06:00.477860
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem import Array, Boolean, Integer, String, Union, OneOf
    data = {"oneOf": [{"type": "string"}, {"type": "integer"}]}
    any_of = [from_json_schema_type(item, item["type"], False) for item in data["oneOf"]]
    schema = OneOf(one_of=any_of)

    # Test for String
    assert schema.is_valid_raw("abc")
    assert schema.is_valid_raw("abcxyz")
    assert not schema.is_valid_raw(123)
    assert not schema.is_valid_raw(123.0)

    # Test for Integer
    assert schema.is_valid_raw(123)
    assert schema.is_valid_raw(123.0)
    assert not schema.is_valid_raw("abc")

# Generated at 2022-06-22 06:06:05.847870
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "string"},
        "default": "Not a string but a default!",
    }
    definitions=None
    field = not_from_json_schema(data, definitions=definitions)
    assert field.default ==  "Not a string but a default!"
    assert field.render({}, "hi") == "hi"


# Generated at 2022-06-22 06:06:17.022076
# Unit test for function from_json_schema
def test_from_json_schema():
    field = from_json_schema(
        {
            "type": "integer",
            "definitions": {
                "foo": {
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 10,
                },
            },
            "$ref": "#/definitions/foo",
        },
    )
    assert isinstance(field, AllOf)
    assert field.fields[0].type == "string"
    assert field.fields[1].type == "integer"
    assert field.fields[0].min_length == 2
    assert field.fields[0].max_length == 10
    assert field.fields[1].definitions is not None
    assert "#/definitions/foo" in field.fields[1].definitions
    assert field.fields[1].type == "integer"

# Generated at 2022-06-22 06:06:19.895463
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Integer().minimum(1).maximum(2).multiple_of(None)
    schema = to_json_schema(field)
    assert schema == {
        "minimum": 1,
        "maximum": 2,
        "type": "integer"
    }
# Testing function to_json_schema with Array type

# Generated at 2022-06-22 06:06:27.600612
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
    assert get_valid_types({'type': ['string', 'null']}) == ({'string'}, True)
    assert get_valid_types({'type': 'null'}) == ({}, True)
    assert get_valid_types({'type': ['number', 'integer']}) == ({'number', 'integer'}, False)


# Generated at 2022-06-22 06:06:34.745437
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "type": "null"
    }
    type_strings, allow_null = get_valid_types(data)
    assert(allow_null)
    assert("null" not in type_strings)
    data = {
        "type": "integer"
    }
    type_strings, allow_null = get_valid_types(data)
    print(type_strings)
    assert("null" not in type_strings)
    assert("integer" in type_strings)
    data = {
        "type": "numeric"
    }
    type_strings, allow_null = get_valid_types(data)
    print(type_strings)
    assert("null" not in type_strings)
    assert("number" in type_strings)
    assert("integer" not in type_strings)
    type

# Generated at 2022-06-22 06:06:42.301002
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-22 06:06:44.579715
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Field(default=5)) == {"default": 5}
    assert get_standard_properties(Field()) == {}

