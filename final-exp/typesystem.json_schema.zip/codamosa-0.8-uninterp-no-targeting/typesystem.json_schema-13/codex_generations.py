

# Generated at 2022-06-22 05:57:56.950515
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/Person",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/Person"] = Object(properties={
        "name": String(),
    })
    field = ref_from_json_schema(data, definitions=definitions)
    assert type(field) is Reference
    assert field.to == "#/definitions/Person"
    assert field.definitions == definitions



# Generated at 2022-06-22 05:58:08.022122
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'array', 'object', 'number', 'string'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "object"}) == ({'object'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "array"}) == ({'array'}, False)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)

# Generated at 2022-06-22 05:58:09.968744
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data_schema = {"if": {"type": "string"}}
    if_then_else_from_json_schema(data_schema, None)



# Generated at 2022-06-22 05:58:15.412869
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"minLength": 5},
        "else": {"maxLength": 4},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.serialize("test") == "test"
    assert not field.serialize("")
    assert not field.serialize("testtesttesttest")
    assert not field.serialize([1, 2, 3])



# Generated at 2022-06-22 05:58:26.138885
# Unit test for function from_json_schema
def test_from_json_schema():

    # 'Any'
    assert from_json_schema(True).to_json_schema() == {'type': 'any'}
    assert from_json_schema(True).validate(1) is None
    assert from_json_schema(True).validate(1.1) is None
    assert from_json_schema(True).validate('str') is None
    assert from_json_schema(True).validate({}) is None
    assert from_json_schema(True).validate([]) is None

    # 'NeverMatch'
    assert from_json_schema(False).to_json_schema() == {'type': 'never'}
    assert from_json_schema(False).validate(1) == ['expected value to be of type never']
    assert from_json_schema

# Generated at 2022-06-22 05:58:31.628117
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    json_input = {
        "oneOf": [{
            "const": 5
        },
        {
            "const": "test"
        }
        ]
    }
    definition = SchemaDefinitions()
    assert type(one_of_from_json_schema(json_input, definition)) == OneOf
    #Test with one_of as constant
    json_input = {
        "oneOf": [{
            "const": 5
        },
        {
            "const": 5
        }
        ]
    }
    definition = SchemaDefinitions()
    assert type(one_of_from_json_schema(json_input, definition)) == Const


# Generated at 2022-06-22 05:58:35.866025
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = {
        "type": "string",
        "const": "3"
    }
    field = const_from_json_schema(schema, None)
    assert field.validate("3") == "3"
    assert field.validate("1") == "3"



# Generated at 2022-06-22 05:58:39.106034
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    class ObjectType(Object):
        foo: Float
        default = {"foo": 1.0}
    field = from_json_schema_type(
        {
            "type": "object",
            "properties": {"foo": {"type": "number"}},
            "required": ["foo"],
            "default": {"foo": 1.0},
        },
        type_string="object",
        allow_null=False,
        definitions=None,
    )
    assert isinstance(field, Object)
    assert field.schema.name == "ObjectType"



# Generated at 2022-06-22 05:58:46.636685
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/string",
        "definitions": {
            "string": {
                "type": "string",
                "pattern": "^[a-z]+$",
            }
        }
    }
    definitions = SchemaDefinitions()
    field = ref_from_json_schema(data, definitions=definitions)
    assert field.validate("Hello") == "Hello"
    assert not field.validate("Hello123")
    assert field.validate("World") == "World"



# Generated at 2022-06-22 05:58:51.756993
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "yes"}
    schema = const_from_json_schema(data, definitions)
    assert schema.validate("yes")
    assert not schema.validate("no")


################
# Compound types
################



# Generated at 2022-06-22 05:59:20.559482
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({}, None), Field)
    assert isinstance(type_from_json_schema({"type": "string"}, None), Field)
    assert isinstance(type_from_json_schema({"type": "number"}, None), Field)
    assert isinstance(type_from_json_schema({"type": "integer"}, None), Field)
    assert isinstance(type_from_json_schema({"type": "object"}, None), Field)
    assert isinstance(type_from_json_schema({"type": "array"}, None), Field)
    assert isinstance(type_from_json_schema({"type": "boolean"}, None), Field)
    assert isinstance(
        type_from_json_schema({"type": "null"}, None), Field
    )

# Generated at 2022-06-22 05:59:26.250062
# Unit test for function get_standard_properties
def test_get_standard_properties():
    arg = String(default='')
    assert get_standard_properties(arg) == {'default': ''}
    arg = String(default=NO_DEFAULT)
    assert get_standard_properties(arg) == {}
    arg = Integer(default=NO_DEFAULT)
    assert get_standard_properties(arg) == {}
# Testing for function to_json_schema

# Generated at 2022-06-22 05:59:33.016455
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    field_1 = Any()
    field_2 = Any()
    schema = {"anyOf": [field_1, field_2]}
    field = any_of_from_json_schema(schema)
    assert field.any_of[0] == field_1
    assert field.any_of[1] == field_2
# End of function any_of_from_json_schema



# Generated at 2022-06-22 05:59:38.124690
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": 1,
        "type": "integer",
        "default": 1,
    }
    field = const_from_json_schema(data, definitions=None)
    assert isinstance(field, Field)
    assert field.const == data["const"]
    assert field.default == data["default"]



# Generated at 2022-06-22 05:59:48.951906
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema_object = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": ["string", "null"],
        "description": "A short string",
        "minLength": 1,
        "maxLength": 8,
    }
    field = type_from_json_schema(schema_object, definitions=SchemaDefinitions())
    assert isinstance(field, Union)
    assert len(field.any_of) == 2
    assert isinstance(field.any_of[0], String)
    assert field.any_of[0].description == "A short string"
    assert field.any_of[0].minimum_length == 1
    assert field.any_of[0].maximum_length == 8

# Generated at 2022-06-22 05:59:56.722024
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {"type": "integer"},
            {"type": "string"},
        ]
    }
    definitions = None
    # Should return an integer or string
    assert isinstance(one_of_from_json_schema(data, definitions), OneOf)
    assert isinstance(one_of_from_json_schema(data, definitions).one_of[0], Integer)
    assert isinstance(one_of_from_json_schema(data, definitions).one_of[1], String)


# Generated at 2022-06-22 06:00:09.175555
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import fields
    from typesystem.utils import build_schema

    assert from_json_schema_type({}, "null", False, definitions={}) == fields.Any()

    assert from_json_schema_type({"type": "null"}, "null", False, definitions={}) == fields.Any()
    assert from_json_schema_type({"type": "boolean"}, "boolean", False, definitions={}) == fields.Boolean()
    assert from_json_schema_type({"type": "number"}, "number", False, definitions={}) == fields.Float()
    assert from_json_schema_type({"type": "integer"}, "integer", False, definitions={}) == fields.Integer()
    assert from_json_schema_type({"type": "string"}, "string", False, definitions={}) == fields

# Generated at 2022-06-22 06:00:19.209832
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.exceptions import ValidationError

    schema = {
        "type": "object",
        "properties": {
            "user_id": {"type": "string", "pattern": "^[0-9]+$"},
            "first_name": {"type": "string"},
            "last_name": {"type": "string"},
        },
    }
    field = from_json_schema(schema)
    field.validate({"user_id": "1234", "first_name": "Joe", "last_name": "Bloggs"})

# Generated at 2022-06-22 06:00:23.079420
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test type validation
    one_of = [{"type": "string"}, {"type": "number"}]
    field = OneOf(one_of=one_of)
    assert not field.is_valid("test")
    assert not field.is_valid(2)
    assert field.is_valid(1.0)


# Generated at 2022-06-22 06:00:29.713247
# Unit test for function to_json_schema
def test_to_json_schema():
    to_json_schema(Integer())
    String(pattern_regex=re.compile(r"[a-z]", re.RegexFlag.UNICODE))
    String(pattern_regex=re.compile(r"[a-z]", re.RegexFlag.IGNORECASE))



# Generated at 2022-06-22 06:01:49.676296
# Unit test for function from_json_schema
def test_from_json_schema():
    """Unit test for function from_json_schema"""
    # Test: String: String, String(minLength=1, maxLength=15, pattern=r"..."), String(format="email")
    assert from_json_schema({}) == Any()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": ["string"]}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "null"}) == Union([Const(None), NeverMatch()])

# Generated at 2022-06-22 06:02:02.463879
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    @schema_class
    class S_NestedIfThenElse(Schema):
        a = Integer(if_={'if': {'propertyNames':{'format':'aa*'}}, 'then':{'minimum':'1'}}, else_={'minimum':'0'})
        b = Integer(if_={'if': {'propertyNames':{'format':'bb*'}}, 'then':{'minimum':'2'}}, else_={'minimum':'0'})
        c = Integer(if_={'if': {'propertyNames':{'format':'cc*'}}, 'then':{'minimum':'3'}}, else_={'minimum':'0'})
    @schema_class
    class S_NestedIfThenElse2(S_NestedIfThenElse):
        d = Integer

# Generated at 2022-06-22 06:02:04.937663
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/dog"}) == \
        Reference(to="#/definitions/dog", definitions=definitions)



# Generated at 2022-06-22 06:02:09.692300
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/my_reference",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/my_reference"] = Integer()
    assert ref_from_json_schema(data, definitions=definitions)
    data = {
        "$ref": "http://google.com",
    }
    # TODO: Raise TypeSystemError instead
    try:
        ref_from_json_schema(data, definitions=definitions)
    except AssertionError:
        pass
    else:  # pragma: no cover
        assert False, "Should not have gotten here."



# Generated at 2022-06-22 06:02:15.159150
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({'$ref': '#/definitions/string'}).to == '#/definitions/string'
    assert ref_from_json_schema({'$ref': '#/definitions/string'}).definitions == None



# Generated at 2022-06-22 06:02:27.062211
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({
        "$ref": "#/definitions/a",
        "definitions": {
            "a": {
                "type": "integer"
            }
        }
    }) == String(format="regex", pattern=r"^#/definitions/a$")

# Generated at 2022-06-22 06:02:34.214089
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Create a field that has a default value
    f1 = String(default="Some string")
    # Create a field that has no default value,
    # but allows null values
    f2 = String(allow_null=True)
    # Create a field that has a default value of None
    f3 = String(default=None)
    # Create a field that has no default value,
    # and does not allow null values
    f4 = String(allow_null=False)

    # Create list of pairs of expected output and input
    pairs = [
        ({"default": "Some string"}, f1),
        ({}, f2),
        ({}, f3),
        ({}, f4),
    ]

    for expected, field in pairs:
        d = get_standard_properties(field) == expected
        assert d



# Generated at 2022-06-22 06:02:39.090652
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    field = one_of_from_json_schema({"oneOf": [{"type":"string"}, {"type":"integer"}]}, definitions={})
    assert field.validate(5) == (5, 5)



# Generated at 2022-06-22 06:02:49.092620
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'boolean', 'string', 'object', 'array', 'null', 'number'}, False)
    assert get_valid_types({'type': []}) == ({'boolean', 'string', 'object', 'array', 'null', 'number'}, False)
    assert get_valid_types({'type': ['string']}) == ({'string'}, False)
    assert get_valid_types({'type': 'null'}) == ({'null'}, True)
    assert get_valid_types({'type': ['null', 'integer']}) == ({'integer'}, True)
    assert get_valid_types({'type': ['null', 'array']}) == ({'array'}, True)
    assert get_valid_types({'type': 'string'}) == ({'string'}, False)
   

# Generated at 2022-06-22 06:03:00.810414
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer.make_validator()) == {
        "type": "integer",
        "default": None,
        "const": None,
        "enum": None,
        "dependencies": None,
        "examples": None,
        "title": None,
        "description": None,
    }
    assert to_json_schema(String.make_validator()) == {
        "type": "string",
        "default": None,
        "const": None,
        "enum": None,
        "dependencies": None,
        "examples": None,
        "title": None,
        "description": None,
    }

# Generated at 2022-06-22 06:03:40.885651
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    definitions = SchemaDefinitions()

    # Positive tests
    data = dict(type=["integer"])
    assert isinstance(from_json_schema_type(data, "integer", allow_null=False, definitions=definitions), Integer)

    data = dict(type=["number"])
    assert isinstance(from_json_schema_type(data, "number", allow_null=False, definitions=definitions), Float)

    data = dict(type=["string"])
    assert isinstance(from_json_schema_type(data, "string", allow_null=False, definitions=definitions), String)

    data = dict(type=["boolean"])
    assert isinstance(from_json_schema_type(data, "boolean", allow_null=False, definitions=definitions), Boolean)


# Generated at 2022-06-22 06:03:44.609214
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 42}).validate(42)
    assert const_from_json_schema({"const": 42}).validate("42")



# Generated at 2022-06-22 06:03:56.316240
# Unit test for function to_json_schema
def test_to_json_schema():
    from .validator import Validator, Field, Schema, Object, Integer, Float, Array, Boolean, String, make_validator, OneOf, Choice, AlwaysMatch
    from .schema_definitions import SchemaDefinitions
    from .exceptions import ValidationError
    import json

    s = make_validator({
        "oneOf": [
            # {"type": "integer", "minimum": 0},
            {"type": "integer", "const": 0},
            {"type": "float", "minimum": 0.0},
            {"type": "float", "const": 0.0},
        ]
    })
    for item in (0, 0.0):
        print(json.dumps(s(item)))


# Generated at 2022-06-22 06:03:59.284687
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {'enum': ['foo', 'bar'], 'const': 'a', 'type': 'integer', 'not': {'enum': ['baz']}}

    assert JSONSchema.is_valid(data)
    assert not_from_json_schema(data, definitions={}).is_valid({})
    assert not_from_json_schema(data, definitions={}).is_valid(5)
    assert not not_from_json_schema(data, definitions={}).is_valid('baz')



# Generated at 2022-06-22 06:04:11.221877
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Test case: array of numbers
    data = {"enum": [1, 2, 3]}
    assert enum_from_json_schema(data, definitions=None) == Choice(
        choices=[(1, 1), (2, 2), (3, 3)]
    )

    # Test case: array of strings
    data = {"enum": ["a", "b", "c"]}
    assert enum_from_json_schema(data, definitions=None) == Choice(
        choices=[("a", "a"), ("b", "b"), ("c", "c")]
    )

    # Test case: array of strings with default
    data = {"enum": ["a", "b", "c"], "default": "b"}

# Generated at 2022-06-22 06:04:14.298044
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={
        "#/definitions/foo": {}
    }), Reference)



# Generated at 2022-06-22 06:04:20.450933
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [1,2,3,4]}
    definitions = SchemaDefinitions()
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    assert OneOf(**kwargs).validate(2)



# Generated at 2022-06-22 06:04:27.034921
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "$ref": "#/definitions/nullable_boolean",
        "definitions": {
            "nullable_boolean": {
                "anyOf": [
                    {"type": "boolean"},
                    {"type": "null"},
                ]
            }
        }
    }
    field = ref_from_json_schema(json_schema, definitions)
    assert field.allow_null
    assert field.validate(True)
    assert not field.validate(None)



# Generated at 2022-06-22 06:04:36.064836
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(
        {"minimum": 1, "maximum": 10, "type": "number"},
        type_string="number",
        allow_null=False,
        definitions=None,
    ) == Float(minimum=1, maximum=10)
    assert from_json_schema_type(
        {"minimum": 1, "maximum": 10, "type": "integer"},
        type_string="integer",
        allow_null=False,
        definitions=None,
    ) == Integer(minimum=1, maximum=10)

# Generated at 2022-06-22 06:04:38.272713
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{}, {}]}
    definitions = SchemaDefinitions()
    schema = one_of_from_json_schema(data, definitions)
    assert type(schema) == OneOf
    assert type(schema.one_of) == list
    assert len(schema.one_of) == 2
    assert schema.default == NO_DEFAULT



# Generated at 2022-06-22 06:05:19.546828
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "nil"}, definitions=definitions) == Const(None)


# Generated at 2022-06-22 06:05:24.871103
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions={}) == Reference(to="#/definitions/foo", definitions={})
    assert ref_from_json_schema({"$ref": "#/definitions/bar"}, definitions={"#/definitions/bar": String()}) == String()



# Generated at 2022-06-22 06:05:31.645412
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Just make sure this function doesn't throw an exception
    # with many different input arguments.
    data = get_standard_properties(None)
    assert data == {}, data

    data = get_standard_properties(Any())
    assert data == {}, data

    data = get_standard_properties(Integer(default=0))
    assert data == {"default": 0}, data

    data = get_standard_properties(Not(negated=Any(), default=2))
    assert data == {"default": 2}, data



# Generated at 2022-06-22 06:05:39.661625
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    valid_type_names = {"string", "boolean", "integer", "number", "object", "array"}

# Generated at 2022-06-22 06:05:48.190781
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_schema = {
        'not': {"type": "integer"}
    }
    field = not_from_json_schema(not_schema, definitions=SchemaDefinitions())
    assert isinstance(field, Not)
    assert isinstance(field.negated, Integer)



# Generated at 2022-06-22 06:05:52.415504
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'$ref': '#/definitions/example'}
    ref = ref_from_json_schema(data, definitions={'#/definitions/example': Const('test')})
    assert isinstance(ref, Reference)
    assert ref.to == '#/definitions/example'

# Generated at 2022-06-22 06:05:59.112771
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # pprint (vars(not_from_json_schema({'not': {'type':'integer'}}, definitions=None))

    not_field = not_from_json_schema({'not': {'type':'integer'}}, definitions=None)
    assert type(not_field) == Not
    assert not_field.negated.type_name == 'integer'
    assert not_field.negated.allow_null == False
    assert not_field.negated.minimum is None
    assert not_field.negated.maximum is None
    assert not_field.negated.exclusive_minimum is None
    assert not_field.negated.exclusive_maximum is None
    assert not_field.negated.multiple_of is None
    assert not_field.negated.default == '__NO_DEFAULT__'



# Generated at 2022-06-22 06:06:08.336129
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Test boolean
    assert isinstance(type_from_json_schema({"type": "boolean"}, None), Boolean)
    assert isinstance(type_from_json_schema({"type": ["boolean"]}, None), Boolean)
    assert isinstance(type_from_json_schema({}, None), Any)
    assert isinstance(type_from_json_schema({"type": ["boolean", None]}, None), Union)
    assert isinstance(type_from_json_schema({"type": [None]}, None), Const)
    assert isinstance(type_from_json_schema({"type": ["boolean", "string"]}, None), Union)
    assert isinstance(type_from_json_schema({"type": ["boolean", "integer"]}, None), Union)

# Generated at 2022-06-22 06:06:19.876834
# Unit test for function get_valid_types
def test_get_valid_types():
    test_data = [
        ({"type": "string"}, {"string"}, False),
        ({"type": {"type": "string"}}, {"string"}, False),
        ({"type": ["string", "null"]}, {"string"}, True),
        ({}, {"string", "null", "object", "array", "number", "integer", "boolean"}, False),
        ({"type": "null"}, {"null"}, False),
        ({"type": {"type": "null"}}, {"null"}, False),
        ({"type": "boolean"}, {"boolean"}, False),
        ({"type": "integer"}, {"integer"}, False),
        ({"type": "number"}, {"number", "integer"}, False),
    ]

    for data, expected_type_strings, expected_allow_null in test_data:
        actual_type_strings, actual_allow_

# Generated at 2022-06-22 06:06:30.166267
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, {}) == Any()
    assert type_from_json_schema({"type": "string"}, {}) == String()
    assert type_from_json_schema({"type": "boolean"}, {}) == Boolean()
    assert type_from_json_schema({"type": "integer"}, {}) == Integer()
    assert type_from_json_schema({"type": "number"}, {}) == Number()
    assert type_from_json_schema({"type": "null"}, {}) == Const(None)
    assert type_from_json_schema({"type": "object"}, {}) == Object()
    assert type_from_json_schema({"type": "array"}, {}) == Array()