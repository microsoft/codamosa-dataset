

# Generated at 2022-06-22 05:58:36.600791
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = Schema({'anyOf': [{'type': 'integer'}, {'type': 'string'}]})
    assert 3 == schema.validated('3')
    assert '3' == schema.validated('3.0')
    assert '3' == schema.validated('3.03')
    assert '3' == schema.validated('3.3')
    assert '3.3' == schema.validated('3.3', return_value=True)
    assert '3.03' == schema.validated('3.03', return_value=True)



# Generated at 2022-06-22 05:58:45.690938
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert any([
        isinstance(ref_from_json_schema({'$ref': '#/definitions/A'}, definitions={'#/definitions/A': Integer()}), Reference),
        isinstance(ref_from_json_schema({'$ref': '#/definitions/A'}, definitions={'#/definitions/A': String()}), Reference),
        isinstance(ref_from_json_schema({'$ref': '#/definitions/A'}, definitions={'#/definitions/A': Boolean()}), Reference),
    ]) == True


# Generated at 2022-06-22 05:58:53.405785
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {'definitions': {'NaturalNumber': {'type': 'integer', 'minimum': 0}},
            '$ref': '#/definitions/NaturalNumber'}
    field = ref_from_json_schema(data, definitions)
    assert isinstance(field, Reference)
    assert field.to == '#/definitions/NaturalNumber'



# Generated at 2022-06-22 05:59:01.048726
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from_json_schema_type({}, "string", False, None)
    from_json_schema_type({}, "number", False, None)
    from_json_schema_type({}, "integer", False, None)
    from_json_schema_type({}, "boolean", False, None)
    from_json_schema_type({}, "array", False, None)
    from_json_schema_type({}, "object", False, None)
    from_json_schema_type(
        {"required": ["foo"]}, "object", False, None
    )  # pragma: no cover



# Generated at 2022-06-22 05:59:09.216606
# Unit test for function from_json_schema
def test_from_json_schema():
    json_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": {
            "absolute_file_path": {
                "type": "string",
                # A custom format for an absolute file path.
                "pattern": r"^((\\[^/\\]+)+|([A-Za-z]:)?[^/\\]+)/((\\[^/\\]+)+|[^/\\]+)*$"
            }
        },
        "$ref": "#/definitions/absolute_file_path"
    }
    field = from_json_schema(json_schema)
    assert type(field) == Reference
    assert field.ref_name == '#/definitions/absolute_file_path'

# Generated at 2022-06-22 05:59:19.526768
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    dataRange = {"allOf": [{"type": "number", "maximum": 3, "minimum": 1}]}
    d_range = all_of_from_json_schema(dataRange, definitions)
    assert d_range.validate(2) == True
    assert d_range.validate(4) == False
    assert d_range.validate(0) == False
    assert d_range.validate("a") == False
    assert d_range.validate(True) == False
    dataType = {"allOf": [{"type": "number"}, {"type": "string"}]}
    d_type = all_of_from_json_schema(dataType, definitions)
    assert d_type.validate(2) == False
    assert d_type.validate("a") == False
    assert d_type.valid

# Generated at 2022-06-22 05:59:29.739564
# Unit test for function to_json_schema
def test_to_json_schema():
    optional_string = String(default="hello")
    required_string = String(default="hello", allow_null=False)
    string_with_length_restrictions = String(
        default="hello", min_length=2, max_length=10
    )
    string_with_regex = String(default="hello", pattern_regex=re.compile("h.*"))
    string_with_schema_format = String(default="hello", format="date-time")
    optional_integer = Integer(default=42)
    required_integer = Integer(default=42, allow_null=False)
    optional_float = Float(default=42.0)
    required_float = Float(default=42.0, allow_null=False)

# Generated at 2022-06-22 05:59:41.181041
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
    "type": "array",
    "items": [
        {
            "anyOf": [
                {"type": "string"},
                {
                    "type": "object",
                    "properties": {
                        "firstName": {"type": "string"},
                        "lastName": {"type": "string"}
                    }
                }
            ]
        }
    ]
}
    assert any_of_from_json_schema(schema,definitions) == Field.__subclasscheck__([String(),Object(properties = {
        "firstName":String(),
        "lastName":String()
    })])
    assert any_of_from_json_schema(schema,definitions) != Field.__subclasscheck__([String(), Float()])


# Generated at 2022-06-22 05:59:47.772403
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"type": "string"}, {"minLength": 5}]}
    allof_result = all_of_from_json_schema(data, definitions=definitions)
    assert isinstance(allof_result, AllOf)
    assert len(allof_result.all_of) == 2
    assert isinstance(allof_result.all_of[0], String)
    assert isinstance(allof_result.all_of[1], String)
    assert allof_result.all_of[1].min_length == 5



# Generated at 2022-06-22 05:59:55.883249
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/MultiType"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/MultiType"] = String(
        one_of=["a", "b", "c"], allow_null=True
    )
    field = ref_from_json_schema(data, definitions=definitions)
    assert field.is_valid("a")
    assert field.is_valid("b")
    assert field.is_valid("c")
    assert field.is_valid(None)
    assert not field.is_valid("d")

# Generated at 2022-06-22 06:00:35.965663
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'string'}, {'type': 'integer'}], 'default': 1, 'type': 'number'}
    kwargs = {'any_of': [String(allow_null=True), Integer(allow_null=True)], 'default': 1}
    assert any_of_from_json_schema(data, None) == Union(**kwargs)


# Generated at 2022-06-22 06:00:39.306481
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = Any()
    schema2 = Union(any_of=[Any(), Any()])
    assert any_of_from_json_schema({"anyOf": [{}, {}]}, None) == schema2



# Generated at 2022-06-22 06:00:49.913952
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()

    assert (
        type_from_json_schema({"type": "string"}, definitions={}) == String()
    )  # noqa

    assert (
        type_from_json_schema({"type": "string", "maxLength": 10}, definitions={})
        == String(max_length=10)
    )  # noqa

    schema = {"type": "string"}

    assert (
        type_from_json_schema({"type": "string", "const": "foo"}, definitions={})
        == Const("foo")
    )  # noqa

    assert (
        type_from_json_schema({"type": ["string", "null"]}, definitions={})
        == String(allow_null=True)
    )  # no

# Generated at 2022-06-22 06:00:57.665736
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    d1 = {
        "not": {
            "type": "string",
        }
    }
    assert not_from_json_schema(d1, definitions=None).to_dataclass_field() == dataclasses.field(
        default=NO_DEFAULT,
        metadata={},
        default_factory=dataclasses._MISSING,
        type=typing_extensions.Annotated[
            typing.Union[object, typing.Type["Not"]], typing.Type["Not"],
        ],
    )



# Generated at 2022-06-22 06:01:06.304724
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = {"#/definitions/foo": Integer()}
    result: Field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/foo"



# Generated at 2022-06-22 06:01:17.476308
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert (
        Object(
            properties={
                "name": String(min_length=2, max_length=10, allow_blank=False),
                "age": Integer(minimum=0, maximum=99),
            }
        ).to_json_schema()
        == {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "definitions": {},
            "properties": {
                "name": {
                    "default": "",
                    "type": "string",
                    "minLength": 2,
                    "maxLength": 10,
                },
                "age": {"default": 0, "type": "integer", "minimum": 0, "maximum": 99},
            },
            "additionalProperties": False,
        }
    )

# Generated at 2022-06-22 06:01:23.675801
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from typesystem.test_utils import assert_field_serialize_roundtrip
    data = {"$ref": "#/definitions/Name"}
    assert_field_serialize_roundtrip(
        from_json_schema(data), definitions,
        assert_func=lambda x: isinstance(x, Reference),
    )
test_ref_from_json_schema()



# Generated at 2022-06-22 06:01:28.845337
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "null"},
            {"type": "integer", "minimum": 0},
        ]
    }
    all_of=all_of_from_json_schema(data, None)
    assert all_of.validate(None)
    assert all_of.validate(5)
    assert not all_of.validate(-1)



# Generated at 2022-06-22 06:01:33.782916
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    from typing import Dict
    from robotoff.utils.json_dt import JsonSchemaDefinitions

    def to_schema(schema: Field) -> Dict[str, any]:
        return json.loads(json.dumps(to_json_schema(schema, {})))

    assert to_schema(String()) == {"type": "string"}
    assert to_schema(String(nullable=True)) == {"type": ["string", "null"]}
    assert to_schema(Integer()) == {"type": "integer"}
    assert to_schema(Integer(nullable=True)) == {"type": ["integer", "null"]}
    assert to_schema(Array(of=String())) == {
        "type": "array",
        "items": {"type": "string"},
    }

# Generated at 2022-06-22 06:01:47.440828
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from .validation import ValidationError

    # if: {const: true}, then: {type: "string"}
    field = if_then_else_from_json_schema(
        {
            "if": {"const": True},
            "then": {"type": "string"},
        },
        definitions=None,
    )
    field.validate(True)
    field.validate("one")
    with pytest.raises(ValidationError):
        field.validate(False)

    # if: {const: true}, then: {type: "string"}, else: {type: "number"}

# Generated at 2022-06-22 06:03:06.298491
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "foo": {
                "oneOf": [
                    {"type": "string"},
                    {"type": "integer"},
                ]
            },
            "bar": {
                "type": "string",
                "maxLength": 7,
            }
        },
        "required": ["foo", "bar"],
    }
    types = type_from_json_schema(data=schema)
    assert isinstance(types, Object)
    assert isinstance(types.properties["foo"], Union)
    assert isinstance(types.properties["foo"].any_of[0], String)
    assert isinstance(types.properties["foo"].any_of[1], Integer)
    assert isinstance(types.properties["bar"], String)

# Generated at 2022-06-22 06:03:12.392432
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema(
        {"a": String, "b": Integer},
        all_of=(String, {"a": String, "b": Integer}),
        if_clause={"a": String},
        then_clause={"b": Integer},
        else_clause={"c": Integer},
    )

# Generated at 2022-06-22 06:03:14.405447
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer()) == {}



# Generated at 2022-06-22 06:03:20.223061
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    sanity check
    """
    f = not_from_json_schema({
        "not" : {
            "oneOf": [
                {
                    "type" : "null"
                },
                {
                    "type" : "number"
                }
            ]
        },
        "default": -1
    }, None)
    assert f.validate('abc') == -1
    assert f.validate(1.1) == 1.1



# Generated at 2022-06-22 06:03:31.672719
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({'type': 'null'}) == ({'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({'type': 'integer'}) == ({'integer', 'number'}, False)
    assert get_valid_types({'type': ['null', 'integer']}) == ({'boolean', 'object', 'array', 'number', 'string', 'integer'}, True)
    assert get_valid_types({'type': ['null', 'integer', 'array']}) == ({'boolean', 'object', 'array', 'number', 'string', 'integer'}, True)

# Generated at 2022-06-22 06:03:43.415251
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "definitions": {
            "typeA": {
                "type": "object",
                "required": ["property"],
                "properties": {"property": {"enum": ["value1", "value2"]}},
            }
        },
        "type": "object",
        "properties": {"name": {"type": "string"}},
    }
    field = from_json_schema(schema)
    assert field.validate({"name": "a"})
    assert field.validate({"name": 42}) is False
    assert field.validate({"name": "a", "property": "value1"}) is False

# Generated at 2022-06-22 06:03:53.421898
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"title": "Female", "type": "boolean", "const": True},
            {"title": "Male", "type": "boolean", "const": False},
        ]
    }
    definitions = SchemaDefinitions()

    field = any_of_from_json_schema(data, definitions)
    assert field.validate(True)
    assert field.validate(False)

    result = field.to_primitive(True)
    assert result == True

    result = field.to_primitive(False)
    assert result == False

    result = field.default
    assert result is None

# Generated at 2022-06-22 06:03:58.211132
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # Given
    data = {
        "type": "string",
        "enum": ["test"]
    }
    # When
    result = all_of_from_json_schema(data, None)
    # Then
    assert isinstance(result, AllOf)


# Generated at 2022-06-22 06:04:05.168506
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "if": {"type": "integer"},
        "then": {"minimum": 5},
        "else": {"minimum": 1},
        "default": 1,
        "definitions": {},
    }
    assert from_json_schema(json_schema) == IfThenElse(
        if_clause=Reference("#/definitions/if"),
        then_clause=Reference("#/definitions/then"),
        else_clause=Reference("#/definitions/else"),
        default=1,
    )



# Generated at 2022-06-22 06:04:15.183549
# Unit test for function to_json_schema
def test_to_json_schema():
    name = String(min_length=3, max_length=10, allow_blank=False)
    age = Integer(minimum=16, maximum=120, exclusive_minimum=False)
    weight = Float(minimum=20.0, maximum=300.0, multiple_of=1.0)
    employed = Boolean(default=False, allow_null=True)
    income = Decimal(minimum=0.0, maximum=1_000_000.0, multiple_of=0.01)
    address = String(min_length=3, max_length=50)
    json_schema = to_json_schema(
        Schema(
            name=name, age=age, weight=weight, employed=employed, income=income
        )
    )

# Generated at 2022-06-22 06:04:43.146533
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(
        data={"type": "integer"}, type_string="integer", allow_null=False, definitions=None
    ) == Integer(
        allow_null=False,
        minimum=None,
        maximum=None,
        exclusive_minimum=None,
        exclusive_maximum=None,
        multiple_of=None,
        default=NO_DEFAULT,
    )



# Generated at 2022-06-22 06:04:44.208416
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "integer"}})  == ~Integer()



# Generated at 2022-06-22 06:04:55.224834
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({'type': 'object'}) == Object()
    assert from_json_schema({'type': 'object', 'properties': {'name': {'type': 'string'}}}) == Object(properties={'name': String()})
    assert from_json_schema({'type': ['object', 'null']}) == OneOf([Object(), Const(None)])
    assert from_json_schema({'enum': ['a', 'b', 'c']}) == Choice(['a', 'b', 'c'])
    assert from_json_schema({'const': 'value'}) == Const('value')
    assert from_json_schema({'not': {'type': 'object'}}) == Not(Object())
    assert from_json_

# Generated at 2022-06-22 06:05:03.498568
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class MyField(Field):
        def produce_default(self, data: dict) -> dict:
            return data
    for field_cls, data in (
        (MyField, {}),
        (String, {}),
        (String, {"default": ""}),
        (Object, {"default": {"a": 1}}),
        (Integer, {"default": 1}),
    ):
        field = field_cls(default=NO_DEFAULT)
        assert get_standard_properties(field) == data



# Generated at 2022-06-22 06:05:15.307587
# Unit test for function to_json_schema
def test_to_json_schema():
    mapping = make_json_schemas(
        {
            "my_string": String(min_length=1, default="hello"),
            "my_int": Integer(minimum=0, maximum=100),
            "my_object": Object(
                properties={
                    "my_string": String(max_length=100),
                    "my_int": Integer(minimum=0),
                },
                required=["my_string"],
            ),
            "my_choice": Choice(
                choices=[
                    ("dog", "Dog"),
                    ("cat", "Cat"),
                    ("mouse", "Mouse"),
                ],
                default="dog",
            ),
        }
    )

# Generated at 2022-06-22 06:05:20.064739
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    """Test the Const field."""

    a = Const(const="string")
    assert a.validate_or_raise(None) == "string"
    assert a.default == "string"



# Generated at 2022-06-22 06:05:24.564125
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    input = {"const": "Hello world", "type": "string"}
    expected = Const(const="Hello world", default=NO_DEFAULT)
    test_value = const_from_json_schema(input, definitions)
    assert test_value == expected



# Generated at 2022-06-22 06:05:29.808197
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/ChildObject"
    }
    definitions = SchemaDefinitions()

    definitions["#/definitions/ChildObject"] = Schema(properties={
        "name": String(),
        "age": Integer()
    })
    
    from_json_schema(data, definitions=definitions)
    assert True



# Generated at 2022-06-22 06:05:34.142711
# Unit test for function to_json_schema
def test_to_json_schema():
    # pylint: disable=W0611
    from . import fields

    # Identity
    all_fields = {
        fields.Any,
        fields.NeverMatch,
        fields.String,
        fields.Integer,
        fields.Float,
        fields.Decimal,
        fields.Boolean,
        fields.Array,
        fields.Object,
        fields.Choice,
        fields.Const,
        fields.Union,
        fields.OneOf,
        fields.AllOf,
        fields.IfThenElse,
        fields.Not,
    }
    for field in all_fields:
        assert from_json_schema(to_json_schema(field())) == field()

    # Basic
    assert from_json_schema(to_json_schema(String())) == String()
    assert from_json

# Generated at 2022-06-22 06:05:45.942337
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": None}) == ({}, True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)
    assert get_valid_types({"type": ["null", "integer", "boolean"]}) == ({"boolean", "integer"}, True)
    assert get_valid_types({"type": ["null", "integer", "boolean", "number"]}) == ({"boolean", "number"}, True)

# Generated at 2022-06-22 06:06:21.416570
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        name: str
        age: Integer(minimum=0)

    class DictPerson(dict, Schema):
        name: str
        age: Integer(minimum=0)

    class TuplePerson(tuple, Schema):
        name: str
        age: Integer(minimum=0)

    assert to_json_schema(Person) == {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {
            "name": {"type": "string", "default": NO_DEFAULT},
            "age": {"type": "integer", "default": NO_DEFAULT, "minimum": 0},
        },
        "required": ["name", "age"],
        "additionalProperties": False,
    }

# Generated at 2022-06-22 06:06:26.613703
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    kwargs = {'one_of': [String()], 'default': NO_DEFAULT}
    result = OneOf(**kwargs)
    assert kwargs['one_of'][0].validate('text') == result.validate('text')
    assert kwargs['one_of'][0].validate('') == result.validate('')



# Generated at 2022-06-22 06:06:39.123271
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema= {
        'anyOf': [
            {'type': 'number'},
            {'type': 'integer'}
        ]
    }
    field = any_of_from_json_schema(json_schema, definitions)
    assert str(field) == "Union(any_of=[Float(), Integer()], allow_null=False, default=typesystem.fields.NO_DEFAULT)"
    is_valid, errors = field.validate(4)
    assert is_valid
    is_valid, errors = field.validate(4.0)
    assert is_valid
    is_valid, errors = field.validate("4")
    assert not is_valid



# Generated at 2022-06-22 06:06:47.394617
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean", "null"]}) == ({"boolean"}, True)
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "number"}) == ({"number"}, False)



# Generated at 2022-06-22 06:06:55.825894
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Test that passing various JSON schemas to ``from_json_schema`` produces
    the expected output.
    """
    from typesystem.base import to_json_schema
    import json

    # Test a simple object.
    object_schema = {
        "type": "object",
        "properties": {
            "property_1": {
                "type": "number"
            }
        }
    }

    assert to_json_schema(from_json_schema(object_schema)) == json.dumps(object_schema)

    # Test more complex schemas.