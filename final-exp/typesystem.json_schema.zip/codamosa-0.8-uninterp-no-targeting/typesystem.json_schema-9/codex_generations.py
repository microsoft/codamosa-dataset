

# Generated at 2022-06-22 05:57:55.066143
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        'allOf': [{"type": "integer"}, {"maximum": 100}],
        'default': 0
    }
    assert all_of_from_json_schema(data, None).default == 0
    assert all_of_from_json_schema(data, None).validate(0) == 0
    assert all_of_from_json_schema(data, None).validate(101) is None
    assert all_of_from_json_schema(data, None).validate('abcd') is None
    assert all_of_from_json_schema(data, None).validate(1.01) is None



# Generated at 2022-06-22 05:58:04.014998
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    def test_one_of_from_json_schema():
        definitions = SchemaDefinitions()

        schema_string = json.dumps(
            {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "$id": "OneOf#",
                "title": "OneOf",
                "type": "object",
                "properties": {

                    "result": {
                        "title": "result",
                        "oneOf": [
                            {"$ref": "String#"},
                            {"$ref": "Integer#"},
                            {"enum": ["a"]},
                        ],
                    }
                },
            }
        )
        data = json.loads(schema_string)
        field = from_json_schema(data, definitions=definitions)

# Generated at 2022-06-22 05:58:16.330587
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'type': 'string'}, {'type': 'number'}]}
    definitions = {}
    schemas = {'#/definitions/schema': String()}

    # a field that must be either a string or a number
    field = one_of_from_json_schema(data, definitions)
    assert field.validate('str').is_valid()
    assert field.validate(123).is_valid()
    assert not field.validate(False).is_valid()
    assert not field.validate(1.0).is_valid()
    # a schema that must be either a string or a number
    schema = from_json_schema(data, definitions)
    assert schema.validate('str').is_valid()
    assert schema.validate(123).is_valid()

# Generated at 2022-06-22 05:58:25.578912
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Test case for a local ref
    document = {"$ref": "#/definitions/test"}
    assert isinstance(ref_from_json_schema(document, definitions=definitions), Reference)
    # Test case for an external ref
    document = {"$ref": "http://example.com/schema.json#/definitions/test"}
    assert isinstance(ref_from_json_schema(document, definitions=definitions), Reference)
    # Test case for an invalid ref
    document = {"$ref": "http://example.com/schema.json"}
    assert isinstance(ref_from_json_schema(document, definitions=definitions), Reference)



# Generated at 2022-06-22 05:58:28.700608
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference = Reference(to="#/definitions/foo", definitions=SchemaDefinitions())
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions=SchemaDefinitions()) == reference


# Generated at 2022-06-22 05:58:33.948856
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["foo"]}) == Choice(choices=[("foo", "foo")])
    assert enum_from_json_schema({"enum": ["foo", "bar"]}) == Choice(choices=[("foo", "foo"), ("bar", "bar")])



# Generated at 2022-06-22 05:58:39.881983
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    ref_object = {
        "definitions": {
            "integer": {"type": "integer"},
            "nullableInteger": {"type": ["integer", "null"]}
        },
        "$ref": "#/definitions/integer",
    }
    assert Reference("#/definitions/integer") == ref_from_json_schema(ref_object)



# Generated at 2022-06-22 05:58:42.562404
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # TODO: add test
    pass



# Generated at 2022-06-22 05:58:45.426478
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/some-ref"
    }
    definitions = SchemaDefinitions()
    definitions["some-ref"] = String()
    assert isinstance(ref_from_json_schema(data, definitions), Reference)
# End unit test



# Generated at 2022-06-22 05:58:54.979277
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field1 = Object(properties={'a':Integer()})
    field2 = AllOf(
        all_of=[
            String(max_length=10),
            String(min_length=1),
            String(pattern="^[0-9]+$")
        ]
    )
    JSON = '{"allOf":[{"type":"object","properties":{"a":{"type":"integer"}}},{"type":"string","maxLength":10,"minLength":1,"pattern":"^[0-9]+$"}]}'
    schema = from_json_schema(JSON)
    assert schema.validate("123") == True
    assert schema.validate("abc") == False
    assert field1.validate("abc") == False
    assert field2.validate("123") == True
    assert schema.validate("abc", raise_exception=True) == None

# Generated at 2022-06-22 05:59:38.571047
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem import Schema

    examples = [
        Schema(
            {
                "type": "number",
                "minimum": 0,
                "maximum": 100,
                "exclusiveMinimum": True,
                "exclusiveMaximum": True,
                "multipleOf": 1,
            }
        ),
        Schema(
            {
                "type": "integer",
                "minimum": 0,
                "maximum": 100,
                "exclusiveMinimum": True,
                "exclusiveMaximum": True,
                "multipleOf": 1,
            }
        ),
    ]
    for example in examples:
        typed_field = from_json_schema(example.to_json_schema())
        typed_data = typed_field.validate(example.default)
        assert typed_data == example.default


# Generated at 2022-06-22 05:59:49.684818
# Unit test for function to_json_schema
def test_to_json_schema():
    Int = Integer(minimum=1, maximum=100, allow_null=False)
    assert to_json_schema(Int) == {
        "type": "integer",
        "minimum": 1,
        "maximum": 100,
    }

    String = String(min_length=1, max_length=16, allow_null=False)
    assert to_json_schema(String) == {
        "type": "string",
        "minLength": 1,
        "maxLength": 16,
    }

    Color = Choice(choices=[("Red", "Red"), ("Green", "Green"), ("Blue", "Blue")])
    assert to_json_schema(Color) == {
        "enum": ["Red", "Green", "Blue"],
    }

    Boolean = Boolean(allow_null=False)
    assert to_

# Generated at 2022-06-22 05:59:53.175014
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class TestField(Field):
        def has_default(self):
            return True

    field = TestField(default="hello")

    assert get_standard_properties(field) == {
        "default": "hello"
    }



# Generated at 2022-06-22 05:59:57.178999
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "default": "test",
        "if": {"const": 0},
        "then": {"type": "integer"},
        "else": {"type": "string"},
    }
    field = from_json_schema(data)
    assert field.default == "test"
    assert isinstance(field, IfThenElse)
    assert isinstance(field.if_clause, Const)
    assert isinstance(field.then_clause, Integer)
    assert isinstance(field.else_clause, String)



# Generated at 2022-06-22 06:00:00.070554
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "null"}) == Any()


# Generated at 2022-06-22 06:00:12.970837
# Unit test for function to_json_schema
def test_to_json_schema():
    class MySchema(Schema):
        d: str
        f: typing.List[float]
        j: typing.List[int]
        t: typing.Optional[typing.Union[int, str]]
        u: typing.Dict[str, int]


# Generated at 2022-06-22 06:00:22.562749
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    number_schema = {"type": "number"}
    schema = from_json_schema(number_schema)
    assert isinstance(schema, Float), "schema=%s" % schema
    assert schema.check_type(1.1) is True, "schema=%s" % schema
    assert schema.check_type(None) is False, "schema=%s" % schema

    integer_schema = {"type": "integer", "maximum": 10}
    schema = from_json_schema(integer_schema)
    assert isinstance(schema, Integer), "schema=%s" % schema
    assert schema.check_type(2) is True, "schema=%s" % schema


# Generated at 2022-06-22 06:00:30.906670
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [{'type': 'boolean'}, {'type': 'integer'}, {'type': 'string'}],
        "default": False
    }
    definitions = SchemaDefinitions()
    expected_type = OneOf(one_of=[Boolean(), Integer(), String()], default=False)
    print([type(x) for x in data["oneOf"]])
    print([type(x) for x in expected_type.one_of])
    assert one_of_from_json_schema(data, definitions) == expected_type



# Generated at 2022-06-22 06:00:33.541988
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Field(default=5)
    data = get_standard_properties(field)
    assert data == {"default": 5}



# Generated at 2022-06-22 06:00:40.915032
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string", "pattern": "^a+$"}, {"type": "string", "pattern": "^b+$"}]}
    definitions = SchemaDefinitions()
    kwargs = {"any_of": [String(pattern='^a+$', allow_blank=False), String(pattern='^b+$', allow_blank=False)]}
    field = Union(**kwargs)
    assert any_of_from_json_schema(data, definitions) == field



# Generated at 2022-06-22 06:01:31.987609
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-06/schema#",
        "type": "object",
        "properties": {
            "enum_test": {
                "enum": [1, 2, 3, 4],
                "default": 5
            }
        }
    }
    expected = {
        "enum_test": Field(
            choices=[(1, 1), (2, 2), (3, 3), (4, 4)],
            type="enum",
            required=False,
            default=5,
            description=None
        )
    }
    import copy
    actual = copy.deepcopy(schema)

# Generated at 2022-06-22 06:01:43.069598
# Unit test for function from_json_schema
def test_from_json_schema():
    import json
    import os
    import typesystem
    import unittest

    file_path = os.path.join(os.path.dirname(__file__), "schema_json_tests.json")
    with open(file_path) as file:
        raw_tests = json.load(file)

        for test in raw_tests:
            with self.subTest(test=test):

                try:
                    typesystem.from_json_schema(test["json-schema"])
                except Exception as error:
                    self.assertEqual(error.__class__.__name__, test["error"])
                    continue

                self.assertEqual(test["error"], "None")



# Generated at 2022-06-22 06:01:44.521404
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) == Float()



# Generated at 2022-06-22 06:01:49.662825
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    json_schema = {
        "const": "test_const"
    }
    expected = Const(const = "test_const")
    assert const_from_json_schema(json_schema, definitions=definitions) == expected



# Generated at 2022-06-22 06:01:52.752423
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    print(const_from_json_schema({"const": 5}, definitions=None))
    print(const_from_json_schema({"const": "hello"}, definitions=None))



# Generated at 2022-06-22 06:01:55.941661
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}}) == Not(negated=String())



# Generated at 2022-06-22 06:02:04.953090
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "object", "properties": {"brand": {"type": "string"}}},
            {"type": "object", "properties": {"category": {"type": "string"}}},
        ],
    }
    field = any_of_from_json_schema(data, definitions=definitions)
    assert field.schema({"brand": "a"}) is True
    assert field.schema({"category": "a"}) is True
    assert field.schema({"brand": "a", "category": "a"}) is True
    assert field.schema({"a": "b"}) is False
    assert field.schema({}) is False



# Generated at 2022-06-22 06:02:09.817715
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definition = {"$ref": "#/definitions/SomeType"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/SomeType"] = String()
    field = ref_from_json_schema(definition, definitions)
    assert isinstance(field, Reference)
    assert field.definitions == definitions
    assert field.to == "#/definitions/SomeType"



# Generated at 2022-06-22 06:02:15.834595
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema={"default": None, "anyOf": [{"type": "string", "minLength": 1}, {"type": "string", "maxLength": 10}]}
    field=any_of_from_json_schema(schema,definitions)
    assert type(field)==Union


# Generated at 2022-06-22 06:02:27.720899
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    with pytest.raises(AssertionError):
        if_then_else_from_json_schema(
            {
                "if": {
                    "properties": {
                        "id": {"type": "integer"},
                        "name": {"type": "string"},
                    }
                },
                "then": {"type": "integer"},
            },
            definitions=None,
        )

    field = if_then_else_from_json_schema(
        {
            "if": {"type": "integer"},
            "then": {"type": "string"},
            "else": {"type": "string"},
        },
        definitions=None,
    )
    assert field.is_valid(5)
    assert field.is_valid("foobar")
    assert not field.is_valid(5.5)

# Generated at 2022-06-22 06:02:59.717431
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    >>> data = {
    ...     "$ref": "https://example.com/typesystem.json#/definitions/JSONSchema",
    ...     "type": "string",
    ...     "enum": ["a", "b", "c"],
    ...     "const": "c",
    ... }
    >>> from_json_schema(data)
    (String & (Enum(values=['a', 'b', 'c'])) & Const(value='c'))

    >>> data = {
    ...     "type": "string",
    ...     "enum": ["a", "b", "c"],
    ... }
    >>> from_json_schema(data)
    String & (Enum(values=['a', 'b', 'c']))
    """



# Generated at 2022-06-22 06:03:03.491189
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({'enum': [1, 2, 3, 4]}) == Choice(
        choices=[(1, 1), (2, 2), (3, 3), (4, 4)]
    )



# Generated at 2022-06-22 06:03:11.255770
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_valid_argument = {
        "$ref": "#/definitions/number_ref",
        "not": {
            "allOf": [
                {"type": "number"},
                {"minimum": 0},
                {"multipleOf": 7},
            ]
        },
        "definitions": {
            "number_ref": {
                "type": "number"
            }
        }
    }
    actual = not_from_json_schema(not_valid_argument, definitions=SchemaDefinitions())
    expected = Not(
        negated=AllOf(
            all_of=[
                Reference(
                    to="#/definitions/number_ref", definitions=SchemaDefinitions()
                ),
                Integer(minimum=0),
                Integer(multiple_of=7),
            ],
        ),
    )
    assert actual

# Generated at 2022-06-22 06:03:17.635006
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover

    type_strings = [
        "number",
        "integer",
        "string",
        "boolean",
        "array",
        "object"
    ]

    for type_string in type_strings:
        data = {'type': type_string}
        s = from_json_schema_type(data, type_string, False, SchemaDefinitions())



# Generated at 2022-06-22 06:03:27.539655
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    sjson = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "definitions": {
            "json_schema_enum": {
                "type": "string",
                "enum": [
                    "a",
                    "b",
                    "c"
                ]
            }
        },
        "properties": {
            "field2": {
                "$ref": "#/definitions/json_schema_enum"
            }
        },
        "required": [
            "field2"
        ]
    }
    assert enum_from_json_schema(sjson, definitions)



# Generated at 2022-06-22 06:03:35.481839
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Check enum is translated as choices
    data = {"enum":["a"]}
    assert enum_from_json_schema(data, None).choices == [("a", "a")]
    data = {"enum":["a","b"]}
    assert enum_from_json_schema(data, None).choices == [("a","a"),("b","b")]
    # Check that default is set
    data = {"enum":["a","b"],"default":"a"}
    assert enum_from_json_schema(data, None).default == "a"


# Generated at 2022-06-22 06:03:41.550661
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data={"if":{"type":"boolean"}, "then":{"type":"string"}, "else":{"type":"boolean"}}
    definitions = SchemaDefinitions()
    for key, value in data.get("definitions", {}).items():
        ref = f"#/definitions/{key}"
        definitions[ref] = from_json_schema(value, definitions=definitions)

# Generated at 2022-06-22 06:03:46.515825
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    f = type_from_json_schema(
        {
            "type": "object",
            "oneOf": [{"type": "object", "properties": {"d": {"type": "number"}}},],
        },
        definitions=SchemaDefinitions(),
    )
    assert isinstance(f, OneOf)



# Generated at 2022-06-22 06:03:51.500781
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    x = Any()
    y = Any()
    assert one_of_from_json_schema({'oneOf': [x.schema, y.schema]}) == x | y
    assert one_of_from_json_schema({'oneOf': [x.schema, y.schema], 'default': None}) == x | y | Const(None)
test_one_of_from_json_schema()



# Generated at 2022-06-22 06:04:01.561145
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "number",
        "minimum": 0,
        "maximum": 100,
        "exclusiveMinimum": True,
        "exclusiveMaximum": False,
        "multipleOf": 2,
    }
    assert from_json_schema_type(data, type_string="number", allow_null=True, definitions={}) == Float(
        allow_null=True,
        minimum=0,
        maximum=100,
        exclusive_minimum=True,
        exclusive_maximum=False,
        multiple_of=2,
    )

# Generated at 2022-06-22 06:04:59.580280
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schemas = {
        "any": {},
        "object": {"type": "object"},
        "null": {"type": "null"},
        "string": {"type": "string"},
        "integer": {"type": "integer"},
        "number": {"type": "number"},
        "boolean": {"type": "boolean"},
        "array": {"type": "array"},
    }
    assert any(map(lambda m: m in str(from_json_schema(schemas["any"])), ["Any()"]))
    assert any(map(lambda m: m in str(from_json_schema(schemas["null"])), ["Const(None)"]))
    assert any(map(lambda m: m in str(from_json_schema(schemas["object"])), ["Object()"]))
    assert any

# Generated at 2022-06-22 06:05:06.685690
# Unit test for function to_json_schema
def test_to_json_schema():
    class StringTest(Schema):
        minLength = Integer(min_value=1)
        maxLength = Integer(min_value=1)
        pattern = String(pattern_regex=re.compile("^[a-z]+$", re.IGNORECASE))
        format_ = String(
            format='date-time', constraints=[
                lambda x: datetime.fromisoformat(x) is not None
            ]
        )

    class NumericTest(Schema):
        minimum = None
        maximum = None
        exclusiveMinimum = None
        exclusiveMaximum = None
        multipleOf = None

    class ObjectTest(Schema):
        required = Array(String)
        maxProperties = Integer(min_value=1)
        minProperties = Integer(min_value=1)

# Generated at 2022-06-22 06:05:19.690781
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-22 06:05:26.231364
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    sample_data = {
        "$ref": "#/definitions/SampleType",
        "definitions": {
            "SampleType": {"type": "integer"}
        }
    }

    expected = Reference(to="#/definitions/SampleType")
    actual = ref_from_json_schema(sample_data, definitions)
    assert type(actual) == Reference
    assert definitions["#/definitions/SampleType"] == expected



# Generated at 2022-06-22 06:05:37.046925
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "object",
        "required": ["url", "items"],
        "additionalProperties": False,
        "properties": {
            "url": {"type": "string", "format": "uri"},
            "items": {
                "type": "array",
                "items": {
                    "oneOf": [
                        {"type": "string", "maxLength": 255},
                        {"type": "null"},
                    ],
                },
                "default": [],
            },
        },
    }
    definitions = SchemaDefinitions()
    field = from_json_schema_type(data, type_string='object', allow_null=False,
                                  definitions=definitions)
    assert field.required == {'url', 'items'}
    assert field.additional_properties is False
   

# Generated at 2022-06-22 06:05:41.234850
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class ExampleSchema(Schema):
        field = String()
    field = ExampleSchema.make_validator()['field']
    data = {
        'default': False,
    }
    assert get_standard_properties(field) == data


# Generated at 2022-06-22 06:05:52.275944
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    obj = {
        "anyOf": [
            {
                "type": "string",
                "maxLength": 255,
            },
            {
              "type": "integer",
              "minimum": 0,
              "maximum": 10,
            },
        ],
    }
    typesystem_field = any_of_from_json_schema(obj, definitions=None)
    assert typesystem_field.__class__.__name__ == "Union"
    assert len(typesystem_field.any_of) == 2
    assert typesystem_field.any_of[0].__class__.__name__ == "String"
    assert typesystem_field.any_of[1].__class__.__name__ == "Integer"
    assert typesystem_field.any_of[0].max_length == 255
    assert types

# Generated at 2022-06-22 06:06:01.439976
# Unit test for function to_json_schema
def test_to_json_schema():
    validate_json_schema_spec(
        to_json_schema(
            String(example="Example", format="email", min_length=1, max_length=10)
        )
    )

    validate_json_schema_spec(
        to_json_schema(Boolean(example=False, default=True)),
    )


    validate_json_schema_spec(
        to_json_schema(
            Float(
                example=1.5,
                minimum=2.5,
                maximum=3.5,
                exclusive_minimum=True,
                exclusive_maximum=True,
            ),
        ),
    )



# Generated at 2022-06-22 06:06:02.785249
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    return 

# Generated at 2022-06-22 06:06:08.892541
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}, {"type": "number"}]}
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of}
    return OneOf(**kwargs)
test_one_of_from_json_schema()


# Generated at 2022-06-22 06:06:51.431163
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "number"}) == ({}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["integer", "number"]}) == ({"integer", "number"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)
    assert get_valid_types({"type": "null"}) == (set(), True)



# Generated at 2022-06-22 06:06:55.728214
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(
         any_of_from_json_schema({'anyOf': [{'type': ['integer', 'null']},{'type': 'string'}]},_),Union
    )
