

# Generated at 2022-06-22 05:57:52.198871
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/root.json",
        "type": "object",
        "properties": {
            "not": {
                "$ref": "#",
                "default": 5
            }
        },
        "default": 4
    }
    approach_from_json_schema(data)



# Generated at 2022-06-22 05:58:01.890068
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Error if not field
    with pytest.raises(ValueError, match=r"^Cannot get default for field type "):
        get_standard_properties(List())
    # Error if field is None
    with pytest.raises(ValueError, match=r"^Cannot get default for field type "):
        get_standard_properties(None)
    # No default if no default exists
    field = Choice(choices=["a", "b"], default="b")
    assert get_standard_properties(field) == {}
    # No default if no default exists, but allow null
    field = Choice(choices=["a", "b"], default="b", allow_null=True)
    assert get_standard_properties(field) == {}
    # No default is default is NO_DEFAULT

# Generated at 2022-06-22 05:58:10.745736
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "string"},
        "else": {"type": "integer"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.schema(format="openapi") == {
        "if": {"type": "object", "properties": {"type": {"type": "string"}}},
        "then": {"type": "object", "properties": {"type": {"type": "string"}}},
        "else": {"type": "object", "properties": {"type": {"type": "string"}}},
    }



# Generated at 2022-06-22 05:58:15.948155
# Unit test for function get_standard_properties
def test_get_standard_properties():
    for field in (
        String(default="string"),
        Integer(default=123),
        String(default="null"),
        String(default=["null", "string"]),
        String(default=["string", "null"]),
    ):
        assert get_standard_properties(field) == {"default": field.default}

# Generated at 2022-06-22 05:58:17.977996
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(
        String(allow_null=True, default="Hi")
    )
    assert data == {"default": "Hi"}



# Generated at 2022-06-22 05:58:24.347852
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'type': 'integer'}]}
    definitions = {}

# Generated at 2022-06-22 05:58:33.542719
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def assert_ref_from_json_schema_raises(data, definitions=None):
        with pytest.raises(
            AssertionError, match="Unsupported \$ref style in document."
        ):
            ref_from_json_schema(data, definitions)

    data = {"$ref": "/definitions/foo"}
    assert_ref_from_json_schema_raises(data)

    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    data = {"$ref": "#/definitions/foo"}
    field = ref_from_json_schema(data, definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/foo"
    assert field.definitions == definitions

    definitions = SchemaDefinitions()
    definitions

# Generated at 2022-06-22 05:58:44.801733
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [{"type": "integer"}, {"minimum": 0}],
        "default": 5,
    }
    r = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(r, Field)
    assert r.render_schema()
    
    data = {
        "allOf": [{"type": "integer"}, {"minimum": 0}],
    }
    r = all_of_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(r, Field)
    assert r.render_schema()
    
    data = {
        "allOf": [{"type": "integer"}, {"minimum": 0, "default": 5}],
    }

# Generated at 2022-06-22 05:58:57.176717
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # noqa: D103
    json_schema = {"type": "number"}
    field = from_json_schema(json_schema)
    assert type(field) is Float
    assert field.allow_null is False

    json_schema = {"type": "integer"}
    field = from_json_schema(json_schema)
    assert type(field) is Integer
    assert field.allow_null is False

    json_schema = {"type": "string"}
    field = from_json_schema(json_schema)
    assert type(field) is String
    assert field.allow_null is False

    json_schema = {"type": "boolean"}
    field = from_json_schema(json_schema)
    assert type(field) is Boolean
    assert field.allow_null is False

# Generated at 2022-06-22 05:59:02.416419
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": ["null", "boolean", "object", "array", "number", "string"]
    }
    assert type(
        from_json_schema_type(
            data, type_string="number", allow_null=False, definitions=None
        )
    ) == Field
    assert type(
        from_json_schema_type(
            data, type_string="integer", allow_null=False, definitions=None
        )
    ) == Field
    assert type(
        from_json_schema_type(
            data, type_string="string", allow_null=False, definitions=None
        )
    ) == Field

# Generated at 2022-06-22 05:59:38.423079
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    all_of_test = {"allOf": [{"type": "string"}, {"maxLength": 15}], "default": "string"}
    assert all_of_from_json_schema(all_of_test, definitions=None) == AllOf([String(), String(max_length=15)], default="string")



# Generated at 2022-06-22 05:59:48.952540
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    data = {"$ref": "#/definitions/Test"}
    field, ref_field = (
        from_json_schema(data, definitions=definitions),
        Reference(to="#/definitions/Test", definitions=definitions),
    )
    assert field == ref_field
    assert id(field) != id(ref_field)
    assert isinstance(field, Reference)
    assert isinstance(field.to, str)
    assert isinstance(field.from_, Field)
    assert field.from_ is ref_field.from_
    assert id(field.from_) != id(ref_field.from_)

# Generated at 2022-06-22 05:59:52.604250
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "default": 1,
        "if": {"type": "integer"},
        "then": {"enum": [1, 2, 3]},
        "else": {"enum": [4, 5, 6]},
    }
    schema = if_then_else_from_json_schema(data, definitions=None)
    validator = Validator([schema])
    assert validator.validate(3) == True
    assert validator.validate(1) == True
    assert validator.validate(str()) == False
    assert validator.validate(None) == False



# Generated at 2022-06-22 05:59:58.712967
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    s = {'oneOf': [
        {'type': 'number'},
        {'type': 'string'}
    ]}

    f = one_of_from_json_schema(s, None)

    assert f.validate(4) == 4
    assert f.validate('str') == 'str'
    assert isinstance(f.type_signature.return_type, Union)



# Generated at 2022-06-22 06:00:05.922659
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema_definitions = {
        "integer": Integer(minimum=1,maximum=10),
        "boolean": Boolean(),
    }
    data = {
        "default": 5,
        "allOf": [
            {"$ref": "#/definitions/integer"},
            {"$ref": "#/definitions/boolean"}
        ]
    }
    field = from_json_schema(data, definitions=schema_definitions)
    assert type(field) == AllOf
    assert field.all_of[0] == schema_definitions["integer"]
    assert field.all_of[1] == schema_definitions["boolean"]
    assert field.default == 5



# Generated at 2022-06-22 06:00:17.419223
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types(dict(type="null")) == (set(), True)
    assert get_valid_types(dict(type="boolean")) == ({"boolean"}, False)
    assert get_valid_types(dict(type="object")) == ({"object"}, False)
    assert get_valid_types(dict(type="array")) == ({"array"}, False)
    assert get_valid_types(dict(type="number")) == ({"number"}, False)
    assert get_valid_types(dict(type="string")) == ({"string"}, False)
    assert get_valid_types(dict(type="integer")) == ({"integer"}, False)
    assert get_valid_types(dict(type=None)) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )

# Generated at 2022-06-22 06:00:27.744655
# Unit test for function from_json_schema
def test_from_json_schema():
    assert (
        str(
            from_json_schema(
                {
                    "type": "string",
                    "minLength": 10,
                    "maxLength": 100,
                    "pattern": "[0-9]{4}",
                }
            )
        )
        == "String(min_length=10, max_length=100, format='regex', pattern='[0-9]{4}')"
    )
    assert (
        str(
            from_json_schema(
                {
                    "type": "number",
                    "minimum": 5,
                    "maximum": 10,
                }
            )
        )
        == "Number(minimum=5, maximum=10)"
    )

# Generated at 2022-06-22 06:00:33.923001
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref" : "#/definitions/test"}
    definition = {"test": {"type": "string"}}
    definitions = SchemaDefinitions()
    definitions["#/definitions/test"] = from_json_schema(definition["test"], definitions=definitions)
    assert ref_from_json_schema(data, definitions=definitions).to_primitive() == {"$ref": reference_string}



# Generated at 2022-06-22 06:00:44.680618
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-22 06:00:56.523181
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # Test the case where only one schema is in the list
    schema1 = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "integer",
    }
    schema2 = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "integer",
    }
    data = {"anyOf": [schema1, schema2]}
    assert isinstance(any_of_from_json_schema(data), Union)



# Generated at 2022-06-22 06:01:16.697649
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        'if': {'type': 'integer'},
        'then': {'type': 'string'},
        'else': {'type': 'number'}
    }
    assert isinstance(if_then_else_from_json_schema(data, definitions=None), IfThenElse)

to_json_schema = JSV.to_json_schema
to_python_type = JSV.to_python_type



# Generated at 2022-06-22 06:01:17.707482
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert 1 == 1


# Generated at 2022-06-22 06:01:25.920628
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "integer", "minimum": 10, "maximum": 20},
            {"type": "integer", "minimum": 30, "maximum": 40},
        ]
    }
    any_of = any_of_from_json_schema(schema, definitions=None)
    assert any_of.validate(10) == 10
    assert any_of.validate(20) == 20
    assert any_of.validate(30) == 30
    assert any_of.validate(40) == 40
    assert any_of.validate(5) is None
    assert any_of.validate(60) is None



# Generated at 2022-06-22 06:01:34.263587
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = Const(1)
    then_clause = Const(2)
    else_clause = Const(3)
    if_then_else = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert if_then_else == if_then_else_from_json_schema(if_then_else, SchemaDefinitions())



# Generated at 2022-06-22 06:01:41.201474
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "const": True,
        "default": False,
    }
    const = data["const"]
    kwargs = {"const": const, "default": data.get("default", NO_DEFAULT)}
    assert Const(**kwargs) == Const(const=True, default=False)


# Generated at 2022-06-22 06:01:50.625461
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    assert type_from_json_schema(data) == String()
    data = {"type": ["string", "number"]}
    assert type_from_json_schema(data) == Choice([String(), Integer()])
    data = {"type": "string", "minLength": 1}
    assert type_from_json_schema(data) == String(min_length=1)
    data = {"type": "string", "minLength": 1, "maxLength": 2}
    assert type_from_json_schema(data) == String(min_length=1, max_length=2)
    data = {"type": "string", "pattern": "\\d+"}
    assert type_from_json_schema(data) == String(pattern=re.compile("\\d+"))



# Generated at 2022-06-22 06:02:01.292510
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert \
        type_from_json_schema(
            {
                "type": "string"
            },
            definitions=SchemaDefinitions()
        ) == String()

    assert \
        type_from_json_schema(
            {
                "type": ["null", "string"]
            },
            definitions=SchemaDefinitions()
        ) == Union([String(), Boolean(allow_null=True)]).as_typed_dict()

    assert \
        type_from_json_schema(
            {
                "type": "null"
            },
            definitions=SchemaDefinitions()
        ) == Const(None)


# Generated at 2022-06-22 06:02:02.125845
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    pass



# Generated at 2022-06-22 06:02:08.864040
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Case true
    data = {"const": 123}
    const1 = const_from_json_schema(data, SchemaDefinitions())
    assert const1.validate(123) == 123
    # Case false
    data = {"const": 123}
    const1 = const_from_json_schema(data, SchemaDefinitions())
    assert const1.validate(12) == 12
    # Case no default
    data = {"const": 123}
    const2 = const_from_json_schema(data, SchemaDefinitions())
    assert const2.validate(None) == None
    # Case with default
    data = {"const": 123}
    const3 = const_from_json_schema(data, SchemaDefinitions())
    assert const3.validate(None) == 123


# Generated at 2022-06-22 06:02:19.487552
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "object"}, None).__class__ == Object
    assert type_from_json_schema({"type": "array"}, None).__class__ == Array
    assert type_from_json_schema({"type": "string"}, None).__class__ == String
    assert type_from_json_schema({"type": "integer"}, None).__class__ == Integer
    assert type_from_json_schema({"type": "number"}, None).__class__ == Decimal
    assert type_from_json_schema({"type": "boolean"}, None).__class__ == Boolean
    assert type_from_json_schema({"type": "null"}, None).__class__ == Const
    assert type_from_json_schema({"type": "any"}, None).__class__

# Generated at 2022-06-22 06:03:00.935742
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    field = all_of_from_json_schema({
        "allOf": [
            {"$ref": "#/definitions/number"}, 
            {"$ref": "#/definitions/integer"}
        ],
        "default": 1
    })
    assert field.default == 1
    assert field.errors(1) == []
    assert field.errors(1.1) != []
    assert field.errors(Decimal(1)) != []
    return


# Generated at 2022-06-22 06:03:07.232392
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 123}) == Const(const=123)
    assert const_from_json_schema({'const': [1,2]}) == Const(const=[1,2])
    assert const_from_json_schema({'const': [1,2], 'default': [2,3]}) == Const(const=[1,2], default=[2,3])
    
    
    

# Generated at 2022-06-22 06:03:18.748387
# Unit test for function enum_from_json_schema

# Generated at 2022-06-22 06:03:27.802584
# Unit test for function to_json_schema
def test_to_json_schema():  # type: ignore
    import pathlib

    def check_file(filename):
        assert str(filename).endswith(".json")
        data = json.loads(filename.read_text(encoding="utf-8"))
        schema = Field.from_json_schema(data)
        to_json_schema(schema)

    path = pathlib.Path(__file__).parent / "test_schema"
    for filename in path.glob("**/*.json"):
        check_file(filename)


# Generated at 2022-06-22 06:03:33.737766
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "enum": [1, 2, 3],
        "default": 3,
    }
    field = enum_from_json_schema(schema, SchemaDefinitions())
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(3) == 3
    assert field.validate(4) == 3



# Generated at 2022-06-22 06:03:44.799433
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema([{'anyOf': [{'type': 'number'}, {'type': 'number'}]}],[]).validate(1.0)
    assert any_of_from_json_schema([{'anyOf': [{'type': 'number'}, {'type': 'number'}]}],[]).validate(2.0)
    assert not any_of_from_json_schema([{'anyOf': [{'type': 'number'}, {'type': 'number'}]}],[]).validate('a')
    assert not any_of_from_json_schema([{'anyOf': [{'type': 'number'}, {'type': 'number'}]}],[]).validate({})

# Generated at 2022-06-22 06:03:56.411293
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "number", "nullable": True}) == ({"number"}, True)
    assert get_valid_types({"type": "string", "nullable": True}) == ({"string"}, True)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["number", "string"]}) == ({"number", "string"}, False)
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)

# Generated at 2022-06-22 06:04:10.014582
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
          "type": "object",
          "definitions": {},
          "properties": {
            "type": {
              "enum": [
                "number",
                "integer"
              ]
            }
          },
          "oneOf": [
            {
              "allOf": [
                {
                  "$ref": "#/definitions/positiveIntegerDefault0"
                },
                {
                  "minimum": 1
                }
              ]
            },
            {
              "allOf": [
                {
                  "$ref": "#/definitions/positiveIntegerDefault0"
                },
                {
                  "minimum": 0
                }
              ]
            }
          ]
        }
    definitions = SchemaDefinitions()
    def_fields: typing.Dict[str, Field] = data["definitions"]


# Generated at 2022-06-22 06:04:16.498119
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "number"},
            {"type": "integer"},
            {"type": "string"},
            {"type": "boolean"},
            {"type": "array"},
            {"type": "object"},
        ]
    }
    assert isinstance(any_of_from_json_schema(data, definitions=SchemaDefinitions()), Union)


# Generated at 2022-06-22 06:04:23.899534
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    """
    Test for function all_of_from_json_schema
    """
    assert(all_of_from_json_schema({'allOf': [{'minimum': 1}, {'maximum': 10}]}, None) == AllOf(all_of=[Integer(minimum=1), Integer(maximum=10)], default=NO_DEFAULT))



# Generated at 2022-06-22 06:05:30.203967
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    print(enum_from_json_schema({"enum": [1, 2, 3]}, None))
    print(enum_from_json_schema({"enum": ["a", "b", "c"]}, None))
    print(enum_from_json_schema({"enum": [True, False]}, None))
    print(enum_from_json_schema({"enum": [1, "b", True]}, None))
    print(enum_from_json_schema({"enum": [1, 2, 3], "default": 2}, None))
    print(enum_from_json_schema({"enum": [1, 2, 3], "default": None}, None))



# Generated at 2022-06-22 06:05:33.490070
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schema = const_from_json_schema({"const": 42})
    assert schema.validate(42) == 42



# Generated at 2022-06-22 06:05:41.235072
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {'const': 0}
    definitions = SchemaDefinitions()
    field = const_from_json_schema(data, definitions)
    assert field.validate(0)
    assert not field.validate(1)
    assert not field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(1)
    with pytest.raises(ValidationError):
        field.validate(None)



# Generated at 2022-06-22 06:05:45.991206
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/foobar",
        "definitions": {
            "foobar": {"type": "number", "minimum": 0, "maximum": 5}
        }
    }
    result = from_json_schema(schema)
    assert isinstance(result, Reference)
    assert result.to == "#/definitions/foobar"
    assert result.definitions["foobar"] == Integer(minimum=0, maximum=5)



# Generated at 2022-06-22 06:05:49.345944
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/a"}
    field = ref_from_json_schema(data, definitions={"#/a": Integer()})
    assert isinstance(field, Reference)
    assert field.to == "#/a"



# Generated at 2022-06-22 06:05:53.265188
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(String(default=None))
    assert data == {}

    data = get_standard_properties(String(default='hi'))
    assert data == {'default': 'hi'}

# Generated at 2022-06-22 06:05:59.807544
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Foo"}
    assert ref_from_json_schema(data) == Reference(to="#/definitions/Foo")



# Generated at 2022-06-22 06:06:04.852803
# Unit test for function to_json_schema
def test_to_json_schema():
    def assert_field_equal(field: Field, json_schema: dict):
        assert to_json_schema(field) == json_schema, "JSON schema not equal"

    schema = Schema(name="first_field", validator=Integer())
    assert_field_equal(schema.first_field, json.loads("""
        {
            "type": "integer",
            "default": "NO_DEFAULT"
        }
    """))

    schema = Schema(
        name="first_field",
        validator=String(
            description="Some description text.",
            min_length=5,
            max_length=10,
            allow_blank=False,
        ),
    )

# Generated at 2022-06-22 06:06:14.495387
# Unit test for function type_from_json_schema
def test_type_from_json_schema():

    data = {"type": "string"}
    field = type_from_json_schema(data, definitions=None)
    assert field.validate("string") is None
    assert field.validate(None) is None

    data = {"type": "integer"}
    field = type_from_json_schema(data, definitions=None)
    assert field.validate(1) is None
    assert field.validate(None) is None

    data = {"type": "object"}
    field = type_from_json_schema(data, definitions=None)
    assert field.validate({"string": "string"}) is None
    assert field.validate(None) is None



# Generated at 2022-06-22 06:06:19.512329
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    with pytest.raises(
            AssertionError,
            match=re.escape("Unsupported $ref style in document.")
    ):
        if_then_else_from_json_schema(
            {"if": {}, "then": {}, "else": {"$ref": "https://example.com"}},
            SchemaDefinitions(),
        )



# Generated at 2022-06-22 06:07:00.768036
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    """Unit test for function any_of_from_json_schema
    
    A function to test the function any_of_from_json_schema defined in module converters.
    """
    #Create input data
    data = {"anyOf": [{"type": "boolean"}, {"type": "boolean"}], "default": True}
    #Create definitions
    definitions = SchemaDefinitions()
    #Apply the function
    any_of = any_of_from_json_schema(data, definitions)
    assert isinstance(any_of, Union)

