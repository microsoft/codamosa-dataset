

# Generated at 2022-06-22 05:57:37.619402
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "string"}}, definitions).match("hello") == False



# Generated at 2022-06-22 05:57:43.078543
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema = {
        "anyOf": [
            {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string"
                    }
                }
            },
            {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string"
                    },
                    "age": {
                        "type": "integer"
                    }
                }
            }
        ]
    }
    assert isinstance(any_of_from_json_schema(json_schema, definitions=definitions), Union)


# Generated at 2022-06-22 05:57:44.193808
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    typ = not_from_json_schema({"not": {"type": "null"}})
    assert isinstance(typ, Not)



# Generated at 2022-06-22 05:57:52.930973
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test the function 'from_json_schema_type()'.
    """
    from typesystem import from_json_schema

    assert from_json_schema_type({}, type_string="integer", allow_null=False) == Integer()
    assert from_json_schema_type({}, type_string="integer", allow_null=True) == Integer(
        allow_null=True
    )

    assert from_json_schema_type({}, type_string="null", allow_null=False) == Const(None)
    assert from_json_schema_type({}, type_string="null", allow_null=True) == Const(None)

    assert from_json_schema_type({}, type_string="number", allow_null=False) == Float()

# Generated at 2022-06-22 05:57:59.387065
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_then_else_data = {
        "if": {"type": "string", "const": "X"},
        "then": {"type": "string", "const": "Y"},
        "else": {"type": "string", "const": "Z"},
    }
    if_clause = from_json_schema(if_then_else_data["if"])
    then_clause = from_json_schema(if_then_else_data["then"])
    else_clause = from_json_schema(if_then_else_data["else"])
    assert if_then_else_from_json_schema(if_then_else_data, None) == IfThenElse(
        if_clause, then_clause, else_clause, NO_DEFAULT
    )

    if_cl

# Generated at 2022-06-22 05:58:05.384024
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    field = enum_from_json_schema({"enum": [1, 2, 3]}, {})
    assert field.is_valid(1)
    assert not field.is_valid(100)
    assert field.bind(1).value == 1



# Generated at 2022-06-22 05:58:17.494373
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # pylint: disable=C0111
    from typesystem.fields import (
        CharField,
        DateField,
        DateTimeField,
        DecimalField,
        FloatField,
        IntegerField,
        NumberField,
        StringField,
    )


# Generated at 2022-06-22 05:58:19.594132
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from_json_schema({"$ref": "#/definitions/id"})


# Generated at 2022-06-22 05:58:21.711808
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="")) == {"default": ""}
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}



# Generated at 2022-06-22 05:58:30.644066
# Unit test for function get_valid_types
def test_get_valid_types():
    """
    Tests for function get_valid_types().
    """
    assert ({"integer"}, True) == get_valid_types({"type": "null"})
    assert ({"integer"}, True) == get_valid_types({"type": "null", "nullable": True})
    assert ({"null"}, True) == get_valid_types({"nullable": True})
    assert ({"integer"}, True) == get_valid_types({})
    assert ({"null"}, True) == get_valid_types({"type": ["null"]})
    assert ({"integer"}, True) == get_valid_types({"type": ["integer", "null"]})
    assert ({"integer", "integer"}, True) == get_valid_types({"type": ["integer", "integer"]})
    assert ({"object"}, False) == get_valid_types

# Generated at 2022-06-22 05:59:01.936123
# Unit test for function get_standard_properties
def test_get_standard_properties():
    string_no_default = String()
    assert get_standard_properties(string_no_default) == {}

    string_with_default = String(default="abc")
    assert get_standard_properties(string_with_default) == {"default": "abc"}

# Generated at 2022-06-22 05:59:03.676594
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({"anyOf":[{"type":"number"}]}, SchemaDefinitions()),
                      typesystem.fields.Union)


# Generated at 2022-06-22 05:59:05.745465
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Field(default=True)) == {"default": True}



# Generated at 2022-06-22 05:59:13.886311
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"type": "integer"},
    }
    if_clause = from_json_schema(data['if'], definitions=None)
    then_clause = from_json_schema(data['then'], definitions=None)
    kwargs = {
        "if_clause": if_clause,
        "then_clause": then_clause,
        "else_clause": None,
        "default": NO_DEFAULT
    }
    assert IfThenElse(**kwargs) == if_then_else_from_json_schema(data, definitions=None)
    
    # Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-22 05:59:17.375869
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # A minimal test for function from_json_schema_type
    assert from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=None) == String()



# Generated at 2022-06-22 05:59:22.996997
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
	one_of_schema = {
		"oneOf": [
			{
				"type": "object"
			},
			{
				"type": "array"
			}
		]
	}
	field = one_of_from_json_schema(one_of_schema, definitions=None)
	assert(field.bind({"a": 1, "b": 2}))
	assert(field.bind(["a", "b"]))
	assert(not field.bind(5))



# Generated at 2022-06-22 05:59:24.963902
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "string"}}
    field = not_from_json_schema(data)
    assert isinstance(field, Field)
    assert not field.validate("")
    assert not field.validate(1)


# Generated at 2022-06-22 05:59:31.107832
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_data = {
        "allOf": [
            {"const": 5},
            {"type": "number", "exclusiveMinimum": 4, "exclusiveMaximum": 6}
        ]
    }
    expected_field = AllOf([Const(const=5),
                            Float(minimum=4, exclusive_minimum=True, maximum=6, exclusive_maximum=True)])
    assert from_json_schema(json_data) == expected_field


# Generated at 2022-06-22 05:59:37.192211
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field1 = String(default="field1")
    data1 = get_standard_properties(field1)
    assert data1 == {"default": field1.default}

    field2 = Reference(to="#/definitions/reference1", definitions=None)
    data2 = get_standard_properties(field2)
    assert data2 == {}

# Generated at 2022-06-22 05:59:46.727590
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    """ Checks that you can use allOf with a valid JSON schema """
    all_of_schema = {'type': 'object', 'allOf': [{'type': 'object', 'properties': {'name': {'type': 'string'}}}, {'type': 'object', 'properties': {'name': {'type': 'string'}}}]}

    assert all_of_from_json_schema(all_of_schema, None).validate({'name': 'test'}) == {'name': 'test'}



# Generated at 2022-06-22 06:00:22.402090
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/arrayField"}, definitions) == Reference(to="#/definitions/arrayField", definitions=definitions)
    assert ref_from_json_schema({"$ref": "#/definitions/arrayField"}, definitions) is not Reference(to="#/definitions/objectField", definitions=definitions)


# Generated at 2022-06-22 06:00:23.964727
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({'not': {'type': 'number', 'minimum': 1}}).get_validators() == [
    'return -1 if value < 1 else 1']



# Generated at 2022-06-22 06:00:27.778647
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    testData = {
        "not" : {
            "type": "object",
            "properties": {
                "a": {"type": "string"}
            }
        },
        "default": "a"
    }
    notSchema = not_from_json_schema(testData, definitions=None)
    assert isinstance(notSchema.negated.properties["a"], String), \
        "not_from_json_schema() should return a Not object that contains a String type"
    assert notSchema.default == "a", \
        "not_from_json_schema() should return a Not object that contains the correct default value"

# Generated at 2022-06-22 06:00:32.654808
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer"}) == Integer()



# Generated at 2022-06-22 06:00:40.874286
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    assert any_of_from_json_schema(data, definitions=definitions) == Union(any_of=[String(), Integer()])

    data = {"anyOf": [{"type": "string"}, {"type": "integer", "const": 10}]}
    assert any_of_from_json_schema(data, definitions=definitions) == Union(any_of=[String(), Const(10)])

    data = {"anyOf": [{"type": "string", "format": "email"}, {"type": "integer", "const": 10}]}

# Generated at 2022-06-22 06:00:48.020651
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    Test that the to_json_schema() function produces valid JSON Schema.
    """

    target = Union(Integer(minimum=0), Reference("#/definitions/positive"))
    definitions = SchemaDefinitions(positive=Integer(minimum=0))
    result = to_json_schema(target, _definitions=definitions)
    assert isinstance(result, dict)
    assert "anyOf" in result
    assert "definitions" in result
    assert result["definitions"]["positive"]["type"] == "integer"
    assert result["definitions"]["positive"]["minimum"] == 0



# Generated at 2022-06-22 06:00:54.008584
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Foo"] = Integer()
    assert ref_from_json_schema(data, definitions=definitions).to_primitive() == {
        "type": "integer"
    }



# Generated at 2022-06-22 06:01:02.026179
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-22 06:01:14.540498
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert(
        from_json_schema_type(
            data={"type": "integer", "minimum": 0, "maximum": 2, "multipleOf": 2},
            type_string="integer",
            allow_null=False,
            definitions=definitions
        ) == Integer(allow_null=False, minimum=0, maximum=2, multiple_of=2)
    )

# Generated at 2022-06-22 06:01:19.766925
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    JSON_SCHEMA = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
        ]
    }
    SCHEMA = {
        "type": ["string", "integer"]
    }
    assert any_of_from_json_schema(JSON_SCHEMA, definitions) == Union(**SCHEMA)


# Generated at 2022-06-22 06:01:48.351392
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    # Create a JSON schema with an enum
    data = {"enum": [1, 2, 3]}
    # Create a Choice field from the JSON schema
    field = enum_from_json_schema(data, definitions)
    # Check that the field validates the enum values
    assert field.validate(1) is True
    assert field.validate(2) is True
    assert field.validate(3) is True
    assert field.validate(4) is False
    # Check that the field does not exclude the enum values from validation
    assert field.validate(4, exclude_choices=True) is False
    assert field.validate(None, exclude_choices=True) is True


# Generated at 2022-06-22 06:01:54.694567
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {'type': 'boolean'}
    assert get_valid_types(data) == ({"boolean"}, False)
    data = {'type': 'number'}
    assert get_valid_types(data) == ({"number"}, False)
    data = {'type': 'integer'}
    assert get_valid_types(data) == ({"integer"}, False)
    data = {'type': 'array'}
    assert get_valid_types(data) == ({"array"}, False)
    data = {'type': 'object'}
    assert get_valid_types(data) == ({"object"}, False)
    data = {'type': ['boolean', 'number']}
    assert get_valid_types(data) == ({"boolean", "number"}, False)

# Generated at 2022-06-22 06:02:00.418741
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(default="string")
    assert get_standard_properties(field) == {"default": "string"}
    field = String()
    assert get_standard_properties(field) == {}



# Generated at 2022-06-22 06:02:07.310696
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-22 06:02:14.333415
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from tests.fixtures import BOOKS
    field = from_json_schema(BOOKS, definitions=definitions)
    data = {
        "$ref": "#/definitions/book",
        "definitions": BOOKS["definitions"],
    }
    assert field == ref_from_json_schema(data, definitions=definitions)



# Generated at 2022-06-22 06:02:18.454836
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(
        data={"not": {"type": "string"}}, definitions=SchemaDefinitions()
    ) == String(allow_null=True, allow_blank=False, negated=True)



# Generated at 2022-06-22 06:02:22.752836
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = dict(
            type="object",
            oneOf=[{"const": 1}, {"const": 2}],
            default=19,
        )
    definitions = SchemaDefinitions()
    returned = one_of_from_json_schema(data, definitions=definitions)
    expected = {'default': 19, 'one_of': [{'const': 1}, {'const': 2}]}
    assert expected == returned.to_primitive()



# Generated at 2022-06-22 06:02:32.593742
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    print("trying...")
    test_field = enum_from_json_schema({"enum": [1, 2, 3]}, None)
    assert test_field.validate(1) == 1
    assert test_field.validate(2) == 2
    assert test_field.validate(3) == 3
    assert test_field.validate(4) == "Must be one of [1, 2, 3]."
    test_field = enum_from_json_schema({"enum": ["a", "b", "c"]}, None)
    assert test_field.validate("a") == "a"
    assert test_field.validate("b") == "b"
    assert test_field.validate("c") == "c"

# Generated at 2022-06-22 06:02:44.348044
# Unit test for function from_json_schema

# Generated at 2022-06-22 06:02:56.057886
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    Test for function type_from_json_schema
    """
    assert isinstance(
        type_from_json_schema(
            {
                "type": "string",
                "maxLength": 5,
                "minLength": 3,
                "pattern": "^[a-z]",
            },
            definitions=NoDefinition,
        ),
        String,
    )
    assert isinstance(
        type_from_json_schema({"type": "string"}), String
    )
    assert isinstance(
        type_from_json_schema({"type": "integer"}), Integer
    )
    assert isinstance(
        type_from_json_schema({"type": "number"}), Number
    )

# Generated at 2022-06-22 06:05:30.102269
# Unit test for function get_standard_properties
def test_get_standard_properties():
    @attr.s(auto_attribs=True)
    class Field:
        default: typing.Any = None

    assert get_standard_properties(Field()) == {}
    assert get_standard_properties(Field(default=5)) == {"default": 5}
    assert get_standard_properties(Field(default=None)) == {"default": None}



# Generated at 2022-06-22 06:05:34.338043
# Unit test for function get_standard_properties
def test_get_standard_properties():
    fn = get_standard_properties
    field = String(default="hello")
    assert fn(field) == {"default": "hello"}
    
    field = String(default=NO_DEFAULT)
    assert fn(field) == {}


# Generated at 2022-06-22 06:05:40.607677
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/JsonSchema"] = Boolean()
    assert ref_from_json_schema(
        {"$ref": "#/definitions/JsonSchema"}, definitions=definitions
    ) == Reference(to="#/definitions/JsonSchema", definitions=definitions)



# Generated at 2022-06-22 06:05:53.583298
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from .core import Field, Boolean, Decimal, Integer, Float, Array, Choice, Const
    from .core import String, Object, Reference, Schema

    assert get_standard_properties(Boolean(default=False)) == {"default": False}
    assert get_standard_properties(Boolean(default=True)) == {"default": True}
    assert get_standard_properties(Boolean(default=None)) == {}

    assert get_standard_properties(Integer(default=0)) == {"default": 0}
    assert get_standard_properties(Integer(default=1)) == {"default": 1}
    assert get_standard_properties(Integer(default=-1)) == {"default": -1}
    assert get_standard_properties(Integer(default=None)) == {}


# Generated at 2022-06-22 06:06:02.131223
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    def js(data):
        return all_of_from_json_schema(data, definitions={})
    assert js({"$ref": "#/definitions/foo"}) == Reference(to="#/definitions/foo")
    assert js({"enum": [1, 2, 3]}) == Choice(const=1)
    assert js({"const": 1}) == Const(const=1)
    assert js({"allOf": [{"enum": [1, 2, 3]}]}) == AllOf([Choice(const=1)])
    assert js({"anyOf": [{"enum": [1, 2, 3]}]}) == Choice(const=1)
    assert js({"oneOf": [{"enum": [1, 2, 3]}]}) == Choice(const=1)

# Generated at 2022-06-22 06:06:14.039117
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions={}) == Any()
    assert type_from_json_schema({"type": None}, definitions={}) == Any()
    assert type_from_json_schema({"type": []}, definitions={}) == Any()
    assert type_from_json_schema({"type": ""}, definitions={}) == Any()
    assert type_from_json_schema({"type": "boolean"}, definitions={}) == Boolean()
    assert type_from_json_schema({"type": "number"}, definitions={}) == Number()
    assert type_from_json_schema({"type": "integer"}, definitions={}) == Integer()
    assert type_from_json_schema({"type": "string"}, definitions={}) == String()

# Generated at 2022-06-22 06:06:26.050698
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    value = {
        "type": "object",
        "properties": {
            "password": {
                "type": "string",
                "minLength": 10,
                "maxLength": 20,
                "pattern": ".*\\d.*",
            }
        },
    }
    assert (
        type_from_json_schema(value, definitions=SchemaDefinitions())
        == Object(properties={"password": String(min_length=10, max_length=20,pattern=".*\\d.*")})
    )


# Generated at 2022-06-22 06:06:37.575415
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "string"},
            {"minLength": 2},
            {"maxLength": 10},
        ],
    }
    expected_schema = AllOf(
        [
            String(allow_blank=False),
            String(min_length=2, allow_blank=False),
            String(max_length=10, allow_blank=False),
        ],
    )
    assert expected_schema == from_json_schema(schema, definitions=SchemaDefinitions())



# Generated at 2022-06-22 06:06:47.589194
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def test_with_definitions():
        data = {"$ref": "#/definitions/Test"}
        definitions = {"#/definitions/Test": Integer()}
        ref_from_json_schema(data, definitions=definitions)
    test_with_definitions()

    def test_without_definitions():
        data = {"$ref": "#/definitions/Test"}
        ref_from_json_schema(data, definitions=None)
    test_without_definitions()



# Generated at 2022-06-22 06:06:50.826842
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "not": {"type": "string"},
    }
    expected = Not(negated=String())
    actual = from_json_schema(schema)
    assert actual == expected