

# Generated at 2022-06-22 05:58:08.022181
# Unit test for function from_json_schema
def test_from_json_schema():
    # Dummy field with custom field name
    class FromJSONSchemaField(Field):
        pass

    # Unit test for function coerce_from_json_schema
    def coerce_from_json_schema(data: dict, definitions: typing.Any = None):
        return FromJSONSchemaField(coerce=data)

    # Unit test for function definition_from_json_schema
    def definition_from_json_schema(data: dict, definitions: typing.Any = None):
        return FromJSONSchemaField(coerce=data)

    # Unit test for function type_from_json_schema
    def type_from_json_schema(data: dict, definitions: typing.Any = None):
        return FromJSONSchemaField(coerce=data)

    # Unit test for function enum_from_json

# Generated at 2022-06-22 05:58:16.835353
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}], "default": 123}, None), Union)
    assert isinstance(any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}]}, None), Union)
    assert isinstance(any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}], "default": "abc"}, None), Union)
    assert isinstance(any_of_from_json_schema({"anyOf": [{"type": "string"}, {"type": "integer"}]}, None).any_of[0], String)

# Generated at 2022-06-22 05:58:18.998049
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(String(default='abc'))
    assert data == {"default": 'abc'}
    data = get_standard_properties(String())
    assert data == {}


# Generated at 2022-06-22 05:58:21.657258
# Unit test for function from_json_schema
def test_from_json_schema():
    trimmed_data = {
        "type": "object",
        "properties": {"my_field": {"type": "string", "minLength": 3, "maxLength": 10}},
        "required": ["my_field"],
    }
    trimmed_schema = from_json_schema(trimmed_data)
    assert type(trimmed_schema) == Object
    assert type(trimmed_schema.properties["my_field"]) == String



# Generated at 2022-06-22 05:58:28.823875
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema(data={}, definitions=[])
    assert any_of_from_json_schema(
        data = {
                'anyOf': [{'type': 'string'}, {'type': 'number'}]
            },
        definitions = []
    )
    assert any_of_from_json_schema(
        data = {
            'anyOf': [{'type': 'string'}, {'type': 'number'}],
            'default': 'bar'
        },
        definitions = []
    )



# Generated at 2022-06-22 05:58:33.475631
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert (
        enum_from_json_schema({"enum": [1, 2, 3]}, None)
        == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    )



# Generated at 2022-06-22 05:58:34.716562
# Unit test for function to_json_schema
def test_to_json_schema():
    ...



# Generated at 2022-06-22 05:58:37.635443
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema(data={"enum": [1, 2]}, definitions=None).validate(1) == 1



# Generated at 2022-06-22 05:58:47.819449
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, definitions=SchemaDefinitions()) == Any()
    assert type_from_json_schema({"type": "string"}, definitions=SchemaDefinitions()) == String()
    assert type_from_json_schema({"type": "number"}, definitions=SchemaDefinitions()) == Number()
    assert type_from_json_schema({"type": "integer"}, definitions=SchemaDefinitions()) == Integer()
    assert type_from_json_schema({"type": "boolean"}, definitions=SchemaDefinitions()) == Boolean()
    assert type_from_json_schema({"type": "object"}, definitions=SchemaDefinitions()) == Object()
    assert type_from_json_schema({"type": "array"}, definitions=SchemaDefinitions()) == Array()
    assert type_from_json

# Generated at 2022-06-22 05:58:51.141410
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const" : 3}
    definitions = SchemaDefinitions()
    assert const_from_json_schema(data, definitions)



# Generated at 2022-06-22 05:59:13.841087
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["foo"] = String()
    assert ref_from_json_schema(dict({"$ref": "#/foo"}), definitions=definitions) == Reference(
        to="#/foo", definitions=definitions
    )



# Generated at 2022-06-22 05:59:16.967753
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_schema = {"const": "A", "default": "A"}
    assert const_from_json_schema(const_schema, definitions=None) == Const(const="A", default="A")



# Generated at 2022-06-22 05:59:24.746517
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    # The schema of my_field is the union of two fields.
    # One is that of field_1 and the other is that of field_2
    field_1 = Integer(minimum=1, maximum=100)
    field_2 = Float(minimum=0.1, maximum=1.0)
    my_field = AllOf(all_of=[field_1, field_2])

    data = {
        "allOf": [
            {"type": "number", "minimum": 1, "maximum": 100},
            {"type": "number", "minimum": 0.1, "maximum": 1.0},
        ],
        "default": 10,
    }
    assert my_field.validate(10)
    assert my_field.validate(1)
    assert my_field.validate(100)

# Generated at 2022-06-22 05:59:29.088819
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "string", "maxLength": 10}}
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == Not(
        negated=String(min_length=11)
    )

    data = {"not": {"type": "array", "maxItems": 10}}
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == Not(
        negated=Array(max_items=10)
    )

    data = {"not": {"type": "array", "maxItems": 10, "items": {"type": "string"}}}
    assert not_from_json_schema(data, definitions=SchemaDefinitions()) == Not(
        negated=Array(items=String(), max_items=10)
    )


# Generated at 2022-06-22 05:59:36.395372
# Unit test for function to_json_schema
def test_to_json_schema():
    # For now the only test is the reverse of from_json_schema
    for field_name, field in globals().items():
        if not hasattr(field, "make_validator"):
            continue
        schema = field.make_validator()
        data = to_json_schema(schema)
        round_trip = from_json_schema(data, {})
        assert schema == round_trip
test_to_json_schema()

# Generated at 2022-06-22 05:59:47.874562
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "enum": ["1", "2"]
    }
    resultJSON = enum_from_json_schema(schema, {})
    assert resultJSON._type == 'Choice', 'Invalid field'
    result = resultJSON.validate(True, "")
    assert result.is_valid and result.value == '1', 'Invalid result'
    result = resultJSON.validate("2", "")
    assert result.is_valid and result.value == '2', 'Invalid result'
    result = resultJSON.validate("3", "")
    assert result.is_valid == False and result.value == '3', 'Invalid result'


# Generated at 2022-06-22 06:00:00.103575
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    json_schema = {'$ref': '#/definitions/Comment', 'definitions': {'Comment': {'type': 'object', 'properties': {'name': {'type': 'string', 'minLength': 1}, 'email': {'type': 'string', 'format': 'email'}}, 'required': ['name']}}}
    result = not_from_json_schema(json_schema, {'#/definitions/Comment': Object(properties={'name': String(min_length=1, allow_blank=False), 'email': String(format='email')}, required=['name'], default=NO_DEFAULT)})

# Generated at 2022-06-22 06:00:02.900799
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data={"const":"there"}
    result=const_from_json_schema(data,definitions)
    assert result.default=='there'
    assert result.const=='there'
    assert isinstance(result,Const)
    assert result.const_value=='there' 


# Generated at 2022-06-22 06:00:08.145767
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Test without default
    data = {
        "oneOf": [{"const": "A"}, {"const": "B"}, {"const": "C"}]
    }
    one_of_schema = one_of_from_json_schema(data, definitions=None)
    assert isinstance(one_of_schema, OneOf)
    assert len(one_of_schema.one_of) == 3
    assert one_of_schema.one_of[0].const == "A"
    assert one_of_schema.one_of[1].const == "B"
    assert one_of_schema.one_of[2].const == "C"
    assert one_of_schema.default is NO_DEFAULT
    
    # Test with default value

# Generated at 2022-06-22 06:00:14.194707
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema(
        data={
            "type": [
                "string",
                "null",
            ]
        },
        definitions=SchemaDefinitions()
    ) == Union(
        any_of=[
            String(),
            Const(None),
        ],
        allow_null=False
    )

# Generated at 2022-06-22 06:00:43.099289
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    f = enum_from_json_schema({'enum': [1]}, definitions = {})
    # Test that the correct choice is made.
    f.validate(1)
    try:
        f.validate(2)
        assert False, 'Did not raise expected error!'
    except:
        pass
    # Test the default value
    f = enum_from_json_schema({'enum': [1], 'default': 1}, definitions = {})
    assert f.to_primitive(None) == 1



# Generated at 2022-06-22 06:00:48.114355
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from_json_schema({"$schema": "http://json-schema.org/draft-07/schema#", "allOf": [{"$ref": "#/definitions/age"}],
  "definitions": {"age": {"$schema": "http://json-schema.org/draft-07/schema#", "type": "integer",
    "maximum": 130}}})



# Generated at 2022-06-22 06:00:53.550644
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from .object import Object
    from .all_of import AllOf
    from .choice import Choice
    from .const import Const

# Generated at 2022-06-22 06:01:01.808260
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Test that a good value will validate against the individual type.
    """


# Generated at 2022-06-22 06:01:14.353042
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Setting up the data for the unit test
    data = {
        "oneOf": [
            {
              "type": "integer",
              "multipleOf": 3
            },
            {
              "type": "integer",
              "multipleOf": 5
            }
          ]
    }
    # Creating the expected field for assertion
    one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
    expected_field = OneOf(**kwargs)
    # Getting the result field
    result_field = one_of_from_json_schema(data, definitions=definitions)
    # Asserting that result and expected are the same
    assert expected

# Generated at 2022-06-22 06:01:19.252953
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/foo",
    }
    definitions = SchemaDefinitions()
    definitions["foo"] = Choice(any_of=[String(), Integer()], allow_null=False)
    field = from_json_schema(data, definitions=definitions)
    print(field)



# Generated at 2022-06-22 06:01:27.573113
# Unit test for function to_json_schema
def test_to_json_schema():
    data = to_json_schema(Foo.schema)
    definitions = data["definitions"]
    del data["definitions"]

# Generated at 2022-06-22 06:01:35.052883
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["name", "age", "gender"]}, None) == Choice(choices = [('name', 'name'), ('age', 'age'), ('gender', 'gender')])
    assert enum_from_json_schema({"enum": ["name", "age", "gender"], "default": "gender"}, None) == Choice(choices = [('name', 'name'), ('age', 'age'), ('gender', 'gender')], default = 'gender')


# Generated at 2022-06-22 06:01:47.440638
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": None}) == ({"null", "boolean", "object", "array", "number", "string"}, False)
    assert get_valid_types({"type": ["string", "number", "integer", "null"]}) == ({"number", "string"}, True)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": ["null", "object", "array", "number", "string"]}) == ({"number", "object", "array", "string"}, True)
    assert get_

# Generated at 2022-06-22 06:01:58.069829
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {"type": "number"}
    assert Number().equals(type_from_json_schema(schema, definitions=definitions))

    schema = {"type": "integer"}
    assert Integer().equals(type_from_json_schema(schema, definitions=definitions))

    schema = {"type": "string"}
    assert String().equals(type_from_json_schema(schema, definitions=definitions))

    schema = {"type": ["null", "integer"]}
    assert Integer(allow_null=True).equals(
        type_from_json_schema(schema, definitions=definitions)
    )

    schema = {"type": ["null", "integer"]}

# Generated at 2022-06-22 06:02:23.356517
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = from_json_schema(
        {
            "type": "array",
            "items": {"anyOf": [{"type": "string"}, {"type": "integer"}, {"enum": [1, 2]}]},
        }
    )
    assert schema.validate(["a", 1, 2])
    assert not schema.validate(["a", 2])


# Generated at 2022-06-22 06:02:27.888618
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/EasyCode"}, definitions).typename == "Reference"
# End Unit test for function ref_from_json_schema



# Generated at 2022-06-22 06:02:31.188748
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"minimum": 1}}
    result = not_from_json_schema(data, definitions=definitions)
    assert str(result) == "~(number(minimum=1))"



# Generated at 2022-06-22 06:02:33.600801
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {"type": "string"},
        "default": "test",
    }
    not_string = not_from_json_schema(data, definitions=definitions)
    assert not_string.default == "test"



# Generated at 2022-06-22 06:02:41.335421
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # type_string is of type string
    assert Any() == type_from_json_schema({"type": "null"})
    # type_string is of type string[]
    assert Any() == type_from_json_schema({"type": ["null"]})
    # type_string is of type string
    assert Boolean() == type_from_json_schema({"type": "boolean"})
    # type_string is of type string[]
    assert Boolean() == type_from_json_schema({"type": ["boolean"]})
    # type_string is of type string
    assert Integer() == type_from_json_schema({"type": "integer"})
    # type_string is of type string[]
    assert Integer() == type_from_json_schema({"type": ["integer"]})
    #

# Generated at 2022-06-22 06:02:53.519178
# Unit test for function to_json_schema
def test_to_json_schema():
    schema_definitions = {}  # type: SchemaDefinitions
    schema = to_json_schema(
        SchemaDefinitions(
            d1=List(String), d2=SchemaDefinitions(d2_1=String, d2_2=String), d3=Boolean,
        ),
        schema_definitions,
    )

# Generated at 2022-06-22 06:02:58.083924
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data_schema = {
        "allOf": [
            {"type": "number"},
            {"minimum": 3}
        ]
    }
    all_of = all_of_from_json_schema(data_schema, definitions)
    assert isinstance(all_of, AllOf)
    assert isinstance(all_of.all_of[0], Number)
    assert isinstance(all_of.all_of[1], Number)


# Generated at 2022-06-22 06:03:04.500321
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from .fields import String
    from .schemas import SchemaDefinitions

    assert get_standard_properties(String(default="hello")) == {"default": "hello"}

    schema = SchemaDefinitions({"hello": String(default="hello")})
    definitions = to_json_schema(schema)["definitions"]
    assert definitions == {
        "hello": {"type": "string", "default": "hello"}
    }

# Generated at 2022-06-22 06:03:11.693373
# Unit test for function to_json_schema
def test_to_json_schema():
    case = test_case.TestCase()

    case.assertEqual(to_json_schema(Integer(allow_null=False)), {"type": "integer"})
    case.assertEqual(
        to_json_schema(
            Object(
                properties={
                    "user": String(allow_null=False),
                    "age": Integer(allow_null=False),
                },
                allow_null=False,
            )
        ),
        {
            "type": "object",
            "properties": {
                "user": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["user", "age"],
        },
    )

    class Obj1(Schema):
        x: Integer
        y: Integer


# Generated at 2022-06-22 06:03:23.681020
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {
                "$ref": "#/definitions/TypeA"
            },
            {
                "$ref": "#/definitions/TypeB"
            }
        ],
        "definitions": {
            "TypeA": {
                "properties": {
                    "valueA": {
                        "type": "string"
                    }
                },
                "type": "object"
            },
            "TypeB": {
                "properties": {
                    "valueB": {
                        "type": "string"
                    }
                },
                "type": "object"
            }
        }
    }

    result = from_json_schema(data)
    assert result.validate({"valueA": 'a', "valueB": 'b'}), "Should be valid"
   

# Generated at 2022-06-22 06:04:22.140577
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.schemas import Reference
    from typesystem import types
    from typesystem.json_schema import to_json_schema
    from typesystem.constraints import AllOf


# Generated at 2022-06-22 06:04:25.677216
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert len(if_then_else_from_json_schema.__defaults__) == 1

if_then_else_from_json_schema.__defaults__ = (NO_DEFAULT,)  # type: ignore



# Generated at 2022-06-22 06:04:28.009233
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": "foo"}, definitions={})
    


# Generated at 2022-06-22 06:04:33.426536
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {'$ref': '#/definitions/integer'}
    value = ref_from_json_schema(schema, definitions)
    assert isinstance(value, Reference), "Check type."
    assert value.to == '#/definitions/integer', "Check to attribute."
    assert value.definitions is definitions, "Check definitions attribute."



# Generated at 2022-06-22 06:04:39.710329
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema(data={'const': 'a'}, definitions=None)
    assert field.validate('a')
    assert not field.validate('b')
    assert field.get_representation() == {'const': 'a'}



# Generated at 2022-06-22 06:04:50.458023
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({'type':'array'}) == ({'array'}, False)
    assert get_valid_types({'type':'array', 'nullable':True}) == ({'array'}, True)
    assert get_valid_types({'type':'array', 'nullable':True}) == ({'array'}, True)
    assert get_valid_types({'type':'array', 'null':True}) == ({'array'}, True)
    assert get_valid_types({'type':'array', 'nullable':False}) == ({'array'}, False)

# Generated at 2022-06-22 06:05:02.427611
# Unit test for function to_json_schema
def test_to_json_schema():  # noqa: D102
    class SimpleSchema(SchemaDefinitions):
        foo: String
        bar: Integer
        baz: Array[Integer]

    schema = SimpleSchema.schema()
    data = to_json_schema(schema)
    expected_data = {
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "bar": {"type": "integer"},
            "baz": {"type": "array", "items": {"type": "integer"}},
        },
    }
    assert data == expected_data, "Invalid data in nested schema"

    data = to_json_schema(Array[SimpleSchema])
    expected_data = {"type": "array", "items": {"properties": {"foo": {"type": "string"}}}}
    assert data

# Generated at 2022-06-22 06:05:15.272917
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem import Number, Integer, Float
    field=enum_from_json_schema({'enum':[1, 2, 3.4, 5]}, {})
    assert field.validate(1)
    assert field.validate(2)
    assert field.validate(3.4)
    assert field.validate(5)
    assert not field.validate(6)
    assert field.validate(None) == None
    assert field.validate(None) == None
    assert field.schema == {'enum':[1, 2, 3.4, 5]}
    assert isinstance(field.field, Number)
    assert isinstance(field.field, Integer) or isinstance(field.field, Float)
    assert field.field.allow_null
    assert field.field.validate(1)

# Generated at 2022-06-22 06:05:28.111412
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = from_json_schema("oneOf")

# Generated at 2022-06-22 06:05:35.640170
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = \
    {
        "type": "object",
        "oneOf":
        [
            {"properties": {"c": {"type": "string", "enum": ["C"]}}},
            {"properties": {"b": {"type": "string", "enum": ["B"]}}}
        ],
        "required": ["a"],
        "properties":
        {
            "a": {"type": "string", "enum": ["A"]}
        }
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    accepted = [
        {'a': 'A'},
        {'a': 'A', 'c': 'C'},
        {'a': 'A', 'b': 'B'}
    ]

# Generated at 2022-06-22 06:06:39.982565
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = all_of_from_json_schema({"allOf":[{"type" :"string", "const": "a"}, {"type" :"number"}]}, None)
    print(schema.validate("a"))
    print(schema.validate(1))
    schema2 = all_of_from_json_schema({"allOf":[{"type" :"string", "const": "a"}, {"type" :"number", "exclusiveMinimum": 4}]}, None)
    print(schema2.validate("a"))
    print(schema2.validate(4))



# Generated at 2022-06-22 06:06:51.964000
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    schema = {
        "type": "integer",
        "minimum": 10,
        "maximum": 20,
        "exclusiveMinimum": 11,
        "exclusiveMaximum": 21,
        "multipleOf": 3,
    }
    field = from_json_schema_type(schema, type_string="integer", allow_null=False, definitions=definitions)
    assert field.validate(10) == [("minimum", 10)]
    assert field.validate(11) == [("exclusive_minimum", 11)]
    assert field.validate(12) == []
    assert field.validate(19) == []
    assert field.validate(20) == [("exclusive_maximum", 21)]
    assert field.validate(21) == [("maximum", 20)]
    assert field.validate(22) == [("maximum", 20)]

# Generated at 2022-06-22 06:06:56.735573
# Unit test for function get_standard_properties
def test_get_standard_properties():
    import jsonschema_objects as jso
    class Person(jso.Schema):
        name: Field = jso.String(default="Anonymous")
    person = Person()
    field = person.name
    assert get_standard_properties(field) == {'default': 'Anonymous'}