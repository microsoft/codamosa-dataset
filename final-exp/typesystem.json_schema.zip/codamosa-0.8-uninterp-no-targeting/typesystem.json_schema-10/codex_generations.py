

# Generated at 2022-06-22 05:58:16.936934
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    from typesystem.schemas import from_json_schema, to_json_schema
    from typesystem.composites import AllOf

    schema = from_json_schema({"type": "string"})
    assert isinstance(schema, String)

    schema = from_json_schema({"type": ["string"]})
    assert isinstance(schema, String)

    schema = from_json_schema({"type": ["string", "null"]})
    assert isinstance(schema, AllOf)
    assert isinstance(schema.constraints[0], String)
    assert Schema(schema.constraints[1]) == Const(None)

    schema = to_json_schema(from_json_schema({"type": "string"}))
    assert schema == {"type": "string"}



# Generated at 2022-06-22 05:58:20.133021
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema_str = '''{
          "anyOf": [
            {
              "type": "integer",
              "minimum": 1
            },
            {
              "type": "string",
              "enum": ["A", "B"]
            }
          ]
        }'''

    json_schema_dict = json.loads(json_schema_str)
    typesystem_field = from_json_schema(json_schema_dict)
    assert typesystem_field == Union([Integer(minimum=1), Choice("A", "B")])


# Generated at 2022-06-22 05:58:29.275830
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    json_schema = {
        "type": "string",
        "enum": ["foo", "bar"],
        "default": "baz",
    }
    field = enum_from_json_schema(json_schema, None)
    assert isinstance(field, Choice)
    assert field.default == "baz"
    value, error = field.validate("foo")
    assert error is None
    assert value == "foo"
    value, error = field.validate("baz")
    assert error is None
    assert value == "baz"
    value, error = field.validate("bam")
    assert error == "Value must be one of ['foo', 'bar']."
    assert value is None



# Generated at 2022-06-22 05:58:34.265166
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {
        "$ref": "#/definitions/Car"
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/Car"] = Object(properties={
        "color": String()
    })
    assert isinstance(ref_from_json_schema(schema, definitions), Reference)



# Generated at 2022-06-22 05:58:45.314193
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem_json_schema import from_json_schema
    from typesystem.schemas import to_json, to_python_types
    
    schema = from_json_schema({
      "type": "object",
      "properties": {
        "name": {
          "type": "string"
        }
      }
    })
    
    assert to_json(schema) == {
      "type": "object",
      "properties": {
        "name": {
          "type": "string"
        }
      }
    }
    
    assert to_python_types(schema) == {
      'name': str
    }
    

# Generated at 2022-06-22 05:58:56.391753
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_definitions = {
        "#/definitions/str": String(allow_null=True),
        "#/definitions/int": Integer(allow_null=True),
        "#/definitions/number": Number(allow_null=True, coerce=True),
        "#/definitions/boolean": Boolean(allow_null=True),
        "#/definitions/null": Const(None),
    }
    for ref_string, typeclass in schema_definitions.items():
        field = ref_from_json_schema(
            {
                "$ref": ref_string,
            },
            definitions=schema_definitions,
        )
        assert field == typeclass



# Generated at 2022-06-22 05:58:58.608103
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema({"not": {"type": "boolean"}}, None).__repr__() == "{'boolean': False}"


# Generated at 2022-06-22 05:59:00.816223
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 1}, None).validate(1)



# Generated at 2022-06-22 05:59:05.043813
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert (
        to_json_schema(String()) == {"type": "string", "minLength": 1}
    ), "Implicit minimum length is 1 character."
    assert to_json_schema(Array()) == {"type": "array", "minItems": 0}
    assert to_json_schema(Object(properties={"bing": Boolean(), "boom": Integer()})) == {
        "type": "object",
        "properties": {
            "bing": {"type": "boolean"},
            "boom": {"type": "integer"},
        },
    }

# Generated at 2022-06-22 05:59:08.188061
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {"type": "string"}
    field = from_json_schema(data)
    assert field.validate("foo") == "foo"


# Generated at 2022-06-22 05:59:55.972569
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    then_field = String()
    else_field = Integer()
    data = {"if": {"type": "string"}, "then": then_field, "else": else_field}
    field = if_then_else_from_json_schema(data, definitions=None)

    assert isinstance(field, IfThenElse)
    assert field.if_clause.__class__.__name__ == "String"
    assert field.then_clause == String()
    assert field.else_clause == Integer()



# Generated at 2022-06-22 06:00:05.763834
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    def assert_union(value, a, b):
        if isinstance(value, str):
            union = any_of_from_json_schema(
                {"anyOf": [a, b],},
                SchemaDefinitions()
            )
            assert union(value) is True
            assert union(not_exist(value)) is False
        else:
            for value_a, value_b in zip(value, not_exist(value)):
                assert_union(value_a, a, b)
                assert_union(value_b, a, b)

    def not_exist(value):
        return None if value is None else [] if value == [] else [None] if value == [None] else [1, 2, 3]

    assert_union(1, Integer(), Float())

# Generated at 2022-06-22 06:00:17.333599
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        'title': 'example',
        'oneOf': [
            {'type': 'null'},
            {'type': 'boolean'},
            {'type': 'number'},
            {'type': 'string'},
            {'type': 'integer'},
            {'type': 'array'},
            {'type': 'object'},
        ],
    }
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions=definitions)
    assert field is not None
    assert type(field) == OneOf
    assert field.one_of is not None
    assert len(field.one_of) == 7
    assert type(field.one_of[0]) == NeverMatch

# Generated at 2022-06-22 06:00:24.148271
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", False, None) is Float()
    assert from_json_schema_type({}, "integer", False, None) is Integer()
    assert from_json_schema_type({}, "string", False, None) is String()
    assert from_json_schema_type({}, "boolean", False, None) is Boolean()
    assert from_json_schema_type({}, "array", False, None) is Array()
    assert from_json_schema_type({}, "object", False, None) is Object()



# Generated at 2022-06-22 06:00:36.119908
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()
    assert from_json_schema({"$ref": "#/definitions/foo"}) == Reference("#/definitions/foo")
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": ["null", "boolean"]}) == Boolean()
    assert from_json_schema({"type": ["null", "integer"]}) == Integer()

# Generated at 2022-06-22 06:00:46.307373
# Unit test for function to_json_schema
def test_to_json_schema():
    import json
    from validx.validators import *
    from validx.jsonschema import JSONSchema
    schema_data = to_json_schema(
        Field(all_of=[Integer, Object(properties={"hello": String()}, allow_null=True)])
    )
    print(
        json.dumps(schema_data, indent=2, sort_keys=True)
        # ,separators=(",", ":"),
        # ensure_ascii=False,
        # indent=None,
        # default=None,
        # sort_keys=False
    )

    schema = JSONSchema(schema_data)
    schema.validate({})
    schema.validate({"hello": "world"})
    schema.validate(42)
    schema.validate(None)
   

# Generated at 2022-06-22 06:00:54.293060
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": ["foo", "bar", "baz"],
    }
    field = enum_from_json_schema(data, definitions=None)
    assert field.clean_value(data) == "bar"
    assert field.error_messages["enum"] == "Must be one of 'foo', 'bar', 'baz'."



# Generated at 2022-06-22 06:01:00.742544
# Unit test for function get_valid_types
def test_get_valid_types():
  assert get_valid_types({"type": "null"}) == ({}, True)
  assert get_valid_types({"type": None}) == (
    {"null", "boolean", "object", "array", "number", "string"},
    False,
  )
  assert get_valid_types({"type": "number"}) == ({"number"}, False)
  assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
  assert get_valid_types({"type": ["integer", "number"]}) == (
    {"number", "integer"},
    False,
  )



# Generated at 2022-06-22 06:01:06.695029
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({
        "const": "True",
        "default": "True"
    }, None)
    assert field.validate("True")
    # check invalid input
    assert type(field.validate("False")) == str


# Generated at 2022-06-22 06:01:09.048198
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "not": {"enum": ["abc", "def"]}
    }
    expected = Not(negated=Union(any_of=[Const(const="abc"), Const(const="def")]))
    assert from_json_schema(data) == expected

# Generated at 2022-06-22 06:01:40.277325
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({"type": "string"}, "string", False, None) == String()
    assert from_json_schema_type({"type": "string"}, "string", True, None) == String(
        allow_null=True
    )
# End unit test



# Generated at 2022-06-22 06:01:48.675589
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import from_json_schema, Integer, Boolean

    # Generated from body:
    # {"definitions": {"integer": {"type": "integer"}}, "type": "integer"}

    definitions = SchemaDefinitions()
    definitions["#/definitions/integer"] = from_json_schema({"type": "integer"})

    body = from_json_schema(
        {
            "definitions": {"integer": {"type": "integer"}},
            "$ref": "#/definitions/integer",
        },
        definitions=definitions,
    )

    assert isinstance(body, Integer), repr(body)



# Generated at 2022-06-22 06:01:52.904074
# Unit test for function get_standard_properties
def test_get_standard_properties():
    # Given
    Field1 = Any()
    Field2 = Union(
        Any(), Any()
    )
    Field3 = Union(
        Any(), Any(),
        default={"field1":"value1","field2":"value2"}
    )
    Field4 = Not(Any(), default={"field1":"value1","field2":"value2"})
    Field5 = Not(
        Any(),
        default={"field1":"value1","field2":"value2"},
        #  We do not pass allow_blank here to check if it is ignored.
    )
    Field6 = IfThenElse(
        Any(), Any()
    )

# Generated at 2022-06-22 06:02:01.822502
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'object', 'properties': {'foo1': {'type': 'integer'}, 'bar': {'type': 'integer'}}}, {'type': 'object', 'properties': {'foo': {'type': 'integer'}, 'bar': {'type': 'integer'}}}]}, {'#/definitions/foo': Field()}) == type(Union(any_of=[Object({'properties': {'foo1': Integer(), 'bar': Integer()}}), Object({'properties': {'foo': Integer(), 'bar': Integer()}})]))



# Generated at 2022-06-22 06:02:11.648160
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": ["string"]}) == ({'string'}, False)
    assert get_valid_types({}) == (
        {'string', 'null', 'boolean', 'object', 'array', 'number'}, False)
    assert get_valid_types({"type": "array"}) == ({'array'}, False)
    assert get_valid_types({"type": ["array"]}) == ({'array'}, False)
    assert get_valid_types({"type": ["array", "null"]}) == ({'array'}, True)
    assert get_valid_types({"type": ["array", "null", "string"]}) == ({'array', 'string'}, False)
    assert get_valid_

# Generated at 2022-06-22 06:02:24.306189
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        'oneOf': [
            {
              'allOf': [
                {
                  'type': 'string',
                  'maxLength': 16,
                  'minLength': 16
                },
                {
                  'type': 'string',
                  'pattern': '^([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}$'
                }
              ]
            },
            {
              'type': 'string',
              'const': 'none'
            },
            {
              'const': None,
              'type': 'null'
            }
          ]
        }
    field = one_of_from_json_schema(data, None)
    assert field.validate("none") == "none"


# Generated at 2022-06-22 06:02:28.775265
# Unit test for function to_json_schema
def test_to_json_schema():
    field = String(pattern_regex=re.compile("[A-Z][0-9]+"))
    assert to_json_schema(field) == {
        "type": "string",
        "pattern": "[A-Z][0-9]+",
        "error_messages": {},
    }

# Generated at 2022-06-22 06:02:32.705845
# Unit test for function from_json_schema
def test_from_json_schema():
    assert Schema.from_json_schema({"type": "string", "minLength": 5}) == Schema(
        {
            "type": Field(Attribute("__getitem__", ['type']), "string"),
            "minLength": Field(Attribute("__getitem__", ['minLength']), Integer(minimum=5)),
        }
    )



# Generated at 2022-06-22 06:02:41.343101
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from tests.test_from_json_schema import TYPES_DATA as test_data

    for test in test_data:
        schema = test["schema"]
        data = test["data"]
        field = test["field"]

        field_2 = type_from_json_schema(schema, definitions=SchemaDefinitions())
        assert field_2.validate(data) == field.validate(data)
        assert field_2.validate(None) == field.validate(None)



# Generated at 2022-06-22 06:02:50.118894
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "type": "object",
      "properties": {
        "id": {
          "type": "array",
          "items": {
            "oneOf": [
              {
                "type": "string"
              },
              {
                "type": "number"
              }
            ]
          }
        }
      }
    }

    one_of = one_of_from_json_schema(data["properties"]["id"]["items"], definitions)
    print(one_of)


# Generated at 2022-06-22 06:03:18.676065
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data={'anyOf':[{'type': 'string'}, {'type': 'integer'}], 'default': 'foo'}
    defi={}
    type = any_of_from_json_schema(data,defi)
    assert isinstance(type, Union)
    assert isinstance(type.any_of[0], String)
    assert isinstance(type.any_of[1], Integer) 



# Generated at 2022-06-22 06:03:29.340027
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import fields

    class MySchema(Schema):
        my_field = fields.Integer(multiple_of=2)

    data = to_json_schema(MySchema)

    assert data == {
        "definitions": {"MySchema": {"properties": {"my_field": {"multipleOf": 2, "type": "integer"}}, "type": "object"}},
        "$ref": "#/definitions/MySchema",
    }

    data = to_json_schema(MySchema.make_validator())
    assert data == {
        "properties": {"my_field": {"multipleOf": 2, "type": "integer"}},
        "type": "object",
    }

# Unit tests for function from_json_schema

# Generated at 2022-06-22 06:03:35.036788
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf":[{"type":"integer"},{"type":"integer"}]}
    definitions = SchemaDefinitions()
    result = one_of_from_json_schema(data, definitions)
    expected_result = OneOf(one_of=[Integer(allow_null=False), Integer(allow_null=False)])
    assert result == expected_result


# Generated at 2022-06-22 06:03:45.348397
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema(
        {
            "type": "object",
            "properties": {
                "foo": {"type": "string", "maxLength": 3},
                "bar": {"type": "number", "minimum": 42},
            },
        }
    ) == Object(
        properties={
            "foo": String(max_length=3),
            "bar": Number(minimum=42),
        }
    )
    assert from_json_schema(
        {"$ref": "#/definitions/person", "definitions": {"person": {"type": "string"}}}
    ) == Reference("#/definitions/person")



# Generated at 2022-06-22 06:03:52.630334
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [
        {"type": "number"},
        {"type": "integer"},
        {"type": "string"}
    ]}
    assert one_of_from_json_schema(data, definitions=SchemaDefinitions()).validate(1) == (1,None)
    assert one_of_from_json_schema(data, definitions=SchemaDefinitions()).validate("abc") == ("abc",None)
    assert one_of_from_json_schema(data, definitions=SchemaDefinitions()).validate("") == ("",None)
    assert one_of_from_json_schema(data, definitions=SchemaDefinitions()).validate(None) == (None,None)
    assert one_of_from_json_schema(data, definitions=SchemaDefinitions()).valid

# Generated at 2022-06-22 06:04:04.483540
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=String(),
        then_clause=Integer(),
        else_clause=Float(),
        default=None,
    ) == if_then_else_from_json_schema(
        data={
            "$schema": "http://json-schema.org/draft-07/schema#",
            "$id": "http://example.com/product.schema.json",
            "type": "object",
            "properties": {
                "if": {"type": "string"},
                "then": {"type": "integer"},
                "else": {"type": "number"},
            },
        },
        definitions=None,
    )

# Generated at 2022-06-22 06:04:14.973290
# Unit test for function get_valid_types
def test_get_valid_types():
    # Test if null returns the correct value
    type_strings, allow_null = get_valid_types({"type": "null"})
    assert allow_null
    assert len(type_strings) == 0

    type_strings_null, allow_null_null = get_valid_types({"type": ["null"]})
    assert allow_null_null
    assert len(type_strings_null) == 0

    # Test if boolean returns the correct value
    type_strings, allow_null = get_valid_types({"type": "boolean"})
    assert allow_null == False
    assert len(type_strings) == 1
    assert type_strings.pop() == "boolean"

    # Test if object returns the correct value
    type_strings, allow_null = get_valid_types({"type": "object"})
   

# Generated at 2022-06-22 06:04:19.644212
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema = {'$ref': '#/definitions/JSONSchema'}
    definitions = {'#/definitions/JSONSchema': JSONSchema}
    assert ref_from_json_schema(schema, definitions) == Reference(to='#/definitions/JSONSchema', definitions=definitions)


# Generated at 2022-06-22 06:04:25.290625
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {"anyOf": [{"type":"string"}, {"type":"null"}]}
    field = any_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert isinstance(field, Union)
    assert field.any_of[0].type == "string"
    assert field.any_of[1].type == "null"
    assert field.allow_null == True



# Generated at 2022-06-22 06:04:35.284685
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    class TestType(object):
        def __init__(self, a, b, c=None):
            self.a = a
            self.b = b
            self.c = c
    data = {"enum": [{"a": "a", "b": "b"}, TestType("a", "b", c="c")], "default": 42}
    field = enum_from_json_schema(data, definitions=SchemaDefinitions())
    assert field.to_native({"a": "a", "b": "b"}) == {"a": "a", "b": "b"}
    assert field.to_native(TestType("a", "b", c="c")) == {"a": "a", "b": "b", "c": "c"}



# Generated at 2022-06-22 06:05:00.373529
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Test that the correct JSONSchema is returned from a reference
    ref_schema_dict = {"$ref": "#/definitions/ref_schema"}

    definitions = SchemaDefinitions()
    definitions["ref_schema"] = JSONSchema

    ref_schema = ref_from_json_schema(ref_schema_dict, definitions)
    assert ref_schema == JSONSchema


# Generated at 2022-06-22 06:05:10.734404
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", allow_null=False, definitions=None) == Float()
    assert from_json_schema_type({}, "integer", allow_null=False, definitions=None) == Integer()
    assert from_json_schema_type({}, "string", allow_null=False, definitions=None) == String()
    assert from_json_schema_type({}, "boolean", allow_null=False, definitions=None) == Boolean()
    assert from_json_schema_type({}, "array", allow_null=False, definitions=None) == Array(
        items=None
    )
    assert from_json_schema_type({}, "object", allow_null=False, definitions=None) == Object(
        properties=None
    )
    assert from_json_schema

# Generated at 2022-06-22 06:05:17.608392
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-22 06:05:26.761861
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="default")) == {
        "default": "default"
    }
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}
    assert get_standard_properties(String(default=MISSING_VALUE)) == {}
    assert get_standard_properties(String(default=MISSING_VALUE, allow_null=False)) == {}
    assert get_standard_properties(String(default=MISSING_VALUE, allow_null=True)) == {
        "default": None
    }



# Generated at 2022-06-22 06:05:30.588171
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    actual_result = not_from_json_schema({'not': {'type': 'integer'}}, SchemaDefinitions())
    expected_result = {'_allow_null': False, '_default': 'NO_DEFAULT',
                     '_negated': {'_allow_null': False, '_default': 'NO_DEFAULT', '_type': 'integer'}}
    assert actual_result.to_dict() == expected_result


# Generated at 2022-06-22 06:05:35.299625
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        "$ref": "#/definitions/Color"
    }
    definitions = SchemaDefinitions()
    
    actual = ref_from_json_schema(data, definitions)
    
    assert actual.name == "Color"
    assert actual.definitions == definitions
    assert actual.to == "#/definitions/Color"



# Generated at 2022-06-22 06:05:41.120634
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    item = {"type": "string", "minLength": 1, "pattern": "b.*", "format": "date-time"}

    assert isinstance(type_from_json_schema(item, None), String)


# from_json_schema_type.__test__ = False



# Generated at 2022-06-22 06:05:48.279229
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = enum_from_json_schema(
        {"enum": [0, 1, 2], "default": 0}, definitions=SchemaDefinitions()
    )

    assert schema.validate(0) == 0
    assert schema.validate(1) == 1
    assert schema.validate(2) == 2



# Generated at 2022-06-22 06:05:54.997822
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const':'a'}, None).validate('a') == 'a'
    assert const_from_json_schema({'const':'a', 'default':'b'}, None).validate('') == 'b'
    assert const_from_json_schema({'const':'a'}, None).validate('c') == "Value must be one of ['a']."



# Generated at 2022-06-22 06:06:02.781679
# Unit test for function get_standard_properties
def test_get_standard_properties():
    with pytest.raises(ValueError, match="Cannot convert field type 'Should' to JSON Schema"):
        get_standard_properties(Should(re.compile("^\\d+$")))
    with pytest.raises(ValueError, match="Cannot convert field type 'ShouldNot' to JSON Schema"):
        get_standard_properties(ShouldNot(re.compile("^\\d+$")))
    with pytest.raises(ValueError, match="Cannot convert field type 'WithMessage' to JSON Schema"):
        get_standard_properties(WithMessage(re.compile("^\\d+$")))

# Generated at 2022-06-22 06:06:22.930358
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert from_json_schema({"not": {"type": "null"}}) == Not(ref_from_json_schema({"$ref": "#/definitions/JSONSchema"}))
    assert from_json_schema({"not": "null"}) == Not(ref_from_json_schema({"$ref": "#/definitions/JSONSchema"}))


# Generated at 2022-06-22 06:06:33.181090
# Unit test for function get_valid_types
def test_get_valid_types():
    for schema in [
        {"type": "null"},
        {"type": ["null"]},
        {"type": ["boolean", "null"]},
        {"type": {"boolean", "null"}},
        {"type": ["integer", "number", "null"]},
    ]:
        (type_strings, allow_null) = get_valid_types(schema)
        assert "null" not in type_strings
        assert allow_null
    for schema in [
        {"type": "boolean"},
        {"type": ["boolean"]},
        {"type": {"boolean"}},
        {"type": ["boolean", "integer"]},
    ]:
        (type_strings, allow_null) = get_valid_types(schema)
        assert "null" not in type_strings
        assert not allow_null



# Generated at 2022-06-22 06:06:43.318827
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(
        {
            "$ref": "#/definitions/simple_ref",
            "definitions": {
                "simple_ref": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 10,
                    "pattern": "[A-Za-z]*",
                    "format": "email",
                },
            },
        }
    ) == String(
        format="email", minimum_length=1, maximum_length=10, pattern=re.compile(r"[A-Za-z]*")
    )


# Generated at 2022-06-22 06:06:53.665931
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": "object"}) == ({'object'}, False)
    assert get_valid_types({"type": "array"}) == ({'array'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "null", "type": "boolean"}) == ({'boolean'}, True)

# Generated at 2022-06-22 06:07:03.333129
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": ["string"]}) == ({'string'}, False)
    assert get_valid_types({"type": ["null", "string"]}) == ({'string'}, True)
    assert get_valid_types({"type": ["null", "string", "object"]}) == ({'object', 'string'}, True)
    assert get_valid_types({"type": ["number"]}) == ({'number'}, False)
    assert get_valid_types({"type": ["number", "object"]}) == ({'number', 'object'}, False)
    assert get_valid_types({"type": ["integer"]}) == ({'integer'}, False)