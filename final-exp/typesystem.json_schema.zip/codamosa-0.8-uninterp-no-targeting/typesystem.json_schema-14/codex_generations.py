

# Generated at 2022-06-22 05:57:36.984052
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    with pytest.raises(KeyError):
        # KeyError because the not key is not in the data
        not_from_json_schema(
            {}, definitions=SchemaDefinitions()
        )



# Generated at 2022-06-22 05:57:39.330643
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # TODO test Const
    pass



# Generated at 2022-06-22 05:57:45.154848
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    my_reference_string = "https://www.google.com/test"
    assert (
        ref_from_json_schema({'$ref': my_reference_string})
        == Reference(to=my_reference_string, definitions=definitions)
    )



# Generated at 2022-06-22 05:57:53.574446
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    field = IfThenElse(
        if_clause=String(format="date"),
        then_clause=Integer(minimum=0)
    )
    data = {
        "if": {"type": "string", "format": "date"},
        "then": {"type": "integer", "minimum": 0},
    }
    schema = JSONSchema(data)
    result = from_json_schema(data)
    assert field.to_python(result.to_python(field.to_json(14))) == field.to_python(14)
    assert field.to_json(result.to_json(field.to_python(14))) == field.to_json(14)
    assert field.to_python(schema.to_python(field.to_json(14))) == field.to_python(14)
   

# Generated at 2022-06-22 05:57:57.252349
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(
        {
            "$ref": "#/definitions/schema",
            "definitions": {
                "schema": {
                    "$ref": "#/definitions/noop",
                    "definitions": {
                        "noop": {"type": "string"},
                        "noop2": {"type": "array"},
                    },
                }
            },
        }
    ) == String()



# Generated at 2022-06-22 05:57:59.570936
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_case = dict()
    test_case["not"] = dict()
    test_case["not"]["type"] = "null"
    assert_equal(repr(not_from_json_schema(test_case, definitions=None)),
    "<Not(negated=<type_field.TypeField(name='TypeField' type_strings=['null'])>)>")



# Generated at 2022-06-22 05:58:10.595565
# Unit test for function get_valid_types
def test_get_valid_types():
    type_strings,allow_null = get_valid_types({})
    assert type_strings == {"boolean", "object", "array", "number", "string"}
    assert allow_null == False
    type_strings,allow_null = get_valid_types({"type":"null"})
    assert type_strings == {"null"}
    assert allow_null == True
    type_strings,allow_null = get_valid_types({"type":"integer"})
    assert type_strings == {"integer"}
    assert allow_null == False
    type_strings,allow_null = get_valid_types({"type":"number"})
    assert type_strings == {"number"}
    assert allow_null == False
    type_strings,allow_null = get_valid_types({"type":["string", "integer","null"]})
    assert type_

# Generated at 2022-06-22 05:58:17.001300
# Unit test for function get_standard_properties
def test_get_standard_properties():
    data = get_standard_properties(Constant(1))
    assert data == {"default": 1}
    
    data = get_standard_properties(Constant(1, True))
    assert data == {"default": 1}
    
    data = get_standard_properties(Constant(1, False))
    assert data == {}
    
    data = get_standard_properties(Constant(NO_DEFAULT, False))
    assert data == {}

# Generated at 2022-06-22 05:58:27.704691
# Unit test for function from_json_schema
def test_from_json_schema():
    # Test Ref
    assert from_json_schema({"$ref": "#/definitions/User"}) == Reference(
        "User", definitions=SchemaDefinitions()
    )
    assert from_json_schema({"$ref": "#/definitions/User2"}) == Reference(
        "User2", definitions=SchemaDefinitions()
    )
    # Test Enum
    enum = ["blue", "green", "violet"]
    assert from_json_schema({"enum": enum},) == Choice(enum)
    # Test Const
    assert from_json_schema({"const": "foo"}) == Const("foo")
    # Test Array
    # Test Array Constraints
    # Test Array Constraints Items

# Generated at 2022-06-22 05:58:38.461353
# Unit test for function from_json_schema

# Generated at 2022-06-22 05:59:16.336851
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert (
        Field.from_json(
            {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "integer",
                "const": 0,
            }
        )
        == Const(0)
    )



# Generated at 2022-06-22 05:59:24.447367
# Unit test for function one_of_from_json_schema

# Generated at 2022-06-22 05:59:36.238442
# Unit test for function from_json_schema
def test_from_json_schema():
    """Tests the function 'from_json_schema'."""
    # Test case class Base(Schema)
    class Base(Schema):
        # Test case class int_schema(Integer)
        class int_schema(Integer):
            minimum = 1
            maximum = 100

        # End of class 'int_schema'

        # Test case class str_schema(String)
        class str_schema(String):
            min_length = 1
            max_length = 4
            pattern = re.compile(r"^[A-Z]+$")

        # End of class 'str_schema'

        # Test case class bool_schema(Boolean)
        class bool_schema(Boolean):
            pass

        # End of class 'bool_schema'

        # Test case class Base(Schema)


# Generated at 2022-06-22 05:59:46.520807
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="number"), Float)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="integer"), Integer)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="string"), String)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="boolean"), Boolean)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="array"), Array)
    assert isinstance(from_json_schema_type({"type": "number"}, type_string="object"), Object)



# Generated at 2022-06-22 05:59:52.042833
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    from_json_schema_definitions = SchemaDefinitions()
    from_json_schema_definitions["#/definitions/foo"] = String(min_length=5)
    assert ref_from_json_schema(
        data={"$ref": "#/definitions/foo"}, definitions=from_json_schema_definitions
    ).validate(value="Hello", ctx=None) == "Hello"
    assert ref_from_json_schema(
        data={"$ref": "#/definitions/foo"}, definitions=from_json_schema_definitions
    ).validate(value="Hello1", ctx=None) == "Hello1"

# Generated at 2022-06-22 05:59:56.972291
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    f = enum_from_json_schema({'enum': [1, 2]} ,definitions={'enum': [1, 2]})
    assert f.choices == [(1, 1), (2, 2)]
    assert f.default == None
    assert isinstance(f, Choice)


# Generated at 2022-06-22 06:00:06.175481
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    """
    https://json-schema.org/draft/2019-09/json-schema-validation.html#rfc.section.9
    """
    data = {"type": "string"}
    assert type_from_json_schema(data, definitions=definitions) == String()

    data = {"type": ["number", "string"]}
    assert type_from_json_schema(data, definitions=definitions) == Union(
        any_of=[Number(), String()]
    )

    data = {"type": ["integer", "string"]}
    assert type_from_json_schema(data, definitions=definitions) == Union(
        any_of=[Integer(), String()]
    )

    data = {"type": ["integer", "null"]}

# Generated at 2022-06-22 06:00:08.367710
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {"type": "integer"},
        "then": {"const": 1},
        "else": {"const": "a"},
    }
    obj = from_json_schema(schema)
    assert obj.validate(2) == 1
    assert obj.validate(True) == "a"



# Generated at 2022-06-22 06:00:19.145282
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "enum": [1, 2, {"a": "b"}, [3, 4]],
        "default": None,
    }
    expected = Choice(choices=[(1, 1), (2, 2), (({"a": "b"}), ({"a": "b"})), (([3, 4]), ([3, 4]))], default=None)
    test = enum_from_json_schema(data, SchemaDefinitions())
    assert test == expected, f"Should be {expected}"

    data = {
        "enum": [1, 3, 4],
        "default": None,
    }
    expected = Choice(choices=[(1, 1), (3, 3), (4, 4)], default=None)
    test = enum_from_json_schema(data, SchemaDefinitions())


# Generated at 2022-06-22 06:00:22.307588
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/contact_details"}
    reference = ref_from_json_schema(data, SchemaDefinitions())
    assert reference.to == "#/definitions/contact_details"



# Generated at 2022-06-22 06:00:55.835926
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    field = const_from_json_schema({"const": "Red"}, definitions=None)
    assert field.schema == {"const": "Red"}
    assert field.validate("Red") is None
    assert field.validate("Green") is not None



# Generated at 2022-06-22 06:01:04.626854
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = Schema.from_fields(
        {"name": String(max_length=120, min_length=1), "email": String(max_length=120)}
    )
    #import pdb; pdb.set_trace()
    jschema = to_json_schema(schema)
    print(jschema)

# Generated at 2022-06-22 06:01:15.947800
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    json_schema1 = {
        "$schema": "http://json-schema.org/schema#",
        "definitions": {
            "schemaArray": {
                "type": "array",
                "minItems": 1,
                "items": {"$ref": "#/definitions/positiveInteger"}
            },
            "positiveInteger": {
                "type": "integer",
                "minimum": 0
            }
        },
        "type": "array",
        "items": {
            "allOf": [
                {"$ref": "#/definitions/schemaArray"},
                {
                    "items": {
                        "allOf": [
                            {"$ref": "#/definitions/positiveInteger"},
                            {"minimum": 100}
                        ]
                    }
                }
            ]
        }
    }

# Generated at 2022-06-22 06:01:26.123827
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}) == Integer()
    assert type_from_json_schema({"type": "string"}) == String()
    assert type_from_json_schema({"type": "number"}) == Number()
    assert type_from_json_schema({"type": "number", "multipleOf": 1}) == Integer()
    assert type_from_json_schema({"type": "number", "multipleOf": 2}) == Decimal()
    assert type_from_json_schema({"type": "number", "multipleOf": 2.5}) == Float()
    assert type_from_json_schema({"type": "array"}) == Array()

# Generated at 2022-06-22 06:01:38.076518
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    import json
    import pytest
    from typesystem import Schema

    def test_json_schema(source):
        schema = Schema(
            properties={
                "string": from_json_schema(source),
            },
        )
        assert schema.validate({"string": ""})["string"] == ""

        assert schema.validate({"string": "foo"})["string"] == "foo"
        assert schema.validate({"string": "bar"})["string"] == "bar"

    source = {"anyOf": [{"type": "string", "minLength": 1}, {"type": "string", "maxLength": 1}]}

    schema = Schema(
            properties={
                "string": from_json_schema(source),
            },
        )

# Generated at 2022-06-22 06:01:46.375488
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-22 06:01:57.331359
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "integer"}, None) == Integer()
    assert type_from_json_schema({"type": "integer", "nullable": True}, None) == Integer().nullable()
    assert type_from_json_schema({"type": ["integer", "null"]}, None) == (Integer(allow_null=True) | Const(None))
    assert type_from_json_schema({"type": "string"}, None) == String()
    assert type_from_json_schema({"type": "object"}, None) == Object()
    assert type_from_json_schema({"type": "array"}, None) == Array()
    assert type_from_json_schema({"type": "number"}, None) == Number()

# Generated at 2022-06-22 06:02:01.783174
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string", "const": "string"}, {"type": "integer"}]}
    defs = SchemaDefinitions()
    field = any_of_from_json_schema(data=data, definitions=defs)
    assert field.validate(1) == (1, None)


# Generated at 2022-06-22 06:02:09.541226
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-22 06:02:19.877777
# Unit test for function to_json_schema
def test_to_json_schema():

    class TestSchema(Schema):
        field = String()

    schema = TestSchema()
    expected_result = {
        "definitions": {"TestSchema-field": {"type": ["string", "null"]},},
        "$ref": "#/definitions/TestSchema-field",
    }
    result = to_json_schema(schema.field)
    assert result == expected_result

    schema = TestSchema.make_validator()
    expected_result = {
        "definitions": {"TestSchema-field": {"type": ["string", "null"]},},
        "$ref": "#/definitions/TestSchema-field",
    }
    result = to_json_schema(schema.field)
    assert result == expected_result

    schema = TestSchema.make_validator()


# Generated at 2022-06-22 06:03:02.294105
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    button_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "button",
        "title": "Button",
        "description": "A button schema",
        "type": "object",
        "properties": {
            "type": {
                "type": "string",
                "enum": ["button", "submit", "reset"],
                "default": "button",
            },
            "label": {"type": "string"},
            "disabled": {"type": "boolean", "default": False},
        },
        "required": ["label"],
    }

    button_field = if_then_else_from_json_schema(button_schema, SchemaDefinitions())


# Generated at 2022-06-22 06:03:14.132162
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    expected_typesystem_field_from_jsonschema_type = {
        "array": Array,
        "boolean": Boolean,
        "integer": Integer,
        "null": NeverMatch,
        "number": Number,
        "object": Object,
        "string": String,
    }
    for jsonschema_type, typesystem_field_type in expected_typesystem_field_from_jsonschema_type.items():
        assert isinstance(from_json_schema_type(data = {"type": jsonschema_type}, type_string = jsonschema_type, allow_null = False, definitions = None), typesystem_field_type)
# End unit test for function type_from_json_schema



# Generated at 2022-06-22 06:03:24.668881
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "type": [
            "object",
            "array",
            "string",
            "number",
            "boolean",
            "integer",
        ]
    }
    get_valid_types(data) == ({"object", "array", "string", "number", "boolean", "integer"}, False)
    
    data = {
        "type": [
            "null",
            "object",
            "array",
            "string",
            "number",
            "boolean",
            "integer",
        ]
    }
    get_valid_types(data) == ({"object", "array", "string", "number", "boolean", "integer"}, True)

test_get_valid_types()


# Generated at 2022-06-22 06:03:35.433636
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, type_string="string", allow_null=False, definitions=definitions) == String()
    assert from_json_schema_type({}, type_string="string", allow_null=True, definitions=definitions) == String(allow_null=True)
    assert from_json_schema_type({}, type_string="boolean", allow_null=False, definitions=definitions) == Boolean()
    assert from_json_schema_type({}, type_string="boolean", allow_null=True, definitions=definitions) == Boolean(allow_null=True)
    assert from_json_schema_type({}, type_string="number", allow_null=False, definitions=definitions) == Float()

# Generated at 2022-06-22 06:03:45.875619
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    definitions = SchemaDefinitions()

    data = {
        "oneOf": [
            {
                "type": "string",
                "minLength": 3,
                "pattern": "^[A-Z][A-Z][A-Z]$",
            },
            {
                "type": "integer",
                "minimum": 0,
                "multipleOf": 100,
            },
        ],
        "default": "a",
    }
    result = one_of_from_json_schema(data, definitions)
    # print(result)
    assert isinstance(result, OneOf) == True
    assert isinstance(result.one_of, list) == True
    assert len(result.one_of) == 2

    assert isinstance(result.one_of[0], String) == True
    assert result.one

# Generated at 2022-06-22 06:03:52.526906
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "type":"string",
        "maxLength":10,
        "not":""
    }
    a = not_from_json_schema(data, SchemaDefinitions())
    # print(a)
    # a = a.to_json_schema()
    # print(a)
    # a = a.to_json_schema()
    # print(a)
    # a = a.to_json_schema()
    # print(a)
    # a = a.to_json_schema()
    # print(a)

    assert a == Not(negated=String(max_length=10, default=NO_DEFAULT), default=NO_DEFAULT)
    assert a.validate(11) is None
    assert a.validate(None) is None
    assert a

# Generated at 2022-06-22 06:03:56.865330
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const = const_from_json_schema({"const": 1}, {})
    assert const.validate(1)
    assert not const.validate(2)
    assert const.schema() == {"type": "const", "const": 1}



# Generated at 2022-06-22 06:04:06.693875
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    f = const_from_json_schema({"const": "Hello"}, definitions=definitions)
    assert isinstance(f, Const)
    assert f.const == "Hello"
    assert f.default == NO_DEFAULT

    f = const_from_json_schema({"const": "A", "default": "B"}, definitions=definitions)
    assert f.default == "B"

    f = const_from_json_schema({"const": 123, "default": None}, definitions=definitions)
    assert f.default is None



# Generated at 2022-06-22 06:04:16.549014
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {
        "type": "null"
    }
    assert get_valid_types(data) == (set(), True)

    data = {
        "type": "string"
    }
    assert get_valid_types(data) == ({"string"}, False)

    data = {
        "type": ["integer", "string"]
    }
    assert get_valid_types(data) == ({"integer", "string"}, False)

    data = {
        "type": []
    }
    assert get_valid_types(data) == ({"null", "boolean", "object", "array", "number", "string"}, False)

# Generated at 2022-06-22 06:04:25.088299
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # test data
    data = {
        "type": ["string", "null"],
        "minLength": 10,
        "maxLength": 20,
        "pattern": r"^\d{3}$",
        "format": "ipv6",
    }

    # expected result
    expected = String(min_length=10, max_length=20, regex=r"^\d{3}$", format="ipv6") | Const(
        None
    )

    assert type_from_json_schema(data, definitions={}) == expected



# Generated at 2022-06-22 06:04:59.037367
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    result=one_of_from_json_schema({'oneOf':[
        {'type':'integer','minimum':1,'maximum':2},
        {'type':'integer','minimum':3,'maximum':4}]
    },'')
    assert result.validate(3) == 3
    assert result.validate(2) == 2
    assert result.validate(4) == 4
    assert result.validate(5) == 5

# Generated at 2022-06-22 06:05:03.905749
# Unit test for function from_json_schema
def test_from_json_schema():
    import json
    from typesystem.tests.test_from_json_schema_data import TEST_SCHEMA

    for data in TEST_SCHEMA:
        input, expected = data
        if isinstance(input, str):
            input = json.loads(input)
        assert from_json_schema(input).as_dict() == expected



# Generated at 2022-06-22 06:05:06.491594
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    obj = const_from_json_schema({"const":3}, None)
    assert obj.validate(3)
    assert obj.validate(3, strict=True)



# Generated at 2022-06-22 06:05:12.515436
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from json_schema import from_json_schema
    from dpf import Not, String
    assert isinstance(from_json_schema({"not": {"type": "string"}}), Not)
    assert isinstance(from_json_schema({"not": {"type": "string"}}).value, String)



# Generated at 2022-06-22 06:05:20.735278
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    any_of = [from_json_schema(item, definitions=definitions) for item in data["anyOf"]]
    kwargs = {"any_of": any_of, "default": data.get("default", NO_DEFAULT)}
    assert Union(**kwargs).validate("hello")
    assert Union(**kwargs).validate(123)
    assert not Union(**kwargs).validate([])


# Generated at 2022-06-22 06:05:31.645437
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type(type_from_json_schema({"type": "integer"}, definitions)) is Integer
    assert type(type_from_json_schema({"type": "number"}, definitions)) is Number
    assert type(
        type_from_json_schema({"type": "integer", "multipleOf": 2}, definitions)
    ) is Integer
    assert type(
        type_from_json_schema({"type": "number", "multipleOf": 2}, definitions)
    ) is Decimal
    assert type(type_from_json_schema({"type": "string"}, definitions)) is String
    assert type(type_from_json_schema({"type": "object"}, definitions)) is Object
    assert type(type_from_json_schema({"type": "array"}, definitions)) is Array

# Generated at 2022-06-22 06:05:39.675160
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({
        "allOf": [{
            "type": "string",
        }],
    }) == Field({
        "type": "string"
    })
    assert all_of_from_json_schema({
        "allOf": [{
            "type": "string",
            "default": "default"
        }, {
            "type": "string",
            "pattern": "p*",
            "default": "default2"
        }],
    }) == AllOf(fields=[Field({
        "type": "string",
        "default": "default"
    }), Field({
        "type": "string",
        "pattern": "p*",
        "default": NO_DEFAULT
    })])

# Generated at 2022-06-22 06:05:46.462080
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type({}, type_string="string", allow_null=False, definitions=None),
        String,
    )



# Generated at 2022-06-22 06:05:57.410051
# Unit test for function get_valid_types
def test_get_valid_types():
    print("Test cases in get_valid_types")
    print("---------------------------------------------")
    type_strings, allow_null = get_valid_types({"type": "null"})
    print("type_strings: {0}, allow_null: {1}".format(type_strings, allow_null))
    if(type_strings == set() and allow_null == True):
        print("-> Succesful")
    else:
        print("-> Failed")

    type_strings, allow_null = get_valid_types({"type": ["null", "boolean"]})
    print("type_strings: {0}, allow_null: {1}".format(type_strings, allow_null))
    if(type_strings == {"boolean"} and allow_null == True):
        print("-> Succesful")

# Generated at 2022-06-22 06:06:07.513689
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"title": "test"}, definitions=definitions) == Any()
    assert (
        type_from_json_schema({"type": "integer"}, definitions=definitions)
        == Integer()
    )
    assert (
        type_from_json_schema({"type": "string"}, definitions=definitions) == String()
    )
    assert (
        type_from_json_schema({"type": "boolean"}, definitions=definitions)
        == Boolean()
    )
    assert (
        type_from_json_schema({"type": "object"}, definitions=definitions) == Object()
    )
    assert (
        type_from_json_schema({"type": "array"}, definitions=definitions) == Array()
    )

# Generated at 2022-06-22 06:06:39.829956
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'not': {
        'type': 'array',
        'items': {
            'type': 'number'
        }
    }}
    field = not_from_json_schema(schema, None)
    assert field.validate(1) == 1
    assert field.validate([1])
    # End of unit test for function not_from_json_schema


# Generated at 2022-06-22 06:06:49.034049
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "number", "minimum": 1},
            {"type": "number", "maximum": 10}
        ],
        "default": 18
    }
    schema = from_json_schema(data)
    assert schema.validate(10) == True
    assert schema.validate(1) == True
    assert schema.validate(0) == False
    assert schema.validate(11) == False
    assert schema.validate(18) == True
    assert schema.validate(None) == False



# Generated at 2022-06-22 06:06:51.745748
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [
        {"minimum": 1},
        {"maximum": 10}]}).validate(5) == 5



# Generated at 2022-06-22 06:07:01.520447
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    schema = {
        "type": "string",
        "maxLength": 10,
    }
    field = type_from_json_schema(schema, definitions=definitions)
    assert field.max_length == 10

    schema = {
        "type": ["string", "null"],
        "maxLength": 10,
    }
    field = type_from_json_schema(schema, definitions=definitions)
    assert isinstance(field, Union)
    assert field.allow_null
    assert isinstance(field.any_of[0], String)
    assert field.any_of[0].max_length == 10

