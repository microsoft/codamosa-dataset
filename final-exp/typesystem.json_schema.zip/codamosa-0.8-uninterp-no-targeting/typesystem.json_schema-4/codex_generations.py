

# Generated at 2022-06-22 05:57:40.678832
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field: Field = String(default="Test string")
    result = get_standard_properties(field)
    assert result == {"default": "Test string"}

    assert get_standard_properties(None) == {}

# Generated at 2022-06-22 05:57:51.226551
# Unit test for function enum_from_json_schema

# Generated at 2022-06-22 05:58:02.090665
# Unit test for function to_json_schema
def test_to_json_schema():
    field = Field(format=None)
    schema = {
        "description": None,
        "title": None,
        "default": NO_DEFAULT,
        "readOnly": False,
        "writeOnly": False,
    }
    assert to_json_schema(field) == schema

    schema = {
        "description": None,
        "title": None,
        "readOnly": False,
        "writeOnly": False,
    }
    assert to_json_schema(field, _definitions=None) == schema

    field = Field(format="foo")
    schema = {
        "description": None,
        "title": None,
        "format": "foo",
        "default": NO_DEFAULT,
        "readOnly": False,
        "writeOnly": False,
    }
    assert to

# Generated at 2022-06-22 05:58:11.735879
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    field = from_json_schema({"$ref": "#/definitions/test"})
    assert isinstance(field, Reference)
    assert field.reference == "#/definitions/test"
    assert field.definitions is None

    field = from_json_schema({"$ref": "#/definitions/test"}, definitions={"#/definitions/test": String()})
    assert isinstance(field, Reference)
    assert field.reference == "#/definitions/test"
    assert isinstance(field.definitions["#/definitions/test"], String)

    field = from_json_schema({"type": "integer"})
   

# Generated at 2022-06-22 05:58:20.133652
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"type": "integer", "const": 5}
    result = from_json_schema(data)
    expected = Const(const=5, allow_null=False)
    assert result == expected

    data = {"type": "integer", "const": 5, "default": 5}
    result = from_json_schema(data)
    expected = Const(const=5, allow_null=False, default=5)
    assert result == expected



# Generated at 2022-06-22 05:58:21.414145
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "integer"}}
    res = not_from_json_schema(data)
    assert res.rules == [{"type": "integer"}]


# Generated at 2022-06-22 05:58:29.736171
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "string", "enum": [None]}) == (set(), True)
    assert get_valid_types({"type": "string", "enum": ["foo"]}) == ({"string"}, False)
    assert get_valid_types({"type": "integer", "minimum": 0, "maximum": 0}) == (
        {"integer"},
        False,
    )
    assert get_valid_types({"type": "number"}) == ({"number"}, False)



# Generated at 2022-06-22 05:58:38.624311
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import Boolean, Integer, parse

    assert from_json_schema(True) == parse("a comma-separated list of values")
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer", "minimum": 1, "maximum": 10}) == Integer(
        minimum=1, maximum=10
    )
    assert from_json_schema({"type": "number", "minimum": 1, "maximum": 10}) == Number(
        minimum=1, maximum=10
    )

# Generated at 2022-06-22 05:58:48.372968
# Unit test for function from_json_schema
def test_from_json_schema():
    # Test: Anything
    assert(Any() == from_json_schema(True))
    # Test: Nothing
    assert(NeverMatch() == from_json_schema(False))
    # Test: Number
    assert(Number(minimum=5) == from_json_schema({"minimum": 5}))
    assert(Integer(minimum=5) == from_json_schema({"type": "integer", "minimum": 5}))
    assert(Float(exclusive_maximum=True, maximum=2.5) == from_json_schema({"type": "number", "exclusiveMaximum": 2.5}))
    assert(Decimal(multiple_of=2.5) == from_json_schema({"type": "number", "multipleOf": 2.5}))
    # Test: String

# Generated at 2022-06-22 05:58:56.804473
# Unit test for function to_json_schema
def test_to_json_schema():
    validator = MySchemaDefinitions.MySchema().make_validator()

# Generated at 2022-06-22 05:59:27.757262
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Any(),
        then_clause=None,
        else_clause=None,
        default=DEFAULT,
    ) == if_then_else_from_json_schema(
        {
            "if": {"type": "object"},
            "then": {"type": ["string", "null"], "const": "a"},
            "else": {"type": "number", "const": 1},
        },
        definitions=None,
    )

# Generated at 2022-06-22 05:59:39.592035
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field = type_from_json_schema(
        {"type": "integer", "enum": [1, 2, 3]}, definitions={},
    )
    assert isinstance(field, Integer)
    assert field.enum == {1, 2, 3}

    field = type_from_json_schema({"type": "string"}, definitions={})
    assert isinstance(field, String)

    field = type_from_json_schema({"type": "number"}, definitions={})
    assert isinstance(field, Number)

    field = type_from_json_schema({"type": "boolean"}, definitions={})
    assert isinstance(field, Boolean)

    field = type_from_json_schema({"type": "null"}, definitions={})
    assert isinstance(field, Const)
    assert field.value is None



# Generated at 2022-06-22 05:59:48.978986
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test function from_json_schema_type
    # > define function
    def test_function(
        type_string: str,
        schema_data: dict,
        definition_data: dict = None,
    ) -> Field:
        definition_data = definition_data or {}
        return from_json_schema_type(
            data=schema_data,
            type_string=type_string,
            definitions=SchemaDefinitions(
                data={ref: from_json_schema(value) for ref, value in definition_data.items()},
            ),
        )
    # Test function from_json_schema_type: Boolean

# Generated at 2022-06-22 05:59:55.034701
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(max_length=10)) == {}
    assert get_standard_properties(String(max_length=10, default="a")) == {
        "default": "a"
    }
test_get_standard_properties()

# Generated at 2022-06-22 06:00:05.289703
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    definitions = SchemaDefinitions()
    d1 = {"type": "string"}
    d2 = {"type": "string", "enum": ["A", "B"]}
    data = {"oneOf": [d1, d2]}
    oneOf = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
    ck = OneOf(one_of=oneOf, default=NO_DEFAULT)

    print(ck.validate(None))
    print(ck.validate("AA"))
    print(ck.validate("A"))
    print(ck.validate("B"))
    print(ck.validate("C"))



# Generated at 2022-06-22 06:00:13.591225
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "type": "integer",
        "minimum": 1,
        "not": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "name": {
                    "type": "string",
                },
            },
            "required": ["name"],
        },
    }
    result = not_from_json_schema(data=data, definitions=None)
    assert isinstance(result, Not)
    assert isinstance(result.negated, Object)
    assert result.negated.default == NO_DEFAULT



# Generated at 2022-06-22 06:00:16.196433
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'integer', 'string'}, False)



# Generated at 2022-06-22 06:00:25.499180
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.base import ValidationError

    schema = from_json_schema({
        "type": "number",
        "const": 3.14,
        "minimum": -10,
        "maximum": 10,
    })
    assert isinstance(schema, Field)
    assert schema.validate(3.14) == 3.14
    assert schema.validate(2) == 2
    assert schema.validate(10) == 10
    try:
        schema.validate(-10.1)
    except ValidationError as e:
        assert e.value == -10.1
    try:
        schema.validate(10.1)
    except ValidationError as e:
        assert e.value == 10.1

# Generated at 2022-06-22 06:00:32.153138
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema_object = \
    {
        "allOf": [
        {
            "type": "string"
        },
        {
            "minLength": 10
        }
        ]
    }
    type_field = from_json_schema(schema_object)
    assert type_field.constraints[0] == String
    assert type_field.constraints[1].field == String
    assert type_field.constraints[1].constraints[0].min_length == 10
    
test_all_of_from_json_schema()


# Generated at 2022-06-22 06:00:37.767799
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    
    data = {
        "if": {
            "properties": {"a": {"type": "string"}, "b": {"type": "string"}},
            "required": ["a"]
        },
        "then": {"required": ["b"]},
    }
    definitions = SchemaDefinitions()
    c = if_then_else_from_json_schema(data, definitions=definitions)
    assert c.if_clause.properties_



# Generated at 2022-06-22 06:01:13.036307
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, type_string="string", allow_null=False), String)



# Generated at 2022-06-22 06:01:24.571264
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    import json

# Generated at 2022-06-22 06:01:28.113367
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_null = not_from_json_schema(data={"not": {"type": "null"}})
    assert len(not_null.validate({})) == 0
    not_null_or_boolean = not_from_json_schema(data={"not": {"type": ["null", "boolean"]}})
    assert len(not_null_or_boolean.validate({})) == 0
    assert not_null_or_boolean.validate({"not": True})[0] == "'not' is not equal to True"



# Generated at 2022-06-22 06:01:32.190338
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = PersonSchema()
    result = to_json_schema(schema)
    expected = {
        "definitions": {
            "Person": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "minLength": 1},
                    "age": {
                        "type": ["number", "null"],
                        "multipleOf": 1.0,
                        "minimum": 0,
                        "maximum": 120,
                    },
                },
                "required": ["name"],
            }
        },
        "$ref": "#/definitions/Person",
    }
    assert result == expected

# Generated at 2022-06-22 06:01:37.996438
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Unit test for function ref_from_json_schema
    """
    # TODO implement this



# Generated at 2022-06-22 06:01:48.639395
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    cases = [
        {
            "not": {
                "type": "string",
                "pattern": "^(acme|corp|org)$",
                "default": "acme"
            }
        },
        {
            "not": {
                "type": "integer",
                "minimum": 1,
                "maximum": 10
            }
        },
    ]
    for case in cases:
        field = not_from_json_schema(case, definitions=None)
        assert field.validate("abc") is None
        assert field.validate("acme") is not None
        assert field.validate("corp") is not None
        assert field.validate("org") is not None
        assert field.validate("0") is not None
        assert field.validate("11") is not None



# Generated at 2022-06-22 06:01:51.352947
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data={"allOf":[{"type": "integer"}, {"maximum": 10}]}
    field=all_of_from_json_schema(data=data, definitions=None)


# Generated at 2022-06-22 06:02:00.470753
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "a": {"if": {"const": True}, "then": {"const": "foo"}, "const": "bar"},
            "b": {"if": {"type": "boolean"}, "then": {"type": "string"}, "const": None},
        },
    }
    field = from_json_schema(schema)
    assert field.validates({"a": "foo"})
    assert field.validates({"a": "bar"})



# Generated at 2022-06-22 06:02:06.711753
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "object",
        "definitions": {
            "foo": {
                "type": "object",
                "properties": {
                    "bar": {"type": "integer"}
                }
            },
            "null": {"type": "null"}
        }
    }
    field = type_from_json_schema(data, definitions=SchemaDefinitions())
    assert isinstance(field, Object)



# Generated at 2022-06-22 06:02:18.557853
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({
        "array",
        "boolean",
        "integer",
        "number",
        "null",
        "object",
        "string"
    }, False)

    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["integer", "number"]}) == ({"integer", "number"}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({"integer"}, True)

# Generated at 2022-06-22 06:02:58.119907
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema(True), Any)
    assert isinstance(from_json_schema(False), NeverMatch)



# Generated at 2022-06-22 06:03:04.102051
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    # We want to make sure that a call to if_then_else_from_json_schema(...)
    # actually builds a IfThenElse object
    assert isinstance(if_then_else_from_json_schema({"if":{}}),IfThenElse)



# Generated at 2022-06-22 06:03:12.699817
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string in {"number", "integer", "string", "boolean", "array", "object"}:
        data = {"type": type_string}
        built_field = from_json_schema_type(data, type_string=type_string, allow_null=False, definitions=SchemaDefinitions())
        assert isinstance(built_field, Field)

    assert from_json_schema_type({"type": "null"}, type_string="null", allow_null=False, definitions=SchemaDefinitions()) == Const(None)


# Generated at 2022-06-22 06:03:18.911525
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    from pyfield.fields.fields import Boolean
    from pyfield.fields.fields import Integer
    from pyfield.fields.fields import Float

    assert not_from_json_schema({'not': {'type': 'null'}}, None) == Not(negated=Const(None))
    assert not_from_json_schema({'not': {'type': 'boolean'}}, None) == Not(negated=Boolean())
    assert not_from_json_schema({'not': {'type': 'object'}}, None) == Not(negated=Object())
    assert not_from_json_schema({'not': {'type': 'array'}}, None) == Not(negated=Array())

# Generated at 2022-06-22 06:03:24.426198
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    enum_field = const_from_json_schema({"const": "10"}, None)
    assert enum_field.validate("10") == "10"
    assert enum_field.validate(10) == "10"



# Generated at 2022-06-22 06:03:32.797681
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import String, Integer, Float, Boolean, Array, Object, Union, AllOf, Not, Const
    from . import Field, Reference
    def test_to_json_schema(arg, expected):
        actual = to_json_schema(arg)
        assert actual == expected, (
            f"Actual JSON schema is not equal to expected schema:\n\n"
            f"Expected:\n{pretty_json(expected)}\n"
            f"Actual:\n{pretty_json(actual)}\n"
        )

    test_to_json_schema(
        Any(),
        {
            "type": "any",
        },
    )


# Generated at 2022-06-22 06:03:44.387075
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Test with one of the negated value and default value
    schema = {
        "$schema": "http://json-schema.org/draft/2019-09/schema#",
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "not": {
                    "enum": [
                        "876"
                    ]
                }
            }
        }
    }
    field = from_json_schema(schema)
    assert field.field == Not
    assert field.negated.field == Choice
    assert field.negated.choices == [('876', '876')]
    assert field.get_default_value() == NO_DEFAULT

    # Test with one of the negated value and no default value

# Generated at 2022-06-22 06:03:49.169400
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert not_from_json_schema(data={"not": {"type": "null"}}, definitions=None) == Not(negated=Object(allow_null=True))
    assert not_from_json_schema(data={"not": {"type": "null"}, "default": "hello"}, definitions=None) == Not(
        negated=Object(allow_null=True), default="hello"
    )



# Generated at 2022-06-22 06:03:56.495518
# Unit test for function get_standard_properties
def test_get_standard_properties():
    test_cases = (
        (String(default="string"), {'default': 'string'}),
        (String(default=None), {}),
        (String(default=NO_DEFAULT), {'default': NO_DEFAULT}),
    )
    for field, result in test_cases:
        assert get_standard_properties(field) == result

# Generated at 2022-06-22 06:04:10.014397
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {
        "type": "array",
        "items": {"type": "string"},
    }
    assert type_from_json_schema(data, definitions) == Array(items=String())

    data = {
        "type": "array",
        "items": {
            "type": "string",
            "enum": [
                "FOO",
                "BAR",
            ],
        },
    }
    assert type_from_json_schema(data, definitions) == Array(
        items=Choice(choices=["FOO", "BAR"])
    )

    data = {
        "type": "string",
        "enum": [
            "FOO",
            "BAR",
        ],
    }

# Generated at 2022-06-22 06:04:53.979639
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert isinstance(if_then_else_from_json_schema({'if': {}, 'then': {}}, {}), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({'if': {}, 'else': {}}, {}), IfThenElse)
    assert isinstance(if_then_else_from_json_schema({'if': {}, 'then': {}, 'else': {}}, {}), IfThenElse)



# Generated at 2022-06-22 06:05:05.697067
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {
        "$id": "http://example.com/schemas/string.json",
        "$schema": "http://json-schema.org/draft/2019-09/schema",
        "title": "A JSON Schema for a string value",
        "type": "string"
    }
    field = from_json_schema(schema)
    assert str(field) == 'Any(String(), min_length=None, max_length=None)'


# Generated at 2022-06-22 06:05:17.909714
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Test a string type.
    field = from_json_schema_type(
        data={"type": "string", "minLength": 0, "maxLength": 3},
        type_string="string",
        allow_null=False,
        definitions=definitions,
    )
    assert field.validate("ab") == "ab"
    assert field.validate("") == ""
    assert field.validate("abcd") == "abcd"
    assert field.validate(["ab"]) == ["ab"]
    assert field.validate(["ab", "c"]) == ["ab", "c"]
    assert field.validate(["a", "bc"]) == ["a", "bc"]
    assert field.validate({"a": "b"}) == {"a": "b"}

# Generated at 2022-06-22 06:05:28.236859
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    x = not_from_json_schema(
        {
            "title": "AllOfSchema",
            "description": "A schema which must match all of the provided schemas",
            "type": "object",
            "properties": {
                "allOf": {
                    "title": "All Of",
                    "description": "A list of schemas, all of which must match",
                    "type": "array",
                    "items": {},
                    "minItems": 1,
                    "uniqueItems": True,
                }
            },
            "required": ["allOf"],
            "additionalProperties": False,
        },
        definitions=[],
    )
    print(x)



# Generated at 2022-06-22 06:05:38.662962
# Unit test for function from_json_schema
def test_from_json_schema():
    definitions = SchemaDefinitions()
    assert from_json_schema({
        "$ref": "#/definitions/name",
    }, definitions=definitions) == Reference("name", definitions=definitions)

    assert from_json_schema({
        "definitions": {
            "name": {
                "type": "string",
                "minLength": 0,
            },
        },
        "$ref": "#/definitions/name",
    }, definitions=definitions) == String(min_length=0)

    assert from_json_schema({
        "type": "string",
    }) == String()

    assert from_json_schema({
        "type": ["string", "integer"],
    }) == String() | Integer()


# Generated at 2022-06-22 06:05:45.643211
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({"$ref": "#/definitions/foo"}), Reference)



# Generated at 2022-06-22 06:05:48.772378
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, 'number') == Float()
    assert from_json_schema_type({}, 'integer') == Integer()
    assert from_json_schema_type({}, 'string') == String()
    assert from_json_schema_type({}, 'boolean') == Boolean()
    assert from_json_schema_type({}, 'array') == Array()
    assert from_json_schema_type({}, 'object') == Object()
 

# Generated at 2022-06-22 06:05:50.641130
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="123")) == {'default': '123'}



# Generated at 2022-06-22 06:06:00.547977
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)

    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean", "null"}, True)

    assert get_valid

# Generated at 2022-06-22 06:06:12.440025
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    test_obj = JSONSchema.bind({})
    assert isinstance(type_from_json_schema(test_obj, definitions=None), Any)

    test_obj = JSONSchema.bind(
        {
            "type": "string",
            "pattern": "\\d+",
            "minLength": 2,
            "maxLength": 2,
            "minItems": 2,
            "maxItems": 2,
        }
    )
    assert isinstance(
        type_from_json_schema(test_obj, definitions=None),
        Choice,
    )
