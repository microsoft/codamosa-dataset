

# Generated at 2022-06-22 05:58:08.101859
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.schemas import Reference, Schema
    from typesystem.fields import (
        Any,
        Array,
        Boolean,
        Choice,
        Const,
        Decimal,
        Float,
        Integer,
        Number,
        Object,
        String,
        Union,
    )
    from typesystem.composites import AllOf, NeverMatch, Not, OneOf


# Generated at 2022-06-22 05:58:16.891423
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {
        '$id': 'https://example.com/person.schema.json',
        '$schema': 'http://json-schema.org/draft-07/schema#',
        'title': 'Person',
        'type': 'object',
        'properties': {
            'firstName': {
                'type': 'string',
                'description': 'The person\'s first name.',
            },
            'lastName': {
                'type': 'string',
                'description': 'The person\'s last name.',
            },
            'age': {
                'description': 'Age in years which must be equal to or greater than zero.',
                'type': 'integer',
                'minimum': 0,
            },
        },
    }

# Generated at 2022-06-22 05:58:28.707989
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    definitions = SchemaDefinitions()
    if_schema = {'type': 'string', 'minLength': 3}
    then_schema = {'type': 'string', 'enum': ['yes']}
    else_schema = {'type': 'string', 'enum': ['no']}

    if_schema_field = from_json_schema(if_schema, definitions=definitions)
    then_schema_field = from_json_schema(then_schema, definitions=definitions)
    else_schema_field = from_json_schema(else_schema, definitions=definitions)

    ite_field = IfThenElse(if_clause=if_schema_field, then_clause=then_schema_field, else_clause=else_schema_field)

# Generated at 2022-06-22 05:58:39.390767
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "type": "object",
        "oneOf": [
            {"type": "number"},
            {"type": "integer"},
            {"enum": ["a", "b"]},
            {"const": "c"},
        ],
    }
    assert from_json_schema(data).validate(1.1) is None
    assert from_json_schema(data).validate(1) is None
    assert from_json_schema(data).validate("a") is None
    assert from_json_schema(data).validate("b") is None
    assert from_json_schema(data).validate("c") is None
    assert from_json_schema(data).validate("d")
    assert from_json_schema(data).validate(1.1) is None

# Generated at 2022-06-22 05:58:45.566029
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        'anyOf': [
            {
                "type": "number"
            },
            {
                "type": "null"
            }
        ]
    }
    definitions = SchemaDefinitions()
    any_of_from_json_schema(data, definitions)
    assert (definitions["#/anyOf/0"].required) == None 
    assert (definitions["#/anyOf/1"].required) == None 



# Generated at 2022-06-22 05:58:57.242288
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "type": "object",
        "required": ["a"],
        "properties": {
            "a": {"type": "integer", "minimum": 5, "maximum": 10},
            "b": {"type": "string", "minLength": 2, "maxLength": 4},
        },
        "patternProperties": {
            "^\\d{4}-\\d{2}-\\d{2}$": {"type": "string", "format": "date-time"}
        },
        "minProperties": 1,
        "maxProperties": 4,
        "additionalProperties": False,
    }
    output = from_json_schema(data)


# Generated at 2022-06-22 05:59:08.735079
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data ={
        "default": [],
        "not": {
            "allOf": [
                {
                    "default": [],
                    "type": "array",
                    "items": {
                        "$ref": "#/definitions/Foo",
                        "default": {}
                    }
                },
                {
                    "default": [],
                    "type": "array",
                    "items": {
                        "const": {"foo": "bar"},
                        "default": {}
                    }
                }
            ]
        }
    }
    definitions = SchemaDefinitions()
    definitions["Foo"] = Object()
    res = not_from_json_schema(data, definitions)
    print(res)

# Generated at 2022-06-22 05:59:15.349775
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "$ref": "#/definitions/address",
    }
    definitions = SchemaDefinitions()
    definitions["#/definitions/address"] = Any()
    assert isinstance(
        to_json_schema(from_json_schema(json_schema, definitions=definitions)), dict
    )


# Generated at 2022-06-22 05:59:20.310999
# Unit test for function get_standard_properties
def test_get_standard_properties():
    try:
        get_standard_properties(None)
        assert False, "Expected assertion to fail"
    except ValueError:
        pass
    assert get_standard_properties(Integer(default=1)) == {'default': 1}
    assert get_standard_properties(Integer(default=None)) == {}
    assert get_standard_properties(Integer(default=NO_DEFAULT)) == {}



# Generated at 2022-06-22 05:59:22.198837
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": True}
    assert isinstance(const_from_json_schema(data, None), Field)



# Generated at 2022-06-22 06:00:21.838588
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        '$schema': 'http://json-schema.org/draft-07/schema',
        '$id': 'http://example.com/product.schema.json',
        'title': 'Product',
        'description': 'A product from Acme\'s catalog',
        'type': 'object',
        'properties': {
            'name': {'type': 'string'},
            'price': {'type': 'number'},
            'category': {
                'type': 'string',
                'enum': ['fruit', 'vegetable', 'meat']}
        }
    }
    output = not_from_json_schema(data, definitions=None)

# Generated at 2022-06-22 06:00:26.577407
# Unit test for function get_standard_properties
def test_get_standard_properties():
    value = get_standard_properties(Const.make_validator())
    assert value == {}
    value = get_standard_properties(Const.make_validator(default=False))
    assert value == {"default": False}
    value = get_standard_properties(Const.make_validator(default=NO_DEFAULT))
    assert value == {}
    value = get_standard_properties(Const.make_validator(default=None))
    assert value == {"default": None}
    value = get_standard_properties(Const.make_validator(default=UNSET))
    assert value == {"default": None}
    value = get_standard_properties(Const.make_validator(default=False))
    assert value == {"default": False}
    value = get_standard_properties(Const.make_validator(default=True))


# Generated at 2022-06-22 06:00:34.347849
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem import from_json_schema

    schema = from_json_schema(
        {
            "$ref": "#/definitions/Pet",
            "definitions": {
                "Pet": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "age": {"type": "number"},
                    },
                }
            },
        }
    )

    assert isinstance(schema, Schema)
    assert not schema.validate({"name": "Tiger", "age": 2})
    assert schema.validate({"name": "Tiger", "age": "2"})



# Generated at 2022-06-22 06:00:44.981242
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="Hi")) == {"default": "Hi"}
    assert get_standard_properties(String(default=None)) == {}
    assert get_standard_properties(Integer(default=2)) == {"default": 2}
    assert get_standard_properties(Integer(default=None)) == {}
    assert get_standard_properties(Array(default=[])) == {"default": []}
    assert get_standard_properties(Array(default=None)) == {}
    assert get_standard_properties(Object(default={})) == {"default": {}}
    assert get_standard_properties(Object(default=None)) == {}
    assert get_standard_properties(Boolean(default=True)) == {"default": True}
    assert get_standard_properties(Boolean(default=None)) == {}
    assert get_standard_

# Generated at 2022-06-22 06:00:54.547042
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    """
    Test function enum_from_json_schema
    """
    field = enum_from_json_schema({"enum": ["a", "b"]})
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"
    assert field.validate("c") == ["Must be one of ['a', 'b']."]



# Generated at 2022-06-22 06:01:00.932240
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    if_clause = {"type": "integer", "minimum": 0}
    then_clause = {"type": "integer", "maximum": 100}
    else_clause = {"type": "integer"}
    schema = {"if": if_clause, "then": then_clause, "else": else_clause}

    inferred = if_then_else_from_json_schema(schema, None)

    assert inferred == IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Integer(maximum=100),
        else_clause=Integer(),
    )



# Generated at 2022-06-22 06:01:13.719129
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, None) == Any()
    assert type_from_json_schema({"type": "boolean"}, None) == Boolean()
    assert type_from_json_schema({"type": "null"}, None) == Const(None)
    assert type_from_json_schema({"type": "number"}, None) == Number()
    assert type_from_json_schema({"type": "integer"}, None) == Integer()

    assert type_from_json_schema({"type": "string"}, None) == String()
    assert type_from_json_schema(
        {"type": "string", "format": "date-time"}, None
    ) == String(format="date-time")

    assert type_from_json_schema({"type": "array"}, None) == Array()

# Generated at 2022-06-22 06:01:18.693085
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":
            [
                {"type": "integer"},
                {"type": "string"},
            ]
    }
    field = any_of_from_json_schema(data, definitions=definitions)
    assert field.validate(1) == 1
    assert field.validate("1") == "1"


# Generated at 2022-06-22 06:01:27.288060
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String().default("abc")) == {"default": "abc"}
    assert get_standard_properties(String().default_factory(lambda: "abc")) == {
        "default": "abc"
    }
    assert get_standard_properties(Integer().default(1)) == {"default": 1}
    assert get_standard_properties(Boolean().default(True)) == {"default": True}
    assert get_standard_properties(Array(String()).default(["abc"])) == {
        "default": ["abc"]
    }
    assert get_standard_properties(Object({"abc": String()}).default({"abc": "123"})) == {
        "default": {"abc": "123"}
    }

# Generated at 2022-06-22 06:01:32.267219
# Unit test for function to_json_schema

# Generated at 2022-06-22 06:02:56.057721
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    field = type_from_json_schema({"type": "string"})
    assert isinstance(field, String)
    assert field.allow_null is False

    field = type_from_json_schema(
        {"type": ["null", "string"]},
    )
    assert isinstance(field, Union)
    assert field.any_of[0].allow_null is False
    assert field.any_of[1].allow_null is True

    field = type_from_json_schema(
        {"type": "integer", "minimum": 5},
    )
    assert isinstance(field, Integer)
    assert field.allow_null is False
    assert field.minimum is 5

    field = type_from_json_schema(
        {"type": "integer", "minimum": 5},
    )

# Generated at 2022-06-22 06:02:59.995249
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema(data={"anyOf":[{"type":"string"}]}, definitions=None).validate('test') == 'test'
# END Unit test for function any_of_from_json_schema



# Generated at 2022-06-22 06:03:06.602615
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "integer"},
            {"type": "string"},
        ]
    }
    field = from_json_schema(schema)
    valid_types = ["null", "integer", "string"]
    assert field.validate(None) == True
    assert field.validate(5) == True
    assert field.validate("5") == True
    assert field.validate(5.5) == False



# Generated at 2022-06-22 06:03:18.312235
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": "string"}
    assert isinstance(type_from_json_schema(data, definitions=None), String)

    data = {"type": "string", "nullable": True}
    assert isinstance(type_from_json_schema(data, definitions=None), Union)
    assert isinstance(type_from_json_schema(data, definitions=None).any_of[0], String)
    assert isinstance(type_from_json_schema(data, definitions=None).any_of[1], Const)
    assert type_from_json_schema(data, definitions=None).any_of[1].value == None

    data = {"type": "string", "nullable": True, "enum": ["str"]}

# Generated at 2022-06-22 06:03:21.202405
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    oneOf = [
        {'type': 'string', 'minLength': 2},
        {"type": "number", "multipleOf": 10},
        {"type": "number", "multipleOf": 13}
    ]
    assert isinstance(one_of_from_json_schema({'oneOf': oneOf}, None), OneOf) is True


# Generated at 2022-06-22 06:03:32.520992
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"number", "object", "null", "integer", "array", "string", "boolean"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": ["string"]}) == ({"string"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["number"]}) == ({"number"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": ["integer"]}) == ({"integer"}, False)

# Generated at 2022-06-22 06:03:34.061143
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({"const": 1})(1)



# Generated at 2022-06-22 06:03:44.743444
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {'allOf': [
        {'type': 'string', 'minLength': 2, 'maxLength': 5},
        {'enum': ["Tom", "Jerry"]}
    ]}
    field = all_of_from_json_schema(schema)
    assert field.validate("Tom")

    schema = {'allOf': [
        {'type': 'string'},
        {'enum': ["Tom", "Jerry"]}
    ]}
    field = all_of_from_json_schema(schema)
    assert field.validate("Tom")
    assert field.validate("Tommy")
    assert not field.validate("Tommy1")


# Generated at 2022-06-22 06:03:51.188630
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():

    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Test Type",
        "type": ["string", "null"],
        "enum": ["Hello", "World", "!"],
        "default": "Hello",
    }

    field = from_json_schema(data)
    assert field.name == "Test Type"
    assert field.allow_null
    assert field.default == "Hello"
    assert isinstance(field, Choice)
    assert field.choices == [("Hello", "Hello"), ("World", "World"), ("!", "!")]



# Generated at 2022-06-22 06:03:57.016045
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {'oneOf': [{'type': 'string'}, {'type': 'integer'}], 'default': 'cool'} # , 'default': 'cool'
    definitions = SchemaDefinitions()
    print(one_of_from_json_schema(data, definitions))
test_one_of_from_json_schema()



# Generated at 2022-06-22 06:04:35.988006
# Unit test for function get_valid_types
def test_get_valid_types():
    test_cases = [
        {
            "type": "string",
            "expected_type_strings": {"string"},
            "expected_allow_null": False
        },
        {
            "type": "null",
            "expected_type_strings": set(),
            "expected_allow_null": True
        },
        {
            "type": ["string", "null"],
            "expected_type_strings": {"string"},
            "expected_allow_null": True
        },
    ]
    for test_case in test_cases:
        type_strings, allow_null = get_valid_types(test_case)
        assert type_strings == test_case["expected_type_strings"]
        assert allow_null == test_case["expected_allow_null"]



# Generated at 2022-06-22 06:04:47.435589
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"enum": [1, 2, 3]}) == enum_from_json_schema({"enum": [1, 2, 3]})

    assert from_json_schema({"allOf": [{"type": "integer"}, {"minimum": 0}]}) == all_of_from_json_schema({"allOf": [{"type": "integer"}, {"minimum": 0}]})

    assert from_json_schema({"if": {"type": "integer"}, "then": {"minimum": 0}}) == if_then_else_from_json_schema({"if": {"type": "integer"}, "then": {"minimum": 0}})

    assert from_json_schema

# Generated at 2022-06-22 06:04:56.539805
# Unit test for function from_json_schema
def test_from_json_schema():
    from typesystem.composites import Equal, Greater, Less
    from typesystem.composites import IfThenElse, Not, OneOf
    from typesystem.fields import Any, Boolean, Choice, Const, Integer, Number, String
    from typesystem.schemas import Reference, SchemaDefinitions

    definitions = SchemaDefinitions()

    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == Not(Any())
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({}) == Any()

    assert from_json_schema({"enum": []}) == Not(Any())

# Generated at 2022-06-22 06:04:59.392296
# Unit test for function get_valid_types
def test_get_valid_types():
    data = {"type": "string"}
    assert get_valid_types(data) == ({'string'}, False)



# Generated at 2022-06-22 06:05:07.034418
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "null"}) == ({'null'}, True)
    assert get_valid_types({"type": "object"}) == ({'object'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer', 'number'}, False)
    assert get_valid_types({"type": "any"}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)

# Generated at 2022-06-22 06:05:19.785198
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": None}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": ["string", "number"]}) == ({'number', 'string'}, False)
    assert get_valid_types({"type": ["null", "number"]}) == ({'number'}, True)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": ["null", "integer"]}) == ({'integer'}, True)
    assert get_valid_types({"type": ["null", "number"]}) == ({'number'}, True)

# Generated at 2022-06-22 06:05:30.888877
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type(data={"type": "string"}, type_string="string", allow_null=False, definitions=None), Field)
    assert isinstance(from_json_schema_type(data={"type": "integer"}, type_string="integer", allow_null=False, definitions=None), Field)
    assert isinstance(from_json_schema_type(data={"type": "number"}, type_string="number", allow_null=False, definitions=None), Field)
    assert isinstance(from_json_schema_type(data={"type": "array"}, type_string="array", allow_null=False, definitions=None), Field)

# Generated at 2022-06-22 06:05:39.576768
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
#     data = [{"type":"string"}, {"type":"number"}]
    data = {"oneOf": [{"type":"integer"}, {"type":"number"}]}
    definitions = {}
    field = one_of_from_json_schema(data=data, definitions=definitions)
    print(field)
    assert field.validate(0.1) == 0.1
    assert field.validate(0) == 0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.1) == 0.1
    assert field.validate(-0.1) == -0.1
    assert field.validate(-1.1) == -1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-22 06:05:53.550619
# Unit test for function from_json_schema_type
def test_from_json_schema_type():  # pragma: no cover
    from_json_schema_type(
        data={},
        type_string="number",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    from_json_schema_type(
        data={},
        type_string="integer",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    from_json_schema_type(
        data={},
        type_string="string",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )
    from_json_schema_type(
        data={},
        type_string="boolean",
        allow_null=False,
        definitions=SchemaDefinitions(),
    )

# Generated at 2022-06-22 06:05:57.009107
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {"enum": [True, False], "default": False}
    field = enum_from_json_schema(schema, definitions)
    assert field.validate(data=True) == True
    assert field.default == False


# Generated at 2022-06-22 06:06:49.378890
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"type": "string"}}
    field = not_from_json_schema(schema, definitions)
    assert field._negated.__class__ == String
