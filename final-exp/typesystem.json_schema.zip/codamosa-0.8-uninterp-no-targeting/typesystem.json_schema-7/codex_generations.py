

# Generated at 2022-06-22 05:58:08.726702
# Unit test for function to_json_schema
def test_to_json_schema():
    """Unit testing for to_json_schema"""
    assert to_json_schema(Any()) == True
    assert to_json_schema(NeverMatch()) == False
    assert to_json_schema(String()) == {
        "type": "string"
    }
    assert to_json_schema(String().allow_null()) == {
        "type": ["string", "null"]
    }
    assert to_json_schema(String().min_length(1)) == {
        "type": "string",
        "minLength": 1
    }
    assert to_json_schema(String().max_length(1)) == {
        "type": "string",
        "maxLength": 1
    }

# Generated at 2022-06-22 05:58:12.497487
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = String()
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}, definitions) == String()



# Generated at 2022-06-22 05:58:16.704485
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = OneOf(one_of=[Integer(), String()])
    schema.validate(1)
    assert schema.validate(2) == False
    assert schema.validate("a") == True


# Generated at 2022-06-22 05:58:28.672266
# Unit test for function to_json_schema
def test_to_json_schema():

    field = Any()
    schema = to_json_schema(field)
    assert isinstance(schema, bool) and schema is True, schema

    field = NeverMatch()
    schema = to_json_schema(field)
    assert isinstance(schema, bool) and schema is False, schema

    field = String(min_length=1, max_length=10, allow_null=True)
    schema = to_json_schema(field)
    assert schema == {
        "type": ["string", "null"],
        "minLength": 1,
        "maxLength": 10,
    }

    field = Choice(choices=[("a", "a"), ("b", "b")], allow_null=True)
    schema = to_json_schema(field)

# Generated at 2022-06-22 05:58:34.174504
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({
        "type": "string",
        "maxLength": 18,
    }) == String(max_length=18)
    assert isinstance(type_from_json_schema({
        "type": "string",
        "maxLength": 18,
    }), Field)



# Generated at 2022-06-22 05:58:45.229735
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": [None, "string"]}) == ({'string'}, False)
    assert get_valid_types({"type": ["string", None]}) == ({'string'}, False)
    assert get_valid_types({"type": None}) == ({'number', 'string', 'array', 'object', 'boolean'}, False)
    assert get_valid_types({"type": "integer"}) == ({'integer'}, False)
    assert get_valid_types({"type": "integer", "multipleOf": 1.5}) == ({'integer'}, False)

# Generated at 2022-06-22 05:58:57.243460
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    complex_schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/example.json",
        "type": "object",
        "title": "The Root Schema",
        "required": ["number", "integer"],
        "properties": {
            "number": {
                "type": "number",
                "title": "The Number Schema",
                "default": 0.0,
                "examples": [0.0],
            },
            "integer": {
                "type": "integer",
                "title": "The Integer Schema",
                "default": 8,
                "examples": [8],
            },
        },
    }


# Generated at 2022-06-22 05:59:00.863660
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}]}
    defn=SchemaDefinitions()
    any_of_field = any_of_from_json_schema(data, defn)
    assert isinstance(any_of_field, Union)
    assert any_of_field.any_of[0].type_name == "string"
    assert any_of_field.any_of[1].type_name == "integer"


# Generated at 2022-06-22 05:59:05.202164
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema(
        {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "string",
            "enum": ["a", "b", "c"],
            "default": "a",
        },
        definitions=None,
    ) == Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], default="a")



# Generated at 2022-06-22 05:59:12.396848
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf":[{"const":1},{"const":3},{"const":5}]}
    def test_ideal(field_name = '', field = any_of_from_json_schema(data, SchemaDefinitions())):
        assert field_name == '', 'AnyOf field name should be empty'
        assert isinstance(field, Union), 'AnyOf field type should be AnyOf'
        for field_item in field.any_of:
            assert isinstance(field_item, Const), 'AnyOf field item type should be Const'
            assert field_item.const in [1,3,5], 'AnyOf field item const should be 1,3,5'
        return 'passed'
    assert test_ideal() == 'passed', 'test_any_of_from_json_schema() assert #1 has failed'



# Generated at 2022-06-22 06:00:02.315760
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    from typesystem import String
    string_schema = String(const="Apple")
    data = {
        "type": "string",
        "const": "Apple",
    }
    to_data = to_json_schema(string_schema)
    assert to_data == data
    field = from_json_schema(data)
    to_data = to_json_schema(field)
    assert to_data == data


# Generated at 2022-06-22 06:00:14.546876
# Unit test for function to_json_schema
def test_to_json_schema():
    from . import (
        make_schema,
        make_schema_definitions,
        json_schema_test_case,
        validate_to_json_schema,
    )


# Generated at 2022-06-22 06:00:20.482023
# Unit test for function get_standard_properties
def test_get_standard_properties():
    for default in [0, 1, 2.4, "a", True, False, None]:
        field = Field(default=default)
        data = get_standard_properties(field)
        assert len(data) == 1
        assert "default" in data
        assert data["default"] == default

    field = Field(default=NO_DEFAULT)
    data = get_standard_properties(field)
    assert len(data) == 0
    assert "default" not in data



# Generated at 2022-06-22 06:00:26.391766
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": ["boolean", "null"]}) == ({"boolean"}, True)
    assert get_valid_types({"type": ["null", "boolean"]}) == ({"boolean"}, True)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": ["integer", "object"]}) == ({"integer", "object"}, False)



# Generated at 2022-06-22 06:00:29.596405
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {'const': 2}
    field = const_from_json_schema(data, [])
    assert isinstance(field, Const)
    assert field.const == 2



# Generated at 2022-06-22 06:00:39.102578
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert issubclass(ref_from_json_schema({"$ref": "#/definitions/A"}, {}).__class__, Field)
    # Testing that a special $ref style is supported.
    assert issubclass(ref_from_json_schema({"$ref": "#/properties/a/properties/b"}, {}).__class__, Field)

    with pytest.raises(AssertionError) as error_info:
        ref_from_json_schema({"$ref": "http://example.com/schema"}, {})
    assert "Unsupported $ref style in document" in str(error_info.value)



# Generated at 2022-06-22 06:00:48.112501
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    unit = OneOf(
        {"a valid integer": Integer(minimum=1, exclusive_maximum=10)},
        {"a valid string": String(enum=["foo", "bar", "baz"])},
        {"a valid array": Array(items=String(), min_items=2)},
    )
    assert (one_of_from_json_schema(data={
        'oneOf': [{
            'type': 'integer',
            'minimum': 1,
            'exclusiveMaximum': 10
        }, {
            'type': 'string',
            'enum': ['foo', 'bar', 'baz']
        }, {
            'type': 'array',
            'items': {'type': 'string'},
            'minItems': 2
        }]
    }, definitions={}) == unit)
    
    


# Generated at 2022-06-22 06:00:52.713319
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any())
    assert to_json_schema(NeverMatch()) is False
    assert to_json_schema(String()) == {
        "type": "string",
        "default": NO_DEFAULT,
        "nullable": None,
        "write_only": None,
        "read_only": None,
    }
    assert to_json_schema(Integer()) == {
        "type": "integer",
        "default": NO_DEFAULT,
        "nullable": None,
        "write_only": None,
        "read_only": None,
    }

# Generated at 2022-06-22 06:01:00.970795
# Unit test for function to_json_schema
def test_to_json_schema():
    from wsgi_schematics_example.schema import Person


# Generated at 2022-06-22 06:01:13.770416
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {
        "$id": "https://example.com/geographical-location.schema.json",
        "$schema": "http://json-schema.org/draft-07/schema#",
        "description": "A geographical location",
        "type": "object",
        "properties": {
            "latitude": {
                "type": "number",
                "description": "A latitude",
                "minimum": -90,
                "maximum": 90,
            },
            "longitude": {
                "type": "number",
                "description": "A longitude",
                "minimum": -180,
                "maximum": 180,
            },
        },
        "required": ["latitude", "longitude"],
    }
    field = from_json_schema(data)

# Generated at 2022-06-22 06:01:35.591210
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "not": {
            "type": "integer",
            "enum": [1, 2, 3],
        }
    }
    assert not_from_json_schema(data, definitions=SchemaDefinitions()).function({}) == "not_from_json_schema_f1_v1"





# Generated at 2022-06-22 06:01:37.278086
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "number", allow_null=False, definitions=None), Float



# Generated at 2022-06-22 06:01:48.560889
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(Any) == True
    assert to_json_schema(NeverMatch) == False
    assert to_json_schema(
        String(
            const="Hello",
            min_length=3,
            max_length=3,
            pattern_regex=re.compile(r"^\d{3}$"),
            format="date-time",
        )
    ) == {
        "type": "string",
        "const": "Hello",
        "default": None,
        "minLength": 3,
        "maxLength": 3,
        "pattern": "^\\\\d{3}$",
        "format": "date-time",
        "title": None,
        "description": None,
    }

# Generated at 2022-06-22 06:01:51.715900
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_field = not_from_json_schema(
        data={"not": {"type": "string", "minLength": 5}}, definitions=SchemaDefinitions()
    )
    assert test_field.validate("") is True
    assert test_field.validate("123") is True
    assert test_field.validate("12345") is False



# Generated at 2022-06-22 06:01:55.643852
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": ["a", "b", "c"]}) == Choice(
        choices=[("a", "a"), ("b", "b"), ("c", "c")]
    )
    assert enum_from_json_schema(
        {"enum": ["a", "b", "c"], "default": "b"}
    ) == Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], default="b")



# Generated at 2022-06-22 06:02:00.523387
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
	definitions = SchemaDefinitions()
	assert not_from_json_schema({"not": {"type": "boolean"}}, definitions=definitions) == Not(negated=Boolean())
	# End unit test for function not_from_json_schema

# Generated at 2022-06-22 06:02:09.118135
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type(
        type_from_json_schema(
            data={"type": "string"}, definitions=SchemaDefinitions()
        )
    ) == String
    assert type(
        type_from_json_schema(
            data={"type": "boolean"}, definitions=SchemaDefinitions()
        )
    ) == Boolean
    assert type(
        type_from_json_schema(
            data={"type": "integer"}, definitions=SchemaDefinitions()
        )
    ) == Integer
    assert type(
        type_from_json_schema(
            data={"type": "number"}, definitions=SchemaDefinitions()
        )
    ) == Float

# Generated at 2022-06-22 06:02:19.672808
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem import Schema
    from .utils import validate_file
    import json
    import os
    import pkg_resources
    import tempfile
    import typesystem


# Generated at 2022-06-22 06:02:31.682098
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "string", "nullable": True}) == ({"string"}, True)
    assert get_valid_types({"type": "string", "nullable": False}) == ({"string"}, False)
    assert get_valid_types({"type": ["string"]}) == ({"string"}, False)
    assert get_valid_types({"type": ["string"], "nullable": True}) == ({"string"}, True)
    assert get_valid_types({"type": ["string"], "nullable": False}) == (
        {"string"},
        False,
    )
    assert get_valid_types({"type": ["null", "string"]}) == ({"string"}, True)

# Generated at 2022-06-22 06:02:33.986924
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema_data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "string",
        "if": {"type": "string"},
        "then": {
            "const": "then"
        }
    }

    from_json_schema(schema_data).validate("then")



# Generated at 2022-06-22 06:02:55.206702
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    # Check that Not(NeverMatch()) is Any()
    assert not_from_json_schema({"not": {}}, definitions=None) is Any()



# Generated at 2022-06-22 06:03:02.428459
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    schems = from_json_schema(
    {
        "$schema": "http://json-schema/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "description": "A product from Acme's catalog",
        "type": "object",
        "properties": {
            "productId": {"description": "The unique identifier for a product", "type": "integer"}
        },
        "$comment": "This is a comment."
    }
)
    input={'productId':1}
    assert schems.validate(input)==True
    input={'productId':"1"}
    assert schems.validate(input)==False


# Generated at 2022-06-22 06:03:10.135048
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {'type': 'object', 'properties': {'foo': {'type': 'string'}}, 'not': {'type': 'object', 'properties': {'foo': {'type': 'string'}}}}
    field = from_json_schema(schema)
    assert field.validate({'foo': 'bar'}) == {'input': {'foo': 'bar'}, 'errors': [], 'match': False}


# Generated at 2022-06-22 06:03:22.225459
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    import json
    schema = json.loads('''{
    "anyOf": [
        {
            "type": "number"
        },
        {
            "type": "string"
        }
    ]
}''')
    
    # Test valid case
    ret = any_of_from_json_schema(schema, None)
    assert isinstance(ret, Number) or isinstance(ret, String)

    # Test invalid case
    any_of = [any_of_from_json_schema({"type": "number"}, None), any_of_from_json_schema({"type":"boolean"}, None)]

# Generated at 2022-06-22 06:03:28.034102
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "integer"}]}
    assert one_of_from_json_schema(data, definitions=definitions).types == [Integer]


# Generated at 2022-06-22 06:03:33.513382
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    d = {"enum": list(range(5))}
    f = enum_from_json_schema(d, None)
    assert f.validate(0) == 0
    assert f.validate(1) == 1
    assert f.validate(4) == 4
    assert f.validate(5) == 5



# Generated at 2022-06-22 06:03:44.599977
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    # Object referencing a defined object
    json_schema = {
        "$ref": "#/definitions/Todo",
        "definitions": {
            "Todo": {
                "type": "object",
                "properties": {
                    "summary": {
                        "type": "string",
                        "maxLength": 140,
                    },
                    "priority": {
                        "type": "string",
                        "enum": ["High", "Medium", "Low"],
                    },
                    "done": {
                        "type": "boolean",
                    },
                },
                "required": ["summary", "priority"],
            },
        },
    }
    field = from_json_schema(json_schema)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/Todo"

# Generated at 2022-06-22 06:03:52.073324
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-22 06:04:03.655408
# Unit test for function to_json_schema
def test_to_json_schema():
    """
    Unit test function to_json_schema
    """
    integer_field = Integer()
    integer_schema = {
        "type": "integer",
        "default": None,
        "examples": [None],
        "nullable": True,
    }
    assert to_json_schema(integer_field) == integer_schema
    integer_field = Integer(minimum=0, maximum=100)
    integer_schema = {
        "type": "integer",
        "default": None,
        "examples": [None],
        "nullable": True,
        "minimum": 0,
        "maximum": 100,
    }
    assert to_json_schema(integer_field) == integer_schema

    string_field = String()

# Generated at 2022-06-22 06:04:14.351109
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        "if": {
            "properties": {
                "a": {"enum": [1, 2, 3]},  # If we see an a, we should see a b.
                "b": {"type": "boolean"},  # If we see a b, it should be a bool.
            },
            "required": ["a"],
        },
        "then": {
            "required": ["b"],
        },
    }
    field = if_then_else_from_json_schema(data=schema, definitions=None)
    assert field.validate({"a": 1}) is ValidationFailure
    assert field.validate({"a": 1, "b": 4}) is ValidationFailure
    assert field.validate({"a": 1, "b": True}) is ValidationSuccess
    assert field.valid

# Generated at 2022-06-22 06:04:35.809361
# Unit test for function get_standard_properties
def test_get_standard_properties():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestStandardProperties))
    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    if 'errors' in str(result) or 'failures' in str(result):
        sys.exit(1)



# Generated at 2022-06-22 06:04:43.078657
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({}) == Any()
    assert from_json_schema({"$ref": "#/definitions/integer"}) == Integer()
    assert from_json_schema({"$ref": "#/definitions/integer"}) != Float()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "string"}) != Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "object"}) == Object()

# Generated at 2022-06-22 06:04:53.866257
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    # Case 1
    data = {
        "$id": "https://example.com/person.schema.json",
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$ref": "#/definitions/person",
        "definitions": {
            "person": {
                "type": "object",
                "properties": {
                    "const": {
                        "type": "string",
                        "const": "john",
                    }
                }
            },
        }
    }
    definitions = SchemaDefinitions()
    definitions["https://example.com/person.schema.json"] = from_json_schema(data)
    obj = {
        "const": "john",
    }

# Generated at 2022-06-22 06:04:59.148345
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({
        'const': 1
    }).validate(1) == True
    assert const_from_json_schema({
        'const': 1
    }).validate(2) == False

# Integration test for function const_from_json_schema

# Generated at 2022-06-22 06:05:02.031012
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions["test"] = String()
    assert ref_from_json_schema({"$ref": "#/test"}, definitions) == Reference("#/test", definitions)



# Generated at 2022-06-22 06:05:11.034343
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [
            {"type": "number", "maximum": 10, "minimum": 0},
            {"type": "number", "maximum": 100, "minimum": 0},
        ]
    }
    field = all_of_from_json_schema(schema, [])
    assert isinstance(field, AllOf)
    assert len(field.all_of) == 2
    assert field.all_of[0].maximum == 10
    assert field.all_of[1].maximum == 100



# Generated at 2022-06-22 06:05:23.269297
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert Const(const='foo', default='foo').validate('foo')
    assert Const(const=123, default='foo').validate(123)
    assert Const(const=[1, 2, 3], default=[1, 2, 3]).validate([1, 2, 3])
    assert Const(const=True, default=True).validate(True)
    assert Const(const=None, default=None).validate(None)
    assert Const(const=None, default=None).validate(None)
    assert Const(const=False, default=False).validate(False)
    assert Const(const=1.0, default=1.0).validate(1.0)
    assert Const(const=['foo', 'bar'], default=['foo', 'bar']).validate(['foo', 'bar'])

# Generated at 2022-06-22 06:05:31.444565
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "null"}) == ({"null"}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "array"}) == ({"array"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)

    assert get_valid_types({"type": ["null"]}) == ({"null"}, True)

# Generated at 2022-06-22 06:05:36.037846
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert len(one_of_from_json_schema({"oneOf": []}, definitions).subschemas) == 0
    assert len(one_of_from_json_schema({"oneOf": [{}]}, definitions).subschemas) == 1
    assert len(one_of_from_json_schema({"oneOf": [{}, {}]}, definitions).subschemas) == 2



# Generated at 2022-06-22 06:05:41.396766
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    data = {'type': 'number'}
    type_string = 'number'
    allow_null = False
    definitions = None
    result = from_json_schema_type(
        data, type_string, allow_null, definitions
    )
    assert result.__class__.__name__ == 'Float'

    data = {'type': 'integer'}
    type_string = 'integer'
    allow_null = False
    definitions = None
    result = from_json_schema_type(
        data, type_string, allow_null, definitions
    )
    assert result.__class__.__name__ == 'Integer'

    data = {'type': 'string'}
    type_string = 'string'
    allow_null = False
    definitions = None
    result = from_json_schema_

# Generated at 2022-06-22 06:06:02.669023
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    return {
        "$ref": "#/definitions/Person",
        "definitions": {
            "Person": {
                "properties": {
                    "name": {"type": "string"},
                    "age": {"type": "integer"},
                }
            }
        },
    }



# Generated at 2022-06-22 06:06:13.338908
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$ref": "#/definitions/SomeAbstractClass",
        "definitions": {
            "SomeAbstractClass": {
                "type": "object",
                "properties": {
                    "foo": {
                        "type": "number",
                        "minimum": 0,
                        "maximum": 10
                    }
                },
                "required": [
                    "foo"
                ]
            }
        }
    }
    const = from_json_schema(data)
    assert const.validate("hello") is True
    assert const.validate("world") is True

# Generated at 2022-06-22 06:06:15.636738
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/foo"}).to == "#/definitions/foo"

# Generated at 2022-06-22 06:06:27.238658
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(True) == Any()
    assert from_json_schema(False) == NeverMatch()

    assert from_json_schema({"$ref": "#/definitions/person"}) == Reference("#/definitions/person")

    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": ["string", "null"]}) == OneOf([String(), Boolean(default=False)])


# Generated at 2022-06-22 06:06:31.406618
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    "Test function const_from_json_schema"

    const_fields = {
    "const": 42,
    "default": "default value for Const"
    }

    # test json_schema
    assert const_from_json_schema(const_fields, {}) == Const(const=42, default="default value for Const")



# Generated at 2022-06-22 06:06:40.799064
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=String(),
        default="",
    ) == from_json_schema(
        {
            "if": {"type": "boolean"},
            "then": {"type": "integer"},
            "else": {"type": "string"},
            "default": "",
        },
        definitions=SchemaDefinitions(),
    )

    assert IfThenElse(
        if_clause=Boolean(),
        then_clause=Integer(),
        else_clause=None,
        default="",
    ) == from_json_schema(
        {"if": {"type": "boolean"}, "then": {"type": "integer"}, "default": ""},
        definitions=SchemaDefinitions(),
    )



# Generated at 2022-06-22 06:06:52.373118
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    json_schema = {
        "type": "number",
        "minimum": 0,
        "maximum": 10,
        "exclusiveMinimum": 1,
        "exclusiveMaximum": 9,
        "multipleOf": 3,
    }
    assert from_json_schema_type(
        json_schema, type_string="number", allow_null=True, definitions={}
    ) == Float(
        allow_null=True,
        minimum=0,
        maximum=10,
        exclusive_minimum=1,
        exclusive_maximum=9,
        multiple_of=3,
    )


# Generated at 2022-06-22 06:07:04.003375
# Unit test for function get_valid_types
def test_get_valid_types():
    """
    should return a set of type strings and allow_null
    """
    data = {"type": "string"}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"string"}
    assert allow_null is False

    data = {"type": ["null", "boolean", "object", "array", "number", "string"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"boolean", "object", "array", "number", "string"}
    assert allow_null is True

    data = {"type": ["number", "integer"]}
    type_strings, allow_null = get_valid_types(data)
    assert type_strings == {"number"}
    assert allow_null is False
