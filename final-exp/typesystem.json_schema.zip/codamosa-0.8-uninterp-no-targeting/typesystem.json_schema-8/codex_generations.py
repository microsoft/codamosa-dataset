

# Generated at 2022-06-22 05:57:48.546468
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [
        {
            "type": "number",
            "minimum": 10
        },
        {
            "type": "number",
            "maximum": 10
        }
    ]}
    schema = one_of_from_json_schema(data, {})
    assert schema.validate(1) == [1.0, 1]
    assert schema.validate(10.0) == [10.0, 10]
    assert schema.validate('v') == ['v', 'v']
    
    

# Generated at 2022-06-22 05:57:54.408059
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema(
        {
            "allOf": [
                {"const": 1},
                {
                    "oneOf": [
                        {"type": "integer", "minimum": 1, "maximum": 10},
                        {"type": "integer", "minimum": 11, "maximum": 20},
                    ]
                },
            ]
        },
        None,
    ) == AllOf(
        [
            Const(1),
            OneOf(
                [
                    Integer(minimum=1, maximum=10),
                    Integer(minimum=11, maximum=20),
                ]
            ),
        ]
    )



# Generated at 2022-06-22 05:58:03.235563
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = Integer().set_default(5)
    assert get_standard_properties(field) == {"default": 5}
    field = Float().set_default(5)
    assert get_standard_properties(field) == {"default": 5}
    field = Decimal().set_default(5)
    assert get_standard_properties(field) == {"default": 5}
    field = String().set_default('5')
    assert get_standard_properties(field) == {"default": '5'}
    field = Boolean().set_default(True)
    assert get_standard_properties(field) == {"default": True}
    field = Array(Integer).set_default([5])
    assert get_standard_properties(field) == {"default": [5]}
    field = Object({}).set_default({"a": 1})

# Generated at 2022-06-22 05:58:08.056481
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert const_from_json_schema({'const': 5})
    assert const_from_json_schema({'const': '6'})
    assert const_from_json_schema({'const': '6', 'default': '7'})


# Generated at 2022-06-22 05:58:16.891188
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    from strict_rfc3339 import validate_rfc3339


# Generated at 2022-06-22 05:58:28.114893
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "description": "A product from Acme's catalog",
        "type": "object",
        "properties": {
            "productId": {
                "description": "The unique identifier for a product",
                "type": "integer"
            }
        },
        "required": ["productId"],
        "additionalProperties": False
    }
    field = from_json_schema(schema)
    assert str(field) == 'Not(Object({properties: Object({productId: Integer()})}))'


# Generated at 2022-06-22 05:58:34.141471
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data1 = {'allOf': [{'$ref': '#/definitions/equipment'}, {'$ref': '#/definitions/weapon'}]}
    data2 = {'allOf': [{'$ref': '#/definitions/weapon'}, {'$ref': '#/definitions/equipment'}]}
    assert all_of_from_json_schema(data1, definitions=definitions) == AllOf(all_of=[Reference(to='#/definitions/equipment', definitions=definitions), Reference(to='#/definitions/weapon', definitions=definitions)], default=NO_DEFAULT)

# Generated at 2022-06-22 05:58:41.608305
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-22 05:58:51.808096
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    json_schema = {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "integer"},
            "c": {"type": "integer"},
        },
        "if": {"required": ["a", "b"]},
        "then": {"required": ["c"]},
    }
    schema = from_json_schema(json_schema)
    assert isinstance(schema, Object)
    assert is_valid(schema, {"a": 1, "b": 2, "c": 3})
    assert not is_valid(schema, {"a": 1, "b": 2})
    assert not is_valid(schema, {"a": 1})
    assert not is_valid(schema, {"c": 3})
    assert not is_valid

# Generated at 2022-06-22 05:58:59.779970
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "type": "object",
        "properties": {
            "foo": {"type": "number", "minimum": 1, "maximum": 3},
            "bar": {"type": "number", "minimum": 1, "maximum": 4},
        },
        "not": {
            "type": "object",
            "properties": {
                "foo": {"type": "number", "minimum": 2, "maximum": 3},
                "bar": {"type": "number", "minimum": 1, "maximum": 3},
            },
        },
    }


# Generated at 2022-06-22 06:00:44.155935
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    pass
    # TODO: Write a unit test for function one_of_from_json_schema



# Generated at 2022-06-22 06:00:56.873588
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    test_data = {
                "allOf": [
                    {
                        "type": "number", 
                        "minimum": 8,
                        "const": 10
                    },
                    {
                        "type": "string",
                        "pattern": "^[A-Z]+$"
                    }
                ]
            }
    x = all_of_from_json_schema(test_data, definitions=definitions)
    assert x.default == NO_DEFAULT
    assert x.all_of[0].const == 10
    assert x.all_of[1].pattern == '^[A-Z]+$'



# Generated at 2022-06-22 06:01:08.914544
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "boolean"},
            {"const": True},
            {"enum": [True, False]},
            {"const": False}
        ]
    }
    any_of = [from_json_schema(item, definitions=definitions) for item in schema["anyOf"]]
    kwargs = {"any_of": any_of, "default": schema.get("default", NO_DEFAULT)}
    return Union(**kwargs)


# Generated at 2022-06-22 06:01:12.929372
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'array'}]}) == Union(any_of = [String(allow_blank = True, allow_null = True), Array(allow_null = True)])



# Generated at 2022-06-22 06:01:22.595193
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    from typesystem import types
    from typesystem import schemas
    from typesystem import validators
    from srsly.json import JSON
    import json

    data = {
        'type': 'string',
        'enum': ['foo', 'bar'],
        'default': 'bar',
    }
    field = Field(name='Field', type='string')
    field.required = True
    field.description = 'description'
    field.validators = [
        validators.Length(min=1, max=6),
        validators.Validator(lambda v: v != 'bar')
    ]

# Generated at 2022-06-22 06:01:27.327149
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    string_any = String(allow_null=True, allow_blank=True)
    string_above_3 = String(allow_null=True, min_length=4)
    string_with_min_length_above_3 = String(allow_null=True, min_length=4)
    string_with_min_length_above_3.default = 'abc'

    assert (
        IfThenElse(
            if_clause = string_above_3,
            then_clause = string_with_min_length_above_3,
            default='abc'
        )
        ==
        IfThenElse(
            if_clause = string_above_3,
            else_clause = string_with_min_length_above_3,
            default='abc'
        )
    )


# Generated at 2022-06-22 06:01:38.248711
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema =    {
        "oneOf": [
            {
                "type": "object",
                "properties": {
                    "foo": {
                        "type": "string",
                        "minLength": 1
                    }
                }
            },
            {
                "type": "object",
                "properties": {
                    "foo": {
                        "type": "string",
                        "maxLength": 0
                    }
                }
            }
        ]
    }
    schema = one_of_from_json_schema(schema, SchemaDefinitions())
    assert schema.validate({"foo": "bar"})
    assert not schema.validate({"foo": ""})
    assert schema.validate({})
    assert schema.validate(None)



# Generated at 2022-06-22 06:01:41.480035
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    expected = Union(any_of=[Any(), Integer()], allow_null=True)
    schema = {"anyOf": [{"type": ["string", "number"]}, {"type": "integer"}], "nullable": True}
    assert expected == any_of_from_json_schema(schema, definitions={})



# Generated at 2022-06-22 06:01:48.670779
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        False,
    )
    assert get_valid_types({"type": "null"}) == (
        {"null", "boolean", "object", "array", "number", "string"},
        True,
    )
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "boolean", "nullable": True}) == ({"boolean"}, True)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": "object", "nullable": True}) == ({"object"}, True)
    assert get_valid_types

# Generated at 2022-06-22 06:01:54.742934
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    schema = {
        'if': {'type': 'string'},
        'then': {'type': 'string'},
        'default': None,
    }
    field = if_then_else_from_json_schema(schema, SchemaDefinitions())
    assert field.validate("123")

    schema = {
        'if': {'type': 'string'},
        'then': {'type': 'string'},
        'else': {'type': 'integer'},
        'default': None,
    }
    field = if_then_else_from_json_schema(schema, SchemaDefinitions())
    assert field.validate("123")
    assert field.validate(123)
    assert field.validate(None)

# Generated at 2022-06-22 06:02:34.282897
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "string"}, {"type": "integer"}], "default": 1}
    assert any_of_from_json_schema(data, None).default == 1
    assert isinstance(any_of_from_json_schema(data, None), Union)



# Generated at 2022-06-22 06:02:40.333994
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string"}]}
    s = one_of_from_json_schema(data, definitions=None)
    assert isinstance(s, OneOf)
    assert s.one_of_string == ["string"]


# Generated at 2022-06-22 06:02:52.142296
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert if_then_else_from_json_schema({"if": {}}, None) == IfThenElse(
        IfThenElseField(if_clause=Any(), then_clause=None, else_clause=None)
    )

# Generated at 2022-06-22 06:02:56.641806
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from .schema_class_definitions import Integer
    assert get_standard_properties(Integer(default=0)) == {"default": 0}
    assert get_standard_properties(Integer(default=NO_DEFAULT)) == {}



# Generated at 2022-06-22 06:03:00.055628
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf':[{'type':'integer'}, {'type':'string'}]}
    assert isinstance(any_of_from_json_schema(data,None), Union)



# Generated at 2022-06-22 06:03:08.884926
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert enum_from_json_schema({"enum": [1, 2, 3]}) == Choice(choices=[(1, 1), (2, 2), (3, 3)])
    assert enum_from_json_schema({"enum": ["a", "b", "c"], "default": "b"}) == Choice(choices=[("a", "a"), ("b", "b"), ("c", "c")], default="b")



# Generated at 2022-06-22 06:03:20.218846
# Unit test for function get_valid_types
def test_get_valid_types():
    cases = [
        # Single type, no null
        ({"type": "string"}, {"string"}, False),
        # Single type, null included
        ({"type": ["string", "null"]}, {"string"}, True),
        # No type, null not included
        ({}, {"null", "boolean", "object", "array", "number", "string"}, False),
        # No type, null included
        ({"type": "null"}, set(), True),
    ]
    for json_schema, expected_types, expected_allow_null in cases:
        actual_types, actual_allow_null = get_valid_types(json_schema)
        assert actual_types == expected_types
        assert actual_allow_null == expected_allow_null



# Generated at 2022-06-22 06:03:31.673265
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    for type_string, expected_type in [
        (
            "number",
            Float,
        ),
        (
            "integer",
            Integer,
        ),
        (
            "string",
            String,
        ),
        (
            "boolean",
            Boolean,
        ),
        (
            "array",
            Array,
        ),
        (
            "object",
            Object,
        ),
    ]:
        data = {"type": type_string}
        result = from_json_schema_type(
            data, type_string=type_string, allow_null=False, definitions=None
        )
        assert isinstance(result, expected_type)
        assert result.allow_null == False
    data = {"type": "null"}

# Generated at 2022-06-22 06:03:37.680252
# Unit test for function to_json_schema
def test_to_json_schema():
    obj: Field = dict(
        is_required=True,
        properties=dict(
            str=str,
            int=int,
            float=float,
            array=list,
            obj=dict,
        ),
    )
    obj_schema = to_json_schema(obj)

# Generated at 2022-06-22 06:03:46.685810
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$ref": "#/definitions/Root",
        "definitions": {
            "Root": {
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "allOf": [
                            {"const": "test"},
                            {
                                "if": {
                                    "properties": {
                                        "name": {"const": "test"}
                                    }
                                },
                                "then": {"not": {"type": "boolean"}},
                            }
                        ]
                    }
                }
            }
        },
    }
    field = from_json_schema(schema)

# Generated at 2022-06-22 06:04:58.463776
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    assert isinstance(not_from_json_schema({"not": {"type": "number"}}, SchemaDefinitions()), Not)



# Generated at 2022-06-22 06:05:02.138537
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    input = {"type": "integer", "const": 2}
    expected = Not(Const(const=2))
    actual = not_from_json_schema(input, definitions={})
    assert actual == expected



# Generated at 2022-06-22 06:05:11.588620
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    """
    Unit tests for function from_json_schema_type.
    """
    json_schema = {
        "$id": "https://example.com/person.schema.json",
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Person",
        "type": "object",
        "properties": {
            "firstName": {"type": "string"},
            "lastName": {"type": "string"},
            "age": {"description": "Age in years", "type": "integer", "minimum": 0},
        },
    }
    expected_result = Object(
        {
            "firstName": String(),
            "lastName": String(),
            "age": Integer(minimum=0),
        }
    )
    result = from_json_

# Generated at 2022-06-22 06:05:24.089461
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from string import ascii_letters
    from vcr import VCR
    from json import loads
    from random import choice, sample
    from pprint import pprint
    from zlib import decompress
    import sys

    import typesystem
    from typesystem import Array, Integer

    WITH_RECORD = True
    VCR_CACHE = ".vcr_cache"

    req = ["type", "enum", "const", "allOf", "anyOf", "oneOf", "not", "if"]
    opt = [
        "definitions",
        "description",
        "title",
        "default",
        "examples",
        "$schema",
        "$id",
        "readOnly",
        "writeOnly",
        "contentMediaType",
        "contentEncoding",
    ]

# Generated at 2022-06-22 06:05:31.351500
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    schema = {
        "anyOf": [
            {"type": "string"},
            {"type": "integer"},
            {"type": "array", "items": {"type": "string"}},
        ]
    }
    typesystem_field = any_of_from_json_schema(schema, definitions=SchemaDefinitions())
    assert typesystem_field(input=1) == 1
    assert typesystem_field(input="2") == "2"
    assert typesystem_field(input=["3"]) == ["3"]



# Generated at 2022-06-22 06:05:45.453670
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(
        "field_name",
        description="blah blah blah",
        allow_blank=True,
        strip_whitespace=True,
        max_length=10,
        min_length=3,
        enum=["a", "b"],
    )
    assert get_standard_properties(field) == {}

    field = String(
        "field_name",
        description="blah blah blah",
        allow_blank=True,
        strip_whitespace=True,
        max_length=None,
        min_length=3,
        enum=["a", "b"],
    )
    assert get_standard_properties(field) == {}


# Generated at 2022-06-22 06:05:47.024339
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"type": "boolean"}}
    expected = Not(negated=Boolean())
    actual = not_from_json_schema(schema, definitions=SchemaDefinitions())
    assert actual == expected


# Generated at 2022-06-22 06:05:53.698059
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    val = {
        "allOf": [
            {"type": "integer", "minimum": 5},
            {"type": "integer", "maximum": 100},
        ]
    }
    expected = AllOf(
        all_of=[Integer(minimum=5), Integer(maximum=100)], default=NO_DEFAULT
    )
    schema = all_of_from_json_schema(val, definitions=None)
    assert expected == schema



# Generated at 2022-06-22 06:05:59.898436
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    # P1
    assert any_of_from_json_schema({
        'anyOf': [
            {
              '$ref': '#/definitions/string-type'
            },
            {
              'type': 'integer'
            }
          ]}, {'#/definitions/string-type': String()}) == Union(any_of=[String(), Integer()])
    # P2

# Generated at 2022-06-22 06:06:11.536215
# Unit test for function get_standard_properties
def test_get_standard_properties():
    class SomeSchema(Schema):
        def __init__(self):
            self.my_field = Field()

        def __repr__(self):
            return f"{type(self).__name__}()"

    schema = SomeSchema()

    data = get_standard_properties(schema.my_field)
    assert data == {}

    schema.my_field.default = 123
    data = get_standard_properties(schema.my_field)
    assert data == {"default": 123}

    # Make sure we don't break if the default has weird repr()
    class MyField(Field):
        def __repr__(self):
            raise ValueError("I'm weird")

    schema.my_field = MyField()
    schema.my_field.default = 123

# Generated at 2022-06-22 06:06:31.970491
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    #Test1:
    json_schema = {
        'allOf': [{'const': 'test'}, {'const': 'test_2'}, {'const': 'test_3'}]
    }
    all_of_schema = all_of_from_json_schema(json_schema, None)
    assert all_of_schema.validate('test_2') == 'test_2'
    assert all_of_schema.validate('test') == 'test'
    assert all_of_schema.validate('test_3') == 'test_3'
    assert all_of_schema.validate('other') == 'other'
    assert all_of_schema.validate('test4') == 'test4'


# Generated at 2022-06-22 06:06:42.385451
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(
        from_json_schema_type(
            {"type": "number", "minimum": -3, "maximum": 3, "exclusiveMinimum": True},
            type_string="number",
            allow_null=False,
            definitions=SchemaDefinitions(),
        ),
        Number,
    )
    assert isinstance(
        from_json_schema_type(
            {"type": "integer", "minimum": -3, "maximum": 3, "exclusiveMinimum": True},
            type_string="integer",
            allow_null=False,
            definitions=SchemaDefinitions(),
        ),
        Integer,
    )

# Generated at 2022-06-22 06:06:48.426463
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = {
        "$schema": "https://json-schema.org/draft-07/schema#",
        "$id": "https://example.com/arrays.schema.json",
        "description": "A representation of a person, company, organization, or place",
        "type": "object",
        "properties": {
            "address": {
                "description": "Physical address of the item.",
                "type": "string",
            }
        },
        "required": [
            "address"
        ]
    }
    result = enum_from_json_schema(data, definitions)
    assert result.description == "A representation of a person, company, organization, or place"
    assert result.type == "object"