

# Generated at 2022-06-22 05:57:39.847857
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {"not": {"type": "number"}}
    expected = Not(negated=Float(minimum=None, maximum=None))
    actual = not_from_json_schema(data, SchemaDefinitions())
    assert actual == expected


# Generated at 2022-06-22 05:57:50.137747
# Unit test for function get_standard_properties
def test_get_standard_properties():
    properties = {
        "type": "array",
        "default": [1, 2, 3],
        "enum": [1, 2, 3],
        "const": [1, 2, 3],
    }
    default_value = [1, 2, 3]
    default_value_2 = [1, 2, 4]
    bool_false = False
    bool_true = True
    integer_1 = 1
    integer_2 = 2
    integer_3 = 3
    string_1 = "1"
    string_2 = "2"
    string_3 = "3"
    string_4 = "4"
    float_1 = 1.1
    float_2 = 1.2
    float_3 = 1.3
    float_4 = 1.4
    data_1 = {"a": 1}
   

# Generated at 2022-06-22 05:58:00.054333
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    one_of = [
        {"type": "string"},
        {"type": "integer", "minimum": 0},
        {"type": "object", "properties": {"name": {"type": "string"}}},
    ]
    schema = one_of_from_json_schema({"oneOf": one_of}, definitions=definitions)
    assert schema.type == OneOf
    assert schema.one_of[0].type == String
    assert schema.one_of[1].type == Integer
    assert schema.one_of[2].type == Object



# Generated at 2022-06-22 05:58:04.448911
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    test_data = {
        "type": "object",
        "properties": {
            "integer": {"type": "integer"},
            "boolean": {"type": "boolean"},
            "string": {"type": "string"}
        },
        "not": {
            "type": "object",
            "properties": {
                "integer": {"type": "integer"},
                "boolean": {"type": "boolean"},
                "string": {"type": "string"}
            }
        }
    }
    assert not_from_json_schema(test_data) == Not(
        negated=Object(
            properties={
                "integer": Integer(),
                "boolean": Boolean(),
                "string": String()
            }
        )
    )



# Generated at 2022-06-22 05:58:12.346693
# Unit test for function from_json_schema
def test_from_json_schema():
    assert isinstance(from_json_schema({"minimum": 4}), Integer)
    assert isinstance(from_json_schema({"minimum": 4, "maximum": 10}), Integer)
    assert isinstance(from_json_schema({"maximum": 10}), Integer)
    assert isinstance(from_json_schema({"enum": [1, 2, 3]}), Choice)
    assert isinstance(from_json_schema({"allOf": [{"minimum": 4}, {"maximum": 10}]}), Integer)
    assert "If" in str(from_json_schema({"if": {"minimum": 4}, "then": {"maximum": 10}}))
    assert "Not" in str(from_json_schema({"not": {"minimum": 4}}))

# Generated at 2022-06-22 05:58:15.883437
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert one_of_from_json_schema({'oneOf': [{'type': 'integer'}, {'type': 'string'}]}, SchemaDefinitions()) == OneOf(one_of=[Integer(), String()])



# Generated at 2022-06-22 05:58:23.451668
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    json_schema_text = """{
        "$ref": "#/definitions/foo"
    }"""
    json_schema_data = to_json_schema()(json_schema_text)
    definitions = {
        "#/definitions/foo": String()
    }
    assert isinstance(from_json_schema(json_schema_data, definitions=definitions), String)



# Generated at 2022-06-22 05:58:32.128176
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema(
        {
            "type": "string",
            "minLength": 2,
            "maxLength": 8,
            "pattern": "\\d+",
            "enum": ["one", "two", "three"],
            "definitions": {
                "string_schema": {"type": "string"},
                "integer_schema": {"type": "integer"},
            },
        }
    ) == (
        String(min_length=2, max_length=8, pattern="\\d+")
        | Choice(
            of_value=["one", "two", "three"], of_type=String(min_length=2, max_length=8, pattern="\\d+")
        )
    )



# Generated at 2022-06-22 05:58:43.252816
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer", "minimum": 1}) == Integer(minimum=1)
    assert from_json_schema({"type": "integer", "multipleOf": 1}) == Integer()
    assert from_json_schema({"type": "integer", "multipleOf": 4}) == Integer(multiple_of=4)
    assert from_json_schema({"type": ["null", "integer"]}) == Union(any_of=[Integer()])

# Generated at 2022-06-22 05:58:55.427868
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    schema = {
        "allOf": [{"type": "integer", "minimum": 0}, {"type": "integer", "maximum": 10}],
    }
    field = from_json_schema(schema)
    assert field.types == [
        "<class 'typesystem.fields.Integer'>"
    ], "Field type should be Integer"
    assert field.minimum == 0, "Field minimum should be 0"
    assert field.maximum == 10, "Field maximum should be 10"
    assert field.check(0) is True
    assert field.check(0) is True
    assert field.check(11) is False



# Generated at 2022-06-22 05:59:33.014981
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{"type": "string", "pattern": "^[A-Z]+$"}, {"type": "string", "pattern": "^[0-9]+$"}]}
    definitions = SchemaDefinitions()
    field = one_of_from_json_schema(data, definitions)
    assert field.validate("FOO") == None
    assert field.validate("foo") == [{'code': 'invalid', 'field_name': 'oneOf', 'field_value': 'foo', 'message': 'Must match at least one of these types:', 'types': ['String(pattern=^[A-Z]+$)', 'String(pattern=^[0-9]+$)']}]

# Generated at 2022-06-22 05:59:36.148490
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = not_from_json_schema(
        {"not": {"enum": [1, 2, 3]}}, definitions=SchemaDefinitions()
    )
    assert validate(0, schema) == {"valid": True}
    assert validate(1, schema) == {
        "valid": False,
        "errors": [
            {
                "instance_path": "",
                "schema_path": "/not",
                "error_message": "Value 1 is one of the enumerated values (1, 2, 3).",
            }
        ],
    }



# Generated at 2022-06-22 05:59:47.296521
# Unit test for function to_json_schema
def test_to_json_schema():
    data = (
        {"type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "string"},
            "c": {"type": "number"}
        }
        }
    )
    schema = from_json_schema(data)
    assert to_json_schema(schema) == data

    to_json_schema(String())
    to_json_schema(String(pattern=re.compile("^[A-Za-z]+$")))
    to_json_schema(String(format="e-mail"))
    to_json_schema(Integer())
    to_json_schema(Float())
    to_json_schema(Boolean())
    to_json_schema(Array())
    to_json_schema

# Generated at 2022-06-22 05:59:58.270441
# Unit test for function all_of_from_json_schema

# Generated at 2022-06-22 06:00:10.796700
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": 0}) == (set(), False)
    assert get_valid_types({"type": "string"}) == ({"string"}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": "null", "type": "string"}) == ({"string"}, True)
    assert get_valid_types({"type": "null", "type": "string", "type": "integer"}) == (
        {"integer", "string"},
        True,
    )
    assert get_valid_types({"type": "null", "type": "integer"}) == (set(), True)

# Generated at 2022-06-22 06:00:21.036778
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # Test type_string only
    assert type_from_json_schema({}, {}) == Any()
    assert type_from_json_schema({"type": "string"}, {}) == String()
    assert type_from_json_schema({"type": "integer"}, {}) == Integer()
    assert type_from_json_schema({"type": "number"}, {}) == Number()
    assert type_from_json_schema({"type": "boolean"}, {}) == Boolean()
    assert type_from_json_schema({"type": "object"}, {}) == Object()
    assert type_from_json_schema({"type": "array"}, {}) == Array()
    assert type_from_json_schema({"type": "null"}, {}) == Const(None)

    # Test type_string with type constraints

# Generated at 2022-06-22 06:00:24.423296
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    with definitions.define("A") as A:
        A.properties = {"field": Any()}

    assert Any() == from_json_schema_type(data={}, type_string="string", allow_null=True, definitions=definitions)



# Generated at 2022-06-22 06:00:36.439222
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "anyOf": [
            {"type": "string"},
            {
                "type": "object",
                "properties": {
                    "number": {"type": "number"},
                    "string": {"type": "string"},
                    "boolean": {"type": "boolean"},
                },
            },
        ],
        "default": {
            "number": 1,
            "string": "foo",
            "boolean": False
        }
    }
    definitions = SchemaDefinitions()
    any_of = any_of_from_json_schema(data, definitions=definitions)
    assert any_of.serialize(None) is None
    assert any_of.serialize("abc") is "abc"

# Generated at 2022-06-22 06:00:51.744301
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    def test_case(ref: str, schema: typing.Union[Field, dict], expected: Field = None):
        if not isinstance(schema, dict):
            assert "$ref" not in schema
            schema = {"$ref": ref, **schema}
        definitions = SchemaDefinitions()
        definitions[ref] = schema
        field = ref_from_json_schema(schema, definitions)
        if expected is not None:
            assert isinstance(field, expected.__class__)
            # assert field.to == expected.to
        if isinstance(schema, dict):
            assert schema["$ref"] == field.to
        else:
            assert isinstance(field, Reference)
            assert field.to == ref
    test_case("#/definitions/User", {"type": "string"})
    test_case

# Generated at 2022-06-22 06:00:56.190433
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():

    data = {
        "oneOf": [
            {"type": "boolean"},
            {"type": "integer"},
        ],
    }

    field = one_of_from_json_schema(data, definitions)

    assert "null" in field.one_of[0].validate(None).errors
    assert "boolean" in field.one_of[0].validate(False).errors
    assert "boolean" in field.one_of[0].validate(True).errors
    assert "integer" in field.one_of[0].validate(1).errors
    assert "integer" in field.one_of[1].validate(5).errors

    assert "null" not in field.one_of[1].validate(None).errors

# Generated at 2022-06-22 06:02:00.719482
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    definitions = SchemaDefinitions()
    data = {"$ref": "#/definitions/foo"}
    field = ref_from_json_schema(data, definitions)
    assert field.__class__ == Reference
    assert field.to == "#/definitions/foo"
    assert field.definitions is definitions

# Generated at 2022-06-22 06:02:09.197201
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types(dict(type="object")) == ({'object'}, False)
    assert get_valid_types(dict(type="null")) == ({}, True)
    assert get_valid_types(dict(type="integer")) == ({'integer'}, False)
    assert get_valid_types(dict(type="object", nullable=True)) == ({'object'}, True)
    assert get_valid_types(dict(type="array", nullable=True)) == ({'array'}, True)
    assert get_valid_types(dict(type=None, nullable=True)) == ({'null'}, True)
    assert get_valid_types(dict(type=["object", "integer"], nullable=True)) == ({'integer', 'object'}, True)

# Generated at 2022-06-22 06:02:19.762629
# Unit test for function to_json_schema
def test_to_json_schema():
    # String
    schema = String()
    assert to_json_schema(schema) == {"type": "string"}
    schema = String(allow_null=True)
    assert to_json_schema(schema) == {"type": ["string", "null"]}
    schema = String(allow_blank=False)
    assert to_json_schema(schema) == {"type": "string", "minLength": 1}
    schema = String(min_length=2)
    assert to_json_schema(schema) == {"type": "string", "minLength": 2}
    schema = String(max_length=99)
    assert to_json_schema(schema) == {"type": "string", "maxLength": 99}
    schema = String(pattern_regex=r"p[attern]")


# Generated at 2022-06-22 06:02:24.728821
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    # Invalid type_string argument
    with pytest.raises(AssertionError) as excinfo:
        from_json_schema_type({}, "invalid_type" , False, SchemaDefinitions())
    assert "Invalid argument type_string" in str(excinfo.value)

    # type is "number"
    result = from_json_schema_type({"type": "number"}, "number", False, SchemaDefinitions())
    assert result.type == Float

    # type is "integer"
    result = from_json_schema_type({"type": "integer"}, "integer", False, SchemaDefinitions())
    assert result.type == Integer

    # type is "string"
    result = from_json_schema_type({"type": "string"}, "string", False, SchemaDefinitions())

# Generated at 2022-06-22 06:02:36.238121
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    from .typesystem import Boolean, Number, String

    schema = {
        "type": "string",
    }
    assert type_from_json_schema(schema, definitions={}) == String()

    schema = {
        "type": "string",
        "enum": ["a", "b", "c"],
    }
    field = type_from_json_schema(schema, definitions={})
    assert isinstance(field, Choice)
    assert isinstance(field.items[0], String)
    assert set(field.items[0].enum) == {"a", "b", "c"}

    schema = {
        "type": "number",
        "minimum": 5.5,
        "maximum": 10.5,
        "multipleOf": 0.5,
    }
    field = type_from_json_sche

# Generated at 2022-06-22 06:02:42.426027
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type(data={}, type_string="number", allow_null=False, definitions=SchemaDefinitions()) == Float(allow_null=False)
    assert from_json_schema_type(data={}, type_string="number", allow_null=True, definitions=SchemaDefinitions()) == Union(items=(Float(allow_null=False), Const(None)), all_of=None, any_of=None, one_of=None, allow_null=True)
    assert from_json_schema_type(data={}, type_string="integer", allow_null=False, definitions=SchemaDefinitions()) == Integer(allow_null=False)

# Generated at 2022-06-22 06:02:53.988437
# Unit test for function get_valid_types
def test_get_valid_types():
    test_type1 = {
        "type": "object",
        "properties": {"test": {"type": "string", "enum": ["test"]}},
    }
    test_type2 = {
        "type": ["object"],
        "properties": {"test": {"type": "string", "enum": ["test"]}},
    }
    test_type3 = {
        "type": ["object", "null"],
        "properties": {"test": {"type": "string", "enum": ["test"]}},
    }
    assert get_valid_types(test_type1) == ({"object"}, False)
    assert get_valid_types(test_type2) == ({"object"}, False)
    assert get_valid_types(test_type3) == ({"object"}, True)



# Generated at 2022-06-22 06:03:01.280015
# Unit test for function from_json_schema
def test_from_json_schema():
    data = {
        "$ref": "http://example.com/schema/person",
        "definitions": {
            "fullName": {
                "type": "string",
                "minLength": 1,
                "maxLength": 50,
            }
        },
    }

    definitions = SchemaDefinitions()
    definitions["http://example.com/schema/person"] = Object(
        properties={"name": Reference("fullName", definitions=definitions)}
    )
    field = definitions["http://example.com/schema/person"]

    result = from_json_schema(data, definitions=definitions)
    assert result == field



# Generated at 2022-06-22 06:03:07.834086
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    all_of_json = {"allOf": [{"type": "object", "required": ["foo"]}, {"type": "object", "required": ["bar"]}], "default": {"foo": 1, "bar": 2}}
    all_of_field = all_of_from_json_schema(all_of_json, None)
    assert all_of_field.validate({"foo": 1, "bar": 2}) == {"foo": 1, "bar": 2}


# Generated at 2022-06-22 06:03:17.007854
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    # Unit test for one_of_from_json_schema with valid input
    assert isinstance(one_of_from_json_schema({'oneOf': [{'type': 'number'}, {'type': 'number'}]}, {}), OneOf)
    # Unit test for one_of_from_json_schema with invalid input
    with pytest.raises(AssertionError):
        one_of_from_json_schema({'oneOf': [{'type': 'number'}, {'type': 'number'}]}, {})



# Generated at 2022-06-22 06:04:24.341397
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Object"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/Object"] = Object(properties={})
    assert isinstance(ref_from_json_schema(data=data, definitions=definitions), Reference)
    assert ref_from_json_schema(data=data, definitions=definitions).to == "#/definitions/Object"



# Generated at 2022-06-22 06:04:30.898203
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Definitions"}
    field = ref_from_json_schema(data, SchemaDefinitions())
    assert isinstance(field, Reference)
    assert field.to == data["$ref"]
# Code to execute unit test
test_ref_from_json_schema()



# Generated at 2022-06-22 06:04:33.884604
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert {
        "enum": [1, 2, 3],
        "default": 3,
    } == to_json_schema(from_json_schema({"enum": [1, 2, 3], "default": 3}))



# Generated at 2022-06-22 06:04:46.762141
# Unit test for function to_json_schema
def test_to_json_schema():

    assert to_json_schema(Any()) == True
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Integer()) == {"type": "integer"}
    assert to_json_schema(Float()) == {"type": "number"}
    assert to_json_schema(Decimal()) == {"type": "number"}
    assert to_json_schema(Boolean()) == {"type": "boolean"}
    assert to_json_schema(String()) == {"type": "string"}
    assert to_json_schema(Array()) == {"type": "array"}
    assert to_json_schema(Object()) == {"type": "object"}
    assert to_json_schema(Union()) == {"anyOf": []}

# Generated at 2022-06-22 06:04:52.957045
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():

    ref_string = "#/definitions/TestA"
    reference_field = Field()
    definitions = {}
    definitions[ref_string] = reference_field

    json_schema = {"$ref": ref_string}
    field = ref_from_json_schema(json_schema, definitions=definitions)
    assert field == reference_field



# Generated at 2022-06-22 06:05:05.115631
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    schema_dict = {
      "$ref": "#/definitions/item",
      "definitions": {
        "item": {"type": "integer"}
      }
    }
    schema = from_json_schema(schema_dict)
    assert schema._reference.to == "#/definitions/item"
    assert schema._reference.definitions == {
      '#/definitions/item': Integer(),
    }
    schemas = from_json_schema(schema_dict).definitions
    assert schemas == {
      '#/definitions/item': Integer(),
    }
    assert schemas["#/definitions/item"] == Integer()
    assert schemas["#/definitions/item"].validate(None) == None
    assert schemas["#/definitions/item"].validate(4) == 4

# Generated at 2022-06-22 06:05:11.458819
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/foo"}
    definitions = SchemaDefinitions()
    definitions["#/definitions/foo"] = Field()

    assert ref_from_json_schema(data, definitions=definitions).to == "#/definitions/foo"
    assert ref_from_json_schema(data, definitions=definitions).definitions == definitions



# Generated at 2022-06-22 06:05:23.918613
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    json_schema = {
        "type": "object",
        "properties": {
            "id": {
                "anyOf": [
                    {"type": "string"},
                    {"type": "number"},
                ]
            }
        }
    }
    schema = from_json_schema(json_schema, definitions=None)
    assert schema.validate({"id": 1}, format_validations=False) == []
    assert schema.validate({"id": "1"}, format_validations=False) == []
    assert schema.validate({"id": None}, format_validations=False) != []
    assert schema.validate({"id": True}, format_validations=False) != []
    assert schema.validate({"id": False}, format_validations=False) != []
    assert schema.valid

# Generated at 2022-06-22 06:05:34.110748
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert from_json_schema_type({}, "null", allow_null=True, definitions={}) == Const(None)
    assert from_json_schema_type({}, "null", allow_null=False, definitions={}) == NeverMatch()
    assert isinstance(from_json_schema_type({}, "string", allow_null=True, definitions={}), String)
    assert isinstance(from_json_schema_type({}, "integer", allow_null=True, definitions={}), Integer)
    assert isinstance(from_json_schema_type({}, "number", allow_null=True, definitions={}), Float)
    assert isinstance(from_json_schema_type({}, "boolean", allow_null=True, definitions={}), Boolean)

# Generated at 2022-06-22 06:05:45.998738
# Unit test for function to_json_schema
def test_to_json_schema():
    class Person(Schema):
        name = String
        age = Integer
        gender = Choice(choices=["M", "F"])

    class Address(Schema):
        street_name = String
        street_number = Integer
        apartment_number = Integer(allow_none=True)

    class ExtendedPerson(Person):
        addresses = Array(items=Address)

    class Message(Schema):
        from_ = Reference(to=Person)
        to = Array(items=Person)
        payload = Choice(choices=[String, Object])

    definitions = {"Person": Person}
    definitions["Message"] = Message
    definitions["ExtendedPerson"] = ExtendedPerson


# Generated at 2022-06-22 06:06:17.220290
# Unit test for function get_standard_properties

# Generated at 2022-06-22 06:06:28.448876
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({"type": "string"}, definitions) == String()
    assert type_from_json_schema({"type": "number"}, definitions) == Number()
    assert type_from_json_schema({"type": "integer"}, definitions) == Integer()
    assert type_from_json_schema({"type": "boolean"}, definitions) == Boolean()

    assert type_from_json_schema({"type": "null"}, definitions) == Any(allow_null=True)

    assert type_from_json_schema({"type": "string", "minLength": 5}, definitions) == String(
        min_length=5
    )

    assert type_from_json_schema(
        {"type": "string", "maxLength": 5}, definitions
    ) == String(max_length=5)

# Generated at 2022-06-22 06:06:33.051774
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert type_from_json_schema({}, None) == Any()
    assert type_from_json_schema({}, None)
    assert type_from_json_schema({"type": "integer"}, None) == Integer()
    assert type_from_json_schema({"type": ["integer", "null"]}, None) == Union(
        any_of=[Integer(), Const(None)], allow_null=True
    )



# Generated at 2022-06-22 06:06:41.048881
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    """
    Test for function ref_from_json_schema.
    """
    test_schema = {
        "definitions": {
            "test": {
                "type": "string",
                "enum": ["hello"]
            },
        },
        "$ref": "#/definitions/test"
    }
    assert Ref("test") == ref_from_json_schema(test_schema)
    assert Ref("test") == ref_from_json_schema({
        "type": "string",
        "enum": ["hello"]
    })



# Generated at 2022-06-22 06:06:52.454803
# Unit test for function to_json_schema
def test_to_json_schema():
    class TestSchema(Schema):
        foo = String()
        bar = String()

    generated = to_json_schema(TestSchema)
    expected = {
        "type": "object",
        "definitions": {
            "foo": {"type": "string"},
            "bar": {"type": "string"},
        },
        "properties": {
            "foo": {"$ref": "#/definitions/foo"},
            "bar": {"$ref": "#/definitions/bar"},
        },
        "required": ["foo", "bar"],
    }
    assert generated == expected

    generated = to_json_schema(TestSchema.make_validator())