

# Generated at 2022-06-22 05:57:52.989635
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert any_of_from_json_schema(data={'anyOf':[]},definitions=[]) == Any()

    assert any_of_from_json_schema(data={'anyOf':[{}]},definitions=[]) == Any()

    assert any_of_from_json_schema(data={'anyOf':[{'anyOf':[{}]}]},definitions=[]) == Any()

    assert any_of_from_json_schema(data={'anyOf':[1]},definitions=[]) == Any()

    assert any_of_from_json_schema(data={'anyOf':[1,2]},definitions=[]) == Any()

    assert any_of_from_json_schema(data={'anyOf':[1,2,'3']},definitions=[]) == Any()



# Generated at 2022-06-22 05:57:59.788023
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    """
    Test that all_of_from_json_schema produces a Field of the correct type.
    Test that it recognizes a valid allOf statement and attaches it to the field.
    Test that it recognizes a default value.
    """
    data = {
        "allOf": [{"type": "string"}, {"maxLength": 10}],
        "default": "test string"
        }
    definitions = {}
    assert isinstance(all_of_from_json_schema(data, definitions), Field)
    assert all_of_from_json_schema(data, definitions).all_of[0].type is String
    assert all_of_from_json_schema(data, definitions).all_of[1].max_length == 10

# Generated at 2022-06-22 05:58:02.525569
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    schema = {"not": {"enum": ["foo"]}}
    expected = Not(negated=Choice(choices=[("foo", "foo")]))
    actual = from_json_schema(schema)
    assert actual == expected

    schema = {"not": {"type": "string"}}
    expected = Not(negated=String(allow_null=True))
    actual = from_json_schema(schema)
    assert actual == expected



# Generated at 2022-06-22 05:58:07.225714
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    assert IfThenElse.from_json_schema({
        "if": {"type": "integer"},
        "then": {"type": "string"},
    }) == IfThenElse(if_clause=Integer(), then_clause=String())



# Generated at 2022-06-22 05:58:18.854119
# Unit test for function from_json_schema
def test_from_json_schema():  # type: ignore
    assert from_json_schema({"type": "boolean"}) == Boolean()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "integer", "enum": [0]}) == Choice(items=[0])
    assert from_json_schema({"type": "null", "const": None}) == Const(value=None)
    assert from_json_schema({"const": [1, 2]}) == Const(value=[1, 2])
    assert from_json_schema({"type": "integer", "allOf": [{"maximum": 10}]})

# Generated at 2022-06-22 05:58:29.500558
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from_json_schema('any_of')
    from_json_schema('data')
    from_json_schema('default')
    from_json_schema('kwargs')
    from_json_schema('item')
    from_json_schema('definitions')
    from_json_schema('anyOf')
    from_json_schema('data')
    from_json_schema('data')
    from_json_schema('data')
    from_json_schema('data')
    from_json_schema('default')
    from_json_schema('kwargs')
    from_json_schema('data')
    from_json_schema('data')
    from_json_schema('data')
    from_json_schema('data')
    from_json_sche

# Generated at 2022-06-22 05:58:38.623850
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    definitions = SchemaDefinitions()
    one_of_data = {
        "oneOf": [
            {"type": "integer", "minimum": 1},
            {"type": "string", "maxLength": 4},
        ]
    }
    one_of = one_of_from_json_schema(one_of_data, definitions)
    assert one_of._schema_classes == [Integer, String]
    assert one_of.get_schema().validate(1) == 1
    assert one_of.get_schema().validate("test") == "test"
    assert one_of.get_schema().validate([1]) == "Invalid value."



# Generated at 2022-06-22 05:58:47.327140
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    mySchema = Object(
        properties={
            "firstName": String(allow_null=False),
            "lastName": String(allow_null=False),
        }
    )
    definitions = SchemaDefinitions()
    definitions["#/definitions/mySchema"] = mySchema
    data = {"$ref": "#/definitions/mySchema"}
    field = ref_from_json_schema(data, definitions)
    assert field == mySchema
    # Test with a relative path
    data = {"$ref": "./definitions/mySchema"}
    field = ref_from_json_schema(data, definitions)
    assert field == mySchema



# Generated at 2022-06-22 05:58:55.390358
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {"oneOf": [{'$ref': '#/definitions/number'}, {'$ref': '#/definitions/string'}]}
    result = one_of_from_json_schema(data, definitions)
    assert type(result) == OneOf
    assert len(result.one_of) == 2
    assert result.default == NO_DEFAULT
    assert result.one_of[0][0].to == '#/definitions/number' and type(result.one_of[0][0]) == Reference
    assert result.one_of[1][0].to == '#/definitions/string' and type(result.one_of[1][0]) == Reference


# Generated at 2022-06-22 05:59:03.730401
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    assert isinstance(from_json_schema_type({}, "number"), Number)
    assert isinstance(from_json_schema_type({}, "integer"), Integer)
    assert isinstance(from_json_schema_type({}, "string"), String)
    assert isinstance(from_json_schema_type({}, "boolean"), Boolean)
    assert isinstance(from_json_schema_type({}, "array"), Array)
    assert isinstance(from_json_schema_type({}, "object"), Object)
    assert from_json_schema_type({'allow_null':True}, "number").allow_null is True
    assert from_json_schema_type({'allow_null':True}, "integer").allow_null is True

# Generated at 2022-06-22 05:59:34.786094
# Unit test for function if_then_else_from_json_schema

# Generated at 2022-06-22 05:59:45.372415
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    def one_of_from_json_schema(data: dict, definitions: SchemaDefinitions) -> Field:
        one_of = [from_json_schema(item, definitions=definitions) for item in data["oneOf"]]
        kwargs = {"one_of": one_of, "default": data.get("default", NO_DEFAULT)}
        return OneOf(**kwargs)
    definitions = SchemaDefinitions()

# Generated at 2022-06-22 05:59:53.805127
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    type_strings = [
        "number",
        "integer",
        "string",
        "boolean",
        "array",
        "object",
    ]
    for type_string in type_strings:
        assert from_json_schema_type(
            data={},
            type_string=type_string,
            allow_null=False,
            definitions=SchemaDefinitions(),
        ) is not None

    assert from_json_schema_type(
        data={},
        type_string="object",
        allow_null=False,
        definitions=SchemaDefinitions(),
    ) is not None
    
    

# Generated at 2022-06-22 05:59:55.602146
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = one_of_from_json_schema({"oneOf": [{"type": "number"}]}, SchemaDefinitions())
    assert isinstance(schema, OneOf)
    assert isinstance(schema.one_of[0], Float)
    assert schema.default is NEVER_SET



# Generated at 2022-06-22 05:59:57.919396
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {'anyOf': [{'type': 'integer', 'maximum': 10}, {'type': 'integer', 'minimum': 1}]}
    field = any_of_from_json_schema(data, None)
    assert field.validate(1)
    assert not field.validate(0)
    assert field.validate(10)
    assert not field.validate(11)


# Generated at 2022-06-22 06:00:02.604872
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "string"},
        "then": {"maxLength": 5},
        "else": {"const": "hi"},
    }
    definitions = SchemaDefinitions()
    expected = Object(properties={
        "if": String(),
        "then": Object(properties={
            "maxLength": Integer(maximum=5),
        }),
        "else": Object(properties={
            "const": Object(properties={
                "const": Const("hi"),
            }),
        }),
    })
    actual = if_then_else_from_json_schema(data, definitions=definitions)
    assert actual == expected

# Generated at 2022-06-22 06:00:10.317112
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    """Tests for matching all_of_from_json_schema with matching values and non matching values"""

    num1 = Integer(minimum=0)
    num2 = Integer(maximum=5)
    num3 = Integer(minimum=1)
    field = AllOf(all_of=[num1, num2, num3])

    assert [True] == field.validate([1])
    assert [] == field.validate([0])
    assert [] == field.validate([6])



# Generated at 2022-06-22 06:00:19.299455
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "type": "object",
        "properties": {"not": {"type": "boolean"}},
        "not": {"$ref": "#/properties/not"},
    }
    field = from_json_schema(data)
    assert field.validate(None) == (False, [f"<No value> is not valid type(s): boolean"])
    assert field.validate(0) == (False, [f"<No value> is not valid type(s): boolean"])
    assert field.validate("") == (False, [f"<No value> is not valid type(s): boolean"])

# Generated at 2022-06-22 06:00:21.881147
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert type(enum_from_json_schema(
        data={"enum": ["one", "two"]}, definitions=SchemaDefinitions()
    )) is Choice



# Generated at 2022-06-22 06:00:33.379846
# Unit test for function type_from_json_schema

# Generated at 2022-06-22 06:01:18.521520
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
  # following code was taken from here: https://json-schema.org/understanding-json-schema/reference/combining.html
  #make sure None is not marked as invalid
  data = {
    "if": {
     "properties": {
      "integer": {
       "type": "integer"
      }
     },
     "required": [
      "integer"
     ]
    },
    "then": {
     "type": "integer"
    }
   }
  assert not any_of_from_json_schema(data, SchemaDefinitions()).validate(None)
  #now see if other types are invalid or not
  data = {
    "type": "object",
    "properties": {
     "foo": {
      "type": "string"
     }
    }
   }

# Generated at 2022-06-22 06:01:24.729101
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [
        {"type": "string", "minLength": 1},
        {"type": "string", "maxLength": 3}
    ]}
    assert all_of_from_json_schema(data, definitions=definitions) == AllOf(all_of=[
        String(min_length=1),
        String(max_length=3)
    ])


# Generated at 2022-06-22 06:01:29.440723
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {
            "username": {
                "type": ["string", "number"],
                "minLength": 1,
                "maxLength": 256
            }
        }
    }
    field = from_json_schema(data)


# Generated at 2022-06-22 06:01:34.279772
# Unit test for function get_standard_properties
def test_get_standard_properties():
    from jsonable_encoder import jsons
    from unittest import TestCase
    from valideer.common import Nothing

    class TestField(Field):
        __slots__ = "default_value"
        default_value: typing.Any
        def __init__(self, default_value: typing.Any):
            self.default_value = default_value
        def has_default(self) -> bool:
            return self.default_value is not Nothing
        @property
        def default(self) -> typing.Any:
            return self.default_value

    class TestCase(TestCase):
        def test(self, field: Field, expected_result: str) -> None:
            result = get_standard_properties(field)
            expected_result = json.loads(expected_result)

# Generated at 2022-06-22 06:01:45.681842
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string"}) == String()
    assert from_json_schema({"type": "number"}) == Number()
    assert from_json_schema({"type": "integer"}) == Integer()
    assert from_json_schema({"type": "object"}) == Object()
    assert from_json_schema({"type": "array"}) == Array()
    assert from_json_schema({"type": ["number", "integer"]}) == Number()
    assert from_json_schema({"type": ["string", "integer"]}) == String() | Integer()



# Generated at 2022-06-22 06:01:49.920770
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const = 1
    kwargs = {'const': const, 'default': 1}
    assert(const_from_json_schema(kwargs, "{}") == Const(**kwargs))



# Generated at 2022-06-22 06:01:52.989355
# Unit test for function any_of_from_json_schema

# Generated at 2022-06-22 06:01:58.506533
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    from_json_schema({'type': 'integer', 'allOf': [{'minimum': 0}, {'maximum': 5}]}) == AllOf(
        [
            Integer(minimum=0, maximum=5),
        ]
    )
    from_json_schema({'anyOf': [{'type': 'string'}, {'type': 'null'}]}) == Any()


# Generated at 2022-06-22 06:02:00.948099
# Unit test for function from_json_schema
def test_from_json_schema():
    for key, value in data_constraints.items():
        field = from_json_schema(value)
        assert isinstance(field.process(value), str)



# Generated at 2022-06-22 06:02:04.576204
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    a = {"anyOf":[{"type":"string"},{"type":"integer"}]}
    b = from_json_schema(a, definitions=None)
    assert isinstance(b, Field)
    assert isinstance(b, Union)



# Generated at 2022-06-22 06:02:30.066711
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    type_schema = {"const": 12345}
    expected_field = Const(const=12345)
    assert const_from_json_schema(type_schema, None) == expected_field



# Generated at 2022-06-22 06:02:31.751410
# Unit test for function from_json_schema_type
def test_from_json_schema_type():
    field = from_json_schema_type({"type": "string"}, "string", False, SchemaDefinitions())
    assert isinstance(field, String), f"Invalid class: {field.__class__.__name__!r}"



# Generated at 2022-06-22 06:02:32.991891
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    assert True



# Generated at 2022-06-22 06:02:36.987731
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    data = dict(enum=['a', 'b'], default='a')
    assert enum_from_json_schema(data, None).schema() == data



# Generated at 2022-06-22 06:02:45.764416
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    data1 = {"not":{"type": "string"}}
    data2 = {"not":{"type": "string", "maxLength": 1}}
    data3 = {"not":{"type": "string", "minLength": 1, "maxLength": 1}}
    schema1 = not_from_json_schema(data1, None)
    assert not schema1.validate("hello")
    assert not schema1.validate(None)
    assert not schema1.validate(5)
    assert schema1.validate(True)
    schema2 = not_from_json_schema(data2, None)
    assert not schema2.validate("hello")
    assert not schema2.validate(None)
    assert not schema2.validate(5)
    assert schema2.validate(True)
    schema3 = not_from_json

# Generated at 2022-06-22 06:02:51.433140
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    const_schema = {
        "const": "string_value"
    }
    expected_schema = Const(
        const='string_value'
    )
    actual_schema = const_from_json_schema(const_schema, definitions)
    assert expected_schema.to_primitive() == actual_schema.to_primitive()


# Generated at 2022-06-22 06:02:56.625121
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert isinstance(type_from_json_schema({}, definitions={}), Any)
    assert isinstance(
        type_from_json_schema({"type": "null"}, definitions={}), Const
    )
    assert isinstance(type_from_json_schema({"type": "number"}, definitions={}), Float)
    assert isinstance(type_from_json_schema({"type": "integer"}, definitions={}), Integer)
    assert isinstance(
        type_from_json_schema({"type": "string"}, definitions={}), String
    )
    assert isinstance(
        type_from_json_schema({"type": "boolean"}, definitions={}), Boolean
    )

# Generated at 2022-06-22 06:03:07.640828
# Unit test for function to_json_schema
def test_to_json_schema():
    # This test is not extensive.  It only tests a few basic data types.
    import json

    assert json.dumps(to_json_schema(Any())) == "{}"
    assert json.dumps(to_json_schema(String())) == '{"type": "string"}'
    assert json.dumps(to_json_schema(String(allow_blank=False))) == '{"type": "string", "minLength": 1}'
    assert (
        json.dumps(to_json_schema(String(format="uri"))) == '{"type": "string", "format": "uri"}'
    )
    assert json.dumps(to_json_schema(Decimal())) == '{"type": "number"}'

# Generated at 2022-06-22 06:03:18.798782
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data1 = {
    "oneOf": [
        {
            "type": "number",
            "minimum": 1,
            "maximum": 10
        },
        {
            "type": "string",
            "minLength": 3,
            "maxLength": 10
        }
    ]
    }
    data2 = {
        "oneOf": [
            {
                "type": "number",
                "minimum": 1,
                "maximum": 10
            },
            {
                "type": "string",
                "minLength": 2,
                "maxLength": 10
            }
        ]
    }
    x = one_of_from_json_schema(data1,definitions=definitions)
    assert x.validate(8)
    assert not x.validate(11)
    assert not x

# Generated at 2022-06-22 06:03:29.653286
# Unit test for function to_json_schema
def test_to_json_schema():
    from_schema = from_json_schema(to_json_schema(String()))
    assert from_schema.validate(None) == FieldError(field=from_schema, reason="required")
    assert from_schema.validate("") == FieldError(field=from_schema, reason="required")
    assert from_schema.validate("abc") == "abc"
    assert from_schema.validate("    ") == "    "

    from_schema = from_json_schema(to_json_schema(String()), allow_null=True)
    assert from_schema.validate(None) == None
    assert from_schema.validate("") == FieldError(field=from_schema, reason="required")

# Generated at 2022-06-22 06:04:04.440078
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    result = const_from_json_schema({'const': 1, 'default': 'asd'}, definitions).validate(2)
    assert result == False
    result = const_from_json_schema({'const': 1, 'default': 'asd'}, definitions).validate(1)
    assert result == True


# Generated at 2022-06-22 06:04:09.726114
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    data = {"type": ["integer", "null"]}
    assert type_from_json_schema(data, definitions={}) == Integer(allow_null=True)
    data = {"type": "integer"}
    assert type_from_json_schema(data, definitions={}) == Integer()



# Generated at 2022-06-22 06:04:11.410840
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    _call_func_that_calls_IfThenElse()


# Generated at 2022-06-22 06:04:21.845796
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {"allOf": [{"$ref": "#/definitions/price"}, {"$ref": "#/definitions/count"}], "definitions": {}}
    definitions = SchemaDefinitions()
    definitions["#/definitions/price"] = String()
    definitions["#/definitions/count"] = Integer()
    field = all_of_from_json_schema(data, definitions)
    assert field.clean("100") == "100"
    assert field.clean("100.1") == "100"
    assert field.clean(-100) == -100
    assert field.clean(-100.1) == -100
    assert field.clean("a") == "a"



# Generated at 2022-06-22 06:04:30.748577
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from typesystem.composites import Union
    constraint = any_of_from_json_schema({'type': 'union', 'anyOf': [{'type': 'integer'}, {'type': 'string'}]}, None)
    assert isinstance(constraint, Union) and constraint.any_of[0].type == 'integer'



# Generated at 2022-06-22 06:04:39.101176
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {"$schema":"http://json-schema.org/draft-07/schema#","$id":"IfThenElse","type":"object","title":"IfThenElse","default":{},"required":["if","then"],"additionalProperties":False,"properties":{"if":{"$id":"#/properties/if","type":"boolean","title":"The If Schema","default":False,"examples":[True]},"then":{"$id":"#/properties/then","type":"string","title":"The Then Schema","default":"","examples":["foo"]},"else":{"$id":"#/properties/else","type":"boolean","title":"The Else Schema","default":False,"examples":[True]}}}
    definitions = SchemaDefinitions()
    if_then_else_field = if_then_else_from_json_schema(data, definitions=definitions)


# Generated at 2022-06-22 06:04:43.569413
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    not_schema = {
        "type": "object",
        "not": {"type" : "number"}
    }
    not_constraint = not_from_json_schema(not_schema)
    assert isinstance(not_constraint, Not)



# Generated at 2022-06-22 06:04:47.000284
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": 10, "default": 20}
    kwargs = {"const": data["const"], "default": data.get("default", NO_DEFAULT)}
    assert Const(**kwargs) != None



# Generated at 2022-06-22 06:04:56.479923
# Unit test for function get_valid_types
def test_get_valid_types():
    type_strings, allow_null = get_valid_types({})
    assert type_strings == {
        "boolean",
        "object",
        "array",
        "number",
        "string"
    }
    assert allow_null == False

    type_strings, allow_null = get_valid_types({"type": "null"})
    assert type_strings == {
        "boolean",
        "object",
        "array",
        "number",
        "string"
    }
    assert allow_null == True

    type_strings, allow_null = get_valid_types({"type": "non-null"})
    assert type_strings == {
        "boolean",
        "object",
        "array",
        "number",
        "string"
    }
    assert allow_null == False

# Generated at 2022-06-22 06:05:06.581857
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    type_system_schema = AllOf(
        [
            Boolean(
                description="`True` if the user has confirmed their email address.", format="boolean"
            ),
            Boolean(description="`True` if the user is active.", format="boolean"),
            Boolean(
                description="`True` if the user is staff.",
                format="boolean",
                default=False,
            ),
        ],
        default=False,
    )

# Generated at 2022-06-22 06:06:15.535534
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    data = {"$ref": "#/definitions/Ref"}
    definitions = SchemaDefinitions()
    definitions["Ref"] = Integer()
    field = ref_from_json_schema(data, definitions=definitions)
    assert isinstance(field, Reference)
    assert field.to == "#/definitions/Ref"



# Generated at 2022-06-22 06:06:24.087363
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    choices = [("item1", "item1")]
    kwargs = {"choices": choices, "default": "NO_DEFAULT"}
    assert Choice(**kwargs) == enum_from_json_schema({"enum": ["item1"]}, SchemaDefinitions())
    assert Choice(**kwargs) == enum_from_json_schema({"enum": ["item1"],"default":"NO_DEFAULT"}, SchemaDefinitions())




# Generated at 2022-06-22 06:06:37.336037
# Unit test for function to_json_schema
def test_to_json_schema():
    schema = make_json_schema(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
            }
        }
    )
    assert to_json_schema(schema) == {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
        }
    }
    assert (
        to_json_schema(String(min_length=1, max_length=10))
        == {"type": "string", "minLength": 1, "maxLength": 10}
    )
    assert (
        to_json_schema(Integer(minimum=1, maximum=10))
        == {"type": "integer", "minimum": 1, "maximum": 10}
    )

# Generated at 2022-06-22 06:06:43.870988
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    assert Const(const="milk").validate("milk")
    assert Const(const="milk").validate("milk", allow_coercion=True)
    assert not Const(const="milk").validate("cheese")



# Generated at 2022-06-22 06:06:46.485168
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert isinstance(any_of_from_json_schema({"anyOf": [{"type": "number"}]}, definitions=None), Union)


# Generated at 2022-06-22 06:06:53.339276
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data = {
        "if": {"type": "boolean"},
        "then": {"type": "integer"},
        "else": {"type": "number"},
    }
    field = if_then_else_from_json_schema(data, definitions=None)
    assert field.validate(True) == (True, 1)
    assert field.validate(False) == (True, 1.1)
    assert field.validate("not a boolean") == (False, '"not a boolean" is not a boolean')



# Generated at 2022-06-22 06:07:03.210630
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    from expecter import expect
    from typesystem.base import Field

    expect(const_from_json_schema({"const": 3.4})).isinstance(Field)
    expect(const_from_json_schema({"const": 'hello'})).isinstance(Field)
    expect(const_from_json_schema({"const": "hello"})).isinstance(Field)
    expect(const_from_json_schema({"const": 3})).isinstance(Field)
    expect(const_from_json_schema({"const": [3, 6]})).type == ['__main__.Const']
    expect(const_from_json_schema({"const": 42})).type == '__main__.Const'