

# Generated at 2022-06-22 05:57:45.074970
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {
        "type": "object",
        "properties": {
            "a": {"type": "integer"},
            "b": {"type": "string"},
        },
        "anyOf" : [{
            "properties": {"a": {"type": "integer", "maxLength": 2}}
        }, {
            "properties": {"b": {"type": "string", "minLength": 2}}
        }]
    }
    field = from_json_schema(data)
    result1 = field.is_valid({"a": 123, "b": "qwerty"})
    assert result1 == True
    result2 = field.is_valid({"a": 12, "b": "qwerty"})
    assert result2 == True

# Generated at 2022-06-22 05:57:50.096672
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    schema = one_of_from_json_schema({"oneOf": [1, 2, 3]})
    assert schema.validate(1) == 1
    assert schema.validate(2) == 2
    assert schema.validate(3) == 3
    with pytest.raises(ValidationError):
        schema.validate(4)


# Generated at 2022-06-22 05:57:55.634747
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    from pprint import pprint
    json_schema_doc = {
        'anyOf': [
            {'type': 'number'},
            {
              'type': 'number',
              'maximum': 1024.0,
              'minimum': 0.0,
            }
        ]
    }
    # pprint(json_schema_doc)
    field = any_of_from_json_schema(json_schema_doc, {})
    assert field.to_representation(64.0) == 64.0
    assert field.to_representation(2048.0) == None
    return field



# Generated at 2022-06-22 05:58:05.629218
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    ref_schema_1 = {'$ref': '#/definitions/machine_price'}
    ref_schema_2 = {'$ref': '#/definitions/machine_speed_rpm'}


# Generated at 2022-06-22 05:58:16.468640
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "boolean"}) == ({'boolean'}, False)
    assert get_valid_types({"type": ["boolean", "null"]}) == ({'boolean'}, True)
    assert get_valid_types({"type": ["boolean", "array", "null"]}) == ({'boolean', 'array'}, True)
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, False)
    assert get_valid_types({"type": ["null", "object", "array", "string", "number", "integer"]}) == ({'object', 'array', 'number', 'string'}, True)



# Generated at 2022-06-22 05:58:27.195061
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "integer", "nullable": True}) == ({"integer"}, True)
    assert get_valid_types({"type": "null", "nullable": True}) == (set(), True)
    assert get_valid_types({"type": "null", "nullable": False}) == (set(), False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"nullable": True}) == (
        {"boolean", "object", "array", "number", "string"},
        True,
    )

# Generated at 2022-06-22 05:58:38.428161
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    document = {
        "if": {"$ref": "#/definitions/foo"},
        "then": {"$ref": "#/definitions/bar"},
        "else": {"$ref": "#/definitions/baz"},
    }
    expected_field = IfThenElse(
        if_clause=Reference(to="#/definitions/foo"),
        then_clause=Reference(to="#/definitions/bar"),
        else_clause=Reference(to="#/definitions/baz"),
    )
    definitions = SchemaDefinitions()
    definitions['#/definitions/foo'] = Any()
    definitions['#/definitions/bar'] = Any()
    definitions['#/definitions/baz'] = Any()
    result = if_then_else_from_json_schema(document, definitions)

# Generated at 2022-06-22 05:58:49.257613
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    import django.forms as forms
    a = IfThenElse(if_clause=Boolean(default=False),then_clause=String(min_length=2),else_clause=Integer(minimum=1))
    b = forms.BooleanField(required=False)
    c = forms.CharField(required=False,min_length=2)
    d = forms.IntegerField(required=False,min_value=1)
    assert a.if_clause == b
    assert a.then_clause == c
    assert a.else_clause == d
    
    e = IfThenElse(if_clause=Integer(multiple_of=2),then_clause=String(min_length=2))

# Generated at 2022-06-22 05:58:59.031383
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    obj_schema = {"type": "object", "properties": {
        "a": {"type": "string"},
        "b": {"type": "number"}
    }}
    obj_field = from_json_schema(obj_schema)
    schema = {"anyOf": [
        {"type": "string"},
        {"type": "number"},
        obj_schema
    ]}
    field = from_json_schema(schema)
    assert isinstance(field, Union)
    assert len(field.any_of) == 3
    assert field.any_of[2] == obj_field



# Generated at 2022-06-22 05:59:03.648710
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({
        "allOf": [
            {"type": "integer"},
            {"minimum": 10}
        ]
    }) == AllOf(all_of=[
        Integer(),
        Integer(minimum=10)
    ])
# Test that allOf subfields can be either of two types

# Generated at 2022-06-22 05:59:49.109450
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({"boolean", "object", "array", "number", "string"}, False)

    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "integer"}) == ({"integer"}, False)
    assert get_valid_types({"type": "number"}) == ({"number"}, False)
    assert get_valid_types({"type": "number", "multipleOf": 2}) == ({"number"}, False)
    assert get_valid_types({"type": "number", "multipleOf": 2.5}) == ({"number"}, False)
    assert get_valid_types({"type": "integer", "multipleOf": 2}) == ({"integer"}, False)

# Generated at 2022-06-22 05:59:53.028946
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String(default="hello")) == {
        "default": "hello"
    }
    assert get_standard_properties(String(default=NO_DEFAULT)) == {}
    assert get_standard_properties(String(default=MISSING)) == {}



# Generated at 2022-06-22 05:59:56.773631
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {'const': 1}
    definitions = None
    field = const_from_json_schema(data, definitions)
    assert isinstance(field, Const)
    assert field.const == 1


# Generated at 2022-06-22 06:00:01.392932
# Unit test for function to_json_schema
def test_to_json_schema():
    assert to_json_schema(MultipleOf(multiple_of=5)) == {
        "type": "integer",
        "multipleOf": 5,
        "default": NO_DEFAULT,
    }
    assert to_json_schema(OneOf(one_of=[MultipleOf(multiple_of=5), MultipleOf(multiple_of=3)])) == {
        "type": "integer",
        "oneOf": [{"multipleOf": 5}, {"multipleOf": 3}],
        "default": NO_DEFAULT,
    }


# One cannot import class Schema here because that would create a circular import

# Generated at 2022-06-22 06:00:09.229595
# Unit test for function from_json_schema
def test_from_json_schema():
    assert from_json_schema({"type": "string", "minLength": 3}) == String(min_length=3)
    assert from_json_schema({"type": "string", "maxLength": 3}) == String(max_length=3)
    assert from_json_schema({"type": "string", "minLength": 3, "maxLength": 5,}) == String(
        min_length=3, max_length=5
    )



# Generated at 2022-06-22 06:00:16.439248
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert isinstance(ref_from_json_schema({'$ref': '#/foo'}, SchemaDefinitions(foo=Any())), Reference)
    assert ref_from_json_schema({'$ref': '#/foo'}, SchemaDefinitions(foo=Any())).to == '#/foo'
    assert ref_from_json_schema({'$ref': '#/foo'}, SchemaDefinitions(foo=Any())).definitions == SchemaDefinitions(foo=Any())



# Generated at 2022-06-22 06:00:25.547761
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    def _test_if_then_else_from_json_schema(
        schema: dict,
        definitions: typing.Optional[typing.Dict[str, dict]] = None,
        expected_result: typing.Optional[typing.Any] = None,
    ) -> None:
        """
        Test the JSON schema constructor for the `if`/`then`/`else` fields.
        """
        if definitions:
            definitions = SchemaDefinitions(definitions)
        else:
            definitions = SchemaDefinitions()
        field = if_then_else_from_json_schema(schema, definitions=definitions)
        if expected_result is None:
            assert isinstance(field, IfThenElse)
        else:
            assert field == expected_result

    _test_if_then_else_from_json

# Generated at 2022-06-22 06:00:33.418339
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    actual_value = const_from_json_schema({"const": 1}, definitions=None)
    expected_value = Const(
        const=1,
        description=None,
        name=None,
        slug=None,
        title=None,
        help_text=None,
        placeholder=None,
        widget=None,
        meta=None,
        choices=None,
        allow_null=False,
        default=NO_DEFAULT,
        serializer=None,
        error_messages=None,
        required=None,
        unique=True,
        unique_scope=None,
    )
    assert actual_value == expected_value



# Generated at 2022-06-22 06:00:43.473362
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    assert str(type_from_json_schema({"type": "string"}, SchemaDefinitions())) == "String()"
    assert str(type_from_json_schema({"type": ["string", "integer"]}, SchemaDefinitions())) == "Union(String(), Integer())"
    assert str(type_from_json_schema({"type": ["string", "integer", "null"]}, SchemaDefinitions())) == "Union(None, String(), Integer())"
    assert str(type_from_json_schema({"type": ["string", "object"], "properties": {"key": {"type": "string"}}}, SchemaDefinitions())) == "Union(String(), Object(properties={'key': String()}))"



# Generated at 2022-06-22 06:00:47.826404
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    """
    Test case function one_of_from_json_schema
    """
    data = {}
    data["oneOf"] = [{"type":"string"}]
    definitions = SchemaDefinitions()
    result = one_of_from_json_schema(data, definitions)
    assert isinstance(result, OneOf)



# Generated at 2022-06-22 06:03:06.903135
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'array', 'boolean', 'integer', 'null', 'number', 'object', 'string'}, False)
    assert get_valid_types({"type": "array"}) == ({'array'}, False)
    assert get_valid_types({"type": "null"}) == ({}, True)
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "number"}) == ({'number'}, False)
    assert get_valid_types({"type": ["null", "number", "integer"]}) == ({'integer', 'number'}, True)
    assert get_valid_types({"type": ["number", "integer"]}) == ({'integer', 'number'}, False)



# Generated at 2022-06-22 06:03:13.748140
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    data = {
        "oneOf": [
            {
                "type": "number",
            },
            {
                "const": 123,
            },
        ]
    }
    definition = one_of_from_json_schema(data, None)
    assert definition.one_of[0].type == "number"
    assert definition.one_of[1].const == 123


# Generated at 2022-06-22 06:03:16.721491
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    with pytest.raises(AssertionError) as excinfo:
        not_from_json_schema({'not': {'type': 'integer'}}, definitions={})
    assert 'Unsupported $ref style in document.' in str(excinfo.value)


# Generated at 2022-06-22 06:03:27.834800
# Unit test for function from_json_schema
def test_from_json_schema():
    """
    Tests for 'from_json_schema' function.
    """
    # Test 'Any'
    field = from_json_schema(True)
    assert isinstance(field, Any)

    # Test 'NeverMatch'
    field = from_json_schema(False)
    assert isinstance(field, NeverMatch)

    # Test 'String'
    field = from_json_schema({"type": "string"})
    assert isinstance(field, String)

    # Test 'String' with format
    field = from_json_schema({"type": "string", "format": "date-time"})
    assert isinstance(field, String)
    assert field.format == "date-time"

    # Test 'Boolean'

# Generated at 2022-06-22 06:03:34.207611
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    reference = {
        "$ref": "#/definitions/test_schema_ref_schema",
    }
    definitions = {
        "test_schema_ref_schema": {
            "type": "number",
        },
    }
    result = from_json_schema(reference, definitions=definitions)
    assert result == Reference("#/definitions/test_schema_ref_schema", definitions=definitions)

# Generated at 2022-06-22 06:03:45.450833
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    """
    Test case:
    - function one_of_from_json_schema creates a OneOf field
    - the OneOf field checks that the data value is one of the values in the one_of list
    - the default value is assigned to the OneOf field if no value is provided
    """
    data = {"oneOf": [{"type": "integer", "minimum": 1}, {"type": "integer", "minimum": 2}], "default": 3}
    schema = one_of_from_json_schema(data, SchemaDefinitions())
    errors = list(schema.check_and_return_errors(None))
    assert len(errors) == 1
    assert errors[0].code == "type_mismatch"
    errors = list(schema.check_and_return_errors(1))
    assert len(errors)

# Generated at 2022-06-22 06:03:57.064234
# Unit test for function one_of_from_json_schema
def test_one_of_from_json_schema():
    from typesystem.schema import Integer, Reference, Schema, SchemaDefinitions
    from typesystem.schemas import Array, Object
    all_schemas = SchemaDefinitions()

# Generated at 2022-06-22 06:04:03.634226
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Field(default=True)) == {"default": True}
    assert get_standard_properties(Field(default=False)) == {"default": False}
    assert get_standard_properties(Field(default="str")) == {"default": "str"}
    assert get_standard_properties(Field(default=1)) == {"default": 1}
    assert get_standard_properties(Field(default=1.5)) == {"default": 1.5}
    assert get_standard_properties(Field(default=None)) == {"default": None}

    assert get_standard_properties(Any(default=True)) == {"default": True}
    assert get_standard_properties(Any(default=False)) == {"default": False}
    assert get_standard_properties(Any(default="str")) == {"default": "str"}
    assert get_

# Generated at 2022-06-22 06:04:13.519181
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({"type": "string"}) == ({'string'}, False)
    assert get_valid_types({"type": "null"}) == (set(), True)
    assert get_valid_types({"type": ["integer", "string"]}) == ({'integer', 'string'}, False)
    assert get_valid_types({"type": ["number", "null"]}) == ({'number'}, True)
    # when `type` is not specified, it should default to all types except 'null'
    assert get_valid_types({}) == ({'boolean', 'array', 'number', 'string', 'integer', 'object'}, False)


# Generated at 2022-06-22 06:04:20.147216
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    data = {"anyOf": [{"type": "integer"}, {"type": "null"}]}
    result = any_of_from_json_schema(data, definitions)
    assert isinstance(result, Union)
    assert result.allow_null == False
    for item in result.any_of:
        assert isinstance(item, IfThenElse)
        assert isinstance(item.if_then_else[1], Integer)



# Generated at 2022-06-22 06:04:58.237341
# Unit test for function const_from_json_schema
def test_const_from_json_schema():
    data = {"const": "abc"}
    definitions = SchemaDefinitions()
    assert const_from_json_schema(data, definitions) == Const(const="abc")



# Generated at 2022-06-22 06:05:06.757128
# Unit test for function if_then_else_from_json_schema
def test_if_then_else_from_json_schema():
    data={'if': {'minimum': 1}, 'then': {'type': 'string'}, 'else': {'type': 'number'}, 'default': 'hello'}
    result=if_then_else_from_json_schema(data,None)
    assert result.description==IfThenElse(Integer(minimum=1),String(allow_blank=True),Float(),'hello').description
    data={'if': {'minimum': 1}, 'then': {'type': 'string'}, 'else': {'type': 'boolean'},'default': True}
    result=if_then_else_from_json_schema(data,None)
    assert result.description==IfThenElse(Integer(minimum=1),String(allow_blank=True),Boolean(),True).description

# Generated at 2022-06-22 06:05:10.679940
# Unit test for function from_json_schema
def test_from_json_schema():
    schema = {'allOf': [{'$ref': '#/definitions/pet'}, {'type': 'object'}], 'definitions': {'pet': {'type': 'object'}}, 'type': 'object'}
    x = from_json_schema(schema)
    y = AllOf([Reference('#/definitions/pet'), Any()])
    assert x == y


# Generated at 2022-06-22 06:05:22.791246
# Unit test for function any_of_from_json_schema
def test_any_of_from_json_schema():
    assert (
        {
            "anyOf": [{"type": "string"}, {"type": "number"}]
        }
        == {
            "type": ["string", "number"],
        }
    )
    assert (
        {
            "anyOf": [
                {"type": "string"},
                {"type": "number"},
                {"type": "boolean"},
            ]
        }
        == {
            "type": ["string", "number", "boolean"],
        }
    )

# Generated at 2022-06-22 06:05:33.399223
# Unit test for function ref_from_json_schema
def test_ref_from_json_schema():
    assert ref_from_json_schema({"$ref": "#/definitions/simple_schema"}, definitions) == Reference(to="#/definitions/simple_schema", definitions=definitions) #nosec
    assert ref_from_json_schema({"$ref": "#/definitions/schema_with_multiple_types"}, definitions) == Reference(to="#/definitions/schema_with_multiple_types", definitions=definitions) #nosec
    assert ref_from_json_schema({"$ref": "#/definitions/schema_with_optional_item"}, definitions) == Reference(to="#/definitions/schema_with_optional_item", definitions=definitions) #nosec

# Generated at 2022-06-22 06:05:45.291981
# Unit test for function to_json_schema
def test_to_json_schema():

    def check_is_superset(json_schema: dict, json_schema_subset: dict):
        assert json_schema.keys() >= json_schema_subset.keys()
        for key, value in json_schema_subset.items():
            assert (
                json_schema[key] == value
            ), f"json_schema[{key!r}] = {json_schema[key]!r} but expected {value!r}"

    json_schema = {
        "type": ["string", "null"],
        "default": "foobar",
        "minLength": 2,
        "maxLength": None,
        "pattern": "^foo.*",
    }

# Generated at 2022-06-22 06:05:49.961955
# Unit test for function get_valid_types
def test_get_valid_types():
    assert get_valid_types({}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({"type": "boolean"}) == ({"boolean"}, False)
    assert get_valid_types({"type": "object"}) == ({"object"}, False)
    assert get_valid_types({"type": None}) == ({'null', 'boolean', 'object', 'array', 'number', 'string'}, True)
    assert get_valid_types({"type": ["object", "null"]}) == ({"object"}, True)
    assert get_valid_types({"type": ["null", "object"]}) == ({"object"}, True)
    assert get_valid_types({"type": ["null"]}) == (set(), True)
    assert get_valid

# Generated at 2022-06-22 06:05:53.881015
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    assert all_of_from_json_schema({"allOf": [{"type": "integer"}]}, definitions).validate(2)
    assert not all_of_from_json_schema({"allOf": [{"type": "integer"}]}, definitions).validate("2")


# Generated at 2022-06-22 06:05:55.771333
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(Integer(default=7)) == {"default": 7}



# Generated at 2022-06-22 06:05:58.801650
# Unit test for function get_standard_properties
def test_get_standard_properties():
    field = String(default="test")
    assert get_standard_properties(field) == {"default": "test"}

    field = String()
    assert get_standard_properties(field) == {}



# Generated at 2022-06-22 06:06:26.700872
# Unit test for function all_of_from_json_schema
def test_all_of_from_json_schema():
    data = {
        "allOf": [
            {"type": "integer"},
            {
                "if": {"type": "integer"},
                "then": {"minimum": 3},
                "else": {"minimum": 0},
            },
        ],
        "default": 0,
    }
    field = AllOf([
        Integer(),
        IfThenElse(
            if_=Integer(),
            then_=Integer(minimum=3),
            else_=Integer(minimum=0),
        ),
    ], default=0)
    assert all_of_from_json_schema(data, definitions=definitions) == field


# Generated at 2022-06-22 06:06:30.052989
# Unit test for function enum_from_json_schema
def test_enum_from_json_schema():
    assert(enum_from_json_schema({'enum': [0,1,2]}, {}) == Choice(choices=[(0,0),(1,1),(2,2)]))
test_enum_from_json_schema()



# Generated at 2022-06-22 06:06:40.163122
# Unit test for function not_from_json_schema
def test_not_from_json_schema():
    """
    This tests that the "not" from JSON schema constructs the expected not Field
    """
    data = {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "$id": "http://example.com/product.schema.json",
        "title": "Product",
        "description": "A product from Acme's catalog",
        "type": "object",
        "properties": {
            "productId": {
                "description": "The unique identifier for a product",
                "type": "integer"
            }
        },
        "not": {
            "description": "The unique identifier for a product",
            "type": ["integer"]
        }
    }
    schema = from_json_schema(data)
    assert isinstance(schema, Not)
   

# Generated at 2022-06-22 06:06:51.656211
# Unit test for function type_from_json_schema
def test_type_from_json_schema():
    # elements = [None, 1]
    data = {
        "type": "object",
        "properties": {
            "hello": {"type": "string"},
            "world": {"type": "number"},
            "hello world": {"type": ["string", None]},
            "number": {"type": "integer", "minimum": 1, "maximum": 2},
        }
    }
    # assert type_from_json_schema(data) == Object(
    #     properties={
    #         "hello": String(),
    #         "world": Number(),
    #         "hello world": Union(any_of=[String(), Const(None)]),
    #         "number": Integer(minimum=1, maximum=2),
    #     }
    # )



# Generated at 2022-06-22 06:06:56.097094
# Unit test for function get_standard_properties
def test_get_standard_properties():
    assert get_standard_properties(String()) == {}
    assert get_standard_properties(String(default="")) == {"default": ""}
    assert get_standard_properties(String(default="anything")) == {"default": "anything"}

