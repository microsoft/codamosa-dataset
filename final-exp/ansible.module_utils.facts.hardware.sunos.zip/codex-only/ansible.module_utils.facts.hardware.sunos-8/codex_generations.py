

# Generated at 2022-06-22 23:25:00.865516
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock()
    hardware.populate()

# Generated at 2022-06-22 23:25:06.599846
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts import Facts
    module = patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware._check_sunos_version')
    module.return_value = True
    module = patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware._get_default_language')
    module.return_value = 'en_US.UTF-8'
    module = patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.get_cpu_facts')
    module.return_value = {'processor': ['SPARC_T4 (chipid 0, clock 1199 MHz)']}

# Generated at 2022-06-22 23:25:13.927331
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    plugin = SunOSHardware()
    result = plugin.get_memory_facts()
    assert result['memtotal_mb'] == 8192
    assert result['swapfree_mb'] == 4096
    assert result['swaptotal_mb'] == 6144
    assert result['swap_allocated_mb'] == 2048
    assert result['swap_reserved_mb'] == 4096


# Generated at 2022-06-22 23:25:17.988579
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'Memory size: 8192 Megabytes', None))

    sunoshw = SunOSHardware(module)
    facts = sunoshw.populate()

    assert facts['memtotal_mb'] == 8192


# Generated at 2022-06-22 23:25:24.398291
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    hw = SunOSHardware(module)
    rc, out, err = hw.module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')

    # Assert that the first output line is correct
    assert out.split()[0] == 'unix:0:system_misc:boot_time'

    uptime_facts = hw.get_uptime_facts()
    diff = int(time.time() - int(out.split('\t')[1]))

    # Assert that the uptime is within 5 seconds
    assert abs(uptime_facts["uptime_seconds"] - diff) < 5


# Generated at 2022-06-22 23:25:26.951405
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSHardware



# Generated at 2022-06-22 23:25:36.745821
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule(object):
        def run_command(self, command):
            if command == "/usr/bin/kstat cpu_info":
                if len(command) == 2:
                    return (0, '\nmodule:\nbrand:\nclock_MHz:\nimplementation:\n\nchip_id:\n', '')
                else:
                    return (0, 'module:\nbrand:\nclock_MHz:\nimplementation:\n\nchip_id:\n', '')
            elif command == ['/usr/sbin/prtconf']:
                return (0, 'Memory size: 8192 Megabytes\nMemory size: 2560 Megabytes', '')

# Generated at 2022-06-22 23:25:49.082559
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # dictionary of items returned by method kstat
    # this dictionary is used to create a string that simulates the
    # output of the method kstat when  any storage device is present
    # in the system
    kstat_out_present_storage_str = []
    kstat_out_present_storage_str.append("sderr:0:sd0,err:Hard Errors     0")
    kstat_out_present_storage_str.append("sderr:0:sd0,err:Illegal Request 6")
    kstat_out_present_storage_str.append("sderr:0:sd0,err:Media Error     0")
    kstat_out_present_storage_str.append("sderr:0:sd0,err:Predictive Failure Analysis     0")
    kstat_out_present_storage_

# Generated at 2022-06-22 23:25:55.732970
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    sunoshw = SunOSHardware(module, "SunOS")
    sunoshw.populate()

    facts = dict(sunoshw.facts)

    assert facts['memtotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['uptime_seconds'] > 0
    assert facts['processor_count'] > 0
    assert facts['processor_cores'] > 0

# Generated at 2022-06-22 23:26:00.129066
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h = SunOSHardware()
    memory = h.get_memory_facts()
    assert isinstance(memory, dict)
    assert 'memtotal_mb' in memory



# Generated at 2022-06-22 23:26:02.888191
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    facts = module.params
    hardware = SunOSHardware(facts)
    assert hardware.platform == 'SunOS'



# Generated at 2022-06-22 23:26:08.592539
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Create a generic hardware object with the right platform name
    hardware = SunOSHardware('SunOS')
    assert hardware.platform == 'SunOS'
    # Verify that the get_cpu_facts() method returns a dictionary
    cpu_facts = hardware.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    # Verify that the get_memory_facts() method returns a dictionary
    memory_facts = hardware.get_memory_facts()
    assert isinstance(memory_facts, dict)

# Generated at 2022-06-22 23:26:09.594247
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:26:22.262402
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules import hardware
    hardware.TIMEOUT = 10

    def run_command(args):
        # Use internal argument parsing
        command = args[0]
        args = args[1:]

        # Translate kstat flags to test data

# Generated at 2022-06-22 23:26:26.377055
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    This method will instantiate the SunOSHardwareCollector class.
    The method will fail if the class cannot be instantiated.
    """
    collector = SunOSHardwareCollector()
    assert collector is not None


# Generated at 2022-06-22 23:26:34.451079
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_called = False

        def run_command(self, cmd):
            self.run_command_called = True
            # Mocking successful kstat command output

# Generated at 2022-06-22 23:26:47.213515
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = SunOSHardware()
    # Create mock object to use instead of module.run_command
    mock_module = MockModule(module)
    # SunOSHardware.get_memory_facts() calls module.run_command twice,
    # therefore we have to set 2 side effects:
    mock_module.run_command.side_effect = [
        (0, 'Memory size: 1024 Megabytes', ''),
        (1, '', ''),
    ]
    module = mock_module
    memory_facts = module.get_memory_facts()
    # Assert values returned by method SunOSHardware.get_memory_facts()
    assert memory_facts.get('memtotal_mb') == 1024
    assert memory_facts.get('swapfree_mb') == 0
    assert memory_facts.get('swaptotal_mb') == 0


# Generated at 2022-06-22 23:26:51.234371
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hwCollector = SunOSHardwareCollector({'platform': 'SunOS'})
    assert hwCollector._platform == 'SunOS'
    assert hwCollector._fact_class == SunOSHardware
    assert hwCollector.required_facts == {'platform'}

# Generated at 2022-06-22 23:26:53.715623
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()

    assert hardware.cpu != {}

# Generated at 2022-06-22 23:27:01.861207
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Creating test object.
    test_object = SunOSHardware()
    test_object.module = MockAnsibleModule()
    expected_total_memory = 100
    test_object.module.run_command.return_value = (0, 'Memory size: ' + str(expected_total_memory) + ' Megabytes', '')
    test_object.module.run_command.return_value = (0, '', '')

    # Setting up return values
    test_object.module.run_command.return_value = (0, 'swap -s\n total: 32761504k bytes allocated + 176708k reserved = 32938212k used, 838212k available', '')

    # Actual return value of the tested method
    actual_facts = test_object.get_memory_facts()

    # Assertion
    test_

# Generated at 2022-06-22 23:27:07.450935
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {}
    facts['platform'] = 'SunOS'
    factCollector = SunOSHardwareCollector(facts, None)
    assert factCollector
    assert factCollector._fact_class == SunOSHardware
    assert factCollector._platform == 'SunOS'
    assert factCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:27:14.181398
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MagicMock()
    module.run_command.return_value = 0, "", ""
    module.get_bin_path.return_value = "/usr/bin/prtdiag"
    module.get_file_content.return_value = ""
    module.run_command_environ_update = dict()
    hardware = SunOSHardware(module=module)

    returned_values = hardware.populate()

    assert hardware.platform == 'SunOS'

    assert returned_values['processor']
    assert returned_values['processor_count']
    assert returned_values['processor_cores']
    assert returned_values['memtotal_mb']
    assert returned_values['swapfree_mb']
    assert returned_values['swaptotal_mb']
    assert returned_values['swap_allocated_mb']
   

# Generated at 2022-06-22 23:27:16.197874
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    result = SunOSHardwareCollector()

    assert result.fact_class is SunOSHardware

# Generated at 2022-06-22 23:27:25.516717
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create a test module
    module = AnsibleModule(argument_spec={})
    # Create the facts instance
    SunOSHardwareInst = SunOSHardware(module)
    # Create expected results

# Generated at 2022-06-22 23:27:32.255182
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = SunOSHardwareCollector(module=module)
    hardware_collector.collect()

    hardware_facts = hardware_collector.get_facts()

    assert hardware_facts['ansible_processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'



# Generated at 2022-06-22 23:27:39.633102
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({})

    assert hardware.get_cpu_facts() == {'processor': []}
    assert hardware.get_memory_facts() == {}
    assert hardware.get_device_facts() == {'devices': {}}
    assert hardware.get_dmi_facts() == {}
    assert hardware.get_uptime_facts() == {}
    assert hardware.get_mount_facts() == {'mounts': []}

# Generated at 2022-06-22 23:27:45.376126
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware.get_cpu_facts(None)

    assert isinstance(cpu_facts['processor'], list)
    assert isinstance(cpu_facts['processor_count'], int)
    assert isinstance(cpu_facts['processor_cores'], (int, str))


# Generated at 2022-06-22 23:27:49.274071
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardwareCollector.collect(module=module, collected_facts={'platform': 'SunOS'})
    assert hardware.get('processor')[0] == 'SUNW,UltraSPARC'
    pass

# Generated at 2022-06-22 23:27:53.524670
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw_collector = SunOSHardwareCollector()
    assert hw_collector is not None
    assert hw_collector._fact_class == SunOSHardware
    assert hw_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:28:00.410958
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command(['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time']).return_value = (0, 1548249689, "")

    sunos_hardware = SunOSHardware(module)

    uptime_facts = sunos_hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689), "uptime_seconds return invalid value"


# Generated at 2022-06-22 23:28:14.041533
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Test environment
    class MockModule(object):
        def __init__(self, out, err=''):
            self.run_command_out = out
            self.run_command_err = err

        def run_command(self, args, check_rc=True):
            return (0, self.run_command_out, self.run_command_err)

    test_obj = SunOSHardware(MockModule(kstat_cpu_info_out))

    # Test method
    cpu_facts = test_obj.get_cpu_facts()

    # Test results
    assert cpu_facts == {'processor': ['UltraSPARC-T1 @ 1GHz', 'UltraSPARC-T1 @ 1GHz'],
                         'processor_cores': 2,
                         'processor_count': 2}



# Generated at 2022-06-22 23:28:26.789669
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:28:37.215040
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:28:50.393699
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:28:55.146123
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'
    assert isinstance(obj.required_facts, set)
    assert obj.required_facts == set(['platform'])


# Generated at 2022-06-22 23:29:06.640361
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    # Check result of methods get_cpu_facts, get_memory_facts, get_dmi_facts, get_device_facts, get_mount_facts
    # and get_uptime_facts of class SunOSHardware
    get_cpu_facts_result = SunOSHardware(module).get_cpu_facts()
    get_memory_facts_result = SunOSHardware(module).get_memory_facts()
    get_dmi_facts_result = SunOSHardware(module).get_dmi_facts()
    get_device_facts_result = SunOSHardware(module).get_device_facts()
    get_mount_facts_result = SunOSHardware(module).get_mount_facts()
    get_uptime_

# Generated at 2022-06-22 23:29:12.513854
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = lambda x: (0, HELPER_RETURN_PRTCONF, None)
    hardware = SunOSHardware(module)
    nr_mb_memory = hardware.get_memory_facts()['memtotal_mb']
    assert nr_mb_memory == HELPER_RETURN_PRTCONF_PARSED_MEMORY


# Generated at 2022-06-22 23:29:24.995700
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_object = SunOSHardware(module)
    # Expected results

# Generated at 2022-06-22 23:29:28.780408
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Return a dictionary containing facts about the system's hardware

    :return dict: A dictionary containing facts about the system's hardware.
    """
    facts = SunOSHardware().populate()
    assert facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-22 23:29:37.344557
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Test parser for the SunOS hardware parser

    Sample output below:
    # Memory size: 2048 Megabytes
    # ===========================
    Memory size: 2048 Megabytes
    ===================================

    """
    parser = SunOSHardware()
    out = """# Memory size: 2048 Megabytes
    # ===========================
    Memory size: 2048 Megabytes
    ===================================
    """
    result = parser.get_memory_facts('', out)
    ansible_facts = {'memtotal_mb': 2048, 'swaptotal_mb': 256, 'swap_allocated_mb': 0, 'swap_reserved_mb': 0, 'swapfree_mb': 256}
    assert result == ansible_facts

# Generated at 2022-06-22 23:29:49.713081
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MagicMock()
    module.run_command.side_effect = [
        (0, u'Memory size: 32 Megabytes', ''),
        (0, u'Total swap space: 2048 Megabytes\n'
           u'available\n'
           u'1024 Megabytes allocated \n'
           u' 1024 Megabytes reserved \n'
           u'1024 Megabytes used, 0 available',
           ''),
    ]
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['swapfree_mb'] == 1024
    assert memory_facts['swaptotal_mb'] == 2048
    assert memory_facts['swap_allocated_mb'] == 1024
    assert memory_facts['swap_reserved_mb'] == 1024

# Generated at 2022-06-22 23:30:02.925329
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Mock object for module input parameters
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, "cpu_info\n"
                                               "brand\ti86pc\n"
                                               "chip_id 0\n"
                                               "core_id 0\n"
                                               "implementation i386\n"
                                               "package_id 0\n"
                                               "state online\n"
                                               "clock_MHz 2400", '')

    # Mock object for module input parameters
    fact_class = SunOSHardware()

    # Execute _get_cpu_facts method and save the result
    cpu_facts = fact_class._get_cpu_facts(module_mock)

    # Test the execution result

# Generated at 2022-06-22 23:30:14.825924
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    obj = SunOSHardware()

# Generated at 2022-06-22 23:30:22.840306
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    This is a unit test for method get_memory_facts of class SunOSHardware
    """
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module=module)

    module.run_command = Mock(return_value=(1, 'System Configuration: Sun Microsystems sun4u', ''))
    mem_facts = hw.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 10_000
    assert mem_facts['swapfree_mb'] == 10_000
    assert mem_facts['swaptotal_mb'] == 20_000
    assert mem_facts['swap_allocated_mb'] == 30_000
    assert mem_facts['swap_reserved_mb'] == 40_000



# Generated at 2022-06-22 23:30:35.690007
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:30:46.494339
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    hardware = SunOSHardware(module)

    module.run_command.side_effect = [
        (0, "Memory size: 8192 Megabytes", None),
        (0, "8192M\t194M\t3874M\t569M\t4565M\t20474M", None)
    ]

    expected = {'memtotal_mb': 8192, 'swap_reserved_mb': 20474,
                'swapfree_mb': 565, 'swaptotal_mb': 20474,
                'swap_allocated_mb': 194}
    result = hardware.get_memory_facts()

    assert result == expected


# Generated at 2022-06-22 23:30:53.109414
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Run a test of the SunOSHardwareCollector constructor.
    """
    # This creates an instance of SunOSHardwareCollector
    hardware_collector = SunOSHardwareCollector()

    # Test the '_fact_class attribute of the SunOSHardwareCollector instance
    assert hardware_collector._fact_class == SunOSHardware

    # Test the '_platform' attribute of the SunOSHardwareCollector instance
    assert hardware_collector._platform == 'SunOS'


# Generated at 2022-06-22 23:30:57.013642
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = SunOSHardware({'module_setup': True})
    facts = m.get_memory_facts()
    assert facts['memtotal_mb'] == 6144
    assert facts['swap_reserved_mb'] == 0
    assert facts['swap_allocated_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swapfree_mb'] == 0


# Create list of devices for unit testing

# Generated at 2022-06-22 23:31:03.477771
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(argument_spec={})

    har_collector = SunOSHardwareCollector(module)
    assert har_collector.platform == 'SunOS'
    assert har_collector._fact_class.platform == 'SunOS'
    assert set(har_collector.required_facts) == set(['platform'])



# Generated at 2022-06-22 23:31:08.014701
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command(['/usr/bin/kstat', '-p'])
    test_module.run_command(['/usr/bin/kstat', '-p', 'sderr:::Product'])
    test_module.run_command(['/usr/bin/kstat', '-p', 'sderr:::Revision'])
    test_module.run_command(['/usr/bin/kstat', '-p', 'sderr:::Serial No'])
    test_module.run_command(['/usr/bin/kstat', '-p', 'sderr:::Size'])

# Generated at 2022-06-22 23:31:11.856629
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule({})
    collector_obj = SunOSHardwareCollector(module)
    assert(collector_obj._fact_class.platform == 'SunOS')
    assert(collector_obj.required_facts == {'platform'})



# Generated at 2022-06-22 23:31:24.156275
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Unit test for method get_device_facts of class SunOSHardware.
    """
    device_facts = {
        'devices': {
            'sd0': {
                'hard_errors': '0',
                'illegal_request': '0',
                'media_errors': '0',
                'predictive_failure_analysis': '0',
                'product': 'VBOX HARDDISK',
                'revision': '1.0',
                'serial': 'VB0ad2ec4d-074a',
                'size': '53687091200',
                'soft_errors': '0',
                'transport_errors': '0',
                'vendor': 'ATA'
            }
        }
    }

# Generated at 2022-06-22 23:31:33.502993
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock
    module.run_command = run_command_mock

    hardware_object = SunOSHardware(module)
    memory_facts = hardware_object.get_memory_facts()

    assert memory_facts
    assert memory_facts['memtotal_mb'] == 32768
    assert memory_facts['swap_allocated_mb']
    assert memory_facts['swap_reserved_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']


# Generated at 2022-06-22 23:31:38.695015
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    result = SunOSHardware.get_memory_facts(None)

    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swap_allocated_mb' in result
    assert 'swap_reserved_mb' in result

# Generated at 2022-06-22 23:31:41.741508
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    fact_data = SunOSHardware().get_device_facts()
    assert isinstance(fact_data['devices'], dict)
    assert fact_data['devices']

# Generated at 2022-06-22 23:31:45.365788
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert hc.fact_class == SunOSHardware
    assert hc.platform == 'SunOS'
    assert hc.required_facts == set(['platform'])

# Generated at 2022-06-22 23:31:51.574823
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Test to check if all required parameters are initialised
    """
    # Test to check if inherited class is SunOSHardwareCollector
    assert isinstance(SunOSHardwareCollector(), HardwareCollector), "Class not inherited"

    # Test to check if all required parameters are initialised
    assert SunOSHardwareCollector._platform == 'SunOS', "Platform mismatch"
    assert SunOSHardwareCollector._fact_class == SunOSHardware, "Fact class mismatch"
    assert SunOSHardwareCollector.required_facts == set(['platform']), "required fact mismatch"

# Generated at 2022-06-22 23:31:54.574306
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector(None).get_all_facts()

# Generated at 2022-06-22 23:32:04.305018
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='list')
        )
    )
    set_module_args(dict(gather_subset=['all']))
    SunOSHardware.get_system_facts = Mock(return_value=dict(
        ansible_all_ipv4_addresses=['1.1.1.1', '2.2.2.2'],
        ansible_all_ipv6_addresses=['::1', '::2'],
    ))
    inst = SunOSHardware()
    inst.module = module

# Generated at 2022-06-22 23:32:08.762463
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware.platform == 'SunOS'
    assert hardware.get_cpu_facts() == {'processor': []}



# Generated at 2022-06-22 23:32:11.121333
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()

# Generated at 2022-06-22 23:32:14.329537
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule({})
    SunOSHardware.run_command = lambda *args, **kwargs: (0, "", "")
    SunOSHardware.get_uptime_facts(module)

# Generated at 2022-06-22 23:32:22.050041
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Tests for SunOSHardware class method: get_dmi_facts
    """
    module = FakeAnsibleModule()
    sunoshw = SunOSHardware(module=module)
    sunoshw.get_dmi_facts(collected_facts=None)
    assert sunoshw.facts['system_vendor'] == 'Oracle Corporation'
    assert sunoshw.facts['product_name'] == 'VirtualBox'

# Generated at 2022-06-22 23:32:25.307766
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert(memory_facts['memtotal_mb'] >= 0)

# Generated at 2022-06-22 23:32:37.159743
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:40.666657
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    '''
    Test the constructor of class SunOSHardware
    '''
    module = AnsibleModuleMock()
    sunos_hardware = SunOSHardware(module=module)
    assert sunos_hardware.__class__.__name__ == "SunOSHardware"



# Generated at 2022-06-22 23:32:51.418390
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec=dict())
    cmd = ['/usr/sbin/swap', '-s']
    out = """total: 16384000k bytes allocated + 6291456k reserved = 22675464k used, 31371764k available
"""
    set_module_args(dict(
        ansible_facts=dict(
            ansible_processor=['foo'],
            ansible_machine='',
        )
    ))
    hardware = SunOSHardware(module)
    rc, out, err = hardware.module.run_command(cmd)
    hardware.populate(collected_facts={'ansible_processor': ['foo']})

# Generated at 2022-06-22 23:32:55.217015
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock({
        'command': 'command',
        'run_command': 'run_command',
        'get_bin_path': 'get_bin_path'
    })
    hardware = SunOSHardware(module)
    facts = hardware.populate()
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'processor' in facts

# Generated at 2022-06-22 23:32:57.125346
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:33:06.930392
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # use argparse to parse the command line
    class FakeModule(object):

        def __init__(self, out, err):
            self.run_command_out = out
            self.run_command_err = err
            self.run_command_rc = 0

        def fail_json(self, **kwargs):
            pass

        def run_command(self, cmd, check_rc=True, environ_update=None):
            return self.run_command_rc, self.run_command_out, self.run_command_err


# Generated at 2022-06-22 23:33:19.624383
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts import ansible_module_get_module_path
    from ansible.module_utils.facts.hardware import SunOSHardware

    module_name = 'ansible_module_get_module_path'
    mock_module = type(module_name, (object,), {
        'get_bin_path': lambda self, module_name, opt_dirs: '/usr/bin/kstat'
    })

    # Define a fake run_command method returning appropriate output for SunOS
    fake_module = mock_module(module_name)

# Generated at 2022-06-22 23:33:20.674308
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock('SunOSHardware')
    hardware = SunOSHardware(module=module)

    assert hardware.module == module


# Generated at 2022-06-22 23:33:28.842805
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import mock
    m = mock.mock_open()
    with mock.patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.run_command', return_value=(0, 'unix:0:system_misc:boot_time\t%s' % int(time.time() - 100), '')):
        hw = SunOSHardware({})
        uptime = hw.get_uptime_facts()
        assert uptime['uptime_seconds'] == 100


# Generated at 2022-06-22 23:33:31.801136
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    assert hardware.platform == 'SunOS'


# Generated at 2022-06-22 23:33:35.838772
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock({'run_command': run_command_mock})

    uptime_facts = SunOSHardware(module).get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 100


# Generated at 2022-06-22 23:33:43.629304
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Setup
    module_mock = Mock()
    module_mock.run_command.return_value = (0, 'System Configuration: Sun Microsystems sun4v', '')
    stdout_mock = Mock()
    stdout_mock.splitlines.return_value = [ 'System Configuration: Sun Microsystems sun4v' ]
    collect_exit_mock = Mock()
    collect_exit_mock.splitlines.return_value = [ 'System Configuration: Sun Microsystems sun4v' ]
    hardware = SunOSHardware(module_mock)

# Generated at 2022-06-22 23:33:47.942226
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = MagicMock()
    module.params = {}
    module.run_command.return_value = [0, "", ""]
    facts = {}
    SunOSHardwareCollector(module=module, facts=facts)

# Generated at 2022-06-22 23:33:56.906926
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    class Object(object):
        pass

    m = Object()
    m.run_command = mock.Mock(return_value=(0, 'Test output', ''))
    SunOSHardware.module = m

    hw = SunOSHardware()

    hw.get_device_facts()

# Generated at 2022-06-22 23:34:05.193849
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule(run_command_results=[
        [0, CPU_KSTAT_COMMAND_OUTPUT, ''],
    ])

    hw = SunOSHardware(module=module)
    facts = hw.get_cpu_facts()

    assert facts == {
        'processor': ['Genuine Intel(R) CPU T2500  @ 2.00GHz', 'Genuine Intel(R) CPU T2500  @ 2.00GHz'],
        'processor_cores': 'NA',
        'processor_count': 2,
    }


# Generated at 2022-06-22 23:34:12.887235
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)

    # Mock the run_command method.
    def run_command_mock(module, command):
        return (0, "Memory size: 64 Megabytes", "")
    hw.module.run_command = run_command_mock

    facts_dict = hw.populate()
    assert 'memtotal_mb' in facts_dict
    assert facts_dict['memtotal_mb'] == 64


# Generated at 2022-06-22 23:34:26.465926
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    construct a SunOSHardware object with sample data from SKIR
    """

# Generated at 2022-06-22 23:34:37.582193
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, args, check_rc=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    # Test data, kstat command returns multiple CPU values

# Generated at 2022-06-22 23:34:41.195901
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = SunOSHardwareCollector.load_platform_subclass(None, {})()
    assert module.required_facts == set(['platform'])
    assert module._platform == 'SunOS'
    assert module._fact_class is SunOSHardware

# Generated at 2022-06-22 23:34:51.446008
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import copy
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.utils.display import Display
    display = Display()

    # Since this is running unit tests, we want to turn off automatic loading of
    # collectors. We're going to add a collector manually in the next line
    fact_collector = FactCollector(collected_facts={})
    fact_collector.add_collector(get_collector_instance('hardware'))
    fact_collector.collect({"collect_subset": "hardware"})
    collected_facts = fact_collector.get_collected_facts()
    collected_facts["ansible_facts"]["ansible_machine"] = "x86"
    test_dict = {}

# Generated at 2022-06-22 23:35:04.048429
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockSysModule():
        def __init__(self):
            self.rc = 0
            self.out = """
System Configuration:  Sun Microsystems  sun4u
Memory size: 256 Megabytes
Root device: /pci@1e,600000/scsi@2/sd@0,0
"""
        def get_bin_path(self, check_dirs=None):
            return '/usr/sbin/prtdiag'

        def run_command(self, cmd):
            return self.rc, self.out, None

    class MockModule():
        def __init__(self):
            self.sys = MockSysModule()

    class MockSunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = MockModule()

    hw = MockSunOSHardware()
    dmi