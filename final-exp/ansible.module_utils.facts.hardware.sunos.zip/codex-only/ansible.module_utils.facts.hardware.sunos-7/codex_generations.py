

# Generated at 2022-06-22 23:24:59.779613
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    hw = SunOSHardware()

    hw.populate(module.collected_facts)

# Generated at 2022-06-22 23:25:11.218683
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import mock_command

    MOCK_MODULES_PATH = ['ansible.module_utils.facts.hardware.sunos']
    MOCK_COMMAND_PATH = 'ansible.module_utils.facts.utils.command'

    command_output = """
Memory size: 8192 Megabytes
"""
    swap_command_output = """
total: 46127080k bytes allocated + 6185928k reserved = 52312008k used, 7709524k available
"""
    swap_command_path = 'ansible.module_utils.facts.utils.swap_command'

    prtconf_mock = mock_command(command_output=command_output)
    swap_mock

# Generated at 2022-06-22 23:25:17.397231
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts = MagicMock()
    hardware.get_dmi_facts.return_value = {'system_vendor': 'Fujitsu',
        'product_name': 'SPARC T4-2'}
    assert hardware.get_dmi_facts() == {'system_vendor': 'Fujitsu', 'product_name': 'SPARC T4-2'}



# Generated at 2022-06-22 23:25:22.980811
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    '''HardwareCollector_SunOS_test_SunOSHardware_populate
    This unit test is for testing the populate method of the SunOSHardware class.
    '''

    dmi_facts_dict = {'system_vendor': 'Oracle Corporation',
                      'product_name': 'sunfirev445'}

    test_class = SunOSHardware()
    test_class.populate()
    ix = 0
    for item in dmi_facts_dict:
        assert test_class.facts[item] == dmi_facts_dict[item]



# Generated at 2022-06-22 23:25:26.205773
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Unit test for constructor of class SunOSHardwareCollector
    """
    required_facts = set(['platform'])

    sunos_hw_collector = SunOSHardwareCollector()
    assert sunos_hw_collector.required_facts == required_facts
    assert sunos_hw_collector._platform == 'SunOS'
    assert sunos_hw_collector._fact_class == SunOSHardware

# Generated at 2022-06-22 23:25:28.426120
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunoshardware = SunOSHardware()
    assert sunoshardware.platform == 'SunOS'

# Generated at 2022-06-22 23:25:37.422577
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Validate the output of the method get_memory_facts of SunOSHardware class.
    """
    obj = SunOSHardware()

    rc, out, err = obj.module.run_command("/usr/sbin/swap -s")
    allocated = int(out.split()[1][:-1])
    reserved = int(out.split()[5][:-1])
    used = int(out.split()[8][:-1])
    free = int(out.split()[10][:-1])

    memory_facts = obj.get_memory_facts()

    assert memory_facts['memtotal_mb'] == int(out.split()[2])
    assert memory_facts['swapfree_mb'] == (free // 1024)

# Generated at 2022-06-22 23:25:45.404112
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    SunOSHardware = SunOSHardware()
    setattr(SunOSHardware, '_boot_time', SunOSHardware)
    setattr(SunOSHardware, '_current_time', SunOSHardware)
    setattr(SunOSHardware, '_convert_to_seconds', SunOSHardware)
    setattr(SunOSHardware, '_uptime_seconds', SunOSHardware)

# Generated at 2022-06-22 23:25:51.648488
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)

    # mocking kstat utility output
    module.run_command = MagicMock(return_value=(0, "unix:0:system_misc:boot_time    1548249689", ""))

    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689), "Uptime seconds must match current time - boot time."

# Generated at 2022-06-22 23:25:52.712609
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSHardware


# Generated at 2022-06-22 23:25:59.130386
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    m = SunOSHardware()

    # Generate a dummy module
    class dummy_module(object):
        def __init__(self):
            pass


# Generated at 2022-06-22 23:26:06.394183
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Setup test
    m = SunOSHardware()
    m.module = type('obj', (object,), {'run_command': test_SunOSHardware_get_cpu_facts.run_command})

    # Test get_cpu_facts
    cpu_facts = m.get_cpu_facts()

    # Assertions
    assert not cpu_facts['processor'], "expected empty but got %s" % (cpu_facts['processor'])
    assert cpu_facts['processor_count'] == 0, "expected 0 but got %s" % (cpu_facts['processor_count'])
    assert cpu_facts['processor_cores'] == 0, "expected 0 but got %s" % (cpu_facts['processor_cores'])



# Generated at 2022-06-22 23:26:12.377955
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import sys
    import platform

    if platform.uname()[0] != 'SunOS':
        sys.exit()

    module = AnsibleModule(
        argument_spec = dict()
    )
    SunOSHardware(module).populate()

if __name__ == '__main__':
    test_SunOSHardware_populate()

# Generated at 2022-06-22 23:26:21.418856
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'Memory size: 65535 Megabytes', ''))
    hardware = SunOSHardware(module)
    fact_data = hardware.get_memory_facts()
    assert fact_data['memtotal_mb'] == 65535
    assert fact_data['swapfree_mb'] == 0
    assert fact_data['swaptotal_mb'] == 0
    assert fact_data['swap_allocated_mb'] == 0
    assert fact_data['swap_reserved_mb'] == 0



# Generated at 2022-06-22 23:26:31.991228
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(argument_spec={})

    # Create a class that can pass the test
    class TestSunOSHardware:
        module = module

        @timeout.timeout()
        def get_mount_facts(self):
            return mount_facts

        def get_memory_facts(self):
            return memory_facts

        def get_uptime_facts(self):
            return uptime_facts

        def get_device_facts(self):
            return device_facts

        def get_dmi_facts(self):
            return dmi_facts

        def get_cpu_facts(self):
            return cpu_facts

        def run_command(self, cmd, *args, **kwargs):
            return rc, out, err

    # Create some facts we can return from the test

# Generated at 2022-06-22 23:26:43.211891
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Create a SunOSHardware object and do some testing
    test_hardware = SunOSHardware(None)
    facts = test_hardware.populate()
    assert 'processor' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'mounts' in facts
    assert 'system_vendor' in facts
    assert 'product_name' in facts
    assert 'devices' in facts

# Generated at 2022-06-22 23:26:47.332046
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    SunOSHardware.get_memory_facts(SunOSHardware(module))



# Generated at 2022-06-22 23:26:54.460183
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    memory_facts = SunOSHardware().get_memory_facts()
    assert isinstance(memory_facts, dict)
    assert isinstance(memory_facts['memtotal_mb'], int)
    assert isinstance(memory_facts['swapfree_mb'], int)
    assert isinstance(memory_facts['swaptotal_mb'], int)
    assert isinstance(memory_facts['swap_allocated_mb'], int)
    assert isinstance(memory_facts['swap_reserved_mb'], int)

# Generated at 2022-06-22 23:27:02.262449
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(None)

# Generated at 2022-06-22 23:27:09.548256
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list'),
            'filter': dict(default='*', type='str'),
        },
        supports_check_mode=True,
    )
    obj = SunOSHardware(module)
    result = obj.populate()
    assert result['processor_cores'] is not None
    assert result['processor_count'] is not None
    assert result['processor'] is not None


# Generated at 2022-06-22 23:27:22.742212
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:25.067499
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.sunos.hardware import SunOSHardware

    hardware = SunOSHardware(dict())
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:27:30.280521
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    obj = SunOSHardware(module)
    dmi = obj.get_dmi_facts()

    assert dmi['system_vendor'] == 'Fujitsu'
    assert dmi['product_name'] == 'SPARC Enterprise T5120'



# Generated at 2022-06-22 23:27:37.836553
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    obj = SunOSHardware(dict())
    rc = 1

# Generated at 2022-06-22 23:27:39.001941
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # FIXME
    pass



# Generated at 2022-06-22 23:27:42.978643
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """ Test nxos_facts.SunOSHardware.get_dmi_facts
    """
    m = SunOSHardware()
    m.module = FakeModule()

    m.module.run_command_environ_update = {}

    m.module.run_command = FakeCommand(
        (
            1,
            'System Configuration: VMware, Inc. VMware Virtual Platform\n',
            '',
        ),
    )

    m.get_dmi_facts()

    assert m.dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert m.dmi_facts['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-22 23:27:50.493581
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    hardware.populate()

    # hardware facts
    hardware_facts = hardware.get_facts()
    assert hardware_facts.get('swap_reserved_mb')
    assert hardware_facts.get('swap_allocated_mb')
    assert hardware_facts.get('ansible_devices')
    assert hardware_facts.get('ansible_mounts')
    assert hardware_facts.get('ansible_system_vendor')
    assert hardware_facts.get('ansible_product_name')



# Generated at 2022-06-22 23:27:53.064303
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = SunOSHardwareCollector.collect(None)
    # We can only test that the fact terminates
    assert 'processor' in facts


# Generated at 2022-06-22 23:28:01.987548
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule({}, supports_check_mode=True)
    # prtdiag returns a different output depending on the
    # architecture. We need to cover both cases.
    sunos_facts = SunOSHardware(module)
    cpu_facts = sunos_facts.get_cpu_facts()

    if cpu_facts['processor_count'] == 1:
        assert cpu_facts['processor'][0] == 'SUNW,UltraSPARC-IIIi @ 1350MHz'
    else:
        assert cpu_facts['processor'][0] == 'SUNW,SPARC-Enterprise-T5220 @ 1625MHz'
        assert cpu_facts['processor'][1] == 'SUNW,SPARC-Enterprise-T5220 @ 1625MHz'



# Generated at 2022-06-22 23:28:15.188370
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    mock_module = type('AnsibleModule', (object,), {
        "run_command": MagicMock(return_value=(0, b'', b'')),
        "get_bin_path": MagicMock(return_value='')})()


# Generated at 2022-06-22 23:28:19.858717
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])
    assert SunOSHardwareCollector._fact_class == SunOSHardware


# Generated at 2022-06-22 23:28:27.802778
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    # create SunOSHardware object
    sunOSHardwareObj = SunOSHardware()

    populate_return_value = {'processor_cores': 'NA',
                             'processor_count': 16,
                             'memtotal_mb': 94751,
                             'swapfree_mb': 7542,
                             'swaptotal_mb': 23500,
                             'swap_allocated_mb': 0,
                             'swap_reserved_mb': 0}

    assert sunOSHardwareObj.populate() == populate_return_value

# Generated at 2022-06-22 23:28:30.384025
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert len(hardware_collector.required_facts) == 1

# Generated at 2022-06-22 23:28:32.899662
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    fact_instance = SunOSHardware()
    fact_instance.module = module
    result = fact_instance.get_device_facts()
    assert isinstance(result, dict)
    assert 'devices' in result



# Generated at 2022-06-22 23:28:41.965586
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # Test case 1
    module = FactModule()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/kstat')
    out = 'module: cpu_info1\nchip_id: 0\nclock_MHz: 2500\nimplementation: sun4v\n\nmodule: cpu_info2\nchip_id: 1\nclock_MHz: 2300\nimplementation: sun4v'

    # create instance of class SunOSHardware
    c = SunOSHardware(module)
    # create mock of method run_command
    c.module.run_command = MagicMock(return_value=(0, out, ''))
    # run method get_cpu_facts of class SunOSHardware
    res

# Generated at 2022-06-22 23:28:55.054033
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    module = get_module()
    hardware = SunOSHardware(module)

    out = ('Memory size: 8192 Megabytes')
    test_memtotal_mb = (8192, out)
    mem = hardware.get_memory_facts()
    assert 'memtotal_mb' in mem
    assert mem['memtotal_mb'] == test_memtotal_mb[0]

    out = ('|1024|0|891852|879502|726592|248290|7|0|0|0|0|0|0|0|0|0|0|0')
    test_allocated = (891852, out)
    test_reserved = (879502, out)
    test_used = (726592, out)

# Generated at 2022-06-22 23:29:04.463604
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # mock object for AnsibleModule
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    # create SunOSHardware object
    sunoshardware = SunOSHardware(module)
    # call method get_device_facts
    facts = sunoshardware.get_device_facts()
    assert facts['devices']
    assert ('sd0' in facts['devices'])
    assert ('sd1' in facts['devices'])

# Helper to mock an AnsibleModule object

# Generated at 2022-06-22 23:29:13.535709
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule:
        def run_command(self, cmd):
            out = 'unix:0:system_misc:boot_time  1548249689'
            return (0, out, None)

    class FakeHardwareCollector:
        module = FakeModule()
        fact_class = SunOSHardware()

    hw_collector = FakeHardwareCollector()

    hw_collector.collect()

    uptime_facts = hw_collector.facts.get('ansible_facts').get('uptime_seconds')
    assert uptime_facts
    assert isinstance(uptime_facts, int)
    assert uptime_facts >= 0

# Generated at 2022-06-22 23:29:16.814815
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import random

    class FakeModule(object):
        def run_command(self, cmd):
            return 0, str(int(time.time() - random.randint(0, 10000))), ''

    facts = {}
    SunOSHardwareCollector(FakeModule()).collect(facts, None)

    if 'uptime_seconds' in facts:
        assert facts['uptime_seconds'] >= 0
    else:
        assert False

# Generated at 2022-06-22 23:29:29.412601
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test data
    data = {
        "ansible_facts": {
            "ansible_product_name": "T2000",
            "ansible_system_vendor": "Sun Microsystems"
        }
    }
    test_lines = [
        "System Configuration: SUN T2000",
        "System Configuration: SUN T2000   sun4v",
        "System Configuration: SUN T2000   sun4v  ",
        "System Configuration: SUN T2000 UP"
    ]

    # Call the method
    test_obj = SunOSHardware()
    result = SunOSHardware.get_dmi_facts(test_obj)

    # Verify the data
    assert result == data['ansible_facts']

    # Call the method with the test data
    for test_line in test_lines:
        result = SunOSHardware.get_

# Generated at 2022-06-22 23:29:32.230036
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardwareCollector = SunOSHardwareCollector()
    assert 'SunOS' == hardwareCollector._platform
    assert 'SunOSHardware' == hardwareCollector._fact_class.__name__


# Generated at 2022-06-22 23:29:38.111113
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # This can be called standalone to aid in debugging
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    module.run_command_environ_update = {'LANG': 'en_US', 'LC_ALL': 'en_US', 'LC_NUMERIC': 'en_US'}

    test_hardware = SunOSHardware()
    test_hardware.module = module

    memory_facts = test_hardware.get_memory_facts()

    pprint(memory_facts)



# Generated at 2022-06-22 23:29:50.815902
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
   hw = SunOSHardware()
   prtdiag_binary_path = ''
   hw.module.get_bin_path = lambda x, opt_dirs: prtdiag_binary_path
   # do not attempt to run 'kstat cpu_info' command
   hw.get_cpu_facts = lambda: {}

   dmi_facts = {}

   # prtdiag not found on system
   dmi_facts['system_vendor'] = 'Sun Microsystems'
   dmi_facts['product_name'] = 'Sun Fire V245'

   prtdiag_binary_path = '/bin/false'
   hw.get_dmi_facts = lambda: dmi_facts

# Generated at 2022-06-22 23:29:54.346327
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()

    facts = SunOSHardware(module).populate()
    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'SPARC T5-2'



# Generated at 2022-06-22 23:30:05.809930
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    test_kstat_output_file_path = os.path.join(os.path.dirname(__file__), 'test_kstat_output')

    test_hardware = SunOSHardware()

    test_hardware.module = MockAnsibleModule()
    test_hardware.module.run_command.return_value = (0, open(test_kstat_output_file_path).read(), '')

    uptime_facts = test_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 138280



# Generated at 2022-06-22 23:30:13.603349
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.run_command = globals()['run_command']
    module.params = {}

    sunoshw = SunOSHardware(module=module)
    uptime_facts = sunoshw.get_uptime_facts()
    assert uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:30:18.902763
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Initialize the SunOSHardware class object
    sunos_fact_obj = SunOSHardware(dict())
    # assert to test the class object instantiation and attributes
    assert sunos_fact_obj._name == 'sunos'
    assert sunos_fact_obj._platform == 'SunOS'
    assert sunos_fact_obj.platform == 'SunOS'


# Generated at 2022-06-22 23:30:32.350834
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class module:
        run_command_environ_update = {'LANG': 'en_US.UTF-8', 'LC_ALL': 'en_US.UTF-8', 'LC_NUMERIC': 'en_US.UTF-8'}

        def run_command(self, *args, **kwargs):
            # Simulate output of /usr/sbin/prtconf
            prtconf_out = u'''
Memory size: 8192 Megabytes
'''
            # Simulate output of /usr/sbin/swap -s
            swap_out = u'''
total: 16384k bytes allocated + 16384k reserved = 32768k used, 9567360k available
'''


# Generated at 2022-06-22 23:30:44.571088
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # pylint: disable=invalid-name
    fake_module = type('module', (object,), {})()
    fake_module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    fake_module.run_command = lambda cmd: (0, cmd, "")
    SunOSHardware.platform = "SunOS"
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert "processor_count" in cpu_facts
    assert "processor_cores" in cpu_facts
    assert len(cpu_facts["processor"]) == cpu_facts["processor_count"]
    assert cpu_facts["processor_cores"] in [cpu_facts["processor_count"], "NA"]

# Generated at 2022-06-22 23:30:55.028565
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:31:04.913405
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MagicMock()
    hardware = SunOSHardware(module)
    # We need to create a dict of fact that are required by hardware module to work properly
    module.get_bin_path.return_value = False
    module.run_command.return_value = (0, '', '')

    res = hardware.populate()
    assert res['processor_cores'] == 'NA'
    assert res['memtotal_mb'] == None
    assert res['swap_allocated_mb'] == None
    assert res['swap_reserved_mb'] == None

# Generated at 2022-06-22 23:31:08.454976
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Tests for the constructor of SunOSHardware
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunoshardware = SunOSHardware(None)
    assert sunoshardware.platform == 'SunOS'

# Generated at 2022-06-22 23:31:14.236199
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_facts = hardware_obj.populate()

    assert isinstance(hardware_facts, dict)
    assert 'mounts' in hardware_facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    main()

# Generated at 2022-06-22 23:31:17.287309
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector(None)
    assert hardware_collector == {'SunOS': SunOSHardware}

# Generated at 2022-06-22 23:31:20.558639
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """Test SunOSHardware class"""
    module = AnsibleModule({})
    sunos = SunOSHardware(module)
    assert sunos.platform == 'SunOS'


# Generated at 2022-06-22 23:31:22.760737
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Test empty return dictionary
    assert SunOSHardware().get_memory_facts() == dict()

# Generated at 2022-06-22 23:31:32.169627
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Initialize the object SunOSHardware
    hardware_obj = SunOSHardware(None)
    # Declare the expected results
    expected_results = {'processor': ['SUNW,UltraSPARC-IIe @ 296MHz'], 'processor_cores': 'NA', 'processor_count': 1}
    # Invoke the method to get the cpu facts
    actual_results = hardware_obj.get_cpu_facts()
    # Assert if the expected results are same as the actual results
    assert actual_results == expected_results

# Unit test method for the class SunOSHardware

# Generated at 2022-06-22 23:31:35.678401
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    sunos_hwCollector = SunOSHardwareCollector()
    assert sunos_hwCollector._fact_class == SunOSHardware
    assert sunos_hwCollector._platform == 'SunOS'
    assert sunos_hwCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:31:39.594237
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    hw = SunOSHardware(module=Facts())
    hw.populate()

    # assert isinstance(hw.populate(), dict)



# Generated at 2022-06-22 23:31:50.336641
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeModule(platform='SunOS')
    hardware_sunos = SunOSHardware(module)
    hardware_facts = hardware_sunos.populate()

    assert hardware_facts['uptime_seconds'] == 7051
    assert isinstance(hardware_facts['uptime_seconds'], int)
    assert isinstance(hardware_facts['devices'], dict)
    assert isinstance(hardware_facts['devices']['sd0'], dict)
    assert isinstance(hardware_facts['devices']['sd0']['size'], str)
    assert 'GiB' in hardware_facts['devices']['sd0']['size']
    assert isinstance(hardware_facts['devices']['sd0']['product'], str)

# Generated at 2022-06-22 23:32:00.982559
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)
    data = hardware.get_cpu_facts({'ansible_machine': 'i86pc', 'processor_cores': 1})
    assert data['processor'][0] == 'Intel(r) Xeon(r) CPU N36L@ 1.20GHz @ 1659MHz'
    assert data['processor_cores'] == 8
    assert data['processor_cores'] == data['processor_count']

    data = hardware.get_cpu_facts({'ansible_machine': 'sparc', 'processor_cores': 1})
    assert data['processor'][0] == 'SUNW,SPARC-Enterprise-T5120'
    assert data['processor_cores'] == 16
    assert data['processor_cores'] == data['processor_count']

# Generated at 2022-06-22 23:32:07.140523
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hw = SunOSHardware()
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts
    assert dmi_facts['system_vendor'] == "Oracle Corporation"
    assert dmi_facts['product_name'] == "SUN FIRE X4270 M2"

# Generated at 2022-06-22 23:32:12.715051
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()

    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts

    assert isinstance(cpu_facts['processor_cores'], int)
    assert isinstance(cpu_facts['processor_count'], int)


# Generated at 2022-06-22 23:32:14.779548
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    my_collector = SunOSHardwareCollector(None)
    assert my_collector.platform == 'SunOS'

# Generated at 2022-06-22 23:32:27.146189
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test the method get_cpu_facts of class SunOSHardware
    """
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.run_command_environ_update=None


# Generated at 2022-06-22 23:32:32.072296
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """ test_SunOSHardwareCollector: Test class constructor SunOSHardwareCollector """
    fc = SunOSHardwareCollector()

    assert(fc)
    assert(fc._fact_class is SunOSHardware)
    assert(fc._platform == 'SunOS')


# Generated at 2022-06-22 23:32:40.538535
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = None
    module.run_command = run_command_stub
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert len(hardware.cpu_facts_stub_out) == 9
    assert len(cpu_facts) == 3
    assert cpu_facts['processor'] == ['Intel(R) Xeon(R) CPU E5-2670 v3 @ 2.30GHz']
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor_cores'] == 32


# Generated at 2022-06-22 23:32:53.590538
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-22 23:32:56.706527
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    f = SunOSHardwareCollector()
    assert f.required_facts == set(['platform'])
    assert f._platform == 'SunOS'
    assert f._fact_class == SunOSHardware


# Generated at 2022-06-22 23:33:06.770903
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = object()

    class MockRunCommand:
        def __init__(self):
            self.cmd = list()
            self.rc = 0
            self.out = None
            self.err = None

        def __call__(self, cmd, in_data=None, executable=None,
                data=None, binary_data=False, path_prefix=None, cwd=None,
                use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                umask=None, encoding=None):
            self.cmd = cmd
            return self.rc, self.out, self.err

    mrc = MockRunCommand()

    class SunOS(object):
        def __init__(self):
            self.run_command = mrc


# Generated at 2022-06-22 23:33:19.465882
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class FakeModule(object):
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def run_command(self, args, check_rc=True):
            return self.run_command_result

        def get_bin_path(self, name, opt_dirs=None):
            return None

    module = FakeModule(run_command_result=(0, '', ''))
    s = SunOSHardware()
    cpu_facts = s.get_cpu_facts(collected_facts={"ansible_machine": "i86pc"})
    assert cpu_facts['processor_cores'] == 0
    assert cpu_facts['processor_count'] == 0


# Generated at 2022-06-22 23:33:27.815089
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_instance = SunOSHardware()
    collected_facts = {'ansible_machine': 'i86pc',
                       'ansible_processor': ['Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz', 'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz', 'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz', 'Intel(R) Core(TM) i7-3630QM CPU @ 2.40GHz']}
    hardware_instance.populate(collected_facts)

# Generated at 2022-06-22 23:33:35.340768
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = SunOSHardware(module, 'platform', 'distribution', 'distribution_version')
    module.run_command.return_value = (0, 'Memory size: 8192 Megabytes', None)

    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 8192


# Generated at 2022-06-22 23:33:38.562571
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleStub()
    module.run_command_environ_update = {}

    s = SunOSHardware()
    s.populate()

    # No assert needed. If this does not throw an exception, the test succeeds.

# Generated at 2022-06-22 23:33:45.157770
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # method get_uptime_facts of class SunOSHardware requires a linux machine
    # with the "kstat" command. This fakes one.
    class MockModule:
        def run_command(self, cmd):
            return 0, "unix:0:system_misc:boot_time    1548249689", ""

    class Mock_facts:
        def __init__(self):
            self.ansible_facts = {"ansible_platform": "SunOS"}

    test_uptime = SunOSHardware(module=MockModule(), collected_facts=Mock_facts().ansible_facts)

    # uptime = time.time() - 1548249689
    assert test_uptime.get_uptime_facts()['uptime_seconds'] > time.time() - 1548249689

    # not a real test, but cannot load

# Generated at 2022-06-22 23:33:46.617402
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    facts = dict()
    h = SunOSHardware(module)
    h.populate(facts)
    assert h.platform == 'SunOS'
    assert h.module == module

# Generated at 2022-06-22 23:33:54.113241
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    def mock_run_command(module, cmd):
        return 0, "unix:0:system_misc:boot_time    1548249689", ''

    mock_module = type('module', (object,), dict(
        run_command=mock_run_command,
        params=type('params', (object,), dict(removes=[]))
    ))

    hw = SunOSHardware(module_executor=mock_module)

    assert(hw.get_uptime_facts()['uptime_seconds'] == int(time.time() - 1548249689))

# Generated at 2022-06-22 23:33:58.802760
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Unit test for the method get_device_facts of SunOSHardware.
    """
    sunos_hardware = SunOSHardware({})
    device_facts = sunos_hardware.get_device_facts()
    assert 'devices' in device_facts

# Generated at 2022-06-22 23:34:00.015811
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    SunOSHardware().populate()

# Generated at 2022-06-22 23:34:02.157398
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    assert SunOSHardware(module) is not None


# Generated at 2022-06-22 23:34:03.477373
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # FIXME
    pass

# Generated at 2022-06-22 23:34:14.969569
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # This is a fake 'module' object to be able to mock results of run_command()
    class MockModule:
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr
        def run_command(self, cmd, warn_only=False):
            return (self.rc, self.stdout, self.stderr)
    # this is a fake 'time' object to be able to mock results of time.time()
    class MockTime:
        def __init__(self, current_time):
            self.current_time = current_time
        def time(self):
            return self.current_time

    # Mock kstat output for boot time and set current time
    rc = 0

# Generated at 2022-06-22 23:34:25.361126
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('Dummy', (object,), {'run_command': run_command_test})
    module.get_bin_path = lambda arg: arg
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    # Check the count of devices and their product
    assert len(device_facts['devices']) == 1
    for device in device_facts['devices']:
        assert device_facts['devices'][device]['product'] == "VBOX HARDDISK"



# Generated at 2022-06-22 23:34:35.378026
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'sderr:::Product VBOX HARDDISK\nsderr:::Hard Errors 0', ''))
    SunOSHardwareCollector.required_facts = set()
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    assert device_facts
    assert 'devices' in device_facts
    assert device_facts['devices']
    assert 'sd0' in device_facts['devices']
    assert device_facts['devices']['sd0']
    assert 'product' in device_facts['devices']['sd0']
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-22 23:34:42.043688
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    sun = SunOSHardware()
    facts = sun.populate()

    assert type(facts['processor_cores']) is int
    assert type(facts['processor_count']) is int
    assert facts['processor_cores'] > 0
    assert facts['processor_count'] > 0
    assert type(facts['processor']) is list
    assert len(facts['processor']) == facts['processor_count']



# Generated at 2022-06-22 23:34:49.354674
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """ Test fixture to test the method get_uptime_facts() of the class SunOSHardware """
    class ModuleMock:
        def run_command(self, cmd):
            return 0, "unix:0:system_misc:boot_time    1548249689", ""

    hardware = SunOSHardware(ModuleMock())
    uptime_facts = hardware.get_uptime_facts()
    expected_uptime = int(time.time() - 1548249689)
    assert uptime_facts['uptime_seconds'] == expected_uptime


# Generated at 2022-06-22 23:34:55.852412
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    hardware = SunOSHardware()
    hardware.module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # fake kstat
    out = (
        'module:         cpu_info\n'
        'class:          misc\n'
        'instance:       0\n'
        'chip_id:        0\n'
        'implementation: SUNW,UltraSPARC-IIIi\n'
        'brand:          SUNW,UltraSPARC-IIIi\n'
        'clock_MHz:      1002\n'
        'state:          on-line\n'
        ''
    )
    hardware.module.run_command.return_value = (0, out, '')

    cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-22 23:35:04.232316
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('obj', (object,), {'run_command': mock_run_command})
    hardware = SunOSHardware(module)
    collected_facts = {
        'ansible_machine': 'sparc',
    }
    expected_facts = {
        'memtotal_mb': 117,
        'swapfree_mb': 1048,
        'swaptotal_mb': 1256,
        'swap_allocated_mb': 256,
        'swap_reserved_mb': 256,
    }
    actual_facts = hardware.get_memory_facts()
    assert_dict_contains_subset(expected_facts, actual_facts)

