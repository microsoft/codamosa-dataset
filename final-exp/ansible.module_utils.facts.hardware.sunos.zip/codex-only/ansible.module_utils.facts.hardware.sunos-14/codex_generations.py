

# Generated at 2022-06-22 23:25:09.834364
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_data = {
        'devices': {
            'sd0': {
                'product': 'product',
                'revision': 'revision',
                'serial': 'serial',
                'size': '123',
                'vendor': 'vendor',
                'hard_errors': 'hard_errors',
                'soft_errors': 'soft_errors',
                'transport_errors': 'transport_errors',
                'media_errors': 'media_errors',
                'predictive_failure_analysis': 'predictive_failure_analysis',
                'illegal_request': 'illegal_request',
            }
        }
    }

    test_kstat_output = ''
    for k in test_data['devices']['sd0'].keys():
        test_kstat_output = test_kstat_

# Generated at 2022-06-22 23:25:18.896456
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = run_command

    dut = SunOSHardware(module)
    dut.populate()

    assert dut.facts['ansible_processor'] == ['SPARC-Enterprise T5120 @ 1200MHz', 'SPARC-Enterprise T5120 @ 1200MHz',
                                              'SPARC-Enterprise T5120 @ 1200MHz', 'SPARC-Enterprise T5120 @ 1200MHz',
                                              'SPARC-Enterprise T5120 @ 1200MHz', 'SPARC-Enterprise T5120 @ 1200MHz',
                                              'SPARC-Enterprise T5120 @ 1200MHz', 'SPARC-Enterprise T5120 @ 1200MHz']
    assert dut.facts['memtotal_mb'] == 16000

# Generated at 2022-06-22 23:25:25.410917
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'
    assert hardware.get_cpu_facts()
    assert hardware.get_memory_facts()
    assert hardware.get_dmi_facts()
    assert hardware.get_device_facts()
    assert hardware.get_uptime_facts()
    assert hardware.get_mount_facts()

# Generated at 2022-06-22 23:25:32.837778
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = MockModule()
    module.run_command = Mock(side_effect = [
        # prtdiag
        (0, "System Configuration: Sun Microsystems sun4u\n", ""),
    ])
    sunos_hw = SunOSHardware(module)
    dmi_facts = sunos_hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == "Sun Microsystems"
    assert dmi_facts['product_name'] == "sun4u"



# Generated at 2022-06-22 23:25:36.388046
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_hw = SunOSHardwareCollector(None)
    assert sun_hw is not None
    assert set(sun_hw.required_facts) == set(['platform'])
    assert sun_hw._fact_class == SunOSHardware
    assert sun_hw._platform == 'SunOS'

# Generated at 2022-06-22 23:25:48.943923
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:25:51.738823
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()

    assert x.required_facts == set(['platform'])
    assert x.platform == 'SunOS'
    assert x.fact_class == SunOSHardware


# Generated at 2022-06-22 23:25:58.833433
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:07.230736
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """This test checks for various values of the first line of prtdiag output and
    returns the corresponding system_vendor and product_name."""
    from ansible.module_utils.facts.collector.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.facts.collector.facts import Facts
    from ansible.module_utils.facts import timeout
    import mock

    f = Facts(collectors=[SunOSHardwareCollector])

    # isinstance() test
    assert isinstance(f, Facts)
    assert isinstance(f.collector[0], SunOSHardwareCollector)
    assert issubclass(SunOSHardwareCollector, HardwareCollector)

# Generated at 2022-06-22 23:26:19.858590
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    class MockModule:
        def __init__(self, run_command_results=None, get_bin_path_results=None, get_file_content_results=None):
            self.run_command_results = run_command_results or {}
            self.get_bin_path_results = get_bin_path_results or {}
            self.get_file_content_results = get_file_content_results or {}
            self.run_command_calls = []
            self.get_bin_path_calls = []
            self.get_file_content_calls = []
            self.run_command_environ_update = None

        def run_command(self, args, check_rc=True, close_fds=True):
            data = self.run_command_results.get(tuple(args))



# Generated at 2022-06-22 23:26:31.112818
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('DummyModule', (object,), {
                       'run_command': run_command,
                       'get_bin_path': lambda *a, **kw: '/usr/bin/prtdiag'
                   })()
    h = SunOSHardware(module)

    def _run_command(command):
        """Mock run_command"""

# Generated at 2022-06-22 23:26:44.359307
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Use a fake module object, since this test is a unit test, not an integration test,
    # and we therefore don't need to mock out the whole module object
    module = type('fakemodule', (), {'run_command': ''})
    module.run_command = mock.Mock(side_effect=['SunOS'])
    module.get_bin_path = mock.Mock(return_value='/usr/sbin/')
    # Get a SunOSHardware object
    sunoshardware = SunOSHardware(module)

    # Make sure that get_dmi_facts() works fine with a test string
    result = sunoshardware.get_dmi_facts({'ansible_system': 'SunOS'})
    assert result['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-22 23:26:52.099824
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """This function is used to unit test the get_uptime_facts method of the SunOSHardware class"""
    # Create a SunOSHardware object and call the get_uptime_facts method
    sunos_hardware = SunOSHardware()
    uptime_facts = sunos_hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] is not None

    # Check the format of the uptime_seconds value
    assert str(uptime_facts['uptime_seconds']).isdigit()

# Generated at 2022-06-22 23:27:01.099593
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys
    import io
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class FakeModule():
        def __init__(self):
            pass

        def run_command(self, command):
            if command == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return (0, 'unix:0:system_misc:boot_time    1234567890', '')
            return (1, None, None)

    module = FakeModule()
    hw = SunOSHardware()

    actual = hw.get_uptime_facts()

    assert 'uptime_seconds' in actual, "uptime fact is not present"

# Generated at 2022-06-22 23:27:06.721981
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()

    # Mock module
    module = type('', (), {})()
    hardware.module = module
    module.run_command = lambda cmd: (0, "Memory size: 8192 Megabytes", "")

    result = hardware.get_memory_facts()

    assert result["memtotal_mb"] == 8192


# Generated at 2022-06-22 23:27:11.873449
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda cmd: (0, 'System Configuration: Oracle Corporation Sun Fire X4170 M3 Server', '')
    test_instance = SunOSHardware(module=module)
    dmidict = {'system_vendor': 'Oracle Corporation', 'product_name': 'Sun Fire X4170 M3 Server'}
    assert test_instance.get_dmi_facts() == dmidict



# Generated at 2022-06-22 23:27:15.121063
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = None
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:27:17.864961
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts = {}
    device_facts = SunOSHardware.get_device_facts()
    assert isinstance(device_facts, dict)

# Generated at 2022-06-22 23:27:26.356480
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, cmd):
            if cmd[-1] == 'uname -i':
                return 0, 'sun4v', ''
            elif cmd[-1] == '/usr/platform/sun4v/sbin/prtdiag':
                return 0, 'System Configuration: Oracle Corporation sun4v SPARC Enterprise T5140', ''
        def get_bin_path(self, cmd, opt_dirs=None):
            if cmd == 'prtdiag':
                return '/usr/platform/sun4v/sbin/prtdiag'
    class MockFactCollector(object):
        def __init__(self):
            self.facts = {}
        def add_fact(self, k, v):
            self.facts[k] = v

# Generated at 2022-06-22 23:27:34.288741
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    fact_subclass = SunOSHardware(module)
    # Need to mock run_command()
    fact_subclass.run_command = lambda x: (0, "", "")
    fact_subclass.run_command.__str__ = lambda x: "run_command(%s)" % x
    facts = fact_subclass.populate()
    assert facts['processor_count'] == 1
    assert facts['processor'] == ['SUNW,Netra-T4 (chipid 0, clock 1500 MHz)']



# Generated at 2022-06-22 23:27:47.448114
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    fixture = [
        b"Memory size: 256 Megabytes",
        b"/usr/sbin/swap -s                     total: 4096708k bytes allocated + 9768k reserved = 4126476k used, 2270596k available",
    ]

    fixture_size = len(fixture)

    m = SunOSHardware()
    m.module.run_command.side_effect = fixture
    m.module.run_command.return_value = fixture[0]

    memory_facts = m.get_memory_facts()
    assert len(memory_facts) == 5
    assert memory_facts['memtotal_mb'] == b'256'
    assert memory_facts['swapfree_mb'] == b'2220'
    assert memory_facts['swaptotal_mb'] == b'4044'

# Generated at 2022-06-22 23:27:58.906809
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    class Object(object):
        def __init__(self):
            self.run_command_results = [
                [0,
                 'System Configuration: VMware, Inc. VMware Virtual Platform VMware ESXi 6.0.0 build-3029758',
                 ''],
                [0,
                 'System Configuration: Oracle Corporation sun4v Sun Fire X4170 M2 Server',
                 ''],
                [0,
                 'System Configuration: Sun Microsystems sun4v Sun Fire T2000',
                 ''],
                [0,
                 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)',
                 ''],
                [0,
                 'System Configuration: Fujitsu PRIMERGY RX300 S8',
                 ''],
            ]
            self.run_command_count = 0


# Generated at 2022-06-22 23:28:07.862962
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeModule()
    hardware = SunOSHardware(module)

    def run_command_mock(command):
        class Return:
            def __init__(self, output):
                self.output = output
        output = "Memory size: 4096 Megabytes"
        return Return(output)

    module.run_command = run_command_mock
    result = hardware.get_memory_facts()

    assert result['memtotal_mb'] == 4096



# Generated at 2022-06-22 23:28:12.418798
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    module.run_command.return_value = (0, "", "")
    module.run_command_environ_update = {}
    x = SunOSHardware(module)
    x.populate()
    assert module.run_command.call_count == 8


# Generated at 2022-06-22 23:28:17.258913
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={},
                           supports_check_mode=True)
    test_file = open('test/unit/module_utils/facts/hardware/test_SunOSHardware_get_cpu_facts.txt', 'r')
    test_output = test_file.read()
    test_file.close()
    hw = SunOSHardware(module)
    hw.populate()
    rc, out, err = module.run_command(['/usr/bin/kstat', 'cpu_info'], check_rc=True)
    assert out == test_output


# Generated at 2022-06-22 23:28:23.411527
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict(gather_subset='hardware'))
    ins = SunOSHardware(module)
    facts = ins.populate()

    assert facts['devices'] is not None
    assert 'sd0' in facts['devices'].keys()

# Generated at 2022-06-22 23:28:32.476959
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware({'module': FakeAnsibleModule()})
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz)']
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 7680
    assert hardware_facts['swapfree_mb'] == 3578
    assert hardware_facts['swaptotal_mb'] == 3578
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['uptime_seconds'] == 0

# Generated at 2022-06-22 23:28:38.052480
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_string = """
Physical Memory:
   Total: 8028 Megabytes
"""
    test_class = SunOSHardware()
    test_class.module = MockModule()
    test_class.module.run_command = Mock(return_value=(0, test_string, ""))
    result = test_class.get_memory_facts()
    assert (result['memtotal_mb'] == 8028)


# Generated at 2022-06-22 23:28:39.715184
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.populate()



# Generated at 2022-06-22 23:28:49.027451
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    module.run_command("/usr/bin/uname -i")
    module.run_command("/usr/bin/uname -i")
    module.run_command("/usr/platform/i86pc/sbin/prtdiag")
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts["system_vendor"] == "Oracle Corporation"
    assert dmi_facts["product_name"] == "Sun Blade X4-2B Server Module"



# Generated at 2022-06-22 23:29:01.827232
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Create a blank facts object
    facts = Facts()
    facts_dict = dict()

    # Create a FactsCollector
    facts_collector = FactsCollector(facts=facts, loader=None)

    # Create SunOSHardware class
    sunos_hw = SunOSHardware()

    # Populate SunOSHardware
    sunos_hw.populate(facts=facts_dict)

    # Test if all expected hardware keys are generated.
    assert len(sunos_hw._facts) == 12
    assert 'devices' in sunos_hw._facts.keys()
    assert 'processor' in sunos_hw._

# Generated at 2022-06-22 23:29:10.709359
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    d = {}
    d['ansible_sysname'] = 'SunOS'
    module = MockModule(**d)
    h = SunOSHardware(module=module)
    # When the value of kstat is greater than the current time,
    # the result of uptime_seconds should return negative value.
    # In this case, the value will be -(uptime_seconds - current time)
    rc, out, err = module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    current_time = int(time.time())
    boot_time = int(out.split('\t')[1])
    uptime_facts = h.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']
    assert uptime_seconds

# Generated at 2022-06-22 23:29:13.535338
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fact_class = SunOSHardwareCollector()
    fact_class.get_memory_facts()



# Generated at 2022-06-22 23:29:15.439166
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """Unit test for constructor of class SunOSHardwareCollector."""
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:29:28.032071
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import os
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.locale import get_best_encoding

    module = type('DummyModule', (object,), {'run_command': lambda *args, **kwargs: ['', '', '']})()
    encoding = get_best_encoding()

    mem_total = 1024 * 1024 * 1024
    mem_swapfree = 1024 * 1024 * 1024
    mem_swaptotal = mem_swapfree * 2
    mem_swap_allocated = mem_total
    mem_swap_reserved = mem_total

    os.environ['LANG'] = encoding
    os.environ['LC_ALL'] = encoding
    os.environ['LC_NUMERIC'] = encoding

# Generated at 2022-06-22 23:29:33.571264
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the ability to parse prtdiag output to determine the Vendor and the
    model of the system running Solaris
    """
    module = MockModule()
    test_class = SunOSHardware(module=module)
    test_class.get_dmi_facts()
    assert module.run_command.call_count == 1
    module.run_command.assert_called_with('/usr/bin/uname -i')


# Generated at 2022-06-22 23:29:40.443198
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test data:
    #   input: one system configuration line
    #   expected values: vendor and product name
    system_conf = "System Configuration: Oracle Corporation sun4v Sun Fire X4470 M2"
    expected_vendor = "Oracle Corporation"
    expected_product_name = "Sun Fire X4470 M2"

    sunoshw = SunOSHardware()
    dmi_facts = sunoshw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == expected_vendor
    assert dmi_facts['product_name'] == expected_product_name


# We don't want to test the whole class. Rather we split it up and test it by parts.
# The class is tested in a more comprehensive fashion by setup/facts/test.integration.yml

# Generated at 2022-06-22 23:29:47.050415
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    facts = SunOSHardware(module).populate()

    for fact in ('ansible_device_facts', 'ansible_dmi_facts',
                 'ansible_mount_facts', 'ansible_memory_facts',
                 'ansible_processor_count', 'ansible_processor_cores',
                 'ansible_processor', 'ansible_system_vendor'):
        assert fact in facts

# Generated at 2022-06-22 23:29:54.296662
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import sys

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = {}

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_calls[cmd] = self.run_command_calls.get(cmd, []) + [args]

        def fail_json(self, *args, **kwargs):
            raise RuntimeError('fail_json called')

        def get_bin_path(self, binary_name, option_dirs=None):
            return binary_name

    # Create a mock module
    module = MockModule()

    # Get an instance of the class to test
    hardware_instance = SunOSHardware(module)

    # Test that calling get_dmi_facts() with a real return value succeeds
    # FIXME

# Generated at 2022-06-22 23:30:07.023938
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware({})
    out = """sderr:::illegal_request       0
sderr:::media_errors         0
sderr:::predictive_failure_analysis        0
sderr:::product      VBOX HARDDISK   9
sderr:::revision     1.0
sderr:::serial       VB0ad2ec4d-074a
sderr:::size         53687091200
sderr:::soft_errors  0
sderr:::transport_errors        0
sderr:::vendor       ATA"""
    devices = hardware.get_device_facts(out)
    assert(devices['devices']['sderr0']['product'] == 'VBOX HARDDISK')

# Generated at 2022-06-22 23:30:19.240729
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type("AnsibleModule", (object,), {
        'run_command': lambda *a, **kw: (0, "sderr:0:sd0,err:Hard Errors     0\nsderr:0:sd0,err:Illegal Request 6\nsderr:0:sd1,err:Hard Errors     0\nsderr:0:sd1,err:Illegal Request 6", ""),
        'get_bin_path': lambda *a, **kw: '/usr/bin/kstat'
    })()
    s = SunOSHardware(module)
    facts = s.get_device_facts()


# Generated at 2022-06-22 23:30:32.775507
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test for device facts derived for sdderr kstats.
    """

    # Creating a fake module.

# Generated at 2022-06-22 23:30:45.370291
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware()
    expected_out = {'devices': {u'sd0': {'hard_errors': '0',
                                         'illegal_request': '0',
                                         'media_errors': '0',
                                         'predictive_failure_analysis': '0',
                                         'product': 'VBOX HARDDISK',
                                         'revision': '1.0',
                                         'serial': 'VB0ad2ec4d-074a',
                                         'size': '50G',
                                         'soft_errors': '0',
                                         'transport_errors': '0',
                                         'vendor': 'ATA'}}}
    with open('tests/data/kstat_output', 'r') as f:
        out = f.read()
    actual_out = m.get_device_

# Generated at 2022-06-22 23:30:48.859186
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.platform == 'SunOS'
    assert SunOSHardwareCollector._fact_class is SunOSHardware
    assert SunOSHardwareCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:30:52.702095
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    mock_module = MockModule()
    hc = SunOSHardwareCollector(mock_module, 'SunOS')

    assert hc._platform == 'SunOS'
    assert hc._fact_class == SunOSHardware
    assert hc.required_facts == set(['platform'])

# Generated at 2022-06-22 23:31:04.408532
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

# Generated at 2022-06-22 23:31:11.837438
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Check if setting the facts from data in class SunOSHardware works correctly.
    """
    module = FakeAnsibleModule()
    facts = SunOSHardware(module)
    facts.populate()

    # Check if the facts are set correctly.
    assert facts.facts['memtotal_mb'] == 8192
    assert facts.facts['swapfree_mb'] == 131072
    assert facts.facts['swaptotal_mb'] == 131072
    assert facts.facts['swap_allocated_mb'] == 0
    assert facts.facts['swap_reserved_mb'] == 0
    assert facts.facts['processor'] == ['GenuineIntel @ 1197MHz']
    assert facts.facts['processor_count'] == 1
    assert facts.facts['processor_cores'] == 1

# Generated at 2022-06-22 23:31:17.068907
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'ansible_machine': 'i86pc', 'ansible_system_vendor': 'Oracle Corporation'})

    assert hardware.system_vendor == 'Oracle Corporation'
    assert hardware.product_name == 'T5-2'

# Generated at 2022-06-22 23:31:26.638073
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    output_facts = {'devices': {'devices': {'sd0': {'product': 'VBOX HARDDISK',
                                                     'revision': '1.0',
                                                     'serial': 'VB0ad2ec4d-074a',
                                                     'size': '53687091200',
                                                     'vendor': 'ATA',
                                                     'hard_errors': '0',
                                                     'soft_errors': '0',
                                                     'transport_errors': '0',
                                                     'media_errors': '0',
                                                     'predictive_failure_analysis': '0',
                                                     'illegal_request': '6'}}}}
    test_SunOSHardware = SunOSHardware({})
    test_facts = test_SunOSHardware.get_device_facts()


# Generated at 2022-06-22 23:31:28.705327
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    test_class = SunOSHardwareCollector()
    assert test_class.collect() != None


# Generated at 2022-06-22 23:31:38.203353
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class Module:
        def __init__(self):
            self.run_command_counter = 0
            self.run_command_rc = []
            self.run_command_out = []
            self.run_command_err = []

        def run_command(self, cmd, **kwargs):
            self.run_command_counter += 1
            if 'run_command_out' in kwargs:
                # convert to list, as kstat output is split in lines there
                self.run_command_out.append(kwargs['run_command_out'].split('\n'))
                self.run_command_rc.append(0)
            else:
                self.run_command_out.append([])
                self.run_command_rc.append(1)

# Generated at 2022-06-22 23:31:49.401369
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    successfully_executed = False
    is_valid_data = False
    error_output = ""
    output_data = ""
    command_result = bytes()

    # create a dummy ansible module
    from ansible.module_utils.facts import module_utils
    import ansible.module_utils.facts.collector

    class ModuleStub:
        def __init__(self):
            self.run_command_environ_update = None
            self.get_bin_path_return = "/usr/bin/kstat"

        def get_bin_path(self, command, opt_dirs=[]):
            return self.get_bin_path_return


# Generated at 2022-06-22 23:32:00.120771
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    obj = SunOSHardware(module)
    facts = obj.get_memory_facts()
    module.exit_json(changed=False, ansible_facts=dict(ansible_memtotal_mb=facts['memtotal_mb'],
                                                       ansible_swapfree_mb=facts['swapfree_mb'],
                                                       ansible_swaptotal_mb=facts['swaptotal_mb'],
                                                       ansible_swap_allocated_mb=facts['swap_allocated_mb'],
                                                       ansible_swap_reserved_mb=facts['swap_reserved_mb']))



# Generated at 2022-06-22 23:32:02.213171
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_test = SunOSHardware({})

    assert hardware_test.platform == 'SunOS'

# Generated at 2022-06-22 23:32:15.672537
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()

    test_successful_cmd = "test@test:~$ /usr/sbin/prtconf\n" \
                          "Memory size: 8192 Megabytes\n" \
                          "test@test:~$ /usr/sbin/swap -s\n" \
                          "total: 8192k bytes allocated + 8192k reserved = 16384k used, 536866816k available\n"

    def run_command_mock(*_, **__):
        return 0, test_successful_cmd, ''

    module.run_command = run_command_mock
    SunOSHardware.module = module

    test_hardware = SunOSHardware()
    results = test_hardware.get_memory_facts()

    assert results['memtotal_mb'] == 8192

# Generated at 2022-06-22 23:32:21.352425
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {}
    hardware = SunOSHardware(module)
    facts = hardware.populate()
    assert ('ansible_memfree_mb' in facts)
    assert ('ansible_mounts' in facts)

# Generated at 2022-06-22 23:32:29.675879
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    memory_facts = hardware.get_memory_facts()

    assert_equals(memory_facts.get('memtotal_mb'), '*memory_total*')
    assert_equals(memory_facts.get('swapfree_mb'), '*swap_free*')
    assert_equals(memory_facts.get('swaptotal_mb'), '*swap_total*')
    assert_equals(memory_facts.get('swap_allocated_mb'), '*swap_allocated*')
    assert_equals(memory_facts.get('swap_reserved_mb'), '*swap_reserved*')


# Generated at 2022-06-22 23:32:40.735306
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockSunOSHardware:
        module = None

        def __init__(self):
            self.facts = {}

        def run_command(self, command):
            """
              Return fake output of command
              Input:
                command: String

              Return:
                out: String
                rc: Integer
                err: String
            """

            # fake output of command '/usr/sbin/prtconf'
            if command == "/usr/sbin/prtconf":
                rc = 0
                out = """Memory size: 255 Megabytes                                     
                """
                err = ""
            # fake output of command '/usr/sbin/swap -s'
            elif command == "/usr/sbin/swap -s":
                rc = 0

# Generated at 2022-06-22 23:32:44.647759
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSHardware
    assert collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:32:52.440307
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = SunOSHardware(module)
    hardware_obj.get_cpu_facts()
    assert hardware_obj.facts['processor'] == [
        'Genuine Intel(R) CPU 1234 @ 1.1GHz', 'Genuine Intel(R) CPU 1234 @ 1.1GHz'
    ]
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['processor_cores'] == 1



# Generated at 2022-06-22 23:32:53.740045
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'


# Generated at 2022-06-22 23:33:04.621767
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Returns a list of unittest.TestCase objects for the get_device_facts method of the SunOSHardware class.
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware, test_SunOSHardware_get_device_facts
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.facts.utils import TestCaseModuleUtils, TestCaseFactsParams, TestCaseFiles
    import ansible.module_utils.facts.hardware.sunos

    class TestSunOSHardware():
        # Fake module instance
        class FakeModule():

            def run_command(self, cmd):
                """
                Fake run_command method to return a static value
                """
                # Each line of

# Generated at 2022-06-22 23:33:17.258169
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hw = SunOSHardware()
    rc = hw.populate()
    assert rc['processor'] == ["SUNW,SPARC-Enterprise-T5240 @ 1350MHz"]
    assert rc['processor_count'] == 1
    assert rc['processor_cores'] == 8
    assert rc['memtotal_mb'] == 8192
    assert rc['swapfree_mb'] == 8192
    assert rc['swaptotal_mb'] == 8192
    assert rc['swap_allocated_mb'] == 8192
    assert rc['swap_reserved_mb'] == 8192

# Generated at 2022-06-22 23:33:19.034686
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    assert SunOSHardware.get_memory_facts()["memtotal_mb"] >= 0

# Generated at 2022-06-22 23:33:30.742897
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    test_facts = dict()
    test_facts['platform'] = 'SunOS'
    test_facts['ansible_machine'] = 'i86pc'
    test_facts['ansible_processor'] = 'i386'
    test_facts['ansible_processor_count'] = 1
    test_facts['ansible_processor_cores'] = 1
    test_facts['ansible_processor_threads_per_core'] = 1
    test_facts['ansible_processor_vcpus'] = 1
    test_facts['ansible_processor_vcpus_used'] = 1
    test_facts['ansible_memtotal_mb'] = 16384
    test_facts['ansible_swapfree_mb'] = 4915
    test_facts['ansible_swaptotal_mb'] = 16106

# Generated at 2022-06-22 23:33:38.692854
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    platform_facts = dict()
    platform_facts['platform'] = 'SunOS'
    platform_facts['distribution'] = 'SunOS'

    hardware_collector = SunOSHardwareCollector(module)
    hardware_collector.collect(platform_facts=platform_facts, collected_facts=None)

    hardware = SunOSHardware(module)
    hardware.populate()

    facts = hardware.get_facts()

    assert facts['devices']['sda']['hard_errors'] == '0'

# Generated at 2022-06-22 23:33:45.111222
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware({'module_setup': True})

    def run_command(self, cmd, check_rc=True):
        return 0, "", ""

    m.run_command = run_command

    facts = m.get_device_facts()
    assert 'devices' in facts
    assert isinstance(facts['devices'], dict)

# Generated at 2022-06-22 23:33:55.048946
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    facts = {}
    hardware = SunOSHardwareCollector.collect(module, facts)


# Generated at 2022-06-22 23:34:02.371465
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = object()
    module.run_command = mock_run_command
    sunos_hw = SunOSHardware(module)
    facts = sunos_hw.get_memory_facts()

    assert facts['memtotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 256
    assert facts['swap_reserved_mb'] == 256
    assert facts['swaptotal_mb'] == 256
    assert facts['swapfree_mb'] == 0

# Generated at 2022-06-22 23:34:11.631796
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOSHardware_instance = SunOSHardware()
    SunOSHardware_instance.module = MagicMock()
    # Making the prtdiag returns the following line:
    # System Configuration: VMware, Inc. VMware Virtual Platform
    rc = 0
    out = 'System Configuration: VMware, Inc. VMware Virtual Platform'
    err = ''
    SunOSHardware_instance.module.run_command.return_value = rc, out, err
    assert SunOSHardware_instance.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}



# Generated at 2022-06-22 23:34:13.560884
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    inst = SunOSHardwareCollector()
    assert inst.required_facts == set(['platform'])

# Generated at 2022-06-22 23:34:21.162167
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class ModuleTest(object):
        def __init__(self, rc, out, err, params=None):
            self.params = params
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args, check_rc=True):
            if self.params:
                for p in self.params.split():
                    if p in args:
                        args.remove(p)
            return self.rc, self.out, self.err

    module = ModuleTest(0, 'Memory size: 32768 Megabytes', '')
    sunos_hardware = SunOSHardware(module)
    fact = sunos_hardware.get_memory_facts()
    assert fact['memtotal_mb'] == 32768

    # Run the method again with different memory size

# Generated at 2022-06-22 23:34:31.304660
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This is a minimal test for the SunOSHardware populate() method.

    It simply checks for the existence of prtdiag binary, and if found
    it passes three strings to be used by the mock_run_command in place
    of the real output from prtdiag.
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Create a mock AnsibleModule object
    # All we care about is the params passed to the SunOSHardware populate() method
    class MockAnsibleModule:
        def __init__(self):
            pass
        def exit_json(self, ansible_facts):
            self.exit_json_called = True
            self.ansible_facts

# Generated at 2022-06-22 23:34:35.035307
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])
    assert SunOSHardwareCollector.optional_facts == set()
    assert SunOSHardwareCollector.label == 'SunOS hardware facts'
    assert SunOSHardwareCollector.collections == ['hardware']
    assert SunOSHardwareCollector.requirements == ['kstat']



# Generated at 2022-06-22 23:34:45.699448
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # AnsibleModule is used by the main ansible module, it has a basic module
    # argument spec, and methods to run commands.
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        def run_command(self, command):
            return 0, "", ""

        def get_bin_path(self, executable, opt_dirs=[]):
            return executable

    hardware = SunOSHardware()
    hardware.module = AnsibleModuleMock()
    hardware.collect()
    assert 'ansible_processor' in hardware.facts
    assert 'ansible_processor_cores' in hardware.facts
    assert 'ansible_processor_count' in hardware.facts

# Generated at 2022-06-22 23:34:51.491584
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    output = """System Configuration: Oracle Corporation sun4v
    Memory size: 32768 Megabytes
    CPUs: 16
    CPU Type: SPARC-T4
    """
    module.run_command.return_value = (0, output, '')
    sun = SunOSHardware(module, 'SunOS')
    dmi_facts = sun.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v'



# Generated at 2022-06-22 23:34:53.981167
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    facts_class = SunOSHardware()
    facts_class.populate()

    # A list of valid supported vendor names.
    valid_vendor_list = ["Fujitsu",
                         "Oracle Corporation",
                         "QEMU",
                         "Sun Microsystems",
                         "VMware, Inc.",
    ]

    assert facts_class.system_vendor in valid_vendor_list


# Generated at 2022-06-22 23:35:04.453053
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command_rc = None
            self.run_command_out = None
            self.run_command_err = None

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, run_as_root=False, environ_update=None, log_fatal=True):
            self.run_command_environ_update = environ_update
            print("run_command: args " + " ".join(args))
            print("run_command: rc " + str(self.run_command_rc))
            print("run_command: out " + self.run_command_out)