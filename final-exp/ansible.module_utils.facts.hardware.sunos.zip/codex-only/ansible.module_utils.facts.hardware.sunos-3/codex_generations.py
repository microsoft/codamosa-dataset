

# Generated at 2022-06-22 23:25:02.339843
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all'], type='list')
        },
        supports_check_mode=True
    )
    result = dict(changed=False, ansible_facts=dict())
    SunOSHardwareCollector(module).collect(result)
    print(result)



# Generated at 2022-06-22 23:25:04.136140
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    assert (SunOSHardware().get_uptime_facts())['uptime_seconds'] >= 0

# Generated at 2022-06-22 23:25:15.101633
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # This is a regression test for the patch for
    # https://bugzilla.redhat.com/show_bug.cgi?id=1201387
    # It checks that the value of 'system_vendor' is not set to an
    # empty string if the output of prtdiag doesn't match the
    # regexp used by Ansible's SunOS hardware fact collector.
    # We test this by checking that the return value of get_dmi_facts()
    # is an empty dict when the output of prtdiag is 'Fake output'.
    class MockModule:
        @staticmethod
        def run_command(*args, **kwargs):
            return 0, 'Fake output', ''

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return '/usr/bin/prtdiag'

    fact_

# Generated at 2022-06-22 23:25:17.586291
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import doctest
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    doctest.testmod(hardware)


# Generated at 2022-06-22 23:25:24.838771
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    if not HAS_SUNOS_HARDWARE:
        module.fail_json(msg="Package sunos_hardware required for this module")

    hardware = SunOSHardware(module=module)

    # Simulate the command output

# Generated at 2022-06-22 23:25:35.459007
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    # FIXME
    module.run_command.return_value = ('sparcv9', '', 0)
    module.run_command.side_effect = [
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0),
        ('', '', 0)
    ]

# Generated at 2022-06-22 23:25:48.179136
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test the populate() method of the SunOSHardware class.
    """
    from collections import namedtuple
    from ansible.module_utils.facts.collector import MemoryInformation

    def run_command_mock(cmd, *args, **kwargs):
        """Mock the run_command() function.

        This makes it possible to modify the behavior of run_command() based
        on the arguments passed to it, to simulate different scenarios.
        """
        if cmd == "prtconf | grep Memory":
            return (0, "Memory size: 32767 Megabytes", "")
        if cmd == "swap -s":
            return (0, "total:  22956k bytes allocated + 15608k reserved = 38564k used, 277636k available", "")

# Generated at 2022-06-22 23:25:50.277024
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardwareCollector.fetch_facts(None, None)
    assert hardware.get('cpu') is not None


# Generated at 2022-06-22 23:25:58.007961
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:04.266300
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunos_hardware = SunOSHardware(None)
    # Get 'boot_time' and set it to a fixed value.
    sunos_hardware.boot_time = 1598362080.0
    assert sunos_hardware.get_uptime_facts()['uptime_seconds'] == int(time.time() - 1598362080)
    del sunos_hardware

# Generated at 2022-06-22 23:26:08.293076
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hardware_collector = SunOSHardwareCollector()
    assert sunos_hardware_collector._fact_class == SunOSHardware
    assert sunos_hardware_collector._platform == 'SunOS'
    assert sunos_hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:26:15.571812
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test the constructor of SunOSHardwareCollector and if it calls the constructor
    # of HardwareCollector
    collectors = {}
    collector = SunOSHardwareCollector(collectors)

    assert collector is not None
    assert '_fact_class' in collector.__dict__
    assert '_platform' in collector.__dict__
    assert 'required_facts' in collector.__dict__


# Generated at 2022-06-22 23:26:24.766463
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Case 1 - Required facts are available
    # Set the required facts
    collected_facts = dict(platform="SunOS")
    # Call the constructor of SunOSHardwareCollector with the collected facts.
    collector = SunOSHardwareCollector(collected_facts=collected_facts)

    # Verify that the constructor does not return any error
    assert collector is not None

    # Case 2 - Required facts are not available
    # Set the required facts
    collected_facts = dict(platform="Linux")
    # Call the constructor of SunOSHardwareCollector with the collected facts.
    collector = SunOSHardwareCollector(collected_facts=collected_facts)

    # Verify that the constructor returns None
    assert collector is None

# Generated at 2022-06-22 23:26:33.693216
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    output = [
        "Memory size: 4096 Megabytes",
        "",
        "Total swap: 8192 Megabytes",
        "        allocated: 4304 Megabytes",
        "        reserved: 3912 Megabytes",
        "        used: 184 Megabytes",
        "        available: 7868 Megabytes",
        "",
        "",
    ]
    prtconf = [
        {'command': '/usr/sbin/prtconf', 'rc': 0, 'stdout': '\n'.join(output), 'stderr': ''}
    ]
    module = Mock(run_command=MagicMock(side_effect=prtconf))
    har = SunOSHardware(module)
    memory_facts = har.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096

# Generated at 2022-06-22 23:26:46.734143
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ModuleStub(object):
        class RunCommandResult(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __eq__(self, other):
                return (self.rc, self.out, self.err) == (other.rc, other.out, other.err)

        def __init__(self):
            self.run_command_result = None

        def run_command(self, cmd, **kwargs):
            return self.run_command_result

        def get_bin_path(self, cmd, **kwargs):
            return "/usr/bin/%s" % cmd

    # Test sderr with missing prtdiag binary
    m = ModuleStub()
    m.run_command_

# Generated at 2022-06-22 23:26:57.314641
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:09.432588
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Define prtconf output
    module.run_command.return_value = (0, '. . . Memory size: 4096 Megabytes', '')

    # Define swap -s output
    module.run_command.side_effect = [
        (0, '', ''),
        (0, 'total: 157440k bytes allocated + 166476k reserved = 323916k used, 4945596k available', ''),
    ]

    # Create the instance of the SunOSHardware class
    sun_hardware = SunOSHardware(module)

    # Testing if get_memory_facts is returning the expected results
    result = sun_hardware.get_memory_facts()


# Generated at 2022-06-22 23:27:11.719982
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule({})
    SunOSHardware(module)



# Generated at 2022-06-22 23:27:23.825283
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()

    current_time = time.time()
    fake_boot_time = current_time - 10
    fake_output = "unix:0:system_misc:boot_time    " + str(fake_boot_time)

    returned_uptime_seconds = 10
    class SunOSHardwareClass(SunOSHardware):
        def __init__(self, module=None):
            super(SunOSHardwareClass, self).__init__(module)

        def run_command(self, command, *args, **kwargs):
            return 0, fake_output, ""

    # when rc returned value is 0
    sun_os_hardware = SunOSHardwareClass(module)
    uptime_facts = sun_os_hardware.get_uptime_facts()

# Generated at 2022-06-22 23:27:34.528776
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    fact_module = SunOSHardware(dict())
    facts = dict()
    facts['memtotal_mb'] = {'memtotal_mb': '131072'}
    facts['swap_allocated_mb'] = {'swap_allocated_mb': '1048576'}
    facts['swap_reserved_mb'] = {'swap_reserved_mb': '1048576'}
    facts['swaptotal_mb'] = {'swaptotal_mb': '1048576'}
    facts['swapfree_mb'] = {'swapfree_mb': '1048576'}

    mock_out = "Memory size: 131072 Megabytes"
    mock_err = ""
    return_code = 0
    module = mock.MagicMock()
    module.run_command.return_value

# Generated at 2022-06-22 23:27:47.552703
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    try:
        import ansible.utils.unsafe_proxy as unsafe_proxy
    except ImportError:
        import ansible.utils.unsafe_proxy
    module = unsafe_proxy.UnsafeProxy()
    md = SunOSHardware(module=module)

    # Collect facts
    kstat_cpu_info = """module: cpu_info
instance: 0
class: misc
chip_id   1
clock_MHz 100
state     idle
chip_id   2
clock_MHz 100
state     idle
chip_id   3
clock_MHz 100
state     idle
chip_id   4
clock_MHz 100
state     idle"""
    module.run_command_environ_update = None
    module.run_command = lambda x: (0, kstat_cpu_info, '')
    cpu_facts = md.get_cpu_

# Generated at 2022-06-22 23:27:58.901195
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # test for empty output
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    hardware = SunOSHardware(module)
    cpu_fact = hardware.get_cpu_facts()
    assert cpu_fact['processor'] == []
    assert cpu_fact['processor_cores'] == 'NA'
    assert cpu_fact['processor_count'] == 0

    # test for single cpu
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-22 23:28:01.226722
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    x = SunOSHardware({'ansible_facts': {'platform': 'SunOS'}})
    assert x.platform == 'SunOS'

# Generated at 2022-06-22 23:28:09.433644
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    hw = SunOSHardware()
    facts = hw.get_memory_facts()

    print(facts)

    assert facts['memtotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swap_allocated_mb'] >= 0
    assert facts['swap_reserved_mb'] >= 0



# Generated at 2022-06-22 23:28:21.801119
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock(return_value=(0, 'sderr:0:sd0,err:Product VBOX HARDDISK\nsderr:0:sd0,err:Size    53687091200\nsderr:0:sd1,err:Product VBOX CD-ROM\nsderr:0:sd1,err:Size    1073741312', ''))
    testclass = SunOSHardware(module)
    result = testclass.get_device_facts()
    assert result['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert result['devices']['sd0']['size'] == '5TiB'

# Generated at 2022-06-22 23:28:30.106419
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # create a module object
    module = AnsibleModule(argument_spec={})

    # create a SunOSHardware object
    facts_obj = SunOSHardware(module)
    # call the get_uptime_facts method
    uptime_facts = facts_obj.get_uptime_facts()

    # check that the uptime_seconds key exists in the returned dict
    assert 'uptime_seconds' in uptime_facts


if __name__ == '__main__':
    from ansible.module_utils.basic import *

    # Run uptime test
    test_SunOSHardware_get_uptime_facts()

# Generated at 2022-06-22 23:28:39.818300
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module = MagicMock()

    hardware.module.run_command.return_value = (0, "Memory size: 32768 Megabytes", None)
    assert hardware.get_memory_facts() == {'memtotal_mb': 32768}

    hardware.module.run_command.return_value = (0, "Memory size: 32768 Megabits", None)
    assert hardware.get_memory_facts() == {'memtotal_mb': 4096}

    hardware.module.run_command.return_value = (0, "Memory size: 32768 Bits", None)
    assert hardware.get_memory_facts() == {'memtotal_mb': 0}

    hardware.module.run_command.return_value = (0, "Memory size: 32", None)
    assert hardware.get_memory_

# Generated at 2022-06-22 23:28:41.712814
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = SunOSHardware(True)
    assert facts.platform == 'SunOS'

# Generated at 2022-06-22 23:28:54.032165
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import subprocess as sp
    import sys

    uptime_facts = {}
    uptime_facts['uptime_seconds'] = int(time.time() - sp.check_output(['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time']).split('\t')[1])

    sh = SunOSHardware()
    assert sh.get_uptime_facts() == uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert isinstance(datetime.timedelta(seconds=uptime_facts['uptime_seconds']), datetime.timedelta)
    assert sys.version_info >= (2, 7)

# Generated at 2022-06-22 23:29:00.865265
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MySunOSHardware(SunOSHardware):
        def __init__(self):
            pass

        def run_command(self, cmd):
            return 0, 'sderr:0:sd0,err:Vendor  ATA\nsderr:0:sd0,err:Size    53687091200', ''

    class AnsibleModule():
        def __init__(self):
            pass

        def get_bin_path(self, app, opt_dirs=[]):
            return app

        def run_command(self, cmd, environ_update=None):
            return 0, '', ''

    my_device_facts = MySunOSHardware().get_device_facts()
    assert 'devices' in my_device_facts
    assert 'sd0' in my_device_facts['devices']
    assert 'vendor'

# Generated at 2022-06-22 23:29:03.262410
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-22 23:29:04.453961
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:29:07.440899
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    hardware_facts = SunOSHardware(dict())

    # test for the init of the class
    assert hardware_facts.platform == 'SunOS'

    # test for the end of the class

# Generated at 2022-06-22 23:29:18.669359
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_data = """module:    cpu_info
instance:   0
class:    misc
chip_id   0
brand    sun4v
clock_MHz  2501.17
module_rev   0
architecture  sparc
implementation sun4v
cores_per_chip  16
chip_family    SPARC64-VII+
vendor    SUNW

module:  cpu_info
instance: 1
class:  misc
chip_id  1
brand    sun4v
clock_MHz   2501.17
module_rev 0
architecture sparc
implementation sun4v
cores_per_chip 16
chip_family SPARC64-VII+
vendor  SUNW
"""
    hardware = SunOSHardware()
    hardware.module = MockModule()

# Generated at 2022-06-22 23:29:30.803165
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    fixture_path_dmi_facts = 'tests/fixtures/facts/SunOS_dmi_facts.txt'
    fixture_file_dmi_facts = open(fixture_path_dmi_facts, 'r')
    fixture_content_dmi_facts = fixture_file_dmi_facts.read()

    fixture_path_uname = 'tests/fixtures/facts/SunOS_uname.txt'
    fixture_file_uname = open(fixture_path_uname, 'r')
    fixture_content_uname = fixture_file_uname.read()

# Generated at 2022-06-22 23:29:32.243238
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:29:40.021183
# Unit test for constructor of class SunOSHardwareCollector

# Generated at 2022-06-22 23:29:44.074991
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware(dict())

    # Check output of empty constructor
    assert hardware_facts.platform == 'SunOS'
    assert 'processor' not in hardware_facts.facts


# Generated at 2022-06-22 23:29:50.543323
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule({})
    uptime_return = "unix:0:system_misc:boot_time 1548264444"
    module.run_command = MagicMock(return_value=(0, uptime_return, ""))
    hardware = SunOSHardware()
    hardware_facts = hardware.populate()
    expected_uptime_facts = {'uptime_seconds': int(time.time() - 1548264444)}
    assert hardware_facts['uptime_seconds'] == expected_uptime_facts['uptime_seconds']



# Generated at 2022-06-22 23:29:56.519812
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Create a generic SunOSHardware instance. We only need its get_cpu_facts method
    sunos_hw = SunOSHardware(dict())

    # This is the output we expect from the "kstat cpu_info" command

# Generated at 2022-06-22 23:30:03.709823
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'Memory size: 16384 Megabytes', None)
    hardware = SunOSHardware(module=mock_module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384


# Generated at 2022-06-22 23:30:07.558459
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    s = """
System Configuration: VMware, Inc. VMware Virtual Platform
"""
    m = SunOSHardware()
    dmi_facts = m.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-22 23:30:18.516020
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.sunos as sunos
    module = ansible.modules.system.freebsd
    module.run_command = sunos.get_uptime_facts
    # use __main__ as the module name to avoid dependency on __init__.py
    module_args = { '_ansible_sysname': 'SunOS'}
    h = sunos.SunOSHardware()
    h.module = module
    h.module_args = module_args
    fact_data = { 'platform': 'SunOS' }
    h.ansible_facts = fact_data
    h.collect()
    assert 'uptime_seconds' in h.ansible_facts

# Generated at 2022-06-22 23:30:30.798203
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    '''
    Test get_uptime_facts method of class SunOSHardware.
    '''
    test_hardware = SunOSHardwareCollector._fact_class()
    # Generate a fake module object with a required run_command method.
    class FakeModule():
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''
    fake_module = FakeModule()
    test_hardware.module = fake_module
    expected_uptime = {'uptime_seconds': int(time.time() - 1548249689)}
    assert(expected_uptime == test_hardware.get_uptime_facts())

# Generated at 2022-06-22 23:30:32.998032
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = {"run_command": run_command}
    sunOS = SunOSHardware(module)
    assert sunOS.platform == 'SunOS'

# Generated at 2022-06-22 23:30:43.212804
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # given
    sut = SunOSHardware()
    sut.module = DummyModule()
    sut.module.run_command = MagicMock(return_value=(0, '', ''))
    sut.module.run_command.return_value = (0, 'Memory size: 4096 Megabytes', '')
    # precondition
    assert sut.module.run_command.call_count == 0
    # when
    result = sut.get_memory_facts()
    # then
    assert result == {"memtotal_mb": 4096}
    assert sut.module.run_command.call_count == 1



# Generated at 2022-06-22 23:30:43.911479
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    SunOSHardware()

# Generated at 2022-06-22 23:30:54.618075
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module_mock = {}
    module_mock['run_command'] = run_command_mock
    module_mock['run_command_environ_update'] = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    # Create the SunOSHardware object that invokes the method
    hardwarefact = SunOSHardware(module_mock)

    # Create our own dictionary that will be in the module
    # parameters.  This corresponds to the "facts" dictionary.
    collected_facts = {}
    collected_facts['ansible_machine'] = 'i86pc'

    # Call the method and store the results.
    result = hardwarefact.get_cpu_facts(collected_facts)

    # Verify that our method works and returns the correct result.
    # There should be 2

# Generated at 2022-06-22 23:30:59.899066
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(argument_spec={})
    result = SunOSHardwareCollector(module=module).collect()
    assert "ansible_processor_cores" in result


if __name__ == '__main__':
    from ansible.module_utils.basic import *
    test_SunOSHardwareCollector()

# Generated at 2022-06-22 23:31:10.119874
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Verify if facts are populated correctly
    """
    hardware_collector = SunOSHardwareCollector()
    hardware_obj = SunOSHardware()
    facts = {'platform': 'SunOS'}

    hardware_obj.populate()
    assert hardware_obj.platform == 'SunOS'
    assert hardware_obj.get('processor') == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert hardware_obj.get('memtotal_mb') == 3072
    assert hardware_obj.get('swapfree_mb') == 0
    assert hardware_obj.get('swaptotal_mb') == 0
    assert hardware_obj.get('swap_allocated_mb') == 0
    assert hardware_obj.get('swap_reserved_mb') == 0
    assert hardware_obj.get('mounts')

# Generated at 2022-06-22 23:31:20.506966
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """This is a test function for the class SunOSHardware get_dmi_facts method."""
    mock_module = MagicMock()
    mock_run_command = MagicMock(
        return_value=(0, 'System Configuration: Sun Microsystems sun4u', '')
    )
    mock_module.run_command = mock_run_command
    hardware_obj = SunOSHardware(mock_module)
    facts = hardware_obj.get_dmi_facts()
    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'sun4u'



# Generated at 2022-06-22 23:31:30.609724
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    output = """
Sun Microsystems  sun4u  Sun Fire V240
System clock frequency:  1000 MHz
Memory size: 64GB
===========================================
""".strip()

    module = FakeModule()
    module.run_command.return_value = (0, output, '')

    fact = SunOSHardware(module)
    dmi_facts = fact.get_dmi_facts()

    assert dmi_facts == {
        'system_vendor': 'Sun Microsystems',
        'product_name': 'sun4u  Sun Fire V240',
    }


# Generated at 2022-06-22 23:31:38.816449
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    from sys import version_info

    assert isinstance(version_info, tuple)

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    module = SunOSHardware()
    facts = module.populate()

    assert isinstance(facts['ansible_processors'], dict)
    assert isinstance(facts['ansible_devices'], dict)
    assert facts.get('ansible_fstype') is None
    assert isinstance(facts['ansible_memtotal_mb'], int)
    assert isinstance(facts['ansible_swapfree_mb'], int)
    assert isinstance(facts['ansible_swaptotal_mb'], int)
    assert isinstance(facts['ansible_system_vendor'], str)

# Generated at 2022-06-22 23:31:41.424514
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hardware_collector = SunOSHardwareCollector()
    assert sunos_hardware_collector is not None


# Generated at 2022-06-22 23:31:51.538683
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule({})
    obj = SunOSHardware(module)

    prtdiag = b"""
System Configuration: Oracle Corporation sun4v sun4v
        Memory size: 16384 Megabytes
        =========================== CPUs =============================
        Run Ecache CPU CPU
        CPU  MHz   MB  Impl. Mask
        --- ---- ------ ------ ----
        0   0 0.0   US-III+  1.4
        1   0 0.0   US-III+  1.4
"""
    module.run_command = lambda *args, **kwargs: (0, prtdiag, None)
    dmi_facts = obj.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v sun4v'



# Generated at 2022-06-22 23:32:00.190497
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule():
        @staticmethod
        def run_command(*args, **kwargs):
            return {
                'boot_time' : '1525269143'
            }[args[0]]

    class MockFactCache():
        @staticmethod
        def get_fact_cache():
            return {
                'uptime_seconds' : '1525269143'
            }

    sunos_hw_facts = SunOSHardwareCollector(MockModule())
    assert sunos_hw_facts.get_uptime_facts() == {  'uptime_seconds': 1525269143  }

# Generated at 2022-06-22 23:32:09.579630
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('MockModule', (object,), {
        'run_command': lambda self, args, check_rc=False: (0, 'Memory size: 8 GB', ''),
    })
    hw = SunOSHardware(module, 'fake_ansible_connection')
    # We don't care about device_facts() for the memory_facts() test.
    hw.get_device_facts = lambda: {}
    facts = hw.populate()
    assert facts['memtotal_mb'] == 8192

# Generated at 2022-06-22 23:32:11.444165
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:32:13.351143
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    obj = SunOSHardware()
    assert obj.platform == 'SunOS'


# Generated at 2022-06-22 23:32:18.046389
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:32:29.034759
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.system import SystemCollector

    system_collector = SystemCollector()
    prtconf_content = 'root@zionsrv:/root# more /var/tmp/prtconf.txt'
    prtconf_content += 'System Configuration: Oracle Corporation sun4v'
    prtconf_content += 'Memory size: 8192 Megabytes'

    module_com = object()
    module_com.run_command = lambda x, **kwargs: (0, prtconf_content, '')

    system_collector.populate()
    sunos_hardware = SunOSHardware()

# Generated at 2022-06-22 23:32:40.258913
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_facts_class = SunOSHardware()
    hardware_facts_class.module = MagicMock()

# Generated at 2022-06-22 23:32:45.995599
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    '''
    Test the get_dmi_facts method of the SunOSHardware class
    '''
    m = SunOSHardware()
    assert m.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'SUNBLADE-T6340'}

# Generated at 2022-06-22 23:32:53.779213
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    result = {'processor': ['SPARC64-VII @ 2100MHz'],
              'processor_cores': 6,
              'processor_count': 1}
    with open("tests/units/module_utils/facts/hardware/test_SunOSHardware_get_cpu_facts_output") as SunOS_output:
        SunOSHardware_object = SunOSHardware(SunOS_output)
        cpu_facts = SunOSHardware_object.get_cpu_facts()
    assert cpu_facts == result

# Generated at 2022-06-22 23:33:04.705134
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:17.362487
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware = SunOSHardware(module=module)
    hardware.populate()

# Generated at 2022-06-22 23:33:29.315402
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class FakeModule:
        def __init__(self, out):
            self.out = out
        def run_command(self, cmd):
            return (0, self.out, '')

# Generated at 2022-06-22 23:33:39.630933
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_file_content
    test_obj = SunOSHardware()

    # Create a mock kstat file
    kstat_file = 'unix:0:system_misc:boot_time    1548249689'
    fd = open("/tmp/kstat", 'wb')
    fd.write(to_bytes(kstat_file))
    fd.close()

    # Get the uptime facts - original method has been mocked
    uptime_facts = test_obj.get_uptime_facts()
    assert int(uptime_facts['uptime_seconds']) == int(time.time()) - 1548249689

# Generated at 2022-06-22 23:33:43.786742
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hw = SunOSHardware(dict(platform='SunOS'))

    values = hw.get_dmi_facts()
    assert values.get('system_vendor') is not None
    assert values.get('product_name') is not None

# Generated at 2022-06-22 23:33:45.792654
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    SunOSHardware.get_memory_facts()

# Generated at 2022-06-22 23:33:48.302162
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    h = SunOSHardware()
    assert h.populate()['processor'] == ['SPARC T7-2 @ 2400MHz']



# Generated at 2022-06-22 23:33:50.764104
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = FakeAnsibleModule()
    SunOSHardwareCollector(module)


# Generated at 2022-06-22 23:34:04.035927
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module_mock = Mock()
    module_mock._name = "SunOSHardware"
    module_mock._ansible_version = "1.3.3"
    module_mock.run_command_environ_update = {"LS_COLORS": ""}

# Generated at 2022-06-22 23:34:08.338661
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hostname = 'host1.domain.com'
    try:
        SunOSHardware(module=None, share=None, params=None, hostname=hostname)
    except Exception:
        assert False, 'Object constructor failed.'
    assert True

# Generated at 2022-06-22 23:34:18.134267
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test method get_device_facts of class SunOSHardware
    """

    # create a fake module
    class FakeModule():
        class RunCommand():
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run_command(self, cmd, environ_update=None, check_rc=True):
                """
                Imitate method from module class to run system commands
                """
                return (self.rc, self.out, self.err)

        def __init__(self):
            self.run_command = RunCommand(0, '', '')

    def get_file_content(path):
        return ''

    # create the fake module
    module = FakeModule()

    # read the data from /usr/platform/

# Generated at 2022-06-22 23:34:21.052262
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_facts = SunOSHardware(dict(), None)

    assert sunos_facts.platform == "SunOS"


# Generated at 2022-06-22 23:34:31.258803
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:34:42.379900
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )


# Generated at 2022-06-22 23:34:52.263577
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689\n', '')

    mock_collected_facts = {}
    mock_collected_facts['ansible_machine'] = 'i86pc'
    mock_collected_facts['platform'] = 'SunOS'

    my_SunOSHardware = SunOSHardware()
    my_SunOSHardware.module = mock_module
    my_SunOSHardware.collect()

    uptime_facts = my_SunOSHardware.get_uptime_facts()

    # 5 mins = 300 secs
    # if result is less than 300 secs it means that the machine is not up for long
    assert uptime_facts['uptime_seconds'] < 300



# Generated at 2022-06-22 23:34:58.595680
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = mock_run_command
    hardware.module.run_command_environ_update = {}

    memfacts = hardware.get_memory_facts()

    assert memfacts['memtotal_mb'] == 1024

