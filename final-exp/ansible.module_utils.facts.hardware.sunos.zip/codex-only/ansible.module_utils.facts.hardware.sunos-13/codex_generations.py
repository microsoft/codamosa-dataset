

# Generated at 2022-06-22 23:25:08.244607
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    mock_module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    mock_SunOSHardware = SunOSHardware(mock_module)

    prtconf_output = """
Memory size: 16384 Megabytes
"""
    swap_output = """
total: 27351772k bytes allocated + 36871140k reserved = 64222912k used, 19296192k available
"""
    mock_module.run_command.return_value = (0, prtconf_output, '')
    mock_module.run_command.return_value = (0, swap_output, '')


# Generated at 2022-06-22 23:25:16.543281
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
  hardware_facts = SunOSHardware({'ansible_machine': 'i86pc'})
  assert hardware_facts.populate() == {'memtotal_mb': 820,
                                       'processor_cores': 4,
                                       'processor': ['i386 @ 492MHz'],
                                       'system_vendor': 'Fujitsu',
                                       'swap_allocated_mb': 0,
                                       'swap_reserved_mb': 0,
                                       'swapfree_mb': 820,
                                       'swaptotal_mb': 820,
                                       'processor_count': 1}

# Generated at 2022-06-22 23:25:19.235295
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock({'ansible_machine': 'sparc'})
    my_obj = SunOSHardware(module)

    assert(my_obj.platform == 'SunOS')

# Generated at 2022-06-22 23:25:31.998878
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Setup module
    test_module = basic.AnsibleModule(
        argument_spec=dict()
    )

    # Setup facts collector
    facts_collector = BaseFactCollector(test_module)

    # Setup facts
    facts = {
        'platform': 'SunOS',
    }

    # Setup hardware info
    hardware_info = SunOSHardware(test_module, facts_collector)

    # Call method get_device_facts of SunOSHardware class
    device_facts = hardware_info.get_device_facts()

    # Check if device_facts is correct

# Generated at 2022-06-22 23:25:34.408834
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Verify that the instance of SunOSHardware is properly constructed
    """
    facts = SunOSHardware()
    assert facts.platform == 'SunOS'



# Generated at 2022-06-22 23:25:35.645065
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._platform == 'SunOS'

# Generated at 2022-06-22 23:25:48.384330
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts import ansible_collector
    import os

    ansible_collector.collect_fqdn = lambda: 'fqdn'
    ansible_collector.collect_domain_name = lambda: 'domain'
    ansible_collector.collect_all_ipv4_addresses = lambda: dict(default=['1.1.1.1'])
    ansible_collector.collect_ipv4_default_interface = lambda: 'default_interface'
    ansible_collector.collect_distribution = lambda: dict(distribution='distribution')
    ansible_collector.collect_distribution_major_version = lambda: 'distribution_version'

# Generated at 2022-06-22 23:25:56.828613
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware._module.run_command.side_effect = [[0, 'Memory size: 8192 Megabytes', None],
                                                [0, '8192M allocated + 0M unused = 8192M used, 0M available', None]]
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 8192

    hardware = SunOSHardware()
    hardware._module.run_command.side_effect = [[0, 'Memory size: 1024 Megabytes', None],
                                                [0, '1024M allocated + 0M unused = 1024M used, 0M available', None]]
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 1024

    hardware = SunOSHardware()

# Generated at 2022-06-22 23:26:07.693495
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # create subclass
    class SunOSHardwareSub(SunOSHardware):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-22 23:26:09.011047
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:26:21.780953
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'ansible_facts': {'platform': 'SunOS'}})
    assert hardware.get_cpu_facts({'ansible_facts': {'platform': 'SunOS'}}) == {}
    assert hardware.get_memory_facts({'ansible_facts': {'platform': 'SunOS'}}) == {'swap_allocated_mb': 0,
                                                                                   'swap_reserved_mb': 0,
                                                                                   'memtotal_mb': 0,
                                                                                   'swaptotal_mb': 0,
                                                                                   'swapfree_mb': 0}
    assert hardware.get_dmi_facts({'ansible_facts': {'platform': 'SunOS'}}) == {}

# Generated at 2022-06-22 23:26:24.132164
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware = SunOSHardware()
    hardware_collector = SunOSHardwareCollector()

    assert hardware_collector.get_sysctl_facts() == hardware.get_sysctl_facts()

# Generated at 2022-06-22 23:26:33.343589
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sderr_statistics = (
        {"Product": "product", "Revision": "revision", "Serial No": "serial", "Size": "size", "Vendor": "vendor",
         "Hard Errors": "hard_errors", "Soft Errors": "soft_errors", "Transport Errors": "transport_errors",
         "Media Error": "media_errors", "Predictive Failure Analysis": "predictive_failure_analysis",
         "Illegal Request": "illegal_request"})


# Generated at 2022-06-22 23:26:46.371761
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Test data taken from a Solaris 11.1 vm
    test_module = type('module', (), {})()

# Generated at 2022-06-22 23:26:56.999661
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module.run_command = lambda cmd, check_rc=False: (0, '', '')

    hardware.module.run_command = lambda cmd, check_rc=False: (0, 'Memory size: 8192 Megabytes', '')
    assert hardware.get_memory_facts()['memtotal_mb'] == 8192

    hardware.module.run_command = lambda cmd, check_rc=False: (0, '', '')
    hardware.module.run_command = lambda cmd, check_rc=False: (0, 'Total Swap = 16384         Total Swap Used = 0', '')
    assert hardware.get_memory_facts()['swapfree_mb'] == 16
    assert hardware.get_memory_facts()['swaptotal_mb'] == 16
    assert hardware.get_memory_facts

# Generated at 2022-06-22 23:26:59.556935
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    m = SunOSHardware()
    out = m.get_cpu_facts
    assert out is not None


# Generated at 2022-06-22 23:27:10.608823
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fake_module = type('obj')
    # Some output examples from OpenIndiana
    fake_module.run_command = lambda *_args, **_kwargs: (0, 'sderr:0:sd0,err:Product VBOX HARDDISK        9\nsderr:0:sd0,err:Revision        1.0\nsderr:0:sd0,err:Serial No       VB0ad2ec4d-074a', '')
    cpu_facts = SunOSHardware(fake_module).get_cpu_facts()
    assert cpu_facts == {
        'processor': ['@ .00MHz', '@ .00MHz', '@ .00MHz', '@ .00MHz'],
        'processor_count': 4,
        'processor_cores': 'NA',
    }



# Generated at 2022-06-22 23:27:13.513359
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    spec = dict()
    hardware = SunOSHardware(spec)
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:27:24.522829
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not module.get_bin_path('kstat'):
        module.fail_json(msg='kstat command not found')
        return

    result = dict(platform='SunOS')
    hardware_collector = SunOSHardwareCollector(module=module, collected_facts=result)
    hardware_collector.collect()

    # We expect something like:
    #   {'devices': {'sd0': {'media_errors': '0',
    #                 'hard_errors': '0',
    #                 'illegal_request': '0',
    #                 'predictive_failure_analysis': '0',

# Generated at 2022-06-22 23:27:29.694760
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Check the constructor of SunOSHardwareCollector
    """
    collector = SunOSHardwareCollector()

    assert collector.required_facts == {'platform'}
    assert collector.platform == 'SunOS'
    assert collector._fact_class == SunOSHardware
    assert collector.collectable_facts == ['all']

# Generated at 2022-06-22 23:27:32.974426
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule('SunOS')
    hardware = SunOSHardware(module=module)
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-22 23:27:34.528402
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x.platform == 'SunOS'


# Generated at 2022-06-22 23:27:41.320072
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    fake_module = FakeModule()
    fake_module.run_command = FakeRunCommand
    fact_class = SunOSHardware(fake_module)
    result = fact_class.get_device_facts()
    # On OpenIndiana Hipster, first disk is size 800GB shown as expected.
    assert result['devices']['sd0']['size'] == '800.00 GB'



# Generated at 2022-06-22 23:27:43.840993
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x._platform == 'SunOS'

# Generated at 2022-06-22 23:27:53.564702
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils._text import to_bytes

    def mock_run_command(self, args, *kwargs):
        mock_rc = 0
        mock_out = to_bytes('')
        mock_err = to_bytes('')

        if args[0] == '/usr/bin/kstat' and args[1] == '-p':
            mock_rc = 0

# Generated at 2022-06-22 23:27:54.824658
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'ansible_facts': {}})
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:27:56.743589
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    hardware.populate()

# Generated at 2022-06-22 23:28:04.075871
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:28:12.214420
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('AnsibleModule', (object,), {'run_command': run_command, 'get_bin_path': get_bin_path})()
    hardware = SunOSHardware(module, 'fake_collected_facts')
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_machine': 'i86pc'})
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-22 23:28:16.644855
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware(dict())
    rc, out, err = hardware.module.run_command(["/usr/sbin/prtconf", "-m"])
    assert rc == 0
    assert int(hardware.get_memory_facts()['memtotal_mb']) == int(out.split()[0])

# Generated at 2022-06-22 23:28:28.989228
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Tests the return of the populate method of the SunOSHardware class.
    """
    hardware = SunOSHardware()
    hardware.module = Mock()


# Generated at 2022-06-22 23:28:36.608323
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filters=dict(type='list', required=False),
        ),
        supports_check_mode=False,
    )

    hardware_collector = SunOSHardware(module=module)

    assert hardware_collector.get_memory_facts() == {
        'swapfree_mb': 1073,
        'swaptotal_mb': 1077,
        'memtotal_mb': 5067,
        'swap_reserved_mb': 4,
        'swap_allocated_mb': 4
    }

# Generated at 2022-06-22 23:28:45.956567
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardwareCollector().collect(None, None)
    assert hardware_facts['processor']
    assert hardware_facts['processor_count'] == hardware_facts['processor_cores']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swap_allocated_mb']
    assert hardware_facts['swap_reserved_mb']
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-22 23:28:58.722087
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:29:08.398654
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({})
    hardware.populate()
    results = hardware.get_facts()
    assert 'platform' in results, \
           "SunOSHardware.populate() returned results does not contain a 'platform' key"
    assert 'memtotal_mb' in results, \
           "SunOSHardware.populate() returned results does not contain a 'memtotal_mb' key"
    assert 'swapfree_mb' in results, \
           "SunOSHardware.populate() returned results does not contain a 'swapfree_mb' key"
    assert 'swaptotal_mb' in results, \
           "SunOSHardware.populate() returned results does not contain a 'swaptotal_mb' key"

# Generated at 2022-06-22 23:29:14.253221
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    fixture = """Memory size: 16384 Megabytes
"""
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.run_command = MagicMock()
    module.run_command.return_value = (0, fixture, '')
    result = SunOSHardware(module).get_memory_facts()
    assert result['memtotal_mb'] == 16384


# Generated at 2022-06-22 23:29:21.606353
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts import collector
    dmi_facts_output = 'System Configuration: Oracle Corporation sun4v SPARC-Enterprise-T5220'
    dmi_facts = SunOSHardware(collector).get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SPARC-Enterprise-T5220'

# Generated at 2022-06-22 23:29:28.290246
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = {"run_command": run_command_mock}

    ans_obj = SunOSHardware(module)
    actual = ans_obj.get_memory_facts()
    expected = {'memtotal_mb': 3, 'swapfree_mb': 12, 'swaptotal_mb': 15, 'swap_allocated_mb': 13, 'swap_reserved_mb': 14}

    assert actual == expected



# Generated at 2022-06-22 23:29:37.423835
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import os
    import tempfile

    module = None


# Generated at 2022-06-22 23:29:50.168024
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class Module:
        # Holds the module args
        arguments = {}
        # Holds the module return values
        return_values = {}
        params = {}

        def fail_json(self, *args, **kwargs):
            print('FAILED: {0}, {1}'.format(args, kwargs))

        def exit_json(self, *args, **kwargs):
            print('SUCCESS: {0}, {1}'.format(args, kwargs))


# Generated at 2022-06-22 23:30:03.399884
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    x = SunOSHardware(None)
    x.module.run_command = mock_run_command

    out = """System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: Oracle Corporation SPARC M7-8
System Configuration: Sun Microsystems sun4v"""
    rc = 0

    expected = {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}
    actual = x.get_dmi_facts(out)
    assert actual == expected

    expected = {'system_vendor': 'Oracle Corporation', 'product_name': 'SPARC M7-8'}
    actual = x.get_dmi_facts(out)
    assert actual == expected

    expected = {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}
   

# Generated at 2022-06-22 23:30:06.258214
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """This helper method used for pytest of method get_uptime_facts"""
    uptime = SunOSHardware().get_uptime_facts()
    assert int(uptime['uptime_seconds'])

# Generated at 2022-06-22 23:30:10.500765
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MockHardwareModule()
    sunos_hardware = SunOSHardware(module)
    device_facts = sunos_hardware.get_device_facts()
    assert len(device_facts['devices']) == 6

# Generated at 2022-06-22 23:30:15.476804
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_facts = SunOSHardware(module).populate()

    assert 'processor' in hardware_facts
    assert hardware_facts['processor'] == ['SUNW,UltraSPARC-T1 @ 1190MHz']



# Generated at 2022-06-22 23:30:23.285792
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    class FakeModule:
        def get_bin_path(self, binary, opt_dirs=[]):
            return binary

        def run_command(self, cmd):
            ds = cmd.split()

            disk_stats = {
                'Product': 'product',
                'Revision': 'revision',
                'Serial No': 'serial',
                'Size': 'size',
                'Vendor': 'vendor',
                'Hard Errors': 'hard_errors',
                'Soft Errors': 'soft_errors',
                'Transport Errors': 'transport_errors',
                'Media Error': 'media_errors',
                'Predictive Failure Analysis': 'predictive_failure_analysis',
                'Illegal Request': 'illegal_request',
            }


# Generated at 2022-06-22 23:30:25.838642
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunoshardware = SunOSHardware()
    assert sunoshardware.platform == 'SunOS'

# Generated at 2022-06-22 23:30:26.957304
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test object creation
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:30:29.655279
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """Unit test for constructor of class SunOSHardware"""
    obj = SunOSHardware()
    assert obj is not None


# Generated at 2022-06-22 23:30:30.508266
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Initialization
    facts = {}
    SunOSHardwareCollector(facts, None, {}, None)

# Generated at 2022-06-22 23:30:37.586031
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module=module)

    input_text = """System Configuration: Sun Microsystems sun4u
Memory size: 16384 Megabytes
"""

    expected_dmi_facts = {
        'system_vendor': 'Sun Microsystems',
        'product_name': 'sun4u',
    }

    # Test sun4u with Sun Microsystems
    module.run_command.return_value = (0, input_text, '')
    dmi_facts = hardware_obj.get_dmi_facts()
    assert dmi_facts == expected_dmi_facts

    # Test i86pc with Oracle Corporation
    input_text = """System Configuration: Oracle Corporation VirtualBox
Memory size: 16384 Megabytes
"""


# Generated at 2022-06-22 23:30:40.743485
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware(dict())

    # TODO: Fill mocks for run_command
    assert hardware.populate() == {}

# Generated at 2022-06-22 23:30:52.158605
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # test data
    prtconf = "Memory size: 8 Gigabytes\n"

    swap = "total: 16384104k bytes allocated + 0k reserved = 16384104k used, 4194304k available\n"

    # create mock module
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    test_module.run_command = MagicMock(return_value=(0, prtconf, ''))
    test_module.run_command = MagicMock(return_value=(0, swap, ''))

    # Create instance of class SunOSHardware and execute get_memory_facts method
    sunoshardware = SunOSHardware()
    memory_facts = sunoshardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-22 23:30:56.454466
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()
    out = """
System Configuration: Sun Microsystems sun4u Sun Fire T1000
    System clock frequency: 1000 MHz
Memory size: 2048 Megabytes
===========================================================
"""
    dmi_facts = m.get_dmi_facts(out)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire T1000'

# Generated at 2022-06-22 23:31:08.535667
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    hardware_collector = SunOSHardwareCollector()
    hardware = hardware_collector.collect()

    assert type(hardware) == dict
    assert hardware['ansible_facts']['ansible_devices']
    assert hardware['ansible_facts']['ansible_devices'].keys()

    assert hardware['ansible_facts']['ansible_dmi']
    assert hardware['ansible_facts']['ansible_dmi'].keys()

    assert hardware['ansible_facts']['ansible_memtotal_mb']
    assert hardware['ansible_facts']['ansible_memory_mb']
    assert hardware['ansible_facts']['ansible_memory_mb']['nocache']['free']

# Generated at 2022-06-22 23:31:21.025378
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = None
    out_prtconf = """Memory size: 8192 Megabytes"""
    out_swap = """total:  83886080k bytes allocated + 62917312k reserved  = 146814370k used,  3701890692k available"""

    class MockModule(object):
        def run_command(self, command, *args, **kwargs):
            if command.find("prtconf") > 0:
                return 0, out_prtconf, None
            elif command.find("swap -s") > 0:
                return 0, out_swap, None
            else:
                return 0, "", None

    module = MockModule()
    sunos_h = SunOSHardware(module)
    memory_facts = sunos_h.get_memory_facts()

# Generated at 2022-06-22 23:31:23.552291
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Checks if we can create an instance. For now, that's all we need.
    """
    SunOSHardware()


# Generated at 2022-06-22 23:31:25.072679
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hw = SunOSHardware(dict())
    assert sunos_hw.platform == 'SunOS'

# Generated at 2022-06-22 23:31:36.712600
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    class TestModule(object):
        def __init__(self):
            self.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
            self.run_command_calls = method_calls

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return args[0] == '/usr/bin/kstat' and args[1] == 'cpu_info' and 0, output, ''

    class TestSunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = TestModule()

        @classmethod
        def platform_first(cls):
            return 'SunOS'

    class TestException(Exception):
        pass

# Generated at 2022-06-22 23:31:45.810305
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = {}
    facts['platform'] = 'SunOS'
    module = MagicMock(run_command=run_command)
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/kstat')

    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts == {'uptime_seconds': 1550851784}

# Generated at 2022-06-22 23:31:53.803117
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import get_collector_for_platform
    hardware = get_collector_for_platform('SunOS')

    # Stub
    hardware.module.run_command = lambda *a, **kw: (0, "", "")


# Generated at 2022-06-22 23:31:59.695516
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # The output of kstat can be different from system to system, so we test
    # it in this way.
    x = SunOSHardware()
    d = x.get_device_facts()
    if 'devices' not in d:
        assert False, "No devices found, while there should be at least one"
    else:
        if 'sd' not in d['devices']:
            assert False, "No sderr devices found, while there should be at least one"
    assert True

# Generated at 2022-06-22 23:32:13.298939
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

# Generated at 2022-06-22 23:32:15.514987
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_facts = SunOSHardwareCollector().collect()
    assert 'SunOS' in hardware_facts['platform']

# Generated at 2022-06-22 23:32:25.866269
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test that SunOSHardware.populate returns expected facts"""
    module = AnsibleModule(argument_spec=dict())
    facts = dict(platform='SunOS')
    sunOSHardwareCollector = SunOSHardwareCollector(module=module, facts=facts)

    # run the code to test
    sunOSHardwareCollector.collect()
    system_vendor = sunOSHardwareCollector.facts['system_vendor']
    product_name = sunOSHardwareCollector.facts['product_name']

    # Check expected results
    assert system_vendor == 'Fujitsu'
    assert product_name == 'SPARC Enterprise T5120'

# Generated at 2022-06-22 23:32:37.944897
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:50.875997
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Because the time.time() function is platform dependent
    # we mock the time call in case of tests with 'mocker' library.
    # The time.time() function should return an epoch time for
    # the test to have a positive result.
    # The time.time() function return an epoch time in seconds
    # so we provide an epoch time in seconds by multiplicating
    # 60 by 60 or by 24.
    # The get_uptime_facts function uses the time.time() function
    # to compute the uptime in seconds.
    # We use the mock_time value as the return value of the
    # time.time() function as it is a value in epoch time.
    mock_time = 1548249689

    # We need to patch the time.time() function so that
    # we can provide our own value because we cannot
    # manipulate

# Generated at 2022-06-22 23:33:02.594795
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_cases = [
        {'input': 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)',
            'expected': {'system_vendor': 'QEMU', 'product_name': 'Standard PC (i440FX + PIIX, 1996)'},
        },
        {'input': 'System Configuration: VMware, Inc. VMware Virtual Platform',
            'expected': {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'},
        },
        {'input': 'System Configuration: Sun Microsystems sun4v',
            'expected': {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'},
        },
    ]

    sunos_hw = SunOSHardware(dict())


# Generated at 2022-06-22 23:33:13.631687
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    class ModuleStub(object):

        def run_command(self, command):
            if command == '/usr/bin/uname -i':
                return 0, 'sparc', None
            elif command == '/usr/platform/sparc/sbin/prtdiag':
                return 0, 'System Configuration: Oracle Corporation sun4v\n', None
            else:
                raise NotImplementedError("Unexpected command was called: %s" % command)

    module = ModuleStub()

    hardware_collector = SunOSHardwareCollector(module)

    facts = hardware_collector.collect(['system_vendor', 'product_name'])
    assert facts['system_vendor'] == 'Oracle Corporation'
    assert facts['product_name'] == 'sun4v'

# Generated at 2022-06-22 23:33:20.540547
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware_facts = SunOSHardware(module)
    out = cpu_info_output
    module.run_command.return_value = (0, out, None)
    result = hardware_facts.get_cpu_facts()

    assert result['processor'] == ['SUNW,SPARC-Enterprise']
    assert result['processor_count'] == 1
    assert result['processor_cores'] == 16



# Generated at 2022-06-22 23:33:26.280893
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_object = SunOSHardware(None)
    test_object.module.run_command = run_command_mock
    real_return = test_object.get_dmi_facts()

    assert real_return == {
        'system_vendor': 'Oracle Corporation',
        'product_name': 'SUNW,SPARC-Enterprise',
    }



# Generated at 2022-06-22 23:33:38.149843
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule({})

# Generated at 2022-06-22 23:33:44.737588
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    h = SunOSHardware()
    h.module.run_command = lambda *args, **kwargs: ("", "sderr:::Product VBOX HARDDISK\nsderr:::Vendor  ATA\nsderr:::Serial No       VB0ad2ec4d-074a\nsderr:::Size    53687091200", "")
    device_facts = h.get_device_facts()
    assert device_facts['devices']['sd0']['product'] == "VBOX HARDDISK"
    assert device_facts['devices']['sd0']['serial'] == "VB0ad2ec4d-074a"
    assert device_facts['devices']['sd0']['size'] == "5.0 TB"

# Generated at 2022-06-22 23:33:46.885661
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware = SunOSHardware(dict())

    assert isinstance(hardware, SunOSHardware)
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector._fact_class == SunOSHardware
    assert SunOSHardwareCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:33:56.151248
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import platform
    import warnings

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware, SunOSHardwareCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import compare_dicts

    if platform.system() != 'SunOS':
        warnings.warn('test_SunOSHardware_populate is being skipped as the detected platform is not SunOS')
        return

    # test 1: SunOS x86 / x86_64
    # initialize Hardware instance
    sh = SunOSHardware()
    # create collected_facts
    cf = {'platform': 'SunOS'}

    # call method under test and compare
    result = sh.populate(cf)

    assert result['swapfree_mb'] == 1521
    assert result

# Generated at 2022-06-22 23:34:00.121899
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    har_coll = SunOSHardwareCollector()
    assert har_coll._fact_class == SunOSHardware
    assert har_coll._platform == 'SunOS'
    assert har_coll.required_facts == set(['platform'])


# Generated at 2022-06-22 23:34:05.506045
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """Test the SunOS HardwareCollector class."""

    required_facts = {
        'platform': 'SunOS',
    }

    hc = SunOSHardwareCollector(required_facts)
    assert hc.required_facts == required_facts
    assert hc._platform == 'SunOS'
    assert hc._fact_class == SunOSHardware

# Generated at 2022-06-22 23:34:16.485778
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts on SunOS facts module
    """


# Generated at 2022-06-22 23:34:29.043756
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class SunOSHardware"""

    class module(object):
        run_command_environ_update = None


# Generated at 2022-06-22 23:34:41.152508
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    class options:
        run_command_environ_update = {}

    class module:
        def __init__(self):
            self.options = options

        def get_bin_path(self, arg1, **kwargs):
            return arg1


# Generated at 2022-06-22 23:34:50.008250
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    cmd = ['/usr/bin/kstat', '-p']
    for ds in ['Product', 'Revision', 'Serial No', 'Size',
               'Vendor', 'Hard Errors', 'Soft Errors',
               'Transport Errors', 'Media Error',
               'Predictive Failure Analysis', 'Illegal Request']:
        cmd.append('sderr:::%s' % ds)

    rc, out, err = module.run_command(cmd)
    if rc != 0:
        return

    hardware = SunOSHardware()

    device_facts = hardware.get_device_facts()

    assert isinstance(device_facts, dict)
    assert isinstance(device_facts['devices'], dict)

# Generated at 2022-06-22 23:34:53.895527
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = MockModule()
    SunOSHardware(module)
    module.run_command.assert_called_with('/usr/bin/kstat cpu_info')

# Generated at 2022-06-22 23:34:57.325560
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = MockModule()
    testdata = [
        SunOSHardware(module),
    ]
    for testobj in testdata:
        testobj.module.run_command = Mock(return_value=(0, "unix:0:system_misc:boot_time    1548249689", ""))
        ret = testobj.get_uptime_facts()
        assert ret['uptime_seconds'] == int(time.time() - int("1548249689"))
