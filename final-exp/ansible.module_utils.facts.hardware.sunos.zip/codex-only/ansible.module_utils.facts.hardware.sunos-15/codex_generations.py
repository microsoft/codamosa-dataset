

# Generated at 2022-06-22 23:25:09.925030
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockedModule:
        def __init__(self, commands):
            self.commands = commands

        def run_command(self, cmd):
            rc = self.commands[cmd]['rc']
            out = self.commands[cmd]['out']
            err = self.commands[cmd]['err']
            return rc, out, err

        def get_bin_path(self, name, opt_dirs):
            return name


# Generated at 2022-06-22 23:25:13.358616
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    fact = hardware.get_device_facts()
    assert fact['devices']['sd0']['size'] == '25.00GiB'

# Generated at 2022-06-22 23:25:18.896469
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = Mock()

    module.run_command = MagicMock(return_value=(0, 'Memory size: 2048 Megabytes\n', ''))

    hw = SunOSHardware(module=module)

    facts = hw.get_memory_facts()

    assert facts['memtotal_mb'] == 2048
    if 'meminfo' in facts:
        assert facts['meminfo']['MemTotal'] == 2048 * 1024

# Generated at 2022-06-22 23:25:29.306162
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    out_good = 'System Configuration: Oracle Corporation sun4v'
    out_bad = 'System Configuration: \nOracle Corporation sun4v\n'

    dmi_facts_good = {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}
    dmi_facts_bad = {}

    module = AnsibleModule({})

    sh = SunOSHardware(module)

    assert sh.get_dmi_facts(out_good) == dmi_facts_good
    assert sh.get_dmi_facts(out_bad) == dmi_facts_bad



# Generated at 2022-06-22 23:25:37.862298
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    test_module.params = {}
    test_module.params['run_command_environ_update'] = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    test_module.command_callbacks = {}
    test_module.check_mode = False

    test_module.run_command = MagicMock(return_value=(0, 'module:   genunix', ''))
    test_SunOSHardware = SunOSHardware(test_module)
    result = test_SunOSHardware.get_cpu_facts()
    assert result

# Generated at 2022-06-22 23:25:49.682377
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time

    # get system time before test
    current_time = time.time()

    class MockModule(object):
        def __init__(self):
            self.run_command = MockRunCommand()
            self.params = {}

        def get_bin_path(self, executable, opt_dirs=None):  # note: opt_dirs is not used
            return executable

    class MockRunCommand(object):
        def __init__(self):
            pass


# Generated at 2022-06-22 23:25:53.123727
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict(collect_subset=dict(default=['!all'], type='list')))
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices']

# Generated at 2022-06-22 23:25:59.568011
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import calendar
    import datetime

    # The current time in seconds
    current_time = calendar.timegm(datetime.datetime.utcnow().utctimetuple())
    # The boot time in seconds
    boot_time = current_time - 60

    # The kstat data that represents this state
    kstat_out = 'unix:0:system_misc:boot_time    {}'.format(boot_time)

    # Create a new SunOSHardware object, then assign the kstat output to it (this is what
    # happens during execution)
    sh = SunOSHardware()
    sh.module.run_command.return_value = (0, kstat_out, '')

    # Invoke the method to be tested
    facts = sh.get_uptime_facts()

    # Get the resulting uptime_seconds value
   

# Generated at 2022-06-22 23:26:02.758823
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_fact = SunOSHardwareCollector('')
    assert sunos_fact.platform == SunOSHardware._platform
    assert sunos_fact.required_facts == set(['platform'])

# Generated at 2022-06-22 23:26:11.946516
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts = {}

    disk_stats = {
            'Product': 'product',
            'Revision': 'revision',
            'Serial No': 'serial',
            'Size': 'size',
            'Vendor': 'vendor',
            'Hard Errors': 'hard_errors',
            'Soft Errors': 'soft_errors',
            'Transport Errors': 'transport_errors',
            'Media Error': 'media_errors',
            'Predictive Failure Analysis': 'predictive_failure_analysis',
            'Illegal Request': 'illegal_request',
        }

    sh = SunOSHardware()
    #kstat output generated from a server running Solaris 10

# Generated at 2022-06-22 23:26:15.183216
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule({})
    facter = SunOSHardware(module)
    # access the method via class name
    assert facter.get_memory_facts() is not None

# Generated at 2022-06-22 23:26:17.137972
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-22 23:26:27.125881
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

    sun_hardware = SunOSHardware(module)
    sun_hardware.get_cpu_facts = MagicMock(return_value=['1', '2'])
    sun_hardware.get_memory_facts = MagicMock(return_value=['1', '2'])
    sun_hardware.get_dmi_facts = MagicMock(return_value=dict(product_name='test'))
    sun_hardware.get_device_facts = MagicMock(return_value=['1', '2'])

# Generated at 2022-06-22 23:26:34.938109
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()

    hardware_obj = SunOSHardware(module)

    hardware_obj.get_cpu_facts = mock.MagicMock(return_value={'processor_count': '1', 'processor': ['SPARC64-VI']})
    hardware_obj.get_memory_facts = mock.MagicMock(return_value={'memtotal_mb': '1024',
                                                                 'swapfree_mb': '1023',
                                                                 'swaptotal_mb': '1024',
                                                                 'swap_reserved_mb': '0',
                                                                 'swap_allocated_mb': '0'})
    hardware_obj.get_mount_facts = mock.MagicMock(return_value={'mounts': {}})
    hardware_obj.get_dmi_

# Generated at 2022-06-22 23:26:47.289233
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    result = {}
    SunOSHardware(module).populate()

    assert 'ansible_facts' in result
    assert 'hardware' in result['ansible_facts']
    assert result['ansible_facts']['hardware']['platform'] == 'SunOS'
    assert 'ansible_system_vendor' in result['ansible_facts']['hardware']
    assert 'ansible_product_name' in result['ansible_facts']['hardware']
    assert 'devices' in result['ansible_facts']['hardware']
    assert 'processors' in result['ansible_facts']['hardware']
    assert result['ansible_facts']['hardware']['memtotal_mb'] > 0

# Generated at 2022-06-22 23:26:57.081056
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Test data
    test_data = (
        # kstat output, expected result
        ('', {}),
        ('unix:0:system_misc:boot_time    1548249689', {'uptime_seconds': int(time.time() - 1548249689)}),
        ('unix:0:system_misc:boot_time    154824968', {'uptime_seconds': int(time.time() - 154824968)}),
        ('not unix:0:system_misc:boot_time    1548249689', {}),
    )

    for kstat_output, expected in test_data:
        result = SunOSHardware().get_uptime_facts({'platform': 'SunOS'})
        assert result == expected

# Generated at 2022-06-22 23:27:09.239268
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()

    # Test get_dmi_facts
    # No prtdiag command found
    module.run_command_return_values = [(1, '', '')]
    module.get_bin_path_return_values = [None]
    hardware.get_dmi_facts()

    # No prtdiag output
    module.run_command_return_values = [(0, '', '')]
    module.get_bin_path_return_values = ['/usr/sbin/prtdiag']
    hardware.get_dmi_facts()

    # Test dmi facts
    dmi_facts = {}
    system_conf = 'System Configuration: Dell Inc. PowerEdge R720'

# Generated at 2022-06-22 23:27:10.147541
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    pass

# Generated at 2022-06-22 23:27:20.687143
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    obj = SunOSHardware(module)

    test_data = {'cmd': '/usr/sbin/prtconf',
                 'stdout': 'Memory size: 16384 Megabytes',
                 'rc': 0}
    module.run_command.return_value = (test_data['rc'], test_data['stdout'], None)

    obj.get_memory_facts()
    assert module.run_command.called_once_with(test_data['cmd'])
    assert obj.facts['memtotal_mb'] == 16384


# Generated at 2022-06-22 23:27:32.395027
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import MagicMock
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import mock_open
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch

    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, """System Configuration:  Sun Microsystems  sun4u
Memory size: 8192 Megabytes  
""", '')

    with patch('ansible_collections.misc.not_a_real_collection.plugins.modules.hardware.sunos.open', mock_open()):
        hw = SunOSHardware(mock_module)

# Generated at 2022-06-22 23:27:33.697443
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:27:37.238650
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '1: stuff\n2: more stuff\nMemory size: 1024 Megabytes', ''))
    hw = SunOSHardware(module)
    ansible_facts = hw.populate()
    assert ansible_facts['memtotal_mb'] == 1024


# Generated at 2022-06-22 23:27:42.363013
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:27:49.446398
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware().get_memory_facts()

    assert(mem_facts.get('memtotal_mb') is not None)
    assert(mem_facts.get('swaptotal_mb') is not None)
    assert(mem_facts.get('swapfree_mb') is not None)
    assert(mem_facts.get('swap_allocated_mb') is not None)
    assert(mem_facts.get('swap_reserved_mb') is not None)

# Generated at 2022-06-22 23:28:00.290621
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from ansible.module_utils.facts import facts
    # Enable catching exceptions that the exception handler of AnsibleModule would catch anyway
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.collections import is_iterable
    from ansible.module_utils.common.text.formatters import bytes_to_human
    import module_utils.facts.hardware.sunos as sunos

# Generated at 2022-06-22 23:28:13.904630
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from module_utils.common.text.formatters import epoch_to_local_date

    class ModuleStub:
        def run_command(self, cmd):
            # kstat(1) is stubbed to return the uptime of the current machine
            # in seconds
            return (0, str(int(time.time()) - int(time.timezone)), None)

    module = ModuleStub()

    sunos_hw = SunOSHardware(module)
    uptime_seconds = sunos_hw.get_uptime_facts()['uptime_seconds']

    assert uptime_seconds < time.time()
    assert uptime_seconds > time.time() - time.timezone
    assert isinstance(uptime_seconds, int)

# Generated at 2022-06-22 23:28:24.084401
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_result = 0
            self.run_command_stdout = 'unix:0:system_misc:boot_time    1548249689'

        def run_command(self, command):
            return (self.run_command_result, self.run_command_stdout, '')

    sun_hardware = SunOSHardware(MockModule())
    assert sun_hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - int('1548249689'))}

# Generated at 2022-06-22 23:28:25.707805
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware({})
    hardware.get_dmi_facts()

# Generated at 2022-06-22 23:28:34.282265
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_dmi_facts = {'system_vendor': 'Sun Microsystems',
              'product_name': 'SPARC Enterprise T5220, No Keyboard'}

    test_cpu_facts = {'processor_cores': 1,
                      'processor_count': 2,
                      'processor': ['SPARC64-VI @ 2460 MHz',
                                    'SPARC64-VI @ 2460 MHz']}

    test_memory_facts = {'memtotal_mb': 8192,
                         'swapfree_mb': 24,
                         'swaptotal_mb': 25,
                         'swap_reserved_mb': 24,
                         'swap_allocated_mb': 1}


# Generated at 2022-06-22 23:28:42.474283
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    class TestModule:

        def __init__(self, out):
            self.out = out

        def run_command(self, cmd):
            return 0, self.out, None


# Generated at 2022-06-22 23:28:45.669371
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector('SunOS')
    assert collector._fact_class == SunOSHardware
    assert collector._platform == 'SunOS'

# Generated at 2022-06-22 23:28:58.464013
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.plugins.test.unit.compat import unittest
    from ansible.module_utils.facts.plugins.test.unit.compat.mock import patch

    # cpus is a list of dicts, created in SunOSHardware.get_cpu_facts.
    cpus = [{'product_name': 'Sun Fire'}]

    # patches is a list of tuples with the mock object and the target object

# Generated at 2022-06-22 23:29:00.912402
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {}
    expected = 'SunOS'
    SunOSHWC = SunOSHardwareCollector(facts)
    assert SunOSHWC._platform == expected

# Generated at 2022-06-22 23:29:03.017594
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Fake module
    module = DummyModule()
    # Fake command
    platform = SunOSHardwareCollector.collect(module, [])
    # Test
    platform.populate()
    assert module.run_command.called



# Generated at 2022-06-22 23:29:06.443738
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sun_hw = SunOSHardware({'ansible_processor': [1, 2, 3]})
    assert sun_hw.facts['ansible_processor'] == [1, 2, 3]

# Generated at 2022-06-22 23:29:17.462424
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    collector = SunOSHardwareCollector(module)


# Generated at 2022-06-22 23:29:20.638384
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hwc = SunOSHardwareCollector()
    assert hwc
    assert hwc._fact_class == SunOSHardware
    assert hwc._platform == 'SunOS'

# Generated at 2022-06-22 23:29:24.257437
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeModule(platform='SunOS')
    hardware = SunOSHardware(module)

    facts = hardware.get_cpu_facts()
    assert len(facts['processor']) == 1
    assert facts['processor_cores'] == 'NA'



# Generated at 2022-06-22 23:29:32.395155
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test get_dmi_facts with known input values"""
    mock_module = MockModule()
    mock_module.run_command = Mock()
    mock_module.run_command.return_value = (0, "System Configuration: Sun Microsystems  sun4u", "")
    sunoshardware = SunOSHardware(mock_module)

    assert sunoshardware.get_dmi_facts()['system_vendor'] == "Sun Microsystems"
    assert sunoshardware.get_dmi_facts()['product_name'] == "sun4u"

# Generated at 2022-06-22 23:29:40.097244
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = SunOSHardwareCollector.get_required_facts(dict())
    module.run_command = Mock(return_value=(0, '', ''))

    hardware_facts = SunOSHardwareCollector.collect(module, dict())
    assert hardware_facts['ansible_devices'] is not None
    assert len(hardware_facts['ansible_devices']) > 0
    assert hardware_facts['ansible_mounts'] is not None
    assert len(hardware_facts['ansible_mounts']) > 0
    assert hardware_facts['ansible_processor_cores'] is not None
    assert hardware_facts['ansible_processor_count'] is not None
    assert hardware_facts['ansible_memtotal_mb'] is not None
    assert hardware_facts['ansible_swapfree_mb'] is not None
    assert hardware

# Generated at 2022-06-22 23:29:45.802588
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test data
    module = MagicMock()
    # Actual call
    sunos_hc = SunOSHardwareCollector(module)
    # Check
    assert sunos_hc is not None
    assert sunos_hc._platform == 'SunOS'
    assert sunos_hc._fact_class == SunOSHardware



# Generated at 2022-06-22 23:29:47.327688
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware(dict())
    assert hardware_facts is not None

# Generated at 2022-06-22 23:29:54.469030
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    def _mock_run_command(module, command):
        class _Result:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

        if command[0] == "/usr/bin/uname":
            return _Result(0, 'sun4v\n', '')
        elif command[0] == "/usr/platform/sun4v/sbin/prtdiag":
            return _Result(0, 'System Configuration: Sun Microsystems sun4v Sun Fire T2000\n', '')
        else:
            return _Result(127, '', '')


# Generated at 2022-06-22 23:29:59.949900
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """This unit test tries to create an instance of the class SunOSHardware"""
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'


# This class is for unit testing by mocking the AnsibleModule class

# Generated at 2022-06-22 23:30:09.119957
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = DummyModule()
    # Dummy prtdiag output with 1 machine
    module.run_command.return_value = (0, 'Sun Microsystems  sun4v SPARC-Enterprise T5120', '')
    sunos_hw = SunOSHardware(module)
    assert sunos_hw.get_dmi_facts() == {'system_vendor': 'Sun Microsystems',
                                        'product_name': 'sun4v SPARC-Enterprise T5120'}
    # Dummy prtdiag output with 2 machines
    module.run_command.return_value = (0, 'Sun Microsystems  sun4v SPARC-Enterprise T5120 System Configuration:  VMware, Inc.    VMware Virtual Platform', '')
    sunos_hw = SunOSHardware(module)
    assert sunos_hw

# Generated at 2022-06-22 23:30:13.433471
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    Module = get_module_mock()
    instance = SunOSHardware(Module)

    prtconf_out = "Memory size: 32768 Megabytes"
    swap_out = "swapctl: swap resource        alloc     free\n" \
            +               "                    16110596  590816\n"
    Module.run_command.side_effect = [
        (0, prtconf_out, ''),
        (0, swap_out, '')
        ]

    output = instance.get_memory_facts()
    expected_output = {
        'swaptotal_mb': 30720,
        'swap_allocated_mb': 15740,
        'swap_reserved_mb': 1520,
        'swapfree_mb': 14200,
        'memtotal_mb': 32768
        }



# Generated at 2022-06-22 23:30:16.845906
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Construct an instance of the class
    obj = SunOSHardwareCollector()

    assert obj.required_facts == set(['platform'])
    assert obj._platform == 'SunOS'



# Generated at 2022-06-22 23:30:28.223261
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test return values of get_device_facts of class SunOSHardware
    """
    # Given:

# Generated at 2022-06-22 23:30:40.900903
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_object = SunOSHardware()

# Generated at 2022-06-22 23:30:43.424831
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = {}
    mem_facts = SunOSHardware().get_memory_facts()
    assert any(mem_facts)

# Generated at 2022-06-22 23:30:54.214830
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware(dict())

    # /usr/bin/kstat cpu_info output

# Generated at 2022-06-22 23:31:06.714867
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(None)

    out_format1 = 'module: %s\nbrand %s\nchip_id %s'
    out_format2 = 'module: %s\nimplementation %s'
    out1 = out_format1 % ('cpu_info', 'i86pc', 0)
    out2 = out_format1 % ('cpu_info', 'i86pc', '0')
    out3 = out_format2 % ('cpu_info', 'i86pc')
    out4 = out_format1 % ('cpu_info', 'i86pc', 0) + '\n' + out_format2 % ('cpu_info', 'i86pc')

# Generated at 2022-06-22 23:31:09.187495
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Return a SunOSHardwareCollector object to be tested.
    """
    module = AnsibleModule(argument_spec=dict())
    return SunOSHardwareCollector(module=module)


# Generated at 2022-06-22 23:31:18.531798
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware({})
    hardware.module = FakeAnsibleModule({})
    hardware.module.run_command = run_command_mock
    hardware_facts = hardware.get_memory_facts()
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 2560
    assert hardware_facts['swaptotal_mb'] == 3072
    assert hardware_facts['swap_allocated_mb'] == 3072
    assert hardware_facts['swap_reserved_mb'] == 3072


# Generated at 2022-06-22 23:31:24.116645
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    facts = {}
    facts['ansible_machine'] = "i86pc"
    facts['ansible_system_vendor'] = "Sun Microsystems"
    module = MockModule(facts=facts)
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']

# Generated at 2022-06-22 23:31:30.297458
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    test_data = [
        ('Memory size: 16384 Megabytes', 16384),
        (' Memory size: 4096 Megabytes', 4096),
        ('Memory size: 4096 ', 4096),
        ('Memory size: 2048', 2048),
        ('Memory size: 8192 Megabytes', 8192),
        ('Memory size: 8192 ', 8192),
    ]

    for input_data, expected_memory_size in test_data:
        hardware_obj = SunOSHardware()
        module_obj = FakeAnsibleModule(input_data)
        hardware_obj.module = module_obj

        collected_facts = hardware_obj.get_memory_facts()
        assert collected_facts['memtotal_mb'] == expected_memory_size


# Generated at 2022-06-22 23:31:41.112185
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.hardware.sunos
    import os

    sunos_facts = Collector(SunOSHardwareCollector).collect(None, None)

    old_get_file_content = ansible.module_utils.facts.hardware.sunos.get_file_content
    os.path.exists = lambda x: True

# Generated at 2022-06-22 23:31:48.863389
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = SunOSHardware({})
    rc = 0
    out = 'unix:0:system_misc:boot_time 1548249689'
    err = ''
    rc_mock, out_mock, err_mock = facts.module.run_command.mock.mock_calls[-1][-3:]
    assert rc == rc_mock
    assert out == out_mock
    assert err == err_mock
    assert {'uptime_seconds': 1548250823} == facts.get_uptime_facts()

# Generated at 2022-06-22 23:32:00.610939
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = {}

    # Mock run_command()
    module.run_command = MagicMock()

# Generated at 2022-06-22 23:32:13.809899
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule:
        def __init__(self, platform, command_result):
            self.platform = platform
            self.command_result = command_result

        def run_command(self, cmd):
            return self.command_result

    module_Solaris_0 = MockModule('SunOS', [0, '', ''])
    module_Solaris_1 = MockModule('SunOS', [0, 'Memory size: 2114976 Kilobytes', ''])
    module_Solaris_2 = MockModule('SunOS', [0, 'Memory size: 2114976 Kilobytes\n', ''])
    module_Solaris_3 = MockModule('SunOS', [0, 'Memory size: 2114976 Kilobytes\n', ''])

# Generated at 2022-06-22 23:32:19.798681
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        pass
    this_module = MockModule()
    this_module.run_command = run_command_mock
    module = SunOSHardware(this_module)

    uptime_facts = module.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 86400


# Generated at 2022-06-22 23:32:22.847195
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = get_module_mock()
    hardware = SunOSHardware(module=module)

    hardware.get_device_facts()

# Generated at 2022-06-22 23:32:25.259530
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = {}
    facts['platform'] = 'SunOS'
    sun = SunOSHardware(facts)
    assert sun.get_cpu_facts()

# Generated at 2022-06-22 23:32:32.183320
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    mock = {
        'platform': 'SunOS'
    }

    expected_out = {
        'processor': ['Intel(r) Core(TM) i5-2500 CPU @ 3.30GHz @ 3305MHz'],
        'processor_cores': 4,
        'processor_count': 1
    }

    h = SunOSHardware(mock, None)
    out = h.populate()

    assert out == expected_out

# Generated at 2022-06-22 23:32:41.912692
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardwareCollector().collect()[0]
    cpu_facts = hardware.get_cpu_facts()

    # Check that cpu facts are of type dict
    assert isinstance(cpu_facts, dict)

    # Check that cpu facts has the keys: processor, processor_cores, processor_count
    assert set(cpu_facts.keys()) == set(['processor', 'processor_cores', 'processor_count'])

    # Check that the values are of the correct type
    assert all(isinstance(value, (list, int)) for value in cpu_facts.values())

    # Check that a non empty list is returned for processor and processor_count
    for value in ['processor', 'processor_count']:
        assert isinstance(cpu_facts[value], list)
        assert cpu_facts[value]



# Generated at 2022-06-22 23:32:54.673357
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Create test class to have access to _module_name
    class TestClass(SunOSHardware):
        pass
    test_obj = TestClass(dict())

    # Make sure the inherited method returns an empty dictionary when module is run on an non-SunOS system
    # and the correct dictionary when module is run on a SunOS system
    if test_obj._module_name == 'ansible.builtin.sunos':
        returned_dmi_facts = test_obj.get_dmi_facts()
        assert returned_dmi_facts['system_vendor'] == 'Sun Microsystems', "get_dmi_facts returned wrong dmi_facts"
        assert returned_dmi_facts['product_name'] == 'E450', "get_dmi_facts returned wrong dmi_facts"
    else:
        assert test_obj.get_

# Generated at 2022-06-22 23:33:05.375755
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    device_facts = {'devices': {'sd0': {'hard_errors': '0',
      'illegal_request': '6',
      'media_errors': '0',
      'predictive_failure_analysis': '0',
      'product': 'VBOX HARDDISK',
      'revision': '1.0',
      'serial': 'VB0ad2ec4d-074a',
      'size': '53687091200',
      'soft_errors': '0',
      'transport_errors': '0',
      'vendor': 'ATA'}}}
    cpu_facts = {'processor': ['Oracle Corporation SUNW,SPARC-Enterprise'],
                 'processor_count': 1,
                 'processor_cores': 1}

# Generated at 2022-06-22 23:33:18.338180
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec={},
    )
    fact_class = SunOSHardware(module)
    fact_class.populate()
    assert fact_class._facts['devices']['sd0']['vendor'] == 'ATA'
    assert fact_class._facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert fact_class._facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert fact_class._facts['devices']['sd0']['revision'] == '1.0'
    assert fact_class._facts['devices']['sd0']['size'] == '51G'

# Generated at 2022-06-22 23:33:19.464202
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # placeholder for future unit tests
    assert True

# Generated at 2022-06-22 23:33:22.882406
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()

    assert collector._fact_class == SunOSHardware
    assert collector._platform == 'SunOS'
    assert collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:33:35.396894
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Checks that the device facts dictionary is correctly populated
    """
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-22 23:33:47.634563
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    facts = SunOSHardware()

# Generated at 2022-06-22 23:33:52.970715
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector
    module = Mock()
    setattr(module, 'params', {'gather_subset': ['all']})
    setattr(module, 'run_command', Mock(return_value=(0, 'output', 'error')))
    collector = SunOSHardwareCollector()
    collector.collect(module=module, collected_facts={'platform': 'SunOS'})

# Generated at 2022-06-22 23:34:05.635345
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class Options(object):
        def __init__(self):
            self.connection = 'local'
            self.become = True
            self.become_user = None
            self.become_method = 'sudo'
            self.ask_pass = False
            self.private_key_file = None
            self.timeout = 10
            self.ssh_common_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.ssh_extra_args = None
            self.verbosity = 0
            self.check = False
            self.syntax = False
            self.diff = False
            self.force_handlers = False
            self.flush_cache = None
            self.listhosts = None
            self.listtasks = None

# Generated at 2022-06-22 23:34:15.194609
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    import sys
    from ansible.module_utils.facts import Facts
    test_facts = Facts(dict(ANSIBLE_MODULE_ARGS={'gather_subset': 'all', 'gather_timeout': 5}))
    test_collector = SunOSHardwareCollector(module=None, facts=test_facts)
    assert test_collector.platform == 'SunOS'
    assert test_collector._platform == 'SunOS'
    assert test_collector.required_facts == SunOSHardwareCollector.required_facts
    assert test_collector._fact_class == SunOSHardware
    assert test_collector.collect() == {}
    sys.exit(0)



# Generated at 2022-06-22 23:34:28.835155
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible_collections.community.general.plugins.module_utils.facts import collect_facts

# Generated at 2022-06-22 23:34:33.437177
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert isinstance(hc, object)
    assert isinstance(hc, HardwareCollector)
    assert hc._fact_class == SunOSHardware
    assert hc._platform == 'SunOS'


# Generated at 2022-06-22 23:34:39.479022
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware_obj = SunOSHardwareCollector.fetch_fact(module)
    uptime_facts = hardware_obj.get_uptime_facts()

    assert isinstance(uptime_facts, dict)
    assert 'uptime_seconds' in uptime_facts


# Generated at 2022-06-22 23:34:42.913998
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    h = SunOSHardware()
    facts = h.get_dmi_facts()
    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'SUNW,SPARC-Enterprise'

# Generated at 2022-06-22 23:34:46.742438
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    sys_mem = SunOSHardware(module)
    sys_mem.get_memory_facts()



# Generated at 2022-06-22 23:34:51.455842
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type("Module", (object,), {})
    module.run_command = Mock(return_value=(0, 'Memory size: 256 Megabytes', None))
    module.exit_json = Mock()
    module.fail_json = Mock()
    module.warn = Mock()
    sunos = SunOSHardware(module)
    sunos.get_memory_facts()
    assert module.run_command.called



# Generated at 2022-06-22 23:34:56.704962
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    collector = SunOSHardwareCollector()
    fact = collector.collect()
    assert fact.device_facts['uptime_seconds'] == int(time.time() - int(1548249689))

# Generated at 2022-06-22 23:35:01.497321
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.get_device_facts()
    assert hardware_facts
    assert hardware_facts['devices']
    assert sorted(hardware_facts['devices'])