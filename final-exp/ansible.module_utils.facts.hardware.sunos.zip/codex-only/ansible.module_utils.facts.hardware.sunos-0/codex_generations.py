

# Generated at 2022-06-22 23:25:09.262168
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import platform
    import sys

    # Test on 32-bit Solaris 10.
    # Solaris 10 U8: System Configuration: VMware, Inc. VMware Virtual Platform
    sol_10_x86_vmware = {
        'system_vendor': 'VMware, Inc.',
        'product_name':  'VMware Virtual Platform',
    }

    # Solaris 10 U8: System Configuration: Sun Microsystems Sun Fire V490
    sol_10_x86_fire_v490 = {
        'system_vendor': 'Sun Microsystems',
        'product_name':  'Sun Fire V490',
    }

    # QEMU: System Configuration: QEMU PC (i440FX + PIIX, 1996)

# Generated at 2022-06-22 23:25:19.515910
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a test fixture to mock the module
    module = AnsibleModule(argument_spec=dict())

    # Create a test fixture to mock the kstat command
    mock_command = MockAnsibleModule()
    if mock_command.run_command is not module.run_command:
        mock_command.run_command = module.run_command

    # Create a test fixture to mock the module.fail_json
    mock_fail_json = MockAnsibleModule()
    if mock_fail_json.fail_json is not module.fail_json:
        mock_fail_json.fail_json = module.fail_json

    # Create the instance of the class
    hardware = SunOSHardware()

    # Use the mocked module
    hardware.module = module
    hardwaredevices = hardware.get_device_facts()

    # Check

# Generated at 2022-06-22 23:25:32.227920
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Patch needed because get_mount_facts() uses get_file_content() which uses 'cat'
    # instead of the module run_command.
    import __builtin__
    real_run_command = __builtin__.run_command
    __builtin__.run_command = lambda x: (0, '', '')

    # TODO: This should be a better implementation which doesn't rely on a real system
    hardware = SunOSHardware()
    hardware.module = type('_Module', (object,), {'run_command': lambda x: (0, '', '')})
    hardware.populate()
    # Do not check if os_family is set, this is not the business of the class and
    # is only added by the fact collector so that it can be used together with other facts

# Generated at 2022-06-22 23:25:41.815855
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test that the method get_dmi_facts of SunOSHardware module
    extracts the right attributes from the provided prtdiag output
    """
    prtdiag_out = '''System Configuration: VMware, Inc. VMware Virtual Platform
                         System Configuration: VMware, Inc. VMware Virtual Platform
                         System Configuration: VMware, Inc. VMware Virtual Platform
                         System Configuration: VMware, Inc. VMware Virtual Platform
                         System Configuration: VMware, Inc. VMware Virtual Platform'''
    test_SunOSHardware = SunOSHardware()
    test_SunOSHardware.module = DummyAnsibleModule()
    dmi_facts = test_SunOSHardware.get_dmi_facts(prtdiag_out)

    # verify the first 2 attributes are extracted
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_

# Generated at 2022-06-22 23:25:45.196468
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """This is to test the constructor of the SunOSHardwareCollector class"""
    sunos_hardware_collector_obj = SunOSHardwareCollector()
    assert sunos_hardware_collector_obj is not None

# Generated at 2022-06-22 23:25:54.493360
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:01.878752
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)


    fact_instance = SunOSHardware()
    fact_data = fact_instance.populate(collected_facts={'ansible_machine': "i86pc"})

    assert 'memtotal_mb' in fact_data
    assert 'swapfree_mb' in fact_data
    assert 'swaptotal_mb' in fact_data
    assert 'swap_reserved_mb' in fact_data
    assert 'swap_allocated_mb' in fact_data
    assert 'processor' in fact_data
    assert 'processor_count' in fact_data
    assert 'processor_cores'

# Generated at 2022-06-22 23:26:10.557163
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=(0, '', ''))

    hardware = SunOSHardware(module)

    module.run_command.return_value = (0, 'SunOS Release 5.11 Version 11.4 64-bit\n\nModule: cpu_info\nClock_MHz\t: 2400\nBrand\t\t: SPARC-T4\n\nModule: cpu_info\nClock_MHz\t: 2400\nBrand\t\t: SPARC-T4\n', '')

# Generated at 2022-06-22 23:26:23.093431
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Mock class to support testing
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_calls = 0
            self.run_command_response = ["", "Foo Bar", ""]

        def run_command(self, args):
            self.run_command_calls += 1
            return self.run_command_response

        def get_bin_path(self, name):
            return 'value returned by get_bin_path()'

    # Test cases

# Generated at 2022-06-22 23:26:26.688208
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector is not None
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'

# Generated at 2022-06-22 23:26:33.469081
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware(None)
    prtdiag_output = ""
    prtdiag_output += ("System Configuration: Sun Microsystems sun4v\n")
    prtdiag_output += ("Memory size: 16384 Megabytes\n")
    prtdiag_output += ("No kernel modules found.\n")
    prtdiag_output += ("=========================== CPUs\n")
    prtdiag_output += ("=========================== CPUs\n")
    prtdiag_output += ("=========================== cpus\n")
    prtdiag_output += ("       Id    Lwc   L2  L3  State    Core    Impl.  Mask\n")
    hardware.module.run_command = lambda x: (0, prtdiag_output, '')
    dmi_facts = hardware

# Generated at 2022-06-22 23:26:46.496136
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import Mock, patch
    from ansible_collections.misc.not_a_real_collection.tests.unit.modules.utils import set_module_args

    def exec_command(commands, check_rc=True):
        return exec_command_map.get(commands[0])

    def get_file_content(file):
        return file_content_map.get(file)

    def get_mount_size(filesystem):
        return mount_facts_map.get(filesystem)

    module = Mock()
    module.run_command = Mock(side_effect=exec_command)
    module.get_bin_path = Mock(return_value='/usr/bin/uname')
    module.get_

# Generated at 2022-06-22 23:26:57.121217
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test for get_dmi_facts() method of SunOSHardware class
    """
    module_args = dict()
    mock_module = MagicMock(**module_args)
    mocked_prtdiag_output = "System Configuration: Oracle Corporation sun4v\n"
    mocked_prtdiag_output += "System Configuration: Oracle Corporation sun4v\n"
    mocked_prtdiag_output += "System Configuration: Oracle Corporation sun4v\n"
    mocked_prtdiag_output += "System Configuration: Oracle Corporation sun4v\n"
    mocked_prtdiag_output += "System Configuration: Oracle Corporation sun4v\n"

    mock_module.run_command = MagicMock(return_value = (0, mocked_prtdiag_output, ""))
    sh = SunOSHardware

# Generated at 2022-06-22 23:27:09.279457
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('MockModule', (object,), {'run_command': lambda cmd: ('', '', '')})()

    facts = SunOSHardware(module).populate()
    assert facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert facts['devices']['sd0']['revision'] == '1.0'
    assert facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert facts['devices']['sd0']['size'] == '50.00 GB'
    assert facts['devices']['sd0']['vendor'] == 'ATA'
    assert facts['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-22 23:27:15.977844
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    import platform

    # mock platform to SunOS
    platform.system = lambda: 'SunOS'

    # create host object
    host = SunOSHardwareCollector()

    assert host.platform == 'SunOS'
    assert host.required_facts == set(['platform'])
    assert host._fact_class == SunOSHardware

# Generated at 2022-06-22 23:27:22.128569
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    collected_facts = {'ansible_machine': 'i86pc'}
    hardware = SunOSHardware()

    dmi_facts = hardware.get_dmi_facts(collected_facts)
    assert(dmi_facts['system_vendor'] == 'QEMU')
    assert(dmi_facts['product_name'] == 'Standard PC (i440FX + PIIX, 1996)')

# Generated at 2022-06-22 23:27:33.805418
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    output = ('module: cpu_info\n'
              'instance: 0\n'
              'clock_MHz: 2499\n'
              'state: on-line\n'
              'chip_id: 1\n'
              'brand:  \n'
              'module: cpu_info\n'
              'instance: 1\n'
              'clock_MHz: 2499\n'
              'state: on-line\n'
              'chip_id: 1\n'
              'brand:  \n')

    hardware = SunOSHardware({})
    hardware.populate()

    assert hardware.get('processor') == []

    hardware = SunOSHardware({'ansible_processor': 'processor'})
    hardware.populate()

    assert hardware.get('processor') == []


# Generated at 2022-06-22 23:27:47.102300
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MockModule()
    sunos = SunOSHardware(module)
    output = [
        'sderr:::Product   VBOX HARDDISK    9\n',
        'sderr:::Revision        1.0  9\n',
        'sderr:::Serial No       VB0ad2ec4d-074a    9\n',
        'sderr:::Size    53687091200 9\n',
        'sderr:::Vendor  ATA 9\n',
        'sderr:::Hard Errors     0   9\n'
    ]
    with patch('ansible.module_utils.facts.hardware.sunos.open') as mock_open:
        handle = MagicMock()
        handle.readlines.return_value = output

# Generated at 2022-06-22 23:27:49.889685
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sut = SunOSHardware(dict())
    # Returned product_name should contain 'Ultra-5'
    assert 'Ultra-5' in sut.get_dmi_facts()['product_name']

# Generated at 2022-06-22 23:27:55.025069
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    result = {'uptime_seconds': 1548249689}
    test_obj = SunOSHardware({}, None)
    test_obj._current_time = 1548249689
    test_obj.out = 'unix:0:system_misc:boot_time    1548249689'
    assert result == test_obj.get_uptime_facts()

# Generated at 2022-06-22 23:28:03.289094
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockedModule(object):
        class MockedRunCommand(object):
            class RunCommandReturn(object):
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.out = out
                    self.err = err

                def __repr__(self):
                    return "rc=%s, out=%s, err=%s" % (self.rc, self.out, self.err)

            def __init__(self, rc, out, err):
                self.return_value = self.RunCommandReturn(rc, out, err)

            def __call__(self, *args, **kwargs):
                return self.return_value


# Generated at 2022-06-22 23:28:10.140015
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """ Test generation of cpu facts from SunOS
    """
    hardware = SunOSHardware()

    facts = hardware.get_cpu_facts()
    assert facts['processor'] == ['SPARC64-VI @ 2000MHz', 'SPARC64-VI @ 2000MHz']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 2

# Generated at 2022-06-22 23:28:15.867847
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    This unit test verifies return value of SunOSHardware.get_dmi_facts
    method with expected output.
    :return:
    """
    s = SunOSHardware()
    assert s.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'SUNW,SPARC-Enterprise-T5140'}


# Generated at 2022-06-22 23:28:21.854171
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOS_hardware_collector = SunOSHardwareCollector([])
    assert SunOS_hardware_collector.platform == "SunOS"
    assert SunOS_hardware_collector.required_facts == {'platform'}
    assert SunOS_hardware_collector.collect() == {}


# Generated at 2022-06-22 23:28:31.821944
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class FakeModule(object):
        def __init__(self):
            self.run_command = ''

        def run_command(self, cmd):
            # cmd returns prtdiag output
            rc = 1
            out = (
                "System Configuration: VMware, Inc. "
                "VMware Virtual Platform          System Serial#: VMware-56 4d 84 c9 fe 85 28 d3-ac 8f fd e8 e2 c7 bb"
            )
            err = ''
            return (rc, out, err)

    class FakeHardware(SunOSHardware):
        def __init__(self, module=None):
            self.module = module
            self.dmi_facts = {}

        def populate(self, collected_facts=None):
            # gather facts
            self.dmi_facts = self.get_dmi_

# Generated at 2022-06-22 23:28:41.221472
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)

# Generated at 2022-06-22 23:28:45.119524
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(dict())

    # If get_cpu_facts method returns a dictionary, the unit test is successful
    assert(type(hardware.get_cpu_facts()) is dict)



# Generated at 2022-06-22 23:28:53.766650
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = None
    out = """
Memory size: 16384 Megabytes

System Configuration: VMware, Inc. VMware Virtual Platform
"""
    module = MagicMock(run_command=MagicMock(return_value=(0, out, '')))
    hardware = SunOSHardware(module)
    rc, out, err = module.run_command("/usr/sbin/swap -s")
    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 16384



# Generated at 2022-06-22 23:28:59.283208
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    This function can be used to test the constructor of class
    SunOSHardwareCollector
    """
    facts = dict()
    c = SunOSHardwareCollector(facts)
    c.collect()
    assert 'hardware' in c.collected_facts
    assert 'SunOS' in c.collected_facts['hardware']['platform']

# Generated at 2022-06-22 23:29:02.906782
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x.platform == 'SunOS'
    assert x.required_facts == set(['platform'])
    assert x._fact_class == SunOSHardware

# Generated at 2022-06-22 23:29:04.832453
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # SunOSHardware._get_cpu_facts('kstat_cpu_info.out')
    pass

# Generated at 2022-06-22 23:29:07.440821
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    hw = SunOSHardware(module)
    hw.get_dmi_facts()


# Generated at 2022-06-22 23:29:09.221939
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts_unix = SunOSHardware(dict())
    devices = device_facts_unix.get_device_facts()
    assert 'devices' in devices

# Generated at 2022-06-22 23:29:20.594207
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    prtconf = """
System Configuration: Oracle Corporation sun4v
   Memory size: 8192 Megabytes
   System Peripherals (Software Nodes):
      SUNW,Generic-x86
      SUNW,Generic-x86
      SUNW,Generic-x86
      SUNW,Generic-x86
      SUNW,Generic-x86
      SUNW,Generic-x86
      SUNW,Generic-x86
"""


# Generated at 2022-06-22 23:29:32.274299
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock
    hardware = SunOSHardware(module)

    # populate method is called, mock some values
    hardware.module.run_command_environ_update = {}
    hardware.module.run_command.return_value = (0, 'kstat: module: cpu_info', '')
    hardware.module.get_bin_path.return_value = '/usr/bin'

    # This is the expected value of the output of populate()

# Generated at 2022-06-22 23:29:37.187947
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.sunos.hardware import SunOSHardwareCollector

    fc = FactsCollector()

    fshc = SunOSHardwareCollector(fc)

    assert fshc.required_facts == set(['platform'])
    assert fshc._fact_class == SunOSHardware
    assert fshc._platform == 'SunOS'

# Generated at 2022-06-22 23:29:46.151188
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    data = """
System Configuration: VMware, Inc. VMware Virtual Platform
BIOS Configuration: Phoenix Technologies LTD 6.00 08/18/2011
"""
    instance = SunOSHardware()
    instance.module = MagicMock()
    instance.module.run_command.return_value = (0, data, '')
    dmi_facts = instance.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-22 23:29:48.793454
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = DummyModule()
    facter = SunOSHardware(module=module)
    facts = facter.populate()
    system_vendor = facts.get('system_vendor')
    product_name = facts.get('product_name')
    assert system_vendor == 'Oracle Corporation'
    assert product_name == 'Oracle Corporation sun4v SPARC T5-2'



# Generated at 2022-06-22 23:29:51.636840
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_obj = SunOSHardware()
    assert hardware_obj.populate()
    hardware_obj.populate(collected_facts=None)


# Generated at 2022-06-22 23:30:05.012024
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = {}
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'][0] == 'SPARC64-VII'
    assert hardware_facts['processor_cores'] == 32
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 524288
    assert hardware_facts['swapfree_mb'] == 5240
    assert hardware_facts['swaptotal_mb'] == 5280
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 40
    assert hardware_facts['devices']['sd0']['hard_errors'] == '0'
    assert hardware_facts

# Generated at 2022-06-22 23:30:06.957327
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    dsf = SunOSHardware().get_device_facts()
    assert type(dsf) == dict


# Generated at 2022-06-22 23:30:13.850773
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    platform_requirements = {'platform': 'SunOS'}
    x = SunOSHardwareCollector(platform_requirements)
    assert x.platform == 'SunOS'
    assert x.requirements.platform == 'SunOS'
    assert x.fact_class == SunOSHardware
    assert 'platform' in x.required_facts
    assert 'memtotal_mb' in x.optional_facts

# Generated at 2022-06-22 23:30:19.112996
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.sunos import SunOSHardware

    module = type('FakeModule', (object,), dict(params={}, run_command=_run_command))

    ansible_hardware = SunOSHardware(module)
    facts = ansible_hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 10



# Generated at 2022-06-22 23:30:19.934292
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    my_unit_test()



# Generated at 2022-06-22 23:30:28.481507
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    hardware._module = type('', (), {'run_command': lambda *_: (0, 'System Configuration: Fujitsu PRIMERGY RX200 S8', '')})

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'PRIMERGY RX200 S8'


# Generated at 2022-06-22 23:30:39.820377
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_data = '''System Configuration: VMware, Inc. VMware Virtual Platform
System clock frequency: 3194 MHz
Memory size: 16384 Megabytes
System revision: None
System serial number: VMware-42 16 d9 c6 ae c7 fc e1-9b 26 b2 c6 bc 30 62 68
'''

    expected_result = {'system_vendor': 'VMware, Inc.',
                       'product_name': 'VMware Virtual Platform'}

    module = mock.MagicMock()
    module.run_command = mock.MagicMock(return_value=(0, test_data, None))
    instance = SunOSHardware()
    assert instance.get_dmi_facts(module) == expected_result



# Generated at 2022-06-22 23:30:51.317203
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import SunOSHardwareCollector
    facter_facts = SunOSHardwareCollector.collect(None, [])

    assert facter_facts['memory']['swapfree_mb'] == facter_facts['memory']['swaptotal_mb'] - facter_facts['memory']['swap_allocated_mb']

    assert facter_facts['memory']['swapfree_mb'] == 3116
    assert facter_facts['memory']['swaptotal_mb'] == 3116
    assert facter_facts['memory']['swap_allocated_mb'] == 0
    assert facter_facts['memory']['swap_reserved_mb'] == 3116
    assert facter_facts['memory']['memtotal_mb'] == 4096

# Generated at 2022-06-22 23:30:53.873456
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector._fact_class is not None
    assert collector._platform == 'SunOS'
    required_facts = set(['platform'])
    assert collector.required_facts == required_facts


# Generated at 2022-06-22 23:31:06.299024
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Unit test for method populate of class SunOSHardware
    """
    hardware = SunOSHardware()

    # This returns a dictionary
    memory_facts = hardware.get_memory_facts()
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts

    cpu_facts = hardware.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor' in cpu_facts

    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts


# Generated at 2022-06-22 23:31:10.101086
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({'ansible_facts':
                        {'ansible_system_vendor': 'Oracle',
                         'ansible_product_name': 'T8-1',
                         'ansible_machine': 'sun4v',
                         'ansible_processor': ['sun4u ']}
                        })
    assert hw.platform == 'SunOS'

# Generated at 2022-06-22 23:31:14.182612
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw = SunOSHardwareCollector()
    assert hw._fact_class == SunOSHardware
    assert hw._platform == 'SunOS'
    assert hw.required_facts == set(['platform'])

# Generated at 2022-06-22 23:31:25.227554
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    mock_module = MockModule()

# Generated at 2022-06-22 23:31:36.751099
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # This unit test requires pytest
    # pip install pytest
    # py.test -v test_solaris_facts.py
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    def get_bin_path(exe, opt_dirs=None):
        return "/usr/bin/kstat"

    input_cmd = ['/usr/bin/kstat', '-p']

    for ds in disk_stats:
        input_cmd.append('sderr:::%s' % ds)

    input_cmd = " ".join(input_cmd)


# Generated at 2022-06-22 23:31:48.344201
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    sunos_hardware = SunOSHardware(module)


# Generated at 2022-06-22 23:31:56.876363
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()

    # code taken from kstat cpu_info -p for two CPUs

# Generated at 2022-06-22 23:32:05.288488
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:17.940365
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(None, {})

# Generated at 2022-06-22 23:32:28.943979
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:34.648789
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This is a unit test for method populate() of class SunOSHardware.
    """

    print('Test hardware/SunOS.py::test_SunOSHardware_populate')

    # Create a fact instance.
    hardware_facts = SunOSHardware()

    # Run method populate of the fact class.
    hardware_facts.populate()

# Generated at 2022-06-22 23:32:43.098457
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule()
    out = """module: SUNW,UltraSPARC-IIi @ 75 MHz
clock_MHz: 75
chip_id: 0
core_id: 0
implementation: SPARC_V9
module_id: 0
cpu_type: sun4u
brand: sun4u
cpu_bind: none
devid: cpu0
cpu_debug: no
sparc_cpu_start: 0
sparc_cpu_revision: 0x3
"""
    module.run_command = lambda *args, **kwargs: (out, "", 0)
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == "NA"
    assert cpu_facts['processor_count'] == 1

# Generated at 2022-06-22 23:32:52.154093
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert not hc.modules_to_skip()
    assert hc.required_facts == set(['platform'])
    assert hc.platform == 'SunOS'
    assert hc.fact_class == SunOSHardware
    assert hc.fact_name() == 'hardware'
    assert hc.get_files() == []
    assert hc.executions() == [('/usr/bin/kstat -p unix:0:system_misc:boot_time',)]
    assert hc.get_env_vars() == {}

# Generated at 2022-06-22 23:33:03.756396
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
    parser = re.compile(r"(\w+):\s+(.*)")

# Generated at 2022-06-22 23:33:10.872510
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    import sys
    import unittest
    from ansible.module_utils.facts.collector import Collector

    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'

    if sys.version_info[0] == 2:
        assert isinstance(collector, Collector)
    elif sys.version_info[0] == 3:
        assert issubclass(SunOSHardwareCollector, Collector)


# Generated at 2022-06-22 23:33:14.677722
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hardware_collector = SunOSHardwareCollector()
    required_facts = sunos_hardware_collector.required_facts
    assert 'platform' in required_facts


# Generated at 2022-06-22 23:33:17.362602
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    HWC = SunOSHardwareCollector()
    assert HWC._platform == 'SunOS'
    assert HWC._fact_class == SunOSHardware

# Generated at 2022-06-22 23:33:19.572684
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict(module=dict()))
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:33:31.800759
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: True

# Generated at 2022-06-22 23:33:37.273172
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:40.533050
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    facts_dict = {}
    facts_dict['platform'] = 'SunOS'
    hardware_obj = SunOSHardware(module, facts_dict)
    assert hardware_obj

# Generated at 2022-06-22 23:33:42.364855
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    obj = SunOSHardware({})
    obj._populate()

# Generated at 2022-06-22 23:33:47.423598
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    HardwareCollector._platform = 'SunOS'
    test_SunOSHardwareCollector = SunOSHardwareCollector()
    assert test_SunOSHardwareCollector._fact_class is SunOSHardware
    assert test_SunOSHardwareCollector._platform == 'SunOS'

# Generated at 2022-06-22 23:33:51.755752
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert hc.platform == 'SunOS'
    assert hc.required_facts == set(['platform'])
    assert hc._fact_class.platform == 'SunOS'
    assert hc.collect() is None

# Generated at 2022-06-22 23:34:04.659329
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import tempfile
    import os
    from ansible.module_utils.six import StringIO
    module_path = os.path.dirname(os.path.abspath(__file__))
    test_file = os.path.join(module_path, 'data/kstat_sd_err.txt')
    with open(test_file, 'r') as f:
        test_kstat_file = f.read()
    output = StringIO(test_kstat_file)
    module = type('AnsibleModule', (object,), {'run_command': lambda x: (0, output, None), 'get_bin_path': lambda x: x})
    hardware = SunOSHardware()
    hardware.module = module
    device_facts = hardware.get_device_facts()

# Generated at 2022-06-22 23:34:12.808549
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    run_command_mock = MagicMock(return_value=(0, '', ''))
    module.run_command = run_command_mock
    with patch.object(SunOSHardware, 'run_command', new=run_command_mock):
        sunos_hardware = SunOSHardware(module)

    # No kstat cpu_info returned
    run_command_mock.return_value = (1, '', '')
    assert sunos_hardware.get_cpu_facts() == {}

    # Valid kstat cpu_info

# Generated at 2022-06-22 23:34:18.014361
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0,
                                                'Memory size: 64 Megabytes',
                                                ''),
        'fail_json': lambda *args, **kwargs: None})()

    hardware = SunOSHardware()
    hardware.populate()
    assert hardware.get_memory_facts() == {'memtotal_mb': 64}

# Generated at 2022-06-22 23:34:28.877619
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class MockModule(object):
        def run_command(self, cmd):
            out = 'unix:0:system_misc:boot_time\t1552723580\n'
            err = None
            rc = 0
            return rc, out, err

    # From 'Fri Feb 15 17:06:20 CST 2019'
    current_time = 1552723580
    expected_uptime_in_seconds = int(current_time - 1552723580)

    m = MockModule()
    h = SunOSHardware(module=m)
    uptime_facts = h.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == expected_uptime_in_seconds

# Generated at 2022-06-22 23:34:40.928551
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    collected_facts = {}
    sunoshardware = SunOSHardware()
    new_facts = sunoshardware.populate(collected_facts)

# Generated at 2022-06-22 23:34:50.154994
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(side_effect=test_module_get_cmd_output)

    test_SunOSHardware = SunOSHardware(test_module)
    test_output = test_SunOSHardware.get_memory_facts()

    assert test_output['memtotal_mb'] == 12345
    assert test_output['swapfree_mb'] == 12345
    assert test_output['swaptotal_mb'] == 12345
    assert test_output['swap_allocated_mb'] == 12345
    assert test_output['swap_reserved_mb'] == 12345


# Generated at 2022-06-22 23:34:51.776607
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:34:53.946632
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mocked_module = type('', (), {'run_command': lambda x: (1, '', '')})
    obj = SunOSHardware(mocked_module)

    assert obj.get_memory_facts() == {'memtotal_mb': None}

# Generated at 2022-06-22 23:34:58.770974
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = SunOSHardware(module)
    facts = hardware.populate()
    expected_cpu_facts = {
        'processor': ['SUNW,UltraSPARC-IIe @ 295MHz'],
        'processor_cores': 1,
        'processor_count': 1 }
    assert facts['processor'] == expected_cpu_facts['processor']
    assert facts['processor_cores'] == expected_cpu_facts['processor_cores']
    assert facts['processor_count'] == expected_cpu_facts['processor_count']
