

# Generated at 2022-06-22 23:25:00.497293
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector({'platform': 'SunOS'})
    assert obj.platform == 'SunOS'

# Generated at 2022-06-22 23:25:11.464608
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-22 23:25:19.747634
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:25:21.036180
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:25:24.505986
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict())
    assert hardware.platform == 'SunOS'
    assert hardware.populate() == {}


# Generated at 2022-06-22 23:25:29.470820
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collect = SunOSHardwareCollector(None)

    assert collect.platform == 'SunOS'
    assert collect.required_facts == set(['platform'])
    assert isinstance(collect.get_facts(), dict)


if __name__ == '__main__':
    test_SunOSHardwareCollector()

# Generated at 2022-06-22 23:25:37.080247
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module = AnsibleModuleMock({'run_command': mock.Mock(return_value=(0, '5.5G', '')),
                                         'get_bin_path': mock.Mock(return_value='/usr/sbin/swap')})
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 5632
    assert memory_facts['swapfree_mb'] == 22
    assert memory_facts['swaptotal_mb'] == 22
    assert memory_facts['swap_allocated_mb'] == 0
    assert memory_facts['swap_reserved_mb'] == 0

# Generated at 2022-06-22 23:25:45.873430
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware = SunOSHardware()
    hardware.module = Mock()
    hardware.module.run_command.return_value = (0, "unix:0:system_misc:boot_time    1548249689", "")
    uptime_facts = hardware.get_uptime_facts()

    # uptime = $current_time - $boot_time
    # current_time = 1548249689 + 10000
    assert uptime_facts['uptime_seconds'] == int(1548349689 - 1548249689)

# Generated at 2022-06-22 23:25:48.431559
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.__class__.__name__ == 'SunOSHardwareCollector'


# Generated at 2022-06-22 23:25:50.510736
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock({})
    hardware = SunOSHardware(module)
    assert hardware._platform == 'SunOS'

# Generated at 2022-06-22 23:25:51.825522
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({}, None)
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:25:58.888232
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """ Unit test for method 'get_cpu_facts' of class SunOSHardware
        test the output of this method.
    """

# Generated at 2022-06-22 23:26:07.309925
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    def get_module(cmd_output=None, cmd_rc=-1, **kwargs):
        class FakeModule():
            def run_command(self, cmd):
                return cmd_rc, cmd_output, ''

            def get_bin_path(self, *args, **kwargs):
                pass

        module = FakeModule()

        return module

    def get_sd_kstat(data):
        def fake_run_command(cmd):
            if cmd[-1] == 'Product':
                out = ''
                for ds in data:
                    out += 'sderr:%s:%s,err:%s\t%s\n' % (ds['instance'], ds['instance'], ds['stat'], ds['value'])
            else:
                out = ''

# Generated at 2022-06-22 23:26:08.967279
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()

    assert hardware.platform == 'SunOS'


# Generated at 2022-06-22 23:26:16.819948
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test the method get_cpu_facts of the class SunOSHardware.
    """

    cpu_facts = SunOSHardware().get_cpu_facts()

    assert cpu_facts['processor'] == ["SUNW,UltraSPARC-IIi @ 297MHz"], "Invalid processor list"
    assert cpu_facts['processor_count'] == 2, "Invalid processor count"
    assert cpu_facts['processor_cores'] == 32, "Invalid processor cores"

# Generated at 2022-06-22 23:26:29.003076
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import subprocess
    # mocking the execution of the kstat command
    # mocking the kstat return values
    # Thanks to http://stackoverflow.com/a/28267723
    kstat_mock = subprocess.Popen(['/bin/sh'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    kstat_mock.stdin.write("echo \"unix:0:system_misc:boot_time    1548249689\"")
    kstat_mock.stdin.close()
    kstat_mock.wait()
    out, err = kstat_mock.communicate()

    # mocking the current time
    time.time_mock = 1548249690

    hw = SunOSHardware()
    h

# Generated at 2022-06-22 23:26:33.517326
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock({})
    hardware = SunOSHardware(module)
    rc, out, err = module.run_command(["/usr/sbin/prtconf"])

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 536870912



# Generated at 2022-06-22 23:26:46.572483
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    h = SunOSHardware()

    # Disk device name, and corresponding value
    # Expected output is a dictionary, d = {'sd<instance>': {<key>: <value>, ...}, ...}
    output = {}
    # Testing the following attributes, they should be present in all devices
    # product, revision, serial, size, vendor, hard_errors, soft_errors,
    # transport_errors, media_errors, predictive_failure_analysis, illegal_request

# Generated at 2022-06-22 23:26:55.725655
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import get_collector_for_platform

    collect_solaris_facts = get_collector_for_platform('SunOS')
    collect_solaris_facts.populate()
    collected_facts = collect_solaris_facts.facts

    memo_facts = collected_facts.get('ansible_facts', {}).get('ansible_memo', {})
    assert memo_facts.get('memtotal_mb') is not None
    assert memo_facts.get('swap_reserved_mb') is not None
    assert memo_facts.get('swap_allocated_mb') is not None


# Generated at 2022-06-22 23:26:58.854751
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = None
    hw = SunOSHardware(module)
    results = hw.get_cpu_facts()
    assert results['processor'] != []


# Generated at 2022-06-22 23:27:10.260516
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class KstatRunResult():
        def __init__(self, kstat_out):
            self.rc = 0
            self.stdout = kstat_out

    class MockModule():
        def __init__(self):
            self.run_command_result = None

        def run_command(self, cmd, **kwargs):
            return self.run_command_result

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd


# Generated at 2022-06-22 23:27:16.878363
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {
        'system_vendor': 'Sun Microsystems',
        'product_name': 'Sun Fire X4170'
    }
    h = SunOSHardware()
    facts = h.get_dmi_facts()
    assert facts == dmi_facts


# Generated at 2022-06-22 23:27:25.688509
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create a helper method to invoke _populate() method of SunOSHardware class
    def populate(module):
        # Instantiate SunOSHardware class
        sunos_hardware = SunOSHardware(module)
        # Invoke _populate() method of SunOSHardware class
        sunos_hardware.populate(collected_facts=collected_facts)
        # Return 'ansible_facts' from module_utils/facts/hardware/sunos.py
        return module._facts['ansible_hardware']

    # Create a test module for invoking populate() method
    module = AnsibleModule(argument_spec={})
    # Set some collected_facts for test module
    collected_facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': 'amd64',
    }
    # Invoke populate()

# Generated at 2022-06-22 23:27:35.498592
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Returns a dictionary containing the uptime (in seconds) of the system.
    :return: A dictionary containing the uptime (in seconds) of the system.
    """
    if platform.system() != 'SunOS':
        return

    result = {}
    # sample kstat output:
    # unix:0:system_misc:boot_time    1548249689
    rc, out, err = module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')

    if rc != 0:
        return result

    # uptime = $current_time - $boot_time
    result['uptime_seconds'] = int(time.time() - int(out.split('\t')[1]))

    return result


# Generated at 2022-06-22 23:27:48.385657
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Set up test variables.
    class MockModule(object):
        @staticmethod
        def run_command(cmd):
            return 0, "unix:0:system_misc:boot_time\t1548249689", ""

    module = MockModule()

    fact_class = SunOSHardware(module)

    # Call method.
    uptime_facts = fact_class.get_uptime_facts()

    # Assert that the uptime_seconds fact was generated.
    assert('uptime_seconds' in uptime_facts)

    # Assert that the uptime_seconds fact is an integer.
    assert(type(uptime_facts['uptime_seconds']) == int)

    # Assert that the uptime_seconds fact was calculated correctly.

# Generated at 2022-06-22 23:27:51.164566
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda: None

    SunOSHardware(module)

# Generated at 2022-06-22 23:27:59.736473
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()
    hardware = SunOSHardware(module)
    system_conf = ''
    with open('tests/data/kstat_cpu_info', 'r') as cpu_info_file_desc:
        system_conf = cpu_info_file_desc.read()

    module.run_command.return_value = (0, system_conf, '')
    cpu_facts = hardware.get_cpu_facts()

    # There are two physical CPUs
    assert cpu_facts['processor_count'] == 2
    # Each physical CPU has four cores
    assert cpu_facts['processor_cores'] == 8



# Generated at 2022-06-22 23:28:03.287620
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('AnsibleModuleMock', (object,), {})
    module.run_command = type('RunCommandMock', (object,), {})
    module.run_command.return_value = (0, 'Memory size: 8192 Megabytes', '')
    memory_facts = SunOSHardware(module).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-22 23:28:07.425888
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sut = SunOSHardware({})
    assert sut.platform == 'SunOS'
    assert sut._platform == 'SunOS'


# Generated at 2022-06-22 23:28:19.741965
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})

    # Dummy prtdiag output
    mock_command_run = MagicMock(return_value=(0,
                                               "System Configuration: test_system_vendor test_product_name\n",
                                               ""))
    # Dummy AnsibleModule.run_command() wrapper
    module.run_command = mock_command_run
    # Supress stdout and stderr
    module.no_log_values.update(['stdout', 'stderr'])
    # Supress module logging
    logging.disable(logging.CRITICAL)

    s = SunOSHardware(module)
    dmi_facts = s.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'test_system_vendor'

# Generated at 2022-06-22 23:28:23.035480
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock({})
    obj = SunOSHardware(module=module)
    output = obj.populate()
    pprint(output)



# Generated at 2022-06-22 23:28:32.302168
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock({'platform': 'SunOS'})
    facts = SunOSHardware(module)
    assert isinstance(facts, dict)
    assert isinstance(facts['processor'], list)
    assert isinstance(facts['processor_count'], int)
    assert isinstance(facts['processor_cores'], int) or facts['processor_cores'] == 'NA'
    assert isinstance(facts['memtotal_mb'], int)
    assert isinstance(facts['swaptotal_mb'], int)
    assert isinstance(facts['swapfree_mb'], int)
    assert isinstance(facts['swap_allocated_mb'], int)
    assert isinstance(facts['swap_reserved_mb'], int)
    assert isinstance(facts['system_vendor'], str)
   

# Generated at 2022-06-22 23:28:36.209477
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware()
    assert hw is not None
    assert hw.platform is not None
    assert hw.platform == 'SunOS'

    # Invoke the populate method
    hw.populate()


# Generated at 2022-06-22 23:28:39.394909
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {'platform': 'SunOS'}
    with SunOSHardwareCollector(facts) as collector:
        assert collector._fact_class is SunOSHardware
        assert collector._platform == 'SunOS'
        assert collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:28:46.293858
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware.platform == 'SunOS'
    assert hardware.get_cpu_facts() == {}
    assert hardware.get_device_facts() == {}
    assert hardware.get_dmi_facts() == {}
    assert hardware.get_mount_facts() == {}
    assert hardware.get_memory_facts() == {}
    assert hardware.populate() == {}

# Generated at 2022-06-22 23:28:49.288544
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec={}
    )
    hw = SunOSHardware(module=module)
    assert hw.platform == 'SunOS'

# Generated at 2022-06-22 23:28:56.368367
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # vendor product
    out1 = """
System Configuration: Fujitsu PRIMERGY RX100 S8
"""

    # product
    out2 = """
System Configuration: sun4v
"""

    # Neither vendor nor product
    out3 = """
System Configuration:
"""

    module = AnsibleModule({})
    sunos_hardware = SunOSHardware(module)

    # Unpatch the module.run_command method
    setattr(module, 'run_command', sunos_hardware.run_command)

    # test with case 1
    setattr(module, 'run_command_return_value', (0, out1, ''))
    result = sunos_hardware.get_dmi_facts()

# Generated at 2022-06-22 23:29:06.703560
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    module.run_command.return_value = (0, "System Configuration: Sun Microsystems sun4u", "")

    sunos_hardware = SunOSHardware(module)
    dmi_facts = sunos_hardware.get_dmi_facts()

    assert "system_vendor" in dmi_facts
    assert "product_name" in dmi_facts
    assert dmi_facts["system_vendor"] == "Sun Microsystems"
    assert dmi_facts["product_name"] == "sun4u"



# Generated at 2022-06-22 23:29:13.992158
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = None

        def run_command(self, args, check_rc=False):
            if args[0] == '/usr/bin/kstat cpu_info':
                return 0, KSTAT_CPU_INFO_OUTPUT, ''
            else:
                raise ValueError(args[0])

        @staticmethod
        def get_bin_path(name, opt_dirs=[]):
            return '%s_path' % name

    class MockFacts(object):
        def __init__(self):
            self.ansible_machine = 'i86pc'


# Generated at 2022-06-22 23:29:18.267891
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = {'ansible_machine': 'i86pc', 'ansible_system': 'SunOS'}
    hardware = SunOSHardware(facts)
    assert hardware.system == 'SunOS'
    assert hardware.platform == 'SunOS'
    assert hardware.machine == 'i86pc'

# Generated at 2022-06-22 23:29:24.952093
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collect = SunOSHardwareCollector()
    assert hasattr(collect, '_fact_class')
    assert SunOSHardware == collect._fact_class
    assert hasattr(collect, '_platform')
    assert 'SunOS' == collect._platform
    assert hasattr(collect, 'required_facts')
    assert {'platform'} == collect.required_facts


# Generated at 2022-06-22 23:29:35.799124
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(argument_spec={},supports_check_mode=True)
    set_module_args(dict(gather_subset='all', filter='*'))

    # Run the populate method of SunOSHardware class
    sunos_hardware = SunOSHardware(module)
    hardware_facts = sunos_hardware.populate()

    # Test whether the dictionary hardware_facts is not empty
    assert hardware_facts, "Hardware facts should not be empty"

    # Test whether the dictionary hardware_facts contains the required entries
    assert 'devices' in hardware_facts, "Hardware facts should contain 'devices'"
    assert 'uptime_seconds' in hardware_facts, "Hardware facts should contain 'uptime_seconds'"
    assert 'dmi' in hardware_facts, "Hardware facts should contain 'dmi'"

# Generated at 2022-06-22 23:29:43.278940
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    sunoshw_module = SunOSHardware(module)

    # fake prtdiag output

# Generated at 2022-06-22 23:29:51.909761
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    out = """
processor:0:cpu_info0:chip_id   0
processor:0:cpu_info0:clk_MHz   3200
processor:0:cpu_info0:core_id   0
processor:0:cpu_info0:implementation Oracle
processor:0:cpu_info0:module_id 0
processor:0:cpu_info0:state_desc ONLINE
processor:0:cpu_info0:state_idle_time   90
processor:0:cpu_info0:state_io_wait_time    0
processor:0:cpu_info0:state_stepped_time    0
processor:0:cpu_info0:state_wait_time   0
processor:0:cpu_info0:state_xcall_time  0
"""
    hardware_collector = SunOSHardwareCollector()


# Generated at 2022-06-22 23:30:02.816161
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_ansible_module = FakeAnsibleModule('SunOS')

    out = ' '
    err = "hello"
    rc = 0
    test_ansible_module.run_command = Mock(return_value=(rc, out, err))

    kstat_out = ' '
    kstat_err = "hello"
    kstat_rc = 0
    test_ansible_module.run_command = Mock(return_value=(kstat_rc, kstat_out, kstat_err))

    hw = SunOSHardware(test_ansible_module)
    hw.populate()

# Generated at 2022-06-22 23:30:08.510401
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = {}  # pretend we have no facts
    proc = SunOSHardware(facts=facts)

    result = proc.get_memory_facts()

    assert result
    assert result['memtotal_mb']
    assert result['swapfree_mb']
    assert result['swaptotal_mb']
    assert result['swap_allocated_mb']
    assert result['swap_reserved_mb']

# Generated at 2022-06-22 23:30:10.799395
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware({})
    facts = hardware.get_device_facts()
    assert isinstance(facts, dict)

# Generated at 2022-06-22 23:30:17.775052
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # create SunOSHardware object
    sunos_hardware = SunOSHardware()

    # create collected_facts dictionary
    collected_facts = {}

    # create CPU facts dictionary
    cpu_facts = {}

    # run get_cpu_facts method
    cpu_facts = sunos_hardware.get_cpu_facts(collected_facts=collected_facts)

    # check if the processor key is present
    assert 'processor' in cpu_facts

# Generated at 2022-06-22 23:30:30.746747
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # setup test variables
    module_args = dict()

    # setup mock values for module
    module_mock = MagicMock()

    # setup mock run_command to return kstat output
    run_command_mock = MagicMock()

# Generated at 2022-06-22 23:30:42.859162
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all', 'min'], type='list'),
        'gather_timeout': dict(default=10, type='int')
    })
    set_module_args(dict(gather_timeout=10))
    mock_run_command = Mock(return_value=(0, "Memory size: 16384 Megabytes", ""))
    with patch.object(SunOSHardware, 'run_command', mock_run_command):
        hardware = SunOSHardware(module)
        setattr(hardware, 'run_command', mock_run_command)

        # run test
        result = hardware.get_memory_facts()

# Generated at 2022-06-22 23:30:53.801918
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()

    hs = SunOSHardware(module)
    d = hs.get_device_facts()
    assert 'devices' in d
    assert 'sd0' in d['devices']
    assert 'product' in d['devices']['sd0']
    assert 'revision' in d['devices']['sd0']
    assert 'serial' in d['devices']['sd0']
    assert 'size' in d['devices']['sd0']
    assert 'vendor' in d['devices']['sd0']
    assert 'hard_errors' in d['devices']['sd0']
    assert 'soft_errors' in d['devices']['sd0']
    assert 'transport_errors' in d['devices']['sd0']

# Generated at 2022-06-22 23:31:06.202120
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}

    # The kstat CmdHelper won't find /usr/bin/kstat without this.
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils import basic

    class MockModule(object):
        def __init__(self):
            self._MODULE_COMPLEX_ARGS = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/kstat'

        def run_command(self, arg, check_rc=True, execute_in_check_mode=False, environ_update=None):
            output = get_file_content('kstat_output.txt')
            rc = 0
            return (rc, output, None)


# Generated at 2022-06-22 23:31:08.166307
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert issubclass(SunOSHardwareCollector, HardwareCollector)
    assert SunOSHardwareCollector._platform == 'SunOS'

# Generated at 2022-06-22 23:31:20.978870
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # id and mount_facts are mocked because they are tested in a separate unit test
    sunos_hw = SunOSHardware({})
    facts_dict = {'ansible_machine': 'i86pc'}
    sunos_hw.populate(facts_dict)
    assert 'processor' in facts_dict
    assert 'memtotal_mb' in facts_dict
    assert 'swapfree_mb' in facts_dict
    assert 'swaptotal_mb' in facts_dict
    assert 'swap_allocated_mb' in facts_dict
    assert 'swap_reserved_mb' in facts_dict
    assert 'system_vendor' in facts_dict
    assert 'product_name' in facts_dict
    assert 'devices' in facts_dict
    assert 'uptime_seconds' in facts_dict

# Generated at 2022-06-22 23:31:26.670909
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = ansible_mock.MockModule()
    module.run_command = lambda args: (0, 'Memory size: 32768 Megabytes\n', None)
    hardware = SunOSHardware(module=module)
    hardware.populate()
    assert hardware.facts['memtotal_mb'] == 32768

# Generated at 2022-06-22 23:31:29.746597
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = None
    hardware = SunOSHardware(module=module, collected_facts={})
    facts = hardware.get_memory_facts()
    assert facts == {}

# Generated at 2022-06-22 23:31:37.514975
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, command, check_rc=True):
            return (0, 'System Configuration: VMware, Inc.      VMware Virtual Platform\n', None)

    class MockFactCollector(object):
        facts = {
            'ansible_machine': 'i86pc'
        }

    hardware = SunOSHardware(MockModule(), MockFactCollector())

    dmi_facts = {'product_name': 'VMware Virtual Platform',
                 'system_vendor': 'VMware, Inc.'}

    assert hardware.get_dmi_facts() == dmi_facts


# Generated at 2022-06-22 23:31:47.028011
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Create a fake module
    fake_module = type('AnsibleModule', (), {
        'run_command': lambda *args, **kwargs: (0, "unix:0:system_misc:boot_time    1548249689", ""),
        'get_bin_path': lambda *args, **kwargs: "/usr/bin/kstat"
    })

    # Create SunOSHardware class
    sunos_hw = SunOSHardware(fake_module)
    uptime_facts = sunos_hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-22 23:31:51.056291
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    result = hardware.get_memory_facts()

    assert 'memtotal_mb' in result

# Generated at 2022-06-22 23:31:53.124125
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:31:55.842482
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware = SunOSHardwareCollector
    assert hardware._fact_class == SunOSHardware
    assert hardware._platform == 'SunOS'


# Generated at 2022-06-22 23:32:04.653000
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector import FactCollector

    # Fake module with basic run_command
    class FakeModule(object):

        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_out = []
            self.run_command_errs = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_rcs.pop(0), self.run_command_out.pop(0), self.run_command_errs.pop(0)

    class FakeFactsCollector(object):

        def __init__(self, module):
            self.module = module
            self.ansible_facts = {}

   

# Generated at 2022-06-22 23:32:17.325654
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Test that the SunOSHardware get_cpu_facts function returns
    the correct cpu facts"""
    mock_module = type('MockModule', (object,), {'run_command': Mock(return_value=(0, '', ''))})

# Generated at 2022-06-22 23:32:28.573997
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:32.703479
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = SunOSHardware()
    module.run_command = real_run_command
    memory_facts = module.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4964



# Generated at 2022-06-22 23:32:39.039469
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware()
    facts.module.get_bin_path = Mock(return_value="/usr/sbin/prtconf")

    prtconf_stdout = ("System Configuration: VMware, Inc. VMware Virtual Platform\n"
                      "Memory size: 8192 Megabytes\n")
    facts.module.run_command = Mock(return_value=(0, prtconf_stdout, ""))
    facts.get_memory_facts()

    assert facts.facts['memtotal_mb'] == 8192

    facts.module.run_command = Mock(return_value=(1, "", "ERROR"))
    facts.get_memory_facts()

    assert 'memtotal_mb' not in facts.facts

# Generated at 2022-06-22 23:32:52.202577
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class Module(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    # Oracle Corporation Sun Fire T2000

# Generated at 2022-06-22 23:32:54.623769
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    SunOSHardwareCollector.populate(module)


# Generated at 2022-06-22 23:33:00.671531
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    s = SunOSHardware(module)

    expected = s.get_dmi_facts()
    assert expected['system_vendor'] == 'Oracle Corporation'
    assert expected['product_name'] == 'SUNW,Netra-T12'


# Generated at 2022-06-22 23:33:08.599308
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:10.641300
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = SunOSHardware({})
    assert module.platform == 'SunOS'

# Generated at 2022-06-22 23:33:22.882520
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    mock = dict(ansible_facts={'devices': {'sda': {'revision': '1.0',
                                                   'hard_errors': '0',
                                                   'transport_errors': '0',
                                                   'serial': 'VB0ad2ec4d-074a',
                                                   'vendor': 'ATA',
                                                   'predictive_failure_analysis': '0',
                                                   'soft_errors': '0',
                                                   'product': 'VBOX HARDDISK',
                                                   'media_errors': '0',
                                                   'illegal_request': '6',
                                                   'size': '53687091200'}}})

# Generated at 2022-06-22 23:33:35.394992
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    obj = SunOSHardware(None)
    # Specification of the form {<output> : <expected_return_value>}
    # The output is derived from kstat output.
    # sderr:0:sd0,err:Hard Errors     0

# Generated at 2022-06-22 23:33:43.518874
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()['devices']

    for disk, values in device_facts.items():
        for key, value in values.items():
            assert not value.startswith('sderr:::'), 'For disk %s the %s value is not derived correctly.' % (disk, key)
            assert not value.strip() == '' or value is None, 'For disk %s the %s value is not derived correctly.' % (disk, key)



# Generated at 2022-06-22 23:33:46.017244
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    h = SunOSHardware({})
    assert h.platform == 'SunOS'

# Generated at 2022-06-22 23:33:55.476208
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('', (), {})
    module.params = {}
    module.run_command = classmethod(run_command)
    module.get_bin_path = classmethod(get_bin_path)
    module.run_command_environ_update = {}
    h = SunOSHardware(module)

    # Dummy facts
    collected_facts = {}
    collected_facts['ansible_machine'] = 'i86pc'

# Generated at 2022-06-22 23:33:58.179971
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    my_SunOSHardware = SunOSHardware({})
    assert my_SunOSHardware is not None
    assert my_SunOSHardware.populate() is not None

# Generated at 2022-06-22 23:34:04.658475
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    SunOSHardware_obj = SunOSHardware()
    SunOSHardware_obj.module = FakeModule()
    SunOSHardware_obj.module.run_command = staticmethod(lambda x, **kwargs: (0, "Memory size: 16384 Megabytes", ""))
    memory_facts = SunOSHardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384


# Generated at 2022-06-22 23:34:15.849858
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware(dict(ansible_facts=dict(platform='SunOS')))

    # Test if expected output is returned by get_dmi_facts()
    # when /usr/sbin/prtdiag returns output
    out = """
System Configuration: Oracle Corporation sun4v
Sun Microsystems VirtualBox
"""
    rc = 0
    err = ''
    hardware.module.run_command = MagicMock()
    hardware.module.run_command.return_value = (rc, out, err)
    expected = dict(system_vendor='Oracle Corporation', product_name='VirtualBox')

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == expected

    # Test that get_dmi_facts() returns
    # empty dict when /usr/sbin/prtdiag returns

# Generated at 2022-06-22 23:34:28.962973
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test CPU facts for SunOS
    """

# Generated at 2022-06-22 23:34:41.063475
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class mock_module():
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def run_command(self, command, environ_update=None, check_rc=True, data=None):
            self.run_command_calls += 1
            self.run_command_rcs.append(0)
            self.run_command_outs.append('''Memory size: 16384 Megabytes
''')
            self.run_command_errs.append('')

# Generated at 2022-06-22 23:34:45.810323
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_collector = SunOSHardwareCollector()
    assert sunos_collector.platform == 'SunOS'
    assert sunos_collector.fact_class._platform == 'SunOS'
    assert sunos_collector.required_facts == set(['platform'])

if __name__ == '__main__':
    # Unit test for constructor of class SunOSHardwareCollector
    test_SunOSHardwareCollector()

# Generated at 2022-06-22 23:34:48.906996
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = mock_run_command

    hardware.get_dmi_facts()

    assert hardware.facts['system_vendor'] == "Oracle Corporation"


# Generated at 2022-06-22 23:34:54.888602
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    import pytest

    fake_module = pytest.Mock()

    fake_module.run_command = pytest.Mock(
        side_effect=[
            (0,
             'Memory size: 20480 Megabytes',
             '')
        ]
    )

    fact_collector = FactsCollector(fake_module)
    fact_collector.collect()

    sunos_hardware = SunOSHardware(fact_collector._collected_facts, fact_collector._module)

    memory_facts = sunos_hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 20480



# Generated at 2022-06-22 23:34:57.742142
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware()
    assert hardware_facts.platform == 'SunOS'
