

# Generated at 2022-06-22 23:25:06.416124
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    This is a test for the method get_dmi_facts of the class SunOSHardware.
    """
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=False
    )
    module.run_command = MagicMock(return_value=(0, 'System Configuration: VMware, Inc. VMware Virtual Platform\nSystem Configuration: VMware, Inc. VMware Virtual Platform', ''))
    sunos_hardware = SunOSHardware(module)

    result = sunos_hardware.get_dmi_facts()

    assert result == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}


# Generated at 2022-06-22 23:25:16.301661
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    import sys
    import tempfile

    with tempfile.TemporaryFile(mode='w+t') as fake_out:
        fake_out.write('unix:0:system_misc:boot_time 1548249689')
        fake_out.seek(0)

        with mock.patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.get_uptime_facts') as uptime_facts:
            uptime_facts.return_value = ('', fake_out, '')
            result = SunOSHardware.get_uptime_facts()

        assert result['uptime_seconds'] > 0



# Generated at 2022-06-22 23:25:23.995904
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()
    sunos_hardware = SunOSHardware(module)

# Generated at 2022-06-22 23:25:28.720499
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fake_module = type('', (), {})()
    fake_module.run_command = lambda: ('', 'out', '')

    fake_module.get_bin_path = lambda x, opt_dirs: x

    fake_module.get_file_content = lambda x: ''
    fake_module.get_mount_size = lambda x: {}

    hardware_obj = SunOSHardware(fake_module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-IV+ @ 1665MHz']
    assert cpu_facts['processor_cores'] == 320
    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-22 23:25:33.162305
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = SunOSHardware(module=module)


# Generated at 2022-06-22 23:25:43.894777
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = object()
    collected_facts = {'ansible_machine': 'i86pc'}
    hardware_instance = SunOSHardware(module)
    module.run_command_environ_update = {'LANG': (b'UTF-8', b'UTF-8'), 'LC_ALL': (b'UTF-8', b'UTF-8'), 'LC_NUMERIC': (b'UTF-8', b'UTF-8')}
    module.run_command = lambda x: (0, b'', '')
    facts = hardware_instance.populate(collected_facts)
    assert facts
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']
    assert facts['memtotal_mb']
    assert facts['swapfree_mb']

# Generated at 2022-06-22 23:25:53.502428
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'run_command': ["/usr/bin/uname -i"],
            }

        def run_command(self, cmd, check_rc=True):
            return 0, self.params['run_command'][0], ''

    class MockFile(object):
        def __init__(self, platform):
            self.platform = platform
            self.content = "System Configuration: Sun Microsystems sun4u\n"

        def readline(self):
            return self.content

    hardware = SunOSHardware()
    module = MockModule()
    hardware.module = module

# Generated at 2022-06-22 23:25:59.273404
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    class Parmas:
        def __init__(self):
            self.run_command = module.run_command

    hw = SunOSHardware(Parmas())
    hw.module.run_command = module.run_command
    module.run_command.return_value = (0, "Memory size: 16384 Megabytes", '')
    assert hw.get_memory_facts() == {'memtotal_mb': 16384}

    module.run_command.return_value = (1, "Memory size: 16384 Megabytes", '')
    assert hw.get_memory_facts() is None


# Generated at 2022-06-22 23:26:07.725331
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Fixtures
    module = AnsibleModule(argument_spec={})
    module.check_mode = False

    # Get expected result from the collect_cmd
    rc, out, err = module.run_command("/usr/sbin/prtconf", check_rc=True)
    for line in out.splitlines():
        if 'Memory size' in line:
            expected_memtotal_mb = int(line.split()[2])

    rc, out, err = module.run_command("/usr/sbin/swap -s", check_rc=True)
    allocated = int(out.split()[1][:-1])
    reserved = int(out.split()[5][:-1])
    used = int(out.split()[8][:-1])

# Generated at 2022-06-22 23:26:20.463388
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Setup fixture
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    test_object = SunOSHardware(validate_threshold=True)
    # Setup some sane default response
    test_object.module = MockModule()

    # Setup mocked run_command responses
    test_object.module.run_command.return_value = [0, '', '']

    # Setup collected facts
    collected_facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': [
            'Intel(r) Core(tm) i5-4570 CPU @ 3.20GHz',
            'Intel(r) Core(tm) i5-4570 CPU @ 3.20GHz'
        ]
    }
    # Setup expected populate dictionary

# Generated at 2022-06-22 23:26:29.269385
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import pytest
    import ansible.module_utils.facts.hardware.sunos as sunos_hw
    import ansible.module_utils.facts.hardware.sunos.tests.test_fixtures.uptime as uptime

    ansible_module = sunos_hw.SunOSHardware()
    ansible_module.run_command = lambda cmd: (0, uptime.test_boot_time, None)

    # Check if uptime facts is calculated properly
    assert ansible_module.get_uptime_facts()['uptime_seconds'] == 1779

    # Check if a ValueError is raised if kstat command does not return the boot time in second
    ansible_module.run_command = lambda cmd: (0, "not a valid integer", None)
    with pytest.raises(ValueError):
        ansible_

# Generated at 2022-06-22 23:26:32.465709
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict())
    assert hardware is not None
    assert str(hardware) == '<ansible.module_utils.facts.hardware.sunos.SunOSHardware>'

# Generated at 2022-06-22 23:26:38.781572
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware({})
    hardware.module.run_command = lambda *args, **kwargs: (0, 'System Configuration: Sun Microsystems  sun4u\n', '')
    assert hardware.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

# Generated at 2022-06-22 23:26:43.580805
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This is a test stub to ensure that SunOSHardware.populate works.
    """
    module = 'test_module'

    # populate the fact_subset member
    SunOSHardwareCollector._fact_class.populate(module)

# Generated at 2022-06-22 23:26:52.291206
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    # Expected output, test case for SunOSHardware.get_dmi_facts()
    # {'product_name': 'SUNW,SPARC-Enterprise-T5220', 'system_vendor': 'Sun Microsystems'}
    assert SunOSHardware.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'SUNW,SPARC-Enterprise-T5220'}

# Generated at 2022-06-22 23:26:56.761433
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {}
    facts['platform'] = 'SunOS'
    sun_hw = SunOSHardwareCollector(facts, None)
    assert sun_hw != None
    assert sun_hw.platform == 'SunOS'
    assert sun_hw.required_facts == SunOSHardwareCollector.required_facts

# Generated at 2022-06-22 23:27:08.990083
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    The test cases use the file prtdiag.out, taken from a virtual machine running
    Solaris 10. This file only contains the first line of prtdiag's output,
    which contains the dmi facts needed for the test case.

    The Solaris 10 machine has a dual-core AMD processor, which is why
    there are many "AMD Athlon(tm)..." lines in the file.
    """

    # Test get_dmi_facts
    # initialize the ansible module
    module = AnsibleModule(argument_spec={})

    # initialize SunOSHardware class
    sunoshw = SunOSHardware(module)

    # run method get_dmi_facts
    sunoshw.get_dmi_facts()

    assert sunoshw.ansible_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-22 23:27:21.228658
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    meta = {'key': 'val'}
    module = MagicMock()
    SunOSHardware().get_device_facts()
    module.run_command.assert_called_once_with(['/usr/bin/kstat', '-p', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size', 'sderr:::Vendor'])

# Generated at 2022-06-22 23:27:31.350279
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import SunOSHardwareCollector

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    fact_list = [
        'dmi_facts',
        'device_facts',
        'get_mount_facts',
        'get_memory_facts',
        'get_cpu_facts',
        'get_uptime_facts',
    ]
    collector = SunOSHardwareCollector(module=module, facts=fact_list)
    collector.collect()
    facts = collector.get_facts()

    assert facts['uptime_seconds'] >= 0



# Generated at 2022-06-22 23:27:32.708295
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'

# Generated at 2022-06-22 23:27:46.161743
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hostname = 'test_host'
    data = {
        'ansible_facts': {'ansible_hostname': hostname},
        'changed': False,
        'failed': False,
        'invocation': {'module_args': ''},
        'rc': 0,
        'stdout': '',
        'stdout_lines': [],
    }
    facts = SunOSHardware()
    module = FakeAnsibleModule(**data)
    facts.module = module
    device_facts = facts.get_device_facts()
    assert device_facts['devices']['sd0']['size'] == '50G'
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-22 23:27:54.542221
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    current_time = 1548249689
    boot_time = 1548249589

    mock_module = Mock()
    mock_module.run_command.return_value = [0, boot_time, None]
    mocked_time = Mock()
    mocked_time.time.return_value = current_time
    sunos_hardware = SunOSHardware(mock_module,
                                   timeout=1,
                                   _time=mocked_time)

    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-22 23:27:59.210843
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Unit test for constructor of class SunOSHardware
    """
    module = Mock()
    sunos_hardware = SunOSHardware(module)
    assert sunos_hardware.platform == 'SunOS', 'Platform is not SunOS'
    assert sunos_hardware.module is module, 'Module is not the mock module'



# Generated at 2022-06-22 23:28:12.571060
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import pytest

    # Arrange
    test_class = SunOSHardware(None)

    # Subject under test - prtdiag command mock
    prtdiag_mock = ['/usr/bin/uname', '-i']

    # Expected result
    expected_dict = {'system_vendor': 'Oracle Corporation', 'product_name': 'Unknown'}

    # Act
    str_prtdiag_out = "System Configuration: Oracle Corporation Unknown"
    test_class.module.run_command = lambda cmd, environ_update, check_rc=False, data=None: (0, str_prtdiag_out, '')
    
    # Assert
    assert test_class.get_dmi_facts() == expected_dict


# Generated at 2022-06-22 23:28:18.670856
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    sunos_hardware = SunOSHardware()

    # Unit test using mocked values for cpu, memory, devices and uptime
    class ModuleMock():
        def __init__(self):
            self.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

# Generated at 2022-06-22 23:28:30.252922
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test if kstat output is parsed correctly
    """
    facts = SunOSHardware()
    out = """sderr:::Hard Errors     0
sderr:::Illegal Request 6
sderr:::Media Error     0
sderr:::Predictive Failure Analysis     0
sderr:::Product VBOX HARDDISK   9
sderr:::Revision        1.0
sderr:::Serial No       VB0ad2ec4d-074a
sderr:::Size    53687091200
sderr:::Soft Errors     0
sderr:::Transport Errors        0
sderr:::Vendor  ATA"""

    facts.module.run_command = lambda x: (0, out, '')
    devices = facts.get_device_facts()
    assert devices

# Generated at 2022-06-22 23:28:32.024874
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    myfact = SunOSHardwareCollector()
    platform = 'SunOS'
    assert myfact.platform == platform


# Generated at 2022-06-22 23:28:41.367286
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('module', (), {'run_command': lambda self, cmd: (0, cmd[1][-1], '')})()
    setattr(module, '_AnsibleModule__ansible_fact_cache', dict())
    setattr(module, '_AnsibleModule__ansible_module_params', dict(gather_subset='!all'))
    mem_facts = SunOSHardware(module).get_memory_facts()
    assert mem_facts['memtotal_mb'] == int(str(0))
    assert mem_facts['swapfree_mb'] == int(str(0))
    assert mem_facts['swaptotal_mb'] == int(str(0))
    assert mem_facts['swap_allocated_mb'] == int(str(0))

# Generated at 2022-06-22 23:28:51.666795
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Method populate of class SunOSHardware
    """
    m = SunOSHardware({})
    res = m.populate()
    assert type(res) is dict
    assert 'devices' in res
    assert 'memtotal_mb' in res
    assert 'mounts' in res
    assert 'processor_cores' in res
    assert 'processor_count' in res
    assert 'processor' in res
    assert 'product_name' in res
    assert 'swap_allocated_mb' in res
    assert 'swap_reserved_mb' in res
    assert 'system_vendor' in res
    assert 'uptime_seconds' in res

# Generated at 2022-06-22 23:29:04.244029
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    if not SunOSHardwareCollector.is_platform_supported(module.params['gather_subset']):
        module.fail_json(msg='Gathering facts on this platform is not supported')

    facts_collector = SunOSHardwareCollector(module=module)
    facts = facts_collector.collect(module.params['gather_subset'])
    ansible_facts = dict()
    for key, value in facts.items():
        key = 'ansible_' + key
        ansible_facts[key] = value
    module.exit_json(ansible_facts=ansible_facts)


# import module

# Generated at 2022-06-22 23:29:07.697689
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({'platform': 'sunos'})


if __name__ == '__main__':
    # Unit test for constructor of class SunOSHardware
    test_SunOSHardware()

# Generated at 2022-06-22 23:29:18.956689
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # mock out SunOSHardware.run_command("/usr/sbin/prtdiag")
    output1 = """System Configuration: Sun Microsystems  sun4u
   System clock frequency: 292 MHz
   Memory size: 4096 Megabytes
"""
    # mock out SunOSHardware.run_command("/usr/sbin/prtdiag")
    output2 = "System Configuration: QEMU     Standard PC (i440FX + PIIX, 1996)"

    sh = SunOSHardware()

    sh.run_command = mock.MagicMock(return_value=('', output1, ''))
    sh_dmi_facts = sh.get_dmi_facts()
    assert sh_dmi_facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

    sh.run_

# Generated at 2022-06-22 23:29:27.133694
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    m = SunOSHardware({})

    # output of kstat cpu_info
    out = """
    prtdiag: System Configuration: VMware, Inc. VMware Virtual Platform
    System clock frequency: 267 MHz
    Memory size: 1024 Megabytes
    Processor types: UNKNOWN
    Kernel version: 5.10
    """

    dmi_facts = m.get_dmi_facts(out)
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-22 23:29:36.521954
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collected_facts = {}
    facts_collector = SunOSHardwareCollector(collected_facts, None)

    assert facts_collector.platform == 'SunOS'
    assert facts_collector._fact_class == SunOSHardware
    assert facts_collector._fact_class.platform == 'SunOS'
    assert facts_collector.required_facts == {
        'platform',
    }


# ==============================================================================
# Unit tests for module
#
# If a test fails, check that the module is actually on the machine and
# that the required commands (e.g., prtconf) are in the path.
#
# Also, check that the module actually makes sense. For example, if the
# module takes the output of prtconf and parses it for something, the
# prtconf output must actually include what is being parsed for.

# Generated at 2022-06-22 23:29:40.883315
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    Sh = SunOSHardware(module)

    assert Sh.module == module
    assert Sh.platform == 'SunOS'
    assert Sh._facts['cache'] == {}

# Generated at 2022-06-22 23:29:49.617512
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule:
        def __init__(self, run_command_return_value):
            self.run_command_return_value = run_command_return_value
            self.run_command_calls = []

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_return_value

    class MockHardware:
        pass

    prtconf_result = """Memory size: 8192 Megabytes
    """.encode("utf-8")
    prtconf_return_code = 0
    swap_s_result = """total:     614576k bytes allocated +   614576k reserved =  1229152k used,  8386580k available
    """.encode("utf-8")

# Generated at 2022-06-22 23:30:02.813814
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    class DummyModule(object):
        def __init__(self, params=None):
            self.params = params or []

    def run_command(module, cmd):
        out = ""
        if cmd == "psrinfo -pv":
            out = psrinfo_out
        elif cmd == "/usr/sbin/prtconf":
            out = prtconf_out
        elif cmd == "/usr/sbin/swap -s":
            out = swap_out
        elif cmd == "/usr/bin/kstat cpu_info":
            out = kstatcpu_out
        elif cmd == "/usr/bin/kstat -p unix:0:system_misc:boot_time":
            out = kstatunix_out
        return 0, out, ""
    module = DummyModule()
   

# Generated at 2022-06-22 23:30:14.616531
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test for method populate of class SunOSHardware"""
    test_module = 'ansible_collections.ansible.builtin.tests.unit.modules.facts.hardware.test_sunos_hardware.AnsibleModuleMock'

    return_cpu_facts_json = {u'processor': [u'Generic SPARC', u'Generic SPARC'], u'processor_cores': 2, u'processor_count': 2}
    return_memory_facts_json = {u'swapfree_mb': 15, u'swaptotal_mb': 15, u'swap_allocated_mb': 15, u'swap_reserved_mb': 15, u'memtotal_mb': 256}

# Generated at 2022-06-22 23:30:22.953343
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sol = SunOSHardware()

    # Example output for SPARC:
    #System Configuration: Sun Microsystems  sun4u
    #System Configuration: Sun Microsystems  sun4v
    #System Configuration: Oracle Corporation sun4u
    #System Configuration: QEMU             SunOS-5.10-sun4u
    #System Configuration: VMware, Inc.     SunOS-5.10-sun4u
    #System Configuration: Fujitsu          SPARC Enterprise M3000
    #System Configuration: Fujitsu          SPARC Enterprise M4000
    #System Configuration: Fujitsu          SPARC Enterprise M5000
    #System Configuration: Fujitsu          SPARC64-VII
    #System Configuration: Fujitsu          SPARC64-VII+
    #System Configuration: Fujitsu          SPARC

# Generated at 2022-06-22 23:30:29.548809
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    sh = SunOSHardware(module)
    expected_facts = {
        'devices': {},
        'mounts': []
    }
    for fact in expected_facts:
        assert fact in sh.facts


# Generated at 2022-06-22 23:30:41.805757
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = DummyModule()
    hardware = SunOSHardware(module)


# Generated at 2022-06-22 23:30:45.525233
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hardware_collector = SunOSHardwareCollector()
    sunos_hardware = sunos_hardware_collector.collect()
    assert isinstance(sunos_hardware, SunOSHardware)

# Generated at 2022-06-22 23:30:55.455687
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Unit tests for get_cpu_facts() facts
    """
    module = type('DummyModule', (), {})
    module.run_command = lambda *a, **kw:(0, OUTPUT_CPU_INFO, None)
    module.get_bin_path = lambda *a, **kw: None
    module.run_command_environ_update = None
    module.params = {}
    facts = {'ansible_machine': 'i86pc'}
    hardware = SunOSHardware(module)
    result = hardware.get_cpu_facts(facts)

    assert result['processor_cores'] == 8
    assert result['processor_count'] == 2
    assert "Intel Xeon" in result['processor']

    facts = {'ansible_machine': 'sun4v'}
    result = hardware.get_cpu_facts

# Generated at 2022-06-22 23:31:06.988372
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sut = SunOSHardware()

    # Test for SunOS >= 9
    sut.get_dmi_facts = lambda: {'system_vendor': 'Fujitsu', 'product_name': 'SPARC Enterprise T5120'}
    expected = {'system_vendor': 'Fujitsu', 'product_name': 'SPARC Enterprise T5120'}
    assert sut.get_dmi_facts() == expected

    # Test for SunOS < 9
    sut.get_dmi_facts = lambda: {}
    expected = {'system_vendor': 'Sun Microsystems', 'product_name': 'SPARCstation-20'}
    assert sut.get_dmi_facts() == expected



# Generated at 2022-06-22 23:31:08.985342
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleFake(dict(platform=''))
    module.run_command = lambda *cmd: (0, 'Memory size: 128 Megabytes', '')
    hardware = SunOSHardware.fetch_platform_subclass(module)(module)

    assert hardware.get_memory_facts() == {'memtotal_mb': 128}



# Generated at 2022-06-22 23:31:21.672189
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    file_content = """
module: cpu_info
class: misc
instance: 0
    brand                         'sun4v'
    chip_id                       0
    clock_MHz                     1799
    fpu_type                      SIMD
    implementor                   'sun'
    L2_cache_associativity        8-way
    L2_cache_line_size            64
    L2_cache_size                 32768
    module                        'cpu_info'
    package_id                    0
    cpu_type                      'sparcv9'
    revision                      2.1
"""
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, file_content, '')
    testobj = SunOSHardware(mock_module)
    result = testobj.get_cpu_facts()
    assert result

# Generated at 2022-06-22 23:31:28.870500
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import json
    import os
    import platform
    import sys

    def run_command_side_effect(*args, **kwargs):
        if args[0] == '/usr/bin/kstat cpu_info':
            return 0, kstat_cpu_info, ''
        if args[0] == '/usr/sbin/prtconf':
            return 0, prtconf_content, ''
        if args[0] == '/usr/sbin/swap -s':
            return 0, swap_content, ''
        if args[0] == '/usr/bin/uname -i':
            return 0, 'i86pc', ''
        if args[0] == ['df', '-Tl']:
            return 0, df_content, ''

# Generated at 2022-06-22 23:31:35.553419
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_module = FakeModule()
    test_module.run_command = lambda args: (1,
        'System Configuration:  VMware, Inc.     VMware Virtual Platform', '')

    fake_SunOSHardware = SunOSHardware(test_module)
    result = fake_SunOSHardware.get_dmi_facts()

    assert result['system_vendor'] == 'VMware, Inc.'
    assert result['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-22 23:31:47.510728
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
        Tests for method to get device facts on a SunOS platform.
    """
    hardware_facts = SunOSHardware()
    test_device_facts = hardware_facts.get_device_facts()
    assert test_device_facts['devices'] is not None
    assert test_device_facts['devices'].get("sd0") is not None
    assert test_device_facts['devices']['sd0'].get("product") is not None
    assert test_device_facts['devices']['sd0'].get("revision") is not None
    assert test_device_facts['devices']['sd0'].get("serial") is not None
    assert test_device_facts['devices']['sd0'].get("size") is not None

# Generated at 2022-06-22 23:31:53.281383
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector._fact_class == 'SunOSHardware'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:32:01.326286
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class TestSunOSHardware :
        def get_bin_path(self, arg, opt_dirs=[]):
            return '/usr/sbin/prtdiag'

        class TestRunCommand :

            def __init__(obj, module):
                obj.run_command = module.run_command

            def run_command(obj, command):
                return 0, '', 'System Configuration: Oracle Corporation V480'

    sunoshw = SunOSHardware(TestSunOSHardware)

    dmi_facts = sunoshw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'V480'

# Generated at 2022-06-22 23:32:02.373043
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert True

# Generated at 2022-06-22 23:32:15.823202
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils._text import to_text
    from ansible.module_utils.ansible_release import __version__

    # This test assumes that kstat is installed on the system
    # If kstat is not installed the test will fail
    # This test also gets the current boot time and calculates the
    # Uptime of the system
    # If the current boot time is not returned the test will fail
    # If the uptime calculation is not correct the test will fail

    # Create a class simulator to test the method get_uptime_facts
    class Module:
        def __init__(self):
            self.run_command = mock_run_command
            self.get_bin_path = mock_get_bin_path

    #

# Generated at 2022-06-22 23:32:27.779230
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Test cases for method get_uptime_facts of class SunOSHardware.
    """
    # Create Mock module
    module = AnsibleModuleMock()

    # Create instance of class
    sh = SunOSHardware()

    # Mock the run_command method of module
    mock_run_command = MagicMock()
    sh.module = module
    sh.module.run_command = mock_run_command

    # Case 1: if boot time is not returned.
    uptime_facts_1 = {}
    mock_run_command.return_value = (1, '', '')
    assert sh.get_uptime_facts() == uptime_facts_1

    # Case 2: if boot time is returned.

# Generated at 2022-06-22 23:32:39.673677
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = mock.Mock()
    module.run_command.return_value = (0, OUTPUT_KSTAT_CPU_INFO, '')

    hardware = SunOSHardware(module)
    facts = hardware.get_cpu_facts()


# Generated at 2022-06-22 23:32:41.977601
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    collector = SunOSHardwareCollector()
    assert collector is not None


# Generated at 2022-06-22 23:32:52.906081
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModuleMock()
    SunOSHardwareCollector(module)
    assert module.run_command.called_once_with(
        ['/usr/bin/kstat', 'cpu_info', 'chip_id', 'clock_MHz', 'brand', 'implementation', 'module:']) is True  # noqa: E501
    assert module.run_command.called_once_with(['/usr/sbin/prtconf']) is True
    assert module.run_command.called_once_with(['/usr/sbin/swap', '-s']) is True
    assert module.get_bin_path.called_once_with("prtdiag") is True

# Generated at 2022-06-22 23:33:04.019221
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import os
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    facts = SunOSHardware()

# Generated at 2022-06-22 23:33:16.780727
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = get_module_mock()

# Generated at 2022-06-22 23:33:19.355867
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = SunOSHardware().get_dmi_facts()
    assert isinstance(dmi_facts, dict)


# Generated at 2022-06-22 23:33:29.685361
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_mock = {
        'ansible_machine': 'i86pc',
        'ansible_processor': 'unknown'
    }

    expected_dict = {
        'processor': [
            'Intel(r) Core(tm) i5-6267U CPU @ 2.90GHz @ 2900MHz',
            'Intel(r) Core(tm) i5-6267U CPU @ 2.90GHz @ 2900MHz'],
        'processor_cores': 4,
        'processor_count': 2
    }

    sunos_hardware = SunOSHardware(module=None)
    assert sunos_hardware.get_cpu_facts(hardware_mock) == expected_dict


# Generated at 2022-06-22 23:33:40.546908
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    This is a test case that tests the get_device_facts() method of SunOSHardware class.
    """
    class Module:
        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}

        def run_command(self, args, check_rc=True, environ_update=None):
            if 'kstat -p' in args:
                return (0, KSTAT_OUT, '')
            else:
                return (0, '', '')
    class Facts:
        def __init__(self):
            self.data = {}
    class File:
        def __init__(self):
            self.content = ''
        def get_content(self):
            return self.content

# Generated at 2022-06-22 23:33:53.048961
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:58.619114
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    module_mock = MagicMock()
    SunOS_hw = SunOSHardware(module_mock)
    result = SunOS_hw.get_cpu_facts()
    assert len(result['processor']) > 0

# Generated at 2022-06-22 23:34:03.634229
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeModule()
    SunOSHardware._module = module
    SunOSHardware.platform = 'SunOS'

    SunOSHardware.populate()

    assert module.run_command.call_count == 5
    SunOSHardware._module = None
    SunOSHardware.platform = None



# Generated at 2022-06-22 23:34:15.106347
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    m_run_command = Mock(return_value=(0, "sderr:::Product VBOX HARDDISK\nsderr:0:sd0,err:Product VBOX HARDDISK\nsderr:0:sd0,err:Revision        1.0\nsderr:0:sd0,err:Serial No       VB0ad2ec4d-074a\nsderr:0:sd0,err:Size    53687091200\nsderr:0:sd0,err:Soft Errors     0\nsderr:0:sd0,err:Transport Errors        0\nsderr:0:sd0,err:Vendor  ATA", ""))
    module.run_command = m_run_command

    sunos_hw = SunOSHardware

# Generated at 2022-06-22 23:34:23.309367
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_fact = {'memtotal_mb': 1023.6, 'swapfree_mb': 4095.1, 'swaptotal_mb': 4095.7, 'swap_allocated_mb': 0.5, 'swap_reserved_mb': 0.0}
    assert mem_fact == SunOSHardware().get_memory_facts()


# Generated at 2022-06-22 23:34:25.713759
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({})
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts



# Generated at 2022-06-22 23:34:29.244075
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sunos_hardware = SunOSHardware()
    memory_facts = sunos_hardware.get_memory_facts()
    assert isinstance(memory_facts, dict)
    # assert memory_facts == {}


# Generated at 2022-06-22 23:34:37.277686
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()

    out = 'unix:0:system_misc:boot_time 1548249689'
    module.run_command.return_value = (0, out, '')

    fact = SunOSHardware(module)
    res = fact.get_uptime_facts()
    assert res.get('uptime_seconds') > 0
    assert res.get('uptime_seconds') <= int(time.time())


# Generated at 2022-06-22 23:34:46.877903
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    output_prtconf = "System Configuration: Oracle Corporation sun4v\n"\
                     "Memory size: 8192 Megabytes\n"
    out = {}
    out['stdout'] = output_prtconf
    out['stdout_lines'] = output_prtconf.split('\n')
    out['stderr'] = None
    out['rc'] = 0
    out['delta'] = '0:00:00.009956'
    out['end'] = '2018-05-10 11:34:00.812604'
    out['start'] = '2018-05-10 11:34:00.802648'
    out['cmd'] = ['prtconf']
    out['invocation'] = {'module_args': 'prtconf'}

    outswap = {}
    outswap

# Generated at 2022-06-22 23:34:50.159761
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {'platform': 'SunOS'}
    result = SunOSHardwareCollector(facts, None)
    assert result
    assert result.platform == 'SunOS'
    assert result.required_facts == set(['platform'])
    assert result.collect()

# Generated at 2022-06-22 23:35:03.077452
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class ModuleDouble:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    # Create SunOSHardware object
    sunos_hardware = SunOSHardware(ModuleDouble(0, 'unix:0:system_misc:boot_time    1548249689', ''))

    # Test get_uptime_facts
    uptime_facts = sunos_hardware.get_uptime_facts()

    # Test if uptime_seconds = 1548249689 + 1548249700 - 1548249689 = 1548249700
    assert uptime_facts['uptime_seconds'] == 1548249700