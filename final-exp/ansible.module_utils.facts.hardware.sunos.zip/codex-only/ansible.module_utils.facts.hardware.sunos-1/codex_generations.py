

# Generated at 2022-06-22 23:24:56.615276
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware_obj = SunOSHardware()
    uptime_facts = hardware_obj.get_uptime_facts()
    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-22 23:25:08.792536
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import os
    import ansible.module_utils.facts.hardware.sunos as sunos

    data = ('Mem:   16384   0   0   0   0     0     0     0     0     0\n'
            'Swap:  49152   0   0   0   0     0     0     0     0     0')

    # On Solaris 8 the prtconf wrapper is absent from /usr/sbin,
    # but that's okay, because we know where to find the real thing:
    os.environ['PATH'] += os.pathsep + '/usr/platform/sun4u/sbin'

    h = sunos.SunOSHardware()
    # Monkey patching to avoid calls to external utils
    h.module.run_command = lambda x: (0, data, '')

    assert h.get

# Generated at 2022-06-22 23:25:12.097194
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector(None, None, [], [])
    assert collector._fact_class == SunOSHardware
    assert collector._platform == 'SunOS'


# Generated at 2022-06-22 23:25:21.889008
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class TestModule:
        def run_command(self, command):
            if command == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 0, 'unix:0:system_misc:boot_time    123456789', ''
            else:
                return 255, '', ''

    class TestFailModule:
        def run_command(self, command):
            return 255, '', ''

    m = TestModule()
    hardware = SunOSHardware(m)
    uptime = hardware.get_uptime_facts()
    assert uptime == {'uptime_seconds': 987654321}

    m = TestFailModule()
    hardware = SunOSHardware(m)
    uptime = hardware.get_uptime_facts()
    assert uptime == {}

# Generated at 2022-06-22 23:25:32.624914
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self, return_value=None):
            self.return_value = return_value

        def run_command(self, cmd):
            if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 0, repr(int(time.time() - self.return_value)), ''
            else:
                return 0, '', ''

    module = MockModule(return_value=100)
    hardware_obj = SunOSHardware(module=module)
    uptime_facts = hardware_obj.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-22 23:25:39.375741
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hw = SunOSHardware({'ansible_machine': 'Unknown'})
    # test cpu with valid output of kstat
    hw.module.run_command = mock.Mock(return_value=(0, "module: amd64\nbrand: AMD Opteron(tm) Processor 6276\nchip_id: 0\nclock_MHz: 2176\nimplementation: AMD\nmodule_cpuid: 0\nmodule_rev: 00000b00\nstatus: on-line\n", ""))
    result = hw.get_cpu_facts()
    assert result == {'processor': ['AMD Opteron(tm) Processor 6276 @ 2176MHz']}

    # test cpu with invalid output of kstat

# Generated at 2022-06-22 23:25:49.954482
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()
    obj = SunOSHardware(module)

    # Set cpu facts
    obj.module.run_command = Mock(side_effect=[(0, 'module:  i86pc', ''),
                                               (0, 'brand AMD', ''),
                                               (0, 'clock_MHz   500', ''),
                                               (0, 'implementation x86', ''),
                                               (0, 'chip_id 0', ''),
                                               (0, 'chip_id 1', ''),
                                               (0, 'chip_id 2', ''),
                                               (0, 'chip_id 3', ''),
                                               (0, 'chip_id 0', ''),
                                               (0, 'chip_id 1', '')])
    obj.module._socket.getaddrinfo = Mock

# Generated at 2022-06-22 23:25:57.823631
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m_module = MagicMock()

    m_out1 = MagicMock()
    m_out1.splitlines.return_value = ['Memory size: 128 Megabytes']
    m_module.run_command.return_value = (0, m_out1, None)

    m_out2 = MagicMock()
    m_out2.splitlines.return_value = ['kbytes      916700  alloc']
    m_module.run_command.return_value = (0, m_out2, None)

    sut = SunOSHardware(m_module)

    actual = sut.get_memory_facts()

    assert actual['memtotal_mb'] == 128
    assert actual['swapfree_mb'] == 0
    assert actual['swaptotal_mb'] == 0

# Generated at 2022-06-22 23:26:04.091037
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test_object = SunOSHardware(dict())

    def mock_run_command(command):
        return (0, 'unix:0:system_misc:boot_time    1548249689', '')

    test_object.module.run_command = mock_run_command

    expected_result = {'uptime_seconds': int(time.time() - 1548249689)}
    result = test_object.get_uptime_facts()

    assert result == expected_result

# Generated at 2022-06-22 23:26:12.866738
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = 'ansible.module_utils.facts.hardware.sunos.SunOSHardware'
    data = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

# Generated at 2022-06-22 23:26:23.969228
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:33.244025
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    This is a functional test for the get_device_facts method.  It requires the dmidecode tool to
    be available in order to run properly.
    """

    import sys
    import os
    import tempfile
    import textwrap
    import platform
    import shutil
    import subprocess
    import json
    import unittest

    # We do not run the functional test for Darwin
    if platform.system() == 'Darwin':
        return

    # Find the dmidecode executable
    dmidecode_exe = None
    for exe_name in ['dmidecode', 'dmi.py']:
        dmidecode_exe = shutil.which(exe_name)
        if dmidecode_exe:
            break

    # If we don't find it we skip the functional test

# Generated at 2022-06-22 23:26:39.310991
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # py3 compat
    fake_module = type('FakeModule', (), {'run_command': lambda self, args: (0, str(args), '')})
    sunos_hw = SunOSHardware(fake_module)

    assert sunos_hw.get_memory_facts() == {'memtotal_mb': 2048}

# Generated at 2022-06-22 23:26:48.256752
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # Example kstat output for Solaris 10, 11 and OmniOS
    module.run_command_environ_update = {}
    mock_cmd = MagicMock(return_value=(1,
                                       'sderr:0:sd0,err:Hard Errors     0',
                                       ''))
    with patch.dict(SunOSHardware.__dict__, {'run_command': mock_cmd}):
        hardware = SunOSHardware(module)
        facts = hardware.populate()
        assert facts['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-22 23:26:52.196387
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Required facts are incorrect
    with pytest.raises(TypeError):
        SunOSHardwareCollector(required_facts=['invalid_fact'])

    # Required facts are missing
    with pytest.raises(TypeError):
        SunOSHardwareCollector(required_facts=set())

# Generated at 2022-06-22 23:26:56.676004
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Arrange
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    hardware = SunOSHardware(None)

    # Act
    result = hardware.get_device_facts()
    # Assert
    assert type(result) == dict
    assert 'devices' in result


# Generated at 2022-06-22 23:27:08.904207
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    obj = SunOSHardware(module)

    prtconf_mock = "Memory size: 16 GB\n"
    swap_s_mock = """swapfile             dev  swaplo blocks   free
                /dev/zvol/dsk/rpool/swap  233,0      16  245760  245760"""

    module.run_command.side_effect = [(0, prtconf_mock, ''),
                                      (0, swap_s_mock, '')]


# Generated at 2022-06-22 23:27:22.545452
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import platform
    import subprocess
    # Create test cases for different operating systems
    testcases = {}

    # Solaris OpenIndiana

# Generated at 2022-06-22 23:27:30.536703
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = object()

    def run_command(cmd, check_rc=True):
        assert cmd == ['/usr/bin/kstat', '-p', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size', 'sderr:::Vendor']


# Generated at 2022-06-22 23:27:42.214235
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_fact = SunOSHardware()
    test_fact.module = FakeANSIModule()
    test_fact.module_setup = True
    test_fact.get_device_facts()
    assert test_fact.facts['devices']['sda']['serial'] == 'VBOX_HARDDISK_VB0ad2ec4d-074a'
    assert test_fact.facts['devices']['sda']['revision'] == '1.0'
    assert test_fact.facts['devices']['sda']['predictive_failure_analysis'] == '0'
    assert test_fact.facts['devices']['sda']['hard_errors'] == '0'


# Generated at 2022-06-22 23:27:52.942182
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module_mock = Mock()
    hw = SunOSHardware(module_mock)


# Generated at 2022-06-22 23:28:02.137482
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:28:15.327198
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:28:19.979497
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = SunOSHardware()
    uptime_facts = facts.get_uptime_facts()
    assert isinstance(uptime_facts, dict)
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-22 23:28:30.679091
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    collected_facts = dict(
        ansible_machine='SunOS',
        ansible_system='SunOS',
        ansible_memtotal_mb='2048',
        ansible_userspace_bits='32',
        ansible_processor=[
            'SUNW,SPARC-Enterprise',
            'SUNW,SPARC-Enterprise',
            'SUNW,SPARC-Enterprise',
            'SUNW,SPARC-Enterprise'
        ]
    )

    sh = SunOSHardware(module)
    sh.populate(collected_facts=collected_facts)
    assert sh.data['ansible_processor_cores'] == 'NA'
    assert sh.data['ansible_processor_count'] == 4

# Generated at 2022-06-22 23:28:32.738147
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    obj = SunOSHardware()
    mem = obj.get_memory_facts()
    assert isinstance(mem['memtotal_mb'], int)

# Generated at 2022-06-22 23:28:41.879445
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # create a fake module
    fake_module = type('AnsibleModule', (), {
        'get_bin_path': lambda *args, **kwargs: None,
        'run_command': lambda *args, **kwargs: (0, '', ''),
    })

    # create a SunOSHardware object using a fake module
    hardware = SunOSHardware(fake_module)

    # create a fake kstat output

# Generated at 2022-06-22 23:28:55.005751
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fixture_file = open('/usr/bin/uname', 'rb')
    try:
        uname_contents = fixture_file.read()
    except Exception as e:
        raise Exception("Failed to open /usr/bin/uname")
    finally:
        fixture_file.close()

# Generated at 2022-06-22 23:29:06.525229
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
    out = ('module:  genunix    implementation   : SUNW,Netra-T12\n'
           'clock_MHz:  428\n'
           'brand      : sun4u\n'
           'chip_id    : 7\n'
           'module:  genunix    implementation   : SUNW,Netra-T12\n'
           'clock_MHz:  428\n'
           'brand      : sun4u\n'
           'chip_id    : 7')
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['sun4u @ 428MHz']


# Generated at 2022-06-22 23:29:10.256694
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = SunOSHardware().get_dmi_facts()
    assert dmi_facts == {'product_name': 'SUNW,SPARC-Enterprise-T5120', 'system_vendor': 'Oracle Corporation'}

# Generated at 2022-06-22 23:29:12.477817
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import pytest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    H = SunOSHardware(None)  # no module

    assert H.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-22 23:29:24.944368
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    prtconf_output = """System Configuration: Sun Microsystems sun4u
Memory size: 1024 Megabytes
"""

    swap_output = """total: 123400k bytes allocated + 137944k reserved = 261344k used, 7420768k available
"""

    hardware = SunOSHardware()
    hardware.module = type('MockModule', (object,), {
        'get_bin_path': lambda self, path: path,
        'run_command': lambda self, cmd: [0, prtconf_output, ''],
    })()

    test_module = type('MockModule', (object,), {
        'run_command': lambda self, cmd: [0, swap_output, ''],
    })()

    hardware.module.module = test_module

    facts = hardware.populate()

# Generated at 2022-06-22 23:29:30.339002
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """This function is to test the constructor of class SunOSHardwareCollector
    """
    HardwareCollector.platform = 'SunOS'
    sunos_fact_collector = SunOSHardwareCollector()
    assert sunos_fact_collector._platform == 'SunOS'
    assert sunos_fact_collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:29:38.973946
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd):
            return (0, "unix:0:system_misc:boot_time 1548249689", "")

    class MockTime:
        def __init__(self, return_time):
            self._return_time = return_time

        def time(self):
            return self._return_time

    def mock_import(name):
        if name == 'time':
            return MockTime

    sun_os_hardware = SunOSHardware(MockModule())

    # Create some test data.
    module = MockModule()
    sun_os_hardware._time = MockTime(1548249697)
    fact_name = 'uptime_seconds'
    fact_value_expected = 8

    # Call the code under test.
    fact_value = sun_os

# Generated at 2022-06-22 23:29:46.680817
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware().populate()
    assert hardware['processor'] is not None
    assert hardware['processor_count'] > 0
    assert hardware['processor_cores'] > 0
    assert hardware['memtotal_mb'] > 0
    assert hardware['swaptotal_mb'] > 0
    assert hardware['swapfree_mb'] > 0
    assert hardware['swap_reserved_mb'] > 0
    assert hardware['swap_allocated_mb'] > 0

# Generated at 2022-06-22 23:29:48.020453
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = SunOSHardware().get_cpu_facts()
    if facts['processor_count'] > 0:
        assert True
    else:
        assert False


# Generated at 2022-06-22 23:29:54.950226
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:29:56.323605
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts.collector import FactCollector
    assert issubclass(SunOSHardwareCollector, FactCollector)


# Generated at 2022-06-22 23:29:59.824796
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert collector.platform == 'SunOS'

# Generated at 2022-06-22 23:30:09.098795
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class DummyModule():
        def __init__(self, tmp_path, rc, out, err):
            self._tmp_path = tmp_path
            self._rc = rc
            self._out = out
            self._err = err

        def get_bin_path(self, executable, opt_dirs=[]):
            return '/usr/bin/kstat'

        def run_command(self, cmd, environ_update=None):
            return [self._rc, self._out, self._err]

    class DummyModuleHardware():
        platform = 'SunOS'

    # unit test when return_code is not equal 0
    tmp_path = '/tmp/test_SunOSHardware_get_device_facts.temp'
    f = open(tmp_path, 'w')

# Generated at 2022-06-22 23:30:16.328826
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = FakeAnsibleModule()
    collector = SunOSHardwareCollector(module=module)
    assert collector.__class__.__name__ == 'SunOSHardwareCollector'
    assert collector.platform == 'SunOS'
    assert collector.module == module
    assert collector._fact_class == SunOSHardware
    assert collector.required_facts == set(['platform'])
    assert collector.collected_facts == {}



# Generated at 2022-06-22 23:30:20.981685
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # The tests here just ensure that the SunOSHardware instance can be created
    # successfully without raising any exceptions and without assertions
    # failing. More specific tests are done in ansible.module_utils.facts.test.
    # hardware.test_sunos.test_SunOSHardware.test_populate()

    # create an instance of the SunOSHardware class with out defining any
    # arguments
    hardware = SunOSHardware(dict())

# Generated at 2022-06-22 23:30:28.128209
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_test_facts = {
        'platform': 'SunOS',
        'ansible_system': 'SunOS',
        'ansible_machine': 'i86pc'}
    sunos_hw = SunOSHardware(sunos_test_facts)
    sunos_hw.populate()

    assert sunos_hw.get_facts() is not None


# Unit tests for methods in class SunOSHardware

# Generated at 2022-06-22 23:30:36.153762
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Test SunOSHardware.get_device_facts()."""
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    sunos_hardware = SunOSHardware()
    device_facts = sunos_hardware.get_device_facts()
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    for value in device_facts['devices'].values():
        assert isinstance(value, dict)



# Generated at 2022-06-22 23:30:42.553769
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = dict()
    instance = SunOSHardware()
    out = "unix:0:system_misc:boot_time    1548249689"
    uptime_facts['uptime_seconds'] = int(time.time() - int(out.split('\t')[1]))
    result = instance.get_uptime_facts()
    assert result == uptime_facts

# Generated at 2022-06-22 23:30:53.543975
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.run_command_results = [
                (0,
                 "System Configuration: Oracle Corporation sun4v Sun Fire X4270",
                 ""),
                (0,
                 "System Configuration: Oracle Corporation T5-8 Sun Fire T5240",
                 ""),
                (0,
                 "System Configuration: Oracle Corporation T5-8 Sun Fire T5240",
                 ""),
                (127,
                 "",
                 ""),
            ]
        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/prtdiag"
        def run_command(self, *args, **kwargs):
            return self.run_command_results.pop()


    module = MockModule()
    m = SunOSHardware(module)

# Generated at 2022-06-22 23:31:05.844464
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = Hardware()

# Generated at 2022-06-22 23:31:08.539713
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = SunOSHardwareCollector(module=module, facts={'platform': 'SunOS'})
    hardware_collector.get_memory_facts()

# Generated at 2022-06-22 23:31:21.025470
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    class MockModule:
        def run_command(self, arg):
            if arg == "/usr/sbin/prtconf":
                return (0, "Memory size: 16384 Megabytes", "")
            if arg == "/usr/sbin/swap -s":
                return (0, "total: 379508k bytes allocated + 257728k reserved = 637236k used, 493436k available", "")
            raise Exception("run_command called with unknown arg '%s'" % arg)

    class MockTime:
        def __init__(self):
            self.time = 100000

        def time(self):
            return self.time

    real_time = time.time
    time.time = MockTime()

    h = SunOSHardware()
    h.module = MockModule()

    facts = h.get_memory_

# Generated at 2022-06-22 23:31:28.505113
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    cmd = module.run_command

    hardware = SunOSHardware(module)

    assert hardware.get_dmi_facts() == {}

    platform = 'i86pc'

# Generated at 2022-06-22 23:31:34.210894
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hw_collector = SunOSHardwareCollector()
    assert type(sunos_hw_collector) == SunOSHardwareCollector
    assert sunos_hw_collector._fact_class == SunOSHardware
    assert sunos_hw_collector._platform == 'SunOS'
    assert sunos_hw_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:31:43.563179
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # create a test-only module
    module = AnsibleModule(argument_spec={})

    # create an instance of the class
    sun_hw = SunOSHardware(module)

    # generate a test case
    test_case = dict(
        memtotal_mb_orig=131099,
        memtotal_mb_test=sun_hw.get_memory_facts()['memtotal_mb']
    )

    # test the memtotal_mb
    assert test_case.get('memtotal_mb_orig') == test_case.get('memtotal_mb_test')


# Generated at 2022-06-22 23:31:52.609397
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    #
    # Mock object
    #
    class MockModule(object):

        def __init__(self):
            self.run_command_results = [
                0,
                "System Configuration: Sun Microsystems  sun4u",
                ""
            ]
            self.run_command_calls = 0

        def run_command(self, cmd, data=None):
            rc = self.run_command_results[self.run_command_calls]
            out = self.run_command_results[self.run_command_calls + 1]
            err = self.run_command_results[self.run_command_calls + 2]
            self.run_command_calls += 3
            return rc, out, err

    #
    # Test in normal case.
    #
    m = MockModule()



# Generated at 2022-06-22 23:31:55.928414
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module)
    assert hardware_facts.platform == 'SunOS'


# Generated at 2022-06-22 23:32:04.748524
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import module_utils.facts.hardware.sunos
    import ansible_collections.ansible.community.plugins.module_utils.facts.hardware.sunos

    FactsCollector().collect()
    hardware_instance = sunos.SunOSHardware()
    hardware_instance.populate()
    hardware_instance.post_process()
    hardware_instance.write_cache()
    hardware_instance.get_cpu_facts()
    hardware_instance.get_memory_facts()
    hardware_instance.get_dmi_facts()
    hardware_instance.get_device_facts()
    hardware_instance.get_uptime_facts()

    # FIXME: need to

# Generated at 2022-06-22 23:32:12.981008
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', None)

    c = SunOSHardware()
    c.module = module

    res = c.get_uptime_facts()

    # We mock the time, always the same, so the uptime (current time - boot time) should be a constant.
    assert res['uptime_seconds'] == 1555018495

# Generated at 2022-06-22 23:32:25.773767
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock({})
    hardware = SunOSHardware(module)

    module.run_command.return_value = (0, '', '')
    module.run_command_environ_update = {}
    rc, out, err = module.run_command("/usr/bin/kstat cpu_info")

    module.run_command.assert_called_with("/usr/bin/kstat cpu_info")
    assert rc == 0

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 'NA'

    memory_facts = hardware.get_memory_facts()
    assert isinstance(memory_facts['memtotal_mb'], int)

    dmi_facts = hardware.get_dmi_facts()

# Generated at 2022-06-22 23:32:37.792118
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_facts = SunOSHardware(dict())


# Generated at 2022-06-22 23:32:50.681997
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module=module)
    # Setting the facts that are otherwise collected by
    # the setup module.
    hardware_obj.facts['ansible_architecture'] = 'x86_64'
    hardware_obj.facts['ansible_system'] = 'SunOS'
    hardware_obj.facts['ansible_machine'] = 'i86pc'
    hardware_obj.facts['ansible_selinux'] = ''

# Generated at 2022-06-22 23:32:59.214351
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    my_SunOSHardware = SunOSHardware(module)

    rc, out, err = module.run_command('/usr/bin/kstat cpu_info')
    assert rc == 0

    cpu_facts = my_SunOSHardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-22 23:33:02.595710
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test that get_dmi_facts() returns a dict"""
    host = SunOSHardware()
    result = host.get_dmi_facts()
    assert isinstance(result, dict), "get_dmi_facts() should return a dict"

# Generated at 2022-06-22 23:33:09.429604
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class ModuleMock(object):
        def run_command(self, args):
            return (0, 'unix:0:system_misc:boot_time 1548249689', '')

    class FactsMock(object):
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

        def get(self, key):
            return self.facts[key]

        def set(self, key, value):
            self.facts[key] = value

    mm = ModuleMock()
    ff = FactsMock()
    sh = SunOSHardware()
    sh.module = mm
    sh.facts = ff
    sh.collect()
    assert ff.get('uptime_seconds') == int(time.time()) - 1548249689


# Generated at 2022-06-22 23:33:22.068770
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class module:
        def __init__(self, rc, out, err):
            self._rc = rc
            self._out = out
            self._err = err

        def run_command(self, cmd):
            return self._rc, self._out, self._err

    m = module(0, 'unix:0:system_misc:boot_time    1548249689', '')
    h = SunOSHardware(m)
    expected_uptime = {'uptime_seconds': int(time.time() - 1548249689)}
    actual_uptime = h.get_uptime_facts()

    if actual_uptime == expected_uptime:
        print("PASSED: test_SunOSHardware_get_uptime_facts()")

# Generated at 2022-06-22 23:33:32.856423
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    uptime = SunOSHardware()
    uptime_facts = uptime.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts
    uptime_seconds = uptime_facts['uptime_seconds']
    uptime_human = bytes_to_human(to_bytes(uptime_seconds, nonstring='passthru'))
    assert uptime_seconds >= 0
    assert uptime_human.endswith('s')

# Generated at 2022-06-22 23:33:34.370340
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:33:37.339994
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hw_collector = SunOSHardwareCollector()
    assert sunos_hw_collector.platform == 'SunOS'
    assert sunos_hw_collector.required_facts == {'platform'}

# Generated at 2022-06-22 23:33:40.242955
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = get_module_mock()
    sunos_hardware = SunOSHardware(module)
    assert isinstance(sunos_hardware.module, get_module_mock())

# Generated at 2022-06-22 23:33:43.145926
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Test SunOSHardwareCollector class constructor.
    """
    facts = SunOSHardwareCollector()
    assert facts._platform == 'SunOS'

# Generated at 2022-06-22 23:33:54.409038
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    #Create SunOSHardware object
    sun_hw_obj = SunOSHardware({})

    #Check if memory facts have been populated
    assert sun_hw_obj.populate().get('memtotal_mb') is not None
    assert sun_hw_obj.populate().get('swapfree_mb') is not None
    assert sun_hw_obj.populate().get('swaptotal_mb') is not None
    assert sun_hw_obj.populate().get('swap_allocated_mb') is not None
    assert sun_hw_obj.populate().get('swap_reserved_mb') is not None
    assert sun_hw_obj.populate().get('mounts') is not None

    #Check if cpu facts have been populated
    assert sun_hw_obj.populate().get('processor') is not None
   

# Generated at 2022-06-22 23:34:07.040686
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import ansible.module_utils.facts.hardware.sunos
    import ansible.module_utils.facts.hardware.sunos

    system_out_prtconf = """
System Configuration: VMware, Inc. Virtual Platform
Memory size: 1024 Megabytes
"""
    system_out_swap = """swap -s
total: 16384k bytes allocated + 0k reserved = 16384k used, 20431968k available
"""
    ah = SunOSHardware(dict(), dict())
    ah._module.run_command = lambda *args, **kwargs: (0, system_out_prtconf, '')
    memory_facts = ah.get_memory_facts()
    print(memory_facts)

# Generated at 2022-06-22 23:34:17.262772
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware(None)

# Generated at 2022-06-22 23:34:29.519014
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    fake_module = _FakeAnsibleModule()
    fake_module.params = {}

    facts_collector = SunOSHardware(fake_module)
    facts = facts_collector.populate()
    for fact in ['memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'swap_allocated_mb', 'swap_reserved_mb',
                 'processor', 'processor_cores', 'processor_count',
                 'system_vendor', 'product_name']:
        assert fact in facts
    assert isinstance(facts['memtotal_mb'], int)
    assert isinstance(facts['swapfree_mb'], int)
    assert isinstance(facts['swaptotal_mb'], int)
    assert isinstance(facts['swap_allocated_mb'], int)

# Generated at 2022-06-22 23:34:41.911828
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()


# Generated at 2022-06-22 23:34:51.483282
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Tests for SunOSHardware
    module = AnsibleModuleMock({'ansible_machine': 'i86pc'})
    SunOSHardwareCollector.add_collector(module)
    ansible_facts = {'ansible_machine': 'i86pc'}
    SunOSHardwareCollector.populate(ansible_facts, module)
    assert 'ansible_memtotal_mb' in ansible_facts
    assert 'ansible_processor' in ansible_facts
    assert 'ansible_processor_cores' in ansible_facts
    assert 'ansible_processor_count' in ansible_facts
    assert 'ansible_swapfree_mb' in ansible_facts
    assert 'ansible_swaptotal_mb' in ansible_facts
    assert 'ansible_system_vendor' in ansible_facts

# Generated at 2022-06-22 23:35:02.007453
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {'uptime_seconds': 123456789}

    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, 'unix:0:system_misc:boot_time    123456789', ''))

    hardware = SunOSHardware(module).get_uptime_facts()
    module.run_command.assert_called_once_with('/usr/bin/kstat -p unix:0:system_misc:boot_time')

    assert hardware == uptime_facts