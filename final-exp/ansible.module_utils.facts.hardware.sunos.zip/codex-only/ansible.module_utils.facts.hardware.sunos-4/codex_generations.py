

# Generated at 2022-06-22 23:25:07.939505
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    system_output = {
        'platform': 'SunOS',
        'command_prtconf': (
            'System Configuration: VMware,  Inc. VMware Virtual Platform\n'
            'Memory size: 1024 Megabytes\n'
            'System Peripherals (Software Nodes):\n'
            'vsw\n'),
        'command_swap': (
            'total:  8192k bytes allocated + 124680k reserved = 128k used,\n'
            '        85436k available\n'),
    }
    expected_result = {
        'memtotal_mb': 1024,
        'swap_allocated_mb': 8,
        'swap_reserved_mb': 124,
        'swaptotal_mb': 123,
        'swapfree_mb': 85,
    }

# Generated at 2022-06-22 23:25:16.779740
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    mock_module = Mock()
    mock_module.run_command_environ_update = {'LANG': 'C'}
    mock_module.get_bin_path.return_value = True
    mock_module.run_command.return_value = (1, "", "")

    sunos = SunOSHardware(mock_module)

    # These asserts test various parts of the SunOSHardware class
    # constructor to ensure that the proper setup is made for testing
    assert sunos.module == mock_module
    assert sunos.platform == 'SunOS'
    assert sunos.collector == None
    assert sunos.facts == {}

# Generated at 2022-06-22 23:25:19.750056
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_obj = SunOSHardware(dict())
    assert hardware_obj.facts == {'processor': [], 'processor_cores': 'NA', 'processor_count': 1}
    assert hardware_obj.platform == 'SunOS'



# Generated at 2022-06-22 23:25:25.091801
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock

    hardware = SunOSHardware(module)

    device_facts = hardware.get_device_facts()
    assert type(device_facts) == dict
    assert len(device_facts) == 1
    assert 'devices' in device_facts



# Generated at 2022-06-22 23:25:34.997275
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test populate method of class SunOSHardware"""

    m = SunOSHardware({})
    facts = m.populate()
    assert 'processor' in facts
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'mounts' in facts
    assert 'system_vendor' in facts
    assert 'product_name' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-22 23:25:40.412380
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware(dict())
    device_facts_output = hardware._get_device_facts()

    assert type(device_facts_output) == dict
    assert 'devices' in device_facts_output.keys()


# Generated at 2022-06-22 23:25:43.786184
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector._fact_class == SunOSHardware
    assert collector._platform == 'SunOS'
    assert collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:25:48.328492
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    hardware = SunOSHardware()
    hardware.module.run_command = lambda *args, **kwargs: [0, 'System Configuration: Sun Microsystems sun4v\n', '']
    hardware.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/kstat'
    hardware.module.run_command = lambda *args, **kwargs: [0, '\r\nMemory size: 3975 Megabytes\r\n', '']
    hardware.module.run_command = lambda *args, **kwargs: [0, 'total:  4016824k bytes allocated + 7532k reserved = 4024356k used, 9519648k available\r\n', '']

# Generated at 2022-06-22 23:25:56.797492
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:07.691842
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sut = SunOSHardware(module)

    # FIXME
    module.run_command_environ_update = {}

    # Note that we are mocking the methods called by SunOSHardware.populate
    module.run_command = MagicMock(side_effect=sut.get_cpu_facts)
    sut.get_memory_facts = MagicMock()
    sut.get_dmi_facts = MagicMock()
    sut.get_device_facts = MagicMock()
    sut.get_uptime_facts = MagicMock()

    sut.populate()

    sut.get_memory_facts.assert_called_once_with()
    sut.get_dmi_facts.assert_called_once_with()

# Generated at 2022-06-22 23:26:16.180415
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = {'ansible_machine': 'i86pc',
             'processor': [],
             'processor_cores': 1,
             'processor_count': 1}
    hw = SunOSHardware()
    out = hw.get_cpu_facts(facts)
    assert out['processor'] == ['Intel(r) Xeon(r) CPU E31240 @ 3.40GHz'], 'The processor list is incorrect'


if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-22 23:26:21.733875
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "Memory size: 16384 Megabytes", "")

    h = SunOSHardware(module, 0)
    facts = h.get_memory_facts()

    assert facts['memtotal_mb'] == 16384


# Generated at 2022-06-22 23:26:26.555809
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])

if __name__ == '__main__':
    # Test if constructor of SunOSHardwareCollector class is working
    test_SunOSHardwareCollector()

# Generated at 2022-06-22 23:26:30.345903
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_collector = SunOSHardwareCollector(module)
    cpu_facts = hardware_collector.collect()['ansible_processor']

    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert len(cpu_facts['processor']) > 0


# Generated at 2022-06-22 23:26:44.059795
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # set known values
    current_time = 1578291202
    boot_time = 1578291202 - 86400
    kstat_boot_time_output = "unix:0:system_misc:boot_time\t%d" % boot_time


    module = FakeAnsibleModule()

    # set up a mock for run_command, but mock it for get_uptime_facts only
    module.run_command = MockAnsibleModuleRunCommand()
    module.run_command.cmds = {'kstat -p unix:0:system_misc:boot_time': (0, kstat_boot_time_output, '')}

    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()

    # an empty dict is returned for uptime_facts if the

# Generated at 2022-06-22 23:26:55.876918
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    rc, out, err = module.run_command(["/usr/sbin/prtconf"])

    for line in out.splitlines():
        if 'Memory size' in line:
            mem_size = int(line.split()[2])
            break

    rc, out, err = module.run_command("/usr/sbin/swap -s")
    swap_total = int(out.split()[1][:-1])
    swap_free = int(out.split()[10][:-1])

    result = hardware.get_memory_facts()
    assert result['memtotal_mb'] == mem_size
    assert result['swaptotal_mb'] == (swap_total // 1024)

# Generated at 2022-06-22 23:27:03.082940
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # required for mocking methods in unit tests
    from importlib import reload

    # Importing module and mocking required items for testing
    from ansible.module_utils import basic
    from ansible.module_utils.facts import hardware

    mock_run_command = basic.AnsibleModule.run_command
    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        if cmd[0] == '/usr/bin/kstat':
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''
        else:
            return mock_run_command(self, cmd, check_rc, close_fds, executable, data, binary_data)

    basic.AnsibleModule.run_command = run_command

# Generated at 2022-06-22 23:27:04.141601
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({})
    assert hw.facts is not None

# Generated at 2022-06-22 23:27:08.688087
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_output = "System Configuration: Sun Microsystems sun4u\n"
    test_container = SunOSHardware()
    ret = test_container.get_dmi_facts()
    assert ret['system_vendor'] == "Sun Microsystems"
    assert ret['product_name'] == "sun4u"

# Generated at 2022-06-22 23:27:12.783962
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware({}, {})
    m.module = MagicMock()
    m.module.run_command = MagicMock(return_value=[0, """System Configuration: VMware, Inc. VMware Virtual Platform\n""", ''])
    out = m.get_dmi_facts()
    assert out == {'product_name': 'VMware Virtual Platform', 'system_vendor': 'VMware, Inc.'}



# Generated at 2022-06-22 23:27:24.157322
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}
    uptime_facts.update(
        _check_kstat_boot_time(boot_time=int(time.time() - 123), timeout=123,
                               rc=0, out='unix:0:system_misc:boot_time    %d\n' % (int(time.time() - 123)), err=''))
    uptime_facts.update(
        _check_kstat_boot_time(boot_time=int(time.time() - 123), timeout=123,
                               rc=0, out='unix:0:system_misc:boot_time    %d' % (int(time.time() - 123)), err=''))

# Generated at 2022-06-22 23:27:26.821107
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {
        'platform': 'SunOS',
    }

    hw = SunOSHardwareCollector(facts=facts)
    assert(isinstance(hw, SunOSHardwareCollector))

# Generated at 2022-06-22 23:27:28.923502
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware()

    assert hardware_facts.platform == 'SunOS'

# Generated at 2022-06-22 23:27:36.028763
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    processor_list = ['UltraSPARC-T1 (chipid 0, clock 1448 MHz) @ 1448 MHz', 'UltraSPARC-T1 (chipid 4, clock 1448 MHz) @ 1448 MHz']
    result = SunOSHardware.get_cpu_facts(SunOSHardware(), {'ansible_processor': processor_list, 'ansible_machine': 'sparc64'})
    assert result['processor_count'] == 2
    assert result['processor_cores'] == 72


# Generated at 2022-06-22 23:27:41.480954
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector(None, {'platform': 'SunOS'}, None)
    assert 'SunOSHardware' == hc.fact_class._platform
    assert 'SunOS' == hc.fact_class.platform
    assert 'SunOSHardwareCollector' == hc.__class__.__name__

# Generated at 2022-06-22 23:27:47.447683
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts() returns valid data or empty dict on error.
    """
    hw = SunOSHardware()
    # Test return value
    assert isinstance(hw.get_dmi_facts(), dict) or hw.get_dmi_facts() == {}, \
        'incorrect return value of get_dmi_facts'

# Generated at 2022-06-22 23:27:58.900895
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = DummyAnsibleModule()
    hardware = SunOSHardware(module=module)

    # test Solaris 9 output
    module.run_command_real = lambda *args, **kwargs: (1, '', '')

# Generated at 2022-06-22 23:28:04.287152
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts for SunOS.
    """

    hardware_instance = SunOSHardware()

    dmi_facts = hardware_instance.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'MB85531-F1'

# Generated at 2022-06-22 23:28:10.194088
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw_collector = SunOSHardwareCollector(None)
    assert hw_collector.fact_class == SunOSHardware
    assert hw_collector.platform == 'SunOS'
    assert hw_collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:28:12.617973
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Set up the class
    hardware_facts = SunOSHardware()

    # Call the method
    hardware_facts.get_memory_facts()

# Generated at 2022-06-22 23:28:18.695047
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import tempfile
    import os
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils.facts.utils import get_file_content

    c = get_collector('SunOSHardwareCollector')
    m = c.collect()
    assert 'devices' in m
    assert 'vendor' in m['devices']['sd0']
    assert 'product' in m['devices']['sd0']
    assert 'serial' in m['devices']['sd0']
    assert 'revision' in m['devices']['sd0']
    assert 'size' in m['devices']['sd0']
    assert 'hard_errors' in m['devices']['sd0']
    assert 'soft_errors' in m['devices']['sd0']

# Generated at 2022-06-22 23:28:20.380116
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # TODO
    pass

# Generated at 2022-06-22 23:28:24.140573
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x._fact_class == SunOSHardware
    assert x._platform == 'SunOS'
    assert x._required_facts == set(['platform'])

# Generated at 2022-06-22 23:28:32.847113
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys
    import os
    import pytest

    sys.path.insert(0, os.path.join(os.path.dirname(os.path.realpath(__file__)), '..'))

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    sunos_hardware_uptime_facts = SunOSHardware(dict())
    uptime_facts = sunos_hardware_uptime_facts.get_uptime_facts()

    assert isinstance(uptime_facts, dict), "uptime_facts are not dict"
    assert 'uptime_seconds' in uptime_facts, "uptime_seconds is missing from uptime_facts"
    assert isinstance(uptime_facts['uptime_seconds'], int), "uptime_seconds is not int"

# Generated at 2022-06-22 23:28:41.935580
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # test with valid output
    cmd = ['/usr/bin/kstat', '-p', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No',
           'sderr:::Size', 'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors',
           'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis',
           'sderr:::Illegal Request']
    rc = 0

# Generated at 2022-06-22 23:28:46.068284
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_instance = SunOSHardwareCollector()
    assert hardware_instance._fact_class == SunOSHardware
    assert hardware_instance._platform == 'SunOS'
    assert hardware_instance.required_facts == {'platform'}

# Generated at 2022-06-22 23:28:53.019721
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default='', required=False)
        )
    )

    c = SunOSHardware(module)
    result = c.get_cpu_facts()
    assert len(result['processor']) == 1
    assert result['processor_count'] > 0
    assert result['processor_cores'] > 0



# Generated at 2022-06-22 23:28:57.820323
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    content = b'''
Memory size: 8192 Megabytes
\n'''

    module = FakeAnsibleModule(content)

    result = SunOSHardware(module).get_memory_facts()
    assert result['memtotal_mb'] == 8192



# Generated at 2022-06-22 23:29:04.841590
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Construct a mock module
    mock_module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, 'unix:0:system_misc:boot_time 1548249689', ''))})

    uptime_facts = SunOSHardware(mock_module).get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': int(time.time() - 1548249689)}


# Generated at 2022-06-22 23:29:07.772951
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    '''
    Test function for method get_device_facts of class SunOSHardware
    '''
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module)
    assert isinstance(hardware.get_device_facts(), Mapping)


# Generated at 2022-06-22 23:29:10.205163
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.get_cpu_facts() == {}
    assert hardware.get_memory_facts() == {}

# Generated at 2022-06-22 23:29:22.265517
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts import collector

    # Inject a fake SunOSHardware class that uses a pre-defined string for
    # prtconf output, then run populate() and check the facts that the
    # method returns.
    class FakeSunOSHardware(SunOSHardware):
        def get_dmi_facts(self):
            return {'system_vendor': 'Fujitsu', 'product_name': 'PRIMERGY TX200 S6'}

        def get_cpu_facts(self):
            return {'processor': ['SPARC64-VI @ 2500MHz', 'SPARC64-VI @ 2500MHz', 'SPARC64-VI @ 2500MHz', 'SPARC64-VI @ 2500MHz'],
                    'processor_cores': 'NA', 'processor_count': 4}


# Generated at 2022-06-22 23:29:32.360972
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # test against the real 'uname -i' output (but without the trailing newline)
    module = MockModule()
    module.run_command.return_value = (0, 'i86pc', None)

    # instantiate class with mocked module
    h = SunOSHardware(module)
    facts = h.populate()

    # this is a 'regular' OS
    assert facts['os_family'] == 'Solaris'
    # and this is a SPARC system
    assert facts['ansible_machine'] != 'i86pc'
    # and the virtualization fact is present
    assert facts['virtualization_type'] == 'zone'
    # and it is a SPARC system
    assert facts['ansible_machine'] == 'sun4v'

# Generated at 2022-06-22 23:29:35.915050
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware = SunOSHardware()
    dmi_facts = sunos_hardware.get_dmi_facts()

    assert dmi_facts
    assert dmi_facts['system_vendor']
    assert dmi_facts['product_name']


# Generated at 2022-06-22 23:29:39.806507
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.get_bin_path.side_effect = lambda x: x
    module.run_command = lambda x, env_update=None: (0, CPUINFO, '')
    module.params = {}

    SunOSHardwareInstance = SunOSHardware(module)

    cpu_facts = SunOSHardwareInstance.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-22 23:29:44.390291
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardwareCollector = SunOSHardwareCollector()
    assert hardwareCollector._fact_class == SunOSHardware
    assert hardwareCollector._platform == 'SunOS'
    assert hardwareCollector.required_facts == {'platform'}


# Generated at 2022-06-22 23:29:52.692931
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = None

# Generated at 2022-06-22 23:29:59.824713
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('AnsibleModule', (), dict(run_command=lambda *args, **kw: (0, '', '')))
    facts = SunOSHardware(module).get_device_facts()
    assert 'devices' in facts
    assert 'sd0' in facts['devices']
    assert facts['devices']['sd0'].get('predictive_failure_analysis') is not None



# Generated at 2022-06-22 23:30:03.626365
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    set_module_args(dict(
        gather_subset='!all',
        gather_timeout=300,
    ))

    mock_run_command = MagicMock(return_value=(0, '', ''))
    with patch.dict(SunOSHardwareCollector.collectors, {'kstat cpu_info': mock_run_command}):
        SunOSHardwareCollector().collect()
        assert mock_run_command.call_count == 1


# Generated at 2022-06-22 23:30:07.993787
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware()
    assert hw.platform == 'SunOS'
    assert hw.ladder.__class__.__name__ == 'Ladder'
    assert hw.ladder.ladder[0] == 'all'
    assert hw.ladder.ladder[1] == 'SunOSHardware'
    assert hw.ladder.ladder[2] == 'Hardware'


# Generated at 2022-06-22 23:30:19.600335
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_test = SunOSHardware()
    # test output that has rootvg and / mounted
    test_out = """
Memory size: 512 Megabytes
/dev/zvol/dsk/rpool/swap    926222944      8388608      8388608      0%      0%     -        1       - """
    module_mock = Mock()
    module_mock.run_command.return_value = (0, test_out, '')
    mem_test.module = module_mock
    facts = mem_test.get_memory_facts()
    assert facts['memtotal_mb'] == '512'
    assert facts['swapfree_mb'] == '895'
    assert facts['swaptotal_mb'] == '905'
    assert facts['swap_reserved_mb'] == '895'

# Generated at 2022-06-22 23:30:26.318768
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock({})
    sunOS = SunOSHardware(module)
    facts = sunOS.get_device_facts()
    assert 'devices' in facts
    devices = facts['devices']
    assert devices['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-22 23:30:31.488870
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    expected_value = 'SunOSHardware'
    actual_value = SunOSHardwareCollector._fact_class.__name__
    assert (expected_value == actual_value)

    expected_value = 'SunOS'
    actual_value = SunOSHardwareCollector._platform
    assert (expected_value == actual_value)

# Generated at 2022-06-22 23:30:43.639099
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    s = SunOSHardware()


# Generated at 2022-06-22 23:30:54.417661
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test get_cpu_facts of class SunOSHardware
    """
    text = '''module: cpu_info
instance: 0
class: misc
clock_MHz	1199
chip_id	0
implementation	SPARC-T4
brand	sparcv9+vis sparcv9+vis
chip_type	SPARC T4
cpu_type	SPARC-T4

module: cpu_info
instance: 1
class: misc
clock_MHz	1199
chip_id	0
implementation	SPARC-T4
brand	sparcv9+vis sparcv9+vis
chip_type	SPARC T4
cpu_type	SPARC-T4
'''
    hardware = SunOSHardware()

# Generated at 2022-06-22 23:31:06.977917
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=False
    )

    # The following arguments are used in the Mocked class.
    params = dict()
    # Instantiate the Mocked class
    msh = MockedSunOSHardware(module, params)
    # Store the facts returned from the method populate of class SunOSHardware
    facts = msh.populate()

    # The following assert checks whether the facts returned from the method
    # populate of class SunOSHardware is not empty
    assert(facts)

    # The following assert checks the value of the key 'ansible_machine' in the
    # facts returned from the method populate of class SunOSHardware
    assert(facts['ansible_machine'] == 'i86pc')

    # The following assert checks whether the facts returned from the method
   

# Generated at 2022-06-22 23:31:13.013500
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.facts import Facts
    fake_module = Facts(module_name='ansible.module_utils.facts.hardware.sunos',
                        module_args={},
                        is_ansible_module=False)

    # Fake the kstat command

# Generated at 2022-06-22 23:31:24.437984
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Set up object
    test_obj = SunOSHardware()


# Generated at 2022-06-22 23:31:27.106883
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    a = SunOSHardware()
    return isinstance(a, SunOSHardware)

# Generated at 2022-06-22 23:31:37.366452
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    def run_command_side_effect(*args, **kwargs):
        cmd = args[0]

# Generated at 2022-06-22 23:31:46.873701
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    kstat_memory_facts = hardware.get_memory_facts()
    # We have at least memtotal_mb in hardware.get_memory_facts()
    assert 'memtotal_mb' in kstat_memory_facts.keys()
    result_kstat = module.from_json(kstat_memory_facts['memtotal_mb'])
    result_prtconf = module.from_json(get_prtconf_memory_facts(module)['memtotal_mb'])
    assert result_kstat == result_prtconf



# Generated at 2022-06-22 23:31:59.228675
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Get facts for device."""
    import os
    import shutil

# Generated at 2022-06-22 23:32:12.925782
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    prtconf_output = 'Memory size: 64 Megabytes'
    swap_s_output = 'Total: 4194880k bytes allocated + 716472k reserved = 4911352k used, 1k available'

    mock_module = MagicMock()
    mock_module.run_command.side_effect = [(0, prtconf_output, ''), (0, swap_s_output, '')]

    sunos_hw = SunOSHardware(module=mock_module)
    memory_facts = sunos_hw.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 64
    assert memory_facts['swaptotal_mb'] == 4911
    assert memory_facts['swap_reserved_mb'] == 716
    assert memory_facts['swap_allocated_mb'] == 4195

# Generated at 2022-06-22 23:32:19.349237
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_class = SunOSHardwareCollector()
    assert hardware_class.platform == 'SunOS'
    assert hardware_class.required_facts == {'platform'}
    assert hardware_class.__class__.__name__ == 'SunOSHardwareCollector'
    assert hardware_class.__dict__ == {'_fact_class': 'SunOSHardware', '_platform': 'SunOS'}

# Generated at 2022-06-22 23:32:22.475381
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.platform == 'SunOS'
    assert SunOSHardwareCollector._fact_class == SunOSHardware


# Generated at 2022-06-22 23:32:24.855734
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    # Constructor test without argument
    hardware_mock = SunOSHardware()

    # Asserts
    assert hardware_mock

# Generated at 2022-06-22 23:32:31.686451
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    module.run_command = mock.Mock(return_value=(0, 'Memory size: 8192 Megabytes', None))
    hardware = SunOSHardware(module=module)
    facts = hardware.get_memory_facts()

    assert facts == {'memtotal_mb': 8192}



# Generated at 2022-06-22 23:32:35.609290
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw_class = SunOSHardwareCollector()
    assert hw_class._fact_class == SunOSHardware
    assert hw_class._platform == 'SunOS'
    assert hw_class.required_facts == set(['platform'])

# Generated at 2022-06-22 23:32:40.810178
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    test_hw = SunOSHardware(module)

    memory_facts_mock = {'memtotal_mb': 8192}
    module.run_command.return_value = (0, 'Memory size: 8192 Megabytes', '')

    memory_facts = test_hw.get_memory_facts()

    assert memory_facts == memory_facts_mock
    

# Generated at 2022-06-22 23:32:50.338041
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = SunOSHardware(module=module)

    hardware_facts = hardware.populate()

    assert hardware_facts['processor'][0] == 'SPARC64-VII'
    assert hardware_facts['memtotal_mb'] == 64
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0


# Get the facts from this system and test the populate method of
# SunOSHardware class.

# Generated at 2022-06-22 23:32:52.152708
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({})
    assert hw.platform == 'SunOS'



# Generated at 2022-06-22 23:32:58.275290
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = SunOSHardware({'platform': 'SunOS'})
    m.module = MagicMock()
    m.module.run_command = MagicMock(return_value=(0, "Memory size: 16384 Megabytes", ''))
    assert "16384" in m.get_memory_facts()['memtotal_mb']



# Generated at 2022-06-22 23:33:00.184593
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    uptime_facts = {}
    uptime_facts['uptime_seconds'] = SunOSHardware.get_uptime_facts(True)

    return uptime_facts

# Generated at 2022-06-22 23:33:07.883513
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeANSIModule()
    s = SunOSHardware(module)
    s.get_device_facts()
    assert module.run_command.call_count == 1
    assert module.run_command.call_args[0][0] == ['/usr/bin/kstat', '-p', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size', 'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request']


# Generated at 2022-06-22 23:33:20.695227
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Test get_uptime_facts() with mocked results
    uptime_facts = {'uptime_seconds': 100}
    class MySunOSHardware(SunOSHardware):
        def get_uptime_facts(self):
            return uptime_facts

    hardware = MySunOSHardware()

    # Test case when get_uptime_facts() returns correct 'uptime_seconds'
    facts = hardware.populate()
    assert 'uptime_seconds' in facts['ansible_facts']['ansible_system']
    assert (facts['ansible_facts']['ansible_system']['uptime_seconds'] == uptime_facts['uptime_seconds'])

    # Test case when get_uptime_facts() returns incorrect 'uptime_seconds'
    uptime_facts['uptime_seconds'] = 'some_string'

# Generated at 2022-06-22 23:33:32.028225
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # create a mock module
    module = AnsibleModule(argument_spec={})

    # create instance of SunOSHardware using mock module
    sunos_hardware = SunOSHardware(module)
    hardware_facts = sunos_hardware.populate()

    # validate required cpu facts
    assert hardware_facts['processor']
    assert hardware_facts['processor_count']
    assert hardware_facts['processor_cores']

    # validate required memory facts
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swap_allocated_mb']
    assert hardware_facts['swap_reserved_mb']



# Generated at 2022-06-22 23:33:41.643074
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    class get_file_content_factory:
        class get_file_content_mock:
            def __init__(self, path):
                self.path = path

            def get_file_content(self, *args):
                return 'test_data'

        def __call__(self, *args):
            return self.get_file_content_mock(*args)

    class get_mount_size_factory:
        class get_mount_size_mock:
            def __init__(self, mount):
                self.mount = mount

            def get_mount_size(self):
                return {
                    'total_size_bytes': 0,
                    'free_size_bytes': 0,
                }


# Generated at 2022-06-22 23:33:46.397791
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    '''SunOSHardware get_memory_facts()'''
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    hardware.get_memory_facts()


# Generated at 2022-06-22 23:33:52.810786
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Test with valid platform value
    myhw = SunOSHardware({'platform': 'SunOS'})
    assert myhw.platform == 'SunOS', "Platform should be SunOS, not %s" % myhw.platform

    # Test with invalid platform value
    myhw = SunOSHardware({'platform': 'AIX'})
    assert myhw.platform == 'AIX', "Platform should be AIX, not %s" % myhw.platform

# Generated at 2022-06-22 23:34:04.611730
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    '''
        Tests to ensure that method get_uptime_facts of class SunOSHardware
        returns expected output.
    '''
    class FakeModule(object):
        class FakeRunCommandResult(object):
            stdout = 'unix:0:system_misc:boot_time    1548249689'
            stderr = ''
            rc = 0

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return self.FakeRunCommandResult()

    fake_module = FakeModule()
    uptime_facts = SunOSHardware.get_uptime_facts(fake_module)
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-22 23:34:08.502371
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: None

    HardwareCollector(module)

# Generated at 2022-06-22 23:34:19.351174
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    test_SunOSHardware = SunOSHardware(dict(), '')


# Generated at 2022-06-22 23:34:25.946184
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # setup
    class MockModule(object):
        def run_command(self, command):
            return 0, '', ''

    mock_module = MockModule()

    class MockSunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = mock_module

    sunos_hardware = MockSunOSHardware()

    # test
    disk = sunos_hardware.get_device_facts()['devices']['sd0']
    assert disk['product'] == 'VBOX HARDDISK'
    assert disk['revision'] == '1.0'
    assert disk['serial'] == 'VB0ad2ec4d-074a'
    assert disk['size'] == '50.00 GB'
    assert disk['vendor'] == 'ATA'

# Generated at 2022-06-22 23:34:27.156186
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:34:28.877519
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    assert SunOSHardware(dict(ansible_facts=dict(ansible_platform='SunOS'))).populate()

# Generated at 2022-06-22 23:34:33.845854
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    hardware_sunos = SunOSHardware()
    cpu_facts = hardware_sunos.get_cpu_facts()

    module.exit_json(ansible_facts={'ansible_processor': cpu_facts['processor']})



# Generated at 2022-06-22 23:34:39.328126
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-22 23:34:48.601018
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }


# Generated at 2022-06-22 23:34:51.776435
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts_object = SunOSHardware()
    test_cpu_facts_output = facts_object.get_cpu_facts()
    assert test_cpu_facts_output['processor_cores'] == 'NA'
    assert test_cpu_facts_output['processor_count'] == 1


# Generated at 2022-06-22 23:34:53.568140
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # This functionality is currently only supported on SunOS
    # so this test is only performed if running on SunOS.
    if 'SunOS' in platform.system():
        hardware = SunOSHardware()

        hardware.get_dmi_facts()
        assert True
    else:
        assert True

# Generated at 2022-06-22 23:34:59.581631
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create instance of class SunOSHardware
    sunoshardware = SunOSHardware(dict())

    # Mock run_command function
    def run_command(self, command):
        return 0, """\
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
BIOS Configuration:   Phoenix Technologies LTD 6.00
  Product Name: VMware Virtual Platform
  Version 2.10
BIOS Revision: 6.00
BIOS Vendor:   Phoenix Technologies LTD
BIOS Version:  6.00
""", ""

    sunoshardware.run_command = run_command.__get__(sunoshardware, SunOSHardware)
    # Collect DMI facts
    dmi_facts = sunoshardware.get_dmi_facts()
    # Assert dmi_facts is dictionary