

# Generated at 2022-06-22 23:25:00.855920
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw_collector = SunOSHardwareCollector(None)

    assert hw_collector._fact_class == SunOSHardware
    assert hw_collector._platform == 'SunOS'
    assert hw_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:25:11.672569
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import pytest
    from ansible.module_utils.facts.collector.sunos import SunOSHardware

    def fake_time():
        return 1548249689.0

    test_uptime_facts = {'uptime_seconds': int(time.time() - 1548249689)}

    class AnsibleModule:
        def __init__(self):
            self.run_command_result = 123
            self.run_command_stdout = b'unix:0:system_misc:boot_time    1548249689'

        def run_command(self, cmd):
            return self.run_command_result, self.run_command_stdout, ''

    ansible_module = AnsibleModule()

    sunos_hardware = SunOSHardware(ansible_module)


# Generated at 2022-06-22 23:25:19.849621
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import ansible_collections.notstdlib.moveitallout.tests.unit.utils.platform_utils as platform_utils
    from ansible_collections.notstdlib.moveitallout.plugins.facts.hardware.sunos import SunOSHardware

    utils = platform_utils.PlatformUtils('SunOS', 'SunOS')

    hardware = SunOSHardware()
    hardware.module = utils.get_module_mock()

    hardware.module.run_command = utils.get_run_command_mock(0, 'unix:0:system_misc:boot_time    1548249689')
    assert hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1548249689)}

    hardware.module.run_command = utils.get_run_command_

# Generated at 2022-06-22 23:25:27.523460
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    rc, out, err = module.run_command('/usr/bin/kstat cpu_info')
    expected_rc = 0
    expected_out = out
    expected_err = err
    assert hardware_obj.populate()['processor']
    assert rc == expected_rc
    assert out == expected_out
    assert err == expected_err

# Generated at 2022-06-22 23:25:37.023300
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    input_cmd_output = """module: cpu_info
instance: 0
class: misc
clock_MHz	669
comment	AMD EPYC 7551 32-Core Processor
cpu_fru	00000000000000000000000000000000
cpu_type	x64
current_clock_Hz	669468966
device_ID	0000000000013f00
family	23
fpu_type	sse
implementation	x86
pg_id	0
brand	AMD EPYC 7551 32-Core Processor
chip_id	0
core_id	0
cpu_faulting	true
device_ID	0
instructions_per_cycle	1
pg_id	0
pg_new	false
processor_id	0
sensitive_inst	true
"""

    output

# Generated at 2022-06-22 23:25:40.079851
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    a = SunOSHardwareCollector(None)
    assert a.collect() is not None

# Generated at 2022-06-22 23:25:50.511902
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    collector = SunOSHardwareCollector()

    # Create a list of fake 'device_facts'
    device_facts = {
        "Hard Errors": "0",
        "Illegal Request": "0",
        "Media Error": "2",
        "Product": "VirtualBox HARDDISK",
        "Predictive Failure Analysis": "0",
        "Revision": "1.0",
        "Serial No": "VBOXHARDDISK   VB8f6a3e6d-c948",
        "Size": "107374182400",
        "Soft Errors": "0",
        "Transport Errors": "0",
        "Vendor": "ATA"
    }

    # Create a fake kstat output
    fake_out = ""

# Generated at 2022-06-22 23:25:55.132217
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:26:07.614123
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # This test is only run on the SunOSPlatform platform
    # and is skipped on all others
    import platform
    if platform.system() != 'SunOS':
        return

    # Create the instance to test
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)

    # Mock the 'run_command_environ_update' attribute of the instance
    hw.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C'}

    # Run the populate method
    try:
        hw.populate()
    except Exception as exc:
        assert(False)

# Generated at 2022-06-22 23:26:20.324909
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:26:29.158946
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test case for unit testing method get_dmi_facts of class SunOSHardware.
    """
    class TestSunOSHardware:
        """
        Python class test_SunOSHardware to test method get_dmi_facts
        """
        def __init__(self, module):
            """
            TestSunOSHardware constructor
            """
            self.module = module

        def run_command(self, cmd):
            """
            Method returns mocked command output
            """

# Generated at 2022-06-22 23:26:33.388422
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector._platform == SunOSHardwareCollector._platform, 'platform not assigned correctly'
    assert collector._fact_class == SunOSHardware, 'fact class not assigned correctly'
    assert SunOSHardwareCollector.required_facts == set(['platform']), 'required_facts not assigned correctly'

# Generated at 2022-06-22 23:26:39.537108
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    result = hardware.populate()

    assert result['system_vendor'] == 'QEMU'
    assert result['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'



# Generated at 2022-06-22 23:26:43.476282
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector(dict())
    assert hardware_collector.collect() is not None
    assert hardware_collector.facts['processor_count'] >= 1

# Generated at 2022-06-22 23:26:55.842319
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware()

    devices = {}
    devices['devices'] = {}
    device_stub = {'product': 'product',
                   'revision': 'revision',
                   'serial': 'serial',
                   'size': 'size',
                   'vendor': 'vendor',
                   'hard_errors': 'hard_errors',
                   'soft_errors': 'soft_errors',
                   'transport_errors': 'transport_errors',
                   'media_errors': 'media_errors',
                   'predictive_failure_analysis': 'predictive_failure_analysis',
                   'illegal_request': 'illegal_request'}
    devices['devices']['sd0'] = device_stub
    devices['devices']['sd1'] = device_stub

# Generated at 2022-06-22 23:27:08.190172
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ModuleDouble:
        def get_bin_path(self, exe, *args, **kwargs):
            return exe

        def run_command(self, args):
            # Return a single line with the vendor and product name
            vendor = "Manufacturer"
            product = "Host"
            return (0, "%s %s" % (vendor, product), "")

    class TestCase:
        def __init__(self, module):
            self.module = module

    class TestFactsModule(ModuleDouble):
        def __init__(self, test_case):
            self.test_case = test_case

        def fail_json(self, *args, **kwargs):
            self.test_case.failed = True
            self.test_case.fail_json_args = args

# Generated at 2022-06-22 23:27:11.849542
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule({}, supports_check_mode=False)
    SunOSHardware(module)


# Generated at 2022-06-22 23:27:23.863077
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:34.530528
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock(**{'run_command.return_value': (0, '0\nchip_id 0\nimplementation sun4\nbrand sun4\nclock_MHz 0\n\n0\nchip_id 1\nimplementation sun4\nbrand sun4\nclock_MHz 0\n\n0\nchip_id 2\nimplementation sun4\nbrand sun4\nclock_MHz 0\n\n0\nchip_id 3\nimplementation sun4\nbrand sun4\nclock_MHz 0\n\n', '')})
    sunoshardware = SunOSHardware(module)

# Generated at 2022-06-22 23:27:36.920344
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_hc = SunOSHardwareCollector.factory()
    assert isinstance(sun_hc, SunOSHardwareCollector)

# Generated at 2022-06-22 23:27:41.534787
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}
    uptime_facts['uptime_seconds'] = int(time.time())
    uptime_facts['uptime'] = "1 second"
    assert uptime_facts == SunOSHardware().get_uptime_facts()

# Generated at 2022-06-22 23:27:49.138398
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockAnsibleModule()
    hardware = SunOSHardware(module=module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T5 (chipid 0, clock 2500 MHz) @ 2500MHz', 'SPARC T5 (chipid 1, clock 2500 MHz) @ 2500MHz']
    assert hardware.facts['processor_cores'] == 20
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] == 32768
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-22 23:28:00.206257
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test that SunOSHardware.get_dmi_facts() returns system information
    in dict form.
    """
    class FakeHardwareModule:
        def __init__(self):
            self.run_command_mock = self._mock_run_command()

        def _mock_run_command(self):
            class RunCommandMock:
                def __init__(self):
                    self.command_to_return_value = {
                        "/usr/bin/uname -i": ("i86pc\n", None, 0),
                        "/usr/platform/i86pc/sbin/prtdiag": (
                            "System Configuration: Sun Microsystems sun4u\n", None, 0)
                    }

                def __call__(self, command, *args, **kwargs):
                    return self.command_to

# Generated at 2022-06-22 23:28:13.815997
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeModule()
    if hasattr(module, '_system_version_info'):
        del module._system_version_info
    hardware = SunOSHardware(module=module)

    if hasattr(hardware, 'dot_dmi'):
        del hardware.dot_dmi
    if hasattr(hardware, '_device_facts'):
        del hardware._device_facts


# Generated at 2022-06-22 23:28:26.561715
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_class = SunOSHardware(None)

    # return prtdiag output if prtdiag wrapper is in /usr/sbin
    test_class.module = MockModule()
    test_class.module.run_command = Mock(return_value=(0, 'System Configuration: Sun Microsystems sun4u', ''))
    facts = test_class.get_dmi_facts()
    assert facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

    # return prtdiag output if prtdiag wrapper is absent from /usr/sbin but real prtdiag is found
    test_class.module = MockModule()
    test_class.module.run_command = Mock(return_value=(0, 'System Configuration: Sun Microsystems sun4u', ''))


# Generated at 2022-06-22 23:28:29.077451
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hd = SunOSHardware()
    device_facts = hd.get_device_facts()
    assert device_facts == {'devices': {}}

# Generated at 2022-06-22 23:28:39.043152
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # test data
    # output of memory related command
    free = '12345'
    used = '67890'
    swap_total = '80000'
    swap_used = '45678'
    swap_free = '12345'
    prtconf_out = 'Memory size: 12345 Megabytes'

    # captured data
    prtconf_captured_stdout = '''Memory size: {0} Megabytes'''.format(free)
    prtconf_captured_stdout_error = '''Memory size: {0} Megabytes\n{0}'''.format(free)
    swap_captured_stdout = '''swapfile: /tmp:    {0} blocks    {1} blocks    {2} blocks'''.format(swap_total, swap_used, swap_free)

    # command outputs

# Generated at 2022-06-22 23:28:51.612615
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_device_facts = {}
    test_device_facts['devices'] = {
        'sd0': {
            'hard_errors': '0',
            'media_errors': '0',
            'predictive_failure_analysis': '0',
            'product': 'VBOX HARDDISK   ',
            'revision': '1.0',
            'serial': 'VB0ad2ec4d-074a',
            'size': '52.01 GB',
            'soft_errors': '0',
            'transport_errors': '0',
            'vendor': 'ATA',
            'illegal_request': '0'}
    }
    sdh = SunOSHardware()
    device_facts = sdh.get_device_facts()
    # get_device_facts() can return an empty dictionary


# Generated at 2022-06-22 23:29:04.243909
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    facts = {}
    hardware = SunOSHardware(facts)
    expected_disks = {'sderr:::Predictive Failure Analysis': '0', 'sderr:::Hard Errors': '0', 'sderr:::Product': 'VBOX HARDDISK', 'sderr:::Size': '53687091200', 'sderr:::Serial No': 'VB0ad2ec4d-074a', 'sderr:::Vendor': 'ATA', 'sderr:::Illegal Request': '6', 'sderr:::Media Error': '0', 'sderr:::Revision': '1.0', 'sderr:::Soft Errors': '0', 'sderr:::Transport Errors': '0'}

# Generated at 2022-06-22 23:29:09.151718
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Returns a dict containing all the hardware information
    """

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if platform.system() != 'SunOS':
        module.fail_json(msg='Tests must be run on a Solaris host')

    sunoshardware = SunOSHardware(module)
    facts_dict = sunoshardware.populate()
    module.exit_json(ansible_facts=facts_dict)



# Generated at 2022-06-22 23:29:16.208822
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    module.params = dict()

    hardware = SunOSHardware(module)
    prtconf_facts = dict()
    prtconf_facts['memtotal_mb'] = 8192
    swap_facts = dict()
    swap_facts['swap_allocated_mb'] = 128
    swap_facts['swap_reserved_mb'] = 256
    swap_facts['swaptotal_mb'] = 512
    swap_facts['swapfree_mb'] = 256
    expected_facts = dict()
    expected_facts.update(prtconf_facts)
    expected_facts.update(swap_facts)
    assert hardware.get_memory_facts() == expected_facts


# Generated at 2022-06-22 23:29:28.895418
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:29:38.141903
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """Test SunOSHardware.get_uptime_facts()"""
    import os
    import sys
    import test.mock as mock
    from ansible.module_utils.facts import facts

    mock_module = mock.MagicMock()
    mock_module.run_command = mock.Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    mock_module.get_bin_path = mock.Mock(return_value=None)

    # We have to mock the open() method to have a predictable result
    class TestSunOSHardware(SunOSHardware):
        def open(self, fname):
            return open(os.path.join(os.path.dirname(sys.modules[__name__].__file__), 'files', fname), 'r')

# Generated at 2022-06-22 23:29:45.069882
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    sunos_hardware = SunOSHardware(module)

    # mock runs of commands on SunOS
    module.run_command.return_value = (0, 'Memory size: 16384 Megabytes', '')

    memory_facts = sunos_hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 16384



# Generated at 2022-06-22 23:29:47.701162
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeModule()
    hardware = SunOSHardware(module)

    assert hardware.module == module
    assert hardware.platform == 'SunOS'



# Generated at 2022-06-22 23:29:49.228585
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Create an instance of SunOSHardwareCollector
    """
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:30:02.030573
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-22 23:30:04.085904
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    my_hardware = SunOSHardware()
    fact_data = my_hardware.populate()
    assert fact_data['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-22 23:30:07.496892
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'Memory size: 32768 Megabytes', ''))
    sunos_hw = SunOSHardware(module)
    result = sunos_hw.get_memory_facts()
    assert result['memtotal_mb'] == 32768

# Generated at 2022-06-22 23:30:10.148425
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-22 23:30:18.686693
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # fixtures:
    class ModuleStub:
        def run_command_environ_update(self):
            return {'LANG': locale, 'LC_ALL': locale, 'LC_NUMERIC': locale}
    module = ModuleStub()

    class HardwareStub:
        pass
    hw = HardwareStub()

    # setup:
    hardware = SunOSHardware(module)
    hardware.distribution = 'SunOS'

    # execute:
    hardware.populate()

    # assert:
    for fact in hardware.data:
        getattr(hw, fact)

# Generated at 2022-06-22 23:30:21.307344
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = SunOSHardware(dict(), None)
    facts.populate()

    assert facts is not None

# Generated at 2022-06-22 23:30:24.323965
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    collector = SunOSHardwareCollector([], {})
    assert collector._fact_class == SunOSHardware

# Generated at 2022-06-22 23:30:36.410940
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = DummyAnsibleModule()
    hardware = SunOSHardware(module)

    cpu_facts_expect = {'processor': ['SUNW,Sun-Blade-2500 @ 1450MHz'],
                        'processor_cores': 1,
                        'processor_count': 1}

    memory_facts_expect = {'memtotal_mb': 4096,
                           'swapfree_mb': 1023,
                           'swaptotal_mb': 1023,
                           'swap_allocated_mb': 0,
                           'swap_reserved_mb': 0}

    dmi_facts_expect = {'system_vendor': 'Sun Microsystems',
                        'product_name': 'Sun Fire V250'}


# Generated at 2022-06-22 23:30:39.551728
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hw = SunOSHardware(dict())
    assert sunos_hw.platform == 'SunOS'


# Generated at 2022-06-22 23:30:44.204683
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_collector = SunOSHardwareCollector()
    hardware = hardware_collector.collect(
        dict(platform='SunOS', ansible_kernel='SunOS')
    )
    assert hardware.platform == 'SunOS'
    assert set(hardware.required_facts) == {'platform'}

# Generated at 2022-06-22 23:30:54.845555
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:31:07.410590
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:31:08.294323
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    h = SunOSHardware('module')
    assert h

# Generated at 2022-06-22 23:31:20.978757
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    sunoshardware = SunOSHardware(module)

    # Assert correct class name for hardware facts
    assert sunoshardware.__class__.__name__ == 'SunOSHardware'

    # Assert that populate function populates cpu facts
    assert 'cpu' in sunoshardware.populate()
    assert 'processor' in sunoshardware.populate()['cpu']

    # Assert that populate function populates memory facts
    assert 'memory' in sunoshardware.populate()
    assert 'memtotal_mb' in sunoshardware.populate()['memory']

    # Assert that populate function populates dmi facts
    assert 'dmi' in sunoshardware.populate()

# Generated at 2022-06-22 23:31:28.478838
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    #############################################################
    #
    # Setup:
    #
    #############################################################
    from ansible.module_utils.facts.sunos.sunos import SunOSHardware

    module = MockModule()
    hardware = SunOSHardware(module)
    hardware.collect()

    #############################################################
    #
    # Test Cases:
    #
    #############################################################

    # Test case where the cpu facts from kstat are correct.
    # The cpucount from the kstat command should be assigned to
    # the cpu_count fact and the processor_cores fact should be
    # set to the number of cpu chips.

    # Populate mock data

# Generated at 2022-06-22 23:31:38.072584
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_info = []

    hardware_info.append('')

    hardware_info.append('module:             cpu_info')
    hardware_info.append('chip_id:            0')
    hardware_info.append('core_id:            0')
    hardware_info.append('clog_id:            0')
    hardware_info.append('strand_id:          0')
    hardware_info.append('state:              on-line')
    hardware_info.append('chip#:              0')
    hardware_info.append('core#:              0')
    hardware_info.append('clog#:              0')
    hardware_info.append('strand#:            0')
    hardware_info.append('board_id:           0000:0000:00')

# Generated at 2022-06-22 23:31:46.770277
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts import ansible_facts
    from ansible.module_utils.facts.hardware import SunOSHardware
    facts = ansible_facts()
    if facts['ansible_machine'] == 'i86pc':
        dmi_facts = SunOSHardware().get_dmi_facts()
        assert dmi_facts
    else:
        dmi_facts = SunOSHardware().get_dmi_facts()
        assert dmi_facts
        assert dmi_facts['system_vendor']
        assert dmi_facts['product_name']


# Generated at 2022-06-22 23:31:56.660144
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Run a test on SunOSHardware class get_cpu_facts method
    """
    # Populate facts
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Add values to facts
    setattr(module, 'ansible_facts', {'ansible_machine': 'i86pc'})

    # Create the class object
    hardware = SunOSHardware(module)
    # Run the get_cpu_facts method
    cpu_facts = hardware.get_cpu_facts()

    # Test the results
    assert 'processor' in cpu_facts

# Generated at 2022-06-22 23:32:05.185810
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:17.890209
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # Case 1: prtconf returns valid data

    # FIXME: need to mock Popen object
    prtconf_output = """
Memory size: 4 GB
"""

    class MockModule:
        def run_command(self, *args, **kwargs):
            return (0, prtconf_output, None)

    hardware_object = SunOSHardware(module=MockModule())
    hardware_object.module = MockModule()
    memory_facts = hardware_object.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096

    # Case 2: prtconf returns invalid data

    # FIXME: need to mock Popen object
    prtconf_output = """
Memory size: 16 GB
"""

    class MockModule:
        def run_command(self, *args, **kwargs):
            return

# Generated at 2022-06-22 23:32:28.943060
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Setup an instance of SunOSHardware for testing
    module = AnsibleModule(argument_spec=dict())
    Hardware = SunOSHardware(module)

    # run the populate method, it should return a dict
    result = Hardware.populate()

    # Test that the module is setup correctly
    assert isinstance(result, dict)

    # Test for correct values
    assert len(result['processor']) >= 1
    assert result['processor_count'] is None or result['processor_count'] >= 1
    assert result['processor_cores'] is None or result['processor_cores'] >= 1
    assert result['processor_threads_per_core'] is None or result['processor_threads_per_core'] >= 1
    assert result['processor_vcpus'] is None or result['processor_vcpus'] >= 1

# Generated at 2022-06-22 23:32:40.219315
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

# Generated at 2022-06-22 23:32:53.543453
# Unit test for method get_uptime_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:04.453448
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware({'platform': 'SunOS'})

    # Mock output from Solaris 8 prtdiag
    prtdiag_8 = (
        "System Configuration: Sun Microsystems sun4u\n"
        "System clock frequency:      48.0000 MHz\n"
    )

    # Mock output from Solaris 10 prtdiag
    prtdiag_10 = (
        "System Configuration: Sun Microsystems sun4u\n"
        "System clock frequency: 33 MHz\n"
        "Memory size: 1024 Megabytes\n"
    )

    # Mock output from Solaris 11 prtdiag

# Generated at 2022-06-22 23:33:15.025190
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware().get_memory_facts()

    assert 'memtotal_mb' in mem_facts
    assert mem_facts['memtotal_mb'] >= 0

    assert 'swapfree_mb' in mem_facts
    assert mem_facts['swapfree_mb'] >= 0

    assert 'swaptotal_mb' in mem_facts
    assert mem_facts['swaptotal_mb'] >= 0

    assert 'swap_allocated_mb' in mem_facts
    assert mem_facts['swap_allocated_mb'] >= 0

    assert 'swap_reserved_mb' in mem_facts
    assert mem_facts['swap_reserved_mb'] >= 0

# Generated at 2022-06-22 23:33:26.868297
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule:
        def run_command(self, arg):
            return 0, """module: cpu_info
instance: 0
class: misc
chip_id   0
clock_MHz   1330
implementation   sparcv9
brand   sun4u
module: cpu_info
instance: 1
class: misc
chip_id   0
clock_MHz   1330
implementation   sparcv9
brand   sun4u""", ""
        def get_bin_path(self, arg, opt_dirs=None):
            return "/usr/sbin/prtconf"
        def run_command_environ_update(self):
            return 0, '', ''

    hw = SunOSHardware(MockModule())
    actual_facts_cpu = hw.get_cpu_facts()

# Generated at 2022-06-22 23:33:36.471870
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fake_module = type('fake_module', (object,), {'fail_json': None, 'run_command': None})()
    fake_module.run_command = lambda *args: (0, 'sderr:0:sd0,err:Hard Errors     0', '')
    hardware_collector = SunOSHardwareCollector(fake_module)
    hardware = hardware_collector.collect(['processor', 'processor_cores', 'processor_count'], cached_facts={'ansible_machine': 'i86pc'})
    assert hardware.processor[0].startswith("Intel") == True

# Generated at 2022-06-22 23:33:44.018048
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    # Create a SunOSHardware object with the module
    sunos_hw_obj = SunOSHardware(module)
    # Expected output of get_memory_facts()
    mem_size = int(bytes_to_human(float(sunos_hw_obj._get_memory_size_bytes())))
    expected_output = {
        'memtotal_mb': mem_size,
        'swap_reserved_mb': 0,
        'swapfree_mb': 0,
        'swap_allocated_mb': 0,
        'swaptotal_mb': 0
    }
    # Test method get_memory_facts of class SunOSHardware()
    assert expected_output == sunos_hw_obj.get_memory_facts()


# Generated at 2022-06-22 23:33:46.505426
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:33:56.036026
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Requires kstat output file as input.
    :return:
    """
    # Get data from file with kstat -p output
    s = open('/var/local/kstat-output.txt', 'r').read()
    data = {'module': {'run_command_environ_update': {'LANG': 'C', 'LC_NUMERIC': 'C', 'LC_ALL': 'C'}}}
    hardware = SunOSHardware(data, s)

    # create expected output:

# Generated at 2022-06-22 23:34:08.395261
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Run prtconf with the following output
    prtconf_out = \
'''
System Configuration: Sun Microsystems  unknown
Memory size: 4096 Megabytes
'''

    # Run swap -s with the following output
    swap_s_out = \
'''
total: 512000k bytes allocated + 0k reserved = 512000k used, 385944k available
'''
    data = SunOSHardware().get_memory_facts(prtconf_out=prtconf_out, swap_s_output=swap_s_out)

    assert data['memtotal_mb'] == 4096
    assert data['swaptotal_mb'] == 512
    assert data['swapfree_mb'] == 384
    assert data['swap_allocated_mb'] == 512
    assert data['swap_reserved_mb'] == 0

# Generated at 2022-06-22 23:34:12.417762
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = FakeModule()
    s = SunOSHardwareCollector(module)
    assert s._platform == 'SunOS'
    assert s._fact_class == SunOSHardware
    assert set(s.required_facts) == set(['platform'])


# Generated at 2022-06-22 23:34:13.107267
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    pass

# Generated at 2022-06-22 23:34:20.931219
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOS_hardware_obj = SunOSHardware({})
    # Pass empty content to get_file_content
    fstab = []
    fstab = "\n".join(fstab)
    SunOS_hardware_obj.get_file_content = lambda _: fstab
    dmi_facts = SunOS_hardware_obj.get_dmi_facts()
    assert dmi_facts == {}
    # Pass content to get_file_content
    fstab = ["System Configuration: Oracle Corporation SUN FIRE T2000"]
    fstab = "\n".join(fstab)
    SunOS_hardware_obj.get_file_content = lambda _: fstab
    dmi_facts = SunOS_hardware_obj.get_dmi_facts()
    assert dmi_facts['system_vendor'] == "Oracle Corporation"


# Generated at 2022-06-22 23:34:31.192617
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    hardware_facts = dict(platform='Solaris', ansible_machine="i86pc")
    sunos_obj = SunOSHardware(None, hardware_facts, None)

    assert sunos_obj.get_cpu_facts()['processor'] == ['Intel(r) Core(TM) i7-6650U CPU @ 2.20GHz']
    assert sunos_obj.get_cpu_facts()['processor_count'] == 2
    assert sunos_obj.get_cpu_facts()['processor_cores'] == 'NA'
    assert sunos_obj.get_memory_facts()['memtotal_mb'] == 8192
    assert sunos_obj.get_dmi_facts()['system_vendor'] == 'Oracle Corporation'
    assert sunos_obj.get_dmi_facts()['product_name'] == 'VirtualBox'

# Generated at 2022-06-22 23:34:39.811102
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    # Instantiate class so we can call get_memory_facts method
    _hw = SunOSHardware(module=module)
    facts = _hw.get_memory_facts()
    # Assert that the required keys for memory facts are present
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts

# Generated at 2022-06-22 23:34:48.869152
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class FakeModule(object):
        def run_command(self, cmd):
            self.cmd = cmd
            if cmd == '/usr/bin/uname -i':
                return 0, 'sun4u', ''
            elif cmd == '/usr/platform/sun4u/sbin/prtdiag':
                return 0, "\n".join(['System Configuration: Sun Microsystems sun4v',
                                     'System Configuration: Oracle Corporation Sun Fire X4140',
                                     'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)',
                                     'System Configuration: VMware, Inc. VMware Virtual Platform',
                                     'System Configuration: QEMU QEMU Virtual CPU version 0.12.5',
                                     'System Configuration: Sun Microsystems sun4u']), ''

# Generated at 2022-06-22 23:34:51.490682
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()

    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:34:57.350296
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module_mock = type('module', (object,), {})()