

# Generated at 2022-06-22 23:25:05.779735
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule():
        def run_command(self):
            current_time = int(time.time())
            return 0, 'unix:0:system_misc:boot_time    %s' % current_time, ''

    fake_module = FakeModule()
    sunos_hw = SunOSHardware(fake_module)
    uptime_facts = sunos_hw.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] < 5

# Generated at 2022-06-22 23:25:06.904326
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:25:17.543128
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    def get_file_content(path):
        return """
/dev/dsk/c0d0s0         /     ufs     rw,intr    1       2
/devices                /devices        devfs   rw      0       0
/proc                   /proc       proc    rw      0       0
mnttab                  /etc/mnttab        mntfs   ro      0       0
swap                    /etc/svc/volatile  tmpfs   xattr   0       0
swap                    -       tmpfs   xattr   0       0
"""

    def get_mount_size(path):
        return {'size_total': 1342177280, 'size_available': 943718400}


# Generated at 2022-06-22 23:25:24.810824
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos = SunOSHardware()
    # Example output provided by Michael Krelin

# Generated at 2022-06-22 23:25:35.421472
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test if object is constructed or not
    if SunOSHardwareCollector():
        pass
    else:
        raise AssertionError("'SunOSHardwareCollector()' object is not constructed")
    # Test if object is instance of class HardwareCollector or not
    if isinstance(SunOSHardwareCollector(), HardwareCollector):
        pass
    else:
        raise AssertionError("'SunOSHardwareCollector()' object is not instance of class HardwareCollector")
    # Test if _fact_class attribute is set to SunOSHardware or not
    if SunOSHardwareCollector()._fact_class == SunOSHardware:
        pass
    else:
        raise AssertionError("'_fact_class' attribute of 'SunOSHardwareCollector()' object is not set to SunOSHardware")
    # Test if _platform attribute is set to SunOS

# Generated at 2022-06-22 23:25:43.785629
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_get_memory_facts = SunOSHardware()
    memory_facts = test_get_memory_facts.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts

# Generated at 2022-06-22 23:25:53.461988
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:25:54.060561
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-22 23:25:55.288987
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    system_uptime_facts = SunOSHardware().get_uptime_facts()
    assert 'uptime_seconds' in system_uptime_facts

# Generated at 2022-06-22 23:26:00.065341
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_facts = {}
    test_hw_facts = SunOSHardware()
    test_hw_facts.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    test_hw_facts.get_cpu_facts(hardware_facts)

    assert hardware_facts['processor_count'] >= 1
    assert hardware_facts['processor_cores'] == hardware_facts['processor_count']

# Generated at 2022-06-22 23:26:09.394074
# Unit test for constructor of class SunOSHardware

# Generated at 2022-06-22 23:26:20.603089
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test that the method get_dmi_facts of class SunOSHardware
    returns a dict with expected keys and values
    """
    print("testing SunOSHardware.get_dmi_facts")
    hw=SunOSHardware()
    test_dmi_facts = {
        'ansible_dmi': {
            'system_vendor': 'Sun Microsystems',
            'product_name': 'Sun Fire V490'
        }
    }

    with open("get_dmi_facts.txt") as fd:
        dmi_facts = hw._get_dmi_facts(fd)

    assert dmi_facts == test_dmi_facts


# Generated at 2022-06-22 23:26:29.375181
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Arrange
    sut = SunOSHardware()

# Generated at 2022-06-22 23:26:30.272035
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_platform = SunOSHardwareCollector()

# Generated at 2022-06-22 23:26:32.762162
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts import Collector

    c = Collector(SunOSHardwareCollector, None)
    assert c != None

# Generated at 2022-06-22 23:26:45.822943
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """ Unit test for SunOSHardware """

    # test case 1
    facts = dict()
    facts.update({'platform': 'SunOS'})
    my_SunOS_hardware = SunOSHardware(facts)
    my_SunOS_hardware._module = 'fake_module'
    my_SunOS_hardware.module.run_command = lambda x: (0, '', '') # fake_module.run_command(x)
    my_SunOS_hardware.module.run_command_environ_update = False
    my_SunOS_hardware.populate()
    my_SunOS_hardware.get_cpu_facts()
    my_SunOS_hardware.get_memory_facts()
    my_SunOS_hardware.get_dmi_facts()

# Generated at 2022-06-22 23:26:48.389428
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    # Make sure the constructor for this class does not throw exceptions
    assert hardware is not None

# Generated at 2022-06-22 23:26:59.558690
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # SunOSHardware.get_dmi_facts() returns a dictionary of system_vendor,
    # product_name.
    hardware_facts = SunOSHardware({})
    collected_facts = {}
    system_vendor = 'QEMU'
    product_name = 'Standard PC (i440FX + PIIX, 1996)'
    system_info = 'System Configuration: {0} {1}'.format(system_vendor, product_name)
    dmi_facts = hardware_facts.get_dmi_facts({'ansible_facts': collected_facts})
    collected_facts.update(dmi_facts)
    assert collected_facts['ansible_facts']['system_vendor'] == system_vendor
    assert collected_facts['ansible_facts']['product_name'] == product_name

# Generated at 2022-06-22 23:27:07.606068
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = type('obj', (), {'run_command': run_command, 'get_bin_path': get_bin_path})
    module.run_command = run_command
    module.get_bin_path = get_bin_path

    hardware = SunOSHardware(module)

    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0



# Generated at 2022-06-22 23:27:08.946775
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = MockModule()
    SunOSHardwareCollector(module)

# Generated at 2022-06-22 23:27:11.454956
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({})
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:27:20.640130
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    setattr(module, 'run_command', run_command)
    setattr(module, 'get_bin_path', get_bin_path)
    setattr(module, 'get_file_content', get_file_content)

    sunoshw = SunOSHardware(module)
    facts = sunoshw.populate()

    for key in facts:
        assert key in sunoshw.facts
        assert key in facts



# Generated at 2022-06-22 23:27:32.349453
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a mock class to simulate the module object
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    # Create a mock class to simulate the module_utils object
    class MockAnsibleModule(object):
        def __init__(self, module):
            self.params = {}
            self.exit_json = lambda **kwargs: True
            self.fail_json = lambda **kwargs: False
            self.check_mode = False
            self.params['gather_subset'] = []

# Generated at 2022-06-22 23:27:38.981991
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    sunoshw = SunOSHardware(module)

    # test with product name and vendor that matches
    module.run_command.return_value = (1, None, None)
    module.run_command.return_value = (0, "System Configuration: Oracle Corporation sun4v", "")
    dmi_facts = sunoshw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v'

    # test with product name that doesn't match
    module.run_command.return_value = (1, None, None)
    module.run_command.return_value = (0, "System Configuration: NotAMatch sun4v", "")
    dmi_facts = sunosh

# Generated at 2022-06-22 23:27:50.455590
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import sys
    import json

    # mock required modules
    sys.modules['ansible'] = type('module', (), {'__path__': ['/usr/lib/python2.7/dist-packages/ansible']})()
    sys.modules['ansible.module_utils'] = type('module', (), {'__path__': ['/usr/lib/python2.7/dist-packages/ansible/module_utils']})()
    sys.modules['ansible.module_utils.common'] = type('module', (), {'__path__': ['/usr/lib/python2.7/dist-packages/ansible/module_utils/common']})()

# Generated at 2022-06-22 23:27:51.711991
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # The default constructor should work
    SunOSHardware()

# Generated at 2022-06-22 23:28:01.470259
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Test method populate of class SunOSHardware
    """

    m = SunOSHardware()
    collected_facts = {
        'ansible_machine': 'i86pc',
    }

# Generated at 2022-06-22 23:28:14.708279
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FAKE_MODULE:
        def __init__(self):
            self.command_results = {
                'kstat_p': (0, "unix:0:system_misc:boot_time 1548249689", ""),
                'kstat_p_fail': (1, "", ""),
            }

        def run_command(self, command):
            if '-p' in command:
                return self.command_results['kstat_p']
            if 'kstat_p_fail' in command:
                return self.command_results['kstat_p_fail']

    class FAKE_TIME:
        @staticmethod
        def time():
            return 1602804863.925835

    mock_module = FAKE_MODULE()
    mock_time = FAKE_TIME()
    sunos

# Generated at 2022-06-22 23:28:23.259190
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    H = SunOSHardware()
    H.module = Mock()
    H.module.run_command = Mock(return_value=(0, '', ''))
    cmd = ['/usr/bin/kstat', '-p']

    for ds in H.get_device_facts()['devices']['sda']:
        cmd.append('sderr:::%s' % ds)

    H.module.run_command.assert_called_once_with(cmd)



# Generated at 2022-06-22 23:28:27.671699
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    facts = SunOSHardware().get_dmi_facts()
    assert(facts.get('system_vendor') in ['Fujitsu', 'Oracle Corporation', 'Sun Microsystems', 'VMware, Inc.'])
    assert(facts.get('product_name') is not None)


# Generated at 2022-06-22 23:28:31.740949
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    _fact_class = SunOSHardware
    _platform = 'SunOS'
    hc = SunOSHardwareCollector(_fact_class, _platform)

    assert hc.fact_class == SunOSHardware
    assert hc.platform == 'SunOS'
    assert hc.required_facts == set(['platform'])

# Generated at 2022-06-22 23:28:41.183424
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = SunOSHardware(module)
    facts = hardware.populate()

    product_name = facts.get('product_name')
    assert product_name is not None

    # Test some cpu facts
    processors = facts.get('processor')
    assert processors is not None

    processor_count = facts.get('processor_count')
    assert processor_count > 0

    processor_cores = facts.get('processor_cores')
    assert processor_cores is not None

    # Test some memory facts
    memtotal_mb = facts.get('memtotal_mb')
    assert memtotal_mb > 0

    swap_reserved_mb = facts.get('swap_reserved_mb')
    assert swap_reserved_mb is not None

    # Test an optional device fact

# Generated at 2022-06-22 23:28:49.334657
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Unit test to verify the cpu facts of SunOSHardware.
    """
    # Collect facts.
    SunOSHardwareCollector.collect(None, None)

    # Get the facts pertaining SunOSHardware
    sunos = SunOSHardwareCollector.get_facts()

    # Check the cpu facts.
    assert 'processor_cores' in sunos
    assert 'processor_count' in sunos
    assert 'processor' in sunos
    assert 'processor_cores' != sunos['processor_count']

# Generated at 2022-06-22 23:28:56.368914
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:28:57.350833
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-22 23:29:00.494227
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = MockModule()
    hardware = SunOSHardware(module)

    assert hardware.module == module
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-22 23:29:09.452760
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule:
        def run_command(self, command):
            return (0, '{}\n'.format(command), '')

    class MockFactCollector:
        def __init__(self):
            self.ansible_facts = {}

    class MockHardware:
        platform = 'SunOS'

    # Expected memory facts
    expected = {
        'swapfree_mb': 0,
        'swaptotal_mb': 0,
        'swap_allocated_mb': 0,
        'swap_reserved_mb': 0,
        'memtotal_mb': 0,
    }

    module = MockModule()
    facts_collector = MockFactCollector()
    # Object of class SunOSHardware
    sunos_hardware = SunOSHardware(module, facts_collector)

    # Actual memory

# Generated at 2022-06-22 23:29:15.178941
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # If a class inherits from object (new style class),
    # then __init__() is inherited from object automatically.
    # Then you should not define __init__() in your class definition.
    x = SunOSHardwareCollector()
    assert x.required_facts == set(['platform'])
    assert x._platform == 'SunOS'
    assert isinstance(x._fact_class, SunOSHardware)

# Generated at 2022-06-22 23:29:27.771229
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import sys
    import os
    import tempfile
    import textwrap
    import stat

    # Create a temporary file, write the kstat output to it, then try parse that output


# Generated at 2022-06-22 23:29:30.478952
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Test for method get_memory_facts of class SunOSHardware
    """
    ret = SunOSHardware.get_memory_facts()
    assert 'memtotal_mb' in ret

# Generated at 2022-06-22 23:29:38.981263
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    '''
    Tests the SunOSHardware.get_device_facts method.
    '''
    # Test data to be used by the mock class returned in place of
    # AnsibleModule

# Generated at 2022-06-22 23:29:42.727673
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'

# Generated at 2022-06-22 23:29:47.743407
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mm = SunOSHardware()
    meminfo = mm.get_memory_facts()
    assert type(meminfo) is dict
    assert 'memtotal_mb' in meminfo
    assert 'swapfree_mb' in meminfo
    assert 'swaptotal_mb' in meminfo


# Generated at 2022-06-22 23:29:59.951131
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:30:01.401189
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'
    assert hardware.processor_count == 0
    assert hardware.processor_cores == 'NA'


# Generated at 2022-06-22 23:30:06.339919
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    expected_cpu_facts = {
        'processor_cores': 2,
        'processor_count': 2,
        # The list of processors is too platform dependent for testing so we don't test it.
    }
    assert_expected_dict_in_actual(expected_cpu_facts, SunOSHardware().get_cpu_facts())



# Generated at 2022-06-22 23:30:18.817714
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sample_text = '''module: cpu_info
instance: 0
class: misc
chip_id     0
clock_MHz   2120
implementation     sparc
brand       sun4v
        '''

    with open('test_SunOSHardware_get_cpu_facts.txt', 'w') as f:
        f.write(sample_text)

    h = SunOSHardware({})
    h.module.run_command = lambda *args, **kwargs: (0, open('test_SunOSHardware_get_cpu_facts.txt').read(), None)
    rc, out, err = h.module.run_command("/usr/bin/kstat cpu_info")

    h.populate()
    h.get_cpu_facts()

    assert out == sample_text

# Generated at 2022-06-22 23:30:24.833547
# Unit test for method get_uptime_facts of class SunOSHardware

# Generated at 2022-06-22 23:30:30.478696
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = os.path.dirname(__file__) + '/ansible_test_mock.py'
    facts = Facts(module=module)
    facts.populate()
    # test for some specific devices
    devices = [
        'sda',
        'sdb'
    ]
    for device in devices:
        # Check if device is present
        assert device in facts['ansible_devices'], \
            "Device {} is not present in ansible_devices fact".format(device)
        # Check if device is enabled
        assert not facts['ansible_devices'][device].get('disabled'),\
            "Device {} is disabled".format(device)
        # Check if device has all the required attributes
        required_attributes = ['product', 'revision', 'serial', 'size', 'vendor']

# Generated at 2022-06-22 23:30:37.583846
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Construct test data by capturing output of command kstat -p for
    # required device statistics.
    test_data = {}
    required_stats = ['Product', 'Revision', 'Serial No', 'Size', 'Vendor',
                      'Hard Errors', 'Soft Errors', 'Transport Errors',
                      'Media Error', 'Predictive Failure Analysis',
                      'Illegal Request']
    cmd = ['/usr/bin/kstat', '-p']
    for stat in required_stats:
        cmd.append('sderr:::%s' % stat)
    rc, out, err = run_command(cmd)
    if rc != 0:
        return
    sd_instances = frozenset(line.split(':')[1] for line in out.split('\n') if line.startswith('sderr'))
   

# Generated at 2022-06-22 23:30:45.477110
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = {'processor_cores': 'NA', 'processor_count': 2, 'processor': [u'SUNW,SPARC-Enterprise-T5220', u'SUNW,SPARC-Enterprise-T5220']}
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.module.run_command_environ_update = None
    assert hardware.get_cpu_facts() == cpu_facts


# Generated at 2022-06-22 23:30:53.284081
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = None
    hardware_obj = SunOSHardware(module)
    memory_facts_dict = hardware_obj.get_memory_facts()
    assert 'memtotal_mb' in memory_facts_dict
    assert 'swap_reserved_mb' in memory_facts_dict
    assert 'swap_allocated_mb' in memory_facts_dict
    assert 'swaptotal_mb' in memory_facts_dict
    assert 'swapfree_mb' in memory_facts_dict

# unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:31:05.410891
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware()
    hardware.module = MockModule()
    results = hardware.get_device_facts()

    devices = results['devices']

    assert 'sd0' in devices
    assert devices['sd0']['product'] == 'VBOX HARDDISK'
    assert devices['sd0']['revision'] == '1.0'
    assert devices['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert devices['sd0']['size'] == '50.00 GB'
    assert devices['sd0']['vendor'] == 'ATA'
    assert devices['sd0']['hard_errors'] == '0'
    assert devices['sd0']['soft_errors'] == '0'

# Generated at 2022-06-22 23:31:10.288004
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    facts = SunOSHardware(module).get_memory_facts()

    # On Solaris, prtconf does not return a valid output everytime.
    # https://docs.oracle.com/cd/E19253-01/816-5167/gepgd/index.html
    # So, memtotal_mb may not be present in facts.
    assert facts.get('memtotal_mb') is not None

# Generated at 2022-06-22 23:31:20.165822
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def __init__(self):
            self.run_command = Mock(return_value = (0, "unix:0:system_misc:boot_time    1548249689", None))

    hw = SunOSHardware(MockModule())
    hw.module.run_command = Mock(return_value = (0, "unix:0:system_misc:boot_time    1548249689", None))
    assert hw.get_uptime_facts()['uptime_seconds'] == int(time.time()) - 1548249689

# Generated at 2022-06-22 23:31:25.325506
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = DummyAnsibleModule()
    hardware = SunOSHardware(module)

    hardware.process_facts = MockModuleUtils()
    hardware.process_facts.dict_merge.side_effect = lambda x, y: dict(x, **y)

    # Mock the call to kstat

# Generated at 2022-06-22 23:31:36.788917
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.module = FakeModule()
    hardware.module.get_bin_path = lambda x: '/usr/bin/%s' % x
    hardware.module.run_command = lambda x: (0, 'fakeout', '')
    hardware.populate()
    test_server_facts = hardware.facts

    assert(test_server_facts['uptime_seconds'] == 40)
    assert(test_server_facts['devices']['sda']['hard_errors'] == '0')
    assert(test_server_facts['devices']['sdb']['media_errors'] == '0')
    assert(test_server_facts['devices']['sdc']['revision'] == '1.0')

# Generated at 2022-06-22 23:31:48.387637
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import FactsCollector

    facts_collector = FactsCollector()


# Generated at 2022-06-22 23:32:00.543104
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class Mock_module:
        class Mock_run_command():
            rc = 0
            out = 'unix:0:system_misc:boot_time    1548249689'

        def __init__(self):
            self.run_command = self.Mock_run_command()

    class Mock_uptime_facts(SunOSHardware):
        def __init__(self):
            self.module = Mock_module()

    # uptime = $current_time - $boot_time
    actual_uptime = int(time.time() - int(Mock_module.Mock_run_command.out.split('\t')[1]))

    s = Mock_uptime_facts()

    expected_uptime = s.get_uptime_facts()['uptime_seconds']

    assert expected_uptime == actual_

# Generated at 2022-06-22 23:32:03.157105
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    SunOSHardware().populate()


# Generated at 2022-06-22 23:32:12.612901
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_obj = SunOSHardware()
    test_obj.module = FakeModule()
    if test_obj.module.run_command.call_count == 0:
        test_obj.module.run_command.side_effect = test_obj.module.run_command(["/usr/sbin/prtconf"])
        test_obj.module.run_command.side_effect = test_obj.module.run_command("/usr/sbin/swap -s")
    assert test_obj.get_memory_facts()


# Generated at 2022-06-22 23:32:16.904434
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    '''
    Test if platform fact and class is exist.
    >>> from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    >>> SunOSHardware().platform
    'SunOS'
    '''
    pass



# Generated at 2022-06-22 23:32:23.482199
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    res_facts = SunOSHardware(module).populate()
    assert res_facts['ansible_hw_memtotal_mb'] == res_facts['ansible_memtotal_mb']
    assert res_facts['ansible_hw_memfree_mb'] == res_facts['ansible_memfree_mb']

# Generated at 2022-06-22 23:32:26.856080
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == {'platform'}

# Generated at 2022-06-22 23:32:38.881054
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This method unit test the populate of class SunOSHardware
    """
    m_run_command = MagicMock(return_value=(0, "", ""))
    m_get_file_content = MagicMock(return_value="")
    m_get_mount_size = MagicMock(return_value={})
    m_get_bin_path = MagicMock(return_value="/usr/bin/prtconf")


# Generated at 2022-06-22 23:32:51.958970
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    system_vendor = 'Fujitsu'
    product_name = 'FST S MPR JBOD CONTROLLER'
    prtdiag_out = "System Configuration: " + system_vendor + " " + product_name

    hardware = SunOSHardware()
    hardware.module = MagicMock(spec_set=basic.AnsibleModule)
    hardware.module.run_command = MagicMock(return_value=(0, prtdiag_out, ''))

    facts = hardware.get_dmi_facts()
    assert facts.get('system_vendor') == system_

# Generated at 2022-06-22 23:32:58.029959
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hostname = 'testhost'
    module = 'testmodule'
    facts = {}

    hardware_class = SunOSHardware(hostname, module, facts)

    assert hardware_class.hostname == hostname
    assert hardware_class.module == module
    assert hardware_class.facts == facts
    assert hardware_class._locale == 'C'

# Generated at 2022-06-22 23:32:59.942396
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert isinstance(hardware, SunOSHardware)


# Generated at 2022-06-22 23:33:08.211033
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = mock_run_command()
    hardware = SunOSHardware(module)
    # 1. If prtconf returns no output, run_command raises CalledProcessError
    module.run_command.side_effect = [
        (0, '', ''),
        (1, '', '')
    ]
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == []
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 0
    # 2. prtconf returns output

# Generated at 2022-06-22 23:33:21.049425
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:23.990995
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = {'platform': 'SunOS'}
    hardware = SunOSHardware(True, facts)
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-22 23:33:36.423437
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Unit test for method get_dmi_facts of class SunOSHardware
    """
    import random
    import string
    random_model = ''.join(random.choice(string.ascii_uppercase) for i in range(5))
    random_vendor = ''.join(random.choice(string.ascii_uppercase) for i in range(5))
    random_input = "System Configuration:  %s %s\n" % (random_vendor, random_model)
    test_class = SunOSHardware()
    test_class.module.run_command.return_value = (0, random_input, '')
    assert test_class.get_dmi_facts() == {'system_vendor': random_vendor, 'product_name': random_model}



# Generated at 2022-06-22 23:33:48.922743
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class ModuleStub:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    sunos_hardware = SunOSHardware()


# Generated at 2022-06-22 23:33:57.534697
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule({})

    # Test Populate returns correct default hardware facts for SunOS
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['memory_mb']['real']['total'] == hardware_facts['memtotal_mb']

    # TODO: test hardware.get_dmi_facts()
    assert hardware_facts['system_vendor'] == 'Sun Microsystems' or \
        hardware_facts['system_vendor'] == 'Fujitsu' or \
        hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name']

    # TODO: test hardware.get_device_facts()
    assert hardware_facts['devices']['sd0']['vendor'] == 'ATA'

    # TODO:

# Generated at 2022-06-22 23:34:09.918286
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()

    # System configuration lines from prtdiag output.
    # Currently supported on Solaris 10 & 11; as well as 9 for SPARC.
    # It will be expanded to include other platforms as the need arises.
    platform = ['i86pc', 'sun4u', 'sun4v']
    system_vendor = ['Oracle Corporation', 'Sun Microsystems', 'Fujitsu']
    product_name = ['SUNW,Sun-Fire-V890', 'SPARC Enterprise T5120', 'SPARC T3-2 Server']

    # These regular expressions should match the output of the
    # 'System Configuration' line of prtdiag.
    # Add new regular expressions here, if needed.
    system_vendor_regex = 'Oracle Corporation|Sun Microsystems|Fujitsu'
    product_name

# Generated at 2022-06-22 23:34:19.235281
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:34:23.406892
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h_obj = SunOSHardware()
    mem_facts = h_obj.get_memory_facts()
    results = {'memtotal_mb': 32000}
    assert mem_facts == results

# Generated at 2022-06-22 23:34:31.923002
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:34:35.586711
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])


# Generated at 2022-06-22 23:34:46.107424
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.hardware.sunos import SunOSHardware
    import datetime
    import mock

    time_now = datetime.datetime.now()

    # mock time_now to return datetime object.
    with mock.patch('datetime.datetime') as mock_datetime:
        mock_datetime.now.return_value = time_now
        obj = SunOSHardware()
        rc = 0
        out = str(time_now.timestamp())
        err = ''
        mock_command = mock.Mock(return_value=(rc, out, err))
        with mock.patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.run_command', mock_command):
            uptime_facts = obj.get_uptime_facts()


# Generated at 2022-06-22 23:34:50.456101
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = mock.MagicMock(return_value=(0, "unix:0:system_misc:boot_time    1548249689", None))
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-22 23:34:56.620284
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    prtconf_output = """Memory size: 16384 Megabytes
System Peripherals (Software Nodes):

System board or motherboard:
  SUNW,Sun-Fire-T1000

"""
    prtconf_output2 = """Memory size: 32768 Megabytes
System Peripherals (Software Nodes):

System board or motherboard:
  SUNW,Sun-Fire-T2000

"""

# Generated at 2022-06-22 23:35:05.151999
# Unit test for method get_dmi_facts of class SunOSHardware