

# Generated at 2022-06-22 23:25:01.094350
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockedModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, args, **kwargs):
            if isinstance(args, list):
                command = ' '.join(args)
            else:
                command = args

            if command == '/usr/bin/uname -i':
                return (0, 'i86pc', '')

            elif command == '/usr/platform/i86pc/sbin/prtdiag':
                return (0, '''\
System Configuration: VMware, Inc. Virtual Platform
BIOS Configuration: Phoenix ROM BIOS PLUS Version 1.10 090117 1319\n''', '')

            else:
                return (256, '', '')


# Generated at 2022-06-22 23:25:04.333197
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    facts = SunOSHardware()

    assert(facts.platform == 'SunOS')

# Generated at 2022-06-22 23:25:14.025340
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    collect_only = False
    # Test with real answers from prtdiag -v
    from ansible.module_utils.facts.collector import get_collector_facts
    test_platform = 'SunOS'
    result = get_collector_facts('hardware', 'SunOSHardwareCollector', test_platform, collect_only)
    if 'platform' in result.keys():
        product = result['dmi_facts']['product_name']
        vendor = result['dmi_facts']['system_vendor']
        assert 'Oracle Corporation' in vendor
        assert 'SPARC T4-2' in product
    else:
        # The platform is not SunOS, we don't test the test
        pass

# Generated at 2022-06-22 23:25:17.721019
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector([{'platform': 'SunOS'}])

    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == {'platform'}

# Generated at 2022-06-22 23:25:20.154191
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-22 23:25:22.788993
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_facts = SunOSHardwareCollector(None, None)
    assert hardware_facts.fact_class == SunOSHardware
    assert hardware_facts.platform == 'SunOS'

# Generated at 2022-06-22 23:25:34.708300
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    dict_arg = {}
    dict_arg['run_command'] = os.system
    dict_arg['get_bin_path'] = lambda _ : '/usr/bin/true'
    dict_arg['get_file_content'] = lambda _ : ''
    dict_arg['_ansible_verbosity'] = True
    instance = SunOSHardware()

    # Set the run_command attribute to a method that returns three
    # values: a return code that is not 0, an output line with a
    # timestamp equal to 2147483647, and an empty error line
    instance.module.run_command = lambda _ : (1, 'unix:0:system_misc:boot_time\t2147483647', '')

   

# Generated at 2022-06-22 23:25:47.211403
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create an instance of the SunOSHardware dict
    o_SunOSHardware = SunOSHardware({})
    # call method populate of SunOSHardware
    d_SunOSHardware_populate = o_SunOSHardware.populate()

    # Tests
    assert d_SunOSHardware_populate.get('ansible_processor') is not None

    assert d_SunOSHardware_populate.get('processor_count') is not None

    assert d_SunOSHardware_populate.get('processor_count') >= 1

    assert d_SunOSHardware_populate.get('processor_cores') is not None

    assert d_SunOSHardware_populate.get('processor_cores') >= 1

    assert d_SunOSHardware_populate.get('memtotal_mb') is not None

    assert d_SunOSHardware_populate.get

# Generated at 2022-06-22 23:25:51.299015
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:25:53.293962
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    assert SunOSHardware({'ansible_machine': 'i86pc', 'ansible_system': 'SunOS'}) is not None

# Generated at 2022-06-22 23:25:55.060460
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj.platform == 'SunOS'
    assert obj.fact_class == SunOSHardware


# Generated at 2022-06-22 23:26:00.673257
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    collector = SunOSHardwareCollector(module)
    fact = collector.collect(None, None)
    assert fact.platform == 'SunOS', 'platform should be SunOS'
    assert fact.mounts is not None, 'mounts should not be None'
    assert fact.memtotal_mb is not None, 'memtotal_mb should not be None'
    assert fact.swap_allocated_mb is not None, 'swap_allocated_mb should not be None'
    assert fact.swap_reserved_mb is not None, 'swap_reserved_mb should not be None'
    assert fact.uptime_seconds is not None, 'uptime_seconds should not be None'
    assert fact.devices is not None, 'devices should not be None'

# Generated at 2022-06-22 23:26:07.371291
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    fake_module = FakeAnsibleModule()
    fake_module.get_bin_path = lambda bin: bin
    fake_module.run_command = lambda cmd: (0, 'System Configuration: Sun Microsystems sun4v', '')
    hardware = SunOSHardware(fake_module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4v'


# Generated at 2022-06-22 23:26:20.015593
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sunOSHardware = SunOSHardware()
    prtconf_out = b"""System Configuration: VMware, Inc. VMware Virtual Platform
Memory size: 2047 Megabytes
"""

    swap_out = b"""kbytes          allocated       used   avail capacity
           4096           4096           4096           0  100%
"""

    system_mock = {'run_command_environ_update': {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}}
    sunOSHardware.module = system_mock
    sunOSHardware.module.run_command = lambda x: (0, prtconf_out, '')
    sunOSHardware.module.run_command = lambda x: (0, swap_out, '')
    memory_facts = sunOSHardware.get_memory_facts()

    assert memory_facts

# Generated at 2022-06-22 23:26:28.872657
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockSystem:
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time 1548249689', ''

    class MockModule:
        def __init__(self):
            self.run_command = MockSystem().run_command

    ph = SunOSHardware()

    # Create an instance of the module (MockModule)
    ph.module = MockModule()

    # Check that uptime_seconds is a valid int
    assert isinstance(ph.get_uptime_facts()['uptime_seconds'], int)



# Generated at 2022-06-22 23:26:29.900984
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:26:35.308350
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(
        )
    )

    # get_cpu_facts returns dictionary
    cpu_facts = SunOSHardware(module=module).get_cpu_facts(collected_facts=None)
    assert isinstance(cpu_facts, dict)

    # get_cpu_facts returns non-empty dictionary
    assert len(cpu_facts) > 0

    # get_cpu_facts returns dictionary with 'processor' key
    assert 'processor' in cpu_facts

    # get_cpu_facts returns dictionary with 'processor_cores' key
    assert 'processor_cores' in cpu_facts

    # get_cpu_facts returns dictionary with 'processor_count' key
    assert 'processor_count' in cpu_facts

    # get_cpu_facts returns dictionary with 'processor_count' greater than 0


# Generated at 2022-06-22 23:26:42.313582
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware(None)

    hardware.module.run_command = lambda command: ("", "", "")

    hardware.get_dmi_facts()

    assert hardware.facts['system_vendor'] == 'Sun Microsystems'
    assert hardware.facts['product_name'] == 'Oracle Corporation sun4u Sun Fire T2000'

# Generated at 2022-06-22 23:26:54.976458
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = dict()
    hardware_facts['ansible_processor'] = 'sparc'
    hardware_facts['ansible_machine'] = 'i86pc'
    hardware_facts['platform'] = 'SunOS'
    hardware_facts['system_vendor'] = 'Fujitsu'
    hardware_facts['product_name'] = 'SPARC Enterprise M3000 Server'
    hardware_facts['memtotal_mb'] = 8192
    hardware_facts['swapfree_mb'] = 4096
    hardware_facts['swaptotal_mb'] = 8192
    hardware_facts['swap_allocated_mb'] = 4096
    hardware_facts['swap_reserved_mb'] = 4096

# Generated at 2022-06-22 23:27:07.705917
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock({})
    ha = SunOSHardware(module)
    facts = ha.populate()

    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 1
    assert facts['processor'] == ['Genuine Intel(R) CPU T2500  @ 2.00GHz']

    assert facts['system_vendor'] == 'QEMU'
    assert facts['product_name'] == 'Standard PC (Q35 + ICH9, 2009)'

    assert facts['memtotal_mb'] == 2516


# Generated at 2022-06-22 23:27:17.045765
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    hardware.get_cpu_facts({'ansible_machine': 'i86pc'})

    assert hardware.facts['processor'][0] == 'Intel(r) Xeon(r) CPU X5660 @ 2.80GHz'
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 24

# Generated at 2022-06-22 23:27:23.108060
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors import get_collector_names
    assert 'hardware' not in get_collector_names(all_collectors=True)
    get_collector_names(all_collectors=True).insert(0, 'hardware')
    c = Collector()
    assert isinstance(c.collectors['hardware'], SunOSHardwareCollector)

# Generated at 2022-06-22 23:27:34.129170
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import json
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    test_result = {
        "devices": {
            "sd0": {
                "serial": "VB0ad2ec4d-074a",
                "predictive_failure_analysis": "0",
                "vendor": "ATA",
                "hard_errors": "0",
                "product": "VBOX HARDDISK",
                "transport_errors": "0",
                "soft_errors": "0",
                "revision": "1.0",
                "media_errors": "0",
                "illegal_request": "6",
                "size": "50.0G"
            }
        }
    }


# Generated at 2022-06-22 23:27:47.447957
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:58.901018
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module=module)
    assert hw.platform == 'SunOS'
    assert hw.get_cpu_facts() == {'processor': [], 'processor_cores': 'NA', 'processor_count': 0}
    assert hw.get_memory_facts() == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'swap_allocated_mb': 0, 'swap_reserved_mb': 0}
    assert hw.get_dmi_facts() == {}
    assert hw.get_device_facts() == {}
    assert hw.get_uptime_facts() == {}

# Generated at 2022-06-22 23:28:03.347990
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """ Test if the method populate of class SunOSHardware works as expected """
    # Test if populate returns a dictonary
    hardware = SunOSHardware()
    hardware_facts = hardware.populate()
    assert isinstance(hardware_facts, dict)


# Generated at 2022-06-22 23:28:06.168349
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()
    assert m.get_dmi_facts() == { }

# Generated at 2022-06-22 23:28:09.848078
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    class FakeModule:
        def run_command(self, command):
            return 0, str(int(datetime.datetime.now().timestamp()) - 1), ""

    fake_module = FakeModule()
    sunos_hardware = SunOSHardware(fake_module)

    result = sunos_hardware.get_uptime_facts()

    assert result['uptime_seconds'] == 1

# Generated at 2022-06-22 23:28:18.123919
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    import sys
    import os
    import unittest
    import StringIO

    cm_mock = StringIO.StringIO()
    cm_mock.name = '/usr/bin/kstat'
    sys.modules['__builtin__'].open = lambda _: cm_mock

    os.environ['PATH'] = '/usr/bin'
    shc = SunOSHardwareCollector(None)

    assert shc.facts_class == SunOSHardware
    assert shc._platform == 'SunOS'
    assert shc.required_facts == set(['platform'])

# Generated at 2022-06-22 23:28:21.018884
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    for f in SunOSHardwareCollector.required_facts:
        assert f in SunOSHardwareCollector.collected_facts

# Generated at 2022-06-22 23:28:25.049563
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()

# Generated at 2022-06-22 23:28:26.092662
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
        SunOSHardwareCollector()

# Generated at 2022-06-22 23:28:34.798342
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    module.get_bin_path = lambda x: x
    hardware = SunOSHardware(module)
    prtdiag_output = """System Configuration: VMware, Inc. VMware Virtual Platform
Sun Microsystems sun4v"""
    hardware.module.run_command = lambda x: (1, prtdiag_output, '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-22 23:28:37.643090
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    m = SunOSHardware(module)
    memory_facts = m.get_memory_facts()
    assert 'memtotal_mb' in memory_facts


# Generated at 2022-06-22 23:28:50.757623
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Run with platform sun4v, valid output for kstat cpu_info
    module_args = dict(platform='sun4v')
    facts_obj = SunOSHardware(module_args)

    cpu_facts = facts_obj.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC T4-1 @ 2300MHz', 'SPARC T4-1 @ 2300MHz', 'SPARC T4-1 @ 2300MHz', 'SPARC T4-1 @ 2300MHz']
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 1

    memory_facts = facts_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['swapfree_mb'] == 4367
    assert memory_facts

# Generated at 2022-06-22 23:29:03.456353
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware()

# Generated at 2022-06-22 23:29:12.675503
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule({})
    module.params = {'foo': 'bar'}
    hardware = SunOSHardware(module)

    rc = 0
    out = 'sderr:0:sd0,err:Product VBOX HARDDISK   9'
    err = ''

    # device_facts returns a dict of dicts.
    # {"devices": {"sd0": {"product": "VBOX"}}}
    device_facts = hardware.get_device_facts()

    assert device_facts == {
        "devices": {
            "sd0": {
                "product": "VBOX"
            }
        }
    }

# Generated at 2022-06-22 23:29:19.245546
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware import SunOSHardware
    import textwrap

    # Mock input for prtdiag
    # Sample text is derived from output of prtdiag on a SunOS machine
    # 4 lines of text are used to test SUNW,LP and Oracle machines

# Generated at 2022-06-22 23:29:25.357404
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule({})
    hardware_obj = SunOSHardware(module)
    cpu_facts = hardware_obj.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts.keys()
    assert 'processor' in cpu_facts


# Generated at 2022-06-22 23:29:26.840916
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector != ''

# Generated at 2022-06-22 23:29:36.316796
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # class FactModule is being mocked as it is not used by this method
    class FactModule:
        def run_command(self, cmd, encode_errors='strict'):
            return 0, 'unix:0:system_misc:boot_time    1548249689', None

    # class SunOSHardware is being mocked as it is not used by this method
    class SunOSHardware:
        module = FactModule

    # test data
    boot_time = 1548249689
    now_time = 1548249731

    # mock time.time() to return now_time
    def mock_time_time():
        return now_time

    # set up
    sunos_hardware = SunOSHardware()
    time.time = mock_time_time

    # execute method
    uptime_facts = sunos_hardware.get_

# Generated at 2022-06-22 23:29:49.550663
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module_mock = AnsibleModuleMock()
    facts_mock = SunOSHardware()
    facts_mock.module = module_mock


# Generated at 2022-06-22 23:30:02.707874
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = DummyAnsibleModule({})
    hardware = SunOSHardware(module)


# Generated at 2022-06-22 23:30:08.386545
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = DummyModule()
    hw = SunOSHardware(module)
    result = hw.get_device_facts()
    assert isinstance(result, dict)
    assert 'devices' in result
    for k, v in result['devices'].items():
        assert k.startswith('sd')
        assert isinstance(v, dict)
        assert 'product' in v
        assert 'vendor' in v
        assert 'size' in v
        assert 'serial' in v
        assert 'revision' in v



# Generated at 2022-06-22 23:30:15.793687
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, "Foo 1.0", "")
    hw = SunOSHardware()
    hw.module = module
    dmi_facts = hw.get_dmi_facts()
    assert(dmi_facts['system_vendor'] == 'Foo')
    assert(dmi_facts['product_name'] == '1.0')

# Generated at 2022-06-22 23:30:23.403930
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.six import PY3

    class FakeModule(object):
        def __init__(self):
            boot_time = int(time.time())
            self.run_command_result = ('', 'unix:0:system_misc:boot_time    %s' % boot_time, None)

        def run_command(self, cmd):
            return self.run_command_result

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    fakefactcollector = BaseFactCollector(None, FakeModule())

# Generated at 2022-06-22 23:30:35.797084
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.facts import Facts
    SunOS_facts = Facts(dict(platform='SunOS'))
    SunOSHardware = SunOS_facts.get_hardware_collector(None).fact_class()

    def run_command_mock(self, cmd, environ_update=None):
        if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
            return 0, "unix:0:system_misc:boot_time   1548249689", ""
        else:
            raise RuntimeError

    SunOSHardware.module.run_command = run_command_mock

    res = SunOSHardware.get_uptime_facts()

    assert res['uptime_seconds'] == time.time() - 1548249689

# Generated at 2022-06-22 23:30:40.262223
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hw_collector_instance = SunOSHardwareCollector()
    assert sunos_hw_collector_instance._fact_class == SunOSHardware
    assert sunos_hw_collector_instance._platform == 'SunOS'

# Generated at 2022-06-22 23:30:42.858748
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware()
    hardware.populate()


# Generated at 2022-06-22 23:30:53.802281
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hc = SunOSHardware()

    # generate mocked 'out'
    cpu_info_keys = [
        "brand",
        "chip_id",
        "clock_MHz",
        "implementation",
        "module",
        "module_id",
        "state",
        "vendor_id",
    ]

    lines = []
    for key in cpu_info_keys:
        lines.append("{key}: {dummy_str}".format(key=key, dummy_str=key))

    out = '\n'.join(lines)

    # generate mocked 'collected_facts'
    collected_facts = {
        "ansible_machine": "i86pc"
    }

    # test 'brand'
    brand = "Intel(r)"

# Generated at 2022-06-22 23:30:55.279795
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    h = SunOSHardware({}, {})
    assert h.get_memory_facts() == {}

# Generated at 2022-06-22 23:31:07.831718
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    dmi_facts = SunOSHardware(module=module).get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'VirtualBox'

    module = AnsibleModuleMock()
    module.run_command = run_command_QEMU
    dmi_facts = SunOSHardware(module=module).get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'QEMU'
    assert dmi_facts['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'

    module = AnsibleModuleMock()
    module.run_command = run_command_VMWare

# Generated at 2022-06-22 23:31:13.463482
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class SolarisModuleMock(object):
        def __init__(self):
            self.boot_time = 1548249689.00
            self.run_command_result = 0

        def run_command(self, cmd):
            if 'kstat -p unix:0:system_misc:boot_time' in cmd:
                return (self.run_command_result, 'unix:0:system_misc:boot_time 1548249689', '')
            elif 'df -k' in cmd:
                return (self.run_command_result, 'Filesystem\t1K-blocks\tUsed\tAvailable\tUse%\tMounted', '')

# Generated at 2022-06-22 23:31:15.539253
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    h = SunOSHardware()
    assert h.platform == 'SunOS'


# Generated at 2022-06-22 23:31:25.227692
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    h = SunOSHardware(module)

    memo = h.memo
    # Set test MemTotal property
    h.memo['MemTotal'] = '3953932 kB'
    # Set swap_allocated_mb and swap_reserved_mb to zero
    h.memo['swap_allocated_mb'] = 0
    h.memo['swap_reserved_mb'] = 0

    facts = h.get_memory_facts()
    assert facts['memtotal_mb'] == 3876
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0


# Generated at 2022-06-22 23:31:31.633498
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    out = """Memory size: 128 Megabytes"""
    module.run_command = MagicMock(return_value=(0, out, ''))
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 128



# Generated at 2022-06-22 23:31:39.244337
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    # Mock up the facts which are required for the code to run and check output
    hardware.facts = {
        "ansible_machine": "i86pc"
    }

    # Mock up the module to be run to populate memory
    hardware.module.run_command = lambda args, check_rc=True: (0, b'', b'')
    hardware.get_cpu_facts = lambda: {'processor': ['i586']}
    hardware.get_memory_facts = lambda: {'swaptotal_mb': 100, 'memtotal_mb': 200}
    hardware.get_dmi_facts = lambda: {'system_vendor': 'vendor', 'product_name': 'product'}
    hardware.get_device_facts

# Generated at 2022-06-22 23:31:42.967713
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos.get_uptime_facts import test_uptime_facts
    test = SunOSHardware()

    test_uptime_facts(test)

# Generated at 2022-06-22 23:31:52.282402
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Test a sample of cpuinfo output."""
    module = AnsibleModule(argument_spec={})
    if not module._name == 'ansible_facts':
        module.exit_json(skipped=True)

# Generated at 2022-06-22 23:31:55.185985
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware(None)
    assert hardware_facts.platform == 'SunOS'

# Generated at 2022-06-22 23:32:04.454245
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule:
        def run_command(self, command, check_rc=True, data=None):
            return 0, 'System Configuration: Sun Microsystems sun4u', ''
        def get_bin_path(self, path):
            return '/usr/sbin/prtdiag'

    class FakeModule:
        def __init__(self):
            self.params = {}

    FakeM = MockModule()
    FakeM.run_command = MockModule.run_command
    FakeM.get_bin_path = MockModule.get_bin_path
    FakeM.module = FakeModule()
    hw = SunOSHardware(FakeM)
    hw.populate()

    assert 'system_vendor' in hw.get_dmi_facts()
    assert 'product_name' in hw.get_

# Generated at 2022-06-22 23:32:17.174955
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import sys
    from ansible.utils.display import Display

    display = Display(verbosity=3)
    options = {
        'remote_user': 'root',
        'tcp_keepalive': True,
        'connection': 'local',
        'gather_timeout': 10,
        '_ansible_verbosity': 3,
        '_ansible_syslog_facility': 'LOG_USER',
        '_ansible_socket': sys.stderr
    }

    class TestModule(object):
        def __init__(self):
            self.params = dict(
            )
            self.fail_json = lambda **kwargs: kwargs['msg']


# Generated at 2022-06-22 23:32:28.499548
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())

    class HardwareSubclass(SunOSHardware):
        def __init__(self, module):
            pass

        def _run_command(self, cmd):
            class C(object):
                pass
            c = C()
            c.rc = 0

# Generated at 2022-06-22 23:32:33.738149
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_object = SunOSHardware()
    cpu_facts = test_object.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-22 23:32:36.574486
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({}, {'platform': 'SunOS'})
    assert hw is not None
    assert hw.platform == 'SunOS'



# Generated at 2022-06-22 23:32:40.499379
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    dmi_facts = SunOSHardware(module).get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V240'


# Generated at 2022-06-22 23:32:53.542897
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:56.924674
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Validate the populate function of SunOSHardware class
    """
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    hardware = SunOSHardware(module=test_module)

    # Test with no parameters
    hardware.populate()

    # Test with a subset defined
    hardware.module.params['gather_subset'] = ['!all']
    hardware.populate()

# Generated at 2022-06-22 23:33:06.930365
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    # If the kstat command fails, get_device_facts returns {}
    module.run_command.return_value = (1, '', '')
    assert hardware.get_device_facts() == {}

    # If the kstat command does not find any devices, get_device_facts returns {}
    module.run_command.return_value = (0, '', '')
    assert hardware.get_device_facts() == {}

    # If the kstat command finds two devices with three available stats, get_device_facts returns {}

# Generated at 2022-06-22 23:33:19.624633
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    tmpdir = ansible_module_mock.tmpdir
    test_file = tmpdir.mkdir('test_dir').join('test_file')
    test_output = 'unix:0:system_misc:boot_time 1548249689'
    test_file.write(test_output)
    module = ansible_module_mock.MockAnsibleModule(
        tmpdir=tmpdir.strpath
    )

    module.run_command.return_value = (0, test_output, '')
    sunoshardware = SunOSHardware(module)
    uptime_facts = sunoshardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - int(test_output.split('\t')[1]))



# Generated at 2022-06-22 23:33:20.726899
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()

    facts = m.get_dmi_facts()

    assert 'system_vendor' in facts
    assert 'product_name' in facts

# Generated at 2022-06-22 23:33:22.880775
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hw_facts = SunOSHardware()
    dmi_facts = hw_facts.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'QEMU'
    assert dmi_facts['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'


# Generated at 2022-06-22 23:33:35.393727
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    # System Configuration: Sun Microsystems sun4v
    out = """System Configuration: Sun Microsystems sun4v
System clock frequency: 1000 MHz
Memory size: 32768 Megabytes
System IO bus frequency: 500 MHz
===========================================================
                        CPUs:
===========================================================
"""
    dmi_facts = hardware.get_dmi_facts(out)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4v'

    # System Configuration: VMware, Inc. VMware Virtual Platform
    out = """System Configuration: VMware, Inc. VMware Virtual Platform
System clock frequency: 1000 MHz
Memory size: 2048 Megabytes
System IO bus frequency: 500 MHz
===========================================================
                        CPUs:
===========================================================
"""
    d

# Generated at 2022-06-22 23:33:38.254212
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test with fair input
    SunOSHardwareCollector([{'platform': 'SunOS'}])

    # Test with empty/null
    SunOSHardwareCollector([{'platform': None}])

# Generated at 2022-06-22 23:33:40.242425
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sun_facts = SunOSHardware({})
    assert isinstance(sun_facts, dict)


# Generated at 2022-06-22 23:33:52.810932
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = mock.MagicMock()
    hardware = SunOSHardware(module)

# Generated at 2022-06-22 23:33:58.864074
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('', (), {'run_command': lambda x: (0, 'Memory size: 512 Megabytes', None)})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    memory_facts = hardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 512


# Generated at 2022-06-22 23:34:08.502045
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test get_device_facts function of SunOSHardware

    Args:
        None

    Returns:
        None

    """
    # Get hardware object to test
    hardware_obj = SunOSHardware({}, {}, {}, {})

    device_facts = hardware_obj.get_device_facts()
    # Validate the test device_facts object
    assert device_facts is not None
    # Validate that the devices dictionary is populated
    assert device_facts.get('devices') is not None
    # Validate that at least one device exists
    assert device_facts['devices'].keys() is not None

# Generated at 2022-06-22 23:34:18.286375
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock()


# Generated at 2022-06-22 23:34:30.019132
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    _get_cpu_facts = SunOSHardware.get_cpu_facts
    SunOSHardware.get_cpu_facts = Mock()
    SunOSHardware.get_cpu_facts.return_value = {'processor': [], 'processor_count': 3, 'processor_cores': 12}

    module = {
        'run_command.return_value': ('', '', '')
    }
    set_module_args(
        dict(
            gather_subset=[
                'all',
            ],
        )
    )
    result = SunOSHardwareCollector.collect(module=module)
    cpu_facts

# Generated at 2022-06-22 23:34:42.086759
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    class MockModule:
        def __init__(self):
            self.run_command_environ_update = None
            self.params = dict()

        def run_command(self, cmd, environ_update=None):
            self.run_command_environ_update = environ_update
            return 0, cmd, ""

        def get_bin_path(self, cmd, opt_dirs=None):
            return "command_not_implemented"

    class MockHardware:
        def __init__(self):
            self.facts = dict()
            self.default_facts = dict()
            self.subsets = dict()

        def get(self, fact, default=None, force=False, strict_fact=False):
            return self.facts.get(fact, default)


# Generated at 2022-06-22 23:34:50.603483
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sparc_prtdiag = """System Configuration: Sun Microsystems sun4u
        Sun Fire V440"""
    x86_prtdiag = """System Configuration: Oracle Corporation sun4v
        Sun Fire X4540"""

    hardware_facts = SunOSHardware({})
    hardware_facts.module = MagicMock()
    hardware_facts.module.run_command = MagicMock(
        return_value=(0, sparc_prtdiag, ''))
    dmi_facts = hardware_facts.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V440'


# Generated at 2022-06-22 23:35:00.800770
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # ARRANGE
    module = FakeAnsibleModule()

    # ACT
    SunOSHardware(module).get_cpu_facts()

    # ASSERT
    assert module.params.get('ansible_processor_count') == 1
    assert module.params.get('ansible_processor_cores') == 1
    assert module.params.get('ansible_processor')[0] == 'Intel(r) Xeon(r) CPU E5-2650 v2 @ 2.60GHz'

