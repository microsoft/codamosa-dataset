

# Generated at 2022-06-22 23:25:08.377812
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:25:18.365818
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Check if method get_device_facts returns correct disk information.
    """

# Generated at 2022-06-22 23:25:21.705308
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    boot_time = int(time.time()) - 3600
    uptime_facts = hardware.get_uptime_facts(boot_time)
    assert uptime_facts['uptime_seconds'] == 3600


# Generated at 2022-06-22 23:25:28.006399
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({'kernel': 'SunOS'})
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, "sderr:0:sd0,err:Predictive Failure Analysis     0", '')

    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {}

# Generated at 2022-06-22 23:25:28.830566
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    SunOSHardware({})

# Generated at 2022-06-22 23:25:33.884842
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_module = AnsibleModule(
        argument_spec={
        },
        supports_check_mode=True
    )

    test_SunOSHardware = SunOSHardware(module=test_module)

    dmi_facts = test_SunOSHardware.get_dmi_facts()

    assert 'system_vendor' in dmi_facts, dmi_facts



# Generated at 2022-06-22 23:25:36.337796
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])
    assert SunOSHardwareCollector._fact_class == SunOSHardware


# Generated at 2022-06-22 23:25:45.493736
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('', (), {})()
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.run_command_environ_update = None

    fact = SunOSHardware(module)

    expected = {
        'processor': [
            'SPARC-Enterprise-T5120 @ 1600MHz'],
        'processor_count': 1,
        'processor_cores': 32,
    }

    assert fact.get_cpu_facts() == expected

# Generated at 2022-06-22 23:25:54.724310
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    hardware = SunOSHardware(module=module)
    hardware.module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems  sun4u', None))
    assert hardware.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

    hardware.module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation  sun4u', None))
    assert hardware.get_dmi_facts() == {'product_name': 'sun4u', 'system_vendor': 'Oracle Corporation'}


# Generated at 2022-06-22 23:25:58.726370
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sunos_facts = SunOSHardware()
    mem_facts = sunos_facts.get_memory_facts()
    assert 'memtotal_mb' in mem_facts
    assert 'swapfree_mb' in mem_facts
    assert 'swaptotal_mb' in mem_facts
    assert 'swap_allocated_mb' in mem_facts
    assert 'swap_reserved_mb' in mem_facts

# Generated at 2022-06-22 23:26:01.291120
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeAnsibleModule(platform='SunOS')
    sunos_hw = SunOSHardware(module)
    uptime_facts = sunos_hw.get_uptime_facts()

    assert ('uptime_seconds' in uptime_facts)

# Generated at 2022-06-22 23:26:05.944613
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    This test ensures that all variables for the SunOSHardwareCollector class
    are set properly
    """
    obj = SunOSHardwareCollector()

    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'
    assert obj.required_facts == set(['platform'])

# Generated at 2022-06-22 23:26:18.821068
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import io

    # Set up the class
    hardware = SunOSHardware(None)

    # Set up the mocked module
    module = MagicMock()

    # Run mkdir
    hardware.module = module
    hardware.module.run_command.return_value = 0, '', ''

# Generated at 2022-06-22 23:26:28.335577
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class SunOSHardware
    """
    facts = SunOSHardware({})
    cpu_facts = facts.get_cpu_facts()
    assert 'ansible_processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert cpu_facts['processor_count'] > 0
    if cpu_facts['processor_cores'] != 'NA':
        assert cpu_facts['processor_cores'] > 0
    assert len(cpu_facts['processor']) == cpu_facts['processor_count']

# Generated at 2022-06-22 23:26:40.322288
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class RunModule(object):
        def __init__(self, out, rc=0, err=""):
            self.out = out
            self.rc = rc
            self.err = err

        def run_command(self, cmd, check_rc=False):
            return self.rc, self.out, self.err

    test_cases = (
        (None, 0),  # No output
        ("unix:0:system_misc:boot_time    1548249689\n", int(time.time()) - 1548249689),  # Valid output
        ("", 0),  # Empty output
    )
    for test_case in test_cases:
        run_module = RunModule(test_case[0])
        s = SunOSHardware(run_module)

# Generated at 2022-06-22 23:26:44.486013
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert isinstance(hardware_collector, SunOSHardwareCollector)
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == {'platform'}

# Generated at 2022-06-22 23:26:56.146502
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:27:08.468210
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, args, check_rc=False, close_fds=True,
                        executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

# Generated at 2022-06-22 23:27:22.506807
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:34.006195
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-22 23:27:39.157896
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Run populate() method of SunOSHardware to make sure it runs smoothly
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sunoshw = SunOSHardware(module)
    sunoshw.populate()

# Generated at 2022-06-22 23:27:41.179484
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x.__class__.__name__ == 'SunOSHardwareCollector'

# Generated at 2022-06-22 23:27:47.254527
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert isinstance(hardware_collector, HardwareCollector)
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])


# ------------------------------

# Generated at 2022-06-22 23:27:55.449885
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import mock
    from ansible.module_utils.facts.utils import TimeoutError

    m = mock.Mock(spec=SunOSHardware)

    # Fail with kstat not present
    m.run_command.return_value = (1, '', '')
    uptime_facts = m.get_uptime_facts()
    assert uptime_facts == {}

    # Pass with kstat present
    m.reset_mock()
    m.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')
    uptime_facts = m.get_uptime_facts()

# Generated at 2022-06-22 23:27:58.120477
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = SunOSHardwareCollector()

    assert (facts.platform == 'SunOS')  # class-level
    assert (facts.required_facts == {'platform'})  # class-level

# Generated at 2022-06-22 23:27:59.822126
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    s = SunOSHardware(module)
    assert s is not None

# Generated at 2022-06-22 23:28:02.363924
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware_instance = SunOSHardware(module)
    assert hardware_instance is not None


# Generated at 2022-06-22 23:28:06.597802
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x._fact_class == SunOSHardware
    assert x._platform == 'SunOS'

# Generated at 2022-06-22 23:28:14.846464
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock_returning_values(['/usr/bin/uname -i', 'i86pc', 0, '', ''],
                                                           ['/usr/sbin/prtdiag', '', 0, 'System Configuration: Oracle Corporation VirtualBox\n', ''])
    device_facts = SunOSHardware(module).get_dmi_facts()
    assert device_facts['system_vendor'] == 'Oracle Corporation'
    assert device_facts['product_name'] == 'VirtualBox'



# Generated at 2022-06-22 23:28:18.178913
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )
    hardware_obj = SunOSHardware(module)
    hardware_obj.get_memory_facts()

# Generated at 2022-06-22 23:28:30.107373
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule():
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
        def run_command(self, args, **kwargs):
            # capture command for unit testing
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)
    class MockSystemTime():
        def __init__(self, value):
            self.time_value = value
        def time(self):
            return self.time_value
    kstat_results = [0, 'unix:0:system_misc:boot_time\t1548249689\n']
    current_time_value = 1548249689 + 60 * 60 * 24 * 5
    uptime_facts = {}

# Generated at 2022-06-22 23:28:36.240259
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = None
    mem_facts = SunOSHardware(module).get_memory_facts()

    assert mem_facts['swapfree_mb'] >= 0
    assert mem_facts['swaptotal_mb'] > 0
    assert mem_facts['swap_allocated_mb'] >= 0
    assert mem_facts['swap_reserved_mb'] >= 0
    assert isinstance(mem_facts['swapfree_mb'], int)
    assert isinstance(mem_facts['swaptotal_mb'], int)
    assert isinstance(mem_facts['swap_allocated_mb'], int)
    assert isinstance(mem_facts['swap_reserved_mb'], int)



# Generated at 2022-06-22 23:28:45.015779
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    hardware_obj = SunOSHardware(module)
    hardware_obj.module.run_command = run_command_mock
    assert hardware_obj.get_cpu_facts() == {
        'processor': ['SPARC64-VII @ 2400MHz'],
        'processor_count': 2,
        'processor_cores': 8
    }


# Generated at 2022-06-22 23:28:58.021878
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardwareCollector.collect(module=module, collected_facts=dict())
    # Assert that 'ansible_facts' key is present in hardware
    assert 'ansible_facts' in hardware
    # Assert that 'ansible_devices' key is present in hardware['ansible_facts']
    assert 'ansible_devices' in hardware['ansible_facts']
    # Assert that:
    #   - 'ansible_processor' key is present in hardware['ansible_facts']
    #   - 'ansible_processor_count' key is present in hardware['ansible_facts']
    #   - 'ansible_processor_cores' key is present in hardware['ansible_facts']
    #   - 'ansible_processor_threads_per_core'

# Generated at 2022-06-22 23:29:03.456109
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    har = SunOSHardware(module)
    facts = har.populate()

    assert 'devices' in facts
    facts['devices'] = []
    assert 'memtotal_mb' in facts
    assert 'system_vendor' in facts
    assert 'uptime_seconds' in facts

# Generated at 2022-06-22 23:29:14.765553
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    h = SunOSHardware()
    h_facts = h.populate()
    assert 'devices' in h_facts
    assert isinstance(h_facts['devices'], dict)
    assert 'mounts' in h_facts
    assert isinstance(h_facts['mounts'], list)
    assert 'memtotal_mb' in h_facts
    assert isinstance(h_facts['memtotal_mb'], int)
    assert 'swapfree_mb' in h_facts
    assert isinstance(h_facts['swapfree_mb'], int)
    assert 'swaptotal_mb' in h_facts
    assert isinstance(h_facts['swaptotal_mb'], int)
    assert 'swap_allocated_mb' in h_facts

# Generated at 2022-06-22 23:29:19.279895
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_stub
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 100


# Generated at 2022-06-22 23:29:25.832816
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()

    facts = SunOSHardware(module).get_memory_facts()

    assert facts['swapfree_mb'] == 16384
    assert facts['swaptotal_mb'] == 32768
    assert facts['swap_allocated_mb'] == 16384
    assert facts['swap_reserved_mb'] == 0


# Generated at 2022-06-22 23:29:27.459475
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector is not None

# Generated at 2022-06-22 23:29:29.458317
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Returns the name of the class.
    """
    return SunOSHardwareCollector().__class__.__name__

# Generated at 2022-06-22 23:29:38.217739
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Set up fake module and platform with prtconf output
    module = FakeModule()
    platform = FakeSunOSHardware()
    platform.prtconf = FakePrtconf()
    platform.swap = FakeSwap()
    setattr(module, "get_bin_path", lambda x, opt_dirs=None: x)

    # Get memory facts
    memory_facts = SunOSHardware(module).get_memory_facts()

    # Assert facts are correct
    assert memory_facts['memtotal_mb'] == 512
    assert memory_facts['swapfree_mb'] == 98
    assert memory_facts['swaptotal_mb'] == 113
    assert memory_facts['swap_allocated_mb'] == 0
    assert memory_facts['swap_reserved_mb'] == 15



# Generated at 2022-06-22 23:29:43.969312
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.required_facts == {'platform'}
    assert collector.collectable_facts == ['all']
    assert collector._fact_class == SunOSHardware



# Generated at 2022-06-22 23:29:52.382303
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """ Check the results of a run of SunOSHardware.populate() """


# Generated at 2022-06-22 23:30:05.728375
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_class = SunOSHardware()

# Generated at 2022-06-22 23:30:18.234000
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()

    hardware_facts = hardware.populate()

    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['processor'] == [
        'SPARC64-VII (chipid 0, clock 3003 MHz) @ 3003MHz',
        'SPARC64-VII (chipid 1, clock 3003 MHz) @ 3003MHz'
    ]
    assert hardware_facts['swapfree_mb'] == 17096
    assert hardware_facts['swaptotal_mb'] == 17096
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['memtotal_mb'] == 131072

# Generated at 2022-06-22 23:30:27.485938
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule(object):
        def run_command(self, args):
            return 1, "/dev/dsk/c1t2d0s2", None

    class MockHardware(SunOSHardware):
        def __init__(self, module):
            self.module = module

    module = MockModule()
    hardware = MockHardware(module)
    device_facts = hardware.get_device_facts()

    assert 'devices' in device_facts
    assert 'c1t2d0s2' in device_facts['devices']

# Generated at 2022-06-22 23:30:40.096721
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()
    sunos = SunOSHardware(module)


# Generated at 2022-06-22 23:30:51.561331
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = Mock(params={})
    hardware = SunOSHardware(module)
    collected_facts = dict()

    # test for bare system (no cpu and memory)
    collected_facts['ansible_machine'] = 'sparc64'
    out = hardware.populate(collected_facts=collected_facts)

# Generated at 2022-06-22 23:30:58.292010
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = runCommandMock
    sunoshw = SunOSHardware(module)
    mem_facts = sunoshw.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 2048
    assert mem_facts['swapfree_mb'] == 511
    assert mem_facts['swaptotal_mb'] == 512
    assert mem_facts['swap_allocated_mb'] == 511
    assert mem_facts['swap_reserved_mb'] == 511


# Generated at 2022-06-22 23:31:09.461389
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    s = SunOSHardware()

    s.module.run_command = mock.Mock(return_value=(0, "System Configuration: Oracle Corporation sun4u\n", ""))
    assert s.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4u'}

    s.module.run_command = mock.Mock(return_value=(0, "System Configuration: Oracle Corporation sun4v", ""))
    assert s.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}

    s.module.run_command = mock.Mock(return_value=(2, "", ""))
    assert s.get_d

# Generated at 2022-06-22 23:31:21.982349
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-22 23:31:32.484926
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Create a mock kstat output
    tempfile = '/tmp/kstat_uptime_output.tmp'
    with open(tempfile, "w") as temp:
        temp.write("unix:0:system_misc:boot_time    1560787600\n")

    try:
        module = AnsibleModuleMock()
        s = SunOSHardware(module)
        s.get_uptime_facts_from_kstat = lambda: tempfile
        assert s.get_uptime_facts()['uptime_seconds'] == 1560818079 - 1560787600
    finally:
        rm_f(tempfile)



# Generated at 2022-06-22 23:31:39.551220
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-22 23:31:43.241421
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    sunos = SunOSHardware(module)
    assert sunos.module
    assert sunos.platform
    assert sunos.populate()


# Generated at 2022-06-22 23:31:47.900391
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import pytest
    hw = SunOSHardware()

    with pytest.raises(AssertionError):
        hw.get_uptime_facts()

    hw.module = MockModule()
    assert hw.get_uptime_facts() == {'uptime_seconds': 1548249696}



# Generated at 2022-06-22 23:31:50.703713
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    assert SunOSHardware({}).get_dmi_facts() == {}

# Generated at 2022-06-22 23:31:56.013033
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector._platform == 'SunOS'
    assert isinstance(hardware_collector._fact_class, SunOSHardware)

# Generated at 2022-06-22 23:32:04.778495
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-22 23:32:09.577633
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:32:21.513382
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict())

    assert hardware.platform == 'SunOS'
    assert hardware.populate() == {'processor': ['Intel(r) Xeon(r) CPU E5-2680 0 @ 2.70GHz @ 2700MHz'],
                                   'memtotal_mb': 65536,
                                   'swapfree_mb': 12286,
                                   'swaptotal_mb': 12700,
                                   'swap_allocated_mb': 415,
                                   'swap_reserved_mb': 415,
                                   'devices': {},
                                   'uptime_seconds': 0,
                                   'system_vendor': 'QEMU',
                                   'product_name': 'Standard PC (i440FX + PIIX, 1996)'}

# Generated at 2022-06-22 23:32:23.481205
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    SunOSHardware(module=module)



# Generated at 2022-06-22 23:32:25.411425
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'


# Generated at 2022-06-22 23:32:27.934112
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # This has to be a function to enable using fixtures
    assert SunOSHardwareCollector._platform == 'SunOS'
    assert SunOSHardwareCollector.required_facts == set(['platform'])

# Generated at 2022-06-22 23:32:30.838620
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw = SunOSHardwareCollector()
    assert hw.platform == 'SunOS'



# Generated at 2022-06-22 23:32:33.901263
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw = SunOSHardwareCollector({'platform': 'SunOS'})
    assert isinstance(hw, SunOSHardwareCollector)
    assert isinstance(hw.collect(), SunOSHardware)

# Generated at 2022-06-22 23:32:39.501033
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, 'Memory size: 65536 Megabytes', '')

    hardware_obj = SunOSHardware(module_mock)
    result = hardware_obj.get_memory_facts()

    assert 'memtotal_mb' in result
    assert result['memtotal_mb'] == 65536



# Generated at 2022-06-22 23:32:43.092748
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict(ansible_facts=dict(platform="SunOS"), module=None))
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-22 23:32:55.558068
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import json
    import tempfile
    import os

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as prtconf:
        # Mock the output of prtconf command.
        prtconf.write('\n')
        prtconf.write('Memory size: 64 Megabytes')
        prtconf.write('\n')


# Generated at 2022-06-22 23:33:02.271989
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    module = MockModule()
    hardware = SunOSHardware(module=module)

    # Populate expected results
    module.run_command_results.append((0, 'System Configuration: VMware, Inc. VMware Virtual Platform', ''))

# Generated at 2022-06-22 23:33:03.282265
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = SunOSHardware()
    assert isinstance(facts, SunOSHardware)

# Generated at 2022-06-22 23:33:15.374515
# Unit test for method get_uptime_facts of class SunOSHardware

# Generated at 2022-06-22 23:33:27.081503
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()

    facts = SunOSHardware(module)
    assert isinstance(facts, SunOSHardware)
    assert isinstance(facts, Hardware)
    assert facts.platform == 'SunOS'

    # Test some individual facts

    # Test device fact
    facts.get_device_facts()
    for device in facts.device_facts['devices'].values():
        assert len(device.get('vendor', '')) > 0
        assert len(device.get('product', '')) > 0
        assert device.get('revision', '') != ''
        assert device.get('serial', '') != ''
        assert device.get('size', '') != ''
        assert device.get('hard_errors', '') != ''
        assert device.get('soft_errors', '') != ''

# Generated at 2022-06-22 23:33:29.791238
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = SunOSHardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-22 23:33:35.743986
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Test that the populate() method of SunOSHardware only retrieves
    facts supported on SunOS platforms.
    """
    facts = SunOSHardware(dict(), dict()).populate()

    unsupported_facts = set(['dmi', 'devices', 'mounts'])

    assert facts.keys() == SunOSHardware.supported_facts - unsupported_facts

# Generated at 2022-06-22 23:33:43.575973
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Test case to check the SunOSHardware class
    """

    # Creating a test dict for prtconf output
    prtconf_dict = dict()
    prtconf_dict['rc'] = 0
    prtconf_dict['stdout'] = '''
        System Configuration: VMware, Inc. VMware Virtual Platform
        Memory size: 4096 Megabytes
        '''
    prtconf_dict['stderr'] = ''

    # Creating a test dict for swap output
    swap_dict = dict()
    swap_dict['rc'] = 0
    swap_dict['stdout'] = '''
        allocation   reservation   heap    pagesize swap   total
        ----------   -----------   -----   -------- -----   -----
        556M           0M            0M       8k   556M   556M
        '''
    swap_

# Generated at 2022-06-22 23:33:47.060894
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware().get_memory_facts()
    assert mem_facts['memtotal_mb']

    return mem_facts

# Generated at 2022-06-22 23:33:56.293866
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    tests = [
        {
            'uname': 'SunOS x86',
            'prtdiag': 'System Configuration: VMware, Inc. VMware Virtual Platform\n',
            'dmi': {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}
        },
        {
            'uname': 'SunOS x86',
            'prtdiag': 'System Configuration: VMware, Inc. VMware Virtual Platform\n',
            'dmi': {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}
        },
    ]

    from ansible.module_utils.facts import ansible_get_module_func

# Generated at 2022-06-22 23:34:08.664297
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    import os

    class dummy():
        def __init__(self, test_dir=None):
            class dummymodule():
                def get_bin_path(self, *args, **kwargs):
                    return os.path.join(test_dir, *args)

            self.module = dummymodule()

    test_dir = os.path.dirname(__file__)
    h = SunOSHardware(dummy(test_dir))

    facts = h.get_memory_facts()

    assert(facts['memtotal_mb'] == 8)
    assert(facts['swapfree_mb'] == 10)
    assert(facts['swaptotal_mb'] == 15)
    assert(facts['swap_allocated_mb'] == 5)
    assert(facts['swap_reserved_mb'] == 2)

# Generated at 2022-06-22 23:34:10.178198
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({})
    assert hardware

# Generated at 2022-06-22 23:34:18.286945
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec={},
    )
    hardware = SunOSHardware(module)

    # validating truthy output
    assert hardware.get_cpu_facts()

    # validating truthy output
    assert hardware.get_memory_facts()

    # validating truthy output
    assert hardware.get_dmi_facts()

    # validating truthy output
    assert hardware.get_device_facts()

    # validating truthy output
    assert hardware.get_uptime_facts()

    # validating falsey output
    # timeoutError exception raised when no output is received in 5 secs
    assert hardware.get_mount_facts()

# Generated at 2022-06-22 23:34:21.703914
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware


# Generated at 2022-06-22 23:34:28.257143
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_facts = SunOSHardware({"platform": "SunOS"})

    assert hardware_facts._get_cpu_facts()

    assert hardware_facts._get_device_facts()

    assert hardware_facts._get_dmi_facts()

    assert hardware_facts._get_memory_facts()

    assert hardware_facts._get_mount_facts()

    assert hardware_facts._get_uptime_facts()

# Generated at 2022-06-22 23:34:40.234983
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    warnings = []
    facts = dict(ansible_facts=dict(
        ansible_machine='i86pc',
        ansible_system='SunOS',
        ansible_processor=['Genuine Intel(R) CPU U7300  @ 1.30GHz', 'Genuine Intel(R) CPU U7300  @ 1.30GHz'],
    ))

    hardware_collector = SunOSHardware(module=module, facts=facts, warnings=warnings)

# Generated at 2022-06-22 23:34:42.129293
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_shell = SunOSHardware()
    assert test_shell.get_memory_facts() is not None

# Generated at 2022-06-22 23:34:46.213732
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()
    output = 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)'
    m.run_command = lambda x: (0, output, None)
    assert m.get_dmi_facts() == {'system_vendor': 'QEMU', 'product_name': 'Standard PC (i440FX + PIIX, 1996)'}

# Generated at 2022-06-22 23:34:53.892137
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware(dict())
    platform = 'i86pc'
    prtdiag_output = 'System Configuration: Oracle Corporation VirtualBox\n'
    hardware.module.get_bin_path = lambda x, opt_dirs: x
    hardware.module.run_command = lambda x: (0, prtdiag_output, '')
    hardware.facts['ansible_machine'] = platform
    hardware_facts = hardware.get_dmi_facts()

    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'VirtualBox'

    hardware = SunOSHardware(dict())
    platform = 'sparc'
    prtdiag_output = 'System Configuration: VMware, Inc. VMware Virtual Platform\n'

# Generated at 2022-06-22 23:35:01.063878
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware().get_memory_facts()
    assert 'memtotal_mb' in mem_facts
    assert 'swapfree_mb' in mem_facts
    assert 'swaptotal_mb' in mem_facts
    assert 'swap_allocated_mb' in mem_facts
    assert 'swap_reserved_mb' in mem_facts