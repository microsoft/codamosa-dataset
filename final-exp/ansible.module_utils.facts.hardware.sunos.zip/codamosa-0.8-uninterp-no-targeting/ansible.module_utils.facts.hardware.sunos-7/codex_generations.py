

# Generated at 2022-06-20 17:38:44.946085
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    my_sunos_hardware = SunOSHardware({'ansible_machine': 'i86pc'})
    assert my_sunos_hardware.get_cpu_facts() == {}
    assert my_sunos_hardware.get_memory_facts() == {}
    assert my_sunos_hardware.get_dmi_facts() == {}
    assert my_sunos_hardware.get_device_facts() == {}
    assert my_sunos_hardware.get_uptime_facts() == {}

# Generated at 2022-06-20 17:38:46.023435
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(dict())
    assert hardware

# Generated at 2022-06-20 17:38:47.595026
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec={},
    )



# Generated at 2022-06-20 17:38:53.590876
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = SunOSHardware._create_module_mock()
    module.run_command.return_value = (0, 'a_string', '')
    module.get_bin_path.return_value = '/usr/bin/prtdiag'

    hardware = SunOSHardware(module)

    hardware.populate()

    assert module.run_command.call_count == 8

# Generated at 2022-06-20 17:39:05.821668
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:13.068618
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hObj = SunOSHardware()

    hObj.module.run_command = lambda *args, **kwargs: (0, FAKE_PRT_CONF, "")
    hObj.module.get_bin_path = lambda *args, **kwargs: "/usr/sbin/prtconf"
    hObj.module.run_command = lambda *args, **kwargs: (0, FAKE_SWAP_S, "")
    hObj.module.get_file_content = lambda *args, **kwargs: ""

    facts = hObj.populate()
    assert facts['memtotal_mb'] == 3072
    assert facts['swapfree_mb'] == 1626
    assert facts['swaptotal_mb'] == 4799
    assert facts['swap_allocated_mb'] == 2048

# Generated at 2022-06-20 17:39:14.680275
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert issubclass(SunOSHardwareCollector, HardwareCollector)


# Generated at 2022-06-20 17:39:17.630149
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    src = SunOSHardware()
    assert 'uptime_seconds' in src.get_uptime_facts(), 'test for get_uptime_facts failed!'

# Generated at 2022-06-20 17:39:29.375402
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    fact_class = SunOSHardware()

    # Test case using a mocked class that provides a run_command
    # method that returns a specific kstat output
    class MockModule:
        def run_command(self, cmd):
            return (0, "unix::system_misc:boot_time\t{}".format(
                int((datetime.datetime.now() - datetime.timedelta(days=1)).timestamp())), "")

    fact_class.module = MockModule()
    assert fact_class.get_uptime_facts() == {'uptime_seconds': 86400}

    # Test case using a mocked class that provides a run_command
    # method that returns a specific kstat output (kstat output using seconds in decimal)

# Generated at 2022-06-20 17:39:38.036695
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.hardware.sunos_hardware import SunOSHardware
    sunos = SunOSHardware()
    hardware = sunos.populate()

    assert hardware.get('processor')
    assert hardware.get('processor_cores')
    assert hardware.get('processor_count')
    assert hardware.get('memtotal_mb')
    assert hardware.get('swapfree_mb')
    assert hardware.get('swaptotal_mb')
    assert hardware.get('system_vendor')
    assert hardware.get('product_name')
    assert hardware.get('devices')

# Generated at 2022-06-20 17:39:58.448516
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """Unit test for SunOSHardwareCollector"""
    sunos_hw_collector = SunOSHardwareCollector()
    assert sunos_hw_collector.facts is None
    assert sunos_hw_collector._platform == 'SunOS'

# Generated at 2022-06-20 17:40:02.182863
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    '''Check if uptime calculated correctly'''
    uptime_facts = SunOSHardware.get_uptime_facts()
    assert type(uptime_facts) == dict

    # test if uptime is not too high nor too low
    assert uptime_facts['uptime_seconds'] < 2160000
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:40:09.763745
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    hardware = SunOSHardware()
    hardware_populate = hardware.populate()

    collector = Collector()
    facts = Facts(collector)
    hardware_populate_facts = SunOSHardware(collector).populate()

    assert hardware_populate == hardware_populate_facts

# Generated at 2022-06-20 17:40:16.867541
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import sys
    import platform

    test_module = sys.modules[__name__]


# Generated at 2022-06-20 17:40:20.514092
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sut = SunOSHardwareCollector()
    assert sut is not None

if __name__ == '__main__':
    # Run unit tests
    test_SunOSHardwareCollector()

# Generated at 2022-06-20 17:40:30.326567
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import unittest.mock as mock

    result = b'unix:0:system_misc:boot_time\t1548249689'

    class SunOSHardwareFakeModule(object):
        def __init__(self):
            self.run_command_results = [(0, result, '')]

        def run_command(self, args):
            return self.run_command_results.pop()

    facts = SunOSHardware()
    facts.module = SunOSHardwareFakeModule()

    expected = {'uptime_seconds': 1548342265 - 1548249689}
    actual = facts.get_uptime_facts()

    assert expected == actual

# Generated at 2022-06-20 17:40:41.792964
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Add parameters needed for the specific test here
    module_args = {}
    out = ''
    err = ''
    result = None

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # Get the class to test
    SunOSHardwareCollectorTest = SunOSHardwareCollector()
    SunOSHardwareTest = SunOSHardware()

    # Get the facts from the system
    SunOSHardwareFacts = SunOSHardwareCollectorTest.collect(module=module, collected_facts=module.params)

    # Populate the module facts from the system facts
    SunOSHardwareFacts = SunOSHardwareTest.populate(SunOSHardwareFacts)


# Generated at 2022-06-20 17:40:53.139977
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Mock module's run_command
    mock_module = type('Module', (object,), {"run_command": mock_run_command})()
    # Mock facts
    sunos_hardware = SunOSHardware(module=mock_module)

    result = sunos_hardware.get_memory_facts()
    # Returned values are in MB
    assert result['memtotal_mb'] == 35995
    # Swap space has been added in bytes
    assert result['swapfree_mb'] == 32828
    assert result['swaptotal_mb'] == 63831
    assert result['swap_allocated_mb'] == 2583
    assert result['swap_reserved_mb'] == 1048568


# Generated at 2022-06-20 17:40:58.437173
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command
    sunos_hardware = SunOSHardware(module)
    module.fail_json = AnsibleModuleMock.fail_json
    sunos_hardware.get_cpu_facts = AnsibleModuleMock.get_cpu_facts
    sunos_hardware.get_memory_facts = AnsibleModuleMock.get_memory_facts
    sunos_hardware.get_dmi_facts = AnsibleModuleMock.get_dmi_facts
    sunos_hardware.get_uptime_facts = AnsibleModuleMock.get_uptime_facts
    sunos_hardware.get_mount_facts = AnsibleModuleMock.get_mount_facts
    sunos_hardware.get_device_facts

# Generated at 2022-06-20 17:41:08.610912
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class RunCommand(object):
        def __init__(self):
            self.call_count = 0

        def __call__(self, command):
            result = 0

            if command[-1] == 'Hard Errors':
                result = 1
                stdout = 'sderr:0:sd0,err:Hard Errors     0\nsderr:0:sd1,err:Hard Errors     1\n'
            elif command[-1] == 'Serial No':
                result = 1
                stdout = 'sderr:0:sd0,err:Serial No       VB0ad2ec4d-074a\nsderr:0:sd1,err:Serial No       VB0ad2ec4d-074c\n'
            elif command[-1] == 'Size':
                result = 1


# Generated at 2022-06-20 17:41:30.647908
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class is SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == {'platform'}

# Generated at 2022-06-20 17:41:33.156092
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # initialize test class
    hardware = SunOSHardware(None)

    # check if the class variables are correctly set
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:41:37.854306
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    from collections import defaultdict
    module = defaultdict(lambda: None)

    inventory = SunOSHardware(module)

    assert inventory.module.run_command('dummy') == (None, None, None), 'Expected return value is None, None, None'

# Generated at 2022-06-20 17:41:47.076723
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule(object):
        def run_command(self, args, check_rc=False):
            class MockRc(object):
                def __init__(self, out, rc=0, err=None):
                    self.out = out
                    self.rc = rc
                    self.err = err

                def is_success(self):
                    return self.rc == 0


# Generated at 2022-06-20 17:41:53.380128
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Run tests with different environment variables
    import os, tempfile
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Verify that object is an instance of the correct class
    assert isinstance(SunOSHardwareCollector(None, None, None), SunOSHardwareCollector)

    # Verify that the object is an instance of BaseFactCollector
    assert isinstance(SunOSHardwareCollector(None, None, None), BaseFactCollector)

# Generated at 2022-06-20 17:41:54.865485
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    SunOSHardware_obj = SunOSHardware(dict())
    SunOSHardware_obj.populate()

# Generated at 2022-06-20 17:42:04.514412
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import subprocess

    hw = SunOSHardware()
    uptime_fact = hw.get_uptime_facts()

    proc = subprocess.Popen(['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time'], stdout=subprocess.PIPE)
    boot_time, err = proc.communicate()
    boot_time = int(boot_time.split('\t')[1])

    assert uptime_fact['uptime_seconds'] == int(time.time() - boot_time)


# Generated at 2022-06-20 17:42:07.683236
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    result = SunOSHardwareCollector()
    assert result._platform == 'SunOS'
    assert result._fact_class == SunOSHardware
    assert result.required_facts == set(['platform'])



# Generated at 2022-06-20 17:42:12.256232
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Test constructor with given data
    h = SunOSHardware(dict(ansible_facts=dict(platform='SunOS',
                                              somefact='somevalue')))

    # Test platform attribute
    assert h.platform == 'SunOS'
    # Test _collected_facts attribute
    assert h._collected_facts == dict(platform='SunOS',
                                      somefact='somevalue')



# Generated at 2022-06-20 17:42:24.620214
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    facts = SunOSHardware(module).populate()

    # test cpu
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts

    # test memory
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts

    # test dmi
    assert 'system_vendor' in facts
    assert 'product_name' in facts

    # test devices
    # assert 'devices' in facts
    assert 'uptime_seconds' in facts

    # test mount
    assert 'mounts' in facts



# Generated at 2022-06-20 17:43:05.362440
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware()
    hardware._module = module
    dmi_facts = hardware.get_dmi_facts()
    assert(re.match('(?: sun[a-z]{1,2})? [0-9a-zA-Z ()-]+',
                    dmi_facts['product_name']))

# Generated at 2022-06-20 17:43:10.389257
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MagicMock()
    module.run_command.return_value = (0, '42', '')

    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()

    assert hardware_obj.facts['memtotal_mb'] == 42
# vim:set et sts=4 ts=4 tw=80:

# Generated at 2022-06-20 17:43:23.162931
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Unit test class SunOSHardware specific function get_memory_facts.
    """
    import mock
    import textwrap

    hardware = SunOSHardware(mock.Mock())

    # Check the code when prtconf returns an output with a Memory size field
    hardware.module.run_command = mock.Mock(return_value=[0, 'Memory size: 8192 Megabytes', ''])

    expected = {'memtotal_mb': 8192}
    result = hardware.get_memory_facts()

    assert result == expected

    # Check the code when prtconf returns an output without a Memory size field
    hardware.module.run_command = mock.Mock(return_value=[0, 'This is an invalid output', ''])

    expected = {}
    result = hardware.get_memory_facts()

    assert result == expected




# Generated at 2022-06-20 17:43:34.038174
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    SunOS = SunOSHardware(module)

    # Populate cpu and memory facts
    facts = SunOS.populate()

    # Test cpu_facts
    assert facts['processor_cores'] > 0

    # Test memory_facts
    assert facts['swapfree_mb'] == facts['memtotal_mb']
    assert facts['swaptotal_mb'] == facts['memtotal_mb']
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0

    # Test dmi_facts
    assert facts['system_vendor'] == 'VMware, Inc.'
    assert facts['product_name'] == 'SUNW,SPARC-Enterprise'


# Generated at 2022-06-20 17:43:35.663784
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware(dict(module=None))

    assert hw.platform == 'SunOS'

# Generated at 2022-06-20 17:43:42.835885
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module_name = 'ansible.module_utils.facts.hardware.sunos.SunOSHardware'
    module = __import__(module_name, fromlist=[''])
    sunos_hw = module.SunOSHardware(None)

    assert sunos_hw.platform == 'SunOS'



# Generated at 2022-06-20 17:43:54.765242
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    facts = {}
    # Get a fake module
    module = type('DummyModule', (object,), {'run_command': (lambda *args, **kwargs: (0, '', ''))})()

    # Create a fake SunOSHardware object
    sunos_hw = SunOSHardware(module)
    # Call the method under test
    device_facts = sunos_hw.get_device_facts()
    # Compare the device_facts with the desired ones

# Generated at 2022-06-20 17:43:59.099485
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    required_facts = set(['platform'])
    collector = SunOSHardwareCollector()
    assert collector.required_facts == required_facts
    assert collector._fact_class is not None
    assert collector._platform == 'SunOS'


# Generated at 2022-06-20 17:44:06.879882
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_module = type('FakeModule', (object,), {'run_command': FakeRunCommand})
    dmi_facts = SunOSHardware(test_module).get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V490'



# Generated at 2022-06-20 17:44:14.850303
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test that the facts are correctly set."""

    import copy
    from ansible_collections.ansible.community.tests.unit.module_utils.facts import AnsibleCoreFactModule

    module = AnsibleCoreFactModule()
    hardware = SunOSHardware(module)
    facts_dict = {}

    # Mock the commands

# Generated at 2022-06-20 17:45:33.944458
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out_prtconf = """Memory size: 32768 Megabytes"""

    out_swap = """swapfile             dev  swaplo blocks   free
swapfile             dev  swaplo blocks   free
/dev/dsk/c0t0d0s1   -      16,4      2047   1016
"""

    m = SunOSHardware()

    m.module.run_command.return_value = (0, out_prtconf, None)
    m.get_memory_facts()
    assert m.module.run_command.called and len(m.module.run_command.call_args_list) == 1

    m.module.run_command.return_value = (0, out_swap, None)
    actual_return = m.get_memory_facts()

# Generated at 2022-06-20 17:45:38.900529
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Test SunOSHardwareCollector constructor.
    """
    sunos_hw_collector = SunOSHardwareCollector()
    assert sunos_hw_collector.platform == 'SunOS'
    assert sunos_hw_collector._fact_class == SunOSHardware
    assert sunos_hw_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:45:40.098748
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    sunoshardware = SunOSHardware()
    assert sunoshardware


# Generated at 2022-06-20 17:45:44.867398
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(
        argument_spec = dict()
    )
    obj = SunOSHardwareCollector(module=module)
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSHardware
    assert obj._required_facts == set(['platform'])

# Generated at 2022-06-20 17:45:54.438039
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'Memory size: 8192 Megabytes', ''))
    module.run_command = MagicMock(return_value=(0, '2048M allocated + 2048M reserved = 4096M used, 4826M available', ''))
    SunOS = SunOSHardware(module)
    facts = SunOS.get_memory_facts()
    assert facts['memtotal_mb'] == 8192
    assert facts['swapfree_mb'] == 4826
    assert facts['swaptotal_mb'] == 8922
    assert facts['swap_allocated_mb'] == 2048
    assert facts['swap_reserved_mb'] == 2048



# Generated at 2022-06-20 17:46:04.799247
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:46:16.967443
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    import json

    # Setup fake ansible module
    fixture_file = open('tests/module_utils/facts/fixtures/sunos_prtconf.txt', 'r')
    prtconf = fixture_file.read()
    fixture_file.close()
    fixture_file = open('tests/module_utils/facts/fixtures/sunos_kstat_cpu_info.txt', 'r')
    kstat_cpu_info = fixture_file.read()
    fixture_file.close()

# Generated at 2022-06-20 17:46:23.072386
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    hardware.module.run_command = MagicMock()
    mocked_out = 'Memory size:\t32768 Megabytes'
    hardware.module.run_command.return_value = (0, mocked_out, '')

    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 32768



# Generated at 2022-06-20 17:46:26.486461
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    s = SunOSHardware()
    class args:
        module = None
    args.module = s
    s.module = args
    s.module.run_command = function
    assert "sderr" in s.get_memory_facts()


# Generated at 2022-06-20 17:46:29.963199
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "Memory size: 32768 Megabytes", "")
    hardware.get_memory_facts()
    assert hardware.facts['memtotal_mb'] == 32768