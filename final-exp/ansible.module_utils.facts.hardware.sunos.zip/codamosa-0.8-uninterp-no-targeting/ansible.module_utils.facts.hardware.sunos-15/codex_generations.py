

# Generated at 2022-06-20 17:38:41.518450
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # GIVEN: A SunOSHardware instance with a module
    module = FakeModule()
    hardware_instance = SunOSHardware(module=module)

    # WHEN: get_cpu_facts is called
    cpu_facts = hardware_instance.get_cpu_facts()

    # THEN: A dictionary containing the processor fact should be returned
    assert cpu_facts['processor'] is not None, "processor fact is None"
    assert len(cpu_facts['processor']) is not 0, "processor list is empty"


# Generated at 2022-06-20 17:38:48.537819
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            if sys.version_info.major == 2:
                self.out = out
            else:
                self.out = bytes(out, "utf-8")
            self.err = err

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    # Test kstat output we expect
    kstat_out = 'unix:0:system_misc:boot_time\t1548249689'

    # set up a test module for testing class SunOSHardware
    module = MockModule(0, kstat_out, '')
    # instantiate the class
    hardware = SunOSHardware(module)

    # call the method
    uptime

# Generated at 2022-06-20 17:38:50.012562
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec=dict(filter=dict(required=False)))
    shared_lib = SunOSHardware(module)
    assert shared_lib.platform == 'SunOS'

# Generated at 2022-06-20 17:39:01.522977
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(argument_spec={})

    sun_hardware = SunOSHardwareCollector.fetch_fact(module)


# Generated at 2022-06-20 17:39:04.641026
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hw_collector = SunOSHardwareCollector()
    assert sunos_hw_collector._fact_class == SunOSHardware

# Generated at 2022-06-20 17:39:12.409338
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Setup test input for populating SunOSHardware facts
    SunOSHardware_obj = SunOSHardware()
    SunOSHardware_obj.module.run_command = mock_run_command
    current_time = 1526285220.0

    # Populate SunOSHardware facts
    SunOSHardware_obj.populate()

    # Assert SunOSHardware facts
    assert SunOSHardware_obj.facts['processor'] == ['GenuineIntel @ 2500MHz']
    assert SunOSHardware_obj.facts['processor_cores'] == 'NA'
    assert SunOSHardware_obj.facts['processor_count'] == 2
    assert SunOSHardware_obj.facts['memtotal_mb'] == 1048575
    assert SunOSHardware_obj.facts['swapfree_mb'] == 2047

# Generated at 2022-06-20 17:39:24.018901
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MagicMock()
    module.run_command.return_value = (0, """
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
sparcv9
      clock_MHz     1000
       chip_id     0x0
      cpu_type     sparcv9
        module:      T2000
      rev_id     0x8100030
      state    online
      status     ok
""", "")

    hardware = SunOSHardware(module)
    result = hardware.get_cpu_facts()


# Generated at 2022-06-20 17:39:29.746225
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sut = SunOSHardware(module)
    rc, out, err = sut.module.run_command('/usr/sbin/prtconf')
    if 'Memory size' not in out:
        sut.module.fail_json(msg='Failed to run prtconf to gather memory facts.')


# Generated at 2022-06-20 17:39:37.898136
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Verify how get_dmi_facts returns facts
    """
    from ansible.module_utils.facts.hardware import SunOSHardware

    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)
    results = hardware.get_dmi_facts()
    assert results['system_vendor'] == 'Fujitsu'
    assert results['product_name'] == 'PRIMERGY TX300 S6'
    assert results['ansible_machine'] == 'sparcv9'


# Generated at 2022-06-20 17:39:45.485521
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import unittest
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.sunoshw = SunOSHardware(TestModule)

        def test_values_uptime_facts(self):
            self.sunoshw.module.run_command = lambda x: (0, \
                                                         "unix:0:system_misc:boot_time    1548249689", \
                                                         "")
            uptime_facts = self.sunoshw.get_uptime_facts()
            self.assertEqual(uptime_facts['uptime_seconds'], (int(time.time()) - 1548249689))



# Generated at 2022-06-20 17:40:07.520524
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_hardware_collector = SunOSHardwareCollector()
    assert sunos_hardware_collector is not None
    assert sunos_hardware_collector._platform == 'SunOS'

# Generated at 2022-06-20 17:40:10.330096
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_object = SunOSHardware(module)
    out = hardware_object.get_uptime_facts()
    assert 'uptime_seconds' in out

# Generated at 2022-06-20 17:40:14.327021
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = SunOSHardware()
    # No output means no devices and no facts to collect
    _, out, _ = module.run_command('/usr/bin/kstat -p')
    if not out:
        return
    module.get_device_facts()

# Generated at 2022-06-20 17:40:26.711335
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Example prtdiag output (trimmed to the System Configuration part)
    prtdiag = '''System Configuration: Oracle Corporation sun4v SPARC T5-1
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: Sun Microsystems sun4v SPARC T5-1
System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)
System Configuration: Fujitsu Siemens E2460-320 X86
'''

    # Create a dummy module to pass to SunOSHardware and run get_dmi_facts
    from ansible.module_utils import basic
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    m = basic.AnsibleModule(argument_spec={})
    s = SunOSHardware(m)
    dmi_facts = s.get_dmi

# Generated at 2022-06-20 17:40:37.997984
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hardware_collector = SunOSHardwareCollector()
    hardware = SunOSHardware(module)
    hardware_collector._populate_from_fact_cache(hardware)
    results = module.exit_json.call_args[0][0]
    assert results['processor_cores'] == 2

if __name__ == '__main__':
    ansible_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    sunos_hardware = SunOSHardware(ansible_module)
    facts = sunos_hardware.populate()
    ansible_module.exit_json(ansible_facts=facts)

# Generated at 2022-06-20 17:40:44.384521
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    input_fstab = (
        "System Configuration: xxxxxx sun4u\n"
        "Memory size: 256 Megabytes\n"
        "==== Devices\n"
    )
    expected_output = {
        'system_vendor': 'xxxxxx',
        'product_name': 'sun4u'
    }

    hardware = SunOSHardware()
    hardware.module = FakeModule()
    hardware.module.get_file_content = lambda x: input_fstab

    output = hardware.get_dmi_facts()
    assert output == expected_output


# Generated at 2022-06-20 17:40:52.377592
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = DummyModule()
    module.run_command = lambda x, environ_update=None: (0, out, None)
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == ['SPARC64-VI @ 3.0GHz']
    assert cpu_facts['processor_count'] == 4
    assert cpu_facts['processor_cores'] == 36


# Generated at 2022-06-20 17:40:57.946078
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # When platform is 'SunOS', system_vendor is 'Oracle Corporation' and product_name is 'VirtualBox'
    module = types.ModuleType('module')
    module.run_command = lambda x : (0, 'System Configuration: Oracle Corporation VirtualBox','')
    sunos = SunOSHardware(module)
    assert sunos.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'VirtualBox'}

    # When platform is not 'SunOS', system_vendor and product_name are not added
    module = types.ModuleType('module')
    module.run_command = lambda x : (0, 'System Configuration: Oracle Corporation VirtualBox','')
    sunos = SunOSHardware(module)
    sunos.module.facts['platform'] = 'Linux'
    sunos.module

# Generated at 2022-06-20 17:41:08.349227
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class Fake_module:
        def run_command(self, cmd, check_rc=True):
            rc = 0

# Generated at 2022-06-20 17:41:12.823882
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = SunOSHardware().get_uptime_facts()
    current_time = int(time.time())
    assert uptime_facts['uptime_seconds'] == (current_time - 1548249689)

# Generated at 2022-06-20 17:41:37.099419
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(dict(
        ansible_facts=dict(),
        ansible_collect_hardware=dict()
    ))

    # Creating a SunOSHardware object and calling the populate method
    sunos_hw = SunOSHardware(module)
    result = sunos_hw.populate()

    assert result != None


# Generated at 2022-06-20 17:41:40.995405
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_obj = SunOSHardware({})
    result = test_obj.get_dmi_facts()
    assert result['system_vendor'] == 'Sun Microsystems'
    assert result['product_name'] == 'SUNW,UltraAX-i2'


# Generated at 2022-06-20 17:41:49.113683
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Method get_uptime_facts of SunOSHardware should return the uptime_seconds in the format
    {"uptime_seconds": <seconds>}
    :return:
    """
    class MockModule:
        def __init__(self):
            self.run_command_environ_update = {}
            self.run_command_calls = []

        def get_bin_path(self, *args, **kwargs):
            return "/usr/bin/kstat"

        def run_command(self, cmd, environ_update=None, check_rc=True, data=None):
            self.run_command_environ_update = environ_update
            self.run_command_calls.append(cmd)
            current_time = int(time.time())

# Generated at 2022-06-20 17:41:53.627416
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    module.run_command = MagicMock()

    hardware = SunOSHardware(module)
    result = hardware.get_dmi_facts()

    assert result['system_vendor'] == 'Fujitsu'
    assert result['product_name'] == 'FUJITSU SPARC M10-1'

# Generated at 2022-06-20 17:42:06.111038
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    assert hardware.platform == 'SunOS'
    assert hardware.get_memory_facts() == {'swaptotal_mb': 0, 'swap_reserved_mb': 0, 'swap_allocated_mb': 0, 'swapfree_mb': 0}

    module.params = {'gather_subset': ['min']}
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'
    assert hardware.get_memory_facts() == {'swaptotal_mb': 0, 'swap_reserved_mb': 0, 'swap_allocated_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-20 17:42:07.585617
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hw = SunOSHardware()
    assert sunos_hw


# Generated at 2022-06-20 17:42:15.469268
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

# Generated at 2022-06-20 17:42:22.049110
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector({'platform': 'SunOS'})

    assert hardware_collector.get_required_facts() == set(['platform'])
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-20 17:42:28.515874
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    rc, out, err = module.run_command(['/usr/platform/sun4v/sbin/prtdiag'])

    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SPARC-T4'



# Generated at 2022-06-20 17:42:30.164902
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-20 17:43:08.525078
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    m = SunOSHardware({})
    facts = m.get_uptime_facts()
    assert 'uptime_seconds' in facts

# Generated at 2022-06-20 17:43:20.459171
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware_obj = SunOSHardware()

    out1 = """
Memory size: 30000 Megabytes
"""
    hardware_obj.module.run_command.return_value = (0, out1, "")
    out2 = """
total:    630120k bytes allocated + 22948k reserved = 653068k used, 346460k available
"""
    hardware_obj.module.run_command.return_value = (0, out2, "")
    return_val = hardware_obj.get_memory_facts()
    assert "memtotal_mb" in return_val
    assert "swaptotal_mb" in return_val
    assert "swapfree_mb" in return_val
    assert "swap_allocated_mb" in return_val
    assert "swap_reserved_mb" in return_val




# Generated at 2022-06-20 17:43:25.939624
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == {'processor': ['SPARC-Enterprise-T5120 @ 1375MHz'], 'processor_cores': 2, 'processor_count': 2}


# Generated at 2022-06-20 17:43:27.064930
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.platform == 'SunOS'

# Generated at 2022-06-20 17:43:37.036866
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module, class_args = get_test_SunOSHardware_instance()
    hardware_fact = SunOSHardware(module, class_args)
    facts_dict = hardware_fact.populate()

    assert facts_dict['processor'] == ['SUNW,Netra-T4 @ 1200MHz']
    assert facts_dict['memtotal_mb'] == 2097152
    assert facts_dict['processor_cores'] == 16
    assert facts_dict['processor_count'] == 2
    assert facts_dict['swap_reserved_mb'] == 1048576
    assert facts_dict['swap_allocated_mb'] == 8388608
    assert facts_dict['swaptotal_mb'] == 9437184
    assert facts_dict['swapfree_mb'] == 8388608

# Generated at 2022-06-20 17:43:41.812703
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert SunOSHardware.platform == "SunOS"
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:43:53.213812
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    in_output = '''System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: VMware, Inc. VMware Virtual Platform'''

    expected_out_facts = {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

    # Create a instance of SunOSHardware module with required parameters
    module = SunOSHardware()

    # Set module.run_command()'s return values

# Generated at 2022-06-20 17:44:03.510404
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {}
    hardware = SunOSHardware(module=module)

    # Responding to command /usr/bin/kstat cpu_info
    # It's the real output on my computer
    # uname -a: SunOS bruno-pc 5.11 omnios-cdea2ebf3 i86pc i386 i86pc

# Generated at 2022-06-20 17:44:13.204220
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_object = SunOSHardware()


# Generated at 2022-06-20 17:44:23.658551
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    FACT_RETURN = {
        'processor': ['SPARC64-VII 3.0 @ 1500MHz', 'SPARC64-VII 3.0 @ 1500MHz', 'SPARC64-VII 3.0 @ 1500MHz', 'SPARC64-VII 3.0 @ 1500MHz'],
        'processor_cores': 4,
        'processor_count': 4
    }

    test_module = type('test_module', (object,), {'run_command': lambda *args, **kwargs: (0, PRTDIAG_MOCK, None)})
    SunOSHardwareCollector(test_module).get_fact()
    assert SunOSHardwareCollector(test_module).get_fact()['ansible_processor']['processor'] == FACT_RETURN['processor']
    assert SunOSHardwareCollector(test_module).get_fact

# Generated at 2022-06-20 17:45:45.765618
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    hardware.module.run_command = FakeRunCommand()
    hardware.module.run_command.set_output((0, "Memory size: 4096 Megabytes", ""))

    hardware.get_memory_facts()

    assert hardware.facts['memtotal_mb'] == 4096



# Generated at 2022-06-20 17:45:54.297290
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    sunhw = SunOSHardware(module)

    # test valid input
    prtconf_content = b'''Memory size: 8192 Megabytes'''
    swap_content = b'''total: 3416388932k bytes allocated + 261372448k reserved = 3677761380k used, 1038671824k available'''

    module.run_command.return_value = (0, prtconf_content, '')
    module.get_file_content.return_value = swap_content

    result = sunhw.get_memory_facts()

# Generated at 2022-06-20 17:46:04.699734
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts import mocker

    #
    # Mock AnsibleModule
    #
    facts = mocker.MockAnsibleModule(argument_spec={})

    #
    # Mock subprocess.check_output
    #
    facts.run_command.return_value = (0, OUTPUT_kstat_p, STDERR_kstat_p)

    #
    # Run method
    #
    hardware = SunOSHardware()
    hardware.populate()


# Generated at 2022-06-20 17:46:16.805441
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware


# Generated at 2022-06-20 17:46:24.694694
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Arrange
    test_module = FakeANSIBLEModule()
    test_module_run_command = test_module.run_command = MagicMock()
    test_module_run_command.return_value = (0, "module:sparcv9\nbrand:SPARC-T2+\nclock_MHz:3000", "")
    test_SunOSHardware = SunOSHardware(test_module)

    # Act
    actual = test_SunOSHardware.get_cpu_facts()

    # Assert
    assert actual['processor'] == ['SPARC-T2+ @ 3000MHz']


# Generated at 2022-06-20 17:46:31.500777
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_subset='hardware'))
    hardware = SunOSHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert 'sd0' in device_facts.get('devices')
    sd0 = device_facts.get('devices').get('sd0')
    assert 'product' in sd0
    assert 'revision' in sd0
    assert 'serial' in sd0
    assert 'size' in sd0
    assert 'vendor' in sd0
    assert 'hard_errors' in sd0
    assert 'soft_errors' in sd0
    assert 'transport_errors' in sd0
    assert 'media_errors' in sd0
    assert 'predictive_failure_analysis' in sd

# Generated at 2022-06-20 17:46:33.926150
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts_obj = SunOSHardware()
    assert uptime_facts_obj.get_uptime_facts()

# Generated at 2022-06-20 17:46:35.092170
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = SunOSHardware()
    assert module


# Generated at 2022-06-20 17:46:42.203666
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    out = \
    """System Configuration: Sun Microsystems sun4v
   Memory size: 32768 Megabytes
   ===========================
   ===========================
   ===========================
   ==========================="""

    facts = SunOSHardware().get_dmi_facts()

    assert 'system_vendor' in facts
    assert facts['system_vendor'] == 'Sun Microsystems'

    assert 'product_name' in facts
    assert facts['product_name'] == 'sun4v'



# Generated at 2022-06-20 17:46:51.919784
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeRunCommand({
        '/usr/sbin/prtconf': (0, 'Memory size: 1024 Megabytes', None),
        '/usr/sbin/swap -s': (0,
            'total: 7772612k bytes allocated + 117904k reserved = 7890516k used,'
            ' 838860k available',
            None)})

    fact_class = SunOSHardware(module)
    memory_facts = fact_class.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 1024, 'swapfree_mb': 819,
                            'swap_reserved_mb': 115, 'swap_allocated_mb': 7626,
                            'swaptotal_mb': 819}

# Unit test