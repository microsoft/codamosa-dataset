

# Generated at 2022-06-20 17:38:42.304252
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create a dummy class to generate the required
    # facts.
    class Facts():
        def __init__(self):
            self.ansible_facts = {'platform': 'SunOS'}

    hardware = SunOSHardware(module, Facts())
    hardware.populate()

    # Assert the result

# Generated at 2022-06-20 17:38:50.669529
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'test_data', 'err'))
    module.get_bin_path = Mock(return_value='/bin/prtdiag')
    sunos_hardware_facts = SunOSHardware()
    sunos_hardware_facts.module = module
    sunos_hardware_facts.populate()
    assert sunos_hardware_facts.data['ansible_processor'][0] == 'SPARC T4 (chipid 0, clock 563 MHz)'

# Generated at 2022-06-20 17:38:55.625775
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    text = '''
Memory size: 16384 Megabytes
'''
    module = AnsibleModuleMock()
    setattr(module, 'run_command', run_command_mock(stdout=text))
    SunOSHardware = SunOSHardware(module)
    memory_facts = SunOSHardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384


# Generated at 2022-06-20 17:39:08.490146
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = SunOSHardware()

# Generated at 2022-06-20 17:39:10.884955
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] >= 0


# Generated at 2022-06-20 17:39:17.142685
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test = SunOSHardware()

    test.module = Mock()
    test.module.run_command = Mock()
    test.module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')

    test_output = test.get_uptime_facts()

    assert test_output['uptime_seconds'] == int(time.time() - 1548249689)



# Generated at 2022-06-20 17:39:29.062110
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # stub out all the external calls
    stubs = {
        'run_command':
        {
            "prtconf": ("", "aaa\nMemory size: 8192 Megabytes\nbbb\n", None),
            "swap -s": ("", "Total: 16384k bytes allocated \n 16384k reserved \n16384k used, 0k available \n", None)
        }
    }

    memory_facts = SunOSHardware().get_memory_facts(stubs)
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['swap_allocated_mb'] == 16
    assert memory_facts['swap_reserved_mb'] == 16
    assert memory_facts['swaptotal_mb'] == 16
    assert memory_facts['swapfree_mb'] == 0

# Generated at 2022-06-20 17:39:39.840525
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content

    current_time = int(time.time())
    boot_time = 1548249689
    boot_timestamp = (datetime.datetime.now() -
                      datetime.timedelta(seconds=(current_time - boot_time))).isoformat()

    with open('/tmp/boot_timestamp', 'w') as fh:
        fh.write("unix:0:system_misc:boot_time	%s" % boot_time)

    h = SunOSHardware()
    h.module = MagicMock()
    h.module.run_command.return_value = (0, "%s" % boot_time, '')

    upt

# Generated at 2022-06-20 17:39:41.661865
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    shc = SunOSHardwareCollector()
    assert shc._fact_class == SunOSHardware
    assert shc.required_facts == {'platform'}

# Generated at 2022-06-20 17:39:48.517656
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    With this test it is ensured, that _get_dmi_facts returns a dictonary
    with a system_vendor and a product_name
    """
    hw = SunOSHardware()
    dmi_facts = hw.get_dmi_facts()
    assert set(dmi_facts.keys()).issuperset(set(['system_vendor', 'product_name']))

# Generated at 2022-06-20 17:40:15.872410
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MySunOSHardware(SunOSHardware):
        def run_command(self, args):
            '''
            Stub for the run_command method, which is called from the
            get_uptime_facts method.
            Returns the contents of the kstat command which was run.
            '''
            return 0, 'unix:0:system_misc:boot_time 1548249689', ''

    my_SunOSHardware = MySunOSHardware()
    uptime_facts = my_SunOSHardware.get_uptime_facts()
    current_time = int(time.time())
    # Make sure that the uptime_seconds is not biased by the execution
    # time of the method.
    assert int(uptime_facts['uptime_seconds']) - current_time < 5
    # Check the uptime_seconds value
    assert int

# Generated at 2022-06-20 17:40:28.963093
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )


# Generated at 2022-06-20 17:40:29.963231
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-20 17:40:40.753977
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeModule()
    hw = SunOSHardware(module=module)
    hw.get_memory_facts()
    assert module.run_command.call_args_list == [call(['/usr/sbin/prtconf']), call(['/usr/sbin/swap', '-s'])]
    assert hw.memory['memtotal_mb'] == '2'
    assert hw.memory['swapfree_mb'] == '0'
    assert hw.memory['swaptotal_mb'] == '1'
    assert hw.memory['swap_allocated_mb'] == '1'
    assert hw.memory['swap_reserved_mb'] == '0'


# Generated at 2022-06-20 17:40:43.320361
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert isinstance(x, SunOSHardwareCollector)

# Generated at 2022-06-20 17:40:51.061058
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule()

    # Update module methods to use our fake kstat
    def run_command(cmd, **kwargs):
        out = "unix:0:system_misc:boot_time    1548249689"
        return 0, out, ""
    module.run_command = run_command

    # The test
    facts = SunOSHardware().get_uptime_facts()
    assert facts['uptime_seconds'] > 0


# Generated at 2022-06-20 17:41:03.303310
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware({})
    cmd = '/usr/bin/kstat -p'

# Generated at 2022-06-20 17:41:05.819791
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Create an instance of SunOSHardware class
    hw = SunOSHardware({'platform': 'SunOS'})

    assert hw.platform == 'SunOS'

# Generated at 2022-06-20 17:41:18.720961
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {}
    facts = SunOSHardware().populate()
    assert facts['ansible_processor'] == ['SPARC64-VI @ 1600MHz']
    assert facts['ansible_system_vendor'] == 'Oracle Corporation'
    assert facts['ansible_product_name'] == 'SPARC T7-2'
    assert facts['ansible_devices']['sda']['size'] == '5.1T'
    assert facts['ansible_devices']['sda']['vendor'] == 'ATA'
    assert facts['ansible_devices']['sda']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-20 17:41:25.905507
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Unit test for method get_dmi_facts of class SunOSHardware.

    :return: ``True`` if unit test passes, ``False`` otherwise
    :rtype: bool
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    hw = SunOSHardware()
    hw.module = MagicMock()
    hw.module.run_command = MagicMock(return_value=(0, 'System Configuration: QEMU Virtual Machine\n', ''))

    dmi_facts = hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'QEMU'
    assert dmi_facts['product_name'] == 'Virtual Machine'

    return True

# Generated at 2022-06-20 17:41:53.626639
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.run_command = MagicMock()

    test_module.run_command.return_value = (0, 'Memory size: 8192 Megabytes', '')

    test_module.run_command_environ_update = {}

    test_module.params = {}

    """
    This method uses a call to kstat to determine swap size. The following
    is the format of the output of kstat.
    """
    test_module.run_command.return_value = (0, ' 8192k allocated +  30524k used,  5700k available', '')
    test_SunOSHardware = SunOSHardware(module=test_module)
    memory_facts = test_SunOSHardware.get_memory_facts()

# Generated at 2022-06-20 17:41:59.582555
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class Module(object):

        @staticmethod
        def run_command(cmd):
            if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return (0, 'unix:0:system_misc:boot_time\t1548249689\n', '')

        @staticmethod
        def get_bin_path(name, opt_dirs=None):
            return name

    Module.run_command.__doc__ = SunOSHardware.run_command.__doc__
    Module.get_bin_path.__doc__ = SunOSHardware.get_bin_path.__doc__

    check = SunOSHardware(Module(), {})
    assert check.get_uptime_facts()['uptime_seconds'] == 1548249689

# Generated at 2022-06-20 17:42:06.321577
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    import pytest

    hw = SunOSHardwareCollector({'platform': 'SunOS'}, None)
    assert hw.platform == 'SunOS'
    assert hw.required_facts == {'platform'}
    assert hw.sysfs_platform == 'SunOS'

    with pytest.raises(AttributeError):
        hw = SunOSHardwareCollector({'platform': 'Darwin'}, None)



# Generated at 2022-06-20 17:42:09.382583
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import time

    hw = SunOSHardware()

    boot_time = time.time()
    hw.module.run_command = lambda x: (0, str(boot_time) + '\n', '')

    uptime_facts = hw.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - boot_time)

# Generated at 2022-06-20 17:42:14.987671
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:27.376576
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpuinfo_facts = {"ansible_processor": ["GenuineIntel", "GenuineIntel", "GenuineIntel"],
                     "ansible_processor_arch": "x86_64",
                     "ansible_processor_cores": 2,
                     "ansible_processor_count": 8,
                     "ansible_processor_threads_per_core": 1,
                     "ansible_processor_vcpus": 8,
                     "processor": ["GenuineIntel", "GenuineIntel", "GenuineIntel"]}
    hardware = SunOSHardware({'ansible_machine': 'i86pc'})
    hardware.populate()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts == cpuinfo_facts

# Generated at 2022-06-20 17:42:32.784910
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hw = SunOSHardware()
    hw.module.run_command = lambda x: (0, 'unix:0:system_misc:boot_time    1548249689\n', '')
    uptime_facts = hw.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1548249689

# Generated at 2022-06-20 17:42:37.868090
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    fake_module = FakeAnsibleModule()
    fake_module.params = {}

    fake_platform = 'SunOS'

    test_collector = FactsCollector(fake_module)
    test_collector.collect(['platform'])
    test_collector.populate()

    # Check whether class SunOSHardware is registered
    assert test_collector.get_facts_for_platform(fake_platform) == SunOSHardware


# Generated at 2022-06-20 17:42:50.128866
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MagicMock()

    # Set the results of kstat cpu_info.
    module.run_command.side_effect = [0, 0, 0]
    module.run_command.return_value = [0, 'module: SUNW,Sun-Fire-T200\nbrand           sun4v\nclock_MHz       1200.000000\nchip_id         24\nimplementation  SPARC-T2\nmodel           sun4v\ncpu_type        sun4v', '']

    # Set the result of prtconf
    module.run_command.side_effect = [0, 0, 0]
    module.run_command.return_value = [0, 'Memory size: 16384 Megabytes', '']

    # Set the result of swap -s

# Generated at 2022-06-20 17:42:54.538982
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    memory = hardware.get_memory_facts()
    assert memory['memtotal_mb'] > 0
    assert memory['swapfree_mb'] > 0
    assert memory['swaptotal_mb'] > 0
    assert memory['swap_allocated_mb'] > 0
    assert memory['swap_reserved_mb'] > 0

# Generated at 2022-06-20 17:43:38.162371
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()

    # Test for SPARC CPU
    output = """module:
brand             SPARC T4 (chipid 0, clock 1700 MHz)
chip_id           0
clock_MHz         1700
implementation    SPARC T4
pg_id             0
serial_number     0
diag-switch?      false
chip-type         sun4v
cpu-type          SPARC T4
cpu-implementation-name SPARC T4
ecache-size       24576
ecache-line-size  64
ecache-associativity 4
ecache-sets       1536
itlb-entries      512
dtlb-entries      512
chip-type         sun4v"""

    facts = hardware._get_cpu_facts(output)

    assert facts['processor'] == ['SPARC T4 @ 1700MHz']
    assert facts

# Generated at 2022-06-20 17:43:50.741906
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    pc = SunOSHardware(module)

    rc, out, err = module.run_command("/usr/sbin/prtconf")

    pc.get_memory_facts(out)

    d = module.params['gather_subset']

# Generated at 2022-06-20 17:44:02.534858
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    output1 = 'System Configuration: Sun Microsystems sun4u\n'
    output2 = 'System Configuration: Oracle Corporation sun4v\n'
    hardware_class = SunOSHardware(None)
    hardware_class.module.run_command.return_value = (0, output1, None)
    output = hardware_class.get_dmi_facts()
    assert output == {'system_vendor': 'Sun Microsystems',
                      'product_name': 'sun4u'}

    hardware_class.module.run_command.return_value = (0, output2, None)
    output = hardware_class.get_dmi_facts()
    assert output == {'system_vendor': 'Oracle Corporation',
                      'product_name': 'sun4v'}

    hardware_class.module.run_command.return_

# Generated at 2022-06-20 17:44:12.558532
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import os
    import tempfile
    import pytest

    from ansible.module_utils.common.locale import get_best_parsable_locale
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils.six import PY2

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.facts import AnsibleCollector

    (fd, kstat_file) = tempfile.mkstemp()
    os.write(fd, get_file_content('tests/unit/ansible_test/test_kstat_cpu_info.txt'))
    os.close(fd)


# Generated at 2022-06-20 17:44:19.505787
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    m = SunOSHardwareCollector(module=module)
    res = m.populate()

    assert not module.fail_json.called
    assert len(res) >= 4
    assert 'system_vendor' in res
    assert 'product_name' in res
    assert 'uptime_seconds' in res
    assert 'devices' in res

# Generated at 2022-06-20 17:44:22.232590
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSHardware
    assert collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:44:26.914320
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    mod = None
    try:
        mod = SunOSHardware(module=None)
    except:
        pass

    assert mod is not None


if __name__ == '__main__':
    # Test SunOSHardware class
    test_SunOSHardware()

# Generated at 2022-06-20 17:44:33.352912
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware({})
    out = """
System Configuration: VMware, Inc. VMware Virtual Platform
System clock frequency: 1999 MHz
Memory size: 16384 Megabytes
"""
    dmi_facts = m.get_dmi_facts(out)

    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-20 17:44:35.780329
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    facts = SunOSHardware(module)
    assert facts.platform == 'SunOS'


# Generated at 2022-06-20 17:44:46.298230
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the get_dmi_facts method of SunOSHardware.
    :return:
    """
    # Setup
    data = []
    data.append('System Configuration: VMware, Inc. VMware Virtual Platform')
    data.append('BIOS Configuration:    Phoenix Technologies LTD 6.00')
    data.append('6.00 08/20/2018')
    data.append('MOTHER BOARD ASSEMBLY NUMBER:')
    data.append('MOTHER BOARD TRACER NUMBER:')
    data.append('#PROCESSORS:1')

    # Test
    hardware = SunOSHardware(None)
    (dmi_facts, dmi_vendor, dmi_product) = hardware.get_dmi_facts(data)

    # Verify

# Generated at 2022-06-20 17:45:28.072948
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Test for method populate(collected_facts) with both memory and cpu facts
    collected_facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': 'i386',
        'ansible_processor_count': 2,
    }
    hardware_facts = SunOSHardware()
    hardware_facts.module = Mock(return_value=0)
    hardware_facts.module.run_command.return_value = (0, '', '')
    hardware_facts.module.get_bin_path.return_value = '/usr/bin/prtconf'
    hardware_facts.populate(collected_facts)
    assert hardware_facts.facts['processor'][0] == 'SUNW,UltraSPARC-T1 @ 1200MHz'
    assert hardware_facts.facts['processor_cores']

# Generated at 2022-06-20 17:45:32.893977
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(dict(ansible_facts={'os_family': 'Solaris'}), module=None)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-20 17:45:43.788090
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This unit test should be run against a SunOS test host with virtualbox
    guest additions installed.
    """
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collectors.hardware.sunos import SunOSHardware
    import ansible.module_utils.facts.hardware.sunos as hardware_sunos
    import sys

    # We need to insert the test module into the module path
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_lib_dir = os.path.realpath(os.path.join(test_dir, os.pardir))
    sys.path.insert(0, test_lib_dir)

    hardware_facts = hardware_sunos.SunOSHardware()
    collected_facts = Facts

# Generated at 2022-06-20 17:45:47.168041
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()

    assert set(hardware_collector.required_facts) == set(['platform'])



# Generated at 2022-06-20 17:45:54.708728
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({})
    hardware.module = MockModule()
    collected_facts = {
        'ansible_machine': 'i86pc',
    }

    hardware.get_cpu_facts(collected_facts)
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i5-4210M CPU @ 2.60GHz @ 2648MHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1

    # Since the cpu facts are calculated from the 'module' run_command output,
    # it is not possible to test the result for SPARC architecture without
    # having an actual SPARC machine at hand.
    # Tests for SPARC system are commented out.

    # collected_facts = {
    #     'ansible_machine': 'sun4v

# Generated at 2022-06-20 17:46:04.934055
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Given
    module = mock.MagicMock()
    module.run_command_environ_update = None
    module.run_command.return_value = (0, "", "")

    # When
    sunoshardware = SunOSHardware(module)
    facts = sunoshardware.populate()

    # Then
    assert 'ansible_processor' in facts
    assert 'ansible_processor_cores' in facts
    assert 'ansible_processor_count' in facts
    assert 'ansible_memfree_mb' in facts
    assert 'ansible_memtotal_mb' in facts
    assert 'ansible_swapfree_mb' in facts
    assert 'ansible_swaptotal_mb' in facts
    assert 'ansible_system_vendor' in facts

# Generated at 2022-06-20 17:46:17.083906
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = SunOSHardware()

    class FakeModule(object):
        def __init__(self):
            self.run_command_environ_update = None

        def run_command(self, module_args, **kwargs):
            if module_args == "/usr/sbin/swap -s":
                return (0, """total: 524276k bytes allocated + 173600k reserved \
= 697676k used, 1345568k available """, '')
            elif module_args == "/usr/bin/uname -i":
                return (0, "i86pc", '')

    m.module = FakeModule()
    facts = m.populate()
    assert m.sderr == {}
    assert facts['memtotal_mb'] == 524276

# Generated at 2022-06-20 17:46:18.858806
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module_mock = MockModule()
    SunOSHardware(module_mock)

# Generated at 2022-06-20 17:46:22.231577
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hw = SunOSHardware({})
    output = hw.get_memory_facts()
    assert 'memtotal_mb' in output
    assert 'swapfree_mb' in output
    assert 'swaptotal_mb' in output

# Generated at 2022-06-20 17:46:26.724153
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('FakeModule', (object,), {'run_command': (lambda *args, **kwargs: (0, '', ''))})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    sunos_hw = SunOSHardware(module=module)
    assert sunos_hw.get_dmi_facts() == {}

# Generated at 2022-06-20 17:47:47.123208
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    try:
        SunOSHardwareCollector()
    except Exception as e:
        pytest.fail(e)

# Generated at 2022-06-20 17:47:54.576009
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    data = 'Memory size: 8192 Megabytes\n'

    result = SunOSHardware(dict(module=dict(run_command=lambda *_, **__: (0, data, '')))).get_memory_facts()
    assert result == {'memtotal_mb': 8192, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'swap_allocated_mb': 0, 'swap_reserved_mb': 0}


# Generated at 2022-06-20 17:48:00.163763
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filters=dict(default=['^memory\.'], type='list'),
        ),
    )

    m = SunOSHardware(module=module)

    expected_memory_facts = dict(
        memtotal_mb=917,
        swapfree_mb=0,
        swaptotal_mb=1,
        swap_allocated_mb=1,
        swap_reserved_mb=0
    )
    assert expected_memory_facts == m.get_memory_facts()

# Generated at 2022-06-20 17:48:10.286556
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test get_dmi_facts of SunOSHardware"""
    output = "System Configuration: VMware, Inc. VMware Virtual Platform"
    line = [output.split('\n')[0]]

    # create instance of SunOSHardware class
    module = FakeModule()
    sunos_hardware = SunOSHardware(module)

    # initial definition of dmi_facts dict
    dmi_facts = {}
    dmi_facts['system_vendor'] = 'VMware, Inc.'
    dmi_facts['product_name'] = 'VMware Virtual Platform'

    # get_dmi_facts method without run_command_environ_update
    #   If run_command_environ_update is not defined, run_command will not be
    #   called and it will have the same output as before
    sunos_hardware_get_d

# Generated at 2022-06-20 17:48:14.286980
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    facts = {'ansible_facts': {'ansible_machine_serial': '12345678',
                               'ansible_machine_id': '6eabd948-77c1-4b8c-a391-d283f5c6f3de',
                               'ansible_machine_name': 'nyc-3a4ef55b.client-disco.noreply.org'},
             'changed': False}
    hardware_facts_obj = SunOSHardware(facts)
    dmi_facts = hardware_facts_obj.get_dmi_facts()
    assert dmi_facts == {}