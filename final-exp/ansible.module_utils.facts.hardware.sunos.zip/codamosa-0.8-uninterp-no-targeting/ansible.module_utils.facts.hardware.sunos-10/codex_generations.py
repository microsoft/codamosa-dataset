

# Generated at 2022-06-20 17:38:50.848296
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = None
    sunos_hw = SunOSHardware(module)
    assert sunos_hw.platform == 'SunOS'

    # Test that populate method calls all other methods
    sunos_hw.populate()
    # Fact collecting code based on SunOS 10 returns None since it execs external commands
    # Will return results on SunOS 11, so this assertion is commented out.
    # assert sunos_hw.cpu_facts() == {
    #         'processor': [u'SUNW,UltraSPARC-II @ 167MHz'],
    #         'processor_count': 1,
    #         'processor_cores': 1}

# Generated at 2022-06-20 17:38:53.901623
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSHardware
    assert collector.required_facts == set(['platform'])


# Generated at 2022-06-20 17:39:06.236872
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:16.323230
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # Testing on i86pc

# Generated at 2022-06-20 17:39:27.728764
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    args = dict(
        ansible_facts=dict(
            platform='SunOS',
        ),
    )
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    module.run_command = lambda *cmd, **kwargs: (0, to_bytes('unix:0:system_misc:boot_time 1548249689'), None)
    result = SunOSHardwareCollector(module).collect(args, [])
    assert result['ansible_facts']['uptime_seconds'] == 1234567890


# Generated at 2022-06-20 17:39:39.084794
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-20 17:39:50.044587
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    syshardware = SunOSHardware(module)
    devfacts = syshardware.get_device_facts()
    assert devfacts['devices']['sd0']['size'] == '5.00 TB'
    assert devfacts['devices']['sd1']['size'] == '5.00 TB'
    assert devfacts['devices']['sd2']['size'] == '5.00 TB'
    assert devfacts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert devfacts['devices']['sd0']['vendor'] == 'ATA'
    assert devfacts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'

# Generated at 2022-06-20 17:40:00.776495
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Unit test for method populate of class SunOSHardware."""
    module = AnsibleModule(argument_spec={'gather_subset': dict()})
    module.exit_json = lambda **kwargs: kwargs
    collected_facts = {}
    hardware = SunOSHardware(module)
    facts = hardware.populate(collected_facts)
    print(facts)

    assert facts['processor']
    assert facts['swapfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swap_reserved_mb']
    assert facts['swap_allocated_mb']
    assert facts['memtotal_mb']
    assert facts['system_vendor']
    assert facts['product_name']
    assert facts['processor_cores']
    assert facts['processor_count']

# Generated at 2022-06-20 17:40:03.331836
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = dict(
        platform='SunOS'
    )

    collected_facts = SunOSHardwareCollector.collect(facts)
    assert collected_facts['platform'] == 'SunOS'

# Generated at 2022-06-20 17:40:14.810247
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # arrange
    class module_mock(object):
        def run_command_environ_update(self, x): return "", "", ""
        def get_bin_path(self, x): return "/usr/bin/bdf"
        def run_command(self, x): return 0, "", ""
        def get_file_content(self, x): return ""

    class hardware_mock(object):
        def __init__(self): self._populate = ""
        def populate(self, x): return self._populate

    class memory_mock(object):
        def __init__(self): self.swapreserved_mb = "1024"
        def get_memory_facts(self): return self

    def get_mount_facts_mock(self): return {"mounts": "abcd"}


# Generated at 2022-06-20 17:40:35.481328
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.facts.hardware.sunos import SunOSHardware
    testSunOSHardware = SunOSHardware()
    assert testSunOSHardware.get_dmi_facts() == {}

# Generated at 2022-06-20 17:40:36.503268
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw = SunOSHardwareCollector()
    assert hw._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 17:40:39.155980
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    H = SunOSHardware()
    assert H.platform == 'SunOS'



# Generated at 2022-06-20 17:40:45.608647
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts

# Generated at 2022-06-20 17:40:49.721051
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hardware = SunOSHardware({'ansible_facts': {'ansible_system': 'SunOS'}})
    assert sunos_hardware.collect()['ansible_system'] == 'SunOS'

# Generated at 2022-06-20 17:40:52.809778
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    u = SunOSHardware()
    uptime_facts = u.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:40:58.266524
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import textwrap
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

# Generated at 2022-06-20 17:41:02.395285
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector({'platform': 'foo'})
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware

# Generated at 2022-06-20 17:41:07.619266
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out = ('Memory size: 8192 Megabytes\n')
    module = AnsibleModule(name='test_SunOSHardware_get_memory_facts',
                           argument_spec={},
                           supports_check_mode=True)
    module.run_command = MagicMock(return_value=(0, out, None))
    SunOSHardwareObj = SunOSHardware(module)
    expected_result = {'memtotal_mb': 8192}
    result = SunOSHardwareObj.get_memory_facts()
    assert result == expected_result



# Generated at 2022-06-20 17:41:17.104868
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    class FakeModule:
        def __init__(self, name):
            self.name = name
        def run_command(self, cmd):
            return (0, "System Configuration: Oracle Corporation sun4v", "")

    module = FakeModule("test")
    hw = SunOSHardware(module)

    # prtconf
    assert hw.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}

# Generated at 2022-06-20 17:41:57.095287
# Unit test for constructor of class SunOSHardware

# Generated at 2022-06-20 17:41:59.506213
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware({})

    assert hardware_facts.platform == 'SunOS'


# Generated at 2022-06-20 17:42:10.348724
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Module mock for ansible.module_utils.facts.hardware.sunos.SunOSHardware.
    # The mock object will be used for the module object of the class
    # ansible.module_utils.facts.hardware.sunos.SunOSHardware
    module_mock = type('AnsibleModuleMock', (object,), {
        'run_command.return_value': (0, '', ''),
        'get_bin_path.return_value': '/usr/sbin/prtconf',
    })()

    # Class mock for SunOSHardware.
    # The mock object will be used for the class
    # ansible.module_utils.facts.hardware.sunos.SunOSHardware
    SunOSHardware_mock = type('SunOSHardwareMock', (SunOSHardware,), {})

    # Pop

# Generated at 2022-06-20 17:42:16.989101
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    data = {
        'kstat_cpu_info': {
            'module': '',
            'brand': 'Sun Microsystems',
            'clock_MHz': '1800',
            'implementation': 'SPARC',
            'chip_id': '3',
            'module:': 'SPARC-Enterprise-M4000',
            'brand_info': 'ISP',
            'chip_rev': '0'
        }
    }
    facts = SunOSHardware(module, data=data)
    result = facts.get_cpu_facts(data)
    assert 'processor_count' in result.keys()
    assert 'processor' in result.keys()
    assert 'processor_cores' in result.keys()
    assert result['processor_count'] == 1

# Generated at 2022-06-20 17:42:22.196461
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = {'platform': 'SunOS'}
    sunos_hw = SunOSHardware(facts)
    assert sunos_hw.platform == 'SunOS'
    assert sunos_hw.populate() == {}



# Generated at 2022-06-20 17:42:25.131092
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {'uptime_seconds': 1548250832}
    sh = SunOSHardware()
    assert uptime_facts == sh.get_uptime_facts()

# Generated at 2022-06-20 17:42:34.337937
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeModule()
    SunOSHardwareObj = SunOSHardware()

    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

    cmd = ['/usr/bin/kstat', '-p']

    for ds in disk_stats:
        cmd.append('sderr:::%s' % ds)

    d = {}

# Generated at 2022-06-20 17:42:38.336155
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # instantiating class
    obj = SunOSHardwareCollector()

    # test for required_facts attribute
    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'
    assert obj.required_facts == set(['platform'])


# Generated at 2022-06-20 17:42:50.169755
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware()

    facts = {'devices': {'sda': {'product': 'VBOX HARDDISK',
                                 'revision': '1.0',
                                 'serial': 'VB0ad2ec4d-074a',
                                 'size': '53687091200',
                                 'vendor': 'ATA',
                                 'hard_errors': '0',
                                 'soft_errors': '0',
                                 'transport_errors': '0',
                                 'media_errors': '0',
                                 'predictive_failure_analysis': '0',
                                 'illegal_request': '6'}}}

    assert hardware.get_device_facts() == facts, "SunOSHardware does not set the facts correctly"

# Generated at 2022-06-20 17:42:54.748497
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = SunOSHardware()
    memory_facts = m.get_memory_facts()

    for k in ('memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'swap_allocated_mb', 'swap_reserved_mb'):
        assert k in memory_facts, "memory_facts should have key: %s, it is %s" % (k, memory_facts.keys())

# Generated at 2022-06-20 17:43:59.224032
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    facts = {}
    SunOSHardware(module, facts)


# Generated at 2022-06-20 17:44:10.553019
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import GenericFactCollector
    from ansible.module_utils.facts import get_collector_for_platform

    module = GenericFactCollector()
    # This test only works on Solaris 11, but it might be possible to add a
    # Solaris 10 VM to the CI test suite.
    module.collect()

    assert 'ansible_machine' in module.facts
    assert 'ansible_processor' in module.facts

    sunos_collector = get_collector_for_platform('SunOS')
    swim = sunos_collector(module, module.collect())
    swim.populate()
    assert 'ansible_processor' in swim.facts

# Generated at 2022-06-20 17:44:18.702340
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert type(facts) is dict
    assert 'memtotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts


# Generated at 2022-06-20 17:44:22.810779
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class module:
        def run_command(self, args):
            return 0, "Memory size: 32768 Megabytes", ""

    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert facts['memtotal_mb'] == 32768


# Generated at 2022-06-20 17:44:34.957749
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Basic test for get_cpu_facts of SunOSHardware
    """
    # This is an excerpt of the output of the kstat command
    # used in the get_cpu_facts method of SunOSHardware.
    # It was generated with the following command on a
    # Solaris 11.3 instance:
    # kstat -m cpu_info | grep -E 'module:|brand|clock_MHz|chip_id|implementation'

# Generated at 2022-06-20 17:44:38.814378
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware_facts = SunOSHardware()
    result = hardware_facts.get_dmi_facts()

    assert result['system_vendor'] == 'Sun Microsystems'
    assert result['product_name'] == 'SUNW,SPARCstation-20'

# Generated at 2022-06-20 17:44:48.433417
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:45:00.814501
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MockModule()
    hardware = SunOSHardware(module)

    # prepare sddev output
    device_facts = {}
    device_facts['devices'] = {}

    device_facts['devices']['sda'] = {
        'product': 'VBOX HARDDISK',
        'revision': '1.0',
        'serial': 'VB0ad2ec4d-074a',
        'size': '53687091200',
        'vendor': 'ATA',
        'hard_errors': '0',
        'soft_errors': '0',
        'transport_errors': '0',
        'media_errors': '0',
        'predictive_failure_analysis': '0',
        'illegal_request': '6',
    }

# Generated at 2022-06-20 17:45:08.646615
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    with open('tests/unit/module_utils/facts/hardware/test_data/sunos/cpu_facts.txt') as f:
        content = f.read()

    hardware = SunOSHardware({
        'run_command': lambda *args, **kwargs: (0, content, None),
    })

    cpu_facts = hardware.get_cpu_facts()
    # Check cpu vendor and model
    assert cpu_facts.get('processor')[0] == 'AMD64 Family 16 Model 4 Stepping 3'

    # Check number of cpu sockets
    assert cpu_facts.get('processor_count') == 2

    # Check number of cpu cores
    assert cpu_facts.get('processor_cores') == 8

# Generated at 2022-06-20 17:45:15.380564
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    module = DummyModule()
    module.run_command = DummyRunCommand(stdout=to_bytes('unix:0:system_misc:boot_time    1548249689'))
    facts = SunOSHardware(module)

    uptime_facts = facts.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0



# Generated at 2022-06-20 17:47:43.990819
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = type('', (), {})()
    module.run_command = lambda cmd: (0, '', '')

    hardware = SunOSHardware(module)
    assert hardware.module == module

# Generated at 2022-06-20 17:47:55.609462
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Dictionary with module parameters
    module_params = {
    }

    # Collected facts
    collected_facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': ['GenuineIntel'],
        'ansible_processor_count': 1,
        'ansible_processor_cores': 1,
        'ansible_processor_threads_per_core': 1,
        'ansible_processor_vcpus': 1,
    }

    obj = SunOSHardware(module_params)
    obj.populate(collected_facts)

if __name__ == '__main__':
    test_SunOSHardware_populate()

# Generated at 2022-06-20 17:48:07.260294
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({'platform': 'SunOS'})
    rc = 0
    out = """sparc
solaris
sparc
sparc
sparc
solaris
sparc"""
    err = """"""
    hardware.module.run_command.return_value = (rc, out, err)
    cpu_facts = hardware.get_cpu_facts()

    assert(cpu_facts['processor_count'] == 7)
    assert(cpu_facts['processor_cores'] == 7)

    # test for SPARC processor
    rc = 0
    out = """sparc
solaris
sparc
sparc
sparc
solaris
sparc"""
    err = """"""

# Generated at 2022-06-20 17:48:13.547242
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Unit test for SunOSHardware.get_cpu_facts"""
    # Create instance of SunOSHardware
    sunosHardware = SunOSHardware()

    # Use command line output of prtconf and dummy output of kstat
    prtconf_out = "/usr/sbin/prtconf: /etc/prtconf.d/dmi-scan.conf: dmidecode: command not found\n" \
                  "Memory size: 16384 Megabytes\n"

# Generated at 2022-06-20 17:48:22.329982
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = 0, "System Configuration: Fujitsu Sun Microsystems SPARC Enterprise T5120", ""
    hw = SunOSHardware()
    hw.module = module
    dmi_facts = hw.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert dmi_facts['system_vendor'] == "Fujitsu"
    assert dmi_facts['product_name'] == "Sun Microsystems SPARC Enterprise T5120"
    module.run_command.assert_called_once_with('/usr/bin/uname -i')
