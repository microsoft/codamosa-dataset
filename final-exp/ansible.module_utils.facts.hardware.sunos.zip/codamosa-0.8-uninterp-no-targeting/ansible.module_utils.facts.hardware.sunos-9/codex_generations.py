

# Generated at 2022-06-20 17:38:43.981387
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class Module(object):
        def run_command(self, cmd):
            return 0, "unix:0:system_misc:boot_time    1548249689", ""

    class Facts(object):
        def __init__(self):
            self.current_time = 1548249691

    module = Module()
    fact = SunOSHardware(module=module)
    fact.populate(Facts())
    assert fact.uptime_seconds == 2

# Generated at 2022-06-20 17:38:55.511638
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware._module = AnsibleModuleMock()
    hardware._module.run_command = run_command_mock

    hardware.populate()

    hardware._module.run_command.assert_any_call('/usr/bin/kstat cpu_info')
    hardware._module.run_command.assert_any_call('/usr/sbin/prtconf')
    hardware._module.run_command.assert_any_call('/usr/sbin/swap -s')
    hardware._module.run_command.assert_any_call('/usr/bin/uname -i')
    hardware._module.run_command.assert_any_call('/usr/platform/sun4v/sbin/prtdiag')

# Generated at 2022-06-20 17:39:01.001391
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    host_vars = {
                   'ansible_facts': {
                     'platform': 'SunOS'
                   }
    }
    HWC = SunOSHardwareCollector(host_vars)
    assert HWC.data['ansible_facts']['platform'] == 'SunOS'

# Generated at 2022-06-20 17:39:04.978337
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hw = SunOSHardware(dict(), dict())
    uptime_facts = hw.get_uptime_facts()
    assert type(uptime_facts['uptime_seconds']) == int

# Generated at 2022-06-20 17:39:15.372903
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleFake


# Generated at 2022-06-20 17:39:28.090622
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    try:
        import ansible.module_utils.facts.hardware.sunos
        sunos_module = ansible.module_utils.facts.hardware.sunos
    except:
        # utils/facts/hardware/sunos.py have not been installed yet
        try:
            import ansible.module_utils.facts.hardware.sunos
            sunos_module = ansible.module_utils.facts.hardware.sunos
        except:
            # Ansible modules not installed
            import module_utils.facts.hardware.sunos
            sunos_module = module_utils.facts.hardware.sunos

    from ansible.module_utils.facts.hardware import get_command_output
    from ansible.module_utils.facts.hardware import run_command

    memory_facts = sunos_module

# Generated at 2022-06-20 17:39:38.856809
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:46.125699
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:48.241393
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    obj = SunOSHardware()
    assert isinstance(obj.get_uptime_facts(), dict)


# Generated at 2022-06-20 17:39:53.047233
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sub_class = SunOSHardwareCollector()
    assert sub_class.facts == set()
    assert sub_class._fact_class._platform == 'SunOS'
    assert sub_class.required_facts == set(['platform'])

# Generated at 2022-06-20 17:40:21.735356
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    # Create a fake Solaris 11 machine
    cpu_facts = {
        'processor': [],
        'processor_cores': 32,
        'processor_count': 8,
    }

    hardware = SunOSHardware(module)
    for cpu in range(cpu_facts['processor_count']):
        cpu_facts['processor'].append("SPARC M7 (chipid 0, clock %f MHz)" % (1111.0 + cpu))
        cpu_facts['processor_cores'] -= 1

    cpu_facts.update(hardware.get_cpu_facts())
    assert cpu_facts['processor_cores'] == 0

    # Create a fake Solaris 9 machine

# Generated at 2022-06-20 17:40:26.527853
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    manufacturer = hardware.get_dmi_facts()['system_vendor']

    assert manufacturer in ['Fujitsu', 'Oracle Corporation', 'QEMU',
                            'Sun Microsystems', 'VMware, Inc.']



# Generated at 2022-06-20 17:40:31.513899
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    sunos_hardware = SunOSHardware(module)
    memory_facts = sunos_hardware.get_memory_facts()
    module.exit_json(memory_facts=memory_facts)


# Generated at 2022-06-20 17:40:33.431047
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    flag = False
    hw = SunOSHardwareCollector()
    flag = True
    assert(flag)

# Generated at 2022-06-20 17:40:44.091962
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    result = SunOSHardware(module).populate()
    assert 'ansible_facts' in result
    facts = result['ansible_facts']
    assert 'ansible_processor' in facts
    assert 'ansible_system_vendor' in facts
    assert 'ansible_product_name' in facts
    assert 'ansible_devices' in facts
    # FIXME
    if facts['ansible_machine'] != 'i86pc':
        assert 'ansible_memfree_mb' in facts
        assert 'ansible_memtotal_mb' in facts
    assert 'ansible_mounts' in facts
    assert 'ansible_processor_cores' in facts
    assert 'ansible_processor_count' in facts

# Generated at 2022-06-20 17:40:46.091261
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    h = SunOSHardware()
    assert h.platform == 'SunOS'



# Generated at 2022-06-20 17:40:50.640888
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = SunOSHardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SPARC T4-4'

# Generated at 2022-06-20 17:40:55.121033
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = SunOSHardwareCollector()
    result = hardware_collector.populate()
    assert len(result) > 0

# ===========================================
# Main
# ===========================================



# Generated at 2022-06-20 17:41:06.670999
# Unit test for constructor of class SunOSHardware

# Generated at 2022-06-20 17:41:18.341141
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    expected_results = {}
    expected_results['devices'] = {'sd0': {'product': 'VBOX HARDDISK', 'revision': '1.0', 'serial': 'VB0ad2ec4d-074a', 'size': '5120 MB', 'vendor': 'ATA', 'hard_errors': '0', 'soft_errors': '0', 'transport_errors': '0', 'media_errors': '0', 'predictive_failure_analysis': '0', 'illegal_request': '6'}}

    # Instantiate SunOSHardware class
    w = SunOSHardware(dict())

    # Call get_device_facts method
    output = w.get_device_facts()

    # Assertions
    assert output == expected_results

# Generated at 2022-06-20 17:41:39.811082
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    SunOSHardware.populate(module)
    assert 'ansible_processor' in module.facts


# Generated at 2022-06-20 17:41:48.143199
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, args):
            if args == ['/usr/bin/uname', '-i']:
                return 0, 'sun4v', ''
            if args == ['/usr/platform/sun4v/sbin/prtdiag']:
                return 0, 'System\nConfiguration: Oracle Corporation sun4v', ''

        def get_bin_path(self, path, opt_dirs=[]):
            return path

    module = MockModule()
    hwrap = SunOSHardware(module)

    hw_facts = hwrap.get_dmi_facts()
    assert hw_facts['system_vendor'] == 'Oracle Corporation'
    assert hw_facts['product_name'] == 'sun4v'


# Generated at 2022-06-20 17:41:56.671109
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    import tempfile

    # Create a temp prtconf file
    with tempfile.NamedTemporaryFile() as f:
        f.write(b"Memory size: 8192 Megabytes")
        f.flush()

        # Use our temp prtconf file and mock swap command
        collect_cmds = {
            '/usr/sbin/prtconf': f". {f.name}",
            '/usr/sbin/swap': 'swapfile             1778628        0   1778628        0%'
        }

        # Run command
        fc = FactsCollector()
       

# Generated at 2022-06-20 17:42:08.584997
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    hardware_inst = SunOSHardware()

    class MockModule:
        def __init__(self):
            self.run_command = basic.AnsibleModule.run_command
            self.fail_json = basic.AnsibleModule.fail_json

    mock_module_inst = MockModule()

    # time.time() returns the seconds since the epoch, which is passed as boot_time to the get_uptime_facts method
    time_inst = time
    time_inst.time = lambda: 123456789

    # mock run_command to return the boot_time

# Generated at 2022-06-20 17:42:14.539316
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    inputdata = ['/usr/sbin/prtconf']
    dmi_facts = {}

    system_conf = inputdata[0].split('\n')[0]

    # If you know of any other manufacturers whose names appear in
    # the first line of prtdiag's output, please add them here:
    vendors = [
        "Fujitsu",
        "Oracle Corporation",
        "QEMU",
        "Sun Microsystems",
        "VMware, Inc.",
    ]
    vendor_regexp = "|".join(map(re.escape, vendors))

# Generated at 2022-06-20 17:42:20.031048
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware._platform == 'SunOS'
    assert hardware._fact_class == SunOSHardware
    assert hardware._fact_methods == set(['populate'])

# Generated at 2022-06-20 17:42:30.507593
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:35.421958
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """ This function is to test the constructor of the class SunOSHardwareCollector """
    sunos_collector = SunOSHardwareCollector()
    assert sunos_collector.platform == 'SunOS'
    assert sunos_collector.fact_class == SunOSHardware
    assert sunos_collector.required_facts == set(['platform'])


# Generated at 2022-06-20 17:42:39.048514
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test whether the class was constructed correctly.
    assert SunOSHardwareCollector._fact_class is SunOSHardware
    assert SunOSHardwareCollector._platform == 'SunOS'

# Generated at 2022-06-20 17:42:40.403100
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    assert callable(SunOSHardware.populate)

# Generated at 2022-06-20 17:43:01.479872
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test = SunOSHardwareCollector()
    collector = test._fact_class()

    result = collector.get_uptime_facts()
    assert(result != {})



# Generated at 2022-06-20 17:43:13.306442
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_obj = SunOSHardware()
    hardware_obj.module.run_command = run_command
    hardware_obj.module.get_bin_path = get_bin_path
    hardware_obj.get_device_facts = get_device_facts

    hardware_facts = hardware_obj.populate()

    assert hardware_facts['devices']['sd1']['hard_errors'] == '0'
    assert hardware_facts['devices']['sd1']['illegal_request'] == '6'
    assert hardware_facts['devices']['sd1']['media_errors'] == '0'
    assert hardware_facts['devices']['sd1']['predictive_failure_analysis'] == '0'

# Generated at 2022-06-20 17:43:15.224825
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:43:25.940737
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    mod_obj = {
        'ansible_facts': {
            'ansible_machine': 'i86pc'
        }
    }

    module.run_command = MagicMock(return_value=(0, '', ''))
    sunos_hw = SunOSHardware()
    sunos_hw.module = module
    result = sunos_hw.populate()

    assert 'processor' in result
    assert 'memtotal_mb' in result
    assert 'swaptotal_mb' in result
    assert 'system_vendor' in result
    assert 'devices' in result['devices']

# Generated at 2022-06-20 17:43:34.559754
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-20 17:43:47.401469
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    import sys
    if sys.version_info.major >= 3:
        from unittest.mock import patch, create_autospec
    else:
        from mock import patch, create_autospec
    import time
    test_object = SunOSHardware()
    mocked_time = create_autospec(time, spec_set=True, instance=True)
    mocked_time.time().return_value = 123456789
    with patch.object(time, 'time', mocked_time):
        test_object.run_command = lambda x: (0, 'unix:0:system_misc:boot_time    1548249689', '')
        res = test_object.get_uptime_facts()

# Generated at 2022-06-20 17:43:51.670238
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector_object = SunOSHardwareCollector()
    assert hardware_collector_object
    assert hardware_collector_object.platform == 'SunOS'
    assert hardware_collector_object.required_facts == set(['platform'])

# Generated at 2022-06-20 17:43:56.374588
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # This test is based on a test for the LinuxHardware class.
    # For the purposes of unit testing, assume that all executables are in path
    # and return the expected values.

    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error


# Generated at 2022-06-20 17:43:58.748573
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    h_obj = SunOSHardware({'ansible_facts': {'platform': "SunOS"}})
    assert h_obj.platform == "SunOS"

# Generated at 2022-06-20 17:44:03.826200
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule({})

    m = SunOSHardware(module)
    result = m.get_device_facts()

    assert 'devices' in result



# Generated at 2022-06-20 17:44:47.683520
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
        required_together=[]
    )

    out = """prtconf: System Configuration: VMware, Inc. VMware Virtual Platform
Memory size: 2048 Megabytes
System Peripherals (Software Nodes):
    SUNW,Ultra-5_10
"""

    rc = 0
    err = ''

# Generated at 2022-06-20 17:44:49.753058
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware()
    assert hardware_facts.platform == 'SunOS'


# Generated at 2022-06-20 17:45:01.654894
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Testing of the "size" stat of the disk
    fixture = """\
    sderr:0:sd0,err:Size    53687091200
    sderr:0:sd1,err:Size    ERR_RESULT_NOT_FOUND
    sderr:0:sd1,err:Size    0
    """
    result = {}
    result['devices'] = {}
    result['devices']['sd0'] = {'size': '5.0G'}
    result['devices']['sd1'] = {'size': '0B'}

    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict())

    hw = SunOSHardware(module)
    hw.module.run_command = MagicMock(return_value=(0, fixture, ''))


# Generated at 2022-06-20 17:45:02.938005
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    assert SunOSHardware.get_uptime_facts(None) is not None

# Generated at 2022-06-20 17:45:11.082580
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:45:22.496166
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Create a SunOSHardware instance
    sunos_hardware = SunOSHardware()

    # Set content of command output

# Generated at 2022-06-20 17:45:29.464343
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:45:31.839052
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    output = hardware.get_device_facts()

    assert 'devices' in output

# Generated at 2022-06-20 17:45:42.480798
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    import platform
    import datetime

    # If a system is booted at the 1.1.1970, the uptime should be at least 48 years.
    # The following return value is used for the mocked run_command.
    BOOTTIME_1970 = datetime.datetime(1970, 1, 1, 0, 0, 0).strftime('%s')

    module = mock.MagicMock()
    module.run_command.return_value = [0, BOOTTIME_1970, ""]

    hardware = SunOSHardware()
    hardware.module = module
    hardware.populate()

    facts = hardware.get_facts()
    uptime_seconds = facts['ansible_uptime_seconds']

    assert uptime_seconds > 48 * 365 * 3600
    assert uptime_seconds < 49 * 365 * 3600

# Generated at 2022-06-20 17:45:48.862584
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = SunOSHardwareCollector().collect()
    assert 'hardware' in facts
    assert 'cpu_facts' in facts['hardware']
    assert 'memory_facts' in facts['hardware']
    assert 'dmi_facts' in facts['hardware']
    assert 'device_facts' in facts['hardware']
    assert 'uptime_facts' in facts['hardware']



# Generated at 2022-06-20 17:47:13.321707
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    SunOSHardware(module, {}).get_memory_facts()

# Generated at 2022-06-20 17:47:14.398243
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = CustomModule()
    SunOSHardware(module)



# Generated at 2022-06-20 17:47:25.807938
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out = """Memory size: 8192 Megabytes"""
    module = MockModule(params={})
    facts = SunOSHardware(module).get_memory_facts()
    assert facts['memtotal_mb'] == 8192

    out = """Memory size: 8192 Gigabytes"""
    module = MockModule(params={})
    with pytest.raises(Exception):
        facts = SunOSHardware(module).get_memory_facts()

    out = """Memory size: 8192 Megabytes
             Memory size: 8192 Megabytes"""
    module = MockModule(params={})
    with pytest.raises(Exception):
        facts = SunOSHardware(module).get_memory_facts()

    out = """"""
    module = MockModule(params={})
    facts = SunOSHardware(module).get_memory_facts()

# Generated at 2022-06-20 17:47:34.916638
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Unit test for method get_uptime_facts of class SunOSHardware
    """

    # Mock input/output
    class Mock(object):
        module = "time"
        stdout = "b'unix:0:system_misc:boot_time\\t1548249689\\n'"
        rc = 0
        stderr = ""

    sunos_hardware_collector = SunOSHardware("time")
    sunos_hardware_collector.module = Mock()

    assert sunos_hardware_collector.get_uptime_facts() == {'uptime_seconds': 1548250065}

# Generated at 2022-06-20 17:47:47.904977
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('module', (), {'run_command': run_command_mock})
    hardware = SunOSHardware(module)

    # 1 device with 5 attributes with expected output
    expected_device_facts = {'devices': {
        'sd0': {
            'product': 'VBOX HARDDISK',
            'revision': '1.0',
            'serial': 'VB0ad2ec4d-074a',
            'size': '51.20 GB',
            'vendor': 'ATA',
            'hard_errors': '0',
            'soft_errors': '0',
            'transport_errors': '0',
            'media_errors': '0',
            'predictive_failure_analysis': '0',
            'illegal_request': '6'
        }
    }}

# Generated at 2022-06-20 17:47:58.839102
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test module for SunOSHardware class."""
    import re
    import sys
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda self, commands: (0, 'uname -i; kstat cpu_info', ''),
        'get_bin_path': lambda self, name, *args, **kwargs: 'prtconf',
        'params': {
            'timeout': 10,
            'gather_subset': ['all'],
        },
    })


# Generated at 2022-06-20 17:48:03.863782
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()

    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])



# Generated at 2022-06-20 17:48:06.648628
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    instance = SunOSHardware(module)
    assert instance.populate()



# Generated at 2022-06-20 17:48:08.894057
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(m)
    memory = hardware.get_memory_facts()
    assert memory['memtotal_mb'] == 1024

# Generated at 2022-06-20 17:48:14.709224
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test for method get_cpu_facts of class SunOSHardware
    """
    cmd = ['kstat', 'cpu_info']
    result = SunOSHardware.run_command(None, cmd)
    SunOSHardware.populate()
