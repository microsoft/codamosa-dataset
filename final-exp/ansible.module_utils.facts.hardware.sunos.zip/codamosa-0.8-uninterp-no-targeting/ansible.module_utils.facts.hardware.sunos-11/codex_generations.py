

# Generated at 2022-06-20 17:38:40.252692
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # get_device_facts should return same for all supported platforms
    assert hardware.get_device_facts() == {'devices': {}}

# Generated at 2022-06-20 17:38:44.484903
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    dmi = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi
    assert 'product_name' in dmi



# Generated at 2022-06-20 17:38:54.456627
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import platform

    machine = platform.machine()

    fake_module = object()
    fake_module.run_command = lambda *a, **kw: (0, 'sderr:0:sd0,err:Product VBOX HARDDISK\nsderr:1:sd1,err:Product VBOX HARDDISK', '')
    sh = SunOSHardware(fake_module)
    d = sh.get_device_facts()

    assert(d['devices']['sd0']['product'] == 'VBOX HARDDISK')
    assert(d['devices']['sd1']['product'] == 'VBOX HARDDISK')



# Generated at 2022-06-20 17:38:55.594251
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # do nothing, just exist to keep the test harness happy
    pass

# Generated at 2022-06-20 17:39:09.081067
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.sunos.collector.test_data import \
        SunOSHardware_get_device_facts_output_kstats_sderr

    module = MagicMock()
    module.run_command.return_value = (0, SunOSHardware_get_device_facts_output_kstats_sderr, "")
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()


# Generated at 2022-06-20 17:39:15.235031
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Runs a unit test to verify the functionality of the SunOSHardware class.
    """
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all']),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )

    set_module_args(dict(
        gather_subset=['all'],
        filter=['*'],
    ))

    # Instantiate SunOSHardware class
    sun_os_hardware = SunOSHardware(module)

    # Validate hardware facts that are common to all hardware vendors
    hardware_facts = sun_os_hardware.populate

# Generated at 2022-06-20 17:39:26.014266
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = 'ansible_collections.oracle.solaris.plugins.modules.hardware_memory_facts'
    test_class = 'SunOSHardware'
    test_method = 'get_memory_facts'
    sunos_hardware = SunOSHardware(test_module)

    with mock.patch.object(sunos_hardware, 'run_command') as run_command_mock:
        run_command_mock.return_value = 0, """Memory size: 16384 Megabytes"""
        memory_facts = sunos_hardware.get_memory_facts()
        assert memory_facts == {'memtotal_mb': 16384}


# Generated at 2022-06-20 17:39:29.452256
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.basic import AnsibleModule

    m_args = dict(
        path='/usr/bin:/usr/sbin:/bin:/usr/local/bin',
    )

    m = AnsibleModule(argument_spec=dict(),
                      supports_check_mode=True,
                      bypass_checks=True)

    s = SunOSHardware(m)
    assert s.get_uptime_facts() is not None

# Generated at 2022-06-20 17:39:39.238524
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    sun_hardware = SunOSHardware(module)
    sun_hardware.populate()
    memory_facts = sun_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4095 and memory_facts['swapfree_mb'] == 1023 and \
        memory_facts['swaptotal_mb'] == 4095 and memory_facts['swap_allocated_mb'] == 3072 and \
        memory_facts['swap_reserved_mb'] == 3072



# Generated at 2022-06-20 17:39:43.223475
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test SunOSHardware.get_cpu_facts with input data
    :return:
    """
    hardware = SunOSHardware()
    result = hardware.get_cpu_facts()
    assert isinstance(result, dict)
    assert 'processor' in result
    assert 'processor_count' in result
    assert 'processor_cores' in result


# Generated at 2022-06-20 17:40:01.989345
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x._platform == 'SunOS'

# Generated at 2022-06-20 17:40:05.939594
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = SunOSHardwareCollector._fact_class().get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:40:12.196634
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    # Initialize the instance of SunOSHardware() and populate it
    # with required facts.
    sunos_hw = SunOSHardware()
    facts_dict = {'platform': 'SunOS', 'system_vendor': 'Oracle Corporation', 'product_name': 'SUN XXXXXXXX'}
    sunos_hw.populate(facts_dict)

    # Assert that get_device_facts() return expected result.

# Generated at 2022-06-20 17:40:23.823686
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    data = [
        "System Configuration: VMware, Inc. VMware Virtual Platform",
        "System Configuration: Microsoft Corporation Virtual Machine",
        "System Configuration: Oracle Corporation sun4v",
        "System Configuration: SUNW,SPARC-Enterprise",
        "System Configuration: SUNW,SPARCEnterprise-T5120",
        "System Configuration: SUNW,SPARC-Enterprise-T5220"
    ]
    for system_conf in data:
        dmi_facts = SunOSHardware(dict(ansible_facts=dict(platform='SunOS'))).get_dmi_facts(system_conf)
        assert dmi_facts['system_vendor'] == 'Oracle Corporation'
        assert dmi_facts['product_name'] == 'sun4v'

# Generated at 2022-06-20 17:40:30.687811
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    This unit test can only be run from the shell and is not yet handled by
    the normal test framework
    """
    class MockModule:
        def __init__(self):
            self.run_command_rc = 0

# Generated at 2022-06-20 17:40:42.071577
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    class ModuleMock(object):
        def __init__(self, params=None):
            self.params = params

        # If there are no params in the argument, we mock get_bin_path
        # Otherwise, we give it a default value of True
        def get_bin_path(self, name, *a, **kw):
            if self.params is None:
                return True

            return '/usr/sbin/prtconf'

        @staticmethod
        def run_command(command, *a, **kw):
            return (0, command, '')


# Generated at 2022-06-20 17:40:48.455214
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    output = {'memtotal_mb': 7182}

    def run_command(cmd, *args, **kwargs):
        cmd = ' '.join(cmd)
        if cmd == '/usr/sbin/prtconf':
            return 0, 'Memory size: 7182 Megabytes', None
        else:
            raise NotImplementedError("Unexepected command %r" % cmd)

    def get_bin_path(bin_name, *args, **kwargs):
        if bin_name == 'prtdiag':
            return '/usr/sbin/prtdiag'

    module = Mock(run_command=run_command, get_bin_path=get_bin_path)
    hardware.module = module

    assert hardware.get_memory_facts() == output

# Generated at 2022-06-20 17:40:54.433643
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Instantiate a SunOS hardware collector test object
    sunos_hw_collector_obj = SunOSHardwareCollector('SunOS')
    # Make sure the correct fact class was assigned
    assert sunos_hw_collector_obj._fact_class == SunOSHardware

# Generated at 2022-06-20 17:41:06.042514
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = get_module_mock()

# Generated at 2022-06-20 17:41:18.883132
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module_mock = MagicMock()
    module_mock.run_command.return_value = 0,"""Memory size: 64 Megabytes
    System Board Information:
    product  Sun-Fire    (todim)
    serial   sgq28897df
    part no. 541-3012
    """,""
    module_mock.get_bin_path.return_value = "/usr/sbin/prtconf"
    sunos = SunOSHardware(module_mock)
    mem_facts = sunos.get_memory_facts()
    assert mem_facts.get('memtotal_mb') == 64

# Test for method get_cpu_facts of class SunOSHardware
# Test file for method get_cpu_facts of class SunOSHardware
# input: cpu_info_result from file

# Generated at 2022-06-20 17:41:52.459483
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 17:42:05.058354
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # list of collected facts
    collected_facts = {u'ansible_distribution': u'SmartOS',
                       u'ansible_distribution_major_version': u'19',
                       u'ansible_distribution_version': u'19.3.0',
                       u'ansible_machine': u'i86pc',
                       u'ansible_os_family': u'Solaris',
                       u'ansible_pkg_mgr': u'pkgsrc',
                       u'ansible_system': u'SunOS',
                       u'ansible_user_dir': u'/export/home/jeanguy',
                       u'ansible_userspace_bits': u'32',
                       u'gather_subset': [u'min'],
                       u'module_setup': True}


# Generated at 2022-06-20 17:42:08.179161
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    HWC = SunOSHardwareCollector()
    assert HWC._platform == 'SunOS'
    assert HWC.required_facts == set(['platform'])
    assert HWC._fact_class == SunOSHardware

# Generated at 2022-06-20 17:42:10.792219
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.fact_class == SunOSHardware
    assert collector.platform == 'SunOS'
# End of unit test for constructor of class SunOSHardwareCollector.

# Generated at 2022-06-20 17:42:11.811609
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_instance = SunOSHardware('module')
    assert hardware_instance.module == 'module'


# Generated at 2022-06-20 17:42:21.753926
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.utils import MockModule

    module = MockModule(facts={'platform': 'SunOS'})
    hardware = SunOSHardware(module)
    collected_facts = hardware.populate()

    assert collected_facts['system_vendor'] == 'VMware, Inc.'
    assert collected_facts['product_name'] == 'SUNW,SPARC-Enterprise'
    assert collected_facts['uptime_seconds'] == 5
    assert collected_facts['memtotal_mb'] == 256
    assert collected_facts['devices']['sd0']['vendor'] == 'ATA'
    assert collected_facts['processor_cores'] == 2
    assert collected_facts['processor_count'] == 2

# Generated at 2022-06-20 17:42:31.927508
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:44.006765
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.compat import mock
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-20 17:42:51.791866
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sys_facts = {
        'platform': 'SunOS'}
    mock_module = MagicMock(params={}, check_mode=False)
    mock_module.run_command.return_value = (0, "Memory size: 16384 Megabytes", None)
    hardware = SunOSHardware(mock_module)
    hardware.populate(sys_facts)

    assert hardware.get_memory_facts()['memtotal_mb'] == 16384
    mock_module.run_command.assert_called_once_with(['/usr/sbin/prtconf'])



# Generated at 2022-06-20 17:43:03.576273
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.module_args = ''
            self.debug = True
            self.warn = True
            self.fail_json = True

        def run_command(self, cmd):
            if self.run_command_calls == 0:
                self.run_command_calls += 1
                return (0, "boot_time\t123\n", '')
            elif self.run_command_calls == 1:
                self.run_command_calls += 1
                return (0, "", '')
            else:
                self.run_command_calls += 1
                return (1, "", '')


# Generated at 2022-06-20 17:44:11.703425
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Create a SunOSHardware object
    sunos_facts = SunOSHardware(dict())

    # Mock run_command() to return a known "prtdiag" output
    sunos_facts.module.run_command = MockCommand(["System Configuration: Sun Microsystems sun4u\n"])
    sunos_facts.module.run_command_environ_update = {}

    # Call populate()
    sunos_facts.populate()

    assert sunos_facts.facts['system_vendor'] == "Sun Microsystems"
    assert sunos_facts.facts['product_name'] == "sun4u"


# Generated at 2022-06-20 17:44:23.076552
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleFailJson
    from ansible_collections.ansible.community.tests.unit.modules.utils import ModuleTestCase

    # test code
    with open('/var/tmp/ansible_facts_hardware_test.dump', 'r') as f:
        ansible_facts_hardware_test = f.read()


# Generated at 2022-06-20 17:44:31.144123
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule:
        def run_command(self, command):
            return 0, 'unix:0:system_misc:boot_time    1548249689', 'ok'

    class FakeHardware:
        def __init__(self):
            self.module = FakeModule()

    fake_hardware = FakeHardware()
    assert fake_hardware.get_uptime_facts() is not None
    assert fake_hardware.get_uptime_facts().get('uptime_seconds') is not None

# Generated at 2022-06-20 17:44:32.746204
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware()
    print(hw.populate())


# Generated at 2022-06-20 17:44:38.501974
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = MockModule(platform='SunOS')

    sut = SunOSHardware(module)

    # Execute
    sut.get_dmi_facts()

    # Verify
    module.run_command.assert_any_call('/usr/bin/uname -i')
    module.run_command.assert_any_call('/usr/platform/SunOS/sbin/prtdiag')



# Generated at 2022-06-20 17:44:48.346625
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    collect = SunOSHardwareCollector()

    # Setup real data to return
    collected_facts = {'ansible_machine': 'i86pc', 'ansible_system_vendor': 'Sun Microsystems'}
    cpu_facts = {
        'processor': ['Intel(R) Xeon(R) CPU E5-2650L v2 @ 1.70GHz'],
        'processor_cores': 8,
        'processor_count': 2,
    }
    memory_facts = {
        'swap_allocated_mb': 6144,
        'swap_reserved_mb': 288,
        'memtotal_mb': 32040.0,
        'swaptotal_mb': 6144.0,
        'swapfree_mb': 5981.0,
    }

# Generated at 2022-06-20 17:45:00.722314
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=["!all"], type='list')
        ),
        supports_check_mode=True)

    # mocks
    SunOSHardware._module = module
    def __init__(self, module):
        self._module = module

    BaseFactCollector.__init__ = __init__

    #

# Generated at 2022-06-20 17:45:09.476550
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import datetime

    # Test data from a Sun X2100 server running Solaris 10

# Generated at 2022-06-20 17:45:20.333529
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Test data
    #
    # SunOS kstat cpu_info
    kstat_cpu_info = """module: 0
chip_id: 1
brand: sun4v
chip_rev: 1.0
clock_MHz: 1600
implementation: SPARC-T3
cores_per_chip: 1
cpu_type: sparcv9
"""
    #
    # SunOS prtconf
    prtconf = """Memory size: 32768 Megabytes
"""
    #
    # SunOS swap -s
    swap_s = """total: 131072k bytes allocated + 0k reserved = 131072k used, 16777216k available
"""
    #
    # SunOS mnttab

# Generated at 2022-06-20 17:45:25.365740
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Ugly hack to make this test run in a reasonable time.
    # It works because time.time() is called twice,
    # and the kstat output doesn't matter as long as it starts with a digit.
    SunOSHardware.get_uptime_facts.time_real = staticmethod(lambda: 1)

    assert SunOSHardware.get_uptime_facts()['uptime_seconds'] == 2

# Generated at 2022-06-20 17:47:56.664501
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    obj = SunOSHardware(module)

    obj.module.run_command = run_command_mock
    obj.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    memory_facts = obj.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 1000000
    assert memory_facts['swapfree_mb'] == 20000
    assert memory_facts['swaptotal_mb'] is not None
    assert memory_facts['swap_allocated_mb'] is not None
    assert memory_facts['swap_reserved_mb'] is not None


# unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:47:59.399605
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:48:04.796874
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_module = type('TestModule', (object,), {'run_command': run_command_mock})
    hardware = SunOSHardware(test_module)
    hardware.run()
    assert hardware.get_device_facts()['devices']['sda']['hard_errors'] == '0'


# Generated at 2022-06-20 17:48:09.937063
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware_obj = SunOSHardware(module)
    mock_run_cmd = mock.Mock()
    mock_run_cmd.return_value = (0, '', '')
    with mock.patch.object(module, 'run_command', mock_run_cmd):
        assert hardware_obj.get_cpu_facts() == {}


# Generated at 2022-06-20 17:48:13.380129
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.required_facts == set(['platform']), "The (initial) value of SunOSHardwareCollector.required_facts is wrong."