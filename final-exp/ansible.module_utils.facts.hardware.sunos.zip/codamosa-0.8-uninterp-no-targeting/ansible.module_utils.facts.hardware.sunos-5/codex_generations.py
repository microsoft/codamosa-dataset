

# Generated at 2022-06-20 17:38:40.111467
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    run_fake_kstat_command()
    sunos_hardware = SunOSHardware()
    assert sunos_hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:38:43.873332
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()

    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-20 17:38:47.233634
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule()
    sunos = SunOSHardware(module=module)
    uptime_facts = sunos.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:38:57.937567
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    from ansible.module_utils import basic

    # Define argument specification for the mock `module`
    argument_spec = dict(
        ansible_facts=dict(type='dict'),
        ansible_module_args=dict()
    )

    # AnsibleModule argument specification for the test 'module'
    am_args = dict(
        argument_spec=argument_spec,
        supports_check_mode=True
    )

    # Initialize the test 'module'
    module = basic.AnsibleModule(**am_args)

    # Generate a mock `basic.AnsibleModule`.

# Generated at 2022-06-20 17:39:01.630604
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_commands = Mock(return_value=(0, 'unix:0:system_misc:boot_time 1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - int('1548249689'))

# Generated at 2022-06-20 17:39:06.425580
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == {'platform'}
    assert hardware_collector._fact_class == SunOSHardware


# Generated at 2022-06-20 17:39:08.857117
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunOSHardware = SunOSHardware()
    assert (sunOSHardware.get_device_facts() is not None)

# Generated at 2022-06-20 17:39:13.095878
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:20.739573
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock()
    module.run_command = CommandMock('kstat -p sderr:::Product sderr:::Revision sderr:::Serial No sderr:::Vendor sderr:::Size sderr:::Hard Errors sderr:::Soft Errors sderr:::Transport Errors sderr:::Media Error sderr:::Predictive Failure Analysis sderr:::Illegal Request')

# Generated at 2022-06-20 17:39:28.714725
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Need to create a module_utils/facts/hardware/base.py Hardware class instance
    #
    # Need to create a module_utils/facts/hardware/sunos.py SunOSHardware class instance
    # Need to create a module_utils/facts/hardware/base.py HardwareCollector class instance
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.populate()

    assert hardware.sysctl == {}
    assert hardware.meminfo == {}
    assert hardware.dmi == {}


# Generated at 2022-06-20 17:39:57.924692
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    sunos_hardware = SunOSHardware(module)

    # Example facts from a SunOS system with an Oracle product name:
    expected = {u'system_vendor': u'Oracle Corporation', u'product_name': u'Sun Fire X4150'}

# Generated at 2022-06-20 17:40:02.817282
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible_collections.ansible.sunos.tests.unit.modules.utils import set_module_args

    module = AnsibleModule(argument_spec=dict())
    set_module_args(dict())

    # Create instance of class SunOSHardware
    hw = SunOSHardware(module)

    # Create a simple kstat output for prtconf.
    prtconf_out = """Memory size: 2048 Megabytes
""".encode('utf-8')

    # Create a simple kstat output for swap
    swap_out = """total: 16558684k bytes allocated + 5790500k reserved = 22343684k used, 803720k available
""".encode('utf-8')

    # Create a result dict
    result = dict()

    # Patching methods run_command, get_file_content

# Generated at 2022-06-20 17:40:09.597630
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleFake(
        dict(
            ANSIBLE_MODULE_ARGS={},
        )
    )
    setattr(module, 'run_command', run_command_mock)
    fact = SunOSHardware(module)

    out = fact.get_cpu_facts()

    assert 'processor' in out
    assert 'processor_count' in out
    assert 'processor_cores' in out


# Generated at 2022-06-20 17:40:21.541016
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    if module.check_mode:
        module.exit_json(changed=False)

    # generate test data for facts_module
    class CpuInfoModel(object):
        def __init__(self):
            self.raw = []
            self.raw.append('module: cpu_info')
            self.raw.append('cpu_info:0')
            self.raw.append('chip_id: 0')
            self.raw.append('implementation: SPARC-T4')
            self.raw.append('brand: SPARC-T4')
            self.raw.append('clock_MHz: 2500.000000')
            self.raw.append('state: on')

# Generated at 2022-06-20 17:40:33.385011
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware_obj = SunOSHardware()
    # Ensure get_memory_facts only succeeds if module is not None
    assert hardware_obj.get_memory_facts() == {}

    # Ensure get_memory_facts sets memtotal_mb
    # we need to create a module object, what if it was None?
    hardware_obj.module = object()

    def run_command_mock(cmd, *args, **kwargs):
        return 1, 'Memory size: 8192 Megabytes', ''
    hardware_obj.module.run_command = run_command_mock
    assert hardware_obj.get_memory_facts() == {'memtotal_mb': 8192}
    assert hardware_obj.get_memory_facts() == {'memtotal_mb': 8192}

    # Ensure get_memory_facts sets swapfree_mb, swaptotal

# Generated at 2022-06-20 17:40:39.122122
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}

    # sample kstat output:
    # unix:0:system_misc:boot_time    1548249689
    uptime_facts['uptime_seconds'] = int(time.time() - 1548249689)

    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:40:52.329902
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MyModule:
        def run_command(self, cmd):
            if cmd == '/usr/sbin/prtconf':
                return 0, 'Memory size:        3138 Megabytes', ''
            elif cmd == '/usr/sbin/swap -s':
                return 0, 'total: 61724k bytes allocated + 18212k reserved = 79936k used, 136928k available', ''
            else:
                raise AssertionError('Unexpected call to MyModule.run_command()', cmd)

    class MySunOSHardware(SunOSHardware):
        module = MyModule()

    sunos_facts = MySunOSHardware()

    mem_facts = sunos_facts.get_memory_facts()


# Generated at 2022-06-20 17:41:04.031477
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    mock_module = type("module", (), {})()
    hardware = SunOSHardware(mock_module)


# Generated at 2022-06-20 17:41:05.779301
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunos_collector = SunOSHardwareCollector()
    assert sunos_collector.platform == 'SunOS'

# Generated at 2022-06-20 17:41:13.431613
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    facts = SunOSHardware(module).get_cpu_facts()
    assert facts['processor'][0] == "SPARC64-X+ @ 1691MHz"
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 4


# Generated at 2022-06-20 17:41:56.912610
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:09.434906
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-20 17:42:15.006111
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(
        argument_spec=dict()
    )

# Generated at 2022-06-20 17:42:24.279253
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    l = 10

    class MockModule(object):
        def run_command(self, *args):
            out = """
Memory size: {} Megabytes
""".format(l)
            return 0, out, ''

    class MockOs(object):
        def __init__(self):
            self.modules = MockModule()

    os = MockOs()
    hw = SunOSHardware(os)
    assert hw.get_memory_facts()['memtotal_mb'] == l

# Generated at 2022-06-20 17:42:33.956800
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            # Return sample prtdiag output
            out = """System Configuration: VMware, Inc. VMware Virtual Platform
                                    Sun Microsystems sun4v"""
            return 0, out, ''

        def get_bin_path(self, cmd, opt_dirs=[]):
            # Return fake for get_bin_path
            return '/usr/bin/prtdiag'

    class MockFactCollector(object):
        def __init__(self):
            self.ansible_facts = {}

    class MockFacts(object):
        def __init__(self):
            self.collector = MockFactCollector()

    result = {}
    m = MockModule()
    f = MockF

# Generated at 2022-06-20 17:42:46.098810
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock(return_value=(0, """module: cpu_info
instance: 0
class: misc
chip_id   0
core_id   0
clock_MHz 2400
state     on-line
module: cpu_info
instance: 1
class: misc
chip_id   0
core_id   1
clock_MHz 2400
state     on-line
module: cpu_info
instance: 2
class: misc
chip_id   0
core_id   2
clock_MHz 2400
state     on-line
module: cpu_info
instance: 3
class: misc
chip_id   0
core_id   3
clock_MHz 2400
state     on-line""", ''))
    res = hardware.get_cpu_

# Generated at 2022-06-20 17:42:56.847324
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 17:43:02.851454
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    h = SunOSHardware()
    dmi_facts = h.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-20 17:43:09.683322
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:43:13.871344
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_collector = SunOSHardwareCollector()
    hardware_object = hardware_collector._fact_class({'platform': 'SunOS'}, {})

    assert hardware_object._platform == 'SunOS'

# Generated at 2022-06-20 17:44:01.622032
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    get_cpu_facts_test_fact_subset = dict(ansible_processor=['Genuine Intel(R) CPU @ 2.00GHz', 'Genuine Intel(R) CPU @ 2.00GHz'],
                                          processor_cores=2,
                                          processor_count=2,
                                          processor=['Genuine Intel(R) CPU @ 2.00GHz', 'Genuine Intel(R) CPU @ 2.00GHz'])
    class LinuxHardwareNoRun:
        def __init__(self, module):
            self.module = module

        def populate(self, collected_facts=None):
            return dict(processor=['Genuine Intel(R) CPU @ 2.00GHz', 'Genuine Intel(R) CPU @ 2.00GHz'])


# Generated at 2022-06-20 17:44:06.206010
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Our test case
    rc, out, err = module.run_command("/usr/sbin/prtconf")
    for line in out.splitlines():
        data = line.split()
        if len(data) < 1:
            continue
        if data[0] == 'Memory':
            test_memtotal_mb = data[2]

    rc, out, err = module.run_command("/usr/sbin/swap -s")

    test_swap_allocated_mb = out.split()[1][:-1]
    test_swap_reserved_mb = out.split()[5][:-1]
    test_swaptotal_mb = out.split()[8][:-1]
    test

# Generated at 2022-06-20 17:44:10.776859
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    m = SunOSHardware(module)

    populate_result = m.populate()

    assert 'processor' in populate_result
    assert 'system_vendor' in populate_result
    assert 'product_name' in populate_result
    assert 'memtotal_mb' in populate_result
    assert 'swapfree_mb' in populate_result
    assert 'swaptotal_mb' in populate_result
    assert 'swap_allocated_mb' in populate_result
    assert 'swap_reserved_mb' in populate_result
    assert 'mounts' in populate_result
    assert 'devices' in populate_result
    assert 'uptime_seconds' in populate_result


# Generated at 2022-06-20 17:44:17.885139
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    hardware_info = SunOSHardware().populate()
    assert hardware_info['ansible_processor_count'] == 1, 'Number of processor should be 1'
    assert hardware_info['ansible_processor_cores'] == 1, 'Number of processor core should be 1'


# Generated at 2022-06-20 17:44:25.571943
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    module.run_command = FakeRunCommand(
        commands_results=[
            # Run command /usr/bin/uname -i
            ("i86pc",    "", ""),

            # Run command /usr/platform/i86pc/sbin/prtdiag
            ("", "System Configuration: "
                "VMware, Inc. Virtual Platform\n", ""),
        ]
    )
    module.get_bin_path = lambda x, a: "/usr/platform/i86pc/sbin/prtdiag"
    sunoshw = SunOSHardware(module)
    facts = sunoshw.get_dmi_facts()
    assert facts["system_vendor"] == "VMware, Inc."
    assert facts["product_name"] == "Virtual Platform"


# Generated at 2022-06-20 17:44:28.915172
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'platform': 'test'}, {})
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:44:32.702992
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardwareCollectorObj = SunOSHardwareCollector()
    assert hardwareCollectorObj._fact_class == SunOSHardware
    assert hardwareCollectorObj._platform == 'SunOS'
    assert hardwareCollectorObj.required_facts == set(['platform'])


# Generated at 2022-06-20 17:44:43.869221
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    n = SunOSHardware(module)

    cpu_facts_data = n.get_cpu_facts()

    number_of_processors_expected = 1
    number_of_processors_actual = cpu_facts_data['processor_count']
    assert number_of_processors_actual == number_of_processors_expected, "number of processors is wrong."

    clock_speed_expected = "NA"
    clock_speed_actual = cpu_facts_data['ansible_processor_cpu_clock_MHz']
    assert clock_speed_actual == clock_speed_expected, "cpu clock speed is wrong."

    cpu_model_actual = cpu_facts_data['ansible_processor'][0]

# Generated at 2022-06-20 17:44:56.667307
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = getattr(__import__('ansible.modules.system.hardware', fromlist=['AnsibleModule']),
                     'AnsibleModule')

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
        """Return hard coded commands."""
        out = ''

# Generated at 2022-06-20 17:45:02.932954
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {}
    sunos_hw = SunOSHardwareCollector(facts, {})
    assert sunos_hw._facts is facts
    assert sunos_hw.required_facts == set(['platform'])
    assert sunos_hw.optional_facts == set()

# Unit test to confirm that class SunOSHardwareCollector
# fails when required params are missing.
# When required params are missing the 'collect' method
# will not be called.

# Generated at 2022-06-20 17:46:41.938183
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    platform_facts = {'platform': 'SunOS'}
    fact_klass = SunOSHardware(platform_facts)

    fact_klass.module.run_command = lambda *args, **kwargs: (0, '', '')

    fact_klass.module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/prtconf'

    fact_klass.get_cpu_facts = lambda: {'processor_cores': 4, 'processor_count': 2}

    fact_klass.module.get_file_content = lambda *args, **kwargs: 'memory size = 1TB'

    fact_klass.get_dmi_facts = lambda: {'product_name': 'VBOX'}


# Generated at 2022-06-20 17:46:51.702537
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    class DummyModule(object):

        def __init__(self):
            self.params = {}
            self.run_command_environ_update = {}
            self.run_command_sudo = False

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False):
            return 0, "module_utils/ansible/module_utils/facts/hardware/sunos/test_data/kstat_cpu_info", ""

    module = DummyModule()
    sunos_hardware = SunOSHardware(module=module)

    cpu_facts = sunos_hardware.get_cpu_facts()

# Generated at 2022-06-20 17:47:03.439319
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, lines):
            self.lines = lines

        def run_command(self, command):
            return 0, self.lines, ''

    # Create a mock module object
    module = MockModule(
        lines="""
module:   module_1
chip_id:  chip_id_a
brand:    brand_a

module:   module_2
chip_id:  chip_id_a
brand:    brand_a

module:   module_3
chip_id:  chip_id_b
brand:    brand_b

module:   module_4
chip_id:  chip_id_b
brand:    brand_b
        """.split('\n')
    )

    # Create a SunOSHardware object
    hardware_obj = SunOSHardware

# Generated at 2022-06-20 17:47:06.795021
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.legacy import DummyLegacyCollector
    hardware = SunOSHardware(DummyLegacyCollector())
    assert hardware.get_uptime_facts() == {'uptime_seconds': 9634}

# Generated at 2022-06-20 17:47:09.708268
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = SunOSHardwareCollector(dict(), None)

    assert facts.required_facts == set(['platform'])
    assert facts._platform == 'SunOS'
    assert facts._fact_class == SunOSHardware

# Generated at 2022-06-20 17:47:17.459440
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    The method _get_uptime_facts in SunOSHardware returns the uptime_seconds
    fact by reading kstats. For this unit test, no kstat is returned as it is
    a dummy module object.
    """
    class DummyModule:
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time 1548249689', ''

    class DummyHardware(SunOSHardware):
        def __init__(self):
            self.module = DummyModule()

    d = DummyHardware()
    uptime_facts = d.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-20 17:47:27.971997
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.sunos.hardware import SunOSHardware
    import ansible.module_utils.facts.hardware.sunos.hardware

    ansible.module_utils.facts.hardware.sunos.hardware.time = time
    ansible.module_utils.facts.hardware.sunos.hardware.SunOSHardware = SunOSHardware

    boottime = 1548249689

    class TestModule(object):
        run_command = _get_runcommand_mock(boottime)

    testharness = SunOSHardware(TestModule)
    uptime = testharness.get_uptime_facts()
    assert uptime['uptime_seconds'] == int(time.time()) - boottime

# Generated at 2022-06-20 17:47:40.623234
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-20 17:47:43.777367
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == _platform
    assert collector.fact_class == _fact_class
    assert collector.required_facts == _required_facts

# Generated at 2022-06-20 17:47:54.659796
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule():
        def run_command(self, arg1):
            if arg1 == "kstat -p unix:0:system_misc:boot_time":
                return 0, "unix:0:system_misc:boot_time    1548249689", ""
            else:
                raise Exception("error")

    sun_hs = SunOSHardware(MockModule())
    uptime_facts = sun_hs.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == (int(time.time()) - 1548249689)


if __name__ == '__main__':
    test_SunOSHardware_get_uptime_facts()