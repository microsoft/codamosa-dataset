

# Generated at 2022-06-20 17:38:47.278581
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sunos_hw = SunOSHardware(module)

    facts = sunos_hw.populate()

    assert facts['ansible_processor'] == ['SPARC T4 (chipid 0, clock 1200 MHz) @ 1200MHz', 'SPARC T4 (chipid 1, clock 1200 MHz) @ 1200MHz']
    assert facts['processor_count'] == 2
    assert facts['processor_cores'] == 8
    assert facts['product_name'] == 'SPARC T4-2'
    assert facts['system_vendor'] == 'Oracle Corporation'
    assert facts['mounts'][0]['size_total'] > 0


# Generated at 2022-06-20 17:38:57.975478
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This test validates the populating of SunOS hardware facts.
    """
    module = AnsibleModuleMock("SunOSHardware", "SunOS")

    test_hardware = SunOSHardware(module)
    # Test hardware fact population
    hardware_facts = test_hardware.populate()

    assert hardware_facts.get('processor') == ['Genuine Intel(R) CPU 0000 @ 2.40GHz']
    assert hardware_facts.get('processor_cores') == 8
    assert hardware_facts.get('processor_count') == 2
    assert hardware_facts.get('memtotal_mb') == 7791
    assert hardware_facts.get('swapfree_mb') > 0
    assert hardware_facts.get('swaptotal_mb') > 0
    assert hardware_facts.get('swap_allocated_mb')

# Generated at 2022-06-20 17:39:09.363131
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Test case #1
    # In this test case, the value of kstat command is a number which is more than 0
    # assert_equal() tests if the output is a number which is more than 0
    from ansible.module_utils.facts.facts import Facts

    module = AnsibleModuleMock(dict(platform='SunOS'))
    facts = Facts(module)
    module.run_command.return_value = (0, '1234', '')

    fact_class = SunOSHardware(facts)
    fact_class.populate()

    assert_equal(int(module.run_command.call_args_list[0][0][0][2]), 0)
    assert_greater(int(fact_class.get_uptime_facts().get('uptime_seconds')), 0)

    # Test case #2
   

# Generated at 2022-06-20 17:39:15.459631
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import json
    import io

    with io.open('tests/facts/ansible_local/data/SunOS.json', encoding='utf-8') as data_file:
        testdata = json.load(data_file)

    hardware = SunOSHardware()

    run_command = lambda arg: (0, testdata['kstat_cpu_info'], '')
    run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    # Monkey patch to make sure the normal run_command is not called
    hardware.module.run_command = run_command
    hardware.module.run_command_environ_update = run_command_environ_update

    data = hardware.populate()


# Generated at 2022-06-20 17:39:28.178834
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class Module:
        def __init__(self):
            self.run_command_environ_update = {}

        def run_command(self, args):
            if args[0] == "/usr/sbin/swap -s":
                out = (
                    "total: 742676k bytes allocated + 21020k reserved = 763696k used, "
                    "1998512k available")
                return (0, out, "")
            if args[0] == "/usr/sbin/prtconf":
                out = "Memory size: 8192 Megabytes"
                return (0, out, "")

    m = Module()
    hardware = SunOSHardware(m)
    facts = hardware.get_memory_facts()

# Generated at 2022-06-20 17:39:39.081162
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:49.942542
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock({})
    module.run_command = run_command_mock

    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == [
        'SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz',
        'SPARC64-VII (chipid 1, clock 1200 MHz) @ 1200MHz',
        'SPARC64-VII (chipid 2, clock 1200 MHz) @ 1200MHz',
        'SPARC64-VII (chipid 3, clock 1200 MHz) @ 1200MHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 4
    assert hardware_facts['memtotal_mb'] == 49152
    assert hardware_facts['swapfree_mb'] == 38

# Generated at 2022-06-20 17:39:58.448743
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test_data = {'uptime_seconds': 1483234340}
    test_expected_result = {'uptime_seconds': 1548249689}
    module = MockModule()
    hardware = SunOSHardware(module)
    # Insert the mock data into uptime_facts
    hardware.uptime_facts = test_data
    # Call the method get_uptime_facts of class SunOSHardware
    hardware.get_uptime_facts()
    actual_result = hardware.uptime_facts
    # Compare the actual result with the expected result
    assert test_expected_result == actual_result


# Generated at 2022-06-20 17:39:59.952095
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({}, {})
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:40:03.980346
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class ModuleStub:
        def run_command(self, args):
            return 0, '', ''

    hw = SunOSHardware(ModuleStub())
    result = hw.get_device_facts()
    assert result.get('devices', None)

# Generated at 2022-06-20 17:40:35.234715
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Unit test for the get_uptime_facts method of class SunOSHardware
    """

    class MockModule(object):
        """
        Mock module class
        """
        class MockRunCommand(object):
            """
            Mock Run command class
            """
            def __init__(self, boot_time):
                """
                Mock Run command class constructor
                """
                self.boot_time = str(boot_time).encode('utf-8')

            def __call__(self, *args, **kwargs):
                """
                Mock Run command method
                """
                return 0, self.boot_time, ''

        def __init__(self, boot_time):
            """
            Mock module class constructor
            """
            self.run_command = self.MockRunCommand(boot_time)

    # Use a

# Generated at 2022-06-20 17:40:44.752672
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    class FakeModule:
        pass

    class FakeModuleUtils:
        pass

    m = FakeModule()
    m.run_command = lambda: (0, '', '')
    m.run_command.__doc__ = 'used for asserting the number of calls'
    m.run_command_environ_update = None
    m.get_bin_path = lambda what, where=None: what
    m.get_bin_path.__doc__ = 'used for asserting the number of calls'
    m.params = dict()
    from ansible.module_utils.facts import ansible_local

    facts_collector = SunOSHardwareCollector()

# Generated at 2022-06-20 17:40:48.035086
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Test class constructor
    """
    collecter = SunOSHardwareCollector()
    assert collecter._fact_class is SunOSHardware



# Generated at 2022-06-20 17:40:55.681945
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Define a dummy module
    module = AnsibleModule(argument_spec={})

    # Create instance of SunOSHardwareCollector
    # Note that the above variables MUST be prefixed with ansible_
    sunos_hw_collector = SunOSHardwareCollector(module)

    # Test if the default platform is valid
    assert sunos_hw_collector._platform == 'SunOS'

    # Test if the default fact class is valid
    assert sunos_hw_collector._fact_class == SunOSHardware

# Generated at 2022-06-20 17:41:07.063998
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # data set
    test_prtcon_output = """
System Configuration:  Sun Fire X4470
Memory size:           32192 Megabytes

===========================================================

System Configuration:  Sun Fire X4470
Memory size:           32192 Megabytes
"""
    test_swap_output = """
swapfile             dev  swaplo   blocks   free
/dev/dsk/c2t0d0s1    -     16     8388608 8388608
"""

    # initialization
    solaris_hardware = SunOSHardware({})

    # mock
    solaris_hardware.module.run_command.return_value = (0, test_prtcon_output, "")
    solaris_hardware.module.run_command.return_value = (0, test_swap_output, "")

   

# Generated at 2022-06-20 17:41:16.148437
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    collected_facts = {}
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'ansible_prtdiag_out' not in facts



# Generated at 2022-06-20 17:41:24.266170
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test_data = [
        ('unix:0:system_misc:boot_time 1537912826\n', 1537912826),
        ('unix:0:system_misc:boot_time 1537912826', 1537912826),
        ('unix:0:system_misc:boot_time 1537912826\nunix:0:system_misc:blah', 1537912826),
        ('unix:0:system_misc:boot_time 1537912826\nunix:0:system_misc:boot_time 1537912826', 1537912826)
    ]
    for test in test_data:
        module = type('', (object,), {})
        module.run_command = lambda x, **kwargs: (0, test[0], None)
        hw = SunOSHardware(module)

# Generated at 2022-06-20 17:41:29.216586
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    module.run_command = Mock(return_value=[0, "System Configuration: Sun Microsystems sun4u", ""])

    hw = SunOSHardware(module)

    dmi_facts = hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'


# Generated at 2022-06-20 17:41:35.770629
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector(None)
    assert obj.facts == {}, "Facts should be empty dictionary"
    assert obj._fact_class == SunOSHardware, \
        "_fact_class should be assigned as SunOSHardware"
    assert obj._platform == "SunOS", "_platform should be assigned as SunOS"
    assert obj.required_facts == set(['platform'])
# end of test_SunOSHardwareCollector()


# Generated at 2022-06-20 17:41:41.086421
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_hardware_collector = SunOSHardwareCollector()
    assert sun_hardware_collector._fact_class == SunOSHardware
    assert sun_hardware_collector._platform == 'SunOS'
    assert sun_hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:42:02.791769
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware = SunOSHardwareCollector({'platform': 'SunOS'})


# Generated at 2022-06-20 17:42:05.217148
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    h = SunOSHardwareCollector()
    assert h._platform == 'SunOS'

# vim: set et ts=4 sw=4:

# Generated at 2022-06-20 17:42:13.212397
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Tests a single method of the SunOSHardware class
    """
    mock_module = create_ansible_mock_module(dict(platform='SunOS'))

    sh = SunOSHardware(mock_module)
    hardware_facts = sh.populate()
    assert hardware_facts['system_vendor'] is not None
    assert hardware_facts['product_name'] is not None
    assert hardware_facts['processor_cores'] is not None
    assert hardware_facts['processor_count'] is not None
    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['swap_allocated_mb'] is not None
    assert hardware_facts['swap_reserved_mb'] is not None

# Generated at 2022-06-20 17:42:21.700231
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.run_command = MagicMock(return_value=(
        0, "System Configuration: Fujitsu SPARC Enterprise T5240", ""))
    hardware = SunOSHardware(module=module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'SPARC Enterprise T5240'



# Generated at 2022-06-20 17:42:31.894517
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.hardware.sunos import SunOSHardware

    class ModuleFake:
        class run_command(object):
            def __init__(self, return_val):
                self.return_val = return_val

            def __call__(self, *args, **kwargs):
                return self.return_val

    # module = ModuleFake(return_val=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    fact = SunOSHardware(ModuleFake())

    # The unit test will fail sometime near 2106
    current_time = datetime.datetime.now().timestamp()
    boot_time = 1548249689

    assert fact.get_uptime

# Generated at 2022-06-20 17:42:33.391256
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    SunOSHardware(module).populate()

# Generated at 2022-06-20 17:42:38.563673
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    # Mock
    class_hardware = SunOSHardware(module)
    # Fake
    class_hardware.get_cpu_facts = lambda: {'processor_count': 8}
    class_hardware.get_memory_facts = lambda: {'memtotal_mb': 8192}
    # Test
    class_hardware.populate()
    assert module.exit_json.called
    assert module.exit_json.call_args[0][0]['ansible_processor_count'] == 8
    assert module.exit_json.call_args[0][0]['ansible_memtotal_mb'] == 8192


# Generated at 2022-06-20 17:42:40.915319
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_instance = SunOSHardware(dict())
    assert hardware_instance.platform == 'SunOS'

# Generated at 2022-06-20 17:42:46.468387
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    h = SunOSHardware({})
    s = h.get_dmi_facts()
    assert(s == {} or 'system_vendor' in s and s['system_vendor'])


# Generated at 2022-06-20 17:42:49.081788
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sys_vendor = SunOSHardwareCollector(None, None)
    assert isinstance(sys_vendor._fact_class, SunOSHardware)

# Generated at 2022-06-20 17:43:17.941378
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock({'ansible_architecture': 'x86_64'})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 0
    assert memory_facts['swapfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swap_reserved_mb'] == 0
    assert memory_facts['swap_allocated_mb'] == 0

# Generated at 2022-06-20 17:43:19.788243
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    assert SunOSHardware(module).platform == 'SunOS'


# Generated at 2022-06-20 17:43:26.883125
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule()
    module.run_command = MagicMock(
        return_value=(0, 'unix:0:system_misc:boot_time    1548249689', '')
    )
    sunos_hardware = SunOSHardware(module)

    assert sunos_hardware.get_uptime_facts() == \
           {'uptime_seconds': 1548249699 - 1548249689}

# Generated at 2022-06-20 17:43:36.839584
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # We create a MockModule
    from ansible.module_utils.facts.test_utils.mock import MockModule
    mock_module = MockModule({},
                             "SunOS",
                             "SunOS")

    def rci_sub_set(cmd):
        if cmd in [['sysdef'], ['/bin/uname', '-i'], ['/usr/bin/uname', '-i'],
                   ['/usr/sbin/prtconf'], ['/usr/bin/lanscan'], ['/usr/sbin/swap', '-s']]:
            return 0, '', ''

# Generated at 2022-06-20 17:43:43.374490
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test case to validate 'get_cpu_facts' method of class SunOSHardware.
    """
    module = AnsibleModule(argument_spec={})
    obj = SunOSHardware(module)
    obj.get_cpu_facts()



# Generated at 2022-06-20 17:43:49.331668
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule()
    module.run_command = lambda x: (0, "unix:0:system_misc:boot_time    1548249689", "")

    platform_solaris = SunOSHardware(module)
    uptime_facts = platform_solaris.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)



# Generated at 2022-06-20 17:44:00.986373
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Sample output of prtdiag -s:
    # System Configuration: VMware, Inc. VMware Virtual Platform
    # BIOS Configuration: Phoenix Technologies LTD 6.00 07/24/2018
    module = AnsibleModule(argument_spec={})
    module.params['filter'] = None
    module.params['gather_subset'] = None
    module.params['gather_timeout'] = 10
    runner = AnsibleRunner(module)
    facts = runner.run()['ansible_facts']
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts(facts)
    assert dmi_facts == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

# Generated at 2022-06-20 17:44:02.871820
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    aa = SunOSHardware()
    aa.module.run_command = lambda x: (0, str(int(time.time())), '')
    result = aa.get_uptime_facts()
    assert result['uptime_seconds'] > 0

# Generated at 2022-06-20 17:44:04.678158
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    SunOSHardwareCollector.populate(module.params)

    assert 'system_vendor' in module.ansible_facts
    assert 'product_name' in module.ansible_facts



# Generated at 2022-06-20 17:44:06.921975
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    sunoshardware_obj = SunOSHardware(module)
    hardware_facts = sunoshardware_obj.populate()
    assert hardware_facts['devices']['sda']

# Generated at 2022-06-20 17:44:38.413092
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class test_Hardware(SunOSHardware):
        def _run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            rc, out, err = 0, '', ''
            if args[-1] == 'sderr:::Product':
                out = 'sderr:0:sd0,err:Product VBOX HARDDISK 9\nsderr:0:sd1,err:Product VBOX HARDDISK 10\n'
            if args[-1] == 'sderr:::Revision':
                out = 'sderr:0:sd0,err:Revision 0.0\nsderr:0:sd1,err:Revision 0.0\n'

# Generated at 2022-06-20 17:44:42.965131
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    mod_args = dict(gather_subset='all', gather_timeout=10)
    sun_hw_collector = SunOSHardwareCollector(module=MagicMock(**mod_args))
    assert isinstance(sun_hw_collector._fact_class, SunOSHardware)

# Generated at 2022-06-20 17:44:55.553016
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # test case where we don't get boot time from kstat
    module = Mock()
    module.run_command.return_value = (0, '', '')
    hc = SunOSHardware(module=module)
    uptime_facts = hc.get_uptime_facts()
    assert not uptime_facts

    # test case where we can parse the boot time from kstat
    module = Mock()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time\t1548249689', '')
    hc = SunOSHardware(module=module)
    uptime_facts = hc.get_uptime_facts()
    assert uptime_facts
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-20 17:44:58.181482
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {'uptime_seconds': 1548249689}
    t = SunOSHardwareCollector()
    assert t.get_uptime_facts() == uptime_facts

# Generated at 2022-06-20 17:45:05.500134
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockDISKModule()
    SunOSHardware.module = module
    SunOSHardware.populate()
    out = module.run_command.call_args[0][1]
    cpu_facts = SunOSHardware.get_cpu_facts()
    # Test if get_cpu_facts() of class SunOSHardware returns expected value
    assert cpu_facts == {'processor': ['SUNW,UltraSparc-II @ 300MHz'],
                         'processor_cores': 'NA',
                         'processor_count': 1}


# Generated at 2022-06-20 17:45:12.820746
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create an instance of the get_memory_facts method of class SunOSHardware
    # to test the method get_memory_facts with
    # the following command line:
    # /usr/sbin/prtconf
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    hw_instance = SunOSHardware()
    hw_instance.module = module

    lines = ['Memory size: 2048 Megabytes']

    f = open(os.devnull, 'w')
    with mock.patch.object(builtins, 'open', mock.mock_open(read_data=lines)):
        with mock.patch('os.path.exists', return_value=True):
            with mock.patch('os.access', return_value=True):
                memory_facts = h

# Generated at 2022-06-20 17:45:14.761444
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:45:20.577643
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    facts = {}
    facts['platform'] = 'SunOS'

    def run_command_mock(args, check_rc=True, close_fds=True):
        return 0, "", ""

    SunOSHardwareObj = SunOSHardware(facts, None, run_command_mock)
    assert SunOSHardwareObj.platform == "SunOS"



# Generated at 2022-06-20 17:45:28.698868
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import re

    class MockModule(object):
        def __init__(self, output):
            self.output = output

        def run_command(self, cmd):
            if re.compile('kstat -p sderr:::.*').match(cmd):
                # return kstat output in lines
                return 0, self.output, ''
            elif re.compile('kstat -p sderr:::sderr_stats:::bytes_.*').match(cmd):
                # return kstat output in lines
                return 0, self.output, ''
            return -1, '', ''

    class MockFactCollector(object):
        def __init__(self, facts):
            self.facts = facts

        def get_facts(self):
            return self.facts


# Generated at 2022-06-20 17:45:39.504683
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a fake module with a mocked-out run_command
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_bytes

    test_prtconf_output = '''
System Configuration: Sun Microsystems sun4u
Memory size: 16384 Megabytes
System Peripherals (Software Nodes):
--------------------------------------------------------------------------
pci1022,1a00@1,1
--------------------------------------------------------------------------
.'''.strip('\n')

    test_dmi_facts = {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}


# Generated at 2022-06-20 17:46:16.311724
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    facts = {
        'platform': 'SunOS'
    }

    # Values from test_SunOSHardware_get_cpu_facts
    cpu_facts = {
        'processor': ['SUNW,SPARC-Enterprise'],
        'processor_cores': 4,
        'processor_count': 1
    }

    # Values from test_SunOSHardware_get_memory_facts
    memory_facts = {
        'swapfree_mb': 246,
        'swaptotal_mb': 247,
        'swap_allocated_mb': 247,
        'swap_reserved_mb': 247,
        'memtotal_mb': 2468
    }

    # Values from test_SunOSHardware_get_dmi_facts

# Generated at 2022-06-20 17:46:19.518632
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    facts = hardware.get_device_facts()
    assert 'devices' in facts.keys()


# Generated at 2022-06-20 17:46:28.478907
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    from ansible.module_utils.facts.collector import FactsCollector

    # inventory_hostname
    # ansible_play_hosts_all
    module_run_args = dict(
        inventory_hostname='fake_inventory_hostname',
        ansible_play_hosts_all=['fake_inventory_hostname'],
    )

    module = MagicMock()
    module.run_command = MagicMock(return_value=(0, 'fake_kstat_output', ''))
    module.get_file_content = MagicMock(return_value=None)
    module.get_bin_path = MagicMock(return_value='/usr/bin/prtdiag')
    module.params = dict()


# Generated at 2022-06-20 17:46:39.487111
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class TestModule():
        def __init__(self):
            self.run_command = lambda *a, **kw: (0, "", "")

    module = TestModule()

    hw = SunOSHardware(module=module)
    assert hw.get_device_facts() == {}

    # with facts

# Generated at 2022-06-20 17:46:49.636237
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import sys
    sys.path.append('/usr/sbin')
    sys.path.append('/usr/bin')
    import ansible.module_utils.facts.hardware.sunos
    test_obj = ansible.module_utils.facts.hardware.sunos.SunOSHardware()

# Generated at 2022-06-20 17:46:59.245382
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Create a SunOSHardware object for testing.
    module = AnsibleModuleStub()
    sunoshw = SunOSHardware(module)

    # Create a fact collection object and add some cpu facts.
    fact_collector = fact_collector_class()
    fact_collector['ansible_processor'] = ['i86pc']

    cpu_facts = sunoshw.get_cpu_facts(fact_collector)
    # Check the value of cpu_facts.
    expected_cpu_facts = {'processor_count': 1, 'processor_cores': 1}
    assert cpu_facts == expected_cpu_facts


# Generated at 2022-06-20 17:47:06.508037
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self, run_command=None, **kwargs):
            self.run_command = run_command

        def get_bin_path(self, arg, **kwargs):
            return "/usr/sbin/swap"

    # prtconf
    cmd = {
        'rc': 0,
        'out': 'System Configuration: Sun Microsystems sun4u\nMemory size: 4096 Megabytes\n',
        'err': ''
    }

    # kstat cpu_info
    # rc returns 1

# Generated at 2022-06-20 17:47:14.509834
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.facts.hardware.sunos import SunOSHardware
    from ansible_collections.ansible.community.tests.unit.module_utils.facts.facts.hardware.sunos import SunOSHardwareCollector

    cpu_facts = SunOSHardwareCollector.fetch_facts(SunOSHardware)
    assert cpu_facts is not None
    assert cpu_facts['processor_cores'] != 'NA'
    assert cpu_facts['processor_count'] > 0


# Generated at 2022-06-20 17:47:21.831002
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    import platform

    if platform.system() == SunOSHardwareCollector._platform:
        sunos = SunOSHardwareCollector()
        cpu_facts = sunos.get_cpu_facts()

        assert cpu_facts.get('processor')
        assert cpu_facts.get('processor_cores')
        assert cpu_facts.get('processor_count')



# Generated at 2022-06-20 17:47:30.343325
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    path = '/usr/bin:/usr/sbin:/usr/platform/'
    module_mock = MockModule()
    module_mock.params = {'gather_timeout': 10}
    module_mock.path = path
    module_mock.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    hardware_mock = SunOSHardware(module_mock)
    hardware_mock.populate()

# Generated at 2022-06-20 17:48:20.082294
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = DummyModule()

    output_time = """
    unix:0:system_misc:boot_time    1548249689
    """
    module.run_command = MagicMock(return_value=(0, output_time, ""))

    sh = SunOSHardware(module)
    data = sh.get_uptime_facts()
    current_time = int(time.time())
    assert data['uptime_seconds'] == current_time - 1548249689

