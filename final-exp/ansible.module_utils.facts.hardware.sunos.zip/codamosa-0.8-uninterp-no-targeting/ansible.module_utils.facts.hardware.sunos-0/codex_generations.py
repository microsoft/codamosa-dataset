

# Generated at 2022-06-20 17:38:35.787941
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.populate()


if __name__ == '__main__':
    test_SunOSHardware_populate()

# Generated at 2022-06-20 17:38:48.159450
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    import types

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    m = mock.mock_open(read_data='1548249689')
    with mock.patch('ansible.module_utils.facts.hardware.sunos.open', m, create=True):
        test_instance = SunOSHardware(dict())
        expected_value = {
            'uptime_seconds': 1548251826,
        }

        # Method invocation
        uptime_result = test_instance.get_uptime_facts()

        assert isinstance(uptime_result, types.DictType)
        assert uptime_result.get('uptime_seconds') == expected_value['uptime_seconds']

# Generated at 2022-06-20 17:38:58.493241
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    import json
    import os
    import shutil
    import sys
    import tempfile

    from units.compat import unittest
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class AnsibleModuleFake(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

            self.params = kwargs

        def fail_json(self, msg=None, **kwargs):
            raise AssertionError(msg)


# Generated at 2022-06-20 17:39:09.807476
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    res = []
    device_facts = {}
    device_facts['devices'] = {}

    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

    cmd = ['/usr/bin/kstat', '-p']

    for ds in disk_stats:
        cmd.append('sderr:::%s' % ds)



# Generated at 2022-06-20 17:39:15.589760
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)

    mock_base_facts = {
       'ansible_machine': 'i86pc'
    }
    hardware.populate(mock_base_facts)

    assert hardware.facts['cpu_cores'] == 1
    assert hardware.facts['cpu_count'] == 1
    assert hardware.facts['cpu_model'] == 'i86pc'
    assert isinstance(hardware.facts['mounts'], list)
    assert hardware.facts['memtotal_mb'] >= 1024
    assert isinstance(hardware.facts['processor'], list)
    assert len(hardware.facts['processor']) == 1
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-20 17:39:28.267396
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:39.119782
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Testing SunOSHardware.get_cpu_facts
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command = None

        def get_bin_path(self, arg, opt_dirs=[]):
            return "/usr/bin/kstat"

        def run_command(self, cmd, environ_update={}):
            """
            Mock run_command method.
            """

# Generated at 2022-06-20 17:39:50.096330
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Given:
    module = AnsibleModule(
        argspec=dict(
            gather_subset=dict(default=["all"], type='list'),
            gather_timeout=dict(default=10, type='int'),
            filter=dict(default=None, type='list')
        )
    )
    # When:
    hw = SunOSHardware(module)
    hw.populate()
    # Then:

# Generated at 2022-06-20 17:40:00.814479
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    hardware_obj = SunOSHardware(module)

    # Method get_cpu_facts
    cpu_facts = hardware_obj.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']

    # Method get_memory_facts
    memory_facts = hardware_obj.get_memory_facts()
    assert memory_facts['memtotal_mb']
    assert memory_facts['swapfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swap_allocated_mb']
    assert memory_facts['swap_reserved_mb']

    # Method get_dmi_facts
    dmi_facts = hardware_obj.get_dmi_facts()

# Generated at 2022-06-20 17:40:05.226587
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hostname = 'localhost.localdomain'
    s = SunOSHardware(hostname, cached_facts={'ansible_distribution': 'Solaris'})

    # test get_cpu_facts
    s.get_cpu_facts()

    # test get_memory_facts
    s.get_memory_facts()

    # test get_mount_facts
    s.get_mount_facts()

    # test get_uptime_facts
    s.get_uptime_facts()

    # test get_device_facts
    s.get_device_facts()


# Generated at 2022-06-20 17:40:23.780263
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockAnsibleModule()
    mem_facts = SunOSHardware(module=module).get_memory_facts()
    assert mem_facts['memtotal_mb'] == 20000
    assert mem_facts['swaptotal_mb'] == 8192
    assert mem_facts['swapfree_mb'] == 4096
    assert mem_facts['swap_allocated_mb'] == 4096
    assert mem_facts['swap_reserved_mb'] == 4096



# Generated at 2022-06-20 17:40:27.361677
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    x = SunOSHardware({})
    x.module.run_command = lambda x: [0, 'Memory size: 8192 Megabytes', '']
    assert x.get_memory_facts()['memtotal_mb'] == 8192

# Generated at 2022-06-20 17:40:34.116462
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware()
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] > 1
    assert type(cpu_facts['processor']) is list
    assert type(cpu_facts['processor_cores']) is int
    assert type(cpu_facts['processor_count']) is int



# Generated at 2022-06-20 17:40:44.205185
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.timeout import TimeoutError
    # Pretend we are running in a container
    if not hasattr(time, "monotonic"):
        time.monotonic = lambda: 3.2
    now = time.time()
    start_time = now - 4
    uptime_facts = {}
    uptime_facts['uptime_seconds'] = int(now - start_time)
    class Module:
        def run_command(self, cmd):
            """
            Pretending to be run_command
            """
            # Pretending that we are running "kstat bla bla"
            # return with exit code 0

# Generated at 2022-06-20 17:40:50.109983
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    s = SunOSHardware()

    expected_uptime_facts = {'uptime_seconds': 1397490110}

    uptime_facts = s.get_uptime_facts()
    assert expected_uptime_facts == uptime_facts

# Generated at 2022-06-20 17:40:52.646735
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector([], None, platform='SunOS')
    assert isinstance(hardware_collector, SunOSHardwareCollector)
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-20 17:41:04.331145
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    ''' SunOSHardware.get_memory_facts()

        Unit test to validate the results of the SunOSHardware.get_memory_facts() method.
    '''
    from ansible.module_utils.facts import Collector

    module = AnsibleModule(argument_spec={})
    facts_collector = Collector(module=module)
    hardware_collector = SunOSHardwareCollector(module=module)
    hardware_collector.collect(facts_collector)
    hardware_collector.post_process(facts_collector)
    hardware = hardware_collector.get_facts()

    assert hardware['memtotal_mb'] == 3900
    assert hardware['swapfree_mb'] == 1073
    assert hardware['swaptotal_mb'] == 1073
    assert hardware['swap_allocated_mb'] == 41

# Generated at 2022-06-20 17:41:07.612813
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type("", (), {"run_command": lambda self, cmd: ("", "System Configuration: Sun Microsystems sun4u", "")})()
    hw = SunOSHardware(module)
    assert hw.get_dmi_facts() == {}


# Generated at 2022-06-20 17:41:18.529175
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_system_vendor_name = "Sun Microsystems, Inc."
    test_product_name = "Sun Fire V440"
    module_mock = {
        'run_command':
            lambda args, **kwargs:
                (0, "System Configuration: {} {}".format(test_system_vendor_name, test_product_name), None)
    }
    test_class = SunOSHardware(module_mock)
    dmi_facts = test_class.get_dmi_facts()
    testcase = (dmi_facts['system_vendor'] == test_system_vendor_name) and (dmi_facts['product_name'] == test_product_name)
    assert testcase

# Generated at 2022-06-20 17:41:25.489347
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware({'module_setup': True})
    """
    The test assumes that system_vendor and product_name are computed from
    the output of Solaris 8 prtdiag. The output contains first line with the
    system configuration which is used to extract the vendor and product name.
    Bellow is an example of the first line of the prtdiag output.
    System Configuration: Sun Microsystems  sun4u
    """
    assert m.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}


# Generated at 2022-06-20 17:42:06.970638
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    kstat_boot_time = 'unix:0:system_misc:boot_time    1548249689'

    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_value = 0
            self.run_command_data = None
            self.run_command_output = [kstat_boot_time]

        def run_command(self, args, check_rc=True):
            self.run_command_called = True
            self.run_command_data = args
            return self.run_command_value, self.run_command_output, ''

    class MockTime(object):
        def __init__(self):
            self.time_called = False
            self.time_return = 1548249700


# Generated at 2022-06-20 17:42:14.861987
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Unit test for method get_dmi_facts of class SunOSHardware
    fake_module = type('FakeModule', (object,), {
        'run_command': lambda s: (0, 'Fujitsu Primergy RX200 S8\n', None),
        'get_bin_path': lambda s, n, d: n,
    })
    hw = SunOSHardware(fake_module)
    dmi_facts = hw.get_dmi_facts()

    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

    assert dmi_facts['system_vendor'] == "Fujitsu"
    assert dmi_facts['product_name'] == "Primergy RX200 S8"



# Generated at 2022-06-20 17:42:28.258292
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module=module)
    hardware.populate()

    assert hardware.facts['hw_cpu_cores'] == hardware.facts['processor_cores']
    assert hardware.facts['hw_cpu_threads_per_core'] == hardware.facts['processor_cores']
    assert hardware.facts['hw_cpu_logical_per_socket'] == hardware.facts['processor_cores']
    assert hardware.facts['hw_cpu_physical_per_socket'] == hardware.facts['processor_count']
    assert hardware.facts['hw_cpu_sockets'] == hardware.facts['processor_count']
    assert hardware.facts['hw_cpu_cores_per_socket'] == hardware.facts['processor_cores']
    assert hardware.facts['hw_memtotal_mb']

# Generated at 2022-06-20 17:42:33.684431
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Unit test for method `get_dmi_facts` of class `SunOSHardware`.

    Example output:
        System Configuration: VMware, Inc. VMware Virtual Platform
    """
    val = 'System Configuration: VMware, Inc. VMware Virtual Platform'
    s = SunOSHardware(None)
    results = s.get_dmi_facts()
    assert results['system_vendor'] == 'VMware, Inc.'
    assert results['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-20 17:42:36.332914
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.platform == 'SunOS'

    required_facts = set(['platform'])
    assert hardware_collector.required_facts == required_facts

# Generated at 2022-06-20 17:42:45.578915
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    sunos_h = SunOSHardware(module)

    # Mock the subprocess call to simulate prtdiag output
    sunos_h.module.run_command = lambda x: (1, 'System Configuration: Sun Microsystems     sun4u', '')

    dmi_facts = sunos_h.get_dmi_facts()

    assert(dmi_facts['system_vendor'] == 'Sun Microsystems')
    assert(dmi_facts['product_name'] == 'sun4u')


# Generated at 2022-06-20 17:42:56.407232
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    cpu_facts = {}
    cpu_facts['processor'] = []
    cpu_facts['ansible_processor'] = []


# Generated at 2022-06-20 17:42:59.499662
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    SunOSHardware.get_memory_facts(module)

# Generated at 2022-06-20 17:43:10.485272
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    assert device_facts['devices']
    assert device_facts['devices']['sd0']['product'], "disk product is missing"
    assert device_facts['devices']['sd0']['revision'], "disk revision is missing"
    assert device_facts['devices']['sd0']['serial'], "disk serial is missing"
    assert device_facts['devices']['sd0']['size'], "disk size is missing"
    assert device_facts['devices']['sd0']['vendor'], "disk vendor is missing"

# Generated at 2022-06-20 17:43:13.921860
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:44:12.963523
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = ansible_module_mock()
    x = SunOSHardware(module)
    x.populate()
    assert module.exit_json.called

# Generated at 2022-06-20 17:44:22.476274
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    hardware = SunOSHardware(module)
    facts = hardware.populate()

    # Assert some basic generic hardware facts
    assert facts['processor'][0].startswith('ARMv7')
    assert facts['memtotal_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['system_vendor'] == 'Oracle Corporation'
    assert facts['product_name'] == 'Oracle Corporation SPARC T7-1'
    # Assert that SunOS specific facts have been set
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0

# Generated at 2022-06-20 17:44:33.532681
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time

    class MockModule:
        """
        A simple mock of AnsibleModule
        """
        def __init__(self, results):
            self.results = results
            self.params = {}

        def run_command(self, command, data=None):
            return self.results.pop(0)

    mock_boot_time = (0, str(int(time.time()) - (5 * 60 * 60 * 24 * 365)), '')
    mock_module = MockModule([mock_boot_time])

    sunos_hw = SunOSHardware(mock_module)
    facts = sunos_hw.get_uptime_facts()
    assert facts == {'uptime_seconds': 157680000}

# Generated at 2022-06-20 17:44:37.789055
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # test 'SunOSHardware(module)'
    hw = SunOSHardware(module)

    # test 'SunOSHardware.populate()'
    hw.populate()

# Generated at 2022-06-20 17:44:46.445346
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    SunOSHardwareCollector.populate(module, {'platform': 'SunOS'})
    hardware = module.params['ansible_facts']['ansible_hardware']

    if hardware is not None:
        if 'swap_allocated_mb' not in hardware:
            module.fail_json(msg="swap_allocated_mb fact missing")
        if 'swap_reserved_mb' not in hardware:
            module.fail_json(msg="swap_reserved_mb fact missing")
    else:
        module.fail_json(msg="SunOSHardware object was not created")


# Generated at 2022-06-20 17:44:53.506086
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = DummyAnsibleModule()

    out_prtconf = '''
      System Configuration: Sun Microsystems sun4u
      Memory size: 32768 Megabytes
      '''
    out_swap = '''
      total: 32952k bytes allocated + 3552k reserved = 36504k used, 9157400k available
      '''
    module.run_command_values = [(0, out_prtconf, ""), (0, out_swap, "")]

    hardware = SunOSHardware(module, "")
    hardware_facts = hardware.get_memory_facts()

    assert hardware_facts['memtotal_mb'] == 32768
    assert hardware_facts['swapfree_mb'] == 8905
    assert hardware_facts['swaptotal_mb'] == 32

# Generated at 2022-06-20 17:44:59.375252
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class FakeModule:
        def run_command(self, cmd):
            """ Fake run command. """

# Generated at 2022-06-20 17:45:08.920480
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create fake module
    class FakeModule:
        def __init__(self):
            self.run_command_environ_update = {}
            self.params = {}
        def run_command(self, args, check_rc=False, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None, cwd=None,
                        use_unsafe_shell=False, prompt_regex=None, environ_update=None):
            self.last_command = args

# Generated at 2022-06-20 17:45:20.169646
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    SunOSHardware._module = type('FakeMockModule', (object,), {})
    SunOSHardware._module.run_command = type('FakeMockRunCommand', (object,), {})
    SunOSHardware._module.run_command.return_value = (0, "", "")
    SunOSHardware._module.get_bin_path = type('FakeMockGetBinPath', (object,), {})
    SunOSHardware._module.get_bin_path.return_value = "prtconf"
    SunOSHardware._get_file_content = type('FakeMockGetFileContent', (object,), {})
    SunOSHardware._get_file_content.return_value = "Memory size: 8192 Megabytes"

    module = type('FakeMockModule', (object,), {})

# Generated at 2022-06-20 17:45:22.743407
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeModule({})

    hardware = SunOSHardware({}, module)

    hardware.get_device_facts()



# Generated at 2022-06-20 17:47:36.659476
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Unit test for method get_device_facts of class SunOSHardware"""
    # TODO: add unit tests for SunOSHardware
    pass

# Generated at 2022-06-20 17:47:45.642790
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Setup
    test = SunOSHardware()
    test.module = type('test', (object,), {'run_command': get_run_command_mock()})

    # Test
    test.populate()

    # Assertions
    cmds = ['/usr/bin/kstat cpu_info', '/usr/sbin/prtconf', '/usr/sbin/swap -s', '/usr/bin/kstat -p']
    for cmd in cmds:
        assert get_run_command_mock.called



# Generated at 2022-06-20 17:47:51.213593
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    required_keys = ['uptime_seconds']
    uptime_facts = SunOSHardware().get_uptime_facts()

    if not uptime_facts:
        assert uptime_facts is None
    else:
        assert set(required_keys) <= set(uptime_facts.keys())

# Generated at 2022-06-20 17:47:59.980959
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # GIVEN a SunOSHardware instance

    # WHEN the method populate is called
    test_hardware = SunOSHardware()
    facts = test_hardware.populate()

    # THEN the resulting dict should be as expected
    assert facts.get('ansible_processor_cores') is not None
    assert facts.get('ansible_processor_count') is not None
    assert facts.get('ansible_processor') is not None
    assert facts.get('ansible_devices') is not None
    assert facts.get('ansible_mounts') is not None
    assert facts.get('ansible_system_vendor') is not None
    assert facts.get('ansible_product_name') is not None
    assert facts.get('ansible_memtotal_mb') is not None

# Generated at 2022-06-20 17:48:10.250708
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)

            if args[0] == "/usr/sbin/prtconf":
                return 0, """System Configuration: Sun Microsystems sun4u
Memory size: 8192 Megabytes
""", ''

            elif args[0] == "/usr/sbin/swap -s":
                return 0, """total: 67832768k bytes allocated + 16k reserved = 67834400k used, 928911296k available
""", ''

    hardware = SunOSHardware()


# Generated at 2022-06-20 17:48:20.864609
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    This is a test to verify that the SunOSHardwareCollector has been created
    successfully
    """
    sunoshwcollector = SunOSHardwareCollector()
    assert sunoshwcollector._platform == 'SunOS', \
        'The SunOSHardwareCollector platform is currently %s, but should be SunOS' % sunoshwcollector._platform

    assert sunoshwcollector._fact_class == SunOSHardware, \
        'The SunOSHardwareCollector fact class is currently %s, but should be SunOSHardware' \
        % sunoshwcollector._fact_class

    assert sunoshwcollector.required_facts == set(['platform']), \
        'The required facts for SunOSHardwareCollector is currently %s, but should be set(["platform"])' \
        % sunoshwcollector.required_facts