

# Generated at 2022-06-20 17:38:50.669705
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs


# Generated at 2022-06-20 17:38:53.310151
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime = SunOSHardware().get_uptime_facts()

    assert uptime == {'uptime_seconds': 158726957}

# Generated at 2022-06-20 17:39:00.116045
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Test the constructor of the SunOSHardware class
    """
    module = mock.Mock()
    SunOSHardware(module)

    # Test if the constructor calls the init method of the parent class
    module.get_bin_path.assert_called_once_with('prtdiag', opt_dirs=['/usr/platform/i86pc/sbin'])
    module.run_command.assert_called_once_with('/usr/bin/kstat cpu_info')

# Generated at 2022-06-20 17:39:01.263082
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-20 17:39:13.051093
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MagicMock()
    module.run_command = MagicMock()

# Generated at 2022-06-20 17:39:19.049746
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    obj = SunOSHardware(None)
    obj.get_cpu_facts(None)
    obj.get_device_facts()
    obj.get_dmi_facts()
    obj.get_memory_facts()
    obj.get_mount_facts()
    obj.get_uptime_facts()
    obj.populate(None)
    obj.platform



# Generated at 2022-06-20 17:39:26.014367
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    mocked_module = type('MockModule', (object,), dict(run_command=lambda x: (0, 'unix:0:system_misc:boot_time\t1548249689\n', '')))()
    mocked_hardware = SunOSHardware()
    mocked_hardware.module = mocked_module
    uptime_facts = mocked_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:39:28.972691
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule({'dummy': ''})
    SunOSHardware(module)

    module.run_command = Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))

    assert SunOSHardware.get_uptime_facts(module)['uptime_seconds'] == 1548249689 - int(time.time())
    assert SunOSHardware.get_uptime_facts(module)['uptime_seconds'] == SunOSHardware.get_uptime_facts(module)['uptime_seconds']



# Generated at 2022-06-20 17:39:39.763758
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = [ 'all' ]
    module.params['gather_timeout'] = '5'

# Generated at 2022-06-20 17:39:45.825833
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule:
        def run_command(self, cmd, data=None):
            return 0, 'unix:0:system_misc:boot_time\t1561713373', ''

    class FakeException(Exception):
        pass

    hw = SunOSHardware(FakeModule())
    hw.get_uptime_facts()

    assert hw.facts['uptime_seconds'] == 1561713373

    hw.module.run_command = lambda cmd: 1, '', 'Command failed'

    try:
        hw.get_uptime_facts()
    except FakeException:
        pass
    else:
        assert False, 'Expected Exception'

# Generated at 2022-06-20 17:40:13.614811
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    #test for a non-virtual machine
    x = SunOSHardware()
    s = ("System Configuration:  Oracle Corporation  T5-2 \n"
         "System clock frequency: 800 MHz\n"
         "Memory size: 16384 Megabytes\n")
    d = x.get_dmi_facts()
    assert(d['product_name'] == 'T5-2')
    assert(d['system_vendor'] == 'Oracle Corporation')

    #test for a virtual machine
    x = SunOSHardware()
    s = ("System Configuration: VMware, Inc.   VMware Virtual Platform \n"
         "System clock frequency: 2133 MHz \n"
         "Memory size: 16384 Megabytes\n")
    d = x.get_dmi_facts()
    assert(d['product_name'] == 'VMware Virtual Platform')


# Generated at 2022-06-20 17:40:16.382459
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    # instantiate the object.
    obj = SunOSHardware(module)
    assert obj.platform == 'SunOS'



# Generated at 2022-06-20 17:40:23.664040
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Mock module
    module_mock = MagicMock(name='module')
    module_mock.run_command.return_value = 2, '', ''

    module_mock.get_bin_path.return_value = '/usr/bin/kstat'

    sh = SunOSHardware(module_mock)
    uptime = sh.get_uptime_facts()
    assert uptime == {}

    return True

# Generated at 2022-06-20 17:40:29.209107
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Test on a SunOS machine
    module = AnsibleModule(argument_spec={})
    platform = module.get_bin_path('uname')
    module.run_command_environ_update = {'PATH': '/bin:/usr/bin'}
    if platform:
        SunOSHardwareCollector.collect(module=module)

# Generated at 2022-06-20 17:40:31.034038
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = None
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:40:42.378903
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a 'SunOSHardware' instance with mock instance attributes
    mock_disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }


# Generated at 2022-06-20 17:40:54.586090
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Setup test data
    data = {'sderr:::Soft Errors': '0', 'sderr:::Hard Errors': '0', 'sderr:::Size': '53687091200',
            'sderr:::Media Error': '0', 'sderr:::Predictive Failure Analysis': '0',
            'sderr:::Vendor': 'ATA', 'sderr:::Serial No': 'VB0ad2ec4d-074a',
            'sderr:::Revision': '1.0', 'sderr:::Product': 'VBOX HARDDISK',
            'sderr:::Transport Errors': '0', 'sderr:::Illegal Request': '6'}
    data_as_lines = ''
    for k in data.keys():
        data_as_lines

# Generated at 2022-06-20 17:41:06.216094
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:41:14.778024
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    instance = SunOSHardware()
    results = {}

    class MockModule(object):
        def run_command(self, cmd):
            results['cmd'] = cmd
            return 0, "Memory size: 16384 Megabytes", ""
    instance.module = MockModule()

    assert instance.get_memory_facts()['memtotal_mb'] == 16384
    assert results['cmd'] == ["/usr/sbin/prtconf"]



# Generated at 2022-06-20 17:41:24.126239
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    current_fact_subset = dict()
    SunOSHardware(module, current_fact_subset)
    assert current_fact_subset.get('processor')
    assert current_fact_subset.get('processor_cores')
    assert current_fact_subset.get('processor_count')
    assert current_fact_subset.get('memtotal_mb')
    assert current_fact_subset.get('swapfree_mb')
    assert current_fact_subset.get('swaptotal_mb')
    assert current_fact_subset.get('swap_allocated_mb')
    assert current_fact_subset.get('swap_reserved_mb')
    assert current_fact_subset.get('system_vendor')
    assert current

# Generated at 2022-06-20 17:42:06.283311
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardwareCollector(dict(), None)

    assert hardware.collect() == dict()  # When given an empty dict, this is the expected result

    # When given a dict with the right key, check that populating facts works
    loaded_facts = dict(platform="SunOS")
    hardware = SunOSHardwareCollector(loaded_facts, None)
    hardware.collect()

    assert loaded_facts.get('ansible_processor') is not None
    assert loaded_facts.get('ansible_processor_cores') is not None
    assert loaded_facts.get('ansible_processor_count') is not None
    assert loaded_facts.get('ansible_system_vendor') is not None
    assert loaded_facts.get('ansible_product_name') is not None

# Generated at 2022-06-20 17:42:12.143196
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': ['Genuine Intel(R) CPU           T1350  @ 1.86GHz',
                              'Genuine Intel(R) CPU           T1350  @ 1.86GHz'],
        'ansible_processor_count': 2,
        'ansible_processor_cores': 2,
        'ansible_processor_threads_per_core': 2,
        'ansible_processor_vcpus': 4,
        'ansible_processor_physical_id': [0, 1],
    }
    hardware = SunOSHardware(dict(), facts)

    cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-20 17:42:14.566229
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    mod = AnsibleModuleMock()
    mod.run_command = run_command
    facts = SunOSHardware(module=mod, collected_facts={})
    facts.populate()
    assert facts.data['system_vendor'] == 'Oracle Corporation'



# Generated at 2022-06-20 17:42:25.451677
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Arrange
    # Return code 0, output and error streams
    rc = 0
    out = 'unix:0:system_misc:boot_time 1548249689\n'
    err = ''

    class MockModule():
        def run_command(self, module_name):
            return rc, out, err
    module = MockModule()
    sun_os_hardware = SunOSHardware(module)

    # Act
    facts = sun_os_hardware.get_uptime_facts()

    # Assert
    assert facts == {'uptime_seconds':int(time.time() - 1548249689)}

# Generated at 2022-06-20 17:42:29.852379
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # build a fake module to pass to SunOSHardware
    module = type('Module', (), {})
    fact_class = SunOSHardware(module)

    # check that the function returns an expected value
    fact_class.get_uptime_facts()

# Generated at 2022-06-20 17:42:32.543270
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    c = SunOSHardwareCollector()
    assert c.platform == 'SunOS'
    assert c.required_facts == {'platform'}
    assert c.fact_class == SunOSHardware


# Generated at 2022-06-20 17:42:35.101841
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False)

    SunOSHardware(module).populate()

    assert module.exit_json.called

# Generated at 2022-06-20 17:42:46.841835
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    raw_prtdiag_output = """System Configuration: Sun Microsystems sun4v System Configuration: VMware, Inc. VMware ESXi
System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)
System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)
System Configuration: Sun Microsystems sun4u System Configuration: Sun Microsystems sun4u System Configuration: Oracle Corporation SUN FIRE T2000
System Configuration: Sun Microsystems sun4u
System Configuration: Oracle Corporation T5-2"""
    hardware = SunOSHardware()
    hardware.module = MagicMock(run_command=MagicMock(return_value=(0, raw_prtdiag_output, "")))
    hardware.module.get_bin_path = MagicMock(return_value='/usr/bin/prtdiag')
    d

# Generated at 2022-06-20 17:42:56.204625
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MagicMock()

    # Get CPU facts from command 'kstat cpu_info'.
    module.run_command.return_value = (0, "module:            cpu_info", None)

    # Create instance of class SunOSHardware.
    sunos_facts = SunOSHardware(module)

    # Call method get_cpu_facts of class SunOSHardware.
    sunos_facts.get_cpu_facts()
    cpu_facts = sunos_facts.populate()

    # Assert that the results are correct.
    assert cpu_facts.get('processor_cores') == 'NA'
    assert cpu_facts.get('processor_count') == 1



# Generated at 2022-06-20 17:43:01.308614
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """This test ensures the constructor of SunOSHardwareCollector works."""
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.required_facts == set(['platform'])
    assert collector._fact_class == SunOSHardware

# Generated at 2022-06-20 17:44:02.883947
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    data = SunOSHardware().get_device_facts()
    assert data['devices']
    assert data['devices']['sd0']

# Generated at 2022-06-20 17:44:04.678099
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Unit test class needs a platform attribute
    setattr(SunOSHardwareCollector, 'platform', 'SunOS')

    x = SunOSHardwareCollector()
    assert x.platform == 'SunOS'
    assert x._fact_class == SunOSHardware


# Generated at 2022-06-20 17:44:06.023723
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    assert SunOSHardware().get_uptime_facts() is not None


# Generated at 2022-06-20 17:44:08.429634
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    hw = SunOSHardware(module)
    hw.populate()



# Generated at 2022-06-20 17:44:14.289506
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    ''' Unit test for SunOSHardware.get_memory_facts'''
    HardwareClass = SunOSHardware
    module = AnsibleModule(argument_spec={})
    hardware_obj = HardwareClass(module)
    memory_facts = hardware_obj.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts



# Generated at 2022-06-20 17:44:23.840869
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # Mock object for ansible.module_utils.common.locale.get_best_parsable_locale
    mock_locale = MagicMock()
    mock_locale.return_value = 'C'

    # Mock object for ansible.module_utils.facts.hardware.base.Hardware.module
    mock_module = MagicMock()

    # Mock object for ansible.module_utils.facts.hardware.base.Hardware.get_bin_path
    mock_bin_path = MagicMock()
    mock_bin_path.return_value = "/bin/whoami"

    # Mock object for ansible.module_utils.facts.hardware.base.Hardware.run_command
    mock_run_command = MagicMock()
    mock_run_command.return_value = (0, "", "")



# Generated at 2022-06-20 17:44:35.922856
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from collections import namedtuple

    # Preparing mock current facts
    file_content = """Memory size: 16384 Megabytes
"""
    mock_run_command = namedtuple('mock_run_command', ['returncode', 'stdout', 'stderr'])
    arguments = {
        'run_command': mock_run_command(0, file_content, ''),
    }
    test_module = FactsCollector(**arguments)
    test_SunOSHardware = SunOSHardware(test_module)

    # Getting memory facts
    memory_facts = test_SunOSHardware.get_memory_facts()
    result_memtotal_mb = memory_facts.get('memtotal_mb')

    # Check result of get_memory_facts method
   

# Generated at 2022-06-20 17:44:46.409185
# Unit test for constructor of class SunOSHardwareCollector

# Generated at 2022-06-20 17:44:57.974857
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a test class
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    # Create a test device, hard_errors and soft_errors
    kstat_output = 'sderr:0:sd0,err:Hard Errors     1\nsderr:0:sd0,err:Soft Errors     2\nsderr:0:sd0,err:Size    3'
    # Get device_facts
    device_facts = hardware.get_device_facts(kstat_output)
    # Assert that hard_errors and soft_errors for device sd0 exists and has the expected value
    assert device_facts['devices']['sd0']['hard_errors'] == '1'
    assert device_facts['devices']['sd0']['soft_errors'] == '2'


# Generated at 2022-06-20 17:45:07.993484
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    class MockModule(object):
        def __init__(self, run_command_result=None, get_bin_path_result=None):
            self.run_command_result = run_command_result
            self.run_command_calls = []
            self.get_bin_path_result = get_bin_path_result
            self.get_bin_path_calls = []

        def run_command(self, cmd, *args, **kwargs):
            self.run_command_calls.append(cmd)
            return self.run_command_result

        def get_bin_path(self, cmd, *args, **kwargs):
            self.get_bin_path_calls.append(cmd)
            return self.get_bin_path_result

    # Testing the command execution.
    # No output

# Generated at 2022-06-20 17:47:40.086894
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # set up
    module = MagicMock()
    module.run_command.return_value = [0, 'boot_time 1548249689', '']
    fact_class = SunOSHardware(module)
    fact_class.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    # run code to test
    result = fact_class.get_uptime_facts()
    expected_uptime = int(time.time()) - 1548249689

    # assertions
    assert result['uptime_seconds'] == expected_uptime

# Generated at 2022-06-20 17:47:53.331206
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = {
        'ansible_architecture': 'i86pc',
        'ansible_machine': 'i86pc',
        'ansible_os_family': 'Solaris',
        'ansible_os_name': 'SunOS',
        'ansible_devices': {},
        'ansible_system_vendor': 'Oracle Corporation',
        'ansible_product_name': 'VirtualBox',
        'ansible_memtotal_mb': 0,
        'ansible_swaptotal_mb': 0,
        'ansible_processor': [],
    }

# Generated at 2022-06-20 17:47:57.025201
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class is SunOSHardware
    assert hardware_collector._platform == "SunOS"
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:48:09.044594
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Tests the get_cpu_facts method of the SunOSHardware class"""
    lines = [
        'module:                               cpu_info',
        'name:                                 cpu_info0',
        'class:                                misc',
        'instance:                             0',
        'brand:                                Intel(r) Xeon(r) CPU E5-2650 v4 @ 2.20GHz',
        'clock_MHz:                            2200',
        'state:                                on-line',
        'chip_id:                              0',
        'device_ID:                            0',
        'core_id:                              0',
        'strand_id:                            0',
    ]

    sun_os_hardware = SunOSHardware()

# Generated at 2022-06-20 17:48:19.246514
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    parameter_values = [['processor',
                       ('Intel(R) Xeon(R) CPU     X5482  @ 3.20GHz',
                        'Intel(R) Xeon(R) CPU     X5482  @ 3.20GHz',
                        'Intel(R) Xeon(R) CPU     X5482  @ 3.20GHz')],
                       ['processor_cores', 3],
                       ['processor_count', 3]]

    module = AnsibleModule(argument_spec={})
    result = SunOSHardware().get_cpu_facts()

    for item in parameter_values:
        assert (item[0] in result.keys()) and (item[1] == result[item[0]])


# Generated at 2022-06-20 17:48:25.560995
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})

    hw = SunOSHardware(module=module)

    # Oracle SunOS output