

# Generated at 2022-06-20 17:38:41.442666
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    facts = SunOSHardware.get_device_facts()
    assert isinstance(facts['devices'], dict)
    assert facts['devices']['sda']['size'] == '49.5 GB'
    assert facts['devices']['sda']['product'] == 'VirtualBox HARDDISK   9'
    assert facts['devices']['sda']['vendor'] == 'ATA'

# Generated at 2022-06-20 17:38:52.709492
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_conf = """Memory size: 4194304 Megabytes

Total swap space: 2147483648 bytes

===============================================================
Memory Modules
   interleave  banks    chips    size   status
"""
    hw = SunOSHardware()
    hw.module.run_command = lambda x: (0, test_conf, None)
    result = hw.get_memory_facts()
    assert result['memtotal_mb'] == 4194304
    assert result['swapfree_mb'] == 2047
    assert result['swaptotal_mb'] == 2097151
    assert result['swap_allocated_mb'] == 2097151
    assert result['swap_reserved_mb'] == 2097151



# Generated at 2022-06-20 17:39:00.500294
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware = SunOSHardware()
    hardware.module = module
    hardware.populate()
    rc, out, err = module.run_command(["/usr/sbin/prtconf"])
    for line in out.splitlines():
        if 'Memory size' in line:
            expected_memory_size_in_mb = int(line.split()[2])

    # Assert if the memtotal_mb fact is not equal to the value of MemTotal in /proc/meminfo
    if expected_memory_size_in_mb != int(hardware.memory['memtotal_mb']):
        raise Exception('Unexpected memtotal_mb value observed.')



# Generated at 2022-06-20 17:39:03.016701
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos_hardware = SunOSHardware(None)
    assert sunos_hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:39:05.608937
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    facts = SunOSHardware().get_dmi_facts()
    assert facts == {}, "Wrong dmi facts when running uname -i"

# Generated at 2022-06-20 17:39:15.839741
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create an instance of class SunOSHardware
    hardware = SunOSHardware({})

    # Create a sample output from kstat
    out = ('sderr:::Product    VBOX HARDDISK    \nsderr:::Revision   1.0   \nsderr:::Serial No  VB0ad2ec4d-074a    \nsderr:::Size       53687091200\nsderr:::Vendor     ATA   \nsderr:::Hard Errors      0\nsderr:::Soft Errors      0\nsderr:::Transport Errors 0\nsderr:::Media Error      0\nsderr:::Predictive Failure Analysis      0\nsderr:::Illegal Request      6\n')

    # Create a sample input to run_command method

# Generated at 2022-06-20 17:39:22.827639
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = {
        'processor': [
            'E3827 @ 2.13GHz',
            'E3827 @ 2.13GHz'
        ],
        'processor_count': 2,
        'processor_cores': 4,
    }
    hw = SunOSHardware({'module': mock.Mock()})
    assert hw.get_cpu_facts() == cpu_facts


# Generated at 2022-06-20 17:39:24.576478
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    result = SunOSHardwareCollector()
    assert result.platform == 'SunOS'

# Generated at 2022-06-20 17:39:36.129189
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.six import PY2
    from ansible.module_utils._text import to_bytes

    if PY2:
        from ansible.module_utils.six.moves import StringIO
        from io import BytesIO
    else:
        from io import StringIO

    real_time = 1548249689
    current_time = real_time + 120
    mock_time_patch = 'ansible.module_utils.facts.hardware.sunos.time.time'
    with mock.patch(mock_time_patch) as mock_time:
        mock_time.return_value = current_time

        # Set up fake kstat output.

# Generated at 2022-06-20 17:39:43.855909
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class ModuleMock:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'unix:0:system_misc:boot_time 1548249689'
            self.run_command_err = None

        def run_command(self, cmd, check_rc=True, close_fds=True):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    m = ModuleMock()
    h = SunOSHardware()
    h.module = m
    ud = h.get_uptime_facts()

    assert ud['uptime_seconds'] == int(time.time() - 1548249689)



# Generated at 2022-06-20 17:40:12.966768
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    # Run the method populate
    obj = SunOSHardware(module)

    # Compare results
    assert obj.populate() == {
        "processor": [
            "sparcv9+vis3 @ 1000MHz",
            "sparcv9+vis3 @ 1000MHz"
        ],
        "processor_cores": 12,
        "processor_count": 2,
        "memtotal_mb": 3959,
        "swapfree_mb": 62249,
        "swaptotal_mb": 65535,
        "swap_allocated_mb": 32767,
        "swap_reserved_mb": 0,
    }



# Generated at 2022-06-20 17:40:25.599159
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Initialize SunOSHardware object
    sunos_object = SunOSHardware()
    # Sample output of kstat command, used in SunOSHardware.get_device_facts() method

# Generated at 2022-06-20 17:40:29.526277
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module_mock = MockPatch()
    hardware_obj = SunOSHardware(module_mock)
    try:
        hardware_obj.get_memory_facts()
    except:
        assert False

# Generated at 2022-06-20 17:40:37.667762
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    def test_get_uptime_facts(obj, output):
        obj.run_command = MagicMock(return_value=(0, output, ''))
        uptime_facts = obj.get_uptime_facts()
        expected = {'uptime_seconds': 1548249689}
        assert uptime_facts == expected

    obj = SunOSHardware()
    test_get_uptime_facts(obj, 'unix:0:system_misc:boot_time    1548249689')

# Generated at 2022-06-20 17:40:44.422913
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    h = SunOSHardware(m)

    h.module.run_command = lambda x: (0, to_bytes('''
unix:0:system_misc:boot_time    1548249689
'''), b'')

    assert (h.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1548249689)})

# Generated at 2022-06-20 17:40:46.433904
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    h = SunOSHardware(module)
    h.get_dmi_facts()

# Generated at 2022-06-20 17:40:59.473526
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    mac = SunOSHardware()
    mac.module = FakeModule()
    mac.module.run_command = MockRunCommand()

# Generated at 2022-06-20 17:41:08.963009
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-20 17:41:10.498263
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    Hardware(module)

# Generated at 2022-06-20 17:41:15.834403
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    ret = SunOSHardwareCollector()
    assert ret
    assert isinstance(ret, SunOSHardwareCollector)
    assert ret._fact_class == SunOSHardware
    assert ret._platform == 'SunOS'


# Generated at 2022-06-20 17:42:01.103110
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class SunOSHardware
    :return:
    """
    module = FakeAnsibleModule()
    hardware = SunOSHardware()
    hardware.module = module
    memory_facts = hardware.get_memory_facts()
    assert memory_facts.get('memtotal_mb') == 128
    assert memory_facts.get('swapfree_mb') == 64
    assert memory_facts.get('swaptotal_mb') == 128
    assert memory_facts.get('swap_allocated_mb') == 64
    assert memory_facts.get('swap_reserved_mb') == 64



# Generated at 2022-06-20 17:42:11.513722
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-20 17:42:22.581524
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command_environ_update = {}

    command_outputs = [
        "/usr/sbin/prtconf\nMemory size: 8192 Megabytes",
        "/usr/sbin/swap -s\n8k reserved, 7897M allocated, 6923M used, 974M available"
    ]
    module.run_command.side_effect = command_outputs

    hardware = SunOSHardware(module)
    facts = hardware.populate()
    assert facts['memtotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 7897
    assert facts['swap_reserved_mb'] == 8
    assert facts['swaptotal_mb'] == 8896
    assert facts['swapfree_mb'] == 974



# Generated at 2022-06-20 17:42:32.542236
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_module = type('test_module', (object,), {})()
    test_module.run_command = lambda x: (0, "module: SUNW,SPARC-Enterprise-T5220\nbrand: SPARC64-VII+\nclock_MHz: 1600\nimplementation: SPARC64-VII+\nchip_id: 0\nmodule: SUNW,SPARC-Enterprise-T5220\nbrand: SPARC64-VII+\nclock_MHz: 1600\nimplementation: SPARC64-VII+\nchip_id: 0\n", "")
    test_module.get_bin_path = lambda x: "/usr/sbin/swap"
    test_SunOSHardware = SunOSHardware(test_module)

# Generated at 2022-06-20 17:42:35.966527
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleFakeModule()
    module.run_command = lambda *args, **kwargs: (0, 1548249689, '')

    fact = SunOSHardware(module)
    uptime_facts = fact.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1548249689

# Generated at 2022-06-20 17:42:47.807726
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:51.389412
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.module = AnsibleModule(argument_spec={})
    hardware.module.params = {'gather_subset': ['all']}
    hardware.module.warnings = []
    hardware.populate()

    assert hardware.data is not None
    

# Generated at 2022-06-20 17:42:59.919609
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    test method get_uptime_facts of class SunOSHardware
    """
    # create an instance of class SunOSHardware
    sunos_hw = SunOSHardware()

    # return value of method get_uptime_facts
    sunos_uptime_facts = {'uptime_seconds': 1234}

    # mock method run_command of class SunOSHardware
    sunos_hw.run_command = lambda x: (0, u'unix:0:system_misc:boot_time    1548249689', '')

    # call method get_uptime_facts with mocked method run_command
    uptime_facts = sunos_hw.get_uptime_facts()

    # check if return value of method get_uptime_facts is equal to expected return value sunos_uptime_facts

# Generated at 2022-06-20 17:43:06.286597
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, "System Configuration: Sun Microsystems sun4u Sun Fire V490", ""

    sunos = SunOSHardware(MockModule())
    facts = sunos.get_dmi_facts()
    assert facts.get('system_vendor') == 'Sun Microsystems'
    assert facts.get('product_name') == 'Sun Fire V490'


# Generated at 2022-06-20 17:43:18.601813
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    # Total memory: 32768 MB
    prtconf_output = 'Memory size: 32768 Megabytes'

    # swap     total:  2097148k bytes allocated +   501864k reserved =  2609012k
    swap_output = 'swap     total:  2097148k bytes allocated +   501864k reserved =  2609012k'

    memory_facts = SunOSHardware(module).get_memory_facts()

    assert memory_facts['swapfree_mb'] == 2048
    assert memory_facts['swaptotal_mb'] == 2457
    assert memory_facts['swap_allocated_mb'] == 2048
    assert memory_facts['swap_reserved_mb'] == 491
    assert memory_facts['memtotal_mb'] == 32768


# Unit

# Generated at 2022-06-20 17:44:37.681841
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Unit test for populate method
    # create instance of SunOSHardware
    # pass ansible_facts, which will be collected by hardware.all()

    facts = {'os_family': 'Solaris',
             'os_version': '5.11',
             'platform_platform': 'SunOS'}
    sun_os_hardware = SunOSHardware(dummy_module(), facts, None)
    fact_subset = sun_os_hardware.populate()

    assert fact_subset.get('memtotal_mb') == 16384
    assert fact_subset.get('swapfree_mb') == 3840
    assert fact_subset.get('swaptotal_mb') == 4096
    assert fact_subset.get('swap_allocated_mb') == 4096

# Generated at 2022-06-20 17:44:42.754119
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector.required_facts = set()

    module = FakeModule({'platform': 'SunOS'})
    sun_hw = SunOSHardwareCollector(module)

    assert sun_hw.platform == 'SunOS'
    assert sun_hw.required_facts == set(['platform'])



# Generated at 2022-06-20 17:44:45.696222
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_facts = SunOSHardwareCollector()
    assert hardware_facts._fact_class is SunOSHardware
    assert hardware_facts._platform is 'SunOS'

# Generated at 2022-06-20 17:44:49.232620
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    platform = 'SunOS'
    hardware_collector.required_facts.add('platform')
    hardware_collector.platform = platform


# Generated at 2022-06-20 17:44:53.448642
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware(None)

    assert hardware.platform == "SunOS"
    assert hardware.collector._platform == "SunOS"
    assert hardware.facts == {}



# Generated at 2022-06-20 17:44:58.037612
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeANSIModule()
    facts = SunOSHardware(module)
    assert facts.platform == 'SunOS'
    assert facts.module == module
    assert facts.run_command_environ_update == {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}



# Generated at 2022-06-20 17:45:01.828210
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_facts = SunOSHardware(None)
    assert hardware_facts is not None
    assert hardware_facts.platform == 'SunOS'
    assert hardware_facts.facts == dict()


# Generated at 2022-06-20 17:45:07.618653
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    hardware = SunOSHardware(module)
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u', ''))

    facts = hardware.populate()

    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'sun4u'


# Generated at 2022-06-20 17:45:09.737937
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    mod = AnsibleModuleMock()

    sunos_hardware = SunOSHardware(mod)

    assert(sunos_hardware.module == mod)
    assert(sunos_hardware.platform == 'SunOS')

# Generated at 2022-06-20 17:45:11.965962
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    system_facts = {'platform': 'SunOS'}
    facts = SunOSHardwareCollector.collect(system_facts)
    assert facts['hardware'].platform == 'SunOS'

# Generated at 2022-06-20 17:47:45.821681
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # FIXME
    pass



# Generated at 2022-06-20 17:47:48.599527
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = SunOSHardware({})
    collected_facts = {'ansible_machine': 'i86pc'}
    expected = {
        'processor': ['AMD64 Family 16 Model 17 Stepping 0'],
        'processor_count': 2,
        'processor_cores': 16
    }
    result = facts.get_cpu_facts(collected_facts=collected_facts)
    assert result == expected

# Generated at 2022-06-20 17:47:59.265614
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = Mock()
    mock_get_command_output = Mock()


# Generated at 2022-06-20 17:48:07.628954
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    SunOSHardware_instance = SunOSHardware(module)
    SunOSHardware_instance.get_memory_facts()
    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[0][0][0] == '/usr/sbin/prtconf'
    assert module.run_command.call_args_list[1][0][0] == '/usr/sbin/swap -s'


# Generated at 2022-06-20 17:48:08.522850
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # FIXME
    pass

# Generated at 2022-06-20 17:48:17.287930
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('obj', (), {'run_command': dummy_run_command})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 64800,
                            'swapfree_mb': 25064,
                            'swap_reserved_mb': 0,
                            'swaptotal_mb': 25064,
                            'swap_allocated_mb': 0}
