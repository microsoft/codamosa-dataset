

# Generated at 2022-06-20 17:38:39.797102
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector({}, {})
    assert hc.platform == 'SunOS'
    assert hc._fact_class == SunOSHardware

# Generated at 2022-06-20 17:38:43.084800
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = SunOSHardware().get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0

# Generated at 2022-06-20 17:38:45.979635
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    m = SunOSHardware(dict(), dict())
    assert m.populate() == {}
    assert m.populate(dict(platform=m._platform)) != {}

# Generated at 2022-06-20 17:38:48.539426
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h = SunOSHardware(run_command='')
    memory_facts = h.get_memory_facts()
    assert memory_facts is not None

# Generated at 2022-06-20 17:38:54.071419
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)

    hw = SunOSHardware(module)

    hw.populate()
    assert isinstance(hw.cpu, dict)
    assert isinstance(hw.memory, dict)
    assert isinstance(hw.dmi, dict)
    assert isinstance(hw.devices, dict)
    assert isinstance(hw.uptime, dict)
    assert isinstance(hw.mounts, dict)



# Generated at 2022-06-20 17:38:56.090347
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    # Create a class object to test the constructor
    collector = SunOSHardwareCollector()

    # Check that platforms list is correct
    assert collector.platforms == ['SunOS']

# Generated at 2022-06-20 17:39:00.901102
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    sunOSHW = SunOSHardware(module)
    assert sunOSHW.platform == 'SunOS'


# Generated at 2022-06-20 17:39:06.902992
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    HardwareCollector.clear_cache('SunOS')
    assert 'SunOS' not in HardwareCollector._module_cache['SunOS']
    h = SunOSHardwareCollector()
    assert 'SunOS' in HardwareCollector._module_cache['SunOS']
    assert h.platform == 'SunOS'
    assert h._fact_class.platform == 'SunOS'

# Generated at 2022-06-20 17:39:13.773339
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # Set up our class instance
    hw = SunOSHardware()

    # Make our test data

# Generated at 2022-06-20 17:39:15.137230
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    SunOSHardware(module)

# Generated at 2022-06-20 17:39:41.599279
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:53.656976
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.run_command = MagicMock(side_effect=lambda x, **kwargs: (0, 'kstat cpu_info output', ''))
    test_SunOSHardware = SunOSHardware(test_module)

    test_SunOSHardware.get_cpu_facts()

    assert test_module.fail_json.called is False
    assert test_module.exit_json.called is True

    cpu_facts = test_SunOSHardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 1
    assert isinstance(cpu_facts['processor'][0], str)



# Generated at 2022-06-20 17:40:00.849061
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = mock.Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    sun_hw = SunOSHardware(module)
    uptime_facts = sun_hw.get_uptime_facts()
    module.run_command.assert_called_once_with('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    assert uptime_facts['uptime_seconds'] == 1548249689


# Generated at 2022-06-20 17:40:05.449639
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # mock module, class and class instance
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "Memory size: 65536 Megabytes", None)

    mock_class_inst = SunOSHardware(mock_module)

    # get total memory from method we are testing
    total_mem = mock_class_inst.get_memory_facts()['memtotal_mb']

    # check method call and return value
    mock_module.run_command.assert_called_once_with("/usr/sbin/prtconf")
    assert total_mem == 65336


# Generated at 2022-06-20 17:40:16.388048
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Define a fake module class
    class FakeModule:
        def __init__(self, out):
            self.out = out

        def run_command(self, args):
            return 0, self.out, None

    # Mock prtconf output
    prtconf_out = 'Memory size: 16384 Megabytes'

    # Mock swap -s output
    swap_s_out = ('pagesize: 8192\n'
                  'total: 2097148\n'
                  'reserved: 419430\n'
                  'allocated: 2097148\n'
                  'used: 1048576\n'
                  'free: 1048576\n')
    # Define fake module object
    fake_module = FakeModule(out=prtconf_out)

# Generated at 2022-06-20 17:40:18.837675
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector_obj = SunOSHardwareCollector()
    assert hardware_collector_obj is not None

# Generated at 2022-06-20 17:40:29.630425
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    '''
    test get_memory_facts function of class SunOSHardware
    :return:
    '''
    from ansible.module_utils.facts.sunos.hardware import SunOSHardware
    hardware_collector = SunOSHardware()
    assert hardware_collector.get_memory_facts()['swapfree_mb'] == 'NA'
    assert hardware_collector.get_memory_facts()['swaptotal_mb'] == 'NA'
    assert hardware_collector.get_memory_facts()['swap_allocated_mb'] == 'NA'
    assert hardware_collector.get_memory_facts()['swap_reserved_mb'] == 'NA'
    pass

# Generated at 2022-06-20 17:40:32.047671
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.populate()

    assert hardware.facts['processor'][0] == 'Fire MAJC @ 1350MHz'

# Generated at 2022-06-20 17:40:34.967153
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = None
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-20 17:40:44.625677
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    Hardware._RunningOS = MagicMock()
    Hardware._RunningOS.system.return_value = "SunOS"
    Hardware.module = MagicMock()

    s = SunOSHardware()


# Generated at 2022-06-20 17:41:09.818588
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:41:17.855375
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list'),
        'filter': dict(default='*', type='str')
    })

    # os.environ['ANSIBLE_UNIT_TESTING'] = '1'
    # 'ANSIBLE_UNIT_TESTING': '1'

    # from ansible.modules.system.hardware import SunOSHardware
    SunOSHardware().populate()

# Generated at 2022-06-20 17:41:23.092500
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.collector import collect_facts

    facts_dict = collect_facts(
        gather_subset=['!all', 'devices'],
        filter_spec=dict(devices='^sd'),
        gather_timeout=5
    )

    assert(hasattr(facts_dict['ansible_devices'], 'sd0'))
    assert(hasattr(facts_dict['ansible_devices'], 'sd1'))

# Generated at 2022-06-20 17:41:27.571181
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector import FactsCollector

    facts_collector = FactsCollector()
    i = facts_collector.get_collection_class('hardware')
    f = i('sunos')
    d = f.get_device_facts()
    #print(d)

# Generated at 2022-06-20 17:41:39.484654
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Checks if get_dmi_facts() of class SunOSHardware
    returns the expected values
    """

    module = MagicMock()
    hardware = SunOSHardware(module)

    module.run_command.return_value = (0, 'System Configuration: Sun Microsystems sun4v\n', '')
    expected_result = {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == expected_result

    module.run_command.return_value = (0, 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)\n', '')

# Generated at 2022-06-20 17:41:43.674686
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    h = SunOSHardware()
    # Test that uptime_seconds does not exist yet
    assert 'uptime_seconds' not in h.facts

    # Test that uptime_seconds was found
    assert h.get_uptime_facts()['uptime_seconds'] is not None

# Generated at 2022-06-20 17:41:54.597076
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    collected_facts = {'ansible_machine': 'i86pc',
                       'ansible_processor': 'Intel(R) Core(TM) i5-3230M CPU @ 2.60GHz',
                       'ansible_processor_cores': '4',
                       'ansible_processor_count': '1',
                       'ansible_system': 'SunOS',
                       'ansible_system_vendor': 'Oracle Corporation',
                       'ansible_version': {'full': '7.1', 'major': '7', 'minor': '1'}}

    out_memory_facts = hardware.get_memory_facts()

    exp_memory_facts = {'memtotal_mb': 16359}

    assert out_memory_facts

# Generated at 2022-06-20 17:42:07.204844
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:15.260935
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    import pytest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector.sunos import SunOSHardwareCollector
    from ansible.module_util._text import to_bytes, to_text

    # Create an instance of SunOSHardware class for testing purpose.
    sun_hardware_obj = SunOSHardware()

    # Create an instance of SunOSHardwareCollector class for testing purpose.
    sun_hw_collector_obj = SunOSHardwareCollector()

    # json_out contains the output of 'kstat -p unix:0:system_misc:boot_time' command in json format.

# Generated at 2022-06-20 17:42:28.685070
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Arrange
    SunOSHardware_instance = SunOSHardware()
    kstat_cpu_info_output = """module: cpu_info	instance: 0	class: misc
brand		                            GenuineIntel
chip_id		                            0
clock_MHz		                        2600.031
clog_id		                            0
core_id		                            0
implementation	                        Intel(R) Atom(TM) CPU  C2750  @ 2.40GHz
module		                            0
socket_id		                        0
state		                            on-line
strand_id		                        0
type		                            x86
update_level	                            25
version		                            0x1
"""

    # Act

# Generated at 2022-06-20 17:43:06.150908
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware(None)
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': 'i86pc'})
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor'] == ['Intel(r) Core(tm) i3 CPU       M 380  @ 2.53GHz']


# Generated at 2022-06-20 17:43:11.013995
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware().get_memory_facts()
    assert mem_facts['swap_reserved_mb']
    assert mem_facts['swaptotal_mb']
    assert mem_facts['swap_allocated_mb']
    assert mem_facts['swapfree_mb']
    assert mem_facts['memtotal_mb']

# Generated at 2022-06-20 17:43:14.025893
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hw = SunOSHardwareCollector()
    assert type(hw) == SunOSHardwareCollector

# Generated at 2022-06-20 17:43:18.108640
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()

    assert len(cpu_facts['processor']) > 0
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-20 17:43:20.411200
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    hardware.populate()
    assert hardware.facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:43:30.265555
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # Create a instance for class SunOSHardware
    data = SunOSHardware({'platform': 'SunOS'})

    # Check the type of instance is SunOSHardware
    assert isinstance(data, SunOSHardware)

    # Check instance interface
    assert hasattr(data, 'populate')
    assert hasattr(data, 'get_cpu_facts')
    assert hasattr(data, 'get_memory_facts')
    assert hasattr(data, 'get_dmi_facts')
    assert hasattr(data, 'get_device_facts')
    assert hasattr(data, 'get_uptime_facts')

# Generated at 2022-06-20 17:43:42.690434
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    # Returned from run_command
    # prtdiag
    system_conf = 'System Configuration: VMware, Inc. VMware Virtual Platform'

    out = {
        '/usr/bin/uname -i': (0, 'i86pc', ''), 
        '/usr/platform/i86pc/sbin/prtdiag': (0, system_conf, '')
    }
    module.run_command.side_effect = out.get
    module.fail_json.side_effect = fail_json_local

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-20 17:43:54.765252
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Create a SunOSHardwareCollector class object and verify it
    is an object of SunOSHardwareCollector and HardwareCollector class and
    has attribute _fact_class of type SunOSHardware and _platform
    of type string and required_facts is a subset of super class
    required_facts
    """

    sunos_collector_obj = SunOSHardwareCollector()
    assert isinstance(sunos_collector_obj, SunOSHardwareCollector)
    assert issubclass(type(sunos_collector_obj), HardwareCollector)
    assert hasattr(sunos_collector_obj, '_fact_class')
    assert type(sunos_collector_obj._fact_class) == SunOSHardware
    assert hasattr(sunos_collector_obj, '_platform')

# Generated at 2022-06-20 17:44:04.838030
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import unittest
    from mock import patch

    class TestSunOSHardware_get_cpu_facts(unittest.TestCase):
        @patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.get_cpu_facts')
        def test_cpu_facts(self, get_cpu_facts_method):
            with patch.object(SunOSHardware, 'get_cpu_facts') as cpu_facts:
                cpu_facts.return_value = {'processor': ['Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz']}
                facts = SunOSHardware()
                cpu_facts_outcome = facts.populate()

                # Assert that cpu_facts() is called
                self.assertTrue(get_cpu_facts_method.called)

                # Assert that populate()

# Generated at 2022-06-20 17:44:13.893609
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=True
    )

    def run_command(self, args, check_rc=True, close_fds=True):
        if args[0] == '/usr/bin/kstat' and '-p' in args and 'sderr' in args:
            return (0, OUT, '')
        else:
            self.fail_json(msg='Unexpected command run by get_device_facts')

    SunOSHardware.run_command = run_command

    hardware = SunOSHardware(module)
    result = hardware.populate()

    assert result.has_key('devices')
    assert result['devices'].has_key('sda')

# Generated at 2022-06-20 17:45:19.760185
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({})
    assert hardware

# Generated at 2022-06-20 17:45:22.371402
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware({})
    assert type(hw) == SunOSHardware

# Unit tests for each method in class SunOSHardware

# Generated at 2022-06-20 17:45:29.389313
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """ Tests if the value of 'uptime_seconds' is equal to the difference of
        the current time and kstat boot time.
    """
    # Mock class used to unit test method get_uptime_facts of class SunOSHardware
    class MockSunOSHardware:
        def __init__(self):
            self.module = None

    # Create a new mock object
    sunos_hardware_obj = MockSunOSHardware()
    # Invoke the method get_uptime_facts of class SunOSHardware to
    # construct the uptime_facts dictionary
    uptime_facts = sunos_hardware_obj.get_uptime_facts()
    # Find the difference between the current time and kstat boot time
    # using the class SunOSHardware
    sunos_hardware_obj2 = SunOSHardware()
    # Invoke the method get

# Generated at 2022-06-20 17:45:32.431075
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test if it returns a SunOSHardware instance"""
    hardware_facts = SunOSHardware('SunOS')
    hardware_facts.populate()
    assert isinstance(hardware_facts, SunOSHardware)
    assert len(hardware_facts.data.keys()) > 0

# Generated at 2022-06-20 17:45:36.900833
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # test data
    kstat_output = 'unix:0:system_misc:boot_time    {0}'.format(int(time.time() - 100))
    # collect data
    uptime_facts = SunOSHardware().get_uptime_facts({'platform': 'SunOS'})
    # assert result
    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-20 17:45:39.385539
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.sunos.hardware import SunOSHardware
    module = SunOSHardware()

    assert module.populate()

# Generated at 2022-06-20 17:45:43.788989
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('AnsibleModule', (object,), {})
    hardware = SunOSHardware(module)
    assert hardware.get_dmi_facts() == {'product_name': 'T5120', 'system_vendor': 'Fujitsu'}

# Generated at 2022-06-20 17:45:50.576585
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware().populate()
    assert 'memtotal_mb' in facts['ansible_facts']
    assert 'swapfree_mb' in facts['ansible_facts']
    assert 'swaptotal_mb' in facts['ansible_facts']
    assert 'swap_allocated_mb' in facts['ansible_facts']
    assert 'swap_reserved_mb' in facts['ansible_facts']

# Generated at 2022-06-20 17:45:55.032819
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    sunos_collector = SunOSHardwareCollector()
    assert sunos_collector.platform == 'SunOS'

# Generated at 2022-06-20 17:46:04.552766
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Unit test for method get_dmi_facts of class SunOSHardware."""

    sun_os_hardware = SunOSHardware(dict())
    test_facts = {
        'prtdiag': """System Configuration: Sun Microsystems sun4v
System Configuration: Oracle Corporation sun4v"""
    }
    test_output = sun_os_hardware.get_dmi_facts(test_facts)
    assert 'system_vendor' in test_output
    assert 'product_name' in test_output
    assert test_output['system_vendor'] == 'Sun Microsystems'
    assert test_output['product_name'] == 'sun4v'


# Unit tests for methods in SunOSHardware not covered by integration tests