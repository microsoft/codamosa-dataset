

# Generated at 2022-06-20 17:38:48.696759
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)
    cpu_facts = hw.get_cpu_facts()
    fact_dict = {'processor': [u'SUNW,Netra-CP3200 @ 667 MHz'],
                 'processor_cores': 1,
                 'processor_count': 1}
    assert cpu_facts == fact_dict

    memory_facts = hw.get_memory_facts()
    fact_dict = {'memtotal_mb': 511,
                 'swap_allocated_mb': 0,
                 'swap_reserved_mb': 0,
                 'swapfree_mb': 0,
                 'swaptotal_mb': 0}
    assert memory_facts == fact_dict



# Generated at 2022-06-20 17:38:51.849422
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    result = SunOSHardware(module)

    for attr in result.__dict__:
        if attr == '_platform':
            assert result._platform == 'SunOS'


# Generated at 2022-06-20 17:39:00.440971
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # ToDo: add some tests here
    # e.g. ''' assert foo == bar '''

    # Constructor test:
    module = FakeAnsibleModule()
    hardware_collector = SunOSHardware(module)

    # run_command
    hardware_collector.module.run_command = lambda x, environ_update=None: (0, '', '')

    # get_uptime_facts
    hardware_collector.get_uptime_facts()

    # get_cpu_facts
    hardware_collector.get_cpu_facts()

    # get_memory_facts
    hardware_collector.get_memory_facts()

    # get_device_facts
    hardware_collector.get_device_facts()

    # get_dmi_facts
    hardware_collector.get_dmi_facts()

# Generated at 2022-06-20 17:39:11.604308
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    dev_facts = {}
    dev_facts['devices'] = {
        'sd0': {
            'product': 'VBOX HARDDISK',
            'revision': '1.0',
            'serial': 'VB0ad2ec4d-074a',
            'size': '50G',
            'vendor': 'ATA',
            'hard_errors': '0',
            'soft_errors': '0',
            'transport_errors': '0',
            'media_errors': '0',
            'predictive_failure_analysis': '0',
            'illegal_request': '6'
        }
    }

    mod = MockModule()

# Generated at 2022-06-20 17:39:19.105851
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    Constructor SunOSHardware test.
    """
    # Test with invalid platforms. 'platform' should be 'SunOS'
    platforms = ['Darwin', 'FreeBSD', 'Linux', 'AIX', 'Junos', 'HP-UX', 'Windows']

    for platform in platforms:
        hardware = SunOSHardware({'ansible_facts': {'platform': platform}})
        hardware.populate()
        hardware.get_device_facts()
        hardware.get_dmi_facts()
        hardware.get_cpu_facts()
        hardware.get_memory_facts()
        hardware.get_mount_facts()
        hardware.get_uptime_facts()
        assert True

# Generated at 2022-06-20 17:39:27.319496
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    sunosHardware = SunOSHardware(module)


# Generated at 2022-06-20 17:39:38.128042
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeModule()
    module.run_command = FakeRunCommand()

    sunos_hw = SunOSHardware(module)
    fact_list = sunos_hw.populate()

    assert fact_list['uptime_seconds'] == 2
    assert len(fact_list['devices']) == 2
    assert fact_list['devices']['sda']['product'] == 'IBM-ESXS" MASTER'
    assert fact_list['devices']['sda']['revision'] == 'A13G'
    assert fact_list['devices']['sda']['serial'] == 'YQF5085R'
    assert fact_list['devices']['sda']['size'] == '3.6T'
    assert fact_list['devices']['sda']['vendor']

# Generated at 2022-06-20 17:39:45.641206
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:53.524338
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()
    dmi_facts = m.get_dmi_facts()

    if dmi_facts['system_vendor'] == 'Sun Microsystems':
        assert(dmi_facts['product_name'] == 'Sun-Fire-V240')
    else:
        assert(dmi_facts['system_vendor'] == 'Oracle Corporation')
        assert(dmi_facts['product_name'] == 'Oracle Corporation sun4v SPARC Enterprise T5240')

# Generated at 2022-06-20 17:40:02.086544
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.hardware import SunOSHardware

    hardware_facts = SunOSHardware()
    hardware_facts.populate()

    assert hardware_facts.fact == {
        'ansible_facts': {
            'devices': {},
            'memtotal_mb': 16384,
            'mounts': None,  # skipped
            'processor': ['Genuine Intel(R) CPU 0000 @ 1600MHz'],
            'processor_cores': 8,
            'processor_count': 1,
            'swap_allocated_mb': 8192,
            'swap_reserved_mb': 8192,
            'swapfree_mb': 8192,
            'swaptotal_mb': 16384
        },
    }

# Generated at 2022-06-20 17:40:31.955217
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts = {}
    # Device facts are derived for sdderr kstats. This code does not use the
    # full output, but rather queries for specific stats.
    # Example output:
    # sderr:0:sd0,err:Hard Errors     0
    # sderr:0:sd0,err:Illegal Request 6
    # sderr:0:sd0,err:Media Error     0
    # sderr:0:sd0,err:Predictive Failure Analysis     0
    # sderr:0:sd0,err:Product VBOX HARDDISK   9
    # sderr:0:sd0,err:Revision        1.0
    # sderr:0:sd0,err:Serial No       VB0ad2ec4d-074a
    # sderr:

# Generated at 2022-06-20 17:40:32.975462
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-20 17:40:36.498025
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockAnsibleModule()
    test_obj = SunOSHardware(module)
    assert test_obj.populate() is None

# Generated at 2022-06-20 17:40:38.506370
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware_object = SunOSHardware(dict())
    assert hardware_object.platform == 'SunOS'



# Generated at 2022-06-20 17:40:46.322447
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:40:59.481585
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import sys
    import unittest
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class AnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = args[0]
            self._tmpdir = '/tmp'
            self.args = []

        def get_bin_path(self, executable, opt_dirs=[]):
            if executable == 'prtdiag':
                return '/usr/sbin/prtdiag'
            if executable == 'kstat':
                return '/usr/bin/kstat'


# Generated at 2022-06-20 17:41:08.958586
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:41:16.013579
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sh = SunOSHardware()
    out = "System Configuration: VMware, Inc. VMware Virtual Platform"
    assert sh.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}, out
    out = sh.get_dmi_facts()
    assert out == {}, out



# Generated at 2022-06-20 17:41:21.861754
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    test_SunOSHardware_get_device_facts: get_device_facts of class SunOSHardware
    """
    module = AnsibleModule(argument_spec={})
    module.params = {}
    sunos_hw = SunOSHardware(module)
    device_facts = sunos_hw.get_device_facts()
    assert isinstance(device_facts, dict)
    assert 'devices' in device_facts.keys()
    assert isinstance(device_facts['devices'], dict)


# Generated at 2022-06-20 17:41:29.065244
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hostname = "host1"
    sn = "deadbeef"
    ssh_pub_key_file = "/root/.ssh/id_rsa.pub"
    module = "ansible.module_utils.facts.hardware.sunos.SunOSHardware"
    _hw = SunOSHardware(module=module, hostname=hostname, ssh_pub_key_file=ssh_pub_key_file, sn=sn)
    assert _hw.module == module
    assert _hw.hostname == hostname
    assert _hw.ssh_pub_key_file == ssh_pub_key_file
    assert _hw.sn == sn


# Generated at 2022-06-20 17:41:51.900690
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = MockModule()
    sut = SunOSHardware(module)

    expected_result = {'uptime_seconds': 1234567890}
    boot_time = '1234567890'
    module.run_command.return_value = (0, boot_time, '')

    # ACT
    actual_result = sut.get_uptime_facts()

    # ASSERT
    assert actual_result == expected_result
    module.run_command.assert_called_with('/usr/bin/kstat -p unix:0:system_misc:boot_time')



# Generated at 2022-06-20 17:42:04.162906
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    This method checks if the uptime_seconds returned by SunOSHardware.get_uptime_facts()
    is correctly calculated.
    """
    import time
    from ansible.module_utils._text import to_text
    from mock import Mock

    # Create a mock module, to be passed as input to SunOSHardware
    mock_module = Mock()
    # Mock the run_command method of the module, to return a mocked out
    # output based on the kstat command.
    mock_module.run_command.return_value = (0, to_text("unix:0:system_misc:boot_time 1548249689"), None)
    # Create an instance of SunOSHardware, using the mocked module.

    hardware_instance = SunOSHardware(mock_module)
    # Get the uptime_facts by invoking the method get

# Generated at 2022-06-20 17:42:07.776127
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware(None)
    test_out = """Memory size: 8192 Megabytes
                     ======================= """
    test_mem_facts = hardware.get_memory_facts()
    assert test_mem_facts['memtotal_mb'] == 8192

# Generated at 2022-06-20 17:42:15.585062
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Initializing test command module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.run_command_environ_update = None

    # Initializing test class
    cls = SunOSHardware()
    cls.module = module
    cls.populate()

    assert cls.facts['processor'] == []
    assert cls.facts['processor_cores'] == 'NA'
    assert cls.facts['processor_count'] == 0
    assert cls.facts['memtotal_mb'] == 0
    assert cls.facts['swapfree_mb'] == 0
    assert cls.facts['swaptotal_mb'] == 0
    assert cls.facts['swap_allocated_mb'] == 0

# Generated at 2022-06-20 17:42:25.817681
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()

    # Expected output:
    # dmi_facts = {
    #     'system_vendor': 'Oracle Corporation',
    #     'product_name': 'Oracle Corporation Sun Fire T2000',
    # }

    sunoshardware = SunOSHardware(module=module)
    dmi_facts = sunoshardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'Oracle Corporation Sun Fire T2000'


# Generated at 2022-06-20 17:42:34.249943
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeANSIModule() 
    hardware = SunOSHardware(module)
    # pass empty string to simulate a command which has failed
    hardware.get_dmi_facts()

    # Actual test
    sample_output = '''System Configuration: VMware, Inc. VMware Virtual Platform
Sun Microsystems sun4v
Memory size: 8192 Megabytes'''
    module.run_command_out = sample_output
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-20 17:42:36.946771
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule()
    uptime_facts = SunOSHardware(module).get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0


# Generated at 2022-06-20 17:42:49.356562
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    facts = SunOSHardware(module).populate()

# Generated at 2022-06-20 17:42:59.450480
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule()
    SunOSHardware(module).populate()
    assert module.exit_json.called
    assert 'ansible_facts' in module.exit_json_args.keys()
    assert 'ansible_devices' in module.exit_json_args['ansible_facts'].keys()
    assert 'ansible_mounts' in module.exit_json_args['ansible_facts'].keys()
    assert 'ansible_processor' in module.exit_json_args['ansible_facts'].keys()
    assert 'ansible_processor_cores' in module.exit_json_args['ansible_facts'].keys()
    assert 'ansible_processor_count' in module.exit_json_args['ansible_facts'].keys()
    assert 'ansible_product_name' in module

# Generated at 2022-06-20 17:43:01.263689
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.platform == 'SunOS'
    assert not hardware.populate()

# Generated at 2022-06-20 17:43:43.751821
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    '''
    Test that the constructor works as expected.
    '''
    # Test the constructor
    sun = SunOSHardware(None)

    # Test the properties of the object
    assert sun.platform == 'SunOS'
    assert sun.facts == {}

# Generated at 2022-06-20 17:43:50.485438
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    mock_module = type('module', (object,), {})()
    mock_module.get_bin_path = lambda *args, **kwargs: None
    mock_module.run_command.return_value = 0, '', ''

    hw_collector = SunOSHardwareCollector(mock_module)

    assert hw_collector._platform == 'SunOS'
    assert hw_collector._fact_class == SunOSHardware
    assert hw_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:43:53.259660
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    collection = SunOSHardwareCollector()
    facts = collection.collect(None, None)
    assert len(facts) == 1

# Generated at 2022-06-20 17:44:03.537815
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Monkeypatched module is required for mocking run_command
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import ansible.module_utils.facts.hardware.sunos

    # create a mock module object
    mock_module = ansible.module_utils.facts.hardware.sunos.AnsibleModule(
        argument_spec={})

    # assign our mock method to the module object `run_command`
    mock_module.run_command = get_mock_run_command()

    # create a new SunOSHardware object
    sunos_facts = SunOSHardware(mock_module)

    # call the method under test
    device_facts = sunos_facts.get_device_facts()

    # assert that the output matches

# Generated at 2022-06-20 17:44:09.322959
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    H = SunOSHardware({})
    # Create a fake fact collection
    fact_collection = dict(ansible_machine='i86pc')
    test_output = "System Configuration: SPARC Enterprise M5000 server"
    assert (H.get_dmi_facts(fact_collection) == {'system_vendor': 'SPARC', 'product_name': 'Enterprise M5000 server'})
    test_output = "System Configuration: Sun Microsystems sun4u Sun Fire T2000"
    assert (H.get_dmi_facts(fact_collection) == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u Sun Fire T2000'})
    test_output = "System Configuration: VMware, Inc. VMware Virtual Platform"

# Generated at 2022-06-20 17:44:21.065889
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:44:28.734027
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """
    SunOSHardware - collect hardware facts on a Solaris system
    """
    module = AnsibleModule(
        argument_spec={},
    )
    # default constructor of SunOSHardware should gather facts based on the platform
    sunos_hardware_facts = SunOSHardware(module)

    # We are only validating that the platform value is set correctly.
    assert sunos_hardware_facts.platform == 'SunOS'

# Generated at 2022-06-20 17:44:34.959768
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = object()
    module.run_command = lambda *args, **kwargs: (0, None, None)
    module.get_bin_path = lambda *args, **kwargs: None
    sunoshw = SunOSHardware(module)
    meminfo = sunoshw.get_memory_facts()
    assert 'memtotal_mb' in meminfo
    assert 'swaptotal_mb' in meminfo
    assert 'swapfree_mb' in meminfo


# Generated at 2022-06-20 17:44:40.008878
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Ensure get_cpu_facts returns results"""

# Generated at 2022-06-20 17:44:44.616442
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h = SunOSHardware()
    result = h.get_memory_facts()
    assert result['memtotal_mb'] == 8192
    assert result['swapfree_mb'] == 1633
    assert result['swaptotal_mb'] == 1633
    assert result['swap_allocated_mb'] == 0
    assert result['swap_reserved_mb'] == 0



# Generated at 2022-06-20 17:46:08.252625
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = dict()
    out = ("module:\n"
           "     cpu_info\n"
           "implementation:\n"
           "     SPARC-T5 (chipid 0, clock 1502 MHz)\n"
           "chip_id:\n"
           "     0\n"
           "chip_type:\n"
           "     SPARC-T5\n"
           "brand:\n"
           "     SPARC-T5 (chipid 0, clock 1502 MHz)\n"
           "clock_MHz:\n"
           "     1502\n"
           "module:")
    f = SunOSHardware(facts, [out, "", 0])

# Generated at 2022-06-20 17:46:19.698929
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Test with prtconf output
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "System Configuration: Sun Microsystems sun4u\nMemory size: 4096 Megabytes\n", "")
    hardware = SunOSHardware(mock_module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4096

    # Test with swap output
    mock_module.run_command.return_value = (0, "swapfile             dev  swaplo blocks   free\n/dev/zvol/dsk/rpool/swap  166,1         8  8388640  8388640", "")
    facts = hardware.get_memory_facts()
    assert facts['swapfree_mb'] == 8192  # 838

# Generated at 2022-06-20 17:46:23.820792
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_facts = SunOSHardware()
    collected_facts = {
        "ansible_machine": "sparc64"
    }
    hardware_facts.populate(collected_facts)
    assert hardware_facts.data["processor"] == ['SPARC64-VI+ @ 1500MHz']


# Generated at 2022-06-20 17:46:25.118028
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    assert x.collect() == {}

# Generated at 2022-06-20 17:46:26.883044
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector(None)

# Generated at 2022-06-20 17:46:37.094967
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    hardware_facts = SunOSHardware(None)

    def convert_to_epoch_seconds(date_time_string):
        dt = datetime.datetime.strptime(date_time_string, '%Y-%m-%dT%H:%M:%S')
        return str(int(dt.timestamp()))

    # Convert a given string in YYYY-MM-DDTHH:MM:SS format to epoch seconds
    epoch_seconds = convert_to_epoch_seconds('2019-01-23T10:26:09')
    expected_output = {
        'uptime_seconds': int(time.time() - int(epoch_seconds))
    }
    # Set the time.

# Generated at 2022-06-20 17:46:45.985041
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Test the get_uptime_facts method for SunOSHardware class.
    """
    from ansible.module_utils.six.moves import mock
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    with mock.patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.run_command') as run_command_mock:
        run_command_mock.return_value = 0, 'unix:0:system_misc:boot_time 1548249689', ''
        uptime = SunOSHardware().get_uptime_facts()
        assert uptime == {'uptime_seconds': 2}

# Generated at 2022-06-20 17:46:51.352240
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd):
            return (0, 'unix:0:system_misc:boot_time 1548249689', '')

    mock_module = MockModule()
    f = SunOSHardware()
    assert f.get_uptime_facts(mock_module)['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-20 17:46:57.075267
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule({})
    hardware = SunOSHardware(module=module)
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': 'i86pc'})
    cpu_facts_sparc = hardware.get_cpu_facts({'ansible_machine': 'sun4v'})

    assert cpu_facts['processor_cores'] == 24
    assert cpu_facts['processor_count'] == 8
    assert cpu_facts['processor'][0] == 'Intel(r) Xeon(r) CPU E5-2697 v2 @ 2.70GHz'
    assert cpu_facts['processor'][7] == 'Intel(r) Xeon(r) CPU E5-2697 v2 @ 2.70GHz'

    assert cpu_facts_sparc['processor_cores'] == 2
    assert cpu

# Generated at 2022-06-20 17:47:00.003806
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunoshw = SunOSHardware()

    assert sunoshw.platform == SunOSHardware.platform
    assert sunoshw.populate.__name__ == 'populate'