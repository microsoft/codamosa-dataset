

# Generated at 2022-06-20 17:38:49.768160
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()

    hw = SunOSHardware(module)

    # Solaris is weird, we can't have one without the other:
    hw.get_cpu_facts = lambda: {'processor': ['foo']}
    hw.get_memory_facts = lambda: {'swapfree': '1M',
                                   'swaptotal': '2M',
                                   'swap_reserved': '2M',
                                   'swap_allocated': '1M'}

    hw.get_dmi_facts = lambda: {'system_vendor': 'Oracle',
                                'product_name': 'SPARC T4-2'}


# Generated at 2022-06-20 17:38:59.465382
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    datalist = [
        (
            [{'ansible_machine': 'sun4v'}],
            {
                'processor': ['SPARC64-VI @ 1.3GHz'],
                'processor_count': 1,
                'processor_cores': 1
            }
        ),
        (
            [{'ansible_machine': 'i86pc'}],
            {
                'processor': ['Intel(r) Xeon(r) CPU E5-2407 0 @ 2.20GHz'],
                'processor_count': 1,
                'processor_cores': 1
            }
        ),
    ]

    for collected_facts, expected_result in datalist:
        hardware = SunOSHardware(None)
        assert hardware.get_cpu_facts(collected_facts) == expected_result

# Generated at 2022-06-20 17:39:03.588762
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert hc._fact_class is SunOSHardware
    assert hc._platform == 'SunOS'
    assert hc.required_facts == set(['platform'])

# Generated at 2022-06-20 17:39:06.430895
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts = {'platform': 'SunOS'}
    collector = SunOSHardwareCollector(facts)
    assert collector.facts == facts
    assert collector.platform == 'SunOS'
    assert collector.fact_class == SunOSHardware

# Generated at 2022-06-20 17:39:11.825331
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    SunOSHardware_obj = SunOSHardware()

    # test for positive values
    uptime_facts = SunOSHardware_obj.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] >= '0'

    # test for negative values
    uptime_facts['uptime_seconds'] = '-1'

    assert uptime_facts['uptime_seconds'] <= '0'

# Generated at 2022-06-20 17:39:20.281025
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware = SunOSHardware(module=module)
    hardware.populate()

    assert hardware.cpu_facts['processor'] == ['SUNW,UltraSPARC-II']
    assert hardware.cpu_facts['processor_cores'] == 1
    assert hardware.cpu_facts['processor_count'] == 1

    assert hardware.memory_facts['memtotal_mb'] == 256
    assert hardware.memory_facts['swapfree_mb'] == 0
    assert hardware.memory_facts['swaptotal_mb'] == 0
    assert hardware.memory_facts['swap_allocated_mb'] == 0
    assert hardware.memory_facts['swap_reserved_mb'] == 0

    assert hardware.mount_facts['mounts'] == []


# Generated at 2022-06-20 17:39:23.500972
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """This is to test the constructor of class SunOSHardwareCollector."""
    module = Mock()
    sunos = SunOSHardwareCollector(module=module)
    assert sunos._platform == 'SunOS'

# Generated at 2022-06-20 17:39:29.320542
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    # inject the module into the fact
    SunOSHardware.module = module

    # Create an instance of the class SunOSHardware
    sh = SunOSHardware()

    # Run the method get_memory_facts
    facts = sh.get_memory_facts()

    assert 'memtotal_mb' in facts



# Generated at 2022-06-20 17:39:40.074964
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-20 17:39:53.116055
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Method get_dmi_facts returns a dict with keys:
    # 'system_vendor'
    # 'product_name'
    # 'system_vendor' is an empty string if it could not be identified from the
    # command output. Likewise, 'product_name'.
    #
    # For example:
    # {'system_vendor': 'Oracle Corporation', 'product_name': 'SUN FIRE X4170'}

    # FIXME: this test does not test a full output of prtdiag

    # Command output for Sun Fire X4170
    m1 = """
System Configuration: SUN FIRE X4170
System clock frequency: 1019 MHz
Memory size: 16384 Megabytes
System Revision: 01
""".strip()


# Generated at 2022-06-20 17:40:18.301512
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-20 17:40:24.976622
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = type('MockModule', (), {'run_command': lambda x: (0, 'unix:0:system_misc:boot_time\t1546799897', '')})
    sh = SunOSHardware(module)
    uptime_facts = sh.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1546799897)

# Generated at 2022-06-20 17:40:27.759695
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'

# Generated at 2022-06-20 17:40:32.481489
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.facts == {}
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-20 17:40:42.434408
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils.sunos import AnsibleModuleSunOS

    m = AnsibleModuleSunOS(
        argument_spec={}
    )

    s = SunOSHardware(m)

    # input

# Generated at 2022-06-20 17:40:47.312493
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    get_uptime_facts_function = SunOSHardware.get_uptime_facts
    # sample kstat output:
    # unix:0:system_misc:boot_time    1548249689
    rc = 0
    out = "unix:0:system_misc:boot_time    1548249689"
    err = ''
    seconds = int(time.time() - int(out.split('\t')[1]))
    expected_result = {'uptime_seconds': seconds}
    assert expected_result == get_uptime_facts_function()


# Generated at 2022-06-20 17:40:59.645485
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    prtconf_output = '''\
System Configuration: VMware, Inc. VMware Virtual Platform
Memory size: 516 Megabytes
'''
    swap_s_output = '''\
swapfile             dev  swaplo blocks   free
/dev/zvol/dsk/rpool/swap 251,0    16  4194296      424
'''
    ansible_module_mock = MagicMock(return_value=prtconf_output)
    module.run_command = ansible_module_mock

    hardware = SunOSHardware(module=module)

    swap_reserved_mb = 424
    swap_allocated_mb = 4194296

    memory_facts = hardware.get_memory_facts()

    swap_reserved_mb_fact = memory_

# Generated at 2022-06-20 17:41:02.394769
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock()
    hardware_obj = SunOSHardware(module)
    assert hardware_obj.module == module

# Generated at 2022-06-20 17:41:04.179304
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector(None, None)
    assert hardware_collector is not None

# Generated at 2022-06-20 17:41:06.869652
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hw = SunOSHardware(module)
    assert hw.populate() is None


# Generated at 2022-06-20 17:41:51.795371
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_module = type('', (), {
        'run_command': lambda *args, **kwargs: (0, b"line\n", b""),
        'get_bin_path': lambda *args, **kwargs: None,
        'get_file_content': lambda *args, **kwargs: None,
        'get_mount_size': lambda *args, **kwargs: None,
    })()

    test_SunOSHardware = SunOSHardware(module=test_module)
    test_SunOSHardware.populate()

# Generated at 2022-06-20 17:41:58.749972
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # Test for AIX
    out = """System Configuration:     IBM,9117-570
        Memory Size:    1024 MB
        CPU Type:       PowerPC_POWER8
        Firmware Version: IBM,SF240_303"""
    facts = {'ansible_machine': 'ppc64'}

    SunOSHardware().get_memory_facts(facts)
    SunOSHardware().get_dmi_facts(facts)

    # Test for I86pc
    out = """System Configuration:     VMware, Inc. VMware Virtual Platform
        Memory Size:    2048 MB
        CPU Type:       x86"""
    facts = {'ansible_machine': 'i86pc'}

    SunOSHardware().get_memory_facts(facts)
    SunOSHardware().get_dmi_facts(facts)

    # Test for Sun4v

# Generated at 2022-06-20 17:42:09.923483
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule(object):
        def __init__(self, out, rc, disk_stats):
            self.out = out
            self.rc = rc
            self.disk_stats = disk_stats

        def run_command(self, cmd):
            self.cmd = cmd
            return self.rc, self.out, ''

    # TODO Add other common cases. Override get_bin_path for testing.

# Generated at 2022-06-20 17:42:14.501780
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec = dict(
            foo=dict(required=True, type='int')
        ),
        supports_check_mode=True
    )

    hardware_sunos = SunOSHardware(module)
    uptime_facts = hardware_sunos.get_uptime_facts()
    # uptime is greater than 0
    assert uptime_facts['uptime_seconds'] > 0
    # return code is 0
    assert module.run_command.call_count > 0

# Generated at 2022-06-20 17:42:27.775632
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:29.719673
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:42:33.729155
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = SunOSHardware().get_uptime_facts()

    if 'uptime_seconds' not in uptime_facts:
        raise AssertionError('No uptime_seconds returned!')
    if uptime_facts['uptime_seconds'] < 0:
        raise AssertionError('Negative uptime_seconds returned!')

# Generated at 2022-06-20 17:42:45.768183
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module_mock = AnsibleModuleMock()
    kstat_cmd = ['/usr/bin/kstat', '-p']
    expected_kstat_cmd = ['/usr/bin/kstat', '-p',
                          'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size',
                          'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors',
                          'sderr:::Transport Errors', 'sderr:::Media Error',
                          'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request']

    def run_command_func(cmd, check_rc=True):
        assert expected_kstat_cmd == cmd

        #

# Generated at 2022-06-20 17:42:56.570852
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = FakeAnsibleModule(argument_spec=dict())

    sunoshardware = SunOSHardware(module)
    collected_facts = sunoshardware.populate()

    assert collected_facts['ansible_processor_cores'] == 2
    assert collected_facts['ansible_processor_count'] == 2
    assert collected_facts['ansible_product_name'] == 'Oracle Corporation SPARC T7-2'
    assert collected_facts['ansible_system_vendor'] == 'Oracle Corporation'
    assert collected_facts['ansible_devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert collected_facts['ansible_devices']['sd0']['revision'] == '1.0'
    assert collected_facts['ansible_devices']['sd0']['serial']

# Generated at 2022-06-20 17:43:07.989290
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock({})

    out = 'Memory size: 2048 Megabytes'
    module.run_command.return_value = (0, out, None)

    out = 'Memory size: 53687091200 Megabytes'
    module.run_command.return_value = (0, out, None)

    out = 'Memory size: 9223372036854771712 Megabytes'
    module.run_command.return_value = (0, out, None)

    result = SunOSHardware(module).get_memory_facts()

    assert result['memtotal_mb'] == 2048
    assert result['memtotal_mb'] == 53687091200
    assert result['memtotal_mb'] == 9223372036854771712



# Generated at 2022-06-20 17:43:59.142755
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:44:10.554046
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    input_kstat_cpu_info = """module: cpu_info
instance: 0
class: misc
current: cpu_info
crtime
chip_id
class
clock_MHz
state
implementation
brand
"""
    input_uname = """SPARC T4-4
"""
    facts_dict = {'platform': 'SunOS'}
    expected_output = """{'processor_count': 1, 'processor_cores': 2, 'processor': ['SPARC T4 @ 2400MHz', 'SPARC T4 @ 2400MHz']}
"""
    output = SunOSHardwareCollector.get_cpu_facts(input_kstat_cpu_info, input_uname, facts_dict)
    assert output == expected_output

# Generated at 2022-06-20 17:44:20.975202
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = mock_module_helper()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')

    hw = SunOSHardware()
    result = hw.get_uptime_facts()

    assert type(result) is dict
    assert 'uptime_seconds' in result.keys()
    assert result['uptime_seconds'] == 32331
    assert module.run_command.call_count == 1
    assert module.run_command.call_args == call('/usr/bin/kstat -p unix:0:system_misc:boot_time')


# Generated at 2022-06-20 17:44:27.214990
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    hardware.populate()

    assert hardware.facts['processor'] == ['sunw,UltraSPARC-T2 @ 1665MHz']
    assert hardware.facts['processor_count'] == 8
    assert hardware.facts['processor_cores'] == 32
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 1505
    assert hardware.facts['swapfree_mb'] == 1505
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'Sun Fire X4140'
    assert hardware

# Generated at 2022-06-20 17:44:29.647578
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    assert SunOSHardware().get_uptime_facts()['uptime_seconds'] >= 0

# Generated at 2022-06-20 17:44:41.093769
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    system_conf = ("System Configuration: VMware,  Inc. VMware Virtual Platform\n"
                   "BIOS Configuration: Phoenix Technologies LTD 6.00           ")
    f_system_conf = '/tmp/system_conf'
    open(f_system_conf, 'w').write(system_conf)
    m_run_command = lambda cmd: (0, system_conf, None)
    m_get_file_content = lambda fn: system_conf
    m_get_bin_path = lambda bin, opt_dirs=[] : '/usr/sbin/' + bin
    hardware_obj = SunOSHardware(dict())
    hardware_obj.run_command = m_run_command
    hardware_obj.get_file_content = m_get_file_content
    hardware_obj.get_bin_path = m_get_bin_

# Generated at 2022-06-20 17:44:49.360081
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Constructor of SunOSHardwareCollector class.
    """

    # Test with platform unset
    collected_facts = dict()
    hardware_collector = SunOSHardwareCollector(collected_facts, None)
    assert hardware_collector.platform == 'SunOS'
    assert not hardware_collector.ignore_collect

    # Test with platform set to SunOS
    collected_facts = dict(platform='SunOS')
    hardware_collector = SunOSHardwareCollector(collected_facts, None)
    assert hardware_collector.platform == 'SunOS'
    assert not hardware_collector.ignore_collect

    # Test with platform set to Linux
    collected_facts = dict(platform='Linux')
    hardware_collector = SunOSHardwareCollector(collected_facts, None)

# Generated at 2022-06-20 17:45:01.480686
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_instance = SunOSHardware()


# Generated at 2022-06-20 17:45:07.950319
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts_out = """
module: Sun Microsystems, UltraSPARC-IIe @ 312MHz
clock_MHz: 312
cpu_type: sparcv9
chip_id: 0
implementation: SPARC Version 9
status: on-line
"""
    module = FakeModule({'run_command': lambda x, **kw: (0, cpu_facts_out, '')})
    hardware = SunOSHardware(module)
    collected_facts = hardware.populate()
    assert collected_facts['processor'][0] == 'SPARC Version 9 @ 312MHz'


# Generated at 2022-06-20 17:45:09.675347
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'


# Generated at 2022-06-20 17:46:44.500261
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    hw = SunOSHardware(module)
    prtconf = """
     System Configuration: sun4u
     Memory size: 8040 Megabytes
    """

    module.run_command.return_value = (0, prtconf, '')
    assert hw.get_memory_facts() == {'memtotal_mb': 8040}


# Generated at 2022-06-20 17:46:50.994919
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeAnsibleModule()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time 1548249689', None)
    module.run_command_environ_update = None

    k = SunOSHardware(module)
    uptime_facts = k.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1548249689

# Test class implementation to avoid mocking all the methods

# Generated at 2022-06-20 17:47:01.876040
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts = SunOSHardware().get_device_facts()
    assert isinstance(device_facts, dict)
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    for key, value in device_facts['devices'].items():
        assert isinstance(value, dict)
        assert 'serial' in value
        assert 'product' in value
        assert 'hard_errors' in value
        assert 'soft_errors' in value
        assert 'transport_errors' in value
        assert 'media_errors' in value
        assert 'predictive_failure_analysis' in value
        assert 'illegal_request' in value
        assert 'size' in value

# Generated at 2022-06-20 17:47:12.684606
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    prtconf_output = """Memory size: 8192 Megabytes
"""
    swap_output = """total: 1628436k bytes allocated + 356828k reserved = 1985260k used, 5229528k available
"""

    swap_reserved_k = 356828
    swap_allocated_k = 1628436
    swap_mb = 5229528 // 1024
    swap_free_mb = swap_mb - swap_reserved_k // 1024
    ram_mb = 8192

    ret = hardware.get_memory_facts()
    assert ret['swap_allocated_mb'] == swap_allocated_k // 1024
    assert ret['swap_reserved_mb'] == swap_reserved_k // 1024

# Generated at 2022-06-20 17:47:13.982236
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware()
    assert hardware.run()
    assert hardware.run()

# Generated at 2022-06-20 17:47:21.206036
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule:
        def run_command(self, command):
            return 0, str(int(time.time())), ""
    facts = {'platform': 'Solaris'}
    class_inst = SunOSHardware(FakeModule, facts)
    uptime_facts = class_inst.get_uptime_facts()
    uptime_seconds = uptime_facts.get('uptime_seconds')
    assert uptime_seconds == int(time.time())



# Generated at 2022-06-20 17:47:28.046718
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    test_object = SunOSHardware(module)

    assert test_object.get_memory_facts()['memtotal_mb'] > 0


if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    facts = SunOSHardwareCollector().collect()
    print(facts)
    module = AnsibleModule(argument_spec={})
    test_object = SunOSHardware(module)
    print(test_object.get_mount_facts())

# Generated at 2022-06-20 17:47:40.766075
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.sunos import SunOSHardwareCollector

    module = AnsibleModule(argument_spec={})

    fact_collector = FactCollector(module=module, collector=SunOSHardwareCollector)
    facts = fact_collector.collect(required_facts=['hardware'])

    hardware_facts = SunOSHardware(module=module)
    result = hardware_facts.populate()

    # Test if hardware_facts.populate() returns a dict.
    assert isinstance(result, dict)

    # Test if returned dict of facts is equal to the module return dict facts.

# Generated at 2022-06-20 17:47:45.673095
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_SunOSHardware = SunOSHardware()
    collected_facts = {'ansible_machine': 'i86pc', 'ansible_all_ipv4_addresses': ['192.168.0.10']}
    test_SunOSHardware.populate(collected_facts)

# Generated at 2022-06-20 17:47:47.949062
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, 'Mem 0x1', ''))
    sunos = SunOSHardware(module)
    facts = sunos.get_memory_facts()
    assert facts['memtotal_mb'] == 0x1