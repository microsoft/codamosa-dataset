

# Generated at 2022-06-20 17:38:44.967911
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Test get_device_facts method of SunOSHardware"""
    module = type('AnsibleModule', (object,), dict(
        run_command=lambda x: (0, '', ''),
        get_bin_path=lambda x, opt_dirs: ''))

    facts = SunOSHardware(module)
    disk_facts = facts.get_device_facts()

    # Check that the correct number of disks were found
    assert 'devices' in disk_facts
    assert len(disk_facts['devices']) == 1

    # Check for the existence of the necessary disk keys
    assert 'product' in disk_facts['devices']['sd0']
    assert 'revision' in disk_facts['devices']['sd0']
    assert 'serial' in disk_facts['devices']['sd0']

# Generated at 2022-06-20 17:38:56.289578
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    data = b'unix:0:system_misc:boot_time\t1540975423'
    # Create a dummy Module
    class MockModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = data
            self.run_command_stderr = ''

        def run_command(self, args, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, raise_err=True, environ_update=None, umask=None, encoding=None, errors='strict', text=True):
            self.run_command_called = True
            self.run_command_args = args
           

# Generated at 2022-06-20 17:38:59.611700
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hw = SunOSHardware()
    assert hw.platform == "SunOS"


# Generated at 2022-06-20 17:39:01.263539
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunoshardware = SunOSHardware()



# Generated at 2022-06-20 17:39:09.081373
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    This testcase tests get_dmi_facts method of SunOSHardware class.
    """
    class TestHardware(SunOSHardware):
        def __init__(self, *args, **kwargs):
            # We can't auto detect this, so we need to set it
            self.facts['platform'] = self.platform
            super(TestHardware, self).__init__(*args, **kwargs)

    test_class = TestHardware(dict())


# Generated at 2022-06-20 17:39:15.287812
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert(hardware_obj.facts['processor'])
    assert(hardware_obj.facts['memtotal_mb'])
    assert(hardware_obj.facts['swapfree_mb'])
    assert(hardware_obj.facts['swaptotal_mb'])
    assert(hardware_obj.facts['swap_allocated_mb'])
    assert(hardware_obj.facts['swap_reserved_mb'])
    assert(hardware_obj.facts['system_vendor'])
    assert(hardware_obj.facts['product_name'])
    assert(hardware_obj.facts['devices'])

# Generated at 2022-06-20 17:39:28.001324
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # Test for case: prtconf returns Memory size
    # Return type will be dict
    testobj = SunOSHardware()
    testobj.module.run_command = lambda x: (0, 'Memory size     = 4096 Megabytes', None)
    rc = testobj.get_memory_facts()
    assert rc == {'memtotal_mb': 4096,
                  'swapfree_mb': 0,
                  'swaptotal_mb': 0,
                  'swap_allocated_mb': 0,
                  'swap_reserved_mb': 0}

    # Test for case: prtconf returns Failure
    # Return type will be None
    testobj = SunOSHardware()
    testobj.module.run_command = lambda x: (1, 'Failure', None)
    rc = testobj.get_memory_facts()

# Generated at 2022-06-20 17:39:38.773763
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Attempt to load the appropriate module
    try:
        module = get_module(PDI)
    except AttributeError:
        try:
            # The command may not be in the PATH
            module = get_module('/usr/local/bin/ansible')
        except AttributeError:
            return False

    # Attempt to instantiate a module
    module = AnsibleModule(argument_spec={})
    module.params = {'paths': ['/usr/sbin', '/usr/bin'], 'gather_subset': ['all']}

    # Create a Hardware subclass
    hardware = SunOSHardware()

    # Skip if this is not the correct platform
    if hardware.platform not in module.params['gather_subset']:
        module.exit_json(changed=False, ansible_facts=dict())


# Generated at 2022-06-20 17:39:40.961645
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware

# Generated at 2022-06-20 17:39:48.585045
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('Module', (object,), {'run_command': None})()
    module.run_command = lambda a: (0, '', '')
    obj = SunOSHardware(module)

    # object should be instance of dict
    assert isinstance(obj.get_device_facts(), dict)
    assert len(obj.get_device_facts()) == 1
    assert obj.get_device_facts().get('devices')

# Generated at 2022-06-20 17:40:18.627412
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Open an empty file for testing kstat command output
    tmpfile = open('testfile', 'w')
    tmpfile.close()

    module = FakeModule(tmpfile.name)

    hardware = SunOSHardware(module)

    # No output from 'kstat' command
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts == {}

    # Write one line of output to the file
    tmpfile = open('testfile', 'w')
    tmpfile.write('unix:0:system_misc:boot_time 1548249689\n')
    tmpfile.close()

    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

    # Cleanup testfile
    os

# Generated at 2022-06-20 17:40:30.988941
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()

    collect_cmds = [
        "/usr/bin/kstat cpu_info",
        "/usr/sbin/swap -s",
        "/usr/sbin/prtconf",
        "/usr/bin/uname -i",
        "/usr/platform/SUNW,Sun-Fire-880/sbin/prtdiag",
        "/usr/bin/kstat -p",
        "/usr/bin/kstat -p unix:0:system_misc:boot_time"
    ]


# Generated at 2022-06-20 17:40:35.481133
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = FakeAnsibleModule()
    module.params = {'ansible_facts': {'platform': 'SunOS'}}

    hardware = SunOSHardware(module)
    assert hardware.platform == 'SunOS'



# Generated at 2022-06-20 17:40:38.696410
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Test object creation
    obj = SunOSHardware(None)

    # Test get_uptime_facts
    obj.get_uptime_facts()


# Generated at 2022-06-20 17:40:45.472818
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware.platform == 'SunOS'
    assert hardware.cpu_facts == {}
    assert hardware.device_facts == {}
    assert hardware.dmi_facts == {}
    assert hardware.memory_facts == {}
    assert hardware.mount_facts == {}
    assert hardware.uptime_facts == {}
    assert hardware.all_facts == {}

# Generated at 2022-06-20 17:40:58.038695
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = fake_ansible_module()
    hw = SunOSHardware(module)
    facts = hw.populate()
    assert facts['processor'] == ['SPARC T4 (chipid 0, clock 2560 MHz) @ 2560MHz', 'SPARC T4 (chipid 1, clock 2560 MHz) @ 2560MHz']
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 2

# Generated at 2022-06-20 17:41:08.416810
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFileEntropyCollector

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Mock hardware Facts
    hardware_facts = SunOSHardware
    hardware_facts.module = module

    # Mock system uptime
    boot_time_string = to_bytes("unix:0:system_misc:boot_time    1548249689")

# Generated at 2022-06-20 17:41:15.924709
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    system_vendor, product_name = SunOSHardware.get_dmi_facts()['system_vendor'], SunOSHardware.get_dmi_facts()['product_name']
    assert system_vendor == 'Oracle Corporation'
#    assert product_name == 'SUNW,SPARC-Enterprise'
    assert product_name == 'SUNW,SPARC-Enterprise-T5220'

# Generated at 2022-06-20 17:41:25.157724
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert hardware_obj.facts['devices']['sd0']['revision'] == '1.0'
    assert hardware_obj.facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert hardware_obj.facts['devices']['sd0']['size'] == '50.00 GB'
    assert hardware_obj.facts['devices']['sd0']['vendor'] == 'ATA'

# Generated at 2022-06-20 17:41:30.638778
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    si = SunOSHardware(dict())
    expected_memory_facts = {
                            'memtotal_mb': 4096,
                            'swap_reserved_mb': 1073741824,
                            'swaptotal_mb': 447185920,
                            'swap_allocated_mb': 2147483648,
                            'swapfree_mb': 2147483648
                           }
    si_output = si.get_memory_facts()
    assert si_output == expected_memory_facts


# Generated at 2022-06-20 17:42:15.139034
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:42:28.601599
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import get_collector_for_platform
    from ansible.module_utils.facts.collector import CollectorFailure
    from ansible.module_utils.facts.utils import get_file_content, get_file_lines

    # Create a mock class for AnsibleModule
    class AnsibleModuleMock():
        called_run_command = None

        def run_command(self, cmd):
            self.called_run_command = cmd
            return (0, "unix:0:system_misc:boot_time    1548249689", "")

    # Create SunOSHardware object
    ansible_module = AnsibleModuleMock()
    hardware = SunOSHardware(ansible_module)

    # Call get_uptime_facts()
    uptime_facts = hardware.get_upt

# Generated at 2022-06-20 17:42:36.645280
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    with mock.patch('ansible.module_utils.common.text.formatters.bytes_to_human', new=mock.Mock()):
        with mock.patch('ansible.module_utils.common.text.formatters.get_file_content') as mock_get_file_content:
            with mock.patch('ansible.module_utils.common.text.formatters.get_mount_size') as mock_get_mount_size:
                mock_get_file_content.return_value = 'substituted_content'

# Generated at 2022-06-20 17:42:49.037903
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ClassUnderTest:
        def __init__(self, module):
            self.module = module

        @timeout.timeout()
        def get_dmi_facts(self):
            return get_dmi_facts(self)

    class TestModule:
        def __init__(self):
            self.run_command_stderr = False

        def run_command(self, string):
            prtdiag_output = (
                """Syste(snip)""",
                 "",
                 None)
            if 'uname -i' in string:
                return 0, "i86pc", None
            elif prtdiag_path in string:
                return prtdiag_output

    prtdiag_path = '/usr/sbin/prtdiag'
    test_module = TestModule()
   

# Generated at 2022-06-20 17:42:52.291212
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module_mock = ModuleMock({'command': "", 'run_command': run_command_mock})
    hw = SunOSHardware(module_mock)
    assert hw.platform == 'SunOS', "The OS platform is not set correctly"
    assert hw.module == module_mock, "The module is not set correctly"


# Generated at 2022-06-20 17:43:00.410928
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-20 17:43:01.050861
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    return True

# Generated at 2022-06-20 17:43:12.832770
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleStub()
    method = SunOSHardware(module)
    # Input data is the output from prtdiag from an Oracle Virtual Box
    # running Solaris 11.4
    input_data = '''System Configuration: VMware, Inc. VMware Virtual Platform   
   System Configuration: Oracle Corporation VirtualBox
   System Configuration: Sun Microsystems sun4v
   System Configuration: Sun Microsystems sun4u
   System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)
   System Configuration: Fujitsu FUJITSU PRIMERGY BX620 S2
'''
    expected_result = {'system_vendor': 'Oracle Corporation',
                       'product_name': 'VirtualBox'}
    # Create monkey patch for method _get_bin_path.  _get_bin_path should be defined in


# Generated at 2022-06-20 17:43:25.417349
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = lambda *cmd: (0, "", "")

    hardware.module.get_bin_path = lambda cmd: "/usr/sbin/prtdiag"

    # Bad rc from command run
    hardware.module.run_command = lambda *cmd: (13, "", "")

    dmi_facts = hardware.get_dmi_facts()
    assert(dmi_facts == {})

    # Bad output from command run
    hardware.module.run_command = lambda *cmd: (0, "", "")

    dmi_facts = hardware.get_dmi_facts()
    assert(dmi_facts == {})

    # Good output from command run, but with wrong vendor

# Generated at 2022-06-20 17:43:31.340858
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = run_command
    sunos = SunOSHardware(module)
    actual = sunos.get_cpu_facts()
    expected = {
        'processor': ['Genuine Intel(R) CPU 0000 @ 2.00GHz @ 2000MHz'],
        'processor_cores': 1,
        'processor_count': 1
    }
    assert actual == expected



# Generated at 2022-06-20 17:44:21.665057
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = 'test_path'

    sh = SunOSHardware(module)
    facts = sh.populate()

# Generated at 2022-06-20 17:44:23.575957
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = SunOSHardware(dict())
    assert isinstance(module, SunOSHardware)

# Generated at 2022-06-20 17:44:31.996393
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.params = {}

    if not HAS_KSTAT:
        module.fail_json(msg="kstat not installed")

    if module.params['platform'] == 'SunOS':
        Hardware = SunOSHardware(module)
        facts = Hardware.populate()
        module.exit_json(ansible_facts=facts)
    else:
        module.exit_json(changed=False)


# Generated at 2022-06-20 17:44:43.184475
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:44:49.472375
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    m = SunOSHardware()
    # Set module.run_command to return a specific set of values
    m.run_command = lambda x: (0, "unix:0:system_misc:boot_time 1548249689", "")
    uptime_facts = m.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-20 17:44:54.475200
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    cachedir = ''
    ansible_module = {}
    collector = SunOSHardwareCollector(ansible_module, cachedir)
    hardware = collector.collect()[0]
    assert hardware.module == ansible_module
    assert hardware.file == __file__



# Generated at 2022-06-20 17:45:04.975975
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = DummyModule()

    cmd = ['kstat', '-p']
    for ds in SunOSHardware.get_device_facts.__func__.__globals__.get('disk_stats'):
        cmd.append('sderr:::%s' % ds)


# Generated at 2022-06-20 17:45:09.109933
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = lambda *args, **kwargs: (0, "Memory size: 8192 Megabytes", None)

    assert hardware.get_memory_facts()["memtotal_mb"] == 8192

    hardware.module.run_command = lambda *args, **kwargs: (0, "Memory size: 8192 Megabytes\nfoo", None)

    assert hardware.get_memory_facts()["memtotal_mb"] == 8192

    hardware.module.run_command = lambda *args, **kwargs: (0, "foo", None)

    assert hardware.get_memory_facts()["memtotal_mb"] == 0



# Generated at 2022-06-20 17:45:20.252762
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command

    h = SunOSHardware(module)
    all_devices = h.get_device_facts()
    first_disk = all_devices['devices']['sd0']

    # Unit testing of 'get_device_facts'
    assert first_disk['hard_errors'] == '1'
    assert first_disk['product'] == 'SUN1.0G'
    assert first_disk['revision'] == '4102'
    assert first_disk['serial'] == '3f0c2b2a'
    assert first_disk['size'] == '1024kB'
    assert first_disk['soft_errors'] == '1'
    assert first_disk['transport_errors'] == '0'
    assert first_disk['vendor']

# Generated at 2022-06-20 17:45:21.488753
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    up = SunOSHardware()
    assert up.platform == 'SunOS'

# Generated at 2022-06-20 17:46:49.420736
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(argument_spec={})
    result = SunOSHardware(module)
    assert result.platform == 'SunOS'

# Generated at 2022-06-20 17:46:54.501164
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.populate()

    assert 'memtotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts

# Generated at 2022-06-20 17:47:04.640330
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    module = "unit_test"

    class SunOSHardware():
        module = module

        @timeout.timeout()
        def get_mount_facts(self):
            return {'mounts': [{'mount': '/', 'size_total': 1234}]}

        def run_command(self, cmd):
            if cmd == "/usr/sbin/swap -s":
                return (0, "total: 6501024k bytes allocated + 2973720k reserved = 9474744k used, 3245112k available", "")
            elif cmd == ("/usr/bin/kstat cpu_info"):
                return (0, "", "")
            elif cmd == "/usr/sbin/prtconf":
                return (0, "Memory size: 8192 Megabytes", "")

# Generated at 2022-06-20 17:47:08.350066
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:47:16.913998
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()

    # case 1: CPU with clock speed
    module.run_command.return_value = (0, CPU_ONE_CORE_WITH_SPEED, '')
    SunOS = SunOSHardware(module)
    result = SunOS.get_cpu_facts()

    assert result['processor'] == ['SPARC64-IV @ 2700MHz']
    assert result['processor_count'] == 1
    assert result['processor_cores'] == 1

    # case 2: CPU without clock speed
    module.run_command.return_value = (0, CPU_TWO_CORE_WITHOUT_SPEED, '')
    SunOS = SunOSHardware(module)
    result = SunOS.get_cpu_facts()


# Generated at 2022-06-20 17:47:26.616938
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    h = SunOSHardware()

    class ModuleMock(object):

        def run_command(self, cmd):
            if cmd == "/usr/bin/kstat -p unix:0:system_misc:boot_time":
                return (0, "unix:0:system_misc:boot_time    1548249689", None)
            return (1, "", "")

        def get_bin_path(self, bp, opt_dirs=[]):
            return bp

    h.module = ModuleMock()
    uptime_facts = h.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-20 17:47:33.701867
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    platform = 'SunOS'
    module = MockModule()
    module.run_command = Mock(return_value=(0, 'Sun Microsystems  sun4u', ''))

    sunos_hw = SunOSHardware(module)
    dmi_facts = sunos_hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'



# Generated at 2022-06-20 17:47:36.375828
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    host = SunOSHardwareCollector()
    assert host.platform == 'SunOS'
    assert host.fact_class is SunOSHardware


# Generated at 2022-06-20 17:47:40.200020
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware(None).get_cpu_facts()

    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-20 17:47:44.140053
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    """Check if the SunOSHardware constructor matches the correct platform."""

    # Create a test object
    sunos_tests = SunOSHardware()

    # Check that the platform is correct
    assert (sunos_tests.platform == 'SunOS')