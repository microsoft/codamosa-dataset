

# Generated at 2022-06-20 17:38:49.077496
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    facts = SunOSHardware({})

    # Test with physical CPUs and CPUs with cores

# Generated at 2022-06-20 17:38:53.083719
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    facts_collector = SunOSHardwareCollector(None, {})
    assert isinstance(facts_collector._fact_class, SunOSHardware), \
        "The SunOSHardwareCollector fact class should be SunOSHardware"

# Generated at 2022-06-20 17:38:54.979743
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware.platform == 'SunOS'

# Generated at 2022-06-20 17:39:01.161642
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModuleMock()
    hardware_collector = SunOSHardwareCollector(module=module)
    assert(hardware_collector.platform == 'SunOS')
    assert(hardware_collector.fact_class == SunOSHardware)
    assert(hardware_collector.required_facts == set(['platform']))


# Generated at 2022-06-20 17:39:09.363073
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sunoshardware = SunOSHardware(module)

    # FIXME: mock system & kstat output
    if not sunoshardware.get_cpu_facts():
        assert False
    if not sunoshardware.get_memory_facts():
        assert False
    if not sunoshardware.get_dmi_facts():
        assert False
    if not sunoshardware.get_device_facts():
        assert False
    if not sunoshardware.get_uptime_facts():
        assert False



# Generated at 2022-06-20 17:39:15.481898
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # initialize a module object for unit test
    class Module(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def run_command(self, *args, **kwargs):
            self.run_command_args = args
            self.run_command_kwargs = kwargs

            # for unit test we return sample outputs for commands
            if args[0] == "/usr/bin/kstat cpu_info":
                return 0, cpu_info, ""
            if args[0] == "/usr/sbin/swap -s":
                return 0, swap_s, ""
            if args[0] == "/usr/bin/kstat -p unix:0:system_misc:boot_time":
                return 0, boot_time,

# Generated at 2022-06-20 17:39:21.177788
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    h = SunOSHardwareCollector(module).collect()[0]
    uptime = h.get_uptime_facts()

    assert uptime['uptime_seconds'] > 0



# Generated at 2022-06-20 17:39:26.218874
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils._text import to_bytes
    from io import StringIO

    cpu_output = get_file_content('./unit/modules/ansible/module_utils/facts/hardware/sunos/cpu_output')
    out = to_bytes(cpu_output)

    cpu_facts = SunOSHardware.get_cpu_facts(None, out)

    assert cpu_facts['processor'] == ['SPARCv9 (chipid 0, clock 2520 MHz)']
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 24


# Generated at 2022-06-20 17:39:36.658219
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    This is a unit test for method get_uptime_facts of class SunOSHardware.
    If the method works as expected, then the test should pass.
    """
    from ansible.module_utils.facts.collector.test_utils import MockModule

    mock_module = MockModule()
    mock_module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', None)

    test_obj = SunOSHardware()
    test_obj.module = mock_module

    uptime_facts = test_obj.get_uptime_facts()
    expected_uptime_facts = {'uptime_seconds': 116567}

    assert uptime_facts == expected_uptime_facts

# Generated at 2022-06-20 17:39:38.435846
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    # class object is created
    obj = SunOSHardware()
    assert obj.platform == 'SunOS'

# Generated at 2022-06-20 17:40:02.728474
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out = '''
System Configuration: VMware, Inc. VMware Virtual Platform
Memory size: 4096 Megabytes
System Peripherals (Software Nodes):
Name: /pci@0,0
Status: okay
Installed: No
Physical: No
Model: pcib
Bus: pci
Child Type: pciex

Name: /pciex@0,0
Status: okay
Installed: No
Physical: No
Model: pciex
Bus: pci
Name: /pciex@0,1
Status: okay
Installed: No
Physical: No
Model: pciex
Bus: pci
'''
    out = out.strip()
    module = AnsibleModuleMock({})
    hardware = SunOSHardwareCollector.fetch_fact('SunOSHardware', module)
    memory_facts = hardware.get_memory_facts()


# Generated at 2022-06-20 17:40:13.812357
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    def mock_run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, 'output', ''

    SunOSHardwareCollector._run_command = mock_run_command

    # Test behaviour if platform not set
    class module(object):
        def __init__(self, params):
            self.params = params
            self.fail_json = self.exit_json = lambda x, **kwargs: None
    params = {'gather_subset': "all"}
    collector = SunOSHardwareCollector(module(params))
    assert not collector.facts

    # Test behaviour if platform is Solaris but platform_subset is set to a subset that does not include 'all'

# Generated at 2022-06-20 17:40:26.375957
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    raw_prtconf_output = """
Memory size: 64 Megabytes
System Peripherals (Software Nodes):
"""
    expected_get_memory_facts_result = '64'
    expected_swap_allocate_mb = '0'
    expected_swap_reserved_mb = '0'

    module = MockModule()
    module.run_command = Mock(return_value=(0,raw_prtconf_output,None))

    sunos_hardware_object = SunOSHardware(module)
    result = sunos_hardware_object.get_memory_facts()
    assert result['memtotal_mb'] == int(expected_get_memory_facts_result)
    assert result['swap_allocated_mb'] == int(expected_swap_allocate_mb)

# Generated at 2022-06-20 17:40:33.204203
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModuleMock({'ansible_facts': {'ansible_machine': 'i86pc', 'ansible_system_vendor': 'Oracle Corporation', 'ansible_product_name': 'VirtualBox'}})
    sunos_h = SunOSHardware(module)
    assert sunos_h.module == module
    assert sunos_h.platform == 'SunOS'

# Test for run_command()

# Generated at 2022-06-20 17:40:37.667579
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    test_SunOSHardware_get_uptime_facts
    """
    # FIXME: there is no unit test for these facts
    pass

# Generated at 2022-06-20 17:40:43.984925
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule('SunOS')
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts.get('processor') == ['sparc64 v9 @ 1197MHz']
    assert cpu_facts.get('processor_cores') == 4
    assert cpu_facts.get('processor_count') == 1


# Generated at 2022-06-20 17:40:56.246069
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    hw = SunOSHardware(module)
    assert hw.get_uptime_facts() is None

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 1, None, None

    module.run_command = run_command
    assert hw.get_uptime_facts() is None

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, 'unix:0:system_misc:boot_time    1548249689', None

    module.run_command = run_command

# Generated at 2022-06-20 17:41:03.643170
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware({})
    facts = hardware.populate()
    assert facts['processor'][0] == 'SUNW,UltraSPARC-II'
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1
    assert facts['memtotal_mb'] == 2048
    assert facts['swap_allocated_mb'] == 2047
    assert facts['swap_reserved_mb'] == 2047

# Generated at 2022-06-20 17:41:05.774784
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    module = AnsibleModule(
        argument_spec = dict(),
    )
    sunos_obj = SunOSHardware(module)


# Generated at 2022-06-20 17:41:18.679771
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware_obj = SunOSHardware(dict())

    # Test empty dmi_facts
    dmi_facts_result = hardware_obj.get_dmi_facts()
    assert 'system_vendor' not in dmi_facts_result
    assert 'product_name' not in dmi_facts_result

    # Test valid dmi_facts
    hardware_obj.module.run_command = lambda cmd: (0,
'''System Configuration: Oracle Corporation sun4v SPARC T4-1 Server
System clock frequency: 2501 MHz
Memory size: 8192 Megabytes
System uptime: 16 hours 3 minutes 18 seconds
''', '')
    dmi_facts_result = hardware_obj.get_dmi_facts()
    assert dmi_facts_result['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts_result

# Generated at 2022-06-20 17:41:52.600997
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    hardware = SunOSHardware()
    hardware.get_memory_facts()
    module = ModuleFactCollector()
    hardware.module = module
    module.run_command = test_get_memory_facts_run_command
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 10
    assert memory_facts['swapfree_mb'] == 3
    assert memory_facts['swaptotal_mb'] == 5
    assert memory_facts['swap_allocated_mb'] == 4
    assert memory_facts['swap_reserved_mb'] == 5


# Generated at 2022-06-20 17:41:53.767109
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    SunOSHardware()



# Generated at 2022-06-20 17:41:57.930516
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockAnsibleModule()
    SunOSHardware(module).populate()
    # assert that the facts have been set
    assert 'devices' in module.exit_json


# Generated at 2022-06-20 17:42:09.206385
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Unit test for method populate of class SunOSHardware
    """
    from ansible.module_utils.facts.collector.solaris import SunOSHardware
    sunOSHardware = SunOSHardware()

    from ansible.module_utils.facts.collector import BaseFactCollector

    # Set the variables needed for the tests
    # The BaseFactCollector can't get the facts for platform,
    # we will set this manually.
    BaseFactCollector.facts['platform'] = 'SunOS'
    BaseFactCollector.facts['virtualization_type'] = 'zone'

    #================== TEST get_cpu_facts() ====================

    BaseFactCollector.collector['SunOSHardware'] = sunOSHardware

    sunOSHardware.populate()

    # Check if the number of cpu cores is correct
    assert BaseFactCollector.facts

# Generated at 2022-06-20 17:42:16.404457
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():

    # Create test items for get_device_facts
    class DeviceItems:
        def __init__(self, device_name, product, revision, serial, size, vendor,
                     hard_errors, soft_errors, transport_errors, media_errors, predictive_failure_analysis,
                     illegal_request):
            self.device_name = device_name
            self.product = product
            self.revision = revision
            self.serial = serial
            self.size = size
            self.vendor = vendor
            self.hard_errors = hard_errors
            self.soft_errors = soft_errors
            self.transport_errors = transport_errors
            self.media_errors = media_errors
            self.predictive_failure_analysis = predictive_failure_analysis
            self.illegal_request = illegal_request

    # Create test

# Generated at 2022-06-20 17:42:26.817287
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.utils import get_file_content, get_mount_size
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    required_collectors = set(['platform'])
    our_collector = SunOSHardwareCollector()

    assert our_collector.required_facts == required_collectors
    assert our_collector.platform == 'SunOS'
    assert our_collector.fact_class == SunOSHardware



# Generated at 2022-06-20 17:42:33.694016
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware({'module_setup': True})

    prtdiag_content = (
        'System Configuration: VMware,  Inc. VMware Virtual Platform\n'
        'BIOS Configuration: Phoenix Technologies LTD 6.00\n'
        'BIOS Revision: 6.00\n'
    )
    facts = hardware.get_dmi_facts(prtdiag_content=prtdiag_content)
    expected_facts = {
        'system_vendor': 'VMware,  Inc.',
        'product_name': 'VMware Virtual Platform',
    }

    assert facts == expected_facts


# Generated at 2022-06-20 17:42:36.122426
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector(None)

    assert obj is not None
    assert obj.required_facts == set(['platform'])
    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'

# Generated at 2022-06-20 17:42:37.032430
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector(None)

# Generated at 2022-06-20 17:42:49.128397
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils import basic
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts import collector

    m = basic.AnsibleModule(argument_spec={})

    # Mock prtdiag output for the SunOSHardware.get_dmi_facts test.
    # The following example is taken from OpenIndiana Hipster 2019.10
    m.run_command = lambda args: ('', 'System Configuration: VMware, Inc. VMware Virtual Platform\n', '')

    hw = collector.collect(m, 'hardware', SunOSHardware)
    assert type(hw) is dict
    assert hw['system_vendor'] == 'VMware, Inc.'
    assert hw['product_name'] == 'VMware Virtual Platform'


# Generated at 2022-06-20 17:43:47.834877
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    test_hardware_obj = SunOSHardware()

    assert test_hardware_obj.platform == 'SunOS'



# Generated at 2022-06-20 17:44:00.168424
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:44:03.883696
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():

    hardware = SunOSHardware({'platform': 'SunOS'})
    assert hardware.platform == 'SunOS'
    assert hardware.get_cpu_facts() == {}
    assert hardware.get_memory_facts() == {}
    assert hardware.get_dmi_facts() == {}
    assert hardware.get_device_facts() == {}
    assert hardware.get_uptime_facts() == {}

# Generated at 2022-06-20 17:44:13.445466
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-20 17:44:24.460735
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    MockModule = type('MockModule', (object,), {})
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, '', ''))
    mock_module.get_bin_path = Mock(return_value='')

    mock_Hardware = type('MockHardware', (object,), {})
    mock_Hardware.platform = 'SunOS'
    mock_Hardware.populate = SunOSHardware.populate
    mock_Hardware.get_cpu_facts = Mock(return_value={'processor': ['SUNW,UltraSPARC-IIi @ 250MHz']})

# Generated at 2022-06-20 17:44:29.005888
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sunos_hardware = SunOSHardware({'module': object()})
    assert len(sunos_hardware.get_device_facts()['devices']) == 0

# Generated at 2022-06-20 17:44:40.381855
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    empty_platform = SunOSHardware()
    platform = SunOSHardware({"platform": "SunOS"})
    platform.module = MockModule()
    platform.module.run_command.return_value = (1, "System Configuration: Sun Microsystems sun4u", "")
    platform.module.get_bin_path.return_value = "/usr/bin/prtdiag"

    assert empty_platform.get_dmi_facts() == {}
    assert not platform.module.run_command.called
    assert platform.get_dmi_facts() == {"system_vendor": "Sun Microsystems", "product_name": "sun4u"}
    assert platform.module.run_command.call_count == 1
    assert platform.module.get_bin_path.call_count == 1
    assert platform.module.get_bin

# Generated at 2022-06-20 17:44:49.000775
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Test for the get_uptime_facts method of SunOSHardware class.

    Assert the 'uptime_seconds' attribute matches the time elapsed
    since the last boot of the machine, i.e. in the case of SunOS,
    the difference between the current time and the boot time as
    stated by 'kstat -p unix:0:system_misc:boot_time'.

    :return: a tuple (success, msg), where success is a boolean and
             msg is an error message
    :rtype: tuple
    """

    class SunOSHardwareTest(SunOSHardware):
        def __init__(self):
            self.module = None
            self.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C'}

        def run_command(self, cmd):
            return

# Generated at 2022-06-20 17:44:54.012288
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert isinstance(hardware_collector._fact_class, SunOSHardware)
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-20 17:44:58.189146
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert isinstance(obj, SunOSHardwareCollector)
    assert obj.required_facts == set(['platform'])
    assert obj._platform == 'SunOS'
    assert obj._fact_class == SunOSHardware

# Unit tests for methods of SunOSHardware

# Generated at 2022-06-20 17:47:17.762689
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Create an instance of class SunOSHardware
    sunoshardware = SunOSHardware()

    # Set system_vendor, product_name and platform as a single string
    system_vendor_string = 'System Configuration:\tOracle Corporation\tsun4v'

    # Set the return code, out and err as string
    return_code = 0
    out = system_vendor_string
    err = ''

    # Return the return code, out and err as string
    rc, out, err = sunoshardware.run_command(['dummy'])
    rc = return_code
    out = out
    err = err

    # Test if product and system vendor is set
    dmi_facts = sunoshardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-20 17:47:28.467814
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-20 17:47:29.222353
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

# Generated at 2022-06-20 17:47:34.360488
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """This test ensures that the SunOSHardwareCollector can be instantiated."""
    attrs = {}
    attrs['platform'] = 'SunOS'
    obj = SunOSHardwareCollector(attrs=attrs)
    assert obj is not None

# Generated at 2022-06-20 17:47:41.091305
# Unit test for constructor of class SunOSHardware
def test_SunOSHardware():
    sunos = SunOSHardware({'ansible_machine_id': 'f6aff8f6-c13f-4e6b-9a71-8b64f865c79b'})

    assert sunos.data['ansible_machine_id'] == 'f6aff8f6-c13f-4e6b-9a71-8b64f865c79b'


# Generated at 2022-06-20 17:47:54.116939
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils import basic

    module_args = dict(
        gather_subset='all'
    )

    class FakeModule(object):

        def __init__(self, *args, **kwargs):
            self.params = module_args

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            return 0, "output", ""

        def get_bin_path(self, *args, **kwargs):
            return "path"

    # Mock AnsibleModule
    fake_module = FakeModule()

    # Create a dictionary containing the output from prtdiag

# Generated at 2022-06-20 17:47:59.204162
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_mock = {
        'run_command.return_value': (0, 'Memory size: 8192 Megabytes', '')
    }
    collected_facts = {'platform': 'SunOS'}

    hardware = SunOSHardware(module=MagicMock(**test_mock), collected_facts=collected_facts)
    hardware.populate()

    assert hardware.facts['memtotal_mb'] == 8192


# Generated at 2022-06-20 17:48:10.157916
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, args, to_native=True):
            return self.rc, self.out, self.err

    # Test get_uptime_facts when kstat command returns rc = 0
    facts = SunOSHardware()

    mock = MockModule(0, 'unix:0:system_misc:boot_time\t1548249689\n', '')
    facts.module = mock

    uptime = facts.get_uptime_facts()

    assert uptime['uptime_seconds'] == int(time.time() - 1548249689)

    # Test get_uptime_facts when kstat command returns rc != 0
    mock

# Generated at 2022-06-20 17:48:14.804713
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule(params={})
    sunos_hw = SunOSHardware(module)
    memory_facts = sunos_hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-20 17:48:20.081880
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_hw = SunOSHardware()

    EXPECTED_SYSTEM_VENDOR = "Oracle Corporation"
    EXPECTED_PRODUCT_NAME = "T5240"

    dmi_facts = sun_hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == EXPECTED_SYSTEM_VENDOR
    assert dmi_facts['product_name'] == EXPECTED_PRODUCT_NAME