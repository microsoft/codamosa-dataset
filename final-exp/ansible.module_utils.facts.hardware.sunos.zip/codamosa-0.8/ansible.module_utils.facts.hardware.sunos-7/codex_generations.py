

# Generated at 2022-06-11 02:54:03.996388
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('', (object,), {'run_command': fake_run_command})
    facts = SunOSHardware()
    facts.populate()

    assert isinstance(facts.memory['SwapFree'], str)
    assert isinstance(facts.memory['SwapTotal'], str)
    assert isinstance(facts.memory['MemTotal'], str)
    assert isinstance(facts.memory['SwapAllocated'], str)
    assert isinstance(facts.memory['SwapReserved'], str)


# Helper function for unit test

# Generated at 2022-06-11 02:54:16.867590
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-11 02:54:24.851107
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    testobj = SunOSHardware()
    testobj.module = FakeModule()

    testout = testobj.get_cpu_facts()

    assert(testout['processor_count'] == 4)
    assert(testout['processor_cores'] == 16)
    assert(testout['processor'] == [
        'SPARC64 X @ 3.3GHz',
        'SPARC64 X @ 3.3GHz',
        'SPARC64 X @ 3.3GHz',
        'SPARC64 X @ 3.3GHz',
    ])



# Generated at 2022-06-11 02:54:28.785070
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create instance of SunOSHardware class
    mem = SunOSHardware()

    # Get memory facts
    mem_facts = mem.get_memory_facts()

    # Assert that memtotal_mb is present in the memory facts
    assert 'memtotal_mb' in mem_facts


# Generated at 2022-06-11 02:54:40.649398
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # test for get_cpu_facts of class SunOSHardware
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # fake test data

# Generated at 2022-06-11 02:54:49.630847
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    data = [
        'System Configuration: Sun Microsystems sun4v',
        'System Configuration: Foo Bar sun4v'
    ]
    expected = [
        {
            'system_vendor': 'Sun Microsystems',
            'product_name': 'sun4v'
        },
        {
            'system_vendor': 'Foo Bar',
            'product_name': 'sun4v'
        }
    ]

    for d, e in zip(data, expected):
        assert SunOSHardware().get_dmi_facts({"uname_output": d}) == e


# Generated at 2022-06-11 02:55:01.319035
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Mock the kstat command
    rc = 0

# Generated at 2022-06-11 02:55:09.496904
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule:
        def run_command(self, command):
            if command == ["/usr/sbin/prtconf"]:
                return (0, 'Memory size: 1024 Megabytes', '')
            elif command == "/usr/sbin/swap -s":
                return (0, 'Total: 160K bytes allocated + 20K reserved = 180K used, 985M available', '')
            return (0, '', '')

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'prtdiag':
                return '/usr/sbin/prtdiag'
            return ''

    module = MockModule()
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    hardware_obj.get_cpu_facts()
    hardware_obj

# Generated at 2022-06-11 02:55:21.014018
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_input = "module:                 cpu_info (id 0)\ncpu_info:0:cpu_info0\ncpu_info:0:SUNW,UltraAX-i2\ncpu_info:0:              chip_id            0\ncpu_info:0:            class              misc\ncpu_info:0:           clock_MHz          800\ncpu_info:0:            cpu_fru            <unknown>\ncpu_info:0:           cpu_type           i86pc\ncpu_info:0:            implementation     Pentium Pro\ncpu_info:0:            instance           0\ncpu_info:0:            manuf              Intel\ncpu_info:0:            model              GenuineIntel\ncpu_info:0:            module             0\ncpu_info:0:            revision           4"
    hw

# Generated at 2022-06-11 02:55:31.576252
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import tempfile
    import os
    import stat

    with tempfile.NamedTemporaryFile() as prtdiag_file:
        script_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            '..',
            '..',
            '..',
            'unit',
            'modules',
            'utils',
            'fakedata',
            'system',
            'sunos',
            'prtdiag.out',
        )
        with open(script_path) as f:
            prtdiag_file.write(f.read().encode())
        prtdiag_file.flush()

        os.chmod(prtdiag_file.name, stat.S_IRUSR)

        hardware = SunOSHardware()

# Generated at 2022-06-11 02:55:55.434777
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sdh = SunOSHardware(module=None)
    f = sdh.get_dmi_facts()
    assert f['system_vendor'].startswith(('Fujitsu', 'Oracle Corporation', 'QEMU', 'Sun Microsystems', 'VMware, Inc.'))
    assert f['product_name'] == 'SUNW,SPARC-Enterprise-T5220' or f['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-11 02:56:03.347472
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Mock kstat result
    s = SunOSHardware()
    def mock_run_command(cmd):
        assert cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time'
        return (0, 'unix:0:system_misc:boot_time    1548249689', '')
    s.module.run_command = mock_run_command
    # Mock current time
    old_time = time.time
    time.time = lambda: 1548250689.0
    # Call method
    uptime_facts = s.get_uptime_facts()
    # Check
    assert uptime_facts == {'uptime_seconds': 1000}
    # Restore time.time
    time.time = old_time

# Generated at 2022-06-11 02:56:11.102314
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    if not HAS_SUNOS_HARDWARE:
        module.fail_json(msg=missing_required_lib('sunos_hardware'))

    inst = SunOSHardware(module)
    result = inst.get_memory_facts()
    assert result['memtotal_mb'] is not None
    assert result['swap_reserved_mb'] is None



# Generated at 2022-06-11 02:56:17.409510
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import ansible.module_utils.facts.hardware.sunos
    fact_class = ansible.module_utils.facts.hardware.sunos.SunOSHardware
    facter = fact_class({})


# Generated at 2022-06-11 02:56:24.990021
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:36.971337
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:47.923891
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:59.463408
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    output = '{0}'.format('Memory size: 4096 Megabytes')
    time_now = time.time()
    swap_out = '{0}'.format('total: 720940k bytes allocated + 95860k reserved = 816800k used, 2299576k available')
    hw = SunOSHardware({})
    hw_facts = hw.populate()
    # Take care of the uptime value; we might be running the unit test a bit longer than one second
    assert hw_facts['uptime_seconds'] - 1 < time_now - hw_facts['ansible_date_time']['epoch'] < hw_facts['uptime_seconds'] + 1
    assert hw_facts['memtotal_mb'] == 4096
    assert hw_facts['swapfree_mb'] == 224.0
   

# Generated at 2022-06-11 02:57:02.105360
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    mock_module = MockAnsibleModule()

    # FIXME
    # Test is incomplete.
    # Test cases should be added in future.


# Generated at 2022-06-11 02:57:09.546012
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import subprocess
    sh = SunOSHardware({})
    # Assert get_uptime_facts when execution of kstat command fails.
    with subprocess.Popen(['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time'], stdout=subprocess.PIPE) as proc:
        out, err = proc.communicate()
    assert sh.get_uptime_facts() == {'uptime_seconds': int(time.time() - float(out.split(b'\t')[1]))}
    assert sh.get_uptime_facts() == {'uptime_seconds': int(time.time() - float(out.split(b'\t')[1]))}

# Generated at 2022-06-11 02:57:29.374044
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    hw = SunOSHardware(module=module)
    out = hw.get_device_facts()
    assert out

# Generated at 2022-06-11 02:57:38.707364
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.facts.utils import get_mount_size


# Generated at 2022-06-11 02:57:48.524304
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import sys
    # create an instance of SunOSHardware class
    sun_hw = SunOSHardware()

    if sys.version_info >= (3, 0):
        # mock run_command method on Python 3
        from unittest.mock import patch
    else:
        # for Python 2 use mock library
        from mock import patch

    with patch.object(sun_hw, 'run_command') as mock_run_command:
        # mock run_command to return output of prtconf
        mock_run_command.return_value = (0, 'Memory size: 16384 Megabytes', '')
        # call get_memory_facts method
        mem_facts = sun_hw.get_memory_facts()
        # verfiy method returns expected value
        assert mem_facts == {'memtotal_mb': 16384}

        # mock

# Generated at 2022-06-11 02:57:59.522325
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    output = '''module: SUNW,Ultra-60
clock_MHz: 800
cpu_type: sparcv9
chip_id: 0
implementation: SPARC-IIIi
brand: SUNW,UltraSPARC-IIIi
pg_flags: 12
pg_id: 0
pg_info: 0
module_id: 0
pg_flags_name: cpu_pgflags_val_name
pg_id_name: cpu_pgid_val_name
pg_info_name: cpu_pginfo_val_name
module_id_name: cpu_moduleid_val_name'''

    cpu_facts = {'processor': []}

    for line in output.splitlines():
        if len(line) < 1:
            continue
        data = line.split(None, 1)
        key = data[0].strip()

# Generated at 2022-06-11 02:58:06.596957
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    s = SunOSHardware(module)
    facts = s.get_memory_facts()
    assert facts['memtotal_mb'] == 48
    assert facts['swapfree_mb'] == 3144
    assert facts['swaptotal_mb'] == 3144
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0


# Generated at 2022-06-11 02:58:17.292875
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fake_module = FakeAnsibleModule()
    SunOS = SunOSHardware(fake_module)

    # Test that s10 and s11 output are parsed correctly.

# Generated at 2022-06-11 02:58:25.646293
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class args:
        module = None
        collected_facts = None
        run_command_environ_update = None
    sun_unix_args = args()
    sun_unix_facts = SunOSHardware()

    sun_unix_facts.populate(sun_unix_args)
    # FIXME
    assert sun_unix_facts.facts['processor']
    assert sun_unix_facts.facts['processor_cores']
    assert sun_unix_facts.facts['processor_count']


# Generated at 2022-06-11 02:58:29.176085
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware as test_class
    test_instance = test_class(None)
    assert test_instance.get_dmi_facts() == {}

# Generated at 2022-06-11 02:58:39.327738
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.run_command_environ_update = {}
    hardware = SunOSHardware(module)
    facts_dict = hardware.populate()

    assert 'memtotal_mb' in facts_dict
    assert 'swapfree_mb' in facts_dict
    assert 'swaptotal_mb' in facts_dict
    assert 'swap_allocated_mb' in facts_dict
    assert 'swap_reserved_mb' in facts_dict
    assert 'devices' in facts_dict
    assert 'processor' in facts_dict
    assert 'system_vendor' in facts_dict
    assert 'product_name' in facts_dict
    assert 'processor_cores' in facts_dict

# Generated at 2022-06-11 02:58:43.617360
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hw_facts = SunOSHardware()
    cpu_facts = hw_facts.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores'] != 'NA'

# Generated at 2022-06-11 02:59:13.669023
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module=module)
    output = hardware.get_device_facts()

    assert output is not None
    assert 'devices' in output
    assert isinstance(output['devices'], dict)
    assert len(output['devices']) > 0

    assert 'sd0' in output['devices']
    assert 'sd1' in output['devices']

    for dev in output['devices']:
        assert output['devices'][dev]['product'] is not None
        assert output['devices'][dev]['revision'] is not None
        assert output['devices'][dev]['serial'] is not None
        assert output['devices'][dev]['size'] is not None
        assert output['devices'][dev]['vendor'] is not None

# Generated at 2022-06-11 02:59:20.627960
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Replace get_file_content with a method that returns the example output
    # of prtconf
    mock_get_file_content = "Memory size: 32768 Megabytes"
    SunOSHardware.get_file_content = lambda _: mock_get_file_content

    def mock_module_run_command(command):
        if command[0] == "/usr/bin/kstat cpu_info":
            return 0, kstat_cpu_info, ""
        if command[0] == "/usr/sbin/swap -s":
            return 0, swap_s, ""
        if command[0] == "w":
            return 0, w, ""

    SunOSHardware.module.run_command = mock_module_run_command

    # Example output for kstat cpu_info,
    # taken from a system with 2 dual core

# Generated at 2022-06-11 02:59:31.960801
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Check SunOSHardware.get_dmi_facts()"""
    import json

    data = {
        'ansible_facts': {
            'ansible_machine': 'i86pc',
        },
    }

    # First test: no prtdiag output
    out = "this is not a prtdiag output"
    module = _mock_ansible_module(data, out)
    obj = SunOSHardware(module)
    facts = obj.get_dmi_facts()
    assert facts == {}

    # Second test: prtdiag output
    #
    # System Configuration: VMware, Inc. VMware Virtual Platform
    # BIOS Configuration: Phoenix Technologies LTD 6.00 06/24/2012
    #

# Generated at 2022-06-11 02:59:37.672564
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    module.run_command.return_value = (0, u'/usr/sbin/prtconf:System Configuration: Sun Microsystems sun4u\nMemory size: 65536 Megabytes\n', None)
    hardware = SunOSHardware(module)
    assert hardware.get_memory_facts() == {'memtotal_mb': 65536}

# Generated at 2022-06-11 02:59:45.977538
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Sample kstat output
    unix:0:system_misc:boot_time    1561436641
    :return:
    """
    from ansible.module_utils._text import to_bytes

    sh = SunOSHardware()
    sh.module = Mock()
    sh.module.run_command = lambda x: (0, to_bytes('unix:0:system_misc:boot_time    1561436641'), '')
    uptime_seconds = sh.get_uptime_facts()
    assert uptime_seconds['uptime_seconds'] > 0


# Generated at 2022-06-11 02:59:58.064596
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.hardware import SunOSHardware

    # Sample output of kstat command
    boot_time = '\nunix:0:system_misc:boot_time    1548249689\n'

    # Mock the method to return fixed value
    def mock_command(command):
        class Args:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err
                self.check_mode = False
        return Args(0, boot_time, '')

    module = type('', (object,), {'run_command': mock_command})()
    sunos_hardware = SunOSHardware(module)
    uptime_facts = sunos_hardware.get_uptime_

# Generated at 2022-06-11 03:00:02.727868
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('', (), {})()
    module.run_command = lambda x: ('', 'module: sun4v\n' +
                                        'implementation: SPARC-T4\n')
    hardware = SunOSHardware(module)
    facts = hardware.get_cpu_facts()
    assert facts['processor'] == ['SPARC-T4']
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 1

# Generated at 2022-06-11 03:00:14.698275
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module=module)

    module.run_command.return_value = (1, "System Configuration: Fujitsu PRIMERGY CX250 S1", None)
    assert hardware.get_dmi_facts() == {'system_vendor': 'Fujitsu', 'product_name': 'PRIMERGY CX250 S1'}

    module.run_command.return_value = (1, "System Configuration: VMware, Inc. VMware Virtual Platform", None)
    assert hardware.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

    module.run_command.return_value = (1, "System Configuration: Oracle Corporation SUN FIRE X4270", None)
    assert hardware.get

# Generated at 2022-06-11 03:00:20.641061
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command

    sunos_hardware = SunOSHardware(module)

    memory_facts = {
        'memtotal_mb': 2047,
        'swapfree_mb': 1024,
        'swaptotal_mb': 2048,
        'swap_allocated_mb': 0,
        'swap_reserved_mb': 2
    }

    assert memory_facts == sunos_hardware.get_memory_facts()


# Generated at 2022-06-11 03:00:24.584089
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_class = SunOSHardware()
    test_class.module = FakeModule()
    test_class.module.run_command = FakeCommandRun()

    results = test_class.get_memory_facts()
    assert results['memtotal_mb'] == 4096



# Generated at 2022-06-11 03:01:07.957159
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('test_module', (object, ), {'run_command': test_run_command})
    hardware_obj = SunOSHardware(module)
    result = hardware_obj.get_cpu_facts()

    assert result['processor_count'] == 1
    assert result['processor_cores'] == 1
    assert result['processor'] == ['SPARC-Enterprise']


# Generated at 2022-06-11 03:01:19.213345
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import BaseFactCollector

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware


    def get_file_content(path):
        return 'mnttab'

    def get_mount_size(path):
        return {'mount': path}

    module = AnsibleModuleMock()
    module.get_bin_path = lambda: '/usr/sbin'
    module.run_command = lambda x: [0, '', '']
    collector.BaseFactCollector.get_file_content = get_file_content
    collector.BaseFactCollector.get_mount_size = get_mount_size
    collector.get_file_content = get_file_content
    collector.get_

# Generated at 2022-06-11 03:01:27.476777
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleStub()

    # C locale for hardware collection helpers to avoid locale specific number formatting
    locale = get_best_parsable_locale(module)
    module.run_command_environ_update = {'LANG': locale, 'LC_ALL': locale, 'LC_NUMERIC': locale}

    sh = SunOSHardware(module=module)

    cpu_facts = sh.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']

    memory_facts = sh.get_memory_facts()
    assert memory_facts['memtotal_mb']

    dmi_facts = sh.get_dmi_facts()
    assert dmi_facts['system_vendor']

# Generated at 2022-06-11 03:01:29.523992
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    coll = SunOSHardwareCollector()
    assert coll.platform == 'SunOS'

# Generated at 2022-06-11 03:01:36.642731
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    sunos_facts = SunOSHardware()
    facts = sunos_facts.populate()

    assert facts['system_vendor'] == 'Oracle Corporation'
    assert facts['product_name'] == 'Oracle VirtualBox'
    assert facts['devices']['sd0']['size'] == '25G'


# Generated at 2022-06-11 03:01:41.634202
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('test_module', (object,), {})()
    module.run_command.return_value = (0, 'System Configuration: Oracle Corporation sun4v', None)

    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v'



# Generated at 2022-06-11 03:01:52.274841
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hw = SunOSHardware(dict(module=None))

    cpu_facts = hw.get_cpu_facts()
    assert cpu_facts['processor'] == ['sun4v SPARC-T4 (chipid 0, clock 1500 MHz)']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4

    memory_facts = hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16383
    assert memory_facts['swap_allocated_mb'] == 0
    assert memory_facts['swap_reserved_mb'] == 0

    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-11 03:02:02.515710
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class FakeModule(object):
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command_calls = []
            self.run_command_return_values = []

        def get_bin_path(self, name, opt_dirs=[]):
            return None

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_return_values.pop(0)

    class FakeCollector(object):
        def __init__(self):
            self.facts = { 'ansible_architecture': 'sun4u', 'ansible_machine': 'sun4v' }

    sunos_hardware = SunOSHardware(FakeModule())
    sunos_hardware.collector = Fake

# Generated at 2022-06-11 03:02:10.577957
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class ModuleStub:
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class TestCase:
        def assertEqual(self, a, b):
            if a != b:
                raise AssertionError('{0} != {1}'.format(a, b))

    testcase = TestCase()
    module_stub = ModuleStub()

    hardware = SunOSHardware(module_stub)
    uptime_facts = hardware.get_uptime_facts()

    testcase.assertEqual(uptime_facts['uptime_seconds'], int(time.time()) - 1548249689)


# Generated at 2022-06-11 03:02:18.176405
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class TestModule(object):
        def get_bin_path(self, arg, opt_dirs=None):
            return arg
        def run_command(self, arg):
            return [0, 'dev_kstat_out', '']
    module = TestModule()
    hardware_facts = SunOSHardware(module)
    hardware_facts.get_device_facts()
    assert module.run_command.called
    assert hardware_facts.devices['sd0']['vendor'] == 'ATA'
    assert hardware_facts.devices['sd0']['product'] == 'VBOX HARDDISK'