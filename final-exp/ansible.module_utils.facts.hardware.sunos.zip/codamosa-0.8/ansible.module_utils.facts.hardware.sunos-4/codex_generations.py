

# Generated at 2022-06-11 02:54:11.542500
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """This is a very basic test for the populate function.

    It doesn't test anything that requires root privileges or
    expensive calls (e.g. prtdiag)
    """

    # Create the module that Ansible thinks it's running in
    module = FakeAnsibleModule()

    # Create a SunOSHardware instance and run the populate method
    s = SunOSHardware(module)
    facts = s.populate()

    # Assert some facts were added
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0
    assert len(facts['processor']) > 0

# Generated at 2022-06-11 02:54:18.891029
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)

    prtconf_facts = dict(
        memtotal_mb=524288,
        swap_allocated_mb=98304,
        swap_reserved_mb=98304,
        swapfree_mb=2688,
        swaptotal_mb=98304,
    )
    assert hw.get_memory_facts() == prtconf_facts



# Generated at 2022-06-11 02:54:23.895156
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "Memory size: 32768 Megabytes", None)

    result = hardware.get_memory_facts()
    assert result['memtotal_mb'] == 32768


# Generated at 2022-06-11 02:54:29.224763
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Input data
    module = None

    # Expected data
    expected_result = {
        'processor': ['SPARC64-VIII @ 2050MHz', 'SPARC64-VIII @ 2050MHz'],
        'processor_count': 2,
        'processor_cores': 16
    }

    # Tested code
    hardware = SunOSHardware(module)
    result = hardware.get_cpu_facts()

    assert expected_result == result



# Generated at 2022-06-11 02:54:40.980377
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:54:45.667086
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOSHardware = SunOSHardware()
    actual = SunOSHardware.get_dmi_facts()
    expected = {
        'system_vendor': 'Fujitsu',
        'product_name': 'SUNW,SPARC-Enterprise'
    }
    assert actual == expected

# Generated at 2022-06-11 02:54:48.468267
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    '''
    Unit test for method get_memory_facts of class SunOSHardware
    '''
    # No unit test for this method...
    pass


# Generated at 2022-06-11 02:54:53.751434
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware_module = SunOSHardware(dict())
    hardware_module.module.run_command = lambda args, **kwargs: (0, '{}\n{}'.format("Memory size: 512 Megabytes", ""), '')
    memory_facts = hardware_module.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 512

# Generated at 2022-06-11 02:54:58.045521
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    hardware_collector = SunOSHardwareCollector(module)
    hardware = SunOSHardware(module)

    hardware_collector.populate()

    hardware.populate()
    assert hardware.platform == 'SunOS'



# Generated at 2022-06-11 02:55:07.819819
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    def run_command_mock(module, command, check_rc=True):
        if command == '/usr/bin/kstat cpu_info':
            out = """module:
            brand
            clock_MHz
            implementation"""
        elif command == "/usr/sbin/swap -s":
            out = """total: 16253240k bytes allocated + 6696180k reserved = 22949420k used, 2839084k available
            """
        elif command == "/usr/sbin/prtconf":
            out = """Memory size: 16384 Megabytes
            """
        else:
            raise Exception("unexpected command: {0}".format(command))

        return 0, out, ''

    class ModuleMock:

        def __init__(self, params):
            pass


# Generated at 2022-06-11 02:55:31.939477
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeModule()
    mem_facts = SunOSHardware(module).get_memory_facts()

    assert mem_facts['memtotal_mb'] == 8941, "Memory facts failed to convert"
    assert mem_facts['swaptotal_mb'] == 131099, "Memory facts failed to convert"
    assert mem_facts['swapfree_mb'] == 130889, "Memory facts failed to convert"
    assert mem_facts['swap_allocated_mb'] == 131099, "Memory facts failed to convert"
    assert mem_facts['swap_reserved_mb'] == 131099, "Memory facts failed to convert"



# Generated at 2022-06-11 02:55:39.456768
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule:
        def run_command(self, args):
            out = 'System Configuration: VMware, Inc. VMware Virtual Platform'
            return (0, out, None)

    class MockFactCollector:
        def __init__(self):
            self.facts = {}

    sunos = SunOSHardware()
    sunos.module = MockModule()
    sunos.collector = MockFactCollector()

    sunos.get_dmi_facts()

    # assert that get_dmi_facts correctly split the first line of prtdiag's output.
    assert sunos.collector.facts['system_vendor'] == 'VMware, Inc.'
    assert sunos.collector.facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-11 02:55:44.066124
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Method get_cpu_facts should return a dictionary with the correct
    number of entries (at least 2) and all keys should be strings.
    """
    hardware = SunOSHardware(dict())
    cpu_facts = hardware.get_cpu_facts()
    assert 2 <= len(cpu_facts)
    for key in cpu_facts:
        assert isinstance(key, str)

# Generated at 2022-06-11 02:55:56.292165
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test for 'SunOSHardware.get_dmi_facts' method
    """

    def test_input(mock_module):
        """
        Mock/Mockup of 'module' as parameter of SunOSHardware.get_dmi_facts
        """
        mock_module.run_command.return_value = (0,
            """System Configuration: Sun Microsystems sun4v
                System clock frequency: 200 MHZ
                Memory size: 4096 Megabytes
                System uptime: 4 days, 9 hours, 30 minutes
                """, None)

        test_fact = SunOSHardware()
        test_fact.populate()

        mock_module.run_command.assert_called_once_with('/usr/sbin/prtconf')

        prtconf_output = test_fact.get_dmi_facts()
       

# Generated at 2022-06-11 02:56:04.252011
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    class CallModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, args, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False,
                        path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None):
            # kstat requires C locale for parsing numbers
            if environ_update and environ_update.get('LC_ALL'):
                return 0, '', ''
            else:
                return 1, '', ''

    # Create instance of class SunOSHardware
    sh = SunOSHardware(CallModule())

    # Collect memory facts
    memory_facts = sh.get_memory_facts()

# Generated at 2022-06-11 02:56:13.472685
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Generate CPU facts by parsing kstat output
    This test case is used to generate cpu facts.
    """

    # Get mock of ansible module
    AnsibleModule = get_AnsibleModule_mock()

    sun_hw = SunOSHardware(AnsibleModule)
    cpu_facts = sun_hw.get_cpu_facts()
    assert cpu_facts["processor_cores"] == 'NA'
    assert cpu_facts["processor_count"] == 2
    assert cpu_facts["processor"] == ['Genuine Intel(R) CPU @ 2.50GHz',
                                      'Genuine Intel(R) CPU @ 2.50GHz']



# Generated at 2022-06-11 02:56:23.036791
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class Module:

        def __init__(self, result):
            self.result = result

        def run_command(self, command):
            return self.result

    # Uptime should be 1234
    module = Module((0, 'unix:0:system_misc:boot_time\t1548249689', None))
    result = SunOSHardware(module).get_uptime_facts()
    assert result['uptime_seconds'] == 1234

    # Uptime denied
    module = Module((0, '', 'Permission Denied'))
    result = SunOSHardware(module).get_uptime_facts()
    assert result == {}

    # Uptime denied
    module = Module((0, '', 'No kstat'))
    result = SunOSHardware(module).get_uptime_facts()

# Generated at 2022-06-11 02:56:33.039714
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module_mock = AnsibleModuleMock()
    module_mock.run_command = MagicMock(return_value=(0, CPU_KSTAT_OUTPUT, ''))
    SunOSHardware.module = module_mock
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert cpu_facts['processor'][0] == 'Intel(r) Xeon(r) CPU E5-2620 v4 @ 2.10GHz'
    assert len(cpu_facts['processor']) == 2
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-11 02:56:44.090512
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test get_cpu_facts from SunOSHardware

    The test is done by having the method load and process the content
    of a file and compare the output with a reference file
    """

    for testfile, ref_file in get_test_files('SunOSHardware_get_cpu_facts', 'data', 'expected'):
        module_mock = FakeModule()
        module_mock.run_command_environ_update = {}
        with open(testfile) as testfile_object:
            module_mock.run_command = MagicMock(return_value=(0, testfile_object.read(), ''))
        sh = SunOSHardware(module_mock)
        result = sh.get_cpu_facts()

# Generated at 2022-06-11 02:56:52.460557
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.run_command_results = kwargs
            self.params = {}

        def fail_json(self, *args, **kwargs):
            return {'failed': True}

        def run_command(self, commands, **kwargs):
            results = self.run_command_results[commands[0]]
            if isinstance(results, Exception):
                raise results
            else:
                return results


# Generated at 2022-06-11 02:57:31.244540
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    prtconf_output = '''
System Configuration:  VMware, Inc. VMware Virtual Platform
Memory size: 2048 Megabytes
'''
    swap_output = '''
total: 524280k bytes allocated + 11112k reserved = 535392k used, 2043744k available
'''

    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, prtconf_output, ''))
    module.run_command = MagicMock(return_value=(0, swap_output, ''))
    sunos_hardware = SunOSHardware(module)
    memory_facts = sunos_hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 2048
    assert memory_facts['swaptotal_mb'] == 1981

# Generated at 2022-06-11 02:57:34.684610
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hc = SunOSHardwareCollector()
    assert hc._fact_class == SunOSHardware
    assert hc._platform == 'SunOS'
    assert hc.required_facts == set(['platform'])


# Generated at 2022-06-11 02:57:43.612455
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)
    expected_output = {'processor': ['SPARC64-X @ 2100MHz', 'SPARC64-X @ 2100MHz'], 'processor_cores': 2,
                       'processor_count': 1}
    actual_output = hardware.get_cpu_facts()
    if not actual_output['processor']:
        raise AssertionError("Actual output is missing key processor")
    else:
        actual_output['processor'] = None

    if not actual_output:
        raise AssertionError("Actual output is missing keys")
    if actual_output != expected_output:
        raise AssertionError("Actual output is different from expected output")



# Generated at 2022-06-11 02:57:46.611273
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    memory_facts = {'memtotal_mb': 44766}

    sunos_hardware = SunOSHardware({})
    assert sunos_hardware.get_memory_facts() == memory_facts


# Generated at 2022-06-11 02:57:48.430255
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    SunOSHardware(module).get_memory_facts()



# Generated at 2022-06-11 02:57:59.377637
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 02:58:09.027439
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule({'platform': 'SunOS'})
    hardware = SunOSHardware(module)

    # simulate the output of kstat command
    out = """
unix:0:system_misc:boot_time    1548249689
"""
    module.run_command.return_value = (0, out, "")

    # check if the expected output is returned
    module.assertEqual(hardware.get_uptime_facts(), {'uptime_seconds': 1228729})
    module.run_command.assert_called_with('/usr/bin/kstat -p unix:0:system_misc:boot_time')



# Generated at 2022-06-11 02:58:16.245550
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Assert that the following test lines match the filter
    test_lines1 = [
        'System Configuration: Sun Microsystems  Sun-Fire-V490',
        'System Configuration:   Sun Microsystems  Sun-Fire-V490',
        'System Configuration: Sun Microsystems sun4u Sun-Fire-V490',
        'System Configuration: Sun QEMU HARDDISK QEMU HARDDISK QEMU HARDDISK   QEMU HARDDISK',
        'System Configuration: Oracle Corporation sun4v SPARC Enterprise T5240',
        'System Configuration: VMware, Inc. VMware Virtual Platform',
    ]


# Generated at 2022-06-11 02:58:23.479290
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    s = SunOSHardware({})
    test1 = s.get_dmi_facts({})
    assert test1.get('system_vendor') == None
    assert test1.get('product_name') == None
    test2 = s.get_dmi_facts({'system_vendor': 'Oracle Corporation', 'product_name': 'Test'})
    assert test2.get('system_vendor') == 'Oracle Corporation'
    assert test2.get('product_name') == 'Test'

# Generated at 2022-06-11 02:58:24.799776
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware = SunOSHardware({})

    # 

# Generated at 2022-06-11 02:59:34.221735
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hw = SunOSHardware(None)
    vendor = hw.get_dmi_facts()['system_vendor']
    assert vendor == 'Oracle Corporation',\
        "SunOSHardware.get_dmi_facts() did not return the correct vendor"
    product = hw.get_dmi_facts()['product_name']
    assert 'SUNW,SPARC-Enterprise-T5120' in product,\
        "SunOSHardware.get_dmi_facts() did not return the correct product_name"


# Generated at 2022-06-11 02:59:40.391103
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_facts = SunOSHardware()
    test_dict = {'system_vendor': 'Sun Microsystems', 'product_name': 'Sun Fire 880'}
    assert test_facts.get_dmi_facts(test_dict) == {'system_vendor': 'Sun Microsystems', 'product_name': 'Sun Fire 880'}

    # test with empty dict
    test_dict = {}
    assert test_facts.get_dmi_facts(test_dict) == {}



# Generated at 2022-06-11 02:59:52.066217
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.facts import FactManager
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    sunos_kstat_output = {
        'output': 'System Configuration: VMware, Inc. VMware Virtual Platform',
        'rc': 0,
        'stderr': b'',
    }

    # New FactManager will create a new instance of SunOSHardware
    sunos_facts = FactManager(SunOSHardware,
                              fact_data={},
                              timeout=10,
                              module=None).get_facts()

    # Mock out module to return pre-defined kstat output
    def mock_run_command(self, args, **kwargs):
        return sunos_kstat_output['rc'],

# Generated at 2022-06-11 03:00:02.171521
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.six.moves import StringIO

    fact_ansible_machine = 'i86pc'
    fact_ansible_processor = ['Intel(r) Core(tm)2 Duo CPU     P8600@ 2.40GHz',
                              'Intel(r) Core(tm)2 Duo CPU     P8600@ 2.40GHz']
    collected_facts = {
        'ansible_machine': fact_ansible_machine,
        'ansible_processor': fact_ansible_processor
    }

    kstat_cmd = StringIO(
        """
        Memory size: 8192 Megabytes
        """
    )


# Generated at 2022-06-11 03:00:06.315377
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {'system_vendor': 'Sun Microsystems',
                 'product_name': 'Sun Fire V210'}
    sunos_hardware_instance = SunOSHardware()
    assert sunos_hardware_instance.get_dmi_facts() == dmi_facts

# Generated at 2022-06-11 03:00:18.134491
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import tempfile
    import shutil
    import os

    # Setup a dummy version of kstat
    temp_path = tempfile.mkdtemp()
    kstat_script_path = os.path.join(temp_path, 'kstat')

    # Create a dummy kstat script which will return some values

# Generated at 2022-06-11 03:00:25.318371
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module=module)
    # Mock run_command
    hw.module.run_command = mock.MagicMock(return_value=(0, 'sample data', ''))
    # Call populate()
    hw.populate()
    # Assert method run_command has been called
    assert hw.module.run_command.called
    # Assert populated data
    assert hw.data.get('memory') is not None
    assert hw.data.get('cpu') is not None


# Generated at 2022-06-11 03:00:27.223268
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MockModule()
    SunOSHardware(module).get_cpu_facts()



# Generated at 2022-06-11 03:00:39.050788
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    collected_facts = dict(ansible_facts=dict(hardware=dict()))
    collected_facts["ansible_facts"]["hardware"] = dict(swap_allocated_mb=4, swap_reserved_mb=4, memtotal_mb=9, swapsize_mb=4, swapfree_mb=8, processor=['Sun Microsystems, UltraSPARC-IIi Processor @ 167MHz'], processor_count=1, processor_cores='NA')
    collected_facts["ansible_facts"]["hardware"]['system_vendor'] = "Sun Microsystems, Inc."
    collected_facts["ansible_facts"]["hardware"]['product_name'] = "Sun Fire V120"
    collected_facts["ansible_facts"]["hardware"]['devices'] = dict()

    m

# Generated at 2022-06-11 03:00:46.758781
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime

    test_module = type(str('test_module'), (object,), dict(TIMEOUT=1))

    class test_SunOSHardware(SunOSHardware):

        def __init__(self, module):
            self.module = module

        def run_command(self, command):
            return 0, str(int(datetime.datetime.now().timestamp())), ''

    hardware = test_SunOSHardware(test_module)

    uptime_facts = hardware.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts

    # If uptime_seconds is greater than zero and less than one, then it is
    # probably correct.
    assert uptime_facts['uptime_seconds'] > 0
    assert uptime_facts['uptime_seconds'] <= 1

# Generated at 2022-06-11 03:03:06.057360
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = ['', 'cpu_info kstat cpu_info']
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    result = SunOSHardware(module).populate()
    assert('processor' in result)


# Generated at 2022-06-11 03:03:13.723698
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts import timeout


# Generated at 2022-06-11 03:03:19.540953
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.hardware.sunos import SunOSHardware
    sut = SunOSHardware({})
    # test valid output
    prtconf_out = 'Memory size:          8192 Megabytes'
    swap_out = 'Total: 2669316k bytes allocated + 14016k reserved = 2675332k used, 9173900k available'
    # mock module.run_command

# Generated at 2022-06-11 03:03:27.235607
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """ Test function for SunOS Hardware class using mocked data from
        prtdiag output.
    """
    mocked_lines = [
        'System Configuration: VMware, Inc. VMware Virtual Platform\n',
        '\n',
        'System clock frequency: 333 MHz\n',
        'Memory size: 16384 Megabytes\n',
        'System revision: VMware VMware Virtual Platform\n',
        'pci bus frequency: 33 MHz\n',
        '\n',
        'System Peripherals (Software Nodes):\n',
        '\n',
        'sbbc, instance #0: SUNW,sbbc\n',
        '\n'
    ]
    sun_hw = SunOSHardware()
    sun_hw.module = DummyModule()

# Generated at 2022-06-11 03:03:36.742544
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    t = SunOSHardware()


# Generated at 2022-06-11 03:03:45.654272
# Unit test for method get_device_facts of class SunOSHardware