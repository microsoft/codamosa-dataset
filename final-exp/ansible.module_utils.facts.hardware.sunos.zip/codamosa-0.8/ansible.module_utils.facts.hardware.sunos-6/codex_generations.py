

# Generated at 2022-06-11 02:54:09.375701
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    module.get_bin_path = get_bin_path_mock
    module.run_command_environ_update = {}
    SunOSHardware.module = module
    fact = SunOSHardware()

    fact_uptime_facts = fact.get_uptime_facts()

    assert fact_uptime_facts
    assert fact_uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-11 02:54:22.235976
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # test data
    # system_conf_regexp is also tested in test_SunOSHardware_get_dmi_facts
    test_data = {
        'input': {
            'system_conf_regexp': '(?P<vendor>\D+)\s+(?P<system>\D+)',
            'system_conf_line': 'System Configuration: Sun Microsystems sun4v',
        },
        'expected': {
            'dmi_facts': {
                'system_vendor': 'Sun Microsystems',
                'product_name': 'sun4v',
            },
        },
    }

    # create class
    obj = SunOSHardware()

    # create mock to be used by function get_dmi_facts

# Generated at 2022-06-11 02:54:30.537089
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    def test(s, expected):
        test_obj = SunOSHardware()

        rc = 0
        err = None

        def run_cmd(cmd, check_rc=True):
            nonlocal rc, err
            rc = 0
            err = None
            return rc, s, err

        test_obj.module.run_command = run_cmd
        facts = test_obj.get_memory_facts()

        assert rc == 0
        assert err is None

        for k,v in expected.items():
            assert k in facts
            assert facts[k] == v

    test('Memory size: 8192 Megabytes', {'memtotal_mb': 8192})
    test('Memory size: 8192 Megabytes\n', {'memtotal_mb': 8192})


# Generated at 2022-06-11 02:54:41.655217
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """This is a unit for method populate of class SunOSHardware."""

    import sys
    import io
    import mock

    # Mock module input parameters.
    sys.argv = ['ansible-test', '--timeout', '10']

    # Mock locale locale.get_best_parsable_locale()

# Generated at 2022-06-11 02:54:53.699728
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import sys
    import os
    import pytest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector

    # populate test should run all of this class's methods.
    # unit_test.py should have already checked their returns.
    # Think of this test as a coverage check.
    test_obj = SunOSHardware()

    # mock command responses to shorten test time.
    test_obj.module.run_command = lambda x: ('', '', '')
    # mock file content.
    test_obj.module.get_file_content = lambda x: 'somedata'
    # mock statvfs response.
    test_obj.get_mount_size = lambda x: {}

    # Run it!

# Generated at 2022-06-11 02:55:04.745418
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = getattr(__import__('ansible.module_utils.facts.hardware.sunos', fromlist=['AnsibleModule']), 'AnsibleModule')
    hardware = SunOSHardware(module)

    # FIXME
    # hardware.module.run_command = lambda x: (1, '''sderr:0:sd0,err:Hard Errors     0
    # sderr:0:sd0,err:Illegal Request 6
    # sderr:0:sd0,err:Media Error     0
    # sderr:0:sd0,err:Predictive Failure Analysis     0
    # sderr:0:sd0,err:Product VBOX HARDDISK   9
    # sderr:0:sd0,err:Revision        1.0
    # sderr:0:

# Generated at 2022-06-11 02:55:15.025454
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.populate()
    for fact in facts:
        assert fact in ['devices', 'memtotal_mb', 'processor', 'processor_cores', 'processor_count', 'system_vendor', 'swap_allocated_mb', 'swap_reserved_mb', 'swaptotal_mb', 'swapfree_mb', 'mounts'], 'populate gives invalid fact: %s' % fact
        assert facts[fact] is not None, 'fact %s has no value' % fact


# Generated at 2022-06-11 02:55:24.317767
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd):
            rc = 0
            kstat_output = 'unix:0:system_misc:boot_time\t1548249689'
            err = ''
            return rc, kstat_output, err

    class MockFacts:
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    sunHardware = SunOSHardware(MockModule())
    uptime_fact = sunHardware.get_uptime_facts()
    expect_uptime_fact = {
        'uptime_seconds': int(time.time() - 1548249689)
    }
    assert uptime_fact == expect_uptime_fact

# Generated at 2022-06-11 02:55:32.292040
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('AnsibleModule', (), {'run_command': run_command, 'get_bin_path': get_bin_path})
    hardware = SunOSHardware(module)

    # Get expected cpu facts
    rc, out, err = hardware.module.run_command("/usr/bin/kstat cpu_info")
    cpu_facts = hardware.get_cpu_facts()

    assert len(cpu_facts['processor']) > 0
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-11 02:55:40.100646
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_facts = SunOSHardware()
    rc, out, err = hardware_facts.module.run_command("/usr/bin/kstat cpu_info")

    socket = 0
    cpu_facts = {}
    cpu_facts['processor'] = []
    cpu_facts['processor_cores'] = 'NA'
    cpu_facts['processor_count'] = socket

    for line in out.splitlines():
        if len(line) < 1:
            continue

        data = line.split(None, 1)
        key = data[0].strip()
        if key == 'module:':
            brand = ''
        elif key == 'brand':
            brand = data[1].strip()
        elif key == 'clock_MHz':
            clock_mhz = data[1].strip()

# Generated at 2022-06-11 02:56:06.080590
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    MOCK_PRTDIAG_OUTPUT = """
System Configuration: Oracle Corporation sun4u Sun Fire V490
System clock frequency: 300 MHz
Memory size: 8192 Megabytes
Processor type: SUNW,UltraSPARC-IV+
Processor implementation: UltraSPARC-IV+
Processor version: E10
Processor clock frequency: 900 MHz
Number of processors: 2
"""

    module = SunOSHardware()
    module.module = Mock()
    module.module.run_command.return_value = (0, MOCK_PRTDIAG_OUTPUT, '')
    module.populate()

    assert module.get_dmi_facts()['system_vendor'] == 'Oracle Corporation'
    assert module.get_dmi_facts()['product_name'] == 'Sun Fire V490'

# Generated at 2022-06-11 02:56:08.314343
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_facts = SunOSHardware()
    hardware_facts.populate()
    assert hardware_facts.populate() == {}

# Generated at 2022-06-11 02:56:16.935351
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import sys, os
    sys.path.append(os.path.abspath('../../test/common'))
    import MockModule
    module = MockModule.MockModule()
    sys.modules['ansible.module_utils.facts.utils'] = MockModule
    module.run_command = MockModule.MockCommand(kstat_out=True)
    sun = SunOSHardware(module)
    dmi_facts = sun.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts



# Generated at 2022-06-11 02:56:24.732513
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hw = SunOSHardware()
    hw.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    hw.module.run_command = run_command
    hw.get_cpu_facts = get_cpu_facts
    hw.get_memory_facts = get_memory_facts
    hw.get_dmi_facts = get_dmi_facts
    hw.get_device_facts = get_device_facts
    hw.get_uptime_facts = get_uptime_facts
    hw.get_mount_facts = get_mount_facts

    collected_facts = {'ansible_machine': 'i86pc'}

# Generated at 2022-06-11 02:56:36.705433
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:47.701929
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    args = dict(module_args=dict())
    ah = SunOSHardware(args)

    facts = ah.populate()

    assert facts['memtotal_mb'] is not None
    assert facts['swaptotal_mb'] is not None
    assert facts['swapfree_mb'] is not None
    assert facts['swap_allocated_mb'] is not None
    assert facts['swap_reserved_mb'] is not None
    assert facts['processor_count'] is not None
    assert facts['processor_cores'] is not None
    assert facts['system_vendor'] is not None
    assert facts['product_name'] is not None
    assert facts['uptime_seconds'] is not None
    assert facts['devices'] is not None

    assert facts['devices']['sd0']['product'] is not None
    assert facts

# Generated at 2022-06-11 02:56:57.310777
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def run_command(self, args, **kwargs):
            return 0, '{0}{1}{2}'.format(args, kwargs, self.params), None

    module = MockModule()
    cpu_facts = SunOSHardware(module).get_cpu_facts()
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['']


# Generated at 2022-06-11 02:57:06.382477
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:11.387666
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module=module)
    module.run_command = AnsibleModuleMock.run_command
    hardware.get_memory_facts()
    module.run_command.assert_has_calls([
        mock.call("/usr/sbin/prtconf"),
        mock.call("/usr/sbin/swap -s"),
    ])


# Generated at 2022-06-11 02:57:20.627614
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ModuleStub():
        def __init__(self):
            pass

        def run_command(self, cmd):
            if cmd == ['/usr/bin/prtdiag']:
                return 0, 'System Configuration:   Sun Microsystems sun4v System Configuration:   Sun Microsystems sun4v', ''
            else:
                return 1, '', ''

    module = ModuleStub()
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts.get('system_vendor') == 'Sun Microsystems'
    assert dmi_facts.get('product_name') == 'sun4v'



# Generated at 2022-06-11 02:57:47.409942
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:50.281172
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # define an instance of class SunOSHardware
    sunos_hw = SunOSHardware(module=None, cache=None)

    # call method populate and examine results
    facts = sunos_hw.populate()

    return facts

# Generated at 2022-06-11 02:58:02.040811
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Total memory of a single system page size
    prtconf_out = "System Configuration:  Oracle Corporation  SunOS 5.11 11.3\n" \
                  "Memory size:          1 Megabyte\n"
    swap_out = "%swap used\n" \
               "1234567"
    module = DummyModule(command_responses={'/usr/sbin/prtconf': [0, prtconf_out, ''],
                                            '/usr/sbin/swap -s': [0, swap_out, '']})
    hardware_facts = SunOSHardware(module).populate()
    assert hardware_facts['swap_allocated_mb'] == 1234
    assert hardware_facts['swap_reserved_mb'] == 567
    assert hardware_facts['swaptotal_mb'] == 1234


# Generated at 2022-06-11 02:58:07.419711
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    data = 'Memory size: 4096 Megabytes'

    class MockRun(object):
        def __init__(self, module):
            self.module = module

        def run_command(self, command):
            return 0, data, ''

    class MockModule(object):
        def __init__(self, module):
            self.run_command = MockRun(module)

    original_module = module
    module = MockModule(module)
    hardware = SunOSHardware(module)
    hardware.populate()

    # Swap facts are not available from the command output, so we need to test
    # them separately
    module = original_module
    hardware = SunOSHardware(module)
    swapinfo = hardware.get_memory

# Generated at 2022-06-11 02:58:10.960053
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = SunOSHardware(None)
    uptime_facts = facts.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-11 02:58:20.525083
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible_collections.testns.testcoll.plugins.module_utils import basic
    basic._ANSIBLE_ARGS = basic.parse_argv([])

    module = basic.AnsibleModule(
        argument_spec={}
    )
    module.warn = lambda x: None
    module.run_command = lambda x: (0, 'Memory size: 4096 Megabytes', '')
    sunoshardware = SunOSHardware(module)
    assert sunoshardware.get_memory_facts() == {'memtotal_mb': 4096}

    module.run_command = lambda x: (0, 'Memory size: 4 Gigabytes', '')
    sunoshardware = SunOSHardware(module)
    assert sunoshardware.get_memory_facts() == {'memtotal_mb': 4096}

    module.run_command

# Generated at 2022-06-11 02:58:31.639548
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module)
    hardware.populate()

# Generated at 2022-06-11 02:58:42.779191
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:58:50.033069
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    collected_facts = {
        'ansible_machine': 'i86pc',
        'ansible_processor': 'i386',
        'ansible_processor_cores': '1',
        'ansible_processor_count': '1'
    }

    module = FakeAnsibleModule(collected_facts)
    collector = SunOSHardwareCollector(module)
    platform = collector.get_platform()

    hardware = SunOSHardware(module)
    facts = hardware.populate()

    assert platform == 'SunOS'
    assert len(facts['ansible_devices']) == 1
    assert facts['ansible_devices']['sd0']['size'] == '51.2GB'


# Generated at 2022-06-11 02:59:00.470046
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockMod(object):
        @staticmethod
        def get_bin_path(path, opt_dirs=None, required=False):
            if path == 'prtconf':
                return '/usr/sbin/prtconf'
            if path == 'swap':
                return '/usr/sbin/swap'
            raise Exception("Unexpected path '%s' in get_bin_path" % path)

        @staticmethod
        def run_command(args):
            if args == '/usr/sbin/prtconf':
                return (0, 'Memory size: 65536 Megabytes', '')
            if args == ['/usr/sbin/swap', '-s']:
                return (0, 'total:  178018144k bytes allocated = 0k used,  178018144k available', '')
            raise

# Generated at 2022-06-11 02:59:25.244693
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunosHardwareCollector = SunOSHardwareCollector()

    assert sunosHardwareCollector._platform == 'SunOS'
    assert sunosHardwareCollector._fact_class == SunOSHardware
    assert sunosHardwareCollector.required_facts == set(['platform'])

# Generated at 2022-06-11 02:59:27.873533
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:37.208040
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpuinfo = """module: cpu_info
id: 0
class: misc
chip_id
0
clock_MHz
1234
brand
Test
implementation
test_model
module: cpu_info
id: 0
class: misc
chip_id
1
clock_MHz
3456
brand
Test
implementation
test_model
module: cpu_info
id: 0
class: misc
chip_id
2
clock_MHz
3456
brand
Test
implementation
test_model
module: cpu_info
id: 0
class: misc
chip_id
3
clock_MHz
3456
brand
Test
implementation
test_model"""
    test_obj = SunOSHardware(dict(), dict())

# Generated at 2022-06-11 02:59:48.159745
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module._ansible_no_log = True
    module.run_command = lambda *args, **kwargs: (0, to_bytes("1548249689"), None)

    # Mock time.time()
    time_time_mock_value = 1548249800
    time_time_mock = lambda: time_time_mock_value
    # Monkeypatch time.time() with mock
    module.time = time_time_mock

    h = SunOSHardware(module=module)

    assert h.get_uptime_facts() == {'uptime_seconds': 111}


# Generated at 2022-06-11 02:59:59.567960
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class test_SunOSHardware():
        def __init__(self):
            self.module = None
    test_module = test_SunOSHardware()
    sh = SunOSHardware(test_module)
    boot_time = int(time.time() - 86400)
    rc = sh.module.run_command.when.called_with('/usr/bin/kstat -p unix:0:system_misc:boot_time').return_value[0]
    out = sh.module.run_command.when.called_with('/usr/bin/kstat -p unix:0:system_misc:boot_time').return_value[1]
    out = 'unix:0:system_misc:boot_time\t' + str(boot_time) + '\n'
    assert rc == 0
    assert out

# Generated at 2022-06-11 03:00:10.686772
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock()
    module.get_bin_path = Mock()
    module.get_bin_path.return_value = '/usr/bin/kstat'

# Generated at 2022-06-11 03:00:16.881660
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    collected_facts = {}
    cpu_facts = SunOSHardware().get_cpu_facts(collected_facts)
    assert isinstance(cpu_facts['processor'], list)
    assert isinstance(cpu_facts['processor_cores'], int)
    assert isinstance(cpu_facts['processor_count'], int)



# Generated at 2022-06-11 03:00:27.175432
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    c = SunOSHardware()
    c.module.run_command = lambda x: (0, "module:\ti86pc\nclock_MHz\t3264\nchip_id\t0\n", "")
    assert c.get_cpu_facts() == {'processor': ['i86pc @ 3264MHz']}

    c.module.run_command = lambda x: (0, "module:\tSUNW,UltraSPARC-T1\nclock_MHz\t1200\nimplementation\tSPARC-T1 (chipid 0, clock 1200 MHz)\nchip_id\t0\nbrand\t\tSUNW,UltraSPARC-T1\n", "")

# Generated at 2022-06-11 03:00:29.636844
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    result = SunOSHardwareCollector(None, None, None)
    assert result._fact_class == SunOSHardware
    assert result._platform == 'SunOS'

# Generated at 2022-06-11 03:00:41.038137
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module=module)

    # Fake data for the first call of run_command()

# Generated at 2022-06-11 03:01:27.750555
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import pytest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunos_facts = SunOSHardware()

    s_conf_oracle_t3 = """
System Configuration: Sun Microsystems sun4u Sun Fire T1000
System clock frequency: 400 MHz
Memory size: 8192 Megabytes
"""

    s_conf_oracle_t5 = """
System Configuration: Oracle Corporation sun4v SPARC T5-8
System clock frequency: 3000 MHz
Memory size: 32256 Megabytes
"""

    s_conf_fujitsu_m10 = """
System Configuration: Fujitsu Limited   M10-1
System clock frequency: 1200 MHz
Memory size: 16384 Megabytes
"""


# Generated at 2022-06-11 03:01:37.186585
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    results = SunOSHardware().get_device_facts()

    # check if test code has sd0 in the devices dictionary
    assert 'sd0' in results['devices'], "SunOSHardware_get_device_facts: Error: test code missing sd0 in fact dictionary"

    # check if test code has hard_errors in the devices dictionary
    assert 'hard_errors' in results['devices']['sd0'], "SunOSHardware_get_device_facts: Error: test code missing sd0:hard_errors in fact dictionary"

    # check if hard_errors value is string "0"
    assert results['devices']['sd0']['hard_errors'] == "0", "SunOSHardware_get_device_facts: Error: test code hard_errors not equal to 0"

# Generated at 2022-06-11 03:01:47.193666
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import mock_command
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import StringIO
    from io import open

    uptime_facts = {}
    uptime_facts['uptime_seconds'] = int(time.time() - int(1548249689))

    kstat_output = """
unix:0:system_misc:boot_time    1548249689
"""


# Generated at 2022-06-11 03:01:52.317696
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = [0, "unix:0:system_misc:boot_time    1548249689", ""]
    hardware.get_uptime_facts()
    assert hardware.facts['uptime_seconds'] == int(time.time()) - 1548249689

# Generated at 2022-06-11 03:02:02.558196
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MockANSibleModule()
    m = SunOSHardware(module)

# Generated at 2022-06-11 03:02:11.339783
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test SunOSHardware.get_dmi_facts()
    """
    test_object = SunOSHardware()

    # test for Solaris 8
    test_object.get_dmi_facts = lambda: collections.OrderedDict([('system_vendor', 'Sun Microsystems'), ('product_name', 'Sun Fire V210')])
    assert test_object.get_dmi_facts() == collections.OrderedDict([('system_vendor', 'Sun Microsystems'), ('product_name', 'Sun Fire V210')])

    # test for Solaris 9
    test_object.get_dmi_facts = lambda: collections.OrderedDict([('system_vendor', 'Sun Microsystems'), ('product_name', 'Sun Fire V240')])
    assert test_object.get_dmi_facts() == collections

# Generated at 2022-06-11 03:02:21.534966
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class Options(object):
        module_lang = 'C'
        become = None
        become_method = None
        become_user = None
        become_ask_pass = False
        verbosity = 0
        no_log = False
        _diff = False
    class AnsibleModule(object):
        def __init__(self):
            self.args = {}
            self.check_mode = False
            self.params = {}
            self.options = Options()
            self.exit_json = None
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/kstat'
        def display(self, key, value):
            print(key, value)
        def run_command(self, cmd, environ_update=None):
            return 0, kstat_output, ""

# Generated at 2022-06-11 03:02:30.771967
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import io

    # mock class SunOSHardware
    class BigSunOSHardware:
        def __init__(self):
            self.module = BigModule()

    # mock class FactsBase
    class BigFactsBase:
        def __init__(self):
            self.facts = {}

    # mock class BigModule
    class BigModule:
        def __init__(self):
            self.params = {}
            # mock stdout of run_command
            self.run_command_stdout = io.StringIO(u'unix:0:system_misc:boot_time    1548249689\n')

        def get_bin_path(self, arg, **kwargs):
            return arg

        def run_command(self, args, **kwargs):
            stdout_value = self.run_command_stdout.readline

# Generated at 2022-06-11 03:02:35.818921
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts.has_key('processor')
    assert cpu_facts.has_key('processor_count')
    assert cpu_facts.has_key('processor_cores')



# Generated at 2022-06-11 03:02:46.574774
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock()
    md = SunOSHardware(module)

    # Test output of kstat command