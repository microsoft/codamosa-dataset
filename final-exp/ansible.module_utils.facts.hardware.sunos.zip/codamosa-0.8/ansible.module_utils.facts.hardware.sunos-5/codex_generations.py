

# Generated at 2022-06-11 02:54:02.864580
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test_adi = SunOSHardware()
    uptime_facts = test_adi.get_uptime_facts()
    assert len(uptime_facts.keys()) == 1
    assert list(uptime_facts.keys())[0] == 'uptime_seconds'

# Generated at 2022-06-11 02:54:15.545532
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({}, {})
    hardware.kstat_cpu_info = """
module: 0
id: 0
instance: 0
clock_MHz: 2600.000000
brand: AMD EPYC 7601 32-Core Processor
chip_id: 0
chip: 1
class: misc
crtime: 8.952467303
snaptime: 34.819228099
level: 1
module: 0
name: cpu_info
instance: 0
clock_MHz: 2600.000000
brand: AMD EPYC 7601 32-Core Processor
chip_id: 0
chip: 1
class: misc
crtime: 8.952467303
snaptime: 34.819228099
level: 1
"""
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': ''})
    assert not cpu_facts

# Generated at 2022-06-11 02:54:21.636145
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    hardware_obj = SunOSHardware(dict())
    hardware_obj.module.run_command = lambda *args, **kwargs: (0, '', '')
    hardware_obj.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/kstat'
    results = hardware_obj.populate()
    assert results['mounts'] == []

# Generated at 2022-06-11 02:54:31.541162
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class module:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, *args, **kwargs):
            return args[0]
        def run_command(self, *args, **kwargs):
            if args[0] == '/usr/bin/kstat':
                return 0, 'unix:0:system_misc:boot_time    1548249689', ''
            elif args[0] == '/usr/bin/uname':
                return 0, 'test', ''
            else:
                return 0, '', ''

    hardware = SunOSHardware(module())
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 123456



# Generated at 2022-06-11 02:54:39.532421
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}
    # sample kstat output:
    # unix:0:system_misc:boot_time    1548249689
    rc, out, err = run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')

    if rc != 0:
        return

    # uptime = $current_time - $boot_time
    uptime_facts['uptime_seconds'] = int(time.time() - int(out.split('\t')[1]))

    return uptime_facts

# Generated at 2022-06-11 02:54:51.328110
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    This test verifies whether get_dmi_facts of class SunOSHardware returns expected results or not.

    Note: _run_command() returns a tuple of three values:
    Return code (integer), stdout (byte string), and stderr (byte string)
    """
    from ansible.module_utils.facts.system.sunos import SunOSHardware

    class SunOSHardwareModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_stdout = b"System Configuration: Sun Microsystems sun4u"
            self.run_command_stderr = None

        def get_bin_path(self, arg1, opt_dirs=None):
            return '/usr/bin/prtdiag'


# Generated at 2022-06-11 02:55:01.366676
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd):
            return (0, 'unix:0:system_misc:boot_time\t1548249689', '')

    class MockFact_collector:
        def __init__(self):
            self.current_time = 1548252068

    current_time = time.time()
    time.time = MockFact_collector().__init__()

    hardware = SunOSHardware(MockModule())
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 309

    # Reset the time to the current time
    time.time = current_time

# Generated at 2022-06-11 02:55:09.524648
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert hardware_facts['devices']['sd0']['revision'] == '1.0'
    assert hardware_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert hardware_facts['devices']['sd0']['size'] == '50 GB'
    assert hardware_facts['devices']['sd0']['vendor'] == 'ATA'

# Generated at 2022-06-11 02:55:21.059047
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware_facts = SunOSHardware()

    class test_module(object):
        def __init__(self):
            self.run_command_counter = -1

        def run_command(self, *args, **kwargs):
            self.run_command_counter += 1
            command = args[0]
            if command == '/usr/sbin/swap -s':
                return (0, 'kstat output', 'err')
            elif command == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return (0, 'kstat output', 'err')
            return (0, '', '')

    test_facts = test_module()
    rc, out, err = hardware_facts.get_uptime_facts(test_facts)
    assert test_facts.run_command

# Generated at 2022-06-11 02:55:31.622936
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = type('Module', (object,), {})
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: None
    module.get_file_content = lambda *args, **kwargs: None
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['sparcv9 (cpp sparc) @ 2.66GHz']
    assert hardware.facts['swapfree_mb'] == 2560
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 5120

# Generated at 2022-06-11 02:55:55.983932
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import get_device_facts

    test_obj = SunOSHardware()

    test_obj.get_device_facts = get_device_facts.__get__(test_obj)

    result = test_obj.get_device_facts()
    assert ('devices' in result)
    assert ('sd0' in result['devices'])
    assert ('product' in result['devices']['sd0'])

# Generated at 2022-06-11 02:55:58.532583
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware(dict())
    facts = m.get_device_facts()

    assert isinstance(facts, dict)
    assert isinstance(facts['devices'], dict)

# Generated at 2022-06-11 02:56:04.751274
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689\n', '')

    uptime_facts = {}
    uptime_facts['uptime_seconds'] = int(time.time() - int(1548249689))

    test_obj = SunOSHardware()

    output = test_obj.get_uptime_facts()
    assert output == uptime_facts


# Generated at 2022-06-11 02:56:16.535728
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class mock_module():
        def __init__(self):
            self.run_command_environ_update = {}
            self.fail_json = mock.Mock()

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, raise_err=True, environ_update=None):
            out = b''

            if args == "/usr/sbin/swap -s":
                out = b"total: 5120k bytes allocated + 4096k reserved = 9.2MB used, 10MB available\n"
                rc = 0

# Generated at 2022-06-11 02:56:21.928536
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create a instance of SunOSHardware
    hardware = SunOSHardware({})
    # Check that the class can be instantiated
    assert hardware

    # Create temporary facts
    collected_facts = {'ansible_machine': 'i86pc', 'ansible_memtotal_mb': 2804}

    # Populate the facts
    hardware.populate(collected_facts)

    # Check that the class hardware was populated
    assert hardware.facts['memtotal_mb'] == 2804

# Generated at 2022-06-11 02:56:30.566473
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts method of SunOSHardware.

    :param facts:
    :return:
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import eval_facts
    from ansible.module_utils.facts.collector import get_collector_instance

    h = SunOSHardware()
    output = eval_facts(get_collector_instance('hardware'))
    print(output['ansible_facts'])

# Generated at 2022-06-11 02:56:41.293393
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    test_facts = SunOSHardware()

    with mock.patch.object(SunOSHardware, '_get_kstat'),\
         mock.patch.object(SunOSHardware, '_get_prtconf'):
        test_facts.module = mock.MagicMock()
        test_facts.module.run_command.return_value = (0, 'unix:0:system_misc:boot_time\t1548249689', '')

        facts = test_facts.get_uptime_facts()

        # Compare the uptime with the value in seconds from the current time.
        ut = datetime.datetime.now() - datetime.datetime.fromtimestamp(float(facts['uptime_seconds']))
        assert ut.total_seconds() == 1548249689

# Generated at 2022-06-11 02:56:47.353529
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockUptimeModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'unix:0:system_misc:boot_time\t1548249689', None))

    module = MockUptimeModule()
    uptime_facts = SunOSHardware(module).get_uptime_facts()

    assert int(uptime_facts['uptime_seconds']) == 1548249689

# Generated at 2022-06-11 02:56:56.497486
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts.
    """
    class MockModule:
        def run_command(self, command, check_rc=True):
            return 0, "System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)", ""

    module = MockModule()
    hardware = SunOSHardware(module)

    result = hardware.get_dmi_facts()

    assert result['system_vendor'] == 'QEMU'
    assert result['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'

# Generated at 2022-06-11 02:57:00.564263
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hw = SunOSHardware(module=module)
    hw.populate()
    assert 'processor' in hw.facts
    assert 'processor_count' in hw.facts
    assert 'processor_cores' in hw.facts


# Generated at 2022-06-11 02:57:27.682596
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    results = hardware.populate()

    assert results['devices']['sd0']['hard_errors'] == "0"
    assert results['devices']['sd0']['soft_errors'] == "0"
    assert results['devices']['sd0']['transport_errors'] == "0"
    assert results['devices']['sd0']['media_errors'] == "0"
    assert results['devices']['sd0']['predictive_failure_analysis'] == "0"
    assert results['devices']['sd0']['illegal_request'] == "6"
    assert results['devices']['sd0']['product'] == "VBOX HARDDISK"

# Generated at 2022-06-11 02:57:36.078835
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    def run_cmd_side_effect(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
        if args[0] == '/usr/bin/kstat cpu_info':
            return (0, """\
module: 0
core_id: 0
chip_id: aw17
clock_MHz: 2600
implementation: sunw,sunw,ultra
brand: sparc64-vii
""", None)
        elif args[0] == "prtconf":
            return (0, """\
System Configuration: VMware, Inc. VMware Virtual Platform
Memory size: 8000 Megabytes
""", None)

# Generated at 2022-06-11 02:57:45.893864
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # This is what we expect the output should look like:
    # unix:0::boot_time       1548249689

    # We need to line up the output of time.mktime as closely as possible.
    # There is probably a better way to do this.

    # NOTE: If this test fails, check your TZ variable
    #       and make sure that your timezone is set to UTC
    #       or run with `TZ=UTC` (assuming you're in bash).
    #       Otherwise, add delta to get_uptime_facts

    import time
    # retrieve current time
    t = time.time()
    # format boot time
    boot_time = time.strftime("%Y%j%H%M%S", time.gmtime(t))
    # remove timezone string

# Generated at 2022-06-11 02:57:56.737377
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    This method is used to test the get_device_facts method of the SunOSHardware class.

    With the return_value_of_run_command fixture, it is possible to mock the command output instead
    of actually running the command.

    For example, if we mock the run_command of the module, we can return the desired output:

        with mock.patch.dict('ansible_facts.ansible_local.SunOSHardware.run_command',
                             {'/usr/bin/kstat': (0, kstat_output, '')}):
            hardware.get_device_facts()

    The run_command method returns a tuple with:
        - the return code of the command
        - the stdout of the command
        - the stderr of the command
    """


# Generated at 2022-06-11 02:58:08.462645
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys
    import unittest

    class MockModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_calls = 0

        def run_command(self, args, check_rc=False):
            self.run_command_calls += 1
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class SunOSHardware_TestCase(unittest.TestCase):
        def test_get_uptime_facts(self):
            module = MockModule()
            sys.modules['ansible.module_utils.facts.hardware.sunos.SunOSHardware'] = module

# Generated at 2022-06-11 02:58:15.835809
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import sys
    if sys.version_info[:2] == (2, 6):
        import unittest2 as unittest
    else:
        import unittest

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware, SunOSHardwareCollector
    from ansible.module_utils.facts import FactCollector, timeout


# Generated at 2022-06-11 02:58:19.722081
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mock_module = type("AnsibleModule", (), {"run_command": get_memory_facts_side_effect})
    mock_module.params = {}
    mock_instance = SunOSHardware(mock_module)

    result = mock_instance.get_memory_facts()
    assert result["memtotal_mb"] == 2048



# Generated at 2022-06-11 02:58:30.928593
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # Create object of class SunOSHardware
    sunos_obj = SunOSHardware(dict(module=None))

    # Test for negative case for method get_uptime_facts. Return value is
    # empty dictionary.
    rc, out, err = sunos_obj.module.run_command.return_value = (1, '', '')
    assert {} == sunos_obj.get_uptime_facts()

    # Test for positive case for method get_uptime_facts
    rc, out, err = sunos_obj.module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')
    assert int(time.time()) - 1548249689 == sunos_obj.get_uptime_facts()['uptime_seconds']
    # Test case where

# Generated at 2022-06-11 02:58:41.479864
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    hardware.module = AnsibleModuleMock()
    hardware.module.run_command = MagicMock(return_value=(1, 'System Configuration: Oracle Corporation sun4v', ''))
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}

    hardware.module.run_command = MagicMock(return_value=(1, 'System Configuration: Oracle Corporation sun4u', ''))
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4u'}


# Generated at 2022-06-11 02:58:49.215421
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    prtconf = '''Memory size: 16384 Megabytes
System Peripherals (Software Nodes):
     SUNW,Sun-Fire-T200
     SUNW,NETRA-T12
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
     SUNW,Sun-Fire-T200
Options:
     vntsd: vntsd
     x64: x64'''



# Generated at 2022-06-11 02:59:30.761662
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule({})
    result = SunOSHardware.get_memory_facts(module)
    assert result['memtotal_mb'] == 1023
    assert result['swap_allocated_mb'] == 10
    assert result['swap_reserved_mb'] == 10
    assert result['swapfree_mb'] == 1
    assert result['swaptotal_mb'] == 11


# Generated at 2022-06-11 02:59:32.784088
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)

    facts = hardware.populate()

    assert facts['uptime_seconds'] == 1518759898, "uptime_seconds is incorrect"

# Generated at 2022-06-11 02:59:42.800019
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    test_data = {
        'System Configuration: VMware, Inc. VMware Virtual Platform' : "VMware, Inc. VMware Virtual Platform",
        'System Configuration: Oracle Corporation sun4v': "Oracle Corporation sun4v",
        'System Configuration: AMD COMPUTER CORPORATION Virtual Machine': "AMD COMPUTER CORPORATION Virtual Machine",
        'System Configuration: QEMU QEMU HARDDISK': "QEMU QEMU HARDDISK",
        'System Configuration: Sun Microsystems sun4u': "Sun Microsystems sun4u",
        'System Configuration: Sun Microsystems sun4v': "Sun Microsystems sun4v",
        'System Configuration: Sun Microsystems sun4v': "Sun Microsystems sun4v",
    }

# Generated at 2022-06-11 02:59:50.476681
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    f = open('prtdiag.txt', 'r')
    prtdiag_output = f.read()
    f.close()

    expected_facts = {
        'system_vendor': 'QEMU',
        'product_name': 'Standard PC (i440FX + PIIX, 1996)'
    }

    m = SunOSHardware()
    actual_facts = m.get_dmi_facts(prtdiag_output)

    assert expected_facts == actual_facts



# Generated at 2022-06-11 03:00:01.247139
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

# Generated at 2022-06-11 03:00:12.696122
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule:
        def run_command(self, cmd):
            if cmd == ["/usr/sbin/prtconf"]:
                out = ("Memory size: 16384 Megabytes\n")
                return 0, out, None
            else:
                return 0, "", None

    class MockHardware:
        def __init__(self, hardware_class):
            self.module = MockModule()

        def populate(self, collected_facts=None):
            return hardware_class().populate(collected_facts)

    # Positive test
    hardware_module = MockHardware(SunOSHardware)
    hardware_facts = hardware_module.populate()
    assert hardware_facts.get('memtotal_mb') == 16384

    # Negative test
    hardware_module = MockHardware(SunOSHardware)
    assert not hardware_module.pop

# Generated at 2022-06-11 03:00:20.904850
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    raw1 = """System Configuration:
                    Sun Microsystems sun4u Sun Fire V240"""
    expected1 = {'system_vendor': 'Sun Microsystems',
                 'product_name': 'sun4u Sun Fire V240'}

    raw2 = """System Configuration:
                    Oracle Corporation sun4v T5240"""
    expected2 = {'system_vendor': 'Oracle Corporation',
                 'product_name': 'sun4v T5240'}

    raw3 = """System Configuration:
                    VMware, Inc. VMware Virtual Platform"""
    expected3 = {'system_vendor': 'VMware, Inc.',
                 'product_name': 'VMware Virtual Platform'}

    raw4 = """System Configuration:
                    QEMU PC (i440FX + PIIX, 1996)"""

# Generated at 2022-06-11 03:00:25.585064
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = SunOSHardwareCollector.test_module
    hardware = SunOSHardwareCollector.test_class()
    result = hardware.get_cpu_facts()
    assert result == {'processor': ['UltraSPARC-T2 @ 1152MHz'], 'processor_count': 4, 'processor_cores': 8}


# Generated at 2022-06-11 03:00:26.214207
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    pass

# Generated at 2022-06-11 03:00:34.474106
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = FakeModule()
    uptime_facts = SunOSHardware(module).get_uptime_facts()

    # If kstat is not reading the boot_time properly, we will get
    # an empty facts map. Else, we will get uptime_seconds.
    if uptime_facts == {}:
        assert False, "get_uptime_facts is not working as expected"
    else:
        assert 'uptime_seconds' in uptime_facts, "get_uptime_facts is not working as expected"


# Generated at 2022-06-11 03:01:54.660763
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Test with a file that contains stats for devices.
    m = SunOSHardware({}, '/etc/ansible/facts.d')
    m.module.get_bin_path = lambda arg: arg

# Generated at 2022-06-11 03:02:04.416029
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class MockModule:
        def run_command(self, args):
            return 0, "unix:0:system_misc:boot_time 1548249689", ""

    class MockFactCollector:
        def __init__(self):
            self.current_time = time.time()

    def test_get_uptime_facts(self):
        collected_facts = {}
        collected_facts['platform'] = self._platform
        uptime_facts = self.collect(collected_facts, MockModule())
        assert uptime_facts['uptime_seconds'] == int(MockFactCollector.current_time - 1548249689)
        assert 'uptime_hours' not in uptime_facts

    test_get_uptime_facts = test_SunOSHardware_get_uptime_facts.test_get_uptime_facts

# Generated at 2022-06-11 03:02:11.419374
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import datetime
    facts = Facts({})
    facts.add_mock_subelement('ansible_facts', 'hardware', SunOSHardware(facts))
    m_time = datetime.datetime.now()
    facts.add_mock_subelement('ansible_facts', 'hardware', SunOSHardware.get_uptime_facts(m_time))

    assert len(facts.ansible_facts['uptime_seconds']) > 0

# Generated at 2022-06-11 03:02:19.650952
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')
    sunos = SunOSHardware(module_mock)

    # storage of start time of unit test
    start_time = time.time()

    # call the method to test
    uptime_facts = sunos.get_uptime_facts()

    # compute the current uptime in seconds
    expected_uptime_seconds = int(time.time() - start_time)

    # check the output
    assert uptime_facts['uptime_seconds'] == expected_uptime_seconds

# Generated at 2022-06-11 03:02:22.481197
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    fact_collector = SunOSHardwareCollector()
    assert fact_collector.required_facts == set(['platform']), fact_collector.required_facts


# Generated at 2022-06-11 03:02:31.694599
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import sys
    import os
    import tempfile
    import shutil

    # Setup
    (test_file_fd, test_file) = tempfile.mkstemp()

    # Test
    os.write(test_file_fd, b"sderr:0:sd0,err:Hard Errors     0\n")
    os.write(test_file_fd, b"sderr:0:sd0,err:Illegal Request 6\n")
    os.write(test_file_fd, b"sderr:0:sd0,err:Media Error     0\n")
    os.write(test_file_fd, b"sderr:0:sd0,err:Predictive Failure Analysis     0\n")

# Generated at 2022-06-11 03:02:39.673335
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict()
    )

    sun_hw = SunOSHardware(module)

    memory_facts = sun_hw.get_memory_facts()

    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts



# Generated at 2022-06-11 03:02:45.781007
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    SunOSHardware_test = SunOSHardware()
    class test_memory_facts():
        def __init__(self):
            self.user_space_grep_out = """Mem: 8k   8k   8k"""
            self.swap_grep_out = """Swap:   8k   8k   8k"""

# Generated at 2022-06-11 03:02:51.209366
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    my_SunOSHardwareCollector = SunOSHardwareCollector()

    assert type(my_SunOSHardwareCollector) == SunOSHardwareCollector
    assert my_SunOSHardwareCollector._platform == 'SunOS'
    assert my_SunOSHardwareCollector.required_facts == set(['platform'])
    assert my_SunOSHardwareCollector._fact_class == SunOSHardware
    assert my_SunOSHardwareCollector._fact_class.platform == 'SunOS'

# Generated at 2022-06-11 03:02:56.138778
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    collected_facts = {
        'platform': 'SunOS'
    }
    fact_subclass = SunOSHardware(dict(), collected_facts)

    # Returns dmi facts
    dmi_facts = fact_subclass.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

