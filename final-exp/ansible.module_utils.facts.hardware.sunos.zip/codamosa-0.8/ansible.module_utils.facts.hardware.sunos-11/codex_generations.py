

# Generated at 2022-06-11 02:54:07.358965
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test that SunOSHardware.get_device_facts correctly parses kstats for devices.
    """

    # SunOSHardware.get_device_facts calls run_command. We stub it out with a
    # stub implementation of run_command that returns fixed output from kstat,
    # and then test the parsed facts.

# Generated at 2022-06-11 02:54:20.243238
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:54:29.930671
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector


# Generated at 2022-06-11 02:54:41.461888
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] in [2, 'NA']
    assert hardware_facts['processor_count'] in [1, 2]
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['swap_allocated_mb'] > 0
    assert hardware_facts['swap_reserved_mb'] > 0

    # Check mount facts
    mount_facts = hardware_facts.get('mounts')
    if mount_facts:
        assert len(mount_facts) > 0
        assert 'mount' in mount_facts[0]

# Generated at 2022-06-11 02:54:53.491027
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import facts

    # Create instance of SunOSHardware and initialize with collected facts
    sun_hardware_instance = SunOSHardware({'ansible_facts': facts.FactsCollector})

    # Populate SunOSHardware
    sun_hardware_instance.populate()

    # Fail test if expected number of keys is not matched
    assert len(sun_hardware_instance.data.keys()) == 11

    # Fail test if keys are not matched

# Generated at 2022-06-11 02:55:01.832370
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    hw = SunOSHardware(module=module)

    facts = hw.get_memory_facts()
    assert facts['memtotal_mb'] == 2
    assert facts['swapfree_mb'] == 4
    assert facts['swaptotal_mb'] == 5
    assert facts['swap_reserved_mb'] == 1
    assert facts['swap_allocated_mb'] == 2



# Generated at 2022-06-11 02:55:09.523399
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeANSIModule()

    # Test with FakeANSIModule
    sunos_hardware = SunOSHardware(module)

    # Test with a file containing kstat information
    with open('./unit/ansible/module_utils/facts/hardware/sunos_test_get_cpu_facts.txt', 'r') as f:
        sunos_hardware.run_command = mock_run_command(f.read())

    cpu_facts = sunos_hardware.get_cpu_facts()

    assert len(cpu_facts['processor']) == 8
    assert cpu_facts['processor_cores'] == 8
    assert int(cpu_facts['processor_cores']) == int(cpu_facts['processor_count'])



# Generated at 2022-06-11 02:55:21.060952
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    cpu_facts_output = {
        'processor': ['SPARC T5 (chipid 0, clock 1549 MHz) @ 1549 MHz'],
        'processor_cores': 'NA',
        'processor_count': 1
    }

    prtconf_output = """System Configuration: Sun Microsystems  sun4v
Memory size: 8192 Megabytes
"""

    test = SunOSHardware(module=module)

    with patch.object(test, 'run_command', create=True) as mock:
        module.run_command.side_effect = [
            (0, cpu_facts_output, ''),
            (0, prtconf_output, '')
        ]
        cpu_facts = test.get_cpu_facts()
        assert cpu_facts == cpu_facts_

# Generated at 2022-06-11 02:55:25.260257
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    hardware = SunOSHardware(module)

    hardware.module.run_command.return_value = (0, 'Memory size: 4096 Megabytes', '')

    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 4096



# Generated at 2022-06-11 02:55:35.614631
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = run_command_mock
    sunos_facts = SunOSHardware(module)

    memory_facts = sunos_facts.get_memory_facts()

    assert memory_facts.get('memtotal_mb') is not None
    assert memory_facts.get('memtotal_mb') == 8196
    assert memory_facts.get('swapfree_mb') is not None
    assert memory_facts.get('swapfree_mb') == 12287
    assert memory_facts.get('swaptotal_mb') is not None
    assert memory_facts.get('swaptotal_mb') == 12864
    assert memory_facts.get('swap_allocated_mb') is not None
    assert memory_facts.get('swap_allocated_mb') == 576

# Generated at 2022-06-11 02:55:52.654837
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Prepare
    SunOSHardware_obj = SunOSHardware()
    SunOSHardware_obj.module.run_command = run_command_mock

    # Execute
    uptime_facts = SunOSHardware_obj.get_uptime_facts()

    # Verify
    assert uptime_facts.get('uptime_seconds') == 100


# Generated at 2022-06-11 02:56:02.180953
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    d = {'devices':
         {'sda':
          {'hard_errors': '0',
           'illegal_request': '0',
           'media_errors': '0',
           'predictive_failure_analysis': '0',
           'product': 'VirtualBox Virtual IDE Hard Drive',
           'revision': '1.0',
           'serial': 'VB0a20c4d-074a',
           'size': '49.00 GB',
           'soft_errors': '0',
           'transport_errors': '0',
           'vendor': 'ATA'}},
         'changed': False}

    module = AnsibleModule(argument_spec=dict())
    sh = SunOSHardware(module=module)

# Generated at 2022-06-11 02:56:10.632536
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    hardware.populate()

    facts_to_test = (
        'memtotal_mb', 'mounts', 'processor', 'swapfree_mb', 'swap_allocated_mb',
        'swap_reserved_mb', 'swaptotal_mb', 'system_vendor', 'products_name',
        'devices', 'uptime_seconds'
    )

    for fact in facts_to_test:
        assert fact in hardware.facts

# Generated at 2022-06-11 02:56:14.346643
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    hardware = SunOSHardware(lambda: dict())
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ["SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz"]
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-11 02:56:20.902384
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    host_facts = {'ansible_facts': {}, 'ansible_modules': {}}
    memory_facts = SunOSHardware(host_facts, timeout=5).get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts


# Generated at 2022-06-11 02:56:26.205812
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts import ansible_facts

    hardware = SunOSHardwareCollector(module=None, facts=ansible_facts)
    facts = hardware.collect()
    assert facts['processor'] == ['SPARC64-VII @ 2GHz']
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 64


# Generated at 2022-06-11 02:56:38.131979
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    test_SunOSHardware_get_dmi_facts verifies the SunOSHardware
    get_dmi_facts method returns the dmi facts.
    :return:
    """
    import ansible.module_utils.facts.hardware.sunos
    my_obj = ansible.module_utils.facts.hardware.sunos.SunOSHardware(None)
    my_obj.module.run_command = Mock(return_value=(0, None, None))
    my_obj.module.get_bin_path = Mock(return_value='/usr/sbin/prtdiag')
    dmi_facts = my_obj.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-11 02:56:48.808024
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    SunOS = SunOSHardware(module=module)

    # Create test environment with:
    # * 2 physical processors with 2 cores (4 vcpus)
    # * 2 logical processors
    # * 4 vcpus
    os.mkdir('/proc/cpuinfo')

# Generated at 2022-06-11 02:56:55.774024
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.collector.solaris.kstat import SunOSHardware
    result = SunOSHardware.get_device_facts(facts.Facts())
    assert 'devices' in result
    assert 'sd0' in result['devices']
    assert 'product' in result['devices']['sd0']


# Generated at 2022-06-11 02:57:02.798888
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # test return of memory facts for prtconf output with memory
    class MockModule():
        def __init__(self):
            pass

        def run_command(self, cmd):
            return (0, 'System Configuration: Sun Microsystems  sun4v\nMemory size: 32768 Megabytes', '')

    test_module = MockModule()
    test_factclass = SunOSHardware(test_module)
    test_memory_facts = test_factclass.get_memory_facts()

    assert test_memory_facts['memtotal_mb'] == 32768

    # test return of memory facts for prtconf output without memory
    class MockModule():
        def __init__(self):
            pass

        def run_command(self, cmd):
            return (0, 'System Configuration: Sun Microsystems  sun4v', '')



# Generated at 2022-06-11 02:57:35.459396
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Test method get_memory_facts of class SunOSHardware
    test_instance = SunOSHardware()
    output = {'memtotal_mb': 15367}
    test_instance.module.run_command = MagicMock(return_value=(0, "    Memory Size: 15367 Megabytes", ''))
    assert test_instance.get_memory_facts() == output


# Generated at 2022-06-11 02:57:39.536438
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)

    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts



# Generated at 2022-06-11 02:57:49.402672
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    p = SunOSHardware()
    prtconf = get_file_content('tests/unit/module_utils/facts/hardware/prtconf')
    swap = get_file_content('tests/unit/module_utils/facts/hardware/swap')
    p.module.run_command = lambda x: (0, prtconf, '')
    p.module.run_command = lambda x: (0, swap, '')
    memory_facts = p.get_memory_facts()
    assert memory_facts.get('memtotal_mb') == 16384
    assert memory_facts.get('swapfree_mb') == 2044
    assert memory_facts.get('swaptotal_mb') == 2255
    assert memory_facts.get('swap_allocated_mb') == 210

# Generated at 2022-06-11 02:58:01.023081
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # This test needs root privileges to run.
    module = MockModule()
    module.get_bin_path = Mock(return_value='/usr/bin/true')
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_file_content = Mock(return_value='')
    sunosh = SunOSHardware(module)
    sunosh.get_cpu_facts = Mock(return_value={"processor": ["CPU 1", "CPU 2"]})
    sunosh.get_memory_facts = Mock(return_value={"memtotal_mb": 16384})
    sunosh.get_dmi_facts = Mock(return_value={"system_vendor": "Oracle"})

# Generated at 2022-06-11 02:58:12.135127
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:58:18.509576
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    out = ("""System Configuration: VMware, Inc. VMware Virtual Platform
System Configuration: Oracle Corporation T5-2
System Configuration: Sun Microsystems sun4v""")
    exampl_facts = {
        "system_vendor": "VMware, Inc.",
        "product_name": "VMware Virtual Platform"
    }
    get_sunos_hw = SunOSHardware()
    assert get_sunos_hw.get_dmi_facts() == exampl_facts

# Generated at 2022-06-11 02:58:23.159489
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = lambda x, *args, **kwargs: (0, 'Memory size: 2047532 Kilobytes', None)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 2000



# Generated at 2022-06-11 02:58:33.163120
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()

# Generated at 2022-06-11 02:58:43.028624
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not SunOSHardwareCollector.detect(module):
        module.fail_json(msg="Gathering SunOS hardware facts requires the kstat fact module.")

    facts = SunOSHardwareCollector().collect(module)

    facts_results = dict(
        ansible_facts=facts,
        changed=False,
        ansible_facts_resources=dict(name='hardware', version='2016-06-01')
    )

    module.exit_json(**facts_results)



# Generated at 2022-06-11 02:58:48.498340
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    collected_facts = {u'system_vendor': u'VMware, Inc.', u'product_name': u'VBOX Harddisk'}
    try:
        data = open('/usr/sbin/prtdiag', 'rb').read()
        data = data.splitlines()[0]
    except OSError:
        data = "no_prtdiag"

    SunOS = SunOSHardware()
    SunOS._run_command = lambda x, data=data: (0, data, None)

    assert collected_facts == SunOS.get_dmi_facts()

# Generated at 2022-06-11 02:59:59.350311
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={'gather_subset': {'choices': ['all', '!all', 'min'], 'default': 'all'}})
    prtconf_output = '''
Memory size: 16384 Megabytes
'''
    swap_output = '''
total: 122232k bytes allocated + 0k reserved = 122232k used, 209975644k available
'''
    module.run_command = MagicMock(return_value=(0, prtconf_output, ''))
    module.run_command_environ_update = MagicMock(return_value=(0, swap_output, ''))
    obj = SunOSHardware()

    memory_facts = obj.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384

# Generated at 2022-06-11 03:00:10.366840
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    f = SunOSHardware()
    cpu_facts = {
        'processor': [
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz',
            'SPARC64-VII+ @ 3300MHz'
        ],
        'processor_cores': 8,
        'processor_count': 2
    }

# Generated at 2022-06-11 03:00:15.414417
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_hardware_collector = SunOSHardwareCollector()
    assert sun_hardware_collector
    assert sun_hardware_collector._fact_class == SunOSHardware
    assert sun_hardware_collector._platform == 'SunOS'
    assert sun_hardware_collector.required_facts == {'platform'}

# Generated at 2022-06-11 03:00:18.010620
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    SunOSHardware = SunOSHardware()
    assert SunOSHardware.get_uptime_facts()['uptime_seconds'] > 0


# Generated at 2022-06-11 03:00:24.357591
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Case 1:
    #   If there is no error in the data, this test case should exit without errors

    test_obj = SunOSHardware({}, {})
    test_obj._module.run_command = lambda *args, **kwargs: [0, '', '']
    test_data = test_obj.populate()
    assert isinstance(test_data, dict)

    # Case 2:
    #   We are running 'kstat cpu_info' and the return code is not 0, so an
    #   empty dict should be returned.

    test_obj = SunOSHardware({}, {})
    test_obj._module.run_command = lambda *args, **kwargs: [1, '', '']
    test_data = test_obj.populate()
    assert not test_data

    # Case 3:
    #

# Generated at 2022-06-11 03:00:27.774096
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock({})
    sunOSHardware = SunOSHardware(module)
    sunOSHardware.get_dmi_facts()
    # FIXME: Verify outcome of get_dmi_facts or that it is called.


# Generated at 2022-06-11 03:00:38.840963
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create an instance of class SunOSHardware
    my_SUNOS_hw = SunOSHardware()

    # Create a temporary output file
    outfile = tempfile.NamedTemporaryFile(delete=True)

    # Defining the output of the command "prtconf"
    output = 'Memory size: 2048 Megabytes'

    # Write the output to the temporary file
    outfile.write(output)
    outfile.flush()

    # Execute the method get_memory_facts
    result = my_SUNOS_hw.get_memory_facts(outfile.name)

    # Assert the result
    assert result['memtotal_mb'] == 2048

    # Test if the result is a dict
    assert isinstance(result, dict)

# Generated at 2022-06-11 03:00:46.600212
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 03:00:56.910171
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    This method tests the get_cpu_facts method of the SunOSHardware class.
    """
    module = get_module()
    data = load_fixture('SunOSHardware_get_cpu_facts.txt')
    # test with strings with trailing white space
    cmd = '/usr/bin/kstat cpu_info'
    module.run_command.return_value = (0, data, None)
    ret = SunOSHardware(module).get_cpu_facts()
    module.run_command.assert_called_with(cmd)
    assert ret['processor_count'] == 2
    assert ret['processor_cores'] == 8
    assert ret['processor'][2] == 'SPARC64-VII+ @ 1645.0MHz'
    # test with strings without trailing white space

# Generated at 2022-06-11 03:01:04.288382
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module=module)
    uptime_facts = hw.get_uptime_facts()

    # Verify that uptime_facts is a dict
    assert isinstance(uptime_facts, dict)

    # Verify that uptime_facts has only one key: uptime_seconds
    assert len(uptime_facts.keys()) == 1
    assert 'uptime_seconds' in uptime_facts

    # Verify that uptime_seconds is a non-negative integer
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert uptime_facts['uptime_seconds'] >= 0



# Generated at 2022-06-11 03:03:10.539603
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-11 03:03:23.051592
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0,
                                                 'Memory size: 8192 Megabytes',
                                                 ''))
    module.run_command = MagicMock(return_value=(0,
                                                 'total:     14366316k bytes allocated = 5029656k used,   9336560k available',
                                                 ''))
    hardware_obj = SunOSHardware(module)
    facts = hardware_obj.get_memory_facts()
    assert facts['memtotal_mb'] == 8192
    assert facts['swaptotal_mb'] == 14433
    assert facts['swapfree_mb'] == 9030
    assert facts['swap_allocated_mb'] == 14363

# Generated at 2022-06-11 03:03:31.429218
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-11 03:03:34.450337
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    facts = SunOSHardware(module)
    uptime_results = facts.get_uptime_facts()
    assert uptime_results['uptime_seconds'] > 0

# Generated at 2022-06-11 03:03:35.959939
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector.get_platform() == 'SunOS'


# Generated at 2022-06-11 03:03:40.483675
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = FakeAnsibleCommand('prtconf')
    mem_facts = SunOSHardware(module).get_memory_facts()
    assert mem_facts['memtotal_mb'] == 2048
    assert mem_facts['swaptotal_mb'] == 1024
    assert mem_facts['swapfree_mb'] == 512
