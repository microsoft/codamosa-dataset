

# Generated at 2022-06-11 02:53:58.024864
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = SunOSHardware().populate()
    assert 'uptime_seconds' in facts

# Generated at 2022-06-11 02:54:07.358713
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_result = {
                'rc': 0,
                'out': 'System Configuration: VMware, Inc. VMware Virtual Platform'
            }

        def run_command(self, command):
            return self.run_command_result

    class MockFacts(object):
        def __init__(self):
            self.ansible_machine = 'i86pc'

    module = MockModule()
    hardware = SunOSHardware(module=module)
    hardware.populate(collected_facts=MockFacts())
    assert hardware['system_vendor'] == 'VMware, Inc.'
    assert hardware['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-11 02:54:13.158296
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleStub()
    sunos_hardware = SunOSHardware(module)

    device_facts = sunos_hardware.get_dmi_facts()
    assert device_facts['product_name'] == 'SUNW,Ultra-4', 'get_dmi_facts failed'

# Generated at 2022-06-11 02:54:18.623197
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = SunOSHardware(module)
    hardware.populate()
    hardware.get_cpu_facts()
    hardware.get_memory_facts()
    hardware.get_device_facts()
    hardware.get_dmi_facts()



# Generated at 2022-06-11 02:54:26.918777
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest.mock as mock
    m = mock.mock_open()
    # kstat output
    mock_out = 'unix:0:system_misc:boot_time    1548249689'
    with mock.patch('ansible.module_utils.facts.hardware.sunos.open', m, create=True):
        m.return_value.read.return_value = mock_out
        uptime_facts = SunOSHardware.get_uptime_facts(None)
    assert (time.time() - 1548249689) == uptime_facts['uptime_seconds']

# Generated at 2022-06-11 02:54:39.023528
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    fake_module = FakeModule()

    sh = SunOSHardware(fake_module)

    # Expected Output with 2 processors (1 physical, 2 cores per)
    # 'processor': ['SUNW,UltraSPARC-III+ @ 1200MHz', 'SUNW,UltraSPARC-III+ @ 1200MHz'],
    expected_cpu_facts = {
        'processor_cores': 2,
         'processor_count': 2,
         'processor': ['SUNW,UltraSPARC-III+ @ 1200MHz', 'SUNW,UltraSPARC-III+ @ 1200MHz']
    }

    # We don't really care about the output of the test, just that it doesn't throw an exception
    # Caught SystemExit: False
    #
    # print "Expected Output \n%s" % expected_cpu_facts
    # print "

# Generated at 2022-06-11 02:54:51.183004
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    collected_facts = {'platform': 'SunOS', 'ansible_machine': 'i86pc'}
    hardware_obj = SunOSHardware(collected_facts=collected_facts)

# Generated at 2022-06-11 02:55:02.856971
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Arrange
    test_module = type('module', (object,), {})()
    test_module.run_command = MagicMock(return_value=(0, '', ''))
    test_SunOSHardware = SunOSHardware(test_module)

    parameter_solaris9 = {'ansible_machine': 'sun4u', 'ansible_processor': ['SUNW,Ultra-4']}
    parameter_solaris10 = {'ansible_machine': 'i86pc', 'ansible_processor': ['Intel(r) Core(tm) i7-2600 CPU @ 3.40GHz']}
    parameter_solaris11 = {'ansible_machine': 'i86pc', 'ansible_processor': ['Intel(r) Core(tm) i7-2600 CPU @ 3.40GHz']}
    parameter

# Generated at 2022-06-11 02:55:08.766213
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    SunOSHardware.get_memory_facts should return the correct value for
    'memtotal_mb' and 'swaptotal_mb'
    """

    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    memtotal_mb = hardware.get_memory_facts()['memtotal_mb']

    status, output, err = module.run_command('/usr/sbin/prtconf')

    assert( memtotal_mb == int(module.from_json(output)[0]['value']['MEMORY size (MB)']) )

# Generated at 2022-06-11 02:55:19.699885
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ModuleStub(object):
        run_command_splits = [
            ['kstat', 'cpu_info'],
            ['prtconf'],
            ['swap', '-s'],
            ['kstat', '-p', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size',
             'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors',
             'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request'],
        ]

    mod = ModuleStub()

    def run_command(c):
        return 0, mod.run_command_splits

# Generated at 2022-06-11 02:55:38.873929
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    values = {
        'ansible_machine': 'i86pc'
    }

    collector = SunOSHardwareCollector()
    result = collector.get_cpu_facts(values)

    assert result['processor_count'] == 2
    assert result['processor_cores'] == 2
    assert 'Intel' in result['processor'][0]



# Generated at 2022-06-11 02:55:50.247104
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:55:58.532439
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModule(argument_spec={},supports_check_mode=True)
    hardwareCollector = SunOSHardwareCollector(module=module)
    assert hardwareCollector.platform == 'SunOS'
    assert hardwareCollector.required_facts == set(['platform'])
    assert hardwareCollector.__dict__['fact_class'] == SunOSHardware
    assert hardwareCollector.__dict__['fact_class'].__dict__['platform'] == 'SunOS'
    assert hardwareCollector.__dict__['fact_class'].__dict__['required_facts'] == set(['platform'])

# Generated at 2022-06-11 02:56:05.367188
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    mocked_class = SunOSHardware(None)


# Generated at 2022-06-11 02:56:16.983950
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self, *args, **kwargs):
            self.params = {
                'path': 'default'
            }

        def run_command(self, command, *args, **kwargs):
            if command[0] == '/usr/bin/kstat':
                return (0, 'unix:0:system_misc:nphysmem         8589934592', None)
            elif command[0] == '/usr/sbin/swap':
                return (0, 'Total:    7995872k bytes allocated + 434444k reserved = 8430316k used, 16951892k available', None)
            else:
                return (0, 'Memory size: 16384 Megabytes', None)


# Generated at 2022-06-11 02:56:22.581668
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()

    sunoshw = SunOSHardware(module)
    cpu_facts = sunoshw.get_cpu_facts()

    # The cpu_facts dict should have processor_count and processor_cores
    assert ('processor_count' in cpu_facts and 'processor_cores' in cpu_facts)

    # The cpu_facts dict should have processor_count and processor_cores
    assert ('processor_count' in cpu_facts and 'processor_cores' in cpu_facts)


# Generated at 2022-06-11 02:56:33.864910
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    info = """System Configuration: Oracle Corporation sun4v\nSPARC T6340 Server\n\nBIOS Configuration: Oracle Corporation SUN T6340.2009.05.22.10.47.57\n\n"""

    module = AnsibleModule(argument_spec={})

    hardware = SunOSHardware(module)
    hardware_facts = hardware.get_dmi_facts()
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SPARC T6340 Server'

    hardware_facts = hardware.get_dmi_facts()
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SPARC T6340 Server'

# Generated at 2022-06-11 02:56:45.275001
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:52.989439
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:01.553361
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    data = {
        'ansible_machine': 'sparcv9',
    }

    sut = SunOSHardware(data)

    rc, out, err = sut.module.run_command("/usr/sbin/prtconf")
    out = re.sub("/bin/kstat.*", "", out)
    rc2, out2, err2 = sut.module.run_command("/usr/sbin/swap -s")

    facts = sut.get_memory_facts()

    assert facts['memtotal_mb'] == int(re.sub("/bin/kstat.*", "", out).split()[2])
    assert facts['swap_allocated_mb'] == int(out2.split()[1][:-1]) // 1024
    assert facts['swap_reserved_mb'] == int

# Generated at 2022-06-11 02:57:26.002715
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    module.params = {}

    hardware_obj = SunOSHardware(module)
    hardware_obj.get_memory_facts()

    assert hardware_obj.facts['memtotal_mb'] is not None
    assert hardware_obj.facts['swapfree_mb'] is not None
    assert hardware_obj.facts['swaptotal_mb'] is not None
    assert hardware_obj.facts['swap_allocated_mb'] is not None
    assert hardware_obj.facts['swap_reserved_mb'] is not None

# Generated at 2022-06-11 02:57:32.765034
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Creating a test class object of SunOSHardware
    obj = SunOSHardware(None)

    # Creating test kstat files
    os.mkdir('kstat_test')
    os.mkdir('kstat_test/unix')
    os.mkdir('kstat_test/unix/0')
    os.mkdir('kstat_test/unix/0/system_misc')
    f = open('kstat_test/unix/0/system_misc/boot_time', 'w')
    f.write('test')
    f.close()

    # Set kstat_path for the test object
    obj.module.set_module_arg('kstat_path', 'kstat_test')

    # Call

# Generated at 2022-06-11 02:57:42.315899
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockSunOSModule(object):
        def __init__(self, facts):
            self.facts = facts
            self.run_command_results = {}

        def run_command(self, args, check_rc=True, close_fds=True):
            if args == ['/usr/bin/kstat -p']:
                return (0, "unix:0:system_misc:boot_time    1548249689", '')
            if args[0] == '/usr/bin/uname' and args[1] == '-i':
                return (0, self.facts['ansible_machine'], '')
            if args == ['/usr/bin/prtdiag']:
                return (1, 'System Configuration: Sun Microsystems sun4u\n', '')

# Generated at 2022-06-11 02:57:52.529956
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts_collector = SunOSHardware(module=module)
    facts = facts_collector.populate()
    assert facts is not None
    assert 'devices' in facts
    assert 'mounts' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'system_vendor' in facts
    assert 'product_name' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-11 02:57:56.072549
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] == int(time.time() - hardware_facts['boot_time'])



# Generated at 2022-06-11 02:58:07.763071
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()
    memory_facts = hardware_facts['ansible_devices']['memory']
    cpu_facts = hardware_facts['ansible_processor']
    uptime_facts = hardware_facts['ansible_uptime_seconds']
    mounts = hardware_facts['ansible_mounts']
    assert memory_facts['memtotal_mb']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor']
    assert memory_facts['swapfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swap_allocated_mb']
    assert memory_facts['swap_reserved_mb']
    assert uptime

# Generated at 2022-06-11 02:58:15.176374
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # mock kstat output
    kstat_output = '''sderr:::Product VBOX HARDDISK\tserial
sderr:::Revision\t1
sderr:::Serial No\tVBOX
sderr:::Size\t53687091200
sderr:::Vendor\tATA
sderr:::Hard Errors\t0
sderr:::Soft Errors\t0
sderr:::Transport Errors\t0
sderr:::Media Error\t0
sderr:::Predictive Failure Analysis\t0
sderr:::Illegal Request\t0'''

    hw = SunOSHardware(dict())
    device_facts = hw.get_device_facts()


# Generated at 2022-06-11 02:58:26.047152
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:58:34.595819
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command_environ_update = {}
    # TODO: mock 'module.run_command'
    module.get_bin_path = lambda app: app
    collector = SunOSHardwareCollector(module=module)
    result = collector.collect()

    expected_keys = set(['devices',
                         'memfree_mb',
                         'memtotal_mb',
                         'mounts',
                         'processor',
                         'processor_cores',
                         'processor_count',
                         'swapfree_mb',
                         'swap_allocated_mb',
                         'swap_reserved_mb',
                         'swaptotal_mb',
                         'system_vendor',
                         'uptime_seconds',
                         'uptime_days'])
    assert expected_keys.iss

# Generated at 2022-06-11 02:58:45.429712
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.params['timeout'] = 10
    hw = SunOSHardware(module)

    # test with boot_time available
    time_spy = MagicMock(side_effect=[1548249689])
    kstat_spy = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    module.run_command = kstat_spy
    with patch('time.time', time_spy):
        uptime_facts = hw.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

    # test with boot_time unavailable

# Generated at 2022-06-11 02:59:29.177291
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    mocked_module = Mock()
    mocked_module.run_command.return_value = 0, "System Configuration: VMware, Inc. VMware Virtual Platform", ""
    system = SunOSHardware(mocked_module)
    dmi_facts = system.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert dmi_facts['system_vendor'] == "VMware, Inc."
    assert dmi_facts['product_name'] == "VMware Virtual Platform"


# Generated at 2022-06-11 02:59:36.121597
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create a mock of a module to pass to the module.run_command() method
    # We will need to make sure that we feed the module the correct values
    # as SunOSHardware will be calling the module.run_command() method.
    class MockModule(object):

        def __init__(self):
            self.run_command_environ_update = None

        def run_command(self, args):
            if args[0] == "/usr/sbin/prtconf":
                # Prepare the mocked output of the prtconf command
                mock_out = "Memory size: 512 Megabytes\n"

# Generated at 2022-06-11 02:59:40.391096
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware({'module_setup': True})
    hardware._module.run_command = lambda x: (0, 'Memory size: 8192 Megabytes', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192


# Generated at 2022-06-11 02:59:45.562324
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    module.platform = 'SunOS'

    hardware = SunOSHardware(module=module)

    # See the comments for this method for what the expected output should be.
    output = hardware.get_dmi_facts()

    assert 'system_vendor' in output
    assert 'product_name' in output



# Generated at 2022-06-11 02:59:57.627009
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock(PARAMS={})
    sunos_obj = SunOSHardware(module)

    sunos_obj.module.run_command = run_command_mock
    sunos_obj.get_device_facts()

    assert sunos_obj.device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert sunos_obj.device_facts['devices']['sd0']['revision'] == '1.0'
    assert sunos_obj.device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert sunos_obj.device_facts['devices']['sd0']['size'] == '50 GB'

# Generated at 2022-06-11 03:00:03.118830
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware_mbs = SunOSHardware()
    cmd = hardware_mbs.module.run_command
    hardware_mbs.module.run_command = mock_run_command
    assert hardware_mbs.get_memory_facts() == {'swapfree_mb': 5120, 'swaptotal_mb': 5211, 'swap_reserved_mb': 991, 'swap_allocated_mb': 5211, 'memtotal_mb': 16384}
    hardware_mbs.module.run_command = cmd


# Generated at 2022-06-11 03:00:15.068461
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # Create an instance of the get_uptime_facts test class
    test = SunOSHardware(dict())

    # Create a kstat output string that matches the real output at the time of writing
    kstat_output = "unix:0:system_misc:boot_time    1548249689"

    # Set the modules run_command return values to the kstat output string
    test.module.run_command.return_value = (0, kstat_output, "")

    # Determine the number of seconds that have passed since the kstat
    # command was ran
    seconds_that_have_passed = int(time.time() - int(kstat_output.split('\t')[1]))

    # Call the get_uptime_facts method
    # This should run kstat and return the number of seconds since the last reboot
   

# Generated at 2022-06-11 03:00:21.386565
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import ansible.module_utils.facts.hardware.sunos as sunfacts
    import functools

    test_obj = SunOSHardware(sunfacts)
    mock_run_command = functools.partial(run_command, test_obj)

    output_list = mocked_output_list
    test_obj.module.run_command = mock_run_command
    devices = test_obj.get_device_facts()

    assert devices['devices'] == expected_result


# Generated at 2022-06-11 03:00:32.200658
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    # Create a SunOSHardware object
    hardware_obj = SunOSHardware(module)
    # Command to be executed
    command = ["/usr/bin/uname", "-i"]
    # Output of command
    output = "i86pc"
    # Input parameters
    params = True
    # Create an AnsibleModuleMock which returns the platform
    module_result = AnsibleModuleMock(platform=output, params=params)
    # Set the module result of class SunOSHardware
    hardware_obj.module = module_result
    # Hardware object of class SunOSHardware
    hw_object = SunOSHardware(hardware_obj)

    assert hw_object.get_dmi_facts() == {"system_vendor": "Oracle Corporation", "product_name": "VirtualBox"}

# Generated at 2022-06-11 03:00:43.091491
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = None
    sunos_hw = SunOSHardware(module)

    # If a kstat error happens during get_device_facts, then devices dictionary is
    # empty.
    def run_command(cmd, check_rc=True, close_fds=True, executable=None,
                    data=None, binary_data=False):
        rc = 0
        out = "sderr:0:sd0,err:Hard Errors     0"
        err = ""
        return rc, out, err

    module.run_command = run_command
    sunos_hw_devices = sunos_hw.get_device_facts()
    assert sunos_hw_devices['devices'] == {}

    # If no kstat error happens, then the devices dictionary will contain a
    # dictionary for each device in the system, where the key is the device name

# Generated at 2022-06-11 03:02:03.172293
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class ModeuleMock():
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def run_command(self, cmd, check_rc=True):
            return self.run_command_result
    class OptionsMock():
        def __init__(self, become, become_user):
            self.become = become
            self.become_user = become_user


# Generated at 2022-06-11 03:02:12.357865
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    hardware._module = Mock()
    hardware._module.run_command = MagicMock()
    hardware._module.run_command.return_value = (0,
        'System Configuration: VMware, Inc. VMware Virtual Platform',
        '')

    assert hardware.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

    hardware._module.run_command.return_value = (0,
        'System Configuration:    Sun Microsystems  sun4u',
        '')

    assert hardware.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}


# Generated at 2022-06-11 03:02:22.158253
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    # Mock modules
    basic._ANSIBLE_ARGS = basic.AnsibleFailJson = basic.AnsibleModule = None
    import ansible.module_utils.facts.hardware.sunos
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector

    # Mock get_file_content
    ansible.module_utils.facts.utils.get_file_content = lambda x: None

    # Mock run_command

# Generated at 2022-06-11 03:02:25.344293
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()

    facts = SunOSHardware(module).get_dmi_facts()

    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'Sun Fire V445'


# Generated at 2022-06-11 03:02:35.263213
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = open_mock()
    hardware = SunOSHardware(module=module)

    mock_cpuinfo = {
        'ansible_machine': 'i86pc',
    }


# Generated at 2022-06-11 03:02:39.855380
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware()
    meminfo = facts.get_memory_facts()
    assert sorted(meminfo.keys()) == ['memtotal_mb', 'swap_allocated_mb', 'swap_reserved_mb', 'swapfree_mb', 'swaptotal_mb']

# Generated at 2022-06-11 03:02:48.581546
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)

    rc, out, err = hw.module.run_command("/usr/bin/kstat cpu_info")
    hw.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    cpu_facts = hw.get_cpu_facts()

    assert_true(isinstance(cpu_facts, dict))
    assert_true('processor_count' in cpu_facts)
    assert_true('processor_cores' in cpu_facts)
    assert_true('processor' in cpu_facts)
    assert_equals(len(cpu_facts), 3)



# Generated at 2022-06-11 03:02:55.991119
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert cpu_facts['processor'] == cpu_facts['ansible_processor']
    assert cpu_facts['processor_count'] == cpu_facts['ansible_processor_count']
    assert cpu_facts['processor_cores'] == cpu_facts['ansible_processor_cores']
    assert cpu_facts['processor_threads_per_core'] == cpu_facts['ansible_processor_threads_per_core']
    assert cpu_facts['processor_socket_destination'] == cpu_facts['ansible_processor_socket_destination']



# Generated at 2022-06-11 03:03:06.502902
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    '''
    SunOSHardware: Test get_dmi_facts method
    '''
    platform_sbin = '/usr/platform/SUNW,Sun-Fire-T200/sbin'
    prtdiag_path = '/usr/platform/SUNW,Sun-Fire-T200/sbin/prtdiag'
    prtdiag_output = 'System Configuration: Oracle Corporation Sun Fire T200   '
    if_module_no_fail_mock = {}
    if_module_no_fail_mock['run_command'] = lambda command, check_rc=True: (0, prtdiag_output, "")
    if_module_no_fail_mock['get_bin_path'] = lambda name, opt_dirs=None: prtdiag_path


# Generated at 2022-06-11 03:03:12.158767
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    date_command = ". /usr/lib/sh/date.sh ; date +%s"
    module = AnsibleModule(argument_spec=dict())
    uptime_seconds = int(module.run_command(date_command)[1]) - 1574485288
    uptime_facts = {'devices': {},
                    'uptime_seconds': uptime_seconds}
    sunos = SunOSHardware(module)
    facts = sunos.get_uptime_facts()
    assert facts == uptime_facts
