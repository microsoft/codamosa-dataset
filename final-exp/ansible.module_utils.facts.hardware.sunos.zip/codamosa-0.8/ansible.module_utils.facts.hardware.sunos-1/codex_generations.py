

# Generated at 2022-06-11 02:54:07.868953
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    fact_module = SunOSHardware()
    cmd = ["/usr/bin/kstat", "-p", "unix:0:system_misc:boot_time"]
    fact_module.module.run_command = lambda x: (0, "unix:0:system_misc:boot_time\t1548249689", None)
    expected_uptime_facts = {'uptime_seconds': int(time.time() - 1548249689)}
    uptime_facts = fact_module.get_uptime_facts()
    assert(fact_module.module.run_command.call_args[0][0] == cmd)
    assert(uptime_facts == expected_uptime_facts)


# Generated at 2022-06-11 02:54:13.609284
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule(object):
        def run_command(self, cmd, check_rc=True):
            return 0, '', ''

    module = MockModule()
    hardware = SunOSHardware(module)
    devices = hardware.get_device_facts().get('devices')
    assert len(devices) == 0

# Generated at 2022-06-11 02:54:25.379072
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = ansible_fake

    # Test with C locale
    locale = get_best_parsable_locale(module)
    module.run_command_environ_update = {'LANG': locale, 'LC_ALL': locale, 'LC_NUMERIC': locale}

    sunos_hardware = SunOSHardware(module)

    # Test hardware in English locale
    facts = sunos_hardware.populate()

    assert facts['processor'] == ['SPARC-Enterprise-T5120 @ 1600MHz']
    assert facts['processor_cores'] == 2
    assert facts['processor_count'] == 2
    assert facts['memtotal_mb'] == 16384
    assert facts['swaptotal_mb'] == 32
    assert facts['swapfree_mb'] == 31
    assert facts['swap_allocated_mb']

# Generated at 2022-06-11 02:54:34.629774
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4v', None))
    module.get_bin_path = MagicMock(return_value="/usr/platform/sun4u/sbin/prtdiag")
    hardware = SunOSHardware(module)

    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4v'


# Generated at 2022-06-11 02:54:43.486727
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = get_ansible_module()

    # Set up a time object for use with mocks
    time_obj = time.time

    # Let's mock the time.time() function
    # time.time() will always return '100'
    # see https://docs.python.org/3/library/unittest.mock.html#unittest.mock.Mock.return_value
    # and https://www.blog.pythonlibrary.org/2016/07/07/python-201-what-is-mocking/
    # for more information
    time.time = Mock(return_value=100)

    # Test the case when /usr/bin/kstat returns an error code
    module.run_command = Mock(return_value=(1, "", ""))
    hw = SunOSHardware(module)
    result

# Generated at 2022-06-11 02:54:47.141721
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector({'platform': 'SunOS'})
    assert isinstance(x._fact_class, SunOSHardware)
    assert x._platform == 'SunOS'
    assert set(x.required_facts) == set(['platform'])

# Generated at 2022-06-11 02:54:58.634256
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    '''
    Unit test for SunOSHardware method get_cpu_facts
    '''
    # Create a class for testing
    class ModuleMock:
        run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}


# Generated at 2022-06-11 02:55:08.213650
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create a test resource object
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    # Create an instance of SunOSHardware class
    sunos = SunOSHardware(module)

    # Populate method for class SunOSHardware
    output = sunos.populate()

    # Assert the output value
    assert output['ansible_devices']
    assert output['ansible_devices']['sd0']
    assert output['ansible_devices']['sd0']['product']
    assert output['ansible_devices']['sd0']['revision']
    assert output['ansible_devices']['sd0']['serial']
    assert output['ansible_devices']['sd0']['size']

# Generated at 2022-06-11 02:55:19.151555
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('AnsibleModule', (), dict(run_command=lambda *args, **kwargs: (0, '', '')))


# Generated at 2022-06-11 02:55:30.248851
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = module_run_command
    module.get_bin_path = module_get_bin_path

    sunOS_hw = SunOSHardware(module=module)
    # mock the module.run_command
    sunOS_hw.run_command = module_run_command
    cpu_facts = sunOS_hw.get_cpu_facts()
    dmi_facts = sunOS_hw.get_dmi_facts()
    memory_facts = sunOS_hw.get_memory_facts()
    device_facts = sunOS_hw.get_device_facts()
    uptime_facts = sunOS_hw.get_uptime_facts()
    mount_facts = sunOS_hw.get_mount_facts()

# Generated at 2022-06-11 02:55:57.203721
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import sys
    if sys.version_info[0] > 2:
        from types import SimpleNamespace as namespace
    else:
        from argparse import Namespace as namespace

    module = namespace()

    module.run_command = lambda x: (0, 'System Configuration: QEMU SunOS\n', 'out')
    module.get_bin_path = lambda x: 'data'

    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts.get('system_vendor') == 'QEMU'
    assert dmi_facts.get('product_name') == 'SunOS'



# Generated at 2022-06-11 02:56:02.132846
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Unit test for method get_dmi_facts of class SunOSHardware"""
    example_string = 'System Configuration: VMware, Inc. VMware Virtual Platform\n'
    hardware = SunOSHardware()

    result = hardware.get_dmi_facts(example_string)
    expected = {
        'system_vendor': 'VMware, Inc.',
        'product_name': 'VMware Virtual Platform'
    }
    assert result == expected

# Generated at 2022-06-11 02:56:13.245821
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    test_solaris = 'a'
    test_unix_boot_time = '1548249689'
    test_time = time.time()
    test_uptime_seconds = test_time - float(test_unix_boot_time)

    def mock_run_command(x, *args, **kwargs):
        return 0, test_solaris, ''

    def mock_time():
        return test_time

    mock_subprocess = mock.Mock()
    mock_subprocess.run_command.side_effect = mock_run_command

    mock_time_time = mock.Mock()
    mock_time_time.time.side_effect = mock_time

    uptime_facts = {}

# Generated at 2022-06-11 02:56:19.359405
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = None
    platform = 'SunOS'
    expected_dmi_facts = {'system_vendor': 'Sun', 'product_name': 'SUNW,SPARC-Enterprise'}

    sunos_hardware_collector = SunOSHardwareCollector(module)
    dmi_facts = sunos_hardware_collector.get_dmi_facts(platform, None)

    assert dmi_facts == expected_dmi_facts

# Generated at 2022-06-11 02:56:31.035971
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Make sure SunOSHardware is collecting
    the right cpu facts.
    """

# Generated at 2022-06-11 02:56:42.270049
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # given
    module = Mock()


# Generated at 2022-06-11 02:56:51.363669
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:55.971983
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    '''
    This function unit tests the constructor of class SunOSHardwareCollector.
    Because it is a class, no function parameters are passed in.
    '''
    # Check that the expected collection class is used
    facts_collector = SunOSHardwareCollector()
    assert facts_collector._fact_class == SunOSHardware

# Generated at 2022-06-11 02:56:58.428872
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert len(cpu_facts['processor']) == cpu_facts['processor_count']

# Generated at 2022-06-11 02:57:00.029750
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    assert hardware.get_memory_facts() == {'memtotal_mb': 32768}


# Generated at 2022-06-11 02:57:27.445661
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockSunOSModule(object):
        def __init__(self):
            self.run_command_results = [(0, '1548249689', ''), (1, '', '')]
            self.run_command_calls = 0

        def run_command(self, args, **kwargs):
            # "kstat -p" returns boot_time,
            # if it is called first time
            if self.run_command_calls == 0:
                self.run_command_calls += 1
                return (0, '1548249689', '')
            else:
                # otherwise it returns an error
                return (1, '', '')

    class MockTime(object):
        def __init__(self):
            self.time_val = 1548249690


# Generated at 2022-06-11 02:57:31.435817
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create a new instance of SunOSHardware
    hw = SunOSHardware(module)

    hw.populate()
    assert hw.facts['system_vendor'] == 'Sun Microsystems'
    assert hw.facts['product_name'] == 'OFFBOX'



# Generated at 2022-06-11 02:57:41.362397
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    print("Test get_cpu_facts of SunOSHardware ...")


# Generated at 2022-06-11 02:57:51.331003
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        run_command_results = []
        def run_command(self, args, check_rc=True):
            res = MockModule.run_command_results.pop(0)
            return (res['rc'], res['out'], res['err'])

    class MockFactCache:
        def __init__(self):
            self.facts = {}

        def set(self, key, value):
            self.facts[key] = value

        def get(self, key, default=None):
            return self.facts.get(key, default)

    module = MockModule()
    module.run_command_results.append({'rc': 0, 'out': "1548249689", 'err': ""})
    fact_cache = MockFactCache()
    fact_cache.set('platform', 'SunOS')

# Generated at 2022-06-11 02:58:01.394481
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = MagicMock()
    SunOSHardware = SunOSHardware(module)

    testcase = [
            # input, platform, output
            (
                'output',
                {
                    'uptime_seconds': 55
                },
                0
            ),
            (
                'output',
                {},
                1
            )
    ]

    for (input, output, rc) in testcase:
        module.run_command.return_value = (rc, input, '')
        if rc != 0:
            assert SunOSHardware.get_uptime_facts() == {}
        else:
            assert SunOSHardware.get_uptime_facts() == output

# Generated at 2022-06-11 02:58:05.862626
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out = "Memory size: 2048 Megabytes"
    module = AnsibleModuleStub(out)
    hardware = SunOSHardware(module)
    memory = hardware.get_memory_facts()
    assert(memory['memtotal_mb'] == 2048)


# Generated at 2022-06-11 02:58:16.662941
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    results = dict(
        ansible_facts=dict(
            ansible_processor=['SPARC64-VI'],
            ansible_machine='sun4v',
            ansible_system_vendor='Sun Microsystems',
            ansible_product_name='T5240',
        )
    )

    # FIXME: we need to mock this to avoid test collisions on host system
    #
    #class FakeModule:
    #    def __init__(self):
    #        self.run_command = lambda cmd: (0, "Memory size: 16384 Megabytes", "")
    #
    #    def get_bin_path(self, name, opt_dirs=[]):
    #        return '/usr/sbin' + name

    #fake_module = FakeModule()
    #hw = SunOSHardware(fake_

# Generated at 2022-06-11 02:58:22.498780
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Mock module
    mock_module = type('AnsibleModule', (object,), dict(run_command=lambda args: (0, 'output', 'err')))()

    sunoshw = SunOSHardware(mock_module)
    # Expected uptime_facts will have uptime_seconds
    uptime_facts = sunoshw.get_uptime_facts()
    assert uptime_facts["uptime_seconds"]

# Generated at 2022-06-11 02:58:25.066192
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware_facts = hardware.populate()
    assert hardware_facts


# Generated at 2022-06-11 02:58:34.112199
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    facts = dict()
    output = ('System Configuration: Sun Microsystems sun4v'
              'System Configuration: VMware, Inc. VMware Virtual Platform'
              'System Configuration: Sun Microsystems sun4u'
              'System Configuration: Oracle Corporation Sun SPARC Enterprise T5270'
              'System Configuration: Oracle Corporation SPARC T5120')
    h = SunOSHardware(dict(), output)
    facts = h.get_dmi_facts()

    assert facts['system_vendor'] == "Sun Microsystems"
    assert facts['product_name'] == "sun4v"

    h = SunOSHardware(dict(), output)
    facts = h.get_dmi_facts()

    assert facts['system_vendor'] == "VMware, Inc."
    assert facts['product_name'] == "VMware Virtual Platform"

    h = Sun

# Generated at 2022-06-11 02:59:04.075499
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:14.008253
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys

    if sys.version_info.major < 3:
        import mock
    else:
        from unittest import mock

    class MockModule():
        def __init__(self):
            self.params = {}

        def run_command(self, args):
            stdout = "unix:0:system_misc:boot_time    1548249689"
            return 0, stdout, ""

    mock_module = MockModule()
    mock_class = type('MockClass', (SunOSHardware,), {'module': mock_module})


# Generated at 2022-06-11 02:59:18.159317
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'boot_time    1548249689', None))

    hwf = SunOSHardware(module)
    facts = hwf.get_uptime_facts()

    assert facts['uptime_seconds'] == int(time.time()) - 1548249689


# AnsibleModule test object

# Generated at 2022-06-11 02:59:27.012950
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = get_module_mock(params={'gather_subset': '!all', 'gather_timeout': 10})
    module.run_command.return_value = (0, 'Memory size: 0x100000000', None)

    hardware_collector = SunOSHardwareCollector(module=module)
    mem_facts = hardware_collector.collect()['ansible_facts']['ansible_memtotal_mb']
    assert mem_facts == 1048576



# Generated at 2022-06-11 02:59:30.143137
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_class = SunOSHardware()

    # Check that the returned value is a dict
    assert isinstance(test_class.get_dmi_facts(), dict)

# Generated at 2022-06-11 02:59:38.350905
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    class temp_module():

        def __init__(self):
            self.run_command_environ_update = None
            self.params = None
            self.facts = None
            self.tmpfile = None

        def fail_json(self, **args):
            raise AssertionError(args)

        def get_bin_path(self, **args):
            return "/usr/bin/kstat"

        def run_command(self, args):
            if args[0] == "/usr/bin/kstat cpu_info":
                return 1, "module: cpu_info\nbrand V-Series\nchip_id 1\nclock_MHz      3275\n", None

# Generated at 2022-06-11 02:59:50.114631
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 03:00:00.932732
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = type('', (), {})
    module.run_command = lambda *args, **kwargs: ('', '', '')
    module.get_bin_path = lambda *args, **kwargs: ('', '', '')
    module.get_file_content = lambda *args, **kwargs: ('', '', '')
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C'}

    # Create an object of type SunOSHardware
    sunos_hardware_obj = SunOSHardware(module)

    # Define the facts
    facts = {
        'ansible_machine': 'i86pc',
        'platform': 'SunOS'
    }

    # Call the method populate
    sunos_hardware_obj.populate(facts)

# Generated at 2022-06-11 03:00:12.346535
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Function to test  the get_device_facts method of SunOSHardware class
    """

    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

    class MockRunner:
        """
        A small mock class to simulate a module.run_command
        """

        def __init__(self):
            self.cmd = []
           

# Generated at 2022-06-11 03:00:21.623304
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    prtdiag_path = module.get_bin_path("prtdiag")
    if 'PathNotFound' in prtdiag_path:
        prtdiag_path = '/usr/sbin/prtdiag'
    dmi_output = '''System Configuration: Oracle Corporation sun4v
Sun Microsystems, Inc. SUN T5220
  Serial No.  123456789
  System PROM Revision   OBP 4.30.3 2010/07/07 18:01
'''
    module.run_command.return_value = (0, dmi_output, '')

    hw = SunOSHardware()
    dmi_facts = hw.get_dmi_facts()

    assert dmi

# Generated at 2022-06-11 03:01:05.654136
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test the method get_dmi_facts of class SunOSHardware"""

    module = FakeAnsibleModule()
    example_out_data = {
        'product': 'SUN Fire T1000',
        'system_vendor': 'Sun Microsystems',
    }
    module.run_command_environ_update = {}
    hardware = SunOSHardware(module)

    class FakeFile:
        """Fake file descriptor"""
        def __init__(self, data):
            self.data = data

        def readlines(self):
            return self.data

    data = ['/usr/bin/prtconf -vp']
    for key, value in example_out_data.items():
        data.append('%s: "%s"' % (key, value))


# Generated at 2022-06-11 03:01:09.365544
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware({})
    facts = hardware.get_memory_facts()

    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0


# Generated at 2022-06-11 03:01:11.909387
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware_obj = SunOSHardware(module=None)
    cpu_facts_result = hardware_obj.get_cpu_facts()
    assert 'processor' in cpu_facts_result

# Generated at 2022-06-11 03:01:21.853135
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    test = SunOSHardware(TestModule([(0, '''System Configuration: VMware, Inc.      VMware Virtual Platform
''', '')]))
    assert test.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

# Generated at 2022-06-11 03:01:26.553232
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Instantiate SunOSHardware class
    test_obj = SunOSHardware()

    # Test method of SunOSHardware class
    actual_result = test_obj.get_memory_facts()

    expected_result = {
            'swap_reserved_mb': 0,
            'swap_allocated_mb': 0,
            'swapfree_mb': 0,
            'swaptotal_mb': 0
        }

    assert actual_result == expected_result



# Generated at 2022-06-11 03:01:37.091261
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 03:01:47.046971
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:01:57.394452
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    # Setup
    m = type('Module', (object,), {'run_command': run_command, 'get_bin_path': get_bin_path})
    x = SunOSHardware(m)

    # Test method populate of class SunOsHardware
    cpu_facts = {
        'processor': ['QEMU Virtual CPU version 1.0'],
        'processor_count': 1,
        'processor_cores': 'NA'
    }

    memory_facts = {
        'memtotal_mb': 1024,
        'swapfree_mb': 1532,
        'swaptotal_mb': 2047,
        'swap_allocated_mb': 1024,
        'swap_reserved_mb': 1024
    }


# Generated at 2022-06-11 03:02:05.004527
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module.run_command_environ_update = {}

    hardware.module.run_command.return_value = (0, 'Memory size: 32768 Megabytes', '')
    hardware.module.run_command.return_value = (0, 'bogus\n', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 32768

    hardware.module.run_command.return_value = (1, '', '')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 0


# Generated at 2022-06-11 03:02:07.383049
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    actual = SunOSHardware().get_cpu_facts()
    assert actual['processor_cores'] > 0
    assert actual['processor_count'] > 0