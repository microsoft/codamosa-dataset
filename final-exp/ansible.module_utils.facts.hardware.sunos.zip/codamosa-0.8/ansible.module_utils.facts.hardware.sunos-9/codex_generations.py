

# Generated at 2022-06-11 02:54:07.140617
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:54:20.018763
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import sys
    import os
    import tempfile
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware as sunos

    module = os.path.join(os.path.dirname(__file__),
                          '../../../lib/ansible/module_utils/facts/hardware/sunos.py')
    if module not in sys.path:
        sys.path.append(module)

    with tempfile.NamedTemporaryFile('w+') as meminfo_file:
        meminfo_file.write('Memory size: 256 Megabytes\n')
        meminfo_file.flush()

        hardware_module = sunos(meminfo_file.name)
        memory_facts = hardware_module.get_memory_facts()

        meminfo_file.close()


# Generated at 2022-06-11 02:54:27.646948
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    device_facts = hardware.get_device_facts()

    assert sorted(device_facts['devices']['sda'].keys()) == sorted([
        'hard_errors',
        'illegal_request',
        'media_errors',
        'predictive_failure_analysis',
        'product',
        'revision',
        'serial',
        'size',
        'soft_errors',
        'transport_errors',
        'vendor',
    ])

# Generated at 2022-06-11 02:54:39.576072
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_file_path = os.path.join(os.path.dirname(__file__), 'prtdiag.output')
    with open(test_file_path) as f:
        prtdiag_output = f.read()

    sunos_hardware_obj = SunOSHardware('/usr/sbin', {'ansible_machine': 'i86pc'})
    # Override the ._get_command_output method with mock output
    sunos_hardware_obj._get_command_output = Mock(return_value = prtdiag_output)
    cpu_facts = sunos_hardware_obj.get_cpu_facts()

    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 8

# Generated at 2022-06-11 02:54:46.612689
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.collector import get_collector

    facts = Facts(
        {
            'filter': '*',
            'gather_subset': '!all',
            'gather_timeout': 5
        }
    )

    facts.populate()

    assert facts.ansible_facts['hardware']['devices'] == {}



# Generated at 2022-06-11 02:54:52.908254
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = type('test', (object,), {'run_command': lambda x: (0, "Memory size: 8192 Megabytes", '')})()
    test_class = type('test', (object,), {'module': test_module})
    hardware = SunOSHardware(test_class)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192



# Generated at 2022-06-11 02:54:55.532407
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sunoshw = SunOSHardwareCollector()
    assert sunoshw._fact_class == SunOSHardware
    assert sunoshw._platform == 'SunOS'

# Generated at 2022-06-11 02:55:06.182067
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Setup the class for testing
    sunos_hardware = SunOSHardware()

    # Case 1. No output from 'kstat'
    sunos_hardware.module.run_command.return_value = (0, "", "")
    cpu_facts = sunos_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == []
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 0

    # Case 2. Output from 'kstat' processor

# Generated at 2022-06-11 02:55:15.193904
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hw = SunOSHardware()
    # The value returned by os.stat("/dev/kmem").st_mtime at time of writing
    # the test.
    hw.module.run_command.return_value = (0, "unix:0:system_misc:boot_time    1548249689", "")

    actual = hw.get_uptime_facts()

    # The value of time.time() at the time of writing the test.
    expected = { 'uptime_seconds': 1557482443 }

    assert actual == expected

# Generated at 2022-06-11 02:55:25.888918
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class MockModule:
        run_command = lambda self, cmd: (0, "module: SUNW,UltraSPARC-IV\n"
            "implementation: SPARC-V9\n"
            "clock_MHz: 800\n"
            "chip_id: 0\n"
            "module: SUNW,UltraSPARC-IV\n"
            "implementation: SPARC-V9\n"
            "clock_MHz: 800\n"
            "chip_id: 0", '')

    facts = SunOSHardware()
    facts.module = MockModule()
    result = facts.get_cpu_facts()
    assert result['processor'] == ['SPARC-V9 @ 800MHz', 'SPARC-V9 @ 800MHz']
    assert result['processor_cores'] == 2
    assert result['processor_count']

# Generated at 2022-06-11 02:55:48.300357
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    lines = []
    lines.append("System Configuration: VMware, Inc. VMware Virtual Platform")
    SunOS_hw = SunOSHardware()
    dmi_facts = SunOS_hw.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'


# Generated at 2022-06-11 02:55:55.226275
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware({'platform': 'SunOS'})

    hardware.module = MockModule()
    hardware.module.run_command.return_value = (0, "", "")
    hardware.collector.module = hardware.module
    facts = hardware.collector.collect()

    # Check that required facts are present
    assert 'facts' in facts
    facts = facts['facts']
    assert 'ansible_processor' in facts

# Generated at 2022-06-11 02:56:03.696628
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {
        'system_vendor': 'Sun Microsystems',
        'product_name': 'Sun Fire T1000'
    }

    prtdiag_output = (
        'System Configuration: Sun Microsystems  Sun Fire T1000\n'
        'System clock frequency: 400 MHz\n'
        'Memory size: 8192 Megabytes\n'
        '--------------------------------------------------\n'
        'Processor   CPU  Module      MHz    Impl.  Mask\n'
        'SYS     MB/s  DMA  MB/s   Interrupts\n'
        '---------------------------------------------'
    )

    hardware = SunOSHardware()

    hardware.module.run_command = FakeRunCommand(
        (0, prtdiag_output, None),
    )

    result = hardware.get_dmi_

# Generated at 2022-06-11 02:56:15.428965
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    if not PARSERS:
        module.fail_json(msg=missing_required_lib('parsers'))
    hardware = SunOSHardware(module=module)
    hardware.populate()
    facts = hardware.get_facts()

    # FIXME: how to test that 'swap_reserved_mb' is populated?
    # FIXME: how to test that 'swap_allocated_mb' is populated?

    assert facts['devices']
    assert facts['devices']['sd0']
    assert facts['mounts']
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts

# Generated at 2022-06-11 02:56:23.907004
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """Unit test for method 'get_cpu_facts()' of class SunOSHardware"""
    import ansible.module_utils.facts.processor.sunos
    import ansible.module_utils.facts.hardware.sunos
    import ansible.module_utils.facts.system.sunos

    # Create instance of SunOSHardware class
    sun_hw = SunOSHardware(ansible_module=None)

    # Create instance of SunOSProcessorFact class
    sun_proc = ansible.module_utils.facts.processor.sunos.SunOSProcessorFact(ansible_module=None)

    # Create instance of SunOSSystemFact class
    sun_sys = ansible.module_utils.facts.system.sunos.SunOSSystemFact(ansible_module=None)

    # Create instance of SunOSTimeZoneFact class (to be

# Generated at 2022-06-11 02:56:34.484095
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    mock_module = MockModule()
    mock_module.run_command = Mock(return_value=(0, 'clock_MHz\t1600\n', ''))
    hardware = SunOSHardware(mock_module)

    # Check that facts are created
    result = hardware.get_cpu_facts()
    assert 'processor' in result
    assert result['processor'] == ['']

    # Check that facts are updated
    mock_module.run_command = Mock(return_value=(0, 'implementation\ti386\n', ''))
    result = hardware.get_cpu_facts()
    assert 'processor' in result
    assert result['processor'] == ['i386 @ 1600MHz']

# Generated at 2022-06-11 02:56:45.088710
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule()

    # Mock kstat
    kstatMock = MagicMock(return_value=(0, 'sderr:0:sd0,err:Product VBOX HARDDISK\nsderr:0:sd0,err:Size    53687091200\n', ''))

    # Mock run_command
    module.run_command = kstatMock

    # Setup
    sh = SunOSHardware(module)

    # Execute
    result = sh.get_device_facts()

    # Verify
    assert result['devices']['sd0']['size'] == '5.0G'
    assert result['devices']['sd0']['product'] == 'VBOX HARDDISK'



# Generated at 2022-06-11 02:56:52.879241
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    s = SunOSHardware()

    # Test Oracle Corporation
    system_conf = "System Configuration: Oracle Corporation sun4v"
    dmi_facts = {}
    dmi_facts = s.get_dmi_facts()
    assert dmi_facts.get('system_vendor') == 'Oracle Corporation'
    assert dmi_facts.get('product_name') == 'sun4v'

    # Test Sun Microsystems
    system_conf = "System Configuration: Sun Microsystems sun4v"
    dmi_facts = {}
    dmi_facts = s.get_dmi_facts()
    assert dmi_facts.get('system_vendor') == 'Sun Microsystems'
    assert dmi_facts.get('product_name') == 'sun4v'

    # Test VMware, Inc.

# Generated at 2022-06-11 02:56:59.363632
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    For testing, we mock the run_command method of AnsibleModule, which otherwise depends on a running system.
    We also mock the time module, because the current time is, of course, not deterministic.
    """
    import ansible.module_utils.basic
    import time

    class MockAnsibleModule():

        class MockRunCommand():
            def __init__(self):
                self.call_count = 0
                self.calls = []

            def __call__(self, *args, **kwargs):
                self.call_count += 1
                self.calls.append(args)
                return 0, 'unix:0:system_misc:boot_time    1548249689', ""

        run_command = MockRunCommand()

    class MockTimeModule():
        def __init__(self):
            self

# Generated at 2022-06-11 02:57:08.330575
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:32.503537
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    my_facts = SunOSHardware()

    data = """System Configuration: Sun Microsystems sun4u
        Memory size: 16384 Megabytes
        System Peripherals (Software Nodes):
                SUNW,Ultra-Enterprise
                SUNW,UltraSPARC-IIi-Engine#0
                SUNW,UltraSPARC-IIi-Engine#1
                SUNW,pci-ide
                SUNW,pci-ide
                SUNW,pci-ide"""

    out = data.splitlines()
    test_list = [
        {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'},
        {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}
    ]

# Generated at 2022-06-11 02:57:42.093854
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeModule()
    hardware = SunOSHardware(module)

    # Test with prtdiag output that matches the product and vendor regexps.
    rc, out, err = module.run_command('cat test/unit/ansible_collections/ansible/builtin/tests/unittests/prtdiag_match.txt')
    facts = hardware.get_dmi_facts()

    assert facts['system_vendor'] == 'QEMU'
    assert facts['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'

    # Test with prtdiag output that does not match the product and vendor regexps.

# Generated at 2022-06-11 02:57:46.244918
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunoshardware = SunOSHardware({})
    dmi_facts = sunoshardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == "QEMU"
    assert dmi_facts['product_name'] == "Standard PC (i440FX + PIIX, 1996)"

# Generated at 2022-06-11 02:57:57.094986
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-11 02:58:02.565032
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Create a SunOSHardwareCollector object for testing
    sunos_hw_collector = SunOSHardwareCollector()

    # Check the values of the members of the object that was just created
    assert sunos_hw_collector._fact_class == SunOSHardware
    assert sunos_hw_collector._platform == 'SunOS'



# Generated at 2022-06-11 02:58:06.119148
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    SunOSHardware_instance = SunOSHardware(module)
    SunOSHardware_instance.populate()
    assert SunOSHardware_instance.data

# Generated at 2022-06-11 02:58:13.888093
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import json
    import unittest

    data = {
        "sderr:::Hard Errors": "0",
        "sderr:::Illegal Request": "6",
        "sderr:::Media Error": "0",
        "sderr:::Predictive Failure Analysis": "0",
        "sderr:::Product": "VBOX HARDDISK",
        "sderr:::Revision": "1.0",
        "sderr:::Serial No": "VB0ad2ec4d-074a",
        "sderr:::Size": "53687091200",
        "sderr:::Soft Errors": "0",
        "sderr:::Transport Errors": "0",
        "sderr:::Vendor": "ATA"
    }


# Generated at 2022-06-11 02:58:18.223457
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.sunos
    uptime_facts = ansible.module_utils.facts.hardware.sunos.SunOSHardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-11 02:58:25.698329
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule({})
    module.run_command = Mock(return_value=(0, "", ""))
    module.get_bin_path = Mock(return_value='/usr/sbin/prtconf')
    sunoshw = SunOSHardware('', module)
    facts = sunoshw.get_memory_facts()
    assert len(facts) == 4
    assert 'memtotal_mb' in facts
    module.run_command.assert_called_with("/usr/sbin/prtconf")

# Generated at 2022-06-11 02:58:34.399017
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware({})
    hardware.module.run_command = lambda args, check_rc=False, encoding=None, errors='strict', binary=False: (0, '', '')
    hardware.module.get_bin_path = lambda arg1, opt_dirs: ['/usr/bin/kstat']
    hardware.module.run_command_environ_update = {}

    hardware.populate()
    assert hardware.facts['devices'] == {}
    assert hardware.facts['mounts'] == [{'block_available': 0, 'block_size': 0, 'block_total': 0, 'block_used': 0, 'device': '', 'fstype': '', 'inode_available': 0, 'inode_total': 0, 'inode_used': 0, 'mount': '', 'options': ''}]

# Generated at 2022-06-11 02:59:02.511298
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class DummyModule(object):
        class Warning(object):
            def __init__(self, message):
                pass

        class RunCommandError(object):
            def __init__(self, rc, stdout, stderr):
                pass

        def warn(self, message):
            pass


# Generated at 2022-06-11 02:59:12.600992
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_cmd = '/usr/bin/kstat'

# Generated at 2022-06-11 02:59:19.969476
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class Mock(object):
        def run_command(self, _):
            return 0, sd_err_out, ''

    module = Mock()
    hw = SunOSHardware(module)

    collected_device_facts = hw.get_device_facts()
    assert collected_device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert collected_device_facts['devices']['sd0']['revision'] == '1.0'
    assert collected_device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert collected_device_facts['devices']['sd0']['size'] == '50.0G'

# Generated at 2022-06-11 02:59:27.927199
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        @classmethod
        def run_command(cls, cmd):
            if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 0, 'unix:0:system_misc:boot_time\t1548249689', None
            raise Exception()

    obj = SunOSHardware()

    uptime_facts = obj.get_uptime_facts(MockModule())
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:59:37.239799
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:48.959685
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Run a test for class get_dmi_facts.
    """

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFileCollector

    class TestModule(object):
        def __init__(self):
            pass
        def get_bin_path(self, executable, opt_dirs=[]):
            return executable
        def run_command(self, cmd):
            return 0, 'System Configuration:\tOracle Corporation\tsunfirev440\n', None

    class TestAnsibleModule(object):
        def __init__(self):
            self.params = {}
            self.test_module = TestModule()
            self.collector = BaseFileCollector()

    test_ansible_module = TestAnsible

# Generated at 2022-06-11 02:59:58.252959
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class DummyModule:
        def run_command(module, command):
            rc = 0
            out = 'System Configuration: Oracle Corporation sun4v'
            err = ''
            return rc, out, err
    class DummyFacts:
        def populate(facts):
            facts['ansible_machine'] = 'i86pc'

    sunoshardware = SunOSHardware(DummyModule())
    sunoshardware.populate(DummyFacts())
    assert sunoshardware._facts['system_vendor'] == 'Oracle Corporation'
    assert sunoshardware._facts['product_name'] == 'sun4v'


# Generated at 2022-06-11 02:59:59.220025
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    x = SunOSHardwareCollector()
    return x

# Generated at 2022-06-11 03:00:10.063986
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class FakeModule:
        def run_command(self, command):
            return 0, "", ""

        def get_bin_path(self, comm_name, opt_dirs=[]):
            return ""

    class FakeFacts:
        def __init__(self):
            self.ansible_facts = {}

    # 'system_vendor' or 'product_name' is not found
    module = FakeModule()
    facts = FakeFacts()
    hardware = SunOSHardware(module=module, facts=facts)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {}

    # 'system_vendor' and 'product_name' are found
    module = FakeModule()
    facts = FakeFacts()

# Generated at 2022-06-11 03:00:18.012640
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    real_time = time.time()
    real_stat = os.stat
    os.stat = lambda path: os.stat_result((33188, 0, 0, 0, 0, 0, 0, real_time, 0, 0))
    try:
        boot_time = int(SunOSHardware(dict(ansible_facts={})).get_uptime_facts()['uptime_seconds'])
        assert abs(boot_time - int(real_time)) < 10
    finally:
        os.stat = real_stat

# Generated at 2022-06-11 03:00:45.628337
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware()
    # Sample values output from prtconf command on Linux.
    out = 'System Configuration: VMware, Inc. VMware Virtual Platform      Memory size: 4096 Megabytes'
    # Sample values output from swap -s command on Linux.
    out2 = 'total:     8192k bytes allocated +   40768k reserved  =   48860k used,  3972440k available'
    setattr(facts, 'module', get_memory_mock_module(out, out2))
    memory_facts = facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['swapfree_mb'] == 3839
    assert memory_facts['swaptotal_mb'] == 4767
    assert memory_facts['swap_allocated_mb'] == 39

# Generated at 2022-06-11 03:00:56.079692
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    class ModuleMock():

        def __init__(self):
            self.run_command_calls = []

        def run_command(self, commandargs):
            self.run_command_calls.append(commandargs)
            if commandargs == 'prtconf':
                return 0, 'Memory size: 256 Megabytes', ''
            else:
                return 0, 'Total    Swap    Free    Largest', ''

    m = ModuleMock()
    h = SunOSHardware(m)

    facts = h.get_memory_facts()
    assert facts['memtotal_mb'] == 256
    assert facts['swaptotal_mb'] == 'NA'
    assert facts['swapfree_mb'] == 'NA'
    assert facts['swap_allocated_mb'] == 'NA'

# Generated at 2022-06-11 03:01:04.471530
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('', (), {})()

# Generated at 2022-06-11 03:01:15.389603
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    hw = SunOSHardware()

    rc = 0

# Generated at 2022-06-11 03:01:24.640281
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule({})
    sunos_hw = SunOSHardware(module)

    # test with a System Configuration line that has 2 spaces after ':'
    assert sunos_hw.get_dmi_facts(fact_lines_list=['System Configuration: Sun Microsystems sun4u']) == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

    # test with a System Configuration line that has 1 space after ':'
    assert sunos_hw.get_dmi_facts(fact_lines_list=['System Configuration: Sun Microsystems  sun4u']) == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

# Generated at 2022-06-11 03:01:31.600280
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class ModuleStub(object):
        def run_command(self, args):
            return 0, "Memory size: 8192 Megabytes", ""

    datadir = os.path.join(os.path.dirname(__file__), 'data')
    hardware = SunOSHardware(ModuleStub())
    hardware.populate()
    assert hardware.get('memtotal_mb') == 8192

# Generated at 2022-06-11 03:01:34.557009
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert len(cpu_facts['processor']) > 0
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-11 03:01:37.887666
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    module.params['gather_subset'] = 'hardware'

    obj = SunOSHardware(module=module)

    obj.get_memory_facts()

# Generated at 2022-06-11 03:01:40.664734
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeModule()
    cpu_facts = SunOSHardware(module).get_cpu_facts()
    assert cpu_facts['processor_count'] == cpu_facts['processor_cores']


# Generated at 2022-06-11 03:01:45.619198
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Test SunOSHardware.populate()
    """
    collector = SunOSHardwareCollector()
    hardware = SunOSHardware()

    # Cannot test, as kstat module is not available in testenvironment
    if False:
        facter = hardware.populate()
        mount_facts = hardware.get_mount_facts()
        assert mount_facts is not None

# Generated at 2022-06-11 03:02:32.666147
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    from ansible.module_utils._text import to_text

    # Fujitsu product_name
    test_cases = [
        # test case input
        ('System Configuration:   Fujitsu   PrimeHPC FX100',
        # expected result
        {'system_vendor': 'Fujitsu', 'product_name': 'PrimeHPC FX100'}),
    ]

    for input_test_case, expected_test_case in test_cases:
        dmi_facts = SunOSHardware.get_dmi_facts(None, input_test_case)
        assert dmi_facts == expected_test_case

    # Oracle Corporation product_name

# Generated at 2022-06-11 03:02:40.353815
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Dummy module class
    class DummyModule:
        def run_command(self, cmd):
            out = ['System Configuration: Oracle Corporation sun4v']
            return 0, out, ''
    # Create test class instance
    h = SunOSHardware(DummyModule())
    result = h.get_dmi_facts()
    assert(result['system_vendor'] == 'Oracle Corporation')
    assert(result['product_name'] == 'sun4v')


# Generated at 2022-06-11 03:02:44.218873
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, '', ''))

    sh = SunOSHardware(module=module)
    cpu_facts = sh.get_cpu_facts()

    # The collection executed sucessfully
    assert cpu_facts['processor']
    assert cpu_facts['processor_count']
    assert cpu_facts['processor_cores']


# Generated at 2022-06-11 03:02:49.507862
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fact_obj = SunOSHardware(module)
    facts = fact_obj.get_memory_facts()

    assert type(facts) == dict
    assert facts[u'memtotal_mb'] == 514
    assert facts[u'swapfree_mb'] == 514
    assert facts[u'swap_allocated_mb'] == 0
    assert facts[u'swap_reserved_mb'] == 0
    assert facts[u'swaptotal_mb'] == 514



# Generated at 2022-06-11 03:02:54.227406
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    system_vendor = 'Oracle Corporation'
    product_name = 'T5120'
    dmi_facts = SunOSHardware().get_dmi_facts()
    assert dmi_facts.get('system_vendor') == system_vendor
    assert dmi_facts.get('product_name') == product_name


# Generated at 2022-06-11 03:03:00.242778
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = MagicMock()
    module.params = {}
    sh = SunOSHardware(module)
    rc, out, err = sh.module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    # uptime = $current_time - $boot_time
    facts = sh.get_uptime_facts()
    uptime_seconds = int(time.time() - int(out.split('\t')[1]))
    assert uptime_seconds == facts['uptime_seconds']

# Generated at 2022-06-11 03:03:08.453978
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import pytest
    from time import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    hw = SunOSHardware({})
    hw.module.run_command = lambda command: (0, str(int(time())), '')

    uptime_facts = hw.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] != 0
    assert time() - uptime_facts['uptime_seconds'] < 1  # was boot time less then 1 second ago?

# Generated at 2022-06-11 03:03:13.478887
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    This method test the uptime in seconds of method get_uptime_facts of class SunOSHardware
    """

    current_time = time.time()
    boot_time = current_time - 100
    out = "unix:0:system_misc:boot_time    %s\n" % boot_time
    module = MockedModule(run_command_return=(0, out, ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-11 03:03:18.872316
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'Memory size:         16384 Megabytes', ''))
    sunos = SunOSHardware(module=module)
    mem_facts = sunos.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 16384

# Generated at 2022-06-11 03:03:20.026853
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector()

