

# Generated at 2022-06-11 02:54:07.151288
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Mock facts that are supported by SunOSHardware.
    mock_ansible_facts = {
        'ansible_machine': 'i86pc',
    }

    # Create an instance of the class with the mocked facts.
    mock_instance = SunOSHardware(mock_ansible_facts)

    # Run the populate() method to collect hardware facts.
    mock_instance.populate()

    # Assert about the collected facts.
    assert mock_instance.facts['processor_cores'] is not None
    assert mock_instance.facts['processor_count'] is not None
    assert mock_instance.facts['memtotal_mb'] is not None
    assert mock_instance.facts['swapfree_mb'] is not None
    assert mock_instance.facts['swaptotal_mb'] is not None

# Generated at 2022-06-11 02:54:20.016425
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    testmodule = type("module", (object,), {})()
    testmodule.run_command = lambda *args, **kwargs: ("", "sderr:0::Hard Errors\t0\nsderr:0::Illegal Request\t6\nsderr:0::Media Error\t0\nsderr:0::Product\tVBOX HARDDISK\nsderr:0::Revision\t1.0\nsderr:0::Serial No\tVB0ad2ec4d-074a\nsderr:0::Size\t53687091200\nsderr:0::Soft Errors\t0\nsderr:0::Transport Errors\t0\nsderr:0::Vendor\tATA", "")
    sys_module = type("module", (object,), {})()
    sys_module

# Generated at 2022-06-11 02:54:29.755454
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test for method get_dmi_facts for the class SunOSHardware
    """
    hardware = SunOSHardware()

    hardware.module.run_command = MagicMock(return_value=(0, 'System Configuration: VMware, Inc. VMware Virtual Platform', None))
    assert hardware.get_dmi_facts() == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

    hardware.module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation Sun Fire X4470', None))
    assert hardware.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'Sun Fire X4470'}

    hardware.module.run_command = MagicMock(return_value=(1, '', ''))


# Generated at 2022-06-11 02:54:41.343850
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    mocked_module = MockAnsibleModule()
    mocked_command = MockAnsibleModuleCommand()

    mocked_module.run_command = mocked_command.run_command
    mocked_module.run_command.return_value = (0, """unix:0:system_misc:boot_time    1548249689""", "")

    uptime_seconds = int(time.time() - int(time.time()) + 10)
    expected = {'uptime_seconds' : uptime_seconds}
    sut = SunOSHardware(mocked_module)
    actual = sut.get_uptime_facts()
    assert actual == expected

# Generated at 2022-06-11 02:54:43.518733
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:54:54.804927
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=[], type='list')
        },
    )

    hardware = SunOSHardware(module=module)

    def run_command(args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        # Organize args by type
        cmd = args.pop(0)
        args_str = " ".join(str(arg) for arg in args)
        if data:
            args_str = "%s <<EOF\n%s\nEOF" % (args_str, data)
        cmdline = "%s %s" % (cmd, args_str)


# Generated at 2022-06-11 02:55:05.650989
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """ Test for method get_cpu_facts of class SunOSHardware """
    class DummyModule(object):
        def __init__(self):
            self.run_command_environ_update = None
            self.run_command_results = None
        def run_command(self, args):
            return self.run_command_results
    dummy_module = DummyModule()
    class Dummy_get_mount_facts(object):
        def __init__(self):
            self.mounts = []
        def get_mount_facts(self):
            return self.mounts
    dummy_get_mount_facts = Dummy_get_mount_facts()
    class Dummy_get_dmi_facts(object):
        def __init__(self):
            self.system_vendor = "Fujitsu"
            self

# Generated at 2022-06-11 02:55:14.573314
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    fake_ansible_module = type('AnsibleModule', (object,), {
        'run_command': lambda *_: [0, 'unix:0:system_misc:boot_time    1548249689\n', '']
    })()
    fake_SunOSHardware = type('SunOSHardware', (object,), {
        'module': fake_ansible_module
    })
    uptime_facts = SunOSHardware._get_uptime_facts(fake_SunOSHardware)
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:55:19.904821
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'System Configuration: VMware, Inc. VMware Virtual Platform None', None))

    sunOS_hardware = SunOSHardware(module)
    dmi_facts = sunOS_hardware.get_dmi_facts()

    assert dmi_facts['product_name'] == 'None'

# Generated at 2022-06-11 02:55:30.959872
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    mock = SunOSHardware()

# Generated at 2022-06-11 02:55:54.178083
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = {}
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, 'Memory size: 32768 Megabytes', ''))
    sunos_hardware = SunOSHardware()
    sunos_hardware.get_memory_facts(facts)
    assert sunos_hardware.populate() == {'memtotal_mb': 32768}



# Generated at 2022-06-11 02:56:03.077585
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    This test was copied from a similar test in the LinuxHardware plugin.
    It has been adapted to the SunOSHardware plugin.

    unit test for method populate of class SunOSHardware
    """
    fixture = SunOSHardware({}, dict(platform='SunOS'))


# Generated at 2022-06-11 02:56:14.265263
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

    result = SunOSHardware().get_device_facts()

    for key, value in result['devices'].items():
        for k, v in value.items():
            assert k == disk_stats[k], "Test get_device_facts failed"


# Generated at 2022-06-11 02:56:23.482593
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:56:30.982731
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    hardware._module.run_command = lambda x, **kwargs: (0, 'System Configuration: VMware, Inc. VMware Virtual Platform  Sun Microsystems sun4v', None)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == "VMware, Inc."
    assert dmi_facts['product_name'] == "VMware Virtual Platform"

# Generated at 2022-06-11 02:56:42.167944
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware({})
    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }
    cmd = ['/usr/bin/kstat', '-p']
    for ds in disk_stats:
        cmd.append('sderr:::%s' % ds)
    d = {}
    sd_instances = frozens

# Generated at 2022-06-11 02:56:47.396719
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command('/usr/sbin/prtconf')

    hardware_facts = SunOSHardware()
    memory_facts = hardware_facts.get_memory_facts(module)

    assert 'memtotal_mb' in memory_facts
    assert memory_facts['memtotal_mb'] > 0


# Generated at 2022-06-11 02:56:52.933322
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = {}
    mem_facts['memtotal_mb'] = int('256')
    mem_facts['swapfree_mb'] = int('62')
    mem_facts['swaptotal_mb'] = int('101')
    mem_facts['swap_allocated_mb'] = int('512')
    mem_facts['swap_reserved_mb'] = int('512')
    m = SunOSHardware()
    facts = m.get_memory_facts(collected_facts=None)
    for fact in list(mem_facts.keys()):
        assert facts[fact] == mem_facts[fact]

# Generated at 2022-06-11 02:56:59.310073
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = type('test', (object,), {'run_command': (lambda self, args: (0, 'unix:0:system_misc:boot_time    1548249689\n', ''))})
    sunos_hardware = SunOSHardware(module.run_command)
    uptime_facts = sunos_hardware.get_uptime_facts()

    assert uptime_facts
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:57:06.504349
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mock_module = Mock()
    mock_module.run_command.side_effect = [
        (0, 'Memory size: 32768 Megabytes\n', ''),
        (0, '8192 blocks\n', '')
    ]
    sunos_hw = SunOSHardware(mock_module)
    facts = sunos_hw.get_memory_facts()
    assert facts == {'memtotal_mb': 32768, 'swap_reserved_mb': 8, 'swaptotal_mb': 8, 'swapfree_mb': 8, 'swap_allocated_mb': 0}

# Generated at 2022-06-11 02:57:49.869589
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    '''
    Test get_dmi_facts method of class SunOSHardware.
    '''

    # Test 0: Test all variants of 'System Configuration'

    # Create a SunOSHardware object.
    sunos_hw = SunOSHardware()

    # Test 'System Configuration': FUJITSU PRIMERGY CX400 S1
    system_conf = 'System Configuration: FUJITSU PRIMERGY CX400 S1'
    dmi = sunos_hw.get_dmi_facts(system_conf)
    assert dmi['system_vendor'] == 'FUJITSU'
    assert dmi['product_name'] == 'PRIMERGY CX400 S1'

    # Test 'System Configuration': Oracle Corporation sun4v
    system_conf = 'System Configuration: Oracle Corporation sun4v'
    dmi

# Generated at 2022-06-11 02:57:56.442882
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command = Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))

    module = MockModule()

    facts = SunOSHardware(module)
    uptime_facts = facts.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 1548249689

# Generated at 2022-06-11 02:57:59.136749
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    m = SunOSHardware({})
    m.populate()
    assert m.facts['processor']
    assert m.facts['memtotal_mb']
    assert m.facts['swapfree_mb']
    assert m.facts['swaptotal_mb']
    assert m.facts['swap_allocated_mb']
    assert m.facts['swap_reserved_mb']

# Generated at 2022-06-11 02:58:00.809207
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    SunOSHardware().populate()

# Generated at 2022-06-11 02:58:11.873131
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    f_module = FakeModule()
    f_module.params = {}
    f_module.collector = SunOSHardwareCollector(f_module)
    #print(type(f_module.collector))
    assert isinstance(f_module.collector, SunOSHardwareCollector)

    #print(type(f_module.collector.platform))
    assert isinstance(f_module.collector.platform, str)

    #print(type(f_module.collector._fact_class))
    assert isinstance(f_module.collector._fact_class, type)

    #print(type(f_module.collector.required_facts))
    assert isinstance(f_module.collector.required_facts, set)

    #print(type(f_module.collector.condition))

# Generated at 2022-06-11 02:58:20.368688
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModuleMock()
    hardware_obj = SunOSHardware(module)
    collected_facts = {}

    hardware_obj.run_command = AnsibleModuleMock.run_command
    rc, out, err = hardware_obj.run_command(["/usr/bin/kstat cpu_info"])
    hardware_obj.run_command = AnsibleModuleMock.run_command
    rc, out2, err = hardware_obj.run_command('/usr/sbin/swap -s')
    hardware_obj.get_mount_facts = AnsibleModuleMock.get_mount_facts

    hardware_obj.get_cpu_facts(collected_facts)



# Generated at 2022-06-11 02:58:31.487719
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    f = SunOSHardware(module)

    # from: http://www.kofler.info/wiki/SunOS:_Schnelle_Fakten_und_Tipps#CPU

# Generated at 2022-06-11 02:58:42.650175
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    m = SunOSHardware()


# Generated at 2022-06-11 02:58:47.969481
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Tests that a call to populate does not raise an exception.
    """
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module=module)
    # TODO: Need to test exceptions properly
    #try:
    hardware.populate()
    #except:
    #    print 'Hardware.populate() raised an exception'
    #    assert False, 'Hardware.populate() raised an exception'
    #else:
    #    assert True, 'Hardware.populate() did not raise an exception'


# Generated at 2022-06-11 02:58:52.303120
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    hardware = SunOSHardware(None)

    test_uptime_facts = hardware.get_uptime_facts()

    # only test that uptime is present.
    assert hardware.uptime_seconds



# Generated at 2022-06-11 02:59:34.521046
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.required_facts == {'platform'}
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware

# Generated at 2022-06-11 02:59:44.795542
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Provide a test for the SunOSHardware.get_device_facts() method.
    """
    import ansible.module_utils.facts.hardware.sunos as sunos_hw
    from ansible.module_utils.facts import hardware
    hardware._HARDWARE_CACHE = {}

    hardware_object = hardware.Hardware()
    sunos_hw_object = sunos_hw.SunOSHardware()

    # Collect all hardware facts (some are not required for the test)
    hardware_object.collect()


# Generated at 2022-06-11 02:59:56.852893
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockShellModule()

# Generated at 2022-06-11 03:00:01.904200
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # create FactsCollector instance
    facts_collector = FactsCollector()

    # run method get_device_facts and get result
    result = facts_collector.collect(['devices'], SunOSHardware)

    # simple tests
    assert result['devices'] is not None

# Generated at 2022-06-11 03:00:13.834124
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    s = SunOSHardware()

    brand_dmi = "brand dmi"
    brand_uname = "brand uname"

    # Collected facts
    collected_facts = {"ansible_machine": "machine"}

    # Grouped output of kstat

# Generated at 2022-06-11 03:00:18.436077
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_data = """module:
brand
chip_id
clog_id
core_id
implementation
package_id
state
"""

    class FakeModule(object):
        def run_command(self, cmd):
            return 0, cpu_data, None

    cpu_facts = SunOSHardware(FakeModule()).get_cpu_facts()
    assert cpu_facts['processor_count'] == 1

# Generated at 2022-06-11 03:00:27.773854
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class ModuleMock:
        class RunCommand:
            def __init__(self, returncode=0, out='1548249689', err=''):
                self.returncode = returncode
                self.out = out
                self.err = err
            def run_command(self, command, check_rc=True):
                return (self.returncode, self.out, self.err)

    class SunOSHardwareMock:
        def __init__(self, module):
            self.module = module

    sun_hardware = SunOSHardwareMock(ModuleMock())
    uptime_facts = sun_hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1548249689

# Generated at 2022-06-11 03:00:39.597377
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    util = SunOSHardware()

    # Method get_memory_facts() should return dictionary containing following keys:
    # memtotal_mb, swapfree_mb, swaptotal_mb, swap_allocated_mb, swap_reserved_mb
    # The list of keys is obtained from the method populate()
    # which calls the method get_memory_facts()
    memory_keys = ['memtotal_mb', 'swapfree_mb', 'swaptotal_mb',
                   'swap_allocated_mb', 'swap_reserved_mb']

    # Method get_memory_facts() should return integer values for the keys listed above
    memory_int_keys = ['memtotal_mb', 'swapfree_mb', 'swaptotal_mb',
                       'swap_allocated_mb', 'swap_reserved_mb']

    memory

# Generated at 2022-06-11 03:00:47.023798
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_obj = SunOSHardware()
    test_obj.module = lambda: None
    test_obj.module.run_command = lambda *args: [0, 'module: SUNW,Netra-CP3220\nbrand: Netra CP3220 CPUS\nclock_MHz:\t2312.000000\nchip_id:\t0\ncores_per_chip:\t4\nimplementation:\tSPARC-T4\ncpu_type:\tSPARC-T4']
    test_obj.module.run_command.__name__ = "run_command"
    result = test_obj._get_cpu_facts()
    assert result['processor_cores'] == '4'
    assert result['processor_count'] == '1'

# Generated at 2022-06-11 03:00:57.169291
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    cmd = ['/usr/bin/kstat', '-p']

    disk_stats = {
        'Product': 'product',
        'Revision': 'revision',
        'Serial No': 'serial',
        'Size': 'size',
        'Vendor': 'vendor',
        'Hard Errors': 'hard_errors',
        'Soft Errors': 'soft_errors',
        'Transport Errors': 'transport_errors',
        'Media Error': 'media_errors',
        'Predictive Failure Analysis': 'predictive_failure_analysis',
        'Illegal Request': 'illegal_request',
    }

    for ds in disk_stats:
        cmd.append('sderr:::%s' % ds)

    device_facts = {}
    device_facts['devices'] = {}

    rc, out,

# Generated at 2022-06-11 03:01:47.634583
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """test if get_memory_facts creates swap values"""
    module = FakeModule()
    setattr(module, 'run_command', fake_run_command)
    memfacts = SunOSHardware(module).get_memory_facts()
    # assert memfacts['swapfree_mb'] exists
    assert memfacts['swapfree_mb'] == 512
    # assert memfacts['swaptotal_mb'] exists
    assert memfacts['swaptotal_mb'] == 1024
    # assert memfacts['swap_allocated_mb'] exists
    assert memfacts['swap_allocated_mb'] == 512
    # assert memfacts['swap_reserved_mb'] exists
    assert memfacts['swap_reserved_mb'] == 512



# Generated at 2022-06-11 03:01:55.529130
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    return {'devices': {'sda': {'vendor': 'ATA',
                                'revision': '1.0',
                                'hard_errors': '0',
                                'size': '53687091200',
                                'predictive_failure_analysis': '0',
                                'illegal_request': '0',
                                'media_errors': '0',
                                'serial': 'VB0ad2ec4d-074a',
                                'transport_errors': '0',
                                'product': 'VBOX HARDDISK',
                                'soft_errors': '0'}}}

# Generated at 2022-06-11 03:02:04.923260
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Arrange
    class Module:
        def run_command(cmd):
            if cmd[0] == '/usr/bin/kstat':
                return 0, 'unix:0:system_misc:boot_time 1548249689', None
            else:
                raise Exception('unexpected command: %s' % cmd[0])

    class AnsibleModule:
        def __init__(self):
            self.params = {}
            self.run_command = Module.run_command

    sut = SunOSHardware(AnsibleModule())
    expected_uptime_facts = {'uptime_seconds': int(time.time()) - 1548249689}
    # Act
    actual_uptime_facts = sut.get_uptime_facts()
    # Assert
    assert actual_uptime_facts == expected_uptime

# Generated at 2022-06-11 03:02:14.286920
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 03:02:21.706411
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware(dict(), dict())
    hardware.module.run_command = MagicMock(return_value=(0, 'Memory size: 1024 Megabytes', ''))
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['swapfree_mb'] == 0
    assert memory_facts['swaptotal_mb'] == 0
    assert memory_facts['swap_allocated_mb'] == 0
    assert memory_facts['swap_reserved_mb'] == 0
    assert memory_facts['memtotal_mb'] == 1024


# Generated at 2022-06-11 03:02:25.262213
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    SunOSHardware(module).populate()
    assert module.run_command_environ_update == {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}


# Generated at 2022-06-11 03:02:27.770526
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    a = SunOSHardware({}, None)
    res = a.get_uptime_facts()
    assert res['uptime_seconds'] > 0


# Generated at 2022-06-11 03:02:33.751788
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class FakeModule(object):
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class FakeSunOSHardware(SunOSHardware):
        def __init__(self, module):
            self.module = module

    bs = FakeSunOSHardware(FakeModule())
    result = bs.get_uptime_facts()
    assert result['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-11 03:02:45.052409
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class _mod(object):
        def __init__(self, stdout):
            self.stdout = stdout
        def run_command(self, args, check_rc=False):
            class _exc(object):
                rc = 0
                stderr = ''
            return _exc()
    h = SunOSHardware

    assert h.get_cpu_facts(_mod('')) == {'processor_count': 0, 'processor': []}

    cpu_facts = h.get_cpu_facts(_mod('module:\nsun4v\nbrand\nSUN T4'))
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['SUN T4']


# Generated at 2022-06-11 03:02:51.580077
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    unit test for get_cpu_facts() of class SunOSHardware
    """