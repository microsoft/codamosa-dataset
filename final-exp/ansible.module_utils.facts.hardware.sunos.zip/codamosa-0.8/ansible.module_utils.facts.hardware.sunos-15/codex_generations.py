

# Generated at 2022-06-11 02:54:14.500948
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # The first line of prtdiag output as provided by SunOSHardware.get_dmi_facts()
    # depends on the hardware platform and on the OS version.
    #
    # This test case covers three different scenarios.

    # SunOS version >= 10, on the Intel platform.
    in_string_1 = u"System Configuration: VMware, Inc. Virtual Platform"
    assert SunOSHardware().get_dmi_facts() == {'system_vendor': 'VMware, Inc.',
                                               'product_name': 'Virtual Platform'}

    # SunOS version < 10, on the SPARC platform.
    in_string_2 = u"System Configuration: Foo Corp. SUNW,Generic-sun4u"

# Generated at 2022-06-11 02:54:25.007144
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    '''
    This test case checks the output of method get_memory_facts for
    Sys class SunOSHardware for an input similar to one of the test
    cases of proc_meminfo in LinuxHardware.

    The input is hard coded here.
    '''
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()

    assert facts['memtotal_mb'] == 132880
    assert facts['swapfree_mb'] == 8192
    assert facts['swaptotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0

# Generated at 2022-06-11 02:54:27.055220
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule({})
    hardware = SunOSHardware(module)
    result = hardware.get_device_facts()
    assert result == {}

# Generated at 2022-06-11 02:54:32.864815
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Unit test to check populating of SunOSHardware()"""
    module = FakeModule()
    sunos_hardware = SunOSHardware(module)

    #check that no exception is raised
    sunos_hardware.populate()

    #check that a dictionary is returned
    assert isinstance(sunos_hardware.populate(), dict)


# Generated at 2022-06-11 02:54:42.799347
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    import json

    # Mock the kstat command output

# Generated at 2022-06-11 02:54:48.414731
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # pylint: disable=abstract-method,import-error
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    hardware = SunOSHardware(dict())
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['sd0']['size'] == '53687091200'


# Generated at 2022-06-11 02:55:00.150353
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_results = [
                [0, "/usr/sbin/prtconf \nSystem Configuration: HP ProLiant DL180 G6\nMemory size: 4096 Megabytes", ""],
                [0, "swap     -s\n      total: 9999640k bytes allocated + 8358088k reserved = 18357128k used, 11924720k available\n  ", ""],
            ]

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    module_stub = ModuleStub()
    hardware = SunOSHardware(module_stub)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 4096
    assert memory_

# Generated at 2022-06-11 02:55:03.989891
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test function for method populate of class SunOSHardware
    """
    module = AnsibleModule(argument_spec={})
    system = SunOSHardwareCollector(module)
    system.populate()
    assert system.facts['ansible_system'] == 'SunOS'

# Generated at 2022-06-11 02:55:16.947422
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    time_now = time.time()
    time_boot = time_now - 1
    # mock module return value
    mock_module = type('mock_module', (object,), {})
    mock_run_command = type('mock_run_command', (object,), {})
    mock_run_command.return_value = [0, 'unix:0:system_misc:boot_time\t{}'.format(str(int(time_boot))), '']
    mock_module.run_command = mock_run_command
    module = mock_module()

    hw = SunOSHardware()
    hw.module = module
    assert hw.get_uptime_facts()['uptime_seconds'] == int(time_now - time_boot)

# Generated at 2022-06-11 02:55:18.554035
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    assert hardware.populate()


# Generated at 2022-06-11 02:55:44.153585
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m = SunOSHardware({})
    facts = m.get_memory_facts()

    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['swapfree_mb'] <= facts['swaptotal_mb']
    assert facts['swap_allocated_mb'] >= 0
    assert facts['swap_reserved_mb'] >= 0
    assert facts['swap_allocated_mb'] <= facts['swap_reserved_mb']
    assert facts['swap_reserved_mb'] <= facts['swaptotal_mb']
    assert facts['memtotal_mb'] >= facts['swaptotal_mb']

# Generated at 2022-06-11 02:55:56.340780
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    uname is mocked and controlled by param desired_output.
    prtdiag is mocked and controlled by param desired_output.
    """

# Generated at 2022-06-11 02:56:01.075189
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    class TestModule(object):
        def run_command(self, cmd, environ_update=None):
            return 1, '', ''

    test_module = TestModule()

    sh = SunOSHardware(module=test_module)
    cpu_facts = sh.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == len(cpu_facts['processor'])

# Generated at 2022-06-11 02:56:06.575265
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockModule()
    facts = SunOSHardware(module).get_memory_facts()

    assert facts['memtotal_mb'] == 131072
    assert facts['swapfree_mb'] == 65536
    assert facts['swaptotal_mb'] == 65536
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0

# Generated at 2022-06-11 02:56:17.729709
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Loads test data
    fake_module = FakeModule({})
    fake_module.run_command_environ_update = {}


# Generated at 2022-06-11 02:56:25.161892
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sunos_hardware = SunOSHardware(module)
    facts_subset = sunos_hardware.populate()

    assert 'processor' in facts_subset
    assert 'memtotal_mb' in facts_subset
    assert 'swapfree_mb' in facts_subset
    assert 'swaptotal_mb' in facts_subset
    assert 'swap_allocated_mb' in facts_subset
    assert 'swap_reserved_mb' in facts_subset
    assert 'system_vendor' in facts_subset
    assert 'product_name' in facts_subset
    assert 'devices' in facts_subset
    assert 'uptime_seconds' in facts_subset
    assert 'mounts' in facts_subset

# Generated at 2022-06-11 02:56:32.829026
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = type('FakeModule', (), {'run_command': fake_run_command})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts == {'memtotal_mb': 8192,
                     'swapfree_mb': 31,
                     'swaptotal_mb': 31,
                     'swap_reserved_mb': 0,
                     'swap_allocated_mb': 0}


# Generated at 2022-06-11 02:56:43.908295
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Arrange
    class TestModule(object):
        def run_command(self, *cmd):
            if 'kstat' in cmd:
                return 0, 'sderr:3:sd0\nsderr:::Size\t123\nsderr:3:sd0\nsderr:::Vendor\tABC\nsderr:3:sd0\nsderr:3:sd0', ''

        def get_bin_path(self, *cmd, **kwargs):
            return '/usr/sbin/prtdiag'

        def run_command_environ_update(self):
            return {}

    m = TestModule()

    # Act
    hardware = SunOSHardware(m)
    actual_hw_facts = hardware.populate()

    # Assert
    assert 'devices' in actual_hw_facts

# Generated at 2022-06-11 02:56:52.309643
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    class MockModule:
        def __init__(self):
            self.run_command_calls = 0

        def run_command(self, args):
            self.run_command_calls += 1
            if args == ['prtconf']:
                return (0, 'Memory size: 16384 Megabytes', '')
            elif args == ['swap', '-s']:
                return (0, 'kbytes     =     10471680\n'
                            'resv kbytes =            0\n'
                            'avail kbytes=     10471680\n'
                            'used  kbytes=            0', '')
            else:
                return (0, '', '')

    hardware = SunOSHardware()
    hardware.module = MockModule()
    mem_facts = hardware.get_memory_

# Generated at 2022-06-11 02:57:01.245471
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    model = SunOSHardware()

    # test system_misc:boot_time not defined in kstat output
    kstat_out = ''
    rc = 0
    err = ''
    model.run_command = MagicMock(name='run_command', return_value=(rc, kstat_out, err))
    assert model.get_uptime_facts() == {}

    # test system_misc:boot_time is defined in kstat output
    kstat_out = 'unix:0:system_misc:boot_time\t1548249689'
    rc = 0
    err = ''
    model.run_command = MagicMock(name='run_command', return_value=(rc, kstat_out, err))

# Generated at 2022-06-11 02:57:44.995639
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware = SunOSHardware()
    hardware.module.run_command = lambda *args, **kwargs: (1, '', '')
    hardware.module.run_command_environ_update = {}

    hardware.populate()
    assert hardware.data['processor'] == []
    assert hardware.data['swapfree_mb'] == 0
    assert hardware.data['memtotal_mb'] == 0
    assert hardware.data['uptime_seconds'] == 0
    assert hardware.data['devices'] == {}

    hardware.module.run_command = lambda *args, **kwargs: (1, 'Fujitsu sun4v', '')
    hardware.populate()
    assert hardware.data['system_vendor'] == 'Fujitsu'
    assert hardware.data['product_name'] == 'sun4v'


# Generated at 2022-06-11 02:57:55.712339
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os
    import re
    import sys
    import time
    import pytest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils._text import to_bytes

    if sys.version_info[0] > 2:
        from unittest.mock import MagicMock
    else:
        from mock import MagicMock

    # Avoid pytest warnings
    pytestmark = pytest.mark.filterwarnings('ignore:.*U.*mode is deprecated:DeprecationWarning')

    # Skip test if the required command is not available.
    if not os.path.exists('/usr/bin/kstat'):
        pytest.skip('Required command absent: /usr/bin/kstat')

    # Skip test if the required command is not executable.

# Generated at 2022-06-11 02:58:07.076195
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):

        def __init__(self):
            self.run_command = self._run_command

        def _run_command(self, cmd):
            if cmd == "ping -c 1 foo.example.com":
                return 0, "1 packets transmitted, 0 packets received, 100% packet loss", ""
            else:
                return 0, "1548249689", ""

    class MockTime(object):
        def __init__(self):
            self.time = 1548249800

        def __call__(self):
            return self.time

    mtime = MockTime()
    mm = MockModule()
    uf = SunOSHardware(mm)
    assert uf.get_uptime_facts()['uptime_seconds'] == 111

# Generated at 2022-06-11 02:58:17.726193
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Mock up results that would be collected by run_command
    prtdiag_output = (
        "System Configuration: Sun Microsystems  sun4u\n"
        "Working CPU(s): 1\n"
        "Available CPU(s): 1\n"
        "Total Memory: 2048 Megabytes"
    )
    prtdiag_output2 = (
        "System Configuration: VMware, Inc.   VMware Virtual Platform\n"
        "Working CPU(s): 1\n"
        "Available CPU(s): 1\n"
        "Total Memory: 2048 Megabytes"
    )

# Generated at 2022-06-11 02:58:26.189053
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, args):
            if '/usr/bin/kstat -p unix:0:system_misc:boot_time' in args:
                return 0, 'unix:0:system_misc:boot_time\t1548249689', ''
            return 0, '', ''

    m = MockModule()

    hardware = SunOSHardware(module=m)
    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 1548249689 - int(time.time())

# Generated at 2022-06-11 02:58:34.665827
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # mock module for testing
    module = MagicMock()
    module.run_command.return_value = 0, 'module: cpu_info\nbrand: AMD Athlon(tm) II P320 Dual-Core Processor\n'

# Generated at 2022-06-11 02:58:45.509561
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Unit test to cover the SunOSHardware.get_cpu_facts method
    """


# Generated at 2022-06-11 02:58:55.321745
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    m = SunOSHardware()

# Generated at 2022-06-11 02:59:06.437294
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    import datetime


# Generated at 2022-06-11 02:59:15.696468
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # SunOSHardware_test.test_SunOSHardware_get_device_facts
    module = AnsibleModule(argument_spec=dict())

    with patch('ansible.module_utils.facts.hardware.sunos.SunOSHardware.module', module):
        with patch('ansible.module_utils.facts.hardware.sunos.AnsibleModule') as mock_module:
            mock_module.run_command.return_value = (0, "sderr:::Product VBOX HARDDISK   9\nsderr:::Revision        1.0\nsderr:::Serial No       VB0ad2ec4d-074a\nsderr:::Size    53687091200\nsderr:::Vendor  ATA", "mock_err")
            sun_hw = SunOSHardware()
            d

# Generated at 2022-06-11 03:00:36.553094
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # Simple class to mock run_command to provide module's run_command with a return value
    # and to count the number of calls to that function.
    class TestModule:
        def __init__(self):
            self.run_command_count = 0
            self.run_command_return = [0, "", ""]

        def run_command(self, cmd):
            self.run_command_count += 1
            return self.run_command_return

    # Instantiate the test module.
    module = TestModule()

    # Create the object to test
    h = SunOSHardware(module)

    # Set the test values.
    expected_run_command_count = 2
    expected_run_command_return = [[0, "", ""],
                                   [0, "Memory size: 32768 Megabytes\n", ""]]

# Generated at 2022-06-11 03:00:45.324195
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Initialize the class
    sunoshardware = SunOSHardware()

    # The facts to be populated by the code
    hardware_facts = {}

    # Run the code
    sunoshardware.populate(hardware_facts)

    # Assertions
    assert hardware_facts['memtotal_mb'] == 2048
    assert hardware_facts['swapfree_mb'] == 4
    assert hardware_facts['swaptotal_mb'] == 8
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 8
    assert hardware_facts['devices']['sda']['vendor'] == 'ATA'
    assert hardware_facts['devices']['sda']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-11 03:00:49.243511
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )

    hardware = SunOSHardware(module=module)
    hardware.populate()
    assert hardware.facts['ansible_facts']['processor'][0] == 'SUNW,SPARC-Enterprise'

# Generated at 2022-06-11 03:00:59.773503
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Define the class module, name, argument spec and populate it with default values
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    # Define a class object
    obj = SunOSHardware(module)

    # Define the expected result for the test data
    expected_result = {
        'processor_count': 1,
        'processor_cores': 8,
        'processor': ['SPARC M8 (chipid 0, clock 2000 MHz) @ 2000MHz'],
        'ansible_processor_count': 1,
        'ansible_processor_cores': 8
    }

    # Read the output

# Generated at 2022-06-11 03:01:03.734962
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware().get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts


# Generated at 2022-06-11 03:01:11.650589
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os
    from ansible.module_utils import basic

    module = basic.AnsibleModule({})
    SunOS = SunOSHardware(module)

    out = "unix:0:system_misc:boot_time    1548249689"
    current_time = 1548250000

    os.environ['ANSIBLE_KSTAT'] = out
    os.environ['ANSIBLE_SYSTEM_TIME'] = str(current_time)

    uptime_facts = SunOS.get_uptime_facts()
    assert uptime_facts["uptime_seconds"] == 511

# Generated at 2022-06-11 03:01:22.679129
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware()
    m.module = MagicMock()
    m.module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems  Sun Fire V240', None))
    dmi_facts = m.get_dmi_facts()
    # Assert that dictionary contains keys and values for platform, product name and system vendor
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V240'

    # Check for alternate error case where not all required information can be extracted from
    # the first line of prtdiag output

# Generated at 2022-06-11 03:01:27.751148
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = type('AnsibleModule', (object,), {'run_command': lambda *args: (0, '', '')})
    module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/prtdiag'

    ah = SunOSHardware(module)

    sut = ah.get_dmi_facts()

    assert sut == {'system_vendor': 'Sun Microsystems',
                   'product_name': 'SUNW,SPARC-Enterprise-T5120',
                   'serial': '07230873XX' }

# Generated at 2022-06-11 03:01:37.679148
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()

    # Mock out the module class
    hardware.module = type('temp_module', (), {})()

    # Mock out the run_command method

# Generated at 2022-06-11 03:01:47.723664
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    # Test for manufacturer 'Oracle Corporation'
    prtconf = get_file_content('./tests/unittests/files/prtconf-oracle.txt')
    hardware.module.run_command = MockRunCommand(
        (0, prtconf, '')
    )
    prtdiag = get_file_content('./tests/unittests/files/prtdiag-oracle.txt')
    hardware.module.get_bin_path = MockGetBinPath(
        '/usr/sbin/prtdiag',
        (0, prtdiag, '')
    )

    dmi_facts = hardware.get_dmi_facts()