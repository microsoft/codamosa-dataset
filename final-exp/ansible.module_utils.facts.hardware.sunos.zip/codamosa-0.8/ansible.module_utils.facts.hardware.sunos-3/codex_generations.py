

# Generated at 2022-06-11 02:54:08.036710
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Create a fake module object
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    # Create a fake class object
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunos_obj = SunOSHardware(module)

    # Create a 'fake' collected_facts
    collected_facts = {
        'ansible_machine': 'i86pc',
    }

    # Create a fake 'prtconf' output
    prtconf = """
        Memory size: 8192 Megabytes
    """

    # Create a fake 'swap -s' output
    swap = """
        total: 8192k bytes allocated + 10240k reserved = 18432k used, 66060k available
    """

    # Create a fake 'prtdiag' output
    pr

# Generated at 2022-06-11 02:54:14.232811
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()

    # Create a SunOSHardware object
    obj = SunOSHardware(module)

    # Mock prtconf command output
    obj.module.run_command.return_value = (0, 'Memory size: 32768 Megabytes', '')

    # Call the get_memory_facts method
    obj.get_memory_facts()

# Generated at 2022-06-11 02:54:25.157350
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = DummyModule()
    sunos_hardware_obj = SunOSHardware(module)

    # test 1 : case of kstat command executed successfully
    kstat_run_command_out = """unix:0:system_misc:boot_time    1542445689"""
    module.run_command = Mock(return_value=[0, kstat_run_command_out, ''])
    assert sunos_hardware_obj.get_uptime_facts() == dict(uptime_seconds=1548251961)

    # test 2 : case of kstat command execution failed
    module.run_command = Mock(return_value=[1, "", ''])
    assert sunos_hardware_obj.get_uptime_facts() == dict()



# Generated at 2022-06-11 02:54:36.986168
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, run_command_results):
            self.run_command_results = run_command_results
            self.run_command_calls = 0

        def run_command(self, args, check_rc=False):
            result = self.run_command_results[self.run_command_calls]
            self.run_command_calls += 1
            return (result['rc'], result['stdout'], result['stderr'])

    def get_prtdiag_results():
        return [
            {
                'rc': 0,
                'stdout': "System Configuration: Oracle Corporation sun4u\n",
                'stderr': ''
            }
        ]


# Generated at 2022-06-11 02:54:44.387728
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Unit tests for method SunOSHardware.get_dmi_facts"""

    # Stub the module & facts
    module = AnsibleModuleStub()
    facts = dict()

    # Stub the module command results
    module.run_command.return_value = 0, "System Configuration: Oracle Corporation sun4v", ""

    # Create an instance of the class
    sunos_hardware_collector = SunOSHardwareCollector(module=module)

    # Execute the method
    dmi_facts = sunos_hardware_collector._fact_class.get_dmi_facts(module=module, facts=facts)

    # Some basic assertions
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v'


# Generated at 2022-06-11 02:54:55.659985
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    cmd_res = {'rc': 0, 'stdout': '/usr/sbin/prtconf: Memory size: 16318 Megabytes',
               'stderr': ''}
    prtconf = ['/usr/sbin/prtconf']
    module_mock = Mock(run_command=MagicMock(side_effect=lambda x, environ_update=None: cmd_res))
    module_mock.get_bin_path.return_value = '/usr/sbin/swap'
    prtconf_instance = SunOSHardware(module_mock)
    mem_facts = prtconf_instance.get_memory_facts()
    total_ram_mb = mem_facts.get('memtotal_mb', None)
    assert (total_ram_mb == 16318)


# Generated at 2022-06-11 02:55:00.636083
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Unit test for method get_device_facts of class SunOSHardware"""
    from ansible.module_utils.facts import Collector

    m = Collector()
    m.populate_facts()
    result = SunOSHardware().get_device_facts()
    assert isinstance(result['devices'], dict)

# Generated at 2022-06-11 02:55:04.680393
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    mock_facts = {
        'platform': 'SunOS'
    }
    collected_facts = SunOSHardware(module, mock_facts).populate()
    # ensure that the facts are populated
    assert collected_facts['ansible_processor_cores']
    assert collected_facts['ansible_processor_count']
    assert collected_facts['ansible_memtotal_mb']
    assert collected_facts['ansible_swaptotal_mb']
    assert collected_facts['ansible_swapfree_mb']
    assert collected_facts['ansible_devices']



# Generated at 2022-06-11 02:55:11.206685
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    hardware.module.run_command = lambda command: (0, 'Sun Microsystems sun4v', '')
    assert hardware.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}


# Generated at 2022-06-11 02:55:16.904122
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = object()
    module.run_command = lambda *args: (0, "Memory size: 16384 Megabytes", None)

    hardware = SunOSHardware(module)

    hardware_facts = hardware.get_memory_facts()

    assert hardware_facts['memtotal_mb'] == 16384

if __name__ == '__main__':
    test_SunOSHardware_get_memory_facts()

# Generated at 2022-06-11 02:55:35.800757
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec={},
    )
    hardware_collector = SunOSHardwareCollector(module)
    hardware_collector.populate()

    assert 'memtotal_mb' in hardware_collector.facts
    assert 'swap_reserved_mb' in hardware_collector.facts



# Generated at 2022-06-11 02:55:39.044313
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')

    uptime_facts = SunOSHardware(module).get_uptime_facts()

    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-11 02:55:40.197088
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector().collect()

# Generated at 2022-06-11 02:55:51.748473
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    collected_facts = {'ansible_machine': "i86pc"}
    hardware_facts_instance = SunOSHardware(module)
    hardware_facts = hardware_facts_instance.populate(collected_facts)

    # Ensure no exception is raised
    assert hardware_facts is not None

    assert hardware_facts['uptime_seconds'] is not None
    assert hardware_facts['system_vendor'] is not None
    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['swaptotal_mb'] is not None
    assert hardware_facts['swap_allocated_mb'] is not None
    assert hardware_facts['swap_reserved_mb'] is not None

    assert hardware_facts['devices'] is not None

# Generated at 2022-06-11 02:56:01.593970
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import json
    import re
    import os

    class FakeModule(object):
        def __init__(self, path1, path2):
            self.path1 = path1
            self.path2 = path2

        def get_bin_path(self, *args, **kwargs):
            if self.path1:
                return self.path1
            else:
                return self.path2

        def run_command(self, *args, **kwargs):
            cmd = args[0]
            rc = 0
            if len(args) > 1:
                env = args[1]
                self.run_command_environ_update = env

            if isinstance(cmd, str):
                cmd = shlex.split(cmd)

            # Ignore any arguments and just return the filename

# Generated at 2022-06-11 02:56:12.632711
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class RunCommandMock:
        def __init__(self, return_value):
            self.return_value = return_value

        def __call__(self, args, **kwargs):
            if isinstance(args, list):
                args = ' '.join(args)

            return (0, self.return_value, None)

    # Mock class SunOSHardware
    class SunOSHardwareMock(SunOSHardware):
        def __init__(self):
            self.module = RunCommandMock(return_value='System Configuration: Sun Microsystems sun4v')

    # Create instance of SunOSHardwareMock class
    shm = SunOSHardwareMock()

    # Execute get_dmi_facts() and save result
    result = shm.get_dmi_facts()

    # Assert result

# Generated at 2022-06-11 02:56:22.392667
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = get_mock_module()


# Generated at 2022-06-11 02:56:28.960320
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    platform = "SunOS"
    result = SunOSHardware.get_cpu_facts(platform)

    assert result == {
        'processor': ['Fujitsu SPARC64-X+ @ 3000MHz', 'Fujitsu SPARC64-X+ @ 3000MHz', 'Fujitsu SPARC64-X+ @ 3000MHz'],
        'processor_cores': 3,
        'processor_count': 3
    }

# Generated at 2022-06-11 02:56:31.184460
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({})
    hardware.populate()
    hardware.get_cpu_facts()

# Generated at 2022-06-11 02:56:39.090415
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    In addition to the generic memory and cpu facts, this also sets
    swap_reserved_mb and swap_allocated_mb that is available from *swap -s*.
    """
    hardware = SunOSHardware()
    hardware.module = AnsibleModule(
        argument_spec = dict()
    )
    hardware.module.run_command = MagicMock(return_value=(0, "OUT", "ERR"))

    hardware.module.run_command.assert_called_with("/usr/bin/kstat cpu_info")


# Generated at 2022-06-11 02:57:12.942089
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware = SunOSHardware(None)

    assert sunos_hardware.get_dmi_facts() == {}

    sunos_hardware.facts = {'platform': 'SunOS'}
    assert sunos_hardware.get_dmi_facts() == {}

# Generated at 2022-06-11 02:57:23.868708
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:29.079897
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeModule()
    hardware = SunOSHardware(module)
    mem_facts = hardware.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 128
    assert mem_facts['swapfree_mb'] == 0
    assert mem_facts['swaptotal_mb'] == 0
    assert mem_facts['swap_allocated_mb'] == 0
    assert mem_facts['swap_reserved_mb'] == 0


# Generated at 2022-06-11 02:57:38.241588
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    '''
    NOTE: Want to test the real-time facts, but it takes too long.
    Python in virtualbox has negative uptime_seconds, so disable it.
    '''
    # fake class for testing
    class ModuleMock:
        def __init__(self):
            self.run_command_environ_update = {}
        def run_command(self, cmd):
            return (0, '', '')
        def get_bin_path(self, cmd, opt_dirs=[]):
            return ''

    hardware = SunOSHardware(ModuleMock())
    hardware.populate()
    assert hardware.facts['memtotal_mb'] > 0
    assert hardware.facts['swapfree_mb'] > 0
    assert hardware.facts['swaptotal_mb'] > 0

# Generated at 2022-06-11 02:57:48.099496
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # given
    module = FakeModule({})
    prtconf = '''Memory size: 4 GB'''
    swap = '''swap     total: 978544k bytes allocated + 58604k reserved = 1037148k used, 267780k available'''
    module.run_command.return_value = (0, prtconf, '')
    module.run_command.return_value = (0, swap, '')

    # when
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()

    # then
    assert memory_facts['memtotal_mb'] == 4096
    assert memory_facts['swapfree_mb'] == 260
    assert memory_facts['swaptotal_mb'] == 1000
    assert memory_facts['swap_allocated_mb'] == 948

# Generated at 2022-06-11 02:57:59.037805
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    '''
    Unit tests for method get_cpu_facts() of class SunOSHardware.
    '''
    collected_facts = {}
    # Test 1 on i86pc
    collected_facts['ansible_machine'] = 'i86pc'
    sw = SunOSHardware()
    sw.module = MagicMock()
    sw.module.run_command.return_value = (0, 'module: sun4v  class: misc\nbrand: x86  clock_MHz: 1600.000000\nchip_id: 0\nimplementation: MCP\nmodule_rev: 0\nserial_num: 0\n', '')
    cpu_facts = sw.get_cpu_facts(collected_facts)
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-11 02:58:10.856319
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import platform
    import os
    import tempfile
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    boottime_file = os.path.join(tmpdir, 'boottime.txt')

    # Create a temporary copy of the current boottime file
    if os.path.isfile('/etc/boottime'):
        boottime_file = tempfile.mkstemp()
        os.close(boottime_file[0])
        boottime_file = boottime_file[1]
        os.rename('/etc/boottime', boottime_file)

    # Setup boottime file

# Generated at 2022-06-11 02:58:15.258584
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun = SunOSHardware()
    uptime_test = True
    while uptime_test:
        uptime_facts = sun.get_uptime_facts()
        if uptime_facts['uptime_seconds']:
            uptime_test = False
    print ("\n")
    print ("system uptime in seconds: %s" % uptime_facts['uptime_seconds'])
    print ("\n")


if __name__ == '__main__':
    test_SunOSHardware_get_uptime_facts()

# Generated at 2022-06-11 02:58:20.144708
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {'uptime_seconds': 1548098499}
    module = MagicMock(run_command_environ_update={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    harware = SunOSHardware(module)
    assert harware.get_uptime_facts() == uptime_facts

# Generated at 2022-06-11 02:58:31.294240
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Set up the test class
    hwmod = SunOSHardware()
    hwmod.module = MagicMock()

    # Set up responses for command runs
    hwmod.module.run_command.return_value = (0,
                                             get_file_content('/usr/include/ansible/module_utils/facts/hardware/test_data/kstat_sderr_output.txt'),
                                             None)

    # Call the method
    res = hwmod.get_device_facts()
    assert res['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert res['devices']['sd0']['revision'] == '1.0'

# Generated at 2022-06-11 02:59:44.538786
# Unit test for method get_device_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:56.593226
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create an instance of the class to test
    test = SunOSHardware()

    # Create some mock input (copied from above)
    test.module.run_command.return_value = (0, 'Memory size: 2048 Megabytes', 'err:')
    test.module.run_command.return_value = (0, '8192k available, no reserve, no swap', 'err:')
    test.module.run_command.return_value = (0, '8192k allocated, 0k used, 8192k available', 'err:')

    # Run the tested method
    results = test.get_memory_facts()

    # Assert the results
    assert results['memtotal_mb'] == 2048
    assert results['swapfree_mb'] == 8
    assert results['swaptotal_mb'] == 8

# Generated at 2022-06-11 03:00:04.236916
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """Test case to check the legacy facts in Solaris.
       Verify that the facts are not empty or None.
    """
    module = FakeAnsibleModule({})
    sunos_fact_collector = SunOSHardwareCollector(module)
    facts = sunos_fact_collector.collect()

    assert facts.get('processor') is not None
    assert facts.get('memtotal_mb') is not None
    assert facts.get('swapfree_mb') is not None
    assert facts.get('swaptotal_mb') is not None
    assert facts.get('swap_allocated_mb') is not None
    assert facts.get('swap_reserved_mb') is not None
    assert facts.get('system_vendor') is not None
    assert facts.get('product_name') is not None
    assert facts

# Generated at 2022-06-11 03:00:15.719124
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    This method tests get_cpu_facts, which includes testing following
    derived facts:
        - processor_count
        - processor_cores

    Testing the derived facts was the main reason for having the method,
    since it is a non-trivial calculation from the prtdiag output.
    """
    import pytest

    from ansible.module_utils.common.text.formatters import bytes_to_human
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    sunos_hardware = SunOSHardware()

    cpu_facts = sunos_hardware.get_cpu_facts()

    processor_count = cpu_facts.get('processor_count')
    processor_cores = cpu_facts.get('processor_cores')
    # Number of CPUs, which equals number of sockets in the

# Generated at 2022-06-11 03:00:19.691874
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    collected_facts = {'ansible_machine': 'i86pc'}
    SunOSHardware.get_cpu_facts(collected_facts)

    collected_facts = {'ansible_machine': 'sun4v'}
    SunOSHardware.get_cpu_facts(collected_facts)



# Generated at 2022-06-11 03:00:23.574652
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    facts = {}
    facts['ansible_machine'] = 'i86pc'
    sunos_hardware = SunOSHardware(facts)
    sunos_hardware.populate()
    assert isinstance(sunos_hardware.data, dict) == True



# Generated at 2022-06-11 03:00:25.788903
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_helper = TestSunOSHardware()
    test_helper.test_get_dmi_facts()


# Generated at 2022-06-11 03:00:36.099077
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class ModuleMock(object):
        def run_command(self, cmd):
            return (0, 'unix:0:system_misc:boot_time    1548249689', '')

    class FactsMock(SunOSHardware):
        def __init__(self):
            pass

        def populate(self, collected_facts=None):
            collected_facts = {}
            return collected_facts

    test_facts = FactsMock()
    test_facts.module = ModuleMock()
    test_facts.get_uptime_facts()
    assert test_facts._collected_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-11 03:00:37.422375
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    SunOSHardware().get_uptime_facts()


# Generated at 2022-06-11 03:00:42.890869
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock(return_value=('', 'System Configuration: Oracle Corporation VirtualBox', ''))
    hw = SunOSHardware(module)
    dmi_facts = hw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'VirtualBox'



# Generated at 2022-06-11 03:03:08.495271
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/bin/true'

    sunos_hw = SunOSHardware()
    sunos_hw = sunos_hw.populate()
    assert sunos_hw['processor'] == []
    assert sunos_hw['processor_cores'] == 'NA'
    assert sunos_hw['processor_count'] == 0
    assert sunos_hw['memtotal_mb'] == 'NA'
    assert sunos_hw['swapfree_mb'] == 'NA'
    assert sunos_hw['swaptotal_mb'] == 'NA'
    assert sunos_hw['swap_allocated_mb'] == 0
   

# Generated at 2022-06-11 03:03:12.544527
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = SunOSHardware(module)
    rc, out, err = module.run_command("/usr/sbin/prtconf")
    for line in out.splitlines():
        if 'Memory size' in line:
            mem_size = int(line.split()[2])

    rc, out, err = module.run_command("/usr/sbin/swap -s")
    reserved = int(out.split()[5][:-1])
    used = int(out.split()[8][:-1])
    free = int(out.split()[10][:-1])
    swp_allocated = int(out.split()[1][:-1])

    memory_facts = hardware.get_memory_facts()

# Generated at 2022-06-11 03:03:23.651405
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts import FactCollector

    # required_collectors is a set containing the names of the default collectors
    # that are required to collect compacted facts.
    required_collectors = FactCollector._collector_classes.keys()

    # ansible_module_mock is a instance of MockAnsibleModule class
    ansible_module_mock = MockAnsibleModule()

    sunos_hardware = SunOSHardware(ansible_module_mock, None,
                                   required_collectors)

    # collected_facts is an object of class FactCollector
    collected_facts = FactCollector(ansible_module_mock,
                                    required_collectors)

    # Set fact ansible_machine to '

# Generated at 2022-06-11 03:03:32.241913
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    single_device = {'sderr:::Soft Errors': '0',
                     'sderr:::Size': '53687091200',
                     'sderr:::Serial No': 'VB0ad2ec4d-074a',
                     'sderr:::Illegal Request': '6',
                     'sderr:::Product': 'VBOX HARDDISK',
                     'sderr:::Predictive Failure Analysis': '0',
                     'sderr:::Vendor': 'ATA',
                     'sderr:::Hard Errors': '0',
                     'sderr:::Revision': '1.0',
                     'sderr:::Media Error': '0',
                     'sderr:::Transport Errors': '0'}


# Generated at 2022-06-11 03:03:41.540545
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
