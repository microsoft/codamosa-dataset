

# Generated at 2022-06-11 02:54:07.411296
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    '''
    Testcases for method get_dmi_facts of class SunOSHardware.
    '''
    expected_result = {'system_vendor': 'Sun Microsystems',
                       'product_name': 'SPARC Enterprise T5240'}

    # prtdiag -v output from Oracle Solaris SPARC T5240 server

# Generated at 2022-06-11 02:54:20.230647
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    def run_command(command):
        return 0, cpu_info, ''
    module = type('FakeModule', (), {'run_command': run_command})

# Generated at 2022-06-11 02:54:29.898710
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Mock out external modules
    from ansible.module_utils.common.text.formatters import bytes_to_human
    import ansible.module_utils.facts.hardware.sunos as sunos
    sunos.bytes_to_human = bytes_to_human
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector

    # Declare a module instance to be tested
    class FakeModule:
        def __init__(self):
            pass

    instance = sunos.SunOSHardware()
    instance.module = FakeModule()
    # Mock out module methods

# Generated at 2022-06-11 02:54:39.023583
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # set facts
    set_module_args(dict(
        ansible_machine='i86pc',
        ansible_processor='x64',
    ))
    hardware_mock = SunOSHardware(module)
    # run code to test
    hardware_mock.populate()
    # assert the result
    assert hardware_mock.facts['ansible_machine'] == 'i86pc'
    assert hardware_mock.facts['ansible_processor'] == 'x64'

# Generated at 2022-06-11 02:54:42.433367
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector()
    assert obj
    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'
    assert obj.required_facts == set(['platform'])
    assert obj.provide_facts == set(dir(SunOSHardware))


# Generated at 2022-06-11 02:54:46.086717
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
  out = "Memory size: 24536 Megabytes"
  facts = SunOSHardware(dict()).get_memory_facts(out)
  assert facts['memtotal_mb'] == 24536



# Generated at 2022-06-11 02:54:57.589480
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Test for kstats output
    module = AnsibleModule()
    class FakeModule:
        def __init__(self):
            self.run_command = module.run_command

    # Input data
    rc = 0

# Generated at 2022-06-11 02:55:07.500856
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_input = """sderr:0:sd1,err:Hard Errors 0
sderr:0:sd1,err:Illegal Request 0
sderr:0:sd1,err:Media Error 0
sderr:0:sd1,err:Predictive Failure Analysis 0
sderr:0:sd1,err:Product SUN72G 970.5G        9
sderr:0:sd1,err:Revision        20080124
sderr:0:sd1,err:Serial No       XXXXXXXXXXXX
sderr:0:sd1,err:Size    1000204189696
sderr:0:sd1,err:Soft Errors 0
sderr:0:sd1,err:Transport Errors        0
sderr:0:sd1,err:Vendor  SUN"""

    test_

# Generated at 2022-06-11 02:55:13.440180
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    m_module = MockModule()
    m_module.run_command = Mock(return_value=(0, 'Memory size: 8192 Megabytes\n', ''))

    s_module = SunOSHardware(m_module)
    res = s_module.get_memory_facts()
    assert res == {'memtotal_mb': 8192}


# Generated at 2022-06-11 02:55:20.919829
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class Module(object):
        def get_bin_path(self, *args, **kwargs):
            return "/usr/sbin/prtdiag"

        def run_command(self, *args, **kwargs):
            return 0, "System Configuration: \n  Sun Microsystems  T2000", ''

    test_object = SunOSHardware(Module())
    facts = test_object.get_dmi_facts()
    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'T2000'

# Generated at 2022-06-11 02:55:42.569525
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = DummyModule()
    module.run_command = MagicMock(return_value=(0, "", ""))
    setattr(module, 'params', {'gather_subset': ['all']})
    setattr(module, 'exit_json', MagicMock())
    h = SunOSHardware()
    h.module = module
    h.populate()
    assert module.run_command.call_count == 3



# Generated at 2022-06-11 02:55:47.813296
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module_mock = Mock()
    module_mock.run_command.return_value = (0, 'Memory size: 64 Megabytes', '')
    hw = SunOSHardware(module_mock)
    memory_facts = hw.get_memory_facts()
    assert memory_facts == {'memtotal_mb': 64}



# Generated at 2022-06-11 02:55:58.351588
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()

    # check that CPU facts were filled in
    assert hardware_facts['processor'][0].startswith('Intel(R)')
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor_count'] == 1
    # check that memory facts were filled in
    assert hardware_facts['memtotal_mb'] == 512
    assert hardware_facts['swapfree_mb'] == 998
    assert hardware_facts['swaptotal_mb'] == 998
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0

# Generated at 2022-06-11 02:56:00.593059
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = None
    facts = SunOSHardware(module).get_device_facts()

    assert 'devices' in facts
    assert 'sd' in facts['devices']

# Generated at 2022-06-11 02:56:11.910614
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    if module.check_mode:
        module.exit_json(changed=False)

    # test_SunOSHardware(module)
    d = SunOSHardware(module)
    # We do not want to run prtconf and prtdiag
    d.get_dmi_facts = lambda: dict()
    d.get_device_facts = lambda: dict()

    # Don't try to access /etc/mnttab
    d.get_mount_facts = lambda: dict()
    results = d.populate()
    assert results['ansible_processor']
    assert results['processor_cores']
    assert results['processor_count']
    assert results['memtotal_mb']

# Generated at 2022-06-11 02:56:14.535281
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware(None).get_cpu_facts()
    assert len(cpu_facts['processor_cores']) >= 1
    assert len(cpu_facts['processor']) >= 1
    assert len(cpu_facts['processor_count']) >= 1

# Generated at 2022-06-11 02:56:23.664430
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    hardware = SunOSHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    hardware.module.run_command_environ_update = {}
    hardware.get_cpu_facts = MagicMock(
        return_value={'processor': [], 'processor_cores': 0, 'processor_count': 0})
    hardware.get_memory_facts = MagicMock(
        return_value={'swapfree_mb': 0, 'swap_allocated_mb': 0,
                      'swap_reserved_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0})

# Generated at 2022-06-11 02:56:36.025428
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import Collector

    # Test uptime facts with kstat command returning valid output
    data = '''unix:0:system_misc:boot_time    1548249689'''
    module = FakeModule(data)

    c = SunOSHardwareCollector(module)
    c.collect()
    facts = c.get_facts()
    assert facts.get('ansible_facts')['uptime_seconds'] == 1588258381

    # Test uptime facts with kstat command returning invalid output
    data = '''unix:0:system_misc:boot_tim'''
    module = FakeModule(data)

    c = SunOSHardwareCollector(module)
    c.collect()
    facts = c.get_facts()

# Generated at 2022-06-11 02:56:47.050815
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Import module to test here
    from ansible.modules.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    module = type('AnsibleModule', (object,), {'run_command': lambda self, cmd: (0, get_file_content('/tmp/sunos_file'), None)})()
    hardware = SunOSHardware(module)
    hardware.populate()

# Generated at 2022-06-11 02:56:59.075194
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_subset='!all,!min'))
    test_object = SunOSHardware(module)
    module.exit_json(ansible_facts=dict(ansible_processor=["Fujitsu SPARC64 VII @ 2000MHz",
                                                           "Fujitsu SPARC64 VII @ 2000MHz"],
                                         ansible_machine='sun4v'))
    test_object.populate()
    assert test_object.get_cpu_facts() == {'processor_count': 2,
                                           'processor_cores': 4,
                                           'processor': ['Fujitsu SPARC64 VII @ 2000MHz',
                                                         'Fujitsu SPARC64 VII @ 2000MHz']}


# Generated at 2022-06-11 02:57:36.740847
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sh = SunOSHardware()
    uptime_facts = {}
    with open("/tmp/uptime_facts.txt", "r") as uptime_file:
        uptime_facts['uptime_seconds'] = uptime_file.readline().rstrip()
    assert sh.get_uptime_facts() == uptime_facts

# Generated at 2022-06-11 02:57:41.270673
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec={
            'filter': {'required': False, 'type': 'str'},
        },
        supports_check_mode=True
    )
    test = SunOSHardware(module=test_module)
    test_module.exit_json(changed=False, ansible_facts=test.populate())

# Generated at 2022-06-11 02:57:51.239364
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.virtual.sunos import SunOSVirtual
    # Stub to get past platform check in HardwareCollector.collect()
    class SolarisFacts(object):
        @property
        def dict(self):
            return {
                'platform': 'SunOS'
            }

    class Collector(SunOSHardwareCollector):
        def __init__(self):
            self.facts = SolarisFacts()
            self.virtual = SunOSVirtual()
            self.all_facts = {}

    collector = Collector()
    fact = collector._fact_class()

    assert fact.get_device_facts() == {}
    assert fact.get_device_facts()['devices'] == {}

# Generated at 2022-06-11 02:58:01.754044
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test to validate the cpu facts for SunOS.
    """
    hardware = SunOSHardware()
    hardware.module = MagicMock()
    hardware.module.run_command = MagicMock(return_value=(0, "module: sun4v", ""))
    hardware.module.run_command_environ_update = {"foo": "bar"}
    collected_facts = {'ansible_machine': 'i86pc'}

    cpu_facts = hardware.get_cpu_facts(collected_facts)

    assert cpu_facts['processor'] == ['sun4v']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-11 02:58:11.595296
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    required_args = {
        'run_command.return_value': (
            0,
            'unix:0:system_misc:boot_time    1548249689',
            ''
        ),
        'get_file_content.return_value': '',
    }
    module = FakeAnsibleModule(**required_args)
    hardware = SunOSHardware(module=module)

    uptime_facts = hardware.get_uptime_facts()
    expected_uptime_facts = {
        'uptime_seconds': int(time.time() - 1548249689)
    }

    assert uptime_facts['uptime_seconds'] == expected_uptime_facts['uptime_seconds']



# Generated at 2022-06-11 02:58:17.423966
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hardware = SunOSHardware(module)
    collected_facts = {}

    collected_facts['ansible_machine'] = 'sparc64'
    hardware.populate(collected_facts=collected_facts)

    collected_facts['ansible_machine'] = 'i86pc'
    hardware.populate(collected_facts=collected_facts)


# Generated at 2022-06-11 02:58:25.699017
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    SunOSHardware().get_cpu_facts() == {'processor': [u'SUNW,Ultra-80'], 'processor_count': 1, 'processor_cores': 2}
    SunOSHardware().get_cpu_facts() == {'processor': [u'SUNW,Ultra-80'], 'processor_count': 1, 'processor_cores': 2}
    SunOSHardware().get_cpu_facts() == {'processor': [u'SUNW,Ultra-80'], 'processor_count': 1, 'processor_cores': 2}

# Generated at 2022-06-11 02:58:34.003436
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Execute SunOSHardwareCollector constructor
    sunoshardwarecollector = SunOSHardwareCollector()
    # Check if required_facts is set to 'platform'
    if sunoshardwarecollector.required_facts != set(['platform']):
        raise Exception("Expected { 'platform' } to equal { 'platform' }")
    # Check if _platform is set to 'SunOS'
    if sunoshardwarecollector._platform != 'SunOS':
        raise Exception("Expected 'SunOS' to equal 'SunOS'")
    # Check if _fact_class is set to SunOSHardware
    if sunoshardwarecollector._fact_class != SunOSHardware:
        raise Exception("Expected SunOSHardware to equal SunOSHardware")

# Generated at 2022-06-11 02:58:44.925075
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    from ansible.module_utils.facts import Processor

    import tempfile
    import shutil
    import os

    processor = Processor()
    processor._cache = {}

    # create a temp directory to store the fake kstat file
    tmp_dir = tempfile.mkdtemp()

    # create a file containing the kstat records we need to test get_uptime_facts()
    fd, kstatFile = tempfile.mkstemp(dir=tmp_dir)
    with os.fdopen(fd, 'w') as f:
        f.write("""unix:0:system_misc:boot_time    1548249689
""")
    # create a set of environ attributes that map to our temp directory
    kstat_env = {'KSTAT_PATH': tmp_dir, 'KSTAT_module_path': tmp_dir }

# Generated at 2022-06-11 02:58:49.140668
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class SunOSHardware
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunOSHardware = SunOSHardware()
    cpu_facts = sunOSHardware.get_cpu_facts()
    assert cpu_facts['processor']


# Generated at 2022-06-11 02:59:30.278954
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware(module=None)
    hardware.module.run_command = lambda *args, **kwargs: ('', 'Memory size:   8192 Megabytes\n', '')
    assert hardware.get_memory_facts() == {'memtotal_mb': 8192}



# Generated at 2022-06-11 02:59:37.520080
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    facts = SunOSHardware().get_memory_facts()
    assert type(facts['memtotal_mb']) == int
    assert facts['memtotal_mb'] > 0
    assert type(facts['swap_allocated_mb'] == int)
    assert facts['swap_allocated_mb'] >= 0
    assert type(facts['swap_reserved_mb'] == int)
    assert facts['swap_reserved_mb'] >= 0
    assert type(facts['swaptotal_mb'] == int)
    assert facts['swaptotal_mb'] >= 0
    assert type(facts['swapfree_mb'] == int)
    assert facts['swapfree_mb'] >= 0

# Generated at 2022-06-11 02:59:39.674339
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    assert SunOSHardware().get_memory_facts()['memtotal_mb'] == 0


# Generated at 2022-06-11 02:59:50.422888
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    expectation = {'system_vendor': 'Fujitsu', 'product_name': 'SUNW,SPARC-Enterprise-T5120'}
    m = SunOSHardware()
    m._module = FakeModule()

# Generated at 2022-06-11 02:59:56.025736
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    h = SunOSHardware()
    f = '\nSystem Configuration: VMware, Inc.  VMware Virtual Platform\n'
    dmi_facts = h.get_dmi_facts(f)
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-11 03:00:04.013738
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.facts import FactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Prepare test fixture
    fake_module = FactCollector()
    fake_module.run_command = lambda command: (0, '', '')
    SunOSHardware.populate = lambda self, collected_facts=None: {
        "processor": ["Intel(r) Core(TM) i5-3470 CPU @ 3.20GHz @ 3200MHz",
                      "Intel(r) Core(TM) i5-3470 CPU @ 3.20GHz @ 3200MHz"],
        "processor_cores": 4,
        "processor_count": 2
    }


# Generated at 2022-06-11 03:00:15.111415
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Should return uptime in seconds
    """
    module = AnsibleModule(argument_spec=dict())

    # sample kstat output:
    # unix:0:system_misc:boot_time    1548249689
    module.run_command = MagicMock(return_value=(0, "unix:0:system_misc:boot_time\t1548249689", ""))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-11 03:00:21.879780
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    collected_facts = dict(ansible_facts=dict(hardware=dict()))
    hardware = SunOSHardware(module)
    result = hardware.populate()
    assert result.get('uptime_seconds') is not None, 'Failed to get uptime facts.'
    assert result.get('devices') is not None, 'Failed to get devices facts.'
    assert result.get('swap_allocated_mb') is not None, 'Failed to get swap allocated facts.'
    assert result.get('swap_reserved_mb') is not None, 'Failed to get swap reserved facts.'

# Generated at 2022-06-11 03:00:26.134801
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_module = type('', (), {'run_command': run_command_mock})

    hw = SunOSHardware(module=test_module)
    result = hw.get_device_facts()

    assert result == sample_result1, "Result does not match expected sample output"


# Generated at 2022-06-11 03:00:38.100002
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-11 03:01:53.744733
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert len(cpu_facts['processor']) == 4
    assert cpu_facts['processor'][0] == 'SPARC64-Viemu'


# Generated at 2022-06-11 03:01:58.018164
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    expected_keys = [
        'processor',
        'processor_count',
        'processor_cores',
    ]

    hardware = SunOSHardware()
    cpu_facts = hardware.get_cpu_facts()

    for key in expected_keys:
        assert key in cpu_facts


# Generated at 2022-06-11 03:02:02.727921
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test that all required facts are present after
    # instantiation of SunOSHardwareCollector
    module_name = 'ansible_facts.hardware.sunos'
    required_facts = set(['platform'])
    collector = SunOSHardwareCollector(module_name)
    assert collector.required_facts == required_facts


# Generated at 2022-06-11 03:02:04.052601
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()


# Generated at 2022-06-11 03:02:09.673373
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collections import SunnyOSFacts
    result = {}
    my_obj = SunOSHardware()
    my_obj.populate(result)
    # Test if all facts are present in the result
    assert set(SunnyOSFacts.fetch().keys()).issubset(set(result.keys()))
    # Test that the result is an instance of dict
    assert isinstance(result, dict)


# Generated at 2022-06-11 03:02:19.292795
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:02:21.378357
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'



# Generated at 2022-06-11 03:02:30.663169
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.device_facts['devices']['sderr:::Vendor'] == 'vendor'
    assert hardware.dmi_facts['system_vendor'] == 'vendor'
    assert hardware.cpu_facts['processor_cores'] == 'NA'
    assert hardware.cpu_facts['processor_count'] == 'NA'
    assert hardware.cpu_facts['processor'] == []
    assert hardware.memory_facts['swaptotal_mb'] == 'NA'
    assert hardware.memory_facts['swapfree_mb'] == 'NA'
    assert hardware.memory_facts['swap_reserved_mb'] == 'NA'
    assert hardware.memory_facts['swap_allocated_mb'] == 'NA'
   

# Generated at 2022-06-11 03:02:41.633187
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import os
    import stat
    import tempfile
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content


# Generated at 2022-06-11 03:02:47.652147
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = type('TestModule', (object,), {})()

    class TestSubprocessModule(type('TestSubprocessModule', (object,), {})):
        def run_command(self, command, check_rc=False):
            if command == "/usr/sbin/prtconf":
                return (0, "Memory size: 8192 Megabytes", "")

            if command == "/usr/sbin/swap -s":
                return (0, "resv	12K	alloc	12K	free	10485716K	\n", "")

    test_module.subprocess = TestSubprocessModule()

    sunos = SunOSHardware()
    result = sunos.get_memory_facts(test_module)
    assert result['memtotal_mb'] == 8192
    assert result['swaptotal_mb']