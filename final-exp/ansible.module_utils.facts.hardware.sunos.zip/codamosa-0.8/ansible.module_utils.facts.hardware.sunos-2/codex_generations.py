

# Generated at 2022-06-11 02:54:03.480772
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    platform = SunOSHardware(module)
    rc, out, err = module.run_command('/usr/bin/kstat -p sderr:::Product')
    out = out.replace('\t', ':')
    device_facts_expected = {'devices': {'sd0': {'product': out.split(':')[1].strip()}}}
    assert device_facts_expected == platform.get_device_facts()


# Generated at 2022-06-11 02:54:16.215348
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    hardware = SunOSHardware()
    hardware.module = MagicMock()

# Generated at 2022-06-11 02:54:27.286869
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class TestModule:
        def __init__(self):
            self.run_command_environ_update = None
        @staticmethod
        def run_command(args):
            if args == '/usr/sbin/prtconf':
                return(0,
                       'System Configuration:',
                       '')
            else:
                return(0,
                       'total: 1234 kB\n'
                       'used: 123 kB\n'
                       'free: 1111 kB\n',
                       '')
        @staticmethod
        def get_bin_path(command, opt_dirs=[]):
            return command
    test_module = TestModule()
    hardware_facts = SunOSHardware()
    hardware_facts.module = test_module
    hardware_facts.populate()

# Generated at 2022-06-11 02:54:31.481995
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {}

    dmi_facts['system_vendor'] = 'Fujitsu'
    dmi_facts['product_name'] = 'SUN FIRE X4270 M3'

    SunOSHardware().get_dmi_facts()

# Generated at 2022-06-11 02:54:42.081302
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Create an instance of the SunOSHardware class
    test_ins = SunOSHardware()

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), dict(run_command=MagicMock(side_effect=[(0, '/usr/sbin/prtconf:', ''),
                                                                                            (0, 'System Configuration: VMware, Inc. VMware Virtual Platform\nSystem Configuration: Oracle Corporation sun4v\nMemory size: 32768 Megabytes\n', '')])))()

    # Set the module to the instance
    test_ins.module = mock_module

    # This is the output we expect from the test
    output = {'memtotal_mb': 32768}

    # And this is the output we get from the test
    assert test_ins.get_memory_facts() == output

#

# Generated at 2022-06-11 02:54:54.110866
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})

    # Instantiate SunOSHardware class
    sunoshw = SunOSHardware(module)

    # These should be defined for all platforms.
    facts = {
        'platform': 'SunOS',
        'ansible_facts': {
            'processor': [
                'SUNW,T2000  @ 1500MHz'
            ]
        }
    }

    # Call populate method
    new_facts = sunoshw.populate(facts)

    assert 'devices' in new_facts
    assert 'dmi' in new_facts
    assert new_facts['dmi']['product_name'] == 'T2000'
    assert new_facts['dmi']['system_vendor'] == 'Sun Microsystems'
    assert 'memtotal_mb' in new_facts

# Generated at 2022-06-11 02:55:05.097147
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.sunos.SunOSHardware'
    facts = {'platform': 'SunOS'}
    up = __import__(module, fromlist=['AnsibleModule', 'run_command'])
    class MockModule(object):
        def __init__(self):
            self.run_command = up.run_command
            self.get_bin_path = up.get_bin_path
    my_object = SunOSHardware(MockModule())
    test_results = my_object.get_device_facts()

    assert isinstance(test_results, dict)
    assert 'devices' in test_results
    assert isinstance(test_results['devices'], dict)

# Generated at 2022-06-11 02:55:17.573412
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MagicMock()
    module.run_command_environ_update = {}
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/usr/sbin/prog"

    sunos_cpu_facts_list = [{'clock_MHz': '1',
                             'implementation': 'Sun Microsystems, Inc. sun4u',
                             'processor': 'Sun Microsystems, Inc. sun4u @ 1MHz'},
                            {'clock_MHz': '1',
                             'implementation': 'Sun Microsystems, Inc. sun4u',
                             'processor': 'Sun Microsystems, Inc. sun4u @ 1MHz'}]

    for cpu_fact in sunos_cpu_facts_list:
        sunos

# Generated at 2022-06-11 02:55:22.917171
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Asserts output of SunOSHardware.get_dmi_facts()
    with mocked input
    """
    output = """
System Configuration: Oracle Corporation sun4v

SPARC T5-2 Server (1 X SPARC T5 Processor)

System clock frequency:  100000000 Hz

Memory size: 7936 Megabytes
    """

    class MockModule:
        def run_command(self, cmd):
            return 0, output, ''

    hardware = SunOSHardware(MockModule())
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}



# Generated at 2022-06-11 02:55:33.606443
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = FakeAnsibleModule()
    fact_class = SunOSHardware()

    # setup prtconf output
    prtconf_out = (b"Memory size: 512 Megabytes\n"
                   b"System Peripherals (Software Nodes):\n"
                   b"  pci, instance #0\n"
                   b"    type: pci\n"
                   b"    name: pci\n"
                   b"    status: ok\n"
                   b"\n")

    # setup swap -s output
    swap_out = (b"total: 15464k bytes allocated + 3444k reserved = 15808k used, "
                b"1201472k available")

    module.run_command.side_effect = [(0, prtconf_out, None),
                                      (0, swap_out, None)]

   

# Generated at 2022-06-11 02:56:00.382637
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    platform = 'SunOS'
    module = MagicMock()
    module.run_command = MagicMock()

    # prtdiag output is empty
    out = ''
    rc = 1
    err = ''
    module.run_command.return_value = (rc, out, err)
    dmi_facts = SunOSHardware().get_dmi_facts()
    assert dmi_facts.get('system_vendor') is None
    assert dmi_facts.get('product_name') is None

    # prtdiag returns an error
    out = ''
    rc = 2
    err = 'some error'
    module.run_command.return_value = (rc, out, err)
    dmi_facts = SunOSHardware().get_dmi_facts()

# Generated at 2022-06-11 02:56:11.729507
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    hardware = SunOSHardware()

    # Mock the run_command() method

# Generated at 2022-06-11 02:56:16.449974
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # test for SunOS
    module = AnsibleModule(dict(ANSIBLE_SYSTEM_HOSTNAME='localhost'))
    module.params = {}
    module.exit_json = lambda x: x
    set_module_args(dict(gather_subset='all'))
    obj = SunOSHardware(module=module)
    facts = obj.populate()
    assert facts['ansible_system_vendor'] == 'Oracle Corporation'
    assert facts['ansible_devices']['sda']['vendor'] == 'ATA'


# Generated at 2022-06-11 02:56:24.467037
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts import timeout

    sun_obj = SunOSHardware()
    result = {}
    with open("test/units/module_utils/facts/hardware/sunos/test_get_cpu_facts", "rb") as output:
        result['stdout'] = output.read()
        result['stdout'] = to_bytes(result['stdout'])
        result['stderr'] = b''
        result['rc'] = 0

    sun_obj.module.run_command.return_value = result
    res_data = sun_obj.get_cpu_facts()


# Generated at 2022-06-11 02:56:28.959456
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kwargs: None
    hardware = SunOSHardware(module)
    hardware.populate()
    assert 'memtotal_mb' in hardware.facts



# Generated at 2022-06-11 02:56:33.931601
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    sunoshw = SunOSHardware(module)

    all_facts = {}
    all_facts['ansible_facts'] = {}

    sunoshw.populate(all_facts)

    assert 'ansible_facts' in all_facts, 'SunOSHardware populate did not create ansible_facts'
    assert 'ansible_devices' in all_facts['ansible_facts'], 'SunOSHardware populate did not set ansible_devices'
    assert 'ansible_dmi' in all_facts['ansible_facts'], 'SunOSHardware populate did not set ansible_dmi'
    assert 'ansible_mounts' in all_facts['ansible_facts'], 'SunOSHardware populate did not set ansible_mounts'
    assert 'ansible_system_vendor'

# Generated at 2022-06-11 02:56:45.413899
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module_mock = {}

    # Set up kstat cpu_info command output
    kstat_cpu_info_output = ('module: cpu_info0\nbrand     Intel(r) Xeon(r) CPU E5-2683 v4 @ 2.10GHz\n'
                             'chip_id   0\nclock_MHz 2100\nimplementation   GenuineIntel\n'
                             'module: cpu_info1\nbrand     Intel(r) Xeon(r) CPU E5-2683 v4 @ 2.10GHz\n'
                             'chip_id   0\nclock_MHz 2100\nimplementation   GenuineIntel\n')

    # Set up the module_mock run_command method

# Generated at 2022-06-11 02:56:58.513868
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:06.702949
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Create a FakeModule to simulate AnsibleModule
    module = FakeModule()
    # Create SunOSHardwareCollector object with AnsibleModule
    # as a constructor parameter
    sunos_obj = SunOSHardwareCollector(module)
    # Test that fact_class of SunOSHardwareCollector returned
    # expected class
    assert sunos_obj.fact_class == SunOSHardware
    # Test that platform of SunOSHardwareCollector returned
    # the expected platform
    assert sunos_obj.platform == 'SunOS'
    # Test that required_facts of SunOSHardwareCollector returned
    # the expected set of facts
    assert sunos_obj.required_facts == set(['platform'])


# Generated at 2022-06-11 02:57:12.584253
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {"system_vendor": "Fujitsu",
                 "product_name": "SPARC ENTERPRISE T5440"}
    sample_prtdiag = """System Configuration: Fujitsu SPARC ENTERPRISE T5440
System clock frequency: 700 MHz
Memory size: 32768 Megabytes
"""
    module = None
    hardware = SunOSHardware({}, module)

    out = hardware.get_dmi_facts(sample_prtdiag)
    assert(dmi_facts == out)


# Generated at 2022-06-11 02:57:56.828983
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockAnsibleModule('SunOSHardware')
    module.get_bin_path.side_effect = lambda x, y: x

    def run_command_side_effect(*args, **kwargs):
        # populate_memtotal_mb
        if args[0] == ['/usr/sbin/prtconf']:
            return (0, 'Memory size: 8192 Megabytes', '')
        # populate_swap_facts
        elif args[0] == ['/usr/sbin/swap', '-s']:
            return (0, 'total: 1663640k bytes allocated + 374512k reserved = 2038152k used, 53645544k available', '')
        # populate_cpu_facts

# Generated at 2022-06-11 02:58:08.565271
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # FIXME: Use full path to path
    class ModuleMock:
        def run_command(self, cmd):
            return 0, "module: SUNW,UltraSPARC-IV+\n" \
                      "clock_MHz: 1628\n" \
                      "cpu_type: sparcv9+vis2\n" \
                      "chip_id: F401008020003c0\n" \
                      "brand: Sun Microsystems, UltraSPARC-T2 (chipid 0, clock 1628 MHz)\n", ''

    m = ModuleMock()
    h = SunOSHardware()
    h.module = m

    cpu_facts = h.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    assert 'processor' in cpu_facts

# Generated at 2022-06-11 02:58:12.529447
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOSHardware = SunOSHardware()
    out = 'System Configuration: Sun Microsystems  sun4u'
    dmi_facts = SunOSHardware.get_dmi_facts(out)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

# Generated at 2022-06-11 02:58:21.479404
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(dict())
    module.run_command = MagicMock(return_value=(0, 'System Configuration: VMware, Inc. VMware Virtual Platform', ''))
    SunOSHardwareCollector.conditionally_add(module, [''])
    assert module.exit_json.call_count == 2

    module.exit_json.reset_mock()
    module.run_command = MagicMock(return_value=(1, 'System Configuration: VMware, Inc. VMware Virtual Platform', 'error'))
    SunOSHardwareCollector.conditionally_add(module, [''])
    assert module.exit_json.call_count == 0
    assert module.fail_json.call_count == 1

    module.exit_json.reset_mock()
    module.fail_json.reset_mock()
    module.run_command

# Generated at 2022-06-11 02:58:32.394677
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    class MockModule(object):
        def __init__(self, run_command_result):
            self._run_command_result = run_command_result
            self.run_command_calls = 0

        def run_command(self, args, **kwargs):
            self.run_command_calls += 1
            return self._run_command_result[self.run_command_calls - 1]

        def get_bin_path(self, app, opt_dirs=None):
            return '/usr/sbin/' + app

    # Case 1: Oracle Corporation Sun Microsystems Sun Fire V490 (4 X UltraSPARC-IV+)
    #
    # System Configuration:  Oracle Corporation Sun Microsystems Sun Fire V490
    #      System clock frequency:  50 MHz
    #                     Memory size:  4096 Megabytes
   

# Generated at 2022-06-11 02:58:39.328237
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '1548249689', '')

    fact_class = SunOSHardware(module)
    uptime_facts = fact_class.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 1558452838 - 1548249689

# Generated at 2022-06-11 02:58:48.284143
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    run_cmd_mock = []


# Generated at 2022-06-11 02:58:58.580203
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    import sys

    sys.modules['ansible'] = type('ansible', (), {'__version__': '2.9.0', '__file__': 'lib/ansible/__init__.py'})
    sys.modules['ansible.module_utils'] = type('ansible.module_utils', (), {'common': type('common', (), {'text': type('text', (), {'formatters': type('formatters', (), {'bytes_to_human': type('bytes_to_human', (), {'__name__': 'bytes_to_human'})})})})})

# Generated at 2022-06-11 02:59:01.671992
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec={})
    SunOSHardware.module = module

    SunOSHardware.get_device_facts()



# Generated at 2022-06-11 02:59:11.807462
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:58.995552
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    f, t, h = dict(), dict(), dict()
    t[0] = (f, h)
    f['ansible_machine'] = 'i86pc'
    facts = dict(ansible_machine='i86pc')
    hardware = SunOSHardware(facts)
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = [0, 'System Configuration: Oracle Corporation sun4v', '']
    h['ansible_system_vendor'] = 'Oracle Corporation'
    h['ansible_product_name'] = 'sun4v'
    t[1] = (f, h)
    f['ansible_machine'] = 'sun4v'
    facts = dict(ansible_machine='sun4v')
    hardware = SunOSHardware(facts)
    hardware.module = MagicMock

# Generated at 2022-06-11 03:00:07.031991
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleFactCollector
    from ansible.module_utils.facts.collector.sunos import SunOSHardwareCollector

    kstat = to_bytes('unix:0:system_misc:boot_time    1548249689')
    test_module = AnsibleModuleMock(kstat=kstat)
    test_hardware_collector = SunOSHardwareCollector(module=test_module)

    assert test_hardware_collector.get_uptime_facts() == {'uptime_seconds': 1517868558}



# Generated at 2022-06-11 03:00:18.721995
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    from ansible.module_utils.facts.hardware.sunos.test_SunOSHardwareCollector import mock_module
    from ansible.module_utils.facts.hardware.test_Hardware import MockKstat

    params = MockKstat.get_kstat_string_output('cpu_info', 'SunOSHardwareCollector')
    mock_module.run_command.return_value = (0, params, '')

    # instantiate a SunOSHardware() object
    sunos_hardware = SunOSHardwareCollector.fetch_facts(mock_module)

    # test if the number of cpu cores reported by "kstat cpu_info" matches
    # the number of processors that were identified
    assert len(sunos_hardware['ansible_processor']) == sunos_hardware['ansible_processor_cores']

# Generated at 2022-06-11 03:00:26.086054
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class FakeModule(object):
        def run_command(self):
            return (0, 'unix:0:system_misc:boot_time    1548249689', '')

    class FakeSunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = FakeModule()

    uh = FakeSunOSHardware()
    uptime_facts = uh.get_uptime_facts()

    # uptime = $current_time - $boot_time
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-11 03:00:34.728366
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    collected_facts = {'ansible_machine': 'i86pc'}

    sunos_hardware = SunOSHardware(dict(), dict())
    sunos_hardware.populate(collected_facts)

    cpu_facts = sunos_hardware.get_cpu_facts(collected_facts)
    assert len(cpu_facts) == 5
    assert len(cpu_facts['processor']) == 2
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2



# Generated at 2022-06-11 03:00:42.529058
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    '''
    Test the ``get_memory_facts()`` method of ``SunOSHardware``
    '''
    module = FakeModule()
    hardware = SunOSHardware(module)
    out_memory_facts = hardware.get_memory_facts()
    assert out_memory_facts['memtotal_mb'] == 12
    assert out_memory_facts['swapfree_mb'] == 49
    assert out_memory_facts['swap_allocated_mb'] == 50
    assert out_memory_facts['swap_reserved_mb'] == 51
    assert out_memory_facts['swaptotal_mb'] == 50


# Generated at 2022-06-11 03:00:48.874738
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    in_data = """
    System Configuration: Sun Microsystems Hypervisor
    System clock frequency: 148 MHz
    Memory size: 16384 Megabytes
    Processor type: i386
    Processor clock frequency: 2930 MHz
    """
    expected_out_data = {'system_vendor': 'Sun Microsystems', 'product_name': 'Hypervisor'}

    m = SunOSHardware({})
    out_data = m.get_dmi_facts()

    assert out_data == expected_out_data

# Generated at 2022-06-11 03:00:59.480865
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = type('TestModule', (object,), {})()
    module.run_command = run_command
    hardware = SunOSHardware(module, {})
    cpu = hardware.get_cpu_facts()
    assert cpu['processor'] == ['SPARC_T4 (chipid 0, clock 1500 MHz)']
    assert cpu['processor_count'] == 2
    assert cpu['processor_cores'] == 10
    assert cpu['processor_vcpus'] == 20

    module.run_command = run_command_old
    cpu = hardware.get_cpu_facts()
    assert cpu['processor'] == ['UltraSPARC-T1 (chipid 0, clock 1000 MHz)']
    assert cpu['processor_count'] == 2
    assert cpu['processor_cores'] == 4
    assert cpu['processor_vcpus'] == 8

#

# Generated at 2022-06-11 03:01:08.893355
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    class mymodule(object):
        def __init__(self):
            self.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

    class my_SunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = mymodule()

    test_SunOSHardware = my_SunOSHardware()
    assert test_SunOSHardware.get_memory_facts() == {'memtotal_mb': 511,
                                                    'swapfree_mb': 2048,
                                                    'swap_allocated_mb': 0,
                                                    'swap_reserved_mb': 2048,
                                                    'swaptotal_mb': 2048}



# Generated at 2022-06-11 03:01:19.334110
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = MagicMock()
    module.run_command.return_value = (0, """module: cpu_info
instance: 0
class: misc
chip_id         16714204
implementation  sparc
brand           sun4v
clock_MHz       1798
revision        0x20001
chip            SUNW,UltraSPARC-T2
board           SUNW,Sun-Fire-T200
cpu_type        sparcv9
chiprev         2.0
model           SUNW,SPARC-Enterprise-T200
"""
                                      , '')
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    expected_result = {'processor': ['sun4v @ 1798MHz']}
    assert cpu_facts == expected_result

# Generated at 2022-06-11 03:02:35.169149
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class SunOSHardware
    """
    class args:
        def __init__(self):
            self.module = None
            self.run_command_environ_update = None
            self.run_command_check_rc = None
            self.get_bin_path_check_rc = None

    class ModuleStub:
        def __init__(self):
            self.params = args()


# Generated at 2022-06-11 03:02:45.974383
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sh = SunOSHardware()

    # input:
    # sderr:0:sd0,err:Hard Errors     0
    # sderr:0:sd0,err:Illegal Request 6
    # sderr:0:sd0,err:Media Error     0
    # sderr:0:sd0,err:Predictive Failure Analysis     0
    # sderr:0:sd0,err:Product VBOX HARDDISK   9
    # sderr:0:sd0,err:Revision        1.0
    # sderr:0:sd0,err:Serial No       VB0ad2ec4d-074a
    # sderr:0:sd0,err:Size    5368709

# Generated at 2022-06-11 03:02:55.335381
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:03:05.853767
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:03:13.615049
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    out = """sderr:::Product                       VBOX HARDDISK
sderr:::Revision                      1.0
sderr:::Serial No                     VB741bd8f5-c722
sderr:::Size                          53687091200
sderr:::Vendor                        ATA
sderr:::Hard Errors                   0
sderr:::Soft Errors                   0
sderr:::Transport Errors              0
sderr:::Media Error                   0
sderr:::Predictive Failure Analysis   0
sderr:::Illegal Request               391"""

    class Module:
        def __init__(self):
            self.run_command_kstat = {'rc': 0, 'out': out, 'err': ''}

        def run_command(self, cmd):
            return self.run

# Generated at 2022-06-11 03:03:16.196790
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    SunOSHardwareCollector().collect(dict(ansible_facts={}))


# Generated at 2022-06-11 03:03:25.259288
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    raw_output = """System Configuration: Sun Microsystems sun4u
Memory size: 512 Megabytes
System Peripherals (Software Nodes):
SUNW,UltraAX-i2                                          SUNW,UltraAX-i2                  
SUNW,SBus,GigaSwift Ethernet                              SUNW,SBus,GigaSwift Ethernet   
SUNW,pci                                                  SUNW,pci                        
SUNW,SBus,qec    """

    module = MockModule()
    module.run_command('/usr/bin/uname -i').return_value = (0, 'sun4u', '')
    module.run_command('/usr/platform/sun4u/sbin/prtdiag').return_value = (0, raw_output, '')

# Generated at 2022-06-11 03:03:27.399295
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    myhw = SunOSHardwareCollector(None)
    assert myhw._fact_class == SunOSHardware
    assert myhw._platform == 'SunOS'
    assert myhw.required_facts == set(['platform'])

# Generated at 2022-06-11 03:03:36.646950
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = None
    collected_facts = {}
    hardware = SunOSHardware(module)
    result = hardware.populate(collected_facts=collected_facts)
    assert 'processor' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swap_allocated_mb' in result
    assert 'swap_reserved_mb' in result
    assert 'system_vendor' in result
    assert 'product_name' in result
    assert 'devices' in result
    assert 'mounts' in result
    assert 'uptime_seconds' in result


testcases = {}
testcases['test_SunOSHardware_populate'] = test_SunOSHardware_populate

# Generated at 2022-06-11 03:03:41.938326
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleStub()

    # test with just the required facts
    facts = {}
    collector = SunOSHardwareCollector(module=module, facts=facts)
    collected_facts = collector.collect()

    assert 'processor' in collected_facts
    assert 'memtotal_mb' in collected_facts
    assert 'uptime_seconds' in collected_facts
    assert 'devices' in collected_facts
    assert 'mounts' in collected_facts

