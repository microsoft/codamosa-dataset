

# Generated at 2022-06-11 02:54:10.097170
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    Test get_device_facts of SunOSHardware.
    """
    # Create a test double for module
    import ansible.module_utils.facts.hardware.sunos
    test_module = ansible.module_utils.facts.hardware.sunos.AnsibleModule(
        argument_spec = {},
        check_invalid_arguments = False,
        bypass_checks = True
    )

    # Create a test double for get_device_facts

# Generated at 2022-06-11 02:54:22.910920
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """ Testcase for method SunOSHardware.get_memory_facts() """
    class TestModule():
        def run_command(self, cmd, **kwargs):
            if cmd == ["/usr/sbin/prtconf"]:
                output = 'Memory size: 32768 Megabytes'
                return (0, output, None)
            elif cmd == "/usr/sbin/swap -s":
                output = 'Total swap space: 9999 Megabytes\n'
                output += 'Allocated swap space: 4455 Megabytes\n'
                output += 'Available swap space: 5440 Megabytes\n'
                output += 'Total swap space: 9999 Megabytes\n'
                output += 'Allocated swap space: 4455 Megabytes\n'
                output += 'Available swap space: 5440 Megabytes\n'

# Generated at 2022-06-11 02:54:29.676377
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.sunos.sunos import get_bin_path
    import mock

    module = mock.MagicMock()
    module.run_command.return_value = 0, 'Memory size:   8192 Megabytes', None
    module.get_bin_path.side_effect = get_bin_path
    hw = SunOSHardware(module)
    facts = hw.get_memory_facts()
    if facts['memtotal_mb'] != 8192:
        raise Exception('get_memory_facts failed')

# Generated at 2022-06-11 02:54:32.960603
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    s = SunOSHardware({})
    s.populate()


fact_class = SunOSHardware
collector = SunOSHardwareCollector

# Generated at 2022-06-11 02:54:40.562394
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time

    current_time = int(time.time())
    boot_time = current_time - 23456

    # mock kstat output
    kstat_output = 'unix:0:system_misc:boot_time    {}'.format(boot_time)

    s = SunOSHardware({"platform": "SunOS"})
    s.module.run_command = lambda x: (0, kstat_output, "")

    assert s.get_uptime_facts() == {'uptime_seconds': 23456}


# Generated at 2022-06-11 02:54:44.764726
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleStub()
    collector = SunOSHardwareCollector(module=module)
    result = collector.collect(module, module.params)
    assert 'devices.sd0.product' in result


# Generated at 2022-06-11 02:54:45.411587
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    SunOSHardware({})

# Generated at 2022-06-11 02:54:56.729226
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, command, check_rc=True, environ_update=None):
            self.run_command_calls.append(command)
            if command == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 0, 'unix:0:system_misc:boot_time\t1548249689', ''
            else:
                return 0, '', ''

    # Mock module and instantiate SunOSHardware
    module = MockModule()
    fact_class = SunOSHardware(module)

    # Mock the time module to a known value
    time_module = time
    time_module.time = lambda: 1548249689

    # Call get

# Generated at 2022-06-11 02:55:07.086319
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    import tempfile
    import shutil
    import os

    test_prtconf_stdout = """
System Configuration: Sun Microsystems sun4v Sun Fire T5140
Memory size: 8192 Megabytes
"""
    test_prtconf_stderr = """"""
    test_swap_stdout = """swapfile             dev  swaplo   blocks   free
/var/swapfile       -1      0      65352  56684"""
    test_swap_stderr = """"""

# Generated at 2022-06-11 02:55:17.242589
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mock_module = MagicMock()
    mock_module.run_command.side_effect = [
        (0, 'Memory size: 16384 Megabytes', ''),
        (0, '2048 blocks  6144K bytes      allocated\n12288 blocks  36864K bytes      reserved', '')]

    sunoshw = SunOSHardware(mock_module)
    facts = sunoshw.get_memory_facts()
    assert facts['memtotal_mb'] == 16384
    assert facts['swaptotal_mb'] == 16
    assert facts['swapfree_mb'] == 16
    assert facts['swap_allocated_mb'] == 6
    assert facts['swap_reserved_mb'] == 12



# Generated at 2022-06-11 02:55:44.021579
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Define mock objects to return as output of get_device_facts method
    # Mocked data is a sample output of command kstat -p sderr:::Product sderr:::Revision sderr:::Serial\ No
    # sderr:0:sd0,err:Product VBOX HARDDISK   9
    # sderr:0:sd0,err:Revision        1.0
    # sderr:0:sd0,err:Serial No       VB0ad2ec4d-074a
    devices = {}
    devices['devices'] = {}
    devices['devices']['sd0'] = {}
    devices['devices']['sd0']['product'] = 'VBOX HARDDISK'
    devices['devices']['sd0']['revision'] = '1.0'


# Generated at 2022-06-11 02:55:56.294642
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Unit test for method 'get_dmi_facts' of class 'SunOSHardware'
    """

    # Mock module
    test_module = type('module', (object,), {})()
    test_module.run_command = lambda *args, **kwargs: (0, '', '')

    # Test data

# Generated at 2022-06-11 02:55:57.727084
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector().__class__.__name__ == 'SunOSHardwareCollector'

# Generated at 2022-06-11 02:56:08.049766
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 02:56:18.879727
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.run_command.return_value = (0, """module: cpu_info
id: 0
instance: 0
class: misc
brand: Genuine Intel(R) CPU           @ 1995.67MHz
clog_id: 0
clock_MHz: 2049
chip_id: 0
core_id: 0
implementation: x86
model: 0
model_name: Intel(R) Xeon(R) CPU           E5-2676 v3 @ 2.40GHz
ncore_per_chip: 8
ncpu_per_chip: 1
ncpu_per_core: 1
nthread_per_core: 2
package_id: 0
state: on-line
status: ok
""", '')

# Generated at 2022-06-11 02:56:30.247064
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class ModuleStub(object):
        def __init__(self):
            # uname_call == 'uname -i'
            self.uname_call = None
            self.uname_return_code = None
            self.uname_return_stdout = None

        def run_command(self, args, **kwargs):
            self.uname_call = args
            return self.uname_return_code, \
                   self.uname_return_stdout, \
                   'stderr'

        def get_bin_path(self, executable, opt_dirs=None):
            return '/usr/bin/prtdiag'

    module = ModuleStub()
    sun = SunOSHardware(module)

    # On an x86 VM, 'uname -i' returns 'i86pc'.
    module

# Generated at 2022-06-11 02:56:37.392049
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    if not SunOSHardwareCollector.detect():
        module.exit_json(changed=False)

    facts = SunOSHardwareCollector(module).collect()

    if module._name == 'test_SunOSHardware_populate':
        module.exit_json(ansible_facts=facts)



# Generated at 2022-06-11 02:56:48.269354
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible.module_utils.facts import hardware

    # Create an instance of SunOSHardware
    sunos_hardware = hardware.SunOSHardware()

    # Create an instance of module_utils.facts.hardware.base.Hardware that contains list of
    # 'ansible_processor'
    class hardware_base(object):

        def __init__(self):
            self.ansible_processor = ['Fujitsu SPARC64 X+']

    instance_hardware_base = hardware_base()

    # Create an instance of module_utils.facts.networking.base.Network that contains list of
    # 'ansible_machine'
    class networking_base(object):

        def __init__(self):
            self.ansible_machine = 'i86pc'

    instance_networking_base = networking_base()

    # Create

# Generated at 2022-06-11 02:56:54.885194
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    shared_test_file = 'data/ansible_facts/sunos_hardware.json'
    hardware = SunOSHardware({})
    hardware_out = hardware.populate()

    with open(shared_test_file) as f:
        shared_test_out = json.load(f)

    assert hardware_out['devices'] == shared_test_out['ansible_devices']

# Generated at 2022-06-11 02:57:02.636930
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = MockAnsibleModule()
    sunos_hw = SunOSHardware(module)
    # fake the output of "prtconf" command
    module.run_command.return_value = (0, 'Memory size: 16384 Megabytes', '')
    # fake the output of "swap -s" command
    module.run_command('/usr/sbin/swap -s').return_value = (0, '1024M allocated + 5M reserved = 1029M used, 739M available', '')

    mem_facts = sunos_hw.get_memory_facts()
    assert mem_facts['memtotal_mb'] == 16384
    assert mem_facts['swap_reserved_mb'] == 5
    assert mem_facts['swap_allocated_mb'] == 1024

# Generated at 2022-06-11 02:57:29.638149
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = False
            pass

        def run_command(self, args, check_rc=False):
            if 'kstat cpu_info' in args:
                return 0, module_kstat_cpu_info, ''
            elif '/usr/sbin/prtconf' in args:
                return 0, module_prtconf, ''
            elif '/usr/sbin/swap -s' in args:
                return 0, module_swap_s, ''
            elif '/usr/bin/kstat -p' in args:
                return 0, module_kstat_p_unix, ''
            else:
                return 0, '', ''


# Generated at 2022-06-11 02:57:39.169449
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    #
    # Test 1: Return value of platform is 'SunOS'
    #
    mocked_module = MockAnsibleModule(
        dict(
            run_command=lambda *_, **__: (0, '', '')
        )
    )

# Generated at 2022-06-11 02:57:49.030020
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    """
    Unit test for method populate of class SunOSHardware
    """
    module = AnsibleModule(
        argument_spec = dict()
    )
    # Set up instantiation of class SunOSHardware and class Hardware
    hw = SunOSHardware(module)
    hw_generic = Hardware(module)

    # Test for populate method for class SunOSHardware
    assert hw.populate()['system_vendor'] == 'Oracle Corporation'
    assert hw.populate()['ansible_processor'][0] == 'SPARC64-VII (chipid 0, clock 1500 MHz)'
    assert hw.populate()['ansible_processor_count'] == 1
    assert hw.populate()['ansible_processor_cores'] == 32
    assert hw.populate()['ansible_processor_vcpus'] == 32

# Generated at 2022-06-11 02:57:53.005932
# Unit test for method get_uptime_facts of class SunOSHardware

# Generated at 2022-06-11 02:57:56.550443
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    out = 'Memory size: 1024 Megabytes'
    hardware = SunOSHardware(dict(), module=None)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 1024

# Generated at 2022-06-11 02:58:00.120984
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    This is a unit test for the get_uptime_facts method
    of the SunOSHardware class.
    """
    class my_module:
        platform = 'SunOS'

        def run_command(self, cmd):
            out = 'unix:0:system_misc:boot_time\t1548249689\n'
            return (0, out, None)

    s = SunOSHardware(module=my_module())

    uptime_facts = s.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:58:06.383159
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware(None)
    out = """System Configuration: VMware, Inc. VMware Virtual Platform
BIOS Configuration: Phoenix[[invalid unicode sequence]] BIOS 4.2.0 2010-02-05
    """
    return set(m.get_dmi_facts().items()) == set({'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}.items())

# Generated at 2022-06-11 02:58:17.158709
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()

    fake_module = type('module', (object,), {'run_command': test_run_command})
    hardware.module = fake_module

    # Test case 1: prtdiag returns System Configuration with supported vendor
    prtdiag_out = '''System Configuration: Sun Microsystems  sun4u
Sun Microsystems  sun4u
Sun Microsystems  sun4u
System clock frequency: 200 MHz
Memory size: 4096 Megabytes
'''
    expected_dmi = {'product_name': 'sun4u', 'system_vendor': 'Sun Microsystems'}

    def side_effect(*args, **kwargs):
        if args[0] == prtdiag_path:
            return (0, prtdiag_out, '')

# Generated at 2022-06-11 02:58:29.124878
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = type('Test', (), {})()
    module.run_command = lambda *args: (0, "sderr:::Product   VBOX HARDDISK\nsderr:::Revision  1.0\nsderr:::Serial No VB0ad2ec4d-074a\nsderr:::Size  53687091200\nsderr:::Vendor    ATA\nsderr:::Hard Errors     0\nsderr:::Soft Errors     0\nsderr:::Transport Errors        0\nsderr:::Media Error     0\nsderr:::Predictive Failure Analysis     0\nsderr:::Illegal Request 6", "")
    SH = SunOSHardware(module)
    device_facts = SH.get_device_facts()

# Generated at 2022-06-11 02:58:35.916897
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    #
    # get_uptime_facts
    #
    import mock
    import module_utils.facts.hardware.sunos as sunos

    module = mock.MagicMock()
    module.run_command.return_value = (0, "unix:0:system_misc:boot_time    1548249689", None)

    hardware = sunos.SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-11 02:59:06.047316
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content, get_mount_size
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils.facts.sunos.cpu import SunOSHardware as cpu_info
    from ansible.module_utils.facts.sunos.memory import SunOSHardware as mem_info
    from ansible.module_utils.facts.sunos.dmi import SunOSHardware as dmi_info
    from ansible.module_utils.facts.sunos.device import SunOSHardware as dev_info
    from ansible.module_utils.facts.sunos.uptime import SunOSHardware as up_info

# Generated at 2022-06-11 02:59:15.343723
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:17.315662
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware


# Generated at 2022-06-11 02:59:19.213045
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the get_dmi_facts() method for SunOSHardware
    """
    dmi_facts = SunOSHardware().get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts


# Unit tests for get_device_facts() method of class SunOSHardware

# Generated at 2022-06-11 02:59:31.502322
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible_collections.ansible.community.plugins.module_utils.facts.hardware.sunos import SunOSHardware

# Generated at 2022-06-11 02:59:35.939766
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    collected_facts = dict(platform='SunOS')
    hardware = SunOSHardware({}, collected_facts)
    # On platform: SunOS
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire X4270 Server'

# Generated at 2022-06-11 02:59:46.576086
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = MockModule()

# Generated at 2022-06-11 02:59:58.680876
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # set up object
    test_obj = SunOSHardware()

    # perform test
    test_result = test_obj.get_device_facts()

    # check result
    assert type(test_result) == dict
    assert test_result['devices']
    assert test_result['devices']['sd0']
    assert test_result['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert test_result['devices']['sd0']['vendor'] == 'ATA'
    assert test_result['devices']['sd0']['revision'] == '1.0'
    assert test_result['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'

# Generated at 2022-06-11 03:00:02.999903
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts import bare_module
    m = bare_module
    s = m.params = {}
    s['run_command'] = return_good_response
    s['get_bin_path'] = return_good_response

    ah = SunOSHardware(m)
    device_facts = ah.get_device_facts()

    # Check for empty devices
    assert('devices' in device_facts)
    assert('sd0' in device_facts['devices'])
    assert(len(device_facts['devices']) == 1)

    # Check for valid data
    assert('sd0' in device_facts['devices'])
    d = device_facts['devices']['sd0']
    assert(d['hard_errors'] == '0')
    assert(d['illegal_request'] == '0')


# Generated at 2022-06-11 03:00:10.994103
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Check returned facts after running the method get_memory_facts.
    my_SunOSHardware = SunOSHardware()
    my_facts = my_SunOSHardware.get_memory_facts()

    assert my_facts['memtotal_mb'] == 0
    assert my_facts['swaptotal_mb'] == 0
    assert my_facts['swapfree_mb'] == 0
    assert my_facts['swap_allocated_mb'] == 0
    assert my_facts['swap_reserved_mb'] == 0

# Generated at 2022-06-11 03:00:59.441987
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    class MockModule(object):
        def __init__(self, prtconf_returncode, prtconf_returnout, prtconf_returnerr, swap_s_returncode, swap_s_returnout, swap_s_returnerr):
            self.prtconf_returncode = prtconf_returncode
            self.prtconf_returnout = prtconf_returnout
            self.prtconf_returnerr = prtconf_returnerr
            self.swap_s_returncode = swap_s_returncode
            self.swap_s_returnout = swap_s_returnout
            self.swap_s_returnerr = swap_s_returnerr

        def run_command(self, cmd):
            if cmd[0] == "/usr/sbin/prtconf":
                return self.prt

# Generated at 2022-06-11 03:01:09.264112
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector.sunos import SunOSHardware
    module = DummyAnsibleModule()
    test_hardware = SunOSHardware(module)
    facts = test_hardware.populate()
    assert facts['devices']['sda']['product'] == 'VBOX HARDDISK'
    assert facts['devices']['sda']['size'] == '50GB'
    assert facts['devices']['sda']['vendor'] == 'ATA'
    assert facts['devices']['sda']['product'] == 'VBOX HARDDISK'
    assert facts['devices']['sda']['hard_errors'] == '0'
    assert facts['devices']['sda']['soft_errors'] == '0'

# Generated at 2022-06-11 03:01:15.180335
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    platform = SunOSHardwareCollector._platform
    fact = SunOSHardwareCollector._fact_class
    required_facts = SunOSHardwareCollector.required_facts
    obj = SunOSHardwareCollector(platform, fact, required_facts)
    assert obj._platform == SunOSHardwareCollector._platform
    assert obj._fact_class == SunOSHardwareCollector._fact_class
    assert obj.required_facts == SunOSHardwareCollector.required_facts

# Generated at 2022-06-11 03:01:23.835021
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    collector = SunOSHardwareCollector()
    fact = collector.collect()

    # check values of cpu_facts
    test_cpu_facts = fact.get_cpu_facts()
    assert isinstance(test_cpu_facts['processor'], list)
    assert isinstance(test_cpu_facts['processor_count'], int)
    assert isinstance(test_cpu_facts['processor_cores'], int)
    assert test_cpu_facts['processor'][0] == 'SPARC64-VII+ @ 2.00GHz'
    assert test_cpu_facts['processor_count'] == 2
    assert test_cpu_facts['processor_cores'] == 24

# Generated at 2022-06-11 03:01:33.206572
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # example input
    example = """
module: cpu_info
instance: 0
class: misc
clock_MHz             2792
brand                 X86 (686-class)
chip_id               0
core_id               0
implementation        x86
module                unknown
pkg_core_id           0
strand_id             0
"""

    facts = SunOSHardware().get_cpu_facts()

    assert facts['processor'] == ['X86 (686-class)']
    assert facts['processor_count'] == 1
    assert facts['processor_cores'] == 1



# Generated at 2022-06-11 03:01:35.084701
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # run method populate of class SunOSHardware
    module = None   # type: AnsibleModule
    SunOSHardware.populate(module)

# Generated at 2022-06-11 03:01:40.394524
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock

    SunOS = SunOSHardware(module)

    d = SunOS.get_device_facts()
    assert 'devices' in d
    assert 'sd0' in d['devices']
    assert d['devices']['sd0']['hard_errors'] == '0'
    assert d['devices']['sd0']['vendor'] == 'ATA'
    assert d['devices']['sd0']['predictive_failure_analysis'] == '0'
    assert d['devices']['sd0']['illegal_request'] == '6'



# Generated at 2022-06-11 03:01:51.004734
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Simulate an instance of SunOSHardware
    sunos = SunOSHardware()
    # Define a data structure to store a number of facts
    collected_facts = {'platform': 'SunOS'}

    # Simulate the first line of prtdiag's output
    # This is the line that will be the subject of the tests
    system_conf = 'System Configuration: Oracle Corporation sun4v SPARC T5-2'

    # Simulate the output of /usr/bin/prtdiag
    out = system_conf
    # Simulate the stream from which the stdout output of prtdiag will be read
    out_file = StringIO(out)

    # Set the boolean variable that controls whether we will exit prematurely
    sunos.module.exit_json.called = False

    # Invoke the method to be tested
    result = sun

# Generated at 2022-06-11 03:02:01.306860
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:02:07.689715
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    sunos_hardware = SunOSHardware()

    # Test memory facts
    memory_facts = {}
    memory_facts['memtotal_mb'] = 10
    memory_facts['swap_allocated_mb'] = 3
    memory_facts['swap_reserved_mb'] = 2
    memory_facts['swaptotal_mb'] = 5
    memory_facts['swapfree_mb'] = 4

    sunos_hardware.get_memory_facts = lambda: memory_facts
    result = sunos_hardware.populate()

    assert result['memtotal_mb'] == 10
    assert result['swap_allocated_mb'] == 3
    assert result['swap_reserved_mb'] == 2
    assert result['swaptotal_mb'] == 5
    assert result['swapfree_mb'] == 4

   