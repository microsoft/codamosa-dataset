

# Generated at 2022-06-11 02:54:02.036343
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    m = SunOSHardware({})
    (rc, out, err) = (0, 'unix:0:system_misc:boot_time    1538796470', None)
    test_uptime_facts = m.get_uptime_facts()

    assert test_uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:54:14.551862
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.exit_json = lambda: None

        def run_command(self, command, environ_update=None):
            if 'uptime' in command:
                return 0, '1548249689', ''
            elif 'disk' in command:
                return 0, '', ''
            elif 'kstat' in command:
                if 'cpu_info' in command:
                    return 0, '''module: cpu_info
brand       Intel(r) Core(tm) i7-4500U CPU @ 1.80GHz
chip_id     0
clock_MHz   1800
implementation GenuineIntel
arch        Intel(r) Core(tm) i7-4500U CPU @ 1.80GHz
''',

# Generated at 2022-06-11 02:54:26.129450
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Verify get_dmi_facts returns expected data for Solaris 10 & 11."""
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import sys

    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO

    dmi_facts = {}

    # SunOSHardware._run_command dispatches the actual call to run_command()
    # run_command() returns (rc, out, err), so we have to return the same.
    # FIXME: This is a work-around for issue #30547 - Ansible mock module
    #        doesn't have a mechanism to set attributes.
    def run_command(*args, **kwargs):
        """Mock run_command"""

# Generated at 2022-06-11 02:54:38.357807
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, input=None, encoding=None, errors=None, env=None, pre_args=None, post_args=None, stdin=None):
        return 1, "", ""

    module.run_command = run_command

    # Set values that are expected

# Generated at 2022-06-11 02:54:51.134234
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation T5240\n', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/prtdiag')
    SunOSHardware = SunOSHardware(module)
    dmi_facts = SunOSHardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'T5240'

if __name__ == '__main__':
    from ansible.module_utils.basic import *
    from ansible.module_utils.facts import *
    from ansible.module_utils.facts.collector import *

# Generated at 2022-06-11 02:55:02.808525
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    class MockModule:
        def run_command(self, command, *args, **kwargs):
            if command == ['/usr/bin/kstat', '-p', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size', 'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request']:
                return 0, 'sderr:0:sd0,err:Product VBOX HARDDISK\n'\
                          'sderr:0:sd0,err:Revision 1.0\n'\
                         

# Generated at 2022-06-11 02:55:07.219350
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': 'all'}
    hardware = SunOSHardware(module)

    rc, out, err = hardware.module.run_command("/usr/bin/kstat cpu_info")
    if rc != 0:
        hardware.module.fail_json(msg='Unable to collect CPU facts')

    hardware.get_cpu_facts()
    hardware.get_memory_facts()
    hardware.get_device_facts()
    hardware.get_uptime_facts()

    hardware_facts = hardware.populate()
    assert hardware_facts['processor'][0] in out
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_

# Generated at 2022-06-11 02:55:10.065683
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.collector import get_collector_instance
    f = get_collector_instance('SunOSHardwareCollector')
    f.populate()

# Generated at 2022-06-11 02:55:15.915759
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    module = AnsibleModuleMock({
    })
    collector = SunOSHardwareCollector(module)

    assert isinstance(collector, SunOSHardwareCollector)
    assert isinstance(collector.platform, str)
    assert isinstance(collector.required_facts, set)
    assert isinstance(collector.fact_class, SunOSHardware)



# Generated at 2022-06-11 02:55:26.593752
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import platform
    # We specifically don't want to use Python's time.time() here
    # because that is not as accurate when used in unit tests.
    # This also ensures that the test is OS independent.
    current_time = int(platform.perf_counter())
    boot_time = current_time - 3600
    mocked_kstat_output = 'unix:0:system_misc:boot_time    %d' % boot_time

    sut = SunOSHardware()

    # Mocked run_command that returns boot_time
    # Note that we are not actually running the real command here and we also
    # don't check whether the command is correct.
    sut.module.run_command = lambda cmd: (0, mocked_kstat_output)
    uptime_facts = sut.get_uptime_

# Generated at 2022-06-11 02:55:49.415222
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    fixture_file = os.path.join(os.path.dirname(__file__), 'get_memory_facts.txt')
    with open(fixture_file, 'r') as f:
        out = f.read()

    results = {'memtotal_mb': 6144}
    sh = SunOSHardware()
    sh.module.run_command = MagicMock(return_value=(0, out, ''))
    sh.get_memory_facts() == results

# Generated at 2022-06-11 02:56:00.058801
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, cmd):
            if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 'cmd_return_code', 'unix:0:system_misc:boot_time\t1548249689\n', 'cmd_stderr'

    class MockFactManager:
        def __init__(self):
            self.facts = {}
            self.facts['platform'] = 'SunOS'

    class MockSunOSHardware:
        def __init__(self, module, fact_manager):
            self.module = module
            self.fact_manager = fact_manager

    module = MockModule()
    fact_manager = MockFactManager()

    sunos = MockSunOSHardware(module, fact_manager)

# Generated at 2022-06-11 02:56:03.072982
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    results = SunOSHardware().get_uptime_facts()
    assert results['uptime_seconds'] > 0


# Generated at 2022-06-11 02:56:14.264923
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.sunos import SunOSHardware
    # Test conditions:
    # 1. Test all vendors
    # 2. Test the fallback data when the first line of the output is not
    #    the conventional System Configuration line.

    def mock_run_command(module, *args):
        return 1, '', ''

    with patch.object(SunOSHardware, 'run_command', side_effect=mock_run_command) as mock_run_command:
        hardware = SunOSHardware()


# Generated at 2022-06-11 02:56:19.876655
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Run the module with the given set of arguments and check if the result
    is equal to the given result.
    """

    sunos = SunOSHardware()
    cpu_facts = sunos.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VI']
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 2

# Generated at 2022-06-11 02:56:31.858593
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hardware = SunOSHardware(module)

    collected_facts = {}
    collected_facts['ansible_machine'] = 'i86pc'
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'][0] == 'Genuine Intel(R) CPU @ 2.40GHz'

    collected_facts['ansible_machine'] = 'sun4v'
    cpu_facts = hardware.get_cpu_facts(collected_facts=collected_facts)

    assert cpu_facts['processor_cores'] == 36
    assert cpu_facts['processor_count'] == 4

# Generated at 2022-06-11 02:56:42.586031
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware = SunOSHardware(dict())
    # Mock prtdiag output
    prtdiag_output = ["System Configuration: Sun Microsystems sun4u\n", "Memory size: 32768 Megabytes\n"]
    # mock run_command
    sunos_hardware.module.run_command = Mock(return_value=(0, '\n'.join(prtdiag_output), ''))
    # call get_dmi_facts
    dmi_facts = sunos_hardware.get_dmi_facts()
    # Check results
    assert len(dmi_facts) == 2
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

# Generated at 2022-06-11 02:56:51.505399
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # set up
    module = MagicMock()
    module.run_command.return_value = (0, 'i86pc', '')
    module.get_bin_path.return_value = '/usr/sbin/prtdiag'

    hw = SunOSHardware(module)

    # test
    hw.populate()

    # assert
    assert hw.data['system_vendor'] == 'QEMU'
    assert hw.data['product_name'] == 'Standard PC (i440FX + PIIX, 1996)'
    assert hw.data['memtotal_mb'] == 3072
    assert hw.data['swapfree_mb'] == 1023
    assert hw.data['swaptotal_mb'] == 1023

# Generated at 2022-06-11 02:57:00.349605
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test for method get_dmi_facts
    SunOSHardware.get_dmi_facts()
    """
    # Make sure there is no other SunOS hardware collector
    SunOSHardwareCollector.clear_collectors()
    hardware = SunOSHardware()
    hardware._module = MockModule()
    hardware._module.run_command = Mock()
    # Run the test
    hardware.get_dmi_facts()
    # Test the results
    assert hardware.dmi_facts['product_name'] == 'test_product_name'
    assert hardware.dmi_facts['system_vendor'] == 'test_system_vendor'
    # Check execution was successful
    assert hardware._module.run_command.call_count > 0


# Generated at 2022-06-11 02:57:09.063038
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Validate that SunOSHardware.get_cpu_facts() returns correct results
    """
    facts = {}
    # populate facts from default facts
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    ssh = SunOSHardware(None)
    facts.update(ssh.populate())

    # set platform to match the test output
    facts['platform'] = 'SunOS'

    # print the facts
    print("\nFacts to be tested:")
    print(facts)

    # call get_cpu_facts() to set facts
    SunOSHardware(facts).get_cpu_facts()

    # expected_facts should have the expected values of facts

# Generated at 2022-06-11 02:57:47.669072
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    module.params = {}
    module.run_command = MagicMock(return_value=[0, CPU_DATA_I86PC, ''])
    module.get_bin_path = MagicMock(return_value='/usr/bin/prtconf')
    sun = SunOSHardware(module)
    cpu_facts = sun.get_cpu_facts()
    assert cpu_facts['processor'] == 'Intel(R) Core(TM)2 Duo CPU T7100  @ 1.80GHz'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-11 02:57:58.148129
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'some output', '')
    module.run_command_environ_update = None
    module.get_bin_path.return_value = '/usr/bin/prtdiag'
    fact_collector = SunOSHardwareCollector()
    facts = fact_collector.collect(module=module, collected_facts=dict(platform='SunOS'))

    assert 'ansible_facts' in facts
    assert 'ansible_memtotal_mb' in facts['ansible_facts']
    assert 'ansible_swaptotal_mb' in facts['ansible_facts']
    assert 'ansible_swapfree_mb' in facts['ansible_facts']



# Generated at 2022-06-11 02:58:01.913456
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = get_module(dict(run_command=run_command))
    hardware = SunOSHardware(module)
    assert hardware.get_memory_facts() == {'memtotal_mb': 3273}

# Generated at 2022-06-11 02:58:13.097100
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = []
        def run_command(self, args, check_rc=True):
            rc, out, err = self.run_command_results.pop(0)
            return rc, out, err

    class TestCollector(object):
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

    mod = TestModule()
    mod.run_command_results = [(0, "unix:0:system_misc:boot_time 1548249689", "")]

    col = TestCollector()
    s = SunOSHardware(col.facts, mod)
    uptime_facts = s.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts


# Generated at 2022-06-11 02:58:19.135124
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()
    hardware.module.run_command = lambda x: (0, 'Memory size: 16384 Megabytes', '')

    assert hardware.get_memory_facts() == {
        'memtotal_mb': 16384,
        'swapfree_mb': None,
        'swaptotal_mb': None,
        'swap_allocated_mb': None,
        'swap_reserved_mb': None
    }


# Generated at 2022-06-11 02:58:30.428106
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware(None)

    # Note that here we are testing the method directly. This is very useful
    # as it allows to make sure the method works as expected with mocked data.
    #
    # When the method is tested this way, we cannot rely on populating the
    # device_facts dict itself in the method being tested, but this is fine
    # since the device_facts dict is tested in test_SunOSHardware_populate
    # (see below), which tests the method indirectly (i.e. invoking it from
    # the populate method).

# Generated at 2022-06-11 02:58:39.805542
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h = SunOSHardware()
    facts = h.get_memory_facts()
    assert facts['memtotal_mb'] == 16384

    h.module.run_command.return_value = (0, "swapfile             dev  swaplo blocks   free\n/dev/zvol/dsk/rpool/swap  -      16  8385860  8385860\n", None)
    facts = h.get_memory_facts()
    assert facts['swapfree_mb'] == 8192
    assert facts['swaptotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 8192
    assert facts['swap_reserved_mb'] == 8192

# Generated at 2022-06-11 02:58:48.526712
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hw = SunOSHardware(module)

    data = hw.populate()
    assert data['ansible_processor'] == ['sparcv9 @ 1647MHz']
    assert data['ansible_processor_cores'] == 8
    assert data['ansible_processor_count'] == 1
    assert data['ansible_devices'] == {}
    assert data['ansible_memtotal_mb'] == 8192
    assert data['ansible_swapfree_mb'] == 4779
    assert data['ansible_swaptotal_mb'] == 4779
    assert data['ansible_system_vendor'] == 'Oracle Corporation'
    assert data['ansible_product_name'] == 'SPARC-Enterprise-T5220'
    assert data['ansible_mounts'] == []




# Generated at 2022-06-11 02:58:58.827506
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    mock_module = MockModule()

# Generated at 2022-06-11 02:59:03.738614
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    hw = SunOSHardware(module=module)

    hw.populate()
    #for fact in hw.facts.keys():
    #    print(fact + ': ' + str(hw.facts[fact]))



# Generated at 2022-06-11 03:00:16.295126
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = SunOSHardware(dict(ansible_facts=dict(ansible_machine='i86pc')))
    SunOSHardware.get_memory_facts = staticmethod(lambda s: dict(memtotal_mb=1, swap_allocated_mb=2, swap_reserved_mb=2,
                                                     swaptotal_mb=2, swapfree_mb=1))
    expected_memory_facts = dict(memtotal_mb=1, swap_allocated_mb=2, swap_reserved_mb=2,
                                 swaptotal_mb=2, swapfree_mb=1)
    memory_facts = module.get_memory_facts()
    assert memory_facts == expected_memory_facts


# Generated at 2022-06-11 03:00:26.312994
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    def get_module_mock(run_command=None):
        run_command_map = {
            "/usr/sbin/prtconf": ("", "Memory size: 16384 Megabytes", ""),
            "/usr/sbin/swap -s": ("", "2049084k", "")
        }

        if run_command is None:
            run_command = run_command_map

        def mock_run_command(self, cmd, check_rc=True):
            return run_command[cmd]

        module_mock = mock.MagicMock()
        module_mock.run_command = mock_run_command
        return module_mock

    module = get_module_mock()
    hardware_obj = sunos_hardware.SunOSHardware(module)

# Generated at 2022-06-11 03:00:29.591477
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModuleMock()
    hardware_collector = SunOSHardwareCollector(module=module)
    hardware_collector.populate()
    assert module.exit_json.called


# Generated at 2022-06-11 03:00:36.374842
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Ensure that we return the expected values for a SunOs system
    """
    module = FakeAnsibleModule()
    sunos_hw = SunOSHardware(module)
    cpu_facts = sunos_hw.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-11 03:00:40.477331
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule({})
    if not module._socket_path:
        module.exit_json(changed=False)

    SunOSHardware(module).populate()
    facts = module.exit_json.call_args[0][0]['ansible_facts']

    assert 'ansible_processor' in facts

# Generated at 2022-06-11 03:00:47.464516
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec={},
    )
    hardware = SunOSHardwareCollector.collect(module=module)[0]
    memory_facts = hardware.get_memory_facts()

    # check swap_allocated_mb returned we get an integer
    assert memory_facts['swap_allocated_mb'] == 0
    assert isinstance(memory_facts['swap_allocated_mb'], int)
    # check swap_reserved_mb returned we get an integer
    assert memory_facts['swap_reserved_mb'] == 0
    assert isinstance(memory_facts['swap_reserved_mb'], int)
    # check memtotal_mb returned we get an integer
    assert isinstance(memory_facts['memtotal_mb'], int)


# Generated at 2022-06-11 03:00:57.701783
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    conf_out = ('Product VBOX HARDDISK\n'
                'Revision 1.0\n'
                'Serial No VB0ad2ec4d-074a\n'
                'Size 53687091200\n'
                'Vendor ATA\n'
                'Hard Errors 0\n'
                'Soft Errors 0\n'
                'Transport Errors 0\n'
                'Media Error 0\n'
                'Predictive Failure Analysis 0\n'
                'Illegal Request 6\n')

# Generated at 2022-06-11 03:01:05.440899
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:01:16.611523
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-11 03:01:19.206925
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_obj = SunOSHardware()
    result = test_obj.get_memory_facts()
    assert 'memtotal_mb' in result