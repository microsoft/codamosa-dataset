

# Generated at 2022-06-11 02:54:09.813669
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    module.run_command = MagicMock()

# Generated at 2022-06-11 02:54:22.717970
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Setup
    module = FakeAnsibleModule()
    module.run_command = MockCommandRunner()
    h = SunOSHardware()

    # Test catch for invalid path
    mock_kstat_command = MockCommand(rc=1, out='', err='')
    module.run_command.add_cmd(mock_kstat_command)
    assert h.get_device_facts() == {'devices': {}}

    # Test catch for invalid kstat output
    mock_kstat_command = MockCommand(rc=0, out='not valid kstat output', err='')
    module.run_command.add_cmd(mock_kstat_command)
    assert h.get_device_facts() == {'devices': {}}

    # Test one disk

# Generated at 2022-06-11 02:54:32.864681
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create mock kstat output

# Generated at 2022-06-11 02:54:42.798974
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    m = SunOSHardware({})
    d = m.get_device_facts()
    assert d == {}
    # Test invalid kstat output

# Generated at 2022-06-11 02:54:52.750666
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Unit test should pass time.time() back to kstat.
    # Since kstat is mocked in our test environment, we have to mock time.time()
    # for our unit test.
    class MockTime(object):

        @staticmethod
        def time():
            return 1

    original_time = time.time
    time.time = MockTime.time

    # Create an instance of the SunOSHardware class
    sun_os = SunOSHardware(dict())
    # Assert boot_time and uptime_seconds.
    assert sun_os.get_uptime_facts()['uptime_seconds'] == 0

    # Set time.time back to the original function.
    time.time = original_time

# Generated at 2022-06-11 02:54:58.225050
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()

    # check if output is at least a dict
    assert isinstance(hardware_facts, dict)
    # check if we can parse the output
    assert 'processor_cores' in hardware_facts


# Generated at 2022-06-11 02:55:06.462231
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    class MockModule(object):
        def run_command(self, command):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockTime(object):
        @staticmethod
        def time():
            return '1548249689'

    mock_module = MockModule()
    mock_time = MockTime

    sunos_hardware = SunOSHardware(module=mock_module, time=mock_time)

    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts
    assert uptime_facts['uptime_seconds'] == 0

# Generated at 2022-06-11 02:55:09.624501
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    h = SunOSHardware()
    rc = h.get_memory_facts()
    assert rc.get('memtotal_mb') == (1024**3) // (1024 ** 2)

# Generated at 2022-06-11 02:55:21.058728
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_obj = SunOSHardware()

    # Returned dict is empty if subprocess.Popen returns RC != 0
    # Will be further checked in the test class
    p = test_obj.module.params
    p['run_command_return_rc'] = 1
    test_obj.module.params = p

    result = test_obj.get_device_facts()
    assert result == {}

    # Products that are returned from kstat have to be present in result dict

# Generated at 2022-06-11 02:55:31.627921
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # populate input for get_device_facts method
    fake_module = type('AnsibleModule', (object,), {})()
    fake_module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}

# Generated at 2022-06-11 02:55:55.927307
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Test type of constructor
    assert(isinstance(SunOSHardwareCollector(), HardwareCollector))
    # Test _fact_class type
    assert(SunOSHardwareCollector._fact_class == SunOSHardware)
    # Test required_facts set
    assert(SunOSHardwareCollector.required_facts == set(['platform']))
    # Test _platform
    assert(SunOSHardwareCollector._platform == 'SunOS')

# Generated at 2022-06-11 02:55:57.353738
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts = SunOSHardware().get_device_facts()

# Generated at 2022-06-11 02:56:07.458262
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware({'ansible_machine': 'i86pc'})

# Generated at 2022-06-11 02:56:16.935045
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    _module = AnsibleModule(argument_spec={})
    _SunOSHardware = SunOSHardware(_module)

    _SunOSHardware.module.run_command = mock.Mock(return_value=(0, 'Memory size: 16384 Megabytes', ''))
    memory_facts = _SunOSHardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384

    _SunOSHardware.module.run_command = mock.Mock(return_value=(0, 'Memory size: 512 Megabytes', ''))
    memory_facts = _SunOSHardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 512



# Generated at 2022-06-11 02:56:19.164393
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware()

    # Check populate method raises not NotImplementedError
    try:
        hardware_obj.populate()
    except NotImplementedError:
        assert False


# Generated at 2022-06-11 02:56:22.001879
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    h = SunOSHardware(module)

    hw_facts = h.populate()

    assert hw_facts['processor']


# Generated at 2022-06-11 02:56:34.120060
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module_inst = None
    facts_obj = SunOSHardware()


# Generated at 2022-06-11 02:56:37.023631
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    hardware = SunOSHardware(module)
    facts = hardware.populate()

    assert facts is not None

# Generated at 2022-06-11 02:56:47.966554
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    import unittest
    import os

    class MockAnsibleModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            raise AssertionError(args[0])

        def get_bin_path(self, executable='', required=True, opt_dirs=[]):
            if executable == 'prtdiag':
                return './prtdiag'

        def run_command(self, cmd):
            if cmd == ['/bin/uname', '-i']:
                return 0, 'SUNW,SPARC-Enterprise-T5120', ''

# Generated at 2022-06-11 02:56:55.085350
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    with patch.object(SunOSHardware, 'populate') as hardware_populate:
        hardware = SunOSHardware(module)
        hardware.populate()
        hardware_populate.assert_called_once_with(None)


# Generated at 2022-06-11 02:57:24.431517
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import __builtin__
    from ansible.module_utils.facts import Collector

    __builtin__.__salt__ = {}

    import ansible.module_utils.facts.hardware.sunos as sunos

    # Create instances of class Collector and SunOSHardware
    collector = Collector()
    uptime = ['uptime']
    sunOSHardware = sunos.SunOSHardware(collector, uptime)

    # Create mock commands such as kstat
    def __mock_kstat_cmd(command, *args, **kwargs):
        if command == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    # Assign mock_command as a side effect of __builtin__.

# Generated at 2022-06-11 02:57:27.683556
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    d = SunOSHardware(module).get_device_facts()
    assert isinstance(d, dict)
    assert 'devices' in d


# Generated at 2022-06-11 02:57:31.127539
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    obj = SunOSHardware()
    results = obj.get_cpu_facts()
    assert results['processor_count'] == 2
    assert results['processor_cores'] == 2
    assert 'processor' in results
    assert len(results['processor']) == 2


# Generated at 2022-06-11 02:57:40.955035
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = object()
    sunoshardware = SunOSHardware(module)

    # Build prtconf output based on https://docs.oracle.com/cd/E53394_01/html/E54813/sysc1s1s1.html
    prtconf_output = 'Memory size: 127 MB\n'
    prtconf_output += 'System Peripherals (Software Nodes):\n'
    prtconf_output += '          SUNW,Ultra-5_10\n'
    prtconf_output += '          SUNW,fdtwo\n'
    prtconf_output += '          SUNW,hme\n'
    prtconf_output += '          SUNW,pci\n'
    prtconf_output += '          SUNW,pci-pci\n'
    prtconf

# Generated at 2022-06-11 02:57:50.909977
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    sunos_collector = SunOSHardwareCollector(module=module)
    result = sunos_collector.collect(module=module)

    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sunos_hw = SunOSHardware(module=module)
    result = sunos_hw.populate()

    assert result is not None
    assert result['memtotal_mb'] is not None
    assert result['swap_reserved_mb'] is not None
    assert result['swap_allocated_mb'] is not None
    assert result['system_vendor'] is not None
   

# Generated at 2022-06-11 02:58:02.766462
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    # create test case inputs
    test_lines = []
    processors = []
    test_lines.append('module:     processor_driver')
    processors.append('processor_driver')
    test_lines.append('implementation:   SUNW,UltraSPARC-IIi-cEngine')
    processors.append('SUNW,UltraSPARC-IIi-cEngine')
    test_lines.append('chip_id:    20000')
    test_lines.append('board_version:   32')
    test_lines.append('status:     ok')
    test_lines.append('configuration:   factory-configured')

    test_lines.append('module:     processor_driver')
    processors.append('processor_driver')

# Generated at 2022-06-11 02:58:13.044059
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.collector import get_collector

    class MockModule(object):
        def run_command(self, cmd):
            cmd.pop(0)
            return 0, 'unix:{}:system_misc:boot_time\t' + str(self.now - datetime.timedelta(seconds=self.uptime)), ''

    collector = get_collector('SunOS')
    module = MockModule()

    # success
    module.now = datetime.datetime.utcnow()
    module.uptime = 15624
    uptime_facts = collector._get_uptime_facts(module)
    assert (uptime_facts['uptime_seconds'] == 15624)


# Generated at 2022-06-11 02:58:19.974643
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    os_facts = {'platform': 'SunOS'}
    module = Mock(exit_json=None, fail_json=None, params={})
    command = module.run_command = Mock(return_value=(0, '\nMemory size: 8192 Megabytes', ''))
    test_object = SunOSHardware(module)
    result = test_object.populate(os_facts)
    command.assert_called_once_with('/usr/sbin/prtconf')
    assert result == {'memtotal_mb': 8192}



# Generated at 2022-06-11 02:58:26.189838
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts



# Generated at 2022-06-11 02:58:33.814192
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.hardware.sunos.SunOSHardware
    SunOSHardware = ansible.module_utils.facts.hardware.sunos.SunOSHardware
    module = timeout.Holder(None)
    timeout.Holder.timeout = 0
    module.run_command = lambda x: (0, 'Memory size: 4096 Megabytes', None)
    module.get_file_content = lambda x: None
    memory_facts = SunOSHardware(module).get_memory_facts()
    assert memory_facts['memtotal_mb'] == 4096

# Generated at 2022-06-11 02:59:13.778942
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """Test specific DMI facts for SunOS."""
    hardware_facts = SunOSHardware()
    facts = hardware_facts.get_dmi_facts()
    if facts['product_name'] == 'Oracle Corporation':
        assert True
    else:
        assert False

# Generated at 2022-06-11 02:59:17.917969
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mock_module = type('module', (object, ), {})()
    mock_module.run_command = lambda x: (0, 'Mem Total:       8192', None)
    mock_module.run_command_environ_update = {}

    hardware = SunOSHardware(mock_module)
    memory_facts = hardware.get_memory_facts()

    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-11 02:59:31.380069
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-11 02:59:39.048239
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hw = SunOSHardware(module=module)

    facts = hw.populate()
    assert facts['processor_cores'] == 1
    assert facts['processor_count'] == 1
    assert facts['memtotal_mb'] == 256
    assert facts['swap_reserved_mb'] == 256
    assert facts['swap_allocated_mb'] == 256
    assert facts['system_vendor'] == 'Sun Microsystems'
    assert facts['product_name'] == 'SPARCstation-20'


# Generated at 2022-06-11 02:59:50.630949
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_prtdiag_output = 'System Configuration: Sun Microsystems sun4u'
    tests = [{'prtdiag_stdout': test_prtdiag_output,
              'expected_dmi_facts': {
                  'system_vendor': 'Sun Microsystems',
                  'product_name': 'sun4u',
              }
              }]
    for test in tests:
        sunos_hardware = SunOSHardware()
        mock_module = Mock()
        mock_module.run_command.return_value = (0, test['prtdiag_stdout'], '')
        sunos_hardware.module = mock_module
        dmi_facts = sunos_hardware.get_dmi_facts()
        assert dmi_facts == test['expected_dmi_facts']



# Generated at 2022-06-11 02:59:53.750121
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.required_facts == set(['platform']), 'Required facts are not set correctly'


# Generated at 2022-06-11 03:00:02.816303
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible.module_utils.facts.sunos.hardware import SunOSHardware
    fact_module = SunOSHardware()
    collected_facts = {'ansible_machine': 'i86pc'}
    facts = fact_module.populate(collected_facts)
    assert isinstance(facts, dict)
    if 'ansible_machine' not in collected_facts:
        assert 'processor' in facts and facts['processor'] != []
        assert 'processor_count' in facts
        assert 'processor_cores' in facts
        assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts
    assert 'devices' in facts
   

# Generated at 2022-06-11 03:00:08.311511
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Arrange
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(None, "/usr/bin/kstat cpu_info", None))

    # Act
    result = SunOSHardware.get_cpu_facts(module)

    # Assert
    assert result['processor'] == []

# Generated at 2022-06-11 03:00:10.274190
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}

    hw = SunOSHardware()
    hw.get_cpu_facts()

    assert isinstance(hw, SunOSHardware)


# Generated at 2022-06-11 03:00:16.880569
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import mock
    module = mock.Mock()
    module.run_command = mock.Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689\n', ''))

    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 1548249689


# Generated at 2022-06-11 03:01:39.675558
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        """This method is a helper to test get_dmi_facts method of class SunOSHardware"""
        def run_command_LANG(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            """This method is a helper to test get_dmi_facts method of class SunOSHardware"""
            args = ['/usr/bin/uname', '-i']
            rc = 0
            out = "i86pc"
            err = ""
            return rc, out, err

# Generated at 2022-06-11 03:01:43.188059
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = Mock(name='ansible_module')
    module.run_command.return_value = (0, prt_conf_output, '')

    hw = SunOSHardware(module)
    facts = hw.populate()

    assert facts == memory_facts


# Generated at 2022-06-11 03:01:48.245192
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "Memory size: 20480 Megabytes", ""))
    h = SunOSHardware(module)
    facts = h.get_memory_facts()
    assert facts['memtotal_mb'] == 20480


# Generated at 2022-06-11 03:01:58.592623
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_module = object()

    test_module.run_command = lambda x: (1, 'System Configuration: VMware, Inc. Virtual Platform', None)

    test_SunOSHardware = SunOSHardware(module=test_module)
    dmi_facts = test_SunOSHardware.get_dmi_facts()
    assert dmi_facts.get('system_vendor') == 'VMware, Inc.'
    assert dmi_facts.get('product_name') == 'Virtual Platform'

    test_module.run_command = lambda x: (1, 'System Configuration: QEMU', None)

    test_SunOSHardware = SunOSHardware(module=test_module)
    dmi_facts = test_SunOSHardware.get_dmi_facts()

# Generated at 2022-06-11 03:02:06.581588
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = MockModule()
    hw = SunOSHardware(module)
    hw.populate()

    assert hw.facts['processor'][0] == 'SUNW,UltraSPARC-II @ 250MHz'
    assert hw.facts['processor_cores'] == 1
    assert hw.facts['processor_count'] == 1
    assert hw.facts['swapfree_mb'] == 1
    assert hw.facts['swaptotal_mb'] == 1
    assert hw.facts['system_vendor'] == 'Sun Microsystems'
    assert hw.facts['memtotal_mb'] == 4
    assert hw.facts['product_name'] == 'Sun Ultra 60 UPA/PCI (2 X UltraSPARC-II 300MHz)'

# Generated at 2022-06-11 03:02:16.366125
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    def find_in_returned_dict(dict, key):
        for k in dict.keys():
            if k == key:
                return True
        return False

    class TestModule(object):
        def __init__(self, run_command_out, run_command_rc):
            self.run_command_out = run_command_out
            self.run_command_rc = run_command_rc

        def run_command(self, args):
            return (self.run_command_rc, self.run_command_out, "")

        def get_bin_path(self, name, opt_dirs=[]):
            return "/usr/bin/prtdiag"

    test_module = TestModule("\nSystem Configuration: Sun Microsystems sun4u\n", 0)


# Generated at 2022-06-11 03:02:20.640472
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware(None)
    out = hardware.get_memory_facts()
    assert out['memtotal_mb'] == 786432
    assert out['swapfree_mb'] == 0
    assert out['swaptotal_mb'] == 0
    assert out['swap_allocated_mb'] == 0
    assert out['swap_reserved_mb'] == 0

# Generated at 2022-06-11 03:02:29.445880
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    class HW:
        pass
    HW.module = sys.modules[__name__]
    HW.module.run_command = mock.Mock(return_value=(0, "", ""))
    hw = HW()
    result = SunOSHardware.get_cpu_facts(hw)
    exp_result = {'processor_count': 1, 'processor_cores': 1, 'processor': ['ARMv6-compatible processor rev 7 (v6l) @ 1000MHz']}
    assert result == exp_result, "Expected %s, got %s" % (exp_result, result)

if __name__ == "__main__":
    import sys, mock
    test_SunOSHardware_get_cpu_facts()

# Generated at 2022-06-11 03:02:35.283999
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Expected data to compare against
    device_facts = {}
    device_facts['devices'] = {}
    expected = {'sd0': {'hard_errors': '0',
                        'illegal_request': '6',
                        'media_errors': '0',
                        'predictive_failure_analysis': '0',
                        'product': 'VBOX HARDDISK',
                        'revision': '1.0',
                        'serial': 'VB0ad2ec4d-074a',
                        'size': '53.7 GB',
                        'soft_errors': '0',
                        'transport_errors': '0',
                        'vendor': 'ATA'}}

    # Create class instance
    hardware = SunOSHardware()

    # Catch actual data by calling the method to be tested
    device_facts = hardware.get_

# Generated at 2022-06-11 03:02:42.102834
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    m = SunOSHardware({})
    data = """System Configuration: VMware, Inc. VMware Virtual Platform
    BIOS Configuration: American Megatrends Inc. 1.00 07/07/2014
    Platform Memory Size: 2GB
    Battery FRU: None""".splitlines()
    assert m.get_dmi_facts({'ansible_machine': 'i86pc'}) == {'system_vendor': 'VMware, Inc.',
                                                             'product_name': 'VMware Virtual Platform'}
