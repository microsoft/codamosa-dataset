

# Generated at 2022-06-24 22:19:45.165266
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

# Generated at 2022-06-24 22:19:54.699820
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-24 22:20:05.153186
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-24 22:20:11.053704
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    byte_array = bytearray(b'\xe63\x1d\xf6\x88\x00)`\xea')
    fact_sun_o_s_hardware_0 = SunOSHardware(byte_array)
    result = fact_sun_o_s_hardware_0.populate()
    assert type(result) is dict


# Generated at 2022-06-24 22:20:22.216979
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\x02\xeb\x1b\xae\xaa\xa7k\x8a'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    bytes_1 = b'\x00\x0c\xe6\x04\x93\xa8\xdc\xa9'
    sun_o_s_hardware_1 = SunOSHardware(bytes_1)
    bytes_2 = b'\x03A\xf8\x86\xde\x80\x95\x0f'
    sun_o_s_hardware_2 = SunOSHardware(bytes_2)

# Generated at 2022-06-24 22:20:28.591130
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    collected_facts_0 = {}
    collected_facts_0['ansible_machine'] = 'i86pc'
    collected_facts_0['ansible_processor'] = ['amd64']
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:20:31.350295
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_collector = SunOSHardwareCollector()
    hardware = SunOSHardware()
    hardware.populate()


# Generated at 2022-06-24 22:20:37.909624
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    device_facts_0 = sun_o_s_hardware_0.get_device_facts(bytes_0)



# Generated at 2022-06-24 22:20:44.669169
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    sun_o_s_hardware_0.module.run_command = lambda args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, env_update=None: (0, b'Memory size: 32 Megabytes\n', None)

    return_value_0 = sun_o_s_hardware_0.get_memory_facts()
    assert return_value_0['memtotal_mb'] == 32



# Generated at 2022-06-24 22:20:48.749213
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xe63\x1d\xf6\x88\x00)`\xea'
    sun_o_s_hardware_0 = SunOSHardware()

    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:21:08.924898
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.populate()
    sun_o_s_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:21:16.116340
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "prtconf: System Configuration: Sun Microsystems sun4u\nMemory size: 16384 Megabytes", ""))
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "swap -s           total:  4096k bytes allocated +  4096k reserved =  8192k used,  18432k available", ""))

# Generated at 2022-06-24 22:21:18.577701
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
        sun_o_s_hardware_0 = SunOSHardware()
        assert ('system_vendor' in sun_o_s_hardware_0.get_dmi_facts())


# Generated at 2022-06-24 22:21:21.124496
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()

# Unit testing for class SunOSHardware

# Generated at 2022-06-24 22:21:27.485934
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    mem_fact = sun_o_s_hardware_0.get_memory_facts()
    assert ('memtotal_mb' in mem_fact)
    assert ('swap_reserved_mb' in mem_fact)
    assert ('swap_allocated_mb' in mem_fact)
    assert ('swaptotal_mb' in mem_fact)
    assert ('swapfree_mb' in mem_fact)

# Generated at 2022-06-24 22:21:31.636870
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Test the Sun hardware get uptime facts method
    sun_o_s_hardware_0 = SunOSHardware()
    uptime_seconds = sun_o_s_hardware_0.get_uptime_facts()
    # The actual test
    if not uptime_seconds['uptime_seconds']:
        raise Exception('Method get_uptime_facts of SunOSHardware failed')
    else:
        print("Method get_uptime_facts of SunOSHardware passed")

# Generated at 2022-06-24 22:21:34.260045
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert isinstance(sun_o_s_hardware_0.get_uptime_facts(), dict)

# Generated at 2022-06-24 22:21:43.292581
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate_from_facts({})
    assert sun_o_s_hardware_0.get_cpu_facts({}) == {'processor': ['SPARC64-VIII @ 1414.52MHz'], 'processor_cores': 'NA', 'processor_count': 4}

    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.populate_from_facts({})
    assert sun_o_s_hardware_1.get_cpu_facts({}) == {'processor': ['SPARC64-VIII @ 1414.52MHz'], 'processor_cores': 'NA', 'processor_count': 4}

    sun_o_s_hardware

# Generated at 2022-06-24 22:21:46.951587
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:52.048471
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = sun_o_s_hardware_0.get_memory_facts()

    assert mem_facts['memtotal_mb'] == 2048
    assert mem_facts['swapfree_mb'] == 2048
    assert mem_facts['swaptotal_mb'] == 2048
    assert mem_facts['swap_allocated_mb'] == 0
    assert mem_facts['swap_reserved_mb'] == 0


# Generated at 2022-06-24 22:22:27.676222
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    test_obj = SunOSHardware()
    results = test_obj.get_uptime_facts()
    assert results is not False


# Generated at 2022-06-24 22:22:33.954237
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command.return_value = (0, 'sderr:0:sd0,err:Media Error 0\nsderr:0:sd0,err:Product VBOX HARDDISK   9\nsderr:0:sd0,err:Revision        1.0\nsderr:0:sd0,err:Serial No       VB0ad2ec4d-074a\nsderr:0:sd0,err:Size    53687091200\nsderr:0:sd0,err:Soft Errors 0\nsderr:0:sd0,err:Transport Errors 0\nsderr:0:sd0,err:Vendor  ATA\n', '')
    sun_o

# Generated at 2022-06-24 22:22:45.318401
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = mock_run_command
    data = {'devices': {'sda': {'size': '53.7 GB', 'vendor': 'ATA', 'predictive_failure_analysis': '0', 'product': 'VBOX HARDDISK', 'hard_errors': '0', 'revision': '1.0', 'media_errors': '0', 'serial': 'VB0ad2ec4d-074a', 'soft_errors': '0', 'transport_errors': '0', 'illegal_request': '6'}}}
    assert sun_o_s_hardware_0.get_device_facts() == data


# Generated at 2022-06-24 22:22:53.248702
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    unix_0_system_misc_boot_time = 0
    unix_0_system_misc_boot_time_kstat = 'unix:0:system_misc:boot_time %i' % (unix_0_system_misc_boot_time)
    return_value = sun_o_s_hardware_0.module.run_command.return_value = (0, unix_0_system_misc_boot_time_kstat, '')

    uptime_seconds = sun_o_s_hardware_0.get_uptime_facts()['uptime_seconds']
    assert uptime_seconds == int(time.time() - unix_0_system_misc_boot_time)

# Generated at 2022-06-24 22:22:59.947639
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.run_command = MagicMock()
    sun_o_s_hardware_0.run_command.return_value = None
    sun_o_s_hardware_0.run_command.return_value = (1, '\n', '')
    sun_o_s_hardware_0.module.run_command = MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = None

# Generated at 2022-06-24 22:23:03.549888
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:23:07.405333
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.module.run_command = mock_run_command
    expected_result = {'memtotal_mb': 919}
    result = sun_o_s_hardware.get_memory_facts()
    assert result == expected_result


# Generated at 2022-06-24 22:23:09.181731
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:23:15.432987
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = Mock(return_value=None)
    sun_o_s_hardware_0.module.run_command = Mock(return_value=(0, "Memory size: 1873064 Megabytes", ""))
    sun_o_s_hardware_0.module.get_bin_path = Mock(return_value="")
    sun_o_s_hardware_0.module.run_command = Mock(return_value=(0, "    allocated    reserved    allocated    reserved\n\n65536.00 mb    71048.00 mb    128.00 mb     128.00 mb", ""))


# Generated at 2022-06-24 22:23:27.013031
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.module.set_command_response(0, "module: proc\nbrand:  x86", "", "")
    sun_o_s_hardware_1.module.set_command_response(0, "module: proc\nbrand:  x86", "", "")
    sun_o_s_hardware_1.module.set_command_response(0, "clock_MHz:   2394.656", "", "")
    sun_o_s_hardware_1.module.set_command_response(0, "implementation: x86", "", "")

# Generated at 2022-06-24 22:24:45.709394
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_cpu_facts()
    assert 'processor' in result


# Generated at 2022-06-24 22:24:51.369814
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.module = AnsibleModule(
        argument_spec = dict()
    )
    dmi_facts = sun_o_s_hardware_1.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise'


# Generated at 2022-06-24 22:24:54.456391
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:59.891192
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor_count': 1, 'processor_cores': 1, 'processor': [u'SUNW,Ultra-5_10 @ 167MHz']}


# Generated at 2022-06-24 22:25:05.523894
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    data = {}
    sun_o_s_hardware_0 = SunOSHardware(module=None, facts=data)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:08.832933
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = dict(ansible_machine='i86pc')

    sun_o_s_hardware_0.get_dmi_facts(collected_facts)


# Generated at 2022-06-24 22:25:11.207880
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_device_facts() == None


# Generated at 2022-06-24 22:25:13.868165
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_uptime_facts()
    assert isinstance(result, dict)

# Generated at 2022-06-24 22:25:15.432644
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware = SunOSHardware()
    sunos_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:25:17.750226
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_SunOSHardware_populate = SunOSHardware()
    sun_o_s_hardware_SunOSHardware_populate.populate()


# Generated at 2022-06-24 22:28:52.564599
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create instance of class SunOSHardware
    sun_o_s_hardware = SunOSHardware()

    # Test method get_device_facts
    sun_o_s_hardware.get_device_facts()

# Generated at 2022-06-24 22:28:57.764130
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_1 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:29:03.957182
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    def side_effect__get_file_content(param):
        return '\n'
    sun_o_s_hardware_0.module.get_bin_path = mock.Mock(return_value='/usr/bin/prtdiag')
    sun_o_s_hardware_0.module.run_command = mock.Mock(side_effect=Exception('Unknown OS'))
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:29:07.335577
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:29:09.816697
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:29:20.406430
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}