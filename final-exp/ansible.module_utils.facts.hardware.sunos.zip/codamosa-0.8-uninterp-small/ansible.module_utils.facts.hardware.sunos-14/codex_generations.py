

# Generated at 2022-06-24 22:19:37.631974
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    float_0 = -1570.411682
    sun_o_s_hardware_0 = SunOSHardware(float_0)


# Generated at 2022-06-24 22:19:42.004128
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    float_0 = -619.834112
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:19:46.212238
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    float_0 = -596.86878767
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_device_facts()



# Generated at 2022-06-24 22:19:51.592555
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(6)
    collected_facts_0 = {'ansible_machine': 'i86pc'}

    sun_o_s_hardware_0.populate(collected_facts=collected_facts_0)


# Generated at 2022-06-24 22:20:01.918021
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    populate = SunOSHardware(float, float)
    populate.get_mount_facts = MagicMock(return_value = {'mounts': []})
    populate.get_dmi_facts = MagicMock(return_value = {'system_vendor': 'QEMU', 'product_name': ''})
    populate.get_memory_facts = MagicMock(return_value = {'memtotal_mb': 5370, 'swapfree_mb': 9315, 'swaptotal_mb': 9315, 'swap_allocated_mb': 2048, 'swap_reserved_mb': 2048})
    populate.get_cpu_facts = MagicMock(return_value = {'processor': [], 'processor_cores': 'NA', 'processor_count': 1})

# Generated at 2022-06-24 22:20:06.610883
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    float_0 = -707.042332
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    uptime_facts = sun_o_s_hardware_0.get_uptime_facts()
    sun_o_s_hardware_0.module.fail_json.assert_called_with(msg=dict)


# Generated at 2022-06-24 22:20:11.665075
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    float_0 = -1846.202803
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    float_1 = -1622.552882
    collected_facts_dict = {'machine': 'i86pc', 'uname_system': 'SunOS'}
    sun_o_s_hardware_0.module = AnsibleModuleStub(float_1, collected_facts_dict)
    sun_o_s_hardware_0.module.run_command = MagicMock()
    sun_o_s_hardware_0.module.run_command_environ_update = {'LC_ALL': 'C', 'LC_NUMERIC': 'C', 'LANG': 'C'}
    sun_o_s_hardware_0.populate()


# Unit test

# Generated at 2022-06-24 22:20:22.901726
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "Memory size: 32768 Megabytes\n", ""))
    sun_o_s_hardware_0.module.run_command.side_effect = [
        (0, "Memory size: 32768 Megabytes\n", ""),
        (0, "Memory size: 32768 Megabytes\n", "")]
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "total: 8192K bytes allocated + 0K reserved = 8192K used, 2397284K available\n", ""))

# Generated at 2022-06-24 22:20:24.333412
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # test case 0
    test_case_0()


# Generated at 2022-06-24 22:20:27.358867
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    float_0 = -1570.411682
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:51.080417
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sunos_hardware_0 = SunOSHardware()
    sunos_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:54.607450
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_uptime_facts() == {'uptime_seconds': 1548249699}


# Generated at 2022-06-24 22:21:03.725015
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # create empty SunOSHardware object
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.module.run_command = lambda x: (0, '', '')

    sun_o_s_hardware_0.get_memory_facts()
    assert ('memtotal_mb' in sun_o_s_hardware_0.facts)
    assert ('swapfree_mb' in sun_o_s_hardware_0.facts)
    assert ('swaptotal_mb' in sun_o_s_hardware_0.facts)
    assert ('swap_allocated_mb' in sun_o_s_hardware_0.facts)
    assert ('swap_reserved_mb' in sun_o_s_hardware_0.facts)



# Generated at 2022-06-24 22:21:12.156678
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg 'self'
    # Testing with required arg 'collected_facts'
    # Testing with required arg '

# Generated at 2022-06-24 22:21:14.154761
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    sun_o_s_hardware = SunOSHardware()

    sun_o_s_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:21:17.431257
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:23.486272
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'Memory size: 128 Megabytes\n', ''))

    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, '\t128\t128\t128\n', ''))

    assert sun_o_s_hardware_0.get_memory_facts() == {'memtotal_mb': 128, 'swapfree_mb': 128, 'swaptotal_mb': 256, 'swap_allocated_mb': 128, 'swap_reserved_mb': 128}


# Generated at 2022-06-24 22:21:28.005092
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_1 = SunOSHardware()

    assert isinstance(sun_o_s_hardware_0.get_uptime_facts(), dict)
    assert sun_o_s_hardware_1.get_uptime_facts() == {}


# Generated at 2022-06-24 22:21:31.100008
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    sun_o_s_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:21:35.682728
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector

    required_facts = set(['platform'])

    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    assert sun_o_s_hardware_collector_0.required_facts == required_facts


# Generated at 2022-06-24 22:22:32.794720
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.module = AnsibleModule({}, ["/usr/bin/uname -i"], 'stdout', False)
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "x86", ""))
    sun_o_s_hardware_0.module.get_bin_path = MagicMock(return_value="/usr/bin/prtdiag")

    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, "System Configuration: Foo", ""))

    result = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:35.913945
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:43.871210
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Call the method without param
    output = sun_o_s_hardware_0.get_memory_facts()
    assert output['memtotal_mb'] == '11994'
    assert output['swapfree_mb'] == '1535'
    assert output['swaptotal_mb'] == '2047'
    assert output['swap_allocated_mb'] == '511'
    assert output['swap_reserved_mb'] == '0'


# Generated at 2022-06-24 22:22:47.206865
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:50.892917
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # pass



# Generated at 2022-06-24 22:22:55.173715
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    from ansible.module_utils.facts.collector import collector
    sun_o_s_hardware_0.collector_object = collector
    z = sun_o_s_hardware_0.get_uptime_facts()
    assert z == {'uptime_seconds': 1547880051}, "Failed to get_uptime_facts."


# Generated at 2022-06-24 22:22:57.566777
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    memory_facts = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:00.672722
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    result = SunOSHardwareCollector()
    assert result._platform.lower() == 'sunos', "Expected " + "SunOS" + ", got it " + result._platform


# Generated at 2022-06-24 22:23:05.083370
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Initalize a SunOSHardware instance
    sun_o_s_hardware_0 = SunOSHardware()

    # Get device facts
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:07.229015
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_device_facts() == {}


# Generated at 2022-06-24 22:24:03.821316
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:24:07.628830
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert isinstance(sun_o_s_hardware_0.get_device_facts(), dict)


# Generated at 2022-06-24 22:24:10.828237
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Tests
    assert sun_o_s_hardware_0.get_uptime_facts() is None


# Generated at 2022-06-24 22:24:13.431195
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    memory_facts = sun_o_s_hardware_0.get_memory_facts()
    assert True


# Generated at 2022-06-24 22:24:15.511669
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    device_facts = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:24:17.733081
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    facts = {}
    sun_o_s_hardware_0.get_cpu_facts(facts)


# Generated at 2022-06-24 22:24:24.585518
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    assert sun_o_s_hardware_collector_0._fact_class is SunOSHardware
    assert sun_o_s_hardware_collector_0._platform == 'SunOS'
    assert set(sun_o_s_hardware_collector_0.required_facts) == set(['platform'])

# Generated at 2022-06-24 22:24:26.765144
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0._get_dmi_facts()



# Generated at 2022-06-24 22:24:31.648255
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # TODO: Need to test with a real kstat output
    sun_o_s_hardware_0 = SunOSHardware({})

    test_data = sun_o_s_hardware_0.get_uptime_facts()

    assert test_data.get('uptime_seconds') == None, "Failed to properly return uptime_seconds"



# Generated at 2022-06-24 22:24:37.543863
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.module.run_command = MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, "unix:0:system_misc:boot_time    1548249689", '')
    sun_o_s_hardware_0.module.get_bin_path = MagicMock()
    sun_o_s_hardware_0.module.get_bin_path.return_value = "/usr/bin/kstat"

    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:27:17.265733
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    object_mock = SunOSHardware()
    try:
        object_mock.populate()
    except Exception as err:
        print("Exception in test_SunOSHardware_populate : ", err)
        traceback.print_exc()
        exit(1)


# Generated at 2022-06-24 22:27:20.149452
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    assert sun_o_s_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 22:27:22.547437
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:25.742073
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:30.068531
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    from ansible_collections.community.general.plugins.module_utils.facts.hardware.sunos import SunOSHardware

    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:27:32.263886
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_os_hardware_get_device_facts_0 = SunOSHardware()

    # Case: Default return value
    assert sun_os_hardware_get_device_facts_0.get_device_facts() == {}


# Generated at 2022-06-24 22:27:34.637270
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    '''
    Unit test for method get_dmi_facts of class SunOSHardware
    '''
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:39.845165
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    SunOSHardware_instance_0 = SunOSHardware()
    rc, out, err = SunOSHardware_instance_0.module.run_command('/usr/bin/kstat -p sderr:::Product')
    rc, out, err = SunOSHardware_instance_0.module.run_command('/usr/bin/kstat -p sderr:::Revision')
    rc, out, err = SunOSHardware_instance_0.module.run_command('/usr/bin/kstat -p sderr:::Serial No')
    rc, out, err = SunOSHardware_instance_0.module.run_command('/usr/bin/kstat -p sderr:::Size')

# Generated at 2022-06-24 22:27:41.924060
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.populate() is None


# Generated at 2022-06-24 22:27:44.163097
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    returns_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert returns_0 == None
