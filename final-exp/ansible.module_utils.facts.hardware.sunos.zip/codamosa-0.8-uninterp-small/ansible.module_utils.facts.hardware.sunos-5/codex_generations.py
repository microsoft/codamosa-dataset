

# Generated at 2022-06-24 22:19:34.211186
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(bytes_0)


# Generated at 2022-06-24 22:19:35.402215
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    pass


# Generated at 2022-06-24 22:19:37.334898
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(None)

# Test of function get_cpu_facts

# Generated at 2022-06-24 22:19:49.268177
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'jA\x8c\x9f\x1f2\xde\x8f\x1c\xed\x02)\xad\x8e\x9b\xab\xdd\x8a\x15'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    param_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert param_0 == {}

    bytes_0 = b'\x0f\x88\xfd\xbf\x8b\xfe\x13\xdf\x9f\x8e\x02\xdd'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0

# Generated at 2022-06-24 22:19:52.559859
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:56.937081
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # Remove the comment from print to debug this method.
    # print("\n\nDEBUG: test SunOSHardware_get_cpu_facts")
    # print("\nChecking class and method get_cpu_facts exists in class SunOSHardware")
    assert(callable(getattr(SunOSHardware, "get_cpu_facts")))


# Generated at 2022-06-24 22:19:59.863092
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)


# Generated at 2022-06-24 22:20:01.681458
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    result = sun_o_s_hardware_0.get_memory_facts()
    assert result == {}


# Generated at 2022-06-24 22:20:02.439947
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test_case_0()


# Generated at 2022-06-24 22:20:07.029126
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xb3\x11_\xeb\x11\x12k\xfd\xe9\x07'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    # Test with valid case
    uptime_facts = sun_o_s_hardware_0.get_uptime_facts()
    assert(type(uptime_facts) == dict)



# Generated at 2022-06-24 22:20:28.353535
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:20:33.104884
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:38.198656
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Unit test for method get_uptime_facts of class SunOSHardware
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:20:41.430727
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:45.818107
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:50.169141
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    with pytest.raises(NotImplementedError):
        sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:53.837480
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:20:55.570088
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    print("Checking: SunOSHardware.populate")
    test_case_0()


# Generated at 2022-06-24 22:21:00.917975
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()
    sun_o_s_hardware_1 = SunOSHardware(bytes_0)
    var_1 = sun_o_s_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:21:04.563190
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    with pytest.raises(NotImplementedError):
        sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:40.565903
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:50.157836
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    try:
        test_case_0()
    except:
        assert False, "Unhandled exception was raised"

if __name__ == "__main__":
    import sys

    bytes0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware0 = SunOSHardware(bytes0)
    var0 = sun_o_s_hardware0.populate()
    print("var0: ")
    print(var0)
    print("var0.keys(): ")
    print(var0.keys())

    # umount_linux

    print("Test completed successfully")
    sys.exit(0)

# Generated at 2022-06-24 22:21:57.156360
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.module = MockModule()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:59.383206
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fixture_SunOSHardware = SunOSHardware()
    fixture_SunOSHardware.get_cpu_facts()


# Generated at 2022-06-24 22:22:09.335484
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-24 22:22:13.187556
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:16.641660
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:19.178618
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()

# Generated at 2022-06-24 22:22:24.608684
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert var_0 == {'memtotal_mb': 4096,
                     'swap_allocated_mb': 0, 'swap_reserved_mb': 0,
                     'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-24 22:22:27.714896
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:38.802112
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:43.075979
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:49.358047
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\x06\xeb\xda\xa1\x84\xb3\xfc\x9f\x82\x84\xbf\x88\x04\xed\x00b\xa0'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert var_0 is not None


# Generated at 2022-06-24 22:23:54.634834
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    with pytest.raises(Exception):
        sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:57.928532
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    sun_o_s_hardware_0 = SunOSHardware(b'\xab\x98\x15\xc7\x10\xba6\xcd\x9c\xee\x07\xed\xbb\xe8\x02\x99\xd2')
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:59.370937
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bits_0 = bytes_to_human(float(value))
    assert var_0 is None


# Generated at 2022-06-24 22:24:02.601119
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xdc\xa6\x15\xc7>\x8b\x07\xf3\x066'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert not var_0


# Generated at 2022-06-24 22:24:04.192840
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    # Init SunOSHardwareCollector
    sun_o_s_hardware_collector = SunOSHardwareCollector()

# Generated at 2022-06-24 22:24:14.954545
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:24:17.469953
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:29.615408
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:27:32.094334
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.populate()
    return var_0


# Generated at 2022-06-24 22:27:37.134713
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.populate()
    var_1 = sun_o_s_hardware_0.get_uptime_facts()
    print(var_1)


# Generated at 2022-06-24 22:27:39.042436
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_1 = sun_o_s_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:27:40.593288
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    if not isinstance(SunOSHardware.get_memory_facts(), dict):
        raise AssertionError()


# Generated at 2022-06-24 22:27:47.444907
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'\x1d\xdc\x01\xbc\x1c\xef\xbc\x16\xc4\xcb\x14\xee\xf8\x9b\x08\x1e'
    bytes_1 = b'x\x97\xa3\x8c\x9c\x94\xa3\x92\x8b\x94x\x91\xa3\x99\x8f\x9c\x86'
    bytes_2 = b'\x03\x1c\xdd\xfe\x8b\x9c\x9c\x12\x8c\x9c\x18\x1c\x8e\x9c\x1e\x1c'

# Generated at 2022-06-24 22:27:50.725769
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:27:54.911272
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert not var_0 == None
    var_1 = sun_o_s_hardware_0.get_memory_facts()
    assert not var_1 == None


# Generated at 2022-06-24 22:27:58.846600
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:28:03.293345
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # FIXME: Use a mock instead of using a real file.
    bytes_0 = b'\xd4}\x17\x006,'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()
