

# Generated at 2022-06-24 22:19:33.953853
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    if SunOSHardware.get_device_facts() != {}:
        raise AssertionError()


# Generated at 2022-06-24 22:19:35.460544
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:19:43.484443
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test function get_dmi_facts of class SunOSHardware
    str_0 = '3'
    str_1 = os.path.join(os.path.dirname(__file__), 'output/kstat_system_configuration_sun4v.txt')
    str_2 = '1.0'
    str_3 = None
    str_4 = os.path.join(os.path.dirname(__file__), 'output/kstat_system_configuration_sun4u.txt')
    str_5 = os.path.join(os.path.dirname(__file__), 'output/kstat_system_configuration_sun4v.txt')
    str_6 = 'Sun Microsystems'
    str_7 = 'T2000'
    str_8 = 'T2000'
    str_9

# Generated at 2022-06-24 22:19:46.548929
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_1 = 'f'
    sun_o_s_hardware_1 = SunOSHardware(str_1)
    sun_o_s_hardware_1.populate()

# Generated at 2022-06-24 22:19:51.804268
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    print('Testing get_dmi_facts of class SunOSHardware')
    str_0 = '6G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    result = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:01.770838
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts = {}
    str_0 = 'unix:0:system_misc:boot_time    1548249689'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.run_command = MagicMock(name='run_command')
    sun_o_s_hardware_0.run_command.return_value = (0, str_0, None)
    
    sun_o_s_hardware_0.get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 1548249689}, "Expected {'uptime_seconds': 1548249689}, got {0}".format(uptime_facts)


# Generated at 2022-06-24 22:20:04.856051
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '6G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    assert sun_o_s_hardware_0.get_device_facts() is None
    return None


# Generated at 2022-06-24 22:20:09.277316
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = '6G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    result = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:12.941198
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = '6G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:17.029980
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware('')
    # Returns dictionary:
    return_value_1 = sun_o_s_hardware_1.get_cpu_facts()
    assert return_value_1


# Generated at 2022-06-24 22:20:36.139677
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_1 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:38.290595
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)


# Generated at 2022-06-24 22:20:43.407064
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware('J')
    facts = {'platform': 'SunOS'}
    sun_o_s_hardware_0.module = MockModule(facts=facts)
    out = """unix:0:system_misc:boot_time    1548249689
"""
    sun_o_s_hardware_0.module.run_command.return_value = (0, out, '')
    sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:20:46.896661
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:50.125272
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:20:56.030460
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    try:
        str_0 = 'G' # Type string
        sun_o_s_hardware_0 = SunOSHardware(str_0)
        var_0 = sun_o_s_hardware_0.get_memory_facts()
        print(var_0)
    except Exception as str_0:
        print('Exception caught: ' + str(str_0))
    else:
        raise Exception('Exception not caught')


# Generated at 2022-06-24 22:20:56.972927
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:20:59.407005
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    print("Testing get_cpu_facts")
    temp0 = SunOSHardware("Testing with argument")
    temp0.get_cpu_facts()


# Generated at 2022-06-24 22:21:04.365306
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'G'
    # try:
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()
    assert not var_0
    # except:
    #     raise

    assert not sun_o_s_hardware_0
    assert str_0 == 'G'
    assert not var_0


# Generated at 2022-06-24 22:21:05.494479
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = SunOSHardware.get_cpu_facts()


# Generated at 2022-06-24 22:21:36.138009
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
   pass


# Generated at 2022-06-24 22:21:39.386535
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'F'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:41.328833
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:21:46.367953
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'l'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.module = unittest.mock.MagicMock()
    sun_o_s_hardware_0.module.run_command = unittest.mock.MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, '', '')
    sun_o_s_hardware_0.module.get_bin_path = unittest.mock.MagicMock()
    sun_o_s_hardware_0.module.get_bin_path.return_value = '2'
    var_0 = sun_o_s_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:21:48.571115
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
	obj = SunOSHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_SunOSHardwareCollector()

# Generated at 2022-06-24 22:21:52.742337
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'l'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:57.150366
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # FIXME: cannot set run_command() here :(
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:02.057599
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = '$'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:05.885098
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'o'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    assert sun_o_s_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:22:08.982750
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '2c'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_dmi_facts()
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:16.266829
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:21.869537
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'f'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:26.313082
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'n'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:28.405605
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    print("Test get_dmi_facts")
    str_0 = 'k'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:23:30.737281
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # FIXME: This unit test is incomplete and cannot be executed
    raise NotImplementedError()


# Generated at 2022-06-24 22:23:35.548074
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:39.529924
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = '1'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert isinstance(var_0, dict)
    #assert len(var_0) == 2


# Generated at 2022-06-24 22:23:43.401083
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'w'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:44.193679
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()

# Generated at 2022-06-24 22:23:46.897169
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # Setup test values
    unittest.TestCase.assertEqual(self, SunOSHardware.get_cpu_facts(), None)



# Generated at 2022-06-24 22:26:48.180706
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'E'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:26:51.343501
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:26:55.418214
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:26:57.771212
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:26:59.531785
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()

    assert var_0 != None


# Generated at 2022-06-24 22:27:03.678914
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:27:06.084907
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = '('
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_2 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:11.061724
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    rc, out, err = module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    assert rc == 0
    assert out == ''


# Generated at 2022-06-24 22:27:21.185621
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'G'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_1 = SunOSHardware(str_0)
    sun_o_s_hardware_2 = SunOSHardware(str_0)
    sun_o_s_hardware_3 = SunOSHardware(str_0)
    sun_o_s_hardware_4 = SunOSHardware(str_0)
    sun_o_s_hardware_5 = SunOSHardware(str_0)
    sun_o_s_hardware_6 = SunOSHardware(str_0)
    sun_o_s_hardware_7 = SunOSHardware(str_0)
    sun_o_s_hardware_8 = SunOSHardware(str_0)
   

# Generated at 2022-06-24 22:27:23.495115
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'hello'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()