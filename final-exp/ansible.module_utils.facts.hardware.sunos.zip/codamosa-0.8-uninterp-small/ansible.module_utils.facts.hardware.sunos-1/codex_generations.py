

# Generated at 2022-06-24 22:19:40.117376
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    out = '''sderr:::Product VBOX HARDDISK   9
sderr:::Revision        1.0
sderr:::Serial No       VB0ad2ec4d-074a
sderr:::Size    53687091200
sderr:::Vendor  ATA
sderr:::Hard Errors     0
sderr:::Soft Errors     0
sderr:::Transport Errors        0
sderr:::Media Error     0
sderr:::Predictive Failure Analysis     0
sderr:::Illegal Request 6'''
    assert out == SunOSHardware.get_device_facts(out)


# Generated at 2022-06-24 22:19:44.794958
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Test for method populate of class SunOSHardware
    sun_o_s_hardware_1 = SunOSHardware(':Oeje\\U\\Ih.n=oid')
    sun_o_s_hardware_1.populate()
    assert 0 == 0


# Generated at 2022-06-24 22:19:47.494322
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    facts = {'uptime_seconds': 54321}
    assert facts == SunOSHardware.get_uptime_facts({})


# Generated at 2022-06-24 22:19:52.719672
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware('@@O}\\1z,Mt+')
    str_0 = 'dV7J)2b5([W{`&L-gJ;Ym]d@$'
    sun_o_s_hardware_0.module = str_0
    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:19:56.331416
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'R;>_z-)N`Jc`CC8'
    sun_o_s_hardware_0 = SunOSHardware(str_0)

    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:02.294973
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '1^]|1+5bZ'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    m_d_i_c_v_4_facts_0 = {}
    sun_o_s_hardware_0.get_device_facts(m_d_i_c_v_4_facts_0)


# Generated at 2022-06-24 22:20:06.153375
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = ':Oeje\\U\\Ih.n=oid'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    collected_facts_0 = dict()

    sun_o_s_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:20:17.692531
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ':Oeje\\U\\Ih.n=oid'
    sun_o_s_hardware_0 = SunOSHardware(str_0)

    # Call method of class SunOSHardware
    sun_o_s_hardware_0.get_uptime_facts()

    # test with unicode string
    # Unit test for method get_uptime_facts of class SunOSHardware
    def test_SunOSHardware_get_uptime_facts():
        str_1 = u':Oeje\\U\\Ih.n=oid'
        sun_o_s_hardware_1 = SunOSHardware(str_1)

        # Call method of class SunOSHardware
        sun_o_s_hardware_1.get_uptime_facts()
        assert True


# Generated at 2022-06-24 22:20:22.124320
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = '&hf$8@k6+z>6$_Y6;{'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:24.443387
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'c:\\'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    dict_1 = {}


# Generated at 2022-06-24 22:20:49.588325
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # out1 = 'unix:0:system_misc:boot_time    1548249689'
    # current_time = int(time.time())
    # boot_time = out1.split('\t')[1]
    # uptime_seconds = int(current_time - int(boot_time))
    hardware = SunOSHardware({'ansible_system_vendor': ''})
    out1 = 'unix:0:system_misc:boot_time    1548249689'
    assert hardware.get_uptime_facts() == {'uptime_seconds': int()}


# Generated at 2022-06-24 22:20:59.633024
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    out_0 = 'VBOX HARDDISK'
    out_1 = None
    out_2 = '1.0'
    out_3 = 'VB0ad2ec4d-074a'
    out_4 = '53687091200'
    out_5 = 'ATA'
    out_6 = '0'
    out_7 = '0'
    out_8 = '0'
    out_9 = '0'
    out_10 = '0'
    out_11 = '6'
    ds_0 = 'Soft Errors'
    ds_1 = 'Size'
    ds_2 = 'Illegal Request'
    ds_3 = 'Vendor'
    ds_4 = 'Product'
    ds_5 = 'Revision'

# Generated at 2022-06-24 22:21:07.460787
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    print("Test case 0 - populate")
    hc = SunOSHardware()
    result = hc.populate()

    assert("devices" in result)
    assert("mounts" in result)
    assert("processor" in result)
    assert("processor_cores" in result)
    assert("processor_count" in result)
    assert("memtotal_mb" in result)
    assert("uptime_seconds" in result)
    assert("swapfree_mb" in result)
    assert("swaptotal_mb" in result)
    assert("swap_allocated_mb" in result)
    assert("swap_reserved_mb" in result)



# Generated at 2022-06-24 22:21:09.976893
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    obj = SunOSHardwareCollector(None)
    assert obj._fact_class == SunOSHardware
    assert obj._platform == 'SunOS'
    assert obj.required_facts == set(['platform'])


# Generated at 2022-06-24 22:21:11.154319
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    hardware = SunOSHardware()
    hardware.get_cpu_facts()


# Generated at 2022-06-24 22:21:17.851237
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # From local variable test_case_0
    str_0 = 'sderr:::Product VBOX HARDDISK   9\nsderr:::Revision        1.0\nsderr:::Serial No       VB0ad2ec4d-074a\nsderr:::Size    53687091200\nsderr:::Vendor  ATA\nsderr:::Hard Errors     0\nsderr:::Soft Errors     0\nsderr:::Transport Errors        0\nsderr:::Media Error     0\nsderr:::Predictive Failure Analysis     0\nsderr:::Illegal Request 6'

# Generated at 2022-06-24 22:21:28.391145
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    ver_str_0 = 'product_name=Oracle Corporation Sun Fire V490, bios_version=2005.01.31_09:38, bios_vendor=Oracle Corporation, system_vendor=Oracle Corporation'
    str_type_0 = type(ver_str_0)
    ver_str_1 = 'product_name=Oracle Corporation Sun Fire V490, bios_version=2005.01.31_09:38, bios_vendor=Oracle Corporation, system_vendor=Oracle Corporation'
    str_type_1 = type(ver_str_1)
    ver_str_2 = 'product_name=Oracle Corporation Sun Fire V490, bios_version=2005.01.31_09:38, bios_vendor=Oracle Corporation, system_vendor=Oracle Corporation'
    str_type_2 = type(ver_str_2)
   

# Generated at 2022-06-24 22:21:29.494810
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # FIXME
    pass


# Generated at 2022-06-24 22:21:31.685151
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sunos_hardware = SunOSHardware()
    assert sunos_hardware.get_uptime_facts() == {}


# Generated at 2022-06-24 22:21:35.351889
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    mem_facts = SunOSHardware.get_memory_facts(None)
    assert mem_facts['memtotal_mb'] == '1'
    assert mem_facts['swaptotal_mb'] == '2'
    assert mem_facts['swap_allocated_mb'] == '3'
    assert mem_facts['swap_reserved_mb'] == '4'


# Generated at 2022-06-24 22:21:57.822438
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    # Call method get_cpu_facts of class SunOSHardware with argument sun_o_s_hardware_0.
    sun_o_s_hardware_0.get_cpu_facts(sun_o_s_hardware_0)


# Generated at 2022-06-24 22:22:03.146830
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:13.187866
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.run_command = test_SunOSHardware_get_dmi_facts_0
    sun_o_s_hardware_0.get_file_content = test_SunOSHardware_get_dmi_facts_1
    var_0 = sun_o_s_hardware_0.get_dmi_facts()
    # Failing due to: "AttributeError: 'SunOSHardware' object has no attribute '_ds'"
    # assert var_0 == {'product_name': 'V450-4', 'system_vendor': 'Sun Microsystems'}


# Generated at 2022-06-24 22:22:16.460623
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:22:19.533090
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    print("Starting test_SunOSHardware_populate...")
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.populate()
    print("test_SunOSHardware_populate finished")


# Generated at 2022-06-24 22:22:25.077222
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Set up mock objects
    ansible_module = type('AnsibleModule', (), {'run_command': Mock(return_value=(0, 'This is dmi output', ''))})
    str_0 = ' ,'

    # Call method to test
    sun_o_s_hardware_0 = SunOSHardware(ansible_module=ansible_module, platform=str_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:28.541736
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    global str_0, sun_o_s_hardware_0, var_0
    test_case_0()

if __name__ == '__main__':
    test_SunOSHardware_get_memory_facts()

# Generated at 2022-06-24 22:22:30.880162
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Case 0
    test_case_0()



# Generated at 2022-06-24 22:22:32.697876
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:37.816212
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_2 = SunOSHardware(' ,')

    # Test for method get_cpu_facts of class SunOSHardware
    def test_SunOSHardware_get_cpu_facts():
        sun_o_s_hardware_1 = SunOSHardware(' ,')

# Generated at 2022-06-24 22:23:16.840862
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware(None)
    sun_o_s_hardware_0.get_cpu_facts('Collected_facts')


# Generated at 2022-06-24 22:23:22.875971
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # FIXME: add test cases
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:28.720278
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '0.0'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()
    str_1 = '0.0'
    # Expected return value: map[string]interface {}
    sun_o_s_hardware_0 = SunOSHardware(str_1)
    var_1 = sun_o_s_hardware_0.get_device_facts()

# Generated at 2022-06-24 22:23:30.115933
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    pass


# Generated at 2022-06-24 22:23:35.848743
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:42.719223
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Last boot time is $current_time - $boot_time
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()
    str_1 = ' ,'
    sun_o_s_hardware_1 = SunOSHardware(str_1)
    var_1 = sun_o_s_hardware_1.get_device_facts()
    str_2 = ' ,'
    sun_o_s_hardware_2 = SunOSHardware(str_1)
    var_2 = sun_o_s_hardware_2.get_dmi_facts()

# Generated at 2022-06-24 22:23:45.931074
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert var_0 == None



# Generated at 2022-06-24 22:23:49.847513
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:23:54.426989
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:57.256822
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create an instance of class SunOSHardware
    sun_o_s_hardware_0 = SunOSHardware()
    # Call the get_device_facts method of SunOSHardware class
    sun_o_s_hardware_0.get_device_facts()

# Generated at 2022-06-24 22:25:20.943801
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    SunOSHardware_0 = SunOSHardware(str_0)
    var_0 = SunOSHardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:25.961861
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    d = {}
    var_0 = sun_o_s_hardware_0.get_device_facts()
    assert var_0 == d, 'Expected: ' + d + '. Got: ' + var_0


# Generated at 2022-06-24 22:25:26.863281
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()



# Generated at 2022-06-24 22:25:32.354827
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    rc, out, err = subprocess.run(['kstat', '-p', 'unix:0:system_misc:boot_time'], stdout=subprocess.PIPE)
    boot_time = int(out.split('\t')[1])

    current_time = int(time.time())
    assert current_time - boot_time == SunOSHardware().get_uptime_facts()['uptime_seconds']

# Generated at 2022-06-24 22:25:34.914878
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:25:37.648265
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:42.582740
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    args0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(args0)
    sun_o_s_hardware_0.module = MagicMock()
    args0 = ' '
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(1, args0, ' '))
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:25:50.710278
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    str_1 = ' /usr/bin/kstat -p unix:0:system_misc:boot_time'
    int_0 = 0
    str_2 = ''
    str_3 = '1548249689'
    dict_0 = dict()
    dict_0['returncode'] = int_0
    dict_0['stdout'] = str_3

    def mock_run_command(self, str_1):
        return dict_0

    sun_o_s_hardware_0.module.run_command = mock_run_command
    dict_1 = sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:25:56.839874
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = ' ,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()
    assert var_0['processor'] == [
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz",
        "SPARCv9 @ 1333MHz"
    ]
    assert var_0['processor_count'] == 8
    assert var_0['processor_cores'] == 8


# Generated at 2022-06-24 22:26:02.359070
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test with a real output
    prtdiag_out = 'System Configuration: Oracle Corporation sun4v SPARC T5-8 Server\n'
    dmi_facts = SunOSHardware('SunOS').get_dmi_facts()
    assert dmi_facts == {'system_vendor': 'Oracle Corporation',
                         'product_name': 'sun4v SPARC T5-8 Server'}
