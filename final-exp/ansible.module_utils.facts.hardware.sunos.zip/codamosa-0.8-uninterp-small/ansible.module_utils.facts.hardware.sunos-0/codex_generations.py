

# Generated at 2022-06-24 22:19:38.375056
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:19:51.382204
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = True
    sun_o_s_hardware_0 = SunOSHardware(bool_0)

    # Testing with face value
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4v', ''))
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()
    assert isinstance(dmi_facts, dict) and len(dmi_facts) == 2 and dmi_facts['system_vendor'] == 'Sun Microsystems' and dmi_facts['product_name'] == 'sun4v'


# Generated at 2022-06-24 22:20:01.665323
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0)
    sun_o_s_hardware_0.module = ModuleStub()
    sun_o_s_hardware_0.run_command_environ_update = {}
    sun_o_s_hardware_0.module.run_command_environ_update = {}
    sun_o_s_hardware_0.set_command_environ(sun_o_s_hardware_0.module.run_command_environ_update)
    sun_o_s_hardware_0.module.run_command_environ_update = {}
    sun_o_s_hardware_0.module.fail_json = MagicMock()

# Generated at 2022-06-24 22:20:04.130976
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware(bool_0)
    str_0 = sun_o_s_hardware_0.get_memory_facts()
    print(str_0)


# Generated at 2022-06-24 22:20:08.032199
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = True
    sun_o_s_hardware_0 = SunOSHardware(bool_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:20:12.108922
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware("true")
    sun_o_s_hardware_0.module.run_command = MagicMock()

    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:21.006635
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = True
    sun_o_s_hardware_0 = SunOSHardware(bool_0)
    # 10
    sun_o_s_hardware_0.run_command = class_mock_0
    # 20
    sun_o_s_hardware_0.get_file_content = class_mock_1
    # 30
    sun_o_s_hardware_0.get_bin_path = class_mock_2

    ret_val_0 = sun_o_s_hardware_0.get_dmi_facts()
    assert ret_val_0 is None



# Generated at 2022-06-24 22:20:25.584559
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bool_0 = True
    sun_o_s_hardware_0 = SunOSHardware(bool_0)
    result = sun_o_s_hardware_0.get_cpu_facts()
    assert result['processor']
    assert result['processor_cores']
    assert result['processor_count']


# Generated at 2022-06-24 22:20:28.475448
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware(None)
    try:
        sun_o_s_hardware_0.get_uptime_facts()
        assert False
    except:
        assert True


# Generated at 2022-06-24 22:20:35.979878
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.required_facts = set()
    # FIXME:
    # assert isinstance(sun_o_s_hardware_0.get_dmi_facts(), dict)
    # assert sun_o_s_hardware_0.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'Sun Fire V240'}


# Generated at 2022-06-24 22:21:00.694788
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return_value_0 = sun_o_s_hardware_0.get_dmi_facts()
    return_value_1 = sun_o_s_hardware_0.get_dmi_facts()
    return_value_2 = sun_o_s_hardware_0.get_device_facts()
    assert return_value_0 == {}
    assert return_value_1 == {}
    assert return_value_2 == {'devices': {}}


# Generated at 2022-06-24 22:21:06.147332
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    memory_facts = sun_o_s_hardware_0._get_memory_facts()
    for k, v in memory_facts.items():
        assert isinstance(k, (type(None), str)), "'k' is not of 'NoneType' or 'str'"
        assert isinstance(v, (type(None), int)), "'v' is not of 'NoneType' or 'int'"


# Generated at 2022-06-24 22:21:08.425396
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware = SunOSHardware()
    result = sun_o_s_hardware.populate()
    assert result


# Generated at 2022-06-24 22:21:10.248039
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    resp = sun_o_s_hardware.get_device_facts()
    assert isinstance(resp, dict)


# Generated at 2022-06-24 22:21:12.763584
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    assert sun_o_s_hardware_1.get_cpu_facts() == {'processor_count': 'NA', 'processor_cores': 'NA', 'processor': []}, 'Unit test failed'


# Generated at 2022-06-24 22:21:15.315096
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:21.860681
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_get_uptime_facts_0 = SunOSHardware()
    sun_o_s_hardware_get_uptime_facts_0.module.run_command = MagicMock(return_value=[0, "unix:0:system_misc:boot_time    1548249689", ""])
    sun_o_s_hardware_get_uptime_facts_0.uptime_seconds = int(time.time() - int("1548249689".split('\t')[1]))
    assert sun_o_s_hardware_get_uptime_facts_0.uptime_seconds == int(time.time() - int("1548249689".split('\t')[1]))


# Generated at 2022-06-24 22:21:25.670089
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    test_param_0 = {
        'devices': {}
    }
    sun_o_s_hardware_0.get_device_facts(test_param_0)


# Generated at 2022-06-24 22:21:29.394372
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:21:32.699866
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    res = sun_o_s_hardware_0.get_cpu_facts()
    assert isinstance(res, dict)
    assert res == {}


# Generated at 2022-06-24 22:22:14.515092
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    memory_facts = sun_o_s_hardware_0.get_memory_facts()
    assert (memory_facts['memtotal_mb'])
    assert (memory_facts['swap_allocated_mb'])
    assert (memory_facts['swap_reserved_mb'])
    assert (memory_facts['swaptotal_mb'])
    assert (memory_facts['swapfree_mb'])


# Generated at 2022-06-24 22:22:17.869576
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    dmi_facts_1 = sun_o_s_hardware_1.get_dmi_facts()
    assert dmi_facts_1
    assert dmi_facts_1['system_vendor'] == 'Oracle Corporation'


# Generated at 2022-06-24 22:22:23.088922
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    facts = {}
    facts['ansible_machine'] = 'i86pc'
    sun_o_s_hardware = SunOSHardware(facts)

    out = '''System Configuration: Sun Microsystems sun4u'''

    # mock module to return desired output
    sun_o_s_hardware.module.run_command.return_value = (0, out, '')
    sun_o_s_hardware.get_dmi_facts()

    # test if command is called
    sun_o_s_hardware.module.run_command.assert_called_with('/usr/bin/prtdiag')


# Generated at 2022-06-24 22:22:30.826088
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_hardware_1.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_hardware_1.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_hardware_1.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_hardware_1.module.run_command = MagicMock(return_value=[0, '', ''])
    sun_o_s_hardware_1.module.run_command

# Generated at 2022-06-24 22:22:34.100791
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    platform = 'SunOS'
    sun_o_s_hardware_0 = SunOSHardware(platform)
    collected_facts = {}
    collected_facts.update({'platform': platform})
    sun_o_s_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:22:37.727575
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:22:40.259451
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:44.685671
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.populate()
    sun_o_s_hardware_1.populate()


# Generated at 2022-06-24 22:22:53.034570
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    sun_o_s_hardware = SunOSHardware()

# Generated at 2022-06-24 22:22:57.072509
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = lambda x: (0, '', '')
    sun_o_s_hardware_0.module.run_command = lambda x: (0, 'Memory size:  8192 Megabytes', '')
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:24:12.745463
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:24:16.334649
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware = SunOSHardware()
    test_fact_1 = sun_o_s_hardware.get_uptime_facts()
    test_fact_2 = sun_o_s_hardware.get_uptime_facts()
    assert test_fact_1 == test_fact_2


# Generated at 2022-06-24 22:24:20.569627
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    cpu_facts = sun_o_s_hardware_0.get_cpu_facts()
    assert("processor" in cpu_facts)


# Generated at 2022-06-24 22:24:23.772450
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware = SunOSHardware()
    uptime_facts = sun_o_s_hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts


# Generated at 2022-06-24 22:24:28.182333
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:24:32.753548
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor_count': 1, 'processor': ['Intel(R) Xeon(R) CPU E5-2670 v3 @ 2.30GHz'], 'processor_cores': 2}


# Generated at 2022-06-24 22:24:35.949896
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:24:43.157019
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock()

    # Create a mock command output

# Generated at 2022-06-24 22:24:45.894493
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_obj = SunOSHardware()

    x = sun_o_s_hardware_obj.get_cpu_facts()


# Generated at 2022-06-24 22:24:54.627535
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0,'sderr:::Hard Errors\t0\nsderr:::Illegal Request\t6\nsderr:::Media Error\t0\nsderr:::Predictive Failure Analysis\t0\nsderr:::Product VBOX HARDDISK\t9\nsderr:::Revision\t1.0\nsderr:::Serial No\tVB0ad2ec4d-074a\nsderr:::Size\t53687091200\nsderr:::Soft Errors\t0\nsderr:::Transport Errors\t0\nsderr:::Vendor\tATA','stderr'))
    sun_

# Generated at 2022-06-24 22:26:54.588463
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.run_command = lambda x, **kwargs: '\n'
    sun_o_s_hardware_0.get_file_content = lambda x: '\n'
    sun_o_s_hardware_0.get_mount_size = lambda x: '\n'
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:02.271149
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()

    # Test attributes are not none
    assert sun_o_s_hardware_0.cpu_facts is not None
    assert sun_o_s_hardware_0.memory_facts is not None
    assert sun_o_s_hardware_0.dmi_facts is not None
    assert sun_o_s_hardware_0.device_facts is not None
    assert sun_o_s_hardware_0.uptime_facts is not None
    assert sun_o_s_hardware_0.mount_facts is not None

    # Test attributes are not empty
    assert sun_o_s_hardware_0.cpu_facts != {}
    assert sun_o_s_hardware_0.memory_facts != {}
    assert sun_o_

# Generated at 2022-06-24 22:27:05.995731
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor': []}


# Generated at 2022-06-24 22:27:10.402818
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_ = SunOSHardware()
    sun_o_s_hardware_.populate()


# Generated at 2022-06-24 22:27:18.572781
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_1 = SunOSHardware()
    sun_o_s_hardware_2 = SunOSHardware()

    sun_o_s_hardware_0.get_device_facts()

    assert isinstance(sun_o_s_hardware_0._device_facts, dict) == True
    assert (isinstance(sun_o_s_hardware_1._device_facts, dict) == True) == True
    assert (isinstance(sun_o_s_hardware_2._device_facts, dict) == True) == True


# Generated at 2022-06-24 22:27:21.715059
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # FIXME
    pass
    # sun_o_s_hardware_0 = SunOSHardware()
    # assert sun_o_s_hardware_0.get_device_facts() is None, 'could not get device facts'


# Generated at 2022-06-24 22:27:31.278536
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:27:38.444455
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware_collector = SunOSHardwareCollector()
    hardware_collector._module.run_command = lambda *args: (1, "", "")
    hardware_collector._module.get_bin_path = lambda *args, **kw: "/usr/sbin/swap"
    hardware_collector._module.is_executable = lambda *args, **kw: True
    assert hardware_collector.get_memory_facts() == {
        'swapfree_mb': 0,
        'swap_reserved_mb': 0,
        'swap_allocated_mb': 0,
        'swaptotal_mb': 0
    }


# Generated at 2022-06-24 22:27:39.727187
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    pass

# Generated at 2022-06-24 22:27:41.825002
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return_value_0 = sun_o_s_hardware_0.get_dmi_facts()
