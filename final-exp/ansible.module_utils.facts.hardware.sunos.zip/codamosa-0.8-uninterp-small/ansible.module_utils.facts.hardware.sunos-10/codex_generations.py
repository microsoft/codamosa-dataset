

# Generated at 2022-06-24 22:19:36.222453
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    collected_facts['ansible_machine'] = 'i86pc'
    collected_facts['ansible_architecture'] = 'x86'
    sun_o_s_hardware_0.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:19:39.083564
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Initializing object
    sun_o_s_hardware = SunOSHardware(module=None)

    # The populate method doesn't return anything, hence testing the input parameters of the call.
    sun_o_s_hardware.populate(collected_facts=None)


# Generated at 2022-06-24 22:19:43.609452
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    output = sun_o_s_hardware_0.get_uptime_facts()
    assert output['uptime_seconds'] >= 0, "Failed to parse uptime_seconds"

# Generated at 2022-06-24 22:19:45.423272
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Case 1: No parameter is passed
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:54.798984
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware = SunOSHardware()
    collected_facts = {u'ansible_machine': u'i86pc'}
    result = sun_o_s_hardware.populate(collected_facts)
    assert result['processor'] == [u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz', u'Genuine Intel(R) CPU 0000 @ 2094MHz']
    assert result['processor_cores'] == 8
   

# Generated at 2022-06-24 22:20:01.612758
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.module = AnsibleModule(argument_spec=dict())
    sun_o_s_hardware.module.run_command = lambda args, **kwargs: (0, '', '')
    sun_o_s_hardware.populate()
    result = sun_o_s_hardware.get_memory_facts()
    assert type(result) is dict


# Generated at 2022-06-24 22:20:04.731364
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_os_hardware_obj = SunOSHardware()
    expected_result = sun_os_hardware_obj.get_cpu_facts()
    assert expected_result != None, "Test Case for method get_cpu_facts failed"


# Generated at 2022-06-24 22:20:16.864613
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_collector = SunOSHardwareCollector()
    sun_o_s_hardware_0 = SunOSHardware()
    out_1 = sun_o_s_hardware_0.get_memory_facts()
    assert out_1['memtotal_mb'] == 1024
    assert out_1['swaptotal_mb'] == 2048
    assert out_1['swapfree_mb'] == 1024
    assert out_1['swap_allocated_mb'] == 8192
    assert out_1['swap_reserved_mb'] == 4096
    assert out_1['swaptotal'] == 2097152
    assert out_1['swapfree'] == 1048576
    assert out_1['swap_allocated'] == 8388608

# Generated at 2022-06-24 22:20:19.971274
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware_0 = SunOSHardwareCollector().collect()['ansible_facts']['ansible_system_vendor']
    if hardware_0 == 'Fujitsu':
        test_case_0()


# Generated at 2022-06-24 22:20:23.189422
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    output_1 = sun_o_s_hardware_0.get_dmi_facts()
    assert output_1 == {}


# Generated at 2022-06-24 22:20:43.945242
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    device_facts = sun_o_s_hardware_0.get_device_facts()

    assert device_facts['devices'] == {}


# Generated at 2022-06-24 22:20:53.115977
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0._module = MagicMock()
    sun_o_s_hardware_0._module.get_bin_path.return_value = 'prtdiag'

# Generated at 2022-06-24 22:21:02.442661
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:21:07.186077
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    module = AnsibleModule(argument_spec={'filter': {'required': False, 'type': 'list', 'elements': 'str'}})
    filtered_result = SunOSHardware.populate(collector=SunOSHardwareCollector(), module=module)
    assert filtered_result['ansible_processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz', 'SPARC64-VII (chipid 1, clock 1200 MHz) @ 1200MHz']


# Generated at 2022-06-24 22:21:11.268944
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class SunOSHardware in module ansible.module_utils.facts.hardware.sunos.

    The method get_cpu_facts is tested for the following scenarios:
    - default
    - Use the module run_command helper to verify the operation.
    - Use a mocked module to pass a test.
    """
    sun_o_s_hardware_0 = SunOSHardware()

    # Test with default parameters.
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:15.012382
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    assert isinstance(sun_o_s_hardware.get_device_facts(), dict), "Test for method get_device_facts of class SunOSHardware"
    assert isinstance(sun_o_s_hardware.get_device_facts(), dict), "Test for method get_device_facts of class SunOSHardware"


# Generated at 2022-06-24 22:21:21.886500
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    # Set a mock for get_file_content
    sun_o_s_hardware_0.get_file_content = lambda path: 'fake_content'
    # Set a mock for get_mount_size
    sun_o_s_hardware_0.get_mount_size = lambda mount_point: {'size_total': 120, 'size_available': 40, 'size_used': 80}
    # Set a mock for run_command
    sun_o_s_hardware_0.run_command = lambda args, data=None, binary_data=False: (0, 'fake_out', 'fake_err')
    # Set a mock for get_bin_path

# Generated at 2022-06-24 22:21:23.429696
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    output = sun_o_s_hardware.get_device_facts()

    assert type(output) == dict


# Generated at 2022-06-24 22:21:26.013907
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:31.460479
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'Oracle VM VirtualBox'}, 'returned incorrect value'


# Generated at 2022-06-24 22:22:05.613204
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    assert sun_o_s_hardware.get_device_facts() == {u'devices': {}}


# Generated at 2022-06-24 22:22:08.875887
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware = SunOSHardware()
    out = sun_o_s_hardware.get_dmi_facts()
    assert isinstance(out, dict)


# Generated at 2022-06-24 22:22:18.026469
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_get_dmi_facts_0 = SunOSHardware()
    sun_o_s_hardware_get_dmi_facts_0.module.run_command = lambda *args, **kwargs: (0, 'System Configuration:  VMware, Inc.  VMware Virtual Platform\n', '')
    assert sun_o_s_hardware_get_dmi_facts_0.get_dmi_facts()['system_vendor'] == 'VMware, Inc.'
    assert sun_o_s_hardware_get_dmi_facts_0.get_dmi_facts()['product_name'] == 'VMware Virtual Platform'
    sun_o_s_hardware_get_dmi_facts_1 = SunOSHardware()
    sun_o_s_hardware_get_dmi_

# Generated at 2022-06-24 22:22:27.870277
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-24 22:22:35.482661
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_get_uptime_facts_1 = SunOSHardware()
    sun_o_s_hardware_get_uptime_facts_1.module = type('', (object,), dict(run_command=test_SunOSHardware_get_uptime_facts_mock_run_command_1))

    sun_o_s_hardware_get_uptime_facts_1 = sun_o_s_hardware_get_uptime_facts_1.get_uptime_facts()
    assert isinstance(sun_o_s_hardware_get_uptime_facts_1, dict)
    assert sun_o_s_hardware_get_uptime_facts_1 == {'uptime_seconds': 1548249689}


# Generated at 2022-06-24 22:22:43.089024
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware_0 = SunOSHardware()
    sunos_hardware_0.module.run_command = mock_run_command_0
    sunos_hardware_0.module.get_bin_path = mock_get_bin_path_0

    assert sunos_hardware_0.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'SUNW,SPARC-Enterprise-T5220'}




# Generated at 2022-06-24 22:22:47.130670
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_os_hardware = SunOSHardware({}, {}, {}, {})
    assert sun_os_hardware._get_cpu_facts() == {}


# Generated at 2022-06-24 22:22:54.888638
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOSHardware_0 = SunOSHardware()
    SunOSHardware_0.module = Mock()
    SunOSHardware_0.module.run_command.return_value = (1, 'System Configuration: Sun Microsystems sun4v', '')

    dmi_facts = SunOSHardware_0.get_dmi_facts()
    assert dmi_facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}

test_case_0()

# Generated at 2022-06-24 22:22:57.858558
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0_devices = sun_o_s_hardware_0.get_device_facts()
    assert 'devices' in sun_o_s_hardware_0_devices


# Generated at 2022-06-24 22:23:05.857492
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModuleStub()
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    sun_o_s_hardware_0.populate()
    expected = {}
    expected['uptime_seconds'] = int(time.time() - 1548249689)
    assert sun_o_s_hardware_0.get_uptime_facts() == expected

# Generated at 2022-06-24 22:24:19.481071
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.module.get_bin_path.return_value = '/usr/bin/prtdiag'

    sun_o_s_hardware_0.module.run_command.return_value = (0, "System Configuration:  Sun Microsystems sun4v \n", "")

    assert sun_o_s_hardware_0.get_dmi_facts() == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}


# Generated at 2022-06-24 22:24:22.423620
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    print('Testing get_uptime_facts')
    sun_o_s_hardware_0 = SunOSHardware(dict())
    print('', sun_o_s_hardware_0.get_uptime_facts(), sep='\n', end='\n\n')


# Generated at 2022-06-24 22:24:28.407189
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    # This test needs access to the sun_o_s_hardware_0.module, which is not
    # the same as the module returned by get_ansible_module(), so instead of
    # using run_commands() here, we just call the module directly.
    sun_o_s_hardware_0.module.run_command(['/usr/bin/uname', '-a'])
    sun_o_s_hardware_0.populate()
    assert True


# Generated at 2022-06-24 22:24:31.292212
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.get_memory_facts()


# Generated at 2022-06-24 22:24:38.496956
# Unit test for method get_memory_facts of class SunOSHardware

# Generated at 2022-06-24 22:24:42.113312
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    assert sun_o_s_hardware_collector_0._fact_class == SunOSHardware
    assert sun_o_s_hardware_collector_0._platform == 'SunOS'
    assert sun_o_s_hardware_collector_0.required_facts == set(['platform'])


# Generated at 2022-06-24 22:24:44.095550
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()



# Generated at 2022-06-24 22:24:49.974049
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    out = '''System Configuration: \tFujitsu \tSUN FIRE X4270 M2\n'''
    assert sun_o_s_hardware_0.get_dmi_facts().get('system_vendor') == 'Fujitsu'
    assert sun_o_s_hardware_0.get_dmi_facts().get('product_name') == 'SUN FIRE X4270 M2'


# Generated at 2022-06-24 22:24:52.447242
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    memory_facts = SunOSHardware().get_memory_facts()
    if memory_facts:
        print("Memory facts: ", memory_facts)


# Generated at 2022-06-24 22:24:53.903373
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:28:16.590350
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    sun_o_s_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:28:20.135880
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    # unset bool_0
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:28:23.265606
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_instance = SunOSHardware()
    output = sun_o_s_hardware_instance.get_memory_facts()
    assert type(output) == dict



# Generated at 2022-06-24 22:28:26.232750
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:28:28.762210
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_dmi_facts_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:28:31.071104
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:28:33.106387
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    sun_o_s_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:28:37.472597
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0._module = AnsibleModule(argument_spec={})
    sun_o_s_hardware_0._module.run_command = mock.Mock(return_value=(0, "unix:0:system_misc:boot_time 1548249689", ""))
    assert sun_o_s_hardware_0.get_uptime_facts() == {'uptime_seconds': 997}


# Generated at 2022-06-24 22:28:39.595592
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:28:44.480390
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return_value_0 = sun_o_s_hardware_0.get_uptime_facts()
