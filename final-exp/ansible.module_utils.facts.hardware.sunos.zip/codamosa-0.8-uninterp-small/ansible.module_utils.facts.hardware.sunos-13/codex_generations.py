

# Generated at 2022-06-24 22:19:38.368705
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    # Create an instance of class 'SunOSHardwareCollector'
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(b'\x00')

    # Delete a member of the class
    del(sun_o_s_hardware_collector_0)


# Generated at 2022-06-24 22:19:44.236415
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.populate()
    assert sun_o_s_hardware_0.memtotal_mb == 2
    assert sun_o_s_hardware_0.swap_reserved_mb == 1


# Generated at 2022-06-24 22:19:54.468199
# Unit test for method get_uptime_facts of class SunOSHardware

# Generated at 2022-06-24 22:20:04.897033
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-24 22:20:12.221305
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    hardware_0 = SunOSHardware()
    hardware_0.module.run_command_environ_update = {}
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()
    hardware_0.populate()


# Generated at 2022-06-24 22:20:23.381572
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    # Testing the memory facts produced by a Solaris 11.3 machine:
    # ansible_memtotal_mb: 7964
    # ansible_swapfree_mb: 2495
    # ansible_swaptotal_mb: 2559
    # ansible_swap_allocated_mb: 64
    # ansible_swap_reserved_mb: 64

    test_case_memory_facts = [
        b'',
        b'Memory size: 7963 Megabytes',
        b'',
        b'',
    ]


# Generated at 2022-06-24 22:20:30.699302
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'0O^\x03?p\xce\x03\xe4n\xc8F\xd4\xa0\xfa+|\xa2'
    bytes_1 = b'\xe7\xc3\x0c\xfb\x10\x9d\x8f\xa1\x1a\xe5\xf4\xf8\xd7\xfc\xbe\xeb\x04\x97\x18\xff\xf7\xbb\xce\xd1\x9b\x9b\x95\x8b\xcf\xfd\xc7'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    ansible_module_0 = AnsibleModuleStub()
    sun_o_s_hardware_

# Generated at 2022-06-24 22:20:40.921488
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'd\x1d\x7f\xe0\xbd\x9e\x8f\xef\x80\x97\x91G\x8c\xc1\x94\xe6\xfa\xda\x80\x0e\xea\xfb\x01\x14\x9c\x12\xb9\xf3\xc6\x19\x07\xa6\x1d\x19\x1b\xa2\x9e\x8a\xf4'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0, None)
    sun_o_s_hardware_0._module = Mock(run_command=Mock(return_value=(0, 'System Configuration: Oracle Corporation sun4v', '')))
    dict

# Generated at 2022-06-24 22:20:51.714609
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'j\x8a\x99\xd7\x04\xb3\xd3\x1b\x00\x00'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    bytes_1 = b'>\x9f\x8b\x86\xb0\x96\xf6\x1b\x00\x00\x00'
    sun_o_s_hardware_1 = SunOSHardware(bytes_1)
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor_cores': 'NA', 'processor_count': 1, 'processor': ['SUNW,UltraSPARC-IIi @ 666.67MHz']}
    assert sun_o_s_hardware_1.get_cpu_

# Generated at 2022-06-24 22:20:56.926653
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'0O^\x03?p\xce\x03\xe4n\xc8F\xd4\xa0\xfa+|\xa2'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    output = sun_o_s_hardware_0.get_uptime_facts()
    assert output == {}


# Generated at 2022-06-24 22:21:16.789421
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware('module')
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:18.865688
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    assert sun_o_s_hardware_0.get_memory_facts() is None


# Generated at 2022-06-24 22:21:22.101988
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:21:24.635114
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:29.654805
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    cpu_facts = sun_o_s_hardware_0.get_cpu_facts(sun_o_s_hardware_collector_0)
    assert isinstance(cpu_facts, dict)
    assert "processor" in cpu_facts
    assert "processor_count" in cpu_facts


# Generated at 2022-06-24 22:21:36.166574
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    rc, out, err = sun_o_s_hardware_0.module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    result = sun_o_s_hardware_0.get_uptime_facts()
    assert result['uptime_seconds'] == int(time.time() - int(out.split('\t')[1]))

# Generated at 2022-06-24 22:21:38.327935
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:21:39.720457
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_1 = SunOSHardware()

# Generated at 2022-06-24 22:21:41.431348
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    This test case checks the output of get_cpu_facts function of class SunOSHardware
    """
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.populate()

# Generated at 2022-06-24 22:21:43.477749
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()

    assert dmi_facts['product_name'] == 'Sun Fire V440'


# Generated at 2022-06-24 22:22:07.474223
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware(file_module=True)
    sun_o_s_hardware_0.module.params['gather_subset'] = ['dmi']
    sun_o_s_hardware_0.module.params['gather_timeout'] = 5


# Generated at 2022-06-24 22:22:15.078540
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    sun_o_s_hardware_0 = SunOSHardware(module=None)
    assert sun_o_s_hardware_collector_0._platform == 'SunOS'
    assert sun_o_s_hardware_collector_0._fact_class == sun_o_s_hardware_collector_0.get_fact_class()
    assert sun_o_s_hardware_collector_0._fact_class == sun_o_s_hardware_0.__class__


# Generated at 2022-06-24 22:22:18.398368
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    out = "\n"
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts(out = out)
    assert dmi_facts == None

#Unit test for method get_mount_facts of class SunOSHardware

# Generated at 2022-06-24 22:22:21.556438
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 22:22:23.507293
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    if not isinstance(sun_o_s_hardware_collector_0, SunOSHardwareCollector):
        raise AssertionError()


# Generated at 2022-06-24 22:22:33.523144
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0._module = mock_module()
    sun_o_s_hardware_0.sd = '/dev/sd'
    sun_o_s_hardware_0.vd = '/dev/vd'
    sun_o_s_hardware_0._run_command = mock_run_command()

# Generated at 2022-06-24 22:22:43.088576
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """Test that the uptime facts are available."""

    class DummyModule:
        class DummyRunCommand:
            def __call__(self, args, **kwargs):
                if 'kstat' in args:
                    return 0, 'unix:0:system_misc:boot_time 1548249689', ''
                return 0, '', ''

        run_command = DummyRunCommand()

    hardware = SunOSHardware(DummyModule)
    hardware_facts = hardware.populate()

    assert hardware_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-24 22:22:45.481727
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Setup
    sunos_hw = SunOSHardware(None)

    # Create the Mock class method
    sunos_hw.get_file_content = MagicMock(target=sunos_hw.get_file_content,
                                          returnvalue=1)

    # Execute the method
    sunos_hw.get_dmi_facts()

# Generated at 2022-06-24 22:22:47.985127
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    assert sun_o_s_hardware.get_device_facts() == {}


# Generated at 2022-06-24 22:22:50.078945
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert isinstance(sun_o_s_hardware_0.get_memory_facts(), dict)


# Generated at 2022-06-24 22:23:15.029245
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = mock.MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, 'System Configuration: VMware, Inc. VMware Virtual Platform', '')
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:19.670685
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=None)
    assert sun_o_s_hardware_0.get_dmi_facts() is None


# Generated at 2022-06-24 22:23:23.453022
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(
        module=None
    )
    sun_o_s_hardware_0.populate()

test_case_0()
test_SunOSHardware_populate()

# Generated at 2022-06-24 22:23:26.717644
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    try:
        sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    except:
        assert False, 'Could not create SunOSHardwareCollector.'
    else:
        assert True, 'Successfully created SunOSHardwareCollector.'



# Generated at 2022-06-24 22:23:37.243002
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_collector = SunOSHardwareCollector()
    sunos_hardware = SunOSHardware({'platform': 'SunOS', 'mounts': [{'options': 'rw', 'time': '-', 'device': '/dev/dsk/c0d0s0', 'mount': '/', 'fstype': 'zfs'}, {'options': 'rw', 'time': '-', 'device': 'swap', 'mount': 'swap', 'fstype': 'swap'}, {'options': 'rw', 'time': '-', 'device': '/dev/dsk/c0d1s0', 'mount': '/var', 'fstype': 'ufs'}]})
    assert isinstance(sunos_hardware.get_uptime_facts(), dict)


# Generated at 2022-06-24 22:23:43.562512
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor': ['sparcv9 @ 1000MHz'], 'processor_count': 1, 'processor_cores': 1}


# Generated at 2022-06-24 22:23:46.687623
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    data_0 = sun_o_s_hardware_0.get_device_facts()
    assert data_0 == {}


# Generated at 2022-06-24 22:23:50.054714
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_memory_facts() == sun_o_s_hardware_0.memory_facts


# Generated at 2022-06-24 22:23:53.896867
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:56.136171
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:24:46.254706
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    ansible_facts = {'ansible_memtotal_mb': 33}
    assert sun_o_s_hardware_0.get_memory_facts(ansible_facts) == {'memtotal_mb': 33}

# Generated at 2022-06-24 22:24:47.991112
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:24:50.518944
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    uptime_facts_dict = SunOSHardware.get_uptime_facts(None)
    assert uptime_facts_dict == {
        'uptime_seconds': int(time.time())
        }

# Generated at 2022-06-24 22:24:55.219582
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Test method get_memory_facts of class SunOSHardware
    This method is used to get the memory information of system
    """

    # Create a new instance of SunOSHardware class
    sun_o_s_hardware_0 = SunOSHardware()

    # Call the method get_memory_facts of class SunOSHardware
    sun_o_s_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:24:57.104920
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:25:02.515142
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    get_file_content_0 = get_file_content('/etc/mnttab')
    sun_o_s_hardware_0.get_mount_facts = get_mount_size()
    setattr(sun_o_s_hardware_0, 'module', MockModule())
    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:25:07.649621
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    SunOSHardware_cpu_facts = SunOSHardware(GetCPUFacts={}).get_cpu_facts()
    assert "processor" in SunOSHardware_cpu_facts
    assert "processor_count" in SunOSHardware_cpu_facts
    assert "processor_cores" in SunOSHardware_cpu_facts


# Generated at 2022-06-24 22:25:10.827667
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:12.324808
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    result = SunOSHardware().get_memory_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:25:19.505275
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware('ansible.module_utils.facts.hardware.sunos.run_command')

    # get_cpu_facts() is tested by test_SunOSHardwareCollector_populate(), so patched version
    # of it returns a fixed list of facts.
    def mock_get_cpu_facts(self):
        return {'processor': ['Intel(R) Core(TM) i5-3470 CPU @ 3.20GHz']}

    sun_o_s_hardware_0.get_cpu_facts = mock_get_cpu_facts.__get__(sun_o_s_hardware_0)

    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:27:20.453335
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware({}) # instantiate class
    if True: # replace with a valid test
        sun_o_s_hardware_0.get_memory_facts() # execute the method


# Generated at 2022-06-24 22:27:30.492846
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.module = AnsibleModuleMock()
    sun_o_s_hardware.module.run_command = MagicMock('run_command')
    sun_o_s_hardware.module.run_command.side_effect = [
        (0, "System Configuration: Oracle Corporation sun4v\n", ""),
        (0, "System Configuration: Oracle Corporation sun4v\n", ""),
    ]

    assert sun_o_s_hardware.get_dmi_facts() == {'system_vendor': 'Oracle Corporation', 'product_name': 'sun4v'}

# Generated at 2022-06-24 22:27:32.890379
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_device_facts()
    assert not result
    assert sun_o_s_hardware_0.get_device_facts() is not None


# Generated at 2022-06-24 22:27:39.634390
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """Test a method ``get_device_facts`` of class ``SunOSHardware``.

    This test case is intended to backup the functionality of a method
    ``get_device_facts`` of class ``SunOSHardware`` and to keep track of it
    in case of future refactoring.
    """
    sun_o_s_hardware = SunOSHardware()

    # check return values of the method ``get_device_facts``
    device_facts = sun_o_s_hardware.get_device_facts()

    # check if the keys of return value ``device_facts`` are correct
    assert 'devices' in device_facts

    # check if the values of keys 'devices' of return value ``device_facts``
    # are correct
    assert type(device_facts['devices']) == dict

    # check if the size of return value ``device

# Generated at 2022-06-24 22:27:42.845660
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:44.739992
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:47.218793
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    # TypeError: 'expect_error' should be a Boolean.
    # sun_o_s_hardware_0.get_device_facts(expect_error=True)



# Generated at 2022-06-24 22:27:52.928649
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModuleMock(platform = 'SunOS', command = 'uname -a')
    sun_o_s_hardware_0.module.run_command = run_command_mock

    assert(sun_o_s_hardware_0.get_uptime_facts()) == {'uptime_seconds': 1000}


# Generated at 2022-06-24 22:27:58.098992
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_memory_facts() == {'swapfree_mb': 819, 'swaptotal_mb': 819, 'memtotal_mb': 4096, 'swap_reserved_mb': 819, 'swap_allocated_mb': 819}


# Generated at 2022-06-24 22:28:04.765391
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
  sun_o_s_hardware_0 = SunOSHardware()
  sun_o_s_hardware_0.populate()
  sun_o_s_hardware_0.OS_FAMILY = "SunOS"
  sun_o_s_hardware_0.module =  MagicMock()
  sun_o_s_hardware_0.module.run_command.return_value = (0, "    Memory size: 8192 Megabytes", "")
  sun_o_s_hardware_0.get_memory_facts()
  pass
