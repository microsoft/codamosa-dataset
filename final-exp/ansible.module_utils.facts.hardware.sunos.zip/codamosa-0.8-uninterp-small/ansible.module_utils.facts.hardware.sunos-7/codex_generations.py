

# Generated at 2022-06-24 22:19:33.042970
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    assert sun_o_s_hardware.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 22:19:41.590964
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware({})
    assert sun_o_s_hardware_0.populate() == {
        'swap_allocated_mb': 'NA',
        'swap_reserved_mb': 'NA',
        'processor_cores': 'NA',
        'memtotal_mb': 'NA',
        'swapfree_mb': 'NA',
        'swaptotal_mb': 'NA',
        'processor_count': 'NA',
        'processor': 'NA'
    }


# Generated at 2022-06-24 22:19:46.212546
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    get_cpu_facts test case.
    """
    sun_o_s_hardware_0 = SunOSHardware() # SunOSHardware()
    assert sun_o_s_hardware_0.get_cpu_facts() == {}


# Generated at 2022-06-24 22:19:48.504382
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.get_uptime_facts()



# Generated at 2022-06-24 22:19:52.144656
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
        sun_o_s_hardware_0 = SunOSHardware()
        return sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:19:56.019236
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Testing method populate() of class SunOSHardware
    sun_o_s_hardware_obj = SunOSHardware()
    collected_facts = {}
    collected_facts['platform'] = 'SunOS'
    sun_o_s_hardware_obj.populate(collected_facts)


# Generated at 2022-06-24 22:19:58.906974
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:01.818448
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_uptime_facts() is None


# Generated at 2022-06-24 22:20:09.731250
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware = SunOSHardware()
    d = {}
    d['devices'] = {}

    rc, out, err = sun_o_s_hardware.module.run_command("/usr/bin/kstat -p sderr:0:sd0::vendor")
    if rc != 0:
        return
    d['devices']['sd0'] = {}
    d['devices']['sd0']['vendor'] = out.split('\t')[1].rstrip()

    assert sun_o_s_hardware.get_device_facts() == d


# Generated at 2022-06-24 22:20:19.638432
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = [0, 'unix:0:system_misc:boot_time\t1548249689', '']
    sun_o_s_hardware_0.module.run_command.assert_called_with('/usr/bin/kstat -p unix:0:system_misc:boot_time')
    assert sun_o_s_hardware_0.get_uptime_facts() == {'uptime_seconds': 1548250162}


# Generated at 2022-06-24 22:20:38.773998
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware = SunOSHardware()
    res = sun_o_s_hardware.populate()
    assert True



# Generated at 2022-06-24 22:20:41.201712
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    test = sun_o_s_hardware_0.get_memory_facts()

    assert test is not None
    assert test.get('memtotal_mb') is not None


# Generated at 2022-06-24 22:20:45.246955
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:54.026900
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware = SunOSHardware(module=None)
    rc, out, err = sun_o_s_hardware.module.run_command('/usr/bin/uname -i')
    platform_sbin = '/usr/platform/' + out.rstrip() + '/sbin'
    prtdiag_path = sun_o_s_hardware.module.get_bin_path("prtdiag", opt_dirs=[platform_sbin])
    rc, out, err = sun_o_s_hardware.module.run_command(prtdiag_path)
    """
    rc returns 1
    """
    if out:
        system_conf = out.split('\n')[0]

        # If you know of any other manufacturers whose names appear in
        # the first line of

# Generated at 2022-06-24 22:20:58.635091
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # Arrange
    sun_o_s_hardware_0 = SunOSHardware()

    # Command output from kstat
    sun_o_s_hardware_0.module.run_command = lambda _: (0, "", "")

    # Act
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    result = sun_o_s_hardware_0.get_dmi_facts()

    # Assert
    assert result == {}, "Expected %s, but got %s" % ({}, result)



# Generated at 2022-06-24 22:21:07.019337
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:21:09.302362
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    assert sun_o_s_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:21:11.335978
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_dmi_facts() is not False


# Generated at 2022-06-24 22:21:19.375365
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModuleStub()
    sun_o_s_hardware_0.module.run_command.return_value = (0, '...', '')
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    sun_o_s_hardware_0.module.get_bin_path.side_effect = lambda x: x
    sun_o_s_hardware_0.module.get_file_content = lambda x: ''
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware

# Generated at 2022-06-24 22:21:24.502020
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    sun_o_s_hardware_0 = SunOSHardware(sun_o_s_hardware_collector_0)
    result = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:08.292569
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    Host = SunOSHardware()

    # Default values

# Generated at 2022-06-24 22:22:12.988124
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    a = SunOSHardware(dict())
    a.module = mock.MagicMock()
    class Args():
        pass
    args = Args()
    a.module.run_command = mock.MagicMock(return_value=(0, 'test', ''))
    a.get_dmi_facts()


# Generated at 2022-06-24 22:22:15.812437
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_dmi_facts()
    assert result is not None


# Generated at 2022-06-24 22:22:17.858994
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return str(sun_o_s_hardware_0.get_dmi_facts())


# Generated at 2022-06-24 22:22:21.066859
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_1 = SunOSHardwareCollector()
    assert isinstance(sun_o_s_hardware_collector_1, SunOSHardwareCollector)


# Generated at 2022-06-24 22:22:26.232162
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    hardware = SunOSHardware()

    hardware.module.run_command = Mock(return_value=(0,
                                                     """Memory size: 16384 Megabytes
""",
                                                     ''))
    hardware.module.run_command = Mock(return_value=(0,
                                                     """ total: 515552K bytes allocated + 294716K reserved = 810268K used, 61576K available
""",
                                                     ''))
    hardware.get_memory_facts()


# Generated at 2022-06-24 22:22:27.762148
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()




# Generated at 2022-06-24 22:22:30.722042
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:36.669160
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    """
    Test get_uptime_facts of class SunOSHardware. Note that this method
    relies on kstat and will only run correctly on Solaris systems
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0,
                                                                    'unix:0:system_misc:boot_time    1548249689',
                                                                    ''))
    sun_o_s_hardware_0.get_uptime_facts()

    # Test that uptime = $current_time - $boot_time

# Generated at 2022-06-24 22:22:42.425090
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector = SunOSHardwareCollector()
    assert sun_o_s_hardware_collector._platform == 'SunOS'
    assert sun_o_s_hardware_collector._fact_class == SunOSHardware
    assert sun_o_s_hardware_collector.required_facts == set(['platform'])


# Generated at 2022-06-24 22:23:55.639953
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.module.run_command = lambda args, check_rc=True: (0, "sderr:::Size    53687091200", None)
    sun_o_s_hardware.get_memory_facts()


# Generated at 2022-06-24 22:23:59.335332
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    if sun_o_s_hardware_0.get_memory_facts():
        sun_o_s_hardware_0.get_memory_facts()
        print("Test case passed")
    else:
        print("Test case failed")


# Generated at 2022-06-24 22:24:00.935603
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:24:07.572484
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    with mock.patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.hardware.sunos.time.time', return_value='time'):
        uptime_facts_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert uptime_facts_0 == {}


# Generated at 2022-06-24 22:24:13.529767
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_collector_1 = SunOSHardwareCollector()
    sun_o_s_hardware_0 = SunOSHardware(sun_o_s_hardware_collector_1)
    sun_o_s_hardware_0.populate()

if __name__ == '__main__':
    # Unit tests for all methods in SunOSHardware
    test_case_0()
    test_SunOSHardware_populate()

# Generated at 2022-06-24 22:24:15.884682
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    test1 = SunOSHardware()
    test1.module = AnsibleModuleMock()
    result = test1.get_device_facts()

    assert result['devices'].keys() == ['sd0']


# Generated at 2022-06-24 22:24:24.189988
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    rc, out, err = sun_o_s_hardware_0.module.run_command('/usr/bin/kstat -p unix:0:system_misc:boot_time')

    if rc != 0:
        return

    # uptime = $current_time - $boot_time
    sun_o_s_hardware_0.fact_dict['uptime_seconds'] = int(time.time() - int(out.split('\t')[1]))


# Generated at 2022-06-24 22:24:28.106380
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'swap_reserved_mb': 0, 'swap_allocated_mb': 0}


# Generated at 2022-06-24 22:24:33.227791
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    sun_o_s_hardware_0.populate()

    sun_o_s_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:24:35.698144
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:27:40.559528
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:27:46.457307
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Setup test parameters
    current_time = int(time.time())
    rc = 0
    out = str(current_time)
    err = ''
    # Setup the test object
    sun_os_hardware_obj = SunOSHardware()
    sun_os_hardware_obj.module.run_command = Mock(return_value=(rc, out, err))
    # run the method under test
    result = sun_os_hardware_obj.get_uptime_facts()
    # The result should be a dict with a key 'uptime_seconds' and its value being
    # the current uptime in seconds
    assert result == {'uptime_seconds': current_time}



# Generated at 2022-06-24 22:27:49.608838
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.populate()


if __name__ == '__main__':
    test_SunOSHardware_populate()

# Generated at 2022-06-24 22:27:53.594197
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    # unittest.TestCase.assertRaises(sun_o_s_hardware, RuntimeError)
#    with self.assertRaises(RuntimeError):
#        sun_o_s_hardware.get_uptime_facts()



# Generated at 2022-06-24 22:27:56.685699
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    return_value = sun_o_s_hardware_0.get_uptime_facts()
    assert return_value is not None


# Generated at 2022-06-24 22:27:59.103730
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert {} == sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:28:03.807570
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    sun_o_s_hardware_collector_0.collect()

    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:28:04.976080
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:28:07.413389
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    instance = SunOSHardware()
    output = instance.get_cpu_facts()
    assert output['processor_count'] == 2
    assert output['processor_cores'] == 4


# Generated at 2022-06-24 22:28:12.494662
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    uptime_facts = sun_o_s_hardware_0.get_uptime_facts()
    if not isinstance(uptime_facts, dict):
        print("Failure, expected an instance of the <class 'dict'> in method get_uptime_facts, got: %s" % type(uptime_facts))

