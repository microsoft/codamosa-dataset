

# Generated at 2022-06-24 22:19:37.881132
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:19:41.304289
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:19:43.639667
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Test with required arguments only.
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:19:54.440136
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_os_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:19:57.972502
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_result_1 = SunOSHardware.get_cpu_facts()
    cpu_result_2 = SunOSHardware.get_cpu_facts()
    cpu_result_3 = SunOSHardware.get_cpu_facts()
    return


# Generated at 2022-06-24 22:20:00.921838
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:20:02.724864
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:03.126449
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    pass

# Generated at 2022-06-24 22:20:06.498194
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware({})
    if not isinstance(sun_o_s_hardware_0, SunOSHardware):
        raise Error('Failed to create test subject')

    # Call method
    actual_return = sun_o_s_hardware_0.get_cpu_facts()
    expected_return = {}

    assert actual_return == expected_return, 'get_cpu_facts() does not return {}'.format(expected_return)


# Generated at 2022-06-24 22:20:13.993876
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sunos_hardware_obj = SunOSHardware()
    memory_facts = sunos_hardware_obj.get_memory_facts()

    assert memory_facts['memtotal_mb'] > -1
    assert memory_facts['swaptotal_mb'] > -1
    assert memory_facts['swapfree_mb'] > -1
    assert memory_facts['swap_reserved_mb'] > -1
    assert memory_facts['swap_allocated_mb'] > -1


# Generated at 2022-06-24 22:20:36.759700
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    str_0 = '%O^r,3>|8<Nx5'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert len(var_0) == 4


# Generated at 2022-06-24 22:20:39.932496
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware('L@XgRf#G{h1<QH!')
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:43.528207
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:48.891329
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    str_0 = 'lRP,_%G<Pw9(F,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts('rlF}k')


# Generated at 2022-06-24 22:20:51.844365
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware('c')
    assert sun_o_s_hardware_0.get_device_facts() == None


# Generated at 2022-06-24 22:20:52.917362
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:20:55.795127
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert var_0 == None


# Generated at 2022-06-24 22:20:57.418962
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware('!lRP,_%G<Pw9(F,')
    assert False


# Generated at 2022-06-24 22:21:06.027018
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    str_0 = '#T|(r_jk2'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts = lambda : 'lJ"Ng(N'
    sun_o_s_hardware_0.get_memory_facts = lambda : ']A,PS(z'
    sun_o_s_hardware_0.get_dmi_facts = lambda : '9Z1xn]A'
    sun_o_s_hardware_0.get_device_facts = lambda : 'L(F4ez'

# Generated at 2022-06-24 22:21:09.310744
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '3q5Brx*+$?v=8Gzf%'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:21:46.236031
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:49.003245
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware('!lRP,_%G<Pw9(F,')
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:53.058505
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware('str_0')
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:57.298944
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert len(var_0) == 7


# Generated at 2022-06-24 22:22:03.672087
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware('74U6;]Ug')
    sun_o_s_hardware_0.populate_from_facts({'ansible_machine': 'i86pc'})
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:07.654510
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware('!lRP,_%G<Pw9(F,')
    result = sun_o_s_hardware_0.get_cpu_facts()
    assert result == None


# Generated at 2022-06-24 22:22:12.609366
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_0 = SunOSHardware('>Q{@!}+XV')
    var_1 = var_0.get_memory_facts()

if __name__ == "__main__":
    print(time.time())
    print("test_case_0")
    test_case_0()
    print("test_SunOSHardware_get_memory_facts")
    test_SunOSHardware_get_memory_facts()

# Generated at 2022-06-24 22:22:15.842044
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware('!lRP,_%G<Pw9(F,')
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:22:22.058533
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    str_0 = '!lRP,_%G<Pw9(F,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:22:24.507269
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    sunos_hardware_0 = SunOSHardware('9XXleD$NCUZ^f[6')
    var_0 = sunos_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:37.778103
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware('N<#c%N(4b4>|')
    try:
        sun_o_s_hardware_0.get_uptime_facts()
    except Exception as inst:
        assert inst.args[0] == "'get_uptime_facts' is not yet implemented"

# Generated at 2022-06-24 22:23:39.776714
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:42.489197
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    sun_o_s_hardware_0 = SunOSHardware(module_0)
    # Call the method
    var_1 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:53.593922
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    # Case 0
    sun_o_s_hardware_0.get_cpu_facts()
    sun_o_s_hardware_0.get_dmi_facts()
    sun_o_s_hardware_0.get_device_facts()
    sun_o_s_hardware_0.get_mount_facts()
    sun_o_s_hardware_0.platform = 'SunOS'
    sun_o_s_hardware_0.get_memory_facts()
    sun_o_s_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:23:56.219596
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Test with no arguments

    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:58.352717
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    var_0 = sun_o_s_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:24:00.040665
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:24:02.947856
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_1 = SunOSHardware('Avuq7CcJ')
    var_1 = sun_o_s_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:24:07.348709
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware('n`FZ"w%c"HH')
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:24:10.603293
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware('o=]?NOp9|qv')
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:33.686526
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware('7r79^9%u5k0#Q')
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:27:34.368366
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:27:37.654771
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    str_0 = '=T*T<'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:27:41.028905
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    str_0 = 'G.Ruk/s$2F[Z/_.q'
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(None, None, False, False, False, str_0, 'ansible_system_vendor', '/:z{mF?NVwEc5u5>HT,')


# Generated at 2022-06-24 22:27:43.484347
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware('@8aR(u&7>Q%c;n')
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:27:44.803225
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():

    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()


# Generated at 2022-06-24 22:27:50.247799
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware('name')
    # Set up mock
    # set up call args
    str_0 = 'name'
    # set up return values
    tuple_0 = (0, '', '')
    mock_run_command = mocker.patch('ansible.module_utils.facts.hardware.sunos.run_command', return_value=tuple_0)
    # execute function
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    # validate return values
    assert var_0 == {}
    # validate calls to mock
    mock_run_command.assert_called_with(('/usr/sbin/prtconf',), False, None, None)


# Generated at 2022-06-24 22:27:52.893532
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware('Yf.,$M')
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:58.365081
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()
    assert not hasattr(sun_o_s_hardware_collector_0, 'platform')
    assert not hasattr(sun_o_s_hardware_collector_0, '_fact_class')
    assert not hasattr(sun_o_s_hardware_collector_0, 'required_facts')


# Generated at 2022-06-24 22:28:01.960817
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = '!lRP,_%G<Pw9(F,'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()
