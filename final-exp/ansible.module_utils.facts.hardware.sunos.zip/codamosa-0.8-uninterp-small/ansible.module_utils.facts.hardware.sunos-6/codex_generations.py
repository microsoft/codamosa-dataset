

# Generated at 2022-06-24 22:19:38.665528
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_hardware_0.get_uptime_facts()
    sun_o_s_hardware_0.module.run_command.assert_called_once_with(['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time'])

# Generated at 2022-06-24 22:19:44.524325
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.populate({})
    SunOSHardware.get_dmi_facts(sun_o_s_hardware_0)


# Generated at 2022-06-24 22:19:55.680190
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.module = mock.MagicMock()

# Generated at 2022-06-24 22:19:59.432453
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:20:03.067113
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:20:04.348957
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    device_facts_0 = SunOSHardware.get_device_facts()

# Generated at 2022-06-24 22:20:08.796165
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:20:13.390438
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    collected_facts_0 = {}
    sun_o_s_hardware_0.get_cpu_facts(collected_facts_0)


# Generated at 2022-06-24 22:20:17.846949
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    SunOSHardware_test_obj = SunOSHardware(
       bytes_0 = b'@\\^\xf4g')
    SunOSHardware_test_obj.get_device_facts()
    assert SunOSHardware_test_obj.get_device_facts == None


# Generated at 2022-06-24 22:20:27.401902
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bytes_0 = b'@\\^\xf4g'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    collected_facts = {}
    sun_o_s_hardware_0.module = mock.MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, "", "")
    sun_o_s_hardware_0.get_cpu_facts.return_value = {}
    sun_o_s_hardware_0.get_memory_facts.return_value = {}
    sun_o_s_hardware_0.get_dmi_facts.return_value = {}
    sun_o_s_hardware_0.get_device_facts.return_value = {}
    sun_o_s_

# Generated at 2022-06-24 22:21:18.795115
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:21:25.516142
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, 'System Configuration: VMware, Inc.  VMware Virtual Platform', '')
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:30.643399
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    with open('/tmp/ansible_SunOS_get_cpu_facts_result', 'r') as ansible_result:
        ansible_result_json = json.load(ansible_result)
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_get_cpu_facts_result = sun_o_s_hardware_0.get_cpu_facts()
    assert ansible_result_json == sun_o_s_hardware_get_cpu_facts_result


# Generated at 2022-06-24 22:21:39.885773
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    rc, out, err = sun_o_s_hardware_0.module.run_command('/usr/bin/uname -i')
    platform_sbin = '/usr/platform/' + out.rstrip() + '/sbin'
    prtdiag_path = sun_o_s_hardware_0.module.get_bin_path("prtdiag", opt_dirs=[platform_sbin])
    rc, out, err = sun_o_s_hardware_0.module.run_command(prtdiag_path)
    # FIXME
    prt_diag_out = out.split('\n')[0]
    prt_diag_out
    dmi_facts = sun_o_s_hardware

# Generated at 2022-06-24 22:21:41.994323
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    sun_o_s_hardware_populate_0 = SunOSHardware()
    sun_o_s_hardware_populate_0.populate()


# Generated at 2022-06-24 22:21:47.899391
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    ansible_facts = dict(
        ansible_processor_cores='NA',
        ansible_processor_count=4
    )
    sun_o_s_hardware_0.populate(ansible_facts=ansible_facts)


# Generated at 2022-06-24 22:21:50.384428
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_memory_facts() == {}

# Generated at 2022-06-24 22:21:55.116231
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_get_dmi_facts()

# Generated at 2022-06-24 22:21:58.461453
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    # Return memtotal_mb and swap_allocated_mb in GiB
    sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:05.306168
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    sun_o_s_hardware_0.module.params = dict()

    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:05.628295
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    memtotal_mb, memfree_mb = sun_o_s_hardware_0.get_memory_facts()
    assert isinstance(memtotal_mb, int) and isinstance(memfree_mb, int)


# Generated at 2022-06-24 22:23:07.439278
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sunos_hardware_obj = SunOSHardware()
    assert sunos_hardware_obj.get_dmi_facts() == {}


# Generated at 2022-06-24 22:23:10.469498
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    ))

    # Call method
    result = sun_o_s_hardware_0.get_cpu_facts()

    assert isinstance(result, dict)


# Generated at 2022-06-24 22:23:11.752874
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    hardware_obj = SunOSHardware()
    assert hardware_obj.get_uptime_facts() == None



# Generated at 2022-06-24 22:23:15.022920
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware = SunOSHardware()
    out_mock = 'unix:0:system_misc:boot_time    1548249689'
    sun_o_s_hardware.module.run_command.return_value = 0, out_mock, ''
    sun_o_s_hardware.get_uptime_facts()


# Generated at 2022-06-24 22:23:25.621852
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    mock1_str = sun_o_s_hardware_0.run_command('/usr/sbin/prtconf')[1]
    mock1_str += 'Memory size:  2031680 Kbytes'

    def run_command(*args, **kwargs):
        return 0, mock1_str, ''

    with mock.patch.object(sun_o_s_hardware_0.module, 'run_command', autospec=True, side_effect=run_command) as mocked_method:
        sun_o_s_hardware_0.get_memory_facts()
        assert mocked_method.call_count == 1


# Generated at 2022-06-24 22:23:27.633395
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(dict(module=('/usr/bin/env', 'python', '2.7', '-u')))
    # FIXME: test populate
    # assert sun_o_s_hardware_0


# Generated at 2022-06-24 22:23:36.513984
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    sun_o_s_hardware_0 = SunOSHardware(module)

    # Test 1:
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'System Configuration: SUNW,Sun-Fire-V240', ''))
    sun_o_s_hardware_0.get_dmi_facts()

    # Test 2:
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'System Configuration: SUNWxyz', ''))
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:38.837615
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:43.399876
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    sun_o_s_hardware.get_cpu_facts()



# Generated at 2022-06-24 22:26:16.615681
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:26:18.747192
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    SunOSHardware_0 = SunOSHardware(None)
    SunOSHardware_0.module = None
    assert type(SunOSHardware_0.get_cpu_facts()) is dict


# Generated at 2022-06-24 22:26:24.160667
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

# Generated at 2022-06-24 22:26:30.879142
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware = SunOSHardware({})
    sun_o_s_hardware_populate_expected_output = {
        "uptime_seconds": "FAKE_ANSIBLE_TEST_VARIABLE"
    }
    sun_o_s_hardware.get_uptime_facts = lambda: sun_o_s_hardware_populate_expected_output

# Generated at 2022-06-24 22:26:32.616363
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:26:40.739487
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-24 22:26:43.391235
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.platform == 'SunOS'


# Generated at 2022-06-24 22:26:45.714053
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    sun_o_s_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:26:55.961577
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModule(argument_spec={})

    # (1) Return when out is empty
    set_module_args(dict(ansible_facts={}))
    with pm():
        sun_o_s_hardware_0.get_dmi_facts()

    # (2) Return when out is not empty
    sun_o_s_hardware_0.module.run_command.return_value = (0, 'System Configuration: Linux Ubuntu 12.04 LTS', '')
    set_module_args(dict(ansible_facts={}))
    with pm():
        sun_o_s_hardware_0.get_dmi_facts()

    # (3) Return when out is not empty

# Generated at 2022-06-24 22:26:59.451496
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = None
    sun_o_s_hardware_0.get_uptime_facts()