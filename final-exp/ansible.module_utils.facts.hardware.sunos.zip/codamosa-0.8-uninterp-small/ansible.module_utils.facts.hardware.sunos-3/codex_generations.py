

# Generated at 2022-06-24 22:19:37.255790
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # Input parameters testing

    # Execution testing
    sun_o_s_hardware_0 = SunOSHardware(None)
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:19:47.408072
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = '3qMDA7V9F'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    str_1 = 'GJ\x6c%g'
    sun_o_s_hardware_0.module = str_1
    str_2 = '9\x5c'
    sun_o_s_hardware_0.module.run_command = str_2
    value_0 = sun_o_s_hardware_0.get_device_facts()
    str_3 = 'Pws@'
    assert value_0[str_3] == {}


# Generated at 2022-06-24 22:19:51.530209
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'I\xc3\x0cp\x14'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    result_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert result_0 == None



# Generated at 2022-06-24 22:19:54.904208
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'v\x06F#Q'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    value = sun_o_s_hardware_0.get_uptime_facts()
    assert value != None


# Generated at 2022-06-24 22:19:59.433998
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'V@g\x0c_#j'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    collected_facts = {}
    sun_o_s_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:20:00.949494
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():

    str_0 = '3q'
    sun_o_s_hardware_0 = SunOSHardware(str_0)

    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:20:03.693801
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = ''
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    method_ret_val_0 = sun_o_s_hardware_0.get_uptime_facts()
    assert method_ret_val_0

# Generated at 2022-06-24 22:20:10.036137
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'V@g\x0c_#j'
    collected_facts_0 = {'ansible_machine': 'i86pc'}
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.collect()
    sun_o_s_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:20:12.757811
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector()

if __name__ == '__main__':
    test_case_0()
    test_SunOSHardwareCollector()

# Generated at 2022-06-24 22:20:23.905675
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # Input parameters used for testing
    collected_facts = {'ansible_machine': 'i86pc'}
    sun_o_s_hardware_0 = SunOSHardware(collected_facts=collected_facts)
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C'}
    sun_o_s_hardware_0.module.run_command = lambda *args, **kwargs: (1, 'V@g\x0c_#j', '')
    sun_o_s_hardware_0.module.get_bin_path = lambda *args, **kwargs: '/usr/bin/prtconf'

# Generated at 2022-06-24 22:20:49.206205
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    fake_cpu_facts = "fake_cpu_facts"
    sun_os_hardware_0 = SunOSHardware()
    sun_os_hardware_0._facts = {'ansible_machine': 'i86pc'}
    sun_os_hardware_0.module = FakeModule()
    sun_os_hardware_0.module.run_command = lambda x: (0, "", "")
    if sun_os_hardware_0.get_cpu_facts() != fake_cpu_facts:
        raise AssertionError("Wrong cpu facts")


# Generated at 2022-06-24 22:20:51.732287
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    random = SunOSHardware({})
    output = random.get_memory_facts()
    assert (isinstance(output, dict))


# Generated at 2022-06-24 22:20:58.049666
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = ansible_module_0
    # Test using a mocked module
    sun_o_s_hardware_0.get_uptime_facts()
    # Test using a real module
    sun_o_s_hardware_0.module = ansible_module_1
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:21:06.553719
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()

# Generated at 2022-06-24 22:21:11.472690
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Test with a mocked module
    sun_o_s_hardware_0_dmi_facts = sun_o_s_hardware_0.get_dmi_facts()

    assert sun_o_s_hardware_0_dmi_facts['system_vendor'] is not None
    assert sun_o_s_hardware_0_dmi_facts['product_name'] is not None


# Generated at 2022-06-24 22:21:12.912484
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:15.534910
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_uptime_facts() is not False


# Generated at 2022-06-24 22:21:16.449377
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware({})

# Generated at 2022-06-24 22:21:18.577610
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.populate() is None


# Generated at 2022-06-24 22:21:21.125053
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    sun_o_s_hardware_collector = SunOSHardwareCollector()


# Generated at 2022-06-24 22:21:45.041948
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=ansible_module_0)
    sun_o_s_hardware_0._executable = {'prtdiag': {'path': '/usr/sbin/prtdiag'}}
    ansible_module_0.run_command = MagicMock(return_value=(rc_mock, out_mock, err_mock))
    assert sun_o_s_hardware_0.get_dmi_facts() == dmi_facts_mock
    ansible_module_0.run_command.assert_called_with(['/usr/sbin/prtdiag'])


# Generated at 2022-06-24 22:21:49.748486
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:52.537884
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()


# Generated at 2022-06-24 22:21:59.293819
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    """
    check if disk size is properly converted from 'bytes' to 'human'
    """

    sun_o_s_hardware_0 = SunOSHardware(None)
    # check if the disk size is converted from 'bytes' to 'human'
    # NOTE: Size    53687091200
    assert sun_o_s_hardware_0.get_device_facts()['devices']['sd0']['size'] == '50.0GB'



# Generated at 2022-06-24 22:22:02.984259
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    if not sun_o_s_hardware_collector_0:
        raise Exception("Failed to instantiate SunOSHardwareCollector")



# Generated at 2022-06-24 22:22:09.415329
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware = SunOSHardware()
    system_conf = 'System Configuration: Sun Microsystems sun4v'
    dmi_facts = sun_o_s_hardware.get_dmi_facts(system_conf)
    if dmi_facts != {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}:
        raise AssertionError()


# Generated at 2022-06-24 22:22:13.270508
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    if True:
        str = 'SunOSHardware()'
        val = sun_o_s_hardware_0.get_dmi_facts()
        assert val == {}


# Generated at 2022-06-24 22:22:20.374495
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    sun_o_s_hardware_0 = SunOSHardware()
    rc, out, err = sun_o_s_hardware_0.module.run_command('/usr/bin/uname -i')
    platform_sbin = '/usr/platform/' + out.rstrip() + '/sbin'
    prtdiag_path = sun_o_s_hardware_0.module.get_bin_path("prtdiag", opt_dirs=[platform_sbin])
    rc, out, err = sun_o_s_hardware_0.module.run_command(prtdiag_path)
    """
    rc returns 1
    """
    if out:
        system_conf = out.split('\n')[0]

        # If you know of any other manufacturers whose names appear in the
       

# Generated at 2022-06-24 22:22:22.765763
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=None)
    assert sun_o_s_hardware_0.get_dmi_facts() is None


# Generated at 2022-06-24 22:22:30.582279
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """Test SunOSHardware.get_memory_facts()"""

# Generated at 2022-06-24 22:22:54.266846
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = lambda x: (0, 'unix:0:system_misc:boot_time    1548249689', '')

    a = sun_o_s_hardware_0.get_uptime_facts()

    assert a['uptime_seconds'] == 1548256328


# Generated at 2022-06-24 22:22:55.288613
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    pass


# Generated at 2022-06-24 22:23:00.787692
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_os_hardware = SunOSHardware()
    sun_os_hardware.module.run_command = mock.MagicMock(return_value=(0, 'Solaris', ''))
    sun_os_hardware.module.get_bin_path = mock.MagicMock(return_value='/usr/bin')
    sun_os_hardware.module.run_command = mock.MagicMock(return_value=(0, 'System Configuration: sun4v SPARC T4-2 Server\nOBP 4.33 2010/08/30 20:00\nOpenBoot 4.33', ''))
    retval = sun_os_hardware.get_dmi_facts()
    assert retval['system_vendor'] == 'sun4v'
    assert retval['product_name'] == 'SPARC T4-2 Server'

# Generated at 2022-06-24 22:23:09.212942
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = MagicMock()

    kstat_cmd = '/usr/sbin/prtconf'
    sun_o_s_hardware_0.module.get_bin_path.return_value = kstat_cmd
    sun_o_s_hardware_0.module.run_command.return_value = (0, "System Configuration: Sun Microsystems sun4v", "")
    assert sun_o_s_hardware_0.get_dmi_facts() == {'product_name': 'sun4v', 'system_vendor': 'Sun Microsystems'}


# Generated at 2022-06-24 22:23:12.255354
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Test exception raise by run_command method
    sun_o_s_hardware_0.run_command = Exception()

    with pytest.raises(Exception):
        sun_o_s_hardware_0.get_device_facts()



# Generated at 2022-06-24 22:23:13.919701
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:15.968269
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = dict()

    # Call method
    result = sun_o_s_hardware_0.get_cpu_facts(collected_facts)



# Generated at 2022-06-24 22:23:23.378123
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():

    # Arrange
    sun_o_s_hardware_0 = SunOSHardware()

    # Act
    collected_facts_0 = {}
    cpu_facts_0 = sun_o_s_hardware_0.get_cpu_facts(collected_facts_0)

    # Assert
    assert cpu_facts_0 is not None


# Generated at 2022-06-24 22:23:26.015894
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware = SunOSHardware()

    # The kstat column values are not equal to a numeric value
    _ = sun_o_s_hardware.get_uptime_facts()


# Generated at 2022-06-24 22:23:32.229008
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = mock.Mock(return_value=(0, "Memory size: 20480 Megabytes", ""))
    sun_o_s_hardware_0.module.run_command = mock.Mock(return_value=(0, "kbytes/ physmem    free    free    anon    exec    file     pin     wire     in     out     page   swap   resid     fault      cow 125560932  2797684  2797684        0        0  2795757        0        0        0        0        0        0        0        0", ""))
    ret_val = sun_o_s_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:23:54.763882
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:57.605761
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:24:03.096063
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()
    var_1 = sun_o_s_hardware_0.uptime_facts
    var_2 = sun_o_s_hardware_0.uptime_seconds
    var_3 = sun_o_s_hardware_0.uptime_tuple
    assert var_0 is not None
    assert var_1 is not None
    assert var_2 is not None
    assert var_3 is None


# Generated at 2022-06-24 22:24:04.401817
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # FIXME: test describe this
    assert True


# Generated at 2022-06-24 22:24:12.854203
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    my_SunOSHardware_0 = SunOSHardware()
    my_SunOSHardware_0.module.run_command = run_command
    my_SunOSHardware_0.module.get_bin_path = get_bin_path
    var_0 = my_SunOSHardware_0.get_memory_facts()
    assert var_0 == {'swapfree_mb': 0, 'memtotal_mb': 0, 'swaptotal_mb': 0, 'swap_allocated_mb': 0, 'swap_reserved_mb': 0}



# Generated at 2022-06-24 22:24:15.368603
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_2 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_2.get_cpu_facts()


# Generated at 2022-06-24 22:24:22.779196
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
  """
  This test case is to check the return value of get_memory_facts method of SunOSHardware class.
  """
  sun_o_s_hardware_0 = SunOSHardware()
  assert sun_o_s_hardware_0.get_memory_facts() == {'swap_allocated_mb': 0, 'swap_reserved_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0}



# Generated at 2022-06-24 22:24:23.636377
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # FIXME
    assert True


# Generated at 2022-06-24 22:24:26.619537
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:30.276518
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:25:20.008077
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    with pytest.raises(AnsibleError) as excinfo:
        SunOSHardware.populate(bool)
    assert 'missing required arguments: module' in str(excinfo.value)


# Generated at 2022-06-24 22:25:22.269043
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:25:26.284875
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.populate()
# Test for method get_mount_facts of class SunOSHardware

# Generated at 2022-06-24 22:25:29.689250
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:25:35.252116
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    sun_o_s_hardware_0.module = MagicMock(return_value=None)
    sun_o_s_hardware_0.module.run_command.return_value = (0, '1024\n', '')
    assert sun_o_s_hardware_0.get_memory_facts() == {'memtotal_mb': 1024}


# Generated at 2022-06-24 22:25:37.931477
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # create the object SunOSHardware
    sun_o_s_hardware_1 = SunOSHardware(bool_0, bool_0)
    var_1 = sun_o_s_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:25:41.012983
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bool_0 = false
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:25:43.202392
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware(False, False)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:25:45.973994
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:48.321583
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:50.806455
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    assert 0 == 0


# Generated at 2022-06-24 22:27:53.558672
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:58.398395
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Verify that SunOSHardware.get_device_facts() returns a dict()
    sun_o_s_hardware_0 = SunOSHardware(False, False)
    var_1 = sun_o_s_hardware_0.get_device_facts()
    assert isinstance(var_1, dict)
    assert var_1 == {}


# Generated at 2022-06-24 22:28:00.937917
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_2 = SunOSHardware()
    sun_o_s_hardware_2.get_memory_facts()


# Generated at 2022-06-24 22:28:03.474336
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    required_facts = set(['platform'])
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(required_facts, '_platform')

# Generated at 2022-06-24 22:28:08.361587
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    sun_o_s_hardware_0.get_dmi_facts = sun_o_s_hardware_0.get_dmi_facts = sun_o_s_hardware_0.get_dmi_facts = sun_o_s_hardware_0.get_dmi_facts
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:28:12.038005
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:28:14.926597
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:28:17.575754
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware(True, True)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:28:21.420191
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    bool_0 = False
    sun_o_s_hardware_0 = SunOSHardware(bool_0, bool_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()
