

# Generated at 2022-06-24 22:19:33.368934
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # TODO: tests
    assert True


# Generated at 2022-06-24 22:19:34.914641
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # This is a placeholder method for unit test
    pass


# Generated at 2022-06-24 22:19:36.070618
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test case with no arguments
    test_case_0()

# Generated at 2022-06-24 22:19:39.249247
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    sun_o_s_hardware_1 = SunOSHardware('qJB[Kx', 'n<,]!=:d|A/KkR', 'W<Y#{vKm=I.')
    y = sun_o_s_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:19:52.062913
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.hardware.sunos import (
        SunOSHardware as A)


# Generated at 2022-06-24 22:20:02.067744
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = ':|.nls<J1,67xI'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    str_1 = ''
    collected_facts_0 = {'ansible_machine': 'i86pc'}
    str_2 = ''
    sun_o_s_hardware_0.module = str_2
    int_0 = 0
    int_1 = 0
    sun_o_s_hardware_0.module.run_command = lambda arg_0: (int_0, str_0, int_1)
    return_value_0 = sun_o_s_hardware_0.get_memory_facts(collected_facts_0)
    assert return_value_0


# Generated at 2022-06-24 22:20:07.148505
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import random

    def random_time():
        return random.randint(0, 2**32)

    #random.seed(0)
    time.time = random_time
    str_0 = '&(dZ=x1<'
    str_1 = 'o|8X!W1#v'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.module = sun_o_s_hardware_0.module.run_command(str_1)
    #assert str(sun_o_s_hardware_0.get_uptime_facts()) == '{   'str_1'}'

# Generated at 2022-06-24 22:20:11.742874
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = '[%Q`xY(c|QRp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    collected_facts = dict()
    sun_o_s_hardware_0.populate(collected_facts)
    return


# Generated at 2022-06-24 22:20:16.099951
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    args_0 = []
    str_0 = 'l#uV'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts(args_0)


# Generated at 2022-06-24 22:20:26.060987
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = ('zQj$U)J&AZ~lX;6Fx_6dM(F&}4JkdC:R.-'
             'iosn%SJQSX?{K<xTb+tK0V7!Y,oLmF7Wz')
    sun_o_s_hardware_0 = SunOSHardware(str_0)

    # Verify that the set of keys returned by get_memory_facts is
    # contained in the set of all keys of the hardware info
    assert set(sun_o_s_hardware_0.get_memory_facts().keys()).issubset(set(
        sun_o_s_hardware_0.get_hardware_info().keys()))


# Generated at 2022-06-24 22:20:52.405681
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'MemTotal:           2046200 kB'
    str_1 = 'MemTotal:           2045000 kB'
    str_2 = 'MemTotal:           2046000 kB'
    str_3 = 'MemTotal:           2045800 kB'
    str_4 = 'MemTotal:           2046200 kB'
    str_5 = 'MemTotal:           2045000 kB'
    str_6 = 'MemTotal:           2046000 kB'
    str_7 = 'MemTotal:           2045800 kB'
    str_8 = 'MemTotal:           2046200 kB'
    str_9 = 'MemTotal:           2045000 kB'
    str_10 = 'MemTotal:           2046000 kB'

# Generated at 2022-06-24 22:21:01.858124
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.populate()
    m_1 = sun_o_s_hardware_0.get_device_facts()
    str_1 = 'vp'
    sun_o_s_hardware_1 = SunOSHardware(str_1)
    sun_o_s_hardware_1.populate()
    m_2 = sun_o_s_hardware_1.get_device_facts()
    str_2 = 'vp'
    sun_o_s_hardware_2 = SunOSHardware(str_2)
    sun_o_s_hardware_2.populate()
    m_3 = sun_o_s_hardware_2

# Generated at 2022-06-24 22:21:03.095405
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert isinstance(SunOSHardwareCollector(), HardwareCollector)


# Generated at 2022-06-24 22:21:05.494869
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware("platform")
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:08.419682
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    set_0 = set()
    SunOSHardwareCollector._platform = 'SunOS'
    sun_o_s_hardware_0 = SunOSHardware(set_0)
    var_0 = sun_o_s_hardware_0.populate()
    return var_0


# Generated at 2022-06-24 22:21:11.226687
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:21:11.853570
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    err = get_device_facts()


# Generated at 2022-06-24 22:21:12.819432
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    case_0 = test_case_0()
    assert case_0 is None

# Generated at 2022-06-24 22:21:16.465426
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()
    print(var_0)
    pass


# Generated at 2022-06-24 22:21:18.911281
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:21:54.531485
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:21:57.609513
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:22:00.532686
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'] == 4096


# Generated at 2022-06-24 22:22:05.306083
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'vp'
    with timeout.timeout():
        sun_o_s_hardware_0 = SunOSHardware(str_0)
        var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:12.446697
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'kstat_arg'
    module_0 = MagicMock()
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0._module = module_0
    sun_o_s_hardware_0._module.run_command = MagicMock(return_value=(0, '', ''))
    sun_o_s_hardware_0._module.run_command_environ_update = {}
    sun_o_s_hardware_0._module.get_bin_path = MagicMock(return_value='/usr/bin/prtconf')
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:22:15.705864
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:22:18.179193
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:22:20.056477
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'mP'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:20.717877
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:22:23.089523
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:27.052299
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:37.320638
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()
    assert isinstance(var_0, dict)
    assert 'processor' in var_0
    assert var_0['processor'] == ['Xeon E5-2697 v4 @ 2.30GHz']
    assert 'processor_count' in var_0
    assert var_0['processor_count'] == 2
    assert 'processor_cores' in var_0
    assert var_0['processor_cores'] == 8
    assert 'memtotal_mb' in var_0
    assert var_0['memtotal_mb'] == 16383
    assert 'swapfree_mb' in var_0

# Generated at 2022-06-24 22:23:41.743838
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    dict_0 = sun_o_s_hardware_0.get_cpu_facts()
    pass


# Generated at 2022-06-24 22:23:45.019509
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    assert sun_o_s_hardware_0.get_device_facts() is None
    test_case_0()


# Generated at 2022-06-24 22:23:49.525034
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)

    # TODO: Figure out how to test this
    # sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:54.064030
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_1 = 'vp'
    sun_o_s_hardware_1 = SunOSHardware(str_1)
    var_1 = sun_o_s_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:23:56.945539
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:59.025378
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware('str')
    output = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:24:09.712654
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'XH'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
    assert var_0 == {'swaptotal_mb': None, 'memtotal_mb': None, 'swap_allocated_mb': None, 'swapfree_mb': None, 'swap_reserved_mb': None}, 'Failed assertion: assert var_0 == {\'swaptotal_mb\': None, \'memtotal_mb\': None, \'swap_allocated_mb\': None, \'swapfree_mb\': None, \'swap_reserved_mb\': None}'


# Generated at 2022-06-24 22:24:12.358841
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_1 = 'vp'
    sun_o_s_hardware_1 = SunOSHardware(str_1)
    sun_o_s_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:27:20.225961
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:27:22.893295
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    sun_o_s_hardware_0.get_cpu_facts(collected_facts)


# Generated at 2022-06-24 22:27:23.669857
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    assert True


# Generated at 2022-06-24 22:27:29.094464
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()
    assert sun_o_s_hardware_0.populate() == None


# Generated at 2022-06-24 22:27:38.557504
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    data = '''System Configuration: Sun Microsystems  sun4u
Sun Microsystems  SUNW,Ultra-5_10
Memory size: 256 Megabytes
System Peripherals (Software Nodes):

sun4u/memory-unit@2/memory-board@0,0
sun4u/memory-unit@2/memory-board@0,1
sun4u/memory-unit@2/memory-board@0,2
sun4u/memory-unit@2/memory-board@0,3'''
    sun_o_s_hardware_0 = SunOSHardware('vp')
    sun_o_s_hardware_0._run_command = lambda y: (0, data, '')

# Generated at 2022-06-24 22:27:40.659397
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'T'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:27:43.092517
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'n1'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:27:45.228845
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:27:47.187993
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:27:50.555102
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'vp'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
