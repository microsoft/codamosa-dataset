

# Generated at 2022-06-24 22:19:40.650246
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    result = sun_o_s_hardware_0.get_cpu_facts()

    assert result is not None


# Generated at 2022-06-24 22:19:43.321487
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:19:45.691320
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()



# Generated at 2022-06-24 22:19:50.137883
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # Stub out the prtdiag command
    sun_o_s_hardware_0.module.run_command = get_run_command_return_value(['/usr/bin/uname -i'], 'i86pc')
    sun_o_s_hardware_0.module.run_command = get_run_command_return_value(['/usr/sbin/prtconf'], 'test_output')

    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:52.489997
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()

    # A test case to check dmi facts
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:19:56.020444
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware({"platform": "SunOS"})
    result = sun_o_s_hardware_0.get_uptime_facts()
    assert result == ({}, {'uptime_seconds': 1548250206})


# Generated at 2022-06-24 22:20:02.340641
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v', None))
    assert sun_o_s_hardware_0.get_dmi_facts() == {'product_name': 'sun4v', 'system_vendor': 'Oracle Corporation'}


# Generated at 2022-06-24 22:20:07.404616
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Save the current environment, which should be restored in the end of this test.
    environ_backup = os.environ.copy()

    env_vars = {
        'LC_NUMERIC': 'C',
        'LANG': 'C',
        'LC_ALL': 'C',
    }

    sun_o_s_hardware_0 = SunOSHardware()

    for key, value in env_vars.items():
        os.environ[key] = value

    # Test with result of running command `/usr/bin/kstat -p`,
    # where the following output is provided:
    # sderr:0:sd0,err:Hard Errors     0
    # sderr:0:sd0,err:Illegal Request 6
    # sderr:0:sd0,err:Media Error

# Generated at 2022-06-24 22:20:11.599770
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Setup
    sun_o_s_hardware_0 = SunOSHardware()

    # Test
    sun_o_s_hardware_0.get_uptime_facts()

    # Assertions
    assert True  # test ran without exception


# Generated at 2022-06-24 22:20:14.568321
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    func = getattr(SunOSHardwareCollector, "_SunOSHardwareCollector", None)
    obj = SunOSHardwareCollector()
    assert obj != None


# Generated at 2022-06-24 22:20:34.754792
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.populate()


# Generated at 2022-06-24 22:20:37.065694
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:20:40.535687
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    fake_module = object
    sun_o_s_hardware_0 = SunOSHardware(fake_module)
    assert sun_o_s_hardware_0.get_uptime_facts() == {'uptime_seconds': 57859}


# Generated at 2022-06-24 22:20:44.945073
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    collected_facts = {}
    out = sun_o_s_hardware_0.get_cpu_facts(collected_facts)
    assert out is not None


# Generated at 2022-06-24 22:20:47.485287
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:20:51.734379
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert isinstance(sun_o_s_hardware_0.get_memory_facts(), dict)


# Generated at 2022-06-24 22:20:54.026420
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:20:55.925027
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:20:58.688534
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=None)
    assert sun_o_s_hardware_0.get_cpu_facts() is None


# Generated at 2022-06-24 22:21:07.712179
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(module=None)
    sun_o_s_hardware_0.get_cpu_facts = MagicMock(return_value=None)
    sun_o_s_hardware_0.get_memory_facts = MagicMock(return_value=None)
    sun_o_s_hardware_0.get_dmi_facts = MagicMock(return_value=None)
    sun_o_s_hardware_0.get_device_facts = MagicMock(return_value=None)
    sun_o_s_hardware_0.get_uptime_facts = MagicMock(return_value=None)

    assert sun_o_s_hardware_0.populate() is None


# Generated at 2022-06-24 22:21:47.192066
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_1 = SunOSHardware()
    assert sun_o_s_hardware_1.get_cpu_facts() == {'processor': ['SUNW,UltraAX-i2 @ 200MHz'], 'processor_cores': 1, 'processor_count': 1}


# Generated at 2022-06-24 22:21:48.969121
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware({})
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:50.076490
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    pass


# Generated at 2022-06-24 22:21:55.204409
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert sun_o_s_hardware_0.get_cpu_facts() is None


# Generated at 2022-06-24 22:22:02.957213
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Tests for method get_dmi_facts of class SunOSHardware
    """
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )
    sun_o_s_hardware_0.module.run_command = MagicMock()
    sun_o_s_hardware_0.module.run_command.return_value = (0, "System Configuration: Oracle Corporation sun4v    Netra T5220", None)
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()
    assert dmi_facts['system_vendor'] is "Oracle Corporation"

# Generated at 2022-06-24 22:22:06.214285
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:12.144945
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    result = sun_o_s_hardware_0.get_memory_facts()
    assert result == {
        'swaptotal_mb': 2048,
        'swapfree_mb': 0,
        'swap_allocated_mb': 0,
        'swap_reserved_mb': 0,
        'memtotal_mb': 4096
    }


# Generated at 2022-06-24 22:22:17.977341
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.params = dict(
        filter='*'
    )
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, 'System Configuration: XXXXX 5100-01', ''))
    dmi_facts = sun_o_s_hardware_0.get_dmi_facts()
    assert dmi_facts['product_name'] == '5100-01'

# Generated at 2022-06-24 22:22:20.450581
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:22:21.149728
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # FIXME
    pass


# Generated at 2022-06-24 22:22:59.293177
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_1 = SunOSHardware('04t')
    var_1 = sun_o_s_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 22:23:04.527076
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    str_0 = 'd,l!Z^8n}WYdL'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:23:05.968815
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str1 = 'm'
    sun_o_s_hardware1 = SunOSHardware(str1)
    var1 = sun_o_s_hardware1.get_dmi_facts()


# Generated at 2022-06-24 22:23:08.679123
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = 'KkMx|Zf,UU.V'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:23:14.648236
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware('+mDB')
    var_0 = sun_o_s_hardware_0.populate()
    if var_0 is not None:
        assert 'swaptotal_mb' in var_0
        assert 'swaptotal_mb' in var_0
        assert 'swapfree_mb' in var_0
        assert 'swapfree_mb' in var_0
        assert 'swapfree_mb' in var_0
        assert 'swapfree_mb' in var_0
    else:
        assert False, 'Expected a dictionary'
    var_1 = sun_o_s_hardware_0.populate()
    if var_1 is not None:
        assert 'swaptotal_mb' in var_1

# Generated at 2022-06-24 22:23:19.177994
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = '@n$x+'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:23:23.538087
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = '+.N5Nj?^JPwtE'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:26.793150
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = '+(MNG;`O*U6xgAb6m'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:23:32.128068
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'q4d:1]s&nhF2E#K/J'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:23:37.670822
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    try:
        str_0 = '+.N5Nj?^JPwtE'
        sun_o_s_hardware_0 = SunOSHardware(str_0)
        var_0 = sun_o_s_hardware_0.populate()
        assert var_0 is not None
    except Exception:
        assert False


# Generated at 2022-06-24 22:25:02.626817
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'K=h*J(S2gMnv'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_collector_0 = SunOSHardwareCollector(str_0)
    sun_o_s_hardware_0.module = sun_o_s_hardware_collector_0.module
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:07.009459
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = "\\Q|w<VC"
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:25:10.517745
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = '@m*m96+x-#'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:11.408136
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:25:15.690715
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'hM;sw[b'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    str_1 = '%&M1}`d4]t@qb4i9'
    str_2 = 'V7jK'
    var_0 = sun_o_s_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:25:18.267873
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = 'X'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    # Call the method with a known argument
    sun_o_s_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:25:19.208447
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    assert False


# Generated at 2022-06-24 22:25:21.872714
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = '+.N5Nj?^JPwtE'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:25:26.108764
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = 'I7Byu\'f3=Y7r'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:25:31.235932
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    str_0 = '+.N5Nj?^JPwtE'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.populate()
    assert var_0 is not None
    assert str(type(var_0)) is "<type 'dict'>"
    assert var_0 == {}


# Generated at 2022-06-24 22:29:02.447957
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    str_0 = '/.='
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:29:07.432164
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_0 = StringIO()
    var_0.write('System Configuration: Sun Microsystems sun4u\n')
    var_0.write('Memory size: 8192 Megabytes\n')
    var_0.write('System Peripherals (Software Nodes):\n')
    var_0.write(' SUNW,UltraSPARC-IIi-Engine#0\n')
    var_0.write(' SUNW,UltraSPARC-IIi-Engine#1\n')
    var_0.write(' SUNW,pci108e,a000  (driver not attached)\n')
    var_0.write('SUNW,pci108e,a001 (driver not attached)\n')
    var_0.write('SUNW,pci108e,a002 (driver not attached)\n')

# Generated at 2022-06-24 22:29:11.597107
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    str_0 = '3X9$K,hVY>%'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    sun_o_s_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:29:14.631299
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    str_0 = 'L|zI(s|#'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    uptime_facts = sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:29:19.631714
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    str_0 = 'yHd.1b<*c'
    sun_o_s_hardware_0 = SunOSHardware(str_0)
    var_0 = sun_o_s_hardware_0.get_memory_facts()
