

# Generated at 2022-06-24 22:19:44.236556
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.module = mock.Mock()
    sun_o_s_hardware_0.module.run_command = mock.Mock()
    sun_o_s_hardware_0.module.run_command.side_effect = [
      (0, ' Memory size: 20480 Megabytes', ''),
      (0, ' 20480  16384    1024', '')
    ]


# Generated at 2022-06-24 22:19:55.440883
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)

    # Test the attribute exists.
    assert hasattr(sun_o_s_hardware_0, '_dmi_facts')

    # Test the attribute value.
    expected_value = None
    actual_value = sun_o_s_hardware_0._dmi_facts
    assert actual_value == expected_value

    # Test override get_dmi_facts.
    sun_o_s_hardware_0._dmi_facts = 'dmi_facts'
    actual_value = sun_o_s_hardware_0._dmi_facts
    assert actual_value == 'dmi_facts'
    sun_o

# Generated at 2022-06-24 22:20:05.668735
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0._module.run_command = lambda x: (0, b'Memory size: 6137965KB', b'')
    sun_o_s_hardware_0._module.run_command = lambda x: (0, b'      6137965K bytes of memory.', b'')
    expected = {'swapfree_mb': 60711, 'swap_reserved_mb': 61024, 'swaptotal_mb': 61380, 'memtotal_mb': 61379, 'swap_allocated_mb': 61024}
    actual = sun_o_s_hardware

# Generated at 2022-06-24 22:20:14.281539
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.module = MagicMock()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    assert sun_o_s_hardware_0.get_dmi_facts() == {'system_vendor': '', 'product_name': ''}


# Generated at 2022-06-24 22:20:22.315663
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0._module = Mock()
    sun_o_s_hardware_0._module.run_command.return_value = (0, '', '')
    assert sun_o_s_hardware_0.get_cpu_facts() == {'processor': [], 'processor_cores': 'NA', 'processor_count': 0}


# Generated at 2022-06-24 22:20:26.282491
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    assert sun_o_s_hardware_0.get_uptime_facts() is None



# Generated at 2022-06-24 22:20:30.348594
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from random import choice
    from string import ascii_letters, digits
    from ansible.module_utils.facts.facts.hardware.sunos import SunOSHardware
    result = SunOSHardware.get_device_facts({})
    assert result is None



# Generated at 2022-06-24 22:20:40.655426
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    bytes_1 = b'\xa2\x05X\x1d\xeb\x1b\xfa'
    sun_o_s_hardware_1 = SunOSHardware(bytes_1)
    bytes_2 = b'\x1f0\xc6\x81\xf1\x7f\x9eP\xca\xbf\x14\x15\x02\xa4\x01\xef\x00\xf9\xba\xba\xba\xba'
    sun_o_s_hardware_2 = SunOSHardware(bytes_2)
    int_0 = sun

# Generated at 2022-06-24 22:20:48.799206
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    bytes_0 = b'\xdc\x8fr\xb2`}!G\x96'
    sun_o_s_hardware_0 = SunOSHardware(bytes_0)
    sun_o_s_hardware_0.module = None
    module_0 = sun_o_s_hardware_0.module
    shell_0 = module_0.shell
    shell_0.run_command = None
    str_0 = sun_o_s_hardware_0.get_uptime_facts()

    assert str_0 is None


# Generated at 2022-06-24 22:20:58.963067
# Unit test for method populate of class SunOSHardware

# Generated at 2022-06-24 22:21:17.968321
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    var_0 = {}
    var_0['ansible_facts'] = {}
    var_1 = SunOSHardware()
    var_0['ansible_facts'] = var_1.populate()


# Generated at 2022-06-24 22:21:28.459781
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    var_0 = {
        'ansible_devices':{
            'sda':{
                'media_errors':'0',
                'predictive_failure_analysis':'0',
                'product':'VBOX HARDDISK',
                'size':'50GiB',
                'revision':'1.0',
                'hard_errors':'0',
                'vendor':'ATA',
                'transport_errors':'0',
                'illegal_request':'6',
                'serial':'VB0ad2ec4d-074a',
                'soft_errors':'0'
            }
        }
    }


# Generated at 2022-06-24 22:21:30.704435
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_0 = SunOSHardware(var_0)
    var_1 = var_0.get_memory_facts()

# Generated at 2022-06-24 22:21:33.542173
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_0 = SunOSHardware()
    var_1 = var_0.get_dmi_facts()
    assert var_1 == None


# Generated at 2022-06-24 22:21:36.424810
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    var_1 = SunOSHardware()
    var_2 = {}
    var_3 = var_1.populate(var_2)


# Generated at 2022-06-24 22:21:44.464557
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    var_0 = SunOSHardware()
    var_0.module = "module"
    var_0.module.run_command = "run_command"
    var_0.module.run_command_environ_update = "run_command_environ_update"
    var_0.module.get_bin_path = "get_bin_path"
    var_0.module.run_command_environ_update = "run_command_environ_update"
    var_0.module.run_command_environ_update = "run_command_environ_update"
    var_0.module.run_command_environ_update = "run_command_environ_update"
    var_0.module.run_command_environ_update = "run_command_environ_update"

# Generated at 2022-06-24 22:21:47.024957
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    var_0 = SunOSHardware()
    var_0.module = Mock()
    var_0.module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')
    assert var_0.get_uptime_facts() == {'uptime_seconds': time.time() - 1548249689}


# Generated at 2022-06-24 22:21:49.583873
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_0 = test_case_0()
    var_1 = SunOSHardware(module=var_0)
    var_2 = var_1.get_cpu_facts()
    assert var_2 == {}


# Generated at 2022-06-24 22:21:52.742215
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    var_0 = SunOSHardware()
    var_1 = var_0.get_uptime_facts()

# Generated at 2022-06-24 22:21:56.851326
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var = test_case_0()
    sunoshardware = SunOSHardware(var)
    result = sunoshardware.get_dmi_facts(var)
    assert result != None



# Generated at 2022-06-24 22:22:14.304064
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    test_case_0()


# Generated at 2022-06-24 22:22:16.787331
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Test with a empty dictionary
    test_case_0()
    # Test with the dummy module object
    dummy = SunOSHardware(module=None)
    test_case_0()


# Generated at 2022-06-24 22:22:22.165088
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_0 = SunOSHardwareCollector()
    var_1 = var_0.get_memory_facts()
    assert var_1 == {u'swap_allocated_mb': 0, u'swap_reserved_mb': 0, u'swaptotal_mb': 0, u'memtotal_mb': 0, u'swapfree_mb': 0}


# Generated at 2022-06-24 22:22:23.654246
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    var_1 = SunOSHardwareCollector()
    assert var_1 != None


# Generated at 2022-06-24 22:22:29.156821
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    # Test case: 0
    var_00 = test_case_0()
    var_1 = SunOSHardware(var_00)
    var_2 = var_1.get_memory_facts()
    assert var_2['swap_reserved_mb'] == 0
    assert var_2['swap_allocated_mb'] == 0
    assert var_2['memtotal_mb'] == 2048
    assert var_2['swapfree_mb'] == 2048
    assert var_2['swaptotal_mb'] == 2048


# Generated at 2022-06-24 22:22:31.350297
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_0 = {}
    var_1 = {}
    var_2 = {}
    var_1 = SunOSHardware(var_0)
    var_2 = var_1.get_cpu_facts()
    return var_2


# Generated at 2022-06-24 22:22:31.974410
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_case_0()


# Generated at 2022-06-24 22:22:36.845042
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    SunOSHardware = SunOSHardware()
    SunOSHardware.module = MagicMock()
    SunOSHardware.module.run_command.return_value = (0, 'ok', '')
    assert var_0 == SunOSHardware.get_memory_facts()


# Generated at 2022-06-24 22:22:47.511516
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_1 = SunOSHardware()
    test_case_0()
    var_1.module.run_command.return_value = (0, b'cpu_info\ncpu_info\tchip_id\t0\ncpu_info\tclock_MHz\t3900\ncpu_info\tmodule\t0\ncpu_info\timplementation\tSPARC-T4\ncpu_info\tbrand\tSPARC T4-1\nmodule: cpu\nchip_id\t0\nclock_MHz\t3900\nmodule\t0\nimplementation\tSPARC-T4\nbrand\tSPARC T4-1\n', '')
    var_2 = var_1.get_cpu_facts()

# Generated at 2022-06-24 22:22:51.871998
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_0 = SunOSHardware()
    var_1 = {}
    var_2 = var_0.get_memory_facts()
    assert var_2 == var_1


# Generated at 2022-06-24 22:23:28.501897
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():

    from ansible.module_utils.facts import Collector
    c = Collector(SunOSHardwareCollector, None)
    c.populate()
    d = c.get_facts()
    print(d)


# Generated at 2022-06-24 22:23:29.935835
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    obj_SunOSHardware = SunOSHardware(var_0)
    obj_SunOSHardware.get_memory_facts()


# Generated at 2022-06-24 22:23:34.854120
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    var_1 = test_case_0()

    obj = SunOSHardware()
    var_1 = obj.get_uptime_facts()

# Generated at 2022-06-24 22:23:37.778691
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    var_0 = SunOSHardware()
    var_1 = {}
    expected = None
    var_1 = var_0.get_device_facts()
    assert var_1 == expected


# Generated at 2022-06-24 22:23:39.360547
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_0 = SunOSHardware()
    var_1 = None
    var_2 = var_0.get_cpu_facts(var_1)
    if var_2 != None:
        raise AssertionError


# Generated at 2022-06-24 22:23:40.928371
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    # unit test for populate
    prtdiag_cmd = "/usr/sbin/prtdiag"


# Generated at 2022-06-24 22:23:43.399188
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    test_case_0()


test_SunOSHardware = [
    test_SunOSHardware_get_cpu_facts,
]



# Generated at 2022-06-24 22:23:44.487593
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()

# Unit test main function

# Generated at 2022-06-24 22:23:49.317334
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    var_0 = { 'ansible_facts': { 'ansible_machine': 'i86pc' } }
    var_1 = {}
    var_0['ansible_facts'] = var_1
    SunOSHardware_obj = SunOSHardware(var_0)
    SunOSHardware_obj.populate()

# Generated at 2022-06-24 22:23:52.556976
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    SunOSHardware = SunOSHardware()
    var_0 = var_0
    assert SunOSHardware.get_dmi_facts()



# Generated at 2022-06-24 22:24:38.128089
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_0 = SunOSHardware()
    var_0.get_dmi_facts()


# Generated at 2022-06-24 22:24:40.198968
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_0 = get_dmi_facts()
    assert var_0 == {}, "return value is wrong"


# Generated at 2022-06-24 22:24:42.672528
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0() # def test_case_0():


# Generated at 2022-06-24 22:24:44.051410
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    var_0 = SunOSHardwareCollector(var_0, 'ansible module')

# Generated at 2022-06-24 22:24:45.709006
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    var = SunOSHardwareCollector(facts={})


# Generated at 2022-06-24 22:24:46.910518
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_1 = SunOSHardware(var_0)
    var_2 = {}
    assert var_1.get_memory_facts() == var_2


# Generated at 2022-06-24 22:24:49.074472
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    host = SunOSHardware()
    # var_0
    test_case_0()
    try:
        host.populate()
    except Exception:
        assert False


# Generated at 2022-06-24 22:24:50.645946
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    assert (type(test_case_0.var_0['ansible_processor']) is list)


# Generated at 2022-06-24 22:24:53.108065
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    var_0 = SunOSHardware()
    var_1 = test_case_0()
    var_0.populate()
    return var_0.get_device_facts()


# Generated at 2022-06-24 22:24:57.652488
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_0 = SunOSHardware()
    var_1 = var_0.get_cpu_facts()
    print('Answer is: {}'.format(var_1))


# Generated at 2022-06-24 22:25:53.881502
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_0 = SunOSHardware()
    var_0.module.run_command = MagicMock(return_value=(0, 'value', ''))
    var_0.module.run_command = MagicMock(return_value=(0, 'value', ''))
    var_ret_0 = var_0.get_memory_facts()
    assert var_ret_0 == {}


# Generated at 2022-06-24 22:26:04.239782
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {}
    var_1 = "/usr/bin/uname -i"
    var_2 = rc = 0
    var_3 = "sun4v"
    var_4 = ""
    platform_sbin = "/usr/platform/sun4v/sbin"
    var_5 = "prtdiag"
    prtdiag_path = "/usr/platform/sun4v/sbin/prtdiag"
    var_6 = "prtdiag"
    var_7 = rc = 0
    var_8 = "System Configuration: Oracle Corporation sun4v"
    var_9 = "SUN FIRE T2000"
    dmi_facts['system_vendor'] = "Oracle Corporation"
    dmi_facts['product_name'] = "SUN FIRE T2000"
    return  dmi

# Generated at 2022-06-24 22:26:05.951730
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    case_0 = SunOSHardware(var_0)
    if not hasattr(case_0, 'populate'):
        print("False")
        print("True")


# Generated at 2022-06-24 22:26:06.745860
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()


# Generated at 2022-06-24 22:26:08.984482
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # See test_case_0 for fixtures.
    var_0 = SunOSHardware()
    var_1 = var_0.get_device_facts()
    assert var_1 == {}

# Generated at 2022-06-24 22:26:11.053537
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    test_case_0()

# Generated at 2022-06-24 22:26:19.069524
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    var_1 = SunOSHardware()
    var_1.module = ansible_module_mock
    var_1.facts = {}
    var_1.module.run_command = run_command_mock

    var_1.module.run_command.return_value = (0, cmd_output, '')

    var_2 = var_1.get_device_facts()


# Generated at 2022-06-24 22:26:20.543321
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    assert SunOSHardware.get_memory_facts() == None, 'The function call get_memory_facts() is false'


# Generated at 2022-06-24 22:26:21.517077
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    var_2 = get_memory_facts()


# Generated at 2022-06-24 22:26:22.573467
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    var_0 = SunOSHardware()
    var_0.populate()



# Generated at 2022-06-24 22:28:22.124724
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_0 = {}
    test_case_0()
    test_object = SunOSHardware(var_0)
    try:
        result = test_object.get_dmi_facts()
    except Exception as e:
        print("SunOSHardware.get_dmi_facts() threw an exception: %s" % str(e))



# Generated at 2022-06-24 22:28:24.048226
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    Hardware = SunOSHardware(var_0)
    Hardware.get_cpu_facts()


# Generated at 2022-06-24 22:28:25.861869
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    var_1 = SunOSHardware()
    test_case_0()



# Generated at 2022-06-24 22:28:27.575325
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_0 = {}
    var_1 = get_cpu_facts(var_0)


# Generated at 2022-06-24 22:28:28.406767
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_case_0()

# Generated at 2022-06-24 22:28:29.908820
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Initial configuration
    test_case_0()

    # Invoke the function and test the result

    # Assertion
    assert True


# Generated at 2022-06-24 22:28:36.525863
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    x = SunOSHardware()
    var_0 = x.get_uptime_facts()
    assert 'uptime_seconds' in var_0.keys()
    assert 'platform' in var_0.keys()
    assert 'devices' in var_0.keys()
    assert 'system_vendor' in var_0.keys()
    assert 'product_name' in var_0.keys()
    assert 'processor' in var_0.keys()
    assert 'swaptotal_mb' in var_0.keys()
    assert 'processor_cores' in var_0.keys()
    assert 'swapfree_mb' in var_0.keys()
    assert 'processor_count' in var_0.keys()
    assert 'swap_reserved_mb' in var_0.keys()

# Generated at 2022-06-24 22:28:43.740682
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    var_0 = 'memory_facts'
    var_1 = {}
    var_2 = 'hardware_facts'

# Generated at 2022-06-24 22:28:45.946137
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var = test_case_0()
    obj = SunOSHardware(var)
    var = obj.get_cpu_facts()
    assert var is not None


# Generated at 2022-06-24 22:28:48.007805
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    var_1 = SunOSHardware()
    var_1.populate(var_0)
    print("'" + var_1.get_cpu_facts() + "'")
