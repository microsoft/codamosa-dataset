

# Generated at 2022-06-24 22:19:34.358617
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:19:39.428958
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.module = ModuleStub()
    # Call the method being tested
    result = sun_o_s_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:19:44.466591
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_o_s_hardware_0 = SunOSHardware(1205.184)
    collected_facts = {}
    sun_o_s_hardware_0.populate(collected_facts)
    print("collect_facts = %class.dict-class")


# Generated at 2022-06-24 22:19:48.298847
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_memory_facts()
    # TODO: get test to work

# Generated at 2022-06-24 22:19:54.010906
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    try:
        # Setup SunOSHardware instance
        float_0 = 1205.184
        sun_o_s_hardware_0 = SunOSHardware(float_0)
        # Call get_memory_facts()
        sun_o_s_hardware_0.get_memory_facts()
        # AssertionError
    except AssertionError:
        pass


# Generated at 2022-06-24 22:20:00.517829
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    float_1 = 1205.184
    sun_o_s_hardware_1 = SunOSHardware(float_1)
    dict_0 = sun_o_s_hardware_1.get_memory_facts()
    # Verify that the length of dict_0 is 1
    assert len(dict_0) == 1
    # Verify that the value at key "memtotal_mb" is equal to 1205
    assert dict_0['memtotal_mb'] == 1205


# Generated at 2022-06-24 22:20:08.547346
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    out = """module: cpu_info       instance: 0
class: miscellaneous
chip_id   0
clock_MHz           1200
class: miscellaneous
module: cpu_info       instance: 1
class: miscellaneous
chip_id   1
clock_MHz           1200"""
    sun_o_s_hardware_0 = SunOSHardware('')
    sun_o_s_hardware_0.module.run_command = Mock(side_effect=[(0, out, '')])
    assert sun_o_s_hardware_0.get_cpu_facts() == {
        'processor': [
            'cpu_info @ 1200MHz',
            'cpu_info @ 1200MHz',
        ],
        'processor_cores': 2,
        'processor_count': 2,
    }


# Generated at 2022-06-24 22:20:18.112979
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    str_0 = 'a'
    str_1 = ''
    sun_o_s_hardware_0.module = str_0

    rc, out, err = sun_o_s_hardware_0.module.run_command('/usr/bin/kstat cpu_info')
    if rc != 0:
        assert False
    sun_o_s_hardware_0.module.run_command('/usr/bin/kstat cpu_info')
    sun_o_s_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:20:21.732219
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:20:25.110343
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:20:54.971004
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.populate()


# Generated at 2022-06-24 22:21:04.075460
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    assert sun_o_s_hardware_0.get_cpu_facts() == {}
    collected_facts = {'ansible_machine': 'i86pc'}
    assert sun_o_s_hardware_0.get_cpu_facts(collected_facts) == {}
    collected_facts = {'ansible_machine': 'sparc'}
    assert sun_o_s_hardware_0.get_cpu_facts(collected_facts) == {}
    collected_facts = {'ansible_machine': 'sparc64'}
    assert sun_o_s_hardware_0.get_cpu_facts(collected_facts) == {}

# Generated at 2022-06-24 22:21:05.720075
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    with pytest.raises(TypeError):
        SunOSHardware.get_memory_facts()


# Generated at 2022-06-24 22:21:07.597196
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.populate()

# Generated at 2022-06-24 22:21:10.408510
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    temp_1 = SunOSHardware(None)
    temp_1.module = MagicMock()
    temp_1.module.run_command.return_value = (0, "", "")
    test_0 = temp_1.get_device_facts()
    assert test_0 == {"devices": {}}


# Generated at 2022-06-24 22:21:17.040539
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    float_0 = 1205.184
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.module.run_command = mock_run_command


# Generated at 2022-06-24 22:21:23.228981
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware(1205.184)
    sun_o_s_hardware_1 = SunOSHardware(1361.59)
    sun_o_s_hardware_2 = SunOSHardware(1055.945)
    sun_o_s_hardware_4 = SunOSHardware(1156.0)
    sun_o_s_hardware_3 = SunOSHardware(1066.667)
    sun_o_s_hardware_5 = SunOSHardware(1159.178)
    sun_o_s_hardware_6 = SunOSHardware(1236.214)
    sun_o_s_hardware_7 = SunOSHardware(1061.429)
    sun_o_s_hardware_8 = SunOSHardware(1353.548)


# Generated at 2022-06-24 22:21:25.858755
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    sun_o_s_hardware_0 = SunOSHardware(float_0)
    sun_o_s_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:21:34.119191
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    test_module = {"run_command": run_command,
                   "run_command_environ_update": {"LANG": get_best_parsable_locale(test_module),
                                                  "LC_ALL": get_best_parsable_locale(test_module),
                                                  "LC_NUMERIC": get_best_parsable_locale(test_module)}}
    test_result = SunOSHardware(test_module).get_memory_facts()
    assert test_result["memtotal_mb"] == 3900
    assert test_result["swap_allocated_mb"] == 256
    assert test_result["swap_reserved_mb"] == 0
    assert test_result["swaptotal_mb"] == 128
    assert test_result["swapfree_mb"] == 128

# Generated at 2022-06-24 22:21:38.578816
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    float_2 = 3.14
    sun_o_s_hardware_1 = SunOSHardware(float_2)
    float_0 = 1205.184
    float_1 = 3.14
    sun_o_s_hardware_2 = SunOSHardware(float_0, float_1)


# Generated at 2022-06-24 22:22:44.587827
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    returned_value_0 = sun_o_s_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:22:48.109064
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module = Mock()
    assert 'ansible_facts' in sun_o_s_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:22:57.804565
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_os_hardware_0 = SunOSHardware()
    sun_os_hardware_0.module = AnsibleModule(argument_spec = dict())
    sun_os_hardware_0.module.run_command = MagicMock(return_value=(0, "unix:0:system_misc:boot_time    1548249689", ""))
    assert sun_os_hardware_0.get_uptime_facts() == {'uptime_seconds': int((time.time() - 1548249689))}
    assert sun_os_hardware_0.get_uptime_facts() != {'uptime_seconds': int(time.time())}
    assert sun_os_hardware_0.get_uptime_facts().keys() == ['uptime_seconds']

# Generated at 2022-06-24 22:23:01.020267
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert not sun_o_s_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:23:05.358221
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    assert isinstance(sun_o_s_hardware_0.get_memory_facts(), dict)

test_case_0()
test_SunOSHardware_get_memory_facts()

# Generated at 2022-06-24 22:23:07.411925
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware(module=None)

    assert sun_o_s_hardware_0.get_dmi_facts() == {}, \
        'Expected value is: {}'


# Generated at 2022-06-24 22:23:08.416679
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()


# Generated at 2022-06-24 22:23:09.178915
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    assert SunOSHardwareCollector()

# Generated at 2022-06-24 22:23:11.856614
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0_get_uptime_facts = SunOSHardware(platform='SunOS')
    sun_o_s_hardware_0_get_uptime_facts.populate()
    return sun_o_s_hardware_0_get_uptime_facts.get_uptime_facts()


# Generated at 2022-06-24 22:23:22.440864
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = run_command_mock
    sun_o_s_hardware_0.module.run_command_environ_update = {'LANG': 'C', 'LC_ALL': 'C', 'LC_NUMERIC': 'C', 'LC_CTYPE': 'C', 'LC_MESSAGES': 'C'}
    current_time = int(time.time()) - 1
    out = 'unix:0:system_misc:boot_time\t%s' % current_time
    rc, out, err = sun_o_s_hardware_0.get_uptime_facts()
    assert rc['uptime_seconds'] == 1


# Generated at 2022-06-24 22:24:57.314370
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, b'Memory size: 16384 Megabytes', b''))
    sun_o_s_hardware_0.module.run_command = MagicMock(return_value=(0, b'4.0K    allocated    0.0M    reserved    0.0M    used    0.0M    available', b''))

    memory_facts = sun_o_s_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:25:02.396950
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():

    # check that the class exists
    try:
        sun_o_s_hardware = SunOSHardware()
    except NameError:
        raise NameError('Class SunOSHardware does not exist')

    # check that the method exists
    try:
        sun_o_s_hardware.get_uptime_facts
    except AttributeError:
        raise AttributeError("Method SunOSHardware.get_uptime_facts does not exist.")


# Generated at 2022-06-24 22:25:05.923314
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    sun_o_s_hardware = SunOSHardware()
    sun_o_s_hardware.get_memory_facts()


# Generated at 2022-06-24 22:25:07.454336
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    f = SunOSHardware()
    assert f.get_memory_facts() is not None


# Generated at 2022-06-24 22:25:11.330468
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    sun_os_hardware_obj = SunOSHardware()
    res = sun_os_hardware_obj.populate()
    assert res['swap_reserved_mb'] >= 0
    assert res['swap_allocated_mb'] >= 0
    assert res['uptime_seconds'] > 0


# Generated at 2022-06-24 22:25:18.926291
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():

    # test setup
    # replace object attributes with mock data that would be returned from actual call to Solaris
    fact_class = SunOSHardware()
    fact_class.module = mock_ansible_module(test_SunOSHardware)
    fact_class.get_file_content = mock_get_file_content
    mock_run_command = ['System Configuration:   Sun Microsystems  sun4u', 'System Configuration:   Fujitsu  Primergy BX400 S1', 'System Configuration:   Oracle Corporation sun4v', 'System Configuration:   VMware, Inc.  VMware Virtual Platform', 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)']
    fact_class.module.run_command = mock_get_command_response(mock_run_command)
    # run test
    result = fact_class.get_

# Generated at 2022-06-24 22:25:20.693427
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
  result = SunOSHardware.get_uptime_facts()
  assert not result, 'The result is not supposed to be empty.'



# Generated at 2022-06-24 22:25:24.488567
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    uptime_facts = sun_o_s_hardware_0.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == "1537037698"


# Generated at 2022-06-24 22:25:34.082702
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    dmi_facts = {}

    # On Solaris 8 the prtdiag wrapper is absent from /usr/sbin,
    # but that's okay, because we know where to find the real thing:
    rc, platform, err = module.run_command('/usr/bin/uname -i')
    platform_sbin = '/usr/platform/' + platform.rstrip() + '/sbin'

    prtdiag_path = module.get_bin_path("prtdiag", opt_dirs=[platform_sbin])
    rc, out, err = module.run_command(prtdiag_path)
    """
    rc returns 1
    """
    if out:
        system_conf = out.split('\n')[0]

        # If you know of any other manufacturers whose names appear in
        # the first

# Generated at 2022-06-24 22:25:42.198121
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    sun_o_s_hardware_0 = SunOSHardware()
    sun_o_s_hardware_0.module.get_bin_path = Mock(return_value='/usr/sbin/prtdiag')
    sun_o_s_hardware_0.module.run_command = Mock(side_effect=[(0, 'System Configuration: Sun Microsystems  Sun-Fire-V210', ''), (0, 'System Configuration: sun4u   Sun-Fire-V210', ''), (0, 'System Configuration: Sun Microsystems  Sun-Fire-V240', '')])
    sun_o_s_hardware_0.populate()

    assert sun_o_s_hardware_0.dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert sun_o_s_hard