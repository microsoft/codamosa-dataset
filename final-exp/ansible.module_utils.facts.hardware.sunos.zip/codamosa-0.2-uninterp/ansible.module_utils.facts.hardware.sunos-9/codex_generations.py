

# Generated at 2022-06-17 00:22:26.928900
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:22:30.416883
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:22:41.042790
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockFactCollector(object):
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

    module = MockModule()
    fact_collector = MockFactCollector()
    hardware = SunOSHardware(module, fact_collector)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:22:46.149491
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:22:50.271878
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']


# Generated at 2022-06-17 00:23:00.626979
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:23:04.317652
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:23:13.762692
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    prtdiag_output = 'System Configuration: Fujitsu PRIMERGY RX300 S6'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'PRIMERGY RX300 S6'

    # Test for Oracle
    prtdiag_output = 'System Configuration: Oracle Corporation sun4v SPARC T5-2'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:25.149214
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:23:36.354436
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    devices = hardware.get_device_facts()
    assert devices['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert devices['devices']['sd0']['revision'] == '1.0'
    assert devices['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert devices['devices']['sd0']['size'] == '50.00 GB'
    assert devices['devices']['sd0']['vendor'] == 'ATA'
    assert devices['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-17 00:24:00.633472
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:06.082492
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:18.486378
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1:
    # System Configuration: Sun Microsystems sun4v
    # Expected result:
    # {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}
    out = 'System Configuration: Sun Microsystems sun4v'
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}

    # Test case 2:
    # System Configuration: Sun Microsystems sun4u
    # Expected result:
    # {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

# Generated at 2022-06-17 00:24:27.272242
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 16
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:29.482542
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']



# Generated at 2022-06-17 00:24:34.449553
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-17 00:24:40.842290
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V490'


# Generated at 2022-06-17 00:24:46.835234
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:24:54.711611
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for empty output
    module.run_command = Mock(return_value=(0, '', ''))
    assert hardware.get_device_facts() == {'devices': {}}

    # Test for valid output

# Generated at 2022-06-17 00:25:06.192057
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:25:49.072899
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1:
    # prtconf output:
    # Memory size: 8192 Megabytes
    #
    # swap -s output:
    # total: 8192k bytes allocated + 0k reserved = 8192k used, 5242872k available
    #
    # Expected output:
    # {'memtotal_mb': 8192, 'swapfree_mb': 5120, 'swaptotal_mb': 8192, 'swap_allocated_mb': 8, 'swap_reserved_mb': 0}
    module.run_command = MagicMock(return_value=(0, 'Memory size: 8192 Megabytes', ''))

# Generated at 2022-06-17 00:26:01.068296
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:04.717069
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:26:11.942575
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:23.237627
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_device_facts()
    assert 'devices' in facts
    assert 'sd0' in facts['devices']
    assert 'product' in facts['devices']['sd0']
    assert 'revision' in facts['devices']['sd0']
    assert 'serial' in facts['devices']['sd0']
    assert 'size' in facts['devices']['sd0']
    assert 'vendor' in facts['devices']['sd0']
    assert 'hard_errors' in facts['devices']['sd0']
    assert 'soft_errors' in facts['devices']['sd0']
    assert 'transport_errors' in facts['devices']['sd0']
    assert 'media_errors'

# Generated at 2022-06-17 00:26:32.288340
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:37.886258
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:26:46.034963
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:48.826665
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V440'


# Generated at 2022-06-17 00:26:56.994398
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a fake module
    module = type('', (), {})()

# Generated at 2022-06-17 00:28:19.848462
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:25.962198
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == hardware_facts['processor_count']
    assert hardware_facts['processor_cores'] == len(hardware_facts['processor'])
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swap_allocated_mb'] > 0
    assert hardware_facts['swap_reserved_mb'] > 0
    assert hardware_facts['system_vendor'] == 'Sun Microsystems'
    assert hardware_facts['product_name'] == 'Sun Fire V440'

# Generated at 2022-06-17 00:28:31.615808
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:28:43.425356
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = SunOSHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    hardware.populate()
    assert hardware.facts['ansible_processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware.facts['ansible_processor_cores'] == 'NA'
    assert hardware.facts['ansible_processor_count'] == 1
    assert hardware.facts['ansible_memtotal_mb'] == 16384
    assert hardware.facts['ansible_swapfree_mb'] == 16384
    assert hardware.facts['ansible_swaptotal_mb'] == 16384
    assert hardware.facts['ansible_swap_allocated_mb'] == 0

# Generated at 2022-06-17 00:28:51.168759
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts

# Generated at 2022-06-17 00:28:56.560434
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a sample output of kstat cpu_info

# Generated at 2022-06-17 00:29:04.633842
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock module class
    class MockModule:
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-17 00:29:14.547126
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:29:24.097093
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:29:32.583175
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the get_dmi_facts method of SunOSHardware class.
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a SunOSHardware object
    hardware_obj = SunOSHardware()

    # Create a BaseFactCollector object
    collector_obj = BaseFactCollector()

    # Set the 'ansible_machine' fact
    collector_obj.collect_fact('ansible_machine', 'i86pc')

    # Set the 'ansible_system' fact
    collector_obj.collect_fact('ansible_system', 'SunOS')

    # Set the 'ansible_distribution' fact
   