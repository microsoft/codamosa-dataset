

# Generated at 2022-06-17 00:22:30.257085
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:22:43.003876
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    module = MockModule()
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()

    assert module.run_command_calls == [['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time']]
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:22:51.165659
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:22:58.133447
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 2048
    assert facts['swapfree_mb'] == 2048
    assert facts['swaptotal_mb'] == 4096
    assert facts['swap_allocated_mb'] == 2048
    assert facts['swap_reserved_mb'] == 2048


# Generated at 2022-06-17 00:23:05.036607
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:23:10.963479
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:23:18.488368
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:23:24.360451
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-17 00:23:31.180538
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-17 00:23:34.323703
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']


# Generated at 2022-06-17 00:24:02.537412
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the method get_dmi_facts of class SunOSHardware.
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd == '/usr/bin/uname -i':
                return 0, 'sun4v', ''
            elif cmd == '/usr/platform/sun4v/sbin/prtdiag':
                return 0, 'System Configuration: Sun Microsystems sun4v\n', ''
            else:
                return 1, '', ''


# Generated at 2022-06-17 00:24:07.007542
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-17 00:24:18.588445
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['SUNW,SPARC-Enterprise']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:27.528477
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Create a SunOSHardware object
    sunos_hw = SunOSHardware()

    # Create a mock module
    mock_module = MagicMock()

    # Create a mock run_command method
    mock_run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))

    # Assign the mock method to the module
    mock_module.run_command = mock_run_command

    # Assign the mock module to the SunOSHardware object
    sunos_hw.module = mock_module

    # Call the get_uptime_facts method
    uptime_facts = sunos_hw.get_uptime_facts()

    # Assert that the uptime_seconds key is present in the returned dictionary
    assert 'uptime_seconds' in uptime_

# Generated at 2022-06-17 00:24:32.714795
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.52GHz']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-17 00:24:41.911809
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content

    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware()

    # Create a fake kstat output
    kstat_output = get_file_content('/usr/bin/kstat')

    # Create a fake kstat command
    def fake_run_command(cmd, *args, **kwargs):
        return (0, kstat_output, '')

    # Replace the run_command method of SunOSHardware with the fake one
    sunos_hardware.module.run_command = fake_run_command

    # Call the get_device_facts method of SunOSHardware
    device_facts = sunos_hardware.get_device_facts()

# Generated at 2022-06-17 00:24:52.910207
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert hardware_facts['memtotal_mb'] == 512
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-17 00:24:59.332260
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:25:05.581361
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:25:08.727359
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:25:55.944040
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:03.844550
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:10.921365
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'Sun Fire X4170 M3 Server'


# Generated at 2022-06-17 00:26:16.304121
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_device_facts()

# Generated at 2022-06-17 00:26:21.193725
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:24.029478
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:26:31.482679
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:26:43.437069
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a valid prtdiag output
    prtdiag_output = """System Configuration: Sun Microsystems sun4u
Sun Microsystems, sun4u, No Keyboard
OpenBoot 4.30.0, 4096 MB memory installed, Serial #10753426.
Ethernet address 0:3:ba:26:1:80, Host ID: 83261880.
"""
    module.run_command = MagicMock(return_value=(0, prtdiag_output, ""))
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test

# Generated at 2022-06-17 00:26:55.616630
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1200 MHz)']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T4-1'

# Generated at 2022-06-17 00:27:02.418468
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-17 00:28:34.361519
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.sunos_hardware = SunOSHardware()

        def test_get_uptime_facts(self):
            # mock the time.time() method
            time.time = lambda: 1548249689
            uptime_facts = self.sunos_hardware.get_uptime_facts()
            self.assertEqual(uptime_facts['uptime_seconds'], 1548249689)

    unittest.main()

# Generated at 2022-06-17 00:28:43.998613
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:54.729957
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a prtdiag output that contains a known vendor name
    # and a product name.
    prtdiag_output = 'System Configuration: Sun Microsystems sun4u\n'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test with a prtdiag output that contains a known vendor name
    # but no product name.
    prtdiag_output = 'System Configuration: Sun Microsystems\n'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)

# Generated at 2022-06-17 00:29:00.437485
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:29:10.714642
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    import time
    import os

    # Create a fake kstat file
    kstat_file = '/tmp/kstat'
    kstat_content = 'unix:0:system_misc:boot_time    1548249689'
    with open(kstat_file, 'w') as f:
        f.write(kstat_content)

    # Create a fake kstat command
    kstat_cmd = '/tmp/kstat_cmd'
    kstat_cmd_content = '#!/bin/sh\ncat %s' % kstat_file

# Generated at 2022-06-17 00:29:16.033190
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'module: cpu_info\nbrand\nclock_MHz\nimplementation\nchip_id\n', ''))
    sunos_hardware = SunOSHardware(module)
    cpu_facts = sunos_hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['cpu_info']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:29:21.929292
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # mock kstat output
    module.run_command = Mock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))

    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:29:31.622802
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:29:42.257144
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    # Create a SunOSHardware object
    sunos_hw = SunOSHardware()

    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))})

    # Set the module as a class attribute
    sunos_hw.module = module

    # Call the get_uptime_facts method
    uptime_facts = sunos_hw.get_uptime_facts()

    # Assert that the uptime_seconds key is present in the returned dictionary
    assert 'uptime_seconds' in uptime_facts

    # Assert that the value of the uptime_seconds key is an integer
    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-17 00:29:45.481243
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0
