

# Generated at 2022-06-17 00:22:16.995914
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0
    assert cpu_facts['processor']


# Generated at 2022-06-17 00:22:25.440097
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-17 00:22:29.910619
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'][0] == 'Genuine Intel(R) CPU 0000 @ 2.00GHz'


# Generated at 2022-06-17 00:22:39.143586
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:22:49.415534
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines

    # Mock the time.time() method to return a fixed value
    time.time = lambda: 1548249689

    # Mock the get_file_content() method to return a fixed value
    get_file_content = lambda x: 'unix:0:system_misc:boot_time    1548249689'

    # Mock the get_mount_size() method to return a fixed value

# Generated at 2022-06-17 00:22:54.099097
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-17 00:23:02.530288
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import mock_module
    from ansible.module_utils.facts.utils import MockModule

    module = mock_module(MockModule)
    sunos_hardware = SunOSHardware(module)

    # mock kstat output
    module.run_command.return_value = (0, 'unix:0:system_misc:boot_time    1548249689', '')
    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

    # mock kstat output
    module.run_command.return_value = (1, '', '')
    uptime_

# Generated at 2022-06-17 00:23:13.619741
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC T5-2', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v SPARC T5-2'

    # Test for Sun Microsystems
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u SPARC Enterprise T5120', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor']

# Generated at 2022-06-17 00:23:24.309659
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert device_facts['devices']['sd0']['revision'] == '1.0'
    assert device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert device_facts['devices']['sd0']['size'] == '50.00 GB'
    assert device_facts['devices']['sd0']['vendor'] == 'ATA'
    assert device_facts['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-17 00:23:36.232640
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert len(device_facts['devices']) > 0
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts

# Generated at 2022-06-17 00:23:57.950869
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:24:04.850974
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    devices = hardware.get_device_facts()['devices']
    assert 'sd0' in devices
    assert 'sd1' in devices
    assert 'sd2' in devices
    assert 'sd3' in devices
    assert 'sd4' in devices
    assert 'sd5' in devices
    assert 'sd6' in devices
    assert 'sd7' in devices
    assert 'sd8' in devices
    assert 'sd9' in devices
    assert 'sd10' in devices
    assert 'sd11' in devices
    assert 'sd12' in devices
    assert 'sd13' in devices
    assert 'sd14' in devices
    assert 'sd15' in devices
    assert 'sd16' in devices
    assert 'sd17' in devices

# Generated at 2022-06-17 00:24:14.464275
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Mock the run_command method

# Generated at 2022-06-17 00:24:22.971220
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:33.305340
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockFactCollector(object):
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

    module = MockModule()
    fact_collector = MockFactCollector()
    sunos_hardware = SunOSHardware(module, fact_collector)
    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:24:39.370126
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:52.413903
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name']

# Generated at 2022-06-17 00:25:03.524810
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import MockModule

    # Create a mock module
    module = MockModule(
        params={},
        ansible_facts={'platform': 'SunOS'},
        check_mode=False
    )

    # Create a mock run_command method
    def mock_run_command(cmd, check_rc=True):
        if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
            return (0, str(int(time.time()) - 10), '')
        else:
            return (0, '', '')

    module.run_command = mock_run_command

    # Create a SunOSHardware object
    sunos_hard

# Generated at 2022-06-17 00:25:11.415291
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a SunOSHardware object
    sunos_hardware_obj = SunOSHardware()

    # Create a mock module
    mock_module = MagicMock()

    # Create a mock run_command method
    mock_run_command = MagicMock()

    # Create a mock prtdiag output
    mock_prtdiag_output = 'System Configuration: Sun Microsystems sun4u\n'

    # Assign the mock run_command method to the mock module
    mock_module.run_command = mock_run_command

    # Assign the mock prtdiag output to the mock run_command method
    mock_run_command.return_value = (0, mock_prtdiag_output, '')

    # Assign the mock module to the SunOSHardware object
    sunos_hardware_obj.module = mock

# Generated at 2022-06-17 00:25:13.333518
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()

# Generated at 2022-06-17 00:25:52.598627
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-17 00:25:59.034165
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:02.893118
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz)']


# Generated at 2022-06-17 00:26:08.312418
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/kstat')
    module.get_file_content = MagicMock(return_value='/etc/mnttab')
    module.run_command_environ_update = {}
    module.params = {}
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.check_mode = False
    module.debug = False
    module.deprecate = MagicMock()
    module.warn = MagicMock()
    module.fail_json = MagicMock()
    module.exit_json = MagicMock()

# Generated at 2022-06-17 00:26:14.726171
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz', 'SPARC64-VII (chipid 1, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_cores'] == 8
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-17 00:26:19.901038
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'


# Generated at 2022-06-17 00:26:30.460472
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert isinstance(device_facts, dict)
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert len(device_facts['devices']) > 0
    assert isinstance(device_facts['devices']['sd0'], dict)
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:37.085206
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.53GHz']


# Generated at 2022-06-17 00:26:45.865968
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:57.046714
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd == '/usr/bin/kstat -p unix:0:system_misc:boot_time':
                return 0, str(int(time.time() - datetime.timedelta(days=1).total_seconds())), ''
            else:
                return 1, '', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(1)

# Generated at 2022-06-17 00:27:52.837538
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a valid prtdiag output

# Generated at 2022-06-17 00:28:01.587244
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:28:07.525183
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.sunos_hardware = SunOSHardware()

        def test_get_uptime_facts(self):
            # mock the kstat command output
            boot_time = int(time.time()) - 100
            self.sunos_hardware.module.run_command = lambda x: (0, 'unix:0:system_misc:boot_time\t%s' % boot_time, '')
            uptime_facts = self.sunos_hardware.get_uptime_facts()
            self.assertEqual(uptime_facts['uptime_seconds'], 100)

    unittest

# Generated at 2022-06-17 00:28:12.468430
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:28:16.092105
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.get_memory_facts()['memtotal_mb'] == 16384


# Generated at 2022-06-17 00:28:23.909322
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:28:26.885087
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'VirtualBox'

# Generated at 2022-06-17 00:28:38.836951
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:28:46.036241
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class SunOSHardware.
    """
    # Create a SunOSHardware object
    sunos_hw = SunOSHardware()

    # Create a mock module
    mock_module = MagicMock()

    # Create a mock command
    mock_command = MagicMock()

    # Set the command output

# Generated at 2022-06-17 00:28:51.338051
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:30:20.690916
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:30:30.451868
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VI @ 2800MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'
    assert hardware

# Generated at 2022-06-17 00:30:38.273521
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    # Create a fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))

    # Create a fake hardware object
    hardware = SunOSHardware(module)

    # Create a fake cpu_facts
    cpu_facts = {
        'processor': ['Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'],
        'processor_cores': 'NA',
        'processor_count': 2,
    }

    # Test get_cpu_facts
    assert hardware.get_cpu_facts() == cpu_facts



# Generated at 2022-06-17 00:30:48.742594
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(1)
            return 1548249689 + 60

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.time = MockTime()
            self.sunos_hardware = SunOSHardware

# Generated at 2022-06-17 00:30:54.215240
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:31:02.253209
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:31:09.137956
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert 'memtotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'swap_allocated_mb' in hardware_facts
    assert 'swap_reserved_mb' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'system_vendor' in hardware_facts
    assert 'product_name' in hardware_facts
    assert 'devices' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'mounts' in hardware_

# Generated at 2022-06-17 00:31:15.646650
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:31:20.935072
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:31:30.873498
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'