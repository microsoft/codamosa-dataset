

# Generated at 2022-06-17 00:22:29.990910
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test for method get_dmi_facts of class SunOSHardware
    """
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC T4-1', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v SPARC T4-1'

    # Test for Sun Microsystems
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u SPARC Enterprise T5120', ''))

# Generated at 2022-06-17 00:22:37.441068
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5220'

# Generated at 2022-06-17 00:22:47.958821
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with prtdiag output that matches the regexp
    prtdiag_output = """System Configuration: Sun Microsystems sun4u
Memory size: 32768 Megabytes
"""
    module.run_command = Mock(return_value=(0, prtdiag_output, ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test with prtdiag output that does not match the regexp
    prtdiag_output = """System Configuration: Sun Microsystems sun4u
Memory size: 32768 Megabytes
"""
    module.run_

# Generated at 2022-06-17 00:23:00.391733
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content, get_mount_size
    from ansible.module_utils.facts.timeout import timeout
    from ansible.module_utils.six.moves import reduce
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import zip
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.urls import open_url
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-17 00:23:05.879986
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts


# Generated at 2022-06-17 00:23:16.074383
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1: prtdiag returns the following output
    # System Configuration: Sun Microsystems sun4u
    # System clock frequency: 200 MHz
    # Memory size: 8192 Megabytes
    # System uptime: 1 day(s), 1:48
    #
    # System Configuration: Sun Microsystems sun4u
    # System clock frequency: 200 MHz
    # Memory size: 8192 Megabytes
    # System uptime: 1 day(s), 1:48
    #
    # System Configuration: Sun Microsystems sun4u
    # System clock frequency: 200 MHz
    # Memory size: 8192 Megabytes
    # System uptime: 1 day(s), 1:48
    #
    # System Configuration: Sun Microsystems sun4

# Generated at 2022-06-17 00:23:29.234233
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware()

    # Create a mock module
    mock_module = MagicMock()

    # Create a mock run_command method
    mock_run_command = MagicMock()

    # Set the return value of the mock run_command method
    mock_run_command.return_value = (0, 'System Configuration: Sun Microsystems sun4u', '')

    # Set the mock run_command method to the mock module
    mock_module.run_command = mock_run_command

    # Set the mock module to the SunOSHardware object
    sunos_hardware.module = mock_module

    # Call the get_dmi_facts method of the SunOSHardware object
    dmi_facts = sunos_hardware.get_dmi_facts()

    # Ass

# Generated at 2022-06-17 00:23:38.858298
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:43.055713
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class MockTime(object):
        def __init__(self, time):
            self.time = time

        def time(self):
            return self.time

    class TestSunOSHardware(unittest.TestCase):
        def test_get_uptime_facts(self):
            # test with valid kstat output
            module = MockModule(0, 'unix:0:system_misc:boot_time    1548249689', '')
            time = MockTime(1548249690)
           

# Generated at 2022-06-17 00:23:45.511824
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:24:01.971982
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware


# Generated at 2022-06-17 00:24:09.658335
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:24:12.710899
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware


# Generated at 2022-06-17 00:24:22.398751
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:24:29.350256
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts



# Generated at 2022-06-17 00:24:41.057398
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content

    # Mock the kstat command output
    kstat_output = 'unix:0:system_misc:boot_time    1548249689'
    kstat_command = ['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time']

    # Mock the time.time() function
    time_time = 1548249700

    # Mock the module.run_command function
    def run_command(self, cmd, check_rc=True):
        if cmd == kstat_command:
            return 0, kstat_output, ''
        else:
            return 1, '', ''

    # Mock the get_file_

# Generated at 2022-06-17 00:24:52.844273
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:24:59.234573
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:25:02.801241
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']


# Generated at 2022-06-17 00:25:11.701830
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert hardware_obj.facts['processor_cores'] == 'NA'
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['memtotal_mb'] == 16384
    assert hardware_obj.facts['swapfree_mb'] == 16384
    assert hardware_obj.facts['swaptotal_mb'] == 16384
    assert hardware_obj.facts['swap_allocated_mb'] == 0
    assert hardware_obj.facts['swap_reserved_mb'] == 0

# Generated at 2022-06-17 00:25:49.220845
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'][0] == 'SPARC64-VII+ @ 2.53GHz'
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 32
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:25:56.509519
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-17 00:25:58.414513
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_device_facts()


# Generated at 2022-06-17 00:26:05.044498
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 200MHz']


# Generated at 2022-06-17 00:26:15.639670
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert hardware.facts['processor_cores'] == 16
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] == 32768
    assert hardware.facts['swapfree_mb'] == 1023
    assert hardware.facts['swaptotal_mb'] == 1023
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-2'

# Generated at 2022-06-17 00:26:23.723880
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    module.run_command_values['prtdiag'] = (0, 'System Configuration: Fujitsu M10-4S\n', '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'M10-4S'

    # Test for Oracle Corporation
    module.run_command_values['prtdiag'] = (0, 'System Configuration: Oracle Corporation sun4v SPARC Enterprise T5240\n', '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:29.414449
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:36.527414
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz)']
    assert hardware_obj.facts['processor_cores'] == 2
    assert hardware_obj.facts['processor_count'] == 2
    assert hardware_obj.facts['memtotal_mb'] == 8192
    assert hardware_obj.facts['swapfree_mb'] == 8192
    assert hardware_obj.facts['swaptotal_mb'] == 8192
    assert hardware_obj.facts['swap_allocated_mb'] == 0
    assert hardware_obj.facts['swap_reserved_mb'] == 0

# Generated at 2022-06-17 00:26:39.941110
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:26:45.393213
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with kstat output from a SPARC T7-1

# Generated at 2022-06-17 00:28:01.494187
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'



# Generated at 2022-06-17 00:28:07.478268
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:28:16.171341
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts


# Generated at 2022-06-17 00:28:23.730447
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-17 00:28:29.317708
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_device_facts()

# Generated at 2022-06-17 00:28:32.794484
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    cpu_facts = SunOSHardware().get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1

# Generated at 2022-06-17 00:28:42.735856
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test output of command /usr/bin/kstat cpu_info

# Generated at 2022-06-17 00:28:53.185121
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a single CPU
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Intel(r) Xeon(r) CPU E5-2620 v3 @ 2.40GHz']

    # Test with multiple CPUs
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2
    assert cpu_facts['processor_cores'] == 2

# Generated at 2022-06-17 00:29:00.743630
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC-T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:29:08.531621
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 16384
    assert memory_facts['swapfree_mb'] == 1023
    assert memory_facts['swaptotal_mb'] == 1024
    assert memory_facts['swap_allocated_mb'] == 1024
    assert memory_facts['swap_reserved_mb'] == 1024



# Generated at 2022-06-17 00:31:38.147439
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts


# Generated at 2022-06-17 00:31:42.027915
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5220'


# Generated at 2022-06-17 00:31:52.539733
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockTime(object):
        def __init__(self):
            self.time_returns = []

        def time(self):
            return self.time_returns.pop(0)

    module = MockModule()
    time = MockTime()

    # Test 1:
    # kstat returns 0
    # time returns 1548249689

# Generated at 2022-06-17 00:31:59.218871
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0
