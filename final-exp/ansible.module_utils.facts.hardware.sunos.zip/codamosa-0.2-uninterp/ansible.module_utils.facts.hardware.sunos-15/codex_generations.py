

# Generated at 2022-06-17 00:22:34.543199
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']


# Generated at 2022-06-17 00:22:38.505960
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware


# Generated at 2022-06-17 00:22:48.878245
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test data

# Generated at 2022-06-17 00:22:53.378670
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:23:05.628249
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a valid prtdiag output

# Generated at 2022-06-17 00:23:15.934089
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, '', ''))})
    module.get_bin_path = MagicMock(return_value='/usr/sbin/prtdiag')
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u', ''))

    # Create a SunOSHardware object
    sunos_hw = SunOSHardware(module)

    # Get dmi facts
    dmi_facts = sunos_hw.get_dmi_facts()

    # Assert that the dmi facts are as expected
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-17 00:23:20.279590
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:23:28.252235
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:23:34.016737
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:23:34.846403
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'

# Generated at 2022-06-17 00:24:05.055921
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC T4-2 Server', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v SPARC T4-2 Server'

    # Test for Sun Microsystems
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u SPARC Enterprise T5120 Server', ''))
    dmi_facts = hardware.get_dmi_facts()

# Generated at 2022-06-17 00:24:11.868650
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:21.862057
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockFactCollector(object):
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

    module = MockModule()
    fact_collector = MockFactCollector()
    hardware = SunOSHardware(module, fact_collector)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:24:30.753041
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:41.215953
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC-Enterprise-T5120 @ 1665MHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:52.877592
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:25:04.191504
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware()

    # Create a mock module object
    module = type('', (), {})()

    # Create a mock run_command method
    def run_command(self, cmd):
        return 0, 'System Configuration: Sun Microsystems sun4u', ''

    # Set the run_command method of the module object to the mock method
    module.run_command = run_command.__get__(module)

    # Set the module object of the SunOSHardware object to the mock module object
    sunos_hardware.module = module

    # Call the get_dmi_facts method of the SunOSHardware object
    dmi_facts = sunos_hardware.get_dmi_facts()

    # Assert that the dmi_facts dictionary contains the expected values

# Generated at 2022-06-17 00:25:12.626403
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:25:16.261559
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()

# Generated at 2022-06-17 00:25:20.764993
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:26:05.223575
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:26:08.990490
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()

# Generated at 2022-06-17 00:26:16.630161
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:24.298055
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def run_command(self, command):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockFactCollector:
        def __init__(self):
            self.facts = {'platform': 'SunOS'}

    class MockFacts:
        def __init__(self):
            self.collector = MockFactCollector()

    class MockSunOSHardware:
        def __init__(self):
            self.module = MockModule()
            self.facts = MockFacts()

    sunos_hardware = MockSunOSHardware()
    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)

# Generated at 2022-06-17 00:26:31.810096
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'][0] == 'Intel(r) Xeon(r) CPU E5-2680 v3 @ 2.50GHz'


# Generated at 2022-06-17 00:26:36.787469
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:26:45.954366
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector

    class MockModule(object):
        def __init__(self):
            self.run_command_environ_update = {}

        def run_command(self, args, check_rc=True):
            if args[0] == '/usr/bin/kstat':
                return 0, get_file_content('./unit/modules/ansible/module_utils/facts/hardware/sunos/kstat_system_misc_boot_time'), ''
            else:
                return 0, '', ''



# Generated at 2022-06-17 00:26:57.167472
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import time

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def run_command(self, cmd):
            self.run_command_calls += 1
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class MockTime(object):
        def __init__(self):
            self.time_calls = 0
            self.time_return = 0

        def time(self):
            self.time_calls += 1
            return self.time_return

    module = MockModule()
    time = MockTime()

    # Test with

# Generated at 2022-06-17 00:27:05.579158
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with no input
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == []
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 0

    # Test with input
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': 'i86pc'})
    assert cpu_facts['processor'] == ['Intel(r) Xeon(r) CPU E5-2680 v3 @ 2.50GHz']
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-17 00:27:09.959775
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:08.038907
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command.return_value = (0, 'System Configuration: VMware, Inc. VMware Virtual Platform', '')
    sunos_hw = SunOSHardware(module)
    dmi_facts = sunos_hw.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'



# Generated at 2022-06-17 00:28:16.803549
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    sunos_hardware = SunOSHardware(module)
    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:28:23.851096
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1
    out = '''module: cpu_info
instance: 0
class: misc
chip_id   0
clock_MHz  1200
cpu_fru    <unknown>
cpu_type   i386
current_clock_Hz  1200000000
device_ID  0
implementation  i386
pg_id   0
status   ok

module: cpu_info
instance: 1
class: misc
chip_id   0
clock_MHz  1200
cpu_fru    <unknown>
cpu_type   i386
current_clock_Hz  1200000000
device_ID  1
implementation  i386
pg_id   0
status   ok
'''

# Generated at 2022-06-17 00:28:32.018848
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise'


# Generated at 2022-06-17 00:28:43.230705
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    hardware = SunOSHardware(module)
    hardware.get_device_facts()

    module.run_command.assert_called_with(['/usr/bin/kstat', '-p', 'sderr:::Product', 'sderr:::Revision', 'sderr:::Serial No', 'sderr:::Size', 'sderr:::Vendor', 'sderr:::Hard Errors', 'sderr:::Soft Errors', 'sderr:::Transport Errors', 'sderr:::Media Error', 'sderr:::Predictive Failure Analysis', 'sderr:::Illegal Request'])

# Generated at 2022-06-17 00:28:54.660064
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a SunOSHardware object
    hardware = SunOSHardware()

    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, '', ''))})
    hardware.module = module

    # Create a mock facts
    facts = {}
    facts['devices'] = {}

    # Call the get_device_facts method
    hardware.get_device_facts()

    # Assert that the run_command method was called with the correct arguments

# Generated at 2022-06-17 00:28:57.291553
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:28:59.645329
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()



# Generated at 2022-06-17 00:29:10.052574
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:29:17.240524
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import HardwareCollector


# Generated at 2022-06-17 00:31:09.974661
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a SunOSHardware object
    sunos_hw = SunOSHardware()

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v', ''))})
    sunos_hw.module = mock_module

    # Create a mock collected_facts
    collected_facts = {}

    # Call the method get_dmi_facts
    dmi_facts = sunos_hw.get_dmi_facts(collected_facts)

    # Assert that the method run_command of the mock module was called with the expected parameters
    mock_module.run_command.assert_called_with('/usr/bin/uname -i')

    # Assert that the method get_dmi_facts returns the

# Generated at 2022-06-17 00:31:19.810866
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with empty string
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {}

    # Test with a valid string
    hardware.module.run_command = lambda x: (0, 'System Configuration: Sun Microsystems sun4u', '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4u'}

    # Test with a valid string
    hardware.module.run_command = lambda x: (0, 'System Configuration: QEMU Standard PC (i440FX + PIIX, 1996)', '')
    dmi_facts = hardware.get_d

# Generated at 2022-06-17 00:31:28.705192
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    hardware.module = MagicMock()
    hardware.module.run_command.return_value = (0, 'System Configuration: VMware, Inc. VMware Virtual Platform', '')
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

# Generated at 2022-06-17 00:31:36.752459
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:31:43.179328
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_results = []

        def run_command(self, args):
            return self.run_command_results.pop(0)

    class MockTime(object):
        def __init__(self):
            self.time_results = []

        def time(self):
            return self.time_results.pop(0)

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.time = MockTime()
            self.hardware = SunOSHardware(self.module)
            self.hardware.time = self.time

        def test_get_uptime_facts(self):
            self.module.run_

# Generated at 2022-06-17 00:31:53.450899
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    prtdiag_output = 'System Configuration:  Fujitsu PRIMERGY RX300 S6'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'PRIMERGY RX300 S6'

    # Test for Oracle Corporation
    prtdiag_output = 'System Configuration:  Oracle Corporation sun4v SPARC T5-2'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_

# Generated at 2022-06-17 00:31:58.742039
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V440'

# Generated at 2022-06-17 00:32:04.050485
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'

# Generated at 2022-06-17 00:32:08.332195
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])