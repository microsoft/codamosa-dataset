

# Generated at 2022-06-17 00:22:30.069475
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the method get_dmi_facts of class SunOSHardware
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a FactsCollector object
    facts_collector = FactsCollector()

    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware(facts_collector)

    # Create a mock module
    mock_module = Mock()

    # Set the module's run_command method to return a specific value
    mock_module.run_command.return_value = (0, 'System Configuration: VMware, Inc. VMware Virtual Platform', '')

    # Set the module attribute of the SunOSHardware

# Generated at 2022-06-17 00:22:39.371889
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:22:49.599149
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 2048
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:23:00.538159
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-17 00:23:04.909241
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] >= 1
    assert cpu_facts['processor_cores'] >= 1
    assert cpu_facts['processor']


# Generated at 2022-06-17 00:23:15.330852
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:23:27.883721
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()
    assert hardware_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SPARC T7-1'
    assert hardware_facts

# Generated at 2022-06-17 00:23:31.603365
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:23:34.718907
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:23:39.323237
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC T4 (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-17 00:24:03.990137
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VI @ 2400MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'

# Generated at 2022-06-17 00:24:10.207525
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == ['SPARC64-X+ @ 2.52GHz']
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-17 00:24:17.834528
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:23.730082
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 8192
    assert facts['swapfree_mb'] == 8192
    assert facts['swaptotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0


# Generated at 2022-06-17 00:24:35.468714
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SUNW,SPARC-Enterprise']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 4096
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC-Enterprise'

# Generated at 2022-06-17 00:24:40.256895
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-17 00:24:52.770223
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 4096
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-17 00:24:58.341860
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['SUNW,SPARC-Enterprise']


# Generated at 2022-06-17 00:25:00.785159
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:25:10.206058
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Test data
    test_data = {
        'devices': {
            'sda': {
                'product': 'VBOX HARDDISK',
                'revision': '1.0',
                'serial': 'VB0ad2ec4d-074a',
                'size': '53687091200',
                'vendor': 'ATA',
                'hard_errors': '0',
                'soft_errors': '0',
                'transport_errors': '0',
                'media_errors': '0',
                'predictive_failure_analysis': '0',
                'illegal_request': '6',
            },
        },
    }

    # Test code
    test_obj = SunOSHardware()
    result = test_obj.get_device_facts()

    # Test assertions
    assert result

# Generated at 2022-06-17 00:25:46.214002
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']


# Generated at 2022-06-17 00:25:48.740864
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:25:51.216516
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:26:02.272757
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            if args == ['/usr/bin/kstat', '-p', 'unix:0:system_misc:boot_time']:
                return 0, 'unix:0:system_misc:boot_time\t1548249689', ''
            else:
                return 1, '', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(1)
            return 1548249689

    module = MockModule()
    time = MockTime()

# Generated at 2022-06-17 00:26:07.943611
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Fujitsu FUJITSU Server PRIMERGY RX2530 M2', ''))
    assert hardware.get_dmi_facts() == {'system_vendor': 'Fujitsu', 'product_name': 'FUJITSU Server PRIMERGY RX2530 M2'}

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC T5-2', ''))

# Generated at 2022-06-17 00:26:16.530068
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:19.224189
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test that the populate method returns a dictionary
    assert isinstance(hardware.populate(), dict)

# Generated at 2022-06-17 00:26:30.328793
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'
   

# Generated at 2022-06-17 00:26:42.521974
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']
    assert device_facts['devices']['sd0']
    assert device_facts['devices']['sd0']['product']
    assert device_facts['devices']['sd0']['revision']
    assert device_facts['devices']['sd0']['serial']
    assert device_facts['devices']['sd0']['size']
    assert device_facts['devices']['sd0']['vendor']
    assert device_facts['devices']['sd0']['hard_errors']
    assert device_facts['devices']['sd0']['soft_errors']

# Generated at 2022-06-17 00:26:49.782165
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.4GHz']


# Generated at 2022-06-17 00:28:05.039839
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['SUNW,SPARC-Enterprise']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:09.205455
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0



# Generated at 2022-06-17 00:28:19.944502
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:23.764019
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:34.821917
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, '', ''))})()
    module.run_command.return_value = (0, 'System Configuration: VMware, Inc. VMware Virtual Platform', '')

    # Create a SunOSHardware object
    sunos_hw = SunOSHardware(module)

    # Call the get_dmi_facts method
    dmi_facts = sunos_hw.get_dmi_facts()

    # Assert that the method returns the expected dictionary
    assert dmi_facts == {'system_vendor': 'VMware, Inc.', 'product_name': 'VMware Virtual Platform'}

# Generated at 2022-06-17 00:28:44.255494
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:28:54.794570
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule:
        def run_command(self, cmd):
            return 0, "unix:0:system_misc:boot_time    1548249689", ""

    class MockTime:
        def time(self):
            return 1548249689 + 3600

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.time = MockTime()
            self.sunos_hardware = SunOSHardware(self.module, self.time)

        def test_get_uptime_facts(self):
            uptime_facts = self.sunos_hardware.get_uptime_facts()
            self.assertEqual(uptime_facts['uptime_seconds'], 3600)

    unitt

# Generated at 2022-06-17 00:29:04.490699
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test 1
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-X+ @ 2.52GHz']

    # Test 2
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-X+ @ 2.52GHz']



# Generated at 2022-06-17 00:29:14.423976
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:29:24.070465
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['Genuine Intel(R) CPU @ 2.00GHz']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:32:13.481470
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    # Create a SunOSHardware object
    sunoshw_obj = SunOSHardware(module)

    # Run the populate method
    sunoshw_obj.populate()

    # Check the result
    assert sunoshw_obj.facts['processor_cores'] == 'NA'
    assert sunoshw_obj.facts['processor_count'] == 1
    assert sunoshw_obj.facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert sunoshw_obj.facts['memtotal_mb'] == 1024
    assert sunoshw_obj.facts['swapfree_mb'] == 1023