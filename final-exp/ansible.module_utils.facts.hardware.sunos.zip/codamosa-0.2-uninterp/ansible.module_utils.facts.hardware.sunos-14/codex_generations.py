

# Generated at 2022-06-17 00:22:31.484792
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swap_allocated_mb']
    assert hardware_facts['swap_reserved_mb']
    assert hardware_facts['system_vendor']
    assert hardware_facts['product_name']
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-17 00:22:38.643885
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU T2400 @ 1.83GHz']


# Generated at 2022-06-17 00:22:43.399812
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V440'


# Generated at 2022-06-17 00:22:52.118443
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC-Enterprise-T5120 @ 1350MHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:05.543441
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    hardware.populate()

    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 4
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:12.220896
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:16.245665
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:22.452977
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.53GHz']


# Generated at 2022-06-17 00:23:24.261213
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    """
    Constructor of class SunOSHardwareCollector can be called.
    """
    SunOSHardwareCollector()

# Generated at 2022-06-17 00:23:36.191146
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content

    # Mock kstat output
    kstat_output = 'unix:0:system_misc:boot_time    1548249689'

    # Mock kstat command
    def mock_run_command(self, cmd):
        return 0, kstat_output, ''

    # Mock time.time()
    def mock_time():
        return 1548249690

    # Mock get_file_content
    def mock_get_file_content(file_name):
        return kstat_output

    # Mock module
    class MockModule:
        def __init__(self):
            self.run_command = mock_run_command

# Generated at 2022-06-17 00:23:59.002213
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-T1 @ 1200MHz']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1



# Generated at 2022-06-17 00:24:04.273621
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:11.519342
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:22.805637
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if module.params['gather_subset'] == ['!all']:
        module.params['gather_subset'] = ['all']

    # Get the hardware instance
    hardware = SunOSHardware(module)

    # Disabling gathering of facts
    hardware.collector.collect_subset = []

    # Populate the facts
    hardware.populate()

    # Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-17 00:24:30.841680
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:41.215949
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert isinstance(device_facts, dict)
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert len(device_facts['devices']) > 0
    for device in device_facts['devices']:
        assert isinstance(device_facts['devices'][device], dict)
        assert 'product' in device_facts['devices'][device]
        assert 'revision' in device_facts['devices'][device]
        assert 'serial' in device_facts['devices'][device]
        assert 'size' in device_facts['devices'][device]
        assert 'vendor' in device_facts['devices'][device]


# Generated at 2022-06-17 00:24:45.352661
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:24:53.386523
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4v', ''))

    # Create a SunOSHardware object
    sunos_hw = SunOSHardware(module)

    # Call the method get_dmi_facts
    dmi_facts = sunos_hw.get_dmi_facts()

    # Assert that the method get_dmi_facts returns the expected dictionary
    assert dmi_facts == {'system_vendor': 'Sun Microsystems', 'product_name': 'sun4v'}

# Generated at 2022-06-17 00:25:04.741968
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a fake module
    setattr(module, 'run_command', fake_run_command)

    # Create a instance of SunOSHardware class
    hardware_obj = SunOSHardware(module)

    # Call method get_memory_facts of SunOSHardware class
    memory_facts = hardware_obj.get_memory_facts()

    # Assertion for method get_memory_facts of class SunOSHardware
    assert memory_facts['memtotal_mb'] == 8192
    assert memory_facts['swapfree_mb'] == 8192
    assert memory_facts['swaptotal_mb'] == 16384
    assert memory_facts['swap_allocated_mb'] == 8192

# Generated at 2022-06-17 00:25:09.937221
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:25:55.914629
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert hardware.facts['memtotal_mb'] == 2048
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Sun Microsystems'
    assert hardware.facts['product_name'] == 'Sun Fire V440'
    assert hardware.facts['devices']['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-17 00:26:03.829547
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:15.565956
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a sample output of kstat cpu_info
    out = """module: cpu_info
instance: 0
class: misc
chip_id   0
clock_MHz  2400
implementation  sparc
model  sparcv9
brand  sun4u
"""
    cpu_facts = hardware.get_cpu_facts(collected_facts={'ansible_machine': 'i86pc'})
    assert cpu_facts['processor'] == ['sparcv9 @ 2400MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1

    # Test with a sample output of kstat cpu_info

# Generated at 2022-06-17 00:26:23.696802
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a prtdiag output that contains a vendor name

# Generated at 2022-06-17 00:26:34.800645
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']
    assert device_facts['devices']['sd0']
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert device_facts['devices']['sd0']['revision'] == '1.0'
    assert device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert device_facts['devices']['sd0']['size'] == '50.00 GB'
    assert device_facts['devices']['sd0']['vendor'] == 'ATA'

# Generated at 2022-06-17 00:26:44.592515
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.timeout import timeout

    # Create a fake kstat output file
    kstat_output = 'unix:0:system_misc:boot_time    1548249689'
    kstat_file = '/tmp/kstat_output'
    with open(kstat_file, 'w') as f:
        f.write(kstat_output)

    # Create a fake kstat command
    kstat_cmd = '/usr/bin/kstat -p unix:0:system_misc:boot_time'
    kstat_cmd_file

# Generated at 2022-06-17 00:26:48.131832
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:26:56.630837
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert device_facts['devices']['sd0']['revision'] == '1.0'
    assert device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert device_facts['devices']['sd0']['size'] == '50.00 GB'
    assert device_facts['devices']['sd0']['vendor'] == 'ATA'
    assert device_facts['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-17 00:27:01.651850
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:27:07.094348
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if module.params['gather_subset'] == ['!all']:
        module.params['gather_subset'] = ['all']

    # Get the hardware instance
    hardware = SunOSHardware(module)

    # Disabling 'all' subset to avoid timeout
    if 'all' in module.params['gather_subset']:
        module.params['gather_subset'].remove('all')

    # Populate the facts
    facts = hardware.populate()

    # Set the facts
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-17 00:28:39.129098
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

    # Create a SunOSHardware object
    hardware = SunOSHardware(module)

    # Create a dictionary of expected results

# Generated at 2022-06-17 00:28:43.087055
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2


# Generated at 2022-06-17 00:28:50.251110
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:54.440033
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 1024
    assert facts['swapfree_mb'] == 512
    assert facts['swaptotal_mb'] == 1024
    assert facts['swap_allocated_mb'] == 512
    assert facts['swap_reserved_mb'] == 512



# Generated at 2022-06-17 00:29:00.402531
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swap_allocated_mb' in memory_facts
    assert 'swap_reserved_mb' in memory_facts


# Generated at 2022-06-17 00:29:10.677855
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a prtdiag output that contains a vendor name and a product name
    prtdiag_output = 'System Configuration: Sun Microsystems sun4u\n'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test with a prtdiag output that contains a vendor name and a product name
    # with spaces
    prtdiag_output = 'System Configuration: Sun Microsystems sun4u sunfire v240\n'

# Generated at 2022-06-17 00:29:15.671093
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU 0000 @ 2.00GHz']


# Generated at 2022-06-17 00:29:24.173667
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0

# Generated at 2022-06-17 00:29:32.677608
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:29:43.352853
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})