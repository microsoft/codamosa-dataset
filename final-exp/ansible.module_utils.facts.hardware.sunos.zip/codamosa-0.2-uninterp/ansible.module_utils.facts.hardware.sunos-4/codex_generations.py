

# Generated at 2022-06-17 00:22:28.464115
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:22:40.815428
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'][0] == 'SPARC64-VII+ @ 2.53GHz'
    assert hardware_facts['processor_cores'] == '8'
    assert hardware_facts['processor_count'] == '2'
    assert hardware_facts['memtotal_mb'] == '8192'
    assert hardware_facts['swapfree_mb'] == '8192'
    assert hardware_facts['swaptotal_mb'] == '8192'
    assert hardware_facts['swap_allocated_mb'] == '0'
    assert hardware_facts['swap_reserved_mb'] == '0'
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'


# Generated at 2022-06-17 00:22:47.387609
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:00.293347
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:23:06.167191
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:16.305023
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['processor_cores'] == 1
    assert hardware_obj.facts['memtotal_mb'] == 1024
    assert hardware_obj.facts['swapfree_mb'] == 1024
    assert hardware_obj.facts['swaptotal_mb'] == 2048
    assert hardware_obj.facts['swap_allocated_mb'] == 1024
    assert hardware_obj.facts['swap_reserved_mb'] == 1024
    assert hardware_obj.facts['system_vendor'] == 'Sun Microsystems'
    assert hardware_obj.facts['product_name'] == 'Sun Fire V440'
    assert hardware_obj

# Generated at 2022-06-17 00:23:29.540104
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()

    assert hardware_obj.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_obj.facts['processor_cores'] == 'NA'
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['memtotal_mb'] == 16384
    assert hardware_obj.facts['swapfree_mb'] == 16384
    assert hardware_obj.facts['swaptotal_mb'] == 16384
    assert hardware_obj.facts['swap_allocated_mb'] == 0
    assert hardware_obj.facts['swap_reserved_mb'] == 0

# Generated at 2022-06-17 00:23:34.675493
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'


# Generated at 2022-06-17 00:23:35.919284
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices'] is not None


# Generated at 2022-06-17 00:23:37.971802
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Genuine Intel(R) CPU 0000 @ 2.00GHz']


# Generated at 2022-06-17 00:24:04.272789
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_number
    from ansible.module_utils.facts.utils import get_file_is_a_

# Generated at 2022-06-17 00:24:14.304348
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:24:18.587876
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'


# Generated at 2022-06-17 00:24:24.858405
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:36.169224
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Sun Microsystems'
    assert hardware.facts['product_name'] == 'Sun Fire V440'

# Generated at 2022-06-17 00:24:45.947380
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import sys
    import os
    import pytest
    import ansible.module_utils.facts.hardware.sunos as sunos

    # Create a fake module
    class FakeModule:
        def __init__(self):
            self.run_command_environ_update = {}

        def run_command(self, cmd):
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

        def get_bin_path(self, cmd, opt_dirs=[]):
            return cmd

    # Create a fake hardware object
    class FakeHardware:
        def __init__(self):
            self.module = FakeModule()

    # Create a fake hardware object
    hardware = FakeHardware()

    # Call the method
    uptime_facts = hardware.get_uptime_facts()

   

# Generated at 2022-06-17 00:24:54.291707
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a prtdiag output that contains a vendor name
    prtdiag_output = 'System Configuration: Sun Microsystems sun4u\n'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test with a prtdiag output that does not contain a vendor name
    prtdiag_output = 'System Configuration: sun4u\n'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == ''
   

# Generated at 2022-06-17 00:25:05.718672
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the get_dmi_facts method of SunOSHardware class
    """
    # Test data

# Generated at 2022-06-17 00:25:13.546814
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for empty output
    module.run_command = MagicMock(return_value=(0, '', ''))
    assert hardware.get_device_facts() == {'devices': {}}

    # Test for output with one device

# Generated at 2022-06-17 00:25:25.750965
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'VirtualBox'
    assert hardware_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-17 00:26:05.129725
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 8192
    assert facts['swapfree_mb'] == 8192
    assert facts['swaptotal_mb'] == 8192
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0


# Generated at 2022-06-17 00:26:11.051570
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:26:22.914804
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with prtconf output

# Generated at 2022-06-17 00:26:30.532905
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:26:36.485134
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:26:45.926176
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:26:52.734819
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0



# Generated at 2022-06-17 00:27:01.306522
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:27:11.763834
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:27:19.538248
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

# Generated at 2022-06-17 00:28:39.419035
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V490'

# Generated at 2022-06-17 00:28:46.342669
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def __init__(self, run_command_result):
            self.run_command_result = run_command_result

        def run_command(self, args, check_rc=True):
            return self.run_command_result

    class MockFacts(object):
        def __init__(self, ansible_machine):
            self.ansible_machine = ansible_machine

    # Test 1:
    # prtdiag output:
    # System Configuration: Sun Microsystems sun4u Sun Fire V240
    # System clock frequency: 200 MHz
    # Memory size: 4096 Megabytes
    # ========================== CPUs ========================================
    #   Run Ecache CPU CPU
    #   CPU  MHz MB  Impl. Mask
    #   ---  --- --  ----- ----
    #   0    200

# Generated at 2022-06-17 00:28:50.265730
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-17 00:29:00.389202
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    """
    Test get_memory_facts method of SunOSHardware class.
    """
    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware()

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, 'Memory size: 8192 Megabytes', ''),
        'get_bin_path': lambda *args, **kwargs: '/usr/sbin/prtconf'
    })

    # Set the module to the SunOSHardware object
    sunos_hardware.module = mock_module

    # Test get_memory_facts
    memory_facts = sunos_hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 8192

# Generated at 2022-06-17 00:29:07.819915
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:29:14.163356
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:29:22.053514
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:29:27.349599
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:29:32.672517
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import time
    import datetime
    import pytz

    # Set the current time to a known value
    current_time = datetime.datetime(2019, 1, 1, 0, 0, 0, 0, pytz.utc)
    time.time = lambda: current_time.timestamp()

    # Set the boot time to a known value
    boot_time = datetime.datetime(2018, 1, 1, 0, 0, 0, 0, pytz.utc)
    boot_time_seconds = boot_time.timestamp()

    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware(None)

    # Set the kstat output to a known value

# Generated at 2022-06-17 00:29:42.798384
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']