

# Generated at 2022-06-17 00:22:29.709340
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Set the current time to a known value
    current_time = 1548249689
    time.time = lambda: current_time

    # Set the boot time to a known value
    boot_time = 1548249689 - (60 * 60 * 24 * 7)
    time.time = lambda: boot_time

    # Create an instance of the SunOSHardware class
    sunos_hardware = SunOSHardware()

    # Get the uptime facts
    uptime_facts = sunos_hardware.get_uptime_facts()

    # Assert that the uptime_seconds fact is correct
    assert uptime_facts['uptime_seconds'] == 604800

# Generated at 2022-06-17 00:22:42.795749
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor'] == ['SPARC64-VI @ 2.52GHz']
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'


# Generated at 2022-06-17 00:22:45.017565
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz)']


# Generated at 2022-06-17 00:22:52.571535
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create a SunOSHardware object
    sunos_obj = SunOSHardware(module)

    # Run the populate method
    facts = sunos_obj.populate()

    # Test the facts
    assert facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert facts['processor_cores'] == 'NA'
    assert facts['processor_count'] == 1
    assert facts['memtotal_mb'] == 8192
    assert facts['swapfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0
    assert facts['swap_allocated_mb'] == 0
    assert facts['swap_reserved_mb'] == 0
    assert facts

# Generated at 2022-06-17 00:23:00.418254
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'



# Generated at 2022-06-17 00:23:04.700975
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:23:15.129518
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v'

    # Test for Sun Microsystems
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4v', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-17 00:23:27.294614
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(1)
            return 1548249689 + 3600

    module = MockModule()
    time = MockTime()
    hardware = SunOSHardware(module=module, time=time)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 3600

# Generated at 2022-06-17 00:23:37.685778
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return 0, 'unix:0:system_misc:boot_time    1548249689', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(1)
            return 1548249689 + 3600

    module = MockModule()
    time = MockTime()
    hardware = SunOSHardware(module)
    hardware.time = time
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 3600

# Generated at 2022-06-17 00:23:42.153452
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:06.884803
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:14.183390
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.4GHz']


# Generated at 2022-06-17 00:24:19.130424
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:24:27.619705
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 16384
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SPARC T7-2'


# Generated at 2022-06-17 00:24:36.900887
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_inode_change_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file

# Generated at 2022-06-17 00:24:41.230103
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 4
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz)']


# Generated at 2022-06-17 00:24:45.749180
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swap_allocated_mb' in facts
    assert 'swap_reserved_mb' in facts


# Generated at 2022-06-17 00:24:50.999964
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:25:01.358350
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1:
    # System Configuration: VMware, Inc. VMware Virtual Platform
    # Expected output:
    #   system_vendor: VMware, Inc.
    #   product_name: VMware Virtual Platform
    out = 'System Configuration: VMware, Inc. VMware Virtual Platform'
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'VMware, Inc.'
    assert dmi_facts['product_name'] == 'VMware Virtual Platform'

    # Test case 2:
    # System Configuration: Sun Microsystems sun4u
    # Expected output:
    #   system_vendor: Sun Microsystems
    #   product_name: sun4u

# Generated at 2022-06-17 00:25:05.849645
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise'


# Generated at 2022-06-17 00:25:32.734847
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:25:41.171260
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:25:47.269685
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a sample output of kstat cpu_info
    # module: cpu_info
    # class: misc
    # instance: 0
    # chip_id   0
    # clock_MHz  800
    # cpu_fru    <unknown>
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i386
    # cpu_type   i

# Generated at 2022-06-17 00:25:56.107602
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.52GHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'

# Generated at 2022-06-17 00:26:03.968513
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:10.966575
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:26:20.114204
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = SunOSHardware(module)
    hardware.get_cpu_facts()
    assert module.params['ansible_processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz',
                                                  'SPARC64-VII (chipid 1, clock 1500 MHz) @ 1500MHz']
    assert module.params['ansible_processor_cores'] == 2
    assert module.params['ansible_processor_count'] == 2


# Generated at 2022-06-17 00:26:23.262933
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'VirtualBox'

# Generated at 2022-06-17 00:26:34.299392
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swap_allocated_mb']
    assert hardware_facts['swap_reserved_mb']
    assert hardware_facts['system_vendor']
    assert hardware_facts['product_name']
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']

# Generated at 2022-06-17 00:26:44.446485
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Fujitsu FUJITSU Server PRIMERGY RX2530 M1', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'FUJITSU Server PRIMERGY RX2530 M1'

    # Test for Oracle
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC Enterprise T5120', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_

# Generated at 2022-06-17 00:27:23.359814
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:27:27.737090
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:27:37.425532
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert isinstance(device_facts, dict)
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert len(device_facts['devices']) > 0
    for device in device_facts['devices']:
        assert isinstance(device_facts['devices'][device], dict)
        assert 'product' in device_facts['devices'][device]
        assert 'revision' in device_facts['devices'][device]
        assert 'serial' in device_facts['devices'][device]
        assert 'size' in device_facts['devices'][device]
        assert 'vendor' in device_facts['devices'][device]


# Generated at 2022-06-17 00:27:42.403350
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'


# Generated at 2022-06-17 00:27:52.456544
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    class MockModule(object):
        def run_command(self, cmd):
            return 0, 'System Configuration: Sun Microsystems sun4v', ''

    class MockFactCollector(object):
        def __init__(self):
            self.collector = {'ansible_machine': 'i86pc'}

    module = MockModule()
    facts = MockFactCollector()
    hardware = SunOSHardware(module, facts)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4v'

# Generated at 2022-06-17 00:28:00.787779
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:07.178516
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:28:15.807506
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz)']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 8


# Generated at 2022-06-17 00:28:22.947334
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:28:29.371894
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:29:43.017531
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_obj = SunOSHardware(module)
    hardware_obj.populate()
    assert hardware_obj.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_obj.facts['processor_count'] == 1
    assert hardware_obj.facts['processor_cores'] == 1
    assert hardware_obj.facts['memtotal_mb'] == 8192
    assert hardware_obj.facts['swapfree_mb'] == 8192
    assert hardware_obj.facts['swaptotal_mb'] == 8192
    assert hardware_obj.facts['swap_allocated_mb'] == 0
    assert hardware_obj.facts['swap_reserved_mb'] == 0
    assert hardware_obj.facts['system_vendor'] == 'Oracle Corporation'


# Generated at 2022-06-17 00:29:47.909862
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:29:52.401039
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-17 00:29:59.879963
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Fujitsu
    prtdiag_output = 'System Configuration: Fujitsu PRIMERGY RX300 S6'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'PRIMERGY RX300 S6'

    # Test for Oracle Corporation
    prtdiag_output = 'System Configuration: Oracle Corporation sun4v SPARC T5-2'
    dmi_facts = hardware.get_dmi_facts(prtdiag_output)
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:30:09.729576
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.populate()
    assert 'ansible_processor' in facts
    assert 'ansible_processor_cores' in facts
    assert 'ansible_processor_count' in facts
    assert 'ansible_memtotal_mb' in facts
    assert 'ansible_swapfree_mb' in facts
    assert 'ansible_swaptotal_mb' in facts
    assert 'ansible_swap_allocated_mb' in facts
    assert 'ansible_swap_reserved_mb' in facts
    assert 'ansible_system_vendor' in facts
    assert 'ansible_product_name' in facts
    assert 'ansible_devices' in facts
    assert 'ansible_uptime_seconds' in facts

# Generated at 2022-06-17 00:30:19.402171
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2400MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0

# Generated at 2022-06-17 00:30:29.514549
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert hardware_facts['devices']['sd0']['revision'] == '1.0'
    assert hardware_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'

# Generated at 2022-06-17 00:30:38.962149
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:30:49.140728
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test case 1:
    # System Configuration: Sun Microsystems sun4u
    # Expected result:
    #   system_vendor: Sun Microsystems
    #   product_name: sun4u
    out = 'System Configuration: Sun Microsystems sun4u'
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test case 2:
    # System Configuration: Oracle Corporation sun4v
    # Expected result:
    #   system_vendor: Oracle Corporation
    #   product_name: sun4v

# Generated at 2022-06-17 00:30:53.810981
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz)']
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor_count'] == 1
