

# Generated at 2022-06-17 00:22:23.410062
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])
    assert hardware_collector.fact_class == SunOSHardware

# Generated at 2022-06-17 00:22:35.138402
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:22:45.899799
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:22:53.975053
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:00.058664
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5220'

# Generated at 2022-06-17 00:23:02.819831
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    collector = SunOSHardwareCollector()
    assert collector.platform == 'SunOS'
    assert collector.required_facts == set(['platform'])
    assert collector.fact_class == SunOSHardware


# Generated at 2022-06-17 00:23:13.918831
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:21.175289
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:33.576269
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['sda']['product'] == 'VBOX HARDDISK'
    assert hardware.facts['devices']['sda']['size'] == '50.00 GB'
    assert hardware.facts['devices']['sda']['vendor'] == 'ATA'
    assert hardware.facts['devices']['sda']['revision'] == '1.0'
    assert hardware.facts['devices']['sda']['serial'] == 'VB0ad2ec4d-074a'
    assert hardware.facts['devices']['sda']['hard_errors'] == '0'

# Generated at 2022-06-17 00:23:37.639494
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'Sun Fire V440'


# Generated at 2022-06-17 00:24:01.596630
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    hardware = SunOSHardware()
    hardware.module = MockModule()
    hardware.module.run_command = Mock(return_value=(0, 'System Configuration: Sun Microsystems sun4u', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'


# Generated at 2022-06-17 00:24:14.084451
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for Oracle Corporation
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Oracle Corporation sun4v SPARC T4-2', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'sun4v SPARC T4-2'

    # Test for Sun Microsystems
    module.run_command = MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4u SPARC Enterprise T5120', ''))
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor']

# Generated at 2022-06-17 00:24:23.730460
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SUNW,UltraSPARC-IIi @ 200MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 1024
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Sun Microsystems'
    assert hardware.facts['product_name'] == 'Sun Fire V210'


# Generated at 2022-06-17 00:24:35.468623
# Unit test for method get_cpu_facts of class SunOSHardware

# Generated at 2022-06-17 00:24:44.705800
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with empty output
    rc, out, err = module.run_command('/usr/bin/kstat -p')
    assert hardware.get_device_facts() == {'devices': {}}

    # Test with valid output
    rc, out, err = module.run_command('/usr/bin/kstat -p sderr:::Product sderr:::Revision sderr:::Serial No sderr:::Size sderr:::Vendor sderr:::Hard Errors sderr:::Soft Errors sderr:::Transport Errors sderr:::Media Error sderr:::Predictive Failure Analysis sderr:::Illegal Request')

# Generated at 2022-06-17 00:24:53.745523
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:58.681494
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts



# Generated at 2022-06-17 00:25:04.556407
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:25:12.134260
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Create a SunOSHardware object
    sunos_hw = SunOSHardware()

    # Create a mock module
    mock_module = type('AnsibleModule', (object,), {'run_command': MagicMock(return_value=(0, 'System Configuration: Sun Microsystems sun4v', ''))})
    sunos_hw.module = mock_module

    # Call the get_dmi_facts method
    dmi_facts = sunos_hw.get_dmi_facts()

    # Assert that the dmi_facts dict contains the expected values
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4v'

# Generated at 2022-06-17 00:25:18.016943
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hw = SunOSHardware(module)
    uptime_facts = hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:26:02.528374
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    # Create a fake module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Create a fake SunOSHardware class
    sunos_hw = SunOSHardware(module)

    # Create a fake kstat output

# Generated at 2022-06-17 00:26:14.731175
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 2
    assert hardware_facts['processor_cores'] == 4
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'VirtualBox'

# Generated at 2022-06-17 00:26:25.158300
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()

    assert hardware_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Sun Microsystems'

# Generated at 2022-06-17 00:26:34.904751
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['SPARC64-VII @ 2400MHz']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'T5-8'


# Generated at 2022-06-17 00:26:44.312236
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test data
    prtdiag_output = 'System Configuration: Sun Microsystems sun4v\n'

    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockSunOSHardware(SunOSHardware):
        def __init__(self, module):
            super(MockSunOSHardware, self).__init__(module)

        def run_command(self, cmd):
            return 0, prtdiag_output, ''

    # Create an instance of the mock class
    sunos_hardware = MockSunOSHardware(module)

    # Test get_dmi_facts
    dmi_facts = sunos_hardware.get_dmi_facts()

    # Assertions

# Generated at 2022-06-17 00:26:47.846333
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:53.911232
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:27:02.078429
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardwareCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.hardware.base import Hardware, HardwareCollector

# Generated at 2022-06-17 00:27:09.378621
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'


# Generated at 2022-06-17 00:27:14.325949
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:28:07.555519
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:28:12.540390
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz)']
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 8
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:14.772055
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.get_dmi_facts()

# Generated at 2022-06-17 00:28:20.651928
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'][0] == 'Genuine Intel(R) CPU 0000 @ 2.00GHz'


# Generated at 2022-06-17 00:28:30.151505
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test the get_dmi_facts method of SunOSHardware class.
    """
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd == ['/usr/bin/uname', '-i']:
                return 0, 'sparc', ''
            elif cmd == ['/usr/platform/sparc/sbin/prtdiag']:
                return 0, 'System Configuration: Sun Microsystems sun4u\n', ''
            else:
                raise Exception("Unexpected command: %s" % cmd)

    module = MockModule()
    hardware = SunOSHardware(module)
    dmi_

# Generated at 2022-06-17 00:28:32.975740
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:28:41.033940
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz', 'SPARC64-VII (chipid 1, clock 1500 MHz) @ 1500MHz']
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-17 00:28:47.638423
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:28:56.962431
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test for SPARC CPU
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': 'sun4v'})
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 2
    assert cpu_facts['processor'] == ['SPARC64-VI @ 2000MHz']

    # Test for x86 CPU
    cpu_facts = hardware.get_cpu_facts({'ansible_machine': 'i86pc'})
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['Intel(r) Core(tm) i7-4770 CPU @ 3.40GHz']


# Unit

# Generated at 2022-06-17 00:29:02.432483
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0



# Generated at 2022-06-17 00:30:31.960685
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-17 00:30:36.699045
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1200 MHz)']


# Generated at 2022-06-17 00:30:39.405260
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector.platform == 'SunOS'
    assert hardware_collector.fact_class == SunOSHardware


# Generated at 2022-06-17 00:30:49.349738
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert device_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'
    assert device_facts['devices']['sd0']['revision'] == '1.0'
    assert device_facts['devices']['sd0']['serial'] == 'VB0ad2ec4d-074a'
    assert device_facts['devices']['sd0']['size'] == '50.00 GB'
    assert device_facts['devices']['sd0']['vendor'] == 'ATA'
    assert device_facts['devices']['sd0']['hard_errors'] == '0'

# Generated at 2022-06-17 00:30:54.548356
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] >= 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] >= 0
    assert facts['swap_reserved_mb'] >= 0


# Generated at 2022-06-17 00:31:05.511303
# Unit test for method get_dmi_facts of class SunOSHardware

# Generated at 2022-06-17 00:31:10.034043
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:31:13.071181
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'


# Generated at 2022-06-17 00:31:23.282904
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    """
    Test get_dmi_facts() method of SunOSHardware class.
    """
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # Create a fake module object
    module = type('AnsibleModule', (object,), {
        'run_command': lambda *args, **kwargs: (0, '', ''),
        'get_bin_path': lambda *args, **kwargs: '/usr/bin/prtdiag',
    })()

    # Create a fake BaseFactCollector object
    fact_collector = type('BaseFactCollector', (object,), {
        'module': module,
    })()

# Generated at 2022-06-17 00:31:28.704948
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
