

# Generated at 2022-06-17 00:22:26.538617
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import datetime
    import time
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware

    # Create a SunOSHardware object
    sunos_hardware = SunOSHardware()

    # Mock the time.time() method to return a fixed value
    time.time = lambda: 1548249689

    # Call the get_uptime_facts() method
    uptime_facts = sunos_hardware.get_uptime_facts()

    # Check the result
    assert uptime_facts['uptime_seconds'] == 1548249689

# Generated at 2022-06-17 00:22:29.437899
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-17 00:22:38.283470
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0

# Generated at 2022-06-17 00:22:48.686901
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockTime(object):
        def __init__(self):
            self.time_results = []

        def time(self):
            return self.time_results.pop(0)

    module = MockModule()
    time = MockTime()

    # Test case 1: kstat returns a valid boot time
    module.run_command_results = [(0, 'unix:0:system_misc:boot_time    1548249689', '')]
    time.time

# Generated at 2022-06-17 00:22:57.435814
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    sunos_hardware = SunOSHardware(module)
    uptime_facts = sunos_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)


# Generated at 2022-06-17 00:23:04.016415
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:13.737775
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1200 MHz) @ 1200MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:23:19.960228
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:27.154967
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:23:37.603598
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    class MockModule:
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockTime:
        def __init__(self):
            self.time_return = 0

        def time(self):
            return self.time_return

    class MockSunOSHardware(SunOSHardware):
        def __init__(self, module):
            self.module = module

    module = MockModule()
    module.run_command_results = [(0, 'unix:0:system_misc:boot_time    1548249689', '')]
    time = Mock

# Generated at 2022-06-17 00:24:02.892937
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:24:06.516786
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert cpu_facts['processor_cores'] == 16
    assert cpu_facts['processor_count'] == 2


# Generated at 2022-06-17 00:24:18.546736
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    # Test with a valid prtdiag output
    prtdiag_output = """
System Configuration: Sun Microsystems sun4u
SunOS Release 5.10 Version Generic_147440-09 64-bit
"""
    module = MockModule()
    module.run_command.return_value = (0, prtdiag_output, '')
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Sun Microsystems'
    assert dmi_facts['product_name'] == 'sun4u'

    # Test with an invalid prtdiag output
    prtdiag_output = """
System Configuration: Sun Microsystems sun4u
"""
    module = MockModule()
    module.run_command.return_

# Generated at 2022-06-17 00:24:23.458018
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:24:35.213014
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)

    # Test with a prtdiag output that contains a valid system configuration
    # line.

# Generated at 2022-06-17 00:24:44.520026
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    import time
    import pytest

    # mock kstat output
    boot_time = int(time.time()) - 100
    kstat_output = 'unix:0:system_misc:boot_time\t%d' % boot_time

    # mock run_command
    def mock_run_command(self, cmd):
        return 0, kstat_output, ''

    # mock time.time
    def mock_time():
        return boot_time + 200

    # mock time.time
    def mock_time_fail():
        return boot_time + 20000

    # mock time.time
    def mock_time_fail_negative():
        return boot_time - 20000

    # mock time.time

# Generated at 2022-06-17 00:24:47.761954
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:24:59.566446
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import datetime
    import pytz
    import unittest

    class TestSunOSHardware(SunOSHardware):
        def __init__(self):
            self.module = None

        def run_command(self, cmd):
            return 0, str(time.time()), ''

    class TestCase(unittest.TestCase):
        def test_get_uptime_facts(self):
            sunos_hardware = TestSunOSHardware()
            uptime_facts = sunos_hardware.get_uptime_facts()
            self.assertTrue(uptime_facts['uptime_seconds'] > 0)
            self.assertTrue(uptime_facts['uptime_seconds'] < time.time())

    unittest.main()

# Generated at 2022-06-17 00:25:05.806141
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] == 1024
    assert facts['swapfree_mb'] == 512
    assert facts['swaptotal_mb'] == 1024
    assert facts['swap_allocated_mb'] == 512
    assert facts['swap_reserved_mb'] == 0



# Generated at 2022-06-17 00:25:13.595342
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 2048
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'VirtualBox'
    assert hardware_facts['devices']['sd0']['product'] == 'VBOX HARDDISK'

# Generated at 2022-06-17 00:25:48.618795
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:25:56.245694
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = SunOSHardware(module).populate()
    assert hardware_facts['processor'] == ['SUNW,SPARC-Enterprise']
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 16384
    assert hardware_facts['swaptotal_mb'] == 16384
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'
    assert hardware_facts['product_name'] == 'SPARC T5-2'
    assert hardware

# Generated at 2022-06-17 00:26:06.719023
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC T4 (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:26:13.205252
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:26:18.286705
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    device_facts = hardware.get_device_facts()

    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:26:30.249440
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII @ 2.53GHz']
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['processor_cores'] == 8
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'
    assert hardware.facts['product_name'] == 'SPARC T7-1'

# Generated at 2022-06-17 00:26:42.482634
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule:
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockTime:
        def __init__(self):
            self.time_calls = []

        def time(self):
            self.time_calls.append(True)
            return 1548249689

    class TestSunOSHardware(unittest.TestCase):
        def setUp(self):
            self.mock_module = MockModule()
            self.mock_time = MockTime()
            self.test_

# Generated at 2022-06-17 00:26:49.782657
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SUNW,UltraSPARC-IIi @ 167MHz']
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1


# Generated at 2022-06-17 00:27:00.985424
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor_cores'] == 1
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Sun Microsystems'
    assert hardware_facts['product_name'] == 'Sun Fire V440'

# Generated at 2022-06-17 00:27:06.984396
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:27:59.035314
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 00:28:10.126422
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_cores'] == 'NA'
    assert hardware_facts['processor_count'] == 1
    assert hardware_facts['processor'] == ['SUNW,SPARC-Enterprise']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['swapfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 8192
    assert hardware_facts['swap_allocated_mb'] == 0
    assert hardware_facts['swap_reserved_mb'] == 0
    assert hardware_facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:20.621156
# Unit test for method get_device_facts of class SunOSHardware
def test_SunOSHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module=module)
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert 'sd0' in device_facts['devices']
    assert 'product' in device_facts['devices']['sd0']
    assert 'revision' in device_facts['devices']['sd0']
    assert 'serial' in device_facts['devices']['sd0']
    assert 'size' in device_facts['devices']['sd0']
    assert 'vendor' in device_facts['devices']['sd0']
    assert 'hard_errors' in device_facts['devices']['sd0']
    assert 'soft_errors' in device_facts['devices']['sd0']

# Generated at 2022-06-17 00:28:26.502847
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_LIBZFS:
        module.fail_json(msg='The python libzfs module is required')

    run_command_original = module.run_command

    def run_command_side_effect(*args, **kwargs):
        if args[0] == ['/usr/sbin/swap', '-s']:
            return (0, 'total: 8192k bytes allocated + 8192k reserved = 16384k used, 16384k available', '')

# Generated at 2022-06-17 00:28:31.615236
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:28:39.602540
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise-T5120'

# Generated at 2022-06-17 00:28:46.428742
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'][0] == 'SPARC64-VII+ @ 2.53GHz'
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 2
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['swapfree_mb'] == 8192
    assert hardware.facts['swaptotal_mb'] == 8192
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:28:52.030507
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['SPARC64-VII+ @ 2.53GHz']
    assert cpu_facts['processor_cores'] == 'NA'
    assert cpu_facts['processor_count'] == 1


# Generated at 2022-06-17 00:28:58.121475
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swap_allocated_mb']
    assert hardware_facts['swap_reserved_mb']
    assert hardware_facts['system_vendor']
    assert hardware_facts['product_name']
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']


# Generated at 2022-06-17 00:29:04.165333
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:30:19.036043
# Unit test for method get_cpu_facts of class SunOSHardware
def test_SunOSHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 1
    assert cpu_facts['processor_cores'] == 1
    assert cpu_facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz)']


# Generated at 2022-06-17 00:30:27.530683
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:30:31.768835
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Oracle Corporation'
    assert dmi_facts['product_name'] == 'SUNW,SPARC-Enterprise'

# Generated at 2022-06-17 00:30:43.585070
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.hardware.sunos import SunOSHardware
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_inode
    from ansible.module_utils.facts.utils import get_file_uid

# Generated at 2022-06-17 00:30:52.298854
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['swapfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swap_allocated_mb'] > 0
    assert facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:31:02.127982
# Unit test for method populate of class SunOSHardware
def test_SunOSHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    hardware.populate()
    assert hardware.facts['processor'] == ['SPARC64-VII (chipid 0, clock 1500 MHz) @ 1500MHz']
    assert hardware.facts['processor_cores'] == 'NA'
    assert hardware.facts['processor_count'] == 1
    assert hardware.facts['memtotal_mb'] == 16384
    assert hardware.facts['swapfree_mb'] == 16384
    assert hardware.facts['swaptotal_mb'] == 16384
    assert hardware.facts['swap_allocated_mb'] == 0
    assert hardware.facts['swap_reserved_mb'] == 0
    assert hardware.facts['system_vendor'] == 'Oracle Corporation'

# Generated at 2022-06-17 00:31:05.962782
# Unit test for method get_dmi_facts of class SunOSHardware
def test_SunOSHardware_get_dmi_facts():
    module = AnsibleModuleMock()
    module.run_command = run_command_mock
    hardware = SunOSHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'Fujitsu'
    assert dmi_facts['product_name'] == 'SPARC Enterprise M4000 Server'



# Generated at 2022-06-17 00:31:08.142621
# Unit test for constructor of class SunOSHardwareCollector
def test_SunOSHardwareCollector():
    hardware_collector = SunOSHardwareCollector()
    assert hardware_collector._fact_class == SunOSHardware
    assert hardware_collector._platform == 'SunOS'
    assert hardware_collector.required_facts == set(['platform'])

# Generated at 2022-06-17 00:31:17.226459
# Unit test for method get_memory_facts of class SunOSHardware
def test_SunOSHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = SunOSHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swap_allocated_mb'] > 0
    assert memory_facts['swap_reserved_mb'] > 0


# Generated at 2022-06-17 00:31:22.423286
# Unit test for method get_uptime_facts of class SunOSHardware
def test_SunOSHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'unix:0:system_misc:boot_time    1548249689', ''))
    hardware = SunOSHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1548249689)
