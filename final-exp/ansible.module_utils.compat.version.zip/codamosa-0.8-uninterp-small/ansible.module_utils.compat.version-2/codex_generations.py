

# Generated at 2022-06-24 21:17:27.100616
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion("1.0a1")
    loose_version_2 = LooseVersion("1.0a2")
    loose_version_3 = LooseVersion("1.0a2.post0")
    loose_version_4 = LooseVersion("1.0.dev1")
    loose_version_5 = LooseVersion("1.0.dev2")
    loose_version_6 = LooseVersion("1.0.dev2.post0")
    loop_counter_0 = 0

# Generated at 2022-06-24 21:17:34.224640
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    alphanum_version_0 = AlphanumVersion()
    alphanum_version_1 = AlphanumVersion()
    alphanum_version_0.parse('b')
    alphanum_version_1.parse('a')
    if (not (loose_version_0 == alphanum_version_0)):
        raise RuntimeError
    if (loose_version_0 == alphanum_version_1):
        raise RuntimeError


# Generated at 2022-06-24 21:17:36.811698
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    ver_0 = Version()
    ver_1 = Version()
    if (not (ver_0 == ver_1)):
        raise RuntimeError()


# Generated at 2022-06-24 21:17:38.624737
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 21:17:40.802437
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    version._cmp = lambda x: 0
    assert version <= ''



# Generated at 2022-06-24 21:17:49.880363
# Unit test for method __le__ of class Version
def test_Version___le__():
    """
    (py18) v-tumulak:ansible-modules-core rini$ pytest test_version.py::test_Version___le__
    ============================= test session starts =============================
    platform darwin -- Python 3.7.0, pytest-5.4.1, py-1.8.1, pluggy-0.13.1
    rootdir: /Users/rini/src/github/ansible/ansible/lib/ansible/module_utils
    plugins: cov-2.8.1
    collected 0 items / 5 deselected / 1 selected

    test_version.py::test_Version___le__ SKIPPED                              [100%]

    =========================== 5 deselected in 0.02s ============================
    """

    def test_case_0():
        loose_version_0 = LooseVersion

# Generated at 2022-06-24 21:17:53.258004
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    looseVersion = LooseVersion()
    try:
        looseVersion < 1.0
    except:
        raise Exception("Should not have thrown exception")


# Generated at 2022-06-24 21:18:00.623407
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion()
    assert str(v) == '0'
    v = StrictVersion('1.0')
    assert str(v) == '1.0'
    v = StrictVersion('  1.0  ')
    assert str(v) == '1.0'
    v = StrictVersion('  1.0.0.0.0.0  ')
    assert str(v) == '1.0'
    v = StrictVersion('1.0.0.0.0.0.0.0.0')
    assert str(v) == '1.0'
    v = StrictVersion('1.0a1')
    assert str(v) == '1.0a1'
    v = StrictVersion('1.0.0a1')

# Generated at 2022-06-24 21:18:02.458216
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert loose_version_0 >= loose_version_1


# Generated at 2022-06-24 21:18:04.764421
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    loose_version_0.parse('1.0.1')
    assert bool(loose_version_0.__gt__('1.0.2')) == True


# Generated at 2022-06-24 21:18:15.863289
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = version_0
    assert version_0 == version_1


# Generated at 2022-06-24 21:18:19.721413
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion('1.2.3')
    string_0 = 'foo'
    string_1 = '1.2.3'
    assert (loose_version_0 >= string_0) == False
    assert (loose_version_0 >= string_1) == True


# Generated at 2022-06-24 21:18:23.177979
# Unit test for method __le__ of class Version
def test_Version___le__():
    lv_test_none = LooseVersion()
    assert lv_test_none <= LooseVersion()
    assert lv_test_none <= "2.2.2"


# Generated at 2022-06-24 21:18:26.097043
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Binary testing (TypeError)
    try:
        Version.__eq__(Version(), 0)
    except TypeError:
        pass
    else:
        raise AssertionError("__eq__ did not raise TypeError")


# Generated at 2022-06-24 21:18:32.435930
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-24 21:18:35.452295
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert test_case_LooseVersion_0()._cmp(test_case_LooseVersion_1()) is True


# Generated at 2022-06-24 21:18:39.324881
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    cases = (
        (test_case_0, NotImplemented,),
    )
    for (case, expected,) in cases:
        actual = case()
        if expected != actual:
            print('FAILED: expected =', expected, ', actual =', actual)


# Generated at 2022-06-24 21:18:41.087662
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    test_case_0()


# Generated at 2022-06-24 21:18:42.735149
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version()
    assert v <= v2


# Generated at 2022-06-24 21:18:43.353535
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass


# Generated at 2022-06-24 21:18:51.407637
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion('1.1.1.1')
    try:
        __temp = loose_version_0 >= None
        assert False
    except TypeError:
        pass


# Generated at 2022-06-24 21:19:01.788176
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print("\n=== test __eq__() of class Version ===")
    # Define eq_test_cases
    eq_test_cases = []
    # Define eq_test_case_0
    loose_version_0 = LooseVersion()
    strict_version_0 = StrictVersion()
    eq_test_cases.append((loose_version_0, strict_version_0))
    eq_test_cases.append((strict_version_0, loose_version_0))
    # Execute eq_test_cases

# Generated at 2022-06-24 21:19:03.790687
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert str(LooseVersion("1.1.1")) == "1.1.1"



# Generated at 2022-06-24 21:19:10.200914
# Unit test for method __le__ of class Version
def test_Version___le__():

    # Test 1
    loose_version_0 = LooseVersion()
    assert loose_version_0 <= ""
    # End test 1

    # Test 2
    try:
        loose_version_1 = LooseVersion()
        try:
            loose_version_1 <= ValueError()
        except ValueError:
            pass
        else:
            raise AssertionError
    except TypeError:
        pass
    # End test 2



# Generated at 2022-06-24 21:19:16.316494
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    import random
    import string

    # Instantiate object
    strict_version = StrictVersion()

    # Evaluate function
    result = strict_version.__str__()

    # Check expected result
    assert( isinstance( result, string ) )


# Generated at 2022-06-24 21:19:23.680604
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    assert (loose_version_0 == None)
    try:
        LooseVersion('0.0') == None
        assert False, "Expected AssertionError"
    except AssertionError:
        pass
    assert LooseVersion('1.0.0') == LooseVersion('1.0.0')
    try:
        LooseVersion('1.0') == 'a'
        assert False, "Expected AssertionError"
    except AssertionError:
        pass
    assert LooseVersion('1.0.0') == LooseVersion('1.0')
    assert LooseVersion('1.0.0') == '1.0'
    assert LooseVersion('1.0') == '1.0.0'

# Generated at 2022-06-24 21:19:31.247687
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    strict_version_0.parse("0.4")
    # Verify that the function returns the correct value
    assert strict_version_0.__str__() == "0.4"
    strict_version_1 = StrictVersion()
    strict_version_1.parse("0.4.0")
    # Verify that the function returns the correct value
    assert strict_version_1.__str__() == "0.4.0"
    strict_version_2 = StrictVersion()
    strict_version_2.parse("0.4.1")
    # Verify that the function returns the correct value
    assert strict_version_2.__str__() == "0.4.1"
    strict_version_3 = StrictVersion()

# Generated at 2022-06-24 21:19:35.696701
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    from distutils.version import LooseVersion

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 21:19:39.165730
# Unit test for method __le__ of class Version
def test_Version___le__():
    import lib_unittest as unittest
    from distutils.version import LooseVersion
    # The bug was that comparing a LooseVersion instance to a string
    # raises a TypeError when it should return NotImplemented.
    # The following two lines form the basis of the unit test:
    not_implemented_result = LooseVersion('99') <= '2'
    assert not_implemented_result is NotImplemented



# Generated at 2022-06-24 21:19:48.374867
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test cases
    # Case1
    loose_version_0 = LooseVersion()
    assert loose_version_0._cmp(loose_version_0) == 0
    # Case2
    loose_version_1 = LooseVersion(str(loose_version_0))
    assert loose_version_0._cmp(loose_version_1) == 0
    # Case3
    loose_version_2 = LooseVersion("1.0")
    assert loose_version_0._cmp(loose_version_2) != 0
    # Case4
    loose_version_3 = LooseVersion("")
    assert loose_version_0._cmp(loose_version_3) != 0
    # Case5
    loose_version_4 = LooseVersion("2.1.1")
    assert loose_version_0._cmp

# Generated at 2022-06-24 21:19:55.260114
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    with pytest.raises(NotImplementedError):
        loose_version_0 = LooseVersion()
        loose_version_0.__lt__(loose_version_0)


# Generated at 2022-06-24 21:20:03.390902
# Unit test for method __lt__ of class Version

# Generated at 2022-06-24 21:20:10.737013
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print("Testing version numbers less than")
    assert (LooseVersion("1.2a1") < LooseVersion("1.2.a1") ==
            StrictVersion("1.2a1") < StrictVersion("1.2.a1") == True)
    # Test that a pre-release version sorts lower than a final release
    assert (LooseVersion("4.4rc3") < LooseVersion("4.4") ==
            StrictVersion("4.4rc3") < StrictVersion("4.4") == True)


# Generated at 2022-06-24 21:20:16.199357
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert LooseVersion() < LooseVersion('0.1')
    assert LooseVersion() < LooseVersion('0.1.0')
    assert LooseVersion('0.1') < LooseVersion('0.2')
    assert LooseVersion('0.1.0') < LooseVersion('0.2.0')
    assert LooseVersion('0.1.0') < LooseVersion('0.1.1')

    assert LooseVersion() == LooseVersion()
    assert LooseVersion() == LooseVersion('0')
    assert LooseVersion('0') == LooseVersion()
    assert LooseVersion() == LooseVersion('0.0')
    assert LooseVersion('0.0') == LooseVersion()

    assert LooseVersion('0.0') < LooseVersion('0.1')
    assert LooseVersion

# Generated at 2022-06-24 21:20:17.471077
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # test_case_0
    loose_version_0 = LooseVersion()


# Generated at 2022-06-24 21:20:20.075634
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v0 = Version()
    v1 = Version()
    v0.parse("1.0")
    v1.parse("2.0")
    assert v0 < v1
    assert not v0 == v1
    assert not v1 < v0


# Generated at 2022-06-24 21:20:27.815799
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_0 = LooseVersion("3.3.0")
    loose_version_1 = LooseVersion("0.14.0")
    loose_version_2 = LooseVersion("5.5.5")
    # No exception thrown
    loose_version_0 <= loose_version_1
    loose_version_0 <= loose_version_2


# Generated at 2022-06-24 21:20:37.725691
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    a1 = StrictVersion()
    a2 = StrictVersion()
    a3 = StrictVersion()
    b = StrictVersion()
    c = StrictVersion()
    a1.parse('1')
    a2.parse('2')
    a3.parse('2')
    b.parse('1')
    c.parse('0')
    # Test typical use case
    assert(a1 < a2)
    # Test that equals is false
    assert(not a2<a3)
    # Test that the method is commutative
    assert(b < a1)
    # Test with a lesser version
    assert(c < a1)


# Generated at 2022-06-24 21:20:43.167923
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion("0.1")
    loose_version_2 = LooseVersion("0.2")
    assert loose_version_1 < loose_version_2
    assert not loose_version_1 < loose_version_1
    assert not loose_version_1 < loose_version_0


# Generated at 2022-06-24 21:20:49.304944
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    Test parse method of class LooseVersion
    """
    """
    Test the method parse of class LooseVersion
    """
    # Test code
    # FIXME: error in test code: 
    #   vstring should be an string, an exception should be raised
    #   Test fail
    try:
        loose_version_0 = LooseVersion()
        loose_version_0.parse(sep='abc')
    except Exception as e:
        assert_true(isinstance(e, ValueError))
        assert_equal(str(e), "invalid version number '0.0.0'")
    # Test code
    # Test the code that raise an exception

# Generated at 2022-06-24 21:20:58.565073
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Initialization
    loose_version_0 = LooseVersion()

    # Try to parse '1.0' (valid)
    loose_version_0.parse('1.0')
    # Try to parse 'a.0' (valid)
    loose_version_0.parse('a.0')
    # Try to parse '1.0' (valid)
    loose_version_0.parse('1.0')
    # Try to parse '1.0g' (valid)
    loose_version_0.parse('1.0g')
    # Try to parse '1.5.1' (valid)
    loose_version_0.parse('1.5.1')
    # Try to parse '1.5.2b2' (valid)
    loose_version_0.parse('1.5.2b2')


# Generated at 2022-06-24 21:21:02.783281
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    '''
    Test for Descriptor.get
    '''
    loose_version_0 = LooseVersion()
    loose_version_0.parse("1.7.1.1")



# Generated at 2022-06-24 21:21:14.273366
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from types import TupleType

    loose_version = LooseVersion()
    assert isinstance(LooseVersion().parse("1.5"), TupleType)
    assert isinstance(LooseVersion(), LooseVersion)
    assert loose_version.parse("1.4") == (1, 4)
    assert loose_version.parse("2.2") == (2, 2)
    assert loose_version.parse("2.2.0") == (2, 2, 0)
    assert loose_version.parse("1.5") == (1, 5)
    assert loose_version.parse("1.5.1") == (1, 5, 1)
    assert loose_version.parse("1.5.1") == (1, 5, 1)

# Generated at 2022-06-24 21:21:24.442769
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    # self.assertRaises(AttributeError, loose_version_0.parse, 'a')
    # Invalid literal for int() with base 10: 'a'
    # self.assertRaises(ValueError, loose_version_0.parse, "ab")
    # invalid version number 'ab'
    # self.assertRaises(ValueError, loose_version_0.parse, "a.b")
    # invalid version number 'a.b'
    # self.assertRaises(AttributeError, loose_version_0.parse, "a.0")
    # Invalid literal for int() with base 10: 'a.0'
    # self.assertRaises(ValueError, loose_version_0.parse, "0.a")
    # invalid version number '0.a'
    # self

# Generated at 2022-06-24 21:21:29.291044
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from . import LooseVersion
    from . import re
    from . import __name__
    from . import ValueError
    from . import TypeError
    from test.test_support import TestFailed

    v = LooseVersion()
    try:
        v.parse()
    except TypeError:
        pass
    else:
        raise TestFailed('v.parse() with no args should fail')

    v.parse('0.9')
    if v.version != [0, 9]:
        raise TestFailed('v.parse() should parse "0.9" into [0, 9]')

    v.parse('1.2.3.4.5')

# Generated at 2022-06-24 21:21:39.493298
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Parse valid version strings
    parse_0_valid = LooseVersion()
    parse_0_valid.parse('0')

    parse_1_valid = LooseVersion()
    parse_1_valid.parse('1.0')

    parse_2_valid = LooseVersion()
    parse_2_valid.parse('0.2.3')

    parse_3_valid = LooseVersion()
    parse_3_valid.parse('1.1.1.0')

    # Will raise ValueError
    try:
        parse_4_invalid = LooseVersion()
        parse_4_invalid.parse('1a')
        parse_4_invalid_ok = int('1a')
    except ValueError:
        parse_4_invalid_ok = 1

# Generated at 2022-06-24 21:21:47.446948
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version = LooseVersion('1.2.3.4')

    version = LooseVersion('1.2.3a1')
    version = LooseVersion('1.2.3b')
    version = LooseVersion('1.2.3pl4')
    version = LooseVersion('1.2.3c1')
    version = LooseVersion('1.2.3c4')
    version = LooseVersion('1.2.3h1')


test_case_0()
test_LooseVersion_parse()

# Generated at 2022-06-24 21:21:48.793779
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test 1
    version = LooseVersion()
    version.parse("1.5.1")
    result = version.vstring
    assert result == "1.5.1"


# Generated at 2022-06-24 21:21:58.572954
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:22:09.476914
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion("1.0")
    loose_version_2 = LooseVersion("0.0.0.0.0")
    loose_version_3 = LooseVersion("11g")
    #compare_parsed(loose_version_1, (1, 0))
    print("loose_version_0.version: " + str(loose_version_0.version))
    print("loose_version_1.version: " + str(loose_version_1.version))
    print("loose_version_0.vstring: " + str(loose_version_0.vstring))
    print("loose_version_1.vstring: " + str(loose_version_1.vstring))
    
    


# Generated at 2022-06-24 21:22:21.352605
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys
    if sys.hexversion < 0x02050000:
        return
    loose_version_0 = LooseVersion()
    loose_version_0.parse('1.5.1')


# Generated at 2022-06-24 21:22:22.698243
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_0 = LooseVersion()

    version_0.parse('1.5.1')


# Generated at 2022-06-24 21:22:33.541842
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    # Test a string containing only numbers
    version_0 = "123456789"
    version = LooseVersion(version_0)
    version.parse(version_0)

    # Test a string containing only letters
    version_1 = "abcdefghijklmnopqrstuvwyz"
    version = LooseVersion(version_1)
    version.parse(version_1)

    # Test a string containing numbers and letters
    version_2 = "123456789abcdefghijklmnopqrstuvwyz"
    version = LooseVersion(version_2)
    version.parse(version_2)

    # Test a string containing only the period
    version_3 = "."
    version = LooseVersion(version_3)
    version.parse(version_3)

    # Test a string containing numbers

# Generated at 2022-06-24 21:22:43.094566
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.5.2b2')
    lv.parse('161')
    lv.parse('3.10a')
    lv.parse('8.02')
    lv.parse('3.4j')
    lv.parse('1996.07.12')
    lv.parse('3.2.pl0')
    lv.parse('3.1.1.6')
    lv.parse('2g6')
    lv.parse('11g')
    lv.parse('0.960923')
    lv.parse('2.2beta29')
    lv.parse('1.13++')
    lv.parse('5.5.kw')
    lv.parse('2.0b1pl0')

# Generated at 2022-06-24 21:22:45.179708
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # prepare the arguments
    # prepare the arguments
    vstring = '1.5.1'
    # execute the method
    result = LooseVersion(vstring)

# Generated at 2022-06-24 21:22:55.014049
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_1 = LooseVersion()


# Generated at 2022-06-24 21:23:02.347115
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Testing constructor, __init__
    loose_version_1 = LooseVersion(vstring=None)
    # Testing parse
    loose_version_1.parse('1.2.1')
    # Testing __str__
    print(str(loose_version_1))
    # Testing __repr__
    print(repr(loose_version_1))
    # Testing _cmp
    print(loose_version_1._cmp('1.2'))


# Generated at 2022-06-24 21:23:13.092459
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    cv0 = LooseVersion('1.5')
    cv0.vstring = '3.5'
    cv0.version = [3, 5]
    assert cv0.vstring == '3.5'
    assert cv0.version == [3, 5]
    # cv0.parse('1.5')
    cv0.version = [1, 5]
    assert cv0.vstring == '1.5'
    assert cv0.version == [1, 5]
    # cv0.parse('3.5')
    cv0.version = [3, 5]
    assert cv0.vstring == '3.5'
    assert cv0.version == [3, 5]
    # cv0.parse('3.5.0')
    cv0

# Generated at 2022-06-24 21:23:17.377395
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test only valid case
    loose_version_0 = LooseVersion()
    str_0 = "abc"
    assert_raises(ValueError, loose_version_0.parse, str_0)


# Generated at 2022-06-24 21:23:22.025772
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    string_0 = "yXs"
    collection_0 = LooseVersion()
    collection_0.parse(string_0)


# Generated at 2022-06-24 21:23:35.034986
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version = LooseVersion()
    version_string = "1.5.0"
    return loose_version.parse(version_string)


# Generated at 2022-06-24 21:23:44.086527
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    if LooseVersion.parse:

        print('')
        print('Testing LooseVersion.parse...')

        v = LooseVersion()
        v.parse('20.3b0')

        assert(v.version == [20, '3b', 0])

        #                           0    1    2    3    4    5    6    7

# Generated at 2022-06-24 21:23:46.624919
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_number_string = '123'
    v = LooseVersion()
    v.parse(version_number_string)


# Generated at 2022-06-24 21:23:54.573031
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_0.parse("")
    loose_version_1 = LooseVersion()
    loose_version_1.parse("2.2beta29")
    loose_version_2 = LooseVersion()
    loose_version_2.parse("3.4j")
    loose_version_3 = LooseVersion()
    loose_version_3.parse("3.1.1.6")
    loose_version_4 = LooseVersion()
    loose_version_4.parse("")
    loose_version_5 = LooseVersion()
    loose_version_5.parse("2.2beta29")
    loose_version_6 = LooseVersion()
    loose_version_6.parse("3.4j")
    loose_version_7 = LooseVersion()
   

# Generated at 2022-06-24 21:23:55.665949
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    pass


# Generated at 2022-06-24 21:23:58.967857
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Preparation
    loose_version_0 = LooseVersion()
    # Invalid call
    try:
        loose_version_0.parse()
        assert False
    except TypeError:
        pass


# Generated at 2022-06-24 21:24:06.743189
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    from distutils.tests import support
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

# Generated at 2022-06-24 21:24:09.657099
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_1 = LooseVersion("8.02")
    loose_version_2 = LooseVersion("8.02")
    assert loose_version_1.parse("8.02") == loose_version_2.parse("8.02")


# Generated at 2022-06-24 21:24:20.729707
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    loose_version_0.parse('1.5.1')
    loose_version_1.parse('1.5.2b2')
    loose_version_2 = LooseVersion()
    loose_version_2.parse('161')
    loose_version_3 = LooseVersion()
    loose_version_3.parse('3.10a')
    loose_version_4 = LooseVersion()
    loose_version_4.parse('8.02')
    loose_version_5 = LooseVersion()
    loose_version_5.parse('3.4j')
    loose_version_6 = LooseVersion()
    loose_version_6.parse('1996.07.12')
    loose_version_7 = Loose

# Generated at 2022-06-24 21:24:23.266425
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Check that LooseVersion().parse() can be called
    test_case_0()



# Generated at 2022-06-24 21:24:40.950415
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    :Description: Python verion function
    :return:
    """
    loose_version_0 = LooseVersion()
    version_string_0 = '3.2.2'
    loose_version_0.parse(version_string_0)
    # Assertions
    assert(loose_version_0.vstring == '3.2.2')
    assert(loose_version_0.version == [3, 2, 2])
#

# Generated at 2022-06-24 21:24:44.302114
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_0.parse('0')
    loose_version_0.parse('1a2')


# Generated at 2022-06-24 21:24:51.652939
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1.5.1")
    v.parse("1.5.2b2")
    v.parse("161")
    v.parse("3.10a")
    v.parse("8.02")
    v.parse("3.4j")
    v.parse("1996.07.12")
    v.parse("3.2.pl0")
    v.parse("3.1.1.6")
    v.parse("2g6")
    v.parse("11g")
    v.parse("0.960923")
    v.parse("2.2beta29")
    v.parse("1.13++")
    v.parse("5.5.kw")
    v.parse("2.0b1pl0")


# Generated at 2022-06-24 21:25:03.042605
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import sys
    if sys.version_info[0]==2 and sys.version_info[1]==4:
    ####
    # TODO:  Maybe this is a bug in python itself, since the same algorithm works well when it's in a function
    #
        import unittest
        test_case = unittest.FunctionTestCase(test_case_0)
        suite = unittest.TestSuite()
        suite.addTest(test_case)
        unittest.TextTestRunner().run(suite)
        return
    ####
    # If a string is passed to the constructor, parse its parameters
    # according to the regular expression above
    loose_version_0 = LooseVersion('1.5.1')
    assert '1.5.1' == repr(loose_version_0)
    loose

# Generated at 2022-06-24 21:25:06.678335
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    expected = (1, 0)
    actual = loose_version_0.parse("1.0")
    diff = expected - actual
    assert expected == actual, \
        " expected: %s \n actual: %s \n diff: %s" % (expected, actual, diff)


# Generated at 2022-06-24 21:25:16.635396
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Create an instance of LooseVersion
    lv = LooseVersion()
    ## test if the method parse of LooseVersion is working correctly
    lv.parse("1.5.1")
    test.compare(lv.version, [1,5,1], "1.5.1 should be pythonically equivalent to [1,5,1]")
    lv.parse("1.5.2b2")
    test.compare(lv.version, [1,5,2,"b",2], "1.5.2b2 should be pythonically equivalent to [1,5,2,'b',2]")
    lv.parse("161")
    test.compare(lv.version, [161], "161 should be pythonically equivalent to [161]")
    lv.parse("3.10a")
    test.comp

# Generated at 2022-06-24 21:25:21.788418
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    vstring = "1.5.1"
    loose_version_0 = LooseVersion()
    loose_version_0.parse(vstring)
    assert_equals(loose_version_0.version, [1, 5, 1])



# Generated at 2022-06-24 21:25:29.493192
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    assert(LooseVersion().parse('1.5.1') == (1, 5, 1))
    assert(LooseVersion().parse('1.5.2b2') == (1, 5, 2, 'b2'))
    assert(LooseVersion().parse('161') == (161,))
    assert(LooseVersion().parse('3.10a') == (3, 10, 'a'))
    assert(LooseVersion().parse('8.02') == (8, 2))
    assert(LooseVersion().parse('3.4j') == (3, 4, 'j'))
    assert(LooseVersion().parse('1996.07.12') == (1996, 7, 12))
    assert(LooseVersion().parse('3.2.pl0') == (3, 2, 'pl0'))

# Generated at 2022-06-24 21:25:33.808061
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    # Create a LooseVersion instance
    loose_version_0 = LooseVersion()

    # Call the parse method with one parameter.
    # No return value expected
    loose_version_0.parse('78,09')

    # Call the parse method with one parameter.
    # No return value expected
    loose_version_0.parse('36.44')

    # Call the parse method with one parameter.
    # No return value expected
    loose_version_0.parse('0.85')


# Generated at 2022-06-24 21:25:37.904214
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1.2.3")
    v.parse("a.b.c")
    v.parse("a.b.c.d")  # this should not trigger an exception


# Generated at 2022-06-24 21:26:04.194384
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    str_arg = ''
    loose_version_0.parse(str_arg)
    str_arg = 'String()'
    loose_version_0.parse(str_arg)


# Generated at 2022-06-24 21:26:07.680109
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse(): 
    print('Testing parse')
    try:
        LooseVersion(vstring='')
    except AttributeError as err:
        print('Test Failed: ',err)
    else:
        print('Test Passed')


# Generated at 2022-06-24 21:26:13.419188
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion("1.0.4.2")

    if(v.version != [1,0,4,2]):
        raise Support.TestError("LooseVersion.parse \
            - method parse of class LooseVersion didn't work properly. Expected: [1,0,4,2]")

if __name__ == "__main__":
    test_case_0()
    test_LooseVersion_parse()

# Generated at 2022-06-24 21:26:20.058547
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    import pysemver   #

    # Test case for first use of parse
    loose_version_0 = LooseVersion()
    loose_version_0.parse('1.2.3')
    assert loose_version_0.version == ('1', '2', '3')
    loose_version_0.version = ('1', '2', '3')
    assert loose_version_0.__str__() == '1.2.3'
    assert loose_version_0._cmp(loose_version_0.__str__()) == 0

    # Test case for second use of parse
    loose_version_1 = LooseVersion()
    loose_version_1.parse('4.5.6')
    assert loose_version_1.version == ('4', '5', '6')

# Generated at 2022-06-24 21:26:25.773946
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:26:34.551450
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def test_case_0():
        loose_version_0 = LooseVersion('1.2a3')
        
        # 
        assert_match(re.compile(r'1.2a3'), loose_version_0.vstring,
            'Unexpected value for vstring')
        assert_equal(loose_version_0.version, ([1,2,'a',3]),
            'Unexpected value for version')

    def test_case_1():
        loose_version_1 = LooseVersion('1.2b3')
        
        # 
        assert_match(re.compile(r'1.2b3'), loose_version_1.vstring,
            'Unexpected value for vstring')

# Generated at 2022-06-24 21:26:37.028636
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Make sure ArgumentError is raised when no arguments
    # are given.
    with pytest.raises(TypeError):
        loose_version_1 = LooseVersion()
        loose_version_1.parse()


# Generated at 2022-06-24 21:26:38.994896
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    loose_version_0 = LooseVersion()
    loose_version_0.parse(str_arg_0)


# Generated at 2022-06-24 21:26:41.163532
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    s = "2.2beta29"
    lv = LooseVersion(s)
    lv.parse(s)

    s = "1.13++"
    lv = LooseVersion(s)
    lv.parse(s)


# Generated at 2022-06-24 21:26:46.713302
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Set up parameters
    vstring = "1.2.3.4"

    # Init object
    v = LooseVersion()

    # Call method
    result = v.parse(vstring)

    # Check result
    expected_result = None
    assert result == expected_result
