

# Generated at 2022-06-24 21:17:22.782867
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()

    version_1.__le__(None)


# Generated at 2022-06-24 21:17:28.980712
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('')
    assert version.__str__() == '0.0.0'
    version = StrictVersion('1.2.3')
    assert version.__str__() == '1.2.3'
    version = StrictVersion('1.2.1.4')
    assert version.__str__() == '1.2.0'
    version = StrictVersion('1.2a3')
    assert version.__str__() == '1.2a3'
    version = StrictVersion('1.2b3')
    assert version.__str__() == '1.2b3'
    version = StrictVersion('1.2a3b4')
    assert version.__str__() == '1.2a3'



# Generated at 2022-06-24 21:17:32.491705
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    loose_version_0 = LooseVersion()

    try:
        loose_version_0.__ge__()
    except TypeError:
        pass
    else:
        assert False

    test_case_0()


# Generated at 2022-06-24 21:17:39.248851
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test1: test if the result is string
    test_StrictVersion = StrictVersion()
    test_StrictVersion.version = (0, 4, 1)
    test_StrictVersion.prerelease = None
    result = test_StrictVersion.__str__()
    assert isinstance(result, str)
    assert result == "0.4.1"
    # Test2: test if the result contains decimal
    test_StrictVersion.version = (0, 4)
    test_StrictVersion.prerelease = None
    result = test_StrictVersion.__str__()
    assert isinstance(result, str)
    assert result == "0.4"
    # Test3: test if the result contains a letter
    test_StrictVersion.version = (0, 5)
    test_StrictVersion.prerelease

# Generated at 2022-06-24 21:17:41.956781
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    expected = True
    actual = None

    loose_version_0 = LooseVersion()

    assert_equal(expected, actual)


# Generated at 2022-06-24 21:17:44.664770
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    str_0 = str(loose_version_0)
    assert str_0 == "0.0"


# Generated at 2022-06-24 21:17:48.133693
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # This unit test will fail if the semantic versioning class does
    # not implement the expected interface.  We test only method that
    # is not part of the base class.
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:17:51.655623
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion("0.9.6")
    assert str(version_0) == "0.9.6"


# Generated at 2022-06-24 21:17:56.438690
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """test_Version___ge__()"""
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert loose_version_0 >= loose_version_1, "Test failed"
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert loose_version_0 >= loose_version_1, "Test failed"


# Generated at 2022-06-24 21:17:58.530708
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion()
    s = '0.7'
    try:
        loose_version_0._cmp(s)
    except NameError:
        pass


# Generated at 2022-06-24 21:18:11.677024
# Unit test for method __le__ of class Version
def test_Version___le__():
    x = Version()
    y = Version()
    x.__le__(y)


# Generated at 2022-06-24 21:18:14.984998
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_1 = LooseVersion("0")
    loose_version_2 = LooseVersion("0")
    assert (loose_version_1 == loose_version_2)


# Generated at 2022-06-24 21:18:15.831096
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    assert not (loose_version_0 <= '')


# Generated at 2022-06-24 21:18:17.316910
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version = LooseVersion()
    assert(loose_version == None)

# Unit tests for class StrictVersion

# Generated at 2022-06-24 21:18:18.981566
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    test_case_0()


# Generated at 2022-06-24 21:18:21.977787
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # v = Version()
    # actual = v.__eq__()
    raise NotImplementedError(
        "Unsupported version: %s" % (Version(),))


# Generated at 2022-06-24 21:18:25.164419
# Unit test for method __le__ of class Version
def test_Version___le__():
    '''test_case_0'''
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    assert (loose_version_0 <= loose_version_1)

# Generated at 2022-06-24 21:18:32.361160
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v_0 = Version()
    v_1 = Version()
    v_2 = Version()
    v_3 = Version()
    v_4 = Version()
    # Case 1
    v_0.parse('1.1.1')
    v_1.parse('1.1.1')
    result = v_0.__eq__(v_1)
    assert result == True


# Generated at 2022-06-24 21:18:41.940099
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version = StrictVersion()
    version.parse("2.7.2")
    version.parse("1.0.0.0.0.0")
    version.parse("1.0.0.0.0.0.0")
    version.parse("1.3.6.2")
    version.parse("1.3.6.2.4")
    version.parse("2.7.2-a0")
    version.parse("2.7.2-a0-0")
    version.parse("2.7.2-0-0-0")
    version.parse("2.7.2-a0-0-0")
    version.parse("2.7.2-a0-0-0-0")
    version.parse("2.7.2-0-0-0-0")
   

# Generated at 2022-06-24 21:18:44.481808
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Check that '__le__' given different class raises TypeError
    try:
        Version().__le__(StrictVersion())
    except TypeError:
        pass
    else:
        raise AssertionError("TypeError expected")


# Generated at 2022-06-24 21:18:59.934096
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test plan:
    #
    # 1. Create a LooseVersion object 'loose_version_0'
    # 2. Create two strings 's_0' and 's_1'
    # 3. Call 'loose_version_0.parse(s_0)'
    # 4. Call 'loose_version_0.parse(s_1)'
    # 5. If 'loose_version_0.__eq__(s_0)' returns True,
    #    AND 'loose_version_0.__eq__(s_1)' returns False,
    #    then the test passes; otherwise, it fails
    pass


# Generated at 2022-06-24 21:19:03.280657
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # version_0 = Version(vstring=None)
    # version_1 = Version()
    # version.__gt__(version_1)
    # version.__ge__(vstring)
    # version.__le__(version_1)
    pass


# Generated at 2022-06-24 21:19:14.460377
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_1 = LooseVersion("1.2.3")
    loose_version_2 = LooseVersion("1.2.3")
    strict_version_3 = StrictVersion("1.2.3")
    loose_version_4 = LooseVersion("1.2.4")
    loose_version_5 = LooseVersion("1.0.0")
    strict_version_6 = StrictVersion("2.0.0")

    assert loose_version_1.__eq__(strict_version_3) == True
    assert loose_version_1.__eq__(loose_version_2) == True
    assert loose_version_2.__eq__(loose_version_1) == True
    assert loose_version_2.__eq__(loose_version_4) == False
    assert loose

# Generated at 2022-06-24 21:19:17.155189
# Unit test for method __le__ of class Version
def test_Version___le__():

    test_case = {'base_version': LooseVersion('0'),
                 'new_version': LooseVersion('0')}
    result = test_case['base_version'] <= test_case['new_version']
    assert result is True



# Generated at 2022-06-24 21:19:18.467520
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    assert loose_version_0 <= "0.0"


# Generated at 2022-06-24 21:19:25.220835
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # test_0
    loose_version_0 = LooseVersion('0.0.1')
    loose_version_1 = LooseVersion('0.1.0')
    assert (loose_version_0 != loose_version_1)


# Generated at 2022-06-24 21:19:27.537071
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion()


# Generated at 2022-06-24 21:19:29.868223
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_1 = LooseVersion("1.1.1")
    loose_version_2 = LooseVersion("2.2.2")
    assert loose_version_1.__lt__(loose_version_2) == True


# Generated at 2022-06-24 21:19:32.637409
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert LooseVersion('1.0') > '0.9.1'
    assert LooseVersion('0.9.1') < '1.0'

# Generated at 2022-06-24 21:19:39.752836
# Unit test for method __le__ of class Version
def test_Version___le__():
    # args: version number, expected result
    # version number is a string representing a valid version number
    cases = [
        ('0.1.0a1', '<='),
    ]
    for vnum, exp in cases:
        v0 = LooseVersion(vnum)
        if exp == '<=':
            assert v0 <= '0.1.0a1'
        else:
            assert not v0 <= '0.1.0a1'



# Generated at 2022-06-24 21:19:51.094897
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0.parse("1.0.0")
    assert (version_0 >= "0.9.9")
    assert (version_0 != "2.0.0")
    assert (version_0 <= "1.3.3")


# Generated at 2022-06-24 21:19:59.743907
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    assert v.__gt__(1) is NotImplemented # Non-Version cannot be compared with Version
    assert v.__ge__(1) is NotImplemented # Non-Version cannot be compared with Version
    assert v.__eq__(1) is NotImplemented # Non-Version cannot be compared with Version
    assert v.__le__(1) is NotImplemented # Non-Version cannot be compared with Version
    assert v.__lt__(1) is NotImplemented # Non-Version cannot be compared with Version

    # setup
    v1 = 1
    v2 = 2

    v3 = Version()
    v4 = Version()

    assert v3.__ge__(v2) is False # v3 is not >= v2
    assert v3.__gt__(v2) is False #

# Generated at 2022-06-24 21:20:05.905888
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    Test python bytecode of
    Version.__gt__()
    """
    from types import FunctionType

    from lib_pypy._version import __gt__ as func

    assert isinstance(func, FunctionType)
    version_0 = Version()
    version_1 = Version()
    assert func.__code__.co_argcount == 2
    assert func.__code__.co_varnames == ('self', 'other')
    func(version_0, version_1)


# Generated at 2022-06-24 21:20:10.032321
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    try:
        assert version_0.__gt__("") is NotImplemented
    except AssertionError as e:
        print('AssertionError:', e)
        print('AssertionError: assert version_0.__gt__("") is NotImplemented')


# Generated at 2022-06-24 21:20:11.736152
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_1 = StrictVersion("0.4")
    assert(version_1.__str__() == "0.4")


# Generated at 2022-06-24 21:20:14.155759
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    try:
        result = version_0.__le__(Exception())
    except NotImplementedError as e:
        assert True
    else:
        assert False


# Generated at 2022-06-24 21:20:15.249682
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_0 = StrictVersion()
    version_0.parse('2')


# Generated at 2022-06-24 21:20:20.785039
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version(vstring="1.0.0")

    # Test: vstring > vstring
    vstring = "1.1.0"
    v2 = Version(vstring=vstring)
    assert (v1 > v2) == False

    # Test: vstring > vobject
    vstring = "1.1.0"
    vobject = Version(vstring=vstring)
    assert (v1 > vobject) == False

    # Test: vobject > vstring
    vstring = "1.1.0"
    vobject = Version(vstring=vstring)
    assert (vobject > v1) == True

    # Test: vobject > vobject
    vstring = "1.1.0"
    vobject = Version(vstring=vstring)

# Generated at 2022-06-24 21:20:22.228104
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0._cmp(version_1) is NotImplemented)


# Generated at 2022-06-24 21:20:26.532902
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    try:
        version_0.__gt__(version_1)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:20:36.693253
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
  assert StrictVersion('1.2').__str__() == '1.2'
  assert StrictVersion('1.2.0').__str__() == '1.2.0'



# Generated at 2022-06-24 21:20:41.771172
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 > version_1) == False


# Generated at 2022-06-24 21:20:43.425925
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    result = version_0.__gt__(version_0)
    assert result == False


# Generated at 2022-06-24 21:20:48.569563
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0.__gt__('#')


# Generated at 2022-06-24 21:20:57.442528
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    assert str(version_0) == '0'
    version_0.parse('0.0.0')
    assert str(version_0) == '0.0'
    version_0.parse('1.0.0')
    assert str(version_0) == '1.0'
    version_0.parse('0.0.1')
    assert str(version_0) == '0.0.1'
    version_0.parse('23.2.3a2')
    assert str(version_0) == '23.2.3a2'


# Generated at 2022-06-24 21:21:02.602411
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_0 = StrictVersion()
    version_0.parse('1.3a4')
    assert(version_0.version == (1,3,0))
    assert(version_0.prerelease == ('a',4))


# Generated at 2022-06-24 21:21:05.391940
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    assert(version_0.__gt__("") == NotImplemented)


# Generated at 2022-06-24 21:21:16.516680
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Version 0.4
    version_0 = StrictVersion('0.4')
    assert str(version_0) == '0.4'
    assert version_0.__str__() == '0.4'
    # Version 0.4.0
    version_0_0 = StrictVersion('0.4.0')
    assert str(version_0_0) == '0.4.0'
    assert version_0_0.__str__() == '0.4.0'
    # Version 0.5a1
    version_0_5a1 = StrictVersion('0.5a1')
    assert str(version_0_5a1) == '0.5a1'
    assert version_0_5a1.__str__() == '0.5a1'
    # Version 1.0

# Generated at 2022-06-24 21:21:19.129509
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0.__gt__(version_1) == False)


# Generated at 2022-06-24 21:21:21.733649
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 >= version_1
    assert version_0 >= version_1


# Generated at 2022-06-24 21:21:29.433073
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version()
    version_2 = Version()
    assert version_1.__gt__(version_2)



# Generated at 2022-06-24 21:21:33.662229
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse('1.0')
    version_1.parse('1.0.0')
    assert(version_0 > version_1)


# Generated at 2022-06-24 21:21:38.611087
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    assert (version_1 != version_2)

    # test true condition
    assert (version_1 > version_3)
    assert (not version_1 > version_2)

    # test false condition
    assert (not version_1 > version_2)



# Generated at 2022-06-24 21:21:46.773339
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version("1.0.1")
    version_2 = Version("1.0.2")
    version_3 = Version("1.0.1")
    assert version_1 > version_2
    assert version_2 < version_1
    assert not version_1 < version_2
    assert not version_2 > version_1
    assert not version_1 > version_3
    assert not version_3 > version_1
    assert not version_3 < version_1
    assert not version_1 < version_3


# Generated at 2022-06-24 21:21:50.093906
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = version("2.5.6")
    version_1 = version("3.6.4")
    version_0.__gt__(version_1)


# Generated at 2022-06-24 21:21:54.194354
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version()
    version_2 = Version()

# Generated at 2022-06-24 21:21:57.406239
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0.__gt__(version_1) is None)

# Generated at 2022-06-24 21:22:01.583585
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    try:
        version_0.__gt__(None)
    except TypeError as raised_exception:
        print(raised_exception)


# Generated at 2022-06-24 21:22:04.644443
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    ret_val_0 = version_0.__gt__('5.5.5')
    assert type(ret_val_0) == NotImplementedType


# Generated at 2022-06-24 21:22:13.324420
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Creating some dummy instances of Version with different versions.
    version0 = Version()
    version1 = Version()
    version2 = Version()
    version3 = Version()
    version4 = Version()
    version5 = Version()
    version6 = Version()
    version7 = Version()
    version8 = Version()
    version9 = Version()

    # Testing the __gt__ function.
    assert not version0 > version0
    assert not version1 > version1
    assert not version2 > version2
    assert not version3 > version3
    assert not version4 > version4
    assert not version5 > version5
    assert not version6 > version6
    assert not version7 > version7
    assert not version8 > version8
    assert not version9 > version9


# Generated at 2022-06-24 21:22:28.840914
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version("0.0.0")
    v1 = Version("0.0.1")
    assert(v0 < v1)

# Generated at 2022-06-24 21:22:30.182016
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert not (version_0 > version_1)


# Generated at 2022-06-24 21:22:39.214195
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    assert version_0.__gt__('1.8.0') == False
    assert version_0.__gt__('1.7.0') == False
    version_0 = Version('1.3.1')
    version_1 = Version()
    assert version_0.__gt__('1.8.0') == False
    assert version_0.__gt__('1.7.0') == False
    version_0 = Version()
    version_1 = Version('1.3.1')
    assert version_0.__gt__(version_1) == False
    assert version_1.__gt__(version_0) == True


# Generated at 2022-06-24 21:22:44.057903
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()

    version_0.parse("1.0")
    version_1.parse("0.9")
    assert version_0 > version_1


# Generated at 2022-06-24 21:22:47.779047
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version("1.0")
    version_1 = Version("1.1")
    assert version_0.__gt__(version_1) == False
    assert version_1.__gt__(version_0) == True


# Generated at 2022-06-24 21:22:49.682394
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(Version()) == NotImplemented


# Generated at 2022-06-24 21:22:59.090437
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_21 = Version()
    version_22 = Version()
    version_23 = Version()
    version_24 = Version()

# Generated at 2022-06-24 21:23:03.873324
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version()
    v1 = Version()
    assert v0 == v1
    assert not v0 > v1
    assert not v0 < v1

    v2 = Version('2')
    assert v1 < v2
    assert not v1 > v2



# Generated at 2022-06-24 21:23:09.522927
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()

    version_6 = Version()
    version_6 = version_6.__gt__(version_4)


# Generated at 2022-06-24 21:23:12.627832
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()

    version_0.parse('2.6')
    version_1.parse('2.7')

    assert version_0.__gt__(version_1) == False


# Generated at 2022-06-24 21:23:36.820422
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    string_0 = "1.1.0"
    string_1 = "1.1.1"
    # Test that the comparison is lexicographic, and not numeric.
    assert version_0.__gt__(string_0)


# Generated at 2022-06-24 21:23:38.156292
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()




# Generated at 2022-06-24 21:23:40.841611
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0.parse('1.1.1')
    version_1 = Version('1.1.1')
    assert (version_0 > version_1) == True



# Generated at 2022-06-24 21:23:43.489692
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    assert Version('2').__gt__(Version('1'))
    assert not Version('1').__gt__(Version('2'))
    assert not Version('1').__gt__(Version('1'))


# Generated at 2022-06-24 21:23:44.822857
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()



# Generated at 2022-06-24 21:23:51.986746
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
  
    # Case 0
    looseVersion = LooseVersion()
    looseVersion.parse("2.2")
    assert looseVersion.version == [ 2, 2 ]
    
    # Case 1
    looseVersion = LooseVersion()
    looseVersion.parse("1.1.1")
    assert looseVersion.version == [ 1, 1, 1 ]
    
    # Case 2
    looseVersion = LooseVersion()
    looseVersion.parse("1.1a")
    assert looseVersion.version == [ 1, 1, "a" ]

# Generated at 2022-06-24 21:23:54.082872
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version("1.0b")
    assert v > (1, 0, 0)
    assert v > "1.0b"


# Generated at 2022-06-24 21:23:57.609677
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver1 = Version("1.0")
    ver2 = Version("2.0")
    assert ver2 > ver1


# Generated at 2022-06-24 21:24:00.658666
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    var_1 = version_0.__gt__(version_1)
    assert(var_1 == False)


# Generated at 2022-06-24 21:24:02.619410
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    boolean_var_0 = version_0 > version_1


# Generated at 2022-06-24 21:24:58.677674
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    compare_result = version_0 > 'a'
    assert compare_result == 1, "'a' should be smaller than Version instance"
    version_1 = Version()
    assert version_0 >= version_1, "invalid comparison result"
    assert version_0 >= 'a', "'a' should be smaller than Version instance"
    assert version_0 >= '1.0', "Version instance should be greater than '1.0'"


# Generated at 2022-06-24 21:25:00.859902
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0 >= version_1)


# Generated at 2022-06-24 21:25:06.470320
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse('0.7.8')

    if version_0.__gt__(version_1):
        raise RuntimeError("version_0.__gt__(version_1)")
    if not version_1.__gt__(version_0):
        raise RuntimeError("not version_1.__gt__(version_0)")


# Generated at 2022-06-24 21:25:16.504093
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse('v0.1')
    version_1.parse('v0.1')
    assert(version_0.__ge__(version_1))
    version_0.parse('v0.1')
    assert(version_0.__ge__(version_1))
    version_0.parse('v0.1')
    version_1.parse('v0.2')
    assert(version_0.__ge__(version_1))
    version_0.parse('v0.2')
    assert(version_0.__ge__(version_1))
    version_0.parse('v0.3')
    version_1.parse('v0.2')
    assert(version_0.__ge__(version_1))

# Generated at 2022-06-24 21:25:19.903605
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()


# Generated at 2022-06-24 21:25:21.639789
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    result = version_0.__gt__(version_1)
    assert result


# Generated at 2022-06-24 21:25:25.612501
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    str_arg_1 = '2.7.1'
    assert version_0.__gt__(str_arg_1) == NotImplemented


# Generated at 2022-06-24 21:25:29.055448
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 > version_1


# Generated at 2022-06-24 21:25:30.557636
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    assert v1.__gt__('0.0')


# Generated at 2022-06-24 21:25:34.348965
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse('0.4')
    version_1.parse('0.5')
    assertEqual(version_0.__gt__(version_1), False)
