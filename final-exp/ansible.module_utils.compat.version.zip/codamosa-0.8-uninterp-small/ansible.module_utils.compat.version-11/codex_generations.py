

# Generated at 2022-06-24 21:17:19.838518
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version('1.2.3.4.5')
    version_0 = version_0.__lt__(version_0)


# Generated at 2022-06-24 21:17:22.976997
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('')
    version_1 = Version('')
    assert version_0.__eq__(version_1)


# Generated at 2022-06-24 21:17:24.530254
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    str_0 = str(version_0)

    assert(str_0 == "0")


# Generated at 2022-06-24 21:17:31.715485
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    assert '' < '1'
    assert '' < '1.1'
    assert '' < '1.1.1'
    assert '' < '1.1.1.1'
    assert '' < '1.1.1.1.1'
    assert '' < '1.1.1.1.1.1'
    assert '' < '1.1.1.1.1.1.1'
    assert '' < '1.1.1.1.1.1.1.1'
    assert '' < '1.1.1.1.1.1.1.1.1'
    assert '' < '1.1.1.1.1.1.1.1.1.1'

# Generated at 2022-06-24 21:17:42.889842
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion('-')
    version_1 = StrictVersion('-')
    version_2 = StrictVersion('-')
    version_3 = StrictVersion('-')
    version_4 = StrictVersion('-')
    version_5 = StrictVersion('-')
    version_6 = StrictVersion('-')
    version_7 = StrictVersion('-')
    version_8 = StrictVersion('-')
    version_9 = StrictVersion('-')
    version_10 = StrictVersion('-')
    version_11 = StrictVersion('-')
    version_12 = StrictVersion('-')
    version_13 = StrictVersion('-')
    version_14 = StrictVersion('-')
    version_15 = StrictVersion('-')
    version_16 = Strict

# Generated at 2022-06-24 21:17:47.529255
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    other_0 = Version()
    c_0 = version_0._cmp(other_0)
    c_1 = c_0 > 0
    msg_0 = type(c_1)
    msg_1 = str(msg_0)
    msg_2 = repr(msg_0)
    assert msg_1 == msg_2


# Generated at 2022-06-24 21:17:51.801789
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    str_arg_1 = '0'
    bool_arg_2 = version_0.__ge__(str_arg_1)
    return (bool_arg_2)


# Generated at 2022-06-24 21:17:57.474026
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_0.parse('0.1.1')
    version_1.parse('0.1.1')
    version_2.parse('0.1.1')
    expected_result = version_0 == version_1
    expected_result = version_1 == version_0
    expected_result = version_1 == version_2


# Generated at 2022-06-24 21:18:04.401170
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0._cmp = lambda self, other: None
    version_1 = Version()
    version_1._cmp = lambda self, other: NotImplemented
    try:
        version_0 < version_1
    except TypeError as raised_exception:
        assert str(raised_exception) == "'<' not supported between instances of 'Version' and 'Version'"


# Generated at 2022-06-24 21:18:07.248881
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version(None)
    version_1 = Version(None)
    version_0.parse("1.2")
    version_1.parse("1.2+666")
    version_2 = version_0 <= version_1


# Generated at 2022-06-24 21:18:17.836395
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    a = LooseVersion('')
    a.parse('1.5.1')
    assert(a.version == [1, 5, 1])

    a = LooseVersion('')
    a.parse('1.5.2b2')
    assert(a.version == [1, 5, '2b2'])

    a = LooseVersion('')
    a.parse('161')
    assert(a.version == [161])

    a = LooseVersion('')
    a.parse('3.10a')
    assert(a.version == [3, '10a'])

    a = LooseVersion('')
    a.parse('8.02')
    assert(a.version == [8, '02'])

    a = LooseVersion('')

# Generated at 2022-06-24 21:18:22.127899
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    str_expected = ""
    str_actual = version_0.__str__()
    print("str_actual = " + str_actual)
    assert(str_expected == str_actual)


# Generated at 2022-06-24 21:18:25.429505
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert test_case_1().__le__(test_case_0()) == True
    assert test_case_0().__le__(test_case_1()) == False


# Generated at 2022-06-24 21:18:27.410052
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    assert (v1 <= v2)


# Generated at 2022-06-24 21:18:28.969647
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    if version_0.__ge__(version_0) == NotImplemented:
        pass # caught exception
    assert True



# Generated at 2022-06-24 21:18:35.859781
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_1 = StrictVersion('0.4')
    version_2 = StrictVersion('0.4.0')
    version_3 = StrictVersion('0.4.1')
    version_4 = StrictVersion('0.5a1')
    version_5 = StrictVersion('0.5b3')
    version_6 = StrictVersion('0.5')
    version_7 = StrictVersion('0.9.6')
    version_8 = StrictVersion('1.0')
    version_9 = StrictVersion('1.0.4a3')
    version_10 = StrictVersion('1.0.4b1')
    version_11 = StrictVersion('1.0.4')


# Generated at 2022-06-24 21:18:40.005216
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1
    assert version_0 >= version_1
    assert version_0 <= version_1
    assert not version_0 > version_1
    assert not version_0 < version_1


# Generated at 2022-06-24 21:18:41.576501
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    assert isinstance(version_0, StrictVersion)
    assert isinstance(version_0, Version)


# Generated at 2022-06-24 21:18:44.895192
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = version_0
    try:
        assert version_0 == version_1
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-24 21:18:48.021202
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Create an instance of Versio
    version_0 = Version()


# Generated at 2022-06-24 21:18:57.110401
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v_x = Version()
    v_y = Version()
    if (v_x >= v_y):
        z = Version()


# Generated at 2022-06-24 21:18:59.177730
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()

    version_0.__lt__(version_1)



# Generated at 2022-06-24 21:19:02.500942
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if not version_0==version_1:
        test_fail('test_Version___eq__')
    else:
        test_pass('test_Version___eq__')


# Generated at 2022-06-24 21:19:14.137001
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()

# Generated at 2022-06-24 21:19:17.703607
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_0 = LooseVersion("0.1.2.3")
    assert version_0.vstring == "0.1.2.3"


# Generated at 2022-06-24 21:19:24.238631
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()

    # Test case: True
    version_1 = Version()
    version_2 = Version()
    version_3 = version_1 < version_2
    assert version_3

    version_1 = Version()
    version_2 = Version()
    version_3 = version_1 < version_2
    assert version_3

    version_1 = Version()
    version_2 = Version()
    version_3 = version_1 < version_2
    assert version_3

    version_1 = Version()
    version_2 = Version()
    version_3 = version_1 < version_2
    assert version_3

    version_1 = Version()
    version_2 = Version()
    version_3 = version_1 < version_2
    assert version_3

    version_1 = Version()
   

# Generated at 2022-06-24 21:19:26.317285
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version("v")
    version_1 = Version("v")
    boolean_0 = version_0 > version_1



# Generated at 2022-06-24 21:19:32.478605
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    >>> from version import Version
    >>> version_0 = Version()
    >>> version_1 = Version()
    >>> result_bool = version_0 > version_1
    >>> result_bool
    False
    """


# Generated at 2022-06-24 21:19:35.645273
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0.__eq__(version_0)


# Generated at 2022-06-24 21:19:41.169454
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()



# Generated at 2022-06-24 21:20:12.335604
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0.__ge__("0.0.0") == True


# Generated at 2022-06-24 21:20:16.771386
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    version_2 = Version()
    version_1.__eq__(version_2)


# Generated at 2022-06-24 21:20:20.447880
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = str(version_0 == version_1)
    version_3 = str(version_0 > version_1)
    version_4 = str(version_0 < version_1)
    version_5 = str(version_0 <= version_1)
    version_6 = str(version_0 >= version_1)


# Generated at 2022-06-24 21:20:26.678705
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    result_1 = version_0.__ge__('')
    if result_1 in [0, NotImplemented]:
        pass
    else:
        raise Exception('Test failed')



# Generated at 2022-06-24 21:20:29.610358
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    assert version_0.__gt__(None) is NotImplemented
    assert version_0.__gt__('1.0') is True


# Generated at 2022-06-24 21:20:33.797069
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    # self <= other
    c1 = version_0._cmp(version_1)
    assert c1 == 0
    # self <= other
    c1 = version_0._cmp(str(version_1))
    assert c1 == 0
    # self <= other
    version_0._cmp(version_1, version_1)
    # TypeError: _cmp() takes 2 positional arguments but 3 were given
    with raises(TypeError):
        version_0._cmp(version_1, version_1, version_1)


# Generated at 2022-06-24 21:20:35.811808
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    b = version_0 <= version_1
    print(b)


# Generated at 2022-06-24 21:20:38.750357
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('04')
    version_1 = Version()
    version_1._Version__ver = version_0._Version__ver
    assert version_0.__eq__(version_1) == True


# Generated at 2022-06-24 21:20:40.513050
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    # Equality not implemented
    assert not version_0.__eq__(version_0)


# Generated at 2022-06-24 21:20:42.777916
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    with pytest.raises(TypeError):
        Version().__lt__()


# Generated at 2022-06-24 21:21:17.748375
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Arrange
    version_0 = Version('v1.0.0')
    comp = Version('v1.0.0')
    # Act
    value = version_0 < comp
    # Assert
    assert value == False


# Generated at 2022-06-24 21:21:21.486610
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = re.compile(r'\d+\.\d+a\d+')
    version_2 = LooseVersion('1.1a10')
    assert version_0 <= version_1


# Generated at 2022-06-24 21:21:22.660633
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version() == Version()


# Generated at 2022-06-24 21:21:24.455790
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test Cases for Version.__gt__
    testVersion = Version()
    stringPassed = "4.0.0"
    assert testVersion._cmp(stringPassed) > 0, "Failed case 0"


# Generated at 2022-06-24 21:21:26.858272
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print('Test of method __lt__')
    version_1 = Version()
    version_2 = Version()
    version_1.__lt__(version_2)


# Generated at 2022-06-24 21:21:27.854390
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= None


# Generated at 2022-06-24 21:21:32.322239
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    version = Version()
    version_0 = Version()
    # Call function with arguments: other = version_0
    c = version._cmp(version_0)
    if c is NotImplemented:
        return c
    return c == 0



# Generated at 2022-06-24 21:21:40.313607
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0._cmp = lambda *args: NotImplemented
    version_0._cmp = lambda *args: None
    version_0._cmp = lambda *args: True
    version_0._cmp = lambda *args: 1
    version_0._cmp = lambda *args: ""
    version_0._cmp = lambda *args: []
    version_0._cmp = lambda *args: ()
    version_0._cmp = lambda *args: {}
    #test_case_0()
    version_0._cmp = lambda x,y: NotImplemented
    assert version_0._cmp("a", "b") == NotImplemented
    version_0._cmp = lambda x,y: 0
    assert version_0._cmp("a", "b") == 0

# Generated at 2022-06-24 21:21:45.495049
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()

    # Test for Python 2.6
    # original exception: AttributeError: 'Version' object has no attribute '__cmp__'
    try:
        version_0.__gt__(version_1)
    except TypeError as e:
        print("TypeError: " + str(e))



# Generated at 2022-06-24 21:21:51.475208
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        version_1 = Version()
        version_2 = Version()
        result = version_1.__gt__(version_2)
        # Expecting NotImplemented
    except NotImplemented:
        pass


# Generated at 2022-06-24 21:22:57.981189
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()

    try:
        version_0.__eq__(version_1)
    except:
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-24 21:22:58.966750
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()


# Generated at 2022-06-24 21:23:07.550839
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()

    version_0.parse(u'7.0')
    version_1.parse(u'7.0')
    version_2.parse(u'7.0')
    assert (version_0 > version_1) == False
    assert (version_0 > version_2) == False
    assert (version_1 > version_0) == False
    assert (version_1 > version_2) == False
    assert (version_2 > version_0) == False
    assert (version_2 > version_1) == False
    version_0.parse(u'7.0')
    version_1.parse(u'7.0')
    version_2.parse(u'7.0')

# Generated at 2022-06-24 21:23:14.102827
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1_0 = Version()
    if (version_0 > version_1_0):
        raise RuntimeError("version_0 greater than version_1_0")


# Generated at 2022-06-24 21:23:22.225786
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    # test case 0
    result_0 = version_0.__ge__(version_3)
    assert result_0 == False

    # test case 1
    result_1 = version_1.__ge__(version_2)
    assert result_1 == True

    # test case 2
    result_2 = version_2.__ge__(version_8)

# Generated at 2022-06-24 21:23:25.403439
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version("Version")
    version_0.__ge__(version_1)


# Generated at 2022-06-24 21:23:28.915800
# Unit test for method __le__ of class Version
def test_Version___le__():
    from distutils.version import Version
    version_0 = Version()
    version_1 = Version()
    try:
        version_0 <= version_1
    except Exception as exc:
        print(exc)
        assert isinstance(exc, TypeError)


# Generated at 2022-06-24 21:23:34.341432
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0.parse('1.0.0')
    version_1 = Version('1.0.0')
    version_2 = Version()
    version_2.parse('2.0.0')
    print(version_0 < version_1)
    print(version_1 < version_2)


# Generated at 2022-06-24 21:23:36.698758
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    other_0 = ()
    version_0._cmp(other_0)


# Generated at 2022-06-24 21:23:38.490561
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    VERSION_0 = Version()
    VERSION_1 = Version()
    assert VERSION_0 < VERSION_1


# Generated at 2022-06-24 21:26:19.703266
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import pytest
    version_0 = Version()
    version_1 = Version('1')
    version_2 = Version('2')
    version_3 = Version('3')
    version_4 = Version('4')
    version_5 = Version('5')
    version_6 = Version('6')
    version_7 = Version('7')
    version_8 = Version('8')
    version_9 = Version('9')
    version_10 = Version('10')
    version_11 = Version('11')
    version_12 = Version('12')
    version_13 = Version('13')
    version_14 = Version('14')
    version_15 = Version('15')
    version_16 = Version('16')
    version_17 = Version('17')
    version_18 = Version('18')
    version_19 = Version

# Generated at 2022-06-24 21:26:26.111086
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_0 >= version_1
    version_2 = Version()
    version_1 >= version_2
    version_3 = Version()
    version_2 >= version_3
    version_0 >= version_3


# Generated at 2022-06-24 21:26:29.797517
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    result = version_0.__le__(version_1)
    assert(result == NotImplemented)

# Generated at 2022-06-24 21:26:32.265387
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = Version()
    res = version_1.__le__(version_2)


# Generated at 2022-06-24 21:26:43.457654
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version('1.2.3')

    # Test against a Version
    v2 = Version('1.2.3')
    assert (v == v2) is True
    v2 = Version('1.2.4')
    assert (v == v2) is False

    # Test against a string
    assert (v == '1.2.3') is True
    assert (v == '1.2.4') is False
    assert (v == '1.2.3.0') is True # (yes, this is loose equality)
    assert (v == '1.2.4.0') is False # (yes, this is loose equality)
    assert (v == '1.2.3dev0') is True # (yes, this is loose equality)
    assert (v == '1.2.4dev1') is False #

# Generated at 2022-06-24 21:26:46.873215
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_retval = version_0.__ge__(version_1)
    assert version_retval is True


# Generated at 2022-06-24 21:26:50.144851
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Create an instance of the Version class
    version_1 = Version()
    # Create an instance of the Version class
    version_2 = Version()
    # Invoke the __le__ method of the Version class
    result = version_1.__le__(version_2)


# Generated at 2022-06-24 21:26:53.672048
# Unit test for method __ge__ of class Version
def test_Version___ge__():
  version1 = Version()
  version2 = Version()
  attrs1 = dir(version1)
  assert(len(attrs1) == 4)
  attrs2 = dir(version2)
  assert(len(attrs2) == 4)


# Generated at 2022-06-24 21:26:56.183467
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    #cases = [
    #    (version_0, version_0, True),
    #]
    #print(check_cases(cases))
    pass


# Generated at 2022-06-24 21:27:00.196940
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1
    assert version_0 == version_1
    assert version_1 == version_0
