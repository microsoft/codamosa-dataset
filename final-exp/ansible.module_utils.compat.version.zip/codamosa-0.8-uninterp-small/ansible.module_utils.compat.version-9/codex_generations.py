

# Generated at 2022-06-24 21:17:23.235995
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if (version_0 == version_1):
        raise AssertionError('version_0 == version_1')


# Generated at 2022-06-24 21:17:26.582400
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert (version_0 >= '0')
    assert (version_0 >= version_0)
    assert (version_0 >= 0)
    assert not (version_0 >= '1')
    assert not (version_0 >= 'a')
    assert not (version_0 >= -1)


# Generated at 2022-06-24 21:17:28.354288
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion('0.1')
    assert version.__str__() == '0.1'


# Generated at 2022-06-24 21:17:32.795496
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0_lt_result = version_0.__lt__(Version())
    version_1 = Version()
    version_1_lt_result = version_1.__lt__(Version())
    assert version_0_lt_result == version_1_lt_result



# Generated at 2022-06-24 21:17:35.545670
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test for case 0
    version_0 = Version()
    version_1 = Version()
    result = version_0.__gt__(version_1)
    assert(not result)


# Generated at 2022-06-24 21:17:46.547126
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # tested class
    class TestClass(Version):
        pass

    # Localization: 'c' => '<'
    if TestClass("<") >= TestClass("<"):
        pass
    elif not TestClass("<") >= TestClass("<"):
        pass

    # Localization: 'c' => '<'
    if TestClass("<") >= TestClass("="):
        pass
    elif not TestClass("<") >= TestClass("="):
        pass

    # Localization: 'c' => '<'
    if TestClass("<") >= TestClass(">"):
        pass
    elif not TestClass("<") >= TestClass(">"):
        pass

    # Localization: 'c' => '='
    if TestClass("=") >= TestClass("<"):
        pass
    el

# Generated at 2022-06-24 21:17:48.582680
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = StrictVersion("1.0.0")
    assert version.__str__() == "1.0.0"


# Generated at 2022-06-24 21:17:52.146709
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver = Version()
    assert ver.__gt__(1), "Version.__gt__ didn't return expected value"


# Generated at 2022-06-24 21:17:53.165225
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()


# Generated at 2022-06-24 21:17:55.776505
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version('1')
    v2 = Version('2.0')
    assert v1 <= v1
    assert v1 <= v2
    assert not v2 <= v1


# Generated at 2022-06-24 21:18:05.524607
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version(vstring=None)
    version_0._cmp(version_1)


# Generated at 2022-06-24 21:18:16.517993
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0.parse("3.0")
    version_1 = Version()
    version_1.parse("2.2")
    version_2 = Version()
    version_2.parse("3.0")

    version_0._cmp = Version._cmp
    if version_0 < version_1:
        version_1._cmp = Version._cmp
        if version_1 < version_2:
            version_2._cmp = Version._cmp
            if version_2 < version_0:
                raise AssertionError
            else:
                raise AssertionError
        else:
            raise AssertionError
    else:
        raise AssertionError


# Generated at 2022-06-24 21:18:18.515951
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    # Create an object of class Version
    version_0 = Version()
    if version_0.__lt__(1) == NotImplemented:
        assert True
    else:
        assert False


# Generated at 2022-06-24 21:18:20.709643
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    other = Version()
    ret = version.__ge__(other)
    assert ret == True


# Generated at 2022-06-24 21:18:22.128432
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version() >= '0'


# Generated at 2022-06-24 21:18:25.429685
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0_vstring = None
    try:
        version_0.__gt__()
        assert False
    except Exception:
        pass


# Generated at 2022-06-24 21:18:28.076032
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 > version_1 is False


# Generated at 2022-06-24 21:18:35.676301
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    version_1 = StrictVersion('1.0')
    version_2 = StrictVersion('1.0.0')
    version_3 = StrictVersion('1.0b2')
    version_4 = StrictVersion('1.0b3')
    version_5 = StrictVersion('1.0a2')
    version_6 = StrictVersion('1.0a3')
    version_7 = StrictVersion('1.0.0')
    version_8 = StrictVersion('1.0.0a1')
    version_9 = StrictVersion('1.0.0c2')

    #''
    assert str(version_0) == ''
    #Version('1.0')
    assert str(version_1) == '1.0'
    #Version('

# Generated at 2022-06-24 21:18:37.485347
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('1')
    assert version_0 >= '1'


# Generated at 2022-06-24 21:18:45.145528
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    test_cases = [
        (
            (
                "0.4",
                "0.4.0",
            ),
            "these two are equivalent",
        ),
        (
            (
                "0.4.1",
                "0.5a1",
                "0.5b3",
                "0.5",
                "0.9.6",
                "1.0",
                "1.0.4a3",
                "1.0.4b1",
                "1.0.4",
            ),
            "valid version numbers",
        ),
    ]

    for (vectors, message) in test_cases:
        for vstring in vectors:
            version = StrictVersion(vstring)

# Generated at 2022-06-24 21:18:58.789114
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert not any((version_0 < version_1, version_0 < version_1, version_0 < version_1))


# Generated at 2022-06-24 21:19:00.967008
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    assert version_0.__lt__()
    assert (version_0.__lt__())



# Generated at 2022-06-24 21:19:04.553090
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()


# Generated at 2022-06-24 21:19:07.598883
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    __result = version_0.__eq__(version_1)
    assert __result


# Generated at 2022-06-24 21:19:10.756616
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('1.0')
    version_1 = Version('1.1')
    # Test that version_0 is not greater than version_1:
    assert not (version_0 > version_1)


# Generated at 2022-06-24 21:19:17.433101
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version("1.0")
    version_2 = Version("1.1")
    version_3 = Version("1.0")
    assert version_0 == None
    assert version_1 == version_3
    assert version_1 != version_2
    assert version_3 != version_2


# Generated at 2022-06-24 21:19:18.514968
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = Version()
    version = version.parse("0.4.0")
    assert(str(version) == "0.4")


# Generated at 2022-06-24 21:19:24.866649
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse("1.2.3")
    version_1.parse("1.2.2")

    assert version_0 > version_1


# Generated at 2022-06-24 21:19:27.249465
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    TestResult = version_0 == version_1


# Generated at 2022-06-24 21:19:29.866353
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda x: 0
    version_1._cmp = lambda x: 0
    try:
        assert version_0 < version_1
    except TypeError:
        pass


# Generated at 2022-06-24 21:19:51.276664
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    method_name = Version.__lt__.__name__
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    Number_0 = Version()
    Number_1 = Version()
    Number_0.__class__.__lt__(Number_0,Number_1)
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()


# Generated at 2022-06-24 21:19:55.956767
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_obj_0 = Version()
    version_obj_1 = Version()
    if version_obj_0.__eq__(version_obj_1):
        pass
    try:
        version_obj_0.__eq__("version_obj_0")
    except:
        pass


# Generated at 2022-06-24 21:19:58.044350
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Test case 0
    temp = StrictVersion()
    assert str(temp) == '0'


# Generated at 2022-06-24 21:20:04.717969
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0, v1 = Version(), Version()
    assert v0 == v1
    v0, v1 = Version(), Version()
    assert not v0 > v1
    v0, v1 = Version(), Version()
    assert not v0 >= v1
    v0, v1 = Version(), Version()
    assert not v1 < v0
    v0, v1 = Version(), Version()
    assert not v1 <= v0


# Generated at 2022-06-24 21:20:12.221122
# Unit test for method __le__ of class Version
def test_Version___le__():
    version = Version()
    assert str(version) == "''"
    assert version == ''
    assert version <= ''
    assert str(version) == "''"
    assert version <= ''
    assert version >= ''
    assert version >= ''
    assert version == Version('')
    assert version <= Version('')
    assert version >= Version('')
    assert str(version) == "''"


# Generated at 2022-06-24 21:20:18.190722
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    # prettify
    assert (version_0 <= version_1)


# Generated at 2022-06-24 21:20:24.135907
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    class TestStr(str):
        def __gt__(self, other):
            return False
        def __ge__(self, other):
            return True
        def __lt__(self, other):
            return True
        def __le__(self, other):
            return False
    def test_case_1():
        version_1 = Version()
        str_1 = TestStr()
        if version_1.__ge__(str_1) is None:
            pass
        else:
            raise ValueError('wrong type')
        if version_1.__ge__(str_1) is not NotImplemented:
            pass
        else:
            raise ValueError('wrong type')
    def test_case_2():
        version_1 = Version()


# Generated at 2022-06-24 21:20:25.820922
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0.__ge__(None) is NotImplemented


# Generated at 2022-06-24 21:20:27.546121
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        result = Version().__gt__(Version())
        assert False
    except TypeError:
        assert True

# ------------------------------------------------------------------------------


# Generated at 2022-06-24 21:20:34.782754
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print("test_StrictVersion___str__")
    version_0 = StrictVersion("1.1")
    print('version_0=', version_0)
    version_1 = StrictVersion("1.1.1")
    print('version_1=', version_1)

if __name__ == '__main__':
    test_case_0()
    test_StrictVersion___str__()

# Generated at 2022-06-24 21:20:56.940466
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert version_0.__eq__(version_0) == True


# Generated at 2022-06-24 21:21:01.428051
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    if not (version_0 <= version_1):
        raise ValueError


# Generated at 2022-06-24 21:21:04.507018
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        version_0 = Version()
        version_1 = Version()
        version_0.__gt__(version_1)
    except Exception as e:
        raise Exception('Method __gt__ of class Version raised an exception:', e)
    else:
        pass


# Generated at 2022-06-24 21:21:11.260697
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert_equal(Version('1.0').__eq__(Version('1.0')), None)
    assert_equal(Version('1.0').__eq__('1.0'), None)
    assert_equal(Version('1.0').__eq__(1), None)


# Generated at 2022-06-24 21:21:15.835998
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version("Verison")
    str_arg_1 = "1.0b1"
    var_1 = version_0.__ge__(str_arg_1)
    assert var_1 == False


# Generated at 2022-06-24 21:21:24.501580
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # default args
    version_0 = LooseVersion()
    assert version_0.version == () and version_0.vstring == ''

    # args
    version_1 = LooseVersion('0.9.6')
    assert version_1.vstring == '0.9.6' and version_1.version == ((0,), (9,), (6,))

    version_2 = LooseVersion('1.13++')
    assert version_2.vstring == '1.13++' and version_2.version == ((1,), (13,), (u'+',), (u'+',))

    version_3 = LooseVersion('1996.07.12')
    assert version_3.vstring == '1996.07.12' and version_3.version == ((1996,), (7,), (12,))

# Generated at 2022-06-24 21:21:26.928731
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    version_0.parse("1.1.1b3")
    str_0 = version_0.__str__()



# Generated at 2022-06-24 21:21:30.541790
# Unit test for method __le__ of class Version
def test_Version___le__():
    a = Version('1.1.1')
    b = Version('1.1.1')
    if not a <= b:
        raise AssertionError


# Generated at 2022-06-24 21:21:35.797976
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('2')
    version_1 = Version('3.4.5')
    try:
        version_0.__ge__(version_1)
    except ValueError:
        return True
    return False


# Generated at 2022-06-24 21:21:40.181815
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda x: 3
    version_1._cmp = lambda x: 2
    version_0.__gt__(version_1)


# Generated at 2022-06-24 21:22:03.175720
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version("1.0")
    v2 = Version("1.0")
    v3 = Version("1.1")
    if v1.__eq__(v2):
        # Move from state 1 to state 2
        pass
    elif v1.__eq__(v3):
        # Move from state 1 to state 3
        pass
    else:
        # Move from state 1 to state 4
        pass



# Generated at 2022-06-24 21:22:04.551818
# Unit test for method __eq__ of class Version
def test_Version___eq__(): 
    version_0 = Version()
    assert version_0 == True


# Generated at 2022-06-24 21:22:07.005157
# Unit test for method __le__ of class Version
def test_Version___le__():
    expected = True
    version_0 = Version()
    version_1 = Version()
    result = version_0 <= version_1
    assert result == expected



# Generated at 2022-06-24 21:22:17.174295
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    num_passed_tests = 0
    num_failed_tests = 0
    num_tests = 0
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_passed_tests += 1
    num_tests += 1
    num_

# Generated at 2022-06-24 21:22:20.270355
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    assert version_1


# Generated at 2022-06-24 21:22:22.068003
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test case 1
    version_0 = Version()
    try:
        version_0._cmp("42")
    except ValueError:
        return
    raise AssertionError("ValueError not raised")


# Generated at 2022-06-24 21:22:27.605592
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = Version(LooseVersion, "1")
    v = Version(LooseVersion, "1.0")
    v = Version(LooseVersion, "1.0b1")
    v = Version(LooseVersion, "1.0.dev456")
    v = Version(LooseVersion, "1.0a1")
    v = Version(LooseVersion, "1.0.post456")
    v = Version(LooseVersion, "1.0rc1")
    v = Version(LooseVersion, "1.0+abc.2")
    v = Version(LooseVersion, "1.0+abc.2.dev456")
    v = Version(LooseVersion, "1.0+abc.2a1")
    v = Version(LooseVersion, "1.0+abc.2.post456")


# Generated at 2022-06-24 21:22:30.462977
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('0')
    version_1 = Version('1')
    def test_case_0():
        version_0 = Version('0')
        version_0 == version_0
    def test_case_1():
        version_0 == version_1
    def test_case_2():
        version_1 == version_0


# Generated at 2022-06-24 21:22:37.926845
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_0.test_0 = version_1
    version_0.test_1 = version_2
    version_2.test_0 = version_0
    version_2.test_1 = version_1
    version_1.test_0 = version_2
    version_1.test_1 = version_0
    result = version_1 < version_2
    assert isinstance(result, bool)
    assert result == True


# Generated at 2022-06-24 21:22:41.758192
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    try:
        version_0.__eq__('')
    except AttributeError:
        pass


# Generated at 2022-06-24 21:22:58.064683
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= '0.0.0'


# Generated at 2022-06-24 21:23:02.296269
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    
    try:
        assert version_0 > version_1
    except (AssertionError) as e:
        print("AssertionError raised during testing")


# Generated at 2022-06-24 21:23:05.650084
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    result = Version().__ge__()
    assert result
    assert isinstance(result, bool)


# Generated at 2022-06-24 21:23:11.100679
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0.parse("1.2.2")
    version_1 = Version()
    version_1.parse("0.0.0")
    # Output of assert_false(version_0.__ge__(version_1))
    assert not version_0.__ge__(version_1)


# Generated at 2022-06-24 21:23:17.961279
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Version.__gt__()
    StrictVersion('1.2.3') > StrictVersion('1.2')
    StrictVersion('1.2.3') > StrictVersion('1.2.3')
    StrictVersion('1.2.3') > StrictVersion('1.2.3-final')
    StrictVersion('1.2.3') > StrictVersion('1.2.3rc1')



# Generated at 2022-06-24 21:23:23.531543
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v1.parse('1.3.3')
    v2 = Version()
    v2.parse('1.3.5')
    assert v1 < v2
    assert v2 > v1

    v1 = Version()
    v1.parse('1.3.3')
    v2 = Version()
    v2.parse('1.3.3')
    assert not v1 > v2
    assert not v2 > v1
    assert not v1 < v2
    assert not v2 < v1


# Generated at 2022-06-24 21:23:33.376005
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_21 = Version()
    version_22 = Version()
    version_23 = Version()
    version_24 = Version()

# Generated at 2022-06-24 21:23:35.853049
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    value_0 = version_0.__lt__(version_1)
    expected_0 = None


# Generated at 2022-06-24 21:23:39.114506
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()

    try:
        version_0.__gt__(version_1)
    except NotImplementedError:
        print("Raised expected Exception")



# Generated at 2022-06-24 21:23:44.385857
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version('1.0')
    version_2 = Version('1.0')
    version_3 = Version('1.0')
    version_4 = Version('1.0')
    version_5 = Version('1.0')
    version_6 = Version('1.0')
    assert version_1 >= version_2
    assert version_1 >= version_3
    assert version_1 >= version_4
    assert version_1 >= version_5
    assert version_1 >= version_6


# Generated at 2022-06-24 21:24:07.034268
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    result = version_0.__eq__(10)
    return result



# Generated at 2022-06-24 21:24:10.049214
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.__init__(version_1)
    version_0._cmp(version_1)

    assert version_0 == version_1


# Generated at 2022-06-24 21:24:13.595683
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0.parse('0.0.3')
    version_1 = Version()
    version_1.parse('0.0.4')
    assert not (version_0 == version_1)


# Generated at 2022-06-24 21:24:16.385108
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__eq__(version_1) == True


# Generated at 2022-06-24 21:24:20.139034
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if (version_1 == version_0):
        pass
    else:
        raise RuntimeError("Test failed")


# Generated at 2022-06-24 21:24:23.810134
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    # The code below raises an exception
    try:
        version_0.__eq__(version_0)
    except NotImplementedError:
        return


# Generated at 2022-06-24 21:24:27.443145
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0._cmp = lambda self, other: 0
    version_1 = Version()

# Generated at 2022-06-24 21:24:30.622521
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0.__eq__(version_1))


# Generated at 2022-06-24 21:24:32.922056
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 <= version_1) == True


# Generated at 2022-06-24 21:24:34.514425
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert len(Version.__eq__.__doc__) > 0


# Generated at 2022-06-24 21:25:06.132110
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0 >= version_1)
    assert(version_0 >= version_0)
    version_1 = Version()
    assert(version_1 >= version_0)
    version_2 = Version()
    assert(version_1 >= version_2)
    version_3 = Version()
    assert(version_3 >= version_1)


# Generated at 2022-06-24 21:25:07.923859
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version("3.9.5") <= Version("3.9.6")


# Generated at 2022-06-24 21:25:13.222158
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    version_2 = Version()
    assert (version_1 >= version_2)


# Generated at 2022-06-24 21:25:14.963400
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    Version() >= Version('0.0')


# Generated at 2022-06-24 21:25:18.101774
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_0_le_version_1 = (version_0 <= version_1)


# Generated at 2022-06-24 21:25:18.882299
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()


# Generated at 2022-06-24 21:25:20.377825
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    version_2 = Version()
    version_1.__ge__(version_2)


# Generated at 2022-06-24 21:25:22.846727
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('1.0')
    version_1 = Version('1.0')
    assert version_0 == version_1


# Generated at 2022-06-24 21:25:31.977634
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()

    if version_0 < version_0:
        raise Exception("Method __lt__ of class Version failed")
    version_0 = Version()

    version_1 = Version()
    if version_0 > version_1:
        raise Exception("Method __gt__ of class Version failed")
    version_1 = Version()

    version_2 = Version()
    if version_0 >= version_2:
        raise Exception("Method __ge__ of class Version failed")
    version_2 = Version()

    if version_0 == version_0:
        raise Exception("Method __eq__ of class Version failed")

if __name__ == '__main__':
    test_case_0()
    test_Version___le__()

# Generated at 2022-06-24 21:25:32.773448
# Unit test for method __le__ of class Version
def test_Version___le__():
    return test_case_0()


# Generated at 2022-06-24 21:26:14.126221
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('1')
    assert not version_0.__ge__(Version('1'))


# Generated at 2022-06-24 21:26:23.396031
# Unit test for method __ge__ of class Version

# Generated at 2022-06-24 21:26:24.609964
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()



# Generated at 2022-06-24 21:26:27.019464
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    str_0 = version_0.__eq__(None)
    assert str_0 == NotImplemented


# Generated at 2022-06-24 21:26:31.690949
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Tests that when two instances of class version are compared using the <= operator, a boolean is returned."""

    version_0 = Version()
    version_1 = Version("1.0.0")

    le_result = version_0 <= version_1

    assert isinstance(le_result, bool)


# Generated at 2022-06-24 21:26:37.335668
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()

    # check that the test case is valid
    other = version
    c = version._cmp(other)
    assert(c != NotImplemented)
    version_0 = version.__ge__(other)
    assert(version_0 == c >= 0)


# Generated at 2022-06-24 21:26:42.557452
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0_0 = Version()
    version_0.parse('1.2.3')
    version_0_0.parse('1.2.2')
    if not (version_0_0 <= version_0):
        print('Assertion failed')
        raise AssertionError
    else:
        print('Test case passed')


# Generated at 2022-06-24 21:26:47.129281
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    other = b'1.2.3'
    assert version.__ge__(other) == NotImplemented


# Generated at 2022-06-24 21:26:49.615973
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    expect = 1
    actual = cmp(Version("1.3.0"), Version("1.3.0"))
    assert actual == expect


# Generated at 2022-06-24 21:26:55.218211
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = version_0
    assert version_0.__eq__(version_1) == True
