

# Generated at 2022-06-24 21:17:27.838560
# Unit test for method __le__ of class Version

# Generated at 2022-06-24 21:17:30.725490
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    ver_str_0 = StrictVersion('2.7.2.2').__str__()
    assert ver_str_0 == '2.7.2.2'


# Generated at 2022-06-24 21:17:34.254657
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version()
    v2 = Version()
    assert (v <= v2)
    assert not (v < v2)
    assert (v >= v2)
    assert not (v > v2)


# Generated at 2022-06-24 21:17:37.248069
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version = "1.2.3"

    strict_version_0 = StrictVersion(version)
    assert(strict_version_0.__str__() == version)


# Generated at 2022-06-24 21:17:40.603153
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version("1.0.0")
    v2 = Version("2.0.0")

    assert v1 < v2
    # assert v1 >= v2
    # assert v1 > v2


# Generated at 2022-06-24 21:17:46.372906
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    v = StrictVersion(str(StrictVersion("1.0.0a1")))
    assert str(v) == "1.0.0a1"

    v = StrictVersion(str(StrictVersion("1.0.0")))
    assert str(v) == "1.0.0"

    v = StrictVersion(str(StrictVersion("1b3")))
    assert str(v) == "1.0.0b3"

    v = StrictVersion(str(StrictVersion("1.0.0b")))
    assert str(v) == "1.0.0"

    v = StrictVersion(str(StrictVersion("1.0b.0")))
    assert str(v) == "1.0.0"


# Generated at 2022-06-24 21:17:56.936869
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    """Unit test for method parse of class StrictVersion"""
    # Test basic cases
    version = StrictVersion()
    version.parse('1.2.3')
    assert version.version == (1, 2, 3)
    assert version.prerelease == None
    version.parse('1.2')
    assert version.version == (1, 2, 0)
    assert version.prerelease == None
    version.parse('1.2a1')
    assert version.version == (1, 2, 0)
    assert version.prerelease == ('a', 1)
    version.parse('1.2b3')
    assert version.version == (1, 2, 0)
    assert version.prerelease == ('b', 3)
    version.parse('1.2.0')
    assert version.version == (1, 2, 0)

# Generated at 2022-06-24 21:18:00.019184
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version_0 = StrictVersion()
    strict_version_0.parse('')


if __name__ == '__main__':
    test_case_0()
    test_StrictVersion_parse()

# Generated at 2022-06-24 21:18:03.054709
# Unit test for method __le__ of class Version
def test_Version___le__():
    loose_version_0 = LooseVersion()
    test.compare(True, loose_version_0 <= loose_version_0)


# Generated at 2022-06-24 21:18:03.953732
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version.__ge__() == NotImplemented


# Generated at 2022-06-24 21:18:22.093950
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_0 = LooseVersion()
    str_0 = '0#'
    try:
        version_0 = loose_version_0.parse(str_0)
    except ValueError:
        pass
    str_1 = '0.1#'
    try:
        version_1 = loose_version_0.parse(str_1)
    except ValueError:
        pass
    try:
        b_0 = loose_version_0 < version_1
    except ValueError:
        pass


# Generated at 2022-06-24 21:18:25.788600
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Create a version instance
    version_instance = Version()

    # Invoke method
    result = version_instance.__gt__('2.7.12')

    # Check for expected result
    assert result == True


# Generated at 2022-06-24 21:18:26.909416
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()


# Generated at 2022-06-24 21:18:27.519858
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    pass

# Generated at 2022-06-24 21:18:35.407876
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:18:36.773916
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Version.__eq__"""
    test_case_0()


# Generated at 2022-06-24 21:18:39.135761
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    looser_0 = LooseVersion()
    looser_1 = LooseVersion()
    assert looser_0 < looser_1


# Generated at 2022-06-24 21:18:44.302685
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    try:
        v1 = LooseVersion()
        v2 = LooseVersion()
        result = v1.__lt__(v2)
    except Exception as exc:
        result = str(exc)
    expected = NotImplemented
    assert result == expected


# Generated at 2022-06-24 21:18:46.196557
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    result = loose_version_0.__gt__(Version())
    assert result == True


# Generated at 2022-06-24 21:18:47.766797
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    ver_0 = Version()
    try:
        ver_0._cmp(ver_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:19:01.537288
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda vstring : 1
    assert version_0 == version_1


# Generated at 2022-06-24 21:19:03.419007
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version("0.0.0")
    assert v == "0.0.0"


# Generated at 2022-06-24 21:19:14.553887
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = None
    version_1 = Version()
    version_2 = Version(version_1)
    version_3 = Version(version_1)
    version_4 = Version(version_0)
    version_5 = Version(version_0)
    version_6 = Version(version_2)

    assert version_1.__eq__(version_2)
    assert version_2.__eq__(version_3)
    assert version_3.__eq__(version_1)
    assert not version_1.__eq__(version_3)
    assert not version_3.__eq__(version_1)
    assert not version_2.__eq__(version_1)
    assert not version_1.__eq__(version_2)
    assert version_4.__eq__(version_5)


# Generated at 2022-06-24 21:19:15.655326
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    obj = Version('1.2.3')
    assert obj == '1.2.3'
    version_0 = Version()


# Generated at 2022-06-24 21:19:17.072189
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2


# Generated at 2022-06-24 21:19:18.408310
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0.__eq__(version_0) == True


# Generated at 2022-06-24 21:19:24.595710
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v0 = Version()
    v1 = Version()
    return v0.__eq__(v1)


# Generated at 2022-06-24 21:19:27.928172
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    version_1 = Version()
    version_2 = Version()
    assert version_1 == version_2

    version_3 = Version()
    version_4 = Version()
    assert not version_3 != version_4


# Generated at 2022-06-24 21:19:39.432120
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:19:44.258422
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # TODO: Add tests for Version.__eq__
    raise NotImplementedError("Test for Version.__eq__ not implemented")


# Generated at 2022-06-24 21:20:02.302745
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version("1.1rc1")
    version_1 = Version("1.1")
    version_2 = Version("1.1rc1")
    version_3 = Version("1.1alpha3")
    version_4 = Version("1.1alpha1")

    if (version_0 == version_1):
        print("version_0 is equal to version_1")
    else:
        print("version_0 is not equal to version_1")
    if (version_0 == version_2):
        print("version_0 is equal to version_2")
    else:
        print("version_0 is not equal to version_2")
    if (version_0 == version_3):
        print("version_0 is equal to version_3")

# Generated at 2022-06-24 21:20:03.129272
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a = Version()
    b = Version()
    assert a == b


# Generated at 2022-06-24 21:20:07.931996
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    other = None
    try:
        var1 = version_0 == other
    except TypeError as raised_exception:
        print('TypeError raised as expected')
    else:
        print('Failed to raise expected TypeError')


# Generated at 2022-06-24 21:20:09.883426
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1, "assert #1 failed"



# Generated at 2022-06-24 21:20:11.554990
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    other = Version()
    assert version.__eq__(other) == NotImplemented


# Generated at 2022-06-24 21:20:13.795974
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    test_str_0 = "1.5.1"
    version = LooseVersion(test_str_0)
    version.parse(test_str_0)


# Generated at 2022-06-24 21:20:14.579293
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    Version.__eq__(Version(), Version())


# Generated at 2022-06-24 21:20:16.441910
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # test_Version___eq__: No test cases defined
    pass


# Generated at 2022-06-24 21:20:22.772185
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test case for __eq__ with identical version numbers
    version_0 = Version()
    version_1 = Version()
    assert(version_0 == version_1)

    # Test case for __eq__ with equal but non-identical version numbers
    version_0 = Version()
    version_1 = Version()
    version_1.parse("0.0.0")
    assert(version_0 == version_1)

    # Test case for __eq__ with different version numbers
    version_0 = Version()
    version_1 = Version()
    version_1.parse("0.0.1")
    assert(version_0 != version_1)

    # Test case for __eq__ with different version numbers
    version_0 = Version()
    version_1 = Version()

# Generated at 2022-06-24 21:20:25.709401
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()
    a = Version()
    b = Version()
    assert a == b


# Generated at 2022-06-24 21:20:39.555638
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for i in range(0,10):
        version_1 = Version()
        if not version_1.__eq__(version_1):
            print(version_1, version_1)
            raise Exception
    version_2 = Version()
    if version_2.__eq__(version_1):
        print(version_2, version_1)
        raise Exception


# Generated at 2022-06-24 21:20:40.967696
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0.__eq__(None) == False


# Generated at 2022-06-24 21:20:42.979934
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_0 = LooseVersion("2.2beta29")
    assert version_0.version == ['2', '2', 'beta', '29']


# Generated at 2022-06-24 21:20:49.150502
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:20:53.725132
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1
    # Don't uncomment next line, otherwise the test will fail
    # assert version_0 == version_1


# Generated at 2022-06-24 21:20:55.993492
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Expect false, given arguments ('', '1.0')
    assert False == Version('').__eq__('1.0'), 'False expected, given arguments'


# Generated at 2022-06-24 21:20:58.642262
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version(vstring='2.0')
    assert version_0 == version_1
    assert version_0 != version_2



# Generated at 2022-06-24 21:21:01.833948
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert (version_0 == version_0)


# Generated at 2022-06-24 21:21:05.961483
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse("2.2.2")
    version_1.parse("2.2.2")
    return version_0 == version_1


# Generated at 2022-06-24 21:21:11.553832
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('1.2.3')
    v2 = Version('1.2.3')
    v3 = Version('1.3')
    assert v1 == v2
    assert not v1 == v3


# Generated at 2022-06-24 21:21:23.925130
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()

    version_0.__eq__(version_1)
    version_1.__eq__(version_2)
    version_2.__eq__(version_3)


# Generated at 2022-06-24 21:21:25.499367
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(Version()) == True


# Generated at 2022-06-24 21:21:26.466228
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    pass


# Generated at 2022-06-24 21:21:36.839684
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from distutils.version import Version
    from random import randint
    from ansiblelint.rules.SetupHasVersionVersion import SetupHasReleaseVersionRule
    import re

    for _ in range(100):
        instance = Version("%s.%s" % (randint(1,1000), randint(1,1000)))
        instance2 = Version("%s.%s" % (randint(1,1000), randint(1,1000)))
        instance3 = Version("%s.%s" % (instance.parse('/^[0-9]*.[0-9]*$/'), instance2.parse('/^[0-9]*.[0-9]*$/')))

# Generated at 2022-06-24 21:21:39.417236
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    pass


# Generated at 2022-06-24 21:21:49.149830
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0.parse('0.0.0')
    version_1 = Version()
    version_1.parse('0.0.1')
    version_2 = Version()
    version_2.parse('0.0.2')

    assert(version_0 == version_0)

    assert(not (version_0 == version_1))
    assert(not (version_0 == version_2))

    assert(not (version_1 == version_0))
    assert(version_1 == version_1)
    assert(not (version_1 == version_2))

    assert(not (version_2 == version_0))
    assert(not (version_2 == version_1))
    assert(version_2 == version_2)


# Generated at 2022-06-24 21:21:51.374427
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    result = version_0 == version_1


# Generated at 2022-06-24 21:21:53.945041
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    assert version_1.__eq__(Version())


# Generated at 2022-06-24 21:22:02.378415
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()

    temp_0 = version_0 == version_1
    version_0.parse('4.0.4')
    version_1.parse('4.0.4')
    temp_1 = version_0 == version_1
    version_0.parse('4.4.4')
    version_1.parse('4.4.4')
    temp_2 = version_0 == version_1
    version_0.parse('4.44.44')
    version_1.parse('4.44.44')
    temp_3 = version_0 == version_1
    version_0.parse('4.444.444')
    version_1.parse('4.444.444')
    temp_4 = version_0 == version_1
    version_0.parse

# Generated at 2022-06-24 21:22:09.109348
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0.vstring = '3.3.0'
    version_0.vlist = [3, 3, 0]
    version_1 = Version()
    version_1.vstring = '3.3.0'
    version_1.vlist = [3, 3, 0]
    result = version_0.__eq__(version_1)
    assert result == 1, '__eq__ failure'
    result = version_1.__eq__(version_0)
    assert result == 1, '__eq__ failure'


# Generated at 2022-06-24 21:22:35.649219
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Version.__eq__([other])"""
    version_0 = Version()
    assert version_0.__eq__('abc') == False


# Generated at 2022-06-24 21:22:37.701361
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:22:39.982946
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:22:47.721305
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version_1 = LooseVersion()
    version_1.parse("1.5.1")
    version_2 = LooseVersion()
    version_2.parse("1.5.2b2")
    version_3 = LooseVersion()
    version_3.parse("161")
    version_4 = LooseVersion()
    version_4.parse("3.10a")
    version_5 = LooseVersion()
    version_5.parse("8.02")
    version_6 = LooseVersion()
    version_6.parse("3.4j")
    version_7 = LooseVersion()
    version_7.parse("1996.07.12")
    version_8 = LooseVersion()
    version_8.parse("3.2.pl0")
    version_9 = LooseVersion()
    version

# Generated at 2022-06-24 21:22:51.568140
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_10 = Version()
    version_11 = Version()
    assert version_10 == version_11
    assert not version_10 == None
    assert (not version_10 == Version('0.0.0'))


# Generated at 2022-06-24 21:22:56.408924
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_string = 'Test'
    version_1 = Version(version_string)
    version_2 = Version()
    version_3 = Version(version_string)

    assert version_1 is not None
    assert version_1 == version_3
    assert version_1 != version_2


# Generated at 2022-06-24 21:23:06.152022
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()

    version_0.parse("1.7.1")
    version_1.parse("1.7.1")
    version_2.parse("1.7")
    version_3.parse("1.7.2")

    if (version_0._cmp(version_1) != 0):
        return 1

    if (version_0._cmp(version_2) != 1):
        return 1

    if (version_0._cmp(version_3) != -1):
        return 1

    return 0


# Generated at 2022-06-24 21:23:10.169711
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version("0.0.0")
    version_1 = Version("0.0.0")
    assert version_0.__eq__(version_1)


# Generated at 2022-06-24 21:23:12.270076
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__eq__(version_1)


# Generated at 2022-06-24 21:23:19.117996
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version = Version()
    version.parse = lambda x: 0
    version._cmp = lambda x: 0
    assert version.__eq__(0)
    version._cmp = lambda x: 1
    assert not version.__eq__(0)
    version._cmp = lambda x: NotImplemented
    try:
        version.__eq__(0)
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:24:13.940634
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # test parsing of valid version number strings
    valid_cases = ["1.5.2b2", "161", "3.10a", "8.02", "3.4j", "1996.07.12",
                   "3.2.pl0", "3.1.1.6", "2g6", "11g", "0.960923",
                   "2.2beta29", "1.13++", "5.5.kw", "2.0b1pl0"]
    for v in valid_cases:
        lv = LooseVersion(v)
        assert lv.version == v


# Generated at 2022-06-24 21:24:17.148888
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version(None)

    assert version_0.__eq__(version_1) == NotImplemented


# Generated at 2022-06-24 21:24:27.087481
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    mock_equal = []
    mock_less = []
    mock_greater = []

    class MockVersion:
        def __init__(self, vstring):
            self.vstring = vstring
        def __eq__(self, other):
            if self.vstring == other.vstring:
                mock_equal.append(self.vstring)
            else:
                mock_less.append(self.vstring)
        def __le__(self, other):
            if self.vstring == other.vstring:
                mock_equal.append(self.vstring)
            else:
                mock_greater.append(self.vstring)
        def __gt__(self, other):
            if self.vstring == other.vstring:
                mock_equal.append(self.vstring)

# Generated at 2022-06-24 21:24:36.110816
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_2.parse('1.0.0')
    version_3.parse('1.0.0')
    assert (version_0 == version_1)
    assert (version_2 == version_3)
    version_4 = Version()
    version_4.parse('2.0.0')
    version_5 = Version()
    version_5.parse('1.1.0')
    assert (version_4 != version_5)


# Generated at 2022-06-24 21:24:37.865952
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__eq__(version_1) == 1


# Generated at 2022-06-24 21:24:40.125562
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0 = version_0.__eq__(version_0)


# Generated at 2022-06-24 21:24:42.453337
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    pyobject = int()
    result = version_0.__eq__(pyobject)


# Generated at 2022-06-24 21:24:44.104374
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version(str(version_0))
    assert version_0 == version_1


# Generated at 2022-06-24 21:24:46.315728
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    version_2 = Version()
    assert version_1 == version_2


# Generated at 2022-06-24 21:24:51.707138
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    result = version_1 == version_0
    assert result is True


# Generated at 2022-06-24 21:26:38.162430
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version() == Version()


# Generated at 2022-06-24 21:26:40.700930
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    other_0 = Version()

    # Verify the method output match
    assert version_0.__eq__(other_0) == False


# Generated at 2022-06-24 21:26:43.381175
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if version_0 == version_1:
        pass
    pass


# Generated at 2022-06-24 21:26:50.798608
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_21 = Version()
    version_22 = Version()
    version_23 = Version()
    version_24 = Version()

# Generated at 2022-06-24 21:26:53.793465
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version('0.9') # Create an object of class Version
    v2 = Version('1.0') # Create an object of class Version
    assert(v1 == v2) # Test method __eq__ of class Version


# Generated at 2022-06-24 21:26:56.711162
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if (version_0 == version_1):
        print('PASS')
    else:
        print('FAIL')


# Generated at 2022-06-24 21:26:59.767713
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    a = Version()
    assert a == a
    assert not (a != a)


# Generated at 2022-06-24 21:27:02.200119
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()

    assert(version_0 == version_1)


# Generated at 2022-06-24 21:27:05.107847
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1_1 = Version()
    version_1_2 = Version()

