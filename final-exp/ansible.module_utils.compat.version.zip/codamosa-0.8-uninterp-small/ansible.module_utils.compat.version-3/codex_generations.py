

# Generated at 2022-06-24 21:17:20.927137
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_0 = StrictVersion()
    version_0.parse('3.11')
    assert (version_0.version[0] == 3)
    assert (version_0.version[1] == 11)
    assert (version_0.version[2] == 0)
    assert (version_0.prerelease == None)
    try:
        version_0.parse('3.11.1.1')
    except ValueError:
        pass


# Generated at 2022-06-24 21:17:24.045692
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    v2 = Version()
    v2.parse("1.0.0")
    assert v2._cmp == NotImplemented
    assert v == v2


# Generated at 2022-06-24 21:17:31.588850
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():

    version_0 = StrictVersion('0.4a3')
    version_1 = StrictVersion()

    version_1.parse('0.4')

    version_2 = StrictVersion('1.1')
    version_3 = StrictVersion('1.1')
    version_4 = StrictVersion('0.9')
    version_5 = StrictVersion('1.1b0')

    assert version_0.version == (0, 4, 0)
    assert version_0.prerelease == ('a', 3)

    assert version_1.version == (0, 4, 0)
    assert version_1.prerelease == None

    assert version_2.version == (1, 1, 0)
    assert version_2.prerelease == None

    assert version_3.version == (1, 1, 0)

# Generated at 2022-06-24 21:17:35.508353
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = "1.1.1"
    version_0.parse(version_1)
    version_2 = "1.1.1"
    version_0.parse(version_2)
    return version_0 == version_2


# Generated at 2022-06-24 21:17:40.702826
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    assert ((version_0 <= version_1) is NotImplemented)
    assert ((version_1 <= version_2) is NotImplemented)
    assert ((version_2 <= version_0) is NotImplemented)


# Generated at 2022-06-24 21:17:46.662851
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    retval_0 = version_0.__ge__(version_0)
    retval_1 = version_1.__ge__(version_1)
    # Do not consider assert statements, multiple paths
    print('Good job!')
    print('Expected Output:')
    print('Good job!')
    print('Click "Next" to continue.')


# Generated at 2022-06-24 21:17:57.195780
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = None
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = None
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_21 = Version()
    version_22 = Version()
    version_23 = Version()
    version_24 = Version()
    version_25 = Version()
   

# Generated at 2022-06-24 21:18:04.310172
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    try:
        version_1 = StrictVersion()
    except:
        pass
    try:
        version_2 = StrictVersion('1')
    except:
        pass
    try:
        version_3 = StrictVersion('2.7.2.2')
    except:
        pass
    try:
        version_4 = StrictVersion('1.3.a4')
    except:
        pass
    try:
        version_5 = StrictVersion('1.3pl1')
    except:
        pass
    try:
        version_6 = StrictVersion('1.3c4')
    except:
        pass
    try:
        version_7 = StrictVersion('0.4')
    except:
        pass

# Generated at 2022-06-24 21:18:11.216644
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    assert StrictVersion('1.0').version == (1, 0, 0)
    assert StrictVersion('1.0.0').version == (1, 0, 0)
    assert StrictVersion('1.0a1').version == (1, 0, 0)
    assert StrictVersion('1.0.0a1').version == (1, 0, 0)
    assert StrictVersion('1.0.0a1').prerelease == ('a', 1)
    assert StrictVersion('1.0rc1').version == (1, 0, 0)
    assert StrictVersion('1.0.0rc1').version == (1, 0, 0)
    assert StrictVersion('1.0.0rc1').prerelease == ('rc', 1)


# Generated at 2022-06-24 21:18:15.174568
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version('1.1.1')
    version_2 = Version('1.1.2')
    if version_1 <= version_2:
        pass
    else:
        raise RuntimeError("Version.__le__ raises exception")


# Generated at 2022-06-24 21:18:26.653603
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('3.3.0')
    v2 = Version('3.3.0')
    result = v1.__ge__(v2)
    assert(result)


# Generated at 2022-06-24 21:18:28.860235
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1


# Generated at 2022-06-24 21:18:35.338470
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    """ Test case for class Version. """
    try:
        test_case_0()
    except:
        import sys
        print("test_Version raised exception => ", sys.exc_info()[1])
        raise

# Generated at 2022-06-24 21:18:38.942366
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    boolean_var_0 = version_0.__eq__(version_1)
    assert isinstance(boolean_var_0, bool)


# Generated at 2022-06-24 21:18:45.733851
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()


# Generated at 2022-06-24 21:18:48.154387
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    x = version_1 == Version()


# Generated at 2022-06-24 21:18:59.099278
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('2.2'))=='2.2'
    assert str(StrictVersion('0.33.1b1'))=='0.33.1b1'
    assert str(StrictVersion('0.33.1b1'))!='0.33.b1'
    assert str(StrictVersion('0.33.1b1'))!='0.33.1'
    assert str(StrictVersion('0.33.1b1'))!='0.33.1.b1'
    assert str(StrictVersion('0.33.1b1'))!='0.33.1b2'
    assert str(StrictVersion('0.33.1b1'))!='0.33.2b1'

# Generated at 2022-06-24 21:19:05.074206
# Unit test for method __le__ of class Version
def test_Version___le__():
    def test_case_0():
        version_0 = Version()
        version_1 = Version()
        version_0._cmp = mock__cmp_0
        assert version_0 <= version_1
    def test_case_1():
        version_0 = Version()
        version_1 = Version()
        version_0._cmp = mock__cmp_1
        assert not version_0 <= version_1
    def mock__cmp_0(self, version):
        return 0
    def mock__cmp_1(self, version):
        return 1


# Generated at 2022-06-24 21:19:07.431412
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    version_2 = Version()
    assert(not version_1 == version_2)


# Generated at 2022-06-24 21:19:13.812748
# Unit test for method __le__ of class Version
def test_Version___le__():
    print('unit test: Version___le__')
    version_0 = Version()
    version_0._cmp = lambda x: -1
    version_0.__le__('')
    version_0._cmp = lambda x: -1
    version_0.__le__('')
    version_0._cmp = lambda x: -1
    version_0.__le__('')


# Generated at 2022-06-24 21:19:28.981646
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    arg0 = None
    arg1 = None
    if arg0 < arg1:
        if arg0 <= arg1:
            if arg0 != arg1:
                if arg1 == arg0:
                    if arg0 is arg1:
                        if arg0 is not arg1:
                            if type(arg0) == type(arg1):
                                pass
                    else:
                        pass
                else:
                    pass
            else:
                pass
        else:
            pass
    else:
        pass

if __name__ == '__main__':
    test_case_0()
    test_Version___lt__()

# Generated at 2022-06-24 21:19:31.164265
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 < version_1) == NotImplemented


# Generated at 2022-06-24 21:19:36.250623
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse("1.2.3")
    version_1.parse("1.2.3")
    TestError(version_0 == version_1)


# Generated at 2022-06-24 21:19:37.539616
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    assert(v.__lt__(None) is NotImplemented)


# Generated at 2022-06-24 21:19:45.591766
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_2.parse('1.0')
    version_1.parse('1.0.dev1')
    try:
        if(version_2 <= version_0):
            pass
        elif(version_0 <= version_1):
            pass
        else:
            pass
    except ValueError:
        pass


# Generated at 2022-06-24 21:19:47.909883
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1

test_Version___eq__()


# Generated at 2022-06-24 21:19:52.199751
# Unit test for method __le__ of class Version
def test_Version___le__():
    global version_0
    version_0 = Version()
    global version_1
    version_1 = Version()
    global version_2
    version_2 = Version()
    print(version_0 <= version_1)
    print(version_1 <= version_0)
    print(version_1 <= version_2)


# Generated at 2022-06-24 21:19:54.899093
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_1 = Version("1.0")
    version_2 = Version("2.0")
    version_1.__lt__(version_2)


# Generated at 2022-06-24 21:19:57.626833
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    method_top_level_scenario_0(version_0, version_1)


# Generated at 2022-06-24 21:19:59.831713
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    >>> l = LooseVersion('1.38.0')
    >>> str(l)
    '1.38.0'
    """


# Generated at 2022-06-24 21:20:11.218774
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    if (version_0 > version_1):
        raise RuntimeError
    if (version_1 > version_0):
        raise RuntimeError


# Generated at 2022-06-24 21:20:12.778052
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    retval_0 = version_0.__ge__(-847.9)
    assert (not retval_0)


# Generated at 2022-06-24 21:20:16.772444
# Unit test for method __le__ of class Version
def test_Version___le__():
  version_0 = Version()
  version_1 = Version()
  assert (version_0 <= version_1)


# Generated at 2022-06-24 21:20:18.644375
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('2.3')
    version_1 = Version('2.1')
    assert(version_0.__ge__(version_1))


# Generated at 2022-06-24 21:20:19.413311
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert version_0 <= None


# Generated at 2022-06-24 21:20:20.409327
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1


# Generated at 2022-06-24 21:20:25.166411
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print('Method __lt__ in class Version not implemented yet.')


# Generated at 2022-06-24 21:20:26.570344
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v0 = Version()
    v1 = Version()
    assert v0 == v1
                

# Generated at 2022-06-24 21:20:30.182402
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    c = version_0._cmp(version_1)
    if (c is NotImplemented):
        c = 0
    assert (c < 0), "expected [%d] < 0, observed [%d]" % (c,c)


# Generated at 2022-06-24 21:20:35.377998
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_a = Version()
    version_b = Version()
    version_c = Version()
    version_d = Version()
    assert version_a.__gt__(version_b) == True
    assert version_b.__gt__(version_c) == True
    assert version_c.__gt__(version_d) == True
    assert version_d.__gt__(version_a) == True
    assert version_a.__gt__(version_c) == True
    assert version_b.__gt__(version_d) == True
    assert version_a.__gt__(version_d) == True
    assert version_c.__gt__(version_b) == True
    assert version_c.__gt__(version_a) == True
    assert version_d.__gt__(version_b)

# Generated at 2022-06-24 21:20:50.114804
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda arg: arg
    version_1._cmp = lambda arg: arg
    assert version_0.__ge__(version_1)


# Generated at 2022-06-24 21:20:56.167627
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    ver = Version(vstring='1')
    ver2 = Version(vstring='2')
    assert ver == Version(vstring='1')
    assert ver <= ver2
    assert not ver >= ver2
    assert not ver > ver2
    assert ver >= ver
    assert not ver > ver
    assert ver > Version(vstring='0')


# Generated at 2022-06-24 21:21:03.117120
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion

    cases = [
        (Version(), Version()),
        (Version(), LooseVersion('1.0')),
        (LooseVersion('1.0'), Version()),
        (LooseVersion('1.0'), LooseVersion('1.0')),
        (StrictVersion('1.0'), StrictVersion('1.0')),
        (StrictVersion('1.0'), StrictVersion('1.0.0')),
    ]

    for case in cases:
        result = case[0].__gt__(case[1])
        if result is NotImplemented:
            return 'NOT_IMPLEMENTED'
        else:
            return result


# Generated at 2022-06-24 21:21:06.730052
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_2 = Version()
    version_1 = version_2
    if (version_0 <= version_2):
        pass
    if (version_1 <= version_2):
        pass


# Generated at 2022-06-24 21:21:16.384168
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse("1.2.3")
    version_2 = Version()
    version_2.parse("1.1.3")
    # Check return value for basic comparisons
    if version_0 is not None:
        assert version_0 == version_1 != version_2
        assert version_1 == version_2 != version_0
        assert version_2 == version_0 != version_1
    else:
        assert version_1 == version_0 != version_2
        assert version_2 == version_0 != version_1
        assert version_0 == version_1 != version_2


# Generated at 2022-06-24 21:21:18.141009
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:21:20.161647
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Case 0
    version_1 = Version()
    version_2 = version_1
    assert(version_1 <= version_2)


# Generated at 2022-06-24 21:21:22.719772
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version("1.2.3")
    version_1 = Version("2.0.0")
    assert version_0 < version_1

# Integration test for class Version

# Generated at 2022-06-24 21:21:28.009080
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert __gt__.__doc__, "Missing doc for __gt__"
    version_0 = Version()
    version_1 = Version("1.0.0")
    version_2 = Version("1.0")
    version_3 = Version("1.xxx")
    version_4 = Version("2.0.0")
    version_5 = Version("2.0")
    version_6 = Version("2.xxx")
    version_7 = Version("3.0.0")
    version_8 = Version("3.0")
    version_9 = Version("3.xxx")
    if true:
        test_case_0()
    if true:
        test_case_0()
    # Tests Version.__gt__
    assert (version_1 > version_0) == True

# Generated at 2022-06-24 21:21:31.499021
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = Version()
    assert (version_1 <= version_2)


# Generated at 2022-06-24 21:22:00.759703
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if version_0.__eq__(version_1):
        raise RuntimeError("__eq__() failed")


# Generated at 2022-06-24 21:22:02.759941
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert version_0.__eq__(version_0)


# Generated at 2022-06-24 21:22:06.748554
# Unit test for method __le__ of class Version
def test_Version___le__():

    # case 0
    version_0 = Version()

    assert version_0._cmp(version_0) == 0
    version_1 = Version()

    assert version_0 <= version_1
    assert version_1 <= version_0
    assert version_0 <= version_0
    assert version_1 <= version_1


# Generated at 2022-06-24 21:22:13.635697
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version('1.1')
    version_2 = Version('0.9.8')
    assert version_1 > version_0
    assert version_1 <= version_1
    assert version_2 < version_1


# Generated at 2022-06-24 21:22:15.821295
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()

    version_1 = Version()
    version_2 = Version()
    assert not (version_1 >= version_2)
    assert (version_1 >= version_1)
    assert (version_2 >= version_2)
    assert (version_2 >= version_1)


# Generated at 2022-06-24 21:22:20.822411
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__gt__(version_1)


# Generated at 2022-06-24 21:22:21.950286
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = Version()
    assert version_1 <= version_2


# Generated at 2022-06-24 21:22:23.551407
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    try:
        version_0.__le__(None)
    except:
        pass


# Generated at 2022-06-24 21:22:29.374769
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0.parse('2.2.2')
    version_1 = Version()
    version_1.parse('2.2.2')
    assert (version_0 <= version_1)


# Generated at 2022-06-24 21:22:31.267769
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('5.5.5')
    if version_0 == '5.5.5':
        pass
    else:
        print("ERROR: %s != '5.5.5'" % str(version_0))


# Generated at 2022-06-24 21:23:39.602766
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version("1.2.3")
    version_2 = Version("1.2")
    version_3 = Version("1.2.3")
    version_4 = Version("1.2.2")
    version_5 = Version("1.2.4")
    assert version_1 >= version_2 == False
    assert version_1 >= version_3 == True
    assert version_1 >= version_4 == True
    assert version_1 >= version_5 == False
    assert version_2 >= version_3 == False
    assert version_2 >= version_4 == True
    assert version_2 >= version_5 == False
    assert version_3 >= version_4 == True
    assert version_3 >= version_5 == False
    assert version_4 >= version_5 == False


# Generated at 2022-06-24 21:23:45.493595
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    bool_0 = version_0.__ge__(version_1)
    assert( bool_0 )
    int_0 = version_0._cmp(version_1)
    assert( int_0 == 0 )


# Generated at 2022-06-24 21:23:52.472283
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0.parse("foo")
    version_1 = Version()
    version_1.parse("1.2.3")
    version_0._cmp = lambda x: NotImplemented
    assert version_0 >= version_1
    version_0._cmp = lambda x: 1
    assert version_0 >= version_1
    version_0._cmp = lambda x: 0
    assert version_0 >= version_1
    version_0._cmp = lambda x: -1
    assert not version_0 >= version_1


# Generated at 2022-06-24 21:23:55.087525
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    assert not version_0.__gt__(version_1)
    print("Test 1 passed")



# Generated at 2022-06-24 21:24:01.982287
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version("1.0.0")
    v2 = Version("1.0.0.0")
    v3 = Version("1.0.0.0.0")
    assert not v1.__ge__("1.0.0")
    assert not v2.__ge__("1.0.0.0")
    assert not v3.__ge__("1.0.0.0.0")


# Generated at 2022-06-24 21:24:06.958906
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()

    # Should not raise an exception
    assert (version_0 <= version_1)


# Generated at 2022-06-24 21:24:13.239711
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    from datetime import datetime
    from collections import deque
    from ansible.module_utils._text import to_native

    vstr = "2.2.0"

    v1 = Version(vstr)
    t0 = datetime.now()
    for i in range(1, 1000):
        v0 = Version(vstr)
        v0 == v1
    t1 = datetime.now()
    dt = t1 - t0
    print(f"test_Version___eq__: {to_native(v1)} == {to_native(v0)} {dt.total_seconds()}")


# Generated at 2022-06-24 21:24:16.389640
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0 == version_1)


# Generated at 2022-06-24 21:24:19.833419
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    try:
        version_0.__lt__(version_0)
    except:
        raise AssertionError


# Generated at 2022-06-24 21:24:23.349695
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_1 = Version()
    version_2 = Version()
    assert version_1 == version_2
    assert not version_1 < version_2
    assert version_1 <= version_2
    assert not version_1 > version_2
    assert version_1 >= version_2


# Generated at 2022-06-24 21:25:45.857996
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert type(Version()).__lt__(Version())
    assert type(Version()).__lt__(Version('1.2'))
    assert type(Version('1.2')).__lt__(Version('1.2.3'))
    assert type(Version('1.2')).__lt__(Version('1.2a'))
    assert type(Version('1.2')).__lt__(Version('1.2.3a'))
    assert type(Version('')).__lt__(Version('1.2'))


# Generated at 2022-06-24 21:25:49.679672
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import pytest
    version_0 = Version()
    version_1 = Version("1")

    with pytest.raises(AttributeError):
        version_0 < version_1


# Generated at 2022-06-24 21:25:52.490698
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    if v1 == v2:
        pass


# Generated at 2022-06-24 21:25:54.806132
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 == version_1



# Generated at 2022-06-24 21:25:59.628956
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try: 
        version_0 = Version()
        version_1 = Version("1")
        version_0.__ge__(version_1)
    except Exception as e: 
        print("Exception occurred: {0}".format(e))
    else: 
        print("Test case 0 passed.")


# Generated at 2022-06-24 21:26:01.600264
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('2.7')
    assert version_0.__gt__('2.2')


# Generated at 2022-06-24 21:26:08.801785
# Unit test for method __le__ of class Version
def test_Version___le__():

    version_0 = Version()
    version_1 = Version()

    result = version_0.__le__(version_1)
    assert result == True

    version_1 = Version()
    version_0 = Version()

    result = version_0.__le__(version_1)
    assert result == True

    version_3 = Version()
    version_2 = Version()

    result = version_3.__le__(version_2)
    assert result == False

    version_4 = Version()
    version_4 = Version()

    result = version_4.__le__(version_4)
    assert result == True

    version_5 = Version()
    version_6 = Version()

    result = version_5.__le__(version_6)
    assert result == True

    version_7 = Version()
   

# Generated at 2022-06-24 21:26:15.011379
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_inst_0 = Version()
    version_inst_1 = Version()
    version_inst_2 = Version()
    version_inst_2.parse('a')
    version_inst_3 = Version()
    version_inst_3.parse('a')
    assert type(version_inst_0) == type(version_inst_1)
    assert version_inst_0 == version_inst_1
    assert not version_inst_0 == version_inst_2
    assert version_inst_2 == version_inst_3


# Generated at 2022-06-24 21:26:18.101379
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__ge__(version_1) == True


# Generated at 2022-06-24 21:26:20.959471
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert ((version_0) == '0')
