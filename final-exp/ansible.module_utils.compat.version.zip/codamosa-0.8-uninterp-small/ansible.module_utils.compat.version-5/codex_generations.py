

# Generated at 2022-06-24 21:17:23.187715
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        version_0_var = Version()
        version_1_var = Version()
        version_0_var.__eq__(version_1_var)
    except:
        pass


# Generated at 2022-06-24 21:17:25.521843
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert (version_0 < version_1)


# Generated at 2022-06-24 21:17:27.015182
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_0 = version_0


# Generated at 2022-06-24 21:17:29.321173
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    version_1 = Version()
    assert version_1.__ge__('') == NotImplemented



# Generated at 2022-06-24 21:17:39.612981
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_0 = Version()
    version_1 = Version()
    version_1 = Version()
    version_0 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_0 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()
    version_0 = Version()
    version_1 = Version()
    version_0 = Version()
    version_1 = Version()
    version_1 = Version()
    version_1 = Version()

# Generated at 2022-06-24 21:17:41.900272
# Unit test for method __le__ of class Version
def test_Version___le__():
        version_0 = Version()
        version_1 = Version()
        assert version_0 <= version_1


# Generated at 2022-06-24 21:17:51.066376
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    import unittest
    from distutils.version import Version as VersionClass

    class Version___eq__TestCase(unittest.TestCase):
        def test_0(self):
            self.assertTrue(VersionClass() == VersionClass())
            self.assertFalse(VersionClass() != VersionClass())
            self.assertFalse(VersionClass() == 1)
            self.assertTrue(VersionClass() != 1)

        def test_1(self):
            version_0_equal = VersionClass() == VersionClass()
            self.assertTrue(version_0_equal)
            version_0_not_equal = VersionClass() != VersionClass()
            self.assertFalse(version_0_not_equal)
            version_1_equal = VersionClass() == 1
            self.assertFalse(version_1_equal)
            version_1_not

# Generated at 2022-06-24 21:17:56.181595
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """
    # Test-case for the class Version
    """
    version_1 = Version()
    assert version_1.__gt__(None) == NotImplemented
    assert version_1.__gt__(0) == NotImplemented
    assert version_1.__gt__('') == NotImplemented


# Generated at 2022-06-24 21:17:58.122507
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    version_0 = Version()
    version_1 = Version()
    version_0_lt = version_0 < version_1
    assert version_0_lt == True


# Generated at 2022-06-24 21:18:03.777156
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    # assert version_0.__le__(version_1) == False
    # assert version_0.__le__(version_1) == True


# Generated at 2022-06-24 21:18:16.421550
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    to_test = version_1 >= version_1
    expected_result = True
    assert to_test == expected_result, 'output does not match expected result'


# Generated at 2022-06-24 21:18:18.163479
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    try:
        version_0.__ge__('')
    except Exception as exception_0:
        print(exception_0)


# Generated at 2022-06-24 21:18:20.597071
# Unit test for method __le__ of class Version
def test_Version___le__():
    instance_0 = Version()
    try:
        int(instance_0)
    except:
        pass
    else:
        raise "AssertionError"
    try:
        float(instance_0)
    except:
        pass
    else:
        raise "AssertionError"


# Generated at 2022-06-24 21:18:23.270163
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    boo = version_0 < version_1 < version_2

# Generated at 2022-06-24 21:18:24.876979
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    string_0 = str(version_0)


# Generated at 2022-06-24 21:18:33.222750
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_1 = StrictVersion('0.4')
    assert str(version_1) == '0.4'
    version_2 = StrictVersion('0.4.0')
    assert str(version_2) == '0.4.0'
    version_3 = StrictVersion('0.4.1')
    assert str(version_3) == '0.4.1'
    version_4 = StrictVersion('0.5a1')
    assert str(version_4) == '0.5a1'
    version_5 = StrictVersion('0.5b3')
    assert str(version_5) == '0.5b3'
    version_6 = StrictVersion('0.5')
    assert str(version_6) == '0.5'

# Generated at 2022-06-24 21:18:34.408204
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    str_1 = StrictVersion('0.4.1').__str__()


# Generated at 2022-06-24 21:18:38.863292
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    print("Testing method __eq__ of class Version")
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    assert version_0 == version_1


# Generated at 2022-06-24 21:18:48.007036
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()

    version_0.parse = lambda x: None
    version_1.parse = lambda x: None

    version_0.version = 4
    version_1.version = 3

    version_2._cmp = lambda x: 1

    try:
        version_0.__gt__(version_1)
    except:
        print("Unexpected exception occured")
    try:
        version_0.__gt__(version_2)
    except:
        print("Unexpected exception occured")



# Generated at 2022-06-24 21:18:55.597674
# Unit test for method __le__ of class Version
def test_Version___le__():
    # version_lte_2 = Version(vstring="1.2")
    version_2 = Version(vstring="1.2")
    version_lte_2 = Version(vstring="1.2")
    assert version_lte_2 <= version_2
    # version_lte_2 = Version(vstring="2.1")
    version_lte_2 = Version(vstring="2.1")
    assert not version_lte_2 <= version_2


# Generated at 2022-06-24 21:19:06.133775
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    lhs = Version("1.1.1")
    rhs = Version("2.2.2")
    assert lhs < rhs


# Generated at 2022-06-24 21:19:08.112123
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1


# Generated at 2022-06-24 21:19:11.104334
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    # Test for __gt__ when object is a class instance
    # Test for False
    assert version_0.__gt__(version_1) == False


# Generated at 2022-06-24 21:19:15.975587
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version()
    version_2 = Version()
    version_1.__gt__(version_2)


# Generated at 2022-06-24 21:19:17.679561
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    result = version_0 >= version_1


# Generated at 2022-06-24 21:19:19.925532
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version('1.0.0')
    v2 = Version('1.0.1')
    if (v1 > v2):
        test_case_0()
    else:
        test_case_1()


# Generated at 2022-06-24 21:19:27.205689
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    str_arg_0 = "1"
    str_arg_1 = "2"
    str_arg_2 = "3"
    assert version_0._cmp(str_arg_0) < 0
    assert version_0._cmp(str_arg_1) < 0
    assert version_0._cmp(str_arg_2) < 0


# Generated at 2022-06-24 21:19:32.808274
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    # Assert: Equality check against version prior to parse
    try:
        version = Version()
        version.__gt__(Version('1.0.0'))
    except ValueError:
        return

    assert False


# Generated at 2022-06-24 21:19:35.486088
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert (Version() < Version()) == (NotImplemented)


# Generated at 2022-06-24 21:19:38.199663
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # From CPython 3.9.5: Version.__ge__
    """Method that implements the >= operator"""
    def __ge__(self, other):
        c = self._cmp(other)
        if c is NotImplemented:
            return c
        return c >= 0


# Generated at 2022-06-24 21:19:48.010767
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    b = v1 > v2
    assert type(b) == bool


# Generated at 2022-06-24 21:19:51.105150
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    """Test that a StrictVersion object is equal to itself
    """
    version_0 = Version(0)
    if version_0 == version_0:
        pass
    else:
        fail()


# Generated at 2022-06-24 21:19:55.809852
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    ret_val = version_0._cmp(version_1)
    assert ret_val is NotImplemented


# Generated at 2022-06-24 21:19:59.063033
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()

    # Test 1
    try:
        version_0.__lt__(version_1)
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_case_0()
    test_Version___lt__()

# Generated at 2022-06-24 21:20:00.019968
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    test_case_0()


# Generated at 2022-06-24 21:20:02.684577
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version()
    v1 = Version()
    assert v0.__gt__(v1) == False, 'Error: Unexpected result'
    v1 = Version('0.0')
    assert v0.__gt__(v1) == False, 'Error: Unexpected result'
    v1 = Version('1.0')
    assert v0.__gt__(v1) == False, 'Error: Unexpected result'



# Generated at 2022-06-24 21:20:04.469886
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version = Version('0')
    version2 = Version('0')
    assert version <= version2
    version3 = Version('1')
    assert version < version3


# Generated at 2022-06-24 21:20:09.300400
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    vstring = "1.3.0.0"
    version_1 = Version(vstring)
    assert not version_0 == version_1, "Expected vstring %s, received %s" % (vstring, str(version_0))


# Generated at 2022-06-24 21:20:10.736963
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Try to compare with a string
    Version('1.0') == '1.0'


# Generated at 2022-06-24 21:20:13.343360
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0.parse("4.4.4")
    version_0.parse("4.4.4")
    version_0.parse("4.4.4")

    version_0.parse("4.4.4")
    version_0.parse("4.4.4")


# Generated at 2022-06-24 21:20:28.176322
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    if version_0.__gt__(version_0) is NotImplemented:
        pass
    else:
        raise AssertionError('test_Version___gt__ failed')


# Generated at 2022-06-24 21:20:34.102083
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0.__le__(None)


# Generated at 2022-06-24 21:20:36.125435
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version = version_0.__gt__(version_1)
    return version


# Generated at 2022-06-24 21:20:41.712060
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version()
    other = Version()
    isinstance(other, Version)
    ver.__lt__(other)


# Generated at 2022-06-24 21:20:42.815686
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version().__gt__(None) == NotImplemented



# Generated at 2022-06-24 21:20:52.729326
# Unit test for method __le__ of class Version
def test_Version___le__():
    v5 = Version("5.0")
    v30 = Version("3.0")
    vnew = Version("3.2")
    v5plus = Version("5+")
    v5dev = Version("5.dev")


    assert str(v5) == "5.0"
    assert str(v30) == "3.0"
    assert str(vnew) == "3.2"

    assert v30 == Version("3.0")
    assert v30 != Version("3.1")

    assert v30 <= Version("3.0")
    assert v30 < Version("3.1")
    assert v30 <= Version("3.1")
    assert v30 < Version("3.1.1")
    assert v30 <= Version("3.1.1")


# Generated at 2022-06-24 21:21:01.889097
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version('1.5')
    version_3 = Version('1.5.6')
    version_4 = Version('1.5.7')
    version_5 = Version('1.8')
    version_6 = Version('1.8.4')
    version_7 = Version('1.10')
    version_8 = Version('2.2.1')

    assert version_0 <= version_1
    assert version_0 <= version_2
    assert version_0 <= version_3
    assert version_0 <= version_4
    assert version_0 <= version_5
    assert version_0 <= version_6
    assert version_0 <= version_7
    assert version_0 <= version_8

    assert version_1 <= version_0
   

# Generated at 2022-06-24 21:21:04.913084
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse("3.3.3")
    assert (version_1 <= version_1)

# Suppress lint error, as it does not make sense to annotate a function
# which does not return a value.
# pylint: disable=bad-return-type

# Generated at 2022-06-24 21:21:16.315716
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_1.parse('0.9.9')
    assert (version_1 > version_0)
    version_2 = Version()
    version_2.parse('1.0.0')
    assert (version_2 > version_1)
    version_3 = Version()
    version_3.parse('1.0.1')
    assert (version_3 > version_2)
    version_4 = Version()
    version_4.parse('1.1.0')
    assert (version_4 > version_3)
    version_5 = Version()
    version_5.parse('1.1.1')
    assert (version_5 > version_4)
    version_6 = Version()

# Generated at 2022-06-24 21:21:23.570056
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Input params
    vstring = 'test'
    other = '123'
    # Expected results
    expected_result = 0
    # Perform the test
    result = vstring.__le__(other)
    # Verify the results
    if result == expected_result:
        # We're okay
        print("Pass")
    else:
        # Something went wrong
        print("Fail")
        print("Expected", expected_result)
        print("Received", result)


# Generated at 2022-06-24 21:21:51.376440
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0 >= '0'
    assert version_0 >= version_0



# Generated at 2022-06-24 21:21:54.259569
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_0 > version_1
    assert version_2



# Generated at 2022-06-24 21:21:57.682318
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version("1.0.1")
    assert(version_1 > "0.9.1") == False, "Fail to compare versions."


# Generated at 2022-06-24 21:22:01.168990
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    origin = Version()
    new = Version()
    if origin != new:
        print("Error:  __lt__ is not correct")


# Generated at 2022-06-24 21:22:05.749037
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()

    assertEqual(version_0 >= version_1, True)
    assertEqual(version_0 >= version_2, True)
    assertEqual(version_0 >= version_3, True)


# Generated at 2022-06-24 21:22:08.110804
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v0 = Version("2.0.0a1")
    v1 = Version("2.0.0b1")
    assert v0<v1


# Generated at 2022-06-24 21:22:12.784610
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v = Version()
    v >= '1.0'
    v > '1.0'
    v > Version('1.0')



# Generated at 2022-06-24 21:22:16.798394
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_2 = 'a'

    try:
        version_0.__gt__(version_1)
    except NotImplementedError:
        pass

    try:
        version_0.__gt__(version_2)
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:22:21.393309
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    retval = Version().__lt__()
    raise NotImplementedError("Test not implemented")


# Generated at 2022-06-24 21:22:22.443872
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert Version() < Version('0.0.0a1')


# Generated at 2022-06-24 21:23:23.487433
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0 == version_1)


# Generated at 2022-06-24 21:23:33.376963
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    version_18 = Version()
    version_19 = Version()
    version_20 = Version()
    version_21 = Version()
    version_22 = Version()
    version_23 = Version()
    version_24 = Version()

# Generated at 2022-06-24 21:23:38.170801
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    class Mock:
        def _cmp(self, other):
            if other == "1.0":
                return 0
            elif other == "2.0":
                return 1
            else:
                return NotImplemented

    mockVersion = Mock()
    assert mockVersion == "1.0"
    assert mockVersion == "2.0"
    assert mockVersion != "3.0"
    assert mockVersion != None


# Generated at 2022-06-24 21:23:44.743733
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = Version._cmp
    version_0._cmp = Version._cmp
    version_0._cmp = Version._cmp
    version_0._cmp = Version._cmp
    version_1._cmp = Version._cmp
    version_1._cmp = Version._cmp
    version_1._cmp = Version._cmp
    version_1._cmp = Version._cmp
    version_0._cmp(version_1)
    version_1._cmp(version_0)
    version_1._cmp(version_0)
    version_0._cmp(version_1)
    version_0._cmp(version_1)
    version_1._cmp(version_0)
    version_0._cmp(version_1)
    version_1._cmp(version_0)

# Generated at 2022-06-24 21:23:46.063683
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert version_0 <= version_0


# Generated at 2022-06-24 21:23:49.145794
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    ret = v1.__le__(v2)
    assert type(ret) == bool


# Generated at 2022-06-24 21:23:52.909972
# Unit test for method __le__ of class Version
def test_Version___le__():
    class Test(Version):
        def _cmp(self, other):
            return 0

    version_0 = Test("")
    assertTestFails(version_0.__le__)
    assertTestFails(Test("").__le__)


# Generated at 2022-06-24 21:24:04.136583
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_2 = Version("2")
    version_2b = Version("2")
    version_3 = Version("3")
    version_0 = Version("0")
    version_negative10 = Version("-10")
    version__5 = Version("-5")
    version_alpha = Version("alpha")
    version_alpha2 = Version("alpha2")
    version_beta = Version("beta")
    version_beta3 = Version("beta3")
    version_pl2 = Version("pl2")
    version_rc1 = Version("rc1")
    version_m1 = Version("m1")
    version_0_4 = Version("0.4")
    version_0_5 = Version("0.5")
    version_0_6 = Version("0.6")
    version_0_7 = Version("0.7")

# Generated at 2022-06-24 21:24:09.634193
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    try:
        version_0 = Version()
        version_1 = Version()
        version_0._cmp = lambda x: NotImplemented
        version_0.__gt__(version_1)
    except NotImplementedError as e:
        assert True
    except:
        assert False


# Generated at 2022-06-24 21:24:11.501250
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v1 = Version()
    v2 = Version()
    assert v1 == v2


# Generated at 2022-06-24 21:25:29.425027
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    ans = version_0.__ge__(version_0)
    assert ans


# Generated at 2022-06-24 21:25:30.597000
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    assert version_1 >= Version()


# Generated at 2022-06-24 21:25:36.158297
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()


# Generated at 2022-06-24 21:25:38.669747
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__lt__(version_1)


# Generated at 2022-06-24 21:25:40.419756
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    arg_0 = Version()
    result_1 = version_0.__gt__(arg_0)


# Generated at 2022-06-24 21:25:42.637920
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    version_0.__ge__(version_1)


# Generated at 2022-06-24 21:25:45.884206
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = Version()
    # version = Version(None)
    version.parse = '0.0.0'
    other = Version()
    # other = Version(None)
    other.parse = '0.0.0'
    # Check if both of them are equal
    if version >= other:
        print("Success")


# Generated at 2022-06-24 21:25:55.555146
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    assert Version("1.0.0b") > Version("1.0.0a")
    assert Version("1.0.0b") > Version("1.0.0a")
    assert Version("1.0.0b") > Version("1.0.0a")
    assert Version("1.0.0b") > Version("1.0.0a")
    assert Version("3.3") > Version("3.2")
    assert Version("3.3") > Version("3.2")
    assert Version("3.3") > Version("3.2")
    assert Version("3.3") > Version("3.2")
    assert Version("3.2") > Version("3.1")
    assert Version("3.2") > Version("3.1")
    assert Version("3.2") > Version("3.1")

# Generated at 2022-06-24 21:25:56.746169
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert version_0 < version_0


# Generated at 2022-06-24 21:25:59.067580
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    with pytest.raises(TypeError):
        version_1.__gt__(version_0)

