

# Generated at 2022-06-24 21:17:20.887115
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse("1.0.0")
    version_1.parse("2.5.5")
    assert not version_0 < version_1
    assert not version_1 < version_0
    assert not version_0 < "2.5.5"
    assert not version_1 < "1.0.0"


# Generated at 2022-06-24 21:17:26.381270
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    version_1 = Version(vstring = '0.0.0')
    version_2 = Version(vstring = '0.0.1')

    # Unit test for condition where method returns False
    if version_1 == version_2 or version_1 >= version_2 or version_1 > version_2:
        raise AssertionError('Unit test for __lt__ failed')


# Generated at 2022-06-24 21:17:30.603290
# Unit test for method __le__ of class Version
def test_Version___le__():

    # In the test run I'm going to check if this function
    # works correctly when comparing objects of class Version

    # Creating an object of class Version to compare
    version_0 = Version()

    # The object I'm going to compare it against
    version_1 = Version()

    # Testing if the two objects are equal
    version_0.__le__(version_1)

    # Testing if the two objects are unequal
    version_0.__le__(version_1)



# Generated at 2022-06-24 21:17:37.247734
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version("5.5")
    version_2 = Version("1.3.3")
    version_3 = Version("0.9.0")
    boolean_0 = version_1 >= version_0
    boolean_1 = version_2 >= version_1
    boolean_2 = version_3 >= version_2
    boolean_3 = version_2 >= version_0
    boolean_4 = version_1 >= version_1
    


# Generated at 2022-06-24 21:17:42.099826
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_0 = version_2
    if version_0 != version_1:
        return True
    if version_0 == version_2:
        return True
    return False


# Generated at 2022-06-24 21:17:48.032901
# Unit test for method __gt__ of class Version
def test_Version___gt__():
	test_case_0()

# Generated at 2022-06-24 21:17:51.174208
# Unit test for method __le__ of class Version
def test_Version___le__():
    f = Version()
    f = Version()
    assert f >= f is True


# Generated at 2022-06-24 21:17:56.007449
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_0
    version_1.parse("2.5.5")
    version_0._cmp(version_1)
    version_0._cmp(version_2)
    version_1._cmp(version_2)


# Generated at 2022-06-24 21:17:59.359605
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    '''Test method Version.__eq__'''
    try:
        assert test_case_0().__eq__('self._cmp(other)') == NotImplemented
    except:
        print("Exception encountered during verification")
        raise


# Generated at 2022-06-24 21:18:01.219251
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_1 = StrictVersion()
    version_1.parse("1.2.3a4")
    version_2 = StrictVersion("1.2.3b4")


# Generated at 2022-06-24 21:18:13.525534
# Unit test for method __le__ of class Version
def test_Version___le__():
    v0 = Version()
    v1 = Version()
    assert v0.__le__(v1)


# Generated at 2022-06-24 21:18:14.566521
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    try:
        StrictVersion().__str__()
    except AttributeError as e:
        print(e)


# Generated at 2022-06-24 21:18:15.592397
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    v2 = Version()
    assert ((v1 < v2) == False)


# Generated at 2022-06-24 21:18:19.534853
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    print("testing __lt__ method")
    try:
        version_1 = Version("v0.0.0")
        version_2 = Version("v1.0.0")

        if(version_1 < version_2):
            print("Pass")
        else:
            print("Fail")
    except Exception:
        print("Fail")



# Generated at 2022-06-24 21:18:21.678898
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_1 = Version()
    other_1 = other()
    assert version_1 >= other_1


# Generated at 2022-06-24 21:18:31.288668
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    assert (version_0 == version_0) == True
    version_1 = Version()
    assert (version_0 == version_1) == True
    version_2 = Version()
    assert (version_0 == version_2) == True
    version_3 = Version()
    assert (version_0 == version_3) == True
    version_4 = Version()
    assert (version_0 == version_4) == True
    version_5 = Version()
    assert (version_0 == version_5) == True
    version_6 = Version()
    assert (version_0 == version_6) == True
    version_7 = Version()
    assert (version_0 == version_7) == True
    version_8 = Version()
    assert (version_0 == version_8) == True
   

# Generated at 2022-06-24 21:18:38.922533
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = version_0
    version_2 = version_0
    version_3 = version_0
    version_4 = version_0
    version_5 = version_0
    version_6 = version_0

    # Test 1

# Generated at 2022-06-24 21:18:47.729129
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    assert Version("1.1").__eq__("1.1"), "test_Version___eq__"
    assert Version("0.0.2").__eq__("0.0.2"), "test_Version___eq__"
    assert not Version("1.1").__eq__("1.0"), "test_Version___eq__"
    assert not Version("1.1").__eq__("2.0.2"), "test_Version___eq__"
    assert not Version("1.1").__eq__("1.1.1"), "test_Version___eq__"


# Generated at 2022-06-24 21:18:58.660157
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # init version_1
    version_1 = Version()
    assert version_1.__class__ == Version

    # Define vstring_1
    vstring_1 = '<undef>'

    # Call method __gt__ of version_1
    # version_1.__gt__(vstring_1)

    # Define version_2
    version_2 = Version()
    assert version_2.__class__ == Version

    # Call method __gt__ of version_2
    # version_2.__gt__(vstring_1)

    # Define version_3
    version_3 = Version()
    assert version_3.__class__ == Version

    # Call method __gt__ of version_3
    # version_3.__gt__(vstring_1)

    # Define version_4
    version

# Generated at 2022-06-24 21:19:00.846810
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    version_0 = Version()
    version_1 = version_0
    assert version_0 >= version_1


# Generated at 2022-06-24 21:19:17.471551
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version('1')
    version_2 = Version('2')
    return version_2.__gt__(version_1)


# Generated at 2022-06-24 21:19:23.498074
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version = Version("v0.0.1")
    version2 = Version("v0.0.2")
    version3 = Version("v0.0.3")
    version4 = Version("v0.0.4")
    version5 = Version("v0.0.5")
    version6 = Version("v0.0.6")
    version7 = Version("v0.0.7")
    version8 = Version("v0.0.8")
    version9 = Version("v0.0.9")

if __name__ == '__main__':
    test_case_0()
    test_Version___gt__()

# Generated at 2022-06-24 21:19:25.693960
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    try:
        version_0.__gt__('string')
    except ValueError:
        pass


# Generated at 2022-06-24 21:19:26.963128
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version()
    version_1 = version_0 > version_1
    assert version_1 is False


# Generated at 2022-06-24 21:19:32.239781
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    ans = version_0 <= version_1


# Generated at 2022-06-24 21:19:36.920308
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_1 = Version("1.0.3")
    version_2 = Version("1.0.1")
    if (version_1 > version_2):
        pass


# Generated at 2022-06-24 21:19:38.064977
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 < version_1


# Generated at 2022-06-24 21:19:44.535961
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    flag = version_0 == version_1
    if flag:
        print("test_Version___eq__(): ok")
    else:
        print("test_Version___eq__(): FAILED")


# Generated at 2022-06-24 21:19:46.848959
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.__eq__(version_1)


# Generated at 2022-06-24 21:19:48.374542
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0 >= version_0


# Generated at 2022-06-24 21:20:09.424762
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert version_0 <= 0
    assert not (version_0 <= 0.0)
    assert not (version_0 <= '0')
    assert not (version_0 <= Version())


# Generated at 2022-06-24 21:20:13.737910
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    vc = Version()
    vd = Version()
    ve = Version()
    vf = Version()
    vg = Version()

    vc._cmp = lambda x,y: -1
    vd._cmp = lambda x,y: 0
    ve._cmp = lambda x,y: 1
    vf._cmp = lambda x,y: -1

    assert vc > Version()
    assert not vd > Version()
    assert not ve > Version()
    assert not vf > Version()

    try:
        not vg > Version()
    except NotImplementedError:
        pass


# Generated at 2022-06-24 21:20:19.016471
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()

    version_6 = version_0.__ge__(version_1)
    version_7 = version_0.__le__(version_2)
    version_8 = version_0.__lt__(version_3)
    version_9 = version_0.__gt__(version_4)
    version_10 = version_0.__eq__(version_5)



# Generated at 2022-06-24 21:20:19.830386
# Unit test for method __le__ of class Version
def test_Version___le__():
    print(Version().__le__('0'))
    

# Generated at 2022-06-24 21:20:21.709422
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    try:
        test_case_0()
    except Exception:
        raise AssertionError('__ge__ method of Version class has errors')
    else:
        pass


# Generated at 2022-06-24 21:20:26.935782
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    assert(v1.__gt__(v2) == 0)


# Generated at 2022-06-24 21:20:29.317722
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = version_0
    assert version_0 == version_1


# Generated at 2022-06-24 21:20:39.435813
# Unit test for method __lt__ of class Version

# Generated at 2022-06-24 21:20:42.696232
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        version_0 = Version("1.2.3")
        version_1 = Version("1.2.2")
        assert version_0 >= version_1
        assert version_0 <= version_1
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-24 21:20:49.127365
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        test_case_0()
    except:
        import traceback
        exception = traceback.format_exc()
        raise Exception("An error occured in unit test method 'test_case_0'\n" + exception)



# Generated at 2022-06-24 21:21:26.759433
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v2 = Version('5000.0')
    v.__ge__(v2)


# Generated at 2022-06-24 21:21:37.094271
# Unit test for method __le__ of class Version
def test_Version___le__():
    import random
    _len = random.randint(0, 1000)
    _vstring0 = [version_0._get_parts()[0], version_0._get_parts()[1]]
    _vstring0[0] = random.sample(range(0, 10), random.randint(0, _len))
    _vstring0[1] = random.sample(range(0, 10), random.randint(0, _len))
    _vstring1 = [version_1._get_parts()[0], version_1._get_parts()[1]]
    _vstring1[0] = random.sample(range(0, 10), random.randint(0, _len))
    _vstring1[1] = random.sample(range(0, 10), random.randint(0, _len))
   

# Generated at 2022-06-24 21:21:40.426078
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if (version_0 == version_1):
        pass


# Generated at 2022-06-24 21:21:49.795849
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()
    version_16 = Version()
    version_17 = Version()
    # __le__(self, other):
    # __le__(Version(), Version())
    version_0.__le__(version_1)
    version_1.__le__(version_2)

# Generated at 2022-06-24 21:21:51.404583
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version("1.0")
    assert (version_1 <= version_0) == False


# Generated at 2022-06-24 21:21:57.466885
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    versions = [Version('1.0.0'), Version('1.1.0'), Version('1.0.1'), Version('1.1.1'), Version('0.99.99')]
    assert versions[0] >= versions[1]
    assert versions[0] >= versions[2]
    assert not versions[0] >= versions[3]
    assert not versions[0] >= versions[4]


# Generated at 2022-06-24 21:22:00.864464
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_1 = Version()
    version_2 = Version()
    assert version_1.__lt__(version_2)


# Generated at 2022-06-24 21:22:03.508781
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    assert version_0 >= version_0


# Generated at 2022-06-24 21:22:06.318312
# Unit test for method __le__ of class Version
def test_Version___le__():
    print("Running test: Version.__le__")
    version_0 = Version()
    version_1 = Version()
    assert (version_0 <= version_1) is True


# Generated at 2022-06-24 21:22:08.283752
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    result = version_0.__eq__(version_0)
    print(result)


# Generated at 2022-06-24 21:23:32.859291
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version('1.2.3')
    version_1 = Version()
    version_2 = Version('1.2.4')
    version_3 = Version('1.2.3')
    version_4 = Version('1.2.2')
    assert (version_0 >= version_1 is None)
    assert (version_0 >= version_2 == None)
    assert (version_0 >= version_3 == True)
    assert (version_0 >= version_4 == True)


# Generated at 2022-06-24 21:23:35.971269
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion("1.2.3")
    v.parse("1.2.3")
    # + 'str': '1.2.3'
    assert(str(v) == "1.2.3")


# Generated at 2022-06-24 21:23:38.260882
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    if (version_0 == version_1):
        pass
    pass


# Generated at 2022-06-24 21:23:40.635993
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v0 = Version(vstring='v0')
    v1 = Version(vstring='v1')
    if not (v1 > v0):
        print('1')


# Generated at 2022-06-24 21:23:44.530824
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    result_0 = version_0.__ge__(version_1)
    result_1 = version_0.__ge__(version_1)
    result_2 = version_0.__ge__(version_1)
    assert (result_0 == result_1) and (result_1 == result_2)


# Generated at 2022-06-24 21:23:49.146587
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0._cmp = lambda other:NotImplemented
    other = None
    try:
        Version.__le__(version_0, other)
    except:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-24 21:23:50.276423
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass # TODO


# Generated at 2022-06-24 21:23:51.797306
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0 = Version()



# Generated at 2022-06-24 21:23:53.564626
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version('1')
    version_1 = Version('2')
    assert version_0 < version_1


# Generated at 2022-06-24 21:23:56.907624
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__ge__(version_1)


# Generated at 2022-06-24 21:25:43.781153
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Test of the generated path leading to a return statement
    # Creates an instance of the class
    version_2 = Version()
    # Checks the value of the variable version_2
    if version_2 is None:
        return 1 # returns 1 if version_2 is None
    else:
        return 0 # returns 0 if version_2 is not None


# Generated at 2022-06-24 21:25:45.997513
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0.parse("Hello")
    assert version_0 >= "Hello", \
        'AssertionError: Expected Version("Hello") >= "Hello" to return True'


# Generated at 2022-06-24 21:25:49.508054
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_1 = Version()
    assert version_1.__ge__(version_0) == False


# Generated at 2022-06-24 21:25:52.390869
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = Version.__gt__(version_0, "")


# Generated at 2022-06-24 21:26:00.967090
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_3 = Version()
    version_2 = Version('1.0')
    version_3 = Version('0.9')
    version_3.parse('1.0')
    if (version_0 > version_1):
        raise RuntimeError
    if (version_0 >= version_1):
        raise RuntimeError
    if (version_2 <= version_3):
        raise RuntimeError
    if (version_2 < version_3):
        raise RuntimeError


# Generated at 2022-06-24 21:26:07.151558
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    import unittest
    import operator

    class TestCase(unittest.TestCase):
        def setUp(self):
            self.version_0 = Version()
            self.version_1 = Version('1')
            self.version_2 = Version('2')

        def test_case_0(self):
            self.assertTrue(operator.lt(self.version_0, self.version_1))
            self.assertFalse(operator.lt(self.version_0, self.version_0))
            self.assertFalse(operator.lt(self.version_1, self.version_0))
            self.assertTrue(operator.lt(self.version_0, self.version_2))
            self.assertFalse(operator.lt(self.version_1, self.version_2))

# Generated at 2022-06-24 21:26:09.232629
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()

    assert version_0 <= version_1



# Generated at 2022-06-24 21:26:13.445615
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = version_0
    assert version_1 > version_0


# Generated at 2022-06-24 21:26:21.310990
# Unit test for method __le__ of class Version
def test_Version___le__():

    # test for method __le__ (1st branch)
    # a valid version number must be passed to __le__
    try:
        version_2 = Version("2")
    except:
        raise
    __le___ret_val_1 = version_2.__le__("1")
    if __le___ret_val_1 != False:
        raise AssertionError("1st branch test for method __le__ of class Version failed")

    # test for method __le__ (1st branch)
    # a valid version number must be passed to __le__
    try:
        version_1 = Version("1")
    except:
        raise
    __le___ret_val_2 = version_1.__le__("1")
    if __le___ret_val_2 != True:
        raise Assertion

# Generated at 2022-06-24 21:26:25.644408
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = StrictVersion("0.0.2")
    version_1 = StrictVersion("1.0.0")
    assert version_0 < version_1
    assert version_0 <= version_1
    assert not (version_0 > version_1)
    assert not (version_0 >= version_1)
