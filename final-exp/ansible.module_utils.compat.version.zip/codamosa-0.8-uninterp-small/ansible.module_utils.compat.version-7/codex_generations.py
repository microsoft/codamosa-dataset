

# Generated at 2022-06-24 21:17:27.377713
# Unit test for method __ge__ of class Version
def test_Version___ge__():

    # From CPython 3.9.5:Lib/distutils/version.py
    strict_version_0 = StrictVersion("1.0.0")
    strict_version_1 = StrictVersion("1.0")
    strict_version_2 = StrictVersion("1.0.0")
    strict_version_3 = StrictVersion("1.1")

    assert strict_version_0 == strict_version_2

    assert not strict_version_0 == strict_version_1
    assert not strict_version_0 == strict_version_3

    assert not strict_version_0 != strict_version_2

    assert strict_version_0 != strict_version_1
    assert strict_version_0 != strict_version_3

    assert strict_version_0 <= strict_version_2
    assert strict_version_0 <= strict_

# Generated at 2022-06-24 21:17:29.060307
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    v1 = Version()
    assert v >= v1


# Generated at 2022-06-24 21:17:31.965955
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version1 = Version()
    version1.parse('1.2')
    version2 = Version()
    version2.parse('1.3')
    assert version1 > version2


# Generated at 2022-06-24 21:17:33.082271
# Unit test for method __gt__ of class Version
def test_Version___gt__():

    # Instantiate an instance of the class to be tested
    strict_versi

# Generated at 2022-06-24 21:17:36.263310
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()

    if not type(str(strict_version_0)) is str:
        raise AssertionError("'str(strict_version_0)' should return a string")


# Generated at 2022-06-24 21:17:40.605205
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion("0.0")
    strict_version_1 = StrictVersion("1.0.0.0")

    print("Version.__gt__() test result:", strict_version_1 > strict_version_0)


# Generated at 2022-06-24 21:17:42.745346
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    assert str(StrictVersion('1.2.3')) == '1.2.3'


# Generated at 2022-06-24 21:17:45.866000
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    v = StrictVersion()
    v.parse('1.0')
    assert v.version == (1, 0, 0), "version"
    assert v.prerelease is None, "prerelease"


# Generated at 2022-06-24 21:17:47.390843
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert not Version().__lt__(Version())


# Generated at 2022-06-24 21:17:49.073115
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert StrictVersion.__ge__({'a': 'a'}, {'b': 'b'})


# Generated at 2022-06-24 21:18:07.384927
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Test that any version at least compares with itself

    # precondition:
    # internal class invariant: vstring is not None
    # __ge__ does not take None as argument
    # so __ge__(None) will fail, but __ge__(<anything else>) should succeed

    # precondition:
    # internal class invariant: vstring is not None
    # __ge__ does not take None as argument
    # so __ge__(None) will fail, but __ge__(<anything else>) should succeed
    strict_version_0 = StrictVersion()

    # precondition:
    # internal class invariant: vstring is not None
    # __ge__ does not take None as argument
    # so __ge__(None) will fail, but __ge__(<anything else>) should succeed

# Generated at 2022-06-24 21:18:12.099884
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    strict_version_3 = StrictVersion()
    strict_version_4 = StrictVersion()
    strict_version_5 = StrictVersion()
    strict_version_6 = StrictVersion()
    strict_version_7 = StrictVersion()
    strict_version_8 = StrictVersion()
    strict_version_9 = StrictVersion()
    strict_version_10 = StrictVersion()
    strict_version_11 = StrictVersion()
    strict_version_12 = StrictVersion()
    strict_version_13 = StrictVersion()
    strict_version_14 = StrictVersion()
    strict_version_15 = StrictVersion()

# Generated at 2022-06-24 21:18:15.166993
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()


# Generated at 2022-06-24 21:18:17.484943
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    expected = 0
    actual = 0
    strict_version_0 = StrictVersion()
    actual = strict_version_0.__lt__()
    if ( actual != expected ):
        print("Testcase 0 failed")


# Generated at 2022-06-24 21:18:21.829575
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_1 = StrictVersion()
    strict_version_1.parse('0')
    strict_version_2 = StrictVersion()
    strict_version_1._cmp(strict_version_2)


# Generated at 2022-06-24 21:18:25.367687
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = StrictVersion("1.2")
    v2 = StrictVersion("1.3")
    if not v1.__lt__(v2):
        raise RuntimeError("Failed: %s is not less than %s" % (v1, v2))


# Generated at 2022-06-24 21:18:28.510495
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()

    assert (not strict_version_0 < strict_version_1)


# Generated at 2022-06-24 21:18:32.032554
# Unit test for method __le__ of class Version
def test_Version___le__():
    """Test case for method __le__ of class Version"""
    s = StrictVersion()
    assert (s >= "1") == False


# Generated at 2022-06-24 21:18:35.404956
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    """Test  StrictVersion('0.0.0.0') > StrictVersion('0.0.0')"""
    
    strict_version_0 = StrictVersion('0.0.0.0')
    strict_version_1 = StrictVersion('0.0.0')

    # Call Version method __gt__ 
    assert strict_version_0 > strict_version_1


# Generated at 2022-06-24 21:18:41.132921
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    strict_version_0._cmp = lambda x: -1
    strict_version_1._cmp = lambda x: 0
    strict_version_2._cmp = lambda x: 1
    assert strict_version_0 <= strict_version_1
    assert strict_version_1 <= strict_version_1
    assert not strict_version_2 <= strict_version_1



# Generated at 2022-06-24 21:18:50.378075
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion('0.0')
    assert not (strict_version_0 <= strict_version_0)


# Generated at 2022-06-24 21:18:53.310035
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = Version()
    v2 = Version()
    v1._cmp = lambda v: 1
    assert v1 > v2


# Generated at 2022-06-24 21:18:59.716038
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_0_0 = StrictVersion()
    strict_version_0_0_1 = StrictVersion('')
    strict_version_0_0_m = StrictVersion('0.0')

# Generated at 2022-06-24 21:19:03.150039
# Unit test for method __le__ of class Version
def test_Version___le__():
    v  = StrictVersion('1')
    assert v <= v
    assert not v <= None
    assert v <= StrictVersion('1')
    assert not v <= StrictVersion('2')
    assert v <= '1'
    assert not v <= '2'


# Generated at 2022-06-24 21:19:14.414994
# Unit test for method __le__ of class Version

# Generated at 2022-06-24 21:19:20.358857
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_0.parse(strict_version_1.parse(strict_version_0))
    strict_version_0.parse(str(strict_version_1))
    # Asserts that the above code raises a ValueError
    strict_version_0.parse(None)


# Generated at 2022-06-24 21:19:25.043160
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version = StrictVersion("1.0.0")
    if (not (strict_version > "0.9.9")):
        raise "strict_version > \"0.9.9\" failed"


# Generated at 2022-06-24 21:19:31.874837
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    if (strict_version_0 is not None):
        pass
    else:
        raise AssertionError("Expected not-None, got None")
    if (str(strict_version_0) == "0"):
        pass
    else:
        raise AssertionError("Expected 0, got %s" % str(strict_version_0))
    strict_version_1_1 = StrictVersion("1.1")
    if (strict_version_0 == strict_version_1_1):
        raise AssertionError("Expected False, got True")
    strict_version_0_0 = StrictVersion("0.0")
    if (strict_version_0 == strict_version_0_0):
        pass
    else:
        raise

# Generated at 2022-06-24 21:19:33.137868
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()


# Generated at 2022-06-24 21:19:35.850198
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert Version().__ge__(Version()) == True


# Generated at 2022-06-24 21:19:47.472166
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    version_1 = Version()



# Generated at 2022-06-24 21:19:50.047166
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version = StrictVersion()
    loose_version = LooseVersion()
    assert strict_version == loose_version



# Generated at 2022-06-24 21:19:56.137338
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    loose_version_0 = LooseVersion()
    # check for equality
    assert strict_version_0 <= strict_version_0
    assert strict_version_0 <= loose_version_0
    # check for inequality
    assert loose_version_0 <= strict_version_0
    return


# Generated at 2022-06-24 21:20:00.988989
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_1.parse('1.1.0')
    strict_version_2 = StrictVersion()
    strict_version_2.parse('1.1.0')
    strict_version_3 = StrictVersion()
    strict_version_3.parse('1.1.0.0')
    assert(strict_version_1 == strict_version_2)
    assert(strict_version_0 != strict_version_1)
    assert(strict_version_1 == strict_version_3)


# Generated at 2022-06-24 21:20:02.901933
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_1 = StrictVersion("123")
    strict_version_2 = StrictVersion("1")
    assert not (strict_version_1 == strict_version_2)


# Generated at 2022-06-24 21:20:04.741500
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion()
    version_0 = Version()
    version_0 = Version()


# Generated at 2022-06-24 21:20:10.723267
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    assert not (strict_version_0 >= strict_version_0)


# Generated at 2022-06-24 21:20:13.218383
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    # Verify that __str__ raises a TypeError exception
    with pytest.raises(TypeError):
        str(strict_version_0)


# Generated at 2022-06-24 21:20:16.130686
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()


# Generated at 2022-06-24 21:20:22.160902
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    global strict_version_0, strict_version_1, strict_version_2
    # Test for version number: 0.4
    strict_version_0 = StrictVersion('0.4')
    assert_equal(strict_version_0.__repr__(), "StrictVersion ('0.4')")
    # Test for version number: 0.5a1
    strict_version_1 = StrictVersion('0.5a1')
    assert_equal(strict_version_1.__repr__(), "StrictVersion ('0.5a1')")
    # Test for version number: 0,5b3
    assert_raises(ValueError, strict_version_1.parse, '0,5b3')


# Generated at 2022-06-24 21:20:32.444842
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert Version().__eq__(None) == False
    assert StrictVersion().__eq__(StrictVersion()) == True



# Generated at 2022-06-24 21:20:33.385133
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_case_0()


# Generated at 2022-06-24 21:20:35.046042
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_1 = Version()
    version_2 = Version()
    assert version_1 == version_2



# Generated at 2022-06-24 21:20:39.990503
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    assertion_type, assertion_msg = strict_version_0
    assert any([strict_version_0 > strict_version_0,
                strict_version_0 >= strict_version_0,
                strict_version_0 == strict_version_0,
                strict_version_0 <= strict_version_0,
                strict_version_0 < strict_version_0])


# Generated at 2022-06-24 21:20:46.908442
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    with pytest.raises(ValueError) as excinfo:
        LooseVersion().parse("")
    assert "invalid version number '%s'" % "" == str(excinfo.value)
    lv = LooseVersion()

# Generated at 2022-06-24 21:20:50.415695
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('0')
    strict_version_2 = StrictVersion(strict_version_1)
    strict_version_3 = StrictVersion(strict_version_2)
    strict_version_4 = StrictVersion('0.0')
    strict_version_5 = StrictVersion(strict_version_4)
    strict_version_6 = StrictVersion(strict_version_5)
    strict_version_7 = StrictVersion('0.0.0')
    strict_version_8 = StrictVersion(strict_version_7)
    strict_version_9 = StrictVersion(strict_version_8)
    strict_version_10 = StrictVersion('0.0.0.0')
    strict_version_

# Generated at 2022-06-24 21:20:54.744926
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    expected = 0

    if strict_version_0 >= '0':
        actual = 1
    else:
        actual = 0
    assert expected == actual


# Generated at 2022-06-24 21:20:55.612190
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    pass


# Generated at 2022-06-24 21:21:02.962822
# Unit test for method __eq__ of class Version

# Generated at 2022-06-24 21:21:14.208926
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()
    strict_version_2.parse('1')
    strict_version_3 = StrictVersion()
    strict_version_3.parse('1.0.0')
    strict_version_4 = StrictVersion()
    strict_version_4.parse('1.0.0.0')
    assert not strict_version_0 == strict_version_1, 'expected strict_version_0 != strict_version_1'
    assert not strict_version_1 == strict_version_2, 'expected strict_version_1 != strict_version_2'
    assert not strict_version_2 == strict_version_3, 'expected strict_version_2 != strict_version_3'
    assert strict

# Generated at 2022-06-24 21:21:29.415623
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = StrictVersion()
    version_1 = StrictVersion("2.6.0.b.4")
    version_2 = StrictVersion("2.6.0.b.4")
    version_3 = LooseVersion("2.6.0.b.4")
    version_4 = strict_version_0
    version_5 = LooseVersion("2.6.0.b.4")
    version_6 = StrictVersion("2.6.0.b.4")
    version_7 = strict_version_0
    version_8 = StrictVersion()
    version_9 = LooseVersion("2.6.0.b.4")
    version_10 = StrictVersion("2.6.0.b.4")

    if ((version_1 <= version_2) != True):
        return

# Generated at 2022-06-24 21:21:36.050089
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_1 = StrictVersion()

    strict_version_2 = StrictVersion()

    strict_version_3 = StrictVersion()

    strict_version_4 = StrictVersion()

    strict_version_5 = StrictVersion()

    strict_version_6 = StrictVersion()

    strict_version_7 = StrictVersion()

    strict_version_8 = StrictVersion()

    strict_version_9 = StrictVersion()


# Generated at 2022-06-24 21:21:48.056770
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.1')
    v2 = Version('1.2')
    assert not (test_Version___ge__.__wrapped__(v1, v2))
    assert test_Version___ge__.__wrapped__(v1, '1.1')
    v3 = Version('beta')
    assert not test_Version___ge__.__wrapped__(v1, v3)
    assert not test_Version___ge__.__wrapped__(v1, 'beta')
    assert not test_Version___ge__.__wrapped__(v3, v1)
    assert not test_Version___ge__.__wrapped__(v3, '1.1')
    v4 = Version('beta')
    assert test_Version___ge__.__wrapped__(v3, v4)

# Generated at 2022-06-24 21:21:51.987556
# Unit test for method __le__ of class Version
def test_Version___le__():
    other = Version()
    strict_version_0 = StrictVersion("1.0")
    # Verify that __le__ returns the expected result
    assert strict_version_0 <= other == False
    assert strict_version_0 <= other == strict_version_0.__le__(other)


# Generated at 2022-06-24 21:21:57.724916
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    print('test_Version___ge__')
    v1 = StrictVersion('1.2.1')
    v2 = StrictVersion('1.2.1')
    v3 = StrictVersion('1.2.2')
    v4 = StrictVersion('1.2.0')
    v5 = StrictVersion('1.2.a')
    assert v1 >= v2
    assert not v1 >= v3
    assert v1 >= v4
    assert not v1 >= v5


# Generated at 2022-06-24 21:22:06.787478
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Create an instance of a class
    # Declare an instance of class Version
    strict_version_0 = StrictVersion()
    # declare a str
    vstring_0 = '1.0'
    # invoke the __init__ method of class Version on strict_version_0 with vstring_0
    try:
        strict_version_1 = StrictVersion(vstring_0)
    except ValueError:
        pass
    # declare a bool
    # Assert that strict_version_1 is greater than or equals to strict_version_0
    assert strict_version_1 >= strict_version_0


# Generated at 2022-06-24 21:22:13.633335
# Unit test for method __le__ of class Version
def test_Version___le__():
    
    strict_version_0 = StrictVersion()
    try:
        strict_version_0.__le__(strict_version_0)
    except:
        pass
    else:
        raise AssertionError('Version.__le__ failed to raise exception')


# Generated at 2022-06-24 21:22:15.879076
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    assert_equal(strict_version_0.__ge__(''), NotImplemented)


# Generated at 2022-06-24 21:22:21.051679
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Assert "StrictVersion('9.9.8') > '2.2.2'" is correct.
    assert StrictVersion('9.9.8') > '2.2.2'


# Generated at 2022-06-24 21:22:24.625075
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion(None)
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion('0.0.0')
    loose_version_0 = LooseVersion('0.0.0')
    strict_version_3 = StrictVersion()
    strict_version_4 = StrictVersion()


# Generated at 2022-06-24 21:22:37.128217
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # noinspection PyTypeChecker
    strict_version_0 = StrictVersion()
    # noinspection PyTypeChecker
    strict_version_1 = StrictVersion()
    retval_0 = strict_version_1.__ge__(strict_version_0)
    retval_1 = strict_version_1.__ge__(strict_version_1)
    assert retval_0 or retval_1


# Generated at 2022-06-24 21:22:42.441741
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    version_0 = Version()
    version_1 = version_0._cmp("2.2")
    version_2 = version_0._cmp("1.1")
    version_3 = version_0._cmp("0.0")
    version_4 = version_1 < version_2

    # verify equality
    assert version_2 == version_3
    # verify that inequality is reflected
    assert version_4 == False



# Generated at 2022-06-24 21:22:46.863615
# Unit test for method __le__ of class Version
def test_Version___le__():
    v_0 = Version()
    v_1 = LooseVersion()
    v_2 = ''
    v_0.__le__(v_1)
    v_1.__le__(v_2)


# Generated at 2022-06-24 21:22:48.917846
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert StrictVersion() <= StrictVersion(), "StrictVersion() <= StrictVersion()"


# Generated at 2022-06-24 21:22:58.648726
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('0')
    strict_version_0.__le__(strict_version_1)
    strict_version_1.__le__(strict_version_0)
    strict_version_2 = StrictVersion('0.0')
    strict_version_0.__le__(strict_version_2)
    strict_version_2.__le__(strict_version_0)
    strict_version_3 = StrictVersion('0.0.0')
    strict_version_0.__le__(strict_version_3)
    strict_version_3.__le__(strict_version_0)
    strict_version_4 = StrictVersion('0.0.0.0')
    strict_version_

# Generated at 2022-06-24 21:23:00.617708
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print("\n======== Case 0: Version() > StrictVersion()")
    test_case_0()


# Generated at 2022-06-24 21:23:03.965824
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    assert Version.__gt__("a","b") == NotImplemented
    assert Version.__gt__("b","a") == NotImplemented


# Generated at 2022-06-24 21:23:08.824683
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v1 = Version('1.0')
    v2 = Version('1.1')

    assert v1 >= v1
    assert v2 >= v2
    assert not v1 >= v2
    assert v2 >= v1



# Generated at 2022-06-24 21:23:16.004865
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    print("\nTest LooseVersion parse method")
    lv = LooseVersion("1.5.1")
    assert lv.version == [1, 5, 1], lv.version
    lv.parse("161")
    assert lv.version == [161], lv.version
    lv.parse("3.10a")
    assert lv.version == [3, 10, 'a'], lv.version
    lv.parse("8.02")
    assert lv.version == [8, 2], lv.version
    lv.parse("3.4j")
    assert lv.version == [3, 4, 'j'], lv.version
    lv.parse("1996.07.12")
    assert lv.version == [1996, 7, 12], lv.version
    l

# Generated at 2022-06-24 21:23:23.656433
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # PSF License (see licenses/PSF-license.txt or https://opensource.org/licenses/Python-2.0)
    #
    # Code from class Version in vendored copy of distutils/version.py from CPython 3.9.5

    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion()

    if (strict_version_1 > strict_version_2):
        print("strict_version_1 > strict_version_2")
        raise AssertionError



# Generated at 2022-06-24 21:23:38.162488
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion()
    other_0 = Version()
    assert strict_version_0.__le__(other_0) == True

# Generated at 2022-06-24 21:23:40.566837
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion('0.0.0')
    assert strict_version_1 >= strict_version_0


# Generated at 2022-06-24 21:23:42.951914
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1_Version = Version()
    v2_Version = Version()
    assert v1_Version.__gt__(v2_Version)


# Generated at 2022-06-24 21:23:47.496973
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    cases = [
        (str(strict_version_0), str(strict_version_1)),
        (str(strict_version_0), str(str(strict_version_1))),
        (str(strict_version_0), str(StrictVersion(str(strict_version_1)))),
        (str(strict_version_0), str(StrictVersion((str(strict_version_1)))))
    ]
    for c in cases:
        inp = (c[0], c[1])
        out = (inp == inp)
        assert out or not out , "strict_version_0.__ge__(strict_version_1) failed"



# Generated at 2022-06-24 21:23:55.702113
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_1 = StrictVersion()

    # Verify that subclass instances can be compared with superclass instances
    assert strict_version_1 <= LooseVersion()

    # Verify that the 'other' argument is not modified
    loose_version_1 = LooseVersion()
    orig_loose_version_1 = copy.deepcopy(loose_version_1)
    strict_version_1 <= orig_loose_version_1
    assert loose_version_1 == orig_loose_version_1

    # Verify that the 'other' argument can be None
    strict_version_1 <= None

    # Verify that the 'other' argument can be an instance of an incompatible type
    strict_version_1 <= Version()


# Generated at 2022-06-24 21:24:00.712294
# Unit test for method __le__ of class Version
def test_Version___le__():
    message = "Test case 0: "
    assert test_case_0(), message
# --- end of test_Version___le__ (...) ---


# Generated at 2022-06-24 21:24:01.976596
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert Version.__le__(Version(), None) is NotImplemented


# Generated at 2022-06-24 21:24:11.337762
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Test with parameters: vstring='', other=''
    vstring = ''
    other = ''
    strict_version_0 = StrictVersion(vstring)
    strict_version_1 = StrictVersion(other)

    try:
        retval_0 = strict_version_0._cmp(other)
        retval_1 = strict_version_1._cmp(vstring)
        if retval_0 != retval_1:
            testcase_error("retval_0, retval_1")
    except ValueError:
        pass
    except Exception as e:
        testcase_error(e)

# Generated at 2022-06-24 21:24:16.271200
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version_0 = StrictVersion('1.2.3')
    strict_version_1 = StrictVersion('1.2.3.dev456')
    assert (strict_version_0 <= strict_version_1)


# Generated at 2022-06-24 21:24:21.405064
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion("v2.2.2")
    strict_version_1 = StrictVersion("v3.3.3")
    # AssertionError: assert ((strict_version_0) > (strict_version_1))
    assert ((strict_version_0) > (strict_version_1))


# Generated at 2022-06-24 21:24:37.497951
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    if (strict_version_0 >= strict_version_1):
        return
    raise RuntimeError


# Generated at 2022-06-24 21:24:41.981412
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    print("\nTesting test_case 0 for __gt__")
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion("1")
    assert strict_version_0 < strict_version_1, "The result does not match the expected result"


# Generated at 2022-06-24 21:24:45.766756
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    if (strict_version_0 > strict_version_1):
        raise AssertionError


# Generated at 2022-06-24 21:24:51.687599
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version = StrictVersion()
    version1 = StrictVersion("0.0")
    result = version.__ge__(version1)


# Generated at 2022-06-24 21:24:56.681085
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion('1.2.2')
    strict_version_1 = StrictVersion('1.2.3')
    strict_version_0.__gt__(strict_version_1)


# Generated at 2022-06-24 21:24:59.141560
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    if strict_version_1 > strict_version_0:
        raise RuntimeError


# Generated at 2022-06-24 21:25:04.521051
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    v1 = StrictVersion('1.101.0')
    v2 = StrictVersion('1.101')
    v1_gt_v2 = v1 > v2
    assert v1_gt_v2
    return 0


# Generated at 2022-06-24 21:25:08.570583
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_0_gt = strict_version_0.__gt__(strict_version_1)


# Generated at 2022-06-24 21:25:13.044147
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    other_0 = str()
    try: 
        strict_version_0._cmp(other_0)
    except NotImplementedError as e:
        pass
    except:
        raise AssertionError("Unexpected exception raised")


# Generated at 2022-06-24 21:25:16.900789
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    assert (strict_version_0 >= None) is NotImplemented
    assert None >= strict_version_0 is NotImplemented


# Generated at 2022-06-24 21:25:24.960772
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    assert v >= Version()


# Generated at 2022-06-24 21:25:28.660169
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert not Version.__ge__(Version(), StrictVersion())


# Generated at 2022-06-24 21:25:30.158852
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    """Test for method Version.__ge__"""
    assert len(str(Version())) > 0


# Generated at 2022-06-24 21:25:33.621348
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion('2.2.2')

    strict_version_0_ge = (strict_version_0 >= (StrictVersion('1.1.1')))
    assert strict_version_0_ge


# Generated at 2022-06-24 21:25:37.752800
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    # requires that __ge__ return True or False (or Raise Exception)
    assert isinstance(strict_version_0 >= 'string', (bool, type(None)))


# Generated at 2022-06-24 21:25:42.371337
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    result = strict_version_0.__ge__('0.0')
    assert result == True


# Generated at 2022-06-24 21:25:47.702472
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    try:
        strict_version_0.__ge__(strict_version_0)
    except ValueError as raised_ValueError:
        print('ValueError raised, message:')
        print(raised_ValueError)
        # Exception must be handled
    else:
        print('OK')
    # Expected output:
    # ValueError raised, message:
    # version argument is required


# Generated at 2022-06-24 21:25:56.258100
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    strict_version = LooseVersion()

# Generated at 2022-06-24 21:25:58.649831
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    version_0 = Version()
    version_0._cmp = lambda x: 0
    version_0.__ge__(Version())


# Generated at 2022-06-24 21:26:00.745527
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Imports
    strict_version = StrictVersion()
    if strict_version >= 0:
        return True


# Generated at 2022-06-24 21:26:10.698852
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('1.0')
    assert v.version == [1, 0], "Version did not parse correctly"


# Generated at 2022-06-24 21:26:19.017068
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    for test_case in test_cases:
        # 'test_case' is a tuple of type (vstring, components,
        #                                  strict_components)
        vstring = test_case[0]
        lv = LooseVersion(vstring)
        lv.parse(vstring)
        components = lv.version
        if components != tuple(test_case[1]):
            print("Component mismatch for", vstring)
            print("  expected %s, got %s" % (test_case[1], components))
            sys.exit(1)
    print("LooseVersion.parse() passes its unit tests.")

if __name__ == "__main__":
    test_LooseVersion_parse()

# Generated at 2022-06-24 21:26:30.542244
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Test case #0
    lv0 = LooseVersion()
    lv0.parse("1.13++")
    lv0.version
    # lv.version must be [1, 13, '++']
    lv0.vstring
    # lv.vstring must be '1.13++'
    lv0.version[2]
    # lv.version[2] must be '++'
    lv0.version[1]
    # lv.version[1] must be 13
    lv0.version[0]
    # lv.version[0] must be 1
    # Test case #1
    lv1 = LooseVersion()
    lv1.parse("5.5.kw")
    lv1.version
    # lv.version must be [5, 5

# Generated at 2022-06-24 21:26:35.037312
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # version is a str
    version = '1.5.1'
    expected_result = [1, 5, 1, '', '']
    actual_result = LooseVersion(version).version

# Generated at 2022-06-24 21:26:44.875422
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v_str_0 = '3.3.2.2.2.2b'
    v_str_1 = '1.0.1pl1'
    v_str_2 = '2.2.2'
    loose_version_0 = LooseVersion(v_str_1)
    loose_version_1 = LooseVersion(v_str_0)
    loose_version_2 = LooseVersion(v_str_1)
    loose_version_1.parse(v_str_2)
    assert type(loose_version_0) == LooseVersion
    assert type(loose_version_1) == LooseVersion
    assert loose_version_1.vstring == '2.2.2'
    assert loose_version_1.version == ['2', '2', '2']
    assert loose_

# Generated at 2022-06-24 21:26:46.664181
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:26:49.568328
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    version = LooseVersion()
    version.parse('1.2a2')
    assert str(version) == '1.2a2', 'parse failed'


# Generated at 2022-06-24 21:26:53.591634
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    str_0 = '1.5.1'
    looseversion_0 = LooseVersion(str_0)
    ret_val_0 = LooseVersion.parse(looseversion_0, str_0)
    assert ret_val_0 is None
    return


# Generated at 2022-06-24 21:26:57.204448
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse('1.2.4.4')
    assert lv.version == (1, 2, 4, 4)
    lv.parse('1')
    assert lv.version == (1,)



# Generated at 2022-06-24 21:27:04.937360
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Case 1: Parsing the version number string 1.5.1
    strict_version_1 = LooseVersion('1.5.1')
    assert strict_version_1.version == (1,5,1)

    # Case 2: Parsing the version number string 1.5.2b2
    strict_version_2 = LooseVersion('1.5.2b2')
    assert strict_version_2.version == (1,5,2,'b',2)

    # Case 3: Parsing the version number string 161
    strict_version_3 = LooseVersion('161')
    assert strict_version_3.version == (161,)

    # Case 4: Parsing the version number string 3.10a
    strict_version_4 = LooseVersion('3.10a')