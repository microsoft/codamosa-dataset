

# Generated at 2022-06-24 21:17:25.934542
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = LooseVersion('2.2.1')
    assert v < LooseVersion('2.2.2')
    assert v < LooseVersion('2.3')
    assert v < LooseVersion('2.3.0')
    assert not v < LooseVersion('2.2.0')
    assert v < '2.2.0'
    assert v < '2.2.2'
    assert v < '2.3'
    assert v < '2.3.0'
    assert not v < '2.2.1'


# Generated at 2022-06-24 21:17:32.346724
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    assert loose_version_0.__eq__(loose_version_0)
    loose_version_1 = LooseVersion()
    assert loose_version_1.__eq__(loose_version_1)


# Generated at 2022-06-24 21:17:34.570744
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # loose_version_0 = LooseVersion()
    LooseVersion("1.1") > "1.0"


# Generated at 2022-06-24 21:17:37.595261
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    loose_version_0 = LooseVersion()
    other_0 = LooseVersion()
    assert loose_version_0.__ge__(other_0) == NotImplemented


# Generated at 2022-06-24 21:17:39.980707
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    assert(version_0 < version_1 == False)


# Generated at 2022-06-24 21:17:49.167163
# Unit test for method __le__ of class Version

# Generated at 2022-06-24 21:17:52.681114
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    v = Version()
    with pytest.raises(NotImplementedError):
        v.__ge__("")


# Generated at 2022-06-24 21:17:53.548745
# Unit test for method __le__ of class Version
def test_Version___le__():
    r = 0
    return r


# Generated at 2022-06-24 21:17:57.341560
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion("1.3")
    s = version_0.__str__()
    assert s == "1.3"
    version_1 =  StrictVersion("1.3a2")
    s = version_1.__str__()
    assert s == "1.3a2"


# Generated at 2022-06-24 21:18:03.249902
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion("1.0")
    assert(loose_version_0 == loose_version_1)


# Generated at 2022-06-24 21:18:15.100674
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    try:
        str(StrictVersion('3.3.3.3'))
    except ValueError:
        pass

# Generated at 2022-06-24 21:18:15.801989
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    pass


# Generated at 2022-06-24 21:18:17.763049
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Calling Version.__le__ with arguments (LooseVersion('1.2.3'))
    v = LooseVersion('1.2.3')
    assert v <= '1.2.4'



# Generated at 2022-06-24 21:18:27.798993
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:18:32.203708
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    loose_version_0 = LooseVersion()
    ans = loose_version_0.__gt__(1.2)
    assert type(ans) == bool
    assert ans == False


# Generated at 2022-06-24 21:18:36.575336
# Unit test for method __le__ of class Version
def test_Version___le__():
    r"""
    Version.__le__(self, other)

    __le__ implements <=

    It returns NotImplemented if the built-in version of <= is used instead
    of the rich comparison version.
    """
    pass


# Generated at 2022-06-24 21:18:43.283432
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    # Testing value
    v = 0
    # Testing with default value
    loose_version_0 = LooseVersion()
    if loose_version_0.__gt__(v):
        raise RuntimeError("Unexpected behavior for method __gt__ of class Version")
    # Testing with value 0
    loose_version_1 = LooseVersion()
    if loose_version_1.__gt__(v):
        raise RuntimeError("Unexpected behavior for method __gt__ of class Version")
    # Testing with value 0
    loose_version_2 = LooseVersion()
    if loose_version_2.__gt__(v):
        raise RuntimeError("Unexpected behavior for method __gt__ of class Version")


# Generated at 2022-06-24 21:18:49.310364
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version0 = Version()
    version1 = Version('1.0.0')
    version2 = Version('2.0.0')
    version3 = Version('3.0.0')
    version4 = Version('4.0.0')
    version5 = Version('5.0.0')
    version6 = Version('6.0.0')
    version7 = Version('7.0.0')
    version8 = Version('8.0.0')
    version9 = Version('9.0.0')
    version10 = Version('10.0.0')
    version11 = Version('11.0.0')
    version12 = Version('12.0.0')
    version13 = Version('13.0.0')
    version14 = Version('14.0.0')

# Generated at 2022-06-24 21:18:49.969800
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    test_case_0()


# Generated at 2022-06-24 21:18:55.882513
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version(vstring="1.7.1")
    loose_version_0 = LooseVersion('1.7.1')
    assert v <= loose_version_0
    assert v <= "1.7.1"
    v = Version(vstring="1.7.1")
    assert loose_version_0 <= v
    assert "1.7.1" <= v


# Generated at 2022-06-24 21:19:04.590840
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = lambda x: 0
    version_0._cmp = lambda x: 0
    assert(version_0 <= version_1)


# Generated at 2022-06-24 21:19:11.205582
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    # Function signatures
    # parse(self, vstring: str) -> None

    # Testing valid version number
    version_1 = StrictVersion()
    version_1.parse('0.9.6')
    version_2 = StrictVersion()
    version_2.parse('1.0.4b1')

    # Testing invalid version number
    version_3 = StrictVersion()
    try:
        version_3.parse('1.3c4')
    except ValueError:
        pass


# Generated at 2022-06-24 21:19:21.301863
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():

    assert str(StrictVersion()) == '0.0.0'
    assert str(StrictVersion('1.0')) == '1.0.0'
    assert str(StrictVersion('1.0.0')) == '1.0.0'
    assert str(StrictVersion('1.0a0')) == '1.0a0'
    assert str(StrictVersion('1.0a1')) == '1.0a1'
    assert str(StrictVersion('1.0a10')) == '1.0a10'
    assert str(StrictVersion('1.0a1.1')) == '1.0a1.1'
    assert str(StrictVersion('1.0b1')) == '1.0b1'

# Generated at 2022-06-24 21:19:30.399657
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    try:
        version_0.__le__(None)
    except:
        e = sys.exc_info()[1]
        val = repr(e)
        ut.verify(isinstance(e, TypeError))
        ut.verify(str(e) == "unorderable types: Version() <= NoneType()")
        ut.verify(str(e) == "unorderable types: Version() <= NoneType()")
        ut.verify(str(e) == "unorderable types: Version() <= NoneType()")
        ut.verify(str(e) == "unorderable types: Version() <= NoneType()")
        ut.verify(str(e) == "unorderable types: Version() <= NoneType()")

# Generated at 2022-06-24 21:19:32.638019
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    str_0 = version_0.__lt__(version_0)
    assert str_0 == False


# Generated at 2022-06-24 21:19:37.232707
# Unit test for method __le__ of class Version
def test_Version___le__():
    ver0 = Version()
    ver1 = Version()
    result = ver0.__le__(ver1)
    if result:
        print('Pass')
    else:
        print('Fail')


# Generated at 2022-06-24 21:19:38.631793
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert test_case_0(test_case_1())


# Generated at 2022-06-24 21:19:46.364918
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    # Create instance of class StrictVersion with arg '0.4'
    version_0 = StrictVersion('0.4')
    # Create expected value
    expected_value_0 = '0.4'
    # Call method __str__ from instance version_0
    actual_value_0 = version_0.__str__()
    # Check for equality between the expected and actual value
    assert expected_value_0 == actual_value_0


# Generated at 2022-06-24 21:19:51.347013
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    version_1 = StrictVersion("1.0")
    assert version_1.version == (1, 0, 0)
    assert version_1.prerelease == None

    version_2 = StrictVersion("1.0b1")
    assert version_2.version == (1, 0, 0)
    assert version_2.prerelease == ('b', 1)


# Generated at 2022-06-24 21:19:56.569385
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_0._cmp = ValueError()
    version_1._cmp = TypeError()
    assert version_0 <= version_1
    assert version_0 <= version_1
    assert version_0 <= version_1
    assert version_1 <= version_0
    assert version_1 <= version_0


# Generated at 2022-06-24 21:20:04.564204
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version('1.2.3')
    assert version_0 <= version_0
    assert version_0 <= '1.2.3'


# Generated at 2022-06-24 21:20:08.328673
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_0.__le__(version_1)
    assert version_2, "Unit test failed!"


# Generated at 2022-06-24 21:20:12.328568
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion(NONE)
    version_0.parse(str_1)
    str_2 = str(version_0)
    assert str_2 == str_1
    msg = "'%s' != '%s'" % (str_2, str_1)
    raise AssertionError(msg)


# Generated at 2022-06-24 21:20:18.941068
# Unit test for method __le__ of class Version
def test_Version___le__():
    v = Version('1.2.3')
    assert v <= v
    assert v <= '1.2.3'
    assert v <= '1.2.3-rc1'
    assert v <= '1.2.3-2'
    assert v <= '1.2.4'
    assert v <= '1.3'
    assert v <= '2.1'
    assert not v <= '1.2.2'
    assert not v <= '1.2.2-rc1'
    assert not v <= '1.1.1'
    assert not v <= '0.9'


# Generated at 2022-06-24 21:20:24.536262
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    # Test comparison of class Version with class Version
    assert (version_0 <= version_2)
    assert (version_2 <= version_4)
    assert (version_4 <= version_6)
    # Test comparison of class Version with class StrictVersion
    assert (version_0 <= StrictVersion())
    assert (version_0 <= StrictVersion("1.2.3"))
    assert (version_2 <= StrictVersion("1.2.3"))
    # Test comparison of class Version with class LooseVersion
    assert (version_0 <= LooseVersion())

# Generated at 2022-06-24 21:20:26.608550
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    version_0 = Version("1.1")

    assert version_0.__lt__("1.1") == False, "Return value was not True as expected"


# Generated at 2022-06-24 21:20:29.317077
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0.__le__(version_1) == NotImplemented


# Generated at 2022-06-24 21:20:35.002365
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    ver = Version('v0.0.1')

    if not (ver < 'v0.0.2'):
        raise Exception("Expected true, got false, type: " + str(type(ver)))

    if (ver < 'v0.0.1'):
        raise Exception("Expected false, got true, type: " + str(type(ver)))


# Generated at 2022-06-24 21:20:38.668817
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    result_0 = version_0 <= version_1
    expected_0 = True
    assert result_0 == expected_0, 'result_0 = %s, expected_0 = %s' % (result_0, expected_0)


# Generated at 2022-06-24 21:20:43.054677
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    ver_string = "0.4.0"
    version_0 = StrictVersion(ver_string)
    assert str(version_0) == ver_string


# Generated at 2022-06-24 21:20:50.497291
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0 = version_0

# Generated at 2022-06-24 21:20:51.546862
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    result = version_0 < version_1
    assert result is False


# Generated at 2022-06-24 21:20:53.573026
# Unit test for method __le__ of class Version
def test_Version___le__():
    test_case_0()

# Generated at 2022-06-24 21:20:55.161659
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()

    assert version_0 < version_1


# Generated at 2022-06-24 21:20:57.025533
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    # test_Version___le__()
    version_0 = Version("1.1.1")


# Generated at 2022-06-24 21:21:04.357035
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_0._cmp = lambda x,y: return_value_0
    version_1._cmp = lambda x,y: return_value_1
    version_2._cmp = lambda x,y: return_value_2
    version_0._cmp(version_1)
    version_0._cmp(version_2)
    version_0._cmp(version_2)


# Generated at 2022-06-24 21:21:06.889585
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse("1.2.1")
    assert v.version == [1, 2, 1]


# Generated at 2022-06-24 21:21:10.977596
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()

    assert version_0 <= version_1


# Generated at 2022-06-24 21:21:12.874034
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    assert version_0 <= version_1


# Generated at 2022-06-24 21:21:16.044851
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_1 = Version()
    version_2 = Version()
    version_1.__le__(version_2)


# Generated at 2022-06-24 21:21:33.467310
# Unit test for method __le__ of class Version
def test_Version___le__():
    try:
        eq_(version_0.__le__(None), NotImplemented)
    except Exception as e:
        eq_(e.error_code, 1101)
        eq_(e.description, "Version expected type Version, but got {0}".format(type(None)))
    else:
        ok_(False, "shouldn't be reached")



# Generated at 2022-06-24 21:21:36.050150
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_0.parse('a')
    version_1.parse('b')
    version_0.__le__(version_1)

# Generated at 2022-06-24 21:21:42.272067
# Unit test for method __le__ of class Version
def test_Version___le__():
    v0 = Version("1.2.3.4")
    v1 = Version("1.2.3.4")
    v2 = Version("1.2.3.3")
    v3 = Version("1.2.3.5")
    assert v0 <= v1
    assert not v0 <= v2
    assert v0 <= v3


# Generated at 2022-06-24 21:21:44.078803
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_0 <= version_1


# Generated at 2022-06-24 21:21:45.907016
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    assert version_0 <= version_0


# Generated at 2022-06-24 21:21:55.695481
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    version_0 = StrictVersion()
    version_1 = StrictVersion()
    version_1.version = (1, 0)
    version_1.prerelease = 'a'
    version_2 = StrictVersion()
    version_2.version = (1, 0, 0)
    version_2.prerelease = 'b'
    version_2.prerelease = 'b'
    version_3 = StrictVersion()
    version_3.version = (2, 2)
    version_3.prerelease = 'a'
    version_3.prerelease = 'a'
    version_4 = StrictVersion()
    version_4.version = (0, 1)
    version_4.prerelease = 'b'
    version_4.prerelease = 'b'
    version_5 = StrictVersion()
   

# Generated at 2022-06-24 21:21:56.557912
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()


# Generated at 2022-06-24 21:21:58.125293
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    version_0 = Version()
    version_1 = Version()
    assert (version_0 < version_1)


# Generated at 2022-06-24 21:22:03.129687
# Unit test for method __le__ of class Version
def test_Version___le__():
    print('Testing...')

    version_0 = Version()
    assert_equal(version_0.__le__(Version()), True)
    print('Passed.')

if __name__ == '__main__':
    test_Version___le__()

# Generated at 2022-06-24 21:22:12.388177
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()

    # Test without exception
    try:
        result = version_0 <= Version()
        if not result:
            raise Exception("Failed on case 0")
    except:
        raise Exception("Failed on case 0")

    # Test with exception (invalid literal)
    try:
        Version(vstring=(5 + 5))
    except ValueError as raised_exception:
        if str(raised_exception) != "'version' must be an instance of 'str', not 'int'":
            raise Exception("Failed on case 1")
    except:
        raise Exception("Failed on case 1")

    # Test with exception (unsupported operand type)

# Generated at 2022-06-24 21:22:44.091893
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    assert not Version().__lt__(Version())


# Generated at 2022-06-24 21:22:45.506518
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_0.__init__()



# Generated at 2022-06-24 21:22:51.348170
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version('')
    assert not version_0 < version_1


# Generated at 2022-06-24 21:22:55.579007
# Unit test for method __le__ of class Version
def test_Version___le__():
    """
    >>> v1 = Version()
    >>> v2 = Version()
    >>> v1 <= v2
    True
    >>> v2 <= v1
    True
    >>> v1 <= Version('1')
    False
    >>> v2 <= Version('1')
    False
    """
    pass



# Generated at 2022-06-24 21:22:58.016050
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    # because of the line below, this currently fails 
    #assert not (version_0 <= None)


# Generated at 2022-06-24 21:23:03.919282
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_0.parse('1.2')
    version_1 = Version()
    version_1.parse('1.3.0')
    try:
        if version_0 <= version_1:
            pass
    except (AttributeError, NameError, TypeError, ValueError) as e:
        print(str(e))


# Generated at 2022-06-24 21:23:08.282150
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    base_version = '1.2.3'
    version = StrictVersion(base_version)
    assert str(version) == base_version, 'ERROR: method __str__ of class StrictVersion'


# Generated at 2022-06-24 21:23:13.935839
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    expected = True
    version_0 = Version()
    version_1 = Version()
    result = version_0 < version_1
    assert result == expected


# Generated at 2022-06-24 21:23:18.315958
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    version_1 = Version()
    bool_0 = version_0 < version_1
    assert not bool_0
    bool_0 = version_1 < version_0
    assert not bool_0


# Generated at 2022-06-24 21:23:22.259764
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    try:
        assert str(strict_version_0) == '0.0.0'
    except AssertionError:
        raise AssertionError("Expected: '0.0.0', Actual: '" + str(strict_version_0) + "'")


# Generated at 2022-06-24 21:24:00.710776
# Unit test for method __lt__ of class Version

# Generated at 2022-06-24 21:24:02.292658
# Unit test for method __le__ of class Version
def test_Version___le__():
    print('Test # 1')
    test_case_0()


# Generated at 2022-06-24 21:24:10.293521
# Unit test for method __le__ of class Version
def test_Version___le__():
    # Input parameters
    version_0 = Version()
    version_1 = Version()

    # Invoke method
    retval = version_0.__le__(version_1)

    # Check return value
    assert isinstance(retval, bool)
    assert retval

    # Check attributes of the return value.
    # NB: We currently don't check the values since they are hard to predict.
    # assert retval.attr() == expected_value


# Generated at 2022-06-24 21:24:13.416845
# Unit test for method __le__ of class Version
def test_Version___le__():
    v1 = Version()
    v2 = Version()
    if not (v1 == v2):
        print("False")
    else:
        print("True")

test_Version___le__()

# Generated at 2022-06-24 21:24:15.534829
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    assert version_0.__lt__(7) == False


# Generated at 2022-06-24 21:24:23.399070
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    try:
        test_case_1()
    except ValueError as e:
        print('test_case_1 failed')
        print(e)

    try:
        test_case_2()
    except ValueError as e:
        print('test_case_2 failed')
        print(e)

    try:
        test_case_3()
    except ValueError as e:
        print('test_case_3 failed')
        print(e)

    try:
        test_case_4()
    except ValueError as e:
        print('test_case_4 failed')
        print(e)

    try:
        test_case_5()
    except ValueError as e:
        print('test_case_5 failed')
        print(e)



# Generated at 2022-06-24 21:24:28.010433
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    # Test n:0 <-> 0:n
    assert (version_0 <= version_1)

    # Test n:m <-> n:m
    assert (version_0 <= version_0)

    # Test n:m <-> m:n
    assert (version_0 <= version_1)


# Generated at 2022-06-24 21:24:38.180307
# Unit test for method __le__ of class Version
def test_Version___le__():
  T = True
  F = False
  v1 = Version()
  v2 = Version()
  if (v1 <= v2) != T:
    raise RuntimeError("Test Failed")
  v2 = "0.0.0"
  if (v1 <= v2) != T:
    raise RuntimeError("Test Failed")
  v2 = "0.0.1"
  if (v1 <= v2) != T:
    raise RuntimeError("Test Failed")
  v2 = "1.0.0"
  if (v1 <= v2) != T:
    raise RuntimeError("Test Failed")
  v2 = "0.0.0.0"
  if (v1 <= v2) != F:
    raise RuntimeError("Test Failed")
  v2 = "0.2.0"

# Generated at 2022-06-24 21:24:40.370875
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert True, "Test if a Version class can be instantiated with no args"


# Generated at 2022-06-24 21:24:49.112421
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    # Evaluating 'Version() <= Version()'
    assert_equal(Version() <= Version(), False, 'evaluating Version() <= Version()')
    # Evaluating 'Version() <= "str"'
    assert_equal(Version() <= "str", False, 'evaluating Version() <= "str"')
    # Evaluating 'Version() <= Version()'
    assert_equal(Version() <= Version(), False, 'evaluating Version() <= Version()')
    # Evaluating 'Version() <= "str"'
    assert_equal(Version() <= "str", False, 'evaluating Version() <= "str"')
    # Evaluating 'Version() <= Version()'
    assert_equal(Version() <= Version(), False, 'evaluating Version() <= Version()')
    # Evaluating 'Version() <= "str"'

# Generated at 2022-06-24 21:26:01.881873
# Unit test for method __le__ of class Version
def test_Version___le__():
    """
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()

    version_1.parse('1.1.1')
    version_2.parse('1.1.1')
    version_3.parse('2.2.2')
    version_4.parse('2.2.2')

    return (version_1._cmp(version_2) == 0) and (version_2._cmp(version_1) == 0) and (version_1 <= version_2) and (version_2 <= version_3) and (version_3 == version_4) and (version_1 < version_3) and (not (version_2 < version_2))
    """



# Generated at 2022-06-24 21:26:06.549779
# Unit test for method __le__ of class Version
def test_Version___le__():
    class_name = "Version"
    method_name = "__le__"
    # class Version of module distutils.version
    # def __le__(self, other):
    #     c = self._cmp(other)
    #     if c is NotImplemented:
    #         return c
    #     return c <= 0
    # This method is a default implementation of an operator method.
    
    # Test case 0
    test_case_0()



# Generated at 2022-06-24 21:26:11.178164
# Unit test for method __le__ of class Version
def test_Version___le__():
    with pytest.raises(NotImplementedError):
        version_2 = Version()
        version_2.__le__("%s" % version_2)


# Generated at 2022-06-24 21:26:12.889034
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    assert not version_0.__lt__(version_0)


# Generated at 2022-06-24 21:26:18.844834
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = version_0
    # test_case_0 for testing __le__
    if 1:
        print('Testing __le__')
        assert (version_0 <= version_1) == True
        assert (version_0 <= version_2) == True
        assert (version_1 <= version_2) == True
        if hasattr(__debug__, 'die'):
            __debug__.die('test_case_0 is complete')

test_Version___le__()

# Generated at 2022-06-24 21:26:23.120988
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version('45.6.78')
    assert not (version_0 <= '45.6.78')
    assert not (version_0 <= '45.6.78')


# Generated at 2022-06-24 21:26:31.128372
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_1._cmp(version_0)
    version_1.__ge__(version_0)
    version_1.__gt__(version_0)
    version_1._cmp('1.2.3')
    version_1.__ge__('1.2.3')
    version_1.__gt__('1.2.3')
    version_1._cmp('')
    version_1.__ge__('')
    version_1.__gt__('')


# Generated at 2022-06-24 21:26:34.182529
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    version_0 = Version()
    ver1 = Version()
    ver1.parse('1.0')
    result = (version_0 < ver1)
    assert result


# Generated at 2022-06-24 21:26:37.068038
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    Class_0 = Version()
    assert version_0 <= Class_0


# Generated at 2022-06-24 21:26:45.502053
# Unit test for method __le__ of class Version
def test_Version___le__():
    version_0 = Version()
    version_1 = Version()
    version_2 = Version()
    version_3 = Version()
    version_4 = Version()
    version_5 = Version()
    version_6 = Version()
    version_7 = Version()
    version_8 = Version()
    version_9 = Version()
    version_10 = Version()
    version_11 = Version()
    version_12 = Version()
    version_13 = Version()
    version_14 = Version()
    version_15 = Version()

    try:
        # exception thrown for ordered comparisons between instances of 'Version' and instances of 'object'
        result_1 = (version_0 <= version_1)
    except TypeError as e:
        assert type(e) == TypeError
