

# Generated at 2022-06-24 21:17:26.252998
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    def do_test(s):
        strict_version = StrictVersion()
        strict_version.parse(s)
        return str(strict_version)

    assert do_test('1') == '1'
    assert do_test('2.7.2.2') == '2.7.0'
    assert do_test('1.3.a4') == '1.3'
    assert do_test('1.3pl1') == '1.3'
    assert do_test('1.3c4') == '1.3'


# Generated at 2022-06-24 21:17:31.626474
# Unit test for method __le__ of class Version
def test_Version___le__():
    # The following call does not match the type signature
    with pytest.raises(TypeError):
        Version.__le__('')


# Generated at 2022-06-24 21:17:42.652954
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    strict_version_0 = StrictVersion()
    
    # Test exception handling
    try:
        res = strict_version_0.__str__()
    except ValueError as err:
        print("ValueError: ", err)
    except:
        print("unexpected exception")
        
    # Test normal case
    strict_version_0.parse("0.4")
    res = strict_version_0.__str__()
    print("strict_version_0.__str__()=", res)
    assert(res == "0.4")
    # Test normal case
    strict_version_1 = StrictVersion("0.4.0")
    res = strict_version_1.__str__()
    print("strict_version_1.__str__()=", res)

# Generated at 2022-06-24 21:17:50.841324
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    #
    # Test method __eq__ of class Version
    #
    strict_version_0 = StrictVersion()
    strict_version_0 = StrictVersion("2.2.2")
    try:
        if (strict_version_0 == StrictVersion("2.2.2")):
            pass
    except ValueError as error:
        str_0 = "Version is not a valid version number."
        if ((str_0) != (str(error))):
            raise error
    except TypeError as error:
        str_0 = "< not supported between instances of 'StrictVersion' and 'StrictVersion'"
        if ((str_0) != (str(error))):
            raise error
    except AttributeError as error:
        str_0 = "'StrictVersion' object has no attribute 'append'"

# Generated at 2022-06-24 21:17:54.481479
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    assert (strict_version_0 >= 1) == False
    assert (strict_version_0 >= 0) == True



# Generated at 2022-06-24 21:17:55.693604
# Unit test for method __le__ of class Version
def test_Version___le__():
    assert '1.0.0' < '1.0.1'


# Generated at 2022-06-24 21:17:57.737672
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v = Version()
    s = str(v)
    v2 = Version(s)
    if (v2 != v):
        print ("Not correct")


# Generated at 2022-06-24 21:18:01.504914
# Unit test for method parse of class StrictVersion
def test_StrictVersion_parse():
    strict_version_0 = StrictVersion()
    # test case:
    # input: '0.4.0'
    # expected: 0.4.0
    try:
        strict_version_0.parse('0.4.0')
    except ValueError as err:
        assert False, str(err)


# Generated at 2022-06-24 21:18:06.248953
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    regex = "(v[0-9]+\.[0-9]+\.[0-9]+)"
    s = "v1.1.1"
    r = re.compile(regex, RE_FLAGS)
    version_tuple = re.match(regex, s).group(1).split('.')
    version_tuple = [int(x) for x in version_tuple]
    version_tuple = tuple(version_tuple)
    strict_version_0 = StrictVersion(s)
    strict_version_0.parse(s)
    strict_version_1 = StrictVersion(version_tuple)
    check_0 = strict_version_0 == strict_version_1
    return check_0


# Generated at 2022-06-24 21:18:17.291620
# Unit test for method __str__ of class StrictVersion
def test_StrictVersion___str__():
    print("Test for StrictVersion class method __str__")
    # Test #1
    strict_version_1 = StrictVersion("1.0.4a3")
    print(strict_version_1)
    # Test #2
    strict_version_2 = StrictVersion("1.0.4b1")
    print(strict_version_2)
    # Test #3
    strict_version_3 = StrictVersion("1.0.4")
    print(strict_version_3)
    # Test #4
    strict_version_4 = StrictVersion()
    print(strict_version_4)
    # Test #5
    strict_version_5 = StrictVersion("1.0")
    print(strict_version_5)
    # Test #6

# Generated at 2022-06-24 21:18:27.313550
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v1 = Version()
    assert v1.__lt__(v1) == False


# Generated at 2022-06-24 21:18:33.977117
# Unit test for method __le__ of class Version
def test_Version___le__():
    strict_version = StrictVersion()
    strict_version_0 = StrictVersion()
    version = Version()
    version_0 = Version()
    not_implemented = NotImplemented
    strict_version.__le__(strict_version_0)
    version.__le__(version_0)
    version.__le__(version)
    version.__le__(not_implemented)


# Generated at 2022-06-24 21:18:34.809193
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    assert StrictVersion() >= Version()


# Generated at 2022-06-24 21:18:38.424433
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    strict_version_0 = StrictVersion()
    other = "string"
    result = strict_version_0.__ge__(other)
    assert result == NotImplemented
    print("test passed")
    return


# Generated at 2022-06-24 21:18:49.445061
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version = StrictVersion()
    strict_version_1 = StrictVersion('0.0')
    strict_version_2 = StrictVersion('0.0.1')
    #strict_version_2 = StrictVersion('0.0.2')
    #strict_version_3 = StrictVersion('0.0.3')
    #strict_version_4 = StrictVersion('0.0.4')
    #strict_version_5 = StrictVersion('0.0.5')
    #strict_version_6 = StrictVersion('0.0.6')
    #strict_version_7 = StrictVersion('0.0.7')
    #strict_version_8 = StrictVersion('0.0.8')
    #strict_version_9 = StrictVersion('0.

# Generated at 2022-06-24 21:19:00.290298
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    strict_version_string = '2.0'
    strict_version = StrictVersion(strict_version_string)
    assert str(strict_version) == strict_version_string

    strict_version_string_1 = '3.0'
    strict_version_1 = StrictVersion(strict_version_string_1)
    assert str(strict_version_1) == strict_version_string_1

    assert strict_version < strict_version_1
    assert strict_version_1 > strict_version
    assert strict_version <= strict_version_1
    assert strict_version_1 >= strict_version
    assert not strict_version > strict_version_1
    assert not strict_version_1 < strict_version
    assert not strict_version >= strict_version_1
    assert not strict_version_1 <= strict

# Generated at 2022-06-24 21:19:03.745556
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    # Create a version instance

    strict_version = StrictVersion('1.2.3')

    # Compare the version instance to a string

    assert strict_version == '1.2.3'

    # Compare the version instance to itself

    assert strict_version == strict_version


# Generated at 2022-06-24 21:19:06.089383
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    vcmp = v._cmp(StrictVersion())
    assert vcmp < 0


# Generated at 2022-06-24 21:19:09.688715
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    result = strict_version_1.__gt__(strict_version_0)
    assert result is False
    assert not result


# Generated at 2022-06-24 21:19:20.094852
# Unit test for method __ge__ of class Version
def test_Version___ge__():
    # Test for method __ge__ (Version)
    # Tests for LooseVersion class.
    v1 = LooseVersion('1.1.0')
    assert v1 >= '1.1.0'
    assert v1 >= '1.1'
    assert v1 >= '1'
    assert v1 >= LooseVersion('1.1.0')
    assert v1 >= LooseVersion('1.1')
    assert v1 >= LooseVersion('1')
    assert not (v1 >= '1.1.1')
    assert not (v1 >= '2')
    assert not (v1 >= LooseVersion('2'))
    assert not (v1 >= LooseVersion('1.1.1'))
    # Tests for StrictVersion class.
    v2 = StrictVersion('1.1')
    assert v2

# Generated at 2022-06-24 21:19:32.675840
# Unit test for method __eq__ of class Version
def test_Version___eq__():

    # implicit conversion of the string to the StrictVersion object,
    # then strict_version_0._cmp() to create the NotImplemented result
    assert StrictVersion("0") == "0"


# Generated at 2022-06-24 21:19:40.602209
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v_0 = StrictVersion(0)
    v_1 = StrictVersion(1)
    try:
        if v_0 < v_1:
            print("PASSED: Calling __lt__ method of Version with parameters: " + v_0 + " and " + v_1)
        else:
            print("FAILED: Calling __lt__ method of Version with parameters: " + v_0 + " and " + v_1)
    except:
        print("FAILED: Calling __lt__ method of Version with parameters: " + v_0 + " and " + v_1)


# Generated at 2022-06-24 21:19:44.907783
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    loose_version_0 = LooseVersion('3.7')
    loose_version_0._cmp('3.8')




# Generated at 2022-06-24 21:19:46.801653
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    vc = Version()
    assert vc.__lt__(vc)


# Generated at 2022-06-24 21:19:54.493188
# Unit test for method __lt__ of class Version
def test_Version___lt__():

    # Call the __lt__ method of a Version object
    #
    # Expected result: returns false if compared to the same object, true if compared to another
    # object with the same _cmp, and finally NotImplemented if the last check raises an exception
    assert ( StrictVersion('1.0') < StrictVersion('1.0') ) == False, 'result must be False'
    assert ( StrictVersion('2.0') < StrictVersion('1.0') ) == True, 'result must be True'
    assert ( StrictVersion('1.0') < StrictVersion('2.0') ) == NotImplemented, 'result must be NotImplemented'


# Generated at 2022-06-24 21:19:57.922032
# Unit test for method __gt__ of class Version
def test_Version___gt__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    # __gt__ returns True
    assert (strict_version_0.__gt__(strict_version_1) == True)


# Generated at 2022-06-24 21:20:04.511456
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    try:
        strict_version_0 = StrictVersion()
        strict_version_1 = StrictVersion()
        # assert(strict_version_0 < strict_version_1)
        # assert(not (strict_version_0 < strict_version_1))
    except AssertionError:
        return 1
    except:
        return 2

test_case_0()
test_Version___lt__()

# Generated at 2022-06-24 21:20:07.115950
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v0 = Version()
    v1 = Version()
    assert(v0 == v1)


# Generated at 2022-06-24 21:20:14.386097
# Unit test for method __lt__ of class Version
def test_Version___lt__():
    v = Version()
    v_0 = Version()
    # Test for the case when both operands are Version instances
    if v._cmp(v_0) is NotImplemented:
        assert False

    # Test for the case when left operand is Version and right one is str
    if v._cmp("1.4a") is NotImplemented:
        assert False

    # Test for the case when left operand is str and right one is Version
    if "1.4a".__lt__(v) is NotImplemented:
        assert False

    # Test for the case when both operands are str
    assert "1.4a".__lt__("1.4") == True


# Generated at 2022-06-24 21:20:19.479339
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    seq = [("1.2", ('1', '2')),
           ("1.2.3.4", ('1', '2', '3', '4')),
           (".1.2.3", ('1', '2', '3')),
           ("1.2.3.4a1", ('1', '2', '3', '4a1')),
           ("1.2.a1.4", ('1', '2', 'a1', '4')),
           ("1.2.0.4", ('1', '2', '0', '4'))]

    for (value, expected) in seq:
        v = LooseVersion()
        v.parse(value)
        assert v.version == expected

# Generated at 2022-06-24 21:20:25.442552
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert True


# Generated at 2022-06-24 21:20:26.725362
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        assert Version() == Version()
        assert not Version() == None
        assert not Version() == 1
    except:
        print('Unit test failed')


# Generated at 2022-06-24 21:20:28.713442
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert (
        Version() == Version()
    ), "__eq__ doesn't return True when comparing to self."


# Generated at 2022-06-24 21:20:38.225573
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    boolean_0 = Version.__eq__(strict_version_0, '-')
    strict_version_1 = StrictVersion()
    boolean_1 = Version.__eq__(strict_version_1, '-')
    boolean_2 = Version.__eq__(strict_version_0, strict_version_1)
    boolean_3 = Version.__eq__(strict_version_0, '-')
    boolean_4 = Version.__eq__(strict_version_1, '-')
    boolean_5 = Version.__eq__(strict_version_0, strict_version_1)
    strict_version_2 = StrictVersion()
    boolean_6 = Version.__eq__(strict_version_2, '-')
    strict_

# Generated at 2022-06-24 21:20:45.144512
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion('1.4.10')
    strict_version_1 = StrictVersion('2.2.0')

    # AssertionError: StrictVersion ('2.2.0') != StrictVersion ('1.4.10')
    # assert strict_version_0 == strict_version_1
    assert strict_version_0 != strict_version_1


# Generated at 2022-06-24 21:20:49.963707
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version()
    version_1 = Version()
    version_0.__eq__(version_1)


# Generated at 2022-06-24 21:20:54.665194
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    v0 = Version()
    v1 = Version()
    #assert (v0 == v1), "Unit test for Version.__eq__: failed"
    print("Unit test for Version.__eq__: passed.")


# Generated at 2022-06-24 21:20:56.871341
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    test_string_0 = ""
    strict_version_0 = StrictVersion(test_string_0)
    assert strict_version_0 == strict_version_0


# Generated at 2022-06-24 21:21:06.237972
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():

    v = LooseVersion("1.1.0")
    if v.version != [1, 1, 0]:
        print("test_LooseVersion_parse: expected %r, got %r" % ([1, 1, 0], v.version))
    assert v.version == [1, 1, 0]

    v = LooseVersion("1.1.0+dev")
    if v.version != [1, 1, 0, 'dev']:
        print("test_LooseVersion_parse: expected %r, got %r" % ([1, 1, 0, 'dev'], v.version))
    assert v.version == [1, 1, 0, 'dev']

    v = LooseVersion("1.1.0+dev.1")

# Generated at 2022-06-24 21:21:12.866563
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    for i in range(2):
        # Setup
        strict_version_0 = StrictVersion()
        strict_version_0.parse('0')
        version_1 = StrictVersion()
        version_1.parse('0')

        # Invoke method
        result = strict_version_0 == version_1

        # Verify results
        assert result



# Generated at 2022-06-24 21:21:26.967973
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    version_0 = Version('7.0.0')
    version_1 = Version()
    version_1.parse('7.0.0')
    version_0 == version_1


# Generated at 2022-06-24 21:21:34.437970
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # No input argument
    assert Version().__eq__() == NotImplemented
    # Input argument of invalid type
    assert Version().__eq__(True) == NotImplemented
    # Input argument of invalid type
    assert Version().__eq__(1) == NotImplemented
    # Input argument of invalid type
    assert Version().__eq__({}) == NotImplemented
    # Input argument of invalid type
    assert Version().__eq__(Version) == NotImplemented


# Generated at 2022-06-24 21:21:36.622312
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    str_0 = str(strict_version_0)
    assert (str_0 == str_0)


# Generated at 2022-06-24 21:21:41.151194
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    assert strict_version_0 == strict_version_0
    assert not strict_version_0 == StrictVersion()
    assert not strict_version_0 == object()


# Generated at 2022-06-24 21:21:50.125669
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion('0.0.0')
    strict_version_3 = StrictVersion('1.0.0')
    strict_version_4 = StrictVersion()
    strict_version_4.parse('1.0.0')
    strict_version_5 = StrictVersion('1.0.0')
    strict_version_6 = StrictVersion('1.0.0')
    strict_version_7 = StrictVersion('1.0.0')
    strict_version_7.parse('1.0.0')
    strict_version_8 = StrictVersion('1.0.0')

    assert strict_version_1 == strict_version_2
    assert strict_version_3 == strict

# Generated at 2022-06-24 21:21:51.508615
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert not Version().__eq__(StrictVersion("1.0.0"))


# Generated at 2022-06-24 21:22:01.340423
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    # Step 1- Create an object of the class under test
    instance_of_class_under_test = LooseVersion()

    # Step 2- Invoke the method under test.
    instance_of_class_under_test.parse("1")

    # Step 3- Check if we got the expected result
    _temp = instance_of_class_under_test
    assert isinstance(_temp, LooseVersion)
    try:
        assert _temp.vstring == "1"
    except AttributeError as e:
        raise AssertionError(str(e))
    try:
        assert _temp.version == [1]
    except AttributeError as e:
        raise AssertionError(str(e))
    return _temp



# Generated at 2022-06-24 21:22:04.828292
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    version_0 = Version()
    version_1 = version_0
    strict_version_1 = StrictVersion()
    assert version_0 == version_0


# Generated at 2022-06-24 21:22:06.919054
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    s = StrictVersion()
    o = StrictVersion()
    assert s.__eq__(o) == NotImplemented


# Generated at 2022-06-24 21:22:15.719983
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion("3")
    strict_version_2 = StrictVersion("3.0.0")
    strict_version_3 = StrictVersion("4")
    strict_version_4 = StrictVersion("4")
    strict_version_5 = StrictVersion("4.1")
    strict_version_6 = StrictVersion("4.2")
    strict_version_7 = StrictVersion("4.3")
    version_8 = 3
    version_9 = 3.0

# Generated at 2022-06-24 21:22:54.550912
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Test no arguments
    if str(Version.__eq__(Version())) != 'NotImplemented':
        print('Failed test_Version___eq__ no argument')

    # Test one argument (self)
    if str(Version.__eq__(Version(), None)) != 'NotImplemented':
        print('Failed test_Version___eq__ one argument')

    # Test two arguments (self and None)
    if str(Version.__eq__(Version(), None, None)) != 'NotImplemented':
        print('Failed test_Version___eq__ two arguments')

    # Test more than two arguments (self and 'other' and None)
    if str(Version.__eq__(Version(), None, None, None)) != 'NotImplemented':
        print('Failed test_Version___eq__ more than two arguments')

   

# Generated at 2022-06-24 21:22:55.988166
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    # Assert if 'self._cmp(other)' returns NotImplemented
    assert False


# Generated at 2022-06-24 21:23:02.295280
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion('0.0.0')
    strict_version_1 = StrictVersion('1.0.0')
    assert not (strict_version_0 == strict_version_1), 'Failed to assert not (strict_version_0 == strict_version_1), got {}'.format(strict_version_0 == strict_version_1)



# Generated at 2022-06-24 21:23:06.820606
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion('0.1')
    strict_version_1 = StrictVersion('0.1')

    assert False == (strict_version_0 == strict_version_1)
    assert False == (strict_version_0 == '0.1')
    assert False == (strict_version_0 == Version('0.1'))


# Generated at 2022-06-24 21:23:13.581689
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    """
    Tests for method LooseVersion.parse
    """

    # Test argument of type <class LooseVersion>
    test_version = LooseVersion("1.1.1")
    test_version.parse("1.1.1")

    # Test argument of type <class StrictVersion>
    test_version = LooseVersion("1.1.1")
    test_version.parse("1.1.1")

    # Test argument of type <class str>
    test_version = LooseVersion("1.1.1")
    test_version.parse("1.1.1")

    # Test argument of type <type NotImplemented>
    test_version = LooseVersion("1.1.1")
    test_version.parse("1.1.1")



# Generated at 2022-06-24 21:23:20.396338
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        import random
        # Unit test for method __eq__ of class Version

        class StrictVersionTest(StrictVersion):
            def __init__(self, some_string):
                print(some_string)

        StrictVersionTest('TestCase_0')
        strict_version_0 = StrictVersion('TestCase_1')
        print(str(strict_version_0))
        strict_version_0 = StrictVersion()
        print(str(strict_version_0))
    except:
        print('test_Version___eq__ FAILED')


# Generated at 2022-06-24 21:23:21.954006
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    assert StrictVersion().__eq__(StrictVersion()) == True


# Generated at 2022-06-24 21:23:31.597921
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    strict_version_1 = StrictVersion()
    strict_version_2 = StrictVersion("0.0")
    strict_version_3 = StrictVersion("0.1")
    strict_version_4 = StrictVersion("0.0.1")
    strict_version_5 = StrictVersion("0.0.1.1")
    strict_version_6 = StrictVersion("0.0.2")

    assert not (strict_version_0 == strict_version_1)
    assert strict_version_0.__eq__(strict_version_1) == NotImplemented
    assert not (strict_version_0 == strict_version_2)
    assert strict_version_0.__eq__(strict_version_2) == NotImplemented
   

# Generated at 2022-06-24 21:23:40.818829
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    strict_version_0 = StrictVersion()
    str_version_0 = str(strict_version_0)
    str_version_1 = str(strict_version_0)
    try:
        strict_version_0.__eq__(str_version_1)
    except TypeError:
        pass
    strict_version_0 = StrictVersion()
    str_version_0 = str(strict_version_0)
    str_version_1 = str(strict_version_0)
    try:
        strict_version_0.__eq__(str_version_1)
    except TypeError:
        pass
    strict_version_0 = StrictVersion()
    str_version_0 = str(strict_version_0)
    str_version_1 = str(strict_version_0)

# Generated at 2022-06-24 21:23:45.113920
# Unit test for method __eq__ of class Version
def test_Version___eq__():
    try:
        strict_version_0 = StrictVersion()
        try:
            strict_version_0._cmp(None)
            assert False
        except ValueError:
            pass
    except NotImplementedError:
        pass

    try:
        strict_version_0 = StrictVersion()
        try:
            strict_version_0._cmp('None')
            assert False
        except ValueError:
            pass
    except NotImplementedError:
        pass



# Generated at 2022-06-24 21:25:13.453876
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    instance = LooseVersion("1.5.1")


# Generated at 2022-06-24 21:25:17.518575
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v = LooseVersion()
    v.parse('2.2beta29')
    assert str(v) == '2.2beta29'
    print('test_LooseVersion_parse passed')


# Generated at 2022-06-24 21:25:26.649117
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    test_obj = LooseVersion()
    test_obj.parse("")
    assert test_obj.version == []
    assert test_obj.vstring == ""

    test_obj.parse("1")
    assert test_obj.version == [1]
    assert test_obj.vstring == "1"

    test_obj.parse("1.2.3.4")
    assert test_obj.version == [1, 2, 3, 4]
    assert test_obj.vstring == "1.2.3.4"

    test_obj.parse("a.b.c")
    assert test_obj.version == ['a', 'b', 'c']
    assert test_obj.vstring == "a.b.c"

    test_obj.parse("a.b.c.d.e")
    assert test_

# Generated at 2022-06-24 21:25:30.982458
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    components = [x for x in LooseVersion.component_re.split('1.0') if x and x != '.']
    for i, obj in enumerate(components):
        try:
            components[i] = int(obj)
        except ValueError:
            pass
    assert(components == [1, 0])


# Generated at 2022-06-24 21:25:42.014585
# Unit test for method parse of class LooseVersion

# Generated at 2022-06-24 21:25:48.533036
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    def check_LooseVersion_parse(vstring, version):
        version_instance = LooseVersion(vstring)
        assert version_instance.vstring == vstring, "%s, %s" % (version_instance.vstring, vstring)
        assert version_instance.version == version, "%s, %s" % (version_instance.version, version)
    #
    check_LooseVersion_parse('1', ['1'])
    check_LooseVersion_parse('1.0', ['1', '0'])
    check_LooseVersion_parse('1.0.0', ['1', '0', '0'])
    check_LooseVersion_parse('0.0', ['0', '0'])
    check_LooseVersion_parse('0.1', ['0', '1'])
    check_Lo

# Generated at 2022-06-24 21:25:50.738946
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()
    lv.parse("3.2a2")

# Generated at 2022-06-24 21:25:53.869508
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    'Test parse for LooseVersion'
    pass


# Generated at 2022-06-24 21:26:00.419730
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    v1 = LooseVersion()
    v2 = LooseVersion()
    str_res1 = v1.parse("1.5.1")
    str_res2 = v2.parse("1.5.2b2")

    if not isinstance(v1, Version):
        return 0

    if not isinstance(v2, Version):
        return 0

    if str_res1 != None:
        return 0

    if str_res2 != None:
        return 0

    return 1


# Generated at 2022-06-24 21:26:04.585681
# Unit test for method parse of class LooseVersion
def test_LooseVersion_parse():
    lv = LooseVersion()

if __name__ == '__main__':
    test_case_0()